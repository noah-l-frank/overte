"""Callback copied State1: exact Feature8/Drain4 metadata, no live Feature.

The role object below is a historical value decoder with a real constructor.
It is deliberately not a Feature/Runtime/SDK owner and exposes no input API.
Existing original-only archive factories retain all literal file/clock checks.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.phase_witness_publisher import PhaseWitnessPublisher
from adapters.phase_retirement_publisher import PhaseRetirementPublisher
from adapters.script_feature.history import pack,unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import arguments,identifier
from feature_journeys.retirement_receipts import WEB_SCENE_STAGE
from ios.adapters.emote_retirement import Frozen
from ios.adapters.emote_callback_terminal import PROFILE8,IOSEmoteCallbackResponsibility
from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
from ios.adapters.emote_callback_window import IOSEmoteCallbackWindow
from ios.adapters.emote_callback_scene import IOSEmoteCallbackSceneRetirement
from ios.adapters.emote_callback_observation import IOSEmoteCallbackSampleRecovery
from ios.adapters.emote_callback_current_state import (CallbackCurrentState,graph,metadata_paths as gpu_paths)
from ios.adapters import emote_callback_drain_originals as drains
from ios.adapters.emote_final_inputs import validate as fixed_inputs
from ios.adapters.emote_final_recoveries import validate as recovery_originals
from ios.adapters.emote_scene_history import validate as scene_history
from ios.adapters.emote_scene_proof import rooted
from ios.adapters.emote_scene_order import IOSEmoteSceneOrder
from ios.adapters.emote_target_pair import original as target_pair,selected
from ios.adapters.graphics_configuration import settings
from ios.adapters.peer_admission import validate as admitted


class CallbackRoleState:
    """Parsed Feature8 payload only; never masquerades as a live Feature."""
    def __init__(self,value,*,store,run,role,locks):
        exact(value,{'iosEmoteFeatureVersion','runId','role','artifactRoot','fixtureUrl','imagePolicy','payload','targetPair','callbackProfile'})
        need(type(value['iosEmoteFeatureVersion']) is int and value['iosEmoteFeatureVersion']==8
            and same(value['callbackProfile'],PROFILE8) and value['runId']==run and value['role']==role)
        self.run,self.role,self.store=identifier(run),role,store
        self.lock,self.primary_lock=locks[role],locks['primary']
        self.lock.assert_held();self.primary_lock.assert_held()
        pair=target_pair(value['targetPair']);self.configured_pair=selected(pair)
        need(all(str(locks[key].path.parent)==pair[key+'StateRoot'] for key in ('primary','actor')))
        policy=settings(dict(artifactRoot=value['artifactRoot'],imagePolicy=value['imagePolicy']))
        self.root,self.policy=Path(policy['artifactRoot']),policy['imagePolicy']
        need(str(self.root)==pair[role+'ArtifactRoot'])
        self.fixture_url=value['fixtureUrl'];suffix='/runs/'+run+'/'
        need(type(self.fixture_url) is str and self.fixture_url.endswith(suffix))
        self.server_url=self.fixture_url[:-len(suffix)]
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0]
        need(value['payload']==pack([state]))
        exact(state,{'phase','binding','primaryBinding','actorAdmission','phaseInstance','initialTicket','lastCall','inputBarrier','cleanup','retirement'})
        need(state['phase']=='cleaned');context(state['binding']);context(state['primaryBinding'])
        identifier(state['phaseInstance']);identifier(state['initialTicket'])
        if role=='primary':
            actor=admitted(state['actorAdmission'],state['binding'])
            need(same(state['binding'],state['primaryBinding']) and same(actor,pair['actorBinding']))
        else:need(state['actorAdmission'] is None and same(state['binding'],pair['actorBinding']))
        need(same(state['primaryBinding'],pair['primaryBinding']))
        if state['lastCall'] is not None:
            call=arguments('feature.emotes.act',state['lastCall'])
            need(call['runId']==run and call['fixtureUrl']==self.fixture_url)
        if state['inputBarrier'] is not None:
            exact(state['inputBarrier'],{'index','sha256'});need(integer(state['inputBarrier']['index'],1))
        need(type(state['cleanup']) is list and 1<=len(state['cleanup'])<=128
            and type(state['retirement']) is dict)
        self.state,self.previous=deepcopy(state),deepcopy(value)
        need(same(store.read(),value))


class _PublicationArchive:
    """Explicit constructor for existing literal publisher decoders."""
    def __init__(self,role,store_for,validate_original,*,retirement=False):
        need(type(role) is CallbackRoleState and callable(store_for) and callable(validate_original))
        self.run,self.area,self.url,self.instance=role.run,'emotes',role.server_url,role.state['phaseInstance']
        self.binding,self.validate_original=deepcopy(role.state['binding']),validate_original
        self.live,self.decode_context=False,None
        self._store_for,self._kind=store_for,PhaseRetirementPublisher if retirement else PhaseWitnessPublisher
        prefix='phase-retirement' if retirement else 'phase-publication'
        self.store=store_for(role.lock.path.with_name(prefix+'-emotes-'+role.run+'-actor.json'))
        value=self.store.read();need(value is not None)
        # Only decoder ports are shared. No live constructor/guard/send exists.
        self.state=self._kind.decode(self,value)
        need(self.state['pending'] is None and self.state['records'])
    def record_store(self,ordinal):return self._store_for(self._kind.record_store(self,ordinal).path)
    def envelope(self,*args,**kwargs):return self._kind.envelope(self,*args,**kwargs)
    def original(self,*args,**kwargs):return self._kind.original(self,*args,**kwargs)
    def intent(self,*args,**kwargs):return self._kind.intent(self,*args,**kwargs)
    def phase_original(self,*args,**kwargs):return self._kind.phase_original(self,*args,**kwargs)
    def journal(self,*args,**kwargs):return self._kind.journal(self,*args,**kwargs)
    def receipt(self,*args,**kwargs):return self._kind.receipt(self,*args,**kwargs)
    def load(self,*args,**kwargs):return self._kind.load(self,*args,**kwargs)
    def _decode(self,*args,**kwargs):return PhaseWitnessPublisher._decode(self,*args,**kwargs)
    acquisition=staticmethod(PhaseWitnessPublisher.acquisition)


class _SceneOrderArchive(IOSEmoteSceneOrder):
    """Real archive constructor; only historical decode is selected."""
    def __init__(self,role,store):
        need(type(role) is CallbackRoleState and role.role=='primary')
        self.store,self.binding,self.run,self.area=store,role.state['binding'],role.run,'emotes'
        self.instance,self.url,self.stage=role.state['phaseInstance'],role.server_url,WEB_SCENE_STAGE
        self.admitted_original=role.state['actorAdmission']
        self.validate_admission=lambda value:dict(runId=self.run,phaseInstance=self.instance,binding=admitted(value,self.binding))
        self.actor=self.admission();self.state=self.decode(store.read())
    def read(self):need(False)


class CallbackCopiedResponsibility:
    SampleRecovery=IOSEmoteCallbackSampleRecovery
    def __init__(self,role,parts,keyed,live,store_for,copies):
        need(type(role) is CallbackRoleState and type(live) is IOSEmoteCallbackLive and live.historical and keyed.historical)
        self.flow,self.store_for=role,store_for
        fixed_inputs(self,copies,parts['raw'])
        recovery_names=['source-recovery','marker-recovery','sample-recovery','scene-gate']
        if role.role=='actor':recovery_names.append('peer-recovery')
        values={}
        for tail in recovery_names:
            store=self.path('ios-emote-'+role.role+'-'+tail+'.json',primary=tail=='source-recovery')
            values[str(store.path)]=store.read()
        recovery_originals(self,values,parts['sources'],parts['peers'],parts['scope'],parts['samples'])
        scene_history(self,values,parts['scope'],parts['restoration'],validate_original=rooted)
        ticket=live.record(live.state['records'][-1])['measurement']['ticket'];retirement=role.state['retirement']
        need(retirement['original'] in role.state['cleanup'])
        if role.role=='primary':
            need(retirement['kind']=='primary-scene-ordered'
                and self.path('ios-emote-primary-peer-retirement.json').read() is None)
            reader=_SceneOrderArchive(role,self.path('ios-emote-primary-scene-order-'+role.run+'.json'))
            need(reader.state['records'] and retirement['peerReceipt'] in reader.state['records']
                and retirement['peerReceipt']['entry']['ticket']==ticket)
        else:
            need(retirement['kind']=='actor-published')
            publications=_PublicationArchive(role,store_for,parts['observer'].validate_original)
            row=publications.load(publications.state['records'][-1]);last=parts['observer'].state['records'][-1]
            need(row['mode']=='published' and same(row['intent']['original'],dict(iosEmoteObservationReferenceVersion=1,**last)))
            retirements=_PublicationArchive(role,store_for,IOSEmoteCallbackSceneRetirement(keyed).actor_original,retirement=True)
            reference=retirement['publisher'];need(reference in retirements.state['records']);row=retirements.load(reference)
            need(row['mode']=='published' and same(row['intent']['original'],retirement['original'])
                and row['intent']['body']['ticket']==ticket and row['intent']['body']['stage']==WEB_SCENE_STAGE)
            need(sum(retirements.load(ref)['mode']=='published' and retirements.load(ref)['intent']['body']['ticket']==ticket
                for ref in retirements.state['records'])==1)
    def path(self,name,*,primary=False):
        lock=self.flow.primary_lock if primary else self.flow.lock
        return self.store_for(lock.path.with_name(name))


def _parents(keyed,raw,samples,state):
    # This is selected_parents' literal loop with explicit decoded state;
    # unlike a live Samples owner, this function has no mutable state field.
    original=raw['sampleOwners'];originals=drains.store(keyed.root,keyed.binding,keyed.run,keyed.role,keyed.lock)
    need(len(original['current'])==len(state['rows']))
    parents={}
    for row,reference in zip(state['rows'],original['current']):
        frame=drains.read_frame(originals,reference)
        need(frame['kind']=='owner' and same(frame['row'],row))
        sample=samples.record(row);drains.sample_owner(frame['owner'],sample,keyed.root,keyed.binding,keyed.run,keyed.role,keyed.lock)
        need(row['requestId'] not in parents);parents[row['requestId']]=deepcopy(frame['owner'])
    frames=keyed.rendered_owner.frames_owner
    for reference in frames.state['records']:
        original=frames.original(reference);owners=unpack(original['owner']);need(len(owners)==1)
        request=original['requestId'];need(request not in parents);parents[request]=owners[0]
    return parents


class IOSEmoteCallbackCopiedState:
    VERSION=1
    def __init__(self,copies,*,run,lock,actor_lock,retirement=None):
        need(type(copies) is dict and 1<=len(copies)<=256 and isinstance(lock,ScriptSourceLock)
            and isinstance(actor_lock,ScriptSourceLock) and lock.path!=actor_lock.path)
        lock.assert_held();actor_lock.assert_held()
        if retirement is not None:
            from ios.adapters.emote_callback_retirement_view import CallbackRetirementView
            need(type(retirement) is CallbackRetirementView and retirement.run==run
                and retirement.locks['primary'] is lock and retirement.locks['actor'] is actor_lock)
            retirement.guard()
        self.retirement=retirement
        self.run,self.locks,self.used=identifier(run),dict(primary=lock,actor=actor_lock),set()
        self.copies=deepcopy(copies)
        for path,value in self.copies.items():
            need(type(path) is str and Path(path).is_absolute() and Path(path).resolve()==Path(path)
                and (value is None or type(value) is dict))
    def store(self,path):
        path=Path(path);key=str(path);need(key in self.copies);self.used.add(key);return Frozen(path,self.copies[key])
    def role(self,role):
        lock=self.locks[role];primary_lock=self.locks['primary']
        store=self.store(lock.path.with_name('ios-emote-'+role+'-feature.json'))
        state=CallbackRoleState(store.read(),store=store,run=self.run,role=role,locks=self.locks)
        live_store=self.store(lock.path.with_name('ios-emote-'+role+'-'+self.run+'-terminal-live.json'))
        with IOSEmoteCallbackLive.archive_scope(live_store.read(),store=live_store,lock=lock,primary_lock=primary_lock) as live:
            need(live.historical and live.owner is None and live.state['pending'] is None and live.state['records']
                and live.run==self.run and live.role==role and live.root==state.root and same(live.policy,state.policy)
                and same(live.binding,state.state['binding']) and same(live.primary_binding,state.state['primaryBinding'])
                and live.fixture_url==state.fixture_url and live.phase_instance==state.state['phaseInstance'])
            snapshot=live.read_frame(live.state['records'][-1])['snapshot']
            need(same(snapshot['reference'],state.state['cleanup'][-1]))
            keyed,raw,sources,peers=graph(snapshot,lock=lock,primary_lock=primary_lock)
            used=len(keyed.state['records'])+len(keyed.state['abandoned'])
            if used<128:need(keyed.record_store(used+1).read() is None)
            scope=drains.projection(raw['sampleOwners'],root=keyed.root,binding=keyed.binding,run=self.run,role=role,lock=lock,policy=keyed.policy)
            samples,sample_state=drains.sample_shell(raw['sampleOwners']['samples'],keyed.root,keyed.binding,self.run,role,lock,keyed.policy)
            parents=_parents(keyed,raw,samples,sample_state)
            paths=gpu_paths(keyed,raw,parents)
            subset={str(path):self.store(path).read() for path in paths}
            if self.retirement is None:
                parts=CallbackCurrentState(snapshot,subset,lock=lock,primary_lock=primary_lock).read()
            else:
                from ios.adapters.emote_callback_retired_state import CallbackRetiredState
                parts=CallbackRetiredState(snapshot,subset,lock=lock,primary_lock=primary_lock,retirement=self.retirement).read()
            need(parts['keyed'].historical)
            parts=dict(parts,raw=raw,restoration=keyed.rendered_owner.frames_owner)
            for tail in ('marker-files','marker-script'):self.store(lock.path.with_name('ios-emote-'+role+'-'+tail+'.json'))
            if role=='primary':
                for tail in ('cleanup-inputs','inputs','background'):self.store(lock.path.with_name('ios-emote-'+tail+'.json'))
            CallbackCopiedResponsibility(state,parts,keyed,live,self.store,self.copies)
            need(sources.frames and (peers is None or peers.frames))
            prefixes=[deepcopy(owner.frames[-1]['phaseAfter']) for owner in (sources,peers) if owner is not None]
            return state,live,prefixes
    def read(self):
        self.used=set()
        roots={lock.path.parent for lock in self.locks.values()}
        for role,lock in self.locks.items():
            value=self.copies.get(str(lock.path.with_name('ios-emote-'+role+'-feature.json')))
            need(type(value) is dict and type(value.get('artifactRoot')) is str);roots.add(Path(value['artifactRoot']))
        def literal():
            roles={role:self.role(role) for role in ('primary','actor')};p,a=roles['primary'][0],roles['actor'][0]
            need(p.root!=a.root and p.fixture_url==a.fixture_url and p.state['phaseInstance']==a.state['phaseInstance']
                and same(p.configured_pair,a.configured_pair)
                and same(admitted(p.state['actorAdmission'],p.state['binding']),a.state['binding'])
                and same(a.state['primaryBinding'],p.state['binding']))
            # The publisher is also consumed by Ownership; it was decoded here.
            need(self.used==set(self.copies))
            return IOSEmoteCallbackWindow(roles['primary'][1],roles['actor'][1]),{role:rows[2] for role,rows in roles.items()}
        if self.retirement is not None:self.retirement.guard()
        result=drains.checked_read(roots,literal)
        if self.retirement is not None:self.retirement.guard()
        return result


def metadata_paths(window,responsibilities):
    """Paths come only from genuine current Callback responsibilities/owners."""
    need(type(window) is IOSEmoteCallbackWindow and type(responsibilities) is list and len(responsibilities)==2)
    by_role={item.flow.role:item for item in responsibilities};exact(by_role,{'primary','actor'});paths=set()
    from ios.adapters.emote_callback_archive import capture
    for role,live in window.roles.items():
        responsibility=by_role[role];need(type(responsibility) is IOSEmoteCallbackResponsibility);responsibility.guard()
        flow=responsibility.flow;need(live.owner is not None and not live.historical and flow.lock is live.lock)
        snapshot=capture(live.owner,flow.state['cleanup'][-1]);keyed,raw,_sources,_peers=graph(snapshot,lock=live.lock,primary_lock=live.primary_lock)
        paths.update(Path(path) for path in responsibility.values)
        paths.update(Path(path) for path in snapshot['paths'].values())
        paths.update(path for path in keyed.rendered_owner.native_owner.paths.values() if path is not None)
        paths.update((flow.store.path,live.store.path))
        for tail in ('marker','samples','observer','marker-files','marker-script'):
            paths.add(flow.store.path.with_name('ios-emote-'+role+'-'+tail+'.json'))
        if role=='primary':
            for tail in ('cleanup-inputs','inputs','background'):paths.add(flow.store.path.with_name('ios-emote-'+tail+'.json'))
        need(same(raw['scope'],PrivateFeatureState(flow.store.path.with_name('ios-emote-'+role+'-marker.json')).read()))
    return [PrivateFeatureState(path) for path in sorted(paths)]
