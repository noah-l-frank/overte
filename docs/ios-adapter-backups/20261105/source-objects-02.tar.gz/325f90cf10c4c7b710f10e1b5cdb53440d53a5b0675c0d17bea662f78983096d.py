"""Actual closed definitions and finite original decorator chains; no verdict cache."""
from pathlib import Path
import ast,contextlib,dataclasses,sys,types,os,hashlib
from metadata_reader import pin as source_pin,meta as source_meta

def read_source(path):
    """Read one unchanged original source FD; no imports, cache or write port."""
    path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
    before=source_pin(path)
    descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        metadata={key:value for key,value in before.items()if key!='sha256'}
        assert source_meta(os.fstat(descriptor))==metadata
        with os.fdopen(descriptor,'rb',closefd=False)as stream:raw=stream.read(before['bytes']+1)
        assert source_meta(os.fstat(descriptor))==metadata==source_meta(path.lstat())
        assert len(raw)==before['bytes']and hashlib.sha256(raw).hexdigest()==before['sha256']
    finally:os.close(descriptor)
    assert source_pin(path)==before
    return raw.decode('utf-8')


def inventory(path):
    tree=ast.parse(read_source(path));functions={};classes={}
    for node in tree.body:
        if type(node)in(ast.FunctionDef,ast.AsyncFunctionDef):functions[node.name]=[ast.unparse(d)for d in node.decorator_list]
        elif type(node)is ast.ClassDef:
            rows=[]
            for fn in node.body:
                if type(fn)in(ast.FunctionDef,ast.AsyncFunctionDef):rows.append(dict(name=fn.name,decorators=[ast.unparse(d)for d in fn.decorator_list]))
            classes[node.name]=rows
    return dict(functions=functions,classes=classes)

EXACT_FROZEN_DATACLASSES={('adapters.normal_ui', 'Locator'): ('using', 'value'), ('ios.adapters.assets_image_ownership', 'ImageInventoryContext'): ('artifact_root', 'binding', 'run', 'initial_ticket', 'lock'), ('ios.adapters.assets_page_generations', 'AssetsPageGenerationContext'): ('birth', 'page', 'retirement'), ('ios.adapters.assets_page_ownership', 'AssetsPageInventoryContext'): ('episodes', 'scopes', 'birth')}

class DefinitionCustody:
    def __init__(self,declared,plan,pin):
        self.plan,self.pin=plan,pin;self.modules=[];self.classes=[];self.class_tables=[];self.class_table_owner=self.class_tables;self.functions=[];self.codes=[];self.factories=[];self.generated=[]
        self.implementation=tuple((n,f,f.__code__,f.__globals__)for n,f in type(self).__dict__.items()if type(f)is types.FunctionType)
        self.inventory_port=(inventory,inventory.__code__,inventory.__globals__,inventory.__defaults__,inventory.__closure__)
        self.source_reader_port=(read_source,read_source.__code__,read_source.__globals__,read_source.__defaults__,read_source.__kwdefaults__,read_source.__closure__)
        self.source_reader_dependencies=tuple((fn,fn.__code__,fn.__globals__,fn.__defaults__,fn.__kwdefaults__,fn.__closure__)for fn in(source_pin,source_meta))
        self.source_reader_aliases=(source_pin,source_meta,os,hashlib,hashlib.sha256)
        self.dataclass_schema=(EXACT_FROZEN_DATACLASSES,tuple(EXACT_FROZEN_DATACLASSES.items()))
        self.context_factory=contextlib.contextmanager
        self.context_controls=tuple((cls,n,f,f.__code__,f.__globals__)for cls in(contextlib._GeneratorContextManager,contextlib._GeneratorContextManagerBase)for n,f in vars(cls).items()if type(f)is types.FunctionType)
        for name,row in declared.items():
            module=sys.modules[name];namespace=vars(module);path=Path(namespace['__file__'])
            assert str(path)==row['path']and pin(path)==plan['sourceAndBinaryPins'][str(path)]and pin(path)['sha256']==row['sha256']
            assert inventory(path)==row['inventory'],('Definition source declaration changed',name,str(path))
            self.modules.append((name,module,tuple(namespace.items())))
            for member,decorators in row['inventory']['functions'].items():
                assert member in namespace,('Missing declared function',name,member,str(path))
                self.decorated(module,member,namespace[member],decorators)
            for clsname,methods in row['inventory']['classes'].items():
                assert clsname in namespace,('Missing declared class',name,clsname,str(path))
                cls=namespace[clsname];assert type(cls)is type and cls.__module__==name
                self.classes.append((cls,cls.__bases__,cls.__mro__))
                self.class_tables.append((cls,tuple(vars(cls).items())))
                if(name,clsname)in EXACT_FROZEN_DATACLASSES:
                    assert namespace['dataclass']is dataclasses.dataclass
                    assert vars(cls)['__dataclass_params__'].frozen is True
                    assert tuple(vars(cls)['__dataclass_fields__'])==EXACT_FROZEN_DATACLASSES[(name,clsname)]
                    for factory in(dataclasses.dataclass,dataclasses._process_class,dataclasses._FuncBuilder.add_fns_to_class):self.function(factory)
                    for slot in('__init__','__repr__','__eq__','__setattr__','__delattr__','__hash__'):
                        actual=vars(cls)[slot];assert type(actual)is types.FunctionType
                        seen=[]
                        while actual is not None:
                            assert not any(actual is old for old in seen);seen.append(actual)
                            if actual.__code__.co_filename=='<string>':self.generated.append((actual,module,cls,slot))
                            actual=getattr(actual,'__wrapped__',None)
                # Include assigned method aliases and property accessors, not
                # only syntax-defined functions. Each real defining namespace
                # must resolve to the actual pinned original module.
                for member,descriptor in vars(cls).items():
                    if type(descriptor)is property:
                        for fn in(descriptor.fget,descriptor.fset,descriptor.fdel):
                            if fn is not None:self.chain(fn)
                    else:
                        fn=descriptor.__func__ if type(descriptor)in(staticmethod,classmethod)else descriptor
                        if type(fn)is types.FunctionType:self.chain(fn)
                for declaration in methods:
                    member=declaration['name'];decorators=declaration['decorators'];descriptor=vars(cls)[member]
                    if any(d=='property'or d.endswith('.setter')or d.endswith('.deleter')for d in decorators):
                        assert type(descriptor)is property
                        fn=descriptor.fset if any(d.endswith('.setter')for d in decorators)else descriptor.fdel if any(d.endswith('.deleter')for d in decorators)else descriptor.fget
                        self.decorated(module,member,fn,[d for d in decorators if d!='property'and not d.endswith(('.setter','.deleter'))])
                    else:
                        fn=descriptor.__func__ if type(descriptor)in(staticmethod,classmethod)else descriptor
                        self.decorated(module,member,fn,[d for d in decorators if d not in('staticmethod','classmethod')])
        self.check()
    def remember(self,code):
        if not any(code is old for old in self.codes):
            self.codes.append(code)
            for value in code.co_consts:
                if type(value)is types.CodeType:self.remember(value)
    def function(self,fn):
        assert type(fn)is types.FunctionType
        code=fn.__code__;namespace=fn.__globals__;owner=sys.modules[namespace['__name__']]
        assert namespace is vars(owner)
        path=Path(code.co_filename)
        if not path.is_absolute():
            generated=[row for row in self.generated if row[0]is fn]
            if generated:
                assert len(generated)==1 and code.co_filename=='<string>'
                actual,module,cls,slot=generated[0];assert owner is module and namespace is vars(module)
                assert(module.__name__,cls.__name__)in EXACT_FROZEN_DATACLASSES and cls is vars(module)[cls.__name__]and fn.__name__==slot
                assert tuple(vars(cls)['__dataclass_fields__'])==EXACT_FROZEN_DATACLASSES[(module.__name__,cls.__name__)]
                assert vars(module)['dataclass']is dataclasses.dataclass
                path=Path(dataclasses.__file__)
            else:
                import importlib.machinery
                spec=vars(owner)['__spec__'];assert spec.origin=='frozen'and spec.loader is importlib.machinery.FrozenImporter and code.co_filename=='<frozen '+namespace['__name__']+'>'
                path=Path(vars(owner)['__file__'])
        assert self.pin(path)==self.plan['sourceAndBinaryPins'][str(path)]
        self.remember(code);defaults=fn.__defaults__;kw=fn.__kwdefaults__;closure=fn.__closure__
        row=(fn,code,namespace,owner,getattr(fn,'__wrapped__',None),defaults,tuple(defaults or()),kw,tuple((kw or{}).items()),closure,tuple(c.cell_contents for c in closure or()))
        self.functions.append(row);return row
    def chain(self,fn):
        seen=[]
        while fn is not None:
            assert not any(fn is old for old in seen);seen.append(fn)
            row=self.function(fn);fn=row[4]
    def decorated(self,module,name,fn,decorators):
        for expression in decorators:
            node=ast.parse(expression,mode='eval').body;called=type(node)is ast.Call;port=node.func if called else node
            assert type(port)is ast.Name and port.id in('contextmanager','operation','installed_entry','bounded'),('Undeclared decorator shape',module.__name__,name,expression)
            factory=vars(module)[port.id];factory_row=self.function(factory);self.factories.append(factory_row)
            assert type(fn)is types.FunctionType and type(getattr(fn,'__wrapped__',None))is types.FunctionType
            following=fn.__wrapped__;codes=[]
            def nested(code):
                for value in code.co_consts:
                    if type(value)is types.CodeType:codes.append(value);nested(value)
            nested(factory.__code__)
            assert any(fn.__code__ is code for code in codes)and fn.__globals__ is factory.__globals__
            closure=dict(zip(fn.__code__.co_freevars,fn.__closure__ or()))
            if port.id=='contextmanager':
                assert factory is self.context_factory and factory.__globals__ is vars(contextlib)
                assert set(closure)=={'func'}and closure['func'].cell_contents is following and following.__code__.co_flags&0x20
                assert not called
            else:
                key='method'if port.id=='bounded'else'function'
                assert key in closure and closure[key].cell_contents is following
                if port.id=='installed_entry':
                    assert called and not node.args and len(node.keywords)==1 and node.keywords[0].arg=='recorded_action'
                    literal=ast.literal_eval(node.keywords[0].value);assert type(literal)is bool and closure['recorded_action'].cell_contents is literal
                else:assert not called
            self.function(fn);fn=following
        assert type(fn)is types.FunctionType and fn.__globals__ is vars(module)and getattr(fn,'__wrapped__',None)is None
        self.function(fn)
    def check(self):
        schema,items=self.dataclass_schema
        assert EXACT_FROZEN_DATACLASSES is schema and tuple(schema.items())==items
        fn,code,ns,defaults,closure=self.inventory_port
        assert inventory is fn and fn.__code__ is code and fn.__globals__ is ns is globals()and fn.__defaults__ is defaults and fn.__closure__ is closure
        reader,code,namespace,defaults,keywords,closure=self.source_reader_port
        assert read_source is reader and reader.__code__ is code and reader.__globals__ is namespace is globals()
        assert reader.__defaults__ is defaults and reader.__kwdefaults__ is keywords and reader.__closure__ is closure
        assert all(actual is held for actual,held in zip((source_pin,source_meta,os,hashlib,hashlib.sha256),self.source_reader_aliases))
        for fn,code,namespace,defaults,keywords,closure in self.source_reader_dependencies:
            assert fn.__code__ is code and fn.__globals__ is namespace and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
        for name,fn,code,ns in self.implementation:assert vars(type(self))[name]is fn and fn.__code__ is code and fn.__globals__ is ns is globals()
        assert contextlib.contextmanager is self.context_factory
        for cls,name,fn,code,ns in self.context_controls:assert vars(cls)[name]is fn and fn.__code__ is code and fn.__globals__ is ns is vars(contextlib)
        for name,module,rows in self.modules:
            assert sys.modules.get(name)is module
            actual=vars(module);assert tuple(actual)==tuple(k for k,v in rows)and all(actual[k]is v for k,v in rows),('Current definition namespace changed',name)
        assert self.class_tables is self.class_table_owner
        for cls,bases,mro in self.classes:assert cls.__bases__ is bases and cls.__mro__ is mro
        # Only the genuine d0 ClassCleanupCustody may update this same list's
        # expected tuple after its original suite/classmethod call. Bases/MRO
        # and all function/code/default/closure rows remain independent.
        for cls,rows in self.class_tables:
            assert tuple(vars(cls))==tuple(k for k,v in rows)and all(vars(cls)[k]is v for k,v in rows)
        for fn,code,ns,owner,wrapped,defaults,values,kw,items,closure,cells in self.functions:
            assert fn.__code__ is code and fn.__globals__ is ns is vars(owner)and sys.modules.get(ns['__name__'])is owner
            assert getattr(fn,'__wrapped__',None)is wrapped and fn.__defaults__ is defaults and fn.__kwdefaults__ is kw and fn.__closure__ is closure
            assert len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values))
            assert tuple(kw or())==tuple(k for k,v in items)and all(kw[k]is v for k,v in items)
            assert len(closure or())==len(cells)and all(c.cell_contents is v for c,v in zip(closure or(),cells))
        return True
