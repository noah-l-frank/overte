"""Root-only fixed-six lower-FD source preparation; no subject imports."""
from pathlib import Path
import argparse,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from project_namespace_admission import project_namespace_admission
from source_execution_readiness import qualification
from definition_custody import inventory
SOURCE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/avatar-original-fixed-reply-retirement-source3-private-20261105'
SUBJECT_SHA='a0a28e894c6d25bd6ad56f4a977df1562a2acbf9f26208802fd85582e85b5555'
EXECUTORS=('prepare.py','run-six.py','supervise-six.py','fd_model_ports.py','definition_custody.py','metadata_reader.py','host_common.py',
    'closed_import_origins.py','source_execution_readiness.py','owned_write_boundary.py','class_cleanup_custody.py','project_namespace_admission.py',
    'readonly-shared-stdlib-sources.json','third-party-source-declarations.json','DECLARED-SOURCE-INVENTORY.json','SIX-CASE-RESOURCE-RECIPE.json')


def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','peer-freeze','peer-sha','expected-head','destination'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--root-reviewed-lower-fd-models-only',required=True,action='store_true');args=parser.parse_args()
    assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO and head()==args.expected_head
    physical={}
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path;row=pin(path)
        if digest is not None:assert row['sha256']==digest
        old=physical.setdefault(str(path),row);assert old==row;return row
    def packet(path,digest):
        path=Path(path);keep(path,digest);value=json.loads(path.read_text())
        for name,row in value['files'].items():
            assert not Path(name).is_absolute()and '..'not in Path(name).parts
            keep(path.parent/name,row if type(row)is str else row['sha256'])
    packet(SOURCE/'source-freeze.json',args.source_freeze);packet(SUBJECT/'source-freeze.json',SUBJECT_SHA)
    peer=Path(args.peer_freeze);assert peer.is_absolute()and peer.is_relative_to(REPO/'.ios-host-tmp');packet(peer,args.peer_sha)
    for name,row in json.loads((SOURCE/'SOURCE-REFERENCES.json').read_text()).items():keep(name,row['sha256'])
    current,current_pins=qualification(pin)
    for name,row in current_pins.items():assert keep(name)==row
    recipe=json.loads((SOURCE/'SIX-CASE-RESOURCE-RECIPE.json').read_text());assert recipe['caseCount']==recipe['TDs']==6 and recipe['wallSeconds']==30 and recipe['killGraceSeconds']==5
    declaration=json.loads((SOURCE/'DECLARED-SOURCE-INVENTORY.json').read_text());assert declaration['originCount']==len(declaration['modules'])
    for name,row in declaration['modules'].items():keep(row['path'],row['sha256']);assert inventory(row['path'])==row['inventory']
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14');stdns={};suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    for folder,dirs,names in os.walk(std,topdown=True,followlinks=False):
        parent=Path(folder);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(parent/n).is_symlink())
        parts=parent.relative_to(std).parts
        if parts and all(n.isidentifier()for n in parts)and not(parent/'__init__.py').is_file():stdns['.'.join(parts)]=[str(parent)]
        for name in names:
            path=parent/name
            if path.suffix=='.py'or str(path).endswith(suffixes):keep(path)
    third={}
    for name,row in json.loads((SOURCE/'third-party-source-declarations.json').read_text()).items():
        keep(row['path'],row['sha256']);third[name]=dict(path=row['path'],sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    python=Path(sys.executable).resolve(strict=True);python_pin=keep(python)
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'and not dest.exists()and dest.name.startswith('avatar-lower-fd-six-prepared-')
    dest.mkdir(mode=0o700)
    def copy_actual(source,target):
        raw=Path(source).read_bytes();fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:assert stream.write(raw)==len(raw)
        assert target.read_bytes()==raw;return keep(target)
    for name in EXECUTORS:copy_actual(SOURCE/name,dest/name)
    declared={};definitions={}
    for name,row in declaration['modules'].items():
        row=dict(row)
        if name in declaration['subjectCopies']:
            target=dest/(name+'.py');value=copy_actual(row['path'],target);row['originalSource']=row['path'];row['path']=str(target);assert value['sha256']==row['sha256']
        declared[name]=dict(path=row['path'],sha256=row['sha256'],package=row['package']);definitions[name]=dict(path=row['path'],sha256=row['sha256'],inventory=row['inventory'])
    for name in EXECUTORS:
        if name.endswith('.py')and name not in('prepare.py','run-six.py','supervise-six.py'):
            path=dest/name;row=keep(path);declared[path.stem]=dict(path=str(path),sha256=row['sha256'],package=False)
    modules,namespaces,admission=project_namespace_admission(declared,[str(REPO/'tests/device')]);assert set(definitions)<=set(modules)
    plan=dict(status='PRIVATE_AVATAR_SIX_LOWER_FD_MODELS_UNRUN',controllerRoot=str(dest),repositoryRoot=str(REPO),actualPublicHead=args.expected_head,
        sourceFreeze=args.source_freeze,peerSource=dict(path=str(peer),sha256=args.peer_sha),subjectSourceFreeze=SUBJECT_SHA,
        cases=recipe['caseIds'],resourceRecipe=recipe,caseCount=6,expectedTemporaryDirectories=6,expectedClassCleanupGroups=1,wallSeconds=30,killGraceSeconds=5,
        currentSourceExecution=current,subjectHelperSha256=pin(dest/'closed_import_origins.py')['sha256'],sourceAndBinaryPins=physical,
        declaredProjectAliases=declared,modules=modules,namespaces=namespaces,projectAliasAdmission=admission,definitions=definitions,
        requiredExecutedModules=list(definitions),thirdPartyModules=third,pythonExecutable=dict(path=str(python),pin=python_pin),
        oldApplicationCorpusInputs=0,globalOriginalScans=0,SDKExecutions=0,NodeExecutions=0,caseChildProcesses=0,realNetwork=False,overteNativeQueries=0,
        declaredProtocolModel=True,nativeQSaveFileQualified=False,SDKProviderQualified=False,consumerAdmission=None,nativeQualified=False,wholeQualified=False)
    plan['originPlan']=dict(modules=modules,namespacePackages=namespaces,projectAliasAdmission=admission,thirdPartyModules=third,thirdPartyNamespacePackages={},
        stdlibNamespacePackages=stdns,stdlibRoots=[str(std)],pythonExecutable=plan['pythonExecutable'],physicalPins=physical)
    output=dest/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_NO_TARGET',approvedInput=str(output),sha256=pin(output)['sha256'],cases=6)))


if __name__=='__main__':main()
