"""Closed one-way command grammar. Syntax is never file/effect authority."""
import re
from adapters.native_feature_observation import exact,need

def command(value):
    exact(value,{'schemaVersion','action','commandId','runId','lastRequestId','rawSha256'})
    need(type(value['schemaVersion'])is int and value['schemaVersion']==1 and value['action']=='feature-ios-emote-response-retire')
    for key,pattern in (('commandId','ios-[0-9a-f]{32}'),('lastRequestId','ios-[0-9a-f]{32}'),('runId','[0-9a-f]{32}'),('rawSha256','[0-9a-f]{64}')):
        need(type(value[key])is str and re.fullmatch(pattern,value[key])is not None)
    return value
