import json,os,sys
from pathlib import Path
from scoped_prerequisite import historical
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
assert sys.dont_write_bytecode and Path.cwd()==REPO
report,_=historical(HERE,REPO)
p=HERE/'root-scoped19-report.json';fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'w') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(report))
