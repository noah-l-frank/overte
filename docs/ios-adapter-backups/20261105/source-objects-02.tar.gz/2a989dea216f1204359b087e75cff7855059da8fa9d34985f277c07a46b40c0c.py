"""Second ordinary picker checkpoint originals, not publication or action ACK.

The first checkpoint/whole guards are unchanged. This separate family owns
actual current action2/Episode1/staged-file originals and the completed first
action source. It creates no input, native query, shadow observer or End fact.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import os
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import collect,readonly,scope
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import pack,same,unpack
from ios.adapters.assets_checkpoint_owned_originals import AssetsCheckpointOriginalOwnership,AssetsCheckpointOwnedArchive
from ios.adapters.assets_end_metadata import signature
from ios.adapters.assets_episodes import AssetsEpisodeScope
from ios.adapters.assets_selected_profile import EpisodeAssetsFiles
from ios.adapters.assets_whole_observation import AssetsWholeObservation

VERSION=1
NAMESPACE='assets-checkpoint2-copied'
PREFIX='iosAssetsSecondCheckpointCopied'


def exact_frame_namespace(store,references):
    expected=set()
    for reference in references:
        full=store.expand(reference) if 'phase'not in reference else reference
        store.original(full);path=store.path(full)
        if full['phase']=='planned':need(not path.exists()and not path.is_symlink())
        else:expected.add(path)
    actual={path for path in store.root.iterdir()if path.name.startswith(store.namespace+'-frame-')}
    need(actual==expected and all(signature(path)is not None for path in expected));return expected


class AssetsSecondCheckpointOriginalOwnership(AssetsCheckpointOriginalOwnership):
    def __init__(self,observer):
        need(type(observer)is AssetsWholeObservation and observer.last is not None
            and observer.action.index==2 and type(observer.episode)is AssetsEpisodeScope
            and type(observer.files)is EpisodeAssetsFiles)
        self.observer=observer;self.run=observer.driver.run;self.role=observer.subject
        self.index=observer.action.index;self.ticket=observer.action.ticket
        self.root=observer.root;self.binding=deepcopy(observer.driver.selected.context['roles'][self.role]['binding'])
        self.cohort=deepcopy(observer.last);self.locks=dict(observer.locks)
        self.value=self.actual_snapshot();self.bound()

    def actual_snapshot(self):
        o=self.observer;episode=o.episode;files=o.files;actions=o.driver.actions
        need(type(o)is AssetsWholeObservation and o.action.index==2 and o.action.owner is actions
            and type(episode)is AssetsEpisodeScope and episode.owner is o.driver.episodes
            and episode.index==1 and episode.owner.selected is o.driver.selected
            and episode.descriptor['kind']=='picker'and episode.descriptor['resource']=='gltf-bundle/main.gltf'
            and episode.descriptor['ticket']==self.ticket and type(files)is EpisodeAssetsFiles
            and files.episode is episode and files.selection is o.driver.selected
            and files.role=='primary'and files.state is not None and files.state['phase']=='staged'
            and files.state['ticket']==self.ticket and files.state['resource']=='gltf-bundle/main.gltf'
            and files.sources.pending is None)
        episode.guard();o.action.guard()
        # The inherited decoder is the original complete current component
        # read; only its original first-action constructor is not reused.
        current=super().actual_snapshot()
        need(current.pop('iosAssetsCheckpointOwnershipVersion')==1)
        with collect()as reads,scope(),readonly():
            before_actions=signature(actions.store.path);a=actions.store.read()
            need(a is not None and same(a,actions.previous)and same(actions.decode(a),actions.state)
                and len(actions.state['records'])==1 and actions.state['pending']is not None)
            pending=actions.state['pending']
            need(pending['index']==2 and pending['ticket']==self.ticket
                and pending['after']is None and pending['original']is None)
            first=actions.read(1)
            need(first['input']==dict(verb='open',inputs={})and first['index']==1
                and first['ticket']!=self.ticket)
            action_paths=exact_frame_namespace(actions.originals,actions.state['records'])
            before_episodes=signature(episode.owner.store.path);e=episode.owner.store.read()
            need(e is not None and same(e,episode.owner.previous)
                and same(episode.owner.decode(e),episode.owner.state)
                and len(episode.owner.state['entries'])==1)
            entry=episode.owner.state['entries'][0];need(entry['phase']=='ready')
            need(same(episode.owner.originals.read(entry['original']),episode.descriptor))
            episode_paths=exact_frame_namespace(episode.owner.originals,[entry['original']])
            # Actual file-source members are a second family omitted from the
            # first page-open checkpoint subset. Decode all bytes again; no
            # native response, modeled file rows or token grants read authority.
            before_files=signature(files.store.path);f=files.store.read()
            need(f is not None and same(f,files.previous)and same(files.decode(f),files.state))
            native=files.sources;file_paths=set(native.owned_paths())
            native_paths={path for path in native.store.root.iterdir()if
                path.name.startswith(native.NAMESPACE+'-frame-')or path.name.startswith(native.MIGRATION_PREFIX)}
            need(native_paths==file_paths and native.pending is None)
            expected={actions.store.path,episode.owner.store.path,files.store.path}|action_paths|episode_paths|file_paths
            need(expected<=reads)
            need(signature(actions.store.path)==before_actions and signature(episode.owner.store.path)==before_episodes
                and signature(files.store.path)==before_files)
        paths=set(current['actualReadPaths'])|set(map(str,reads))|set(map(str,expected))
        signatures={path:signature(Path(path))for path in sorted(paths)}
        need(0<len(signatures)<=4096 and all(v is not None for v in signatures.values()))
        need(all(list(signatures[path])==value for path,value in current['actualReadSignatures'].items()))
        need(signature(actions.store.path)==before_actions and signature(episode.owner.store.path)==before_episodes
            and signature(files.store.path)==before_files)
        episode.guard();o.guard();need(same(o.last,self.cohort))
        return dict(current,iosAssetsSecondCheckpointOwnershipVersion=VERSION,
            actualHeaderValues=dict(current['actualHeaderValues'],**{str(actions.store.path):deepcopy(a),str(episode.owner.store.path):deepcopy(e)}),
            actualReadPaths=sorted(signatures),actualReadSignatures={path:list(v)for path,v in signatures.items()},
            componentNamespacePaths=sorted(set(current['componentNamespacePaths'])|set(map(str,expected))),
            firstCompletedActionOriginal=deepcopy(first),currentSecondActionPending=deepcopy(pending),
            episodeOriginal=deepcopy(episode.descriptor),fileOriginalCreatorRole='primary',
            fileSourceOriginalReferences=deepcopy(native.manifest()),
            meaning='CURRENT_SECOND_ORDINARY_PICKER_CHECKPOINT_OWNERSHIP_ONLY',
            firstCheckpointHistoricalEffectEstablished=False,actionCompletionEstablished=False)


class AssetsSecondCheckpointOwnedArchive(AssetsCheckpointOwnedArchive):
    def __init__(self,ownership):
        need(type(ownership)is AssetsSecondCheckpointOriginalOwnership)
        self.ownership=ownership;self.root=ownership.root;self.binding=deepcopy(ownership.binding)
        self.run,self.role=ownership.run,ownership.role;self.failed=False
        name='ios-assets-second-checkpoint-'+self.run+'-a2-'+self.role+'-owned.json'
        self.store=PrivateFeatureState(self.root/name)
        self.originals=OriginalFrameStore(self.root,self.binding,self.run,self.role,self.bound,self.intent,
            namespace=NAMESPACE+'-a2',schema_prefix=PREFIX,kind='inputs')
        self.previous=self.store.read();self.state=None if self.previous is None else self.decode(self.previous)
        self.bound()

    def envelope(self,state):
        return dict(iosAssetsSecondCheckpointOwnedArchiveVersion=VERSION,runId=self.run,role=self.role,
            sourceBinding=deepcopy(self.binding),actionIndex=2,actionTicket=self.ownership.ticket,payload=pack([state]))

    def decode(self,value):
        exact(value,{'iosAssetsSecondCheckpointOwnedArchiveVersion','runId','role','sourceBinding','actionIndex','actionTicket','payload'})
        rows=unpack(value['payload']);need(len(rows)==1 and type(value['iosAssetsSecondCheckpointOwnedArchiveVersion'])is int
            and same(value,self.envelope(rows[0])))
        state=rows[0];exact(state,{'phase','snapshotSha256','pending','record'})
        need(state['phase']in('copying','copied')and state['snapshotSha256']==digest(self.ownership.snapshot()))
        if state['pending']is not None:
            self.originals.original(state['pending']);need(state['pending']['index']==1 and state['phase']=='copying'and state['record']is None)
        if state['record']is not None:
            self.originals.expand(state['record']);need(state['record']['index']==1 and state['phase']=='copied'and state['pending']is None)
        need((state['phase']=='copied')==(state['record']is not None));return deepcopy(state)

    def retirement_manifest(self):
        value=super().retirement_manifest();need(value.pop('iosAssetsCheckpointOwnedResponsibilityVersion')==1)
        return dict(value,iosAssetsSecondCheckpointOwnedResponsibilityVersion=VERSION,
            currentCheckpointOnly=True,firstCheckpointHistoricalEffectEstablished=False,actionCompletionEstablished=False)


class AssetsSecondCheckpointRetainedArchive:
    """Actual readonly copied-byte duty inventory after action guard loss.

    This is not a live checkpoint reconstruction, current effect, metadata
    recovery writer, release/End owner or replacement for source consumers.
    """
    def __init__(self,archive):
        need(type(archive)is AssetsSecondCheckpointOwnedArchive)
        self.root,self.binding,self.run,self.role=archive.root,deepcopy(archive.binding),archive.run,archive.role
        self.locks=dict(archive.ownership.locks);self.ticket=archive.ownership.ticket
        self.store=PrivateFeatureState(archive.store.path)
        self.previous=self.store.read();need(self.previous is not None)
        exact(self.previous,{'iosAssetsSecondCheckpointOwnedArchiveVersion','runId','role','sourceBinding','actionIndex','actionTicket','payload'})
        need(type(self.previous['iosAssetsSecondCheckpointOwnedArchiveVersion'])is int
            and self.previous['iosAssetsSecondCheckpointOwnedArchiveVersion']==VERSION
            and self.previous['runId']==self.run and self.previous['role']==self.role
            and same(self.previous['sourceBinding'],self.binding)and self.previous['actionIndex']==2
            and self.previous['actionTicket']==self.ticket)
        rows=unpack(self.previous['payload']);need(len(rows)==1)
        self.state=deepcopy(rows[0]);exact(self.state,{'phase','snapshotSha256','pending','record'})
        need(self.state['phase']in('copying','copied')and type(self.state['snapshotSha256'])is str
            and len(self.state['snapshotSha256'])==64 and all(c in'0123456789abcdef'for c in self.state['snapshotSha256']))
        self.originals=OriginalFrameStore(self.root,self.binding,self.run,self.role,self.guard,self.deny_write,
            namespace=NAMESPACE+'-a2',schema_prefix=PREFIX,kind='inputs')
        self.paths={self.store.path};wire=self.state['pending'];record=self.state['record']
        if wire is not None:
            self.originals.original(wire);need(wire['index']==1 and self.state['phase']=='copying'and record is None)
            path=self.originals.path(wire)
            if wire['phase']=='planned':need(not path.exists()and not path.is_symlink())
            else:self.paths.add(path)
        if record is not None:
            full=self.originals.expand(record);need(full['index']==1 and wire is None and self.state['phase']=='copied')
            self.paths.add(self.originals.path(full))
        need((self.state['phase']=='copied')==(record is not None))
        need(self.store.path==self.root/('ios-assets-second-checkpoint-'+self.run+'-a2-'+self.role+'-owned.json'))
        self.pins={str(path):signature(path)for path in self.paths};need(all(v is not None for v in self.pins.values()))
        # Even an incomplete opened prefix must retain its actual original
        # inode, not a foreign path/symlink admitted merely as an owed filename.
        held=wire if wire is not None and wire['phase']!='planned' else (None if record is None else self.originals.expand(record))
        if held is not None:
            path=self.originals.path(held);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
            try:self.originals.file(path,fd,held)
            finally:os.close(fd)
            need(signature(path)==self.pins[str(path)])
        self.guard()

    def deny_write(self,*args,**kwargs):need(False)

    def guard(self):
        for lock in self.locks.values():lock.assert_held()
        need(same(self.store.read(),self.previous)
            and all(signature(Path(path))==pin for path,pin in self.pins.items()))
        expected=self.paths-{self.store.path}
        actual={path for path in self.root.iterdir()if path.name.startswith(self.originals.namespace+'-frame-')}
        need(actual==expected);return True

    def original(self):
        self.guard();need(self.state['phase']=='copied')
        # OriginalFrameStore still executes its actual FD/body/SHA/namespace
        # codec and read deadline. Old component state is never made current.
        with collect()as reads,scope(),readonly():
            value=self.originals.read(self.originals.expand(self.state['record']))
        need(digest(value)==self.state['snapshotSha256']
            and type(value.get('iosAssetsSecondCheckpointOwnershipVersion'))is int
            and value['iosAssetsSecondCheckpointOwnershipVersion']==VERSION
            and value['runId']==self.run and value['role']==self.role and value['actionIndex']==2
            and value['actionTicket']==self.ticket and same(value['sourceBinding'],self.binding))
        self.guard()
        return dict(iosAssetsSecondCheckpointRetainedOriginalVersion=VERSION,
            retainedOriginal=deepcopy(value),actualCopiedReadPaths=sorted(str(path)for path in reads),
            currentCheckpointEstablished=False,externalConsumersComplete=False,wholeEndEligible=False)

    def manifest(self):
        self.guard()
        return dict(iosAssetsSecondCheckpointRetainedResponsibilityVersion=VERSION,
            runId=self.run,role=self.role,actionIndex=2,actionTicket=self.ticket,
            phase=self.state['phase'],pending=deepcopy(self.state['pending']),record=deepcopy(self.state['record']),
            paths=sorted(self.pins),actualSignatures={path:list(pin)for path,pin in self.pins.items()},
            actualCopiedOriginalValidated=self.state['phase']=='copied'and self.original()is not None,
            openedOrIncompleteIsOwed=self.state['phase']=='copying',
            originalComponentFamiliesRevalidated=False,currentCheckpointEstablished=False,
            metadataRetirementAllowed=False,externalConsumersComplete=False,wholeEndEligible=False,performed=False)
