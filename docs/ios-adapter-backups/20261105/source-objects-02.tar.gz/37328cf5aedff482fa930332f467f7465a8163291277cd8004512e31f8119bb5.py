from contextlib import ExitStack
import hashlib
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.witness import Client
from ios.adapters.chat_draft_owner import IOSChatDraftOwner
from ios.adapters.chat_draft_runtime import IOSChatDraftRuntime
from ios.adapters.chat_receive_sources import IOSChatReceiveSources
from ios.adapters import chat_archive_round as rounds

root=Path('.ios-host-tmp/tmp8deowa9l').resolve(strict=True)
def census():
    return {str(p.relative_to(root)):(p.stat().st_dev,p.stat().st_ino,p.stat().st_mode,p.stat().st_uid,p.stat().st_gid,p.stat().st_nlink,p.stat().st_size,p.stat().st_mtime_ns,p.stat().st_ctime_ns,hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.rglob('*') if p.is_file()}
before=census();forbidden=[]
def refuse(*args,**kwargs):forbidden.append(True);raise AssertionError('Read-only original replay')
with ExitStack() as stack:
    locks={role:ScriptSourceLock(root/role/'script-feature-sources.lock') for role in ('primary','peer')}
    for lock in locks.values():stack.enter_context(lock.held())
    saved=PrivateFeatureState(root/'peer'/'ios-chat-receive-sources.json').read()
    source=IOSChatReceiveSources.archive(PrivateFeatureState(root/'peer'/'ios-chat-receive-sources.json'),
        saved['primaryBinding'],saved['binding'],saved['runId'],saved['peerBindingRecord']['primaryArtifactRoot']['path'],
        saved['artifactRoot'],saved['peerBindingRecord'],locks['primary'],locks['peer'])
    runtime=object.__new__(IOSChatDraftRuntime);runtime.adapter=SimpleNamespace(state_path=lambda role:root/role/'session.json')
    client=object.__new__(Client);head=PrivateFeatureState(root/'primary'/'ios-chat-draft-owner.json').read();client.url=head['fixtureUrl'].split('/runs/')[0]
    contexts=runtime._chat_receipt_contexts('primary','peer',saved['runId'],client,source)
    for target in ('adapters.normal_feature_state.PrivateFeatureState.write','subprocess.Popen','socket.socket'):
        stack.enter_context(patch(target,side_effect=refuse))
    for role in ('primary','peer'):
        store=PrivateFeatureState(root/role/'ios-chat-draft-owner.json');value=store.read()
        archive=IOSChatDraftOwner.archive(store,value['artifactRoot'],value['binding'],value['runId'],locks[role],value['fixtureUrl'],
            source_bound=True,peer_actor=role=='peer',peer_receipts=contexts[role])
        print(role,'records',len(archive.state['records']),'hits/completed',rounds._LAST_COUNTS.get(),flush=True)
        assert rounds._ACTIVE.get() is None
assert before==census();assert not forbidden
print('All',len(before),'originals unchanged; forbidden0; no writes/live SDK/native/input/network/process calls.',flush=True)
