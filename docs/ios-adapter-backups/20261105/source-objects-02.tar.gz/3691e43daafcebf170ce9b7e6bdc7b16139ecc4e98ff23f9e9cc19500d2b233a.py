"""Root-only ONE exact retained-owner custody/preflight/literal-index method; exact file overlay, no guard replacement."""
import hashlib,importlib.abc,importlib.util,json,os,sys,tempfile,threading,traceback,unittest
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from guard import sources,first_pass,sha,pin
from root_stage_guard import baseline,terminal
from diagnostic_write_guard import MutationBoundary
from moving_host_ports import MovingNodePort,OwnedLoopbacks
sys.dont_write_bytecode=True
HERE=Path(os.environ['LIFECYCLE_WHOLE_STAGE']).resolve();PREP=HERE.parent
plan=json.loads((PREP/'plan.json').read_text());REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and str(REPO)==plan['repositoryRoot']
def target(p):
    p=Path(p);assert p.resolve().is_relative_to(REPO);return p
selection=json.loads((HERE/'case.json').read_text());expected_roots=selection['expectedTemporaryDirectories']
assert expected_roots==3
sources(HERE);first_pass(HERE)
for key,row in json.loads((PREP/'maps.json').read_text()).items():
    path=Path(row['path']);assert sha(path)==row['sha256'];os.environ[key]=str(path);os.environ[key+'_SHA256']=row['sha256']
for name in ('bindings','retained','cleanup'):target(HERE/name).mkdir(mode=0o700,exist_ok=False)
os.environ['LIFECYCLE_CODE_BINDINGS_ROOT']=str(HERE/'bindings')
boundary=MutationBoundary(REPO,HERE)
node_port=MovingNodePort(plan,boundary);loopback_port=OwnedLoopbacks()
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf')
def sdk_free():assert not [name for name in sys.modules if name.split('.')[0]in forbidden],'SDK imported'
def audit(event,args):
    if event=='open'and type(args[0])is int and node_port.pipe_open(args,sys._getframe(1)):return
    boundary.audit(event,args)
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Installed/vendor SDK import prohibited')
    if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
        value=os.fsdecode(args[0])
        if '/overte-ios-remotexpc/'in value or any('/'+name+'/'in value for name in forbidden):raise RuntimeError('Installed SDK path prohibited')
    if event=='subprocess.Popen':node_port.spawn(args,sys._getframe(1))
    elif event in('os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.putenv','os.unsetenv','os.setsid','os.setpgid','os.kill','os.killpg')or event.startswith('os.spawn'):raise RuntimeError('Only the exact original Moving Node subprocess is admitted')
    if event in('socket.connect','socket.bind','socket.sendto','socket.sendmsg','socket.getaddrinfo','socket.gethostbyname','socket.gethostbyaddr','socket.getnameinfo'):loopback_port.audit(event,args,sys._getframe(1))
sdk_free();sys.addaudithook(audit) # Before target imports or host-model birth.
initial=baseline()
origins=json.loads((PREP/'module-origins.json').read_text());origin_pins=json.loads((PREP/'immutable-source-pins.json').read_text())
project_tops={n.split('.')[0]for n in(*origins['modules'],*origins['namespaces'])}
class Overlay(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        source=origins['modules'].get(fullname)
        if source is not None:
            source=Path(source);assert pin(source)==origin_pins[str(source)]
            return importlib.util.spec_from_file_location(fullname,source,
                submodule_search_locations=[str(source.parent)]if source.name=='__init__.py'else None)
        directory=origins['namespaces'].get(fullname)
        if directory is not None:
            spec=importlib.machinery.ModuleSpec(fullname,None,is_package=True);spec.submodule_search_locations=[directory];return spec
        if fullname.split('.')[0]in project_tops:raise ImportError('Project import absent from exact current origin map: '+fullname)
        return None
sys.meta_path.insert(0,Overlay())
roots=[*plan['modelSearchOrder'],str(Path(plan['baseModelRoot'])),str(Path(plan['legacyController'])/'support'),*[str(REPO/rel)for rel in ('tests/device','tests/device/self_tests','tests/device/ios/self_tests')]]
rest=[entry for entry in sys.path if entry and not Path(entry).resolve().is_relative_to(REPO)]
sys.path[:]=roots+rest
# Genuine original TemporaryDirectory objects are retained by the repository's
# already reviewed retained_host_roots hook; actual case cleanup still runs.
import fcntl
import adapters.script_feature.lock as original_lock_module
boundary.bind_original_lock(original_lock_module,fcntl)
from ios.self_tests.retained_host_roots import retain_owned_root
real_td=tempfile.TemporaryDirectory;owned=[];objects=[]
def temporary(suffix=None,prefix=None,dir=None,*,ignore_cleanup_errors=False,delete=True):
    assert dir is None or Path(dir)==HERE/'retained'
    actual=real_td(suffix=suffix,prefix=prefix,dir=target(HERE/'retained'),ignore_cleanup_errors=ignore_cleanup_errors,delete=delete)
    root=Path(actual.name);assert root.parent==HERE/'retained'and root.is_dir()and root.stat().st_mode&0o077==0
    retain_owned_root(actual,expected_root=root);owned.append(str(root));objects.append(actual)
    target(HERE/'created-original-roots.json').write_text(json.dumps(owned)+'\n');return actual
selection=json.loads((HERE/'case.json').read_text());case_id=selection['case']
module_name,class_name,method=case_id.rsplit('.',2)
module=__import__(module_name,fromlist=[class_name]);kind=getattr(module,class_name)
assert method in kind.__dict__ and method.startswith('test_'),'Only explicitly authored OWN method allowed'
loader=unittest.TestLoader();suite=loader.loadTestsFromName(case_id);assert suite.countTestCases()==1
def flatten(value):
    if isinstance(value,unittest.TestSuite):
        for part in value:yield from flatten(part)
    else:yield value
from lifecycle_moving_raw_worker import RawMarkerWorker
node_port.bind(RawMarkerWorker)
selected_cases=list(flatten(suite));assert len(selected_cases)==1
actual_case=selected_cases[0]
result=None;returned=False;runner_error=None
terminal_errors=[];terminal_checks=[]
original_tempfile_ports=tuple((importlib.import_module(name),importlib.import_module(name).tempfile)
    for name in plan['retainedTemporaryDirectoryAliases'])
from ios.adapters import feature_observation as original_feature_observation,normal_input as original_normal_input
original_transport_ports=(original_feature_observation.post_request,original_normal_input.urlopen)
def restored_controller_and_transport_ports():
    assert all(module.tempfile is original for module,original in original_tempfile_ports)
    assert original_feature_observation.post_request is original_transport_ports[0]
    assert original_normal_input.urlopen is original_transport_ports[1]
    return dict(actualControllerTempfileAliasesRestored=True,actualFeaturePostPortRestored=True,
        actualNormalInputPortRestored=True)
def checked(name,function):
    try:
        value=function();terminal_checks.append(dict(name=name,passed=True));return value
    except BaseException as error:
        terminal_errors.append(dict(name=name,type=type(error).__module__+'.'+type(error).__qualname__,
            traceback=''.join(traceback.format_exception(error))))
        terminal_checks.append(dict(name=name,passed=False));return None
try:
    with ExitStack()as stack:
        for module,unused in original_tempfile_ports:
            stack.enter_context(patch.object(module,'tempfile',SimpleNamespace(TemporaryDirectory=temporary)))
        result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite);returned=True
except BaseException as error:
    runner_error=error
finally:
    # Run ALL independent checks after the actual standard unittest/AsyncRunner
    # cleanup and ExitStack restoration, even when the positive Node proof is
    # inapplicable or another check fails. Do not convert case errors to PASS.
    target(HERE/'cleanup/terminal-census-1.json');target(HERE/'cleanup/terminal-census-2.json')
    producer_namespaces=[*owned,str(HERE/'bindings')]
    def exact_namespaces():
        assert len(producer_namespaces)==4 and len(owned)==expected_roots==3
    checked('exact-three-tds-plus-bindings',exact_namespaces)
    actual_ports=checked('actual-controller-and-transport-port-restoration',restored_controller_and_transport_ports)
    actual_terminal=checked('two-original-terminal-censuses',lambda:terminal(target(HERE/'cleanup'),initial,producer_namespaces))
    checked('original-lock-owner-inode-fd-release',boundary.finish)
    checked('no-sdk-imports',sdk_free)
    checked('exact-source-pins',lambda:sources(HERE))
    case_successful=result is not None and result.wasSuccessful()and result.testsRun==1 and not result.skipped
    actual_node=None;actual_loopbacks=None
    try:
        if case_successful or node_port.spawned or node_port.pending is not None:
            # Existing positive custody stays strict. A partial Popen without
            # a valid actual drain remains a failure, never a no-Node receipt.
            actual_node=checked('actual-positive-node-drain',node_port.finish)
        else:
            channels=getattr(actual_case,'moving_channels',None)
            worker=None if channels is None else channels.worker
            actual_node=checked('negative-no-node-birth-ledger',lambda:node_port.failed_case_ledger(worker,initial['children']))
    finally:
        # This cannot be skipped by an earlier no-birth/positive assertion.
        actual_loopbacks=checked('actual-owned-loopback-socket-drain',loopback_port.finish)
    target(HERE/'cleanup/moving-host-drain.json').write_text(json.dumps(dict(node=actual_node,
        loopbacks=actual_loopbacks,restoredPorts=actual_ports,checks=terminal_checks,errors=terminal_errors,
        caseSuccessful=bool(case_successful),wholeFeatureQualified=False),indent=2)+'\n')
    original_errors=[] if result is None else [dict(testId=test.id(),traceback=text)for test,text in result.errors]
    original_failures=[] if result is None else [dict(testId=test.id(),traceback=text)for test,text in result.failures]
    receipt=dict(case=case_id,actualStandardCaseRunReturned=returned,
        originalStandardCaseErrors=original_errors,originalStandardCaseFailures=original_failures,
        standardCleanupOutcome='Preserved in the actual standard unittest result; no negative ledger upgrades it',
        twoCensusesPassed=any(row['name']=='two-original-terminal-censuses'and row['passed']for row in terminal_checks),
        retainedRoots=owned,producerNamespaces=producer_namespaces,bindingsIncluded=True,
        originalLockOpens=boundary.lock_opens,originalLockFlocks=boundary.lock_flocks,
        originalLockHandoffs=boundary.lock_handoffs,allOriginalLockOwnersRetained=len(boundary.all_lock_owners),
        allOriginalLockOwnersReleased=all(owner._owner is None for owner in boundary.all_lock_owners),
        noSDK=any(row['name']=='no-sdk-imports'and row['passed']for row in terminal_checks),
        actualNode=actual_node,actualLoopbacks=actual_loopbacks,actualRestoredPorts=actual_ports,
        independentTerminalChecks=terminal_checks,independentTerminalErrors=terminal_errors,
        wholeFeatureQualified=False)
    if runner_error is not None:
        receipt['originalRunnerException']=''.join(traceback.format_exception(runner_error))
    target(HERE/'cleanup/receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
value=dict(selectedIds=[case_id],testsRun=0 if result is None else result.testsRun,
    successful=bool(result is not None and result.wasSuccessful()and result.testsRun==1 and not result.skipped and not terminal_errors),
    hostMovingFrontdoorOnly=True,frontdoorCalls=getattr(actual_case,'frontdoor_calls',None),
    failureCount=0 if result is None else len(result.failures),errorCount=0 if result is None else len(result.errors),
    skippedCount=0 if result is None else len(result.skipped),independentTerminalErrorCount=len(terminal_errors),
    negativeLedgerIsNotPositiveQualification=True,wholeFeatureQualified=False,nativeQualified=False)
target(HERE/'selected-result.json').write_text(json.dumps(value,indent=2)+'\n')
if runner_error is not None:raise runner_error
if result is None:raise RuntimeError('Standard test result unavailable')
raise SystemExit(0 if value['successful']else 1)
