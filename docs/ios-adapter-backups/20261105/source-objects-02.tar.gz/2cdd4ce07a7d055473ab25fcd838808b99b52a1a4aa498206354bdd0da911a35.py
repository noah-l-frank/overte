"""Exact real fixture/PCM TD callers for the 26 unchanged host cases."""
from pathlib import Path
from types import FrameType
import os,stat,threading

class AudioResources:
    def __init__(self,temp,recipe):
        self.temp=Path(temp);self.recipe=recipe;self.classes={};self.analysis=None;self.roots=[];self.main=threading.current_thread();self.pair_type=None;self.owners=[]
    def loaded(self,name,module):
        if name=='ios.self_tests.audio_ordinary_received_pair_fixture':
            self.pair_type=(module,vars(module)['AudioOrdinaryReceivedFixture']);return
        if name=='feature_journeys.evidence':
            fn=vars(module)['audio_observation'];self.analysis=(module,fn,fn.__code__,fn.__globals__,fn.__defaults__,tuple(fn.__defaults__ or()),fn.__kwdefaults__,tuple((fn.__kwdefaults__ or{}).items()),fn.__closure__,tuple(cell.cell_contents for cell in fn.__closure__ or()));return
        selected={'ios.self_tests.audio_whole_fixture':('whole','AudioWholeFixture','__init__'),
            'ios.self_tests.test_ios_installed_adapter':('installed','InstalledAdapterTests','setUp'),
            'ios.self_tests.test_ios_audio_recorded_owner':('recorded','AudioRecordedOwnerTests','setUp')}
        if name not in selected:return
        role,class_name,method=selected[name];cls=vars(module)[class_name];fn=vars(cls)[method]
        assert role not in self.classes
        self.classes[role]=(module,class_name,cls,method,fn,fn.__code__,fn.__globals__,fn.__defaults__,fn.__closure__)
    def td_role(self,frame,args,kwargs):
        assert type(frame)is FrameType and threading.current_thread()is self.main
        if self.analysis is not None:
            module,fn,code,namespace,defaults,values,keywords,items,closure,cells=self.analysis
            assert module.audio_observation is fn and fn.__code__ is code and fn.__globals__ is namespace and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
            assert len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values))
            assert tuple(keywords or())==tuple(key for key,value in items)and all(keywords[key]is value for key,value in items)
            assert len(closure or())==len(cells)and all(cell.cell_contents is value for cell,value in zip(closure or(),cells))
            if frame.f_code is code and frame.f_globals is namespace:
                assert not args and kwargs=={'prefix':'overte-feature-pcm-'}and type(frame.f_locals['content'])is bytes
                assert sum(row['role']=='pcm-analysis'for row in self.roots)<self.recipe['expectedPCMScratchTDs']
                return 'pcm-analysis'
        assert not args and not kwargs;found=[]
        for role,row in self.classes.items():
            module,name,cls,method,fn,code,namespace,defaults,closure=row
            assert vars(module)[name]is cls and vars(cls)[method]is fn
            assert fn.__code__ is code and fn.__globals__ is namespace and fn.__defaults__ is defaults and fn.__closure__ is closure
            if frame.f_code is code and frame.f_globals is namespace:
                owner=frame.f_locals.get('self');accepted=type(owner)is cls
                if role=='whole'and self.pair_type is not None:
                    pair_module,pair_cls=self.pair_type
                    assert vars(pair_module)['AudioOrdinaryReceivedFixture']is pair_cls and pair_cls.__bases__==(cls,)
                    accepted=accepted or type(owner)is pair_cls
                if accepted:found.append((role,owner))
        assert len(found)==1
        role,owner=found[0];assert not any(owner is prior for prior in self.owners)
        assert sum(row['role']==role for row in self.roots)<self.recipe['expectedTDByRole'].get(role,0)
        self.owners.append(owner);return role
    def remember(self,role,path):
        path=Path(path);s=path.lstat();assert path.parent==self.temp and path.resolve(strict=True)==path
        assert stat.S_ISDIR(s.st_mode)and stat.S_IMODE(s.st_mode)==0o700 and s.st_uid==os.geteuid()
        self.roots.append(dict(role=role,path=str(path),device=s.st_dev,inode=s.st_ino))
    def finish(self):
        assert len(self.roots)==self.recipe['expectedTDs']
        assert {role:sum(row['role']==role for row in self.roots)for role in self.recipe['expectedTDByRole']}==self.recipe['expectedTDByRole']
        assert set(row['role']for row in self.roots)==set(self.recipe['expectedTDByRole'])
        for row in self.roots:
            path=Path(row['path']);s=path.lstat();assert(s.st_dev,s.st_ino)==(row['device'],row['inode'])and path.resolve(strict=True)==path
        return dict(realTemporaryDirectories=len(self.roots),realNodeExecutions=0,realHTTPListeners=0,realUDPSockets=0,realTLS=0,realSDK=0,
            noNewProductionDunderNew=True,declaredLowerProducers=['native','UIKit','SDK','OS','audio capture/output','received packet decoder','phase Client','host/model clocks'],actualRoots=self.roots,nativeQualified=False,wholeQualified=False)
