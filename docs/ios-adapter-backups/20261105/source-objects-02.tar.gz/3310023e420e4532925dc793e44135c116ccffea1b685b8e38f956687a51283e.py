"""Prospective real owners/packet WALs/canonical Journal; declared native model.

No native parser/device/socket service runs here. Each negative has a fresh
real constructor/root lifetime, so no earlier unresolved slot masks its input.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib,uuid
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from adapters.phase_witness_publisher import PublicationPending
from adapters.script_feature.history import unpack
from ios.adapters import appium_adapter
from ios.adapters.lifecycle_actor_publication import LifecycleActorCanonicalPublication
from ios.adapters.lifecycle_received_actor_flow import observe_held_with_canonical_received_actor
from ios.adapters.lifecycle_received_actor_join import compare_received_held_originals
from ios.adapters.lifecycle_received_actor_world import LifecycleReceivedActorPacket
from ios.self_tests import test_ios_lifecycle_world_attempt as attempt
from ios.self_tests.test_ios_lifecycle_world_hold import LifecycleWorldHoldTests
from ios.self_tests.test_ios_lifecycle_independent_actor_world import LifecycleIndependentActorOriginalTests
from ios.self_tests.lifecycle_received_actor_domain import LifecycleReceivedActorDomain,PRIMARY,TICKET


class LifecycleReceivedActorOriginalTests(LifecycleIndependentActorOriginalTests):
    def setUp(self):
        original=attempt.TouchBoundary
        class PrimaryIdentity(original):
            def decorate(receiver,value):
                super().decorate(value)
                value['source']['domain']['selfSha256']=hashlib.sha256(uuid.UUID(PRIMARY).bytes).hexdigest()
        with patch.object(attempt,'TouchBoundary',PrimaryIdentity):LifecycleWorldHoldTests.setUp(self)
        self.peer=LifecycleReceivedActorDomain(self,self.b.owner.run)

    async def held_pair(self,*,ignored=False):
        primary=self.make();self.peer.ignore_packet=ignored
        with self.peer.lock.held():
            before,after=self.actors();publication=LifecycleActorCanonicalPublication((before,after),self.peer.client)
            before.acquire(TICKET);publication.publish(before.index)
            await primary.act();primary.observe();self.peer.peer_event()
            after.acquire(TICKET);publication.publish(after.index)
            return primary,before,after

    async def test_actual_held_flow_publishes_independent_received_and_body_originals_without_borrowed_primary(self):
        primary=self.make();send=self.context.send_touchscreen
        async def reported(state,x,y):
            result=await send(state,x,y)
            if state==0xC2 and len(self.context.calls)==2:self.peer.peer_event()
            return result
        self.context.send_touchscreen=reported
        with patch.object(appium_adapter,'WebDriver',return_value=self.peer.sdk_client):
            value=await self.peer.runtime.observe_canonical_held_actor(primary,'test-only',self.peer.client)
        self.assertEqual([0.,0.,-.7],value['actorMeasuredWireRootDelta']);self.assertEqual(2,len(self.peer.queries))
        self.assertEqual(2,len(self.peer.posts));self.assertTrue(value['canonicalPublicationEstablished'])
        self.assertTrue(value['actorObjectLifetimeAndPacketMembershipEstablished']);self.assertTrue(value['originalPrimaryReleaseStillRequired'])
        for key in('actorPixelsEstablished','authenticatedTouchEstablished','resourceRetirementEstablished','nativeQualified','wholeQualified',
                'pairedTemporalOrderEstablished','nativeClockSynchronyEstablished','interpolatedRootEqualsReceivedWireRootEstablished'):
            self.assertFalse(value[key])

    async def test_body_motion_without_independent_received_packet_cannot_establish_wire_join(self):
        primary,before,after=await self.held_pair(ignored=True)
        with self.peer.lock.held():
            saved=after.original();queries=len(self.peer.queries)
            with self.assertRaises(NativeUIError):compare_received_held_originals(primary,before,after)
            self.assertEqual(saved,after.original());self.assertEqual(queries,len(self.peer.queries))

    async def test_new_body_object_with_same_session_cannot_adopt_prior_object_packet(self):
        # A new declared Avatar object is installed before this native lower
        # read. Its old receive record remains literal in the passive ledger.
        self.peer.primary_lifetime='9'*32
        from ios.adapters.lifecycle_received_world import received_primary
        with self.peer.lock.held():
            original=self.peer.owner(1).acquire(TICKET);packet=original['nativeOriginal']['packet']
            self.assertEqual('8'*32,packet['source']['receivedRoots']['records'][-1]['avatarInstance'])
            self.assertEqual('9'*32,packet['source']['bodyLifetimes'][hashlib.sha256(uuid.UUID(PRIMARY).bytes).hexdigest()])
            with self.assertRaises(NativeUIError):received_primary(packet,hashlib.sha256(uuid.UUID(PRIMARY).bytes).hexdigest())
            self.assertEqual(1,len(self.peer.queries))

    async def test_foreign_mixer_received_root_refuses_against_actual_actor_domain(self):
        self.peer.fault=lambda value:value['source']['receivedRoots']['records'][-1].update(mixerSha256='0'*64)
        from ios.adapters.lifecycle_received_world import received_primary
        with self.peer.lock.held():
            original=self.peer.owner(1).acquire(TICKET);calls=len(self.peer.queries)
            with self.assertRaises(NativeUIError):received_primary(original['nativeOriginal']['packet'],hashlib.sha256(uuid.UUID(PRIMARY).bytes).hexdigest())
            self.assertEqual(calls,len(self.peer.queries))

    async def test_old_received_record_cannot_become_current_by_new_world_envelope(self):
        self.peer.fault=lambda value:value['source']['receivedRoots']['records'][-1].update(capturedEpochMs=17000)
        from ios.adapters.lifecycle_received_world import received_primary
        with self.peer.lock.held():
            original=self.peer.owner(1).acquire(TICKET)
            with self.assertRaises(NativeUIError):received_primary(original['nativeOriginal']['packet'],hashlib.sha256(uuid.UUID(PRIMARY).bytes).hexdigest())
            self.assertEqual(1,len(self.peer.queries));self.assertEqual(17000,original['nativeOriginal']['packet']['source']['receivedRoots']['records'][-1]['capturedEpochMs'])

    async def test_lost_actual_received_http_return_reopens_same_nonce_without_new_capture(self):
        with self.peer.lock.held():
            owner=self.peer.owner(1);self.peer.lost=True
            with self.assertRaises(OSError):owner.acquire(TICKET)
            first=deepcopy(self.peer.queries);original=self.peer.owner(1).acquire(TICKET)
            self.assertEqual(first,self.peer.queries);self.assertIn('iosLifecycleReceivedActorWorldOriginalVersion',original)
            self.assertNotIn('iosLifecycleIndependentActorWorldOriginalVersion',original)

    async def test_real_published_sample_with_lost_return_resolves_from_journal_without_second_post(self):
        with self.peer.lock.held():
            owners=self.actors();owners[0].acquire(TICKET);publication=LifecycleActorCanonicalPublication(owners,self.peer.client)
            self.peer.lose_post=True
            with self.assertRaises(OSError):publication.publish(owners[0].index)
            self.assertTrue(publication.publisher.failed);posts=deepcopy(self.peer.posts);queries=len(self.peer.queries)
            reopened=LifecycleActorCanonicalPublication(owners,self.peer.client);reopened.publish(owners[0].index)
            self.assertEqual(posts,self.peer.posts);self.assertEqual(queries,len(self.peer.queries));self.assertEqual(1,len(reopened.history()))

    async def test_uncertain_missing_publication_retains_pending_and_never_reposts(self):
        with self.peer.lock.held():
            owners=self.actors();owners[0].acquire(TICKET);publication=LifecycleActorCanonicalPublication(owners,self.peer.client)
            self.peer.drop_post=self.peer.lose_post=True
            with self.assertRaises(OSError):publication.publish(owners[0].index)
            posts=deepcopy(self.peer.posts);queries=len(self.peer.queries)
            reopened=LifecycleActorCanonicalPublication(owners,self.peer.client)
            with self.assertRaises(PublicationPending):reopened.publish(owners[0].index)
            self.assertEqual(posts,self.peer.posts);self.assertEqual(queries,len(self.peer.queries))
            self.assertIsNotNone(unpack(reopened.store.read()['payload'])[0]['pending'])

    async def test_instance_send_alias_cannot_redirect_actual_closed_actor_transport(self):
        calls=[]
        self.peer.feature.send=lambda query:calls.append(query)
        with self.peer.lock.held(),self.assertRaises(NativeUIError):self.peer.owner(1).acquire(TICKET)
        self.assertEqual([],calls);self.assertEqual([],self.peer.queries)

    async def test_instance_original_alias_after_lost_query_cannot_replace_saved_response(self):
        with self.peer.lock.held():
            self.peer.lost=True
            with self.assertRaises(OSError):self.peer.owner(1).acquire(TICKET)
            calls=[];self.peer.feature.original=lambda **kwargs:calls.append(kwargs)
            with self.assertRaises(NativeUIError):self.peer.owner(1).acquire(TICKET)
            self.assertEqual([],calls);self.assertEqual(1,len(self.peer.queries))

    async def test_changed_native_callback_code_refuses_before_actor_query(self):
        function=self.peer.native.original
        def replacement_factory(self,remote):return lambda:(self,remote)
        replacement=replacement_factory(self.peer.feature,'foreign')
        self.assertEqual(function.__code__.co_freevars,replacement.__code__.co_freevars)
        with patch.object(function,'__code__',replacement.__code__),self.peer.lock.held(),self.assertRaises(NativeUIError):
            self.peer.owner(1).acquire(TICKET)
        self.assertEqual([],self.peer.queries)

    async def test_changed_effective_native_path_cannot_be_reanchored_at_packet_birth(self):
        self.peer.feature.remote=self.peer.feature.remote.rsplit('/',1)[0]+'/foreign.json'
        with self.peer.lock.held(),self.assertRaises(NativeUIError):self.peer.owner(1).acquire(TICKET)
        self.assertEqual([],self.peer.queries)

    async def test_fresh_isolated_body_sequence_packet_reaches_validator_and_stays_issued(self):
        self.peer.fault=lambda value:value['source']['world']['source']['bodies'].update(sequence=0)
        with self.peer.lock.held():
            owner=self.peer.owner(1)
            with self.assertRaises(NativeUIError):owner.acquire(TICKET)
            self.assertEqual(1,len(self.peer.queries));self.assertIn('"sequence": 0',self.peer.raw)
            self.assertEqual('reading',unpack(owner.store.read()['payload'])[0]['phase'])
            with self.assertRaises(NativeUIError):self.peer.owner(1).acquire(TICKET)
            self.assertEqual(1,len(self.peer.queries))

    async def test_foreign_packet_process_has_its_own_fresh_root_and_cannot_resend(self):
        self.peer.fault=lambda value:value.update(processId=43)
        with self.peer.lock.held():
            owner=self.peer.owner(1)
            with self.assertRaises(NativeUIError):owner.acquire(TICKET)
            self.assertEqual(1,len(self.peer.queries));self.assertIn('"processId": 43',self.peer.raw)
            with self.assertRaises(NativeUIError):self.peer.owner(1).acquire(TICKET)
            self.assertEqual(1,len(self.peer.queries))

    async def test_actual_same_bytes_replaced_received_original_inode_refuses_without_native_query(self):
        with self.peer.lock.held():
            owner=self.peer.owner(1);owner.acquire(TICKET);packet=owner.child(historical=True)
            path=packet.files().path(packet.state['storage']);raw=path.read_bytes();path.rename(path.with_name('old-'+path.name))
            path.write_bytes(raw);path.chmod(0o600);queries=len(self.peer.queries)
            with self.assertRaises(NativeUIError):owner.original()
            self.assertEqual(queries,len(self.peer.queries));self.assertEqual(raw,path.read_bytes())

    async def test_foreign_publication_reference_cannot_post_or_replace_owned_originals(self):
        with self.peer.lock.held():
            owners=self.actors();saved=owners[0].acquire(TICKET);publication=LifecycleActorCanonicalPublication(owners,self.peer.client)
            publisher=publication.prepare();reference=publication.reference(owners[0].index);reference['ownerSha256']='0'*64
            with self.assertRaises(NativeUIError):publisher.publish(reference)
            self.assertEqual([],self.peer.posts);self.assertEqual(saved,owners[0].original());self.assertEqual(1,len(self.peer.queries))
