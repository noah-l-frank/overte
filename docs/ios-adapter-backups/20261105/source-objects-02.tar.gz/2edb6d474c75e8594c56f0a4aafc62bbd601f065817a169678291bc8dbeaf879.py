"""Actual Source request/tasks/physical originals; native/SDK are MODELS only."""
import asyncio,json,os
from copy import deepcopy
from unittest.mock import patch
from test_native_passive_carrier_models import NativePassiveCarrierModels


class NativeTerminalBatchModels(NativePassiveCarrierModels):
    def terminal_args(self,mode='collect'):
        from adapters.script_feature.history import canonical
        return dict(self.acquire_args(),nativePassiveAcquisitionVersion=2,phase='released-quiet',terminalMode=mode,
            expectedOwnerInstance=self.ops.instance,preparationReferenceJson=canonical(self.ops.retained_motion_resource[8]).decode('ascii'))
    async def terminal_ready(self):
        await self.open_motion();held=await self.collect('held');await self.passive_rpc('touch-release',{})
        self.assertEqual(19,len(self.commands));self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        return held
    async def terminal_call(self,mode='collect'):
        value=await self.passive_rpc('touch-native-acquire',self.terminal_args(mode))
        self.assertEqual(5,value['originalKeeperNativeAcquisitionVersion'])
        self.assertTrue(all(value[k] is False for k in ('nativeAcquisitionBound','installedCandidateBound',
            'nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished')))
        return value,json.loads(value['acquisitionJson'])
    async def read_saved(self,result,row):
        selector=dict(binding=deepcopy(self.binding),runId=self.run,**deepcopy(row))
        return await asyncio.to_thread(self.runtime._native_passive_world_reference,
            'modeled-original-source',self.host_source,self.run,row['phase'],result,selector)
    def cut_path(self,ref):
        from adapters.original_frame_store import OriginalFrameStore
        codec=OriginalFrameStore(self.f.store.path.parent,self.binding,self.run,'primary',lambda:True,lambda *_:False,
            namespace='lifecycle-passive-world',schema_prefix='iosLifecyclePassiveWorld')
        return codec.path(codec.expand(ref))

    async def test_one_original_request_collects_released_and_four_quiet_before_slow_host_reads_without_reclocking(self):
        from ios.adapters import lifecycle_world as world
        await self.terminal_ready();result,payload=await self.terminal_call()
        self.assertEqual('saved',payload['terminalState']);rows=payload['references'];self.assertEqual([2,3,4,5,6],[r['ordinal'] for r in rows])
        originals={str(self.cut_path(r['reference'])):(self.cut_path(r['reference']).stat().st_ino,self.cut_path(r['reference']).read_bytes()) for r in rows}
        frames=[deepcopy(c['frame']) for c in self.collection()['cuts'][1:]];commands=len(self.commands)
        # Actual elapsed host cost occurs AFTER all strict Source cuts. Old
        # source/native carrier clocks are never moved to this later host time.
        await asyncio.sleep(1.55)
        saved=[await self.read_saved(result,row) for row in rows]
        self.assertEqual(frames,[value['originalFrame'] for value in saved]);self.assertEqual(30,commands);self.assertEqual(commands,len(self.commands))
        proof=world.stationary([value['originalFrame']['originals']['world'] for value in saved[1:]])
        self.assertEqual(4,proof['samples']);self.assertGreaterEqual(proof['nativeMilliseconds'],3000)
        self.assertEqual(originals,{p:(self.cut_path(r['reference']).stat().st_ino,self.cut_path(r['reference']).read_bytes()) for p,r in zip(originals,rows)})
        terminal=self.collection()['terminal'];task=terminal['task']()
        self.assertTrue(task.done());self.assertIs(terminal['row']['task'],task);self.assertTrue(any(row is terminal['row'] for row in self.ops.issued.values()))
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes());self.assertEqual(3,len(self.journal()['previous']['frames']))

    async def test_lost_original_pipe_return_keeps_saved_batch_and_only_explicit_recovery_reads_same_originals(self):
        await self.terminal_ready();ns=type(self.ops).execute.__globals__;wire=self.wire
        class LostWriter:
            failed=False
            def write(actual,text):
                if not actual.failed and '"originalKeeperNativeAcquisitionVersion":5' in text:
                    actual.failed=True;raise OSError('Declared ORIGINAL pipe loss AFTER Source saved all five cuts')
                return wire.write(text)
            def flush(actual):return wire.flush()
        old=ns['sys'].stdout;ns['sys'].stdout=LostWriter()
        try:
            with self.assertRaises(OSError):await self.terminal_call()
        finally:ns['sys'].stdout=old
        history=self.collection();task=history['terminal']['task']();self.assertTrue(task.done());self.assertIsInstance(task.exception(),OSError)
        refs=[deepcopy(c['reference']) for c in history['cuts'][1:]];commands=len(self.commands)
        with self.assertRaises(RuntimeError):await self.terminal_call()
        result,payload=await self.terminal_call('recover');self.assertEqual('saved',payload['terminalState'])
        self.assertEqual(refs,[r['reference'] for r in payload['references']]);self.assertEqual(commands,len(self.commands));self.assertEqual(30,commands)
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        self.assertEqual(refs[0],(await self.read_saved(result,payload['references'][0]))['reference'])

    async def test_lost_saved_partial_cut_cannot_adopt_or_requery_and_recovery_has_no_four_quiet_claim(self):
        await self.terminal_ready();write=self.frame_store_type.write
        def lost(store,index,frame):
            reference=write(store,index,frame)
            if store.namespace=='lifecycle-passive-world' and frame['ordinal']==3:
                raise OSError('Declared loss AFTER actual first quiet frame save, before source caller return')
            return reference
        with patch.object(self.frame_store_type,'write',new=lost),self.assertRaises(RuntimeError):await self.terminal_call()
        history=self.collection();self.assertEqual(2,len(history['cuts']));self.assertIsNotNone(history['pending']);commands=len(self.commands)
        journal=self.ops.native_query_journals[self.run];row=next(row for row in reversed(journal['previous']['records']) if 'passiveCut' in row)
        self.assertEqual('saved',row['passiveCut']['phase']);original=deepcopy(row['passiveCut'])
        with self.assertRaises(RuntimeError):await self.terminal_call()
        _,payload=await self.terminal_call('recover');self.assertEqual('partial',payload['terminalState']);self.assertEqual([2],[r['ordinal'] for r in payload['references']])
        self.assertEqual(commands,len(self.commands));self.assertEqual(original,row['passiveCut']);self.assertEqual(2,len(history['cuts']));self.assertIsNotNone(history['pending'])
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)

    async def test_foreign_owner_and_preparation_reference_refuse_before_terminal_intent_or_query(self):
        from adapters.script_feature.history import canonical
        await self.terminal_ready();args=self.terminal_args();commands=len(self.commands)
        reference=deepcopy(self.ops.retained_motion_resource[8]);reference['inode']+=1
        for changed in (dict(args,expectedOwnerInstance='f'*32),dict(args,preparationReferenceJson=canonical(reference).decode('ascii'))):
            with self.assertRaises(RuntimeError):await self.passive_rpc('touch-native-acquire',changed)
        self.assertEqual(commands,len(self.commands));self.assertNotIn('terminal',self.collection())
        self.assertNotIn('passiveTerminal',self.ops.native_query_journals[self.run]['previous']);self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_pending_original_batch_rejects_second_collect_and_saved_recovery_until_actual_task_return(self):
        await self.terminal_ready();before=len(self.commands);self.response_gate.clear()
        request,task=self.request('touch-native-acquire',self.terminal_args());self.controls_motion.append(task)
        try:
            while len(self.commands)==before:await asyncio.sleep(.001)
            self.assertFalse(task.done());self.assertIs(self.collection()['terminal']['task'](),task)
            commands=len(self.commands)
            with self.assertRaises(RuntimeError):await self.terminal_call('recover')
            with self.assertRaises(RuntimeError):await self.terminal_call()
            self.assertFalse(task.done());self.assertEqual(commands,len(self.commands))
        finally:self.response_gate.set()
        await task;self.assertEqual('complete',self.ops.issued[request]['original']['status']);self.assertEqual(30,len(self.commands))
        _,payload=await self.terminal_call('recover');self.assertEqual('saved',payload['terminalState']);self.assertEqual(5,len(payload['references']))

    async def test_replaced_saved_quiet_inode_refuses_existing_chunk_reader_without_new_query_or_native_time(self):
        await self.terminal_ready();result,payload=await self.terminal_call();row=payload['references'][-1];path=self.cut_path(row['reference'])
        body=path.read_bytes();inode=path.stat().st_ino;replacement=path.with_name('declared-foreign-terminal-quiet')
        replacement.write_bytes(body);replacement.chmod(0o600);os.replace(replacement,path);self.assertNotEqual(inode,path.stat().st_ino)
        commands=len(self.commands)
        with self.assertRaises((RuntimeError,ValueError)):await self.read_saved(result,row)
        self.assertEqual(commands,len(self.commands));self.assertEqual(body,path.read_bytes());self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_source_loss_after_partial_batch_retains_originals_and_original_cleanup_without_replacement_query(self):
        await self.terminal_ready();write=self.frame_store_type.write;current=self.cap.current;lost={'value':False}
        def source_current():
            if lost['value']:raise RuntimeError('Declared original Source/RSD loss AFTER first saved quiet original')
            return current()
        def source_loss(store,index,frame):
            reference=write(store,index,frame)
            if store.namespace=='lifecycle-passive-world' and frame['ordinal']==3:lost['value']=True
            return reference
        with patch.object(self.cap,'current',new=source_current),patch.object(self.frame_store_type,'write',new=source_loss):
            with self.assertRaises(RuntimeError):await self.terminal_call()
            self.assertTrue(lost['value']);history=self.collection();self.assertEqual(2,len(history['cuts']))
            journal=self.ops.native_query_journals[self.run];saved=(journal['store'].path.stat().st_ino,journal['store'].path.read_bytes())
            commands=len(self.commands)
            with self.assertRaises(RuntimeError):await self.terminal_call('recover')
            with self.assertRaises(RuntimeError):await self.terminal_call()
            self.assertEqual(commands,len(self.commands));self.assertEqual(saved,(journal['store'].path.stat().st_ino,journal['store'].path.read_bytes()))
            # Original Up has already returned. Current Source loss cannot
            # prevent actual retained cleanup or become a full quiet proof.
            await self.ops.execute('touch-settle',{},self.binding['sessionId'])
        self.assertTrue(self.source._closing);self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
