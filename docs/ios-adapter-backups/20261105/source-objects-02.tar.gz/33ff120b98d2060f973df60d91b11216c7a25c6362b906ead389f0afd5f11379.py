"""Close the already failed B14 originals; never rerun a target or repair raw data."""
from pathlib import Path
import hashlib,json,runpy
B=Path.cwd()/'.ios-host-tmp';H=B/'emote-callback-source3-one-positive-prepared-root1006-headd483-b14-20261104';O=H.with_name(H.name+'-outer');C=B/'root-emote-b14-whole-outputs-window-current1006-20261104'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,x):
 with(d/n).open('x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
assert sha(H/'approved-inputs.json')=='5b926ad1ae81a65c924bf7142f97d692d74ae5a1d8478730b74d54450499394b'
plan=load(H/'approved-inputs.json');t=load(O/'terminal.json');r=load(H/'child-receipts/child-result.json');resource=load(H/'child-receipts/actual-resources.json')
assert t['status']=='FAIL'and t['checks']['childReturnCode']==1 and t['checks']['ownedProcessesAbsent']and t['checks']['parentFDThreadKernelDrain']and t['checks']['actualOriginalParentPorts']and t['checks']['pinsEqual']and t['checks']['approvedInputEqual']
assert not t['timedOut']and not t['forcedKill']and not t['actualSignals']and not t['checks']['completeOriginalNodeLineage']and not t['checks']['quietCensusesAdmitted']
assert r['testsRun']==1 and r['standardRunReturned']and not r['standardUnittestSuccessful']and r['originalFatal']is None
assert resource['nodes']==[] and load(O/'global-after-first.json')is load(O/'global-after-second.json')is None
error=(H/'child-logs/stderr.log').read_text();assert "assert values['bufsize']==(1 if role=='vm'else-1)"in error and 'FAILED (failures=1)'in error
assert load(C/'unqualified-partial.json')['status']=='NO_TERMINAL_QUALIFICATION_INFERRED'
ctx=B/'root-ios-current1006-after-snapshot-b4-negative-context-20261104';assert sha(ctx/'root-context.json')=='81e305adf6156e829e350343213e2a9b6d24584f0083c4e243afb27c17f8a2bf'
expected=load(ctx/'global-original-corpus-baseline.json');before=load(O/'global-before.json');a=load(C/'independent-global-after-first.json');b=load(C/'independent-global-after-second.json')
assert len(expected)==1006 and before==expected and a==b and set(a)==set(expected)|{str(H/'temporary')}
assert all(a[n]==value for n,value in expected.items())
absence=load(C/'actual-root-kernel-absence.json');assert not absence['actualSameGroupOrSession']
for ident in absence['checkedIdentities']:
 try:raw=Path('/proc',str(ident['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(raw[raw.rfind(')')+2:].split()[19])!=ident['startTicks']
group=absence['originalBirth']['group'];same=[]
for p in Path('/proc').iterdir():
 if not p.name.isdecimal():continue
 try:raw=(p/'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 values=raw[raw.rfind(')')+2:].split()
 if int(values[2])==group or int(values[3])==group:same.append(p.name)
assert not same
q=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(q)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(q))['census']
roots=[H,H/'temporary',O,C];first={str(p):census(p)for p in roots};assert first=={str(p):census(p)for p in roots}
assert first[str(H/'temporary')]==a[str(H/'temporary')]
OUT=B/'root-emote-b14-original-bufsize-failure-complete-custody-results-20261104';OUT.mkdir(mode=0o700)
put(OUT,'whole-first.json',first);put(OUT,'whole-second.json',first)
refs={str(p):dict(path=str(p),sha256=sha(p))for root in roots for p in sorted(root.rglob('*'))if p.is_file()and not p.is_symlink()}
terminal=dict(childReturnCode=t['checks']['childReturnCode'],ownProcessesAbsent=True,problems=t['problems'],timedOut=t['timedOut'],forcedKill=t['forcedKill'])
put(OUT,'results.json',dict(status='ROOT_RETAINED_EMOTE_B14_ACTUAL_ORIGINAL_BUFFER_NORMALIZATION_FAILURE_WITH_COMPLETE_CUSTODY',terminal=terminal,newOriginalRoots=list(map(str,roots))+[str(OUT)],originalSupervisorTerminal=t,actualChildResult=r,originalResourceLedger=resource,actualCaseExecuted=True,all1006OldOriginalBodiesUnchanged=True,originalInternalPostCensusesCorrectlyWithheld=True,actualIndependentRootPostScans=2,onlyNewOwnTemporaryRootIncluded=True,originalRootCollectorMetadataFailurePreserved=True,targetReruns=0,missingNodeLineageNeverQualified=True,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(OUT,'actual-receipt-references.json',refs);put(OUT,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in OUT.iterdir()}));print(json.dumps(dict(freeze=sha(OUT/'freeze.json'),references=len(refs),newRoots=5)))
