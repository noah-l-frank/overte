"""Private AST-only proposal: descriptor reuse lives for ONE identity check.

The old public methods(namespace) branch remains the exact reference route.
No metadata or result is retained between parser_identity calls.
"""
from types import FunctionType,ModuleType
from adapters.normal_feature_state import PrivateFeatureState
from adapters.native_feature_observation import need
from ios.adapters.snapshot_photos_end_round import data,function,methods as legacy_methods

def methods(namespace,memo=None):
    if memo is None:return legacy_methods(namespace)
    functions=memo.setdefault('functions',{});classes=memo.setdefault('classes',{})
    def fingerprint(value):
        key=id(value)
        if key not in functions:functions[key]=(value,function(value))
        prior,value_signature=functions[key];need(prior is value);return value_signature
    result=[]
    for name,value in sorted(namespace.items()):
        if isinstance(value,FunctionType):result.append((name,fingerprint(value)))
        elif isinstance(value,type):
            key=id(value)
            if key not in classes:
                members=[]
                for parent in value.__mro__:
                    for attribute,item in sorted(vars(parent).items()):
                        if parent is PrivateFeatureState and attribute in ('write','discard'):continue
                        if isinstance(item,(staticmethod,classmethod)):item=item.__func__
                        if isinstance(item,FunctionType):members.append((parent,attribute,fingerprint(item)))
                        elif not attribute.startswith('__'):members.append((parent,attribute,data(item)))
                classes[key]=(value,tuple(members))
            prior,members=classes[key];need(prior is value);result.append((name,value,members))
        elif isinstance(value,ModuleType):result.append((name,id(value)))
    return tuple(result)

# Source patch plan for parser_identity, not executed by this private module:
#   memo = {}                       # NEW for every invocation
#   current = {}
#   for original module:
#       signature = methods(vars(module), memo)
#       current[name] = (module, signature)
#       need(module identity and signature == ORIGINAL[name])
#   return the SAME prior tuple shape:
#       methods signature from current if that exact module was checked,
#       otherwise methods(vars(module), memo) for a newly imported module;
#       all uppercase constants still freshly evaluated by unchanged data().
