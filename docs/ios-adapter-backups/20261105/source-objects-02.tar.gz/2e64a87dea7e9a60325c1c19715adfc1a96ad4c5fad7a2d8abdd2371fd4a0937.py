"""Same original snapshot bytes from one complete validation, no result cache."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_ui import NativeUIError
from ios.adapters.audio_passive_capture_source import original_frame
from ios.self_tests.test_ios_audio_passive_owner import AudioPassiveOwnerTests

class AudioOriginalSnapshotReturnTests(unittest.TestCase):
    def setUp(self):
        self.f=AudioPassiveOwnerTests();self.f.setUp();self.addCleanup(self.f.doCleanups);self.f.begin()
        with self.f.owner()as owner:owner.capture();owner.retire()

    def test_exact_original_bytes_epoch_and_native_frame_with_less_duplicate_reads_and_fresh_independent_calls(self):
        with self.f.owner()as owner:
            files={p:(p.stat().st_ino,p.read_bytes())for p in owner.root.iterdir()};commands=deepcopy(self.f.boundary.commands)
            journal=owner.journals['proofs'];read=journal.files.read;reads=[]
            def counted(ref):reads.append(ref['index']);return read(ref)
            with patch.object(journal.files,'read',counted):
                frame=owner.proof(owner.state['snapshot']);wav=owner.snapshot()['wav']
                body=owner.assembled(frame['chunks']['capture'],'capture',frame['selection'],owner.state['snapshot'])
                native=original_frame(body,wav,owner.state['capture'],owner.pid);selection=owner.proof(frame['selection'])
            legacy=len(reads);reads.clear()
            with patch.object(journal.files,'read',counted):value=owner.snapshot_original()
            self.assertEqual(wav,value['raw']['wav']);self.assertEqual(body,value['raw']['capture']);self.assertEqual(native,value['native'])
            self.assertEqual(frame,value['frame']);self.assertEqual(selection,value['selection']);self.assertLess(len(reads),legacy)
            self.assertTrue(set(sum(frame['chunks'].values(),[])).issubset(set(reads)));self.assertIsNone(owner._snapshot_handoff);self.assertIsNone(owner._inventory_round)
            reads.clear()
            with patch.object(journal.files,'read',counted):self.assertEqual(value,owner.snapshot_original())
            self.assertTrue(reads);self.assertEqual(commands,self.f.boundary.commands)
            self.assertEqual(files,{p:(p.stat().st_ino,p.read_bytes())for p in owner.root.iterdir()})

    def test_unknown_namespace_birth_during_complete_original_validation_refuses_without_handoff_or_native_commands(self):
        with self.f.owner()as owner:
            journal=owner.journals['proofs'];actual=journal.files.read;changed=[];commands=deepcopy(self.f.boundary.commands)
            def original(ref):
                value=actual(ref)
                if not changed:
                    path=owner.root/'foreign-original-duty.json';path.write_text('{}');path.chmod(0o600);changed.append(path)
                return value
            with patch.object(journal.files,'read',original),self.assertRaises(NativeUIError):owner.snapshot_original()
            self.assertTrue(changed);self.assertIsNone(owner._snapshot_handoff);self.assertIsNone(owner._inventory_round)
            self.assertEqual(commands,self.f.boundary.commands)

    def test_same_inode_original_rewrite_and_changed_owner_state_cannot_escape_the_call(self):
        with self.f.owner()as owner:
            journal=owner.journals['proofs'];actual=journal.files.read;changed=[]
            path=next(p for p in owner._signatures if '-native-frame-'in p.name);raw=path.read_bytes();inode=path.stat().st_ino
            def original(ref):
                value=actual(ref)
                if not changed:path.write_bytes(raw);changed.append(True)
                return value
            with patch.object(journal.files,'read',original),self.assertRaises(NativeUIError):owner.snapshot_original()
            self.assertEqual(inode,path.stat().st_ino);self.assertIsNone(owner._snapshot_handoff);self.assertIsNone(owner._inventory_round)
        # Independent intact originals; never relabel the preceding mutation.
        other=AudioPassiveOwnerTests();other.setUp();self.addCleanup(other.doCleanups);other.begin()
        with other.owner()as owner:
            owner.capture();owner.retire();journal=owner.journals['proofs'];actual=journal.files.read;changed=[]
            def state_change(ref):
                value=actual(ref)
                if not changed:owner.state['phase']='captured';changed.append(True)
                return value
            with patch.object(journal.files,'read',state_change),self.assertRaises(NativeUIError):owner.snapshot_original()
            self.assertIsNone(owner._snapshot_handoff);self.assertIsNone(owner._inventory_round)
