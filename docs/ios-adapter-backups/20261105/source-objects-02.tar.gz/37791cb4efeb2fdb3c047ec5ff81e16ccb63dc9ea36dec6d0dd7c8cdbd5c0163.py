"""Fresh pre-input whole source fixture; only SDK/Qt/native are MODELS.

Selects four exact removals from HOST MODEL setup before any original exists.
No production method, validator, current packet or saved history is replaced.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import ast,asyncio,base64,hashlib,inspect,json,marshal,os,time,uuid
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.phase_fixture import PhaseFixtureReader
from ios.adapters.appium_adapter import AppiumAdapter
from ios.adapters.lifecycle_actions import LifecycleActions
from ios.adapters.lifecycle_actor_history import LifecycleCurrentHistory
from ios.adapters.lifecycle_current_stream import LifecycleCurrentStream
from ios.adapters.lifecycle_editors import LifecycleEditors
from ios.adapters.lifecycle_editor_history import LifecycleEditorHistory
from ios.adapters.lifecycle_originals import IOSLifecycleSources
from ios.adapters.lifecycle_navigation_owner import LifecycleNavigationOwner
from ios.adapters.lifecycle_input_owner import LifecycleInputOwner
from ios.adapters.lifecycle_editors_runtime import IOSLifecycleEditorsRuntime
from ios.adapters.lifecycle_restoration import LifecycleRestoration
from ios.adapters.lifecycle_observer import LifecycleObserver
from ios.adapters.script_runtime import IOSScriptRuntime
from ios.adapters import feature_observation,lifecycle_pending_commands as pending_commands,normal_input
from ios.self_tests import test_ios_lifecycle_world_attempt as attempt_fixture
from normal_child_fixture import NormalChildFixture
from test_lifecycle_actor_phase_publication_models import LifecycleActorPhasePublicationModels,POLICY


def setup_method(case,role,kind,name,removed,*,super_kind=None):
    raw=Path(os.environ['LIFECYCLE_WHOLE_FIXTURE_BIRTH_MAP']).read_bytes()
    case.assertEqual(os.environ['LIFECYCLE_WHOLE_FIXTURE_BIRTH_MAP_SHA256'],hashlib.sha256(raw).hexdigest())
    row=json.loads(raw)[role];path=Path(row['path']);source=path.read_bytes();case.assertEqual(row['sha256'],hashlib.sha256(source).hexdigest())
    original=getattr(kind,name);case.assertEqual(path.resolve(),Path(inspect.getsourcefile(original)).resolve())
    tree=ast.parse(source);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name==kind.__name__)
    function=deepcopy(next(n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))and n.name==name))
    found=[]
    for parent in ast.walk(function):
        if not isinstance(getattr(parent,'body',None),list):continue
        for node in tuple(parent.body):
            if isinstance(node,ast.Expr)and isinstance(node.value,ast.Call)and ast.unparse(node.value.func)in removed:
                found.append(ast.unparse(node.value.func));parent.body.remove(node)
    case.assertEqual(sorted(removed),sorted(found))
    count=0
    if super_kind is not None:
        for node in ast.walk(function):
            if isinstance(node,ast.Call)and isinstance(node.func,ast.Name)and node.func.id=='super'and not node.args:
                node.args=[ast.Name(id='_MODEL_ORIGINAL_CLASS',ctx=ast.Load()),ast.Name(id='self',ctx=ast.Load())];count+=1
        case.assertEqual(1,count)
    module=ast.Module(body=[function],type_ignores=[]);code=compile(ast.fix_missing_locations(module),str(path),'exec')
    namespace=dict(original.__globals__,_MODEL_ORIGINAL_CLASS=super_kind);exec(code,namespace)
    record=dict(role=role,sourceSha256=row['sha256'],modelAstSha256=hashlib.sha256(ast.dump(module,include_attributes=False).encode()).hexdigest(),
        compiledCodeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest(),removedModelCalls=found,superClassExplicit=count,
        productionCodeChanged=False,oldOriginalsModified=False)
    side=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/('whole-fresh-model-'+role+'-'+uuid.uuid4().hex+'.json')
    side.write_text(json.dumps(record)+'\n');side.chmod(0o600);return namespace[name]


class FreshWholeFixture(LifecycleActorPhasePublicationModels):
    _fixture_has_legacy_actions=False
    async def asyncSetUp(self):
        attempt=setup_method(self,'attempt',attempt_fixture.AttemptDomain,'__init__',{'self.d.flow.open','self.d.flow.type'})
        normal=setup_method(self,'normal',NormalChildFixture,'asyncSetUp',{'self.normal.owner.act','self.normal.d.flow.back'},super_kind=NormalChildFixture)
        with patch.object(attempt_fixture.AttemptDomain,'__init__',new=attempt),patch.object(NormalChildFixture,'asyncSetUp',new=normal):
            await super().asyncSetUp()
        self.assertEqual([],self.normal.d.commands);self.assertEqual([],self.normal.boundary.events)
        self.assertEqual([],self.normal.d.flow.state['actions']);self.assertEqual([],self.normal.d.flow.history.state['aliases'])
        self.assertEqual([],self.f.states());self.assertEqual(1,len(self.ops._lifecycle_current['primary'].frames))
        self.lifecycle=dict(backgrounds=0,activations=1,launches=1);self.os_inputs=[];self.pending_rows=[];self.pending_query=None;self.pending_sequence=0
        self.setup_merged_ui();self.setup_os_and_pending()

    def setup_merged_ui(self):
        editor=self.normal.d;address=self.address;original_observed=editor.observed;original_post=editor.post
        previous_visible=address.visible
        def visible(name):
            if editor.route!='closed'and name in ('Go to destination','tablet.open'):return False
            return previous_visible(name)
        address.visible=visible
        def observed():
            current=original_observed();address.sequence_native=editor.b.sequence;extra=address.observed()
            self.assertEqual(current['instance'],extra['instance']);self.assertEqual(current['lastSequence'],extra['lastSequence'])
            current['controls'].extend(row for row in extra['controls']if row['id']!='hud.tablet')
            for key in ('navigationInventory','navigationDialogControlsVersion','navigationDialogSourceSequence'):current[key]=deepcopy(extra[key])
            return current
        editor.b.observed=observed
        def post(request,timeout):
            query=json.loads(request.data)
            command=query.get('input');tokens={row['token']for row in address.observed()['controls']if row['id']!='hud.tablet'}
            if command is not None and command['fieldToken']in tokens:
                returned=address.post(request,timeout);editor.b.receipt=deepcopy(address.native_boundary.receipt)
                editor.b.sequence=address.sequence_native;return returned
            if query['operation']=='observe':
                editor.b.requests.append(deepcopy(query));editor.b.receipt=dict(schemaVersion=1,commandId=query['commandId'],observation=observed())
                editor.b.response=json.dumps(query).encode();return editor.b
            returned=original_post(request,timeout);address.sequence_native=editor.b.sequence;return returned
        self.enterContext(patch.object(normal_input,'urlopen',side_effect=post))
        # Current7's original child HTTP producer invokes this same real raw
        # SDK boundary, so it sees the same merged instance/sequence/inventory.
        editor.b.observed=observed

    def setup_os_and_pending(self):
        installed=self.normal.d.f.f.f;previous_clock=installed.clock.mutate;previous_execute=self.normal.client.execute
        def clock(value):previous_clock(value);value['lifecycle']=deepcopy(self.lifecycle)
        installed.clock.mutate=clock
        world_mutate=self.normal.boundary.mutate
        def world(value):world_mutate(value);value['source']['lifecycle']=deepcopy(self.lifecycle)
        self.normal.boundary.mutate=world
        native=self.normal.native.p.boundary;original=native.original
        def tap():
            raw=original();query=native.request;value=json.loads(raw)
            if query['operation']in ('hold','attempt','release')and not any(row['command']['commandId']==query['commandId']for row in self.pending_rows):
                self.pending_rows.append(dict(index=len(self.pending_rows)+1,command=deepcopy(query),reply=deepcopy(value),recordedEpochMs=self.normal.native.stamp()['epochMs']))
            return raw
        native.original=tap
        previous_post=feature_observation.post_request.side_effect
        def post(request,timeout):
            query=json.loads(request.data)
            if query.get('action')!=pending_commands.ACTION:return previous_post(request,timeout)
            self.pending_query=deepcopy(query);self.pending_sequence+=1;raw=json.dumps(query).encode()
            class Response:
                status=200
                def __enter__(self):return self
                def __exit__(self,*_):return False
                def read(self,limit):return raw[:limit]
            return Response()
        def execute(session,operation,arguments):
            if operation=='mobile: queryAppState':return 4 if installed.process and installed.process['foreground']else 3
            if operation in ('mobile: backgroundApp','mobile: activateApp'):
                self.os_inputs.append(operation)
                saved=PrivateFeatureState(installed.root/'ios-lifecycle-background.json').read()
                self.assertEqual('background-issued'if operation.endswith('backgroundApp')else'foreground-issued',saved['state']['phase'])
                if operation.endswith('backgroundApp'):
                    installed.process['foreground']=False;self.lifecycle['backgrounds']+=1
                    self.normal.d.current()['focused']=False;self.normal.native.p.k.b.notify('did-hide',valid=False)
                else:installed.process['foreground']=True;self.lifecycle['activations']+=1
                return True
            if operation=='mobile: pullFile'and arguments['remotePath'].endswith('/'+pending_commands.FILE):
                before=self.normal.native.stamp();after=self.normal.native.stamp()
                packet=dict(iosLifecyclePendingCommandsVersion=1,requestId=self.pending_query['commandId'],runId=self.run,instance='9'*32,
                    sequence=self.pending_sequence,processId=42,clockDomain='native-main-lifecycle-pending-commands',clockBefore=before,clockAfter=after,
                    source=dict(installed=True,complete=True,commands=deepcopy(self.pending_rows)))
                return base64.b64encode(json.dumps(packet).encode()).decode()
            return previous_execute(session,operation,arguments)
        self.normal.client.execute=execute;self.enterContext(patch.object(feature_observation,'post_request',side_effect=post))
        installed.adapter.query_app_state=AppiumAdapter.query_app_state.__get__(installed.adapter,type(installed.adapter))

    def new_editors(self,source,lock,root):
        # Preserve the actual Source's NativeInput. Its SDK boundary is the
        # merged producer above; no Address-only replacement input is injected.
        originals=IOSLifecycleSources(source,self.run)
        owners=[];readers=[]
        for owner_type,reader_name in ((LifecycleNavigationOwner,'lifecycle_navigation_inputs'),(LifecycleInputOwner,'lifecycle_inputs')):
            owners.append(owner_type(PrivateFeatureState(root/owner_type.store_name('primary')),lock,self.binding,self.run,'primary',source['native'],source['check']))
            readers.append(getattr(source['observer'],reader_name)(clock_source=source['clock_source']))
        history=LifecycleEditorHistory(PrivateFeatureState(root/'lifecycle-editor-owner.json'),self.binding,self.run,lock,source['check'])
        editors=LifecycleEditors(PrivateFeatureState(root/'ios-lifecycle-editors-owner.json'),history,originals,
            owners[0],readers[0],owners[1],readers[1],whole=True)
        # The raw editor producer asserts the ACTUAL currently issued owner WAL,
        # including newly reconstructed parents. This supplies no product facts.
        self.normal.d.flow=editors;return editors

    async def primary_api(self,operation='observe',call=None):
        def enter():
            runtime=IOSScriptRuntime(self.runtime.adapter);root=runtime.state_path('test-only').parent;lock=ScriptSourceLock(root/'script-feature-sources.lock')
            with lock.held():
                source=runtime._sources('test-only');editors=self.new_editors(source,lock,root)
                stream=LifecycleCurrentStream(PrivateFeatureState(root/('ios-lifecycle-current-stream-primary-'+self.run+'.json')),
                    self.current_root,source,self.run,'primary',lock)
                history=LifecycleCurrentHistory(PrivateFeatureState(root/('ios-lifecycle-primary-current-history-'+self.run+'.json')),stream);history.recover_saved()
                phase=PhaseFixtureReader(self.runner_client,self.run,'lifecycle-input');phase.read()
                restoration=LifecycleRestoration(PrivateFeatureState(root/'ios-lifecycle-restoration.json'),editors,
                    epoch_ms=lambda:time.time()*1000,monotonic=time.monotonic,current_stream=stream)
                actions=LifecycleActions(PrivateFeatureState(root/'ios-lifecycle-actions.json'),IOSLifecycleEditorsRuntime(runtime.adapter),'test-only',editors,restoration,phase)
                self.primary_actions=actions;self.primary_history=history
                if operation=='act':return actions.act(call)
                if operation=='settle':return actions.settle_original_input()
                observer=LifecycleObserver(PrivateFeatureState(root/('ios-lifecycle-observer-primary-'+self.run+'.json')),stream,history,actions,phase,
                    policy=POLICY,epoch_ms=lambda:time.time()*1000,monotonic=time.monotonic)
                return observer.observe()
        return await asyncio.to_thread(enter)
