"""Actual C10c proof is known; OwnBoundary success still requires its real receipt."""
from pathlib import Path
from prefix_common import REPO,pin,load
from source_execution_admission import SUBJECT,HELPER,QUALIFIED,qualify


def retained_packet(path,digest):
    path=Path(path)
    assert path.is_absolute()and path.resolve(strict=True)==path
    assert path.is_relative_to(REPO/'.ios-host-tmp')and path.name=='freeze.json'
    assert pin(path)['sha256']==digest
    for name,row in load(path)['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        actual=path.parent/name
        assert pin(actual)['sha256']==(row if type(row)is str else row['sha256'])
    return path


def qualified_original(path,digest):
    retained_packet(path,digest)
    raise RuntimeError('Actual OwnBoundary runtime result join pending: no prefix metadata admission')


def source_execution_original(path,digest):
    assert Path(path)==REPO/'.ios-host-tmp/root-c10c-source-execution-six-cache-mutation-alias-counters-qualified-results-20261104/freeze.json'
    assert digest==QUALIFIED;retained_packet(path,digest)
    proof=dict(subjectSourceFreeze=SUBJECT,helperSha256=HELPER,rootFreeze=dict(path=str(path),sha256=digest))
    actual=qualify(dict(qualifiedSourceExecution=proof),pin)
    references=load(Path(path).parent/'actual-receipt-references.json');assert len(references)==48
    for row in references.values():assert pin(row['path'])['sha256']==row['sha256']
    return dict(qualifiedSourceExecution=proof,actualResult=actual,actualReceiptReferences=references)
