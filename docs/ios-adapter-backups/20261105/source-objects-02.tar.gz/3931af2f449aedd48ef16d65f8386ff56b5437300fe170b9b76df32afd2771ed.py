"""Original Emote supervisor owns its old-corpus window; Root closes whole outputs."""
from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys,traceback
R=Path.cwd().resolve();B=R/'.ios-host-tmp';S=Path(__file__).resolve().parent
H=B/'emote-callback-source3-one-positive-prepared-root966-headcb793-b11-20261104';O=H.with_name(H.name+'-outer');OUT=B/'root-emote-b11-whole-outputs-window-current966-20261104'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(n,x):
 with(OUT/n).open('x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
 (OUT/n).chmod(0o600)
assert sys.flags.no_site and sys.dont_write_bytecode and len(sys.argv)==2 and sys.argv[1]==sha(S/'source-freeze.json')
assert sha(Path(__file__))==load(S/'source-freeze.json')['files']['run.py']['sha256']
p=H/'approved-inputs.json';digest='9128b0cfafcc7b83b8f2a3b342888c5ec295db8ea3b17141c70cdd2811e6a9ba';assert sha(p)==digest
plan=load(p);assert plan['oldRootCount']==966 and plan['wallSeconds']==300 and plan['killGraceSeconds']==5 and len(plan['cases'])==1
assert not O.exists()and not(H/'temporary').exists()and not OUT.exists()
review=B/'root-emote-b11-generated966-complete-readback-20261104';assert sha(review/'freeze.json')=='139eab84ce792fd05b8bfa7b78fce0ac146a3fd9e78e2220e804a4faf54920c0'
freeze=load(review/'freeze.json')
for n,v in freeze['files'].items():assert sha(review/n)==v['sha256']
assert load(review/'review.json')['inputSha256']==digest
ad=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(ad)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(ad))['census']
OUT.mkdir(mode=0o700);put('attempt.json',dict(input=str(p),inputSha256=digest,oldRoots=966,originalSupervisorOwnsBeforeAndTwoAfterGlobalWindows=True,externalRootAddsNoDuplicateOldCorpusWindow=True,original300Plus5CapsUnchanged=True))
try:
 with(OUT/'supervisor-stdout.log').open('xb')as stdout,(OUT/'supervisor-stderr.log').open('xb')as stderr:
  result=subprocess.run([sys.executable,'-S','-B',str(H/'supervise.py'),'--approved-inputs-sha',digest],cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
 terminal=load(O/'terminal.json');checks=terminal['checks'];assert checks['ownedProcessesAbsent']is True
 birth=load(O/'actual-runner-birth.json')
 # Missing original resource receipts stay missing and never qualify a case.
 # Independently confirm actual kernel absence even for a pre-case failure.
 resource_path=H/'child-receipts/actual-resources.json'
 resource=load(resource_path) if resource_path.is_file() else None
 observed=terminal['actualObservedDescendants']
 identities=[birth]+list(observed.values())
 if resource is not None:identities += [row['birth']for row in resource['nodes']]
 assert type(birth['group']) is int and birth['group']>0
 same_group=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdecimal():continue
  try:raw=(proc/'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  values=raw[raw.rfind(')')+2:].split()
  if int(values[2])==birth['group'] or int(values[3])==birth['group']:
   same_group.append(dict(pid=int(proc.name),group=int(values[2]),session=int(values[3]),startTicks=int(values[19])))
 assert not same_group,'Original process group/session remains; no quiet close'
 put('actual-root-kernel-absence.json',dict(originalBirth=birth,actualObservedDescendants=observed,originalResourceLedgerAvailable=resource is not None,checkedIdentities=identities,actualSameGroupOrSession=same_group,originalResourceQualificationGranted=False))
 for ident in identities:
  try:raw=Path('/proc',str(ident['pid']),'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  assert int(raw[raw.rfind(')')+2:].split()[19])!=ident['startTicks'],'Original owned process remains'
 before=load(O/'global-before.json');after1=load(O/'global-after-first.json');after2=load(O/'global-after-second.json')
 assert len(before)==966 and after1==after2 and set(after1)==set(before)|{str(H/'temporary')}
 assert all(after1[name]==value for name,value in before.items())
 roots=[H,H/'temporary',O];first={str(root):census(root)for root in roots};second={str(root):census(root)for root in roots};assert first==second
 put('whole-first.json',first);put('whole-second.json',second)
 put('terminal.json',dict(status='ROOT_ORIGINAL_EMOTE_ONE_PASS_CLOSED'if result.returncode==0 and terminal['status']=='PASS'else'ROOT_ORIGINAL_EMOTE_ONE_FAILURE_CLOSED',originalSupervisorReturnCode=result.returncode,originalSupervisorTerminal=terminal,actualOriginalThreeGlobalCensusesJoined=True,all966OldOriginalBodiesUnchanged=True,wholeHEREAndOuterTwiceEqual=True,ownProcessesAbsent=True,newOriginalRoots=[str(root)for root in roots]+[str(OUT)],nativeQualified=False,wholeQualified=False))
except BaseException:
 put('unqualified-partial.json',dict(status='NO_TERMINAL_QUALIFICATION_INFERRED',traceback=traceback.format_exc(),attemptedOriginalRoots=[str(H),str(H/'temporary'),str(O),str(OUT)]));raise
put('freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in sorted(OUT.iterdir())}))
print(json.dumps(dict(status=load(OUT/'terminal.json')['status'],freeze=sha(OUT/'freeze.json'))),flush=True)
raise SystemExit(0 if result.returncode==0 and terminal['status']=='PASS'else 1)
