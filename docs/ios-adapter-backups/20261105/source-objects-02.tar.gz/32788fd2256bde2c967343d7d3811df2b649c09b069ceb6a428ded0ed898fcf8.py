"""One exact unchanged IntentTransitions.persist local-return observer."""
import os,sys


class TypedIntentObserver:
    def __init__(self,transition_type,policy_type,owner_type,temporary):
        self.transition_type,self.policy_type,self.owner_type=transition_type,policy_type,owner_type
        self.function=transition_type.persist;self.code=self.function.__code__;self.namespace=self.function.__globals__
        self.temporary=temporary;self.tool=None;self.rows=[];self.literal_returns=0
        self.name='overte-assets-reserved-intent-observer-'+str(os.getpid())+'-'+str(id(self))
        self.previous_profile=sys.getprofile();self.previous_trace=sys.gettrace()
    def start(self):
        if self.tool is not None or self.previous_profile is not None or self.previous_trace is not None:
            raise RuntimeError('Exact inactive local intent observer required')
        m=sys.monitoring;free=[i for i in(2,5,4,3,1,0)if m.get_tool(i)is None]
        if not free:raise RuntimeError('No distinct private intent monitor slot')
        self.monitoring=m;self.tool=free[0];m.use_tool_id(self.tool,self.name)
        m.register_callback(self.tool,m.events.PY_RETURN,self.returned)
        m.set_local_events(self.tool,self.code,m.events.PY_RETURN)
        if m.get_events(self.tool)!=0 or m.get_local_events(self.tool,self.code)!=m.events.PY_RETURN:
            raise RuntimeError('Intent observer must have only exact local returns')
        return self
    def returned(self,code,offset,value):
        frame=sys._getframe(1);owner=frame.f_locals.get('self')
        if (code is not self.code or frame.f_code is not self.code or frame.f_globals is not self.namespace
                or self.transition_type.persist is not self.function or self.function.__code__ is not self.code):
            raise RuntimeError('Actual unchanged intent method required')
        if type(owner)is not self.transition_type:raise RuntimeError('Unknown intent receiver')
        if owner.disabled:
            self.literal_returns+=1;return
        if value is True and owner.typed_transitions>0:
            picker=owner.owner
            if type(owner.policy)is not self.policy_type or owner.policy.owner is not picker or type(picker)is not self.owner_type:
                raise RuntimeError('Typed path needs actual picker/policy custody')
            path=picker.store.path.resolve(strict=True)
            if not path.is_relative_to(self.temporary):raise RuntimeError('Typed owner outside actual owned room')
            self.rows.append(dict(ownerPath=str(path),typedTransitions=owner.typed_transitions,
                actualPolicyType=type(owner.policy).__name__,disabled=False,returnWasTrue=True))
    def stop(self):
        if self.tool is None:return
        m=self.monitoring;tool=self.tool
        if m.get_tool(tool)!=self.name:raise RuntimeError('Foreign monitoring tool not cleared')
        m.set_local_events(tool,self.code,0);m.register_callback(tool,m.events.PY_RETURN,None)
        if m.get_events(tool)!=0 or m.get_local_events(tool,self.code)!=0:raise RuntimeError('Intent observer not drained')
        m.free_tool_id(tool);self.tool=None
        if sys.getprofile()is not self.previous_profile or sys.gettrace()is not self.previous_trace:
            raise RuntimeError('Original profile/trace changed')
    def report(self):
        return dict(exactLocalReturnOnly=True,actualTypedPathReached=bool(self.rows),rows=self.rows,
            literalFallbackReturns=self.literal_returns,ownToolFreed=self.tool is None,
            nativeVerdictsCached=False,wholeAssetsQualified=False)


class NodeConstructorObserver:
    """Original Popen entry only, before any parameter normalization or spawn."""
    def __init__(self,scope):
        self.scope=scope;self.function=scope.popen;self.code=scope.popen_code;self.tool=None;self.entries=0
        self.name='overte-assets-exact-node-entry-'+str(os.getpid())+'-'+str(id(self))
    def start(self):
        m=sys.monitoring;free=[tool for tool in(2,5,4,3,1,0)if m.get_tool(tool)is None]
        if not free:raise RuntimeError('No private exact constructor observer slot')
        self.monitor=m;self.tool=free[0];m.use_tool_id(self.tool,self.name)
        m.register_callback(self.tool,m.events.PY_START,self.entered)
        m.set_local_events(self.tool,self.code,m.events.PY_START)
        if m.get_events(self.tool)!=0 or m.get_local_events(self.tool,self.code)!=m.events.PY_START:
            raise RuntimeError('Constructor observer must be exact local-start only')
        return self
    def entered(self,code,offset):
        frame=sys._getframe(1)
        if code is not self.code or frame.f_code is not self.code or self.function.__code__ is not self.code:
            raise RuntimeError('Original constructor code changed')
        self.scope.node_start(frame);self.entries+=1
    def stop(self):
        if self.tool is None:return
        m=self.monitor;tool=self.tool
        if m.get_tool(tool)!=self.name:raise RuntimeError('Foreign constructor monitor not cleared')
        m.set_local_events(tool,self.code,0);m.register_callback(tool,m.events.PY_START,None)
        if m.get_events(tool)!=0 or m.get_local_events(tool,self.code)!=0:raise RuntimeError('Constructor monitor not drained')
        m.free_tool_id(tool);self.tool=None
