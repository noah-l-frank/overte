// In-client observation probe for physical-device E2E tests. This script is
// loaded only through Interface's --testScript command-line option and writes
// snapshots into --testResultsLocation through the existing Test API.
(function () {
    "use strict";

    function reloadCommandIdFromAddress(address) {
        var match = String(address).match(
            /[?&]overteE2EReloadCommandId=([^&#]*)/);
        if (!match) {
            return "";
        }
        try {
            return decodeURIComponent(match[1]);
        } catch (error) {
            return "";
        }
    }

    function addressWithoutReloadCommand(address) {
        var withoutFragment = String(address).split("#", 1)[0];
        var queryStart = withoutFragment.indexOf("?");
        if (queryStart === -1) {
            return withoutFragment;
        }
        var path = withoutFragment.slice(0, queryStart);
        var components = withoutFragment.slice(queryStart + 1).split("&");
        var retained = [];
        var index;
        for (index = 0; index < components.length; index += 1) {
            if (components[index]
                    && components[index].indexOf("overteE2EReloadCommandId=") !== 0) {
                retained.push(components[index]);
            }
        }
        return path + (retained.length ? "?" + retained.join("&") : "");
    }

    var tablet = Tablet.getTablet("com.highfidelity.interface.tablet.system");
    var stableEntitySamples = 0;
    var previousEntityCount = -1;
    var stableAvatarSamples = 0;
    var previousAvatarPosition = null;
    var sceneReady = false;
    var probeErrorCount = 0;
    var lastProbeError = "";
    var lastSampleEpochMs = 0;
    var lastCompletedSampleEpochMs = 0;
    var lastHeartbeatEpochMs = 0;
    var sampleIntervalMs = 250;
    var heartbeatIntervalMs = 5000;
    var previousLocationKey = "";
    // About.platform is the product brand, not the operating system. Only the
    // fixed debug launcher supplies this local, versioned control marker.
    var controlledTextFixtureActive = false;
    var androidControlMarkerUrl = String(Script.resolvePath("android-control.json"));
    var androidControlCommandUrl = String(Script.resolvePath("android-control-command.json"));
    var androidFixtureUrl = String(Script.resolvePath("scene.json"))
        + "?location=/0,0,4/0,0,0,1";
    var androidControlEligible = /^file:/.test(androidControlMarkerUrl);
    var androidControlAvailable = false;
    var androidControlProcessId = null;
    var nativeMotionUrl = String(Script.resolvePath("avatar-motion-observation.json"));
    var nativeMotionLastRequestEpochMs = 0;
    var nativeMotionLastSequence = 0;
    var nativeMotionUpdatedEpochMs = 0;
    var nativeMotionAvailable = false;
    var lastAndroidControlCommandId = reloadCommandIdFromAddress(location.href);
    var androidAssetEntityId = null;
    var flightNormalizationAllowed = true;
    var flightNormalizationActive = false;
    var flightNormalizationStableSamples = 0;
    var flyingEnabledBeforeNormalization = false;
    var assetResource = null;
    var assetResourceUrl = "";
    var controlledAssetEntity = null;
    var controlledKey = null;
    var controlledKeyCommandId = "";
    var controlledInputMappingName = "org.overte.e2e.probe.controlled-input";
    var controlledInputMapping = Controller.newMapping(controlledInputMappingName);
    // Resolve while the script file is the active execution context. Timer
    // callbacks do not retain that source context on every script engine.
    var clientCommandFallbackUrl = String(Script.resolvePath("e2e-client-command.json"));
    var clientCommandRequest = null;
    var clientCommandUnavailable = false;
    var lastClientCommandId = "";
    var savedNativeClientReceiptIds = {};
    var pendingProbeRequestId = "";
    var lastProbeResponseId = "";
    var lastTextCommandId = "";
    var primaryOriginalCameraMode = null;
    var primaryViewCommandId = "";
    // Serverless navigation can restart the probe. Recover the identity from
    // the actual loaded address, rather than losing the reload confirmation.
    var lastSceneCommandId = reloadCommandIdFromAddress(location.href);
    var sampleSequence = 0;
    // Private read-only diagnostic for normal Running Scripts row identity.
    // Actual execution is still judged by the independent fixture journal.
    var normalFeatureInstance = String(Uuid.generate()).replace(/[{}-]/g, "").toLowerCase();
    var normalFeatureSequence = 0;
    var lastChatObservationCommand="";
    var lastChatViewCommand="";
    var lastIOSBundleDone="";
    function validChatObservationCommand(command) {
        return command && command.schemaVersion===1 && command.action==="feature-chat-observe"
            && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
            && /^[0-9a-f]{32}$/.test(String(command.runId))
            && /^(observe|inspect|retire)$/.test(String(command.operation))
            && objectKeysMatch(command,["schemaVersion","commandId","action","operation","runId"]);
    }


    var lastNormalFeatureRequest = "";
    var lastNativeFeatureRequest = "";
    var nativeFeatureTimer = null;
    var lastAccountProbeCommand = "";
    var lastPrivateLoginInputCommand = "";
    var lastAccountOriginCommand = "";
    var accountProbeTimer = null;
    var lastRecordedPreviewRequest = "";
    // Explicit passive original-file profile; legacy shared quotas unchanged.
    var passiveAudioRequests = {};
    var passiveAudioRequestCount = 0;
    var completedFrameCommand = null;
    var completedFrameTimer = null;
    var lastCompletedFrameCommand = "";
    function saveCompletedFrame(command, remaining) {
        if (completedFrameCommand !== command) { return; }
        var result = {completedFrameVersion: 1, commandId: command.commandId, requestId: command.requestId, available: false};
        try {
            if (typeof Test.featureCompletedFrameObservation === "function") {
                var original = Test.featureCompletedFrameObservation(command);
                if (original && original.commandId === command.commandId && original.requestId === command.requestId) {
                    if (original.pending === true && remaining > 0) {
                        completedFrameTimer = Script.setTimeout(function () {
                            if (completedFrameCommand !== command) { return; }
                            completedFrameTimer = null; saveCompletedFrame(command, remaining - 1);
                        }, 25);
                        return;
                    }
                    result = original;
                }
            }
        } catch (_completedFrameError) { /* Recording or an ACK is never GPU completion. */ }
        Test.saveObject(result, command.action === "feature-vulkan-world-frame"
            ? "feature-vulkan-world-frame.json" : "feature-completed-frame.json");
    }
    var lastWorldRenderRequest = "";
    var lastGraphicsSubjectRequest = "";
    var lastIOSLocationBookmarksRequest = "";
    var lastIOSPlacesModelRequest = "";
    var lastIOSPlacesHttpRequest = "";
    var lastIOSNavigationDialogRequest = "";
    var lastIOSNavigationStateRequest = "";
    var lastIOSAvatarStateRequest = "";
    var iosNewSourceRequests = {};
    var iosNewSourceRequestCount = 0;
    var lastIOSSceneInventoryRequest = "";
    var lastSceneLoadRequest = "";
    var lastWorldRenderStorageCommand = "";
    var lastWorldRenderReceiptCommand = "";
    var worldRenderTimer = null;
    function saveWorldRenderObservation(requestId, remaining) {
        if (requestId !== lastWorldRenderRequest) { return; }
        if (remaining === undefined) { remaining = 50; }
        var value = {schemaVersion: 1, requestId: requestId, available: false};
        try {
            if (typeof Test.featureWorldRenderCapture === "function") {
                var original = Test.featureWorldRenderCapture(requestId);
                if (original && original.requestId === requestId && original.pending === true) {
                    if (remaining > 0) {
                        worldRenderTimer = Script.setTimeout(function () {
                            if (requestId !== lastWorldRenderRequest) { return; }
                            worldRenderTimer = null;
                            saveWorldRenderObservation(requestId, remaining - 1);
                        }, 50);
                        return;
                    }
                } else if (original && original.requestId === requestId) { value = original; }
            }
        } catch (_worldRenderReadError) { /* Missing acquisition is never a frame. */ }
        Test.saveObject(value, "world-render-observation.json");
    }
    var lastScriptSourceRequest = "";
    var lastScriptRootsRequest = "";
    var lastScriptWorkRequest = "";
    var scriptWorkTimer = null;
    function saveScriptWorkObservation(command, remaining) {
        if (command.commandId !== lastScriptWorkRequest) { return; }
        if (remaining === undefined) { remaining = 50; }
        var value = {schemaVersion:1,requestId:command.commandId,available:false};
        try {
            if (typeof Test.featureScriptWork === "function") {
                var original = Test.featureScriptWork(command);
                if (original && original.requestId === command.commandId && original.pending === true && remaining > 0) {
                    scriptWorkTimer = Script.setTimeout(function () {
                        if (command.commandId !== lastScriptWorkRequest) { return; }
                        scriptWorkTimer = null; saveScriptWorkObservation(command,remaining-1);
                    },50);
                    return;
                }
                if (original && original.requestId === command.commandId && original.pending !== true
                        && original.schemaVersion === 1 && original.source) { value = original; }
            }
        } catch (_scriptWorkError) { /* Missing owner-thread work is never an empty inventory. */ }
        Test.saveObject(value,"feature-script-work.json");
    }
    var lastAvatarReceiveRequest = "";
    var lastProcessPresenceRequest = "";
    var lastScriptFilesRequest = "";
    function saveScriptSourceObservation(requestId) {
        var value = {schemaVersion: 1, requestId: requestId, available: false};
        try {
            if (typeof Test.featureScriptObservation === "function") {
                var native = Test.featureScriptObservation(requestId);
                if (native && native.requestId === requestId) { value = native; }
            }
        } catch (_scriptSourceReadError) { /* Missing native source cannot qualify execution. */ }
        Test.saveObject(value, "feature-script-observation.json");
    }
    function saveOwnedRecordedPreviewRelease(command) {
        var value = {schemaVersion: 1, requestId: command.commandId, available: false};
        try {
            if (typeof Test.releaseOwnedFeatureRecordedVoiceEvidence === "function") {
                var native = Test.releaseOwnedFeatureRecordedVoiceEvidence(command);
                if (native && native.requestId === command.commandId) { value = native; }
            }
        } catch (_ownedPreviewReleaseError) { /* No cleanup or delivery fact is inferred. */ }
        Test.saveObject(value, "recorded-preview-observation.json");
    }
    function saveRecordedPreviewObservation(requestId, action) {
        var value = {schemaVersion: 1, requestId: requestId, available: false};
        try {
            var hook = action === "feature-recorded-audio-release" ? Test.releaseFeatureRecordedVoiceEvidence
                : action === "feature-recorded-audio-files" ? Test.featureRecordedVoiceFiles : Test.featureRecordedVoiceEvidence;
            if (typeof hook === "function") {
                var native = hook.call(Test, requestId);
                if (native && native.requestId === requestId) { value = native; }
            }
        } catch (_recordedPreviewReadError) { /* Missing source is never a feature result. */ }
        Test.saveObject(value, "recorded-preview-observation.json");
    }
    function validPrivateLoginInputCommand(command) {
        return command && command.schemaVersion === 1 && command.action === "feature-private-login-input"
            && typeof command.commandId === "string" && /^ios-[0-9a-f]{32}$/.test(command.commandId)
            && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId)
            && typeof command.inputId === "string" && /^[0-9a-f]{32}$/.test(command.inputId)
            && /^(inspect|reserve|deliver|retire)$/.test(String(command.operation))
            && objectKeysMatch(command,["schemaVersion","commandId","action","operation","runId","inputId"]);
    }
    function validAccountOriginCommand(command) {
        return command && command.schemaVersion === 1 && command.action === "feature-account-origin"
            && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
            && /^[0-9a-f]{32}$/.test(String(command.runId)) && /^[0-9a-f]{32}$/.test(String(command.instance))
            && /^[0-9a-f]{64}$/.test(String(command.ownerToken)) && /^(stage|observe|release|locate)$/.test(String(command.operation))
            && (command.operation !== "stage" || (typeof command.origin === "string" && command.origin.length <= 1024))
            && objectKeysMatch(command,command.operation === "stage"
                ? ["schemaVersion","commandId","action","operation","runId","ownerToken","instance","origin"]
                : ["schemaVersion","commandId","action","operation","runId","ownerToken","instance"]);
    }
    function validAccountProbeCommand(command) {
        return command && command.schemaVersion === 1 && command.action === "feature-account-probe"
            && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
            && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.requestId))
            && /^ios-/.test(command.commandId) === /^ios-/.test(command.requestId)
            && /^[0-9a-f]{32}$/.test(String(command.runId)) && /^[0-9a-f]{32}$/.test(String(command.ticket))
            && /^(read|release|inspect)$/.test(String(command.operation))
            && (command.operation === "read" ? command.commandId === command.requestId : command.commandId !== command.requestId)
            && objectKeysMatch(command,["schemaVersion","commandId","action","operation","requestId","runId","ticket"]);
    }
    function saveAccountProbe(command, remaining) {
        if (command.commandId !== lastAccountProbeCommand) { return; }
        if (remaining === undefined) { remaining = 50; }
        var value = {schemaVersion:1,requestId:command.requestId,commandId:command.commandId,available:false};
        try {
            if (typeof Test.featureAccountProbe === "function") {
                var original = Test.featureAccountProbe(command);
                if (original && original.requestId === command.requestId && original.pending === true
                        && command.operation === "read" && remaining > 0) {
                    accountProbeTimer = Script.setTimeout(function () {
                        if (command.commandId !== lastAccountProbeCommand) { return; }
                        accountProbeTimer = null; saveAccountProbe(command,remaining-1);
                    },50);
                    return;
                }
                if (original && original.commandId === command.commandId && original.requestId === command.requestId
                        && original.pending !== true && original.probeVersion === 1) { value = original; }
            }
        } catch (_accountProbeError) { /* A missing HTTP/native result cannot establish authority. */ }
        Test.saveObject(value,"feature-account-probe.json");
    }
    function saveNativeFeatureObservation(requestId, remaining) {
        if (requestId !== lastNativeFeatureRequest) { return; }
        if (remaining === undefined) { remaining = 50; }
        var value = {schemaVersion: 1, requestId: requestId, available: false};
        try {
            if (typeof Test.featureNativeObservation === "function") {
                var native = Test.featureNativeObservation(requestId);
                if (native && native.requestId === requestId && native.pending === true) {
                    if (remaining > 0) {
                        nativeFeatureTimer = Script.setTimeout(function () {
                            if (requestId !== lastNativeFeatureRequest) { return; }
                            nativeFeatureTimer = null;
                            saveNativeFeatureObservation(requestId, remaining - 1);
                        }, 50);
                        return;
                    }
                } else if (native && native.requestId === requestId) { value = native; }
            }
        } catch (_nativeFeatureReadError) { /* An unavailable native read is not success. */ }
        Test.saveObject(value, "feature-native-observation.json");
    }
    function saveNormalFeatureObservation(now, sequence, includeEntities, requestId) {
        var observation = {schemaVersion: 1, instance: normalFeatureInstance,
            sampleSequence: sequence, sampleEpochMs: now, complete: false, scripts: []};
        if (typeof requestId === "string") { observation.requestId = requestId; }
        try {
            var running = ScriptDiscoveryService.getRunning();
            if (Array.isArray(running) && running.length <= 128) {
                running.forEach(function (row) {
                    if (typeof row.url !== "string" || typeof row.path !== "string"
                            || !row.url.length || !row.path.length
                            || row.url.length > 4096 || row.path.length > 4096) {
                        throw new Error("invalid-native-script-row");
                    }
                    observation.scripts.push({url: row.url, path: row.path});
                });
                // Preserve the service's real order. The input adapter performs
                // the same explicit sorting as TabletRunningScripts.qml.
                observation.complete = true;
            }
        } catch (_normalFeatureError) {
            observation.scripts = [];
        }
        if (includeEntities === true) {
          observation.avatarEntities = [];
          observation.entitiesComplete = false;
          try {
            var ids = Entities.findEntities(MyAvatar.position, 64);
            if (!Array.isArray(ids) || ids.length > 4096) { throw new Error("entity-query-budget"); }
            var me = String(MyAvatar.sessionUUID).replace(/[{}-]/g, "").toLowerCase();
            var self = String(MyAvatar.SELF_ID).replace(/[{}-]/g, "").toLowerCase();
            ids.forEach(function (id) {
                var properties = Entities.getEntityProperties(id, ["name", "type", "entityHostType", "owningAvatarID"]);
                var owner = String(properties.owningAvatarID || "").replace(/[{}-]/g, "").toLowerCase();
                if (properties.entityHostType === "avatar" && owner.length === 32
                        && owner !== "00000000000000000000000000000000" && (owner === me || owner === self)) {
                    observation.avatarEntities.push({id: String(id), name: String(properties.name || ""),
                        type: String(properties.type)});
                }
            });
            if (observation.avatarEntities.length > 256) { throw new Error("owned-entity-budget"); }
            observation.entitiesComplete = true;
          } catch (_entityReadError) {
            observation.avatarEntities = [];
          }
        }
        Test.saveObject(observation, "normal-feature-observation.json");
    }
    var phoneTouchHistory = [];
    var orientationHistory = [];
    var verticalObservationPrevious = null;
    var verticalJumpActive = false;
    var verticalEvents = {
        jumpCount: 0,
        jumpCompletedCount: 0,
        lastJumpStartY: null,
        lastJumpPeakY: null,
        lastJumpLandingY: null,
        flightCount: 0,
        lastFlightStartY: null,
        lastFlightPeakY: null
    };
    var soundCommandRequest = null;
    // Network-loaded probes retain the fixture-relative fallback. A target
    // adapter's private probe copy can replace it through the narrow command
    // channel only after the fixture has accepted an exact sound command.
    var soundCommandUrl = Script.resolvePath("sound-command.json");
    var lastSoundControlCommandId = "";
    var soundResource = null;
    var soundInjector = null;
    var soundStopRequested = false;
    var soundState = {
        commandId: "",
        url: "",
        commandObserved: false,
        resourceReady: false,
        durationSeconds: 0.0,
        format: "unknown",
        injectorCreated: false,
        started: false,
        playing: false,
        finished: false,
        finishReason: "none"
    };
    var fixtureMarkers = ["OVERTE_E2E_COLLISION_WALL", "OVERTE_E2E_EAST",
        "OVERTE_E2E_FLOOR", "OVERTE_E2E_NORTH", "OVERTE_E2E_ORIGIN"];
    var interactionTargetName = "OVERTE_E2E_INTERACTABLE";
    var interactionPressCount = 0;
    var interactionLastEntityName = "";
    var interactionLastPointerId = null;
    // Read-only diagnostics of the real dispatcher rays. These observations
    // never create a pointer, deliver an event, or count as a test assertion.
    var interactionPointers = null;
    var interactionPointerHistory = [];
    var interactionPointerSequence = 0;
    var interactionPointerLastSampleMs = 0;
    var interactionPointerChannel = "Pico4-FarGrab-Depth";
    function observeDispatcherPointers(channel, message, sender, localOnly) {
        if (channel !== interactionPointerChannel || !localOnly) { return; }
        try {
            var config = JSON.parse(message);
            if (config.action === "configurePointers"
                    && typeof config.left === "number" && typeof config.right === "number") {
                interactionPointers = [config.left, config.right];
            }
        } catch (error) { /* Ignore unrelated worker messages. */ }
    }
    Messages.subscribe(interactionPointerChannel);
    Messages.messageReceived.connect(observeDispatcherPointers);
    var interactionPointerDiscovery = Script.setInterval(function () {
        if (interactionPointers === null) {
            Messages.sendLocalMessage(interactionPointerChannel, JSON.stringify({ action: "ready" }));
        }
    }, 1000);
    function observeDispatcherRay(now) {
        if (interactionPointers === null || now - interactionPointerLastSampleMs < 100) { return; }
        var trigger = Controller.getValue(Controller.Standard.RT);
        if (trigger <= 0.01) { return; }
        interactionPointerLastSampleMs = now;
        try {
            interactionPointerSequence += 1;
            var pick = Pointers.getPrevPickResult(interactionPointers[1]);
            interactionPointerHistory.push({
                sampleSequence: interactionPointerSequence, sampleEpochMs: now,
                trigger: trigger, triggerClick: Controller.getValue(Controller.Standard.RTClick),
                pose: controllerPose(Controller.Standard.RightHand),
                pick: pick, avatarPosition: MyAvatar.position,
                sensorToWorld: MyAvatar.getSensorToWorldMatrix(),
                pressCount: interactionPressCount
            });
            if (interactionPointerHistory.length > 64) { interactionPointerHistory.shift(); }
            Test.saveObject({ schemaVersion: 1, source: "actual-dispatcher-ray",
                processId: androidControlProcessId, updatedEpochMs: now,
                samples: interactionPointerHistory }, "interaction-ray-observation.json");
        } catch (error) { /* Diagnostic availability does not change test results. */ }
    }
    var peerTrackingId = "";
    var peerPreviousPosition = null;
    var peerObservationCount = 0;
    var peerMovementDistance = 0.0;
    var renderFrameCount = 0;
    var renderLastFrameEpochMs = 0;
    var renderStats = Render.getConfig("Stats");
    var domainMarkers = ["OVERTE_E2E_DOMAIN_FLOOR", "OVERTE_E2E_DOMAIN_NORTH",
        "OVERTE_E2E_DOMAIN_EAST", "OVERTE_E2E_DOMAIN_ORIGIN"];
    var expectedSpawn = { x: 0.0, y: 0.0, z: 4.0 };

    function controlledTabletOpen() {
        return Boolean(tablet.tabletShown || HMD.showTablet);
    }

    function addControlledInputRoute(name, action) {
        controlledInputMapping.from(function () {
            // A physical desktop key is consumed by the focused tablet before
            // it can reach world locomotion. Preserve that routing boundary
            // for semantic in-client input while leaving ContextMenu active.
            return controlledKey === name
                && (name === "tablet" || !controlledTabletOpen()) ? 1.0 : 0.0;
        }).to(action);
    }

    addControlledInputRoute("backward", Controller.Actions.Backward);
    addControlledInputRoute("down", Controller.Actions.Down);
    addControlledInputRoute("forward", Controller.Actions.Forward);
    addControlledInputRoute("jump", Controller.Actions.Up);
    addControlledInputRoute("left", Controller.Actions.StrafeLeft);
    addControlledInputRoute("right", Controller.Actions.StrafeRight);
    addControlledInputRoute("tablet", Controller.Actions.ContextMenu);
    Controller.enableMapping(controlledInputMappingName);

    function vector(value) {
        return { x: Number(value.x), y: Number(value.y), z: Number(value.z) };
    }

    function pendingVector(value) {
        if (!value || !isFinite(Number(value.x)) || !isFinite(Number(value.y))
                || !isFinite(Number(value.z))) {
            return { x: 0.0, y: 0.0, z: 0.0 };
        }
        return vector(value);
    }

    function observeRenderedFrame() {
        renderFrameCount += 1;
        renderLastFrameEpochMs = Date.now();
    }

    if (renderStats && renderStats.newStats) {
        renderStats.newStats.connect(observeRenderedFrame);
    }

    function controlledSharedObservation(properties) {
        if (properties.name !== "OVERTE_E2E_SHARED_COLOR") { return null; }
        var state;
        try { state = JSON.parse(String(properties.userData)); } catch (error) { return null; }
        var author = String(properties.lastEditedBy).replace(/[{}]/g, "").toLowerCase();
        if (!state || state.contract !== "overte-e2e-collaboration-v1"
                || state.actorId !== "OVERTE_E2E_ACTOR_FIXTURE"
                || typeof state.revision !== "number" || !isFinite(state.revision)
                || state.revision < 0 || state.revision > 9007199254740991 || state.revision % 1 !== 0
                || (state.value !== "blue" && state.value !== "orange")
                || !/^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(author)
                || author === "00000000-0000-0000-0000-000000000000") { return null; }
        var color = state.value === "blue"
            ? { red: 40, green: 120, blue: 255 } : { red: 255, green: 150, blue: 40 };
        if (!properties.color || properties.color.red !== color.red
                || properties.color.green !== color.green || properties.color.blue !== color.blue) { return null; }
        return { schemaVersion: 1, entityName: String(properties.name), actorId: state.actorId,
            revision: state.revision, value: state.value, actorSessionId: author };
    }

    function controlledPeer() {
        var identifiers = AvatarList.getAvatarIdentifiers();
        var candidates = [];
        var peerDiagnostic = { epochMs: Date.now(), avatarCount: identifiers.length,
            avatars: [] };
        var index;
        for (index = 0; index < identifiers.length; index += 1) {
            if (String(identifiers[index]) === String(MyAvatar.sessionUUID)) {
                continue;
            }
            var avatar = AvatarList.getAvatar(identifiers[index]);
            if (androidControlAvailable) {
                peerDiagnostic.avatars.push({
                    available: Boolean(avatar),
                    nameType: avatar ? typeof avatar.displayName : "unavailable",
                    named: Boolean(avatar && String(avatar.displayName)),
                    controlledPeer: Boolean(avatar && String(avatar.displayName) === "OVERTE_E2E_PEER"),
                    voicePeer: Boolean(avatar && String(avatar.displayName) === "OVERTE_VOICE_TEST_PC"),
                    position: avatar ? vector(avatar.position) : null
                });
            }
            if (avatar && String(avatar.displayName) === "OVERTE_E2E_PEER") {
                candidates.push(avatar);
            }
        }
        if (androidControlAvailable) {
            Test.saveObject(peerDiagnostic, "phone-peer-observation.json");
        }
        if (candidates.length !== 1) {
            return {
                present: false, sessionId: "", displayName: "", position: null,
                observationCount: peerObservationCount,
                movementDistanceMeters: peerMovementDistance
            };
        }
        var peer = candidates[0];
        var sessionId = String(peer.sessionUUID);
        var position = vector(peer.position);
        if (peerTrackingId !== sessionId) {
            peerTrackingId = sessionId;
            peerPreviousPosition = null;
            peerObservationCount = 0;
            peerMovementDistance = 0.0;
        }
        if (peerPreviousPosition !== null) {
            var dx = position.x - peerPreviousPosition.x;
            var dy = position.y - peerPreviousPosition.y;
            var dz = position.z - peerPreviousPosition.z;
            peerMovementDistance += Math.sqrt(dx * dx + dy * dy + dz * dz);
        }
        peerPreviousPosition = position;
        peerObservationCount += 1;
        return {
            present: true,
            sessionId: sessionId,
            displayName: "OVERTE_E2E_PEER",
            position: position,
            observationCount: peerObservationCount,
            movementDistanceMeters: peerMovementDistance
        };
    }

    function observePrimaryInteraction(entityID, event) {
        var properties = Entities.getEntityProperties(entityID, ["name"]);
        if (String(properties.name) !== interactionTargetName) {
            return;
        }
        interactionPressCount += 1;
        interactionLastEntityName = interactionTargetName;
        interactionLastPointerId = event && isFinite(Number(event.id))
            ? Math.max(0, Math.floor(Number(event.id))) : null;
    }

    Entities.mousePressOnEntity.connect(observePrimaryInteraction);

    function primaryViewObservation(now, sequence) {
        var result = { schemaVersion: 1, sampleEpochMs: now, sampleSequence: sequence,
            commandId: primaryViewCommandId, valid: false, entityName: "", point: null };
        if (primaryOriginalCameraMode === null || String(Camera.mode) !== "first person") {
            return result;
        }
        var ids = Entities.findEntities(MyAvatar.position, 1000.0);
        var candidates = [];
        ids.forEach(function (id) {
            var properties = Entities.getEntityProperties(id, ["name", "position"]);
            if (properties.name === interactionTargetName) { candidates.push({id:id, properties:properties}); }
        });
        if (candidates.length !== 1) { return result; }
        var frustum = Camera.frustum;
        var view = Mat4.inverse(Mat4.createFromRotAndTrans(frustum.orientation, frustum.position));
        var cameraPoint = Mat4.transformPoint(view, candidates[0].properties.position);
        if (cameraPoint.z >= 0) { return result; }
        var clip = Mat4.transformPoint(frustum.projection, cameraPoint);
        var u = (Number(clip.x) + 1) / 2;
        var v = (1 - Number(clip.y)) / 2;
        if (!isFinite(u) || !isFinite(v) || u <= 0.05 || u >= 0.95 || v <= 0.05 || v >= 0.95) {
            return result;
        }
        var ray = Camera.computePickRay(u * Window.innerWidth, v * Window.innerHeight);
        var hit = Entities.findRayIntersection(ray);
        if (!hit.intersects || String(hit.entityID) !== String(candidates[0].id)) { return result; }
        result.valid = true;
        result.entityName = String(candidates[0].properties.name);
        result.point = { x: u, y: v };
        return result;
    }

    function controllerPose(channel) {
        var pose = Controller.getPoseValue(channel);
        if (!pose || !pose.valid) {
            return { valid: false, translation: null, rotation: null };
        }
        return {
            valid: true,
            translation: vector(pose.translation),
            rotation: {
                x: Number(pose.rotation.x),
                y: Number(pose.rotation.y),
                z: Number(pose.rotation.z),
                w: Number(pose.rotation.w)
            }
        };
    }

    function openXrAxes(openXr) {
        if (openXr === undefined) {
            return null;
        }
        return {
            lx: Number(Controller.getValue(openXr.LX)),
            ly: Number(Controller.getValue(openXr.LY)),
            rx: Number(Controller.getValue(openXr.RX)),
            ry: Number(Controller.getValue(openXr.RY))
        };
    }

    function effectiveInputState() {
        var application = Controller.Hardware.Application;
        var right = Number(Controller.getValue(application.RightHandDominant)) > 0.5;
        var left = Number(Controller.getValue(application.LeftHandDominant)) > 0.5;
        return {
            dominantHand: right && !left ? "right" : (left && !right ? "left" : "unknown"),
            advancedMovementControls:
                Number(Controller.getValue(application.AdvancedMovement)) > 0.5
        };
    }

    function releaseAssetResource() {
        if (assetResource !== null) {
            assetResource.release();
            assetResource = null;
        }
        assetResourceUrl = "";
    }

    function resourceStateName(state) {
        if (state === Resource.State.QUEUED) {
            return "queued";
        }
        if (state === Resource.State.LOADING) {
            return "loading";
        }
        if (state === Resource.State.LOADED) {
            return "loaded";
        }
        if (state === Resource.State.FINISHED) {
            return "finished";
        }
        return "failed";
    }

    function appendAssetCandidate(candidates, id) {
        if (id === null || id === undefined) {
            return;
        }
        var index;
        for (index = 0; index < candidates.length; index += 1) {
            if (String(candidates[index]) === String(id)) {
                return;
            }
        }
        var identity = Entities.getEntityProperties(id, ["name"]);
        if (String(identity.name).indexOf("OVERTE_E2E_ASSET_LOAD") === 0) {
            candidates.push(id);
        }
    }

    function observeAsset(ids) {
        var candidates = [];
        appendAssetCandidate(candidates, androidAssetEntityId);
        appendAssetCandidate(candidates, controlledAssetEntity);
        var index;
        for (index = 0; index < ids.length; index += 1) {
            appendAssetCandidate(candidates, ids[index]);
        }
        if (candidates.length !== 1) {
            releaseAssetResource();
            return null;
        }
        var id = candidates[0];
        var properties = Entities.getEntityProperties(id, [
            "name", "type", "imageURL", "userData", "dimensions", "naturalDimensions"
        ]);
        var metadata;
        try {
            metadata = JSON.parse(String(properties.userData));
        } catch (error) {
            releaseAssetResource();
            return null;
        }
        var assetId = metadata && metadata.overteE2EAssetId;
        var imageURL = String(properties.imageURL);
        if (typeof assetId !== "string" || assetId.length === 0 || imageURL.length === 0) {
            releaseAssetResource();
            return null;
        }
        if (!properties.naturalDimensions) {
            return null;
        }
        if (assetResource === null || assetResourceUrl !== imageURL) {
            releaseAssetResource();
            assetResourceUrl = imageURL;
            assetResource = TextureCache.prefetch(imageURL);
        }
        return {
            assetId: assetId,
            resource: {
                url: String(assetResource.url),
                state: resourceStateName(assetResource.state)
            },
            entity: {
                id: String(id),
                name: String(properties.name),
                type: String(properties.type),
                imageURL: imageURL,
                naturalDimensions: pendingVector(properties.naturalDimensions)
            }
        };
    }

    function soundFormat(url) {
        return String(url).split("?", 1)[0].toLowerCase().slice(-4) === ".wav"
            ? "wav" : "unknown";
    }

    function startSound(command) {
        if (soundInjector && soundInjector.playing) {
            soundInjector.stop();
        }
        soundResource = null;
        soundInjector = null;
        soundStopRequested = false;
        soundState = {
            commandId: String(command.commandId),
            url: String(command.soundUrl),
            commandObserved: true,
            resourceReady: false,
            durationSeconds: 0.0,
            format: soundFormat(command.soundUrl),
            injectorCreated: false,
            started: false,
            playing: false,
            finished: false,
            finishReason: "none"
        };
        soundResource = SoundCache.getSound(soundState.url);

        function playReadySound() {
            if (!soundResource || soundState.commandId !== String(command.commandId)) {
                return;
            }
            soundState.resourceReady = Boolean(soundResource.downloaded);
            soundState.durationSeconds = Number(soundResource.duration);
            if (!soundState.resourceReady || soundState.durationSeconds <= 0.0) {
                return;
            }
            soundInjector = Audio.playSound(soundResource, {
                localOnly: true,
                volume: 0.1
            });
            soundState.injectorCreated = Boolean(soundInjector);
            if (soundInjector) {
                soundInjector.finished.connect(function () {
                    soundState.playing = false;
                    soundState.finished = true;
                    soundState.finishReason = soundStopRequested ? "stopped" : "natural";
                });
            }
        }

        if (soundResource.downloaded) {
            playReadySound();
        } else {
            soundResource.ready.connect(playReadySound);
        }
    }

    function applySoundCommand(command) {
        if (!command || command.schemaVersion !== 1 || !command.commandId
                || command.commandId === lastSoundControlCommandId) {
            return;
        }
        lastSoundControlCommandId = String(command.commandId);
        if (command.action === "play" && command.soundUrl) {
            startSound(command);
        } else if (command.action === "stop" && soundInjector) {
            soundStopRequested = true;
            soundInjector.stop();
        }
    }

    function safeErrorText(error) {
        return String(error && error.message ? error.message : error)
            .replace(/[\r\n]+/g, " ").slice(0, 160);
    }

    function objectKeysMatch(value, expected) {
        if (!value || typeof value !== "object") {
            return false;
        }
        return Object.keys(value).sort().join("|") === expected.slice().sort().join("|");
    }

    function httpUrl(value) {
        return typeof value === "string"
            && /^https?:\/\/(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]+)?(?:[/?#]|$)/.test(value);
    }

    function clientCommandEndpoint() {
        if (httpUrl(clientCommandFallbackUrl)) {
            return clientCommandFallbackUrl;
        }
        var currentAddress = String(location.href);
        var origin = /^(https?:\/\/(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::[0-9]+)?)(?:[/?#]|$)/
            .exec(currentAddress);
        return origin ? origin[1] + "/e2e-client-command.json" : "";
    }

    function controlledSceneLocation(value) {
        var queryStart = value.indexOf("?");
        if (queryStart === -1) {
            return "";
        }
        var fragmentStart = value.indexOf("#", queryStart);
        var query = value.slice(queryStart + 1,
            fragmentStart === -1 ? value.length : fragmentStart);
        var parts = query.split("&");
        var index;
        for (index = 0; index < parts.length; index += 1) {
            var separator = parts[index].indexOf("=");
            if (separator === -1) {
                continue;
            }
            var name;
            var path;
            try {
                name = decodeURIComponent(parts[index].slice(0, separator).replace(/\+/g, "%20"));
                path = decodeURIComponent(parts[index].slice(separator + 1).replace(/\+/g, "%20"));
            } catch (error) {
                return "";
            }
            if (name !== "location") {
                continue;
            }
            var sections = path.split("/");
            if (sections.length !== 3 || sections[0] !== "") {
                return "";
            }
            var position = sections[1].split(",");
            var orientation = sections[2].split(",");
            if (position.length !== 3 || orientation.length !== 4) {
                return "";
            }
            var components = position.concat(orientation);
            var component;
            for (component = 0; component < components.length; component += 1) {
                if (!/^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?$/.test(components[component])
                        || !isFinite(Number(components[component]))
                        || Math.abs(Number(components[component]))
                        > (component < 3 ? 100000 : 1.01)) {
                    return "";
                }
            }
            return path;
        }
        return "";
    }

    function resetSceneObservation() {
        stableEntitySamples = 0;
        previousEntityCount = -1;
        stableAvatarSamples = 0;
        previousAvatarPosition = null;
        sceneReady = false;
        // Reloading the same serverless URL does not change the domain key,
        // but Window.location can leave the avatar in the temporary flight
        // state used while applying its viewpoint. Re-arm the same bounded
        // normalization used at initial startup before declaring readiness.
        flightNormalizationAllowed = true;
        flightNormalizationStableSamples = 0;
        orientationHistory = [];
    }

    function reloadControlledScene(commandId) {
        var baseAddress = addressWithoutReloadCommand(androidControlAvailable
            ? androidFixtureUrl : location.href);
        var separator = baseAddress.indexOf("?") === -1 ? "?" : "&";
        resetSceneObservation();
        lastSceneCommandId = String(commandId);
        Window.location = baseAddress + separator + "overteE2EReloadCommandId="
            + encodeURIComponent(String(commandId));
    }

    function avatarAtExpectedSpawn() {
        var position = MyAvatar.position;
        var deltaX = Number(position.x) - expectedSpawn.x;
        var deltaZ = Number(position.z) - expectedSpawn.z;
        return deltaX * deltaX + deltaZ * deltaZ <= 1.0;
    }

    function applySceneLocation(commandId, scenePath) {
        if (scenePath !== "" && lastClientCommandId === commandId && !sceneReady
                && !avatarAtExpectedSpawn()) {
            resetSceneObservation();
            Window.location = scenePath;
        }
    }

    function controlledKeySpec(name) {
        var keys = {
            backward: true,
            down: true,
            forward: true,
            jump: true,
            left: true,
            right: true,
            tablet: true
        };
        return Object.prototype.hasOwnProperty.call(keys, name) ? String(name) : null;
    }

    function releaseControlledKey(commandId) {
        if (controlledKey !== null && controlledKeyCommandId === commandId) {
            controlledKey = null;
            controlledKeyCommandId = "";
        }
    }

    function applyControlledKey(command) {
        var key = controlledKeySpec(command.key);
        var durationMs = Number(command.durationMs);
        if (key === null || typeof command.durationMs !== "number"
                || !isFinite(durationMs) || Math.floor(durationMs) !== durationMs
                || durationMs < 50 || durationMs > 10000) {
            return false;
        }
        releaseControlledKey(controlledKeyCommandId);
        controlledKey = key;
        controlledKeyCommandId = String(command.commandId);
        Script.setTimeout(function () {
            releaseControlledKey(String(command.commandId));
        }, durationMs);
        return true;
    }

    var voiceOriginal = null;
    var voiceWatchdog = null;
    var voiceLocalEcho = false;
    var voiceServerEcho = false;
    function restoreVoice() {
        if (typeof Test.voiceTest === "function") {
            Test.voiceTest({ schemaVersion: 1, commandId: "voice-watchdog-reset", action: "reset" });
            Test.saveObject({ schemaVersion: 1, commandId: "voice-watchdog-reset", ok: true }, "voice-result.json");
        }
        if (voiceOriginal) {
            Object.keys(voiceOriginal).forEach(function (key) { Audio[key] = voiceOriginal[key]; });
            voiceOriginal = null;
            Audio.setLocalEcho(voiceLocalEcho);
            Audio.setServerEcho(voiceServerEcho);
        }
        if (voiceWatchdog !== null) { Script.clearTimeout(voiceWatchdog); voiceWatchdog = null; }
    }
    function applyVoice(command) {
        if (!command || command.schemaVersion !== 1
                || !objectKeysMatch(command, ["schemaVersion", "commandId", "action", "request"])
                || command.action !== "voice-test" || !command.commandId
                || command.commandId === lastClientCommandId) { return false; }
        lastClientCommandId = String(command.commandId);
        var request = command.request;
        var result = { schemaVersion: 1, commandId: command.commandId, ok: false,
            error: "voice-test-not-enabled" };
        if (typeof Test.voiceTest === "function" && request && request.commandId === command.commandId) {
            if (request.action === "prepare") {
                if (voiceOriginal !== null) {
                    result.error = "voice-session-busy";
                    Test.saveObject(result, "voice-result.json");
                    return true;
                }
                result = Test.voiceTest(request);
                if (result.ok) {
                    voiceOriginal = {};
                    voiceLocalEcho = Boolean(Audio.getLocalEcho());
                    voiceServerEcho = Boolean(Audio.getServerEcho());
                    ["muted", "pushToTalk", "noiseReduction", "acousticEchoCancellation", "avatarGain",
                        "serverInjectorGain", "localInjectorGain", "systemInjectorGain"].forEach(function (key) {
                        voiceOriginal[key] = Audio[key];
                    });
                    Audio.muted = true;
                    Audio.pushToTalk = false;
                    Audio.noiseReduction = false;
                    Audio.acousticEchoCancellation = false;
                    Audio.avatarGain = 0;
                    Audio.serverInjectorGain = -96;
                    Audio.localInjectorGain = -96;
                    Audio.systemInjectorGain = -96;
                    Audio.setLocalEcho(false);
                    Audio.setServerEcho(false);
                    // Keep an already established voice domain intact. Looking
                    // it up again can enter the loading interstitial and pause
                    // the native source after the test clock has been prepared.
                    var domainPattern = new RegExp("^hifi://([^/?#]+)(?:[/?#]|$)", "i");
                    var currentDomain = domainPattern.exec(String(location.href));
                    var requestedDomain = domainPattern.exec(String(request.domainUrl));
                    if (!location.isConnected || !currentDomain || !requestedDomain
                            || currentDomain[1].toLowerCase() !== requestedDomain[1].toLowerCase()) {
                        location.handleLookupString(request.domainUrl);
                    }
                }
            } else if (request.action === "status") {
                // Read the actual native audio state without preparing a voice
                // session or changing microphone, mute, echo or domain state.
                result = Test.voiceTest(request);
            } else if (request.action === "reset") {
                restoreVoice();
                result = Test.voiceTest(request);
            } else if (voiceOriginal !== null) {
                if (request.action === "send") { Audio.muted = request.muted; }
                result = Test.voiceTest(request);
            } else { result.error = "voice-session-unprepared"; }
            if (voiceOriginal !== null) {
                if (voiceWatchdog !== null) { Script.clearTimeout(voiceWatchdog); }
                voiceWatchdog = Script.setTimeout(restoreVoice, 120000);
            }
        }
        result.sampleEpochMs = Date.now();
        result.position = MyAvatar.position;
        result.connected = Boolean(location.isConnected);
        result.domainId = String(location.domainID);
        result.version = String(About.buildVersion);
        result.muted = Boolean(Audio.muted);
        result.localEcho = Boolean(Audio.getLocalEcho());
        result.serverEcho = Boolean(Audio.getServerEcho());
        Test.saveObject(result, "voice-result.json");
        return true;
    }

    function saveClientCommandReceipt(now) {
        if (lastClientCommandId === "") { return; }
        var receipt = { schemaVersion: 1, commandId: lastClientCommandId,
            sampleEpochMs: now };
        if (/^ios-[0-9a-f]{32}$/.test(lastClientCommandId)) {
            // AFC readers must never race periodic truncation of their receipt.
            // Each actual native command owns one immutable private document.
            if (savedNativeClientReceiptIds[lastClientCommandId]) { return; }
            Test.saveObject(receipt, "ios-client-command-"
                + lastClientCommandId.slice(4) + "-result.json");
            savedNativeClientReceiptIds[lastClientCommandId] = true;
        } else {
            Test.saveObject(receipt, "client-command-result.json");
        }
    }

    function applyClientCommand(command) {
        if (command && command.action === "ios-bundle-observe") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string" && command.commandId.length === 36
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId)
                    && objectKeysMatch(command,["schemaVersion","commandId","action"])
                    && command.commandId !== lastIOSBundleDone) {
                var installedBundle={bundleObservationVersion:1,commandId:command.commandId,available:false};
                try {
                    if (typeof Test.featureIOSBundleObservation === "function") {
                        var originalBundle=Test.featureIOSBundleObservation(command);
                        if (originalBundle && originalBundle.commandId === command.commandId) { installedBundle=originalBundle; }
                    }
                } catch (_bundleReadError) { /* No paths or archive expectations are exported. */ }
                if (installedBundle.status !== "pending") { lastIOSBundleDone=command.commandId; }
                Test.saveObject(installedBundle,"ios-installed-bundle-observation.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-scene-inventory") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (command.commandId === lastIOSSceneInventoryRequest) { return; }
                lastIOSSceneInventoryRequest=command.commandId;
                var sceneInventory={iosSceneInventoryVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSceneInventory === "function") {
                        var originalInventory=Test.featureIOSSceneInventory(command);
                        if (originalInventory && originalInventory.requestId === command.commandId) { sceneInventory=originalInventory; }
                    }
                } catch (_sceneInventoryError) { /* Unknown/partial global scope is never empty absence. */ }
                Test.saveObject(sceneInventory,"feature-ios-scene-inventory.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-audio-passive-capture") {
            var passiveFields=["schemaVersion","commandId","action","operation","instance","runId","role","leaseId","startCommandId"];
            if (command.operation==="start") {passiveFields.push("seconds");}
            if (command.operation==="read") {passiveFields.push("kind","offset","bytes");}
            var passiveInteger=function(value,low,high) {return typeof value==="number" && isFinite(value)
                && Math.floor(value)===value && value>=low && value<=high;};
            if (command.schemaVersion===1 && command.role==="actor" && typeof command.commandId==="string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.instance==="string" && /^[0-9a-f]{32}$/.test(command.instance) && command.instance.length===32
                    && typeof command.runId==="string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length===32
                    && typeof command.leaseId==="string" && /^[0-9a-f]{32}$/.test(command.leaseId) && command.leaseId.length===32
                    && /^(start|observe|capture|read|release|recover|files)$/.test(String(command.operation))
                    && typeof command.startCommandId==="string" && /^ios-[0-9a-f]{32}$/.test(command.startCommandId)
                    && command.startCommandId.length===36
                    && (command.operation!=="start" || (passiveInteger(command.seconds,6,10) && command.startCommandId===command.commandId))
                    && (command.operation!=="read" || (/^(intent|capture|wav)$/.test(String(command.kind))
                        && passiveInteger(command.offset,0,2097152) && passiveInteger(command.bytes,1,4096)
                        && command.offset+command.bytes<=2097152)) && objectKeysMatch(command,passiveFields)) {
                if (passiveAudioRequests[command.commandId] || passiveAudioRequestCount>=65536) {return;}
                passiveAudioRequests[command.commandId]=true;passiveAudioRequestCount+=1;
                var passiveOriginal={passiveAcousticReplyVersion:1,commandId:command.commandId,available:false};
                try {
                    if (typeof Test.featureIOSAudioPassiveCapture==="function") {
                        var passiveReply=Test.featureIOSAudioPassiveCapture(command);
                        if (passiveReply && passiveReply.commandId===command.commandId) {passiveOriginal=passiveReply;}
                    }
                } catch (_passiveAudioError) { /* Missing original ownership is never empty memory or acoustic success. */ }
                Test.saveObject(passiveOriginal,"feature-ios-audio-passive-capture.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-audio-session") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var audioSessionOriginal={iosAudioSessionVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAudioSession==="function") {
                        var audioSessionReply=Test.featureIOSAudioSession(command);
                        if (audioSessionReply && audioSessionReply.requestId===command.commandId) {audioSessionOriginal=audioSessionReply;}
                    }
                } catch (_audioSessionError) { /* Missing OS authorization is never inferred from a requested state. */ }
                Test.saveObject(audioSessionOriginal,"feature-ios-audio-session.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-audio-settings") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var audioSettingsOriginal={iosAudioSettingsVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAudioSettings==="function") {
                        var audioSettingsReply=Test.featureIOSAudioSettings(command);
                        if (audioSettingsReply && audioSettingsReply.requestId===command.commandId) {audioSettingsOriginal=audioSettingsReply;}
                    }
                } catch (_audioSettingsError) { /* Missing typed settings is never inferred from a requested state. */ }
                Test.saveObject(audioSettingsOriginal,"feature-ios-audio-settings.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-keyboard") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var keyboardOriginal={iosKeyboardVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSKeyboard==="function") {
                        var keyboardReply=Test.featureIOSKeyboard(command);
                        if (keyboardReply && keyboardReply.requestId===command.commandId) {keyboardOriginal=keyboardReply;}
                    }
                } catch (_keyboardError) { /* Original unavailable is never known keyboard absence. */ }
                Test.saveObject(keyboardOriginal,"feature-ios-keyboard.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-script-dialogs") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceScriptDialogs={iosScriptDialogVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSScriptDialogs === "function") {
                        var originalScriptDialogs=Test.featureIOSScriptDialogs(command);
                        if (originalScriptDialogs && originalScriptDialogs.requestId === command.commandId) { sourceScriptDialogs=originalScriptDialogs; }
                    }
                } catch (_ScriptDialogsError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceScriptDialogs,"feature-ios-script-dialogs.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-emote-world") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceEmoteWorld={iosEmoteWorldVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSEmoteWorld === "function") {
                        var originalEmoteWorld=Test.featureIOSEmoteWorld(command);
                        if (originalEmoteWorld && originalEmoteWorld.requestId === command.commandId) { sourceEmoteWorld=originalEmoteWorld; }
                    }
                } catch (_EmoteWorldError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceEmoteWorld,"feature-ios-emote-world.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-avatar-world") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceAvatarWorld={iosAvatarWorldVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAvatarWorld === "function") {
                        var originalAvatarWorld=Test.featureIOSAvatarWorld(command);
                        if (originalAvatarWorld && originalAvatarWorld.requestId === command.commandId) { sourceAvatarWorld=originalAvatarWorld; }
                    }
                } catch (_AvatarWorldError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceAvatarWorld,"feature-ios-avatar-world.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-avatar-inputs") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceAvatarInputs={iosNormalInputsVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAvatarInputs === "function") {
                        var originalAvatarInputs=Test.featureIOSAvatarInputs(command);
                        if (originalAvatarInputs && originalAvatarInputs.requestId === command.commandId) { sourceAvatarInputs=originalAvatarInputs; }
                    }
                } catch (_AvatarInputsError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceAvatarInputs,"feature-ios-avatar-inputs.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-avatar-social-http") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceAvatarSocialHttp={iosAvatarSocialHttpVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAvatarSocialHttp === "function") {
                        var originalAvatarSocialHttp=Test.featureIOSAvatarSocialHttp(command);
                        if (originalAvatarSocialHttp && originalAvatarSocialHttp.requestId === command.commandId) { sourceAvatarSocialHttp=originalAvatarSocialHttp; }
                    }
                } catch (_AvatarSocialHttpError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceAvatarSocialHttp,"feature-ios-avatar-social-http.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-preflight-http") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceSnapshotPreflightHttp={iosSnapshotPreflightHttpVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotPreflightHttp === "function") {
                        var originalSnapshotPreflightHttp=Test.featureIOSSnapshotPreflightHttp(command);
                        if (originalSnapshotPreflightHttp && originalSnapshotPreflightHttp.requestId === command.commandId) { sourceSnapshotPreflightHttp=originalSnapshotPreflightHttp; }
                    }
                } catch (_SnapshotPreflightHttpError) { /* Original uncertainty remains owned; no second invocation on poll. */ }
                Test.saveObject(sourceSnapshotPreflightHttp,"feature-ios-snapshot-preflight-http.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-combined-preflight-http") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceSnapshotCombinedPreflightHttp={iosSnapshotCombinedPreflightHttpVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotCombinedPreflightHttp === "function") {
                        var originalSnapshotCombinedPreflightHttp=Test.featureIOSSnapshotCombinedPreflightHttp(command);
                        if (originalSnapshotCombinedPreflightHttp && originalSnapshotCombinedPreflightHttp.requestId === command.commandId) { sourceSnapshotCombinedPreflightHttp=originalSnapshotCombinedPreflightHttp; }
                    }
                } catch (_SnapshotCombinedPreflightHttpError) { /* Original uncertainty remains owned; no second invocation on poll. */ }
                Test.saveObject(sourceSnapshotCombinedPreflightHttp,"feature-ios-snapshot-combined-preflight-http.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-causal-dispatch") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceSnapshotCausalDispatch={iosSnapshotCausalDispatchVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotCausalDispatch === "function") {
                        var originalSnapshotCausalDispatch=Test.featureIOSSnapshotCausalDispatch(command);
                        if (originalSnapshotCausalDispatch && originalSnapshotCausalDispatch.requestId === command.commandId) { sourceSnapshotCausalDispatch=originalSnapshotCausalDispatch; }
                    }
                } catch (_SnapshotCausalDispatchError) { /* Original uncertainty remains owned; no second invocation on poll. */ }
                Test.saveObject(sourceSnapshotCausalDispatch,"feature-ios-snapshot-causal-dispatch.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-combined-work") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceSnapshotCombinedWork={iosSnapshotCombinedWorkVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotCombinedWork === "function") {
                        var originalSnapshotCombinedWork=Test.featureIOSSnapshotCombinedWork(command);
                        if (originalSnapshotCombinedWork && originalSnapshotCombinedWork.requestId === command.commandId) { sourceSnapshotCombinedWork=originalSnapshotCombinedWork; }
                    }
                } catch (_SnapshotCombinedWorkError) { /* Preserve unknown original query responsibility. */ }
                Test.saveObject(sourceSnapshotCombinedWork,"feature-ios-snapshot-combined-work.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-chat-script-sources") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceChatScripts={iosChatScriptSourcesVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSChatScriptSources === "function") {
                        var originalChatScripts=Test.featureIOSChatScriptSources(command);
                        if (originalChatScripts && originalChatScripts.requestId === command.commandId) { sourceChatScripts=originalChatScripts; }
                    }
                } catch (_ChatScriptSourcesError) { /* Retain the unknown original read; no second invocation on poll. */ }
                Test.saveObject(sourceChatScripts,"feature-ios-chat-script-sources.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-chat-qml-sources") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceChatQml={iosChatQmlSourcesVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSChatQmlSources === "function") {
                        var originalChatQml=Test.featureIOSChatQmlSources(command);
                        if (originalChatQml && originalChatQml.requestId === command.commandId) { sourceChatQml=originalChatQml; }
                    }
                } catch (_ChatQmlSourcesError) { /* Keep unknown responsibility; no native reissue on poll. */ }
                Test.saveObject(sourceChatQml,"feature-ios-chat-qml-sources.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-people-model") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourcePeopleModel={iosPeopleModelVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSPeopleModel === "function") {
                        var originalPeopleModel=Test.featureIOSPeopleModel(command);
                        if (originalPeopleModel && originalPeopleModel.requestId === command.commandId) { sourcePeopleModel=originalPeopleModel; }
                    }
                } catch (_PeopleModelError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourcePeopleModel,"feature-ios-people-model.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-create-work") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceCreateWork={iosCreateWorkVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSCreateWork === "function") {
                        var originalCreateWork=Test.featureIOSCreateWork(command);
                        if (originalCreateWork && originalCreateWork.requestId === command.commandId) { sourceCreateWork=originalCreateWork; }
                    }
                } catch (_CreateWorkError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceCreateWork,"feature-ios-create-work.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-world-web-work") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceWorldWebWork={iosWorldWebWorkVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSWorldWebWork === "function") {
                        var originalWorldWebWork=Test.featureIOSWorldWebWork(command);
                        if (originalWorldWebWork && originalWorldWebWork.requestId === command.commandId) { sourceWorldWebWork=originalWorldWebWork; }
                    }
                } catch (_WorldWebWorkError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceWorldWebWork,"feature-ios-world-web-work.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-world-web-keys") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceWorldWebKeys={iosWorldWebKeysVersion:2,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSWorldWebKeys === "function") {
                        var originalWorldWebKeys=Test.featureIOSWorldWebKeys(command);
                        if (originalWorldWebKeys && originalWorldWebKeys.requestId === command.commandId) { sourceWorldWebKeys=originalWorldWebKeys; }
                    }
                } catch (_WorldWebKeysError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceWorldWebKeys,"feature-ios-world-web-keys.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-world-web-geometry") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceWorldWebGeometry={iosWorldWebGeometryVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSWorldWebGeometry === "function") {
                        var originalWorldWebGeometry=Test.featureIOSWorldWebGeometry(command);
                        if (originalWorldWebGeometry && originalWorldWebGeometry.requestId === command.commandId) { sourceWorldWebGeometry=originalWorldWebGeometry; }
                    }
                } catch (_WorldWebGeometryError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceWorldWebGeometry,"feature-ios-world-web-geometry.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-world-web-surfaces") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceWorldWebSurfaces={iosWorldWebSurfacesVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSWorldWebSurfaces === "function") {
                        var originalWorldWebSurfaces=Test.featureIOSWorldWebSurfaces(command);
                        if (originalWorldWebSurfaces && originalWorldWebSurfaces.requestId === command.commandId) { sourceWorldWebSurfaces=originalWorldWebSurfaces; }
                    }
                } catch (_WorldWebSurfacesError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceWorldWebSurfaces,"feature-ios-world-web-surfaces.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-avatar-scripts") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceAvatarScripts={iosAvatarScriptsVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAvatarScripts === "function") {
                        var originalAvatarScripts=Test.featureIOSAvatarScripts(command);
                        if (originalAvatarScripts && originalAvatarScripts.requestId === command.commandId) { sourceAvatarScripts=originalAvatarScripts; }
                    }
                } catch (_AvatarScriptsError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceAvatarScripts,"feature-ios-avatar-scripts.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-avatar-entities") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceAvatarEntities={iosAvatarEntitiesVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAvatarEntities === "function") {
                        var originalAvatarEntities=Test.featureIOSAvatarEntities(command);
                        if (originalAvatarEntities && originalAvatarEntities.requestId === command.commandId) { sourceAvatarEntities=originalAvatarEntities; }
                    }
                } catch (_AvatarEntitiesError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceAvatarEntities,"feature-ios-avatar-entities.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-pointer-state") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Consume even an unavailable/lost read once. A getter cannot
                // reset actual startup, contact or dispatch history.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourcePointerState={iosPointerStateVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSPointerState === "function") {
                        var originalPointerState=Test.featureIOSPointerState(command);
                        if (originalPointerState && originalPointerState.requestId === command.commandId) { sourcePointerState=originalPointerState; }
                    }
                } catch (_PointerStateError) { /* Keep unavailable and consumed. */ }
                Test.saveObject(sourcePointerState,"feature-ios-pointer-state.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-create-entities") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceCreateEntities={iosCreateEntitiesVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSCreateEntities === "function") {
                        var originalCreateEntities=Test.featureIOSCreateEntities(command);
                        if (originalCreateEntities && originalCreateEntities.requestId === command.commandId) { sourceCreateEntities=originalCreateEntities; }
                    }
                } catch (_CreateEntitiesError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceCreateEntities,"feature-ios-create-entities.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-avatar-renderers") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceAvatarRenderers={iosAvatarRenderersVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAvatarRenderers === "function") {
                        var originalAvatarRenderers=Test.featureIOSAvatarRenderers(command);
                        if (originalAvatarRenderers && originalAvatarRenderers.requestId === command.commandId) { sourceAvatarRenderers=originalAvatarRenderers; }
                    }
                } catch (_AvatarRenderersError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceAvatarRenderers,"feature-ios-avatar-renderers.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-assets-image-reader") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var assetsImageReader={iosAssetsImageReaderVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAssetsImageReader==="function") {
                        var actualAssetsImageReader=Test.featureIOSAssetsImageReader(command);
                        if (actualAssetsImageReader && actualAssetsImageReader.requestId===command.commandId) {assetsImageReader=actualAssetsImageReader;}
                    }
                } catch (_assetsImageReaderError) { /* Retain unavailable and consume the original nonce. */ }
                Test.saveObject(assetsImageReader,"feature-ios-assets-image-reader.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-assets-image-reader-queue") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var assetsImageReaderQueue={iosAssetsImageReaderQueueVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAssetsImageReaderQueue==="function") {
                        var actualAssetsImageReaderQueue=Test.featureIOSAssetsImageReaderQueue(command);
                        if (actualAssetsImageReaderQueue && actualAssetsImageReaderQueue.requestId===command.commandId) {assetsImageReaderQueue=actualAssetsImageReaderQueue;}
                    }
                } catch (_assetsImageReaderQueueError) { /* Retain unavailable and consume the original nonce. */ }
                Test.saveObject(assetsImageReaderQueue,"feature-ios-assets-image-reader-queue.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-assets-image-reader-processing") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var assetsImageReaderProcessing={iosAssetsImageReaderProcessingVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAssetsImageReaderProcessing==="function") {
                        var actualAssetsImageReaderProcessing=Test.featureIOSAssetsImageReaderProcessing(command);
                        if (actualAssetsImageReaderProcessing && actualAssetsImageReaderProcessing.requestId===command.commandId) {assetsImageReaderProcessing=actualAssetsImageReaderProcessing;}
                    }
                } catch (_assetsImageReaderProcessingError) { /* Retain unavailable and consume the original nonce. */ }
                Test.saveObject(assetsImageReaderProcessing,"feature-ios-assets-image-reader-processing.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-assets-image-reader-storage") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var assetsImageReaderStorage={iosAssetsImageReaderStorageVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAssetsImageReaderStorage==="function") {
                        var actualAssetsImageReaderStorage=Test.featureIOSAssetsImageReaderStorage(command);
                        if (actualAssetsImageReaderStorage && actualAssetsImageReaderStorage.requestId===command.commandId) {assetsImageReaderStorage=actualAssetsImageReaderStorage;}
                    }
                } catch (_assetsImageReaderStorageError) { /* Retain unavailable and consume the original nonce. */ }
                Test.saveObject(assetsImageReaderStorage,"feature-ios-assets-image-reader-storage.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-assets-image-reader-pool") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var assetsImageReaderPool={iosAssetsImageReaderPoolVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAssetsImageReaderPool==="function") {
                        var actualAssetsImageReaderPool=Test.featureIOSAssetsImageReaderPool(command);
                        if (actualAssetsImageReaderPool && actualAssetsImageReaderPool.requestId===command.commandId) {assetsImageReaderPool=actualAssetsImageReaderPool;}
                    }
                } catch (_assetsImageReaderPoolError) { /* Retain unavailable and consume the original nonce. */ }
                Test.saveObject(assetsImageReaderPool,"feature-ios-assets-image-reader-pool.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-assets-model-origin") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var assetModelOrigin={iosAssetsModelOriginVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAssetsModelOrigin==="function") {
                        var actualAssetModelOrigin=Test.featureIOSAssetsModelOrigin(command);
                        if (actualAssetModelOrigin && actualAssetModelOrigin.requestId===command.commandId) {assetModelOrigin=actualAssetModelOrigin;}
                    }
                } catch (_assetModelOriginError) { /* Preserve unavailable, with the original nonce consumed. */ }
                Test.saveObject(assetModelOrigin,"feature-ios-assets-model-origin.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-assets-model-renderers") {
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var assetModelRenderers={iosAssetsModelRenderersVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAssetsModelRenderers==="function") {
                        var actualAssetModelRenderers=Test.featureIOSAssetsModelRenderers(command);
                        if (actualAssetModelRenderers && actualAssetModelRenderers.requestId===command.commandId) {assetModelRenderers=actualAssetModelRenderers;}
                    }
                } catch (_assetModelRenderersError) { /* Preserve unavailable and the consumed original nonce. */ }
                Test.saveObject(assetModelRenderers,"feature-ios-assets-model-renderers.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-create-state") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceCreateState={iosCreateStateVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSCreateState === "function") {
                        var originalCreateState=Test.featureIOSCreateState(command);
                        if (originalCreateState && originalCreateState.requestId === command.commandId) { sourceCreateState=originalCreateState; }
                    }
                } catch (_CreateStateError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceCreateState,"feature-ios-create-state.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-assets-replies") {
            var assetsReplyChild=["mapping","info","raw-server"].indexOf(command.operation)!==-1;
            var assetsReplyExisting=["observe","retire"].indexOf(command.operation)!==-1;
            if (command.schemaVersion===1 && typeof command.commandId==="string" && /^ios-[a-f0-9]{32}$/.test(command.commandId) && command.commandId.length===36
                    && typeof command.runId==="string" && /^[a-f0-9]{32}$/.test(command.runId) && command.runId.length===32
                    && typeof command.ticket==="string" && /^[a-f0-9]{32}$/.test(command.ticket) && command.ticket.length===32
                    && typeof command.ownerToken==="string" && /^[a-f0-9]{64}$/.test(command.ownerToken) && command.ownerToken.length===64
                    && ["gltf-bundle/main.gltf","obj-bundle/main.obj","asset-stand.fbx"].indexOf(command.resource)!==-1
                    && ["original","renamed"].indexOf(command.namespace)!==-1
                    && ["inventory","mapping","info","raw-server","observe","retire"].indexOf(command.operation)!==-1
                    && (!assetsReplyChild || typeof command.sourceJob==="string" && /^ios-[a-f0-9]{32}$/.test(command.sourceJob)
                        && command.sourceJob.length===36 && typeof command.relativePath==="string" && command.relativePath.length<=128)
                    && (!assetsReplyExisting || typeof command.jobId==="string" && /^ios-[a-f0-9]{32}$/.test(command.jobId) && command.jobId.length===36)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","ticket","ownerToken","resource","namespace","operation"].concat(
                        assetsReplyChild?["sourceJob","relativePath"]:assetsReplyExisting?["jobId"]:[]))) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount>=4096) {return;}
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceAssetsReplies={iosAssetsRepliesVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAssetsReplies==="function") {
                        var originalAssetsReplies=Test.featureIOSAssetsReplies(command);
                        if (originalAssetsReplies && originalAssetsReplies.requestId===command.commandId) {sourceAssetsReplies=originalAssetsReplies;}
                    }
                } catch (_AssetsRepliesError) { /* Original unavailable remains consumed, including uncertain reads/retirement. */ }
                Test.saveObject(sourceAssetsReplies,"feature-ios-assets-replies.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-assets-files") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && typeof command.ticket === "string" && /^[0-9a-f]{32}$/.test(command.ticket) && command.ticket.length === 32
                    && typeof command.ownerToken === "string" && /^[0-9a-f]{64}$/.test(command.ownerToken) && command.ownerToken.length === 64
                    && ["gltf-bundle/main.gltf","obj-bundle/main.obj","asset-stand.fbx"].indexOf(command.resource) !== -1
                    && ["stage","observe","retire-primary","release"].indexOf(command.operation) !== -1
                    && (command.operation !== "stage" || command.files && typeof command.files === "object" && !Array.isArray(command.files))
                    && (["retire-primary","release"].indexOf(command.operation) === -1 || Array.isArray(command.originals))
                    && JSON.stringify(command).length <= 131072
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","ticket","ownerToken","resource","operation"].concat(
                        command.operation === "stage" ? ["files"] : ["retire-primary","release"].indexOf(command.operation) !== -1 ? ["originals"] : []))) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceAssetsFiles={iosAssetsFilesVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAssetsFiles === "function") {
                        var originalAssetsFiles=Test.featureIOSAssetsFiles(command);
                        if (originalAssetsFiles && originalAssetsFiles.requestId === command.commandId) { sourceAssetsFiles=originalAssetsFiles; }
                    }
                } catch (_AssetsFilesError) { /* Original unavailable remains consumed, including uncertain storage input. */ }
                Test.saveObject(sourceAssetsFiles,"feature-ios-assets-files.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-create-files") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && typeof command.ownerToken === "string" && /^[0-9a-f]{64}$/.test(command.ownerToken) && command.ownerToken.length === 64
                    && ["stage","locate","observe","release"].indexOf(command.operation) !== -1
                    && (command.operation !== "stage" || typeof command.inputBase64 === "string" && command.inputBase64.length <= 10924)
                    && (command.operation !== "release" || Array.isArray(command.originals) && command.originals.length === 2)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","ownerToken","operation"].concat(
                        command.operation === "stage" ? ["inputBase64"] : command.operation === "release" ? ["originals"] : []))) {
                // Keep every nonce consumed, including unavailable reads and
                // storage mutations with a lost return. No reissue on polling.
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var sourceCreateFiles={iosCreateFilesVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSCreateFiles === "function") {
                        var originalCreateFiles=Test.featureIOSCreateFiles(command);
                        if (originalCreateFiles && originalCreateFiles.requestId === command.commandId) { sourceCreateFiles=originalCreateFiles; }
                    }
                } catch (_CreateFilesError) { /* Retain unavailable; never retry an uncertain input. */ }
                Test.saveObject(sourceCreateFiles,"feature-ios-create-files.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-pending-inputs") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotPendingInputs={iosNormalInputsVersion:1,profile:"snapshot-pending",requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotPendingInputs === "function") {
                        var originalSnapshotPendingInputs=Test.featureIOSSnapshotPendingInputs(command);
                        if (originalSnapshotPendingInputs && originalSnapshotPendingInputs.requestId === command.commandId) { snapshotPendingInputs=originalSnapshotPendingInputs; }
                    }
                } catch (_snapshotPendingInputsError) { /* Preserve actual source unavailability; never reissue. */ }
                Test.saveObject(snapshotPendingInputs,"feature-ios-snapshot-pending-inputs.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-inputs") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotInputs={iosNormalInputsVersion:1,profile:"snapshot",requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotInputs === "function") {
                        var originalSnapshotInputs=Test.featureIOSSnapshotInputs(command);
                        if (originalSnapshotInputs && originalSnapshotInputs.requestId === command.commandId) { snapshotInputs=originalSnapshotInputs; }
                    }
                } catch (_snapshotInputsError) { /* Missing original reception cannot supply an input result. */ }
                Test.saveObject(snapshotInputs,"feature-ios-snapshot-inputs.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-lifecycle-inputs") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var lifecycleInputs={iosNormalInputsVersion:1,profile:"lifecycle",requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSLifecycleInputs === "function") {
                        var originalLifecycleInputs=Test.featureIOSLifecycleInputs(command);
                        if (originalLifecycleInputs && originalLifecycleInputs.requestId === command.commandId) { lifecycleInputs=originalLifecycleInputs; }
                    }
                } catch (_lifecycleInputsError) { /* Missing original reception cannot supply an input result. */ }
                Test.saveObject(lifecycleInputs,"feature-ios-lifecycle-inputs.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-lifecycle-navigation-inputs") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var lifecycleNavigation={iosNormalInputsVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSLifecycleNavigationInputs === "function") {
                        var originalLifecycleNavigation=Test.featureIOSLifecycleNavigationInputs(command);
                        if (originalLifecycleNavigation && originalLifecycleNavigation.requestId === command.commandId) { lifecycleNavigation=originalLifecycleNavigation; }
                    }
                } catch (_lifecycleNavigationError) { /* Missing original reception remains unknown. */ }
                Test.saveObject(lifecycleNavigation,"feature-ios-lifecycle-navigation-inputs.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-lifecycle-pending-commands") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var lifecyclePending={iosLifecyclePendingCommandsVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSLifecyclePendingCommands === "function") {
                        var originalLifecyclePending=Test.featureIOSLifecyclePendingCommands(command);
                        if (originalLifecyclePending && originalLifecyclePending.requestId === command.commandId) { lifecyclePending=originalLifecyclePending; }
                    }
                } catch (_lifecyclePendingError) { /* Missing original command remains unknown. */ }
                Test.saveObject(lifecyclePending,"feature-ios-lifecycle-pending-commands.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-lifecycle-world") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var lifecycleWorld={iosLifecycleWorldVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSLifecycleWorld === "function") {
                        var originalLifecycleWorld=Test.featureIOSLifecycleWorld(command);
                        if (originalLifecycleWorld && originalLifecycleWorld.requestId === command.commandId) { lifecycleWorld=originalLifecycleWorld; }
                    }
                } catch (_lifecycleWorldError) { /* Missing original reception cannot supply an input result. */ }
                Test.saveObject(lifecycleWorld,"feature-ios-lifecycle-world.json");
            }
            return;
        }
        if (command && (command.action === "feature-ios-snapshot-owned-files" || command.action === "feature-ios-snapshot-file-remove")) {
            var removeSnapshotFile=command.action === "feature-ios-snapshot-file-remove";
            var snapshotOwnedFields=["schemaVersion","commandId","action","runId"];
            if (removeSnapshotFile) { snapshotOwnedFields.push("fileId","manifestCommandId"); }
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && (!removeSnapshotFile || typeof command.fileId === "string" && /^[0-9a-f]{32}$/.test(command.fileId)
                        && command.fileId.length === 32 && typeof command.manifestCommandId === "string"
                        && /^ios-[0-9a-f]{32}$/.test(command.manifestCommandId) && command.manifestCommandId.length === 36)
                    && objectKeysMatch(command,snapshotOwnedFields)) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                // Consume before entering native code, including busy, thrown
                // or missing hooks. An uncertain removal is never resent.
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                if (removeSnapshotFile) {
                    var snapshotRemoveReceipt={iosSnapshotFileRemoveReceiptVersion:1,requestId:command.commandId,accepted:false};
                    try {
                        if (typeof Test.iosSnapshotRemoveFileRequest === "function") {
                            snapshotRemoveReceipt.accepted=Test.iosSnapshotRemoveFileRequest(command) === true;
                        }
                    } catch (_snapshotRemoveError) { /* Original job/source must resolve an uncertain queue outcome. */ }
                    Test.saveObject(snapshotRemoveReceipt,"feature-ios-snapshot-file-remove.json");
                } else {
                    var snapshotOwned={iosSnapshotOwnedFilesVersion:1,requestId:command.commandId,status:"unavailable"};
                    try {
                        if (typeof Test.featureIOSSnapshotOwnedFiles === "function") {
                            var originalSnapshotOwned=Test.featureIOSSnapshotOwnedFiles(command);
                            if (originalSnapshotOwned && originalSnapshotOwned.requestId === command.commandId) { snapshotOwned=originalSnapshotOwned; }
                        }
                    } catch (_snapshotOwnedError) { /* An unavailable original source cannot establish file ownership. */ }
                    Test.saveObject(snapshotOwned,"feature-ios-snapshot-owned-files.json");
                }
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-file-work") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotFiles={iosSnapshotFileWorkVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotFileWork === "function") {
                        var originalSnapshotFiles=Test.featureIOSSnapshotFileWork(command);
                        if (originalSnapshotFiles && originalSnapshotFiles.requestId === command.commandId) { snapshotFiles=originalSnapshotFiles; }
                    }
                } catch (_snapshotFilesError) { /* An unavailable worker source cannot establish absence. */ }
                Test.saveObject(snapshotFiles,"feature-ios-snapshot-file-work.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-uploads") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotUploads={iosSnapshotUploadsVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotUploads === "function") {
                        var originalSnapshotUploads=Test.featureIOSSnapshotUploads(command);
                        if (originalSnapshotUploads && originalSnapshotUploads.requestId === command.commandId) { snapshotUploads=originalSnapshotUploads; }
                    }
                } catch (_snapshotUploadsError) { /* Uncertain diagnostics never establish an empty upload scope. */ }
                Test.saveObject(snapshotUploads,"feature-ios-snapshot-uploads.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-provenance") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotProvenance={iosSnapshotProvenanceVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotProvenance === "function") {
                        var originalSnapshotProvenance=Test.featureIOSSnapshotProvenance(command);
                        if (originalSnapshotProvenance && originalSnapshotProvenance.requestId === command.commandId) { snapshotProvenance=originalSnapshotProvenance; }
                    }
                } catch (_snapshotProvenanceError) { /* An uncertain read remains consumed. */ }
                Test.saveObject(snapshotProvenance,"feature-ios-snapshot-provenance.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-emote-palette") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var emotePalette={iosEmotePaletteVersion:2,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSEmotePalette === "function") {
                        var originalEmotePalette=Test.featureIOSEmotePalette(command);
                        if (originalEmotePalette && originalEmotePalette.requestId === command.commandId) { emotePalette=originalEmotePalette; }
                    }
                } catch (_emotePaletteError) { /* Unknown read stays consumed; no input or query replay. */ }
                Test.saveObject(emotePalette,"feature-ios-emote-palette.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-scene") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotScene={iosSnapshotSceneVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotScene === "function") {
                        var originalSnapshotScene=Test.featureIOSSnapshotScene(command);
                        if (originalSnapshotScene && originalSnapshotScene.requestId === command.commandId) { snapshotScene=originalSnapshotScene; }
                    }
                } catch (_snapshotSceneError) { /* An uncertain read remains consumed. */ }
                Test.saveObject(snapshotScene,"feature-ios-snapshot-scene.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-actor-pixels") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotActorPixels={iosSnapshotActorPixelsVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotActorPixels === "function") {
                        var originalSnapshotActorPixels=Test.featureIOSSnapshotActorPixels(command);
                        if (originalSnapshotActorPixels && originalSnapshotActorPixels.requestId === command.commandId) { snapshotActorPixels=originalSnapshotActorPixels; }
                    }
                } catch (_snapshotActorPixelsError) { /* An uncertain read remains consumed. */ }
                Test.saveObject(snapshotActorPixels,"feature-ios-snapshot-actor-pixels.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-captures") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotCaptures={iosSnapshotCapturesVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotCaptures === "function") {
                        var originalSnapshotCaptures=Test.featureIOSSnapshotCaptures(command);
                        if (originalSnapshotCaptures && originalSnapshotCaptures.requestId === command.commandId) { snapshotCaptures=originalSnapshotCaptures; }
                    }
                } catch (_snapshotCapturesError) { /* An uncertain read remains consumed. */ }
                Test.saveObject(snapshotCaptures,"feature-ios-snapshot-captures.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-work") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotWork={iosSnapshotWorkVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotWork === "function") {
                        var originalSnapshotWork=Test.featureIOSSnapshotWork(command);
                        if (originalSnapshotWork && originalSnapshotWork.requestId === command.commandId) { snapshotWork=originalSnapshotWork; }
                    }
                } catch (_snapshotWorkError) { /* An uncertain read remains consumed. */ }
                Test.saveObject(snapshotWork,"feature-ios-snapshot-work.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-snapshot-exports") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var snapshotExports={iosSnapshotExportsVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSSnapshotExports === "function") {
                        var originalSnapshotExports=Test.featureIOSSnapshotExports(command);
                        if (originalSnapshotExports && originalSnapshotExports.requestId === command.commandId) { snapshotExports=originalSnapshotExports; }
                    }
                } catch (_snapshotExportsError) { /* An export ACK is not a saved or delivered original. */ }
                Test.saveObject(snapshotExports,"feature-ios-snapshot-exports.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-avatar-state") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (command.commandId === lastIOSAvatarStateRequest) { return; }
                lastIOSAvatarStateRequest=command.commandId;
                var avatarState={iosAvatarStateVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSAvatarState === "function") {
                        var originalAvatarState=Test.featureIOSAvatarState(command);
                        if (originalAvatarState && originalAvatarState.requestId === command.commandId) { avatarState=originalAvatarState; }
                    }
                } catch (_avatarStateError) { /* No current properties can fabricate an original model failure. */ }
                Test.saveObject(avatarState,"feature-ios-avatar-state.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-navigation-state") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (command.commandId === lastIOSNavigationStateRequest) { return; }
                lastIOSNavigationStateRequest=command.commandId;
                var navigationState={iosNavigationStateVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSNavigationState === "function") {
                        var originalNavigationState=Test.featureIOSNavigationState(command);
                        if (originalNavigationState && originalNavigationState.requestId === command.commandId) { navigationState=originalNavigationState; }
                    }
                } catch (_navigationStateError) { /* A missing original is not an arrived scene. */ }
                Test.saveObject(navigationState,"feature-ios-navigation-state.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-navigation-dialogs") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (command.commandId === lastIOSNavigationDialogRequest) { return; }
                lastIOSNavigationDialogRequest=command.commandId;
                var navigationDialogs={iosNavigationDialogsVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSNavigationDialogs === "function") {
                        var originalDialogs=Test.featureIOSNavigationDialogs(command);
                        if (originalDialogs && originalDialogs.requestId === command.commandId) { navigationDialogs=originalDialogs; }
                    }
                } catch (_navigationDialogsError) { /* Unknown modal/lifetime is not empty successful absence. */ }
                Test.saveObject(navigationDialogs,"feature-ios-navigation-dialogs.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-places-http") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (command.commandId === lastIOSPlacesHttpRequest) { return; }
                lastIOSPlacesHttpRequest=command.commandId;
                var placesHttp={iosPlacesHttpVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSPlacesHttp === "function") {
                        var originalHttp=Test.featureIOSPlacesHttp(command);
                        if (originalHttp && originalHttp.requestId === command.commandId) { placesHttp=originalHttp; }
                    }
                } catch (_placesHttpError) { /* Missing XHR/lifetime evidence cannot become a drained history. */ }
                Test.saveObject(placesHttp,"feature-ios-places-http.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-places-model") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (command.commandId === lastIOSPlacesModelRequest) { return; }
                lastIOSPlacesModelRequest=command.commandId;
                var placesModel={iosPlacesModelVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSPlacesModel === "function") {
                        var originalModel=Test.featureIOSPlacesModel(command);
                        if (originalModel && originalModel.requestId === command.commandId) { placesModel=originalModel; }
                    }
                } catch (_placesModelError) { /* Missing model is not an empty list or a drained queue. */ }
                Test.saveObject(placesModel,"feature-ios-places-model.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-location-bookmarks") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                if (command.commandId === lastIOSLocationBookmarksRequest) { return; }
                lastIOSLocationBookmarksRequest=command.commandId;
                var locationBookmarks={iosLocationBookmarksVersion:1,requestId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSLocationBookmarks === "function") {
                        var originalBookmarks=Test.featureIOSLocationBookmarks(command);
                        if (originalBookmarks && originalBookmarks.requestId === command.commandId) { locationBookmarks=originalBookmarks; }
                    }
                } catch (_locationBookmarksError) { /* Unknown loaded/disk state is not an empty successful map. */ }
                Test.saveObject(locationBookmarks,"feature-ios-location-bookmarks.json");
            }
            return;
        }
        if (command && command.action === "feature-navigation-replies") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                    && command.commandId.length === (command.commandId.indexOf("ios-") === 0 ? 36 : 32)
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId"])) {
                var navigationReplies={navigationReplyVersion:1,commandId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureNavigationReplies === "function") {
                        var originalNavigationReplies=Test.featureNavigationReplies(command);
                        if (originalNavigationReplies && originalNavigationReplies.commandId === command.commandId) { navigationReplies=originalNavigationReplies; }
                    }
                } catch (_navigationReplyError) { /* Missing original provenance is not an empty successful history. */ }
                Test.saveObject(navigationReplies,"feature-navigation-replies.json");
            }
            return true;
        }
        if (command && command.action === "feature-pending-commit-owner") {
            var pendingOwnerFields = ["schemaVersion","commandId","action","operation","runId","eventId"];
            var pendingOwnerInput = /^(focus|type|hold|attempt)$/.test(String(command.operation));
            if (command.operation !== "observe") { pendingOwnerFields = pendingOwnerFields.concat(["ownerInstance","intentSequence"]); }
            if (pendingOwnerInput) { pendingOwnerFields = pendingOwnerFields.concat(["fieldToken","observationSequence"]); }
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                    && command.commandId.length === (command.commandId.indexOf("ios-") === 0 ? 36 : 32)
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.eventId === "string" && (command.eventId === "" || /^[0-9a-f]{32}$/.test(command.eventId) && command.eventId.length === 32)
                    && /^(observe|focus|type|hold|attempt|release)$/.test(String(command.operation))
                    && ((command.operation === "attempt" || command.operation === "release") ? command.eventId.length === 32
                        : command.operation === "observe" || command.eventId === "")
                    && (command.operation === "observe" || typeof command.ownerInstance === "string" && command.ownerInstance.length === 32
                        && /^[0-9a-f]{32}$/.test(command.ownerInstance) && typeof command.intentSequence === "number"
                        && isFinite(command.intentSequence) && Math.floor(command.intentSequence) === command.intentSequence
                        && command.intentSequence >= 1 && command.intentSequence <= 1000000000)
                    && (!pendingOwnerInput || typeof command.fieldToken === "string" && command.fieldToken.length === 32
                        && /^[0-9a-f]{32}$/.test(command.fieldToken) && typeof command.observationSequence === "number"
                        && isFinite(command.observationSequence) && Math.floor(command.observationSequence) === command.observationSequence
                        && command.observationSequence >= 1 && command.observationSequence <= 1000000000)
                    && objectKeysMatch(command,pendingOwnerFields)) {
                var pendingOwner = {pendingCommitOwnerVersion:1,commandId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featurePendingCommitOwner === "function") {
                        var originalPendingOwner = Test.featurePendingCommitOwner(command);
                        if (originalPendingOwner && originalPendingOwner.commandId === command.commandId) { pendingOwner = originalPendingOwner; }
                    }
                } catch (_pendingOwnerError) { /* A missing actual owner is never a successful empty inventory. */ }
                Test.saveObject(pendingOwner,"feature-pending-commit-owner.json");
            }
            return true;
        }
        if (command && command.action === "feature-ios-world-web-whole-snapshot") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                var worldWholeSnapshot={iosWorldWebSnapshotVersion:2,commandId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSWorldWebWholeSnapshot === "function") {
                        var originalWholeSnapshot=Test.featureIOSWorldWebWholeSnapshot(command);
                        if (originalWholeSnapshot && originalWholeSnapshot.commandId===command.commandId) { worldWholeSnapshot=originalWholeSnapshot; }
                    }
                } catch (_worldWholeSnapshotError) { /* Actual pending callback remains owned by its native source. */ }
                Test.saveObject(worldWholeSnapshot,"feature-ios-world-web-whole-snapshot.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-world-web-snapshot") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                var worldSnapshot={iosWorldWebSnapshotVersion:1,commandId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSWorldWebSnapshot === "function") {
                        var originalSnapshot=Test.featureIOSWorldWebSnapshot(command);
                        if (originalSnapshot && originalSnapshot.commandId===command.commandId) { worldSnapshot=originalSnapshot; }
                    }
                } catch (_worldSnapshotError) { /* Actual pending callback remains owned by its native source. */ }
                Test.saveObject(worldSnapshot,"feature-ios-world-web-snapshot.json");
            }
            return;
        }
        if (command && (command.action === "feature-ios-world-web" || command.action === "feature-ios-world-web-dom")) {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                var worldDOM = command.action === "feature-ios-world-web-dom";
                if (!worldDOM) {
                    if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                    iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                }
                var worldWeb = worldDOM ? {iosWorldWebDOMNativeVersion:1,commandId:command.commandId,status:"unavailable"}
                    : {iosWorldWebVersion:1,commandId:command.commandId,complete:false};
                try {
                    var worldGetter = worldDOM ? Test.featureIOSWorldWebDOM : Test.featureIOSWorldWeb;
                    if (typeof worldGetter === "function") {
                        var originalWorldWeb = worldGetter.call(Test,command);
                        if (originalWorldWeb && originalWorldWeb.commandId === command.commandId) { worldWeb=originalWorldWeb; }
                    }
                } catch (_worldWebError) { /* A missing actual transcript never supplies a ready document. */ }
                Test.saveObject(worldWeb,worldDOM ? "feature-ios-world-web-dom.json" : "feature-ios-world-web.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-tablet-sources") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var tabletSources={iosTabletSourcesVersion:1,commandId:command.commandId,complete:false};
                try {
                    if (typeof Test.featureIOSTabletSources === "function") {
                        var originalTabletSources=Test.featureIOSTabletSources(command);
                        if (originalTabletSources && originalTabletSources.commandId === command.commandId) { tabletSources=originalTabletSources; }
                    }
                } catch (_tabletSourcesError) { /* Missing native originals cannot provide an empty inventory. */ }
                Test.saveObject(tabletSources,"feature-ios-tablet-sources.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-tablet-web") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var tabletWeb={iosTabletWebVersion:1,commandId:command.commandId,complete:false};
                try {
                    if (typeof Test.featureIOSTabletWeb === "function") {
                        var originalTabletWeb=Test.featureIOSTabletWeb(command);
                        if (originalTabletWeb && originalTabletWeb.commandId === command.commandId) { tabletWeb=originalTabletWeb; }
                    }
                } catch (_tabletWebError) { /* Missing native originals cannot provide an empty inventory. */ }
                Test.saveObject(tabletWeb,"feature-ios-tablet-web.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-tablet-web-deferred") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var tabletWeb={iosTabletWebDeferredVersion:1,commandId:command.commandId,complete:false};
                try {
                    if (typeof Test.featureIOSTabletWebDeferred === "function") {
                        var originalTabletWeb=Test.featureIOSTabletWebDeferred(command);
                        if (originalTabletWeb && originalTabletWeb.commandId === command.commandId) { tabletWeb=originalTabletWeb; }
                    }
                } catch (_tabletWebError) { /* Missing native originals cannot provide an empty inventory. */ }
                Test.saveObject(tabletWeb,"feature-ios-tablet-web-deferred.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-tablet-web-defer") {
            var arm=command.operation === "arm";
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId) && command.runId.length === 32
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && (arm || ((command.operation === "deliver" || command.operation === "discard")
                        && typeof command.recordId === "string" && /^[0-9a-f]{32}$/.test(command.recordId) && command.recordId.length === 32))
                    && objectKeysMatch(command,arm ? ["schemaVersion","commandId","action","runId","fixtureUrl","operation"]
                        : ["schemaVersion","commandId","action","runId","fixtureUrl","operation","recordId"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var held={iosTabletWebDeferReceiptVersion:1,command:command,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSTabletWebDefer === "function") {
                        var originalHeld=Test.featureIOSTabletWebDefer(command);
                        if (originalHeld && originalHeld.command && originalHeld.command.commandId === command.commandId) { held=originalHeld; }
                    }
                } catch (_heldError) { /* Unknown issued command remains unresolved; never replay it here. */ }
                Test.saveObject(held,"feature-ios-tablet-web-defer.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-web-script-emissions") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var tabletWeb={iosWebScriptEmissionsVersion:1,commandId:command.commandId,complete:false};
                try {
                    if (typeof Test.featureIOSWebScriptEmissions === "function") {
                        var originalTabletWeb=Test.featureIOSWebScriptEmissions(command);
                        if (originalTabletWeb && originalTabletWeb.commandId === command.commandId) { tabletWeb=originalTabletWeb; }
                    }
                } catch (_tabletWebError) { /* Missing native originals cannot provide an empty inventory. */ }
                Test.saveObject(tabletWeb,"feature-ios-web-script-emissions.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-tablet-web-state") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var tabletWeb={iosTabletWebStateVersion:1,commandId:command.commandId,complete:false};
                try {
                    if (typeof Test.featureIOSTabletWebState === "function") {
                        var originalTabletWeb=Test.featureIOSTabletWebState(command);
                        if (originalTabletWeb && originalTabletWeb.commandId === command.commandId) { tabletWeb=originalTabletWeb; }
                    }
                } catch (_tabletWebError) { /* Missing native originals cannot provide an empty inventory. */ }
                Test.saveObject(tabletWeb,"feature-ios-tablet-web-state.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-tablet-app-buttons") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var tabletWeb={iosTabletAppButtonsVersion:1,commandId:command.commandId,complete:false};
                try {
                    if (typeof Test.featureIOSTabletAppButtons === "function") {
                        var originalTabletWeb=Test.featureIOSTabletAppButtons(command);
                        if (originalTabletWeb && originalTabletWeb.commandId === command.commandId) { tabletWeb=originalTabletWeb; }
                    }
                } catch (_tabletWebError) { /* Missing native originals cannot provide an empty inventory. */ }
                Test.saveObject(tabletWeb,"feature-ios-tablet-app-buttons.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-uikit-input") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var tabletWeb={iosUIKitInputVersion:2,commandId:command.commandId,complete:false};
                try {
                    if (typeof Test.featureIOSUIKitInput === "function") {
                        var originalTabletWeb=Test.featureIOSUIKitInput(command);
                        if (originalTabletWeb && originalTabletWeb.commandId === command.commandId) { tabletWeb=originalTabletWeb; }
                    }
                } catch (_tabletWebError) { /* Missing native originals cannot provide an empty inventory. */ }
                Test.saveObject(tabletWeb,"feature-ios-uikit-input.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-tablet-web-closures") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var tabletWeb={iosTabletWebClosuresVersion:1,commandId:command.commandId,complete:false};
                try {
                    if (typeof Test.featureIOSTabletWebClosures === "function") {
                        var originalTabletWeb=Test.featureIOSTabletWebClosures(command);
                        if (originalTabletWeb && originalTabletWeb.commandId === command.commandId) { tabletWeb=originalTabletWeb; }
                    }
                } catch (_tabletWebError) { /* Missing native originals cannot provide an empty inventory. */ }
                Test.saveObject(tabletWeb,"feature-ios-tablet-web-closures.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-tablet-web-dom") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                var tabletWeb={iosTabletWebDOMNativeVersion:1,commandId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureIOSTabletWebDOM === "function") {
                        var originalTabletWeb=Test.featureIOSTabletWebDOM(command);
                        if (originalTabletWeb && originalTabletWeb.commandId === command.commandId) { tabletWeb=originalTabletWeb; }
                    }
                } catch (_tabletWebError) { /* Missing native originals cannot provide an empty inventory. */ }
                Test.saveObject(tabletWeb,"feature-ios-tablet-web-dom.json");
            }
            return;
        }
        if (command && command.action === "feature-ios-web-closures") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^ios-[0-9a-f]{32}$/.test(command.commandId) && command.commandId.length === 36
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","fixtureUrl"])) {
                var webClosures = {iosWebClosureVersion:1,commandId:command.commandId,complete:false};
                try {
                    if (typeof Test.featureIOSWebClosures === "function") {
                        var originalClosures = Test.featureIOSWebClosures(command);
                        if (originalClosures && originalClosures.commandId === command.commandId) { webClosures = originalClosures; }
                    }
                } catch (_webClosureError) { /* No native source is never an empty inventory. */ }
                Test.saveObject(webClosures,"feature-ios-web-closures.json");
            }
            return true;
        }
        if (command && command.action === "feature-web-dom-observe") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                    && command.commandId.length === (command.commandId.indexOf("ios-") === 0 ? 36 : 32)
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && (command.surface === "world" || command.surface === "tablet")
                    && typeof command.fixtureUrl === "string" && command.fixtureUrl.length <= 512
                    && new RegExp("^https?://[^/?#@\\s]+/feature-fixture/v1/runs/"+command.runId+"/$").test(command.fixtureUrl)
                    && objectKeysMatch(command,["schemaVersion","commandId","action","runId","surface","fixtureUrl"])) {
                var webDOM={webNativeVersion:1,commandId:command.commandId,status:"unavailable"};
                try {
                    if (typeof Test.featureWebDOMObservation === "function") {
                        var originalWebDOM=Test.featureWebDOMObservation(command);
                        if (originalWebDOM && originalWebDOM.commandId === command.commandId) { webDOM=originalWebDOM; }
                    }
                } catch (_) {}
                Test.saveObject(webDOM,"feature-web-dom-observation.json");
            }
            return true;
        }
        if (command && command.action === "feature-chat-view-observe") {
            var loadedObjectProfile=command.schemaVersion === 2 && command.profile === "loaded-qml-object"
                && typeof command.commandId === "string" && /^ios-[0-9a-f]{32}$/.test(command.commandId)
                && objectKeysMatch(command,["schemaVersion","commandId","action","runId","profile"]);
            var literalChatView=command.schemaVersion === 1
                && objectKeysMatch(command,["schemaVersion","commandId","action","runId"]);
            if ((literalChatView || loadedObjectProfile) && typeof command.commandId === "string"
                    && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                    && command.commandId.length === (command.commandId.indexOf("ios-") === 0 ? 36 : 32)
                    && typeof command.runId === "string" && command.runId.length === 32 && /^[0-9a-f]{32}$/.test(command.runId)
                    && command.commandId!==lastChatViewCommand) {
                lastChatViewCommand=String(command.commandId);
                var chatView={chatViewVersion:1,commandId:command.commandId,available:false};
                try {
                    if (typeof Test.featureChatViewObservation === "function") {
                        var originalChatView=Test.featureChatViewObservation(command);
                        if (originalChatView && originalChatView.commandId === command.commandId) { chatView=originalChatView; }
                    }
                } catch (_chatViewError) { /* Missing original UI/storage/keyboard is not a result. */ }
                Test.saveObject(chatView,"feature-chat-view-observation.json");
            }
            return;
        }
        if (command && command.action==="feature-chat-observe" && validChatObservationCommand(command)) {
            if (command.commandId!==lastChatObservationCommand) {
                lastChatObservationCommand=String(command.commandId);
                var chatSource={commandId:command.commandId,available:false};
                try {
                    if (typeof Test.featureChatObservation==="function") {
                        var originalChat=Test.featureChatObservation(command);
                        if (originalChat && originalChat.commandId===command.commandId) { chatSource=originalChat; }
                    }
                } catch (_chatObservationError) { /* No failed source is an empty received ledger. */ }
                Test.saveObject(chatSource,"feature-chat-observation.json");
            }
            return;
        }

        if (command && command.action === "feature-private-login-input" && validPrivateLoginInputCommand(command)) {
            if (command.commandId !== lastPrivateLoginInputCommand) {
                lastPrivateLoginInputCommand=String(command.commandId);
                var privateInput={commandId:command.commandId,available:false};
                try {
                    if (typeof Test.iosPrivateLoginInput === "function") {
                        var original=Test.iosPrivateLoginInput(command);
                        if (original && original.commandId===command.commandId) { privateInput=original; }
                    }
                } catch (_privateInputError) { /* No entered text or native exception export. */ }
                Test.saveObject(privateInput,"feature-private-login-input.json");
            }
            return;
        }

        if (command && command.action === "feature-account-origin" && validAccountOriginCommand(command)) {
            if (command.commandId !== lastAccountOriginCommand) {
                lastAccountOriginCommand = String(command.commandId);
                var originResult = {commandId:command.commandId,available:false};
                try {
                    if (typeof Test.featureAccountOrigin === "function") {
                        var originSource = Test.featureAccountOrigin(command);
                        if (originSource && originSource.commandId === command.commandId) { originResult = originSource; }
                    }
                } catch (_accountOriginError) { /* Missing ownership/readback never proves a fixture. */ }
                Test.saveObject(originResult,"feature-account-origin-result.json");
            }
            return;
        }
        if (command && command.action === "feature-account-probe" && validAccountProbeCommand(command)) {
            if (command.commandId !== lastAccountProbeCommand) {
                if (accountProbeTimer !== null) { Script.clearTimeout(accountProbeTimer); accountProbeTimer = null; }
                lastAccountProbeCommand = String(command.commandId); saveAccountProbe(command);
            }
            return;
        }
        if (command && command.action === "feature-avatar-receive-observe") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                    && command.commandId.length === (command.commandId.indexOf("ios-") === 0 ? 36 : 32)
                    && objectKeysMatch(command,["schemaVersion","commandId","action"])
                    && command.commandId !== lastAvatarReceiveRequest) {
                lastAvatarReceiveRequest=command.commandId;
                var receivedAvatar={avatarReceiveObservationVersion:1,commandId:command.commandId,available:false};
                try {
                    if (typeof Test.featureAvatarReceive === "function") {
                        var originalReceivedAvatar=Test.featureAvatarReceive(command);
                        if (originalReceivedAvatar && originalReceivedAvatar.commandId === command.commandId) { receivedAvatar=originalReceivedAvatar; }
                    }
                } catch (_avatarReceiveError) { /* Missing native source remains unavailable. */ }
                Test.saveObject(receivedAvatar,"feature-avatar-receive.json");
            }
            return;
        }
        if (command && command.action === "feature-script-work-observe") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                    && command.commandId.length === (command.commandId.indexOf("ios-") === 0 ? 36 : 32)
                    && typeof command.managerInstance === "string" && /^[0-9a-f]{32}$/.test(command.managerInstance)
                    && command.managerInstance.length === 32
                    && objectKeysMatch(command,["schemaVersion","commandId","action","managerInstance"])
                    && command.commandId !== lastScriptWorkRequest) {
                if (scriptWorkTimer !== null) { Script.clearTimeout(scriptWorkTimer); scriptWorkTimer = null; }
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                lastScriptWorkRequest=command.commandId;saveScriptWorkObservation(command);
            }
            return;
        }
        if (command && command.action === "feature-script-terminal-observe") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                    && command.commandId.length === (command.commandId.indexOf("ios-") === 0 ? 36 : 32)
                    && objectKeysMatch(command,["schemaVersion","commandId","action"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                var scriptTerminal={scriptTerminalObservationVersion:1,commandId:command.commandId,available:false};
                try {
                    if (typeof Test.featureScriptTerminal === "function") {
                        var originalTerminal=Test.featureScriptTerminal(command);
                        if (originalTerminal && originalTerminal.commandId === command.commandId) { scriptTerminal=originalTerminal; }
                    }
                } catch (_scriptTerminalError) { /* No original terminal source proves no drainage. */ }
                Test.saveObject(scriptTerminal,"feature-script-terminal.json");
            }
            return;
        }
        if (command && command.action === "feature-script-roots-observe") {
            if (command.schemaVersion === 1 && typeof command.commandId === "string"
                    && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                    && command.commandId.length === (command.commandId.indexOf("ios-") === 0 ? 36 : 32)
                    && objectKeysMatch(command,["schemaVersion","commandId","action"])
                    && command.commandId !== lastScriptRootsRequest) {
                lastScriptRootsRequest=command.commandId;
                var scriptRoots={scriptRootsVersion:1,commandId:command.commandId,available:false};
                try {
                    if (typeof Test.featureScriptRoots === "function") {
                        var originalScriptRoots=Test.featureScriptRoots(command);
                        if (originalScriptRoots && originalScriptRoots.commandId === command.commandId) { scriptRoots=originalScriptRoots; }
                    }
                } catch (_scriptRootsError) { /* Missing configuration stays unavailable. */ }
                Test.saveObject(scriptRoots,"feature-script-roots.json");
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && (command.action === "feature-completed-frame" || command.action === "feature-vulkan-world-frame")
                && typeof command.commandId === "string" && /^ios-[0-9a-f]{32}$/.test(command.commandId)
                && typeof command.requestId === "string" && /^ios-[0-9a-f]{32}$/.test(command.requestId)
                && (/^(read|release|inspect)$/.test(String(command.operation))
                    || command.action === "feature-vulkan-world-frame" && command.operation === "read-bytes")
                && objectKeysMatch(command,command.operation === "read-bytes"
                    ? ["schemaVersion","commandId","action","requestId","operation","offset"]
                    : ["schemaVersion","commandId","action","requestId","operation"])
                && (command.operation !== "read-bytes" || typeof command.offset === "number"
                    && command.offset >= 0 && command.offset < 33554432 && Math.floor(command.offset) === command.offset)) {
            if (command.commandId === lastCompletedFrameCommand) { return; }
            lastCompletedFrameCommand = command.commandId;
            if (command.operation === "read") {
                if (completedFrameTimer !== null) { Script.clearTimeout(completedFrameTimer); completedFrameTimer = null; }
                completedFrameCommand = command;saveCompletedFrame(command,50);
            } else {
                if (command.operation === "release" && completedFrameCommand !== null
                        && completedFrameCommand.requestId === command.requestId) {
                    completedFrameCommand = null;
                    if (completedFrameTimer !== null) { Script.clearTimeout(completedFrameTimer); completedFrameTimer = null; }
                }
                var storage = {};
                try {
                    if (typeof Test.featureCompletedFrameObservation === "function") { storage = Test.featureCompletedFrameObservation(command); }
                } catch (_completedFrameStorageError) { /* Missing source is not cleanup. */ }
                Test.saveObject(storage,command.action === "feature-vulkan-world-frame"
                    ? "feature-vulkan-world-frame.json" : "feature-completed-frame.json");
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.requestId))
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.receiptId))
                && command.action === "feature-world-render-receipt"
                && /^(remove|inspect)$/.test(String(command.operation))
                && objectKeysMatch(command,["schemaVersion","commandId","action","requestId","receiptId","operation"])) {
            if (command.commandId === lastWorldRenderReceiptCommand) { return; }
            lastWorldRenderReceiptCommand = command.commandId;
            var receipt = {};
            try {
                if (typeof Test.featureWorldRenderReceipt === "function") { receipt = Test.featureWorldRenderReceipt(command); }
            } catch (_worldReceiptError) { /* No missing/foreign document proves absence. */ }
            Test.saveObject(receipt,"world-render-receipt-result.json");
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.requestId))
                && command.action === "feature-world-render-storage"
                && /^(read|release|inspect)$/.test(String(command.operation))
                && objectKeysMatch(command, command.operation === "read"
                    ? ["schemaVersion", "commandId", "action", "requestId", "operation", "offset"]
                    : ["schemaVersion", "commandId", "action", "requestId", "operation"])
                && (command.operation !== "read" || (typeof command.offset === "number"
                    && command.offset >= 0 && command.offset < 33554432 && Math.floor(command.offset) === command.offset))) {
            if (command.commandId === lastWorldRenderStorageCommand) { return; }
            lastWorldRenderStorageCommand = command.commandId;
            if (command.operation === "release" && command.requestId === lastWorldRenderRequest) {
                if (worldRenderTimer !== null) { Script.clearTimeout(worldRenderTimer); worldRenderTimer = null; }
                lastWorldRenderRequest = "";
            }
            var stored = {};
            try {
                if (typeof Test.featureWorldRenderStorage === "function") { stored = Test.featureWorldRenderStorage(command); }
            } catch (_worldStorageError) { /* Missing originals remain unavailable. */ }
            Test.saveObject(stored, "world-render-storage-" + String(command.commandId).replace(/^ios-/, "") + ".json");
            return;
        }
        if (command && command.schemaVersion === 1
                && typeof command.commandId === "string" && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                && typeof command.runId === "string" && /^[0-9a-f]{32}$/.test(command.runId)
                && command.action === "feature-scene-load-observe"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "runId"])) {
            if (command.commandId === lastSceneLoadRequest) { return; }
            lastSceneLoadRequest = command.commandId;
            var sceneLoad = {schemaVersion: 1, commandId: command.commandId, available: false};
            try {
                if (typeof Test.featureSceneLoadObservation === "function") {
                    var originalSceneLoad = Test.featureSceneLoadObservation(command);
                    if (originalSceneLoad && originalSceneLoad.commandId === command.commandId) { sceneLoad = originalSceneLoad; }
                }
            } catch (_sceneLoadError) { /* Missing native lifecycle facts remain unavailable. */ }
            Test.saveObject(sceneLoad, "feature-scene-load.json");
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
                && /^[0-9a-f]{32}$/.test(String(command.runId))
                && command.action === "feature-graphics-subject-observe"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "runId"])) {
            if (command.commandId === lastGraphicsSubjectRequest) { return; }
            lastGraphicsSubjectRequest = command.commandId;
            var subject = {schemaVersion: 1, requestId: command.commandId, available: false};
            try {
                if (typeof Test.featureGraphicsSubjectObservation === "function") {
                    var originalSubject = Test.featureGraphicsSubjectObservation(command);
                    if (originalSubject && originalSubject.requestId === command.commandId) { subject = originalSubject; }
                }
            } catch (_graphicsSubjectError) { /* Missing originals remain unavailable. */ }
            Test.saveObject(subject, "feature-graphics-subject.json");
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
                && command.action === "feature-world-render-observe"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action"])) {
            if (command.commandId !== lastWorldRenderRequest) {
                if (worldRenderTimer !== null) { Script.clearTimeout(worldRenderTimer); worldRenderTimer = null; }
                lastWorldRenderRequest = String(command.commandId);
                saveWorldRenderObservation(command.commandId);
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
                && command.action === "feature-script-files"
                && /^(stage|observe|release|locate)$/.test(String(command.operation))
                && /^[0-9a-f]{32}$/.test(String(command.runId))
                && /^[0-9a-f]{64}$/.test(String(command.ownerToken))
                && objectKeysMatch(command, command.operation === "stage"
                    ? ["schemaVersion", "commandId", "action", "operation", "runId", "ownerToken", "files"]
                    : ["schemaVersion", "commandId", "action", "operation", "runId", "ownerToken"])) {
            if (command.commandId !== lastScriptFilesRequest) {
                lastScriptFilesRequest = String(command.commandId);
                var fileResult = {schemaVersion: 1, requestId: command.commandId, available: false};
                try {
                    if (typeof Test.featureScriptFiles === "function") {
                        var fileNative = Test.featureScriptFiles(command);
                        if (fileNative && fileNative.requestId === command.commandId) { fileResult = fileNative; }
                    }
                } catch (_scriptFileError) { /* Failed staging/cleanup cannot be acknowledged. */ }
                Test.saveObject(fileResult, "feature-script-files.json");
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
                && command.action === "feature-process-presence"
                && typeof command.queryProcessId === "number" && isFinite(command.queryProcessId)
                && Math.floor(command.queryProcessId) === command.queryProcessId
                && command.queryProcessId >= 1 && command.queryProcessId <= 2147483647
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "queryProcessId"])) {
            if (command.commandId !== lastProcessPresenceRequest) {
                lastProcessPresenceRequest = String(command.commandId);
                var presence = {processPresenceVersion: 1, commandId: command.commandId, available: false};
                try {
                    if (typeof Test.featureProcessPresence === "function") {
                        var originalPresence = Test.featureProcessPresence(command);
                        if (originalPresence && originalPresence.commandId === command.commandId) { presence = originalPresence; }
                    }
                } catch (_processPresenceError) { /* Unknown never means absent. */ }
                Test.saveObject(presence, "feature-process-presence.json");
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
                && command.action === "feature-script-observe"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action"])) {
            if (command.commandId !== lastScriptSourceRequest) {
                lastScriptSourceRequest = String(command.commandId);
                saveScriptSourceObservation(command.commandId);
            }
            return;
        }
        if (command && command.schemaVersion === 2 && command.action === "feature-recorded-audio-release"
                && /^ios-[0-9a-f]{32}$/.test(String(command.commandId))
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "expected"])) {
            if (command.commandId !== lastRecordedPreviewRequest) {
                lastRecordedPreviewRequest = String(command.commandId);
                saveOwnedRecordedPreviewRelease(command);
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(String(command.commandId))
                && (command.action === "feature-recorded-audio-observe" || command.action === "feature-recorded-audio-release"
                    || command.action === "feature-recorded-audio-files")
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action"])) {
            if (command.commandId !== lastRecordedPreviewRequest) {
                lastRecordedPreviewRequest = String(command.commandId);
                saveRecordedPreviewObservation(command.commandId, command.action);
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                && command.action === "feature-native-observe"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action"])) {
            if (command.commandId !== lastNativeFeatureRequest) {
                if (nativeFeatureTimer !== null) { Script.clearTimeout(nativeFeatureTimer); nativeFeatureTimer = null; }
                lastNativeFeatureRequest = String(command.commandId);
                saveNativeFeatureObservation(command.commandId);
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && /^(?:ios-)?[0-9a-f]{32}$/.test(command.commandId)
                && command.action === "normal-feature-observe"
                && typeof command.includeAvatarEntities === "boolean"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "includeAvatarEntities"])) {
            // One original read per correlated request. Do not poll expensive
            // entity queries or export unrelated script paths in other suites.
            if (command.commandId !== lastNormalFeatureRequest) {
                normalFeatureSequence += 1;
                saveNormalFeatureObservation(Date.now(), normalFeatureSequence,
                    command.includeAvatarEntities, command.commandId);
                lastNormalFeatureRequest = String(command.commandId);
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && /^ios-[0-9a-f]{32}$/.test(command.commandId)
                && command.action === "native-probe-snapshot"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action"])) {
            // Observation must not supersede an in-flight scene/action receipt.
            pendingProbeRequestId = String(command.commandId);
            return;
        }
        if (command && command.schemaVersion === 1
                && /^ios-[0-9a-f]{32}$/.test(command.commandId)
                && command.commandId !== lastClientCommandId
                && command.action === "native-geometry-snapshot"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action"])
                && typeof Tablet.touchUiRuntimeMetrics === "object"
                && Tablet.touchUiRuntimeMetrics !== null) {
            // Preserve this actual native sample while the host reads it.
            Test.saveObject({ schemaVersion: 1, commandId: String(command.commandId),
                observation: { schemaVersion: 1, sampleEpochMs: Date.now(),
                    sampleSequence: sampleSequence, nativeUi: Tablet.touchUiRuntimeMetrics,
                    window: { width: Number(Window.innerWidth), height: Number(Window.innerHeight) }
                } }, "ios-ui-request-result.json");
            lastClientCommandId = String(command.commandId);
            return;
        }
        if (command && command.schemaVersion === 2 && command.action === "snapshot-files") {
            if (typeof command.commandId === "string" && command.commandId.length === 36 && /^ios-[0-9a-f]{32}$/.test(command.commandId)
                    && command.operation === "read" && command.chunkBytes === 524288
                    && objectKeysMatch(command,["schemaVersion","commandId","action","operation","prefix","name","revision","offset","chunkBytes"])) {
                if (iosNewSourceRequests[command.commandId] || iosNewSourceRequestCount >= 4096) { return; }
                // Claim before native entry, including an unknown return. A
                // later request must never resample this retained chunk nonce.
                iosNewSourceRequests[command.commandId]=true;iosNewSourceRequestCount+=1;
                try {
                    if (typeof Test.iosSnapshotFilesRequest === "function") { Test.iosSnapshotFilesRequest(command); }
                } catch (_snapshotChunkError) { /* Retain the unresolved original query; never replay it. */ }
            }
            return;
        }
        if (command && command.schemaVersion === 1
                && /^ios-[0-9a-f]{32}$/.test(command.commandId)
                && command.commandId !== lastClientCommandId
                && command.action === "snapshot-files"
                && ((command.operation === "list"
                    && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "operation", "prefix"]))
                    || (command.operation === "read"
                    && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "operation", "prefix", "name", "revision", "offset"])))
                && typeof Test.iosSnapshotFilesRequest === "function"
                && Test.iosSnapshotFilesRequest(command)) {
            // Read-only native storage observation. The native producer owns
            // all path, size and original-byte validation; never capture here.
            lastClientCommandId = String(command.commandId);
            return;
        }
        if (command && command.schemaVersion === 1
                && /^ios-[0-9a-f]{32}$/.test(command.commandId)
                && command.commandId !== lastClientCommandId
                && command.action === "normal-ui-input"
                && ((command.operation === "observe"
                    && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "operation"]))
                    || (command.operation === "edit"
                    && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "operation", "input"])))
                && typeof Test.iosNormalUiRequest === "function"
                && Test.iosNormalUiRequest(command)) {
            // The native GUI owner validates the closed input schema and saves
            // its actual result. Queuing is never a navigation/feature verdict.
            lastClientCommandId = String(command.commandId);
            return;
        }
        if (command && command.schemaVersion === 1 && command.commandId
                && command.commandId !== lastClientCommandId
                && command.action === "native-ui-snapshot"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action"])
                && typeof Test.iosNativeUiSnapshot === "function") {
            // Keep the actual UIKit result stable while AFC consumes it.
            // Each request receives a fresh native observation and nonce.
            Test.saveObject({ schemaVersion: 1, commandId: String(command.commandId),
                observation: Test.iosNativeUiSnapshot() }, "ios-native-ui-request-result.json");
            lastClientCommandId = String(command.commandId);
            return;
        }
        if (command && command.commandId !== lastClientCommandId && command.action === "native-crash"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action"])
                && typeof Test.iosCrashTest === "function" && Test.iosCrashTest(command)) {
            lastClientCommandId = String(command.commandId);
            return;
        }
        if (command && command.commandId !== lastClientCommandId
                && command.action === "entity-script-consent"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "operation", "source"])
                && typeof Test.iosEntityScriptConsentTest === "function"
                && Test.iosEntityScriptConsentTest(command)) {
            lastClientCommandId = String(command.commandId);
            return;
        }
        if (command && command.commandId !== lastTextCommandId && command.action === "text-fixture"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "operation"])
                && typeof Test.iosTextTest === "function" && Test.iosTextTest(command)) {
            lastTextCommandId = String(command.commandId);
            return;
        }
        if (applyVoice(command)) { return; }
        if (!command || command.schemaVersion !== 1 || !command.commandId
                || command.commandId === lastClientCommandId) {
            return;
        }
        if (command.action === "primary-view"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "operation"])
                && (command.operation === "prepare" || command.operation === "restore")) {
            if (command.operation === "prepare") {
                if (primaryOriginalCameraMode === null) { primaryOriginalCameraMode = String(Camera.mode); }
                Camera.mode = "first person";
                if (String(Camera.mode) !== "first person") { return; }
            } else {
                if (primaryOriginalCameraMode !== null) { Camera.mode = primaryOriginalCameraMode; }
                primaryOriginalCameraMode = null;
            }
            primaryViewCommandId = String(command.commandId);
            lastClientCommandId = String(command.commandId);
            return;
        }
        if (command.action === "key-hold"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action",
                    "key", "durationMs"])
                && applyControlledKey(command)) {
            lastClientCommandId = String(command.commandId);
            return;
        }
        if (command.action === "scene-load"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "url"])
                && httpUrl(command.url)) {
            var sceneCommandId = String(command.commandId);
            var scenePath = controlledSceneLocation(command.url);
            lastClientCommandId = sceneCommandId;
            lastSceneCommandId = sceneCommandId;
            resetSceneObservation();
            // A path-only viewpoint is valid only inside this serverless
            // scene. From a domain it merely moves the avatar in that domain
            // and never disconnects or loads the fixture.
            if (Boolean(location.isConnected)
                    || addressWithoutReloadCommand(location.href) !== addressWithoutReloadCommand(command.url)) {
                Window.location = command.url;
            } else if (scenePath !== "") {
                Window.location = scenePath;
            }
            Script.setTimeout(function () {
                applySceneLocation(sceneCommandId, scenePath);
            }, 1500);
            Script.setTimeout(function () {
                applySceneLocation(sceneCommandId, scenePath);
            }, 3500);
            return;
        }
        if (command.action === "navigate"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "url"])
                && typeof command.url === "string"
                && /^hifi:\/\/(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\]):[0-9]+(?:\/|$)/.test(command.url)) {
            lastClientCommandId = String(command.commandId);
            location.handleLookupString(command.url);
            return;
        }
        if (command.action === "set-safe-setting"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action",
                    "settingId", "enabled"])
                && command.settingId === "audio.warn-when-muted"
                && typeof command.enabled === "boolean") {
            Audio.warnWhenMuted = command.enabled;
            if (Boolean(Audio.warnWhenMuted) === command.enabled) {
                lastClientCommandId = String(command.commandId);
            }
            return;
        }
        if (command.action === "set-audio-mute"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "muted"])
                && typeof command.muted === "boolean") {
            Audio.muted = command.muted;
            if (Boolean(Audio.muted) === command.muted) {
                lastClientCommandId = String(command.commandId);
            }
            return;
        }
        if (command.action === "asset-load"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action",
                    "assetId", "url", "entityName"])
                && typeof command.assetId === "string" && command.assetId.length > 0
                && typeof command.entityName === "string"
                && command.entityName.indexOf("OVERTE_E2E_ASSET_LOAD") === 0
                && httpUrl(command.url)) {
            if (controlledAssetEntity !== null) {
                Entities.deleteEntity(controlledAssetEntity);
                controlledAssetEntity = null;
            }
            controlledAssetEntity = Entities.addEntity({
                type: "Image",
                name: command.entityName,
                imageURL: command.url,
                userData: JSON.stringify({ overteE2EAssetId: command.assetId }),
                position: Vec3.sum(MyAvatar.position, Vec3.multiply(
                    2.0, Quat.getForward(Camera.orientation))),
                dimensions: { x: 1.0, y: 1.0, z: 0.01 }
            }, "local");
            lastClientCommandId = String(command.commandId);
            return;
        }
        if (command.action === "sound-channel"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "url"])
                && httpUrl(command.url)) {
            soundCommandUrl = String(command.url);
            lastClientCommandId = String(command.commandId);
        }
    }

    function pollClientCommand() {
        if (clientCommandUnavailable || clientCommandRequest !== null) {
            return;
        }
        var commandUrl = clientCommandEndpoint();
        if (commandUrl === "") {
            return;
        }
        var request = new XMLHttpRequest();
        clientCommandRequest = request;
        request.onreadystatechange = function () {
            if (request.readyState !== request.DONE) {
                return;
            }
            clientCommandRequest = null;
            if ((request.status === 0 || request.status === 200)
                    && request.responseText) {
                try {
                    applyClientCommand(JSON.parse(request.responseText));
                } catch (error) {
                    print("OVERTE_E2E_CLIENT_COMMAND_ERROR " + safeErrorText(error));
                }
            } else if (request.status >= 400
                    || (request.status === 0 && !request.responseText)) {
                // A network-loaded shared probe has no private command file.
                // Stop polling a permanent miss for the rest of the session.
                clientCommandUnavailable = true;
            }
        };
        request.open("GET", commandUrl);
        request.send();
    }

    function removeAndroidControlledAssetEntities() {
        var ids = Entities.findEntities(MyAvatar.position, 1000.0);
        var index;
        for (index = 0; index < ids.length; index += 1) {
            var properties = Entities.getEntityProperties(ids[index], ["name"]);
            if (String(properties.name).indexOf("OVERTE_E2E_ASSET_LOAD") === 0) {
                Entities.deleteEntity(ids[index]);
            }
        }
        androidAssetEntityId = null;
        releaseAssetResource();
    }

    function applyAndroidControlCommand(command) {
        if (command && (command.action === "normal-feature-observe" || command.action === "feature-native-observe"
                || command.action === "feature-chat-observe" || command.action === "feature-chat-view-observe" || command.action === "feature-web-dom-observe" || command.action === "feature-account-probe" || command.action === "feature-account-origin"
                || command.action === "feature-pending-commit-owner" || command.action === "feature-navigation-replies"
                || command.action === "feature-process-presence"
                || command.action === "feature-recorded-audio-observe" || command.action === "feature-recorded-audio-release"
                || command.action === "feature-recorded-audio-files" || command.action === "feature-script-observe"
                || command.action === "feature-scene-load-observe"
                || command.action === "feature-graphics-subject-observe"
                || command.action === "feature-world-render-observe"
                || command.action === "feature-world-render-storage"
                || command.action === "feature-world-render-receipt"
                || command.action === "feature-script-files")) {
            // Android's existing private channel is separate from the HTTP
            // fixture command endpoint. Reuse the closed native feature path.
            applyClientCommand(command);
            return;
        }
        if (applyVoice(command)) { return; }
        if (!command || command.schemaVersion !== 1 || !command.commandId
                || command.commandId === lastAndroidControlCommandId) {
            return;
        }
        if (command.action === "text-fixture"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "operation"])
                && typeof Test.uiTest === "function"
                && (command.operation === "focus" || command.operation === "snapshot" || command.operation === "dismiss")
                && Test.uiTest(command)) {
            if (command.operation === "focus") {
                controlledTextFixtureActive = true;
                Controller.setVPadHidden(true);
            }
            else if (command.operation === "dismiss") {
                controlledTextFixtureActive = false;
                Controller.setVPadHidden(controlledTabletOpen());
            }
            lastAndroidControlCommandId = String(command.commandId);
            return;
        }
        if (command.action === "reload-scene"
                && objectKeysMatch(command,
                    ["schemaVersion", "commandId", "action"])) {
            lastAndroidControlCommandId = String(command.commandId);
            lastSceneCommandId = lastAndroidControlCommandId;
            reloadControlledScene(lastAndroidControlCommandId);
            return;
        }
        if (command.action === "enter-domain"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "url"])
                && typeof command.url === "string"
                && /^hifi:\/\/(?:[A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\]):[0-9]+(?:\/|$)/.test(command.url)) {
            lastAndroidControlCommandId = String(command.commandId);
            location.handleLookupString(command.url);
            return;
        }
        if (command.action === "load-asset"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action",
                    "assetId", "entityName", "url"])
                && typeof command.assetId === "string" && command.assetId.length > 0
                && typeof command.entityName === "string"
                && command.entityName.indexOf("OVERTE_E2E_ASSET_LOAD") === 0
                && httpUrl(command.url)) {
            removeAndroidControlledAssetEntities();
            androidAssetEntityId = Entities.addEntity({
                type: "Image",
                name: command.entityName,
                imageURL: command.url,
                userData: JSON.stringify({ overteE2EAssetId: command.assetId }),
                position: {
                    x: Number(MyAvatar.position.x),
                    y: Number(MyAvatar.position.y),
                    z: Number(MyAvatar.position.z) - 2.0
                },
                dimensions: { x: 1.0, y: 1.0, z: 0.01 },
                lifetime: 300
            }, "local");
            lastAndroidControlCommandId = String(command.commandId);
            return;
        }
        if (command.action === "sound-channel"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action",
                    "commandUrl"])
                && httpUrl(command.commandUrl)) {
            soundCommandUrl = String(command.commandUrl);
            lastAndroidControlCommandId = String(command.commandId);
            return;
        }
        if (command.action === "audio-mute"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action", "muted"])
                && typeof command.muted === "boolean") {
            Audio.muted = command.muted;
            lastAndroidControlCommandId = String(command.commandId);
            return;
        }
        if (command.action === "set-safe-setting"
                && objectKeysMatch(command, ["schemaVersion", "commandId", "action",
                    "settingId", "enabled"])
                && command.settingId === "audio.warn-when-muted"
                && typeof command.enabled === "boolean") {
            Audio.warnWhenMuted = command.enabled;
            lastAndroidControlCommandId = String(command.commandId);
        }
    }

    function pollAndroidControlCommand() {
        if (!androidControlAvailable) {
            return;
        }
        try {
            var command = Script.require(androidControlCommandUrl + "?sample="
                + sampleSequence);
            applyAndroidControlCommand(command);
        } catch (error) {
            // The launcher starts without a command and creates it on demand.
        }
    }

    function pollAndroidControlMarker() {
        if (!androidControlEligible) {
            return;
        }
        if (androidControlAvailable) {
            pollAndroidControlCommand();
            return;
        }
        try {
            var marker = Script.require(androidControlMarkerUrl);
            androidControlAvailable = marker.schemaVersion === 1
                && marker.channel === "android-debug-file-v1"
                && marker.probe === "overte_e2e_probe.js";
            if (androidControlAvailable && typeof marker.processId === "number"
                    && marker.processId > 0) {
                androidControlProcessId = marker.processId;
            }
        } catch (error) {
            androidControlAvailable = false;
        }
        pollAndroidControlCommand();
    }

    function pollSoundCommand() {
        if (!soundCommandUrl || soundCommandRequest !== null) {
            return;
        }
        var request = new XMLHttpRequest();
        soundCommandRequest = request;
        request.onreadystatechange = function () {
            if (request.readyState !== request.DONE) {
                return;
            }
            soundCommandRequest = null;
            if (request.status === 200) {
                try {
                    applySoundCommand(JSON.parse(request.responseText));
                } catch (error) {
                    print("OVERTE_E2E_SOUND_COMMAND_ERROR " + safeErrorText(error));
                }
            }
        };
        request.open("GET", soundCommandUrl);
        request.send();
    }

    function normalizeInitialFlightState() {
        if (flightNormalizationAllowed && !flightNormalizationActive
                && MyAvatar.isFlying()) {
            flyingEnabledBeforeNormalization = Boolean(MyAvatar.getFlyingEnabled());
            flightNormalizationActive = true;
            flightNormalizationStableSamples = 0;
            MyAvatar.setFlyingEnabled(false);
            print("OVERTE_E2E_FLIGHT_NORMALIZATION stage=started");
        }
        if (!flightNormalizationActive) {
            return;
        }
        if (!MyAvatar.isInAir() && !MyAvatar.isFlying()) {
            flightNormalizationStableSamples += 1;
        } else {
            flightNormalizationStableSamples = 0;
        }
        if (flightNormalizationStableSamples >= 2) {
            MyAvatar.setFlyingEnabled(flyingEnabledBeforeNormalization);
            flightNormalizationActive = false;
            flightNormalizationAllowed = false;
            print("OVERTE_E2E_FLIGHT_NORMALIZATION stage=completed");
        }
    }

    function observeVerticalMotion(observation) {
        observation = observation || {
            y: Number(MyAvatar.position.y),
            inAir: Boolean(MyAvatar.isInAir()),
            flying: Boolean(MyAvatar.isFlying())
        };
        if (!sceneReady || flightNormalizationAllowed || flightNormalizationActive) {
            verticalObservationPrevious = observation;
            verticalJumpActive = false;
            return;
        }
        if (verticalObservationPrevious === null) {
            verticalObservationPrevious = observation;
            return;
        }

        if (observation.flying && !verticalObservationPrevious.flying) {
            verticalEvents.flightCount += 1;
            verticalEvents.lastFlightStartY = verticalObservationPrevious.y;
            verticalEvents.lastFlightPeakY = Math.max(
                verticalObservationPrevious.y, observation.y);
        } else if (observation.flying && verticalEvents.lastFlightPeakY !== null) {
            verticalEvents.lastFlightPeakY = Math.max(
                verticalEvents.lastFlightPeakY, observation.y);
        }

        if (observation.inAir && !observation.flying
                && (!verticalObservationPrevious.inAir
                    || verticalObservationPrevious.flying)) {
            verticalEvents.jumpCount += 1;
            verticalEvents.lastJumpStartY = verticalObservationPrevious.y;
            verticalEvents.lastJumpPeakY = Math.max(
                verticalObservationPrevious.y, observation.y);
            verticalEvents.lastJumpLandingY = null;
            verticalJumpActive = true;
        }
        if (verticalJumpActive && observation.inAir && !observation.flying) {
            verticalEvents.lastJumpPeakY = Math.max(
                verticalEvents.lastJumpPeakY, observation.y);
        } else if (verticalJumpActive && !observation.inAir) {
            verticalEvents.jumpCompletedCount = verticalEvents.jumpCount;
            verticalEvents.lastJumpLandingY = observation.y;
            verticalJumpActive = false;
        } else if (verticalJumpActive && observation.flying) {
            verticalJumpActive = false;
        }
        verticalObservationPrevious = observation;
    }

    function consumeNativeMotion(history, now) {
        if (!androidControlProcessId || !history || history.schemaVersion !== 1
                || history.processId !== androidControlProcessId
                || history.source !== "native-avatar-motion"
                || !Array.isArray(history.samples)
                || typeof history.updatedEpochMs !== "number"
                || !isFinite(history.updatedEpochMs)
                || history.updatedEpochMs > now + 1000
                || now - history.updatedEpochMs > 5000) {
            return;
        }
        history.samples.forEach(function (entry) {
            var motion = entry.avatarMotion;
            if (typeof entry.sampleSequence !== "number"
                    || !isFinite(entry.sampleSequence)
                    || entry.sampleSequence <= nativeMotionLastSequence
                    || typeof entry.sampleEpochMs !== "number"
                    || !isFinite(entry.sampleEpochMs)
                    || entry.sampleEpochMs > now + 1000
                    || now - entry.sampleEpochMs > 5000
                    || !motion || !motion.position
                    || typeof motion.position.y !== "number"
                    || !isFinite(motion.position.y)
                    || typeof motion.inAir !== "boolean"
                    || typeof motion.flying !== "boolean") {
                return;
            }
            nativeMotionLastSequence = entry.sampleSequence;
            nativeMotionUpdatedEpochMs = entry.sampleEpochMs;
            nativeMotionAvailable = true;
            observeVerticalMotion({ y: motion.position.y,
                inAir: motion.inAir, flying: motion.flying });
        });
    }

    function pollNativeMotion(now) {
        if (!androidControlProcessId || now - nativeMotionLastRequestEpochMs < 500) {
            return;
        }
        nativeMotionLastRequestEpochMs = now;
        var moduleId = nativeMotionUrl + "?sample=" + now;
        try {
            // The fixed private-file loader is supported by the Android script
            // engine; local XMLHttpRequest does not complete on this runtime.
            consumeNativeMotion(Script.require(moduleId), Date.now());
        } catch (error) {
            // Missing or malformed observations cannot produce events.
        } finally {
            // Each fresh URL is a one-use observation, not a persistent module.
            // Release only our own entry; preserve all other script modules.
            try {
                delete Script.require.cache[Script.require.resolve(moduleId)];
            } catch (error) {
                // An unavailable native source has no resolvable cache entry.
            }
        }
    }

    function sample(now, verticalObservationMs) {
        var phaseEpochMs = Date.now();
        var timing = { schemaVersion: 1, startedEpochMs: phaseEpochMs,
            processId: androidControlProcessId,
            previousSampleIntervalMs: lastCompletedSampleEpochMs
                ? now - lastCompletedSampleEpochMs : null,
            verticalMotionObservationMs: verticalObservationMs, phasesMs: {} };
        function phase(name) {
            var completed = Date.now();
            timing.phasesMs[name] = completed - phaseEpochMs;
            phaseEpochMs = completed;
            timing.completedPhase = name;
            timing.updatedEpochMs = completed;
            if (androidControlAvailable) {
                Test.saveObject(timing, "pico-probe-timing-in-progress.json");
            }
        }
        pollAndroidControlMarker();
        var nativePad = Controller.Hardware.TouchscreenVirtualPad;
        if (androidControlAvailable && nativePad) {
            var touch = {
                epochMs: now, cameraMode: String(Camera.mode),
                lx: Number(Controller.getValue(nativePad.LX)),
                ly: Number(Controller.getValue(nativePad.LY)),
                translateX: Number(Controller.getValue(Controller.Actions.TranslateX)),
                translateZ: Number(Controller.getValue(Controller.Actions.TranslateZ))
            };
            var lastTouch = phoneTouchHistory.length ? phoneTouchHistory[phoneTouchHistory.length - 1] : null;
            if (!lastTouch || touch.lx !== lastTouch.lx || touch.ly !== lastTouch.ly
                    || touch.translateX !== lastTouch.translateX || touch.translateZ !== lastTouch.translateZ) {
                phoneTouchHistory.push(touch);
                if (phoneTouchHistory.length > 128) { phoneTouchHistory.shift(); }
                Test.saveObject({samples: phoneTouchHistory}, "phone-touch-observation.json");
            }
        }
        pollClientCommand();
        pollSoundCommand();
        phase("controlPolling");
        var currentAddress = String(location.href);
        var currentLocationKey = [String(location.protocol), String(location.hostname),
            String(location.domainID)].join("|");
        if (previousLocationKey !== "" && currentLocationKey !== previousLocationKey) {
            stableEntitySamples = 0;
            previousEntityCount = -1;
            stableAvatarSamples = 0;
            previousAvatarPosition = null;
            sceneReady = false;
            flightNormalizationAllowed = true;
            flightNormalizationStableSamples = 0;
        }
        previousLocationKey = currentLocationKey;
        normalizeInitialFlightState();
        phase("locationAndFlight");
        var ids = Entities.findEntities(MyAvatar.position, 1000.0);
        phase("entitySearch");
        var foundMarkers = {};
        var foundDomainMarkers = {};
        var sharedEntityCount = 0;
        var sharedObservation = null;
        var interactionTargetAvailable = false;
        var scriptedEntity = {
            targetAvailable: false, loaded: false, scriptUrl: "", activationCount: 0,
            state: "unavailable", color: null
        };
        var floorTopY = null;
        var collisionWall = null;
        var index;
        for (index = 0; index < ids.length; index += 1) {
            var properties = Entities.getEntityProperties(ids[index], [
                "name", "position", "dimensions", "script", "userData", "color", "lastEditedBy"
            ]);
            if (fixtureMarkers.indexOf(properties.name) !== -1) {
                foundMarkers[properties.name] = true;
            }
            if (domainMarkers.indexOf(properties.name) !== -1) {
                foundDomainMarkers[properties.name] = true;
            }
            if ((androidControlAvailable || typeof Test.iosNativeUiSnapshot === "function")
                    && properties.name === "OVERTE_E2E_SHARED_COLOR") {
                sharedEntityCount += 1;
                sharedObservation = controlledSharedObservation(properties);
            }
            if (properties.name === "OVERTE_E2E_FLOOR") {
                floorTopY = Number(properties.position.y) + Number(properties.dimensions.y) / 2.0;
            }
            if (properties.name === "OVERTE_E2E_COLLISION_WALL") {
                collisionWall = {
                    name: String(properties.name),
                    center: vector(properties.position),
                    dimensions: vector(properties.dimensions)
                };
            }
            if (properties.name === interactionTargetName) {
                interactionTargetAvailable = true;
                var metadata = null;
                try {
                    metadata = JSON.parse(String(properties.userData));
                } catch (error) {
                    metadata = null;
                }
                scriptedEntity = {
                    targetAvailable: true,
                    loaded: Boolean(metadata && metadata.contract ===
                        "overte-e2e-scripted-entity-v1" && metadata.loaded === true),
                    scriptUrl: String(properties.script),
                    activationCount: metadata && isFinite(Number(metadata.activationCount))
                        ? Math.max(0, Math.floor(Number(metadata.activationCount))) : 0,
                    state: metadata && (metadata.state === "active" || metadata.state === "idle")
                        ? metadata.state : "idle",
                    color: {
                        red: Math.floor(Number(properties.color.red)),
                        green: Math.floor(Number(properties.color.green)),
                        blue: Math.floor(Number(properties.color.blue))
                    }
                };
            }
        }
        phase("entityProperties");
        if (ids.length === previousEntityCount) {
            stableEntitySamples += 1;
        } else {
            stableEntitySamples = 0;
            previousEntityCount = ids.length;
        }
        var markerCount = Object.keys(foundMarkers).length;
        var foundFixtureMarkers = Object.keys(foundMarkers).sort();
        var domainMarkerCount = Object.keys(foundDomainMarkers).length;
        var avatarPosition = vector(MyAvatar.position);
        var avatarFeetPosition = vector(MyAvatar.feetPosition);
        var spawnDeltaX = avatarPosition.x - expectedSpawn.x;
        var spawnDeltaZ = avatarPosition.z - expectedSpawn.z;
        var avatarAtSpawn = spawnDeltaX * spawnDeltaX + spawnDeltaZ * spawnDeltaZ <= 1.0;
        if (previousAvatarPosition !== null) {
            var deltaX = avatarPosition.x - previousAvatarPosition.x;
            var deltaY = avatarPosition.y - previousAvatarPosition.y;
            var deltaZ = avatarPosition.z - previousAvatarPosition.z;
            stableAvatarSamples = (deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ <= 0.0004)
                ? stableAvatarSamples + 1 : 0;
        }
        previousAvatarPosition = avatarPosition;
        spawnDeltaX = avatarPosition.x - expectedSpawn.x;
        spawnDeltaZ = avatarPosition.z - expectedSpawn.z;
        var avatarAboveFloor = floorTopY !== null
            && avatarFeetPosition.y >= floorTopY - 0.05;
        avatarAtSpawn = spawnDeltaX * spawnDeltaX + spawnDeltaZ * spawnDeltaZ <= 1.0;
        if (!sceneReady && markerCount === fixtureMarkers.length && stableEntitySamples >= 3
                && stableAvatarSamples >= 4 && avatarAboveFloor && avatarAtSpawn
                && !flightNormalizationActive && !MyAvatar.isInAir()
                && !MyAvatar.isFlying()) {
            sceneReady = true;
            flightNormalizationAllowed = false;
        }
        var orientation = Quat.safeEulerAngles(Camera.orientation);
        if (soundInjector && !soundState.finished) {
            soundState.playing = Boolean(soundInjector.playing);
            if (soundState.playing) {
                soundState.started = true;
            } else if (soundState.started) {
                soundState.finished = true;
                soundState.finishReason = soundStopRequested ? "stopped" : "natural";
            }
        }
        Test.saveObject(primaryViewObservation(now, sampleSequence + 1), "ios-primary-observation.json");
        phase("avatarAndCamera");
        sampleSequence += 1;
        if (androidControlAvailable) {
            // Separate private evidence keeps real native author identity out
            // of the portable, publishable snapshot. No client entity edit is
            // performed here: all values come from received entity properties.
            Test.saveObject({ schemaVersion: 1, sampleEpochMs: now, sampleSequence: sampleSequence,
                entityCount: sharedEntityCount,
                observation: sharedEntityCount === 1 ? sharedObservation : null }, "phone-collaboration-observation.json");
            Test.saveObject({ schemaVersion: 1, sampleEpochMs: now, sampleSequence: sampleSequence,
                entityCount: sharedEntityCount,
                observation: sharedEntityCount === 1 ? sharedObservation : null }, "pico-collaboration-observation.json");
        }
        // Read-only entity replication evidence. Native author UUIDs remain
        // in this app-private document and never enter the portable probe.
        Test.saveObject({ schemaVersion: 1, sampleEpochMs: now, sampleSequence: sampleSequence,
            entityCount: sharedEntityCount, observation: sharedEntityCount === 1 ? sharedObservation : null
        }, "e2e-collaboration-observation.json");
        if (typeof Test.iosRenderObservation === "function") {
            Test.saveObject(Test.iosRenderObservation(), "ios-render-observation.json");
        }
        if (typeof Tablet.touchUiRuntimeMetrics === "object"
                && Tablet.touchUiRuntimeMetrics !== null) {
            // Independent live UIKit bounds and Qt viewport observations let
            // the host validate real screen-coordinate HID input without
            // asking XCTest to traverse the Qt accessibility window tree.
            Test.saveObject({ schemaVersion: 1, sampleEpochMs: now,
                sampleSequence: sampleSequence,
                nativeUi: Tablet.touchUiRuntimeMetrics,
                window: { width: Number(Window.innerWidth), height: Number(Window.innerHeight) }
            }, "ios-ui-observation.json");
        }
        // The fixture's HTTP echo proves delivery only. This independent
        // device-side receipt is emitted after the real client action; the
        // adapter requires the exact nonce, fresh timestamp and same PID.
        saveClientCommandReceipt(now);
        orientationHistory.push({
            sampleSequence: sampleSequence,
            orientation: vector(orientation)
        });
        if (orientationHistory.length > 48) {
            orientationHistory.shift();
        }
        phase("collaborationSnapshotAndHistory");
        // QVariantMap exposure converts an entire channel directory on every
        // property access. Read each directory once per sample; input values
        // and poses still come from the live Controller API on every query.
        var standardChannels = Controller.Standard;
        var actionChannels = Controller.Actions;
        var hardwareChannels = Controller.Hardware;
        var observedController = {
                route: {
                    openxrAxes: openXrAxes(hardwareChannels.OpenXR),
                    standardLy: Number(Controller.getValue(standardChannels.LY)),
                    translateYAction: Number(Controller.getValue(actionChannels.TranslateY)),
                    rawTranslateYDriveKey: Number(MyAvatar.getRawDriveKey(DriveKeys.TRANSLATE_Y)),
                    translateYDriveKeyDisabled: Boolean(MyAvatar.isDriveKeyDisabled(DriveKeys.TRANSLATE_Y)),
                    translateZAction: Number(Controller.getValue(actionChannels.TranslateZ)),
                    rawTranslateZDriveKey: Number(MyAvatar.getRawDriveKey(DriveKeys.TRANSLATE_Z)),
                    translateZDriveKeyDisabled: Boolean(MyAvatar.isDriveKeyDisabled(DriveKeys.TRANSLATE_Z))
                },
                axes: {
                    lx: Number(Controller.getValue(standardChannels.LX)),
                    ly: Number(Controller.getValue(standardChannels.LY)),
                    rx: Number(Controller.getValue(standardChannels.RX)),
                    ry: Number(Controller.getValue(standardChannels.RY)),
                    leftTrigger: Number(Controller.getValue(standardChannels.LT)),
                    rightTrigger: Number(Controller.getValue(standardChannels.RT)),
                    leftGrip: Number(Controller.getValue(standardChannels.LeftGrip)),
                    rightGrip: Number(Controller.getValue(standardChannels.RightGrip))
                },
                buttons: {
                    menu: Boolean(Controller.getValue(hardwareChannels.OpenXR
                        ? hardwareChannels.OpenXR.Start : standardChannels.Start)),
                    leftPrimary: Boolean(Controller.getValue(standardChannels.LeftPrimaryThumb)),
                    leftSecondary: Boolean(Controller.getValue(standardChannels.LeftSecondaryThumb)),
                    leftThumbstick: Boolean(Controller.getValue(standardChannels.LS)),
                    leftTrigger: Boolean(Controller.getValue(standardChannels.LTClick)),
                    rightPrimary: Boolean(Controller.getValue(standardChannels.RightPrimaryThumb)),
                    rightSecondary: Boolean(Controller.getValue(standardChannels.RightSecondaryThumb)),
                    rightThumbstick: Boolean(Controller.getValue(standardChannels.RS)),
                    rightTrigger: Boolean(Controller.getValue(standardChannels.RTClick))
                },
                poses: {
                    left: controllerPose(standardChannels.LeftHand),
                    right: controllerPose(standardChannels.RightHand)
                }
        };
        phase("controller");
        var probeSnapshot = {
            schemaVersion: 2,
            sampleEpochMs: now,
            sampleSequence: sampleSequence,
            build: {
                platform: String(About.platform),
                version: String(About.buildVersion),
                date: String(About.buildDate)
            },
            application: {
                running: true,
                foreground: Boolean(Window.hasFocus())
            },
            control: androidControlAvailable ? {
                schemaVersion: 1,
                channel: "android-debug-file-v1",
                probe: "overte_e2e_probe.js",
                lastCommandId: lastAndroidControlCommandId
            } : null,
            domain: {
                // File and HTTP(S) serverless scenes report isConnected when
                // their scene is loaded, without a domain server connection.
                connected: Boolean(location.isConnected)
                    && String(location.protocol) !== "file"
                    && String(location.protocol) !== "http"
                    && String(location.protocol) !== "https",
                hostname: String(location.hostname),
                id: String(location.domainID),
                protocol: String(location.protocol),
                serverless: /^(file|http|https)$/.test(String(location.protocol))
            },
            input: effectiveInputState(),
            audio: {
                muted: Boolean(Audio.muted)
            },
            settings: {
                audioWarnWhenMuted: Boolean(Audio.warnWhenMuted)
            },
            render: {
                frameCount: renderFrameCount,
                lastFrameEpochMs: renderLastFrameEpochMs
            },
            scene: {
                url: currentAddress,
                commandId: lastSceneCommandId,
                ready: sceneReady,
                entityCount: ids.length,
                fixtureMarkerCount: markerCount,
                fixtureMarkers: foundFixtureMarkers,
                domainMarkerCount: domainMarkerCount,
                domainMarkers: Object.keys(foundDomainMarkers).sort(),
                floorTopY: floorTopY,
                avatarAboveFloor: avatarAboveFloor,
                spawnLocationObserved: avatarAtSpawn,
                spawnValidated: sceneReady,
                collisionWall: collisionWall
            },
            avatar: {
                position: avatarPosition,
                feetPosition: avatarFeetPosition,
                velocity: vector(MyAvatar.velocity),
                bodyYawDegrees: Number(MyAvatar.bodyYaw),
                inAir: Boolean(MyAvatar.isInAir()),
                flying: Boolean(MyAvatar.isFlying()),
                flyingEnabled: Boolean(MyAvatar.getFlyingEnabled())
            },
            verticalEvents: verticalEvents,
            nativeMotion: { processId: androidControlProcessId,
                sampleSequence: nativeMotionLastSequence,
                sampleEpochMs: nativeMotionUpdatedEpochMs },
            view: {
                orientation: vector(orientation),
                orientationHistory: orientationHistory
            },
            tablet: {
                // tabletShown is explicitly unused in desktop toolbar mode.
                // HMD.showTablet is the application-level ContextMenu state
                // shared by toolbar and world-tablet presentations.
                open: controlledTabletOpen(),
                home: Boolean(tablet.onHomeScreen()),
                toolbarMode: Boolean(tablet.toolbarMode)
            },
            interaction: {
                targetAvailable: interactionTargetAvailable,
                pressCount: interactionPressCount,
                lastEntityName: interactionLastEntityName,
                lastPointerId: interactionLastPointerId
            },
            scriptedEntity: scriptedEntity,
            peer: controlledPeer(),
            controller: observedController,
            asset: observeAsset(ids),
            sound: {
                commandId: soundState.commandId,
                url: soundState.url,
                commandObserved: soundState.commandObserved,
                resourceReady: soundState.resourceReady,
                durationSeconds: soundState.durationSeconds,
                format: soundState.format,
                injectorCreated: soundState.injectorCreated,
                started: soundState.started,
                playing: soundState.playing,
                finished: soundState.finished,
                finishReason: soundState.finishReason
            }
        };
        Test.saveObject(probeSnapshot, "overte-probe.json");
        if (pendingProbeRequestId !== "" && pendingProbeRequestId !== lastProbeResponseId) {
            // Preserve exactly this real sample until the next owned request.
            Test.saveObject({ schemaVersion: 1, commandId: pendingProbeRequestId,
                observation: probeSnapshot }, "ios-probe-request-result.json");
            lastProbeResponseId = pendingProbeRequestId;
        }
        phase("snapshotSerializationAndWrite");
        timing.sampleSequence = sampleSequence;
        timing.completedEpochMs = Date.now();
        lastCompletedSampleEpochMs = now;
        Test.saveObject(timing, "pico-probe-timing.json");
    }

    function updateProbe() {
        var observationStartedMs = Date.now();
        observeDispatcherRay(observationStartedMs);
        // Other Android products also publish the process marker but do not
        // provide the Pico application-thread history. Keep their real direct
        // observations until a valid native source is actually available.
        if (!nativeMotionAvailable) {
            observeVerticalMotion();
        }
        pollNativeMotion(observationStartedMs);
        var now = Date.now();
        if (lastSampleEpochMs !== 0 && now - lastSampleEpochMs < sampleIntervalMs) {
            return;
        }
        lastSampleEpochMs = now;
        try {
            sample(now, now - observationStartedMs);
            lastProbeError = "";
        } catch (error) {
            probeErrorCount += 1;
            var detail = safeErrorText(error);
            Test.saveObject({
                schemaVersion: 1,
                sampleEpochMs: Date.now(),
                sampleSequence: sampleSequence,
                errorCount: probeErrorCount,
                detail: detail
            }, "overte-probe-error.json");
            if (detail !== lastProbeError) {
                print("OVERTE_E2E_PROBE_ERROR " + detail);
                lastProbeError = detail;
            }
        }
        if (lastHeartbeatEpochMs === 0
                || now - lastHeartbeatEpochMs >= heartbeatIntervalMs) {
            print("OVERTE_E2E_PROBE_HEARTBEAT sequence=" + sampleSequence
                + " errors=" + probeErrorCount);
            lastHeartbeatEpochMs = now;
        }
    }

    Script.update.connect(updateProbe);
    Script.scriptEnding.connect(function () {
        completedFrameCommand = null;
        if (completedFrameTimer !== null) { Script.clearTimeout(completedFrameTimer); completedFrameTimer = null; }
        lastAccountProbeCommand = "";
        if (accountProbeTimer !== null) { Script.clearTimeout(accountProbeTimer); accountProbeTimer = null; }
        if (worldRenderTimer !== null) { Script.clearTimeout(worldRenderTimer); worldRenderTimer = null; }
        lastNativeFeatureRequest = "";
        lastScriptWorkRequest = "";
        if (scriptWorkTimer !== null) { Script.clearTimeout(scriptWorkTimer); scriptWorkTimer = null; }
        if (nativeFeatureTimer !== null) { Script.clearTimeout(nativeFeatureTimer); nativeFeatureTimer = null; }
        Script.update.disconnect(updateProbe);
        Script.clearInterval(interactionPointerDiscovery);
        Messages.messageReceived.disconnect(observeDispatcherPointers);
        Messages.unsubscribe(interactionPointerChannel);
        restoreVoice();
        if (controlledTextFixtureActive && typeof Test.uiTest === "function") {
            Test.uiTest({ schemaVersion: 1, commandId: "ffffffffffffffffffffffffffffffff",
                action: "text-fixture", operation: "dismiss" });
            Controller.setVPadHidden(controlledTabletOpen());
            controlledTextFixtureActive = false;
        }
        if (primaryOriginalCameraMode !== null) { Camera.mode = primaryOriginalCameraMode; }
        releaseControlledKey(controlledKeyCommandId);
        Controller.disableMapping(controlledInputMappingName);
        Entities.mousePressOnEntity.disconnect(observePrimaryInteraction);
        if (renderStats && renderStats.newStats) {
            renderStats.newStats.disconnect(observeRenderedFrame);
        }
        if (flightNormalizationActive) {
            MyAvatar.setFlyingEnabled(flyingEnabledBeforeNormalization);
            flightNormalizationActive = false;
        }
        if (controlledTabletOpen()) {
            HMD.closeTablet();
        }
        releaseAssetResource();
        if (androidAssetEntityId !== null) {
            Entities.deleteEntity(androidAssetEntityId);
            androidAssetEntityId = null;
        }
        if (controlledAssetEntity !== null) {
            Entities.deleteEntity(controlledAssetEntity);
            controlledAssetEntity = null;
        }
    });
    updateProbe();
}());
