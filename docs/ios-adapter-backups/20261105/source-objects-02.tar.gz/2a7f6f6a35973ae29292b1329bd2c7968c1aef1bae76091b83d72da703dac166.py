"""PRIVATE/UNRUN. Root actual post-publication map required before target imports."""
from contextlib import ExitStack
import ast
import hashlib
from importlib.machinery import PathFinder
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
RETAINED = HERE / 'retained-first45'
REAL_TEMPORARY_DIRECTORY = tempfile.TemporaryDirectory
OBJECTS, CREATED, CASES = [], [], []
PIN_FIELDS = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_uid', 'st_gid', 'st_size', 'st_mtime_ns', 'st_ctime_ns')


def save(name, value):
    (HERE / name).write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


def process(pid):
    fields = Path('/proc/' + str(pid) + '/stat').read_text().rsplit(') ', 1)[1].split()
    return dict(pid=pid, ppid=int(fields[1]), pgid=int(fields[2]), sid=int(fields[3]), startTicks=int(fields[19]))


def pin(path):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and not path.is_symlink(), str(path)
    return dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                **{name: getattr(value, name) for name in PIN_FIELDS})


def spec_without_import(name):
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:
            assert search is not None,name
    return spec


def verify_before_import():
    # Missing Root evidence fails before target imports, retained-root creation,
    # resolver calls or test loading. No frozen broad pre-Audio map is reused.
    path = Path(os.environ['AUDIO_ORIGIN_ACTUAL_ROOT_MAP']).resolve(strict=True)
    expected_map_sha = os.environ['AUDIO_ORIGIN_ACTUAL_ROOT_MAP_SHA256']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected_map_sha
    actual = json.loads(path.read_text())
    config = json.loads((HERE / 'source-root-final-map.json').read_text())
    assert actual['schemaVersion'] == 1 and actual['worktreeRoot'] == str(REPO)
    root = REPO.stat()
    assert actual['rootIdentity'] == dict(st_dev=root.st_dev, st_ino=root.st_ino)
    assert Path.cwd() == REPO and os.environ.get('PYTHONDONTWRITEBYTECODE') == '1' and sys.dont_write_bytecode
    assert set(actual['targets']) == set(config['targets']) and len(actual['targets']) == 12
    required = set(config['targets']) | {row['path'] for row in config['modules'].values()} | {str(Path(__file__).resolve().relative_to(REPO))}
    assert required <= set(actual['sources'])
    before = {}
    for relative, expected in actual['sources'].items():
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        source = REPO / relative
        assert source.resolve(strict=True) == source
        observed = pin(source)
        assert observed == expected, relative
        before[relative] = observed
    for relative, expected in config['targets'].items():
        assert actual['targets'][relative] == before[relative]['sha256'], relative
        if expected['kind'] == 'exact-reviewed-candidate':
            assert actual['targets'][relative] == expected['sha256'], relative
    # Registry full-file SHAs come from Root's CURRENT map. Merge only our
    # reviewed row/constant and preserve Root changes and seven Photo WIP keys.
    registry = json.loads((REPO / 'tests/device/contract-versions.json').read_text())
    entries = [value for value in registry.values() if type(value) is dict and 'recorded-preview-evidence' in value]
    assert len(entries) == 1
    assert entries[0]['recorded-preview-evidence'] == dict(current=2, reads=[1, 2])
    tree = ast.parse((REPO / 'tests/device/validate_contract_versions.py').read_text())
    values = [value.value for node in ast.walk(tree) if isinstance(node, ast.Dict)
              for key, value in zip(node.keys, node.values)
              if isinstance(key, ast.Constant) and key.value == 'recorded-preview-evidence'
              and isinstance(value, ast.Constant)]
    assert values == [2], values
    assert not any(name.split('.')[0] in config['packageRoots'] for name in sys.modules)
    remaining = []
    for entry in sys.path:
        current = Path(entry or os.getcwd()).resolve()
        if current == REPO or REPO in current.parents:
            continue
        if str(current) not in remaining:
            remaining.append(str(current))
    ordered = [str(REPO / relative) for relative in config['orderedRoots']]
    assert len(ordered) == 3 and str(REPO) not in ordered
    sys.path[:] = ordered + remaining
    for name, relative in config['packageRoots'].items():
        spec = spec_without_import(name)
        assert [str(Path(p).resolve()) for p in spec.submodule_search_locations or ()] == [str(REPO / relative)], name
    for name, expected in config['modules'].items():
        spec = spec_without_import(name)
        source = Path(spec.origin).resolve(strict=True)
        assert source == REPO / expected['path'] and pin(source)['sha256'] == expected['sha256'], name
    save('first45-root-map-verified.json', dict(mapPath=str(path), mapSha256=expected_map_sha,
         sourceCount=len(before), targetCount=12, moduleCount=len(config['modules']), orderedRoots=ordered))
    return path, expected_map_sha, before


def flatten(suite):
    return [name for child in suite for name in flatten(child)] if isinstance(suite, unittest.TestSuite) else [suite.id()]


class Result(unittest.TextTestResult):
    def startTest(self, test):
        super().startTest(test); self.first_root = len(CREATED)
        print('START_CASE', test.id(), flush=True)

    def stopTest(self, test):
        CASES.append(dict(id=test.id(), actualOwnedRoots=CREATED[self.first_root:]))
        super().stopTest(test); print('END_CASE', test.id(), flush=True)


def main():
    save('first45-runner-process.json', process(os.getpid()))
    print('ACTUAL_RUNNER', json.dumps(process(os.getpid())), flush=True)
    map_path, map_sha, sources = verify_before_import()
    from feature_journeys import evidence
    from ios.self_tests import test_ios_audio_recorded_owner as owner_fixture
    from ios.self_tests.retained_host_roots import retain_owned_root
    RETAINED.mkdir(mode=0o700, exist_ok=False)

    def retained_directory(suffix=None, prefix=None, dir=None, *, ignore_cleanup_errors=False, delete=True):
        assert dir is None or Path(dir) == RETAINED
        directory = REAL_TEMPORARY_DIRECTORY(suffix=suffix, prefix=prefix, dir=RETAINED,
            ignore_cleanup_errors=ignore_cleanup_errors, delete=delete)
        root = Path(directory.name); info = root.lstat()
        assert root.parent == RETAINED and stat.S_IMODE(info.st_mode) == 0o700 and info.st_uid == os.geteuid()
        assert retain_owned_root(directory, expected_root=root) == root
        OBJECTS.append(directory); CREATED.append(str(root))
        save('first45-created-roots.json', CREATED)
        return directory

    aliases = SimpleNamespace(TemporaryDirectory=retained_directory)
    names = json.loads((HERE / 'selected-case-ids.json').read_text())
    assert len(names) == len(set(names)) == 45
    loader = unittest.TestLoader(); suite = loader.loadTestsFromNames(names)
    assert not loader.errors, loader.errors
    selected = flatten(suite); assert selected == names and len(set(selected)) == 45
    save('first45-selected-ids-actual.json', selected)
    result = None
    try:
        with ExitStack() as stack:
            for module in (owner_fixture, evidence):
                stack.enter_context(patch.object(module, 'tempfile', aliases))
            result = unittest.TextTestRunner(verbosity=2, failfast=True, resultclass=Result).run(suite)
    finally:
        imported = {}
        for name, module in tuple(sys.modules.items()):
            filename = getattr(module, '__file__', None)
            if filename is not None:
                source = Path(filename).resolve()
                if REPO in source.parents:
                    relative = str(source.relative_to(REPO)); assert relative in sources, (name, relative)
                    imported[name] = relative
        after = {relative: pin(REPO / relative) for relative in sources}
        assert after == sources
        assert hashlib.sha256(map_path.read_bytes()).hexdigest() == map_sha
        save('first45-imported-sources.json', imported)
        save('first45-source-pins-after.json', after)
        save('first45-test-report.json', dict(testsRun=None if result is None else result.testsRun,
             successful=False if result is None else result.wasSuccessful(), selectedIds=selected,
             caseResults=CASES, actualOwnedRoots=CREATED, expectedRootsNotEvidence=27,
             nativeExecuted=False, deviceQualified=False, physicalADCQualified=False,
             acousticQualified=False, peerQualified=False, wholeFeatureQualified=False))
    return result is None or not result.wasSuccessful()


if __name__ == '__main__':
    raise SystemExit(main())
