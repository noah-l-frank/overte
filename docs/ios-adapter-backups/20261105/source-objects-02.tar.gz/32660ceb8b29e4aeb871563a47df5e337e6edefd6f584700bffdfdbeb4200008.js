"use strict";
(function () {
    var companion = Script.require("./companion.js");
    var marker = Entities.addEntity({
        type: "Web", name: "e2e-cccccccccccccccccccccccccccccccc-script",
        userData: "{\"kind\":\"avatar-marker-v1\",\"nonce\":\"86a7547346b89250797f65bfa7e4ab85\",\"runId\":\"cccccccccccccccccccccccccccccccc\"}",
        position: Vec3.sum(MyAvatar.position,
            Vec3.multiplyQbyV(MyAvatar.orientation, {x: 0, y: 1.6, z: -3})),
        rotation: MyAvatar.orientation,
        dimensions: {x: 1.6, y: 0.4, z: 0.01},
        sourceUrl: "https://localhost:43879/feature-fixture/v1/runs/cccccccccccccccccccccccccccccccc/tickets/bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb/graphics-marker.v1.html", visible: true, collisionless: true, dpi: 100
    }, "local");
    Script.scriptEnding.connect(function () {
        if (marker) { Entities.deleteEntity(marker); }
    });
}());
