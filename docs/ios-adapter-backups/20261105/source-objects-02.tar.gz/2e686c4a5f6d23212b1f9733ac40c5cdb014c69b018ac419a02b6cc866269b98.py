"""Real shared-memory/Tracker resources and genuine original finalization."""
from pathlib import Path
import errno,multiprocessing as mp,multiprocessing.connection as connection
import multiprocessing.heap as heap,multiprocessing.resource_tracker as tracker
import multiprocessing.synchronize as synchronize,multiprocessing.util as util
import multiprocessing.popen_fork as fork_popen
import os,stat,sys,threading
from tablet_constructor_custody import FunctionBinding,CustodyRefusal
from .common import fds,kernel
class OriginalMPLifetime:
 def __init__(self,arena,ipc,spawn,save_original):
  self.arena,self.ipc,self.spawn=arena,ipc,spawn;self.save_original=FunctionBinding(save_original)
  self.semaphore=FunctionBinding(synchronize.SemLock.__init__);self.semaphore_rows=[]
  self.tracker_launch=FunctionBinding(tracker.ResourceTracker._launch)
  self.finalize=FunctionBinding(util.Finalize.__call__);self.run_finalizers=FunctionBinding(util._run_finalizers)
  self.original_registry=util._finalizer_registry;assert not self.original_registry and not self.cleanup_errors
  self.cleanup_errors=[];self.cleanup_returns=[];self.after_finalizers=False
  self.signal=FunctionBinding(fork_popen.Popen._send_signal);self.signals=[]
 def semaphore_returned(self,frame,value):
  self.semaphore.frame(frame);owner=frame.f_locals['self'];actual=owner._semlock
  assert actual.name is not None
  path=Path('/dev/shm')/('sem.'+actual.name.lstrip('/'));info=path.lstat()
  row=dict(owner=owner,name=actual.name,path=str(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode,uid=info.st_uid,parentPID=os.getpid())
  self.semaphore_rows.append(row);self.save_original.guard()
  self.save_original.function('semaphore-'+str(len(self.semaphore_rows))+'-original.json',{k:v for k,v in row.items()if k!='owner'})
 def tracker_returned(self,frame,value):
  self.tracker_launch.frame(frame);assert frame.f_locals['self']is tracker._resource_tracker
  self.ipc.bind_tracker_return(frame)
  born=next(row for row in self.spawn.records if row['role']=='tracker')
  assert tracker._resource_tracker._pid==born['kernel']['pid']
 def finalize_returned(self,frame,value):
  self.finalize.frame(frame)
  if self.after_finalizers:self.cleanup_returns.append(dict(actualFinalizerKey=repr(frame.f_locals['self']._key),returnedNormally=True))
 def finalize_unwound(self,frame,error):
  self.finalize.frame(frame)
  if self.after_finalizers:self.cleanup_errors.append(dict(type=type(error).__name__,message=str(error)))
 def actor_signal(self,args,frame):
  self.signal.frame(frame);owner=frame.f_locals['self'];pid,sig=args
  actual=next(row for row in self.spawn.records if row['role']=='actor')
  assert owner.pid==pid==actual['kernel']['pid']and sig==frame.f_locals['sig']
  row=kernel(pid);assert row is not None and row['startTicks']==actual['kernel']['startTicks']
  self.signals.append(dict(pid=pid,signal=int(sig),originalActorCleanup=True))
 def retire_original_stdlib(self):
  # Called only after the real selected unittest cleanup. No product state,
  # sample, clock or Original is rewritten. The Heap may retain mmap FDs.
  assert util._finalizer_registry is self.original_registry
  actors=[row for row in self.spawn.records if row['role']=='actor']
  assert len(actors)==1 and kernel(actors[0]['kernel']['pid'])is None
  self.run_finalizers.guard();self.after_finalizers=True
  self.run_finalizers.function()
  assert not self.original_registry and not self.cleanup_errors
  for row in self.semaphore_rows:assert not Path(row['path']).exists()
  resource=tracker._resource_tracker;oldpid=resource._pid
  if oldpid is not None:resource._stop(wait_timeout=1)
  assert oldpid is not None and kernel(oldpid)is None and resource._pid is None and resource._fd is None and resource._exitcode==0
  # All extra live descriptors must have the actual observed Arena inode.
  allowed={(row['device'],row['inode'])for owner,buffer,row in self.arena.arenas}
  live={fd:row for fd,row in fds().items()if(row['device'],row['inode'])in allowed}
  return dict(originalFinalizersInvoked=True,actualRegistryEmpty=True,
   actualSemaphores=[{k:v for k,v in row.items()if k!='owner'}for row in self.semaphore_rows],
   actualSemaphoreNamesAbsent=True,actualOriginalTrackerPID=oldpid,actualOriginalTrackerExitCode=resource._exitcode,trackerKernelAbsent=True,
   actualCachedArenaDescriptors=live,cachedArenaRetirementBoundary='actual runner process exit',
   actualOriginalActorCleanupSignals=list(self.signals),allSharedMemoryClaimedClosedInsideRunner=False)
