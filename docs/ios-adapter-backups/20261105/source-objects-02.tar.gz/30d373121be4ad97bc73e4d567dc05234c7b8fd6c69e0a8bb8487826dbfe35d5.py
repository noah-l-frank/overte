"""Root-owned single fixed-cap supervisor; full source pins and actual originals."""
from pathlib import Path
import json,os,stat,subprocess,sys,tempfile,time
from run_metadata import HERE,REPO,originals,pin,proc,publication,save,sha,sources,validate_frozen,prior_originals,completed_prior_rows
assert len(sys.argv)==2 and sys.argv[1] in ('consumer8','legacy22','rooted5')
kind=sys.argv[1];plan=validate_frozen();plan=dict(plan,priorOriginalCorpora=completed_prior_rows(plan),pendingCompletedWorldReports=[]);selected=plan['suites'][kind];publication()
ready_path=HERE/(kind+'-publication-ready-source-map.json');approved=json.loads(ready_path.read_text());ready_pin=pin(ready_path)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
reportpath=HERE/(kind+'-report.json');logpath=HERE/(kind+'-first.log')
assert not reportpath.exists() and not logpath.exists(),'No unchanged repeat'
before=sources(plan);assert before==approved['sourcePins'],'Actual sources differ from reviewed post-publication map'
assert 'interface/src/main.cpp' in before
save(HERE/(kind+'-source-before.json'),before)
prior_before=prior_originals(plan);save(HERE/(kind+'-prior-originals-before.json'),prior_before)
runs=HERE/'runs'/kind;runs.mkdir(mode=0o700,parents=True,exist_ok=True)
runroot=Path(tempfile.mkdtemp(prefix='first-',dir=runs));runroot.chmod(0o700)
temporary=runroot/'temporary';temporary.mkdir(mode=0o700)
environment=os.environ.copy();environment.update(PYTHONDONTWRITEBYTECODE='1',
    PYTHONPATH='tests/device:tests/device/self_tests:tests/device/ios/self_tests',
    TMPDIR=str(temporary),OVERTE_EMOTE_FRAME_CONTEXT_RUN_ROOT=str(runroot))
command=['timeout','--signal=TERM','--kill-after='+str(selected['killAfterSeconds'])+'s',
    str(selected['initialTimeoutSeconds'])+'s',sys.executable,str(HERE/'run-selected.py'),kind]
print('SOURCE_LAUNCHER_REFERENCE_PINS',len(before),flush=True);started=time.monotonic()
with logpath.open('x') as log:
    task=subprocess.Popen(command,cwd=REPO,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    binding=proc(task.pid);assert binding is not None and binding['session']==task.pid and binding['processGroup']==task.pid
    save(HERE/(kind+'-process-binding.json'),dict(supervisor=proc(os.getpid()),task=binding,command=command))
    print('ACTUAL_PROCESS',json.dumps(binding,sort_keys=True),flush=True);code=task.wait()
# Full stop checks and preserved originals run also after failure/timeout.
after=sources(plan);save(HERE/(kind+'-source-after.json'),after)
def owned_processes():
    found=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        value=proc(int(path.name))
        if value is not None and (value['session']==task.pid or value['processGroup']==task.pid):found.append(value)
    runnerpath=runroot/'runner-process-binding.json'
    if runnerpath.exists():
        runner=json.loads(runnerpath.read_text());current=proc(runner['pid'])
        if current is not None and current['startTicks']==runner['startTicks'] and current not in found:found.append(current)
    return found
# Establish process absence BEFORE the purported post-stop censuses, then recheck.
remaining_before=owned_processes()
first=originals(temporary);save(HERE/(kind+'-originals-first.json'),first)
prior_first=prior_originals(plan);save(HERE/(kind+'-prior-originals-first.json'),prior_first)
second=originals(temporary);save(HERE/(kind+'-originals-second.json'),second)
prior_second=prior_originals(plan);save(HERE/(kind+'-prior-originals-second.json'),prior_second)
remaining=owned_processes()
runnerpath=runroot/'runner-process-binding.json';runner=json.loads(runnerpath.read_text()) if runnerpath.exists() else None
report=dict(kind=kind,exitCode=code,seconds=time.monotonic()-started,runRoot=str(runroot),
    initialTimeoutSeconds=selected['initialTimeoutSeconds'],killAfterSeconds=selected['killAfterSeconds'],
    sourceLauncherReferencePins=len(after),mainCppPinned=True,allPinsEqual=before==after,
    publicationReadyMapUnchanged=pin(ready_path)==ready_pin,postStopOriginalCensusesEqual=first==second,
    priorOriginalCensusesUnchanged=prior_before==prior_first==prior_second,priorCorpora=len(plan['priorOriginalCorpora']),priorFiles=sum(row['files'] for row in plan['priorOriginalCorpora']),ownedProcessesBeforeCensuses=remaining_before,postStopCensusesQualified=not remaining_before and not remaining,
    originalFiles=sum(stat.S_ISREG(row['st_mode']) for row in first.values()),remainingOwnedProcesses=remaining,
    taskBinding=binding,runnerBinding=runner,nativeCompiled=False,sdkExecuted=False,deviceQualified=False,
    wholeEmoteQualified=False,worldV7Qualified=False,nativeDeviceQualified=False)
save(reportpath,report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
assert before==after and pin(ready_path)==ready_pin,'Source/launcher/map drift'
assert first==second,'Retained originals changed after process stop'
assert prior_before==prior_first==prior_second,'Prior World originals changed'
assert not remaining_before and not remaining,'Owned process group/session/runner remained live around censuses'
raise SystemExit(code)
