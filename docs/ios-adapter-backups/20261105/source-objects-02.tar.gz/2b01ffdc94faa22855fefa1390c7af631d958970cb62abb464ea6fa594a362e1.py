"""Source-model diagnostic binding, never installed/auth/native authority."""
from __future__ import annotations
import ast,hashlib,json,marshal,os,stat,uuid
from pathlib import Path

def execute_original(tree,namespace,source_path,expected,label):
    path=Path(source_path);before=path.stat();raw=path.read_bytes()
    if path.is_symlink() or path.resolve()!=path or hashlib.sha256(raw).hexdigest()!=expected:
        raise RuntimeError('Actual original source byte pin changed')
    selected=ast.dump(tree,include_attributes=False).encode();code=compile(ast.fix_missing_locations(tree),str(path),'exec')
    root=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT']);info=root.lstat()
    if not root.is_absolute() or root.resolve()!=root or not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.geteuid() or stat.S_IMODE(info.st_mode)!=0o700:
        raise RuntimeError('Owned code-binding output required')
    value=dict(profile='source-model-compiled-before-exec',label=label,sourcePath=str(path),sourceSha256=expected,
        selectedAstSha256=hashlib.sha256(selected).hexdigest(),compiledCodeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest(),
        sdkImported=False,authQualified=False,nativeQualified=False)
    fd=os.open(root/(uuid.uuid4().hex+'.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as stream:json.dump(value,stream,sort_keys=True);stream.write('\n')
    exec(code,namespace)
    after=path.stat();keys=('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected or any(getattr(before,k)!=getattr(after,k) for k in keys):
        raise RuntimeError('Source changed during actual model exec')
