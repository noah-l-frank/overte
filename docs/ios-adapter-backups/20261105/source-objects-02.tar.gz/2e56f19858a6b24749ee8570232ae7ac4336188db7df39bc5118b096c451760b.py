from pathlib import Path
import ast,hashlib,json,difflib
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';S=Path('/usr/local/lib/overte-ios-remotexpc/5.15.3-r12/appium');P=T/'lifecycle-original-owner-appium-assembly-proposal-20261028';P.mkdir(mode=0o700)
h=lambda b:hashlib.sha256(b).hexdigest()
base=T/'lifecycle-original-owner-python-closure-overlay-20261028/candidate/repo/tests/device/ios/remotexpc_tunnel.py'
mirror=T/'lifecycle-original-owner-loaded-mirrors-20261028';m=json.loads((mirror/'manifest.json').read_text());rows=[]
for row in m['files']:
 rows.append((row['path'],Path(row['candidate']),row['sourceSHA256']))
rows += [('node_modules/appium-ios-remotexpc/scripts/tunnel-creation.mjs',T/'lifecycle-original-owner-route-draft-20261028/candidates/node-sdk/scripts/tunnel-creation.mjs',h((S/'node_modules/appium-ios-remotexpc/scripts/tunnel-creation.mjs').read_bytes())),('node_modules/appium-ios-remotexpc/scripts/lib/userspace-keeper.mjs',T/'lifecycle-original-owner-python-packaging-proposal-20261028/candidate/node-sdk/scripts/lib/userspace-keeper.mjs',None)]
assert len(rows)==23 and len({x[0] for x in rows})==23
sources=[]
for rel,pin,old in rows:
 b=pin.read_bytes();payload='source-patches/original-owner-appium/'+rel
 q=P/'candidate/repo/tests/device/ios'/payload;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 sources.append(dict(path=rel,originalSha256=old,payload=payload,payloadSha256=h(b)))
profile=dict(sourceProfileVersion=1,sources=sources)
q=P/'candidate/repo/tests/device/ios/original-owner-appium-sources.json';q.write_text(json.dumps(profile,indent=2)+'\n')
expected=repr(sorted(x['path'] for x in sources))
code='''def assemble_original_owner_appium(arguments: argparse.Namespace) -> int:
    """Source-only copy into private scratch; never load, install, or admit it."""
    repo = Path(__file__).resolve().parents[3]
    scratch = repo / ".ios-host-tmp"
    source, destination = arguments.source_appium, arguments.destination
    parent = destination.parent
    if (not source.is_absolute() or source.resolve(strict=True) != source
            or not destination.is_absolute() or destination.exists() or destination.is_symlink()
            or parent.resolve(strict=True) != parent or scratch not in (parent, *parent.parents)
            or source == destination or source in destination.parents or destination in source.parents):
        fail("original-owner Appium assembly requires an absent private scratch destination")
    current = parent
    while True:
        value = current.lstat()
        if (current.is_symlink() or not stat.S_ISDIR(value.st_mode)
                or value.st_uid != os.geteuid() or value.st_mode & 0o077):
            fail("original-owner Appium scratch parent is not private and owned")
        if current == scratch:break
        current = current.parent
    if (type(arguments.expected_source_tree_sha256) is not str
            or re.fullmatch("[0-9a-f]{64}", arguments.expected_source_tree_sha256) is None):
        fail("reviewed original Appium source tree pin is required")
    original_tree = tree_sha256(source)
    if original_tree != arguments.expected_source_tree_sha256:
        fail("actual original Appium source tree differs from reviewed source pin")
    manifest_path = Path(__file__).with_name("original-owner-appium-sources.json")
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes)
    expected_paths = set(EXPECTED_PATHS)
    if (type(manifest) is not dict or set(manifest) != {"sourceProfileVersion", "sources"}
            or type(manifest["sourceProfileVersion"]) is not int or manifest["sourceProfileVersion"] != 1
            or type(manifest["sources"]) is not list or len(manifest["sources"]) != len(expected_paths)
            or any(type(row) is not dict for row in manifest["sources"])
            or {row.get("path") for row in manifest["sources"]} != expected_paths):
        fail("unreviewed exact original-owner Appium source inventory")
    payloads = []
    for row in manifest["sources"]:
        if (set(row) != {"path", "originalSha256", "payload", "payloadSha256"}
                or type(row["payloadSha256"]) is not str
                or re.fullmatch("[0-9a-f]{64}", row["payloadSha256"]) is None
                or (row["originalSha256"] is not None and (type(row["originalSha256"]) is not str
                    or re.fullmatch("[0-9a-f]{64}", row["originalSha256"]) is None))):
            fail("invalid original-owner Appium source member")
        relative = Path(row["path"])
        if row["payload"] != str(Path("source-patches/original-owner-appium") / relative):
            fail("unreviewed Appium payload location")
        payload = Path(__file__).parent / row["payload"]
        if payload.is_symlink() or payload.resolve(strict=True) != payload or not payload.is_file():
            fail("Appium source payload is not an ordinary original")
        if file_sha256(payload) != row["payloadSha256"]:
            fail("Appium source payload changed")
        original = source / relative
        if row["originalSha256"] is None:
            if original.exists() or original.is_symlink():fail("new Appium source member already exists")
        elif not original.is_file() or file_sha256(original) != row["originalSha256"]:
            fail("original Appium source member changed")
        payloads.append((row, payload))
    copy_plain_tree(source, destination)
    if tree_sha256(destination) != original_tree:fail("copied original Appium tree changed")
    for row, payload in payloads:
        target = destination / row["path"]
        target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        if row["originalSha256"] is None:
            if target.exists() or target.is_symlink():fail("new Appium payload target already exists")
        elif file_sha256(target) != row["originalSha256"]:
            fail("copied original Appium member changed")
        mode = 0o700 if target.exists() and target.stat().st_mode & 0o111 else 0o600
        shutil.copyfile(payload, target);target.chmod(mode)
        if file_sha256(target) != row["payloadSha256"]:fail("copied Appium payload changed")
    if manifest_path.read_bytes() != manifest_bytes or tree_sha256(source) != original_tree:
        fail("original Appium tree or source inventory changed during assembly")
    for row, payload in payloads:
        if file_sha256(payload) != row["payloadSha256"]:fail("Appium source payload changed during assembly")
    assembled_tree = tree_sha256(destination)
    report = dict(originalOwnerAppiumSourceProfileVersion=1, originalTreeSha256=original_tree,
        assembledTreeSha256=assembled_tree, manifestSha256=hashlib.sha256(manifest_bytes).hexdigest(),
        changedSources={row["path"]: row["payloadSha256"] for row, _ in payloads},
        sdkImported=False, sdkInstalled=False, compilerRun=False, lockUpdated=False,
        loadedSourceQualified=False, nativeTouchSupport=False, deviceQualified=False)
    report_path = destination.with_name(destination.name + "-original-owner-appium-source-profile.json")
    descriptor = os.open(report_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "w") as output:
        json.dump(report, output, indent=2, sort_keys=True);output.write("\\n");output.flush();os.fsync(output.fileno())
    print(json.dumps(dict(sourceProfileVersion=1, assembledTreeSha256=assembled_tree,
                         changedSourceFiles=len(payloads), sdkImported=False, sdkInstalled=False)))
    return 0


'''.replace('EXPECTED_PATHS',expected)
s=base.read_text();assert s.count('def require_immutable_tree(')==1;s=s.replace('def require_immutable_tree(',code+'def require_immutable_tree(',1)
a='    assembly_parser = subparsers.add_parser("assemble-original-owner-python")';assert s.count(a)==1;s=s.replace(a,'''    appium_assembly = subparsers.add_parser("assemble-original-owner-appium")
    appium_assembly.add_argument("--source-appium", type=Path, required=True)
    appium_assembly.add_argument("--destination", type=Path, required=True)
    appium_assembly.add_argument("--expected-source-tree-sha256", required=True)
'''+a,1)
a='        if arguments.action == "assemble-original-owner-python":';assert s.count(a)==1;s=s.replace(a,'''        if arguments.action == "assemble-original-owner-appium":
            return assemble_original_owner_appium(arguments)
'''+a,1)
ast.parse(s);out=P/'candidate/repo/tests/device/ios/remotexpc_tunnel.py';out.write_text(s)
(P/'proposal.diff').write_text(''.join(difflib.unified_diff(base.read_text().splitlines(True),s.splitlines(True),fromfile='a/tests/device/ios/remotexpc_tunnel.py',tofile='b/tests/device/ios/remotexpc_tunnel.py')))
(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE SOURCE-ONLY UNRUN',base=str(base),baseSHA256=h(base.read_bytes()),candidate=str(out),candidateSHA256=h(out.read_bytes()),profileSHA256=h(q.read_bytes()),payloads=sources,assemblyExecuted=False,productionGate=False),indent=2)+'\n')
print(str(P),h(out.read_bytes()))
