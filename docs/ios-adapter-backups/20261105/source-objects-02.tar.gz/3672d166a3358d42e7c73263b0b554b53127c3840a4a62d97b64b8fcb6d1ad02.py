"""Offline host process/resource/original preservation verification only."""
from pathlib import Path
import hashlib,json,os,stat,threading

def process_identity(pid):
 if type(pid)is not int or pid<=0:raise ValueError('Invalid process identity PID')
 try:raw=(Path('/proc')/str(pid)/'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):return None
 fields=raw[raw.rfind(')')+2:].split()
 return dict(pid=pid,parent=int(fields[1]),group=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]),state=fields[0])

def process_table():
 rows={}
 for path in Path('/proc').iterdir():
  if not path.name.isdigit():continue
  try:row=process_identity(int(path.name))
  except PermissionError:continue
  if row is not None:rows[row['pid']]=row
 return rows

def observed_owned(identity,table):
 # Only a previously bound actual birth identity may enter this lookup. A
 # fresh per-PID stat closes the table-before-spawn-receipt race; it never
 # admits an arbitrary table PID or changes original ownership identifiers.
 keys={'pid','parent','group','session','startTicks'}
 if type(identity)is not dict or set(identity)!=keys or not all(type(identity[k])is int and identity[k]>0 for k in keys):
  raise ValueError('A complete bound original process identity is required')
 row=table.get(identity['pid']);source='table'
 if row is None:
  source='fresh-pid-after-receipt'
  try:row=process_identity(identity['pid'])
  except(PermissionError,ValueError,IndexError):return 'unobservable',None,source
 if row is None:
  # Do not convert a surviving but unreadable /proc entry into absence.
  return ('unobservable'if Path('/proc',str(identity['pid'])).exists()else'absent'),None,source
 if row['pid']!=identity['pid']:raise ValueError('PID stat lookup identity mismatch')
 if row['startTicks']!=identity['startTicks']:return 'reused',None,source
 return 'present',row,source

def fd_census():
 rows={}
 for path in Path('/proc/self/fd').iterdir():
  try:
   value=os.readlink(path);info=path.stat();rows[path.name]=dict(target=value,device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
  except(FileNotFoundError,ProcessLookupError):pass
 return rows

def thread_census():
 return [dict(ident=t.ident,nativeId=t.native_id,name=t.name,daemon=t.daemon,alive=t.is_alive())for t in threading.enumerate()]

def tree_census(root):
 root=Path(root);rows={}
 def meta(info):
  return dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,uid=info.st_uid,gid=info.st_gid,links=info.st_nlink,bytes=info.st_size,mtimeNs=info.st_mtime_ns,ctimeNs=info.st_ctime_ns)
 def walk(path):
  before=path.lstat();key=str(path.relative_to(root));row=meta(before)
  if stat.S_ISDIR(before.st_mode):
   with os.scandir(path)as entries:names=sorted(item.name for item in entries)
   row['namespace']=names
   for name in names:walk(path/name)
  else:
   assert stat.S_ISREG(before.st_mode)and before.st_nlink==1,'Unexpected original symlink/special/link'
   descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
   with os.fdopen(descriptor,'rb')as stream:
    assert meta(os.fstat(stream.fileno()))==row
    raw=stream.read();assert len(raw)==before.st_size
    assert meta(os.fstat(stream.fileno()))==row
   row['sha256']=hashlib.sha256(raw).hexdigest()
  assert meta(path.lstat())==meta(before),'Original changed during complete census'
  rows[key]=row
 walk(root);return rows

def sdk_original_censuses(root):
 """Read actual saved SDK-close originals; never generate a retirement DTO."""
 found={}
 def visit(value,path):
  if type(value)is dict:
   if type(value.get('iosOriginalKeeperSDKCloseVersion'))is int and value['iosOriginalKeeperSDKCloseVersion']==1:
    raw=json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode();sha=hashlib.sha256(raw).hexdigest()
    found.setdefault(sha,dict(paths=[],original=value))['paths'].append(str(path))
   for child in value.values():visit(child,path)
  elif type(value)is list:
   for child in value:visit(child,path)
 for path in Path(root).rglob('*.json'):
  try:value=json.loads(path.read_bytes())
  except(UnicodeError,json.JSONDecodeError):continue
  visit(value,path)
 rows=[]
 for sha,row in found.items():
  value=row['original'];required=('resourceRetirementEstablished','originalWdaTaskReturned','originalWatcherDone','originalRelayTasksDone',
   'originalSDKTasksDone','originalExecutorThreadsDone','originalThreadCensusOnlyControl','originalRemainingTaskCensusOnlyControlAndEnd',
   'rsdWriterWaitClosedReturned','authenticationWriterWaitClosedReturned','proxyWriterWaitClosedReturned','relayListenerClosed',
   'originalRelayListenerWaitClosedReturned','stackStopReturned','sourceSlotCleared')
  valid=value.get('source')=='ios-original-keeper-process-end-v1'and value.get('canonicalSessionDeleted')is False and all(value.get(k)is True for k in required)
  for key in ('originalListenerSocketFds','originalStreamSocketFds','tunSocketFds'):valid=valid and bool(value.get(key))and all(fd==-1 for fd in value[key])
  valid=valid and bool(value.get('originalHTTPThreads'))and all(t==dict(finished=True,alive=False)for t in value['originalHTTPThreads'])
  valid=valid and bool(value.get('originalAFCServices'))and all(all(s.get(k)is True for k in ('originalCloseReturned','originalTaskDone','serviceSlotCleared','readerSlotCleared'))and s.get('pending')==0 for s in value['originalAFCServices'])
  providers=value.get('providers',[])
  valid=valid and bool(providers)and len({p.get('id')for p in providers})==len(providers)
  valid=valid and all(all(p.get(k)is True for k in ('providerSlotCleared','originalDtxCloseAwaitReturned','originalReaderTaskDone','originalWriterWaitClosedReturned'))
    and p.get('originalSocketFd')==-1 and all(type(p.get(k))is int and p[k]==0 for k in ('channels','services','pendingReplies','pendingOutgoingReplies'))for p in providers)
  controls=value.get('originalControlTasks',[])
  valid=valid and {v.get('kind')for v in controls}=={'reading','stopping'}and all(all(v.get(k)is True for k in ('originalCreatorRegistered','originalReceiverCodeBound','originalLoopBound'))for v in controls)
  rows.append(dict(sha256=sha,paths=sorted(set(row['paths'])),ownerInstance=value.get('ownerInstance'),valid=valid,original=value))
 return rows
