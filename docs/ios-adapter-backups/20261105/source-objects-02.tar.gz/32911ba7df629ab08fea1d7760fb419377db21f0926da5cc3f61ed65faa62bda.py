"""Explicit private source-level iOS feature admission; no automatic target setup."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import os
from pathlib import Path
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.feature_fixture_access import client as fixture_client
from ios.adapters.normal_scripts import configuration as scripts_configuration

VERSION=9
AUDIO_VERSION=11
LIFECYCLE_VERSION=13
READS=(1,2,3,4,5,6,7,8,9,11,13)
WHOLE_SETTINGS={'world-navigation':('worldNavigation','navigation_configuration'),
    'avatar-people':('avatarPeople','avatar_configuration'),
    'world-web':('worldWeb','world_web_configuration'),
    'tablet-web':('tabletWeb','tablet_web_configuration')}
LEGACY_AREAS=frozenset(('scripts','authentication','graphics','create','emotes'))
BASE_AREAS=LEGACY_AREAS|frozenset(WHOLE_SETTINGS)|{'audio'}
AREAS=BASE_AREAS|{'lifecycle-input'}
# Prospective Emote whole admission requires explicit configuration v8.
# Older rooted v6/v7 configurations remain readable and closed; the live roots
# still require the actual typed paired process/SDK end in the complete journey.
COMPLETE_AREAS=frozenset(('scripts','authentication','graphics','create','world-navigation','world-web','emotes'))
OPERATIONS=frozenset('feature.'+area+'.'+kind for area in AREAS for kind in ('act','observe','cleanup'))|frozenset(
    'feature.'+area+'.terminal' for area in set(WHOLE_SETTINGS)|{'emotes','audio','lifecycle-input'})


def configuration(path=None):
    path=os.environ.get('OVERTE_IOS_FEATURE_ADAPTER_CONFIG') if path is None else path
    if path is None:return None
    need(isinstance(path,(str,Path)) and bool(str(path)))
    value=PrivateFeatureState(Path(path)).read()
    validate(value)
    return value


def validate(value):
    if type(value)is dict and type(value.get('iosFeatureAdapterVersion'))is int and value['iosFeatureAdapterVersion']==13:
        from ios.adapters.lifecycle_feature13_configuration import feature13
        return feature13(value,validate)
    if type(value)is dict and type(value.get('iosFeatureAdapterVersion'))is int and value['iosFeatureAdapterVersion']==12:
        from ios.adapters.audio_configuration import feature12
        return feature12(value,validate)
    if type(value) is dict and type(value.get('iosFeatureAdapterVersion')) is int and value['iosFeatureAdapterVersion']==11:
        from ios.adapters.audio_configuration import feature11
        return feature11(value,validate)
    need(type(value) is dict and type(value.get('iosFeatureAdapterVersion')) is int and value['iosFeatureAdapterVersion'] in READS)
    version=value['iosFeatureAdapterVersion']
    exact(value,{'iosFeatureAdapterVersion','areas','fixtureConfig'}|({'graphics'} if version>=2 else set())|({'create'} if version>=3 else set())|({'emotes'} if version>=4 else set())
        |({field for field,_module in WHOLE_SETTINGS.values()} if version>=5 else set())
        |({'emoteCoordinatorVersion'} if version>=6 else set())
        |({'worldWebCoordinatorVersion'} if version>=7 else set())|({'emoteTargets'} if version>=8 else set())
        |({'emotePostControllerFamilyVersion'}if version>=9 else set()))
    allowed=BASE_AREAS-{'audio'} if version>=5 else LEGACY_AREAS if version==4 else LEGACY_AREAS-{'emotes'} if version==3 else LEGACY_AREAS-{'create','emotes'} if version==2 else LEGACY_AREAS-{'graphics','create','emotes'}
    need(type(value['iosFeatureAdapterVersion']) is int
         and type(value['areas']) is list and 1<=len(value['areas'])<=len(BASE_AREAS)
         and all(type(area) is str and area in allowed for area in value['areas'])
         and len(set(value['areas']))==len(value['areas']) and type(value['fixtureConfig']) is str
         and Path(value['fixtureConfig']).is_absolute())
    if version>=2:
        if 'graphics' in value['areas']:
            from ios.adapters.graphics_configuration import settings
            settings(value['graphics'])
        else:need(value['graphics'] is None)
    if version>=3:
        if 'create' in value['areas']:
            from ios.adapters.create_configuration import settings
            settings(value['create'])
        else:need(value['create'] is None)
    if version>=4:
        if 'emotes' in value['areas']:
            from ios.adapters.emote_configuration import settings
            settings(value['emotes'])
        else:need(value['emotes'] is None)
    if version>=6:
        if 'emotes' in value['areas']:
            need(type(value['emoteCoordinatorVersion']) is int and value['emoteCoordinatorVersion']==2)
        else:need(value['emoteCoordinatorVersion'] is None)
    if version>=7:
        if 'world-web' in value['areas']:
            need(type(value['worldWebCoordinatorVersion']) is int and value['worldWebCoordinatorVersion']==1)
        else:need(value['worldWebCoordinatorVersion'] is None)
    if version>=8:
        if 'emotes' in value['areas']:
            from ios.adapters.emote_target_pair import configuration as pair_configuration
            pair=pair_configuration(value['emoteTargets'])
            need(pair['actorTarget']==value['emotes']['actorTarget'] and pair['primaryArtifactRoot']==value['emotes']['artifactRoot'])
        else:need(value['emoteTargets'] is None)
    if version>=9:
        need(value['emotePostControllerFamilyVersion']==1 and type(value['emotePostControllerFamilyVersion'])is int
            if 'emotes'in value['areas']else value['emotePostControllerFamilyVersion']is None)
    if version>=5:
        from importlib import import_module
        for area,(field,module) in WHOLE_SETTINGS.items():
            if area in value['areas']:
                validate_settings=import_module('ios.adapters.'+module).settings
                if area=='avatar-people':validate_settings(value[field],role='primary')
                else:validate_settings(value[field])
            else:need(value[field] is None)
    return value


def capabilities(target):
    config=configuration()
    if config is None:return []
    need(set(config['areas'])<=COMPLETE_AREAS)
    # Reading an old configuration does not upgrade its coordinator or admit
    # rooted terminal ownership. Complete admission remains closed above.
    if 'emotes' in config['areas']:
        need(config['iosFeatureAdapterVersion']>=8 and config['emoteCoordinatorVersion']==2)
        if config['iosFeatureAdapterVersion']in(9,13):
            from ios.adapters.emote_post9_caller import target_flags
            target_flags(target)
    # Prospective whole source admission is an explicit coordinator contract.
    # A readable old configuration cannot silently acquire the terminal/Actor
    # protocol merely because the area has an implementation in this version.
    if 'world-web' in config['areas']:
        need(config['iosFeatureAdapterVersion']>=7 and config['worldWebCoordinatorVersion']==1)
    need(scripts_configuration(target) is not None)
    if 'authentication' in config['areas']:
        from ios.adapters.authentication_origin import origin
        value=target.get('testBuild',{}).get('launchEnvironment',{}).get('HIFI_METAVERSE_URL')
        need(type(value) is str and origin(value+'/feature-fixture/v1')==value)
    return sorted(operation for operation in OPERATIONS if operation.split('.')[1] in config['areas'])


def reader(config):
    validate(config)
    return fixture_client(config['fixtureConfig'])
