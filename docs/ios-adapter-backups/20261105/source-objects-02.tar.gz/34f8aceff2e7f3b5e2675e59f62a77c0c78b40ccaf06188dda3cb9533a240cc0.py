"""Explicit pending actual OwnBoundary admission; no DTO creates authority."""
from pathlib import Path
from prefix_common import REPO,pin,load,sha

def qualified_original(path,digest):
    path=Path(path)
    assert path.is_absolute()and path.resolve(strict=True)==path
    assert path.is_relative_to(REPO/'.ios-host-tmp')and path.name=='freeze.json'
    assert pin(path)['sha256']==digest
    packet=load(path)
    for name,row in packet['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        actual=path.parent/name
        assert pin(actual)['sha256']==(row if type(row)is str else row['sha256'])
    # Root must supply the real completed OwnB3-or-later packet and its actual
    # result/receipt grammar. This WIP cannot infer PASS from a path, a freeze
    # hash, a copied proof, mutable success booleans or the old source review.
    raise RuntimeError('Actual OwnBoundary result join is pending: no prefix metadata admission')
