//
//  main.cpp
//  interface/src
//
//  Copyright 2013 High Fidelity, Inc.
//  Copyright 2022 Overte e.V.
//
//  Distributed under the Apache License, Version 2.0.
//  See the accompanying file LICENSE or http://www.apache.org/licenses/LICENSE-2.0.html
//

#include <QCommandLineParser>
#if !defined(Q_OS_IOS)
#include <QtCore/QProcess>
#endif
#include <QtCore/QProcessEnvironment>
#include <QDebug>
#include <QDir>
#include <QFileInfo>
#include <QLocalSocket>
#include <QLocalServer>
#include <QSharedMemory>
#include <QTranslator>
#include <QStandardPaths>

#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD)
#include <material-networking/IOSAssetsImageReaderPoolObservation.h>
#endif
#include <BuildInfo.h>
#include <SandboxUtils.h>
#include <SharedUtil.h>
#include <NetworkAccessManager.h>
#if (defined(Q_OS_MAC) && !defined(Q_OS_IOS)) || defined(Q_OS_WIN)
#include <gl/GLHelpers.h>
#endif
#include <iostream>
#include <plugins/InputPlugin.h>
#include <plugins/PluginManager.h>
#include <plugins/DisplayPlugin.h>
#include <plugins/CodecPlugin.h>
#include <shared/GlobalAppProperties.h>
#include <shared/IOSRuntimeLogging.h>
#if defined(Q_OS_IOS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
#include "../../ios/development/DevelopmentOverrides.h"
#endif

#ifdef Q_OS_IOS
#include <QtCore/QPluginLoader>
#include <QtCore/QSet>
#include <QtWebView/QtWebView>
#endif

#include "AddressManager.h"
#include "Application.h"
#include "crash-handler/CrashHandler.h"
#include "InterfaceLogging.h"
#include "UserActivityLogger.h"
#include "MainWindow.h"
#include "Profile.h"
#include "LogHandler.h"
#include "RunningMarker.h"

#ifdef Q_OS_IOS
static void logIOSStaticQmlPluginGate() {
    QSet<QString> pluginClasses;
    for (const auto& plugin : QPluginLoader::staticPlugins()) {
        const auto className = plugin.metaData().value(QStringLiteral("className")).toString();
        if (!className.isEmpty()) {
            pluginClasses.insert(className);
        }
    }

    qInfo().nospace()
        << "OVERTE_IOS_QML_PLUGIN_GATE static_plugin_count=" << pluginClasses.size()
        << " qtquick2=" << pluginClasses.contains(QStringLiteral("QtQuick2Plugin"))
        << " qtquick_controls2=" << pluginClasses.contains(QStringLiteral("QtQuickControls2Plugin"))
        << " qtquick_templates2=" << pluginClasses.contains(QStringLiteral("QtQuickTemplates2Plugin"))
        << " qtquick_layouts=" << pluginClasses.contains(QStringLiteral("QtQuickLayoutsPlugin"))
        << " qtqml_models=" << pluginClasses.contains(QStringLiteral("QtQmlModelsPlugin"))
        << " qt5compat_graphical_effects="
        << pluginClasses.contains(QStringLiteral("QtGraphicalEffectsPlugin"))
        << " qt5compat_graphical_effects_private="
        << pluginClasses.contains(QStringLiteral("QtGraphicalEffectsPrivatePlugin"));
}
#endif

#ifdef Q_OS_WIN
#include <Windows.h>
extern "C" {
    typedef int(__stdcall* CHECKMINSPECPROC)();
}
#endif

int main(int argc, const char* argv[]) {
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD)
    overte::e2e::IOSAssetsImageReaderPoolObservation::bootstrap(argc,argv);
#endif
#ifdef Q_OS_IOS
    // Keep the physical-device renderer on the same MoltenVK resource-binding
    // path exercised by the iOS simulator acceptance harness. MoltenVK 1.4.2
    // enables Metal argument buffers by default, but the existing Vulkan
    // descriptor path can leave an argument-buffer resource at GPU address
    // zero on Apple GPU hardware. This must be set before the first Vulkan
    // call; Context::createInstance() verifies the effective MoltenVK value.
    if (!qputenv("MVK_CONFIG_USE_METAL_ARGUMENT_BUFFERS", "0")) {
        qFatal("Unable to disable MoltenVK Metal argument buffers on iOS");
    }
    qInfo().noquote()
        << "OVERTE_IOS_MOLTENVK_CONFIG requested metal_argument_buffers=0 source=application";

    // Qt WebView must select WKWebView before the application object exists.
    QtWebView::initialize();
#endif
#if defined(Q_OS_MAC) && !defined(Q_OS_IOS)
    auto format = getDefaultOpenGLSurfaceFormat();
    // Deal with some weirdness in the chromium context sharing on Mac.
    // The primary share context needs to be 3.2, so that the Chromium will
    // succeed in it's creation of it's command stub contexts.
    format.setVersion(3, 2);
    // This appears to resolve the issues with corrupted fonts on OSX.  No
    // idea why.
    qputenv("QT_ENABLE_GLYPH_CACHE_WORKAROUND", "true");
    // https://i.kym-cdn.com/entries/icons/original/000/008/342/ihave.jpg
    QSurfaceFormat::setDefaultFormat(format);
#endif

    // You can force a specific graphics API with the --graphicsAPI option.  By default we will pick the best available based on the platform.
    // Some systems may fallback to a lower API than requested based on what is supported.
    std::string apiString;
    for (int i = 1; i < argc; ++i) {
        if (std::string(argv[i]) == "--graphicsAPI" && i + 1 < argc) {
            apiString = argv[i + 1];
            break;
        }
    }
    if (!apiString.empty()) {
        if (apiString == "gl45") {
            hifi::properties::setGraphicsAPI(hifi::properties::GraphicsAPI::GL45);
        } else if (apiString == "gl41") {
            hifi::properties::setGraphicsAPI(hifi::properties::GraphicsAPI::GL41);
        } else if (apiString == "gles32") {
            hifi::properties::setGraphicsAPI(hifi::properties::GraphicsAPI::GLES32);
        } else if (apiString == "vulkan") {
            hifi::properties::setGraphicsAPI(hifi::properties::GraphicsAPI::Vulkan);
        } else {
            qWarning() << "Unknown graphics API specified, defaulting to GL4.5:" << QString::fromStdString(apiString);
            hifi::properties::setGraphicsAPI(hifi::properties::GraphicsAPI::GL45);
        }
    } else {
#ifdef Q_OS_IOS
        hifi::properties::setGraphicsAPI(hifi::properties::GraphicsAPI::Vulkan);
#elif defined(Q_OS_MAC)
        hifi::properties::setGraphicsAPI(hifi::properties::GraphicsAPI::GL41);
#elif defined(Q_OS_ANDROID) || (defined(Q_OS_LINUX) && defined(__aarch64__))
        // Use GLES on Android and aarch64 Linux
        hifi::properties::setGraphicsAPI(hifi::properties::GraphicsAPI::GLES32);
#else
        hifi::properties::setGraphicsAPI(hifi::properties::GraphicsAPI::GL45);
#endif
    }

#ifdef Q_OS_WIN
    // Check the minimum GL version as early as possible
    {
        uint16_t available = gl::getAvailableVersion();
        uint16_t required = gl::getRequiredVersion();
        if (gl::getAvailableVersion() < gl::getRequiredVersion()) {
            int availMajor = GL_GET_MAJOR_VERSION(available);
            int availMinor = GL_GET_MINOR_VERSION(available);
            int reqMajor = GL_GET_MAJOR_VERSION(required);
            int reqMinor = GL_GET_MINOR_VERSION(required);
            std::string message = "Interface requires OpenGL " + std::to_string(reqMajor) + "." + std::to_string(reqMinor) + " or higher. Available: " + std::to_string(availMajor) + "." + std::to_string(availMinor);
            MessageBoxA(nullptr, message.c_str(), "Unsupported", MB_OK);
            // GL version logging is currently disabled.  Version checking needs to happen before Application creation, but then the AccountManager + UserActivityLogger aren't set up yet.
    #if 0
            auto accountManager = DependencyManager::get<AccountManager>();
            if (accountManager->isLoggedIn()) {
                UserActivityLogger::getInstance().insufficientGLVersion(glData);
            } else {
                QObject::connect(accountManager.data(), &AccountManager::loginComplete, [glData](){
                    static bool loggedInsufficientGL = false;
                    if (!loggedInsufficientGL) {
                        UserActivityLogger::getInstance().insufficientGLVersion(glData);
                        loggedInsufficientGL = true;
                    }
                });
            }
    #endif
            return -1;
        }
    }
#endif

    // Force-disable subpixel antialiasing on QML distance-field text.
    // An existing override for QSG_DISTANCEFIELD_ANTIALIASING will be respected, and this
    // variable will change nothing if QML_DISABLE_DISTANCEFIELD is set.
    // Qt doesn't seem to have any public API for changing this besides the environment variable.
    // See qtdeclarative/src/quick/scenegraph/qsgdefaultcontext.cpp
    if (
        auto aa = qgetenv("QSG_DISTANCEFIELD_ANTIALIASING");
        aa.isNull() || aa.isEmpty()
    ) {
        qputenv("QSG_DISTANCEFIELD_ANTIALIASING", "gray");
    }

    // Setup QCoreApplication settings, install log message handler
    setupHifiApplication(BuildInfo::INTERFACE_NAME);

    // Journald by default in user applications is probably a bit too modern still.
    LogHandler::getInstance().setShouldUseJournald(false);

    std::vector<const char*> argvExtended(&argv[0], &argv[argc]);
#ifdef Q_OS_ANDROID
    argvExtended.push_back("--suppress-settings-reset");
#endif
    int argcExtended = (int)argvExtended.size();

    QElapsedTimer startupTime;
    startupTime.start();

    QCommandLineParser parser;
    parser.setApplicationDescription("Overte -- A free/libre and open-source virtual worlds client");
    QCommandLineOption helpOption = parser.addHelpOption();
    QCommandLineOption versionOption = parser.addVersionOption();

    QCommandLineOption urlOption(
        "url",
        "Start at specified URL location.",
        "string"
    );
#ifdef Q_OS_IOS
    QCommandLineOption iosWorldEvidenceOption(
        "ios-world-evidence",
        "Emit privacy-bounded iOS world acceptance markers for the fixed CI destinations."
    );
#endif
    QCommandLineOption protocolVersionOption(
        "protocolVersion",
        "Writes the protocol version base64 signature to a file",
        "path"
    );
    QCommandLineOption noUpdaterOption(
        "no-updater",
        "Do not show auto-updater."
    );
    QCommandLineOption checkMinSpecOption(
        "checkMinSpec",
        "Check if machine meets minimum specifications. The program will run if check passes."
    );
    QCommandLineOption runServerOption(
        "runServer",
        "Run the server."
    );
    QCommandLineOption listenPortOption(
        "listenPort",
        "Port to listen on.",
        "port_number"
    );
    QCommandLineOption serverContentPathOption(
        "serverContentPath",
        "Path to find server content.", // What content??
        "path"
    );
    QCommandLineOption overrideAppLocalDataPathOption(
        "cache",
        "Set test cache.",
        "dir"
    );
    QCommandLineOption scriptsOption(
        "scripts",
        "Set path for defaultScripts. These are probably scripts that run automatically. This parameter does not seem to work.",
        "dir"
    );
    QCommandLineOption allowMultipleInstancesOption(
        "allowMultipleInstances",
        "Allow multiple instances to run."
    );
    QCommandLineOption displaysOption(
        "display",
        "Preferred display plugin. Valid options include \"Desktop\", \"OpenXR\", and \"OpenVR (Vive)\". If \"Desktop\" is specified, all VR plugins are disabled.",
        "displays"
    );
    QCommandLineOption disableDisplaysOption(
        "disableDisplayPlugins",
        "Display plugins to disable, separated by commas. Valid options include \"OpenXR\" and \"OpenVR (Vive)\".",
        "string"
    );
    QCommandLineOption disableInputsOption(
        "disableInputPlugins",
        "Input plugins to disable, separated by commas. Valid options include \"SDL2\" (used only for gamepads), \"OpenXR\", and \"OpenVR (Vive)\".",
        "string"
    );
    QCommandLineOption suppressSettingsResetOption(
        "suppress-settings-reset",
        "Suppress the prompt to reset interface settings."
    );
    QCommandLineOption oculusStoreOption(
        "oculus-store",
        "Let the Oculus plugin know if interface was run from the Oculus Store."
    );
    QCommandLineOption standaloneOption(
        "standalone",
        "Emulate a standalone device."
    );
    QCommandLineOption disableWatchdogOption(
        "disableWatchdog",
        "Disable the watchdog thread. The interface will crash on deadlocks."
    );
    QCommandLineOption systemCursorOption(
        "system-cursor",
        "Use the default system cursor."
    );
    QCommandLineOption concurrentDownloadsOption(
        "concurrent-downloads",
        "Maximum concurrent resource downloads. Default is 16, except for Android where it is 4.",
        "integer"
    );
    QCommandLineOption avatarURLOption(
        "avatarURL",
        "Override the avatar U.R.L.",
        "url"
    );
    QCommandLineOption replaceAvatarURLOption(
        "replaceAvatarURL",
        "Replaces the avatar U.R.L. When used with --avatarURL, this takes precedence.",
        "url"
    );
    QCommandLineOption setBookmarkOption(
        "setBookmark",
        "Set bookmark as key=value pair. Including the '=' symbol in either string is unsupported.",
        "string"
    );
    QCommandLineOption forceCrashReportingOption(
        "forceCrashReporting",
        "Force crash reporting to initialize."
    );
    // The documented "--disable-lod" does not seem to exist.
    // Below are undocumented.
    QCommandLineOption noLauncherOption(
       "no-launcher",
       "Supposedly does something for the server, unrelated to the application launcher. The feature may never have been implemented."
    );
    QCommandLineOption overrideScriptsPathOption(
       "overrideScriptsPath",
       "Specifies path to default directory where the application will look for scripts to load.",
       "string"
    );
    QCommandLineOption defaultScriptsOverrideOption(
       "defaultScriptsOverride",
       "Override default script to run automatically on start. Default is \"defaultsScripts.js\".",
       "string"
    );
    QCommandLineOption responseTokensOption(
       "tokens",
       "Set response tokens <json>.",
       "json"
    );
    QCommandLineOption displayNameOption(
       "displayName",
       "Set user display name <string>.",
       "string"
    );
    QCommandLineOption noLoginOption(
       "no-login-suggestion",
       "Do not show log-in dialogue."
    );
    QCommandLineOption traceFileOption(
       "traceFile",
       "Writes a trace to a file in the documents folder. Only works if \"--traceDuration\" is specified.",
       "path"
    );
    QCommandLineOption traceDurationOption(
       "traceDuration",
       "Automatically quit interface after duration. Only works if \"--traceFile\" is specified.",
       "seconds"
    );
    QCommandLineOption clockSkewOption(
       "clockSkew",
       "Forces client instance's clock to skew for demonstration purposes.",
       "integer"
    ); // This should probably be removed.
    QCommandLineOption testScriptOption(
       "testScript",
       "Undocumented. Accepts parameter as U.R.L.",
       "string"
    );
    QCommandLineOption testResultsLocationOption(
       "testResultsLocation",
       "Undocumented",
       "path"
    );
    QCommandLineOption quitWhenFinishedOption(
       "quitWhenFinished",
       "Only works if \"--testScript\" is provided."
    ); // Should probably also be made to work on testResultsLocationOption.
    QCommandLineOption fastHeartbeatOption(
       "fast-heartbeat",
       "Change stats polling interval from 10000ms to 1000ms."
    );
    QCommandLineOption logOption(
        "logOptions",
        "Logging options, comma separated: color,nocolor,process_id,thread_id,milliseconds,keep_repeats,journald,nojournald",
        "options"
    );
    QCommandLineOption getPluginsOption(
        "getPlugins",
        "Print out a list of plugins in JSON"
    );
    QCommandLineOption abortAfterStartupOption(
        "abortAfterStartup",
        "Debug option. Aborts right after startup."
    );
    QCommandLineOption abortAfterInitOption(
        "abortAfterInit",
        "Debug option. Aborts after initialization, right before the program starts running the event loop."
    );
    QCommandLineOption getProtocolVersionHashOption(
        "getProtocolVersionHash",
        "Debug option. Returns the network protocol version MD5 hash."
    );
    QCommandLineOption getProtocolVersionDataOption(
        "getProtocolVersionData",
        "Debug option. Returns the network protocol detailed data in JSON."
    );
    QCommandLineOption useExperimentalXROption(
        "useExperimentalXR",
        "Legacy alias of \"--display=OpenXR\"."
    );
    QCommandLineOption xrNoHandTrackingOption(
        "xrNoHandTracking",
        "Debug option. Disables OpenXR hand tracking, even if it's supported."
    );
    QCommandLineOption xrNoBodyTrackingOption(
        "xrNoBodyTracking",
        "Debug option. Disables OpenXR body tracking, even if it's supported."
    );
    QCommandLineOption xrNoPalmPoseOption(
        "xrNoPalmPose",
        "Debug option. Disables use of the OpenXR palm pose, even if it's supported. Falls back to the controller's grip pose."
    );
    QCommandLineOption graphicsAPIOption(
        "graphicsAPI",
        "Which graphics API to target. Supports gl45, gl41, and gles32. Final API may vary based on system support.",
        "string"
    );

    parser.addOption(urlOption);
#ifdef Q_OS_IOS
    parser.addOption(iosWorldEvidenceOption);
#endif
    parser.addOption(protocolVersionOption);
    parser.addOption(noUpdaterOption);
    parser.addOption(checkMinSpecOption);
    parser.addOption(runServerOption);
    parser.addOption(listenPortOption);
    parser.addOption(serverContentPathOption);
    parser.addOption(overrideAppLocalDataPathOption);
    parser.addOption(scriptsOption);
    parser.addOption(allowMultipleInstancesOption);
    parser.addOption(displaysOption);
    parser.addOption(disableDisplaysOption);
    parser.addOption(disableInputsOption);
    parser.addOption(suppressSettingsResetOption);
    parser.addOption(oculusStoreOption);
    parser.addOption(standaloneOption);
    parser.addOption(disableWatchdogOption);
    parser.addOption(systemCursorOption);
    parser.addOption(concurrentDownloadsOption);
    parser.addOption(avatarURLOption);
    parser.addOption(replaceAvatarURLOption);
    parser.addOption(setBookmarkOption);
    parser.addOption(forceCrashReportingOption);
    parser.addOption(noLauncherOption);
    parser.addOption(responseTokensOption);
    parser.addOption(displayNameOption);
    parser.addOption(noLoginOption);
    parser.addOption(overrideScriptsPathOption);
    parser.addOption(defaultScriptsOverrideOption);
    parser.addOption(traceFileOption);
    parser.addOption(traceDurationOption);
    parser.addOption(clockSkewOption);
    parser.addOption(testScriptOption);
#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(Q_OS_IOS)
    parser.addOption(QCommandLineOption("testSnapshotProvenance", "Observe ordinary main-mono forward Snapshot callback provenance; requires --testScript."));
    parser.addOption(QCommandLineOption("testSnapshotSceneInputs", "Observe same-frame entity render-entry inputs; requires --testScript and --testSnapshotProvenance."));
#endif
    parser.addOption(testResultsLocationOption);
    parser.addOption(quitWhenFinishedOption);
    parser.addOption(fastHeartbeatOption);
    parser.addOption(logOption);
    parser.addOption(abortAfterStartupOption);
    parser.addOption(abortAfterInitOption);
    parser.addOption(getPluginsOption);
    parser.addOption(getProtocolVersionHashOption);
    parser.addOption(getProtocolVersionDataOption);
    parser.addOption(useExperimentalXROption);
    parser.addOption(xrNoHandTrackingOption);
    parser.addOption(xrNoPalmPoseOption);
    parser.addOption(graphicsAPIOption);

    QString applicationPath;
    // A temporary application instance is needed to get the location of the running executable
    // Tests using high_resolution_clock show that this takes about 30-50 microseconds (on my machine, YMMV)
    // If we wanted to avoid the QCoreApplication, we would need to write our own
    // cross-platform implementation.
    {
        QCoreApplication tempApp(argc, const_cast<char**>(argv));

        parser.process(QCoreApplication::arguments());  // Must be run after QCoreApplication is initalised.

#ifdef Q_OS_IOS
        if (parser.isSet(iosWorldEvidenceOption)) {
            QString kind { "unsupported" };
            QString destination { "unsupported" };
            QString requested = parser.value(urlOption).trimmed().toLower();
            if (requested == QStringLiteral("file:///~/serverless/tutorial.json")) {
                kind = QStringLiteral("serverless");
                destination = QStringLiteral("serverless_tutorial");
            } else if (requested == QStringLiteral("hifi://overte_hub") ||
                       requested == QStringLiteral("hifi://overte_hub/")) {
                kind = QStringLiteral("online");
                destination = QStringLiteral("overte_hub");
            }
            logIOSRuntimeMarker("OVERTE_IOS_WORLD_GATE navigation_requested",
                                "kind=", kind,
                                "destination=", destination);
        }
#endif

#ifdef Q_OS_OSX
        if (QFileInfo::exists(QCoreApplication::applicationDirPath() + "/../../../config.json")) {
            applicationPath = QCoreApplication::applicationDirPath() + "/../../../";
        } else {
            applicationPath = QCoreApplication::applicationDirPath();
        }
#else
        applicationPath = QCoreApplication::applicationDirPath();
#endif
    }

    // TODO: We need settings for Application, but Settings needs an Application
    // to handle events. Needs splitting into two parts: enough initialization
    // for Application to work, and then thread start afterwards.
    Setting::init();
#ifdef NDEBUG
    // Fail if asserts are enabled on release build.
    Q_ASSERT_X(false, "Interface", "This is not a debug build, but somehow Q_ASSERTs are enabled. \
               This is known to happen on Windows if QT_NO_DEBUG isn't set by us.");
#endif
    Application app(argcExtended, const_cast<char**>(argvExtended.data()), startupTime);

#ifdef Q_OS_IOS
    logIOSStaticQmlPluginGate();
#endif

    if (parser.isSet("abortAfterStartup")) {
        return 99;
    }

    // We want to configure the logging system as early as possible
    auto& logHandler = LogHandler::getInstance();

    if (parser.isSet(logOption)) {
        if (!logHandler.parseOptions(parser.value(logOption).toUtf8(), logOption.names().first())) {
            QCoreApplication mockApp(argc, const_cast<char**>(argv));  // required for call to showHelp()
            parser.showHelp();
            Q_UNREACHABLE();
        }
    }

    app.initializePluginManager(parser);

    if (parser.isSet(getPluginsOption)) {
        auto pluginManager = PluginManager::getInstance();

        QJsonObject pluginsJson;
        for (const auto &plugin : pluginManager->getPluginInfo()) {
            QJsonObject data;
            data["data"] = plugin.metaData;
            data["loaded"] = plugin.loaded;
            data["disabled"] = plugin.disabled;
            data["filteredOut"] = plugin.filteredOut;
            data["wrongVersion"] = plugin.wrongVersion;
            pluginsJson[plugin.name] = data;
        }

        QJsonObject inputJson;
        for (const auto &plugin : pluginManager->getInputPlugins()) {
            QJsonObject data;
            data["subdeviceNames"] = QJsonArray::fromStringList(plugin->getSubdeviceNames());
            data["deviceName"] = plugin->getDeviceName();
            data["configurable"] = plugin->configurable();
            data["isHandController"] = plugin->isHandController();
            data["isHeadController"] = plugin->isHeadController();
            data["isActive"] = plugin->isActive();
            data["isSupported"] = plugin->isSupported();

            inputJson[plugin->getName()] = data;
        }

        QJsonObject displayJson;
        for (const auto &plugin : pluginManager->getDisplayPlugins()) {
            QJsonObject data;
            data["isHmd"] = plugin->isHmd();
            data["isStereo"] = plugin->isStereo();
            data["targetFramerate"] = plugin->getTargetFrameRate();
            data["hasAsyncReprojection"] = plugin->hasAsyncReprojection();
            data["isActive"] = plugin->isActive();
            data["isSupported"] = plugin->isSupported();

            displayJson[plugin->getName()] = data;
        }

        QJsonObject codecsJson;
        for (const auto &plugin : pluginManager->getCodecPlugins()) {
            QJsonObject data;
            data["isActive"] = plugin->isActive();
            data["isSupported"] = plugin->isSupported();

            codecsJson[plugin->getName()] = data;
        }

        QJsonObject platformsJson;
        platformsJson["steamAvailable"] = (pluginManager->getSteamClientPlugin() != nullptr);
        platformsJson["oculusAvailable"] = (pluginManager->getOculusPlatformPlugin() != nullptr);

        QJsonObject root;
        root["plugins"] = pluginsJson;
        root["inputs"] = inputJson;
        root["displays"] = displayJson;
        root["codecs"] = codecsJson;
        root["platforms"] = platformsJson;

        std::cout << QJsonDocument(root).toJson().toStdString() << "\n";

        return 0;
    }


    // Act on arguments for early termination.
    if (parser.isSet(versionOption)) {
        parser.showVersion();
        Q_UNREACHABLE();
    }
    if (parser.isSet(helpOption)) {
        QCoreApplication mockApp(argc, const_cast<char**>(argv));  // required for call to showHelp()
        parser.showHelp();
        Q_UNREACHABLE();
    }
    if (parser.isSet(protocolVersionOption)) {
        FILE* fp = fopen(parser.value(protocolVersionOption).toStdString().c_str(), "w");
        if (fp) {
            fputs(protocolVersionsSignatureBase64().toStdString().c_str(), fp);
            fclose(fp);
            return 0;
        } else {
            qWarning() << "Failed to open file specified for --protocolVersion.";
            return 1;
        }
    }
    if (parser.isSet(getProtocolVersionHashOption)) {
        std::cout << protocolVersionsSignatureHex().toStdString() << std::endl;
        return 0;
    }
    if (parser.isSet(getProtocolVersionDataOption)) {
        auto protocolMap = protocolVersionsSignatureMap();
        QMetaEnum packetMetaEnum = QMetaEnum::fromType<PacketTypeEnum::Value>();

        QJsonArray packetTypesList;
        auto keyList = protocolMap.keys();
        std::sort(keyList.begin(), keyList.end()); // Sort by numeric value

        for(const auto packet : keyList) {
            QJsonObject data;
            int intValue = static_cast<int>(packet);
            QString keyName = packetMetaEnum.valueToKey(intValue);

            data["name"] = keyName;
            data["value"] = intValue;
            data["version"] = versionForPacketType(packet);

            packetTypesList.append(data);
        }

        std::cout << QJsonDocument(packetTypesList).toJson().toStdString() << std::endl;
        return 0;
    }


    static const QString APPLICATION_CONFIG_FILENAME = "config.json";
    QDir applicationDir(applicationPath);
    QString configFileName = applicationDir.filePath(APPLICATION_CONFIG_FILENAME);
    QFile configFile(configFileName);
    QString launcherPath;
    if (configFile.exists()) {
        if (!configFile.open(QIODevice::ReadOnly)) {
            qWarning() << "Found application config, but could not open it";
        } else {
            auto contents = configFile.readAll();
            QJsonParseError error;

            auto doc = QJsonDocument::fromJson(contents, &error);
            if (error.error) {
                qWarning() << "Found application config, but could not parse it: " << error.errorString();
            } else {
                static const QString LAUNCHER_PATH_KEY = "launcherPath";
                launcherPath = doc.object()[LAUNCHER_PATH_KEY].toString();
                if (!launcherPath.isEmpty()) {
#if !defined(Q_OS_IOS)
                    if (!parser.isSet(noLauncherOption)) {
                        qDebug() << "Found a launcherPath in application config. Starting launcher.";
                        QProcess launcher;
                        launcher.setProgram(launcherPath);
                        launcher.startDetached();
                        return 0;
                    } else {
                        qDebug() << "Found a launcherPath in application config, but the launcher"
                                    " has been suppressed. Continuing normal execution.";
                    }
#endif
                    configFile.close();
                }
            }
        }
    }

    // Early check for --traceFile argument
    auto tracer = DependencyManager::set<tracing::Tracer>();
    const char* traceFile = nullptr;
    float traceDuration = 0.0f;
    if (parser.isSet(traceFileOption)) {
        traceFile = parser.value(traceFileOption).toStdString().c_str();
        if (parser.isSet(traceDurationOption)) {
            traceDuration = parser.value(traceDurationOption).toFloat();
            tracer->startTracing();
        } else {
            qWarning() << "\"--traceDuration\" must be specified along with \"--traceFile\"...";
            return 1;
        }
    }

    PROFILE_SYNC_BEGIN(startup, "main startup", "");

#ifdef Q_OS_LINUX
    QApplication::setAttribute(Qt::AA_DontUseNativeMenuBar);
#endif

#if defined(Q_OS_WIN)
    // Must come after property is set above
    if (hifi::properties::getGraphicsAPI() == hifi::properties::GraphicsAPI::GLES32) {
        // When using GLES on Windows, we can't create normal GL context in Qt, so
        // we force Qt to use angle.  This will cause the QML to be unable to be used
        // in the output window, so QML should be disabled.
        qputenv("QT_ANGLE_PLATFORM", "d3d11");
        QCoreApplication::setAttribute(Qt::AA_UseOpenGLES);
    }
#endif

    // Instance UserActivityLogger now that the settings are loaded
    auto& ual = UserActivityLogger::getInstance();
    auto& ch = CrashHandler::getInstance();

    QObject::connect(&ch, &CrashHandler::enabledChanged, [](bool enabled) {
        Settings s;
        s.beginGroup("Crash");
        s.setValue("ReportingEnabled", enabled);
        s.endGroup();
    });

    // once the settings have been loaded, check if we need to flip the default for UserActivityLogger
    if (!ual.isDisabledSettingSet()) {
        // the user activity logger is opt-out for Interface
        // but it's defaulted to disabled for other targets
        // so we need to enable it here if it has never been disabled by the user
        ual.disable(false);
    }
    qDebug() << "UserActivityLogger is enabled:" << ual.isEnabled();

    if (parser.isSet(forceCrashReportingOption)) {
        qInfo() << "Crash reporting enabled on the command-line";
        ch.setEnabled(true);
    }

    {
        Settings crashSettings;
        crashSettings.beginGroup("Crash");
        if (crashSettings.value("ReportingEnabled").toBool()) {
            ch.setEnabled(true);
        }
        crashSettings.endGroup();
    }

    ch.setAnnotation("program", "interface");

    const QString& applicationName = getInterfaceSharedMemoryName();
    bool instanceMightBeRunning = true;
#ifdef Q_OS_WIN
    // Try to create a shared memory block - if it can't be created, there is an instance of
    // interface already running. We only do this on Windows for now because of the potential
    // for crashed instances to leave behind shared memory instances on unix.
    QSharedMemory sharedMemory{ applicationName };
    instanceMightBeRunning = !sharedMemory.create(1, QSharedMemory::ReadOnly);
#endif

    // allow multiple interfaces to run if this environment variable is set.
    bool allowMultipleInstances = parser.isSet(allowMultipleInstancesOption) ||
                                  QProcessEnvironment::systemEnvironment().contains("HIFI_ALLOW_MULTIPLE_INSTANCES");
    if (allowMultipleInstances) {
        instanceMightBeRunning = false;
    }
    // this needs to be done here in main, as the mechanism for setting the
    // scripts directory appears not to work.  See the bug report (dead link)
    // https://highfidelity.fogbugz.com/f/cases/5759/Issues-changing-scripts-directory-in-ScriptsEngine
#if defined(Q_OS_IOS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && QT_VERSION >= QT_VERSION_CHECK(6, 0, 0)
    const auto developmentScripts = overte::ios::development::initialize(
        QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation),
        QCoreApplication::applicationDirPath() + ':' + overte::ios::development::digest(
            overte::ios::development::read(QCoreApplication::applicationDirPath() + "/Info.plist")));
    if (!developmentScripts.isEmpty()) {
        PathUtils::defaultScriptsLocation(developmentScripts);
    }
#endif
    if (parser.isSet(overrideScriptsPathOption)) {
        QDir scriptsPath(parser.value(overrideScriptsPathOption));
        if (scriptsPath.exists()) {
            PathUtils::defaultScriptsLocation(scriptsPath.path());
        }
    }

    if (instanceMightBeRunning) {
        // Try to connect and send message to existing interface instance
        QLocalSocket socket;

        socket.connectToServer(applicationName);

        static const int LOCAL_SERVER_TIMEOUT_MS = 500;

        // Try to connect - if we can't connect, interface has probably just gone down
        if (socket.waitForConnected(LOCAL_SERVER_TIMEOUT_MS)) {
            if (parser.isSet(urlOption)) {
                QUrl url = QUrl(parser.value(urlOption));
                if (url.isValid() && (url.scheme() == URL_SCHEME_OVERTE || url.scheme() == URL_SCHEME_OVERTEAPP ||
                                      url.scheme() == HIFI_URL_SCHEME_HTTP || url.scheme() == HIFI_URL_SCHEME_HTTPS ||
                                      url.scheme() == HIFI_URL_SCHEME_FILE)) {
                    qDebug() << "Writing URL to local socket";
                    socket.write(url.toString().toUtf8());
                    if (!socket.waitForBytesWritten(5000)) {
                        qDebug() << "Error writing URL to local socket";
                    }
                }
            }

            socket.close();

            qCritical() << "Interface instance appears to be running, exiting";
            qCritical() << "Start with --allowMultipleInstances to allow running multiple instances at once.";

            return EXIT_SUCCESS;
        }

#ifdef Q_OS_WIN
        return EXIT_SUCCESS;
#endif
    }

    // Debug option to demonstrate that the client's local time does not
    // need to be in sync with any other network node. This forces clock
    // skew for the individual client
    if (parser.isSet(clockSkewOption)) {
        const char* clockSkewValue = parser.value(clockSkewOption).toStdString().c_str();
        qint64 clockSkew = atoll(clockSkewValue);
        usecTimestampNowForceClockSkew(clockSkew);
        qCDebug(interfaceapp) << "clockSkewOption=" << clockSkewValue << "clockSkew=" << clockSkew;
    }

    // Oculus initialization MUST PRECEDE OpenGL context creation.
    // The nature of the Application constructor means this has to be either here,
    // or in the main window ctor, before GL startup.
    //app.configurePlugins(parser);

#ifdef Q_OS_WIN
    // If we're running in steam mode, we need to do an explicit check to ensure we're up to the required min spec
    if (parser.isSet(checkMinSpecOption)) {
        QString appPath;
        {
            char filename[MAX_PATH];
            GetModuleFileName(NULL, filename, MAX_PATH);
            QFileInfo appInfo(filename);
            appPath = appInfo.absolutePath();
        }
        QString openvrDllPath = appPath + "/plugins/openvr.dll";
        HMODULE openvrDll;
        CHECKMINSPECPROC checkMinSpecPtr;
        if ((openvrDll = LoadLibrary(openvrDllPath.toLocal8Bit().data())) &&
            (checkMinSpecPtr = (CHECKMINSPECPROC)GetProcAddress(openvrDll, "CheckMinSpec"))) {
            if (!checkMinSpecPtr()) {
                return -1;
            }
        }
    }
#endif

    int exitCode;
    {
        RunningMarker runningMarker("Interface.running");
        bool runningMarkerExisted = runningMarker.fileExists();
        runningMarker.writeRunningMarkerFile();

        bool noUpdater = parser.isSet(noUpdaterOption);
        bool runServer = parser.isSet(runServerOption);
        bool serverContentPathOptionIsSet = parser.isSet(serverContentPathOption);
        QString serverContentPath = serverContentPathOptionIsSet ? parser.value(serverContentPathOption) : QString();
        if (runServer) {
            SandboxUtils::runLocalSandbox(serverContentPath, true, noUpdater);
        }

        PROFILE_SYNC_END(startup, "main startup", "");
        PROFILE_SYNC_BEGIN(startup, "app full ctor", "");
        app.setPreviousSessionCrashed(runningMarkerExisted);
        app.initialize(parser);
        PROFILE_SYNC_END(startup, "app full ctor", "");

#if defined(Q_OS_LINUX)
        app.setWindowIcon(QIcon(PathUtils::resourcesPath() + "images/brand-logo.svg"));
#endif
        ch.startMonitor(&app);


        QTimer exitTimer;
        if (traceDuration > 0.0f) {
            exitTimer.setSingleShot(true);
            QObject::connect(&exitTimer, &QTimer::timeout, &app, &Application::quit);
            exitTimer.start(int(1000 * traceDuration));
        }

        // Setup local server
        QLocalServer server{ &app };

        // We failed to connect to a local server, so we remove any existing servers.
        server.removeServer(applicationName);
        server.listen(applicationName);

        QObject::connect(&server, &QLocalServer::newConnection,
                         &app, &Application::handleLocalServerConnection, Qt::DirectConnection);

        printSystemInformation();

        auto appPointer = dynamic_cast<Application*>(&app);
        if (appPointer) {
            if (parser.isSet(urlOption)) {
                appPointer->overrideEntry();
            }
            if (parser.isSet(displayNameOption)) {
                QString displayName = QString(parser.value(displayNameOption));
                appPointer->forceDisplayName(displayName);
            }
            if (!launcherPath.isEmpty()) {
                appPointer->setConfigFileURL(configFileName);
            }
            if (parser.isSet(responseTokensOption)) {
                QString tokens = QString(parser.value(responseTokensOption));
                appPointer->forceLoginWithTokens(tokens);
            }
        }

        QTranslator translator;
        translator.load("i18n/interface_en");
        app.installTranslator(&translator);
        qCDebug(interfaceapp, "Created QT Application.");
        if (parser.isSet("abortAfterInit")) {
            return 99;
        }
        exitCode = app.exec();
        server.close();

        if (traceFile != nullptr) {
            tracer->stopTracing();
            tracer->serialize(QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/" + traceFile);
        }
    }

    Application::shutdownPlugins();

    qCDebug(interfaceapp, "Normal exit.");
#if !defined(DEBUG) && !defined(Q_OS_LINUX)
    // HACK: exit immediately (don't handle shutdown callbacks) for Release build
    _exit(exitCode);
#endif
    return exitCode;
}
