"""Prospective own counters; author has not imported or run this module."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,json,os,time,unittest
from pathlib import Path
from ios.adapters import emote_callback_live_records as tokens
from ios.adapters import lifecycle_literal_token_instructions as instructions
from test_lifecycle_publication_original_read_phase_models import LifecyclePublicationOriginalReadPhaseModels


class LifecycleLiteralTokenInstructionModels(unittest.TestCase):
    def prepare(self,value):
        refs=[];expected=tokens._token(value,refs,set())
        owner=instructions.LiteralTokenInstructions();plan=owner.compile(expected);owner.seal()
        return owner,plan,expected,refs

    def equivalent(self,owner,plan,expected,value):
        actual=[];other=[];a=b=None
        try:a=('value',tokens._token(value,actual,set())==expected)
        except tokens._Unsupported as error:a=('unsupported',error.kind,error.reason)
        except(AttributeError,TypeError,ValueError,RecursionError)as error:a=('error',type(error),str(error))
        try:b=('value',owner.compare(plan,expected,value,other))
        except tokens._Unsupported as error:b=('unsupported',error.kind,error.reason)
        except(AttributeError,TypeError,ValueError,RecursionError)as error:b=('error',type(error),str(error))
        self.assertEqual(a,b);self.assertEqual([id(v)for v in actual],[id(v)for v in other])
        self.assertTrue(all(a is b for a,b in zip(actual,other)))
        return a

    def test_literal_tree_aliases_preserve_current_outcomes_and_exact_reference_order(self):
        shared={'v':[-0.0,float('nan'),float('inf'),b'x',True,None,2,'2']}
        value={'z':shared,2:(shared,{'nested':[1,2]}),'a':[shared]}
        owner,plan,expected,refs=self.prepare(value);self.assertIsNotNone(plan)
        self.assertEqual(('value',True),self.equivalent(owner,plan,expected,value))
        reordered=dict(reversed(tuple(value.items())))
        self.assertEqual(('value',True),self.equivalent(owner,plan,expected,reordered))
        with self.assertRaises(TypeError):owner.instructions[expected]=None

    def test_each_alias_reads_a_nested_mutation_and_new_unsupported_value_again(self):
        value={'rows':[{'state':'old'}]};owner,plan,expected,_=self.prepare(value)
        self.assertEqual(('value',True),self.equivalent(owner,plan,expected,value))
        value['rows'][0]['state']='changed'
        self.assertEqual(('value',False),self.equivalent(owner,plan,expected,value))
        value['rows'][0]['state']=object()
        self.assertEqual('unsupported',self.equivalent(owner,plan,expected,value)[0])
        value['rows'][0]['state']='old'
        self.assertEqual(('value',True),self.equivalent(owner,plan,expected,value))

    def test_current_recursive_depth_key_and_primitive_types_take_exact_literal_behavior(self):
        value={'rows':[{'v':1}]};owner,plan,expected,_=self.prepare(value)
        for changed in({'rows':[{'v':True}]},{True:1},{1.0:1},{'rows':(1,)},{'extra':object()}):
            self.equivalent(owner,plan,expected,changed)
        recursive=[];recursive.append(recursive)
        self.equivalent(owner,plan,expected,recursive)
        deep=[];current=deep
        for _ in range(34):child=[];current.append(child);current=child
        self.assertEqual(('unsupported',('builtins','list'),'depth'),self.equivalent(owner,plan,expected,deep))
        for original in(recursive,{'notliteral':lambda:None}):
            literal,unsupported_plan,old,_=self.prepare(original)
            self.assertIsNone(unsupported_plan);self.equivalent(literal,unsupported_plan,old,original)

    def test_fallback_never_runs_a_changed_nonliteral_producer_twice(self):
        value={'first':[1],'later':'old'};owner,plan,expected,_=self.prepare(value)
        calls=[]
        class ChangingEnum(tokens.enum.Enum):
            ITEM=1
            @property
            def name(self):
                calls.append('name');value['first'].append(2);return 'ITEM'
        value['later']=ChangingEnum.ITEM
        # Each arm starts with the same actual tree. Only the unchanged tokenizer
        # executes the nonliteral property; the attempted fast prefix cannot.
        actual=[];other=[];value['first'][:]=[1]
        old=tokens._token(value,actual,set());self.assertEqual(['name'],calls)
        calls.clear();value['first'][:]=[1]
        self.assertEqual(old==expected,owner.compare(plan,expected,value,other))
        self.assertEqual(['name'],calls);self.assertEqual([id(v)for v in actual],[id(v)for v in other])

    def test_actual_classifier_mutation_uses_original_path_without_a_scan_result_memo(self):
        value={'v':[1,2]};owner,plan,expected,_=self.prepare(value);old=tokens.FunctionType
        self.assertTrue(owner.compare(plan,expected,value,[]))
        try:
            tokens.FunctionType=list
            self.equivalent(owner,plan,expected,value)
        finally:tokens.FunctionType=old
        self.assertTrue(owner.compare(plan,expected,value,[]))

    def test_same_tokenizer_or_compiler_code_mutation_refuses_before_fast_comparison(self):
        value={'v':[1]};owner,plan,expected,_=self.prepare(value)
        for function in(tokens._token,instructions._compile_literal,instructions._walk_literal,
                instructions.LiteralTokenInstructions.compare,instructions.LiteralTokenInstructions._path):
            original=function.__code__
            def changed(*args,**kwargs):raise AssertionError('changed implementation ran')
            # Mutating compare itself cannot safely enter it; its actual retained
            # bound guard is tested directly before any changed call can occur.
            try:
                function.__code__=changed.__code__
                with self.assertRaises(RuntimeError):owner.bound()
            finally:function.__code__=original
            self.assertTrue(owner.compare(plan,expected,value,[]))


class LifecycleLiteralTokenActualPolicyModels(LifecyclePublicationOriginalReadPhaseModels):
    async def test_passive_actual_literal_instruction_policy_equivalence_without_publisher_post(self):
        await self.primary_api();await self.actor_api(publish=False)
        owner=self.observer;before=self.counts();journal=self.phase_server.journal.snapshot(self.run)
        prefix='phase-publication-lifecycle-input-'+self.run+'-actor'
        self.assertEqual([],journal['entries']);self.assertEqual([],list(owner.store.path.parent.glob(prefix+'*.json')))
        repo=Path.cwd().resolve(strict=True);self.assertEqual('overte-ios-feature-adapters-resume-20261026',repo.name)
        output=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/'passive-literal-token-instruction-profile.json'
        report=dict(version=1,diagnosticOnly=True,completed=False,freshPublishQualified=False,actualPublisherPOSTs=0,
            compilerAppliedToPrivatePolicy=True,scans=[])
        def save():
            self.assertTrue(output.resolve().is_relative_to(repo));output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');output.chmod(0o600)
        def profile():
            policy=owner._publication_parser_policy;self.assertIsNotNone(policy.members);self.assertTrue(policy.admitted())
            report['supported']=True;report['admitted']=True;save()
            prepared=[]
            for (_name,module,members),plans in zip(policy.members,policy.instructions):
                for (member,expected),plan in zip(members,plans):prepared.append((module,member,expected,plan))
            for scan in range(2):
                row=dict(scan=scan+1,members=0,compiledAliases=0,literalSeconds=0.,comparisonSeconds=0.,allOutcomesEqual=True,allReferenceOrdersEqual=True)
                report['scans'].append(row)
                for module,member,expected,plan in prepared:
                    value=vars(module)[member];actual=[];other=[];start=time.perf_counter()
                    old=tokens._token(value,actual,set());row['literalSeconds']+=time.perf_counter()-start;start=time.perf_counter()
                    new=policy.literal.compare(plan,expected,value,other);row['comparisonSeconds']+=time.perf_counter()-start
                    self.assertEqual(old==expected,new,(module.__name__,member))
                    self.assertEqual([id(v)for v in actual],[id(v)for v in other],(module.__name__,member))
                    self.assertTrue(new);row['members']+=1;row['compiledAliases']+=plan is not None
                    if row['members']%128==0:save()
                self.assertTrue(policy.admitted());save()
            from ios.adapters import lifecycle_publication_read_phase as phase_module
            name='_literal_instruction_initial_unsupported_probe'
            self.assertNotIn(name,vars(phase_module))
            try:
                setattr(phase_module,name,object())
                self.assertFalse(policy.admitted()) # New member selects literal.
                unsupported=phase_module.ParserPolicy()
                self.assertIsNone(unsupported.members);self.assertFalse(unsupported.admitted())
            finally:delattr(phase_module,name)
            self.assertTrue(policy.admitted());report['unsupportedInitialRemainsLiteral']=True
        save();await asyncio.to_thread(profile)
        self.assertEqual(before,self.counts());self.assertEqual(journal['entries'],self.phase_server.journal.snapshot(self.run)['entries'])
        self.assertEqual([],list(owner.store.path.parent.glob(prefix+'*.json')))
        report.update(completed=True,noPublisherWALOrPOST=True,countsUnchanged=True);save()
