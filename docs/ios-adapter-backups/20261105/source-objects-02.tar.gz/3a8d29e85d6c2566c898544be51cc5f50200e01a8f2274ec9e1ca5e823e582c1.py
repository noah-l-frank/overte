"""The unchanged common Lifecycle16 actions over existing concrete owners.

Only ticket/input authorization comes from the closed common scenario. Product
state and counters always come from actual original observations elsewhere.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio
from copy import deepcopy
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from feature_journeys.contract import arguments,context,expand
from feature_journeys.scenarios import SCENARIOS
from ios.adapters.lifecycle_editors import LifecycleEditors
from ios.adapters.lifecycle_editors_runtime import IOSLifecycleEditorsRuntime
from ios.adapters.lifecycle_background_runtime import IOSLifecycleBackgroundRuntime
from ios.adapters.lifecycle_world_hold_runtime import IOSLifecycleWorldHoldRuntime
from ios.adapters.lifecycle_restoration import LifecycleRestoration

AREA='lifecycle-input'


class LifecycleActions:
    def __init__(self,store,runtime,selector,editors,restoration,phase):
        need(isinstance(store,PrivateFeatureState) and type(editors) is LifecycleEditors and editors._whole
            and type(restoration) is LifecycleRestoration and restoration.editors is editors
            and type(runtime) is IOSLifecycleEditorsRuntime and phase.area==AREA and phase.run==editors.run)
        self.store,self.runtime,self.selector,self.editors,self.restoration,self.phase=store,runtime,selector,editors,restoration,phase
        self.binding,self.run,self.lock=deepcopy(editors.binding),editors.run,editors.lock
        need(store.path==editors.store.path.with_name('ios-lifecycle-actions.json'))
        self.previous=store.read();self.state=dict(events=[]) if self.previous is None else self.decode(self.previous)
        self.check()

    def envelope(self):return dict(iosLifecycleActionsVersion=1,binding=self.binding,runId=self.run,state=deepcopy(self.state))

    def check(self):
        self.lock.assert_held();self.editors.bound();need(same(self.store.read(),self.previous));return True

    def decode(self,value):
        exact(value,{'iosLifecycleActionsVersion','binding','runId','state'})
        need(type(value['iosLifecycleActionsVersion']) is int and value['iosLifecycleActionsVersion']==1
            and value['binding']==self.binding and value['runId']==self.run);exact(value['state'],{'events'})
        events=value['state']['events'];need(type(events) is list and len(events)<=16);tickets=set()
        for index,event in enumerate(events):
            exact(event,{'call','phase'});call=arguments('feature.'+AREA+'.act',event['call'])
            expected=expand(SCENARIOS[AREA]['steps'][index],context(self.run))
            need(call['runId']==self.run and call['fixtureUrl']==self.phase.fixture_url
                and call['ticket'] not in tickets and call['verb']==expected['verb'] and same(call['inputs'],expected['inputs'])
                and event['phase'] in ('planned','returned') and (index==len(events)-1 or event['phase']=='returned'))
            tickets.add(call['ticket'])
        return deepcopy(value['state'])

    def save(self):
        self.check();value=self.envelope();self.decode(value);self.store.write(value,self.previous);self.previous=deepcopy(value)

    def parts(self):
        pending=self.runtime.pending_child(self.selector,self.editors)
        attempt=self.runtime.world_attempt_child(self.selector,self.editors)
        held=IOSLifecycleWorldHoldRuntime(self.runtime.adapter).child(self.selector,self.editors,attempt,None,
            original_child=True,resource_history=True,cleanup_transport=True)
        return pending,attempt,held

    def act(self,call):
        call=arguments('feature.'+AREA+'.act',call);self.check()
        status=self.phase.read();need(status['ticket']==call['ticket'] and call['fixtureUrl']==self.phase.fixture_url
            and status['verb']==call['verb']and same(status['inputs'],call['inputs']))
        previous=[event for event in self.state['events'] if event['call']['ticket']==call['ticket']]
        if previous:
            need(len(previous)==1 and same(previous[0]['call'],call));event=previous[0]
            if event['phase']=='returned':return dict(performed=True)
        else:
            event=dict(call=deepcopy(call),phase='planned');self.state['events'].append(event);self.save()
        verb=call['verb'];inputs=call['inputs'];pending,attempt,held=self.parts()
        if verb=='open-editor':self.editors.open(inputs['editor'])
        elif verb=='type':
            self.editors.start();alias=self.editors.history.state['aliases'][-1];self.editors.type(alias['identity']['editor'],inputs['text'])
        elif verb=='back':self.editors.back('create')
        elif verb=='background-resume':IOSLifecycleBackgroundRuntime(self.runtime.adapter).resume_chat(self.selector,self.editors)
        elif verb=='hold-editor-input':pending.act('hold')
        elif verb=='replace-context':self.editors.replace_scripts()
        elif verb=='deliver-stale-input':pending.act('attempt');pending.act('release')
        elif verb=='close-editor':self.editors.back('scripts');self.editors.close_tablet()
        elif verb=='world-input':
            if self.state['events'].index(event)==2:attempt.act()
            else:
                async def begin():
                    if held.state['phase'] in ('new','prepared'):result=await held.act(seconds=12)
                    else:result=await held.recover_original_child()
                    need(result['downIssued']);return result
                asyncio.run(begin())
        elif verb=='release-input':
            async def release():
                if held.state['released'] is None:
                    await held.recover_original_child();await held.release()
                while len(held.state['quiet'])<4:await held.sample_quiet()
                held.proof();held.resource_history_proof()
            asyncio.run(release())
        elif verb=='restore':self.restoration.restore(ticket=call['ticket'])
        else:need(False)
        event['phase']='returned';self.save();return dict(performed=True)

    def settle_original_input(self):
        """Ordinary original Up first, even before any new effect proof exists."""
        from ios.adapters.lifecycle_original_up import birth_path,OriginalLifecycleUp
        birth=birth_path(self.store.path.parent,self.run)
        original_up=None
        if birth.exists():original_up=asyncio.run(OriginalLifecycleUp(birth,self.run).release())
        # Fresh restoration/pending/current proofs stay behind current admission.
        # The canonical standalone cleanup dispatch must call OriginalLifecycleUp
        # even when constructing this checked Actions owner is no longer possible.
        self.check();pending,attempt,held=self.parts()
        if held.state['phase'] in ('issued','held') and held.state['released'] is None:
            async def release():
                await held.recover_original_child();return await held.lease_owner().release()
            if original_up is None or not original_up['ordinaryUpSendReturned']:
                actual=asyncio.run(release());need(actual['contextExitReturned'] and not actual['hostResponsibility'])
        if attempt.state['phase'] in ('issued','observed'):attempt.release()
        if pending.state['events']:pending.act('release')
        return dict(performed=True)
