"""Existing normal frontdoor/actual HTTP+tasks; SDK/native remain MODELS."""
from types import SimpleNamespace
from unittest.mock import patch
from normal_child_fixture import NormalChildFixture


class Resource4NormalFrontdoorModels(NormalChildFixture):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        from ios.self_tests.lifecycle_touch_resources_fixture import Display,Receiver
        from ios.adapters.hid_session import touch_session as actual_touch_session
        self.rsd.service=SimpleNamespace(address=('fd00::2',1));self.metadata_display=Display();self.metadata_receiver=None
        def receiver():
            recorder=self.ops.touch_resources._observation_owner
            self.assertEqual(recorder.previous,recorder.store.read())
            self.assertEqual([],recorder.state['frames']) # Before the first actual SDK receiver.
            self.metadata_receiver=Receiver();return self.metadata_receiver
        def observed(rsd,address,**options):
            self.assertIs(self.rsd,rsd);self.assertIs(options['observation'],self.ops.touch_resources._source)
            return actual_touch_session(rsd,address,observation=options['observation'],socket_factory=receiver,
                display_factory=lambda _:self.metadata_display,hid_factory=lambda _:self.f.context)
        self.enterContext(patch('ios.adapters.lifecycle_touch_resource_owner.touch_session',new=observed))
    async def test_existing_runtime_resource_metadata_frontdoor_reopens_actual_motion_observer_header_and_capture_through_original_child(self):
        await self.owner.act(seconds=12);connection=self.owner._original_child
        original_preparation=self.ops.touch_resources.store.path.read_bytes()
        held=await self.runtime.resource_metadata('test-only',self.run,original_child=connection)
        self.assertEqual(3,held['originalKeeperTouchResourceVersion']);self.assertTrue(held['capture']['worker']['workerRunning'])
        self.assertEqual({'rsd','receiver','drain','display','hid'},{r['kind'] for r in held['capture']['source']['resources']})
        # The held WORLD sample remains distinct from passive resource metadata.
        await self.owner.observe();await self.owner.release()
        returned=await self.runtime.resource_metadata('test-only',self.run,original_child=connection)
        self.assertTrue(returned['capture']['worker']['contextExitReturned']);self.assertFalse(returned['resourceRetirementEstablished'])
        self.assertFalse(returned['nativeTouchSupport']);self.assertFalse(returned['capture']['worker']['retirementEstablished'])
        self.assertEqual(original_preparation,self.ops.touch_resources.store.path.read_bytes())
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertTrue(all(fd.fileno()==-1 for fd in self.metadata_receiver.sockets))
        self.assertEqual(1,len(self.metadata_display.stops));self.assertEqual(30,len(self.commands))
        sourceclock=returned['capture']['source']['clock']
        recovered=await self.runtime.resource_metadata('test-only',self.run,original_child=connection,recover=True)
        self.assertEqual(returned,recovered);self.assertEqual(sourceclock,recovered['capture']['source']['clock'])
        self.assertEqual(30,len(self.commands));self.assertEqual([0xC2,0xC2,0x02],self.f.states())
