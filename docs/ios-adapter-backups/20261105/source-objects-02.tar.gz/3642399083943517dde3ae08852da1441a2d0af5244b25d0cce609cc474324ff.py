"""Fixed30+5 one general utility counter, no Feature or historical original."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,time
R=Path.cwd().resolve(strict=True);P=Path(__file__).resolve().parent
assert R.name=='overte-ios-feature-adapters-resume-20261026'and P.resolve()==P and P.is_relative_to(R)and sys.dont_write_bytecode
assert not(P/'report.json').exists()and not(P/'test.log').exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,v):
 p=P/n;assert p.resolve().is_relative_to(R)and p.parent==P and not p.exists()
 with p.open('x')as stream:json.dump(v,stream,sort_keys=True,indent=2);stream.write('\n')
def proc(pid):
 try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
 except(FileNotFoundError,ProcessLookupError):return None
 return dict(pid=pid,parent=int(fields[1]),group=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
def remaining(pid):
 rows=[]
 for p in Path('/proc').iterdir():
  if p.name.isdecimal():
   v=proc(int(p.name))
   if v is not None and(v['group']==pid or v['session']==pid):rows.append(v)
 return rows
def census():
 root=P/'utility-stage';out={}
 for p in(root,*sorted(root.rglob('*'))):
  s=p.lstat();row=dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,bytes=s.st_size,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns)
  if stat.S_ISREG(s.st_mode):row['sha256']=sha(p)
  else:assert stat.S_ISDIR(s.st_mode);row['namespace']=sorted(q.name for q in p.iterdir())
  assert s==p.lstat();out[str(p.relative_to(root))]=row
 return out
f=json.loads((P/'code-freeze.json').read_text())
for n,d in f['files'].items():assert sha(P/n)==d
plan=json.loads((P/'plan.json').read_text())
for n,d in plan['physicalSources'].items():assert sha(n)==d
started=time.monotonic();command=['timeout','--signal=TERM','--kill-after=5s','30s',sys.executable,'-B',str(P/'run-counter.py')]
with(P/'test.log').open('x')as log:
 child=subprocess.Popen(command,cwd=R,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 bound=proc(child.pid);assert bound is not None and bound['pid']==bound['group']==bound['session'];save('process-binding.json',dict(child=bound,command=command));code=child.wait()
assert not remaining(bound['pid'])
first=census();second=census();assert first==second and not remaining(bound['pid'])
for n,d in f['files'].items():assert sha(P/n)==d
for n,d in plan['physicalSources'].items():assert sha(n)==d
body=json.loads((P/'utility-stage/selected-result.json').read_text())if(P/'utility-stage/selected-result.json').exists()else None
report=dict(actualExitCode=code,qualifiedUtilityOnly=code==0 and body is not None and body['successful'],seconds=time.monotonic()-started,sourcePinsUnchanged=True,actualOwnedProcessesAbsent=True,remainingOwned=remaining(bound['pid']),twoOwnToyCensusesEqual=first==second,FeatureQualified=False,FeatureExecutions=0,oldRawReads=0,globalScans=0,fixedWallSeconds=30,killGraceSeconds=5)
save('own-toy-first.json',first);save('own-toy-second.json',second);save('report.json',report);print(json.dumps(report),flush=True)
raise SystemExit(0 if report['qualifiedUtilityOnly']else code if code else 1)
