"""Normal14/independent originals plus a distinct received-original SDK owner.

Same phase/source ownership is joined, not an individual peer/audio route or
cross-device clock claim. All process End effects stay with existing Keepers.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager,ExitStack
from copy import deepcopy
from pathlib import Path
import hashlib
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.audio_api_clock import operation
from ios.adapters.audio_ordinary_independent_originals import IOSAudioOrdinaryIndependentOriginals
from ios.adapters.audio_ordinary_received_pair_config import settings
from ios.adapters.audio_passive_runtime import identity
from ios.adapters.audio_received_mixer_actor import IOSAudioReceivedMixerActor,lease_id
from ios.adapters.audio_received_mixer_runtime import ReceivedMixerSDKLedger


class IOSAudioOrdinaryReceivedPair:
    def __init__(self,flow,received,configuration):
        from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
        need(type(flow)is IOSAudioWholeFeature and flow.role=='primary'and type(received)is IOSAudioReceivedMixerActor)
        need(received.run==flow.run and received.client.url==flow.client.url)
        self.flow,self.received=flow,received;self.config=settings(configuration,flow,received)
        self.root=Path(self.config['pairOriginalRoot']);self.root_identity=identity(self.root)
        self.lock=ScriptSourceLock(self.root/'pair-originals.lock');self.store=PrivateFeatureState(self.root/'pair-originals.json')
        self.monotonic=flow.monotonic;self.previous=self.state=None;self.binding=None
        with self.held():
            need(flow.state is not None)
            self.binding=deepcopy(flow.state['bindings']['primary'])
            if self.state is None:
                self.state=dict(sourceTicket=None,frame=None,pending=None,cleanupIssued=0,cleanupReturned=0,terminalCalls=0,terminalFinishReturned=False,receivedEnd=None)
                self.save()
            else:need(same(self.binding,self.previous['binding']))

    @contextmanager
    def held(self):
        locks=(*self.flow.locks,self.received.lock,self.lock)
        need(len({lock.path for lock in locks})==len(locks))
        with ExitStack()as stack:
            for lock in sorted(locks,key=lambda value:str(value.path)):stack.enter_context(lock.held())
            self.flow.load();self.previous=self.store.read();self.state=None
            if self.previous is not None:
                value=self.previous
                exact(value,{'iosAudioOrdinaryReceivedPairVersion','binding','runId','configuration','rootIdentity','state'})
                need(type(value['iosAudioOrdinaryReceivedPairVersion'])is int and value['iosAudioOrdinaryReceivedPairVersion']==1
                    and value['runId']==self.flow.run and same(value['configuration'],self.config)and value['rootIdentity']==self.root_identity)
                self.binding=deepcopy(value['binding']);self.state=deepcopy(value['state'])
                exact(self.state,{'sourceTicket','frame','pending','cleanupIssued','cleanupReturned','terminalCalls','terminalFinishReturned','receivedEnd'})
                need(all(integer(self.state[k],0,8)for k in('cleanupIssued','cleanupReturned','terminalCalls'))
                    and self.state['cleanupReturned']<=self.state['cleanupIssued']and type(self.state['terminalFinishReturned'])is bool)
                need(same(self.binding,self.flow.state['bindings']['primary']))
            self.guard();yield
            self.guard()

    def guard(self):
        for lock in(*self.flow.locks,self.received.lock,self.lock):lock.assert_held()
        need(identity(self.root)==self.root_identity and same(self.store.read(),self.previous))
        expected={self.lock.path}
        if self.previous is not None:expected.add(self.store.path)
        if self.state is not None:
            if self.state['frame']is not None:expected.add(self.codec().path(self.codec().expand(self.state['frame'])))
            if self.state['pending']is not None and self.state['pending']['phase']!='planned':expected.add(self.codec().path(self.state['pending']))
        need(set(self.root.iterdir())==expected)
        return True

    def save(self):
        self.guard();value=dict(iosAudioOrdinaryReceivedPairVersion=1,binding=deepcopy(self.binding),runId=self.flow.run,
            configuration=deepcopy(self.config),rootIdentity=self.root_identity,state=deepcopy(self.state))
        self.store.write(value,self.previous);need(same(self.store.read(),value));self.previous=deepcopy(value)

    def codec(self):return OriginalFrameStore(self.root,self.binding,self.flow.run,'primary',self.guard,self.intent,
        namespace='audio-ordinary-received-pair',schema_prefix='iosAudioOrdinaryReceivedPair',monotonic=self.monotonic)

    def intent(self,event,value):
        need(event=='original'and value['index']==1)
        self.state['pending']=deepcopy(value);self.save();return True

    def ledger(self,ticket):
        r=self.received
        return ReceivedMixerSDKLedger(r.runtime,r.selector,r.run,lease_id(r.run,ticket),r.root,r.client,r.lock)

    def owner(self,ticket):
        ledger=self.ledger(ticket);owner=ledger.archives.get(lease_id(self.flow.run,ticket))
        need(owner is not None and owner.historical)
        self.received.birth(owner,ticket)
        return ledger,owner

    @operation
    def arm(self,ticket):
        with self.held():
            need(self.state['frame']is None and self.state['cleanupIssued']==0)
            if self.state['sourceTicket']is None:self.state['sourceTicket']=ticket;self.save()
            need(self.state['sourceTicket']==ticket)
            return self.received.arm(ticket) # real factory, no local success substitute

    @operation
    def capture_and_release(self,ticket):
        with self.held():
            need(self.state['sourceTicket']==ticket and self.state['cleanupIssued']==0)
            _ledger,owner=self.owner(ticket)
            if owner.state['absence']is None:
                self.received.capture(ticket);self.received.retire_capture(ticket)
            return self.received.original(ticket)

    def paired_original(self):
        f=self.flow;normal=IOSAudioOrdinaryIndependentOriginals(f).original();ticket=normal['sourceTicket']
        ledger,owner=self.owner(ticket);received=self.received.original(ticket);retired=owner.retired()
        need(ledger.process_end is None and retired['receivedMixerRetired']and not retired['SDKRetired'])
        need(all(ledger.binding[k]==f.state['bindings']['primary'][k]for k in('sourceRevision','artifactSha256')))
        for binding in f.state['bindings'].values():
            need(ledger.binding['sessionId']!=binding['sessionId']and ledger.binding['targetFingerprint']!=binding['targetFingerprint'])
        operation=[row for row in f.primary_parent().state['operations']if row['ticket']==ticket and row['verb']=='record-start']
        need(len(operation)==1 and operation[0]['after']is not None)
        primary=f.primary_parent().original(operation[0]['before'])
        birth=owner.proof(owner.state['birth']);selection=owner.proof(birth['selection'])
        for phase in(selection['phaseBefore'],selection['phaseAfter']):
            need(phase['instance']==primary['phaseBefore']['instance']and phase['runId']==f.run)
            a=phase['activations'][-1]
            need(a['ticket']==ticket and a['stimulus']['verb']=='record-start')
            normal_phase=f.primary_parent().phase_original(primary['phaseBefore'],ticket,'record-start')
            need(same(a['stimulus']['inputs'],normal_phase))
        original=received['original'];source=original['source']
        return dict(iosAudioOrdinaryReceivedOriginalVersion=1,runId=f.run,sourceTicket=ticket,
            normalMedia=normal,normalActionsSha256=digest(f.state['actions']),
            received=dict(binding=deepcopy(ledger.binding),leaseId=owner.lease,birth=owner.state['birth'],snapshot=owner.state['snapshot'],absence=owner.state['absence'],
                originalCaptureSha256=hashlib.sha256(received['rawOriginals']['capture']).hexdigest(),wavSha256=hashlib.sha256(received['wav']).hexdigest(),
                PCMsha256=hashlib.sha256(received['pcm']).hexdigest(),PCMbytes=len(received['pcm']),
                phaseBefore=deepcopy(selection['phaseBefore']),phaseAfter=deepcopy(selection['phaseAfter']),
                nativeSource=deepcopy(source),receivedCaptureRetired=True,SDKRetired=False),
            normalAndReceivedOriginalsJoined=True,sameOriginalPhaseTicketJoined=True,
            crossDeviceClockComparisonPerformed=False,individualTalkerQualified=False,causalOutputToMixerQualified=False,
            physicalADCQualified=False,physicalDACQualified=False,acousticQualified=False,nativeQualified=False,wholeQualified=False)

    @operation
    def retain(self):
        with self.held():
            need(self.state['cleanupIssued']==0)
            value=self.paired_original();ticket=value['sourceTicket']
            need(self.state['sourceTicket']in(None,ticket));self.state['sourceTicket']=ticket
            if self.state['frame']is not None:
                need(same(self.codec().read(self.codec().expand(self.state['frame'])),value));return self.original()
            if self.state['pending']is not None:
                pending=self.state['pending'];need(pending['phase']in('opened','saved')and same(self.codec().read(pending),value))
                reference=self.codec().compact(dict(pending,phase='saved'))
            else:reference=self.codec().write(1,value)
            self.state['frame']=reference;self.state['pending']=None;self.save();return self.original()

    def validate_saved(self,value):
        exact(value,{'iosAudioOrdinaryReceivedOriginalVersion','runId','sourceTicket','normalMedia','normalActionsSha256','received',
            'normalAndReceivedOriginalsJoined','sameOriginalPhaseTicketJoined','crossDeviceClockComparisonPerformed','individualTalkerQualified',
            'causalOutputToMixerQualified','physicalADCQualified','physicalDACQualified','acousticQualified','nativeQualified','wholeQualified'})
        need(value['normalAndReceivedOriginalsJoined']is True and value['sameOriginalPhaseTicketJoined']is True
            and all(value[k]is False for k in('crossDeviceClockComparisonPerformed','individualTalkerQualified','causalOutputToMixerQualified',
                'physicalADCQualified','physicalDACQualified','acousticQualified','nativeQualified','wholeQualified')))
        f=self.flow;need(type(value['iosAudioOrdinaryReceivedOriginalVersion'])is int and value['iosAudioOrdinaryReceivedOriginalVersion']==1 and value['runId']==f.run
            and value['sourceTicket']==self.state['sourceTicket']and value['normalActionsSha256']==digest(f.state['actions']))
        need(same(value['normalMedia']['bindings'],f.state['bindings']))
        from ios.adapters.audio_whole_inventory import admit
        admit(f) # original full known graph, including in-progress actual End
        for role in('primary','actor'):
            saved=value['normalMedia'][role];row=saved['publicArtifact']
            need(any(same(row,r)for r in f.state['artifacts']))
            raw=f.evidence.read(row);need(f.validate_artifact_source(row,return_bytes=True)==raw)
            need(hashlib.sha256(raw).hexdigest()==saved['originalWavSha256'])
        _ledger,owner=self.owner(value['sourceTicket']);received=self.received.original(value['sourceTicket']);owner.retired()
        birth=owner.proof(owner.state['birth']);selection=owner.proof(birth['selection'])
        need(same(selection['phaseBefore'],value['received']['phaseBefore'])and same(selection['phaseAfter'],value['received']['phaseAfter'])
            and same(received['original']['source'],value['received']['nativeSource'])and len(received['pcm'])==value['received']['PCMbytes'])
        need(same(owner.binding,value['received']['binding'])and owner.state['birth']==value['received']['birth']
            and owner.state['snapshot']==value['received']['snapshot']and owner.state['absence']==value['received']['absence']
            and hashlib.sha256(received['rawOriginals']['capture']).hexdigest()==value['received']['originalCaptureSha256']
            and hashlib.sha256(received['wav']).hexdigest()==value['received']['wavSha256']
            and hashlib.sha256(received['pcm']).hexdigest()==value['received']['PCMsha256'])
        return value

    def original(self):
        # Pure retained original graph. No capture/phase/network/current source.
        with self.held():
            need(self.state['frame']is not None)
            value=self.codec().read(self.codec().expand(self.state['frame']));return deepcopy(self.validate_saved(value))

    @operation
    def cleanup(self,call):
        with self.held():
            self.original();need(self.state['cleanupIssued']<8)
            self.state['cleanupIssued']+=1;self.save()
            result=self.flow.cleanup(call) # repeated calls use actual original recovery
            need(result==dict(performed=True));self.state['cleanupReturned']+=1;self.save();return result

    def finish_received_end(self):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
        ledger,_owner=self.owner(self.state['sourceTicket'])
        if ledger.process_end is None or ledger.process_end['phase']!='complete':
            parameters=ledger.prepare_process_end()
            end=IOSOriginalKeeperProcessEnd(self.received.runtime,self.received.selector,parameters['root'],parameters['binding'],self.flow.run,
                'actor',0,parameters['profile_key'],parameters['lock'],epoch_ms=self.received.epoch_ms,monotonic=self.received.monotonic,sleep=self.received.sleep)
            end.finish();ledger.finish_process_end(end)
        proof=ledger.retired()['originalProcessEnd'];self.state['receivedEnd']=deepcopy(proof);self.save();return proof

    @operation
    def terminal(self,call):
        with self.held():
            self.original();need(self.state['cleanupReturned']>0 and self.state['terminalCalls']<8)
            self.state['terminalCalls']+=1;self.save()
            result=self.flow.terminal(call)
            if call['stage']=='finish':
                self.finish_received_end();self.state['terminalFinishReturned']=True;self.save()
            return result

    def completed_original(self):
        with self.held():
            value=self.original();need(self.state['terminalFinishReturned']and self.flow.state['phase']=='ended')
            from ios.adapters.audio_whole_terminal import AudioWholeTerminal
            terminal=AudioWholeTerminal(self.flow);terminal.admit_archives();need(self.flow.state['terminal']['end']is not None)
            ledger,_owner=self.owner(self.state['sourceTicket']);proof=ledger.retired()['originalProcessEnd']
            need(same(proof,self.state['receivedEnd']))
            return dict(iosAudioOrdinaryReceivedCompletionVersion=1,original=value,normalTerminalEnd=deepcopy(self.flow.state['terminal']['end']),
                receivedOriginalProcessEnd=deepcopy(proof),SDKProcessOriginalGraphJoined=True,
                nativeQualified=False,individualPeerQualified=False,acousticQualified=False,featureQualified=False,wholeQualified=False)
