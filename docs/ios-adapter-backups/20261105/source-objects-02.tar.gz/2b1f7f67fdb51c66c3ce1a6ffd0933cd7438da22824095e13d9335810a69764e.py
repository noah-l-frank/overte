from pathlib import Path
import ast,difflib,hashlib,json,shutil,os
R=Path.cwd();P=R/'.ios-host-tmp/lifecycle-original-owner-child-bundle-profile-proposal-20261028';M=R/'.ios-host-tmp/lifecycle-original-owner-motion-owned-reference-proposal-20261028'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Literal SDK-boundary fixture, previously Root-PASS8 and retained immutable.
filebase=R/'.ios-host-tmp/lifecycle-original-owner-native-file8-socket-corrected-root-preparation-20261028/05-native8/test_native_file_channel_models.py'
assert H(filebase)=='9bef848da9fddf91fdeeb9029dcc0676a5982d36e1fe8babff6ea484b8f3ecd3'
shutil.copyfile(filebase,P/'native_file_fixture.py')
checkpoint=json.loads((P/'checkpoint.json').read_text());rows=checkpoint['files'];own=[]
for rel in ['tests/device/contract-versions.json','tests/device/validate_contract_versions.py']:
 base=R/rel;b=base.read_text();prospective=b
 # Dependency owns these THREE hunks; never substitute old whole JSON.
 previous={'ios-lifecycle-touch-resource-owner':(2,3),'original-keeper-motion-preparation':(1,2),'original-keeper-native-acquisition':(1,2)}
 for key,(old,new) in previous.items():
  if rel.endswith('.json'):
   a='"'+key+'": {"current": '+str(old)+', "reads": '+json.dumps(list(range(1,old+1)))+'}'
   c='"'+key+'": {"current": '+str(new)+', "reads": '+json.dumps(list(range(1,new+1)))+'}'
  else:a='"'+key+'": '+str(old)+',';c='"'+key+'": '+str(new)+','
  if a in prospective:assert prospective.count(a)==1;prospective=prospective.replace(a,c,1)
  else:assert c in prospective
 snap=P/'basis-after-motion-owned-lines/repo'/rel;snap.parent.mkdir(parents=True,exist_ok=True);snap.write_text(prospective)
 s=prospective
 for key in ['original-keeper-native-file','original-keeper-native-query','original-keeper-installed-query']:
  if rel.endswith('.json'):a='"'+key+'": {"current": 1, "reads": [1]}';c='"'+key+'": {"current": 2, "reads": [1, 2]}'
  else:a='"'+key+'": 1,';c='"'+key+'": 2,'
  assert s.count(a)==1;s=s.replace(a,c,1)
 if rel.endswith('.py'):ast.parse(s)
 else:json.loads(s)
 out=P/'candidate/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s)
 rows.append(dict(path=rel,base=str(snap),baseSHA256=H(snap),candidate=str(out),candidateSHA256=H(out),ownThreeLinesOnly=True,currentPublicSHA256=H(base)))
 own.append(''.join(difflib.unified_diff(prospective.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(P/'own-registry-three-lines.diff').write_text(''.join(own))
cases=[]
for filename in ['test_child_bundle_profile_models.py','test_installed_child_bundle_models.py']:
 tree=ast.parse((P/filename).read_bytes(),filename=filename)
 for cls in [x for x in tree.body if isinstance(x,ast.ClassDef)]:
  cases.extend(filename[:-3]+'.'+cls.name+'.'+x.name for x in cls.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) and x.name.startswith('test_'))
assert len(cases)==12
plan=dict(status='PRIVATE_UNRUN_SOURCE_DI_12',cases=cases,caseCount=12,initialOuterSeconds=60,killAfterSeconds=5,expectedActualRetainedRoots=24,
 explicitSelectionOnly=True,retentionAliases=['ios.self_tests.test_ios_touch_lease.tempfile','ios.self_tests.test_ios_bundle_identity.tempfile','ios.self_tests.test_ios_installed_adapter.tempfile'],
 retentionPolicy='REAL TemporaryDirectory plus existing retain_owned_root; module-local aliases only; preserve original async teardown and LIFO callbacks; expected roots is a forecast, never evidence',
 sdkBoundary='Original RSD/AFC/native producer modeled explicitly. Source8 uses real owned loopback HTTP/thread+actualFD service models. Host4 reuses existing declared HTTP/nativeSDK fixture models; actual selected IPA, directory files, source codecs, session/WAL guards execute. No SDK import/native code/auth proof.',
 rootRequirements=['Actual full source/launcher map before ANY target imports, strict canonical3 entry roots','Pin dependency1497 plus final Source2 keeper/installed and actual registry/validator shared bytes AFTER own-hunks PUB','Pin every old retained original and package freeze plus both actual censuses','FD/thread/task/child before/after actual cleanup; owned original threads/tasks/AFC services/socketpairs must close, no fake await/FD ignore/GC assumption','Target imports/test selection only by Root; compile actual selected AST+code hashes for provenance not binary identity'])
(P/'test-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
refs=[]
for rel in ['tests/device/ios/InstalledBundleIdentity.h','tests/device/ios/adapters/bundle_observation.py','tests/device/ios/adapters/bundle_identity.py','tests/device/ios/adapters/installed_code.py','tests/device/ios/appium_wda_host_ops.js','tests/device/ios/self_tests/test_ios_bundle_identity.py','tests/device/ios/self_tests/test_ios_bundle_observation.py','tests/device/ios/self_tests/test_ios_installed_adapter.py']:
 p=R/rel;before=p.stat();raw=p.read_bytes();after=p.stat();record=lambda x:[x.st_dev,x.st_ino,x.st_size,x.st_mtime_ns,x.st_ctime_ns]
 assert record(before)==record(after)
 refs.append(dict(path=str(p),sha256=hashlib.sha256(raw).hexdigest(),stat=record(after)))
(P/'reviewed-actual-source-pins.json').write_text(json.dumps(refs,indent=2)+'\n')
(P/'README.txt').write_text('''Feature14 / Source2 optional child native bundle connection, PRIVATE UNRUN.
Dependency frozen Motion3/14974e3f; all its originals remain immutable. No PUB,
index, SDK imports, native/compiler/device/services, test or Node execution.
Source2 adds optional nativeBundleProfileVersion1 ONLY for ios-bundle-observe
on existing query/file operations. Default three actions retain DTO1; bundle
uses DTO2/query-owner2. Cold native hashing may return literal pending; no
polling/replay/100s budget is folded into the existing original1.5s cuts.
Existing original nonce/intent/thread plus SAME Source/RSD/loop query journal
must own the exact http-returned query BEFORE new fixedfile can open. The file
uses existing original HouseArrest/AFC and unconditional retained cleanup,
source/SDK/current/release/deadline guards before/after, no reauth/new session.
Native packet is validated by the existing bundle codec. Native bundle UUID is
its own birth and is NEVER equated to native-clock UUID or source-code hash.

Existing physical installed helper composes actual selected signed-IPA bytes,
InstalledCodeBinding/SessionStore guards and new ORIGINAL child raw bytes. It
requires exact measured bundle, native bundle instance/prepared birth, fresh
sequence between independent original host observations, and checks source/
selected artifact before/after. This is a HOST physical comparison. It does
NOT serialize an authority callback or make child candidate/motion available.
No child-selected-IPA owner is manufactured from parent JSON/booleans.

Exact missing next interface: creator bootstrap2 currently receives only
udid/stateRoot. OriginalKeeperOperations.claim receives only original session,
archiveBundleId/WDA bundleId. Neither owns an original selected-IPA FD/lease
nor a local ArtifactLease producer. Actual host create_physical_adapter owns
ArtifactLease+candidate preflight; those live originals must be explicitly
handed into original child ownership/loop with independently read IPA bytes,
original selection/source scope and revocable born owner, before child motion
can use a candidate predicate. The current Source2 does not implement that
cross-process original selection handoff. Native motion/current/Up/End and
canonical child gates remain separate and false. This boundary is explicit,
not an always-unavailable wrapper substituted for the implemented file path.

12 exact new meaningful cases (8 source HTTP/WAL/FD +4 actual physical host
compositions) in test-plan.json, UNRUN. Prospective60+kill5,24 real TD roots.
Only explicit method IDs, not inherited legacy/imported classes. The installed
fixture is a reviewed old source-DI fixture with ONE exact SDK import replaced
by explicit original-service model, real FD/socketpairs/readerTask cleanup;
its actual selected AST/code hashes are recorded by existing fixture. Source8
uses byte-identical Root-PASS native-file fixture9bef. Retain all genuine TDs
and original lifetimes with module-local aliases, never global tempfile patch.
Unknown native/AFC/ACK returns remain errors/held responsibility, not evidence.
Old default NativeAcq8/Query10/Installed6 need Root-selected regressions after
publication; no prior PASS transfers to this new source. Own registry hunks
raise ONLY file/query/installed-query families1->2, reads1/2, on actual shared
bytes plus dependency-owned Motion3 lines. Never apply stale whole JSON.
''')
manifest=dict(checkpoint,files=rows,status='PRIVATE_FROZEN_SOURCE2_OWN3LINES_MODEL12_UNRUN',models={n:H(P/n) for n in ['test_child_bundle_profile_models.py','test_installed_child_bundle_models.py','installed_query_fixture.py','native_file_fixture.py']},caseCount=12,actualRootCountExpected=24,initialOuterSeconds=60,killAfterSeconds=5,nativeCompiled=False,SDKImported=False,childSelectedArtifactOwnerImplemented=False)
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file() and p.name!='freeze.json'}
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_FROZEN',files=files),indent=2)+'\n')
print('freeze',H(P/'freeze.json'));print('source2',H(P/'source2.diff'));print('models',[H(P/x) for x in ['test_child_bundle_profile_models.py','test_installed_child_bundle_models.py']])
