"""Prospective real host ownership/OFS/error counters; native wire is MODEL.

No native executable, real current paired9, process death, SDK404 or End PASS.
The native wire control uses its actual OWN HOST FD only as declared wire input;
it is never a native/device original or deletion/Stop authorization.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib,json,os,tempfile,unittest,uuid
from pathlib import Path
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.script_feature.history import unpack
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.witness import Client
from ios.adapters.emote_post_controller_end_owned import PostControllerFamilyOwnership,PostControllerFamilyOwnedArchive,NAMESPACE
from ios.adapters.emote_post_controller_end_boundary import existing_profile9_actor
from ios.adapters.emote_palette_file_original import decode_file_original,FILE,METADATA
from ios.adapters.emote_observer import EmoteObservationPending
from ios.adapters.emote_sources import EmotePhaseChanged
from ios.self_tests.emote_post_controller_runtime_fixture import IOSPostControllerDomain,installed_runtime


def metadata(info):
    return dict(zip(METADATA,map(str,(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,
        info.st_size,info.st_mtime_ns,info.st_ctime_ns))))


class DeclaredFileWire:
    """Real own host file lifetime, explicitly not the proposed C++ service."""
    def __init__(self,case,domain):
        owner=domain.owner();ref=owner.read(domain.source_reference);self.palette=owner.original(ref)['palette']
        self.path=domain.root/FILE;self.raw=json.dumps(self.palette,sort_keys=True,indent=4).encode()
        self.path.write_bytes(self.raw);self.path.chmod(0o600)
        self.fd=os.open(self.path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC);case.addCleanup(os.close,self.fd)
        self.before=metadata(os.fstat(self.fd));self.instance=uuid.uuid4().hex;self.reader=uuid.uuid4().hex
        self.sequence=0;self.retired=False;self.run=domain.run;self.binding=domain.sources().binding
    def query(self):return dict(schemaVersion=1,commandId='ios-'+uuid.uuid4().hex,action='feature-ios-emote-palette-file',operation='observe',runId=self.run)
    def value(self,query):
        self.sequence+=1;clock=dict(epochMs=100000+self.sequence,monotonicMs=1000+self.sequence)
        file=dict(name=FILE,metadata=deepcopy(self.before),sha256=hashlib.sha256(self.raw).hexdigest(),bytes=len(self.raw),palette=deepcopy(self.palette))
        original=dict(iosEmotePaletteFileOwnedOriginalVersion=1,instance=self.instance,processId=31,generation=1,
            phase='retired'if self.retired else'owned',retirementIssued=self.retired,pendingPublication=False,
            file=file,afterRetirement=metadata(os.fstat(self.fd))if self.retired else{},processDeathProved=False,sdkAbsentProved=False)
        return dict(iosEmotePaletteFileVersion=1,requestId=query['commandId'],runId=self.run,instance=self.reader,sequence=self.sequence,processId=31,
            clockDomain='native-main-emote-palette-file',clockBefore=dict(clock),clockAfter=dict(clock),source=dict(complete=True,ownership=original))
    def unlink_own_model_file(self):
        # A genuine host IO event for a declared codec input, no C++ invocation.
        os.unlink(self.path);self.retired=True


class PostControllerEndOwnedTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name);self.root.chmod(0o700)
        self.lock=ScriptSourceLock(self.root/'script-feature-sources.lock');self.held=self.lock.held();self.held.__enter__();self.addCleanup(self.held.__exit__,None,None,None)
        self.domain=IOSPostControllerDomain(self.root,self.lock)
    def archive(self):
        ownership=PostControllerFamilyOwnership(self.domain.sources())
        path=self.domain.store.path.with_name('ios-emote-primary-'+self.domain.run+'-post-controller-end-owned.json')
        return PostControllerFamilyOwnedArchive(PrivateFeatureState(path),ownership)
    def test_real_completed_family_copy_preserves_old_original_and_never_grants_end(self):
        d=self.domain;ref=d.owner().read(d.source_reference);old=d.store.read();sent=deepcopy(d.sent)
        a=self.archive();value=a.freeze();self.assertEqual('copied',a.state['phase']);self.assertEqual(old,value['familyOwnerValue'])
        self.assertEqual([True],value['stableOriginalFlags']);self.assertEqual('primary',value['creatorRole'])
        self.assertEqual(sent,d.sent);self.assertFalse(value['hostMetadataRetirementAllowed']);self.assertFalse(value['EndAllowed'])
        with self.assertRaises(EmoteObservationPending):a.retire()
        self.assertEqual(old,d.store.read());self.assertEqual(ref['index'],1)
    def test_unknown_palette_query_is_archived_as_uncertain_without_resend_or_cleanup(self):
        d=self.domain;d.lose_palette=True
        with self.assertRaises(NativeUIError):d.owner().read(d.source_reference)
        before=deepcopy(d.sent);a=self.archive();value=a.freeze();duty=a.retirement_manifest()
        self.assertTrue(value['responsibility']['uncertainRead']);self.assertEqual('palette-query',value['responsibility']['pending']['stage'])
        self.assertTrue(duty['uncertainFamilyQuery']);self.assertIsNone(duty['nativeFileRetirementOriginal'])
        with self.assertRaises(EmoteObservationPending):a.retire()
        self.assertEqual(before,d.sent);self.assertFalse(duty['finishAllowed'])
    def test_lost_complete_copy_return_recovers_actual_saved_inode_without_source_query(self):
        self.domain.owner().read(self.domain.source_reference);a=self.archive();write=a.originals.write
        def lost(index,value):write(index,value);raise OSError('Declared lost complete copied-original return')
        with patch.object(a.originals,'write',lost),self.assertRaises(OSError):a.freeze()
        item=a.state['pending'];path=a.originals.path(item);before=(path.stat().st_dev,path.stat().st_ino,path.read_bytes());sent=deepcopy(self.domain.sent)
        reopened=self.archive();reopened.freeze()
        self.assertEqual(before,(path.stat().st_dev,path.stat().st_ino,path.read_bytes()));self.assertEqual(sent,self.domain.sent)
        with self.assertRaises(EmoteObservationPending):reopened.retire()
    def test_lost_actual_final_cas_return_reopens_real_copied_state_without_rewrite(self):
        self.domain.owner().read(self.domain.source_reference);a=self.archive();write=a.store.write
        def lost(value,previous):
            returned=write(value,previous)
            if unpack(value['payload'])[0]['phase']=='copied':raise OSError('Declared lost AFTER actual copied-state CAS')
            return returned
        with patch.object(a.store,'write',lost),self.assertRaises(OSError):a.freeze()
        actual=a.store.read();before=(a.store.path.stat().st_dev,a.store.path.stat().st_ino,a.store.path.read_bytes());sent=deepcopy(self.domain.sent)
        reopened=self.archive();self.assertEqual('copied',reopened.state['phase']);reopened.freeze()
        self.assertEqual(actual,reopened.previous);self.assertEqual(before,(a.store.path.stat().st_dev,a.store.path.stat().st_ino,a.store.path.read_bytes()));self.assertEqual(sent,self.domain.sent)
    def test_genuine_opened_empty_copy_remains_owned_and_cannot_be_completed_from_dto(self):
        self.domain.owner().read(self.domain.source_reference);a=self.archive();intent=a.originals.intent
        def lost(kind,wire):
            result=intent(kind,wire)
            if wire['phase']=='opened':raise OSError('Declared real opened FD interruption before write')
            return result
        with patch.object(a.originals,'intent',lost),self.assertRaises(OSError):a.freeze()
        item=a.state['pending'];path=a.originals.path(item);self.assertEqual(b'',path.read_bytes());old=a.store.read();sent=deepcopy(self.domain.sent)
        reopened=self.archive()
        with self.assertRaises(NativeUIError):reopened.freeze()
        self.assertEqual(old,reopened.store.read());self.assertEqual(b'',path.read_bytes());self.assertEqual(sent,self.domain.sent)
        self.assertEqual('opened',reopened.retirement_manifest()['pending']['phase'])
    def test_same_bytes_new_copy_inode_cannot_adopt_original_or_retire_metadata(self):
        self.domain.owner().read(self.domain.source_reference);a=self.archive();a.freeze();path=a.originals.path(a.originals.expand(a.state['record']));raw=path.read_bytes()
        path.rename(path.with_name('retained-original-'+path.name));path.write_bytes(raw);path.chmod(0o600)
        with self.assertRaises(NativeUIError):a.original()
        with self.assertRaises(NativeUIError):a.retirement_manifest()
    def test_changed_source_original_inode_invalidates_held_family_ownership(self):
        self.domain.owner().read(self.domain.source_reference);a=self.archive();a.freeze();source=self.domain.sources();item=source.originals.manifest(source.state['manifests'][0])[0]
        path=source.originals.path(source.originals.expand(item));raw=path.read_bytes();path.rename(path.with_name('retained-original-'+path.name));path.write_bytes(raw);path.chmod(0o600)
        with self.assertRaises(NativeUIError):a.ownership.bound()
    def test_unknown_new_copy_namespace_carrier_stays_a_refusal(self):
        a=self.archive();path=self.root/(NAMESPACE+'-frame-inputs-'+self.domain.run+'-primary-unclaimed.json');path.write_bytes(b'{}');path.chmod(0o600)
        before=(path.stat().st_dev,path.stat().st_ino,path.read_bytes())
        with self.assertRaises(NativeUIError):self.archive()
        self.assertEqual(before,(path.stat().st_dev,path.stat().st_ino,path.read_bytes()))
    def test_actual_host_fd_wire_retirement_grammar_stays_separate_from_process_end(self):
        wire=DeclaredFileWire(self,self.domain);query=wire.query();first=wire.value(query)
        self.assertEqual(first,decode_file_original(first,query,wire.binding));old=deepcopy(first['source']['ownership']['file']['palette'])
        wire.unlink_own_model_file();query=wire.query();last=wire.value(query);self.assertEqual(last,decode_file_original(last,query,wire.binding,first))
        self.assertEqual(old,last['source']['ownership']['file']['palette']);self.assertFalse(last['source']['ownership']['processDeathProved']);self.assertFalse(last['source']['ownership']['sdkAbsentProved'])
    def test_native_file_wrong_name_creator_source_or_reused_sequence_refuses(self):
        wire=DeclaredFileWire(self,self.domain);query=wire.query();value=wire.value(query)
        mutations=(lambda v:v['source']['ownership']['file'].update(name='foreign.json'),lambda v:v['source']['ownership'].update(processId=32),
            lambda v:v.update(clockDomain='native-main-foreign-file'),lambda v:v['source']['ownership']['file']['palette'].update(iosEmotePaletteVersion=1))
        for mutate in mutations:
            changed=deepcopy(value);mutate(changed)
            with self.assertRaises(NativeUIError):decode_file_original(changed,query,wire.binding)
        with self.assertRaises(NativeUIError):decode_file_original(value,query,wire.binding,value)
    def test_actual_profile9_factory_refuses_missing_or_same_sdk_actor_without_transport(self):
        fixture,runtime=installed_runtime(self);client=Client('http://127.0.0.1:1/feature-fixture/v1','d'*64)
        settings=dict(artifactRoot=str(self.root),imagePolicy=dict(source='world-render-target',marker=[4,4,132,36],subject=[150,40,250,140]),actorTarget='different-owned-actor')
        pair=dict(primaryTarget='test-only',actorTarget='different-owned-actor',primaryArtifactRoot=str(self.root),actorArtifactRoot=str(fixture.f.root))
        primary=runtime._emote_post_controller_feature('test-only',self.domain.run,role='primary',client=client,settings=settings,target_pair=pair)
        before=deepcopy(fixture.f.commands)
        with self.assertRaises(NativeUIError):existing_profile9_actor(primary)
        self.assertEqual(before,fixture.f.commands);self.assertIsNone(primary.state)
    def test_empty_new_family_is_not_an_implicit_profile9_end_permission(self):
        a=self.archive();value=a.freeze();self.assertIsNone(value['responsibility']);self.assertFalse(value['nativeFileRetirementRequired'])
        with self.assertRaises(EmoteObservationPending):a.retire()
        self.assertIsNone(a.retirement_manifest()['creatorProcessEndOriginal'])

    def test_crossed_family_original_is_copied_as_owned_but_never_as_stable_end(self):
        d=self.domain;d.phase_wire.changed=True
        with self.assertRaises(EmotePhaseChanged):d.owner().read(d.source_reference)
        before=deepcopy(d.sent);a=self.archive();value=a.freeze();self.assertEqual([False],value['stableOriginalFlags'])
        self.assertEqual(before,d.sent)
        with self.assertRaises(EmoteObservationPending):a.retire()
        self.assertEqual(before,d.sent)
    def test_same_bytes_new_source_pfs_inode_cannot_reanchor_old_owned_copy(self):
        self.domain.owner().read(self.domain.source_reference);a=self.archive();a.freeze();path=self.domain.store.path;raw=path.read_bytes()
        path.rename(path.with_name('retained-source-pfs-'+path.name));path.write_bytes(raw);path.chmod(0o600)
        with self.assertRaises(NativeUIError):a.ownership.bound()
        with self.assertRaises(NativeUIError):self.archive()
