"""Metadata-only passive one-case diagnostic preparation; no target imports."""
from pathlib import Path
import ast,hashlib,json,stat
R=Path.cwd().resolve(strict=True)
assert R.name=='overte-ios-feature-adapters-resume-20261026'and(R/'.git').is_file()and(R/'.ios-host-tmp').is_dir()
def target(p):
    p=Path(p);assert p.resolve().is_relative_to(R);return p
def write(p,text):target(p).write_text(text)
def mkdir(p):target(p).mkdir(parents=True,exist_ok=True,mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
O=R/'.ios-host-tmp/lifecycle-publication-read-phase-own7-real-http-pinned-overlay-root-preparation-20261103';P=R/'.ios-host-tmp/lifecycle-publication-own7-real-http-subject-fixture-source-proposal-20261103';S=R/'.ios-host-tmp/lifecycle-publication-original-read-phase-diagnostic-source-proposal-20261103';H=R/'.ios-host-tmp/lifecycle-publication-read-phase-passive-diagnostic-one-pinned-overlay-root-preparation-20261103'
assert sha(O/'freeze.json')=='b78e43ac5dd61b72a21794611e30bcfa3fce8cdc1ff0c3c8797ddedc5234d4b5'and sha(P/'freeze.json')=='49d2aa161e6593505fa10535d74bbc3a1a29a14f7c18fe56ed356cb2f9c4317f'
assert sha(S/'freeze.json')=='a689248ad97eda8dc32490aba02bdbde1c26a987e71725683bf1f1468cd43e54'and not H.exists();mkdir(H)
source_files=json.loads((S/'freeze.json').read_text())['files']
for relative,digest in source_files.items():assert sha(S/relative)==digest
for file in(S/'candidate').rglob('*'):
    if file.is_file():assert file.read_bytes()==(P/'candidate'/file.relative_to(S/'candidate')).read_bytes()
for relative,digest in json.loads((O/'freeze.json').read_text())['files'].items():
    assert sha(O/relative)==digest
    if relative in('immutable-source-pins.json','AST-ONLY.json'):continue
    p=H/relative;mkdir(p.parent);target(p).write_bytes((O/relative).read_bytes());target(p).chmod(0o600)
new=H/'models/test_lifecycle_publication_read_phase_diagnostic_models.py';target(new).write_bytes((S/'models'/new.name).read_bytes());target(new).chmod(0o600)
def rebase(value):
    if type(value)is dict:return {key:rebase(row)for key,row in value.items()}
    if type(value)is list:return [rebase(row)for row in value]
    return value.replace(str(O),str(H)).replace(str(P),str(S)).replace(sha(P/'freeze.json'),sha(S/'freeze.json'))if type(value)is str else value
for relative in('plan.json','maps.json',*[str(p.relative_to(O))for p in(O/'maps').glob('*.json')]):write(H/relative,json.dumps(rebase(json.loads((H/relative).read_text())),indent=2,sort_keys=True)+'\n')
rows=json.loads((H/'maps.json').read_text())
for row in rows.values():row['sha256']=sha(Path(row['path']))
write(H/'maps.json',json.dumps(rows,indent=2,sort_keys=True)+'\n')
case='test_lifecycle_publication_read_phase_diagnostic_models.LifecyclePublicationReadPhaseDiagnosticModels.test_passive_actual_policy_members_and_cold_warm_original_cost_without_publisher_post'
value=json.loads((H/'first1/case.json').read_text());value.update(case=case,diagnosticOnly=True,freshPublishQualified=False);write(H/'first1/case.json',json.dumps(value,indent=2)+'\n')
plan=json.loads((H/'plan.json').read_text());plan.update(caseCount=1,cases=[case],stageOrder=['first1'],sourceFreezeSha256=sha(S/'freeze.json'),diagnosticOnly=True)
for row in plan['overlays']:row['sha256']=sha(Path(row['path']))
write(H/'plan.json',json.dumps(plan,indent=2,sort_keys=True)+'\n')
p=H/'root-supervise.py';t=p.read_text();old="HERE.name in ('first1','sameInode1','parentOrphan1','code1','unsupported1','foreignStore1','lostPost1')";assert t.count(old)==1;write(p,t.replace(old,"HERE.name in ('first1',)"))
p=H/'guard.py';t=p.read_text();old="    order=('first1','sameInode1','parentOrphan1','code1','unsupported1','foreignStore1','lostPost1');assert here.name in order";assert t.count(old)==1;write(p,t.replace(old,"    order=('first1',);assert here.name in order"))
history=json.loads((H/'historical-proof-scope.json').read_text());stage=O/'first1';report=json.loads((stage/'run/report.json').read_text());receipt=json.loads((stage/'cleanup/receipt.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==43 and report['allPinsEqual']and report['retainedOriginalsUnchanged']and not report['remainingOwnedProcesses']
history.setdefault('failedStages',[]).append(dict(path=str(stage),reportSha256=sha(stage/'run/report.json'),exitCode=1,retainedFiles=43,retainedRootCount=len(receipt['retainedRoots']),selectedResultExists=(stage/'selected-result.json').exists()));write(H/'historical-proof-scope.json',json.dumps(history,indent=2,sort_keys=True)+'\n')
write(H/'ROOT-PLAN.txt',"""ROOT REVIEW REQUIRED — FROZEN PASSIVE DIAGNOSTIC ONLY, UNRUN

Select ONLY the one explicit OWN method in case.json at stage first1.
Sourcea689248ad97eda8dc32490aba02bdbde1c26a987e71725683bf1f1468cd43e54.
Command from checked Resume worktree:
python3 -B .ios-host-tmp/lifecycle-publication-read-phase-passive-diagnostic-one-pinned-overlay-root-preparation-20261103/root-supervise.py .ios-host-tmp/lifecycle-publication-read-phase-passive-diagnostic-one-pinned-overlay-root-preparation-20261103/first1
Budget unchanged180 seconds+TERM/kill-after5; no other stage can launch.
No execution is authorized/performed by this preparation; Root reviews first.

Exact original standard AsyncRunner/teardown/cleanup/Runner.close and literal
run-selected.py/root_stage_guard.py remain unchanged from b78e. Child owns only
existing original-loop/loopback HTTP/AFC/Phase SDK-data-model resources; no new
server/thread/process/SDK/device endpoint is introduced by this diagnostic.
ZERO subprocess/Node, installed/vendor SDK imports/reads forbidden, bind/connect
only owned loopback; actual source/nonce/file/receiver guards preserved. Parent
PGID/SID/startticks must drain before two real original raw-file censuses; FD/
Task/thread/child/SDK checks and exactly3 real retained TDs remain mandatory.
All before/after source/maps/deps and every retained original are pinned. Old
b78e first43 files and all earlier44/79/etc failures remain failures unchanged.
Clock2 remains exact historicalSourcea012 proof, not current map qualification.

Fixture subject setup performs actual primary.observe then actor.observe with
publish=False BEFORE this diagnostic body. This deliberately excludes the
optional prior default setup Publisher POST: no publisher instance/WAL/intent/
receipt may exist and actual journal entries must be empty before/after. No old
keeper/Baseline producer boundary is rewritten. Actual Current7/Actor/History/
PFS/Phase originals and existing actual HTTP/AFC path still run. This IS NOT a
FreshPublish success, Own7 positive gate, Whole16/image/End/native/device proof.

Artifact first1/bindings/passive-publication-read-diagnostic.json records the
actual closed-policy module/member/type/reason identifiers (no arbitrary values),
initial supported/admitted status, wall costs for policy scan/admitted check/
archive/cold/warm, real file membership and scope stats/post-exit empty rows.
Each measured stage saves its actual partial data before rethrowing an error.
Initial unsupported remains literal. No admission assertion is replaced by a
whitelist and no fact/clock/current/native result is injected. DiagnosticOnly
and freshPublishQualifiedFalse remain explicit even if standard case succeeds.
A failure/timeout remains actualfailure; no automatic retry, cap rise or selection
of any existing Own7/Whole16 follow-up is permitted by this controller.
""")
write(H/'diagnostic-provenance.json',json.dumps(dict(parentControllerFreeze=sha(O/'freeze.json'),parentSourceFreeze=sha(P/'freeze.json'),sourceFreeze=sha(S/'freeze.json'),candidateDeltaPaths=[],ownCase=case,setupActorObservePublished=False,diagnosticOnly=True,freshPublishQualified=False,runnerUnchanged=sha(H/'run-selected.py')==sha(O/'run-selected.py'),terminalGuardUnchanged=sha(H/'root_stage_guard.py')==sha(O/'root_stage_guard.py')),indent=2,sort_keys=True)+'\n')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
    a=p.lstat();assert not p.is_symlink()and p.resolve(strict=True)==p;value=dict(stat=[getattr(a,k)for k in FIELDS])
    if p.is_file():value['sha256']=sha(p)
    assert value['stat']==[getattr(p.lstat(),k)for k in FIELDS];return value
old=json.loads((O/'immutable-source-pins.json').read_text());pins={name:pin(Path(name))for name in old};assert pins==old
for p in(O/'freeze.json',O/'immutable-source-pins.json',*sorted((O/'first1').rglob('*')),Path(__file__).resolve()):pins[str(p)]=pin(p)
for relative in source_files:pins[str(S/relative)]=pin(S/relative)
pins[str(S/'freeze.json')]=pin(S/'freeze.json')
for p in sorted(H.rglob('*')):
    if p.is_file():pins[str(p)]=pin(p)
write(H/'immutable-source-pins.json',json.dumps(pins,indent=2,sort_keys=True)+'\n')
rows=[]
for p in sorted(H.rglob('*.py')):rows.append(dict(path=str(p.relative_to(H)),sha256=sha(p),astSha256=hashlib.sha256(ast.dump(ast.parse(p.read_bytes()),include_attributes=False).encode()).hexdigest()))
write(H/'AST-ONLY.json',json.dumps(dict(status='NO_TARGET_IMPORT_OR_EXECUTION',files=rows),indent=2)+'\n');files={str(p.relative_to(H)):sha(p)for p in sorted(H.rglob('*'))if p.is_file()}
write(H/'freeze.json',json.dumps(dict(status='PRIVATE_FROZEN_DIAGNOSTIC_UNRUN_ROOT_REVIEW_REQUIRED',sourceFreeze=sha(S/'freeze.json'),parentControllerFreeze=sha(O/'freeze.json'),files=files),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(controller=str(H),freeze=sha(H/'freeze.json'),pins=len(pins),pythonFiles=len(rows),source=sha(S/'freeze.json'),executed=False)))
