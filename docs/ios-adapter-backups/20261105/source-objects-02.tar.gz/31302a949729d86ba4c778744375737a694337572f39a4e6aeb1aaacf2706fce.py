"""Root-only CrossAPI original-child qualification, original caps and audited runner."""
import ast,difflib,hashlib,json,stat
from pathlib import Path
R=Path.cwd();H=R/'.ios-host-tmp/lifecycle-original-child-cross-api-four-root-preparation-20261103';S=R/'.ios-host-tmp/lifecycle-original-child-cross-api-recovery-exact-counter-overlay-20261103';N=R/'.ios-host-tmp/lifecycle-resource4-sdk-separated-actual-native3-gated-root-preparation-20261102';E=R/'.ios-host-tmp/emote-callback-live-prefix-typed-set-mechanisms19-root-preparation-20261102/smoke1';BASE=N/'normal1'
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(s)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in F])
 if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
 assert v['stat']==[getattr(p.lstat(),k) for k in F];return v
for packet in (S,BASE,E):
 for rel,d in json.loads((packet/'freeze.json').read_text())['files'].items():assert sha(packet/rel)==d
source_rows=json.loads((S/'plan.json').read_text())['sourceRows']
own={'ios-lifecycle-world-hold':{'current':3,'reads':[1,2,3]},'ios-lifecycle-parent-resource-original':{'current':1,'reads':[1]},'ios-lifecycle-parent-resource-history-proof':{'current':1,'reads':[1]}}
actual=json.loads((R/'tests/device/contract-versions.json').read_text());assert {k:actual['contracts'][k] for k in own}==own
save(H/'registry-semantic-owned-prerequisite.json',dict(owned=own,foreignKeysPreserved=True,registryMutations=False))
prior=json.loads((E/'prior-retained-original-pins.json').read_text());proofs=[];proofpins={}
bookend=R/'.ios-host-tmp/lifecycle-resource4-native-bookend-first3-root-preparation-20261102/first3'
PARENT=R/'.ios-host-tmp/lifecycle-parent-resource-history-four-root-preparation-20261102'
for stage,files in [(bookend,48),*[(N/name,count) for name,count in [('first1',19),('foreignPostrelease1',19),('remaining6',107),('normal1',62)]],(PARENT/'first1',70),(PARENT/'remaining3',121)]:
 plan=json.loads((stage/'run-plan.json').read_text());report=json.loads((stage/'root-run-first/report.json').read_text());assert report['exitCode']==0 and report['retainedFiles']==files and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and report['remainingOwnedProcesses']==[]
 assert json.loads((stage/'root-run-first/source-before.json').read_text())==json.loads((stage/'root-run-first/source-after.json').read_text())
 root=stage/'retained-first';expected=json.loads((stage/'root-run-first/originals-first.json').read_text());current={str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))};assert current==expected==json.loads((stage/'root-run-first/originals-second.json').read_text())
 frozen=set(json.loads((stage/'freeze.json').read_text())['files'])|{'freeze.json'}
 for p in stage.rglob('*'):
  if str(p.relative_to(stage)) not in frozen:prior[str(p)]=pin(p);proofpins[str(p)]=pin(p)
 for i,case in enumerate(plan['cases'],1):
  receipt=json.loads((stage/('case-cleanup-'+str(i))/'receipt.json').read_text());assert receipt['case']==case and receipt['actualStandardCaseRunReturned'] and receipt['twoCensusesPassed']
 proofs.append(dict(stage=str(stage),cases=plan['cases'],retainedFiles=files))
# The actual old proof maps are retained, never reinterpreted as current Source
# qualification. Only unchanged original Native guard/receiver bodies are reused.
unchanged={str(R/p):sha(R/p) for p in ('tests/device/ios/pymobiledevice3_wda_xctest.py','tests/device/ios/adapters/lifecycle_touch_resource_owner.py')}
assert list(unchanged.values())==['77e08b83377cce6941e21c5fdaea280020c1d8278ed0a030dc8fb169df5feec0','fb249bcc11fe359e0238f480f2abf8d21189b94d250a74fb67a1ac8f801ee34b']
model=S/'models/test_original_child_cross_api_recovery_models.py';tree=ast.parse(model.read_bytes());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef));ids=['test_original_child_cross_api_recovery_models.'+cls.name+'.'+n.name for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name.startswith('test_')];assert len(ids)==4
stages=[];baseplan=json.loads((BASE/'run-plan.json').read_text());manifest=json.loads((BASE/'source-manifest.json').read_text());superplan=json.loads((BASE/'supervisor-plan.json').read_text())
prerequisite='''"""Actual old Native12 retention; no upgrade to current changed Source."""
import hashlib,json,stat
from pathlib import Path
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def require(here,repo,*,parent=False):
 data=json.loads((here/'actual-component-prerequisite.json').read_text());pins=json.loads((here/'actual-component-proof-pins.json').read_text());paths=[]
 for name,digest in data['unchangedNativeSource'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest;paths.append(Path(name))
 for item in data['actualStages']:
  root=Path(item['stage']);report=json.loads((root/'root-run-first/report.json').read_text());assert report['exitCode']==0 and report['retainedFiles']==item['retainedFiles'] and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
  assert json.loads((root/'root-run-first/thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
  assert json.loads((root/'run-plan.json').read_text())['cases']==item['cases']
  assert json.loads((root/'root-run-first/source-before.json').read_text())==json.loads((root/'root-run-first/source-after.json').read_text())
  assert json.loads((root/'root-run-first/originals-first.json').read_text())==json.loads((root/'root-run-first/originals-second.json').read_text())
  for i,case in enumerate(item['cases'],1):
   c=root/('case-cleanup-'+str(i));r=json.loads((c/'receipt.json').read_text());assert r['case']==case and r['actualStandardCaseRunReturned'] and r['twoCensusesPassed']
   a=json.loads((c/'terminal-census-1.json').read_text());b=json.loads((c/'terminal-census-2.json').read_text());assert a==b and not a['threads'] and not a['pendingTasks'] and not a['sdkModules'] and a['children']==''
  process=json.loads((root/'root-run-first/process-binding.json').read_text())['task']
  try:row=Path('/proc',str(process['pid']),'stat').read_text().rsplit(') ',1)[1].split()
  except (FileNotFoundError,ProcessLookupError):row=None
  assert row is None or int(row[19])!=process['startTicks']
 for name,expected in pins.items():
  p=Path(name);assert p.is_relative_to(repo) and p.resolve(strict=True)==p;a=p.lstat();value=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):value['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert value==expected and value['stat']==[getattr(p.lstat(),k) for k in F];paths.append(p)
 if here.name=='remaining3':
  first=here.parent/'first1';out=first/'root-run-first';report=json.loads((out/'report.json').read_text())
  assert report['exitCode']==0 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
  assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
  assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
  assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text())
  cases=json.loads((first/'run-plan.json').read_text())['cases'];r=json.loads((first/'selected-result.json').read_text());assert len(cases)==1 and r['selectedIds']==cases and r['successful'] and r['testsRun']==1 and not any(r[k] for k in ('failureCount','errorCount','skippedCount'))
  c=first/'case-cleanup-1';receipt=json.loads((c/'receipt.json').read_text());assert receipt['case']==cases[0] and receipt['actualStandardCaseRunReturned'] and receipt['twoCensusesPassed']
  for name in ('terminal-census-1.json','terminal-census-2.json'):
   a=json.loads((c/name).read_text());assert a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
  process=json.loads((out/'process-binding.json').read_text())['task']
  try:row=Path('/proc',str(process['pid']),'stat').read_text().rsplit(') ',1)[1].split()
  except (FileNotFoundError,ProcessLookupError):row=None
  assert row is None or int(row[19])!=process['startTicks']
  frozen=set(json.loads((first/'freeze.json').read_text())['files'])|{'freeze.json'}
  for p in sorted(first.rglob('*')):
   if str(p.relative_to(first)) not in frozen:assert p.resolve(strict=True)==p;paths.append(p)
 return paths
'''
for name,cases,seconds,roots in [('first1',ids[:1],60,3),('remaining3',ids[1:],90,9)]:
 stage=H/name;stage.mkdir(mode=0o700)
 # Keep all existing private producer/SDK/model code exact; replace the old
 # current-map gate with honest immutable old proof retention only.
 for rel,digest in json.loads((BASE/'freeze.json').read_text())['files'].items():
  if rel.endswith('.py') or rel=='sdk-original-pins.json':write(stage/rel,(BASE/rel).read_text())
 (stage/'run-selected.py').write_text((E/'run-selected.py').read_text())
 code=(stage/'run-selected.py').read_text();anchor='    initial=baseline() # BEFORE any target module import.\n';assert code.count(anchor)==1
 code=code.replace(anchor,"    from actual_prerequisite import require\n    require(HERE,repo) # Actual old completed source/cleanup proofs only.\n"+anchor)
 code=code.replace("        sdk_free()\n        if len(owned)","        sdk_free();require(HERE,repo)\n        if len(owned)")
 (stage/'run-selected.py').write_text(code);(stage/'actual_prerequisite.py').write_text(prerequisite)
 write(stage/'test_original_child_cross_api_recovery_models.py',model.read_text())
 write(stage/'test_parent_resource_world_history_models.py',(PARENT/'first1/test_parent_resource_world_history_models.py').read_text())
 parent=(stage/'root-supervise.py').read_text();anchor="def sources(stage):\n";assert parent.count(anchor)==1
 # The Native template already invokes require(parent=True); preserve that call.
 assert 'paths.update(require(HERE,REPO,parent=True))' in parent
 (stage/'root-supervise.py').write_text(parent)
 save(stage/'actual-component-prerequisite.json',dict(actualStages=proofs,unchangedNativeSource=unchanged,changedSourceReview='CrossAPI Source2 actual original transport recovery; old proofs retained as OLD Source, not declared unchanged qualification'))
 save(stage/'actual-component-proof-pins.json',proofpins);save(stage/'prior-retained-original-pins.json',prior)
 plan=dict(baseplan,status='PRIVATE_UNRUN_PARENT_RESOURCE_HISTORY_'+name,cases=cases,caseCount=len(cases),totalCaseCount=len(cases),initialOuterSeconds=seconds,expectedRetainedRoots=roots)
 plan['requiredPublicDependencies']=sorted(set(baseplan['requiredPublicDependencies'])|{row['path'] for row in source_rows})
 plan['registryRequirements']=dict(baseplan['registryRequirements'],**own)
 plan['privateFiles']={p.name:sha(p) for p in stage.glob('*.py')};plan['qualification']='Cross-API original-child birth recovery, separate actual host loops, original Up/no repeatDown only; no physical/native/SDK/whole acceptance.'
 save(stage/'run-plan.json',plan)
 current=dict(manifest,name=name,stage='parent-resource-history-'+name,status=plan['status'],sourcePaths=[dict(row,candidate=str(S/'candidate'/row['path']),observedPublicSHA256=sha(R/row['path']) if (R/row['path']).exists() else None,changesCurrentPublic=True) for row in source_rows],sourcePathCount=2,sourceDeltaPaths=[row['path'] for row in source_rows],caseCount=len(cases),pythonCaseCount=len(cases),initialTimeoutSeconds=seconds)
 current['orderedParentFreezes']=dict(manifest['orderedParentFreezes']);current['orderedParentFreezes'][str(S.relative_to(R/'.ios-host-tmp'))]=sha(S/'freeze.json');current['orderedParentFreezes'][str(N.relative_to(R/'.ios-host-tmp'))]=sha(N/'freeze.json')
 current['actualPublicBasis']='Actual after Root-approved CrossAPI2 publication. Current full Source map generated fresh. Actual Native12 +Parent4 retained as historical proof, never replayed or upgraded to current code.'
 save(stage/'source-manifest.json',current);save(stage/'supervisor-plan.json',dict(superplan,initialSeconds=seconds))
 for p in stage.glob('*.py'):ast.parse(p.read_bytes(),filename=str(p))
 code=(stage/'run-selected.py').read_text();old="        if len(owned)!=plan['expectedRetainedRoots']:raise RuntimeError('Actual retained root count differs')\n        terminal(HERE,initial,owned)";assert code.count(old)==1;code=code.replace(old,"        terminal(HERE,initial,owned)\n        if len(owned)!=plan['expectedRetainedRoots']:raise RuntimeError('Actual retained root count differs')");(stage/'run-selected.py').write_text(code)
 plan['privateFiles']={p.name:sha(p) for p in stage.glob('*.py')};(stage/'run-plan.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
 save(stage/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={p.name:sha(p) for p in stage.iterdir() if p.is_file() and p.name!='freeze.json'}));stages.append(dict(name=name,cases=cases,initialSeconds=seconds,killAfterSeconds=5,realRoots=roots,freeze=sha(stage/'freeze.json')))
save(H/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceFreeze=sha(S/'freeze.json'),sourceRows=source_rows,ownedRegistry=own,allForeignRegistryPreserved=True,stages=stages,actualOldNative12Retained=True,oldProofsReexecuted=False,targetImports=False,testsRun=False,publicMutations=False))
write(H/'ROOT-PLAN.txt','Root-only UNRUN after reviewed CrossAPI2 publication. Own4 cases only; Native12+Parent4 prior actual proofs retained without replay. first1 original60+kill5/3realTD. remaining3 separate90+kill5/9realTD, notrun until actual changed first1PASS. Existing Native original fixtures, explicit ignored requiredPublicDependencies, strict SDK/no-subprocess/loopback preimportaudit, actual per-case standardRunner afterasyncRunner.close plus2FD/task/thread/child/original censuses unchanged. Original Native12/Resource9 actualproof maps/reports/originals immutable and currentrawpins retained; old Source maps are not current qualification. Only actual unchanged Native receiver77e08/resourcefb249 bodies must remain exact; changedRuntimefb933/WorldHold3ea89 plus unchanged rawdecoder0c054/semanticregistry3 are new selectedSource. Actual newbroad map only after PUB. No cap/join/clock/SDK/device/whole gate changes.\n')
save(H/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(H)):sha(p) for p in H.rglob('*') if p.is_file() and p.name!='freeze.json'},stageFreezes={s['name']:s['freeze'] for s in stages}))
print(json.dumps(dict(packet=str(H),freeze=sha(H/'freeze.json'),stages=stages,proofPins=len(proofpins),priorPins=len(prior))))
