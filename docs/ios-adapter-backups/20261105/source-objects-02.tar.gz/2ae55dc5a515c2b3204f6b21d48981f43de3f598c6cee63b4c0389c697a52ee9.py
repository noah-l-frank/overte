from pathlib import Path
import ast,difflib,hashlib,json,shutil
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';OLD=T/'lifecycle-original-owner-native-file8-root-preparation-20261028/05-native8';Q=T/'lifecycle-original-owner-native-query-owner-proposal-20261028';P=T/'lifecycle-original-owner-native-query10-root-preparation-20261028';S=P/'06-query10';S.mkdir(mode=0o700,parents=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
qm=json.loads((Q/'manifest.json').read_bytes());qfreeze=json.loads((Q/'freeze.json').read_bytes())
assert h(Q/'freeze.json')=='7af8795ac1ada2540d213a9fe31c3d4636275a964f8e2ab8888f93e5358a76d7'
for row in qfreeze['files']:assert h(Q/row['path'])==row['sha256']
for name in ('root-child.py','root-supervise.py','root_stage_guard.py','source_model_bindings.py','run-selected.py','sdk-original-pins.json'):
 shutil.copyfile(OLD/name,S/name)
shutil.copyfile(Q/'test_native_query_owner_models.py',S/'test_native_query_owner_models.py');shutil.copyfile(Q/'proposal.diff',S/'source3.diff')
# Only normalize the reviewed packet's explicit list-shaped freeze; do not
# mutate the original frozen packet or silently skip any pin.
p=S/'root-supervise.py';s=p.read_text();a="  for relative,expected in json.loads((packet/'freeze.json').read_text())['files'].items():\n";b="""  frozen=json.loads((packet/'freeze.json').read_text())['files']
  if isinstance(frozen,list):
   assert all(type(row) is dict and set(row)=={'path','sha256','bytes'} for row in frozen)
   assert len({row['path'] for row in frozen})==len(frozen)
   frozen={row['path']:row['sha256'] for row in frozen}
  for relative,expected in frozen.items():
""";assert s.count(a)==1;p.write_text(s.replace(a,b))
(S/'root-parent-freeze-format.diff').write_text(''.join(difflib.unified_diff((OLD/'root-supervise.py').read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/root-supervise.py',tofile='b/root-supervise.py')))
stage=json.loads((OLD/'source-manifest.json').read_text());stage.update(stage=6,name='native-query10',status='PRIVATE_UNRUN_NATIVE_QUERY_SOURCE10',caseCount=10)
stage['orderedParentFreezes']['lifecycle-original-owner-native-query-owner-proposal-20261028']=h(Q/'freeze.json')
overrides={row['path']:row for row in qm['files']};by_path={row['path']:row for row in stage['sourcePaths']}
for relative,row in overrides.items():
 by_path[relative]=dict(path=relative,observedPublicSHA256=h(R/relative),candidate=row['candidate'],candidateSHA256=row['candidateSHA256'],changesCurrentPublic=h(R/relative)!=row['candidateSHA256'])
stage['sourcePaths']=list(by_path.values());stage['sourcePathCount']=len(by_path);stage['sourceDeltaPaths']=list(overrides);stage['publicSourceBasisCommit']='67df3bccce';stage['nativeFile2RequiredBeforeQuery3']=True
(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
plan=json.loads((OLD/'run-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_ROOT10_SOURCE_MODELS',caseCount=10,cases=qm['modelCases'],expectedRetainedRoots=10)
plan['privateFiles']={name:h(S/name) for name in ('root_stage_guard.py','source_model_bindings.py','run-selected.py','test_native_query_owner_models.py')}
plan['modelMaps']={'LIFECYCLE_NATIVE_QUERY_MAP':{'keeper':'tests/device/ios/pymobiledevice3_wda_xctest.py','featureObservation':'tests/device/ios/adapters/feature_observation.py','hostOperations':'tests/device/ios/appium_wda_host_ops.js','lease':'tests/device/ios/adapters/touch_lease.py','fixture':'tests/device/ios/self_tests/test_ios_touch_lease.py'}}
plan['requiredPublicDependencies']=sorted(set(plan['requiredPublicDependencies'])|{'tests/device/adapters/normal_feature_state.py','tests/device/adapters/operation_transport_guard.py','tests/device/adapters/script_feature/lock.py','tests/device/ios/adapters/appium_adapter.py','tests/device/ios/adapters/feature_observation.py'})
plan['registryRequirements']['original-keeper-native-query']={'current':1,'reads':[1]}
plan['sourceModelsOnly']=True;plan['qualification']='Actual stdlib loopback HTTP / original sender / fsynced WAL / actual Task+Thread+TouchLease. RSD/WDA/HID/native producers modeled; no SDK/auth/native/whole qualification.'
(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
sup=json.loads((OLD/'supervisor-plan.json').read_bytes());(S/'supervisor-plan.json').write_text(json.dumps(sup,indent=2)+'\n')
registry=R/'tests/device/contract-versions.json';raw=registry.read_text();v=json.loads(raw);v['contracts']['original-keeper-native-query']={'current':1,'reads':[1]};candidate=json.dumps(v,indent=2)+'\n'
# Reviewable proposal only; Root applies OWN KEY on actual current registry.
p=S/'registry-candidate/tests/device/contract-versions.json';p.parent.mkdir(parents=True);p.write_text(candidate)
(S/'registry-own-only.diff').write_text(''.join(difflib.unified_diff(raw.splitlines(True),candidate.splitlines(True),fromfile='a/tests/device/contract-versions.json',tofile='b/tests/device/contract-versions.json')))
(S/'clone-provenance.json').write_text(json.dumps(dict(parent=str(OLD),parentFreezeSHA256=h(OLD/'freeze.json'),sourcePacket=str(Q),sourcePacketFreezeSHA256=h(Q/'freeze.json'),sourceFiles=stage['sourcePathCount'],exactCases=10,fixedOuterSeconds=60,killGraceSeconds=5,modelsSHA256=h(S/'test_native_query_owner_models.py'),rootParentChange='Only explicit list-shaped freeze normalization, all exact packet pins still enforced.',actualRootMap='Required and generated by Root supervisor AFTER publication; NOT generated during agent preparation.'),indent=2)+'\n')
(S/'README.txt').write_text('''ROOT-ONLY Feature14 owned-query10 stage / PRIVATE UNRUN

Dependency: committed67df Source37 -> NativeFile2 reviewed Source2 -> unchanged
OwnedQuery3 frozen7af8795a. Publish exact3 query hunks only after NativeFile2.
Current source-manifest composes38 actual Source paths; broad Root map is taken
only AFTER publication and before any selected target import. Source map absent
or candidate mismatch fails closed. No SDK or device import/execution.

Run only after Root review: from repositoryRoot, PYTHONDONTWRITEBYTECODE=1
python3 <this directory>/root-supervise.py. Fixed prospective60s+kill5; exact10
AST IDs; failfast. Actual Source selected AST/code hash sidecars are diagnostics,
not authentication. All selected Source/SDK/launcher bytes+stats pinned before/
after, actual owned SID/PGID/start before wait and both retained censuses.

The reused runner preserves canonical3 device roots and reviewed PathFinder
private namespace lookup; repository '.' is excluded. Baseline FD/thread/child
census is O_EXCL saved BEFORE target imports. Actual terminal Task/thread/FD/
child checks and two retained-original byte/stat censuses cannot be waived.
Expected10 real TouchLease TD roots is only an expectation until actual run.
Only fixture-local tempfile alias changes. REAL retained TemporaryDirectory
objects survive, original socketpair callbacks and asyncTearDown preserve LIFO.
Models own actual HTTPServer/socket/server thread and query non-daemon Thread;
release real response gate, await original tasks, call real shutdown/server_close
and join actual threads before terminal checks. No fake close/GC/FD allowance.

Parent change is limited to normalizing the new frozen packet's explicitly
pinned list-shaped file manifest into exact hash bindings; no pin is omitted.
Original Native8, Source3 and all failed/passed historical runs stay untouched.
The registry file is a proposal; apply only original-keeper-native-query1 on
actual current registry, retain native-file1 and ALL foreign keys literally.
Query ownership is not native delivery/freshness/candidate/motion/native-end or
whole capability. All those gates remain false. No agent-side run/import.
''')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
# Exact cases match actual concrete model AST before any resolver/import.
tree=ast.parse((S/'test_native_query_owner_models.py').read_bytes());actual=['test_native_query_owner_models.'+c.name+'.'+n.name for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.AsyncFunctionDef) and n.name.startswith('test_')];assert actual==plan['cases'] and len(set(actual))==10
freeze={str(p.relative_to(S)):h(p) for p in sorted(S.rglob('*')) if p.is_file()};(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_FROZEN_UNRUN',files=freeze),indent=2)+'\n')
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_ROOT10_UNRUN',files={str(p.relative_to(P)):h(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n')
print(json.dumps(dict(stageFreeze=h(S/'freeze.json'),parentFreeze=h(P/'freeze.json'),sourcePaths=stage['sourcePathCount'],models=h(S/'test_native_query_owner_models.py'),cases=10,budget='60+5'),indent=2))
