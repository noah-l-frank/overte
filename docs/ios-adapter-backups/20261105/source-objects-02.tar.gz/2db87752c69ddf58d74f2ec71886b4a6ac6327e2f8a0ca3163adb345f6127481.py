"""Explicit Audio11 pair and five disjoint existing private roots.

Reader credentials never authorize Actor publication. Configuration supplies
no native fact, permission grant, source admission or feature completion.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import exact,need
from ios.adapters.avatar_configuration import selector

VERSION=1
ROOTS=('artifactRoot','primaryArtifactRoot','actorArtifactRoot','primaryWholeRoot','actorWholeRoot')

def settings(value,*,target=None):
    exact(value,{'actorTarget'}|set(ROOTS))
    selector(value['actorTarget'])
    if target is not None:need(selector(target)!=value['actorTarget'])
    paths=[]
    for key in ROOTS:
        raw=value[key];need(type(raw) is str and bool(raw));path=Path(raw)
        need(path.is_absolute() and path.resolve(strict=True)==path and path.is_dir())
        from adapters.normal_feature_state import PrivateFeatureState
        PrivateFeatureState(path/'audio11-boundary.json')._parent();paths.append(path)
    need(all(a!=b and a not in b.parents and b not in a.parents for i,a in enumerate(paths) for b in paths[i+1:]))
    return deepcopy(value)


def feature11(value,validate_legacy):
    """Separate additive11 proposal; Root merges its private9/10 grammars.

    Versions1..8 retain their exact grammar. Versions9/10 are deliberately not
    parsed here. Even readable11 does not add Audio to COMPLETE_AREAS.
    """
    need(type(value) is dict and type(value.get('iosFeatureAdapterVersion')) is int and value['iosFeatureAdapterVersion']==11)
    legacy=deepcopy(value);audio=legacy.pop('audio');coordinator=legacy.pop('audioCoordinatorVersion')
    areas=legacy['areas'];need(type(areas) is list and 1<=len(areas)<=10 and all(type(a) is str for a in areas) and len(areas)==len(set(areas)))
    if 'audio' in areas:
        need(type(coordinator) is int and coordinator==1);settings(audio)
    else:need(audio is None and coordinator is None)
    legacy['areas']=[a for a in areas if a!='audio'];legacy['iosFeatureAdapterVersion']=8
    # Validate the literal old envelope even for an Audio-only config. The
    # temporary Scripts member supplies syntax validation, never admission.
    if not legacy['areas']:legacy['areas']=['scripts']
    validate_legacy(legacy);return value


def feature12(value,validate_legacy):
    """Explicit family2 opt-in; no legacy1 parent or capability upgrade."""
    need(type(value)is dict and type(value.get('iosFeatureAdapterVersion'))is int and value['iosFeatureAdapterVersion']==12)
    legacy=deepcopy(value);family=legacy.pop('audioSharedActorFamilyVersion')
    need(type(family)is int and family==2 if 'audio'in legacy['areas']else family is None)
    legacy['iosFeatureAdapterVersion']=11
    feature11(legacy,validate_legacy)
    return value
