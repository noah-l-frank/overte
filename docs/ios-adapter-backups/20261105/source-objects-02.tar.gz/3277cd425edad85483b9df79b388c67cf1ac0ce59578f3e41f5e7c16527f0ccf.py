"""Raw Vulkan-ABI MODEL backed by actual host draw work/event/PNG ownership.

This is CPU rendering and a modeled submission fence, never real Vulkan/native
qualification. Pending/unknown workers retain their real allocation/ownership;
release acknowledgement cannot manufacture their completion or absence.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import base64,hashlib,math,threading,uuid
from copy import deepcopy
from io import BytesIO
from PIL import Image,ImageDraw
from lifecycle_moving_raw_world_renderer import rotate


def project(point,view,extent):
    inverse=[-v for v in view['rotation'][:3]]+[view['rotation'][3]]
    local=rotate(inverse,[a-b for a,b in zip(point,view['position'])]);m=view['projection'];v=local+[1.]
    clip=[sum(m[row*4+i]*v[i]for i in range(4))for row in range(4)]
    if clip[3]<=0:raise ValueError('Independent renderer vertex is behind the actual camera')
    return [(clip[0]/clip[3]+1)*extent[0]/2,(1-clip[1]/clip[3])*extent[1]/2]


class RawVulkanModel:
    def __init__(self,state,browser,completed):
        self.state,self.browser,self.on_completed=state,browser,completed;self.birth=uuid.uuid4().hex;self.sequence=0;self.rows={};self.lock=threading.RLock()
        self.allow_fence=threading.Event();self.allow_fence.set();self.last_query=None;self.current_packet=None;self.commands=[];self.closed=False

    def stamp(self):return self.state.stamp()['epochMs']

    def _draw(self,row):
        try:
            recorded=self.stamp();snapshot=self.state.render_snapshot();begun=self.stamp()
            extent=[1600,1000];image=Image.new('RGBA',tuple(extent),(95,95,95,255));draw=ImageDraw.Draw(image)
            vertices=[project(p,snapshot['view'],extent)for p in snapshot['vertices']];calls=[]
            for index,face in enumerate(snapshot['faces']):
                polygon=[tuple(vertices[i])for i in face];draw.polygon(polygon,fill=(45+index*17,100+index*7,170-index*9,255));calls.append(dict(kind='mesh-face',vertices=polygon))
            marker=snapshot['marker']
            if marker is not None:
                # Sample the independent page timer's last actual HTTP image;
                # never derive challenge pixels from requestId/ticket/expected.
                if not self.browser.image_ready.wait(timeout=1):raise TimeoutError('Actual page callback has not produced an image')
                raw,page=self.browser.image(marker['sourceUrl'])
                p,q=marker['position'],marker['rotation'];w,h=marker['dimensions'][:2]
                corners=[[a+b for a,b in zip(p,rotate(q,v))]for v in([-.5*w,-.5*h,0],[.5*w,-.5*h,0],[.5*w,.5*h,0],[-.5*w,.5*h,0])]
                pixels=[project(v,snapshot['view'],extent)for v in corners]
                box=[math.floor(min(v[0]for v in pixels)),math.floor(min(v[1]for v in pixels)),math.ceil(max(v[0]for v in pixels)),math.ceil(max(v[1]for v in pixels))]
                with Image.open(BytesIO(raw))as card:
                    card=card.convert('RGBA').resize((box[2]-box[0],box[3]-box[1]),resample=Image.Resampling.NEAREST)
                    image.paste(card,tuple(box[:2]));calls.append(dict(kind='world-web',box=box,page=page))
            completed=self.stamp();stream=BytesIO();image.save(stream,format='PNG');png=stream.getvalue();pixels=image.tobytes()
            submitted=self.stamp()
            with self.lock:row.update(snapshot=snapshot,drawCalls=calls,submitted=True,submittedEpochMs=submitted,png=png,pixels=pixels)
            # An independent real Event models the queue/fence boundary. Tests
            # may hold it BEFORE submission; no read call can complete it.
            if not self.allow_fence.wait(timeout=5):return
            fence=self.stamp();readback=self.stamp();captured=self.stamp()
            trace=dict(completedDrawTraceVersion=1,frameId=uuid.uuid4().hex,recordedEpochMs=recorded,recordedView=snapshot['view'],
                begunEpochMs=begun,completedEpochMs=completed,drawSource='vulkan-api-issued',renderer='forward',view='main-mono',
                forwardBatches=1 if calls else 0,forwardDrawCalls=len(calls),hazeBatches=0,hazeDrawCalls=0,mirrorBatches=0,mirrorDrawCalls=0)
            with self.lock:
                self.sequence+=1
                row['frame']=dict(vulkanWorldFrameVersion=1,commandId=row['query']['commandId'],requestId=row['query']['requestId'],instance=self.birth,
                    sequence=self.sequence,processId=self.state.pid,requestedEpochMs=row['requestedEpochMs'],capturedEpochMs=captured,
                    source=dict(backend='vulkan',stage='tone-map-before-hud',view='main-mono',sourceExtent=extent,targetExtent=extent,
                        renderTrace=trace,frameIndex=row['index'],submittedEpochMs=submitted,fenceObservedEpochMs=fence,
                        pixelFormat='rgba8-top-left',pixelsReadEpochMs=readback,image=dict(bytes=len(png),sha256=hashlib.sha256(png).hexdigest(),
                            pixelSha256=hashlib.sha256(pixels).hexdigest(),width=extent[0],height=extent[1])))
                row['gpu_buffer']=None
                completed_frame=deepcopy(row['frame'])
                if row['retired']:row['png']=row['pixels']=row['frame']=None
                row['completed'].set()
            self.on_completed(deepcopy(row['query']),completed_frame)
        except BaseException as error:
            with self.lock:row['failure']=type(error).__module__+'.'+type(error).__qualname__
        finally:
            with self.lock:row['worker_returned']=True

    def command(self,query):
        # Use the existing unchanged closed grammar, solely to reject extra
        # desired values. The modeled producer constructs its own raw result.
        from adapters.native_vulkan_world_frame import command
        command(query);key=query['requestId'];operation=query['operation'];started=self.stamp()
        with self.lock:
            assert not self.closed;self.commands.append(deepcopy(query));self.last_query=deepcopy(query)
            if operation=='read':
                if key in self.rows:raise RuntimeError('Original modeled frame read cannot be replayed')
                row=dict(query=deepcopy(query),requestedEpochMs=started,index=len(self.rows),retired=False,submitted=False,
                    completed=threading.Event(),frame=None,png=None,pixels=None,gpu_buffer=bytearray(1600*1000*4),worker_returned=False,failure=None)
                worker=threading.Thread(target=self._draw,args=(row,),name='explicit-vulkan-abi-model-'+key[4:],daemon=False)
                row['worker']=worker;self.rows[key]=row;worker.start()
            else:
                row=self.rows[key]
                if operation=='release':
                    row['retired']=True
                    # Original immutable disk pixels stay under the parent;
                    # only this modeled source's retained allocation retires.
                    if row['completed'].is_set():row['png']=row['pixels']=row['frame']=None
        if operation!='read':
            with self.lock:self.current_packet=self._storage(query,started)
        return self.original()

    def original(self):
        with self.lock:
            query=deepcopy(self.last_query);row=self.rows[query['requestId']]
            if query['operation']=='read':
                if row['frame']is not None:return deepcopy(row['frame'])
                return dict(commandId=query['commandId'],requestId=query['requestId'],pending=True)
            return deepcopy(self.current_packet)

    def _storage(self,query,requested):
        row=self.rows[query['requestId']];self.sequence+=1;operation=query['operation']
        retired=row['retired'];worker_alive=row['worker'].is_alive();pending=not row['completed'].is_set();present=not retired
        png=row['png'];source=dict(retired=retired,present=present,callbacks=int(worker_alive),gpuPending=pending,
            metadataBytes=len(str(row['frame']).encode())if present and row['frame']is not None else 0,
            pngBytes=len(png)if present and png is not None else 0,gpuBufferBytes=0 if row['gpu_buffer']is None else len(row['gpu_buffer']))
        if operation=='release':source['performed']=True
        if operation=='read-bytes':
            assert present and png is not None and not pending
            offset=query['offset'];source.update(offset=offset,data=base64.b64encode(png[offset:offset+65536]).decode())
        return dict(vulkanWorldStorageVersion=1,commandId=query['commandId'],requestId=query['requestId'],operation=operation,
            instance=self.birth,sequence=self.sequence,processId=self.state.pid,requestedEpochMs=requested,capturedEpochMs=self.stamp(),source=source)

    def close(self):
        self.allow_fence.set()
        for row in self.rows.values():row['worker'].join(timeout=5)
        assert not any(row['worker'].is_alive()for row in self.rows.values())
        self.closed=True
