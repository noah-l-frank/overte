"""Metadata-only writer: requires actual Root59 terminal PASS before cloning."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-scoped-cleanup-remaining14-root-preparation-20261029/59-scoped-cleanup-remaining14';PACK=T/'lifecycle-original-owner-resource-scoped-forward-prepare-import-composition-20261029';P=T/'lifecycle-original-owner-resource-scoped-forward7-root-preparation-20261029';S=P/'60-resource-scoped-forward7';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((B/'root-run-first/report.json').read_text());assert report['exitCode']==0 and report['allPinsEqual'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses']
for n,d in json.loads((PACK/'freeze.json').read_text())['files'].items():assert H(PACK/n)==d
P.mkdir(mode=0o700);S.mkdir(mode=0o700)
for n,d in json.loads((B/'freeze.json').read_text())['files'].items():
 assert H(B/n)==d;dest=S/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/n,dest)
for n in ['test_resource_scoped_forward_models.py','test_resource_scoped_forward_routes.mjs']:shutil.copyfile(PACK/n,S/n)
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((B/'prior-retained-original-pins.json').read_text());root=B/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==report['retainedFiles']
for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
for n in ['report.json','thread-report.json','process-binding.json']:p=B/'root-run-first'/n;prior[str(p)]=pin(p)
(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n');manifest=json.loads((PACK/'manifest.json').read_text());own={r['path']:r for r in manifest['files']};registry=[];diff=[]
for rel in ['tests/device/contract-versions.json','tests/device/validate_contract_versions.py']:
 base=S/'actual-current-registry-base/repo'/rel;out=S/'actual-current-own2/repo'/rel
 for path in (base,out):path.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(R/rel,base);raw=base.read_text()
 if rel.endswith('.json'):
  old='    "ios-original-keeper-touch": {"current": 3, "reads": [1, 2, 3]},'
  new='    "ios-original-keeper-touch": {"current": 4, "reads": [1, 2, 3, 4]},\n    "original-keeper-motion-profile": {"current": 2, "reads": [1, 2]},'
 else:
  old='    "ios-original-keeper-touch": 3,'
  new='    "ios-original-keeper-touch": 4,\n    "original-keeper-motion-profile": 2,'
 assert raw.count(old)==1 and '"original-keeper-motion-profile"' not in raw
 text=raw.replace(old,new,1);out.write_text(text);diff.extend(difflib.unified_diff(raw.splitlines(True),text.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 own[rel]=dict(path=rel,baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out));registry.append(own[rel])
(S/'registry-own2-forward.diff').write_text(''.join(diff));shutil.copyfile(PACK/'source2.diff',S/'source2-forward.diff')
stage=json.loads((S/'source-manifest.json').read_text());changes=[]
for row in stage['sourcePaths']:
 rel=row['path'];actual=H(R/rel)
 if rel in own:row.update(candidate=own[rel]['candidate'],candidateSHA256=own[rel]['candidateSHA256'],observedPublicSHA256=actual,changesCurrentPublic=actual!=own[rel]['candidateSHA256']);continue
 if actual!=row['candidateSHA256']:
  out=S/'actual-current-dependency/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(out),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
stage.update(stage=60,name=S.name,status='PRIVATE_UNRUN_SCOPED_FORWARD_MODEL7',caseCount=7,pythonCaseCount=4,nodeCaseCount=3,initialTimeoutSeconds=60,sourceDeltaPaths=[r['path'] for r in manifest['files']],exactPublicMutationPlan='Root ONLY reviewed Begin2 Source2 and ownTouch4/MotionProfile2 hunks; preserveforeignkeys.');stage['orderedParentFreezes'][PACK.name]=H(PACK/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
plan=json.loads((S/'run-plan.json').read_text());selection=json.loads((PACK/'test-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_SCOPED_FORWARD7',cases=selection['pythonCases'],caseCount=4,totalCaseCount=7,expectedRetainedRoots=8,initialOuterSeconds=60,nodeEntry='test_resource_scoped_forward_routes.mjs',nodeCaseCount=3,nodeInnerSeconds=15)
plan['modelMaps']['LIFECYCLE_SCOPED_FORWARD_NODE_MAP']={'hostops':'tests/device/ios/appium_wda_host_ops.js'}
for n in ['test_resource_scoped_forward_models.py','test_resource_scoped_forward_routes.mjs']:plan['privateFiles'][n]=H(S/n)
for row in registry:
 if row['path'].endswith('.json'):
  contracts=json.loads(Path(row['candidate']).read_text())['contracts']
  for name in ['ios-original-keeper-touch','original-keeper-motion-profile']:plan['registryRequirements'][name]=contracts[name]
plan['requiredPriorActualPASS']=dict(path=str(B/'root-run-first/report.json'),sha256=H(B/'root-run-first/report.json'),actualExitCode=0)
(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n');settings=json.loads((S/'supervisor-plan.json').read_text());settings['initialSeconds']=60;(S/'supervisor-plan.json').write_text(json.dumps(settings,indent=2)+'\n')
(S/'clone-provenance-forward7.json').write_text(json.dumps(dict(parent59Freeze=H(B/'freeze.json'),packetFreeze=H(PACK/'freeze.json'),actual59ReportSHA256=H(B/'root-run-first/report.json'),actual59OriginalFiles=report['retainedFiles'],totalPriorPinnedFiles=sum('sha256' in r for r in prior.values()),cases=7,pythonCases=4,nodeCases=3,initialSeconds=60,killAfterSeconds=5,nodeInnerSeconds=15,realRoots=8,sourceDependenciesChanged=changes,executed=False),indent=2)+'\n');(S/'README-forward7.txt').write_text('Root60 prospective afteractual59PASS. Optionalsameoperation Begin2: actuallocalbirth owner/Resource/Source/loop/receipt guard BEFOREWorker/Down, NodeOwner check BEFOREWDA/dispatch. OldMotion1/cleanup literal.4actualReceiver+3actualNode source models,60+kill5/Node15/8realTD. NoSDKimports; native/SDK/Auth/canonical/end/wholefalse. Allprioractual59files/reports plus58/56/55/oldtimeout retained. Noagentimports/tests/PUB. Root mustpublishreviewedSource2+own2only andcreateactualfullmapbeforeimports.\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(stage=str(S),parentFreeze=H(P/'freeze.json'),stageFreeze=H(S/'freeze.json'),priorFiles=sum('sha256' in r for r in prior.values()),sourceChanges=changes),indent=2))
