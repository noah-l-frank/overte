"""Root-only fresh metadata for exactly one unchanged Assets Source2 case.

No subject import, child, model execution or corpus census is performed here.
The current Root must separately guard all prior originals around the utility.
"""
from pathlib import Path
import argparse,ast,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from project_namespace_admission import project_namespace_admission
from source_execution_readiness import qualification
SOURCE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/assets-current-checkpoint-owned-originals-source2-complete-save-failure-domain-private-20261105'
SUBJECT_SHA='42748bf52f23de932810d6cea3546c4fe04a6efd5e6e67383901f97bd6f8a625'
HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
C25=REPO/'.ios-host-tmp/assets-picker3-reserved-phase-controller25-qualified-diagnostic14-source-private-20261104'
EXECUTORS=('run-one.py','supervise-one.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','source_execution_readiness.py',
 'readonly-shared-stdlib-sources.json','class_cleanup_custody.py','definition_custody.py','project_namespace_admission.py','third-party-source-declarations.json',
 'fixed-ten-groups.json','SOURCE-OVERLAYS.json','assets_resources.py','fixture_common.py','scoped_ports.py','backend_dirfd_ports.py','monitoring_observer.py','typed_observer.py',
 'c10d_admission.py','backend_utility_readiness.py','definition-inventory.json','required-definition-closure.json')
def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','expected-head','destination','group','source-review-freeze','source-review-sha'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--root-reviewed-source2-and-bootstrap',required=True,action='store_true')
    args=parser.parse_args();assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and all(c in'0123456789abcdef'for c in args.expected_head)and head()==args.expected_head
    groups=json.loads((SOURCE/'fixed-ten-groups.json').read_text())['groups'];assert args.group in groups;recipe=groups[args.group]
    assert len(recipe['caseIds'])==1 and recipe['wallSeconds']==300 and recipe['killGraceSeconds']==5
    physical={}
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        row=pin(path)
        if digest is not None:assert row['sha256']==digest
        previous=physical.setdefault(str(path),row);assert previous==row
        return row
    def frozen(folder,name,digest):
        keep(folder/name,digest);value=json.loads((folder/name).read_text());assert type(value['files'])is dict
        for leaf,row in value['files'].items():
            assert not Path(leaf).is_absolute()and '..'not in Path(leaf).parts
            keep(folder/leaf,row if type(row)is str else row['sha256'])
        return value
    frozen(SOURCE,'source-freeze.json',args.source_freeze);frozen(SUBJECT,'source-freeze.json',SUBJECT_SHA)
    frozen(REPO/'.ios-host-tmp/assets-checkpoint-owned-source2-ten-bootstrap1-closed-code-preparation-20261105','source-freeze.json','b5c788b8ce8d97f778e17e958c52e35b4a8b9560da2b41d9808c39515daad201')
    frozen(REPO/'.ios-host-tmp/assets-checkpoint-owned-source2-ten-bootstrap2-exact-own-adapter-metadata-read-code-preparation-20261105','source-freeze.json','67a7a5a13018989b5012f5a2b0e2815b94778289cd8964c98d7968a46584f851')
    review=Path(args.source_review_freeze);assert review.is_absolute()and review.is_relative_to(REPO/'.ios-host-tmp')
    frozen(review.parent,review.name,args.source_review_sha)
    composition=json.loads((SUBJECT/'COMPOSED-SOURCE-MANIFEST.json').read_text());assert len(composition['origins'])==88
    for row in composition['origins']:keep(row['path'],row['sha256'])
    current,current_pins=qualification(pin);physical.update(current_pins);keep(SOURCE/'closed_import_origins.py',HELPER)
    from backend_utility_readiness import boundary_qualification
    backend,backend_pins=boundary_qualification(REPO,pin,SOURCE);physical.update(backend_pins)
    # Existing public roots declare canonical names and the genuinely used bare
    # self-test names. All physical sources are pinned before classification.
    device=REPO/'tests/device';roots=(device,device/'self_tests',device/'ios/self_tests');declared={}
    for root in roots:
        for path in sorted(root.rglob('*.py')):
            parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
            if package:parts.pop()
            if parts:
                row=keep(path);declared.setdefault('.'.join(parts),dict(path=str(path),sha256=row['sha256'],package=package))
    overlays=json.loads((SOURCE/'SOURCE-OVERLAYS.json').read_text());assert len(overlays)==80
    for row in overlays:
        actual=keep(row['path'],row['sha256']);declared[row['module']]=dict(path=row['path'],sha256=actual['sha256'],package=row['package'])
    from definition_custody import inventory
    definitions=json.loads((SOURCE/'definition-inventory.json').read_text())
    for name,row in definitions.items():
        assert name in declared and declared[name]['path']==row['path']and declared[name]['sha256']==row['sha256']
        keep(row['path'],row['sha256']);assert inventory(row['path'])==row['inventory'],('Actual definition source changed',name)
    required=json.loads((SOURCE/'required-definition-closure.json').read_text());assert set(required)==set(definitions)
    # Actual picker with_name JS and actual public ROOT-derived QML operands.
    node_args=['node',str(device/'ios/self_tests/assets_picker_host.js'),str(REPO/'interface/resources/qml/hifi/dialogs/TabletAssetServer.qml'),
      str(REPO/'interface/resources/qml/dialogs/NativeFileBrowser.qml'),str(REPO/'interface/resources/qml/hifi/tablet/TabletNavigation.qml'),
      str(REPO/'interface/resources/qml/hifi/dialogs/NativeModelTree.qml'),'usage']
    for path in node_args[1:-1]:keep(path)
    node_path=Path('/usr/bin/node');real_node=node_path.resolve(strict=True);node=keep(real_node)
    node_pin=dict(path=str(node_path),realPath=str(real_node),device=node['device'],inode=node['inode'],sha256=node['sha256'])
    third={};external=json.loads((SOURCE/'third-party-source-declarations.json').read_text());assert len(external)==39
    for name,row in external.items():
        assert name=='PIL'or name.startswith('PIL.')or name=='defusedxml'or name.startswith('defusedxml.')
        keep(row['path'],row['sha256']);third[name]=dict(path=row['path'],sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14');stdns={};suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    for stdlib_dir,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(stdlib_dir);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink());relative=folder.relative_to(std)
        if relative.parts and all(n.isidentifier()for n in relative.parts)and not(folder/'__init__.py').is_file():stdns['.'.join(relative.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix=='.py'or str(path).endswith(suffixes):keep(path)
    python=Path(sys.executable).resolve(strict=True);python_pin=keep(python)
    # Explicit actual head admission; historical Source2 headers are not rebound.
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ');gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for path in(REPO/'.git',gd/'HEAD',gd/'commondir',gd/'index'):keep(path)
    keep(next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs'))
    own_reads={str(path)for path in map(Path,physical)if path.is_relative_to(device/'adapters/appium')}
    own_adapter=device/'ios/adapters/appium_adapter.py'
    assert own_adapter.resolve(strict=True)==own_adapter and str(own_adapter)in physical
    assert pin(own_adapter)==physical[str(own_adapter)]
    own_reads.add(str(own_adapter)) # Exact existing own source; metadata-pin frame only.
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'
    assert dest.name.startswith('assets-checkpoint-'+args.group+'-prepared-')and not dest.exists()
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    dest.mkdir(mode=0o700)
    for name in EXECUTORS:
        path=dest/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        row=keep(path)
        if path.suffix=='.py'and name not in('run-one.py','supervise-one.py'):
            assert path.stem not in declared;declared[path.stem]=dict(path=str(path),sha256=row['sha256'],package=False)
    projects,namespaces,alias_data=project_namespace_admission(declared,[str(device)])
    assert(projects,namespaces,alias_data)==project_namespace_admission(declared,[str(device)])
    assert all(name in projects for name in definitions)
    plan=dict(status='PRIVATE_ASSETS_SOURCE2_ONE_OF_TEN_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(dest),actualPublicHead=args.expected_head,
      sourceFreeze=args.source_freeze,subjectSourceFreeze=SUBJECT_SHA,sourceReview=dict(path=str(review),sha256=args.source_review_sha),
      qualifiedSourceExecution=current,subjectHelperSha256=HELPER,backendBoundaryQualification=backend,
      sourceAndBinaryPins=physical,modules=projects,namespaces=namespaces,thirdPartyModules=third,subjectOriginModules=definitions,definitionInventory=definitions,
      groupName=args.group,cases=recipe['caseIds'],resourceRecipe=recipe,wallSeconds=300,killGraceSeconds=5,expectedTemporaryDirectories=4,expectedNestedCleanupCalls=7,
      expectedNode=1,expectedHTTP=2,expectedPickerNodeArgv=node_args,nodePin=node_pin,
      SDKExecutions=0,overteNativeQueries=0,oldCorpusInputs=0,globalOriginalScans=0,realNetwork='exact-two-owned-loopback-listeners-only',
      pythonExecutable=dict(path=str(python),pin=python_pin),declaredProjectAliases=declared,projectAliasAdmission=alias_data,
      productionAndTestOverlays=overlays,historicalCompositionOriginals=composition,ownForbiddenMetadataReadPaths=sorted(own_reads),
      trustedHostBootstrap='Initial interpreter/stdlib/control modules are held physical HOSTBOOTSTRAP; only genuine project delegates execute fresh through current C10d.',
      normalAction2Qualified=False,phaseAdmission=None,remaining6Admission=None,nativeCompiled=False,nativeQualified=False,wholeQualified=False)
    plan['originPlan']=dict(modules=projects,namespacePackages=namespaces,projectAliasAdmission=alias_data,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=stdns,
      stdlibRoots=[str(std)],pythonExecutable=plan['pythonExecutable'],physicalPins=physical)
    output=dest/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,sort_keys=True,indent=2);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),sha256=pin(output)['sha256'],group=args.group,cases=recipe['caseIds'],targetStarts=0,globalCensuses=0)))
if __name__=='__main__':main()
