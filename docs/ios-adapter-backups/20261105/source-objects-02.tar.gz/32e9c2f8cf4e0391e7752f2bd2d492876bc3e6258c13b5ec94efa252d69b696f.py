from pathlib import Path
import ast,difflib,hashlib,json,shutil
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-world-hold-child-profile-review-packet-20261029';P=T/'lifecycle-original-owner-normal-child-retained-alias-overlay-20261029';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P.mkdir(mode=0o700)
for n,d in json.loads((B/'freeze.json').read_text())['files'].items():assert H(B/n)==d
rows=[]
rel='tests/device/ios/adapters/lifecycle_world_hold_runtime.py';base=B/'candidate/repo'/rel;s=base.read_text();old="        self.binding=deepcopy(source['binding']);self.owner=None;self.lease=None;self.preparation=None";new=old+';self._lease=None';assert s.count(old)==1;s=s.replace(old,new,1)
old="        need(self.source['binding']==self.binding and self.source['check']() is not False);return True";new="""        need(self.source['binding']==self.binding and self.source['check']() is not False
            and self.lease is self._lease);return True
    def retained_lease(self):
        # This exact private born transport survives mutable public aliases.
        # It is only a sender; the child still proves the original Resource.
        need(self._lease is None or type(self._lease) is _OriginalKeeperMotionLease)
        return self._lease""";assert s.count(old)==1;s=s.replace(old,new,1)
old="        self.owner=value['ownerInstance'];self.lease=_OriginalKeeperMotionLease(self.source,self.run,self.owner,value['reference'],path,seconds)\n        prepared=await self.lease._request";new="        self.owner=value['ownerInstance'];lease=_OriginalKeeperMotionLease(self.source,self.run,self.owner,value['reference'],path,seconds)\n        self._lease=self.lease=lease # BEFORE the preparation may have an unknown return.\n        prepared=await lease._request";assert s.count(old)==1;s=s.replace(old,new,1)
old="        self.lease=_OriginalKeeperMotionLease(self.source,self.run,self.owner,value['reference'],coordinates(frame),seconds)";new="        self._lease=self.lease=_OriginalKeeperMotionLease(self.source,self.run,self.owner,value['reference'],coordinates(frame),seconds)";assert s.count(old)==1;s=s.replace(old,new,1)
for method in ['inspect','release','settle']:
 old=f"    async def {method}(self):need(self.lease is not None);return await self.lease.{method}()";new=f"    async def {method}(self):\n        lease=self.retained_lease();need(lease is not None);return await lease.{method}()";assert s.count(old)==1;s=s.replace(old,new,1)
out=P/'candidate/repo'/rel;out.parent.mkdir(parents=True);out.write_text(s);ast.parse(s);rows.append(dict(path=rel,base=str(base),baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out)))
rel='tests/device/ios/adapters/lifecycle_world_hold.py';base=B/'candidate/repo'/rel;s=base.read_text();old='        self.original_child=self._original_child=original_child';new=old+"\n        self._child_lease_owner=None if original_child is None else original_child.retained_lease\n        self._child_bind_preparation=None if original_child is None else original_child.bind_preparation";assert s.count(old)==1;s=s.replace(old,new,1)
old="""        if self.version==2:
            need(self.original_child is self._original_child)
            if self.lease is not None:
                need(self.lease is self.original_child.lease);return self.lease
            if self.original_child.lease is None:
                self.prepared();self.original_child.bind_preparation(self.frame(1),self.state['seconds'])
            self.lease=self.original_child.lease;return self.lease"""
new="""        if self.version==2:
            # Captured original callbacks select no new endpoint/HID/Source.
            # Current public aliases may refuse NEW proof, never old Up.
            lease=self._child_lease_owner()
            if lease is None:
                self.prepared();self._child_bind_preparation(self.frame(1),self.state['seconds'])
                lease=self._child_lease_owner()
            need(lease is not None);self.lease=lease;return lease"""
assert s.count(old)==1;s=s.replace(old,new,1);out=P/'candidate/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s);ast.parse(s);rows.append(dict(path=rel,base=str(base),baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out)))
name='test_normal_child_world_hold_models.py';base=B/name;s=base.read_text()+'''
    async def test_public_connection_and_lease_aliases_cannot_redirect_or_block_original_up_after_actual_down(self):
        await self.owner.act();original=self.owner.lease;connection=self.owner._original_child;called=[]
        class Foreign:
            async def release(self):called.append('foreign-release');raise AssertionError('Foreign transport used')
            async def inspect(self):called.append('foreign-inspect');raise AssertionError('Foreign transport used')
            async def settle(self):called.append('foreign-settle');raise AssertionError('Foreign transport used')
        foreign=Foreign();self.owner.lease=foreign;connection.lease=foreign;self.owner.original_child=foreign
        commands=len(self.commands)
        with self.assertRaises((RuntimeError,ValueError)):await self.owner.release()
        self.assertEqual([],called);self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        self.assertEqual(commands,len(self.commands));self.assertIsNone(self.owner.state['released'])
        self.assertIs(original,connection.retained_lease())
        status=await original.inspect();self.assertFalse(status['hostResponsibility'])
        await original.settle();self.assertTrue(self.source._closing);self.assertEqual([],called)
''';out=P/'candidate'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s);ast.parse(s);rows.append(dict(path=name,base=str(base),baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out)))
(P/'source2-test1.diff').write_text(''.join(''.join(difflib.unified_diff(Path(row['base']).read_text().splitlines(True),Path(row['candidate']).read_text().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path'])) for row in rows))
(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE_FROZEN_SOURCE2_TEST1_UNRUN',parentCanonicalFreeze=H(B/'freeze.json'),files=rows,oldDefault1Unchanged=True,retainedUpBeforePublicAliasCurrentGuard=True,newForwardAndProofChecksUnchanged=True,actualChildOwnerResourceGuardUnchanged=True,newCases=4,prospectiveInitialSeconds=90,killAfter=5,realRoots=12,nativeSDKAuthWholeQualified=False,testsRun=False,targetImports=False),indent=2)+'\n');(P/'README.txt').write_text('Separate minimal Canonical cleanup correction after same actual Down. Original private typed sender is captured BEFORE prepare has unknown effect; original callbacks are captured by the existing Hold owner. Public owner.original_child/owner.lease/connection.lease aliases may block NEW forward/proof via existing current checks, but cannot redirect/block original Up/drain. No Source/endpoint/session/HID/auth/candidate factory added. Actual child expectedOwner+Resource+bornWorker checks remain. New fourth actualnormal+HTTP+receiver case changes public aliases afterDown, expectsUponce/noForeignCall/noReleasedproof; original3 cases unchanged. Source2/test1 overlay depends on parent982f; compose with separatelyfrozenSessionBirth2, oldfreezespreserved. Prospective4/90+5/12realTD;18legacy separately. UNRUN; no agentTargetimports/tests/PUB.\n')
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(path=str(P),freeze=H(P/'freeze.json'),diff=H(P/'source2-test1.diff'),files=rows),indent=2))
