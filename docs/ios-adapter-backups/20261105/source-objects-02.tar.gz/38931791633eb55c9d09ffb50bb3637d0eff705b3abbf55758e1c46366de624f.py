"""Fresh-process parser baselines; empty actual IO scopes, no End authority."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from ios.self_tests.retained_host_roots import retain_owned_root


CHILD=r"""
import sys
from pathlib import Path
from contextlib import ExitStack
from types import ModuleType
from adapters.normal_ui import NativeUIError
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.snapshot_photos_end_originals import SnapshotPhotosEndOriginals
from ios.adapters import snapshot_photos_end_read_area as source
from adapters.native_feature_observation import validate
from ios.adapters import assets_controls
# Importing this EXISTING explicit in-memory producer calls no test or SDK.
# Its historical sys.path helper is restored immediately, not a foreign root.
paths=list(sys.path)
from self_tests.test_native_feature_observation import Boundary
sys.path[:]=paths
lazy=('adapters.native_animation_history','adapters.native_animation_caller',
 'ios.adapters.assets_bundle_controls','ios.adapters.assets_tree_controls','ios.adapters.assets_usage_controls')
assert all(name not in sys.modules for name in lazy),'Process must actually start cold'
root=Path(sys.argv[1]);mode=sys.argv[2]
roots={name:root/name for name in ('main','photos','archive')};locks={}
for name,path in roots.items():path.mkdir(mode=0o700);locks[name]=ScriptSourceLock(path/'script-feature-sources.lock')
binding=dict(sourceRevision='a'*40,artifactSha256='b'*64,processIdentity='42',sessionId='owned-session',generation=0,targetFingerprint='c'*64)
packet=Boundary();request='ios-'+'1'*32;packet.send(dict(commandId=request))
with ExitStack() as held:
 for lock in locks.values():held.enter_context(lock.held())
 with source.scope(roots,locks,{name:dict(binding) for name in roots},'a'*32,
        'https://controlled.invalid/feature-fixture/v1/runs/'+'a'*32+'/') as area:
  assert all(name in sys.modules for name in lazy),'Known actual lazy definitions missing at baseline'
  baseline=area.parsers
  # Actual consumers from the failing Page original path; no decoder/pin swap.
  validate(packet.sample,request,123,20000)
  assert assets_controls.control_id('snapshot.capture') is False
  area.check();assert baseline==area.parser_module.parser_identity()
  if mode!='known-consumers':
   animation=sys.modules[lazy[0]];controls=sys.modules[lazy[2]]
   old_code=animation.clip.__code__;old_ids=controls.IDS;added=None
   try:
    if mode=='changed-code':
     def changed(value):return value
     animation.clip.__code__=changed.__code__
    elif mode=='changed-constant':controls.IDS=controls.IDS|{'assets.unreviewed-control'}
    elif mode=='unknown-late-module':
     added='ios.adapters.snapshot_unreviewed_late';assert added not in sys.modules
     sys.modules[added]=ModuleType(added)
    else:raise AssertionError('Unknown test mode')
    refused=False
    try:area.check()
    except NativeUIError:refused=True
    assert refused,'Full original parser guard was weakened'
   finally:
    animation.clip.__code__=old_code;controls.IDS=old_ids
    if added is not None:del sys.modules[added]
print('ACTUAL_COLD_SCOPE_PASS',mode)
"""


class PhotosEndColdParserScopeTests(unittest.TestCase):
    def run_mode(self,mode):
        temporary=tempfile.TemporaryDirectory(prefix='photos-cold-parser-');self.addCleanup(temporary.cleanup)
        root=Path(temporary.name);root.chmod(0o700);retain_owned_root(temporary,expected_root=root)
        repo=Path(__file__).resolve().parents[4]
        environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join(str(repo/name) for name in
            ('tests/device','tests/device/self_tests','tests/device/ios/self_tests')))
        result=subprocess.run([sys.executable,'-B','-c',CHILD,str(root),mode],cwd=repo,env=environment,
            capture_output=True,text=True,timeout=20)
        (root/'child-stdout.txt').write_text(result.stdout);(root/'child-stderr.txt').write_text(result.stderr)
        self.assertEqual(0,result.returncode,result.stdout+'\n'+result.stderr)
        self.assertIn('ACTUAL_COLD_SCOPE_PASS '+mode,result.stdout)
    def test_fresh_minimal_imports_keep_actual_native_and_assets_consumers_inside_original_baseline(self):self.run_mode('known-consumers')
    def test_preloaded_native_validator_code_change_still_refuses_current_scope(self):self.run_mode('changed-code')
    def test_preloaded_assets_constant_change_still_refuses_current_scope(self):self.run_mode('changed-constant')
    def test_unknown_parser_module_loaded_after_baseline_still_refuses_current_scope(self):self.run_mode('unknown-late-module')


if __name__=='__main__':unittest.main()
