"""Version2 post-controller/native motion/CPU palette; no rendered verdict.

The ordinary acquiring owner retains native/phase/OFS/file lifetime duties.
This codec and its separately opt-in source supply no feature capability.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import json
import re
from adapters.native_feature_observation import exact,integer,need,number,fresh
from adapters.native_animation_history import validate as history,accept,clip_run
from adapters.emote_rig_measurements import playback,source as emote_source,actual_state
from feature_journeys.contract import typed_equal
from ios.adapters.places_model import IOSPlacesModel
ACTION='feature-ios-emote-palette'
FILE=ACTION+'.json'
LIMIT=250000


def identity(value):
    need(type(value)is str and re.fullmatch('[0-9a-f]{32}',value)is not None)


def command(value):
    exact(value,{'schemaVersion','commandId','action','runId'})
    need(type(value['schemaVersion'])is int and value['schemaVersion']==1 and value['action']==ACTION
        and type(value['commandId'])is str and re.fullmatch('ios-[0-9a-f]{32}',value['commandId'])is not None)
    identity(value['runId']);return value


def animation(value,epoch):
    fields={'rigId','capturedEpochMs','evaluationSequence','animationsEnabled','graphLoaded','overrideActive','joints','history'}
    exact(value,fields|({'clip'}if 'clip'in value else set()))
    need(integer(value['rigId'],1)and integer(value['evaluationSequence'],1)
        and value['animationsEnabled']is value['graphLoaded']is True
        and type(value['overrideActive'])is bool and type(value['joints'])is list and 1<=len(value['joints'])<=256)
    fresh(value['capturedEpochMs'],epoch)
    for pose in value['joints']:
        need(type(pose)is list and len(pose)==7 and all(number(n)for n in pose)
            and .9<=sum(n*n for n in pose[:4])<=1.1)
    history(value['history'],value,epoch);need(value['history']['historyVersion']==2)
    if value['overrideActive']:
        from adapters.native_animation_history import clip
        need('clip'in value);clip(value['clip'])
        need(value['clip']['url']==value['clip']['requestedUrl']and value['clip']['loadedFrames']>0
            and value['clip']['evaluationSequence']>0)
        fresh(value['clip']['evaluatedEpochMs'],epoch)
    else:need('clip'not in value)
    return value


def validate(value,query,pid,epoch=None,previous=None):
    command(query)
    exact(value,{'iosEmotePaletteVersion','requestId','runId','instance','sequence','processId','clockDomain','clockBefore','clockAfter','source'})
    need(type(value['iosEmotePaletteVersion'])is int and value['iosEmotePaletteVersion']==2
        and value['requestId']==query['commandId']and value['runId']==query['runId']
        and integer(pid,1)and integer(value['processId'],1)and value['processId']==pid
        and integer(value['sequence'],1,1000000000)and value['clockDomain']=='native-main-emote-palette')
    identity(value['instance'])
    for clock in(value['clockBefore'],value['clockAfter']):
        exact(clock,{'epochMs','monotonicMs'});need(integer(clock['epochMs'],1)and integer(clock['monotonicMs']))
    before,after=value['clockBefore'],value['clockAfter']
    elapsed=after['epochMs']-before['epochMs'];mono=after['monotonicMs']-before['monotonicMs']
    need(0<=elapsed<1500 and 0<=mono<1500 and abs(elapsed-mono)<=250)
    if epoch is not None:fresh(after['epochMs'],epoch)
    exact(value['source'],{'complete','observation'});need(value['source']['complete']is True)
    record=value['source']['observation']
    exact(record,{'emotePaletteOriginalVersion','modelInstance','sequence','computedEpochMs','modelUrl','paletteMode','animation','postControllerPose','meshes','stage'})
    need(type(record['emotePaletteOriginalVersion'])is int and record['emotePaletteOriginalVersion']==2
        and integer(record['sequence'],1,1000000000)and integer(record['computedEpochMs'],1,before['epochMs'])
        and 0<=after['epochMs']-record['computedEpochMs']<1500
        and type(record['modelUrl'])is str and 0<len(record['modelUrl'])<=4096
        and not any(ord(n)<32 for n in record['modelUrl'])
        and record['paletteMode']in('matrix','dual-quaternion-matrix-projection')
        and record['stage']=='cpu-skinning-palette-prepared')
    identity(record['modelInstance']);animation(record['animation'],record['computedEpochMs'])
    pose=record['postControllerPose'];a=record['animation']
    exact(pose,{'emotePostControllerPoseVersion','instance','sequence','capturedEpochMs','rigId',
        'evaluationSequence','historyInstance','callSequence','stage','relativePoses','absolutePoses'})
    need(type(pose['emotePostControllerPoseVersion'])is int and pose['emotePostControllerPoseVersion']==1
        and integer(pose['sequence'],1,1000000000)and integer(pose['rigId'],1)and pose['rigId']==a['rigId']
        and integer(pose['evaluationSequence'],1)and pose['evaluationSequence']==a['evaluationSequence']
        and integer(pose['callSequence'])and pose['callSequence']==a['history']['callSequence']
        and pose['historyInstance']==a['history']['instance']
        and integer(pose['capturedEpochMs'],a['capturedEpochMs'],record['computedEpochMs'])
        and pose['stage']=='local-my-skeleton-post-eye-fingers')
    identity(pose['instance']);identity(pose['historyInstance'])
    for field in('relativePoses','absolutePoses'):
        poses=pose[field];need(type(poses)is list and len(poses)==len(a['joints']))
        for row in poses:
            need(type(row)is list and len(row)==10 and all(number(n)for n in row)
                and .9<=sum(n*n for n in row[3:7])<=1.1)
    # A final post-eye pose is a NEW original, not a rewritten pre-eye joint.
    # No equality against old animation.joints or exclusion of eye indices.

    meshes=record['meshes'];need(type(meshes)is list and 1<=len(meshes)<=16);total=0
    for index,mesh in enumerate(meshes):
        exact(mesh,{'meshIndex','clusters'});need(type(mesh['meshIndex'])is int and mesh['meshIndex']==index
            and type(mesh['clusters'])is list)
        for cluster_index,row in enumerate(mesh['clusters']):
            exact(row,{'clusterIndex','jointIndex','matrix'})
            need(type(row['clusterIndex'])is int and row['clusterIndex']==cluster_index
                and integer(row['jointIndex'],0,len(record['animation']['joints'])-1))
            matrix=row['matrix'];need(type(matrix)is list and len(matrix)==16
                and all(number(n,-1e12,1e12)for n in matrix)
                and all(abs(matrix[n]-wanted)<1e-5 for n,wanted in((3,0),(7,0),(11,0),(15,1))))
            total+=1
    need(1<=total<=128 and len(json.dumps(value,allow_nan=False).encode())<=LIMIT)
    if previous is not None:
        validate(previous,dict(query,commandId=previous['requestId']),pid)
        prior=previous['source']['observation']
        need(value['instance']==previous['instance']and value['sequence']>previous['sequence']
            and value['requestId']!=previous['requestId']and value['runId']==previous['runId']
            and all(before[key]>=previous['clockAfter'][key]for key in before)
            and record['modelInstance']==prior['modelInstance']and record['modelUrl']==prior['modelUrl']
            and record['sequence']>prior['sequence']and record['computedEpochMs']>=prior['computedEpochMs']
            and record['paletteMode']==prior['paletteMode'])
        prior_pose=prior['postControllerPose']
        need(pose['instance']==prior_pose['instance']and pose['sequence']>prior_pose['sequence']
            and pose['capturedEpochMs']>=prior_pose['capturedEpochMs'])
        accept(accept(None,prior['animation']['rigId'],prior['animation']['history']),
            record['animation']['rigId'],record['animation']['history'])
    return value


def original(value):
    return validate(value,dict(schemaVersion=1,action=ACTION,commandId=value.get('requestId'),runId=value.get('runId')),value.get('processId'))


def measured_playback(before,after,group,barrier,*,pid,epoch):
    """Coincident loaded motion and changed CPU palette, never causality."""
    original(before);original(after)
    query=dict(schemaVersion=1,action=ACTION,commandId=after['requestId'],runId=after['runId'])
    validate(after,query,pid,epoch,before);need(before['processId']==pid)
    played=playback(group,barrier,pid=pid,epoch=group['rootsAfter']['capturedEpochMs'])
    left,right=before['source']['observation'],after['source']['observation']
    old,current=left['animation'],right['animation'];native=group['native']['animation']
    need(old['overrideActive']is False and current['overrideActive']is True
        and left['computedEpochMs']<=barrier['capturedEpochMs']<=group['native']['capturedEpochMs']<=right['computedEpochMs']
        and old['history']['callSequence']==barrier['animation']['history']['callSequence']
        and old['capturedEpochMs']<=barrier['animation']['capturedEpochMs']
        and current['evaluationSequence']>=native['evaluationSequence'])
    state=accept(None,old['rigId'],old['history'])
    for item in(barrier['animation'],native,current):state=accept(state,item['rigId'],item['history'])
    # Exact saved fields projected into an existing pure codec. No native
    # query/clock envelope, expected pose, callback, frame or live owner exists.
    event,frames=clip_run(dict(animation=current,capturedEpochMs=right['computedEpochMs']),
        played['event']['request']['url'],after_event=barrier['animation']['history']['callSequence'],after_epoch=barrier['capturedEpochMs'])
    need(typed_equal(event,played['event'])and current['clip']['url']==played['event']['request']['url']
        and current['history']['overrideSequence']==event['overrideSequence'])
    _selected,_native,urls=emote_source(group,pid,group['rootsAfter']['capturedEpochMs'])
    measured,_restore,_inactive=actual_state(dict(animation=current,capturedEpochMs=right['computedEpochMs']),event,urls,barrier)
    need(measured['override']is True and measured['animation']==played['state']['animation']
        and measured['sit']==played['state']['sit'])
    def rows(value):
        return {(mesh['meshIndex'],row['clusterIndex'],row['jointIndex']):row['matrix']for mesh in value['meshes']for row in mesh['clusters']}
    prior,latest=rows(left),rows(right);need(prior.keys()==latest.keys())
    changed=[list(key)for key in prior if any(abs(a-b)>1e-8 for a,b in zip(prior[key],latest[key]))]
    need(bool(changed))
    return dict(emoteEvaluatedPaletteVersion=2,before=deepcopy(before),after=deepcopy(after),
        playback=deepcopy(played),postControllerPoseOriginal=deepcopy(right['postControllerPose']),measuredAnimation=played['state']['animation'],measuredSitVariant=played['state']['sit'],
        changedPaletteClusters=changed,coincidentLoadedClipAndPaletteMovement=True,
        requestedNameUsedAsObservation=False,palettePreparationOnly=True,payloadAccepted=False,
        GPUFrameCompleted=False,independentActorPixelsQualified=False,causalityEstablished=False,
        allCatalogChoicesQualified=False,nativeQualified=False,wholeQualified=False)


class IOSEmotePalette(IOSPlacesModel):
    """Existing native acquisition/clock guards; public feature routes unchanged."""
    _limit=LIMIT;_action=ACTION;_command=staticmethod(command);_validate=staticmethod(validate)
    _acquisition_key='iosEmotePostControllerPaletteAcquisitionVersion'
