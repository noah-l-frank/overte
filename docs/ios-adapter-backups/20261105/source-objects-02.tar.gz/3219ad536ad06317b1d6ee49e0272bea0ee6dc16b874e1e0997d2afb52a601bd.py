"""Scoped own-Actor factory over an existing installed SDK and source lock."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from copy import deepcopy
from types import FunctionType
import time
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.lock import ScriptSourceLock
from adapters.script_feature.history import same
from feature_journeys.phase_fixture import PhaseFixtureReader
from ios.adapters.script_runtime import IOSScriptRuntime
from ios.adapters.lifecycle_independent_actor_world import LifecycleIndependentActorWorld


class IOSLifecycleIndependentActorRuntime(IOSScriptRuntime):
    @contextmanager
    def actor_world_originals(self,selector,run,indices,client,*,epoch_ms=lambda:int(time.time()*1000),monotonic=time.monotonic):
        need(type(indices)is tuple and len(indices)==2 and all(type(i)is int and 1<=i<=128 for i in indices)and indices[1]==indices[0]+1)
        path=self.state_path(selector).with_name('script-feature-sources.lock');lock=ScriptSourceLock(path)
        with lock.held():
            source=self._sources(selector);binding=source['binding']
            need(source['session']==binding['sessionId']and source['process']()['pid']==int(binding['processIdentity']))
            # Hold exact creator-scoped members. No new session, tunnel, target,
            # PID, Source, input, borrowed Primary callback or image is created.
            original_binding=deepcopy(binding)
            check=source['check'];need(type(check)is FunctionType)
            check_code,check_globals=check.__code__,check.__globals__
            check_defaults,check_closure=check.__defaults__,check.__closure__
            check_cells=tuple(cell.cell_contents for cell in check_closure or())
            held=tuple((key,source[key])for key in('client','session','binding','observer','clock_source','check','process'))
            def guard():
                lock.assert_held();need(same(binding,original_binding)and check.__code__ is check_code and check.__globals__ is check_globals
                    and check.__defaults__ is check_defaults and check.__closure__ is check_closure
                    and all(cell.cell_contents is value for cell,value in zip(check_closure or(),check_cells))
                    and all(source.get(key)is value for key,value in held)
                    and source['check']()is not False and source['process']()['pid']==int(binding['processIdentity']))
                return True
            phase=PhaseFixtureReader(client,run,'lifecycle-input',epoch_ms=epoch_ms,monotonic=monotonic)
            owners=tuple(LifecycleIndependentActorWorld(PrivateFeatureState(path.with_name('ios-lifecycle-independent-actor-world-'+format(index,'04d')+'.json')),
                lock,binding,run,index,phase.fixture_url,phase=phase,feature=source['observer'],native=source['clock_source'],guard=guard,
                epoch_ms=epoch_ms,monotonic=monotonic)for index in indices)
            try:yield owners
            except BaseException as error:
                try:guard()
                except BaseException as secondary:error.add_note('Independent Actor source exit guard: '+type(secondary).__name__+': '+str(secondary))
                raise
            else:guard()
