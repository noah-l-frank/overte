"""Independent peer-world/Node permission producer; native APIs remain models.

No primary UI packet, owner journal, expected rights result or receipt is copied.
The peer's distinct local Node/API identity and native clock supply its source.
Shared persisted HTTP settings drive a declared permission-delivery model.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import json,secrets
from types import SimpleNamespace
from adapters.native_feature_observation import NativeFeatureObservation,need
from ios.adapters.normal_input import NativeInput,observation
from ios.self_tests.assets_picker_fixture import uid
from ios.self_tests.assets_scene_facts_fixture import instantiate_native


class PeerPermissionBoundary:
    def __init__(self,world,primary,binding,settings):
        self.world,self.primary,self.binding,self.settings=world,primary,deepcopy(binding),settings
        self.pid=int(binding['processIdentity']);self.instance,self.permission_instance,self.api_id=uid(),uid(),uid()
        self.ui_instance,self.bundle_instance,self.clock_instance=uid(),uid(),secrets.token_hex(16)
        self.sequence=self.clock_sequence=0;self.raw='';self.propagate=True;self.can_write=True
    def clock(self):return self.world.clock()
    def packet(self):
        self.sequence+=1
        if self.propagate:self.can_write=next(row['id_can_write_to_asset_server'] for row in self.settings.security['standard_permissions'] if row['permissions_id']=='anonymous')
        epoch=self.clock()
        return dict(schemaVersion=1,instance=self.instance,frameSpace='qt-window-logical',processId=self.pid,sampleEpochMs=epoch,
            elapsedMs=self.primary.elapsed,lastSequence=0,tabletShown=False,ready=True,controls=[],
            assetControlsVersion=1,assetInventory=dict(iosAssetUiInventoryVersion=1,available=True,complete=True,
                instance=self.ui_instance,sequence=self.sequence,capturedEpochMs=epoch,processId=self.pid,roots=[]),
            assetBundleControlsVersion=1,assetBundleInventory=dict(iosAssetsBundleUiVersion=1,available=True,complete=True,
                instance=self.bundle_instance,sequence=self.sequence,capturedEpochMs=epoch,processId=self.pid,rows=[]),
            assetPermissionsVersion=1,assetPermissions=dict(iosAssetsPermissionSourceVersion=1,instance=self.permission_instance,
                sequence=self.sequence,processId=self.pid,capturedEpochMs=epoch,available=True,complete=True,
                binding=dict(apiId=self.api_id,clientNodeId=self.world.usage_ids['clientNodeId'],domainId=self.world.reads.binding['domainId']),
                permissions=dict(canWriteAssets=self.can_write,canRez=True,canRezTmp=False)))
    def ports(self,scope):
        boundary=self
        def checked():scope.guard();return True
        def send(query):
            checked();self.clock_sequence+=1;self.primary.tick()
            packet=instantiate_native(self.clock(),self.pid,self.clock_instance,self.clock_sequence)
            packet['requestId']=query['commandId'];self.raw=json.dumps(packet)
        clock=NativeFeatureObservation(send,lambda:self.raw,self.clock,checked,self.pid,ios=True,
            monotonic=self.primary.monotonic,sleep=self.primary.sleep)
        class Input(NativeInput):
            def __init__(self):
                self.monotonic,self.sleep,self.native_epoch_ms=boundary.primary.monotonic,boundary.primary.sleep,boundary.clock
                self.last_receipt=None
            def capture(self):
                checked();query=dict(schemaVersion=1,commandId='ios-'+secrets.token_hex(16),action='normal-ui-input',operation='observe')
                intent=getattr(self,'observe_intent',None)
                if intent is not None:intent(query)
                packet=boundary.packet();observation(packet,boundary.pid,boundary.clock())
                self.last_receipt=dict(schemaVersion=1,commandId=query['commandId'],observation=deepcopy(packet));return packet
            def deliver(self,*args,**kwargs):raise AssertionError('Peer permission observation has no input authority')
        return dict(binding=deepcopy(self.binding),native=Input(),clock_source=clock,observer=SimpleNamespace(sleep=self.primary.sleep),check=checked)
