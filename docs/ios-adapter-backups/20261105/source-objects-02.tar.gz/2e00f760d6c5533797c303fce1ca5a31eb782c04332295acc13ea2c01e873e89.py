"""Read-only plan integrity preflight; never imports targets or starts a test."""
from pathlib import Path
import hashlib,json,stat
HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def load(name):return json.loads((HERE/name).read_text())
freeze=load('freeze.json')
for row in freeze['files']:
    path=HERE/row['path']
    assert path.is_file() and not path.is_symlink() and sha(path)==row['sha256'],row['path']
plan=load('execution-plan.json')
packet=REPO/plan['packetPath']
assert sha(packet/'freeze.json')==plan['packetRawFreezeSha256']
for row in json.loads((packet/'freeze.json').read_text())['files']:
    assert sha(packet/row['path'])==row['sha256'],row['path']
for row in load('exact-overlay-and-basematches.json'):
    assert sha(REPO/row['candidatePath'])==row['candidate']['sha256'],row['path']
assert len(plan['selection'])==5
assert all(x['initialTimeoutSeconds']==300 and x['killAfterSeconds']==5 for x in plan['selection'].values())
assert plan['modelsExecuted']==0 and plan['status']=='PROPOSED_UNRUN_ROOT_EXECUTION_ONLY'
print(json.dumps(dict(status='READONLY_PRIVATE_PLAN_BYTES_VALID',targetImports=0,testsExecuted=0,selectedModels=5),sort_keys=True))
