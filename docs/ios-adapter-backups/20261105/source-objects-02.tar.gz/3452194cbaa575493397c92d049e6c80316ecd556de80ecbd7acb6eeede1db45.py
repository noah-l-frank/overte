"""Historical scoped19 +actual smoke helper proof; no old test replay."""
import ast,hashlib,json,stat
from pathlib import Path
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def allpins(master):
 pins=json.loads((master/'actual-history-current-pins.json').read_text())
 for name,expected in pins.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();v=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
  assert v==expected and v['stat']==[getattr(p.lstat(),k) for k in F]
 return [Path(name) for name in pins]
def delta(plan,repo):
 old=Path(plan['oldTestFile']);new=Path(plan['newTestFile']);assert sha(old)==plan['oldTestSha256'] and sha(new)==plan['newTestSha256']
 a,b=[ast.parse(p.read_text()) for p in (old,new)];changed=[]
 for ca,cb in zip(a.body,b.body,strict=True):
  if isinstance(ca,ast.ClassDef):
   assert ast.dump(type(ca)(**{k:[] if k=='body' else getattr(ca,k) for k in ca._fields}))==ast.dump(type(cb)(**{k:[] if k=='body' else getattr(cb,k) for k in cb._fields}))
   for na,nb in zip(ca.body,cb.body,strict=True):
    if ast.dump(na,include_attributes=False)!=ast.dump(nb,include_attributes=False):assert isinstance(na,ast.FunctionDef);changed.append(ca.name+'.'+na.name)
  else:assert ast.dump(ca,include_attributes=False)==ast.dump(cb,include_attributes=False)
 assert changed==plan['changedMethods']
 assert sha(repo/plan['helperPath'])==plan['helperSha256']
 return [old,new]
def exited(out):
 p=json.loads((out/'process-binding.json').read_text())['task']
 try:row=Path('/proc',str(p['pid']),'stat').read_text().rsplit(') ',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):row=None
 assert row is None or int(row[19])!=p['startTicks']
def cleanup(stage,index,case):
 c=stage/('case-cleanup-'+str(index));r=json.loads((c/'receipt.json').read_text());assert r['case']==case and r['actualStandardCaseRunReturned'] and r['twoCensusesPassed']
 a=json.loads((c/'terminal-census-1.json').read_text());b=json.loads((c/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
def historical(master,repo):
 plan=json.loads((master/'scope-plan.json').read_text());paths=allpins(master);paths+=delta(plan,repo);stage=Path(plan['oldStage']);out=stage/'root-run-first'
 report=json.loads((out/'report.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==41 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=1,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 assert not list(stage.glob('terminal-census*'))
 r=json.loads((stage/'selected-result.json').read_text());assert r['selectedIds']==plan['unchangedPrefix']+plan['tail'] and r['testsRun']==20 and not r['successful'] and r['failureCount']==1 and r['errorCount']==r['skippedCount']==0
 lines=(out/'first.log').read_text().splitlines();parsed=[]
 for case in plan['unchangedPrefix']+[plan['failedCase']]:
  method=case.rsplit('.',1)[1];classname=case.rsplit('.',1)[0];expected=method+' ('+classname+'.'+method+') ... '+('FAIL' if case==plan['failedCase'] else 'ok')
  assert lines.count(expected)==1;parsed.append(expected)
 for index,case in enumerate(plan['unchangedPrefix']+[plan['failedCase']],1):cleanup(stage,index,case)
 allpins(master)
 return dict(status='ACTUAL_HISTORICAL_SCOPED19_PASS',scopedCases=plan['unchangedPrefix'],failedCasePreserved=plan['failedCase'],oldAggregatePassed=False,aggregateTerminalCensusesPresent=False,actualPerCaseCensuses=20,originalFiles=41,oldSourceBeforeAfterEqual=True,oldCurrentRawPinsExact=True,originalProcessAbsent=True,helperSha256=plan['helperSha256'],unchangedPrefixTestAST=True,actualOutcomeLines=parsed),paths

def require(here,repo,current=None):
 master=here.parent;plan=json.loads((master/'scope-plan.json').read_text());expected,paths=historical(master,repo)
 actual=json.loads((master/'root-scoped19-report.json').read_text());assert actual==expected;paths.append(master/'root-scoped19-report.json')
 assert sha(repo/plan['testPath'])==plan['newTestSha256']
 smoke=Path(plan['smokeStage']);out=smoke/'root-run-first';r=json.loads((out/'report.json').read_text());assert r['exitCode']==0 and r['retainedFiles']==0 and all(r[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not r['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 ids=json.loads((smoke/'run-plan.json').read_text())['cases'];a=json.loads((smoke/'selected-result.json').read_text());assert len(ids)==1 and a['selectedIds']==ids and a['successful'] and a['testsRun']==1 and not any(a[k] for k in ('failureCount','errorCount','skippedCount'));cleanup(smoke,1,ids[0])
 old=json.loads((out/'root-source-map.json').read_text());assert old['repositoryRoot']==str(repo) and old['currentSourcePins'][plan['testPath']]==plan['oldTestSha256']
 adjusted=dict(old['currentSourcePins']);adjusted[plan['testPath']]=plan['newTestSha256']
 if current is not None:assert current['currentSourcePins']==adjusted
 for name,digest in adjusted.items():
  p=repo/name;assert p.is_relative_to(repo) and p.resolve(strict=True)==p and sha(p)==digest
 allpins(master);return paths+[master/'scope-plan.json',master/'actual-history-current-pins.json']
