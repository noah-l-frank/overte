"""Pure saved actual Root8d upstream proof, never MP variant qualification."""
from pathlib import Path
import json
UPSTREAM_FREEZE='8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a'
UPSTREAM_HELPER='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
RESULT_SHA='46eb559da5cb54307af31584341002ba97453c5dc2536094cac2ca65a5360f7f'
REFERENCES_SHA='dc021f854cc40451570b213f72888b4a0e4d5fe45677434c696b829563685109'

def require_upstream(path,digest,pin):
    path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path and path.name=='freeze.json'
    assert digest==UPSTREAM_FREEZE
    physical={}
    def checked(p,sha):
        p=Path(p);assert p.is_absolute()and p.resolve(strict=True)==p
        row=pin(p);assert row['sha256']==sha;physical[str(p)]=row;return p
    checked(path,UPSTREAM_FREEZE);root=path.parent;frozen=json.loads(path.read_text())
    assert frozen['files']['results.json']['sha256']==RESULT_SHA and frozen['files']['actual-receipt-references.json']['sha256']==REFERENCES_SHA
    result=checked(root/'results.json',RESULT_SHA);actual=json.loads(result.read_text())
    refs=json.loads(checked(root/'actual-receipt-references.json',REFERENCES_SHA).read_text());assert len(refs)==48
    for row in refs.values():checked(row['path'],row['sha256'])
    assert actual['status']=='ACTUAL_C10C_FRESH_SOURCE_CACHE_MUTATION_COMPILER_STDLIB_ALIAS_COUNTER6_AND_ALL_UTILITY_GATES_PASS'
    assert actual['subjectSourceFreeze']=='63f5ffc563996ad7793a600cb6a16c53d8df05a54d65db24321a1a2b5c020fc4'and actual['subjectHelperSha256']==UPSTREAM_HELPER
    assert actual['actualPassedCases']==actual['actualStartedCases']==6 and len(actual['actualIds'])==len(set(actual['actualIds']))==6
    for key in('sourceExecutionCounterQualified','cachePoisonTimestampAndUncheckedRefusalQualified','actualSourceMutationRefusalQualified','actualCompileExecRebindRefusalQualified','actualGenericStdlibExecutionRowEqualityQualified','actualGenuineFourExpatNamesAndForeignReceiverRefusalQualified','all27OsCioDupToolsRestored','all725FrozenSourceBinaryPinsUnchanged','actualInputAndCliShaUnchanged','parentFDThreadAndKernelDrain','twoWholeOwnCensusesEqual'):assert actual[key]is True
    assert actual['actualOriginalStandardCleanupCalls']==actual['actualGenuineTemporaryDirectories']==6
    assert actual['actualCallbackErrors']==actual['NodeExecutions']==actual['SDKExecutions']==actual['overteNativeQueries']==0
    assert actual['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
    assert actual['realNetwork']is actual['nativeQualified']is actual['deviceQualified']is actual['wholeQualified']is False
    return dict(physicalPins=physical,upstreamHelperSha256=UPSTREAM_HELPER,actualUpstreamSixCases=actual['actualIds'],
        adaptedMPHelperQualified=False,scope=actual['qualificationScope'])
