"""Exact declared module origins; genuine interpreter fallback only.

This module imports no project/Pillow/SDK source. All origin pins must already
be in Root's approved input before a project or external module executes.
"""
from pathlib import Path
from types import ModuleType, BuiltinFunctionType
import builtins
import hashlib
import stat
import importlib.machinery as machinery
import importlib.util as util
import os
import sys

# Interpreter entry points are retained at controller-module birth, before
# any project admission. No replacement compile/exec hook is installed.
_ORIGINAL_COMPILE = builtins.compile
_ORIGINAL_EXEC = builtins.exec


class ClosedOrigins:
    def __init__(self, plan, source, repo, pin):
        self.plan, self.source, self.repo, self.pin = plan, source, repo, pin
        self.projects = plan['modules']
        self.third = plan['thirdPartyModules']
        self.project_namespaces = plan['namespacePackages']
        self.third_namespaces = plan['thirdPartyNamespacePackages']
        self.std_namespaces = plan['stdlibNamespacePackages']
        self.std = tuple(Path(value) for value in plan['stdlibRoots'])
        # os is a genuine already bootstrapped interpreter module. Its actual
        # source location is used, not sysconfig's unrelated /usr/local prefix.
        actual_std = Path(vars(os)['__file__']).resolve(strict=True).parent
        assert self.std == (actual_std,)
        assert actual_std.is_dir() and not self.excluded(actual_std)
        self.python = Path(sys.executable).resolve(strict=True)
        assert str(self.python) == plan['pythonExecutable']['path']
        assert self.pin(self.python) == plan['pythonExecutable']['pin'] == plan['physicalPins'][str(self.python)]
        assert not set(self.projects).intersection(self.third)
        assert not set(self.project_namespaces).intersection(self.third_namespaces)
        self.admissions = {}
        self.observed_files = {}
        self.observed_namespaces = {}
        self.snapshot_count = 0
        self.python_executions = {}
        self.extension_executions = {}
        self.compiler, self.executor = _ORIGINAL_COMPILE, _ORIGINAL_EXEC
        self.source_read_ports = (os.open, os.read, os.fstat, os.close)
        self.compilation_ports_bound()
        self.extension_child_receivers = {}
        self.extension_alias_receivers = {}
        self.source_class = machinery.SourceFileLoader
        self.extension_class = machinery.ExtensionFileLoader
        self.path_finder = machinery.PathFinder
        self.builtin = machinery.BuiltinImporter
        self.frozen = machinery.FrozenImporter
        self.initial_modules = dict(sys.modules)
        self.snapshot('before-project-imports')

    @staticmethod
    def excluded(path):
        return any(part in ('site-packages', 'dist-packages') for part in path.parts)

    def physical(self, raw):
        path = Path(raw)
        assert path.is_absolute() and path.resolve(strict=True) == path
        expected = self.plan['physicalPins'].get(str(path))
        assert expected is not None, 'Module origin not independently pinned before import: ' + str(path)
        actual = self.pin(path)
        assert actual == expected
        if str(path) in self.observed_files:
            assert self.observed_files[str(path)] == actual
        else:
            self.observed_files[str(path)] = actual
        return path

    def namespaces(self, name, raw_roots, expected, kind):
        assert type(raw_roots) in (list, tuple) and raw_roots
        # Resolve each actual and each separately declared root exactly once.
        actual = tuple(Path(raw).resolve(strict=True) for raw in raw_roots)
        declared = tuple(Path(raw).resolve(strict=True) for raw in expected)
        assert actual == declared and len(set(actual)) == len(actual)
        if kind == 'stdlib':
            assert all(any(real.is_relative_to(root) for root in self.std)
                and not self.excluded(real) for real in actual)
        else:
            assert all(real.is_dir() for real in actual)
        value = dict(kind=kind, roots=[str(real) for real in actual])
        if name in self.observed_namespaces:
            assert self.observed_namespaces[name] == value
        else:
            self.observed_namespaces[name] = value
        return value

    def genuine_special(self, spec):
        assert spec is not None
        if spec.origin == 'built-in':
            actual = self.builtin.find_spec(spec.name)
            assert spec.loader is self.builtin and actual is not None and actual.origin == 'built-in'
            return 'builtin'
        if spec.origin == 'frozen':
            actual = self.frozen.find_spec(spec.name)
            assert spec.loader is self.frozen and actual is not None and actual.origin == 'frozen'
            return 'frozen'
        raise AssertionError('Not a genuine interpreter module')

    def source_row(self, name, module, row, kind):
        namespace = vars(module)
        assert namespace.get('__file__') is not None
        actual = self.physical(namespace['__file__'])
        assert actual == Path(row['path'])
        assert self.plan['physicalPins'][str(actual)]['sha256'] == row['sha256']
        value = dict(kind=kind, origin=str(actual), pin=self.plan['physicalPins'][str(actual)])
        execution = self.execution_row(name, module, actual)
        if execution is not None:
            value['actualExecution'] = execution
        return value

    def execution_row(self, name, module, actual):
        execution = self.python_executions.get(name)
        if execution is not None:
            original_module, path, digest, size = execution
            assert module is original_module and actual == path
            assert digest == self.plan['physicalPins'][str(actual)]['sha256']
            return dict(kind='fresh-pinned-python-source-bytes',
                sourceSha256=digest, sourceBytes=size, cachedBytecodeConsulted=False)
        if name in self.extension_executions:
            original_module, path = self.extension_executions[name]
            assert module is original_module and actual == path
            return dict(kind='genuine-pinned-extension-loader',
                compiledThroughPythonSourceBranch=False)
        return None

    def project_loaded(self, name, module, row):
        assert self.projects.get(name) == row
        self.admissions[name] = self.source_row(name, module, row, 'project')

    def file_spec(self, name, row, kind):
        path = self.physical(row['path'])
        assert self.plan['physicalPins'][str(path)]['sha256'] == row['sha256']
        if row['loader'] == 'extension':
            original = self.extension_class(name, str(path))
        else:
            assert row['loader'] == 'source' and path.suffix == '.py'
            original = self.source_class(name, str(path))
        loader = PinnedDelegate(self, name, original, row, kind)
        locations = [str(path.parent)] if row['package'] else None
        return util.spec_from_file_location(name, str(path), loader=loader,
            submodule_search_locations=locations)

    def remaining_spec(self, name, search):
        if name in self.third:
            return self.file_spec(name, self.third[name], 'third-party')
        if name in self.third_namespaces:
            roots = self.third_namespaces[name]
            self.namespaces(name, roots, roots, 'third-party')
            spec = machinery.ModuleSpec(name, None, is_package=True)
            spec.submodule_search_locations = roots
            return spec
        spec = self.builtin.find_spec(name)
        if spec is None:
            spec = self.frozen.find_spec(name)
        if spec is not None:
            self.genuine_special(spec)
            assert self.pin(self.python) == self.plan['pythonExecutable']['pin']
            return spec
        spec = self.path_finder.find_spec(name, search)
        if spec is None:
            raise ModuleNotFoundError('No genuine declared/interpreter module named '+repr(name), name=name)
        if spec.origin is None:
            expected = self.std_namespaces.get(name)
            assert expected is not None, 'Undeclared namespace import: ' + name
            roots = tuple(spec.submodule_search_locations or ())
            self.namespaces(name, roots, expected, 'stdlib')
            return spec
        real = Path(spec.origin).resolve(strict=True)
        assert any(real.is_relative_to(root) for root in self.std) and not self.excluded(real), 'Undeclared non-stdlib import: ' + name
        self.physical(real)
        assert type(spec.loader) in (self.source_class, self.extension_class)
        row = dict(path=str(real), sha256=self.plan['physicalPins'][str(real)]['sha256'],
            package=spec.submodule_search_locations is not None,
            loader='extension' if type(spec.loader) is self.extension_class else 'source')
        return self.file_spec(name, row, 'stdlib')

    def compilation_ports_bound(self):
        assert self.compiler is _ORIGINAL_COMPILE and self.executor is _ORIGINAL_EXEC
        assert builtins.compile is self.compiler and builtins.exec is self.executor
        for function, name in ((self.compiler, 'compile'), (self.executor, 'exec')):
            assert type(function) is BuiltinFunctionType
            assert function.__self__ is builtins and function.__module__ == 'builtins'
            assert function.__name__ == function.__qualname__ == name

    @staticmethod
    def source_stat(info):
        return tuple(getattr(info, name) for name in ('st_dev', 'st_ino', 'st_mode',
            'st_uid', 'st_gid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))

    def execute_python_source(self, delegate, module):
        # Keep the actual SourceFileLoader as original creator/metadata owner,
        # but do not call its get_code/exec_module bytecode-cache branch.
        assert type(delegate) is PinnedDelegate and delegate.guard is self
        assert delegate.row['loader'] == 'source'
        assert type(delegate.original) is self.source_class
        assert delegate.original.name == delegate.name
        path = self.physical(delegate.row['path'])
        assert Path(delegate.original.path) == path and path.suffix == '.py'
        assert type(module) is ModuleType and sys.modules.get(delegate.name) is module
        namespace = vars(module)
        assert namespace.get('__name__') == delegate.name
        spec = namespace['__spec__']
        assert type(spec) is machinery.ModuleSpec and spec.name == delegate.name
        assert spec.origin == str(path) and Path(namespace['__file__']) == path
        # A genuine outer project-observation loader may wrap this delegate;
        # it preserves the real module spec and invokes this actual port.
        before = path.lstat()
        assert stat.S_ISREG(before.st_mode) and path.resolve(strict=True) == path
        original_open, original_read, original_fstat, original_close = self.source_read_ports
        descriptor = original_open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
        try:
            signature = self.source_stat(before)
            assert self.source_stat(original_fstat(descriptor)) == signature
            pieces = []
            while True:
                piece = original_read(descriptor, 65536)
                if not piece:
                    break
                pieces.append(piece)
            raw = b''.join(pieces)
            assert len(raw) == before.st_size
            assert self.source_stat(original_fstat(descriptor)) == signature
            assert self.source_stat(path.lstat()) == signature
        finally:
            original_close(descriptor)
        digest = hashlib.sha256(raw).hexdigest()
        assert digest == delegate.row['sha256'] == self.plan['physicalPins'][str(path)]['sha256']
        self.physical(path)
        self.compilation_ports_bound()
        code = self.compiler(raw, str(path), 'exec', dont_inherit=True, optimize=-1)
        self.compilation_ports_bound()
        # Actual interpreter compile+exec, actual normal import namespace. A
        # .pyc is neither opened, removed, rewritten nor reported missing.
        self.executor(code, namespace)
        self.compilation_ports_bound()
        self.physical(path)
        self.python_executions[delegate.name] = (module, path, digest, len(raw))

    def hold_extension_children(self, name, module, delegate):
        # These are the two actual modules born by the real pinned Expat C
        # extension before its original import returns to project code. This
        # is not authority for arbitrary spec-less or invented modules.
        if name != 'pyexpat':
            return
        assert delegate.guard is self and delegate.name == name
        assert delegate.kind == 'stdlib' and delegate.row['loader'] == 'extension'
        assert type(delegate.original) is self.extension_class
        assert delegate.original.name == name
        path = self.physical(delegate.row['path'])
        assert Path(delegate.original.path) == path
        assert any(path.is_relative_to(root) for root in self.std) and not self.excluded(path)
        assert type(module) is ModuleType and sys.modules.get(name) is module
        assert vars(module)['__spec__'].loader is delegate
        assert Path(vars(module)['__file__']) == path
        for leaf in ('errors', 'model'):
            child_name = name + '.' + leaf
            child = vars(module).get(leaf)
            assert type(child) is ModuleType and sys.modules.get(child_name) is child
            assert vars(child).get('__name__') == child_name
            assert vars(child).get('__file__') is None and vars(child).get('__spec__') is None
            assert vars(child).get('__package__') is None and vars(child).get('__loader__') is None
            held = (module, child, leaf, delegate, path)
            if child_name in self.extension_child_receivers:
                previous = self.extension_child_receivers[child_name]
                assert all(actual is original for actual, original in zip(held[:4], previous[:4]))
                assert path == previous[4]
            else:
                self.extension_child_receivers[child_name] = held

    def extension_child_row(self, name, module):
        parent, child, leaf, delegate, path = self.extension_child_receivers[name]
        assert module is child and sys.modules.get('pyexpat') is parent
        assert vars(parent).get(leaf) is child
        assert vars(parent)['__spec__'].loader is delegate
        assert delegate.guard is self and delegate.name == 'pyexpat' and delegate.kind == 'stdlib'
        assert type(delegate.original) is self.extension_class
        assert delegate.original.name == 'pyexpat' and Path(delegate.original.path) == path
        assert vars(child).get('__name__') == name
        assert vars(child).get('__file__') is None and vars(child).get('__spec__') is None
        assert vars(child).get('__package__') is None and vars(child).get('__loader__') is None
        assert self.physical(vars(parent)['__file__']) == path
        return dict(kind='stdlib-extension-created-module', parent='pyexpat',
            originalAttribute=leaf, origin=str(path), pin=self.plan['physicalPins'][str(path)])

    def hold_extension_aliases(self, name, module, delegate):
        # The actual pinned Python wrapper reexports the two already held C
        # children. Its sys.modules aliases do not create new module origins.
        if name != 'xml.parsers.expat':
            return
        assert type(delegate) is PinnedDelegate and delegate.guard is self and delegate.name == name
        assert delegate.kind == 'stdlib' and delegate.row['loader'] == 'source'
        assert type(delegate.original) is self.source_class and delegate.original.name == name
        path = self.physical(delegate.row['path'])
        assert path == self.std[0] / 'xml' / 'parsers' / 'expat.py'
        assert Path(delegate.original.path) == path and not self.excluded(path)
        assert type(module) is ModuleType and sys.modules.get(name) is module
        assert vars(module).get('__name__') == name and vars(module).get('__loader__') is delegate
        spec = vars(module)['__spec__']
        assert type(spec) is machinery.ModuleSpec and spec.name == name and spec.loader is delegate
        assert spec.origin == str(path) and Path(vars(module)['__file__']) == path
        assert vars(module).get('__package__') == 'xml.parsers'
        for leaf in ('errors', 'model'):
            original_name = 'pyexpat.' + leaf
            original = self.extension_child_receivers.get(original_name)
            assert original is not None
            child = vars(module).get(leaf)
            alias_name = name + '.' + leaf
            assert child is original[1] and sys.modules.get(alias_name) is child
            self.extension_child_row(original_name, child)
            held = (module, child, leaf, delegate, path, original)
            if alias_name in self.extension_alias_receivers:
                previous = self.extension_alias_receivers[alias_name]
                assert all(actual is expected for actual, expected in zip(held[:4], previous[:4]))
                assert path == previous[4] and original is previous[5]
            else:
                self.extension_alias_receivers[alias_name] = held

    def extension_alias_row(self, name, module):
        wrapper, child, leaf, delegate, path, original = self.extension_alias_receivers[name]
        assert leaf in ('errors', 'model') and name == 'xml.parsers.expat.' + leaf
        assert module is child and sys.modules.get(name) is child and sys.modules.get('xml.parsers.expat') is wrapper
        assert type(wrapper) is ModuleType and vars(wrapper).get(leaf) is child
        assert vars(wrapper).get('__name__') == 'xml.parsers.expat' and vars(wrapper).get('__loader__') is delegate
        assert type(delegate) is PinnedDelegate and delegate.guard is self and delegate.name == 'xml.parsers.expat'
        assert delegate.kind == 'stdlib' and delegate.row['loader'] == 'source'
        assert type(delegate.original) is self.source_class and delegate.original.name == 'xml.parsers.expat'
        assert path == self.std[0] / 'xml' / 'parsers' / 'expat.py'
        assert Path(delegate.original.path) == path and Path(delegate.row['path']) == path
        spec = vars(wrapper)['__spec__']
        assert type(spec) is machinery.ModuleSpec and spec.name == 'xml.parsers.expat' and spec.loader is delegate
        assert spec.origin == str(path) and vars(wrapper).get('__package__') == 'xml.parsers'
        assert self.physical(vars(wrapper)['__file__']) == self.physical(delegate.row['path']) == path
        original_name = 'pyexpat.' + leaf
        assert self.extension_child_receivers.get(original_name) is original and original[1] is child
        actual = self.extension_child_row(original_name, child)
        return dict(kind='stdlib-source-reexported-extension-module', parent='pyexpat',
            wrapper='xml.parsers.expat', originalAttribute=leaf, origin=actual['origin'], pin=actual['pin'],
            wrapperOrigin=str(path), wrapperPin=self.plan['physicalPins'][str(path)])

    def snapshot(self, phase):
        # The genuinely bootstrapped module receivers are independently held.
        # An authentic importer spec does not authorize a replacement module.
        for name, original in self.initial_modules.items():
            if original is not None:
                assert sys.modules.get(name) is original, 'Initial module receiver changed: ' + name
        rows = {}
        for name, module in tuple(sys.modules.items()):
            if module is None:
                continue
            assert type(module) is ModuleType, 'Non-module sys.modules entry: ' + name
            namespace = vars(module)
            file = namespace.get('__file__')
            spec = namespace.get('__spec__')
            if name in self.projects:
                row = self.source_row(name, module, self.projects[name], 'project')
            elif name in self.third:
                row = self.source_row(name, module, self.third[name], 'third-party')
            elif name in self.extension_child_receivers:
                row = self.extension_child_row(name, module)
            elif name in self.extension_alias_receivers:
                row = self.extension_alias_row(name, module)
            elif spec is not None and spec.origin in ('built-in', 'frozen'):
                kind = self.genuine_special(spec)
                assert sys.modules.get(spec.name) is module
                row = dict(kind=kind, interpreter=str(self.python))
                if file is not None:
                    row['sourceRepresentation'] = str(self.physical(file))
            elif file is not None:
                actual = self.physical(file)
                if actual.parent == self.source:
                    # Only the exact already independently pinned controller
                    # modules may predate target admission.
                    assert name in self.initial_modules and self.initial_modules[name] is module
                    kind = 'controller'
                else:
                    assert any(actual.is_relative_to(root) for root in self.std) and not self.excluded(actual), 'Unaccounted loaded external origin: ' + name
                    kind = 'stdlib'
                row = dict(kind=kind, origin=str(actual), pin=self.plan['physicalPins'][str(actual)])
            else:
                assert spec is not None and spec.origin is None, 'Unaccounted fileless module: ' + name
                roots = tuple(spec.submodule_search_locations or ())
                if name in self.project_namespaces:
                    row = self.namespaces(name, roots, self.project_namespaces[name], 'project')
                elif name in self.third_namespaces:
                    row = self.namespaces(name, roots, self.third_namespaces[name], 'third-party')
                else:
                    assert name in self.std_namespaces, 'Unaccounted loaded namespace: ' + name
                    row = self.namespaces(name, roots, self.std_namespaces[name], 'stdlib')
            if name in self.python_executions or name in self.extension_executions:
                assert file is not None
                # The same actual receipt grammar is used for project,
                # external and generic stdlib rows. Never drop a real fresh
                # execution record before the admission equality check.
                row['actualExecution'] = self.execution_row(name, module, self.physical(file))
            if name in self.admissions:
                assert self.admissions[name] == row
            if name in self.initial_modules:
                row = dict(row)
                row['hostBootstrap'] = dict(kind='held-original-host-bootstrap',
                    compiledThroughC10=False)
            rows[name] = row
        assert self.pin(self.python) == self.plan['pythonExecutable']['pin']
        self.snapshot_count += 1
        return dict(phase=phase, modules=rows, observedFiles=dict(self.observed_files),
            namespaces=dict(self.observed_namespaces), snapshots=self.snapshot_count,
            executionScope=dict(pythonDelegates='fresh-pinned-python-source-bytes',
                preloaded='held-host-bootstrap-only', extensions='genuine-pinned-extension-loader',
                entryScriptAndPrivateBootstrap='outside-this-loader-scope',
                cacheFilesReadByThisSourceBranch=False, cacheFilesChanged=False))


class PinnedDelegate:
    """Delegate actual source/extension creation+execution, pinning both sides."""
    def __init__(self, guard, name, original, row, kind):
        self.guard, self.name, self.original, self.row, self.kind = guard, name, original, row, kind
        assert type(original) in (guard.source_class, guard.extension_class)
    def create_module(self, spec):
        self.guard.physical(self.row['path'])
        module = self.original.create_module(spec)
        self.guard.physical(self.row['path'])
        return module
    def exec_module(self, module):
        self.guard.physical(self.row['path'])
        # Genuine ExtensionFileLoader is used even for its create_module
        # phase above; no custom binary decoder or substitute module exists.
        if self.row['loader'] == 'source':
            self.guard.execute_python_source(self, module)
        else:
            assert self.row['loader'] == 'extension'
            assert type(self.original) is self.guard.extension_class
            self.original.exec_module(module)
            self.guard.extension_executions[self.name] = (module, Path(self.row['path']))
        value = self.guard.source_row(self.name, module, self.row, self.kind)
        self.guard.admissions[self.name] = value
        self.guard.hold_extension_children(self.name, module, self)
        self.guard.hold_extension_aliases(self.name, module, self)
