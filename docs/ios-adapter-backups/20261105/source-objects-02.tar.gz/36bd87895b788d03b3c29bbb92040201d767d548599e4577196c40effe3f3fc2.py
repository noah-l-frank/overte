"""NOT RUN: narrow metadata-only pinning, after explicit Root review/window."""
from pathlib import Path
import hashlib,json,sys
SOURCE=Path(__file__).resolve().parent
assert sys.dont_write_bytecode and len(sys.argv)==2
constants={};exec(compile((SOURCE/'declarations.py').read_bytes(),str(SOURCE/'declarations.py'),'exec'),constants)
plan=constants['DECLARATIONS'];output=Path(sys.argv[1]);assert output.is_absolute()and not output.exists()and output.parent==SOURCE.parent and output.suffix=='.json'
def pin(path):
 path=Path(path);assert path.is_file()and not path.is_symlink()
 return dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
packet=Path(plan['sourcePacket']['path']);assert pin(packet)['sha256']==plan['sourcePacket']['sha256']
freeze=json.loads(packet.read_text())
for name,row in freeze['files'].items():assert pin(packet.parent/name)['sha256']==row['sha256']
plan['modules']={name:dict(pin(row['path']),package=row['package'])for name,row in plan['moduleDeclarations'].items()}
plan['sources']=dict(plan['modules']);plan['controllerFiles']=list(json.loads((SOURCE/'source-freeze.json').read_text())['files'])
plan['frozenPackets']=[pin(packet)]+[pin(packet.parent/name)for name in freeze['files']]
plan['writeBoundarySource']=pin(SOURCE/'owned_write_boundary.py')
plan['sources']['controller-owned-write-boundary']=plan['writeBoundarySource']
with output.open('x')as stream:stream.write(json.dumps(plan,sort_keys=True,indent=2)+'\n')
output.chmod(0o600);print(hashlib.sha256(output.read_bytes()).hexdigest())
