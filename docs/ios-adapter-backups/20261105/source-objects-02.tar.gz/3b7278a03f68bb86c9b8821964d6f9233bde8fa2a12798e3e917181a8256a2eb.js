"use strict";
(function () {
    var companion = Script.require("./companion.js");
    var marker = Entities.addEntity({
        type: "Web", name: "e2e-11111111111111111111111111111111-script",
        userData: "{\"kind\":\"avatar-marker-v1\",\"nonce\":\"33333333333333333333333333333333\",\"runId\":\"11111111111111111111111111111111\"}",
        position: Vec3.sum(MyAvatar.position,
            Vec3.multiplyQbyV(MyAvatar.orientation, {x: 0, y: 1.6, z: -3})),
        rotation: MyAvatar.orientation,
        dimensions: {x: 1.6, y: 0.4, z: 0.01},
        sourceUrl: "https://controlled.invalid/feature-fixture/v1/runs/11111111111111111111111111111111/tickets/22222222222222222222222222222222/graphics-marker.v1.html", visible: true, collisionless: true, dpi: 100
    }, "local");
    Script.scriptEnding.connect(function () {
        if (marker) { Entities.deleteEntity(marker); }
    });
}());
