"""Eight pure metadata contracts. PRIVATE/UNRUN; no product module imports."""
from pathlib import Path
import hashlib
import json
import unittest


class DataWalkerCountercases(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root=Path(__file__).resolve().parent
        plan=json.loads((root/'package-plan.json').read_text());cls.walkers=[]
        for filename,key in (('baseline-data.py','baselineDataSha256'),('candidate-data.py','candidateDataSha256')):
            body=(root/filename).read_bytes()
            if hashlib.sha256(body).hexdigest()!=plan[key]:raise AssertionError('Frozen metadata function changed')
            namespace={}
            # Only the single retained pure function is evaluated. Its own
            # recursive calls resolve within this private namespace. No live
            # parser/module replacement, SDK, area or historical read occurs.
            exec(compile(body,str(root/filename),'exec'),namespace)
            cls.walkers.append(namespace['data'])

    def test_01_primitives_preserve_exact_object_identity_even_at_depth_limit(self):
        values=[None,False,True,0,10**40,-3.5,float('nan'),float('inf'),'text',b'bytes']
        for walk in self.walkers:
            for value in values:
                self.assertIs(value,walk(value,depth=100))

    def test_02_container_sorting_key_coercion_and_repr_order_are_literal(self):
        value={'z':{2,10},4:[False,('x',None)],'a':frozenset({3,11})}
        expected=(('4',(False,('x',None))),('a',(11,3)),('z',(10,2)))
        for walk in self.walkers:self.assertEqual(expected,walk(value))

    def test_03_self_and_mutual_cycles_stop_at_the_actual_ancestor_identity(self):
        value=[];value.append(value);left={};right=[left];left['link']=right
        for walk in self.walkers:
            self.assertEqual((('cycle',id(value)),),walk(value))
            self.assertEqual((('link',(('cycle',id(left)),)),),walk(left))

    def test_04_sibling_alias_is_not_a_cycle_and_caller_seen_set_is_not_mutated(self):
        shared=[1,None];value=[shared,shared];seen={123456789}
        for walk in self.walkers:
            self.assertEqual(((1,None),(1,None)),walk(value,seen))
            self.assertEqual({123456789},seen)
            self.assertEqual(('cycle',id(shared)),walk(shared,{id(shared)}))

    def test_05_depth_six_identity_precedes_cycle_and_does_not_hide_primitives(self):
        leaf=object();container=[leaf,None];seen={id(container)}
        for walk in self.walkers:
            self.assertEqual(('identity',id(container)),walk(container,seen,depth=6))
            self.assertEqual((('identity',id(leaf)),None),walk(container,depth=5))
            self.assertEqual((('identity',id(leaf)),None),walk(tuple(container),depth=5))

    def test_06_builtin_subclasses_and_opaque_objects_are_not_traversed(self):
        class ListChild(list):pass
        class DictChild(dict):pass
        class TupleChild(tuple):pass
        class SetChild(set):pass
        class IntChild(int):pass
        class StrChild(str):pass
        values=[ListChild([1]),DictChild(a=1),TupleChild((1,)),SetChild({1}),IntChild(2),StrChild('s'),object()]
        for walk in self.walkers:
            for value in values:self.assertEqual(('identity',id(value)),walk(value))

    def test_07_nested_mutations_are_recomputed_and_reverting_restores_same_descriptor(self):
        for walk in self.walkers:
            value={'defaults':[{'mode':False}],'kwdefaults':None};first=walk(value)
            self.assertEqual((('defaults',((('mode',False),),)),('kwdefaults',None)),first)
            value['defaults'][0]['mode']=True
            self.assertNotEqual(first,walk(value))
            value['defaults'][0]['mode']=False;self.assertEqual(first,walk(value))
            value['kwdefaults']={};self.assertNotEqual(first,walk(value))

    def test_08_legacy_type_equality_and_key_conversion_failures_are_preserved(self):
        # The original uses tuple membership, including NoneType equality.
        # Exact-type rewriting would silently change this unusual old input.
        class PretendNone(type):
            def __eq__(cls,other):return other is type(None)
        class Value(metaclass=PretendNone):pass
        value=Value()
        class BadKey:
            def __str__(self):raise ValueError('key cannot be rendered')
        for walk in self.walkers:
            self.assertIs(value,walk(value))
            with self.assertRaisesRegex(ValueError,'key cannot be rendered'):walk({BadKey():1})


if __name__=='__main__':unittest.main()
