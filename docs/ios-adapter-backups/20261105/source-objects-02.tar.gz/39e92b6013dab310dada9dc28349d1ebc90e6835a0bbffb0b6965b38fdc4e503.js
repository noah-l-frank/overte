"use strict";
(function () {
    var companion = Script.require("./companion.js");
    var page = "http://127.0.0.1:40211/feature-fixture/v1/runs/a9b8a3c5940eaa29f4fa4de23d14af7c/tickets/ce28e82a5c7546a6a280b8f09ba90c10/reference.html", injected = "http://127.0.0.1:40211/feature-fixture/v1/runs/a9b8a3c5940eaa29f4fa4de23d14af7c/tickets/ce28e82a5c7546a6a280b8f09ba90c10/injected.js", entity = null, stopped = false, call = 0;
    var observer = typeof Test !== "undefined" && typeof Test.featureIOSWorldWebEvent === "function" ? Test : null;
    function event(kind, sequence, payload) {
        if (observer) observer.featureIOSWorldWebEvent({worldWebWorkEventVersion:1,runId:"a9b8a3c5940eaa29f4fa4de23d14af7c",nonce:"8b6408f589b5ae1e7c3dc35dc1c9cacd",event:kind,call:sequence,payload:payload});
    }
    function tracked(kind, payload, closure) {
        if (!observer) return closure();
        var sequence = ++call;
        event(kind + "-enter", sequence, payload);
        try { var result = closure(); event(kind + "-return", sequence, payload); return result; }
        finally { event(kind + "-finally", sequence, payload); }
    }
    function respond(message, surface, send) {
        var packet;
        if (typeof message !== "string" || message.length > 4096) return;
        try { packet = JSON.parse(message); } catch (_) { return; }
        if (!packet || packet.contract !== "overte-web-parity-v1" || packet.action !== "echo" ||
                typeof packet.sequence !== "number" || !isFinite(packet.sequence) ||
                packet.sequence < 1 || packet.sequence > 1000000 || Math.floor(packet.sequence) !== packet.sequence) return;
        send(JSON.stringify({contract: packet.contract, action: "echo", sequence: packet.sequence, surface: surface}));
    }

    function worldEvent(id, message) {
        if (!stopped && entity && String(id) === String(entity)) {
            return tracked("world-event", {entityId:String(id),message:message}, function () {
                return respond(message, "world", function (reply) {
                    return tracked("script-reply", {entityId:String(entity),message:reply}, function () {
                        return Entities.emitScriptEvent(entity, reply);
                    });
                });
            });
        }
    }
    entity = Entities.addEntity({type:"Web",name:"e2e-a9b8a3c5940eaa29f4fa4de23d14af7c-script",userData:"{\"kind\":\"emote-marker-v1\",\"nonce\":\"8b6408f589b5ae1e7c3dc35dc1c9cacd\",\"runId\":\"a9b8a3c5940eaa29f4fa4de23d14af7c\"}",sourceUrl:page,scriptURL:injected,
        position:Vec3.sum(Camera.position,Vec3.multiplyQbyV(Camera.orientation,{x:0,y:0,z:-1.5})),rotation:Camera.orientation,
        dimensions:{x:1.8,y:1.4,z:0.01},dpi:12,maxFPS:30,grab:{grabbable:false},visible:true,collisionless:true},"local");
    Entities.webEventReceived.connect(worldEvent);
    event("loaded", 0, {entityId:entity ? String(entity) : null});
    Script.scriptEnding.connect(function () {
        return tracked("ending", {entityId:entity ? String(entity) : null}, function () {
            stopped = true;
            Entities.webEventReceived.disconnect(worldEvent);
            if (entity) Entities.deleteEntity(entity);
        });
    });
}());
