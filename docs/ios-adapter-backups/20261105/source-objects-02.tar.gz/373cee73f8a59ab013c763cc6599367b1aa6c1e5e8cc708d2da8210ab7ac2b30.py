"""Exactly nine existing C22 lower-model counters, true30+5 Root supervisor."""
from pathlib import Path
from metadata_reader import pin
from host_common import head
from closed_import_origins import ClosedOrigins
from own9_controls import Own9Controls
from method_custody import MethodCustody
import builtins,contextlib,hashlib,importlib.abc,importlib.machinery,importlib.util,io,json,os,signal,stat,sys,tempfile,threading,time,traceback,types,unittest
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert sys.flags.no_site==1 and sys.dont_write_bytecode and len(sys.argv)==3
INPUT=Path(sys.argv[1]);input_before=pin(INPUT);assert INPUT==HERE/'approved-inputs.json'and input_before['sha256']==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)and head()==plan['actualPublicHead']
assert plan['status']=='PRIVATE_ASSETS_C22_DIRFD_OWN9_SOURCE_UNRUN'and plan['cases']==json.loads((HERE/'exact-nine-selectors.json').read_text())
assert len(plan['cases'])==len(set(plan['cases']))==9 and plan['wallSeconds']==30 and plan['killGraceSeconds']==5
assert plan['subjectHelperSha256']=='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
assert plan['subjectActualCopiedPath']==str(HERE/'closed_import_origins.py')and pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
assert all(plan[k]==0 for k in('PythonChildExecutions','NodeExecutions','HTTPExecutions','UDPExecutions','TLSExecutions','SDKExecutions','overteNativeQueries','oldCorpusInputs','globalOriginalScans'))
assert plan['expectedTemporaryDirectories']==9 and plan['expectedTemporaryDirectoriesPerCase']==1 and plan['C22PhaseAdmission']is None
assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
TOYS=HERE/'own-toys';RECEIPTS=HERE/'child-receipts'
assert all(p.is_dir()and not any(p.iterdir())for p in(TOYS,RECEIPTS))
assert os.environ['TMPDIR']==str(TOYS)and Path(tempfile.gettempdir())==TOYS
initial_path=tuple(sys.path);initial_meta=tuple(sys.meta_path);loaded={};diagnostics=[];diagnostic_receivers=[]
bootstrap={'metadata_reader','host_common','closed_import_origins','own9_controls','method_custody'}
for name,row in plan['modules'].items():
 if name in bootstrap:
  module=sys.modules[name];assert vars(module)['__file__']==row['path']and pin(row['path'])==plan['sourceAndBinaryPins'][row['path']]
 else:assert name not in sys.modules
sys.path[:]=[p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
origin_plan=plan['originPlan'];assert origin_plan['physicalPins']==plan['sourceAndBinaryPins']and origin_plan['modules']==plan['modules']
origins=ClosedOrigins(origin_plan,HERE,REPO,pin)
controls=Own9Controls();original_io=(io.open,builtins.open);original_term=signal.getsignal(signal.SIGTERM)
original_ports={n:getattr(os,n)for n in('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')if hasattr(os,n)}
original_cleanup=unittest.TestCase.doCleanups;original_td=tempfile.TemporaryDirectory
loaded_definition_names=set(json.loads((HERE/'project-source-inputs.json').read_text())['modules'])-{'owned_write_boundary','backend_dirfd_ports','backend_dirfd_qualification','test_backend_dirfd_boundary','utility_retained_roots'}
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright','PIL')
tops={n.split('.')[0]for n in(*plan['modules'],*plan['namespaces'])}

def save(name,body):
 path=RECEIPTS/name;assert path.parent==RECEIPTS and not path.exists()
 raw=(json.dumps(body,sort_keys=True,indent=2)+'\n').encode();fd=original_ports['open'](path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
 try:
  offset=0
  while offset<len(raw):offset+=original_ports['write'](fd,raw[offset:])
  os.fsync(fd)
 finally:original_ports['close'](fd)
save_fn=save;save_code=save.__code__;save_globals=save.__globals__

def audit(event,args):
 if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Unselected SDK/renderer import')
 if event.startswith('socket.')or event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
  raise RuntimeError('No qualifier process/network/SDK/native/signal action')
 relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
 if not relevant:return
 if event=='open':
  unused,mode,flags=args;writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
  if not writing:return
 caller=sys._getframe(1);runtime=controls.runtime
 if runtime is not None and runtime.active:
  controls.fault_audit(event,args,caller);runtime.helper.audit(event,args,caller);return
 if event=='open':
  value,mode,flags=args
  assert caller.f_code is save_code and caller.f_globals is save_globals and save is save_fn and save_fn.__code__ is save_code
  assert type(value)in(str,type(HERE))and Path(value)==caller.f_locals['path']and Path(value).parent==RECEIPTS
  assert mode is None and flags==(os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC)
  return
 raise RuntimeError('Mutation outside actual counter writer scope')
sys.addaudithook(audit)

def diagnostic_snapshot(phase):
 try:return origins.snapshot(phase)
 except BaseException as error:
  try:
   rows=[];trace=error.__traceback__
   while trace:
    frame=trace.tb_frame
    if frame.f_code is execution_code and frame.f_globals is execution_globals and frame.f_locals.get('self')is origins:
     values=frame.f_locals;name=values.get('name');module=values.get('module');held=values.get('original_module');current=sys.modules.get(name)if type(name)is str else None
     diagnostic_receivers.append((module,held,current))
     def actual(m):return dict(identity=id(m),name=vars(m).get('__name__'),file=vars(m).get('__file__'))if type(m)is types.ModuleType else dict(identity=id(m),type=type(m).__name__)
     rows.append(dict(name=name,receiver=actual(module),heldReceiver=actual(held),sysModulesReceiver=actual(current),moduleIsHeld=module is held,actualPath=str(values.get('actual')),heldPath=str(values.get('path')),line=trace.tb_lineno,offset=trace.tb_lasti))
    trace=trace.tb_next
   diagnostics.append(dict(phase=phase,exception=type(error).__name__,rows=rows,diagnosticOnly=True,originalExceptionRethrown=True))
   save('original-origin-refusal-'+str(len(diagnostics))+'.json',diagnostics[-1])
  except BaseException:
   try:print(traceback.format_exc(),flush=True)
   except BaseException:pass
  raise
execution=ClosedOrigins.execution_row;execution_code=execution.__code__;execution_globals=execution.__globals__
origin_before=diagnostic_snapshot('before-own9-project-imports')
class AfterLoader(importlib.abc.Loader):
 def __init__(self,name,delegate):self.name,self.delegate=name,delegate
 def create_module(self,spec):return self.delegate.create_module(spec)
 def exec_module(self,module):
  self.delegate.exec_module(module);row=plan['modules'][self.name]
  assert vars(module)['__file__']==row['path']and pin(row['path'])==plan['sourceAndBinaryPins'][row['path']]
  loaded[self.name]=row['path']
  if self.name in loaded_definition_names:controls.definitions(module)
class Finder(importlib.abc.MetaPathFinder):
 def find_spec(self,name,path=None,target=None):
  if name.split('.')[0]in forbidden:raise ImportError('Forbidden definition/SDK/renderer import')
  if name in plan['modules']:
   spec=origins.file_spec(name,dict(plan['modules'][name],loader='source'),'project');spec.loader=AfterLoader(name,spec.loader);return spec
  if name in plan['namespaces']:
   values=plan['namespaces'][name];origins.namespaces(name,values,values,'project')
   spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=values;return spec
  if name.split('.')[0]in tops:raise ImportError('Unmapped project import before execution: '+name)
  return origins.remaining_spec(name,path)
finder=Finder();sys.meta_path.insert(0,finder)
# Observer starts before genuine definition imports. No XML import is added or
# reordered to avoid C10c's separately known frontier refusal.
subject=qualifier=producers=backend_source=None;original_source_tempfile=None;custody=None
retained=[];retained_objects=[];runtimes=[];cleanup_calls=[];factory_cases=[]
case_rows=[];selected=[];result=None;fatal=None;passed=False
def fds():
 rows={}
 for path in Path('/proc/self/fd').iterdir():
  try:info=path.stat();rows[path.name]=dict(target=os.readlink(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
  except(FileNotFoundError,ProcessLookupError):pass
 return rows
def kernel():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text().strip()
fd_before=fds();threads_before=tuple(threading.enumerate());kernel_before=kernel()
try:
 controls.install()
 import test_backend_dirfd_boundary as subject
 import backend_dirfd_qualification as qualifier
 import test_asset_backend_files as producers
 import test_asset_backend_source as backend_source
 from utility_retained_roots import retain_owned_root
 controls.bind(subject)
 retained=[];retained_objects=[];runtimes=[];cleanup_calls=[];factory_cases=[]
 setup=backend_source.BackendSourceTests.__dict__['setUp'];setup_code=setup.__code__;setup_globals=setup.__globals__
 original_source_tempfile=backend_source.tempfile

 def retained_directory(*args,**kwargs):
  frame=sys._getframe(1)
  assert frame.f_code is setup_code and frame.f_globals is setup_globals and type(frame.f_locals.get('self'))is backend_source.BackendSourceTests
  assert backend_source.BackendSourceTests.__dict__['setUp']is setup and setup.__code__ is setup_code
  assert controls.case is not None and controls.runtime is not None and controls.runtime.active and not args and not kwargs
  directory=original_td(dir=TOYS);path=Path(directory.name)
  assert path.parent==TOYS and path.resolve(strict=True)==path
  retain_owned_root(directory,expected_root=path);info=path.lstat();retained_objects.append(directory)
  retained.append(dict(path=str(path),device=info.st_dev,inode=info.st_ino,case=controls.case.id(),originalSetup=setup_code.co_filename))
  return directory
 proxy=types.SimpleNamespace(**vars(tempfile));proxy.TemporaryDirectory=retained_directory;backend_source.tempfile=proxy

 def factory():
  assert controls.case is not None and controls.runtime is None and controls.case.id()not in factory_cases
  assert all(getattr(os,name)is original for name,original in original_ports.items())and original_io==(io.open,builtins.open)
  rows={name:dict(path=plan['modules'][name]['path'],pin=plan['sourceAndBinaryPins'][plan['modules'][name]['path']])for name in('adapters.asset_backend_files','test_asset_backend_files')}
  runtime=qualifier.QualificationRuntime(TOYS,pin,rows,sys.modules['adapters.asset_backend_files'],producers)
  factory_cases.append(controls.case.id());controls.runtime=runtime;runtimes.append(runtime);return runtime
 subject.RUNTIME_FACTORY=factory

 def observe_cleanup(case):
  returned=None;raised=None;before=len(case._cleanups)
  try:returned=original_cleanup(case);return returned
  except BaseException as error:raised=type(error).__name__;raise
  finally:cleanup_calls.append(dict(owner=type(case).__module__+'.'+type(case).__qualname__,pendingBefore=before,remaining=len(case._cleanups),originalReturn=returned,originalRaised=raised))
 unittest.TestCase.doCleanups=observe_cleanup
 custody=MethodCustody(plan['sourceAndBinaryPins'],pin)
 for name,clsname in(('closed_import_origins','ClosedOrigins'),('closed_import_origins','PinnedDelegate'),('owned_write_boundary','OwnedWrites'),
  ('backend_dirfd_ports','BackendDirFDPorts'),('backend_dirfd_qualification','QualificationRuntime'),('test_backend_dirfd_boundary','BackendDirFDBoundaryTests'),
  ('adapters.asset_backend_files','AssetsBackendFiles'),('test_asset_backend_files','ProcessModel'),('test_asset_backend_files','BackendFilesTests'),
  ('test_asset_backend_source','BackendSourceTests'),('test_asset_backend_source','NativeWorkModel'),('test_asset_backend_source','Holder')):
  module=sys.modules[name];custody.bind(module,vars(module)[clsname])
 assert sys.gettrace()is None and sys.getprofile()is None

 class Result(unittest.TextTestResult):
  def startTest(self,test):
   assert unittest.TestCase.doCleanups is observe_cleanup and custody.check()and controls.definitions_unchanged()and controls.case is None and controls.runtime is None
   diagnostic_snapshot('before-case-'+test.id());controls.case=test
   self.before=(fds(),tuple(threading.enumerate()),kernel(),len(retained),len(cleanup_calls));super().startTest(test)
  def stopTest(self,test):
   fd,threads,children,roots,cleanups=self.before;failure=None;resource=None
   try:resource=controls.finish_case();assert unittest.TestCase.doCleanups is observe_cleanup and custody.check()and controls.definitions_unchanged();diagnostic_snapshot('after-case-'+test.id())
   except BaseException:failure=traceback.format_exc();self.addError(test,sys.exc_info())
   row=dict(id=test.id(),standardStopAfterCleanup=True,remainingCleanups=len(test._cleanups),fdUnchanged=fds()==fd,
    threadsUnchanged=tuple(threading.enumerate())==threads,kernelUnchanged=kernel()==children,newTDs=len(retained)-roots,
    cleanups=cleanup_calls[cleanups:],actualResources=resource,resourceFailure=failure)
   case_rows.append(row);save('standard-case-'+str(len(case_rows))+'.json',row);super().stopTest(test)
 def interrupt(signum,frame):
  print('ACTUAL_OWN9_TERM_STACK',flush=True);traceback.print_stack(frame);raise KeyboardInterrupt('Fixed30-second Own9 boundary')
 signal.signal(signal.SIGTERM,interrupt)
 module=subject;loader=unittest.TestLoader();suite=unittest.TestSuite()
 for selected_id in plan['cases']:
  name,clsname,method=selected_id.rsplit('.',2);assert name==module.__name__
  suite.addTests(loader.loadTestsFromName(clsname+'.'+method,module))
 def flatten(value):
  if isinstance(value,unittest.TestSuite):
   for item in value:yield from flatten(item)
  else:yield value
 selected=list(flatten(suite));assert not loader.errors and [test.id()for test in selected]==plan['cases']and suite.countTestCases()==9
 save('actual-selection.json',dict(ids=[test.id()for test in selected],loaderErrors=loader.errors))
 result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
 cleanup_rescues=[]
 for test in selected:
  if test._cleanups:
   before=len(test._cleanups);returned=None;error=None
   try:returned=original_cleanup(test)
   except BaseException:error=traceback.format_exc()
   cleanup_rescues.append(dict(id=test.id(),pending=before,originalReturn=returned,remaining=len(test._cleanups),error=error))
 # Failure drain is typed, preserves original failures, and can never qualify.
 fd_rescues=[]
 for row in controls.dup_rows:
  try:
   info=os.fstat(row['held'])
   if controls.identity(info)==row['identity']:
    original_ports['close'](row['held']);fd_rescues.append(dict(fd=row['held'],kind='known-duplicate',device=info.st_dev,inode=info.st_ino))
  except OSError:pass
 for runtime in runtimes:
  for descriptor,row in tuple(runtime.boundary.files.items()):
   try:
    info=os.fstat(descriptor)
    if(info.st_dev,info.st_ino)==(row[2],row[3]):runtime.originals['close'](descriptor);fd_rescues.append(dict(fd=descriptor,kind='known-leaf',device=info.st_dev,inode=info.st_ino))
   except OSError:pass
  for descriptor,row in tuple(runtime.boundary.roots.items()):
   try:
    info=os.fstat(descriptor)
    if(info.st_dev,info.st_ino)==row[2][:2]:runtime.originals['close'](descriptor);fd_rescues.append(dict(fd=descriptor,kind='known-root',device=info.st_dev,inode=info.st_ino))
   except OSError:pass
 if backend_source is not None and original_source_tempfile is not None:backend_source.tempfile=original_source_tempfile
 if subject is not None:subject.RUNTIME_FACTORY=None
 unittest.TestCase.doCleanups=original_cleanup
 restored=all(getattr(os,name)is original for name,original in original_ports.items())and original_io==(io.open,builtins.open)
 control_receipt=controls.restore();signal.signal(signal.SIGTERM,original_term)
 final_origin=None;origin_error=None
 try:final_origin=diagnostic_snapshot('after-own9-original-cleanup')
 except BaseException:origin_error=traceback.format_exc()
 actual_origins={}
 for name in('owned_write_boundary','backend_dirfd_ports','backend_dirfd_qualification','test_backend_dirfd_boundary','adapters.asset_backend_files','test_asset_backend_files','test_asset_backend_source'):
  module=sys.modules.get(name);row=plan['modules'][name]
  actual_origins[name]=dict(actualFile=None if module is None else vars(module).get('__file__'),executedPath=loaded.get(name),expectedPath=row['path'],expectedSHA=row['sha256'])
 origins_ok=all(r['actualFile']==r['executedPath']==r['expectedPath']and pin(r['expectedPath'])['sha256']==r['expectedSHA']for r in actual_origins.values())
 pins_after={p:pin(p)for p in plan['sourceAndBinaryPins']};input_after=pin(INPUT)
 source_ok=pins_after==plan['sourceAndBinaryPins']and input_after==input_before and input_after['sha256']==sys.argv[2]and final_origin is not None and origin_error is None
 passed=(fatal is None and result is not None and result.testsRun==9 and result.wasSuccessful()and not result.skipped and len(case_rows)==len(factory_cases)==len(retained)==len(runtimes)==9)
 passed=passed and all(row['remainingCleanups']==0 and row['fdUnchanged']and row['threadsUnchanged']and row['kernelUnchanged']and row['newTDs']==1 and row['resourceFailure']is None for row in case_rows)
 passed=passed and len(cleanup_calls)==27 and all(r['originalReturn']is True and r['originalRaised']is None and r['remaining']==0 for r in cleanup_calls)
 passed=passed and restored and not cleanup_rescues and not fd_rescues and not control_receipt['problems']and control_receipt['actualHelperThreads']==1 and control_receipt['toolsRestored']and control_receipt['dupPortsRestored']
 passed=passed and fds()==fd_before and tuple(threading.enumerate())==threads_before and kernel()==kernel_before==''and source_ok and origins_ok
 save('actual-source-origins.json',dict(origins=actual_origins,allActualOriginsEstablished=origins_ok,loaded=loaded))
 save('actual-cleanup.json',dict(originalCalls=cleanup_calls,outerCleanupRescues=cleanup_rescues,typedFailureFDRescues=fd_rescues,standardCleanupQualified=passed))
 save('actual-ports-and-tools.json',dict(originalPortsRestored=restored,ports=len(original_ports),originalCIO=original_io==(io.open,builtins.open),controls=control_receipt))
 save('actual-all-loaded-origins-before.json',origin_before);save('actual-all-loaded-origins-after.json',final_origin)
 save('report.json',dict(status='PASS'if passed else'FAIL_OR_REFUSED',testsRun=None if result is None else result.testsRun,cases=case_rows,fatal=fatal,originError=origin_error,
  sourceAndInputUnchanged=source_ok,allActualLoadedOriginsAccounted=final_origin is not None and origin_error is None,actualOriginsEstablished=origins_ok,
  fdUnchanged=fds()==fd_before,threadsUnchanged=tuple(threading.enumerate())==threads_before,kernelChildrenUnchanged=kernel()==kernel_before=='',retainedTDs=retained,
  actualHelperThreads=control_receipt['actualHelperThreads'],originalCleanupCalls=len(cleanup_calls),wholeQualified=False,normalAction2Qualified=False,C22PhaseAdmission=None,SDKExecutions=0,NodeExecutions=0,PythonChildExecutions=0))
 sys.meta_path[:]=initial_meta;sys.path[:]=initial_path
raise SystemExit(0 if passed else 1)
