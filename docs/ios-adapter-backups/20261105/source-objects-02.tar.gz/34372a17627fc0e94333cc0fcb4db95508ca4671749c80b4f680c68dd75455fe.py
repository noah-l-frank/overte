"""Actual pre-operation source allocation, original CAS/copy and no replay.

Real loopback SDK/Source/WAL/frames execute. Native/UIKit/clock/SDK endpoints
remain explicit host models; no whole26/native/device/Actor authority follows.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import unittest
from unittest.mock import patch

from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.original_frame_store import OriginalFrameStore
from ios.adapters import tablet_web_aggregate_root as aggregate
from ios.adapters.tablet_web_feature import operation_source_reserve
from ios.adapters.tablet_web_source_owner import TabletWebSourceOwner,ORDER
from ios.self_tests.tablet_web_paired_fixture import PairedTabletFixture
from ios.self_tests.test_ios_tablet_web_sources import RUN
from ios.self_tests.test_ios_tablet_web_sample_root import TabletOwnedSampleRootTests


class TabletOperationReserveTests(unittest.TestCase):
    def setUp(self):
        self.fixture=PairedTabletFixture(self);self.primary=self.fixture.primary;self.boundary=self.fixture.boundary
        self.primary.observe(dict(contractVersion=16,runId=RUN,afterSequence=0))

    @staticmethod
    def pins(paths):
        return {str(path):(path.stat().st_dev,path.stat().st_ino,path.stat().st_size,path.stat().st_mtime_ns,
            path.stat().st_ctime_ns,path.read_bytes()) for path in paths}

    def original126(self):
        with self.primary.parts() as runtime:
            owner=runtime.observer.source;self.assertIs(type(owner),TabletWebSourceOwner)
            child=owner.children['dom']
            while len(child.state['records'])<126:child.capture(runtime.observer.readers['dom'])
            self.assertEqual(126,len(child.state['records']))
            self.assertTrue(all(child.originals.read(child.originals.expand(ref))['status']=='returned' for ref in child.state['records']))
            self.legacy=owner;self.old_count=len(owner.state['records'])
            self.children=self.pins([child.store.path for child in owner.children.values()])
            self.last=deepcopy(child.state['records'][-1])
            self.assertFalse((owner.root/aggregate.root_name(RUN,'primary')).exists())

    def public_observe(self):return self.primary.observe(dict(contractVersion=16,runId=RUN,afterSequence=0))

    def checked_current(self):
        with self.primary.parts() as runtime:
            owner=runtime.observer.source;self.assertIs(type(owner),aggregate.TabletWebAggregateRoot)
            self.assertEqual(self.children,self.pins([owner.root/name.rsplit('/',1)[-1] for name in self.children]))
            self.assertEqual(self.last,owner.children['dom'].reference(126))
            self.assertEqual(self.old_count+1,owner.state['records'][0]['index'])
            calls=deepcopy(self.fixture.sdk.calls)
            historical=aggregate.source_owner(owner.root,owner.binding,owner.run,owner.role,owner.fixture,owner.pid,owner.lock,
                lambda:True,epoch_ms=owner.epoch_ms,monotonic=owner.monotonic,historical=True)
            self.assertTrue(historical.historical);row,_frame,_prefix=historical.frame_at(owner.state['records'][0])
            self.assertEqual(calls,self.fixture.sdk.calls)
            self.assertEqual(127,next(part['index'] for part in row['components'] if part['component']=='dom'))
            return owner,self.pins([owner.root/('tabletweb-source-owner-'+RUN+'-primary.json')])

    def test_public_observe_rotates_real_126_DOM_prefix_before_first_new_frame_and_keeps_original_heads(self):
        self.original126();observed=self.public_observe();owner,parent=self.checked_current()
        self.assertEqual(self.old_count+1,observed['sequence']);self.assertFalse(observed['state']['open'])
        self.public_observe()
        self.assertEqual(parent,self.pins([owner.root/('tabletweb-source-owner-'+RUN+'-primary.json')]))
        self.assertEqual([],self.fixture.sdk.errors)

    def test_lost_saved_reserved_copy_return_recovers_same_original_without_another_copy_write(self):
        self.original126();write=OriginalFrameStore.write;copies=[]
        def actual(store,index,frame):
            value=write(store,index,frame)
            if store.namespace=='tabletweb-closed-headers':
                copies.append(store.path(store.expand(value)))
                if len(copies)==1:raise OSError('Actual reserved closed-copy local return lost')
            return value
        with patch.object(OriginalFrameStore,'write',actual):
            with self.assertRaises(OSError):self.public_observe()
            self.assertEqual(1,len(copies));before=self.pins(copies)
            self.assertEqual(self.children,self.pins([part.store.path for part in self.legacy.children.values()]))
            self.assertEqual('saved',self.legacy.store.read()['copyIntent']['phase'])
            self.public_observe();self.checked_current()
            self.assertEqual(1,len(copies));self.assertEqual(before,self.pins(copies))
        self.assertEqual([],self.fixture.sdk.errors)

    def test_saved_reserved_CAS_without_copy_receipt_remains_owned_and_new_operation_never_begins(self):
        self.original126();write=PrivateFeatureState.write;lost=[]
        def actual(store,value,previous):
            result=write(store,value,previous)
            if store.path==self.legacy.store.path and value.get('tabletWebSourceOwnerVersion')==3 and not lost:
                lost.append(True);raise OSError('Actual reserved Source3 CAS local return lost')
            return result
        with patch.object(PrivateFeatureState,'write',actual),self.assertRaises(OSError):self.public_observe()
        self.assertEqual([True],lost);self.assertIsNone(self.legacy.store.read()['copyIntent']);before=self.pins([self.legacy.store.path])
        for _attempt in range(2):
            with self.assertRaises(NativeUIError):self.public_observe()
            self.assertEqual(before,self.pins([self.legacy.store.path]))
            self.assertEqual(self.children,self.pins([part.store.path for part in self.legacy.children.values()]))
            self.assertFalse((self.legacy.root/aggregate.root_name(RUN,'primary')).exists())
            self.assertFalse(any(path.name.startswith('tabletweb-closed-headers-') for path in self.legacy.root.iterdir()))
        self.assertEqual([],self.fixture.sdk.errors)

    def test_invalid_profiles_refuse_before_any_SDK_call_and_caller_alias_change_during_real_process_read_is_detached(self):
        valid=operation_source_reserve('observe');callbacks=[]
        class Foreign(dict):
            def __getitem__(self,key):callbacks.append('foreign');raise AssertionError('No subtype callback')
        class Opaque:
            def __hash__(self):callbacks.append('hash');return 17
            def __eq__(self,other):callbacks.append('eq');return False
        bad=[False,Foreign(valid),dict(valid,aggregate=True),dict(valid,aggregate=129),dict(valid,unknown=1)]
        for value in (0,True,1.,None,129):
            changed=deepcopy(valid);changed['children']['dom']=value;bad.append(changed)
        changed=deepcopy(valid);changed['children'][Opaque()]=1;bad.append(changed);callbacks.clear()
        for value in bad:
            calls=list(self.fixture.sdk.calls)
            with self.assertRaises(NativeUIError):
                with self.primary.parts(source_reserve=value):self.fail('Invalid reservation must not reach owner construction')
            self.assertEqual(calls,self.fixture.sdk.calls)
        self.assertEqual([],callbacks)
        requested=operation_source_reserve('observe');original=self.boundary.process;changed=[]
        def actual():
            value=original()
            if not changed:requested['children']['dom']=0;changed.append(True)
            return value
        with patch.object(self.boundary,'process',actual),self.primary.parts(source_reserve=requested) as runtime:
            self.assertIs(type(runtime.observer.source),TabletWebSourceOwner);runtime.tail_source()
        self.assertEqual([True],changed);self.assertEqual(0,requested['children']['dom']);self.assertEqual([],self.fixture.sdk.errors)

    def test_owned_epoch_without_requested_room_refuses_before_yield_and_never_creates_another_epoch(self):
        with self.primary.parts() as runtime:
            owner=TabletOwnedSampleRootTests.source_root(runtime);runtime.tail_source()
            paths=[owner.store.path,*[child.store.path for child in owner.children.values()]];before=self.pins(paths)
        requested=dict(aggregate=128,children={name:128 for name in ORDER})
        with self.assertRaises(NativeUIError):
            with self.primary.parts(source_reserve=requested):self.fail('An exhausted owned epoch cannot yield any new input owner')
        self.assertEqual(before,self.pins(paths));self.assertEqual(1,len(list(owner.root.glob('tabletweb-aggregate-root-*.json'))))
        self.assertEqual([],self.fixture.sdk.errors)


if __name__=='__main__':unittest.main()
