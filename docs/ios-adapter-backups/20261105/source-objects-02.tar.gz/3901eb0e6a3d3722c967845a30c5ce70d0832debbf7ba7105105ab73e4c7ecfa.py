"""Counter-only real CPython pre-spawn event observer. No child admission.

The actual command/pipe guard may accept its real event, but the counter ALWAYS
raises PreSpawnStop there. This never proves a process was created or exited.
"""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,threading


class PreSpawnStop(RuntimeError):pass


_ACTIVE=None
_INSTALLED=False


def metadata(path):
    path=Path(path);before=path.lstat()
    assert path.resolve(strict=True)==path and not path.is_symlink()and stat.S_ISREG(before.st_mode)
    raw=path.read_bytes();after=path.lstat()
    fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    row=dict(stat=[getattr(before,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest())
    assert row['stat']==[getattr(after,key)for key in fields];return row


def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:
            link=os.readlink(path);info=path.stat()
            result[path.name]=dict(link=link,device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result


def children():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()


def audit(event,args):
    # Classification precedes function-code/frame inspection. No global active
    # exception authorizes an OS child: every actual subprocess event raises.
    if event=='subprocess.Popen':
        current=_ACTIVE
        if current is None:raise RuntimeError('Counter forbids all unbound subprocesses')
        current.before_spawn(args,sys._getframe(1))
        raise PreSpawnStop('Actual accepted audit event stopped before fork/exec')
    if event in('os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen')or event.startswith('os.spawn'):
        raise RuntimeError('Counter never creates OS children or native SDK loads')
    if event.startswith('socket.')and event not in('socket.__new__',):
        current=_ACTIVE
        if current is None or current.loopbacks is None:raise RuntimeError('Unbound socket transport refused')
        if current.before_socket_event is not None:current.before_socket_event(event,args)
        current.loopbacks.audit(event,args,sys._getframe(1))
    if event=='open'and _ACTIVE is not None:
        descriptor,mode,flags=args
        writing=type(mode)is str and any(letter in mode for letter in'wax+')or type(flags)is int and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if writing:
            current=_ACTIVE;frame=sys._getframe(1)
            current.observe_constructor(frame)
            if type(descriptor)is int and current.port.pipe_open(args,frame):return
            current.boundary.audit(event,args)


def install():
    global _INSTALLED
    if not _INSTALLED:sys.addaudithook(audit);_INSTALLED=True


class OriginalPreSpawnObserver:
    def __init__(self,port,boundary,loopbacks=None):
        self.port,self.boundary,self.loopbacks=port,boundary,loopbacks;self.before_socket_event=None
        self.descriptors=[];self.original_streams=[];self.actual_constructor=None
        self.actual_audit_events=[];self.accepted=0;self.thread=threading.get_ident();self.kernel_children_before=children()
    def observe_constructor(self,frame):
        assert threading.get_ident()==self.thread
        code=self.port.popen_methods[0][2]
        while frame is not None:
            if frame.f_code is code and frame.f_globals is self.port.popen_methods[0][1].__globals__:
                child=frame.f_locals['self'];assert type(child)is self.port.popen
                if self.actual_constructor is None:self.actual_constructor=child
                assert child is self.actual_constructor
                for name in('p2cread','p2cwrite','c2pread','c2pwrite','errread','errwrite'):
                    descriptor=frame.f_locals.get(name)
                    if type(descriptor)is int and descriptor>=0:
                        info=os.fstat(descriptor);assert stat.S_ISFIFO(info.st_mode)
                        row=dict(descriptor=descriptor,device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
                        if row not in self.descriptors:self.descriptors.append(row)
                for name in('stdin','stdout','stderr'):
                    stream=getattr(child,name,None)
                    if stream is not None and not any(stream is old for old in self.original_streams):self.original_streams.append(stream)
                return
            frame=frame.f_back
    def before_spawn(self,args,frame):
        self.observe_constructor(frame)
        self.actual_audit_events.append(dict(executable=args[0],command=list(args[1]),cwd=args[2],environmentWasNone=args[3]is None))
        self.port.spawn(args,frame);self.accepted+=1
        assert self.actual_constructor is self.port.pending and len(self.descriptors)==6
        assert not getattr(self.actual_constructor,'_child_created',False)
    def assert_original_exception_drain(self):
        # Called immediately after the actual constructor raised, BEFORE any
        # rescue cleanup. No closed-descriptor result is invented or cached.
        for row in self.descriptors:
            try:info=os.fstat(row['descriptor'])
            except OSError as error:assert error.errno==9
            else:assert(info.st_dev,info.st_ino)!=(row['device'],row['inode'])
        if self.actual_constructor is not None:
            child=self.actual_constructor
            assert not getattr(child,'_child_created',False)and child.pid is None
            assert children()==self.kernel_children_before
            for name in('stdin','stdout','stderr'):
                stream=getattr(child,name,None)
                if stream is not None:assert stream.closed
    def rescue_close(self):
        # Any earlier drain assertion remains a test failure; cleanup cannot
        # turn rescue into an original successful constructor cleanup proof.
        for stream in self.original_streams:
            if not stream.closed:stream.close()
        for row in self.descriptors:
            try:info=os.fstat(row['descriptor'])
            except OSError:continue
            if(info.st_dev,info.st_ino)==(row['device'],row['inode']):os.close(row['descriptor'])
    def enter(self):
        global _ACTIVE
        install();assert _ACTIVE is None;_ACTIVE=self
    def leave(self):
        global _ACTIVE
        assert _ACTIVE is self;_ACTIVE=None
