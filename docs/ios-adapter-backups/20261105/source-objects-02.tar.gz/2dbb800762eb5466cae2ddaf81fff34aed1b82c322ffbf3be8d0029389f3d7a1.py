"""Private AST/JSON/source inventory only; never import or run tests."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
sha=lambda value:hashlib.sha256(value).hexdigest()
pins=json.loads((HERE/'base-pins.json').read_text());registry={'tests/device/contract-versions.json','tests/device/validate_contract_versions.py'}
paths=sorted(str(p.relative_to(HERE)) for p in (HERE/'tests').rglob('*') if p.is_file());rows=[];patch=[];cases=[];parsed=[]
for name in paths:
    actual=ROOT/name;target=HERE/name;data=target.read_bytes();base=actual.read_bytes() if actual.exists() else b''
    if name in pins:assert sha(base)==pins[name],('Base changed',name)
    if name in registry:base=subprocess.check_output(['git','show','HEAD:'+name],cwd=ROOT)
    rows.append(dict(path=name,privatePath=str(target.relative_to(ROOT)),baseSha256=sha(base) if actual.exists() else None,
        sha256=sha(data),currentWorktreeSha256=sha(actual.read_bytes()) if actual.exists() else None,
        publication='OWN_5_KEYS_HUNKS_ONLY_PRESERVE_FOREIGN_REGISTRY_WIP' if name in registry else 'VERIFY_BASE_SHA_THEN_EXACT_PATH'))
    if name.endswith('.py'):
        tree=ast.parse(data.decode(),filename=name);parsed.append(name)
        if '/self_tests/test_' in name:
            cases.extend(name+'::'+c.name+'::'+n.name for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body
                if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_'))
    if name.endswith('.json'):json.loads(data)
    patch.extend(difflib.unified_diff(base.decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),fromfile='a/'+name if actual.exists() else '/dev/null',tofile='b/'+name))
value=dict(status='PRIVATE_SOURCE_DRAFT_ONLY_UNRUN_REQUIRES_ROOT_REVIEW_AND_GRANT',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    feature='14/14 Lifecycle input',adapterCompletionCount='5/14',publicationPaths=rows,ownRegistryKeys=json.loads((HERE/'own-registry-keys.json').read_text()),
    astParsedOnly=parsed,authoredUnrunCases=cases,hostTestsExecuted=False,authenticatedTransportAvailable=False,
    tunnelInventoryAvailable=False,sdkResourceRetirementAvailable=False,wholeLifecycleRetirementAvailable=False,
    missingProducer='Canonical IOSScriptRuntime._sources has no authenticated RSD plus same-userspace-tunnel media-stack owner handoff or original resource census')
(HERE/'package-plan.json').write_text(json.dumps(value,indent=2)+'\n');(HERE/'full-private-packet.patch').write_text(''.join(patch));(HERE/'publication-paths.txt').write_text('\n'.join(paths)+'\n')
print(json.dumps(dict(privatePaths=len(paths),astParsedOnly=len(parsed),authoredUnrunCases=len(cases),registryOwnKeys=5)))
