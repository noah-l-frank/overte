"""Actual worker/lock/resource-owner source; SDK/RSD/display/HID are DI models."""
from __future__ import annotations
from source_model_bindings import execute_original
import ast,asyncio,hashlib,inspect,json,os,weakref
from contextlib import asynccontextmanager
from pathlib import Path
import tempfile,unittest
from unittest.mock import patch

class OriginalResourceBorrowModels(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        raw=Path(os.environ['LIFECYCLE_RESOURCE_BORROW_MAP']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_RESOURCE_BORROW_MAP_SHA256']:
            raise RuntimeError('Reviewed original source map required before target imports')
        self.mapping=json.loads(raw)
        for row in self.mapping.values():
            if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('Target source changed')
        from ios.adapters import lifecycle_touch_resource_owner as owners
        from ios.self_tests import lifecycle_touch_resources_fixture as fixture
        from adapters.normal_feature_state import PrivateFeatureState
        from adapters.script_feature.lock import ScriptSourceLock
        self.assertEqual(Path(owners.__file__).resolve(),Path(self.mapping['resourceOwner']['path']))
        self.owners=owners;self.fixture=fixture
        self.root=Path(tempfile.mkdtemp(prefix='original-resource-borrow-'));self.root.chmod(0o700)
        self.lock=ScriptSourceLock(self.root/'script-feature-sources.lock');self.good=True
        self.rsd=fixture.RSD();self.receiver=fixture.Receiver();self.display=fixture.Display()
        self.store=PrivateFeatureState(self.root/('ios-lifecycle-touch-lease-'+fixture.RUN+'.json'));self.hid=fixture.HID(self.store)
        self.addCleanup(self.receiver.close);self.lease=None
        with self.lock.held():self.resource=owners.LifecycleTouchResourceOwner(PrivateFeatureState(self.root/('ios-lifecycle-touch-resources-'+fixture.RUN+'.json')),
            fixture.BINDING,fixture.RUN,self.lock,lambda:self.good)
        tree=ast.parse(Path(self.mapping['keeper']['path']).read_bytes())
        nodes=[next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FAILURE_PHASES' for t in n.targets))]
        nodes += [next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name) for name in ('LaunchError','OriginalKeeperSource')]
        ns=dict(asyncio=asyncio,asynccontextmanager=asynccontextmanager,inspect=inspect,weakref=weakref)
        execute_original(ast.Module(body=nodes,type_ignores=[]),ns,self.mapping['keeper']['path'],self.mapping['keeper']['sha256'],'test_resource_borrow_models')
        class Cap:
            def current(cap):return self.rsd,'fd00::1'
            def udp_socket(cap):return self.receiver
        class Tunnel:
            def original_source(tunnel):return self.cap
        self.cap=Cap();self.tunnel=Tunnel();self.source=ns['OriginalKeeperSource'].__new__(ns['OriginalKeeperSource'])
        self.source._tunnel=weakref.ref(self.tunnel);self.source._source=self.cap;self.source._loop=asyncio.get_running_loop()
        self.source._leases=[];self.source._born=[];self.source._closing=False
        actual=owners.touch_session
        def model_session(rsd,address,*,observation,socket_factory):
            self.assertIs(rsd,self.rsd);self.assertIs(socket_factory.__self__,self.cap)
            return actual(rsd,address,observation=observation,socket_factory=socket_factory,
                display_factory=lambda original:self.display,hid_factory=lambda original:self.hid)
        self.session_patch=patch.object(owners,'touch_session',side_effect=model_session);self.session_patch.start();self.addCleanup(self.session_patch.stop)
    def make(self):
        with self.lock.held():
            self.lease=self.source.touch_lease(self.store,binding=self.fixture.BINDING,run=self.fixture.RUN,
                check=lambda:self.good,resource_owner=self.resource)
        return self.lease
    async def asyncTearDown(self):
        self.hid.down_gate.set();self.display.stop_gate.set()
        if self.lease is not None:
            self.lease.request_release.set()
            if self.lease.worker is not None:await asyncio.wait_for(asyncio.shield(self.lease.worker),6)
        self.receiver.close()
    async def test_original_worker_birth_lock_resource_opening_and_actual_passive_edges_join(self):
        lease=self.make();self.assertIsNone(self.lock._owner)
        await lease.begin(100,50,25,10,seconds=3)
        self.lock.assert_held();self.assertIs(self.source._born[0]['worker'],lease.worker)
        self.assertIs(self.resource._retained._worker,lease.worker)
        value=self.resource.capture();self.assertEqual(lease.previous['leaseId'],value['leaseId'])
        self.assertTrue(value['source']['workerAlive']);self.assertFalse(value['source']['workerDone'])
        self.assertIn('hid-entered',[row['edge'] for row in value['source']['events']])
        self.assertFalse(value['source']['authenticatedTransportAvailable']);self.assertFalse(value['worker']['retirementEstablished'])
        self.assertEqual([0xC2],self.hid.reports)
        await self.source.settle_touches();self.assertEqual([0xC2,0x02],self.hid.reports);self.assertIsNone(self.lock._owner)
        with self.lock.held():
            last=self.resource.capture();self.assertTrue(last['source']['workerDone'])
            self.assertTrue(last['worker']['contextExitReturned']);self.assertFalse(last['source']['wholeLifecycleRetirementAvailable'])
    async def test_current_guard_loss_blocks_capture_but_original_up_does_not_reenter_factory(self):
        lease=self.make();await lease.begin(100,50,25,10,seconds=3);self.resource.capture()
        before=self.resource.store.path.read_bytes();worker=lease.worker;self.good=False
        with self.assertRaises(RuntimeError):self.resource.capture()
        await self.source.settle_touches()
        self.assertIs(lease.worker,worker);self.assertEqual([0xC2,0x02],self.hid.reports)
        self.assertEqual(before,self.resource.store.path.read_bytes());self.assertEqual(1,len(self.display.starts));self.assertEqual(self.display.starts,self.display.stops)
    async def test_pending_down_keeps_original_task_and_worker_lock_until_original_up_and_drain(self):
        self.hid.down_gate.clear();lease=self.make();begin=asyncio.create_task(lease.begin(100,50,25,10,seconds=3))
        await self.hid.down_started.wait();original=lease.worker
        settling=asyncio.create_task(self.source.settle_touches());await asyncio.sleep(0)
        self.assertTrue(self.source._closing);self.lock.assert_held();self.assertFalse(original.done());self.assertFalse(settling.done())
        self.assertEqual([0xC2],self.hid.reports);self.hid.down_gate.set()
        await asyncio.gather(begin,settling,return_exceptions=True)
        self.assertTrue(original.done());self.assertFalse(original.cancelled());self.assertEqual([0xC2,0x02],self.hid.reports);self.assertIsNone(self.lock._owner)
    async def test_same_bytes_foreign_resource_original_inode_blocks_archive_without_new_hid(self):
        lease=self.make();await lease.begin(100,50,25,10,seconds=3);self.resource.capture()
        full=self.resource.files.expand(self.resource.state['frames'][-1]);path=self.resource.files.path(full);raw=path.read_bytes()
        path.rename(self.root/'retained-old-resource-frame');path.write_bytes(raw);path.chmod(0o600)
        from adapters.normal_feature_state import PrivateFeatureState
        with self.lock.held(),self.assertRaises(RuntimeError):
            self.owners.LifecycleTouchResourceOwner(PrivateFeatureState(self.resource.store.path),self.fixture.BINDING,self.fixture.RUN,self.lock,lambda:True)
        self.assertEqual([0xC2],self.hid.reports);await self.source.settle_touches();self.assertEqual([0xC2,0x02],self.hid.reports)
