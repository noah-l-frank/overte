"""Actual prospective Avatar10 frontdoor and unchanged common fifteen steps.

No capability/factory/outcome/verifier is patched. Native producers are models;
this cannot qualify a device, installed binary, or separate Actor OS process.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import json
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from feature_journeys.scenarios import SCENARIOS
from ios.adapters import feature_configuration
from ios.self_tests.avatar_canonical_frontdoor_fixture import AvatarCanonicalFrontdoor
from ios.self_tests.avatar_installed_full15_fixture import AvatarInstalledFull15
from ios.self_tests import test_ios_avatar_prepare_composed as preparation


class AvatarInstalledFull15Tests(unittest.TestCase):
    retain_originals=True
    @classmethod
    def setUpClass(cls):preparation.AvatarPrepareComposedTests.setUpClass()
    @classmethod
    def tearDownClass(cls):preparation.AvatarPrepareComposedTests.tearDownClass()

    def test_version10_explicit_avatar_only_keeps_legacy_versions_closed_before_native_or_control(self):
        f=AvatarCanonicalFrontdoor(self);before=f.snapshot_effects()
        for version in range(1,5):
            value=f.configuration(version);value['areas']=['scripts'];f.set_configuration(value)
            self.assertEqual(value,feature_configuration.configuration())
            self.assertEqual({'feature.scripts.'+kind for kind in ('act','observe','cleanup')},
                set(feature_configuration.capabilities(f.domain.natives['primary'].target)))
            self.assertEqual(before,f.snapshot_effects())
        for version in range(5,9):
            value=f.configuration(version);f.set_configuration(value)
            self.assertEqual(value,feature_configuration.configuration())
            with self.assertRaises(NativeUIError):feature_configuration.capabilities(f.domain.natives['primary'].target)
            self.assertEqual(before,f.snapshot_effects())
        # Version9 has no published configuration contract and stays refused.
        f.set_configuration(f.configuration(9))
        with self.assertRaises(NativeUIError):feature_configuration.configuration()
        self.assertEqual(before,f.snapshot_effects())
        value=f.configuration(10);value.update(avatarCoordinatorVersion=1)
        value['avatarPeople']['authorityControlRoot']=str(f.root)
        f.set_configuration(value)
        self.assertEqual({'feature.avatar-people.'+kind for kind in ('act','observe','cleanup','terminal')},set(feature_configuration.capabilities(f.domain.natives['primary'].target)))
        for kind in ('missing-profile','wrong-coordinator','foreign-area','bool-coordinator','foreign-emote-coordinator','foreign-emote-targets'):
            bad=deepcopy(value)
            if kind=='missing-profile':del bad['avatarPeople']['authorityControlRoot']
            elif kind=='wrong-coordinator':bad['avatarCoordinatorVersion']=2
            elif kind=='bool-coordinator':bad['avatarCoordinatorVersion']=True
            elif kind=='foreign-emote-coordinator':bad['emoteCoordinatorVersion']=2
            elif kind=='foreign-emote-targets':bad['emoteTargets']={}
            else:bad['areas'].append('emotes')
            f.set_configuration(bad)
            with self.subTest(kind=kind),self.assertRaises(NativeUIError):feature_configuration.configuration()
            self.assertEqual(before,f.snapshot_effects())

    def test_actual_InstalledAdapter_all15_shared_images_Actor_publications_and_canonical_paired_end(self):
        f=AvatarInstalledFull15(self);original=deepcopy(f.configuration)
        phases=f.journey.execute();f.worker.finish()
        self.assertEqual(15,len(SCENARIOS['avatar-people']['steps']));self.assertEqual(17,len(phases))
        self.assertEqual('owned-clean-baseline',phases[0]['phase']);self.assertEqual('cleanup-restored-baseline',phases[-1]['phase'])
        self.assertEqual(1,len(f.reports));report=f.reports[0]
        self.assertTrue(report['sequenceCompleted']);self.assertTrue(report['cleanupSucceeded']);self.assertFalse(report['deviceAcceptance'])
        self.assertTrue(all(row['witness'] is not None for row in report['samples']))
        self.assertIsNotNone(report['terminalRetirement']['end'])
        actions=[value['verb'] for operation,value in f.calls if operation=='feature.avatar-people.act']
        self.assertEqual([step['verb'] for step in SCENARIOS['avatar-people']['steps']],actions)
        self.assertEqual(2,sum(operation=='feature.avatar-people.cleanup' for operation,value in f.calls))
        first=next(index for index,(operation,value) in enumerate(f.calls) if operation=='feature.avatar-people.terminal' and value['stage']=='inspect')
        self.assertEqual(2,sum(operation=='feature.avatar-people.cleanup' for operation,value in f.calls[:first]))
        self.assertEqual(['inspect','seal','finish'],[value['stage'] for operation,value in f.calls if operation=='feature.avatar-people.terminal'])
        self.assertEqual(original,PrivateFeatureState(f.frontdoor.config_store.path).read())
        self.assertEqual(0,f.worker.result);self.assertFalse(f.worker.thread.is_alive())
        events=json.loads((f.root/'actual-avatar-actor-events.json').read_text())
        self.assertEqual(dict(event='actual-original-worker-return',returnCode=0,uncaughtType=None),events[-1])
        for role in ('primary','actor'):
            self.assertFalse(f.domain.natives[role].running);self.assertFalse(f.domain.sdk_exists[role])
            self.assertEqual(1,f.domain.natives[role].lifecycle_inputs.count('app.stop'))
            self.assertEqual(1,f.domain.sdk_requests.count((role,'DELETE')))
            self.assertIsNone(f.adapter.read_session(role));self.assertIsNone(f.adapter._binding_store(role).read())
        before=f.metadata_effects()
        for selector,adapter in (('actor',f.actor_adapter),('primary',f.adapter),('actor',f.actor_adapter),('primary',f.adapter)):
            self.assertEqual(dict(cleaned=True),adapter.cleanup(selector))
            self.assertEqual(before,f.metadata_effects())


if __name__=='__main__':unittest.main()
