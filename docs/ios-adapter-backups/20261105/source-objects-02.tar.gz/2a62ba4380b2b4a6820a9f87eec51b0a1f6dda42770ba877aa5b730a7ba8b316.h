// Copyright 2026 Overte contributors.
// SPDX-License-Identifier: Apache-2.0
#pragma once

// Default-off E2E ownership of ONE actual native writer output. No arbitrary
// pathname, expected bytes, marker namespace, OS death or SDK absence API.
#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(Q_OS_IOS)
#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMutex>
#include <QMutexLocker>
#include <QRegularExpression>
#include <QUuid>
#include <QVariantMap>
#include <cerrno>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace overte::e2e {
class IOSEmotePaletteFileOwnership {
public:
    static IOSEmotePaletteFileOwnership& instance() { static IOSEmotePaletteFileOwnership owner; return owner; }
    static bool enabled() {
        const auto args=QCoreApplication::arguments();
        return QCoreApplication::instance() && args.contains("--testScript") && args.contains("--emote-palette-observe")
            && args.contains("--e2e-emote-palette-file-ownership");
    }
    ~IOSEmotePaletteFileOwnership() {
        // Process teardown closes only our descriptors; it does not delete an
        // unproved/unknown native file or manufacture a retirement original.
        if (_pending>=0) {::close(_pending);} if (_file>=0) {::close(_file);} if (_parent>=0) {::close(_parent);}
    }
    bool paletteReadAllowed() {
        QMutexLocker locker(&_mutex);return enabled() && !_unknown && !_issued && _pending<0;
    }
    void produced(const QVariantMap& actual) {
        QMutexLocker locker(&_mutex);
        if (!enabled()) {return;}
        if (_unknown || _issued || _pending>=0 || actual.isEmpty()) {_unknown=true;return;}
        // Called ONLY at the genuine native2 producer return. Test.saveObject
        // cannot create ownership by supplying requested/fabricated JSON.
        _produced=actual;
    }
    bool begin(const QString& directory,int writer,const QByteArray& raw,const QVariantMap& palette) {
        QMutexLocker locker(&_mutex);
        if (!enabled() || _unknown || _issued || _pending>=0 || QJsonObject::fromVariantMap(palette)!=QJsonObject::fromVariantMap(_produced) || writer<0 || raw!=QJsonDocument::fromVariant(palette).toJson() || raw.isEmpty() || raw.size()>250000 || _attempt>=1000000000) {return false;}
        const auto run=palette.value("runId").toString(),request=palette.value("requestId").toString();
        if (palette.value("iosEmotePaletteVersion").toInt()!=2 || palette.value("processId").toLongLong()!=::getpid()
                || !hex(run) || !QRegularExpression("\\Aios-[0-9a-f]{32}\\z").match(request).hasMatch()) {return false;}
        const auto root=QDir::cleanPath(QDir(directory).absolutePath());const QFileInfo info(root);
        if (info.canonicalFilePath()!=root) {return false;}
        const int opened=::open(QFile::encodeName(root).constData(),O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
        struct stat parent,temp;
        if (opened<0 || ::fstat(opened,&parent) || !privateDirectory(parent) || !sameRoot(opened,root)
                || ::fstat(writer,&temp) || !S_ISREG(temp.st_mode) || temp.st_uid!=::geteuid()
                || (temp.st_mode&0777)!=0600 || temp.st_size!=raw.size() || temp.st_nlink>1) {
            if (opened>=0) {::close(opened);} return false;
        }
        if (_parent>=0 && (_root!=root || !sameIdentity(parent,_parentIdentity) || !current())) {_unknown=true;::close(opened);return false;}
        if (_parent<0) {
            struct stat foreign;
            if (!::fstatat(opened,filename(),&foreign,AT_SYMLINK_NOFOLLOW) || errno!=ENOENT) {
                // An older/foreign native output is not this lifetime's file.
                // The new opt-in cannot overwrite it into claimed ownership.
                _unknown=true;::close(opened);return false;
            }
            _parent=opened;_root=root;_parentIdentity=parent;
        } else {::close(opened);}
        // A genuine duplicate of the real QSaveFile FD, before commit can
        // close it. A later failed/uncertain commit retains this duty.
        _pending=::fcntl(writer,F_DUPFD_CLOEXEC,0);
        if (_pending<0) {return false;}
        ++_attempt;_pendingRaw=raw;_pendingPalette=palette;_pendingIdentity=temp;
        return true;
    }
    void committed(bool returned) {
        QMutexLocker locker(&_mutex);
        if (_pending<0) {_unknown=true;return;}
        if (!returned || !sameRoot(_parent,_root)) {_unknown=true;return;}
        struct stat written,path;
        if (::fstat(_pending,&written) || !privateFile(written) || !sameIdentity(written,_pendingIdentity)
                || written.st_size!=_pendingRaw.size() || ::fstatat(_parent,filename(),&path,AT_SYMLINK_NOFOLLOW)
                || !sameStat(written,path)) {_unknown=true;return;}
        const int readable=::openat(_parent,filename(),O_RDONLY|O_NOFOLLOW|O_CLOEXEC|O_NONBLOCK);
        struct stat opened;
        if (readable<0 || ::fstat(readable,&opened) || !sameStat(opened,written) || !bytes(readable,written,_pendingRaw)) {
            if (readable>=0) {::close(readable);} _unknown=true;return;
        }
        if (_file>=0) {::close(_file);}
        _file=readable;_published=written;_raw=_pendingRaw;_palette=_pendingPalette;_generation=_attempt;
        ::close(_pending);_pending=-1;_pendingRaw.clear();_pendingPalette.clear();
    }
    QVariantMap observe(const QString& run) {
        QMutexLocker locker(&_mutex);
        if (!enabled() || !hex(run)) {return {};}
        if ((_file>=0 && run!=_palette.value("runId").toString()) || (_pending>=0 && run!=_pendingPalette.value("runId").toString())) {return {};}
        if (!_unknown && _file>=0 && !(_retired ? retiredCurrent() : current())) {_unknown=true;}
        return original();
    }
    QVariantMap retire(const QString& run,const QString& instance,quint64 generation,const QString& paletteRequest) {
        QMutexLocker locker(&_mutex);
        if (!enabled() || _unknown || _issued || _pending>=0 || _file<0 || run!=_palette.value("runId").toString()
                || instance!=_instance || generation!=_generation || paletteRequest!=_palette.value("requestId").toString()) {return {};}
        // This is a once-only real fixed-file mutation. The external host must
        // durably journal its own intent before invoking this native method.
        // There is no automatic retry, seal/Stop permission, or SDK assertion.
        _issued=true;
        if (!current()) {_unknown=true;return original();}
        if (::unlinkat(_parent,filename(),0) || ::fsync(_parent)) {_unknown=true;return original();}
        _retired=true;
        if (!retiredCurrent()) {_unknown=true;}
        return original();
    }
private:
    IOSEmotePaletteFileOwnership():_instance(QUuid::createUuid().toString(QUuid::Id128)) {}
    static const char* filename() {return "feature-ios-emote-palette.json";}
    static bool hex(const QString& s) {return QRegularExpression("\\A[0-9a-f]{32}\\z").match(s).hasMatch();}
    static bool privateDirectory(const struct stat& s) {return S_ISDIR(s.st_mode) && s.st_uid==::geteuid() && (s.st_mode&0777)==0700;}
    static bool privateFile(const struct stat& s) {return S_ISREG(s.st_mode) && s.st_uid==::geteuid() && (s.st_mode&0777)==0600 && s.st_nlink==1;}
    static bool sameIdentity(const struct stat& a,const struct stat& b) {return a.st_dev==b.st_dev && a.st_ino==b.st_ino && a.st_uid==b.st_uid && a.st_gid==b.st_gid && a.st_mode==b.st_mode;}
    static bool sameStat(const struct stat& a,const struct stat& b) {
        return sameIdentity(a,b) && a.st_size==b.st_size && a.st_nlink==b.st_nlink
            && a.st_mtimespec.tv_sec==b.st_mtimespec.tv_sec && a.st_mtimespec.tv_nsec==b.st_mtimespec.tv_nsec
            && a.st_ctimespec.tv_sec==b.st_ctimespec.tv_sec && a.st_ctimespec.tv_nsec==b.st_ctimespec.tv_nsec;
    }
    static bool sameRoot(int fd,const QString& root) {
        struct stat opened,path;
        return fd>=0 && !::fstat(fd,&opened) && privateDirectory(opened)
            && !::lstat(QFile::encodeName(root).constData(),&path) && sameIdentity(opened,path)
            && QFileInfo(root).canonicalFilePath()==root;
    }
    static bool bytes(int fd,const struct stat& expected,const QByteArray& raw) {
        struct stat before,after;
        if (::fstat(fd,&before) || !sameStat(before,expected)) {return false;}
        QByteArray actual(raw.size()+1,'\0');qint64 used=0;
        while (used<actual.size()) {
            const auto count=::pread(fd,actual.data()+used,static_cast<size_t>(actual.size()-used),used);
            if (count<0 && errno==EINTR) {continue;}
            if (count<0) {return false;} if (!count) {break;} used+=count;
        }
        actual.resize(used);
        return actual==raw && !::fstat(fd,&after) && sameStat(before,after);
    }
    bool current() const {
        struct stat actual,path,parent;
        return _file>=0 && !::fstat(_parent,&parent) && sameIdentity(parent,_parentIdentity) && sameRoot(_parent,_root) && !::fstat(_file,&actual) && privateFile(actual)
            && sameStat(actual,_published) && !::fstatat(_parent,filename(),&path,AT_SYMLINK_NOFOLLOW)
            && sameStat(actual,path) && bytes(_file,actual,_raw);
    }
    bool retiredCurrent() {
        struct stat actual,path,parent;
        if (_file<0 || ::fstat(_parent,&parent) || !sameIdentity(parent,_parentIdentity) || !sameRoot(_parent,_root) || ::fstat(_file,&actual) || !sameIdentity(actual,_published)
                || actual.st_size!=_published.st_size || actual.st_nlink!=0 || !bytes(_file,actual,_raw)) {return false;}
        if (!::fstatat(_parent,filename(),&path,AT_SYMLINK_NOFOLLOW) || errno!=ENOENT) {return false;}
        _after=actual;return true;
    }
    static QVariantMap metadata(const struct stat& s) {
        return {{"device",QString::number(s.st_dev)},{"inode",QString::number(s.st_ino)},{"mode",QString::number(s.st_mode)},
            {"uid",QString::number(s.st_uid)},{"gid",QString::number(s.st_gid)},{"nlink",QString::number(s.st_nlink)},
            {"bytes",QString::number(s.st_size)},
            {"mtimeNs",QString::number(static_cast<qint64>(s.st_mtimespec.tv_sec)*1000000000+s.st_mtimespec.tv_nsec)},
            {"ctimeNs",QString::number(static_cast<qint64>(s.st_ctimespec.tv_sec)*1000000000+s.st_ctimespec.tv_nsec)}};
    }
    QVariantMap original() const {
        QVariantMap file;
        if (_file>=0) {file={{"name",QString::fromLatin1(filename())},{"metadata",metadata(_published)},
            {"sha256",QString::fromLatin1(QCryptographicHash::hash(_raw,QCryptographicHash::Sha256).toHex())},
            {"bytes",_raw.size()},{"palette",_palette}};}
        return {{"iosEmotePaletteFileOwnedOriginalVersion",1},{"instance",_instance},
            {"processId",static_cast<double>(::getpid())},{"generation",static_cast<double>(_generation)},
            {"phase",_unknown?"unknown":_retired?"retired":_file>=0?"owned":"unobserved"},
            {"retirementIssued",_issued},{"pendingPublication",_pending>=0},{"file",file},
            {"afterRetirement",_retired?metadata(_after):QVariantMap()},
            {"processDeathProved",false},{"sdkAbsentProved",false}};
    }
    QMutex _mutex;QString _instance,_root;int _parent{-1},_file{-1},_pending{-1};
    struct stat _parentIdentity{},_published{},_pendingIdentity{},_after{};
    quint64 _attempt{0},_generation{0};bool _unknown{false},_issued{false},_retired{false};
    QByteArray _raw,_pendingRaw;QVariantMap _palette,_pendingPalette,_produced;
};
} // namespace overte::e2e
#endif
