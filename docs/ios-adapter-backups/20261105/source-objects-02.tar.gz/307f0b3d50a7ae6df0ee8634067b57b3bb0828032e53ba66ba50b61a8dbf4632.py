"""Actual original selected IPA→fresh bundle/window/native Motion reference join.

Native/RSD/WDA/creator/HTTP producers modeled; no native motion/SDK qualification.
All source dispatch/task/byte codecs/WAL/frame/receipt/Resource paths are actual.
"""
import asyncio,json,os,weakref
from copy import deepcopy
from pathlib import Path
import motion_reference_fixture as motion_fixture


class MotionSelectedJoinModels(motion_fixture.MotionOwnedReferenceModels):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        from ios.self_tests import test_ios_bundle_identity as archive_fixture
        from ios.self_tests.test_ios_bundle_observation import Boundary
        from ios.self_tests.retained_host_roots import retain_owned_root
        self.archive=archive_fixture.BundleIdentityTests();self.archive.setUp();retain_owned_root(self.archive.temp,expected_root=Path(self.archive.temp.name))
        for callback,args,kwargs in self.archive._cleanups:
            if getattr(callback,'__self__',None) is self.archive.temp:callback=self.archive.temp.cleanup
            self.addCleanup(callback,*args,**kwargs)
        self.archive._cleanups.clear();digest=self.archive.archive();self.measured_bundle=self.archive.actual_directory_manifest();self.binding['artifactSha256']=digest
        # Select fresh MODEL native clock before the first command/capture of
        # this new synthetic CF-bundle producer, not by editing retained bytes.
        self.bundle_source=Boundary();self.bundle_source.bundle=deepcopy(self.measured_bundle)
        self.bundle_source.mutate=lambda value:value.update(capturedEpochMs=self.modeled_epoch())
    async def select_original(self):
        args=dict(self.acquire_args(),action='ios-bundle-observe',nativeBundleProfileVersion=2,selectedArtifact=dict(root=str(self.archive.path.parent),relative=self.archive.path.name))
        request,task=self.request('touch-native-query',args);await task;packet=self.ops.issued[request]['original'];self.assertEqual('complete',packet['status'])
        self.selection=packet['result']['query']['commandId'];self.selected=self.ops.native_query_journals[self.run]['selectedOriginals'][self.selection]
        self.assertTrue(task.done());self.assertIs(task,self.selected[3]['capture']());return packet['result']
    async def capture_selected(self,selected=None):
        args=dict(self.acquire_args(),selectedQueryId=self.selection if selected is None else selected)
        request,task=self.request('touch-native-motion-acquire',args);await task;return self.ops.issued[request]['original'],task

    async def test_actual_selected_ipa_source_and_five_new_originals_bind_resource4_without_input_or_candidate_boolean(self):
        await self.select_original();packet,task=await self.capture_selected();self.assertEqual('complete',packet['status']);value=packet['result'];self.assertEqual(3,value['originalKeeperNativeAcquisitionVersion'])
        ref=json.loads(value['acquisitionJson'])['reference'];body=json.loads(self.frame_path(ref).read_bytes());frame=body['frame'];self.assertEqual(3,frame['originalKeeperNativeAcquisitionFrameVersion'])
        self.assertEqual(5,len(frame['reads']));candidate=frame['selectedCandidate'];self.assertEqual(self.selection,candidate['selectionQueryId']);self.assertEqual(self.measured_bundle,candidate['selectedArtifactBundle'])
        bundle=json.loads(candidate['bundleRead']['original']['rawJson']);self.assertNotEqual(bundle['instance'],frame['clockJoin']['nativeBefore']['instance'])
        self.assertLessEqual(frame['clockJoin']['nativeBefore']['capturedEpochMs'],bundle['capturedEpochMs']);self.assertLessEqual(bundle['capturedEpochMs'],frame['clockJoin']['nativeAfter']['capturedEpochMs'])
        result=await self.prepared(value);self.assertEqual(3,result['originalKeeperMotionPreparationVersion']);resource=self.ops.touch_resources;self.assertEqual(4,resource.version)
        self.assertIs(resource,self.selected[3]['motionTarget']());self.assertIs(self.journal()['motionOriginals'][ref['sha256']]._selected,self.selected)
        self.assertEqual(self.selection,resource.state['selectedQueryId']);self.assertEqual([],self.f.states());self.assertTrue(task.done());self.assertFalse(self.creator.done())

    async def test_missing_live_selected_source_object_cannot_be_replaced_by_a_correctly_shaped_query_selector(self):
        packet,_=await self.capture_selected('ios-'+'f'*32);self.assertEqual('failed',packet['status']);self.assertEqual([],self.commands)
        self.assertEqual([],self.journal()['previous']['frames']);self.assertEqual([],self.f.states());self.assertIsNone(self.ops.touch_resources)

    async def test_plain_bundle_profile_query_never_mints_selected_ipa_motion_authority(self):
        args=dict(self.acquire_args(),action='ios-bundle-observe',nativeBundleProfileVersion=1);request,task=self.request('touch-native-query',args);await task;query=self.ops.issued[request]['original']['result']['query']
        packet,_=await self.capture_selected(query['commandId']);self.assertEqual('failed',packet['status']);self.assertEqual(1,len(self.commands));self.assertEqual([],self.journal()['previous']['frames']);self.assertEqual([],self.f.states())

    async def test_valid_foreign_bundle_bytes_inside_new_native_cut_revoke_original_and_cannot_restore_to_success(self):
        await self.select_original();original=deepcopy(self.bundle_source.bundle);self.bundle_source.bundle['executableSha256']='f'*64
        packet,_=await self.capture_selected();self.assertEqual('failed',packet['status']);self.assertEqual([],self.journal()['previous']['frames']);self.assertTrue(self.selected[3]['revoked'])
        self.bundle_source.bundle=original;before=len(self.commands);packet,_=await self.capture_selected();self.assertEqual('failed',packet['status']);self.assertEqual(before,len(self.commands));self.assertEqual([],self.f.states())

    async def test_actual_old_native_bundle_timestamp_inside_fresh_native_before_after_cut_refuses_without_retiming(self):
        await self.select_original();self.bundle_source.mutate=lambda value:value.update(capturedEpochMs=19999);await asyncio.sleep(.02)
        packet,_=await self.capture_selected();self.assertEqual('failed',packet['status']);self.assertTrue(self.selected[3]['revoked']);self.assertEqual([],self.journal()['previous']['frames']);self.assertEqual([],self.f.states())
        self.assertEqual(19999,self.bundle_source.value['capturedEpochMs'])

    async def test_observed_original_creator_reference_change_before_motion_cut_is_permanently_revoked(self):
        await self.select_original();reference=self.source._creator_task;self.source._creator_task=weakref.ref(asyncio.current_task())
        packet,_=await self.capture_selected();self.assertEqual('failed',packet['status']);self.source._creator_task=reference
        packet,_=await self.capture_selected();self.assertEqual('failed',packet['status']);self.assertEqual(1,len(self.commands));self.assertTrue(self.selected[3]['revoked']);self.assertEqual([],self.f.states())

    async def test_same_byte_original_frame_inode_swap_refuses_preparation_and_revokes_exact_selected_source(self):
        await self.select_original();packet,_=await self.capture_selected();self.assertEqual('complete',packet['status']);value=packet['result'];ref=json.loads(value['acquisitionJson'])['reference'];path=self.frame_path(ref)
        replacement=path.with_name('foreign-same-bytes');replacement.write_bytes(path.read_bytes());replacement.chmod(0o600);os.replace(replacement,path)
        with self.assertRaises((RuntimeError,ValueError)):await self.prepared(value)
        self.assertTrue(self.selected[3]['revoked']);self.assertEqual([],self.f.states());self.assertFalse(self.resource_path().exists())

    async def test_selected_native_preparation_does_not_release_make_lease_without_actual_current_movement_guard(self):
        from adapters.normal_feature_state import PrivateFeatureState
        await self.select_original();packet,_=await self.capture_selected();self.assertEqual('complete',packet['status']);await self.prepared(packet['result']);resource=self.ops.touch_resources
        store=PrivateFeatureState(self.resource_path().with_name('ios-lifecycle-touch-lease-'+self.run+'.json'))
        with self.assertRaises((RuntimeError,ValueError)):
            self.source.touch_lease(store,binding=self.binding,run=self.run,check=lambda:self.ops.fresh_touch_scope(self.binding),resource_owner=resource)
        self.assertIsNone(store.read());self.assertEqual([],self.f.states());self.assertEqual([],self.source._leases);self.assertEqual([],self.source._born)
