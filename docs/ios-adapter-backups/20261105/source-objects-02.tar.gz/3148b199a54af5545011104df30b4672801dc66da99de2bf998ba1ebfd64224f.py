#!/usr/bin/env python3
"""Root-only exact source models; no SDK import, native or admission claim."""
from __future__ import annotations
import hashlib,json,os,sys,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
from unittest.mock import patch
from importlib.machinery import PathFinder
from root_stage_guard import pinned,baseline,terminal
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent

def main():
    stage_raw=pinned(HERE/'source-manifest.json',os.environ['LIFECYCLE_STAGE_MANIFEST_SHA256']);stage=json.loads(stage_raw)
    plan_raw=pinned(HERE/'run-plan.json',os.environ['LIFECYCLE_STAGE_PLAN_SHA256']);plan=json.loads(plan_raw)
    map_path=Path(os.environ['LIFECYCLE_STAGE_ROOT_MAP']);map_raw=pinned(map_path,os.environ['LIFECYCLE_STAGE_ROOT_MAP_SHA256']);mapping=json.loads(map_raw)
    if set(mapping)!={'repositoryRoot','currentSourcePins','reviewedCandidates'}:raise RuntimeError('Root source map schema')
    repo=Path(mapping['repositoryRoot']);expected={row['path']:row['candidateSHA256'] for row in stage['sourcePaths']}
    if str(repo)!=stage['repositoryRoot'] or not repo.is_absolute() or repo.resolve()!=repo or not (repo/'.git').exists() or mapping['reviewedCandidates']!=expected:raise RuntimeError('Actual Root/source candidates required')
    required=set(plan['requiredPublicDependencies'])|set(expected)|{'tests/device/contract-versions.json','tests/device/validate_contract_versions.py'}
    if not required<=set(mapping['currentSourcePins']):raise RuntimeError('Actual broad source census incomplete')
    guards=[]
    for relative,digest in mapping['currentSourcePins'].items():
        rel=Path(relative)
        if rel.is_absolute() or '..' in rel.parts:raise RuntimeError('Root source escape')
        guards.append((repo/rel,digest))
    guards.extend((repo/rel,digest) for rel,digest in expected.items())
    guards.extend((Path(row['candidate']),row['candidateSHA256']) for row in stage['sourcePaths'])
    guards.extend((HERE/name,digest) for name,digest in plan['privateFiles'].items())
    for path,digest in guards:pinned(path,digest)
    before={str(path):path.stat() for path,_ in guards}
    registry=json.loads((repo/'tests/device/contract-versions.json').read_text())['contracts']
    for name,value in plan['registryRequirements'].items():
        if registry.get(name)!=value:raise RuntimeError('Own protocol registry prerequisite unavailable')
    initial=baseline() # BEFORE any target module import.
    fd=os.open(HERE/'baseline-fds-first.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as stream:json.dump(dict(fds=initial['fds'],children=initial['children'],baselineThreadCount=len(initial['threads'])),stream,indent=2);stream.write('\n')
    roots=[str(repo/rel) for rel in ('tests/device','tests/device/self_tests','tests/device/ios/self_tests')]
    remainder=[]
    for entry in sys.path:
        path=Path(entry or os.getcwd()).resolve()
        if path==repo or repo in path.parents:continue
        if str(path) not in remainder:remainder.append(str(path))
    sys.path[:]=roots+[str(HERE)]+remainder
    namespaces={'adapters':('tests/device/adapters',sys.path),'ios':('tests/device/ios',sys.path),'self_tests':('tests/device/self_tests',sys.path),
        'ios.adapters':('tests/device/ios/adapters',[str(repo/'tests/device/ios')]),'ios.self_tests':('tests/device/ios/self_tests',[str(repo/'tests/device/ios')])}
    for name,(relative,parents) in namespaces.items():
        spec=PathFinder._get_spec(name,list(parents))
        if spec is None or [str(Path(p).resolve()) for p in spec.submodule_search_locations or ()]!=[str(repo/relative)]:raise RuntimeError('Canonical namespace mismatch before target import')
    retained=HERE/'retained-first';retained.mkdir(mode=0o700,exist_ok=False)
    bindings=HERE/'source-code-bindings-first';bindings.mkdir(mode=0o700,exist_ok=False);os.environ['LIFECYCLE_CODE_BINDINGS_ROOT']=str(bindings)
    owned=[];objects=[];real_td=tempfile.TemporaryDirectory;real_mkdtemp=tempfile.mkdtemp
    def record(root,kind):
        root=Path(root);info=root.stat()
        if root.parent!=retained or not root.is_dir() or info.st_uid!=os.geteuid() or info.st_mode&0o077:raise RuntimeError('Real private retained root unavailable')
        owned.append(str(root));(HERE/'created-original-roots.json').write_text(json.dumps([dict(path=p,kind='genuine-owned-temp-root') for p in owned])+'\n');return root
    def mkdtemp(suffix=None,prefix=None,dir=None):
        if dir is not None and Path(dir)!=retained:raise RuntimeError('Foreign temp root')
        return str(record(real_mkdtemp(suffix=suffix,prefix=prefix,dir=retained),'mkdtemp'))
    def temporary(suffix=None,prefix=None,dir=None,*,ignore_cleanup_errors=False,delete=True):
        if dir is not None and Path(dir)!=retained:raise RuntimeError('Foreign temp root')
        actual=real_td(suffix=suffix,prefix=prefix,dir=retained,ignore_cleanup_errors=ignore_cleanup_errors,delete=delete)
        from ios.self_tests.retained_host_roots import retain_owned_root
        root=record(actual.name,'TemporaryDirectory');retain_owned_root(actual,expected_root=root);objects.append(actual);return actual
    models={}
    for name,roles in plan['modelMaps'].items():
        value={role:dict(path=str(repo/relative),sha256=expected.get(relative,mapping['currentSourcePins'][relative])) for role,relative in roles.items()}
        path=HERE/(name+'-actual-root-map.json');raw=(json.dumps(value,indent=2)+'\n').encode();path.write_bytes(raw)
        os.environ[name]=str(path);os.environ[name+'_SHA256']=hashlib.sha256(raw).hexdigest();models[str(path)]=hashlib.sha256(raw).hexdigest()
    try:
        from ios.self_tests.retained_host_roots import retain_owned_root
        loader=unittest.TestLoader();suite=unittest.TestSuite()
        for case in plan['cases']:suite.addTests(loader.loadTestsFromName(case))
        if suite.countTestCases()!=plan['caseCount']:raise RuntimeError('Exact unique selection changed')
        with ExitStack() as stack:
            for name in plan['mkdtempAliases']:stack.enter_context(patch.object(sys.modules[name],'tempfile',SimpleNamespace(mkdtemp=mkdtemp)))
            if plan['retainInstalledFixture']:
                from ios.self_tests import test_ios_touch_lease as touch_fixture
                stack.enter_context(patch.object(touch_fixture,'tempfile',SimpleNamespace(TemporaryDirectory=temporary)))
            result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
        return 0 if result.wasSuccessful() else 1
    finally:
        pinned(map_path,hashlib.sha256(map_raw).hexdigest());pinned(HERE/'source-manifest.json',hashlib.sha256(stage_raw).hexdigest());pinned(HERE/'run-plan.json',hashlib.sha256(plan_raw).hexdigest())
        for path,digest in guards:
            pinned(path,digest);old=before[str(path)];new=path.stat()
            if any(getattr(old,key)!=getattr(new,key) for key in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')):raise RuntimeError('Actual source/launcher stat changed')
        for path,digest in models.items():pinned(path,digest)
        terminal(HERE,initial,owned)
        print('Host source models only; SDK/auth/native/whole gates remain false.',flush=True)
if __name__=='__main__':raise SystemExit(main())
