from pathlib import Path
import ast,hashlib,json
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');H=R/'.ios-host-tmp/world-web-witness-decode-root22-and-world4-preparation-20261028';O=R/'.ios-host-tmp/world-web-public-full19-real-actor-root-preparation-20261028';A=R/'.ios-host-tmp/audio-pcm-input-origin-profile-root-preparation2-20261028';S=R/'.ios-host-tmp/world-web-witness-pure-decode-round-proposal-20261028'
F=R/'.ios-host-tmp/world-web-pure-witness-changed-source-full19-root-preparation-20261028';F.mkdir(mode=0o700,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
# Actual newer, fully read supervisor: both sides of both original censuses.
supervisor=(A/'root-supervise.py').read_text().replace("('components25','strict1','legacy1')","('generic22','world4')").replace("HERE/(kind+'-publication-ready-source-map.json')","HERE/'publication-ready-source-map.json'").replace('OVERTE_AUDIO_PCM_PROFILE_RUN_ROOT','OVERTE_WORLD6_WITNESS_DECODE_RUN_ROOT').replace('wholeAudioQualified=False,physicalADCQualified=False,acousticQualified=False,peerQualified=False,physicalTimingQualified=False','wholeWorldWebQualified=False,publicAreaAcceptanceChanged=False')
(H/'root-supervise.py').write_text(supervisor)
runner=(H/'run-selected.py').read_text()
a=runner.index('    def census():');b=runner.index('    first=census()',a)
runner=runner[:b]+'''    remaining_before=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
''' +runner[b:]
runner=runner.replace('originalCensusesEqual=True,remainingNewThreads=remaining','originalCensusesEqual=True,remainingNewThreadsBeforeCensuses=remaining_before,remainingNewThreads=remaining')
runner=runner.replace("assert not remaining,'New fixture/worker/listener thread remains live'","assert not remaining_before and not remaining,'New fixture/worker/listener thread remains live around censuses'")
(H/'run-selected.py').write_text(runner)
# Full19 shares only new reviewed metadata mechanics, never a historical actual source map.
for n in ['run_metadata.py','refresh-after-publication.py']:(F/n).write_text((H/n).read_text())
(F/'root-supervise.py').write_text(supervisor.replace("('generic22','world4')","('full19',)").replace('OVERTE_WORLD6_WITNESS_DECODE_RUN_ROOT','OVERTE_WORLD6_CHANGED_WITNESS_FULL19_RUN_ROOT'))
full=runner.replace("('generic22','world4')","('full19',)").replace('OVERTE_WORLD6_WITNESS_DECODE_RUN_ROOT','OVERTE_WORLD6_CHANGED_WITNESS_FULL19_RUN_ROOT')
a=full.index("if kind=='generic22':");b=full.index('from ios.self_tests.retained_host_roots',a)
full=full[:a]+'''from ios.self_tests import test_ios_emote_marker_scope as scope_fixture
from ios.self_tests import world_web_actor_fixture as actor_fixture
from ios.self_tests import world_web_public_vertical_fixture as vertical_fixture
from ios.self_tests import test_ios_installed_adapter as installed_fixture
fixture_modules=[scope_fixture,actor_fixture,vertical_fixture,installed_fixture]
''' +full[b:]
(F/'run-selected.py').write_text(full)
oldplan=json.loads((O/'suite-plan.json').read_text());plan=json.loads((H/'suite-plan.json').read_text())
fullids=oldplan['suites']['full19']['caseIds'];assert len(fullids)==1
expected=json.loads((H/'expected-publication.json').read_text())
# The unchanged real Actor API25 + original-error Rev2 fixture and exact full19 case are explicit reviewed payloads.
for n in ['tests/device/ios/self_tests/world_web_public_vertical_fixture.py','tests/device/ios/self_tests/test_ios_world_web_public_vertical.py']:
 row=next(r for r in json.loads((O/'expected-publication.json').read_text()) if r['path']==n);expected.append(row)
dump(F/'expected-publication.json',expected)
# Retain the exact reviewed V7 semantic registry requirement without pinning foreign keys.
(F/'expected-registry-own-key.json').write_text((O/'expected-registry-own-key.json').read_text())
md=(F/'run_metadata.py').read_text().replace('import hashlib,json,os,stat,subprocess','import ast,hashlib,json,os,stat,subprocess')
where=md.index('    return rows\n',md.index('def publication():'))
md=md[:where]+'''    own=json.loads((HERE/'expected-registry-own-key.json').read_text())
    assert json.loads((REPO/own['jsonPath']).read_text())[own['jsonSection']][own['ownKey']]==own['expectedContract']
    tree=ast.parse((REPO/own['validatorPath']).read_text())
    assignments=[node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id==own['validatorAssignment'] for target in node.targets)]
    assert len(assignments)==1 and ast.literal_eval(assignments[0].value)[own['ownKey']]==own['expectedRequired']
''' +md[where:]
# Additional frozen source packets are provenance only, no old actual run/ready maps.
where=md.index('    return plan\n',md.index('def validate_frozen():'))
md=md[:where]+'''    assert sha(HERE/'expected-registry-own-key.json')==plan['expectedRegistryOwnKeySha256']
    for row in plan['additionalFrozenPackets']:
        root=REPO/row['path'];assert sha(root/'freeze.json')==row['freezeSha256']
        frozen=json.loads((root/'freeze.json').read_text())
        for name,expected in frozen['files'].items():assert sha(root/name)==expected,name
''' +md[where:]
where=md.index('    return {str(path.relative_to(REPO)):pin(path)',md.index('def sources(plan):'))
md=md[:where]+'''    for row in plan['additionalFrozenPackets']:
        root=REPO/row['path'];frozen=json.loads((root/'freeze.json').read_text())
        paths.update(root/name for name in frozen['files']);paths.add(root/'freeze.json')
''' +md[where:]
(F/'run_metadata.py').write_text(md)
# Add the semantic registry guard itself to child source pins.
full=(F/'run-selected.py').read_text().replace("'expected-publication.json','freeze.json'","'expected-publication.json','expected-registry-own-key.json','freeze.json'")
(F/'run-selected.py').write_text(full)
# Full19 module paths computed without import; current hashes left absent until Root post-PUB refresh.
config=json.loads((H/'source-root-final-map.json').read_text());mods=config['modules'];queue=[i.rsplit('.',2)[0] for i in fullids]+['ios.self_tests.world_web_public_vertical_fixture','ios.self_tests.test_ios_installed_adapter']
def virtual(rel):
 p=S/'candidate'/rel
 return p if p.is_file() else R/rel
def modulefile(name):
 for root in config['orderedRoots']:
  for tail in [name.replace('.','/')+'.py',name.replace('.','/')+'/__init__.py']:
   rel=(Path(root)/tail).as_posix()
   if virtual(rel).is_file():return rel
 return None
while queue:
 name=queue.pop()
 if name in mods:continue
 rel=modulefile(name)
 if not rel:continue
 mods[name]=dict(path=rel);t=ast.parse(virtual(rel).read_bytes())
 for n in ast.walk(t):
  if isinstance(n,ast.Import):queue.extend(a.name for a in n.names)
  elif isinstance(n,ast.ImportFrom) and not n.level:
   base=n.module or ''
   if base:queue.append(base);queue.extend(base+'.'+x.name for x in n.names if x.name!='*')
config['modules']=dict(sorted(mods.items()));dump(F/'source-root-final-map.json',config)
plan.update(status='PRIVATE_CHANGED_SOURCE_FULL19_UNRUN_NO_TARGET_IMPORTS',suites={'full19':dict(caseIds=fullids,count=1,initialTimeoutSeconds=1200,killAfterSeconds=5)},expectedPublicationCount=len(expected),expectedPublicationSha256=sha(F/'expected-publication.json'),sourceRootMapSha256=sha(F/'source-root-final-map.json'),expectedRegistryOwnKeySha256=sha(F/'expected-registry-own-key.json'),additionalFrozenPackets=oldplan['frozenPackets'],localTempfileAliases={'full19':['ios.self_tests.test_ios_emote_marker_scope.tempfile','ios.self_tests.world_web_actor_fixture.tempfile','ios.self_tests.world_web_public_vertical_fixture.tempfile','ios.self_tests.test_ios_installed_adapter.tempfile']},entrypointAudit='Exactly the unchanged public full19 case and real Actor API25/early-original-error Rev2 fixture. Existing original run_flow catches and original failure WAL/pause precede same exception rethrow. Shared Journey uses actual installed invoke, original Node/HTTP/PNG/typed owner graph, repeated cleanup, terminal canonical end and actual worker exit. Only Source change proposed is the separately reviewed optional pure PWP decode context. No GPU-clock proposal. Native/SDK/OS/Qt/GPU remain declared host models.',initialBudgetReason='Parent approved changed-source actual full19 initial1200+kill5 BEFORE first run. Original API25/20/30 and scheduler35 unchanged. Old step14 actual API25 failure and retained originals remain intact; not an unchanged retry.',historicalRunMapsCopied=False)
dump(F/'suite-plan.json',plan)
for folder in [H,F]:
 for p in folder.iterdir():
  if p.suffix=='.py':ast.parse(p.read_bytes(),filename=str(p))
  if p.suffix=='.json':json.loads(p.read_bytes())
 print(json.dumps(dict(path=str(folder),pythonAST='PASS_ONLY_NO_IMPORT',actualSourceMapPresent=(folder/'publication-ready-source-map.json').exists())))
