"""Current own checkout identity, stdlib-only."""
from pathlib import Path
REPO=Path(__file__).resolve().parent.parent.parent
def head():
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ')
    gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for base in(gd,common):
        path=base/ref[5:]
        if path.is_file():return path.read_text().strip()
    for line in(common/'packed-refs').read_text().splitlines():
        if line and not line.startswith(('#','^')):
            value,name=line.split(' ',1)
            if name==ref[5:]:return value
    raise AssertionError('Actual current checkout HEAD unavailable')
