"""Metadata-only full finalizer; no target/SDK/native imports or execution."""
from pathlib import Path
import argparse,json,hashlib,os,stat,sys
from context_metadata import pin,sha,initialize,admit_context
REPO=Path.cwd().resolve(strict=True);SOURCE=Path(__file__).resolve().parent;PREP=None
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()
def target(p):
    p=Path(p);assert p.resolve().is_relative_to(REPO);return p

def write(name,value):
    p=target(PREP/name);assert not p.exists()
    with target(p).open('x')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    target(p).chmod(0o600)

def anchors():
    raw=(REPO/'.git').read_text();assert raw.startswith('gitdir: ')
    gd=Path(raw[8:].strip()).resolve(strict=True);common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    head=(gd/'HEAD').read_text().strip();assert head.startswith('ref: ')
    ref=common/head[5:];return ref.read_text().strip(),[REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir',ref]

def main():
    global PREP
    parser=argparse.ArgumentParser();parser.add_argument('--expected-head',required=True);parser.add_argument('--quiet-receipt',required=True);parser.add_argument('--destination',required=True);parser.add_argument('--code-source-freeze',required=True);parser.add_argument('--current-original-baseline',required=True);parser.add_argument('--current-original-baseline-sha',required=True);parser.add_argument('--later-terminal-results',required=True);parser.add_argument('--later-terminal-results-sha',required=True);args=parser.parse_args()
    actual,git=anchors();assert actual==args.expected_head
    PREP=initialize(SOURCE,REPO,args)
    assert sys.dont_write_bytecode and args.quiet_receipt.strip()and not(PREP/'freeze.json').exists()
    plan=json.loads((PREP/'plan-draft.json').read_text());actual,git=anchors();assert actual==args.expected_head==plan['publicHead']
    physical=set();packets=[]
    def frozen(path,expected,filename='freeze.json'):
        path=Path(path);f=path/filename;assert sha(f)==expected;physical.add(f)
        body=json.loads(f.read_text());rows=body['files'];items=rows.items()if type(rows)is dict else((r['path'],r)for r in rows)
        for name,row in items:
            assert not Path(name).is_absolute()and '..'not in Path(name).parts
            digest=row if type(row)is str else row['sha256']
            leaf=path/name;assert sha(leaf)==digest;physical.add(leaf)
        packets.append(dict(path=str(path),freezeFile=filename,sha256=expected));return body
    frozen(SOURCE,args.code_source_freeze,'source-freeze.json')
    frozen(plan['codePreparation'],plan['codePreparationFreeze'],'code-preparation-freeze.json')
    frozen(plan['reviewedObserverCodePacket'],plan['reviewedObserverCodeFreeze'],'code-preparation-freeze.json')
    utility_error=frozen(plan['utilityErrorPacket'],plan['utilityErrorFreeze'],'actual-error-result-freeze.json')
    utility_pass=frozen(plan['utilityPassPacket'],plan['utilityPassFreeze'],'utility-result-freeze.json')
    assert utility_error['actualExitCode']==1 and utility_pass['actualExitCode']==0 and utility_pass['actualOwners']==2 and utility_pass['actualHandoffs']==1
    assert utility_pass['standardCleanupEstablished']and utility_pass['actualProcessesAbsent']and utility_pass['sameBytesNewInodeRefused']
    for key in('utilityErrorPacket','utilityPassPacket'):
        folder=Path(plan[key]);code_sha=sha(folder/'code-freeze.json');frozen(folder,code_sha,'code-freeze.json')
    code=json.loads((PREP/'code-preparation-freeze.json').read_text())
    for name,digest in code['files'].items():assert sha(PREP/name)==digest;physical.add(PREP/name)
    physical.add(PREP/'code-preparation-freeze.json')
    frozen(plan['sourcePacket'],plan['sourceFreezeSha256'])
    provenance=json.loads((SOURCE/'source-provenance.json').read_text())
    frozen(provenance['split']['path'],provenance['split']['sha256'],'source-freeze.json')
    frozen(plan['productionSourcePacket'],plan['productionSourceFreezeSha256'])
    legacy=Path(plan['legacyController']);frozen(legacy,plan['legacyControllerFreeze'])
    root=Path(plan['root21Packet']);frozen(root,plan['root21Freeze']);root_state=json.loads((root/'state.json').read_text())
    assert root_state['publicHead']==actual and root_state['status']=='SOURCE11_COMMITTED_ALL_TARGETS_TERMINAL'
    frozen(plan['EmotePrecaseFailurePacket'],plan['EmotePrecaseFailureFreeze'])
    basis=Path(plan['globalBaselineController']);frozen(basis,plan['globalBaselineControllerFreeze'])
    old_global,required_context,context_physical=admit_context(SOURCE,REPO,args);physical.update(context_physical)
    old19=REPO/root_state['previous19RootsPacket'];old19freeze=sha(old19/'freeze.json');assert old19freeze=='6b26d9970f4ce73e0a0980050aa36156909eb34dfe0e88a3035738492b2f1f85'
    frozen(old19,old19freeze);required=json.loads((old19/'additional-original-roots.json').read_text())+[r['path']for r in root_state['originalRoots']];assert len(required)==21
    old_pins=json.loads((legacy/'immutable-source-pins.json').read_text())
    historical_private={name:row for name,row in old_pins.items()if Path(name).is_relative_to(REPO/'.ios-host-tmp')}
    # Every physical historical private leaf/directory must still be exact. Do
    # not follow old public rows and reinterpret them as newly tested sources.
    assert all(pin(name)==row for name,row in historical_private.items())
    physical.update(Path(n)for n in historical_private)
    maps={};map_source_paths=[]
    for key,row in json.loads((PREP/'map-inputs.json').read_text()).items():
        old=Path(row['path']);assert sha(old)==row['sha256'];value=json.loads(old.read_text());physical.add(old)
        for entry in value.values():
            assert type(entry)is dict and type(entry['path'])is str and sha(Path(entry['path']))==entry['sha256']
            map_source_paths.append(Path(entry['path']))
        relative='maps/'+key+'.json';destination=target(PREP/relative)
        target(destination.parent).mkdir(mode=0o700,exist_ok=True)
        assert not destination.exists();target(destination).write_bytes(old.read_bytes());target(destination).chmod(0o600);assert sha(destination)==sha(old)
        maps[key]=dict(path=str(destination),sha256=sha(destination),exactHistoricalMapBytesPreserved=True)
    write('maps.json',maps);physical.update(map_source_paths)
    roots=[REPO/name for name in('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml')]
    public={p for root in roots for p in(root,*root.rglob('*'))}|{REPO/'CMakeLists.txt'}
    assert all(p.resolve(strict=True)==p and not p.is_symlink()for p in public)
    write('public-source-namespace.json',dict(roots=[str(p)for p in roots],paths=sorted(str(p)for p in public if p!=REPO/'CMakeLists.txt')))
    model_roots=[Path(name)for name in plan['modelSearchOrder']]+[Path(plan['baseModelRoot'])]+[legacy/'support',REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests']
    origins={};namespaces={}
    for base in model_roots:
        assert base.is_dir()and base.resolve(strict=True)==base
        for p in sorted(base.rglob('*.py')):
            assert p.resolve(strict=True)==p and not p.is_symlink();parts=p.relative_to(base).with_suffix('').parts
            name='.'.join(parts[:-1]if parts[-1]=='__init__'else parts)
            if name:origins.setdefault(name,str(p))
            for index in range(1,len(parts)):
                prefix='.'.join(parts[:index]);namespaces.setdefault(prefix,str(base.joinpath(*parts[:index])))
    physical.update(Path(path)for path in origins.values()) # Preserve physical pre-overlay sources too.
    origins['test_lifecycle_sparse_connected_one']=str(Path(plan['modelRoot'])/'test_lifecycle_sparse_connected_one.py')
    origins['test_lifecycle_actor_phase_publication_models']=str(Path(plan['sourceModelRoot'])/'test_lifecycle_actor_phase_publication_models.py')
    for row in plan['overlays']:
        assert sha(Path(row['path']))==row['sha256'];origins[row['module']]=row['path']
    # These real observer modules are already imported before the project
    # finder is installed. Preserve their actual current physical origins.
    for module in('guard','root_stage_guard','diagnostic_write_guard','original_loopbacks','sparse_receipt','prerequisites','global_original_corpus'):
        origins[module]=str(PREP/(module+'.py'))
    namespaces={n:p for n,p in namespaces.items()if n not in origins}
    write('module-origins.json',dict(modules=origins,namespaces=namespaces,unknownProjectImportsRefuse=True))
    physical.update(Path(p)for p in origins.values());physical.update(Path(p)for p in namespaces.values())
    # Preserve all old source-pin scopes physically except public source files:
    # those receive independent current namespace/code pins on this exact HEAD.
    for name in old_pins:
        p=Path(name)
        if not p.is_relative_to(REPO)or p.is_relative_to(REPO/'.ios-host-tmp'):physical.add(p)
    physical.update(public);physical.update(git)
    for row in plan['overlays']:physical.add(Path(row['path']))
    physical.update(PREP/'maps'/name for name in())
    physical.update(PREP/'maps.json'for _ in(0,));physical.add(PREP/'module-origins.json');physical.add(PREP/'public-source-namespace.json')
    physical.update(Path(v['path'])for v in maps.values())
    names=set(required_context)
    assert set(old_global)<=names
    for name in names:
        p=Path(name);assert p.is_dir()and p.resolve(strict=True)==p and p.is_relative_to(REPO)and not PREP.is_relative_to(p)
    write('global-original-roots-seed.json',dict(roots=sorted(names),noWriterExclusions=True,explicitTerminalContext=True,minimumKnownOriginalRoots=671,rootCountIsNotExecutionCap=True))
    sys.path.insert(0,str(PREP))
    from global_original_corpus import current
    first=current();second=current();assert first==second
    assert set(first)==names,'An unacknowledged later original root requires an explicit frozen terminal-result addition; no discovery exclusions' 
    assert all(first[name]==rows for name,rows in old_global.items())and all(p in first for p in(*required,*plan['additionalUtilityOriginalRoots'],*required_context))
    write('global-original-corpus-baseline.json',first)
    plan.update(status='PRIVATE_PREPARED_UNRUN_ROOT_REVIEW_REQUIRED',quietRootReceipt=args.quiet_receipt)
    write('plan.json',plan)
    physical.update((PREP/'plan.json',PREP/'global-original-roots-seed.json',PREP/'global-original-corpus-baseline.json'))
    physical.update(SOURCE/name for name in ('prepare-final.py','context_metadata.py','terminal-context-inputs.json','ROOT-PLAN.md','source-freeze.json'))
    import importlib.util
    prereq_spec=importlib.util.spec_from_file_location('sparse_metadata_prerequisites',PREP/'prerequisites.py')
    prereq=importlib.util.module_from_spec(prereq_spec);prereq_spec.loader.exec_module(prereq)
    physical.update(prereq.checked(PREP))
    physical.update(p for p in PREP.rglob('*')if p.is_file()) # All seven physical maps, copied prerequisite files and stage selector.
    pinned={str(p):pin(p)for p in sorted(physical)};write('immutable-source-pins.json',pinned)
    write('source-map.json',dict(publicHead=actual,sourcePins=len(pinned),globalRoots=len(first),old635Preserved=True,old636Preserved=True,explicit21Preserved=all(p in first for p in required),utilityOriginalRoots=plan['additionalUtilityOriginalRoots'],utilityOriginalRootsPreserved=all(p in first for p in plan['additionalUtilityOriginalRoots']),observerCodeFreeze=plan['reviewedObserverCodeFreeze'],physicalHistoricalPrivatePins=len(historical_private),historicalPublicRowsRelabeled=False,mappedModules=len(origins),namespacePackages=len(namespaces),maps=maps,physicalFrozenPackets=packets,sourceFreeze=plan['sourceFreezeSha256'],diagnosticOnly=True,sparseDiagnosticOnly=True,wholeFeatureQualified=False,nativeQualified=False,maximumNodeChildren=0,caseCount=1,wallSeconds=180,killAfterSeconds=5,producerNamespaces=4))
    assert pinned=={name:pin(name)for name in pinned}and first==current()
    for name in ('first-case.json','map-inputs.json','prerequisites.json','code-preparation-freeze.json','historical-proof-scope.json','historical-clock-prerequisites.json','historical-qualified-instruction-prerequisites.json','historical-qualified-warm-prerequisites.json','historical-qualified-retained-owner-prerequisites.json'):
        assert str(PREP/name)in pinned
    files={str(p.relative_to(PREP)):sha(p)for p in sorted(PREP.rglob('*'))if p.is_file()and p.name!='freeze.json'}
    write('freeze.json',dict(status='FROZEN_UNRUN_REQUIRES_ROOT_AND_INDEPENDENT_REVIEW_NO_TARGET_AUTHORIZATION',files=files,publicHead=actual,diagnosticOnly=True,sparseDiagnosticOnly=True,wholeFeatureQualified=False,nativeQualified=False,maximumNodeChildren=0,caseCount=1,wallSeconds=180,killAfterSeconds=5,producerNamespaces=4))
    print(json.dumps(dict(freeze=sha(PREP/'freeze.json'),sourcePins=len(pinned),globalRoots=len(first),historicalPrivatePins=len(historical_private),mappedModules=len(origins),targetExecutions=0)))
if __name__=='__main__':main()
