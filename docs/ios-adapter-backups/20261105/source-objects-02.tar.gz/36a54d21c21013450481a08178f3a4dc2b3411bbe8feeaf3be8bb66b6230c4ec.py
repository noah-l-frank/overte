"""Actual public/common Callback9 end graph over declared host producers.

Node/JS, W3C inputs, UDP, HTTP, PNG, original files and end owners are actual.
Native/Qt/GPU/OS producers, installed target and release preflight are models.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from functools import partial
from pathlib import Path
import json
import os
import threading
import traceback
from unittest.mock import patch
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from feature_journeys.engine import Journey
from feature_journeys.terminal import PROFILE
from feature_journeys.witness import Client
from ios import emote_observer
from ios.adapters import feature_configuration
from ios.adapters.emote_callback_finish_profile import IOSEmoteCallbackFinishFeature
from ios.adapters.emote_runtime import IOSEmoteRuntime
from ios.self_tests.emote_callback_whole_end_fixture import whole_end
from ios.adapters import emote_callback_worker


class ScheduledEmoteActor:
    """Original worker iterations run only outside the Primary SDK lease."""
    def __init__(self,flow,configuration,clock,report):
        self.flow,self.configuration,self.clock,self.report=flow,configuration,clock,report
        self.condition=threading.Condition();self.requested=self.completed=0
        self.cancelled=False;self.result=None;self.error=None;self.first_original_error=None
        self.thread=threading.Thread(target=self.work,name='emote-public-actor',daemon=True);self.thread.start()
    def wait(self):
        with self.condition:
            self.condition.wait_for(lambda:self.cancelled or self.requested>self.completed)
            if self.cancelled:raise RuntimeError('Declared host worker schedule cancelled')
    def pause(self,_seconds):
        with self.condition:self.completed+=1;self.condition.notify_all()
        self.wait()
    def work(self):
        try:
            self.wait()
            self.result=emote_observer.run_flow(self.flow,self.configuration,monotonic=self.clock,sleep=self.pause)
        except BaseException as error:
            self.error=error;self.report(dict(event='uncaught-worker-exception',exceptionType=type(error).__name__,traceback=''.join(traceback.format_exception(error))))
        finally:
            self.report(dict(event='actual-worker-return',returnCode=self.result,uncaughtExceptionType=None if self.error is None else type(self.error).__name__))
            with self.condition:self.condition.notify_all()
    def cycle(self):
        with self.condition:
            need(self.error is None and self.result is None and self.requested==self.completed)
            self.requested+=1;wanted=self.requested;self.condition.notify_all()
            # The original worker publish ceiling is60s. This scheduler wait
            # neither changes that budget nor advances native/model time.
            need(self.condition.wait_for(lambda:self.completed>=wanted or self.error is not None or self.result is not None,timeout=65))
            if self.error is not None:raise self.error
            need(self.completed==wanted and self.result is None)
            # The original run_flow has already persisted its failure and
            # yielded. Propagate the exact first source error to the test;
            # never substitute an expected worker outcome or stop it early.
            if self.first_original_error is not None:
                error,traceback=self.first_original_error
                raise error.with_traceback(traceback)
    def finish(self):
        with self.condition:
            need(self.error is None and self.result is None and self.requested==self.completed)
            self.requested+=1;self.condition.notify_all()
        self.thread.join(timeout=65);need(not self.thread.is_alive())
        if self.error is not None:raise self.error
        need(self.result==0)
    def close(self):
        with self.condition:self.cancelled=True;self.condition.notify_all()
        self.thread.join(timeout=65);need(not self.thread.is_alive())


class PublicCallbackEmoteVertical:
    def __init__(self,test):
        # The qualified single-context Callback producer, original target pair,
        # requested-clip curve and both role epochs are selected before birth.
        self.end=whole_end(test)
        self.normal=self.end.normal;self.adapter=self.end.base;self.runtime=self.end.runtime
        self.domain=self.normal.target.domain;self.root=self.end.root
        self.calls=[];self.factories=[];self.reports=[];self.worker_events=[];self.worker=None
        self.reader=Client(self.normal.target.client.url,'r'*64)
        self.configuration_path=self.root/'public-feature-configuration.json';access=self.root/'public-fixture-reader.json'
        PrivateFeatureState(access).write(dict(fixtureAdapterAccessVersion=1,fixtureUrl=self.normal.target.client.url,adapterToken='d'*64),None)
        self.configuration=dict(iosFeatureAdapterVersion=9,areas=['emotes'],fixtureConfig=str(access),
            graphics=None,create=None,emotes=dict(artifactRoot=str(self.normal.flow.root),imagePolicy=deepcopy(self.normal.flow.policy),actorTarget='actor'),
            worldNavigation=None,avatarPeople=None,worldWeb=None,tabletWeb=None,emoteCoordinatorVersion=3,worldWebCoordinatorVersion=None)
        self.configuration['emoteTargets']=dict(primaryTarget='primary',actorTarget='actor',
            primaryArtifactRoot=str(self.normal.flow.root),actorArtifactRoot=str(self.normal.actor.flow.root))
        PrivateFeatureState(self.configuration_path).write(self.configuration,None)
        test.enterContext(patch.dict(os.environ,OVERTE_IOS_FEATURE_ADAPTER_CONFIG=str(self.configuration_path)))
        need(9 in feature_configuration.READS)
        self.flows={}
        for role,item in self.end.roles.items():
            # The old single-thread fixture must never run hidden direct peer
            # operations. All independent work below uses the actual worker.
            item.flow.sleep=item.target.domain.sleep
            self.flows[role]=self.make_flow(role,item.flow.client)
        self.primary,self.actor=self.flows['primary'],self.flows['actor']
        actual_factory=IOSEmoteRuntime._emote_callback_finish_feature
        def factory(runtime,selector,run,*,role,client,settings,target_pair=None):
            need(runtime.adapter is self.adapter and selector==role and run==self.primary.run)
            from ios.adapters.emote_configuration import settings as validate
            expected=dict(artifactRoot=str(self.flows[role].root),imagePolicy=self.flows[role].policy,
                **({'actorTarget':'actor'} if role=='primary' else {'primaryTarget':'primary'}))
            need(validate(settings,role=role,target=selector)==expected and client.url==self.primary.client.url
                and target_pair==self.configuration['emoteTargets'])
            self.factories.append((selector,run,role))
            # A fresh exact product Flow owns the ACTUAL configured adapter
            # reader, just as the normal production factory does. Existing
            # typed children are only the declared producer assembly seam.
            # Execute the actual production factory exactly once, including its
            # original settings/pair/type constructor boundary. Adapt only the
            # declared host producer assembly before this fresh Flow acquires
            # its first phase/native/input original.
            flow=actual_factory(runtime,selector,run,role=role,client=client,settings=settings,target_pair=target_pair)
            flow=self.make_flow(role,client,flow=flow);self.flows[role]=flow
            if role=='primary':self.primary=flow;flow.sleep=self.primary_sleep
            return flow
        test.enterContext(patch.object(IOSEmoteRuntime,'_emote_callback_finish_feature',factory))
        actual_step=emote_callback_worker.step
        def observed_step(flow,configuration):
            try:return actual_step(flow,configuration)
            except BaseException as error:
                if flow is self.actor:
                    self.record_worker(dict(event='actual-step-exception',exceptionType=type(error).__name__,traceback=''.join(traceback.format_exception(error))))
                    from ios.adapters.emote_observer import EmoteObservationPending
                    from adapters.script_feature.lock import ScriptSourceBusy
                    from feature_journeys.phase_fixture import PhasePending
                    if not isinstance(error,(EmoteObservationPending,ScriptSourceBusy,PhasePending)) and isinstance(error,
                            (OSError,RuntimeError,ValueError,TypeError,KeyError,RecursionError)) and self.worker.first_original_error is None:
                        self.worker.first_original_error=(error,error.__traceback__)
                raise
        test.enterContext(patch.object(emote_callback_worker,'step',observed_step))
        config=dict(iosEmoteObserverVersion=4,targetPair=deepcopy(self.configuration['emoteTargets']),target='actor',primaryTarget='primary',runId=self.primary.run,
            durationSeconds=1800,artifactRoot=str(self.actor.root),imagePolicy=self.actor.policy,
            primaryArtifactRoot=str(self.primary.root),primaryImagePolicy=self.primary.policy)
        self.worker=ScheduledEmoteActor(self.actor,config,self.primary.monotonic,self.record_worker);test.addCleanup(self.worker.close)
        self.primary.sleep=self.primary_sleep
        # Prepare the actual source before the shared runner selects its fresh
        # baseline ticket, as the established common fixture already does.
        self.invoke('feature.emotes.observe',dict(contractVersion=16,runId=self.primary.run,afterSequence=0))
        self.journey=Journey('emotes',self.primary.run,self.primary.phase.fixture_url,
            invoke=self.invoke,witness=self.witness,activate=self.activate,read_artifact=self.read_artifact,
            image_policy=dict(screen=deepcopy(self.primary.policy)),continuity=self.continuity,
            monotonic=self.primary.monotonic,epoch_ms=self.primary.epoch_ms,sleep=self.domain.sleep,
            report=self.reports.append,terminal_profile=PROFILE,retire_fixture=self.retire)
    def make_flow(self,role,client,*,flow=None):
        item=self.end.roles[role];old=item.flow
        if flow is None:
            flow=IOSEmoteCallbackFinishFeature(self.runtime,role,client,old.run,role,old.root,old.policy,
                actor_selector='actor' if role=='primary' else None,primary_selector='primary' if role=='actor' else None,
                epoch_ms=old.epoch_ms,monotonic=old.monotonic,sleep=item.target.domain.sleep,target_pair=self.configuration['emoteTargets'])
        else:
            need(type(flow) is IOSEmoteCallbackFinishFeature and flow.runtime.adapter is self.adapter
                and flow.selector==role and flow.role==role and flow.run==old.run and flow.root==old.root
                and flow.policy==old.policy and flow.configured_pair==self.configuration['emoteTargets']
                and flow.state is None and flow.previous is None and flow.phase.previous is None)
            # Before its first capture, select the established host producer
            # runtime/clock endpoints. No saved DTO, acquisition or clock is
            # altered. All candidate/installed/source gates remain actual.
            flow.runtime=self.runtime
            flow.monotonic,flow.epoch_ms,flow.sleep=old.monotonic,old.epoch_ms,item.target.domain.sleep
            flow.phase.monotonic,flow.phase.epoch_ms=old.monotonic,old.epoch_ms
        flow.lock=old.lock;flow.primary_lock=self.normal.flow.lock
        def components():
            own,primary=flow.bindings()
            need(flow.state is not None and flow.state['phaseInstance']==flow.phase.previous['instance'])
            parts=item.parts
            need(parts['sources'].binding==primary['binding'] and parts['scope'].binding==own['binding']
                and parts['scope'].lock is flow.lock and parts['observer'].binding==own['binding'])
            own['check']();primary['check']();return parts
        # Same genuine typed assembly as WholePrimary/ActorFixture. No method
        # providing observations, effects, publications or end facts is patched.
        flow.components=components
        return flow
    def record_worker(self,event):
        # This metadata root is outside both product original roots and the
        # immutable candidate tree. No generic locals/config dump is captured.
        self.worker_events.append(deepcopy(event))
        with (self.root/'actual-emote-worker-events.json').open('w') as stream:
            json.dump(self.worker_events,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    def primary_sleep(self,seconds):
        if self.primary.lock._owner is None and self.primary.primary_lock._owner is None:
            if self.primary.phase.status()['active']:self.worker.cycle()
        self.domain.sleep(seconds)
    def activate(self,ticket,verb='baseline',inputs=None):
        self.normal.target.ticket=ticket;self.normal.target.server.journal.activate(self.primary.run,ticket,verb,inputs)
        for item in self.end.roles.values():
            scope=item.parts['scope']
            if scope.previous is None and not scope.frames:scope.ticket=ticket
    def invoke(self,operation,values):
        self.calls.append((operation,deepcopy(values)))
        result=self.adapter.invoke('primary',operation,values);need(self.adapter._operation is None)
        if operation in ('feature.emotes.act','feature.emotes.observe'):self.worker.cycle()
        if operation=='feature.emotes.terminal' and values['stage']=='finish':self.worker.finish()
        return result
    def witness(self):return self.reader.request('/runs/'+self.primary.run)
    def continuity(self,_stage,_verb):need(self.runtime._sources('primary')['check']() is not False)
    def read_artifact(self,name):
        from feature_journeys.evidence import read_private_artifact
        return read_private_artifact(self.primary.root,name)
    def retire(self):return self.reader.request('/runs/'+self.primary.run,method='DELETE')
