"""Real Native Runtime/marker/PNG handoff and original-file/time refusals.

Native/GPU/Qt remain explicit host producers. No Source, guard, acquisition
clock, archive or expected effect is replaced. Faults run only AFTER genuine
finish_record, retaining each replaced task-owned original under a new name.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import hashlib
from pathlib import Path
import time
from adapters.original_file_reads import scope
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import canonical
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.owned_vulkan_world_frame import VulkanWorldFrameOwner
from ios.adapters.avatar_sample_return import AvatarSampleReturnProof
from ios.adapters import avatar_images
from ios.self_tests.test_ios_avatar_bilateral_initial_barrier import AvatarBilateralInitialBarrierTests
from ios.self_tests.avatar_prepare_fixture import TICKET


class AvatarSampleReturnHandoffTests(AvatarBilateralInitialBarrierTests):
    def samples(self):
        frontdoor,domain,runtime,primary,actor,_before=self.initial_pair()
        actor.prepare_marker();primary.prepare_marker()
        return frontdoor,domain,primary

    def preserve_and_replace(self,path):
        raw=path.read_bytes();before=path.lstat()
        backup=path.with_name('counter-retained-original-'+path.name)
        self.assertFalse(backup.exists());path.rename(backup)
        path.write_bytes(raw);path.chmod(0o600)
        self.assertEqual(raw,backup.read_bytes());self.assertEqual(before.st_ino,backup.lstat().st_ino)
        self.assertNotEqual(before.st_ino,path.lstat().st_ino)
        return dict(originalPath=str(path),retainedPath=str(backup),originalInode=before.st_ino,
            replacementInode=path.lstat().st_ino,sha256=hashlib.sha256(raw).hexdigest())

    def capture_refusal(self,samples):
        try:samples.capture(TICKET)
        except NativeUIError as error:
            frames=[];tb=error.__traceback__
            while tb is not None:frames.append(tb.tb_frame.f_code);tb=tb.tb_next
            return frames
        self.fail('The genuine current capture unexpectedly returned after the declared refusal fault')

    def one_read_one_release(self,domain,row):
        gpu=domain.scenes['primary'].gpus[row['requestId']]
        self.assertEqual(1,sum(value['operation']=='read' for value in gpu.commands))
        self.assertEqual(1,sum(value['operation']=='release' for value in gpu.commands))

    def retire_optional_prefix(self,samples):
        marker=samples.scope;reference=marker.state['manifests'][0]
        entries=marker.originals.manifest(reference);self.assertGreater(len(entries),1)
        body=dict(avatarManifestVersion=1,kind='inputs',binding=marker.binding,runId=marker.run,
            role=marker.role,block=reference['block'],entries=entries[:1])
        raw=canonical(body);prefix=dict(block=reference['block'],count=1,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
        path=marker.originals.manifest_path(prefix);self.assertTrue(path.exists())
        retained=path.with_name('counter-retained-optional-prefix-'+path.name);self.assertFalse(retained.exists())
        original=path.read_bytes();before=path.lstat();path.rename(retained)
        self.assertEqual(original,retained.read_bytes());self.assertEqual(before.st_ino,retained.lstat().st_ino)
        self.assertFalse(path.exists())
        return path,retained,body

    def test_same_capture_saved_record_and_original_png_match_independent_cold_archive(self):
        f,d,owner=self.samples()
        with owner.held(paired=True):
            owner.load();samples=owner.components(owner.source_parts())['samples']
            self.assertTrue(AvatarSampleReturnProof(samples).available)
            row=samples.capture(TICKET);self.assertEqual('observed',row['status'])
            commands={key:len(gpu.commands) for key,gpu in d.scenes['primary'].gpus.items()}
            frame,raw,measured=samples.archive(row)
            self.assertTrue(measured['modelLoaded']);self.assertEqual(row['requestId'],frame['capture']['requestId'])
            self.assertEqual(raw,(samples.root/samples.read_record(row,historical=True)['owner']['name']).read_bytes())
            self.assertEqual(commands,{key:len(gpu.commands) for key,gpu in d.scenes['primary'].gpus.items()})
            self.one_read_one_release(d,row)
            PrivateFeatureState(f.root/'actual-sample-return-positive.json').write(dict(original=row,
                pngSha256=hashlib.sha256(raw).hexdigest(),coldArchiveMeasurementMatches=True,
                noAdditionalNativeCommand=True,normalQualified=False,nativeQualified=False,wholeQualified=False),None)

    def test_saved_png_replacement_after_real_finish_refuses_without_another_native_input(self):
        f,d,owner=self.samples();faults=[]
        with owner.held(paired=True):
            owner.load();samples=owner.components(owner.source_parts())['samples'];finish=samples.finish_record
            self.assertTrue(AvatarSampleReturnProof(samples).available)
            def replace(record):
                row=finish(record);faults.append(self.preserve_and_replace(samples.root/record['owner']['name']));return row
            samples.finish_record=replace
            frames=self.capture_refusal(samples)
            self.assertEqual(1,len(faults));self.assertIsNone(samples.state['pending']);self.assertEqual(1,len(samples.state['rows']))
            self.assertIn(VulkanWorldFrameOwner._file.__code__,frames)
            row=samples.state['rows'][0];self.one_read_one_release(d,row)
            self.assertEqual('observed',row['status'])  # Durable responsibility is not a successful return.
            PrivateFeatureState(f.root/'actual-sample-return-png-refusal.json').write(dict(fault=faults[0],
                savedOriginal=row,returnedCurrentSample=False,nativeQualified=False,wholeQualified=False),None)

    def test_marker_dependency_inode_replacement_after_real_finish_refuses_even_for_same_bytes(self):
        f,d,owner=self.samples();faults=[]
        with owner.held(paired=True):
            owner.load();samples=owner.components(owner.source_parts())['samples'];finish=samples.finish_record
            self.assertTrue(AvatarSampleReturnProof(samples).available)
            marker=samples.scope;path=marker.originals.manifest_path(marker.state['manifests'][0])
            def replace(record):
                row=finish(record);faults.append(self.preserve_and_replace(path));return row
            samples.finish_record=replace
            frames=self.capture_refusal(samples)
            self.assertEqual(1,len(faults));self.assertIsNone(samples.state['pending']);self.assertEqual(1,len(samples.state['rows']))
            self.assertIn(AvatarSampleReturnProof.check.__code__,frames)
            row=samples.state['rows'][0];self.one_read_one_release(d,row)
            self.assertEqual(faults[0]['sha256'],hashlib.sha256(Path(faults[0]['retainedPath']).read_bytes()).hexdigest())
            PrivateFeatureState(f.root/'actual-sample-return-marker-refusal.json').write(dict(fault=faults[0],
                savedOriginal=row,returnedCurrentSample=False,nativeQualified=False,wholeQualified=False),None)

    def test_real_elapsed_after_saved_original_still_fails_unchanged_final1point5_guard(self):
        f,d,owner=self.samples();saved=[]
        with owner.held(paired=True):
            owner.load();samples=owner.components(owner.source_parts())['samples'];finish=samples.finish_record
            self.assertTrue(AvatarSampleReturnProof(samples).available)
            def delayed(record):
                row=finish(record);saved.append(row);time.sleep(1.6);return row
            samples.finish_record=delayed
            frames=self.capture_refusal(samples)
            self.assertEqual(1,len(saved));self.assertIsNone(samples.state['pending'])
            # The deepest owning frame is the literal capture return guard;
            # no earlier failed source, file proof or native join can count.
            self.assertIs(samples.capture.__func__.__code__,frames[-2])
            row=saved[0];record=samples.read_record(row,historical=True);clock=record['partial']['clockJoin']
            self.assertLess(clock['hostAfterMonotonic']-clock['hostBeforeMonotonic'],1.5)
            self.assertGreater(time.monotonic()-clock['hostBeforeMonotonic'],1.5)
            self.one_read_one_release(d,row)
            frame,raw,measurement=samples.archive(row);self.assertTrue(measurement['modelLoaded'])
            PrivateFeatureState(f.root/'actual-sample-return-clock-refusal.json').write(dict(savedOriginal=row,
                originalHostBeforeMonotonic=clock['hostBeforeMonotonic'],originalHostAfterMonotonic=clock['hostAfterMonotonic'],
                originalPNGStillColdReadable=True,returnedCurrentSample=False,nativeQualified=False,wholeQualified=False),None)

    def test_same_function_code_mutation_invalidates_existing_policy_and_exact_restore_recovers(self):
        f,d,owner=self.samples()
        with owner.held(paired=True):
            owner.load();samples=owner.components(owner.source_parts())['samples'];proof=AvatarSampleReturnProof(samples)
            self.assertTrue(proof.available);function=avatar_images.compose;code=function.__code__
            def foreign(*_args,**_kwargs):return None
            commands={role:len(native.commands) for role,native in d.natives.items()}
            try:
                function.__code__=foreign.__code__
                self.assertIs(function,avatar_images.compose)
                with self.assertRaises(NativeUIError):proof.check()
            finally:function.__code__=code
            proof.check();self.assertEqual(commands,{role:len(native.commands) for role,native in d.natives.items()})
            self.assertIs(code,function.__code__)
            PrivateFeatureState(f.root/'actual-sample-return-code-refusal.json').write(dict(
                sameFunctionMutationRefused=True,exactOriginalCodeRestored=True,noAdditionalNativeCommand=True,
                nativeQualified=False,wholeQualified=False),None)

    def test_cached_marker_state_frames_and_component_rebinding_invalidate_existing_proof(self):
        f,d,owner=self.samples()
        with owner.held(paired=True):
            owner.load();samples=owner.components(owner.source_parts())['samples'];proof=AvatarSampleReturnProof(samples)
            self.assertTrue(proof.available);marker=proof.marker
            commands={role:len(native.commands) for role,native in d.natives.items()}
            old=marker.state['phase']
            try:
                marker.state['phase']='released'
                with self.assertRaises(NativeUIError):proof.check()
            finally:marker.state['phase']=old
            proof.check();old=marker.frames[0]['label']
            try:
                marker.frames[0]['label']='foreign-cached-marker-label'
                with self.assertRaises(NativeUIError):proof.check()
            finally:marker.frames[0]['label']=old
            proof.check();old=marker.components
            try:
                marker.components=type(old)(**vars(old))
                with self.assertRaises(NativeUIError):proof.check()
            finally:marker.components=old
            proof.check();clone=object.__new__(type(marker));vars(clone).update(vars(marker))
            self.assertIs(clone.state,marker.state);self.assertIs(clone.frames,marker.frames)
            try:
                proof.marker=clone
                with self.assertRaises(NativeUIError):proof.check()
            finally:proof.marker=marker
            proof.check();self.assertEqual(commands,{role:len(native.commands) for role,native in d.natives.items()})
            PrivateFeatureState(f.root/'actual-sample-return-cached-marker-refusal.json').write(dict(
                sameStateObjectMutationRefused=True,sameFrameObjectMutationRefused=True,componentIdentityChangeRefused=True,
                sameTypeMarkerCloneSharingStateRefused=True,
                exactOriginalBindingsRestored=True,noAdditionalNativeCommand=True,nativeQualified=False,wholeQualified=False),None)

    def test_absent_optional_marker_prefix_allows_real_sample_and_gpu_file_births(self):
        f,d,owner=self.samples()
        with owner.held(paired=True):
            owner.load();samples=owner.components(owner.source_parts())['samples']
            missing,retained,_body=self.retire_optional_prefix(samples)
            self.assertTrue(AvatarSampleReturnProof(samples).available)
            row=samples.capture(TICKET);self.assertEqual('observed',row['status']);self.assertFalse(missing.exists())
            with scope(fresh=True):frame,raw,measurement=samples.archive(row)
            self.assertTrue(measurement['modelLoaded']);self.one_read_one_release(d,row)
            self.assertTrue((samples.root/samples.read_record(row,historical=True)['owner']['name']).is_file())
            self.assertTrue(samples.originals.path(samples.originals.expand(row['original'])).is_file())
            PrivateFeatureState(f.root/'actual-sample-return-optional-prefix-positive.json').write(dict(
                absentOptionalPrefix=str(missing),retainedOriginal=str(retained),savedOriginal=row,
                sampleAndGPUFilesBorn=True,independentColdArchiveReadable=True,nativeQualified=False,wholeQualified=False),None)

    def test_foreign_previously_absent_marker_prefix_after_real_finish_refuses_before_return(self):
        f,d,owner=self.samples();faults=[]
        with owner.held(paired=True):
            owner.load();samples=owner.components(owner.source_parts())['samples'];finish=samples.finish_record
            missing,retained,body=self.retire_optional_prefix(samples)
            self.assertTrue(AvatarSampleReturnProof(samples).available)
            def foreign(record):
                row=finish(record);self.assertFalse(missing.exists())
                PrivateFeatureState(missing).write(dict(body,runId='foreign-marker-prefix'),None)
                faults.append(dict(path=str(missing),retainedOriginal=str(retained),foreignBody=True));return row
            samples.finish_record=foreign;frames=self.capture_refusal(samples)
            self.assertEqual(1,len(faults));self.assertIn(AvatarSampleReturnProof.check.__code__,frames)
            self.assertIsNone(samples.state['pending']);self.assertEqual(1,len(samples.state['rows']))
            row=samples.state['rows'][0];self.one_read_one_release(d,row)
            # Existing OriginalFrameStore permits an absent deterministic
            # prefix, but its foreign body is an actual cold-decoder refusal.
            try:
                with scope(fresh=True):samples.archive(row)
            except NativeUIError as error:
                codes=[];tb=error.__traceback__
                while tb is not None:codes.append(tb.tb_frame.f_code);tb=tb.tb_next
                self.assertIn(OriginalFrameStore.manifest.__code__,codes)
            else:self.fail('Foreign deterministic original prefix unexpectedly passed the independent cold decoder')
            self.assertTrue(missing.is_file() and retained.is_file())
            PrivateFeatureState(f.root/'actual-sample-return-optional-prefix-refusal.json').write(dict(
                fault=faults[0],savedOriginal=row,coldDecoderAlsoRefused=True,returnedCurrentSample=False,
                nativeQualified=False,wholeQualified=False),None)
