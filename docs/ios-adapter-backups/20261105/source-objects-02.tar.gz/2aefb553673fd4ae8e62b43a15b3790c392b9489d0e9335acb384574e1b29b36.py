"""Metadata-only pinned Lifecycle read-phase own7 controller; no target imports."""
from pathlib import Path
import ast,hashlib,json,sys
R=Path.cwd();ROOT=R/'.ios-host-tmp';config_path=Path(sys.argv[1]).resolve();config=json.loads(config_path.read_text())
O=ROOT/config['parentController'];P=ROOT/config['parentSource'];S=ROOT/config['sourceName'];H=ROOT/config['controllerName']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(O/'freeze.json')==config['parentControllerFreeze']and sha(P/'freeze.json')==config['parentSourceFreeze']
assert sha(S/'freeze.json')==config['sourceFreeze']and not H.exists();H.mkdir(mode=0o700)
source_files=json.loads((S/'freeze.json').read_text())['files']
for relative,digest in source_files.items():assert sha(S/relative)==digest
actual=[]
for path in (S/'candidate').rglob('*'):
    if path.is_file():
        parent=P/'candidate'/path.relative_to(S/'candidate')
        if not parent.exists()or path.read_bytes()!=parent.read_bytes():actual.append(str(path.relative_to(S)))
assert sorted(actual)==sorted('candidate/tests/device/ios/adapters/'+name for name in('lifecycle_current_archive.py','lifecycle_checkpoint_index.py','lifecycle_observer.py','lifecycle_publication_read_phase.py'))
changes=[dict(path=name,sha256=sha(S/name))for name in actual]
old_freeze=json.loads((O/'freeze.json').read_text());excluded={'immutable-source-pins.json','AST-ONLY.json','lexical-provenance.json'}
for relative,digest in old_freeze['files'].items():
    assert sha(O/relative)==digest,relative
    if relative in excluded:continue
    path=H/relative;path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    source=S/relative if relative.startswith('models/')else O/relative;path.write_bytes(source.read_bytes());path.chmod(0o600)
def replace(value):
    if isinstance(value,dict):return {k:replace(v)for k,v in value.items()}
    if isinstance(value,list):return [replace(v)for v in value]
    if isinstance(value,str):return value.replace(str(O),str(H)).replace(str(P),str(S)).replace(sha(P/'freeze.json'),sha(S/'freeze.json'))
    return value
for relative in ('maps.json','plan.json','historical-proof-scope.json',*[str(p.relative_to(O))for p in (O/'maps').glob('*.json')]):
    path=H/relative;value=replace(json.loads(path.read_text()))
    if relative=='plan.json':
        for row in value['overlays']:row['sha256']=sha(row['path'])
    path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
path=H/'maps.json';maps=json.loads(path.read_text())
for row in maps.values():row['sha256']=sha(row['path'])
path.write_text(json.dumps(maps,indent=2,sort_keys=True)+'\n')
path=H/'ROOT-PLAN.txt';text=path.read_text().replace(O.name,H.name).replace(sha(P/'freeze.json'),sha(S/'freeze.json'))
text+='\nPRODUCTIVE CLOCK-CARRIER SUCCESSOR: '+config['scope']+' No execution occurred during preparation. New first1 remains actual-pass gated for the exact remaining two cases.\n';path.write_text(text)
# General historical FAILURE reader admits no new test/SDK behavior and cannot
# relabel any failed stage as a first PASS. Exact raw source pins remain checked.
history=json.loads((H/'historical-proof-scope.json').read_text());failures=history.get('failedStages',[])
for item in failures:
    stage=Path(item['path']);receipt=json.loads((stage/'cleanup/receipt.json').read_text())
    item['retainedRootCount']=len(receipt['retainedRoots']);item['selectedResultExists']=(stage/'selected-result.json').exists()
stage=O/'first1';report_path=stage/'run/report.json';report=json.loads(report_path.read_text());receipt=json.loads((stage/'cleanup/receipt.json').read_text())
assert report['exitCode']==1 and report['allPinsEqual']and report['retainedOriginalsUnchanged']and not report['remainingOwnedProcesses']
failures.append(dict(path=str(stage),reportSha256=sha(report_path),exitCode=1,retainedFiles=report['retainedFiles'],retainedRootCount=len(receipt['retainedRoots']),selectedResultExists=(stage/'selected-result.json').exists()))
history['failedStages']=failures;(H/'historical-proof-scope.json').write_text(json.dumps(history,indent=2,sort_keys=True)+'\n')
path=H/'guard.py';text=path.read_text();start=text.index("    for row in history.get('failedStages',[]):");finish=text.index('    return current\n',start)
text=text[:start]+"""    for row in history.get('failedStages',[]):
        stage=Path(row['path']);report_path=stage/'run/report.json';assert sha(report_path)==row['reportSha256']
        report=json.loads(report_path.read_text());assert report['exitCode']==row['exitCode']==1 and report['retainedFiles']==row['retainedFiles']
        assert report['allPinsEqual']and report['retainedOriginalsUnchanged']and not report['remainingOwnedProcesses']
        assert json.loads((stage/'run/source-before.json').read_text())==json.loads((stage/'run/source-after.json').read_text())
        assert json.loads((stage/'run/originals-first.json').read_text())==json.loads((stage/'run/originals-second.json').read_text())
        receipt=json.loads((stage/'cleanup/receipt.json').read_text());assert receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']and len(receipt['retainedRoots'])==row['retainedRootCount']
        a=json.loads((stage/'cleanup/terminal-census-1.json').read_text());b=json.loads((stage/'cleanup/terminal-census-2.json').read_text())
        assert a==b and not any(a[k]for k in ('threads','pendingTasks','sdkModules'))and a['children']==''
        selected_path=stage/'selected-result.json';assert selected_path.exists()==row['selectedResultExists']
        if selected_path.exists():
            selected=json.loads(selected_path.read_text());assert selected['successful']is False and selected['testsRun']==1 and selected['failureCount']+selected['errorCount']>0 and selected['skippedCount']==0
"""+text[finish:];path.write_text(text)
# Exact Root selection: one admitted/membership/exit own case, then six independent counters.
model=H/'models/test_lifecycle_publication_original_read_phase_models.py';model.write_bytes((S/'models'/model.name).read_bytes());model.chmod(0o600)
selection=[('first1','test_real_historical_record_index_leases_restore_membership_inside_one_publication_only'),('sameInode1','test_same_inode_same_bytes_rewrite_refuses_a_warm_historical_row_without_new_query'),('parentOrphan1','test_new_unknown_parent_original_refuses_even_when_requested_row_is_already_warm'),('code1','test_same_receiver_code_change_refuses_before_a_warm_original_decoder_can_run'),('unsupported1','test_unsupported_new_namespace_member_selects_literal_replay_without_old_memo_admission'),('foreignStore1','test_same_originals_and_copied_sdk_metadata_cannot_borrow_retained_store_lock_owner_memo_admission'),('lostPost1','test_actual_loopback_post_return_loss_replays_saved_receipt_without_second_post_or_current_cut')]
for name,method in selection:
    directory=H/name;directory.mkdir(mode=0o700,exist_ok=True);row=dict(case='test_lifecycle_publication_original_read_phase_models.LifecyclePublicationOriginalReadPhaseModels.'+method,expectedRealTemporaryDirectories=3,killAfterSeconds=5,ownMethodOnly=True,seconds=180)
    (directory/'case.json').write_text(json.dumps(row,indent=2)+'\n')
p=H/'plan.json';plan=json.loads(p.read_text());plan['cases']=[json.loads((H/name/'case.json').read_text())['case']for name,_method in selection];plan['caseCount']=7;plan['stageOrder']=[name for name,_method in selection];plan['sourceFreezeSha256']=sha(S/'freeze.json')
new=S/'candidate/tests/device/ios/adapters/lifecycle_publication_read_phase.py';assert not any(row['module']=='ios.adapters.lifecycle_publication_read_phase'for row in plan['overlays']);plan['overlays'].append(dict(module='ios.adapters.lifecycle_publication_read_phase',path=str(new),sha256=sha(new),publicPath=None,publicSha256=None));p.write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
p=H/'root-supervise.py';t=p.read_text();old="HERE.name in ('first1','typeLoss1','originalUp1')";assert t.count(old)==1;p.write_text(t.replace(old,"HERE.name in ('first1','sameInode1','parentOrphan1','code1','unsupported1','foreignStore1','lostPost1')"))
p=H/'guard.py';t=p.read_text();old="    order=('first1','typeLoss1','originalUp1');assert here.name in order";assert t.count(old)==1;t=t.replace(old,"    order=('first1','sameInode1','parentOrphan1','code1','unsupported1','foreignStore1','lostPost1');assert here.name in order");p.write_text(t)
(H/'ROOT-PLAN.txt').write_text("""ROOT AUTHORIZED EXACT READ-PHASE OWN7; NO WHOLE16/PNG/END RUN

Sourceb29b3dc6718ca772ab3223384422608ef356a9e9c62270c95edd9d5ceea92bc4.
Exact stage order: first1, sameInode1, parentOrphan1, code1, unsupported1,
foreignStore1, lostPost1. Each is exactly one named OWN method, fresh process,
unchanged180s+TERM/kill-after5s. FIRST is only the admitted/hits/read-membership/
foreign-context/exit-refusal case. Only qualified actualPASS permits remaining
six, one at a time. Any failed prior stage blocks every following stage. Stop
on failure/timeout/policy/semantic issue; no retry or budget/guard change.
No Whole16 first1/typeLoss/originalUp is selected or admitted by these names.

Complete exact private source-file overlays only; no parent/native/guard AST
substitution. Exactly43 candidate Python module overlays include the new read
phase. Old SDK/Qt/native producer seams stay explicit models. Current7 Source/
worker/loop/original HTTP/AFC, actual Phase/Journal/Publisher/PFS/CAS and real
standard IsolatedAsyncioTestCase teardown/cleanup/Runner.close remain actual.
Exactly three genuine inherited TemporaryDirectory objects are retained per
case through reviewed retain_owned_root. All original raw files, inodes, PFS,
WAL, hostile same-inode/orphan specimens and code-binding sidecars are retained.
The literal root_stage_guard and run-selected.py are unchanged from Controller
7ccc, preserving two task/thread/FD/child/SDK/raw original censuses. Child forbids
all subprocess/Node and installed/vendor SDK import/read before target imports;
only owned loopback bind/connect permitted. Parent owns PGID/SID/startticks and
requires no group/session remainder before original-file census. Every source/
map/dependency pin is checked before/after; follow-up gates re-pin actual prior
original files against saved census and verify exact own ID/receipt/result.

Clock2 actualPASS remain historical exactSourcea012, never relabeled current.
All earlier Whole16/bootstrap failures including last79 originals are pinned
as failures. Parent 7ccc/53e8 and every older freeze remain unchanged. Root's
current public files are dependencies, not mutated or re-published by a private
overlay. Initial unsupported policy is literal; first case MUST prove actual
admitted policy and real warm hits, never bypass policy to obtain a PASS.
""")

# AST only: record exact lexical source; no proposed module is imported.
normal=H/'support/normal_child_fixture.py';tree=ast.parse(normal.read_bytes());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='NormalChildFixture');fn=next(n for n in cls.body if isinstance(n,ast.AsyncFunctionDef)and n.name=='asyncSetUp')
all_calls=[n for n in ast.walk(fn)if isinstance(n,ast.Call)and isinstance(n.func,ast.Name)and n.func.id=='super'and not n.args]
class Lexical(ast.NodeVisitor):
    def __init__(self):self.calls=[]
    def visit_ClassDef(self,n):return
    def visit_FunctionDef(self,n):
        if n is fn:self.generic_visit(n)
    def visit_AsyncFunctionDef(self,n):
        if n is fn:self.generic_visit(n)
    def visit_Lambda(self,n):return
    def visit_Call(self,n):
        if isinstance(n.func,ast.Name)and n.func.id=='super'and not n.args:self.calls.append(n)
        self.generic_visit(n)
v=Lexical();v.visit(fn);assert len(all_calls)==2 and len(v.calls)==1
(H/'lexical-provenance.json').write_text(json.dumps(dict(sourcePath=str(normal),sourceSha256=sha(normal),lexicalCalls=1,nestedCallsUnchanged=1,onlyASTRead=True),indent=2)+'\n')
(H/'productive-clock-provenance.json').write_text(json.dumps(dict(scope=config['scope'],changes=changes,parentControllerFreeze=sha(O/'freeze.json'),parentSourceFreeze=sha(P/'freeze.json'),sourceFreeze=sha(S/'freeze.json'),metadataBuilderPath=str(Path(__file__).resolve()),metadataBuilderSha256=sha(Path(__file__)),configurationPath=str(config_path),configurationSha256=sha(config_path)),indent=2)+'\n')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
    info=p.lstat();assert not p.is_symlink()and p.resolve(strict=True)==p
    row=dict(stat=[getattr(info,k)for k in FIELDS])
    if p.is_file():row['sha256']=sha(p)
    assert row['stat']==[getattr(p.lstat(),k)for k in FIELDS];return row
old_pins=json.loads((O/'immutable-source-pins.json').read_text());pins={name:pin(Path(name))for name in old_pins};assert pins==old_pins
for p in (O/'freeze.json',O/'immutable-source-pins.json',*sorted((O/'first1').rglob('*')),config_path,Path(__file__).resolve()):pins[str(p)]=pin(p)
for relative in source_files:pins[str(S/relative)]=pin(S/relative)
pins[str(S/'freeze.json')]=pin(S/'freeze.json')
for p in sorted(H.rglob('*')):
    if p.is_file():pins[str(p)]=pin(p)
(H/'immutable-source-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
rows=[]
for p in sorted(H.rglob('*.py')):
    raw=p.read_bytes();rows.append(dict(path=str(p.relative_to(H)),sha256=sha(p),astSha256=hashlib.sha256(ast.dump(ast.parse(raw),include_attributes=False).encode()).hexdigest()))
(H/'AST-ONLY.json').write_text(json.dumps(dict(status='NO_TARGET_IMPORT_OR_EXECUTION',files=rows),indent=2)+'\n')
files={str(p.relative_to(H)):sha(p)for p in sorted(H.rglob('*'))if p.is_file()and p.name!='freeze.json'}
(H/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_FROZEN_UNRUN_ROOT_REVIEW_REQUIRED',sourceFreezeSha256=sha(S/'freeze.json'),parentControllerFreezeSha256=sha(O/'freeze.json'),files=files),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(sourcePacket=str(S),sourceFreeze=sha(S/'freeze.json'),controllerPacket=str(H),controllerFreeze=sha(H/'freeze.json'),sourcePins=len(pins),pythonFiles=len(rows),targetImported=False,executed=False)))
