"""Historical27/235/factory2 and genuine own4 gate; no unchanged replay."""
import hashlib,json,stat
from pathlib import Path
from component_prerequisite import require as historical,passed
from foreign_publication_rebase import retained_paths
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
OLD=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/emote-callback-window-flow-cache-focused-window-corrected-root-preparation-20261103')
def reviewed_foreign6(mapping):
 mapping=dict(mapping);mapping['currentSourcePins']=dict(mapping['currentSourcePins'])
 for pub in json.loads((Path(__file__).resolve().parent.parent/'actual-foreign6-publications.json').read_text())['publications']:
  assert hashlib.sha256(Path(pub['path']).read_bytes()).hexdigest()==pub['sha256']
  for row in pub['files']:
   assert mapping['currentSourcePins'].get(row['path'])==row['baseSha256'];mapping['currentSourcePins'][row['path']]=row['sha256']
 return mapping

def require(here,repo,current=None):
 paths=historical(OLD/'window1',repo,current)+retained_paths()
 pins={}
 for pinmap in ('actual-causal-profile-pins.json','actual-current747-input-pins.json'):pins.update(json.loads((here.parent/pinmap).read_text()))
 for name,expected in pins.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();row=dict(stat=[getattr(a,k)for k in F]);assert stat.S_ISDIR(a.st_mode)or stat.S_ISREG(a.st_mode)
  if stat.S_ISREG(a.st_mode):row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert row==expected and row['stat']==[getattr(p.lstat(),k)for k in F];paths.append(p)
 for stage_name,expected_exit in (('round1',0),('literal1',1)):
  stage=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/emote-current747-constructor-foreign53-final-root-preparation-20261103')/stage_name;report=json.loads((stage/'root-run-first/report.json').read_text());assert report['exitCode']==expected_exit and all(report[k]for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged'))and not report['remainingOwnedProcesses']
 if here.name in ('remaining3','window1','profile1'):
  first=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/emote-current-constructor-own4-foreign5-window-hold-root-preparation-20261103/first1');ids=passed(first,1);assert ids==json.loads((here.parent/'own4-cases.json').read_text())[:1]
  if current is not None:assert reviewed_foreign6(json.loads((first/'root-run-first/root-source-map.json').read_text()))==current
  frozen=set(json.loads((first/'freeze.json').read_text())['files'])|{'freeze.json'}
  paths += [p for p in first.rglob('*')if str(p.relative_to(first))not in frozen]
 if here.name in ('window1','profile1'):
  remaining=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/emote-current-constructor-own4-foreign5-window-hold-root-preparation-20261103/remaining3');ids=passed(remaining,3);assert ids==json.loads((here.parent/'own4-cases.json').read_text())[1:]
  if current is not None:assert reviewed_foreign6(json.loads((remaining/'root-run-first/root-source-map.json').read_text()))==current
  frozen=set(json.loads((remaining/'freeze.json').read_text())['files'])|{'freeze.json'}
  paths += [p for p in remaining.rglob('*')if str(p.relative_to(remaining))not in frozen]
 clearance=json.loads((here.parent/'actual-window-clearance.json').read_text());a=Path(clearance['avatarErrorStage']);run=Path(clearance['avatarRunRoot']);report=json.loads((a/'closedNative1-report.json').read_text())
 assert hashlib.sha256((a/'closedNative1-report.json').read_bytes()).hexdigest()==clearance['avatarReportSha256']
 assert report['exitCode']==1 and report['originalFiles']==164 and all(report[k]for k in ('allPinsEqual','postStopCensusesQualified','postStopOriginalCensusesEqual','priorOriginalCensusesUnchanged','publicationReadyMapUnchanged'))and report['ownedProcessesBeforeCensuses']==report['remainingOwnedProcesses']==[]
 assert json.loads((a/'closedNative1-source-before.json').read_text())==json.loads((a/'closedNative1-source-after.json').read_text())
 assert json.loads((a/'closedNative1-originals-first.json').read_text())==json.loads((a/'closedNative1-originals-second.json').read_text())
 before=json.loads((a/'closedNative1-prior-originals-before.json').read_text());assert before==json.loads((a/'closedNative1-prior-originals-first.json').read_text())==json.loads((a/'closedNative1-prior-originals-second.json').read_text())
 result=json.loads((run/'selected-result.json').read_text());assert result['successful']is False and result['testsRun']==1 and result['remainingNewThreads']==result['remainingNewThreadsBeforeCensuses']==[] and result['originalCensusesEqual']and result['fixtureAliasesRestored']and not result['sdkExecuted']
 stops=[json.loads(line)for line in (run/'case-stop-receipts.jsonl').read_text().splitlines()if line];assert len(stops)==1 and stops[0]['caseSuccessful']is False and stops[0]['allKnownNodeProcessesGone']and stops[0]['allOriginalStreamsClosed']
 for name,expected in json.loads((here.parent/'actual-stopped-avatar-normal-error-pins.json').read_text()).items():
  p=Path(name);assert p.resolve(strict=True)==p;info=p.lstat();row=dict(stat=[getattr(info,k)for k in F]);assert stat.S_ISDIR(info.st_mode)or stat.S_ISREG(info.st_mode)
  if stat.S_ISREG(info.st_mode):row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert row==expected and row['stat']==[getattr(p.lstat(),k)for k in F];paths.append(p)
 for process in (report['runnerBinding'],report['taskBinding']):
  try:row=Path('/proc',str(process['pid']),'stat').read_text().rsplit(') ',1)[1].split()
  except(FileNotFoundError,ProcessLookupError):row=None
  assert row is None or int(row[19])!=process['startTicks']
 timeout=Path(json.loads((here/'input-plan.json').read_text())['actualWindowStage']);out=timeout/'root-run-first';report=json.loads((out/'report.json').read_text())
 assert report['exitCode']==124 and report['retainedFiles']==747 and all(report[k]for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged'))and not report['remainingOwnedProcesses']
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text())
 from component_prerequisite import exited
 exited(out)
 if current is not None:assert reviewed_foreign6(json.loads((out/'root-source-map.json').read_text()))==current
 for name,expected in json.loads((here.parent/'actual-e89-window-timeout-pins.json').read_text()).items():
  p=Path(name);assert p.resolve(strict=True)==p;info=p.lstat();row=dict(stat=[getattr(info,k)for k in F]);assert stat.S_ISDIR(info.st_mode)or stat.S_ISREG(info.st_mode)
  if stat.S_ISREG(info.st_mode):row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert row==expected and row['stat']==[getattr(p.lstat(),k)for k in F];paths.append(p)
 return paths
