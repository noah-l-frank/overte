"""Exact World Source clock memo25 selection; no discovery/native execution."""
from pathlib import Path
import json,os,stat,sys,tempfile,threading,types,unittest
from importlib.machinery import PathFinder
from run_metadata import HERE,REPO,pin,proc,publication,save,sha,sources,registry_original,validate_frozen
assert len(sys.argv)==2 and sys.argv[1]=='projection12'
kind=sys.argv[1];plan=validate_frozen();selected=plan['suites'][kind];publication()
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/(kind+'-publication-ready-source-map.json');assert ready.is_file(),'Root must refresh after source publication'
runroot=Path(os.environ['OVERTE_WORLD_SOURCE_CLOCK_MEMO_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs'/kind) and runroot!=HERE/'runs'/kind
info=runroot.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
temporary=Path(os.environ['TMPDIR']).resolve(strict=True)
assert temporary==runroot/'temporary' and Path(tempfile.gettempdir())==temporary
info=temporary.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
assert not any(temporary.iterdir()) and not (runroot/'selected-result.json').exists()
save(runroot/'runner-process-binding.json',proc(os.getpid()))
config=json.loads((HERE/'source-root-final-map.json').read_text())
approved=json.loads(ready.read_text());ready_pin=pin(ready)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
assert approved['broadSourceRoots']==plan['broadSourceRoots']
root=REPO.stat();assert approved['worktreeRoot']==str(REPO) and approved['rootIdentity']==dict(st_dev=root.st_dev,st_ino=root.st_ino)
source_before=sources(plan);assert source_before==approved['sourcePins'],'Current full Source membership/bytes differ from after-publication map'
assert 'interface/src/main.cpp' in source_before and approved['registry']==registry_original()
for row in config['modules'].values():assert row['path'] in source_before

def spec_without_import(name):
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:assert search is not None,name
    return spec

def preimport_source_roots():
    top_names={name.split('.')[0] for name in config['packageRoots']}
    assert not any(name.split('.')[0] in top_names for name in sys.modules),'Target imported before source preflight'
    expected=[str(REPO/name) for name in config['orderedRoots']];remaining=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==REPO or REPO in path.parents:continue
        if str(path) not in remaining:remaining.append(str(path))
    sys.path[:]=expected+remaining
    for name,relative in config['packageRoots'].items():
        spec=spec_without_import(name)
        assert [str(Path(path).resolve()) for path in spec.submodule_search_locations or ()]==[str(REPO/relative)],name
    actual={}
    for name,row in config['modules'].items():
        spec=spec_without_import(name);assert spec.origin is not None,name
        path=Path(spec.origin).resolve(strict=True)
        assert path==REPO/row['path'] and sha(path)==approved['sourcePins'][row['path']]['sha256'],name
        actual[name]=str(path)
    save(runroot/'preimport-source-map-actual.json',dict(orderedRoots=expected,modules=actual))
threads_before=set(threading.enumerate())
process_before_import=proc(os.getpid())
def current_group_processes():
    values=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        value=proc(int(path.name))
        if value is not None and (value['session']==process_before_import['session'] or value['processGroup']==process_before_import['processGroup']):values.append(value)
    return values
process_baseline={(row['pid'],row['startTicks']) for row in current_group_processes()}
save(runroot/'processes-before-target-imports.json',current_group_processes())
def remaining_children():
    return [row for row in current_group_processes() if (row['pid'],row['startTicks']) not in process_baseline]
preimport_source_roots()
from ios.self_tests import test_ios_world_web_snapshot_parts as parts_fixture
from ios.self_tests import test_ios_world_web_source_clock_query_memo as memo_fixture
fixture_modules=[parts_fixture]
from ios.self_tests.retained_host_roots import retain_owned_root
real_td=tempfile.TemporaryDirectory;retained=[];objects=[]
def retained_directory(*args,**kwargs):
    directory=real_td(*args,**kwargs);root=Path(directory.name)
    assert root.is_relative_to(temporary)
    root=retain_owned_root(directory,expected_root=root)
    retained.append(str(root));objects.append(directory)
    save(runroot/'created-original-roots.json',retained)
    print('RETAINED_ACTUAL_WORLD_SOURCE_CLOCK_MEMO_ROOT',root,flush=True)
    return directory
aliases=[(module,module.tempfile) for module in fixture_modules]
# These actual selected producers start no Node processes. Only the new
# audit countercase starts one owned interpreter; preserve its exact close.
node_aliases=[];node_children=[];audit_children=[]
original_audit_subprocess=memo_fixture.subprocess
def observed_audit_popen(*args,**kwargs):
    child=original_audit_subprocess.Popen(*args,**kwargs)
    audit_children.append((child,proc(child.pid),'isolated-marshal-audit-child'))
    return child
memo_fixture.subprocess=types.SimpleNamespace(Popen=observed_audit_popen,PIPE=original_audit_subprocess.PIPE)
result=None;actual_ids=[]

class ImmediateResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.error_serial=0
    def report_exception(self,test,error,kind):
        import traceback
        # Preserve the original traceback immediately, BEFORE any optional
        # metadata diagnostic. Never capture generic locals or configuration.
        text=''.join(traceback.format_exception(*error))
        pending=[error[1]];seen=set();chain=[]
        while pending and len(chain)<64:
            actual=pending.pop()
            if id(actual) in seen:continue
            seen.add(id(actual));chain.append(dict(type=type(actual).__name__,module=type(actual).__module__,
                traceback=''.join(traceback.format_exception(type(actual),actual,actual.__traceback__,chain=False)),suppressContext=actual.__suppress_context__))
            for linked in (actual.__context__,actual.__cause__):
                if linked is not None:pending.append(linked)
        self.error_serial+=1
        path=runroot/('explicit-original-exception-chain-'+format(self.error_serial,'06d')+'.json')
        descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(descriptor,'w') as output:
            output.write(json.dumps(dict(testId=test.id(),event=kind,exceptions=chain),indent=2,sort_keys=True)+'\n')
            output.flush();os.fsync(output.fileno())
        self.stream.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text)
        self.stream.flush()
        descriptor=os.open(runroot/'immediate-exceptions.log',os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
        with os.fdopen(descriptor,'a') as output:
            output.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text);output.flush();os.fsync(output.fileno())
    def addError(self,test,error):
        super().addError(test,error);self.report_exception(test,error,'ERROR')
    def addFailure(self,test,error):
        super().addFailure(test,error);self.report_exception(test,error,'FAILURE')
    def addSubTest(self,test,subtest,error):
        super().addSubTest(test,subtest,error)
        if error is not None:self.report_exception(subtest,error,'SUBTEST_ERROR')

try:
    for module,original in aliases:
        assert original is tempfile;module.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_directory)
    ids=selected['caseIds'];assert len(ids)==len(set(ids))==selected['count']
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for child in value:yield from flatten(child)
        else:yield value
    actual_ids=[test.id() for test in flatten(suite)]
    assert not loader.errors and actual_ids==ids and suite.countTestCases()==selected['count'],(loader.errors,actual_ids)
    save(runroot/'selected-ids-actual.json',actual_ids);print('ACTUAL_SELECTED_IDS',json.dumps(actual_ids),flush=True)
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=ImmediateResult).run(suite)
    assert result.testsRun==selected['count'] and not result.skipped,'All exact cases must execute without skip'
    if result.wasSuccessful():assert len(retained)==selected['expectedRetainedRootsNotProof'],'Unexpected actual root count'
finally:
    for module,original in aliases:module.tempfile=original
    memo_fixture.subprocess=original_audit_subprocess
    assert tempfile.TemporaryDirectory is real_td and all(module.tempfile is original for module,original in aliases)
    imported={}
    for name,module in tuple(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if file is not None:
            path=Path(file).resolve()
            if REPO in path.parents:
                relative=str(path.relative_to(REPO));assert relative in source_before,(name,relative)
                imported[name]=relative
    save(runroot/'actual-imported-local-sources.json',imported)
    assert source_before==sources(plan) and pin(ready)==ready_pin,'Full Source/launcher/map membership changed'
    assert registry_original()==approved['registry'],'Actual registry or foreign WIP changed during World Source selection'
    def census():return {str(path.relative_to(temporary)):pin(path) for path in (temporary,*sorted(temporary.rglob('*')))}
    remaining_before=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
    nodes=[]
    for child,binding,producer in node_children:
        nodes.append(dict(binding=binding,producer=producer,exitCode=child.poll(),
            stdinClosed=child.stdin.closed,stdoutClosed=child.stdout.closed,stderrClosed=child.stderr.closed))
    save(runroot/'actual-node-original-close-observations.json',nodes)
    audits=[]
    for child,binding,producer in audit_children:
        audits.append(dict(binding=binding,producer=producer,exitCode=child.poll(),
            stdoutClosed=child.stdout.closed,stderrClosed=child.stderr.closed))
    save(runroot/'actual-isolated-audit-child-close-observations.json',audits)
    audit_close_complete=len(audits)==selected['expectedAuditChildrenNotProof'] and all(row['binding'] is not None and row['exitCode']==0 and row['stdoutClosed'] and row['stderrClosed'] for row in audits)
    processes_before_censuses=remaining_children()
    first=census();second=census();assert first==second,'Post-test originals changed'
    processes_after_censuses=remaining_children()
    save(runroot/'selected-originals-first.json',first);save(runroot/'selected-originals-second.json',second)
    remaining=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
    selection_complete=result is not None and result.testsRun==selected['count'] and not result.skipped
    node_close_complete=len(nodes)==selected['expectedNodeChildrenNotProof'] and all(row['binding'] is not None and row['exitCode']==0 and row['stdinClosed'] and row['stdoutClosed'] and row['stderrClosed'] for row in nodes)
    report=dict(kind=kind,testsRun=None if result is None else result.testsRun,selectedIds=actual_ids,
        successful=result is not None and result.wasSuccessful() and selection_complete and node_close_complete and audit_close_complete and not remaining_before and not remaining and not processes_before_censuses and not processes_after_censuses,skipped=[] if result is None else result.skipped,
        retainedTemporaryDirectoryRoots=retained,fixtureAliasesRestored=True,nodeProducerAliasesRestored=all(module.subprocess is original for module,original in node_aliases),originalNodeCloseObservations=nodes,actualAuditChildCloseObservations=audits,auditChildAliasRestored=memo_fixture.subprocess is original_audit_subprocess,sourceLauncherPinsUnchanged=True,
        originalCensusesEqual=True,remainingOwnedChildrenBeforeCensuses=processes_before_censuses,remainingOwnedChildrenAfterCensuses=processes_after_censuses,remainingNewThreadsBeforeCensuses=remaining_before,remainingNewThreads=remaining,nativeCompiled=False,sdkExecuted=False,
        deviceQualified=False,wholeWorldQualified=False,worldV7Qualified=False,nativeDeviceQualified=False)
    save(runroot/'selected-result.json',report);print('ACTUAL_RESULT',json.dumps(report),flush=True)
    assert not remaining_before and not remaining,'New fixture/worker/listener thread remains live around censuses'
    assert not processes_before_censuses and not processes_after_censuses,'Actual Node/child process remains live around censuses'
    if result is not None and result.wasSuccessful():
        assert audit_close_complete,'Owned audit child did not exit/close cleanly'
        assert len(nodes)==selected['expectedNodeChildrenNotProof']
        assert all(row['binding'] is not None and row['exitCode']==0 and row['stdinClosed'] and row['stdoutClosed'] and row['stderrClosed'] for row in nodes),'Existing Node close did not actually finish cleanly'
sys.exit(0 if result is not None and result.wasSuccessful() else 1)
