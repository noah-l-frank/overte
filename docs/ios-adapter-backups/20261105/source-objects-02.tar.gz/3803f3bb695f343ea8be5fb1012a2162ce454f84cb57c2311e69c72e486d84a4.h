// Copyright 2026 Overte contributors.
// SPDX-License-Identifier: Apache-2.0
#pragma once

// Default-off Audio ownership of three fixed actual native writer outputs. No arbitrary
// pathname, expected bytes, marker namespace, OS death or SDK absence API.
#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(Q_OS_IOS) && defined(OVERTE_E2E_VOICE_TESTS)
#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMutex>
#include <QMutexLocker>
#include <QRegularExpression>
#include <QUuid>
#include <QVariantMap>
#include <array>
#include <cerrno>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace overte::e2e {
enum class AudioReplyKind { Passive=0, Received=1, Clock=2 };

class IOSAudioResponseFileOwnership;

class AudioReplyFileSlot {
public:
    static bool requested() {
        const auto args=QCoreApplication::arguments();
        return QCoreApplication::instance() && args.contains("--testScript") && args.contains("--e2e-audio-response-file-ownership");
    }
    static bool enabled() {
        const auto args=QCoreApplication::arguments();
        return requested() && !args.contains("--e2e-emote-response-file-ownership") && !args.contains("--emote-palette-observe");
    }
    ~AudioReplyFileSlot() {
        // Process teardown closes only our descriptors; it does not delete an
        // unproved/unknown native file or manufacture a retirement original.
        if (_pending>=0) {::close(_pending);} if (_file>=0) {::close(_file);} if (_parent>=0) {::close(_parent);}
    }
    bool readAllowed() {
        QMutexLocker locker(&_mutex);
        if (_file>=0 && !current()) {_unknown=true;}
        return enabled() && !_unknown && !_issued && _pending<0;
    }
    bool begin(const QString& directory,int writer,const QByteArray& raw,const QVariantMap& palette) {
        QMutexLocker locker(&_mutex);
        if (!enabled() || _unknown || _issued || _pending>=0 || writer<0 || raw!=QJsonDocument::fromVariant(palette).toJson() || raw.isEmpty() || raw.size()>1048576 || _attempt>=1000000000) {return false;}
        const auto request=palette.value(_kind==AudioReplyKind::Clock ? "requestId" : "commandId").toString();
        if (palette.value("processId").toLongLong()!=::getpid()
                || !QRegularExpression("\\Aios-[0-9a-f]{32}\\z").match(request).hasMatch()) {return false;}
        const auto root=QDir::cleanPath(QDir(directory).absolutePath());const QFileInfo info(root);
        if (info.canonicalFilePath()!=root) {return false;}
        const int opened=::open(QFile::encodeName(root).constData(),O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
        struct stat parent,temp;
        if (opened<0 || ::fstat(opened,&parent) || !privateDirectory(parent) || !sameRoot(opened,root)
                || ::fstat(writer,&temp) || !S_ISREG(temp.st_mode) || temp.st_uid!=::geteuid()
                || (temp.st_mode&0777)!=0600 || temp.st_size!=raw.size() || temp.st_nlink>1) {
            if (opened>=0) {::close(opened);} return false;
        }
        if (_parent>=0 && (_root!=root || !sameIdentity(parent,_parentIdentity) || !current())) {_unknown=true;::close(opened);return false;}
        if (_parent<0) {
            struct stat foreign;
            if (!::fstatat(opened,filename(),&foreign,AT_SYMLINK_NOFOLLOW) || errno!=ENOENT) {
                // An older/foreign native output is not this lifetime's file.
                // The new opt-in cannot overwrite it into claimed ownership.
                _unknown=true;::close(opened);return false;
            }
            _parent=opened;_root=root;_parentIdentity=parent;
        } else {::close(opened);}
        // A genuine duplicate of the real QSaveFile FD, before commit can
        // close it. A later failed/uncertain commit retains this duty.
        _pending=::fcntl(writer,F_DUPFD_CLOEXEC,0);
        if (_pending<0) {return false;}
        ++_attempt;_pendingRaw=raw;_pendingPalette=palette;_pendingIdentity=temp;
        return true;
    }
    void committed(bool returned) {
        QMutexLocker locker(&_mutex);
        if (_pending<0) {_unknown=true;return;}
        if (!returned || !sameRoot(_parent,_root)) {_unknown=true;return;}
        struct stat written,path;
        if (::fstat(_pending,&written) || !privateFile(written) || !sameIdentity(written,_pendingIdentity)
                || written.st_size!=_pendingRaw.size() || ::fstatat(_parent,filename(),&path,AT_SYMLINK_NOFOLLOW)
                || !sameStat(written,path)) {_unknown=true;return;}
        const int readable=::openat(_parent,filename(),O_RDONLY|O_NOFOLLOW|O_CLOEXEC|O_NONBLOCK);
        struct stat opened;
        if (readable<0 || ::fstat(readable,&opened) || !sameStat(opened,written) || !bytes(readable,written,_pendingRaw)) {
            if (readable>=0) {::close(readable);} _unknown=true;return;
        }
        const int previousFile=_file;_file=-1;
        if (previousFile>=0 && ::close(previousFile)) {_unknown=true;::close(readable);return;}
        _file=readable;_published=written;_raw=_pendingRaw;_palette=_pendingPalette;_generation=_attempt;
        const int committedFD=_pending;_pending=-1;
        if (::close(committedFD)) {_unknown=true;return;}
        _pendingRaw.clear();_pendingPalette.clear();
    }
    bool retire(const QString& command,const QString& run,const QString& previousRequest,const QByteArray& actualSha256) {
        QMutexLocker locker(&_mutex);
        if (!enabled() || _issued) {return false;}
        // Latch BEFORE validation/mutation: an uncertain or rejected request
        // cannot reopen publication or authorize a second unlink.
        _issued=true;
        if (_unknown || _pending>=0 || _file<0
                || !QRegularExpression("\\Aios-[0-9a-f]{32}\\z").match(command).hasMatch()
                || (_kind!=AudioReplyKind::Clock && _palette.value("runId").toString()!=run)
                || previousRequest!=_palette.value(_kind==AudioReplyKind::Clock ? "requestId" : "commandId").toString()
                || actualSha256!=QCryptographicHash::hash(_raw,QCryptographicHash::Sha256).toHex()
                || !current()) {_unknown=true;return false;}
        if (::unlinkat(_parent,filename(),0) || ::fsync(_parent)) {_unknown=true;return false;}
        _retired=true;
        if (!retiredCurrent()) {_unknown=true;return false;}
        // No saveObject, result file, output original or ACK authority follows.
        // Independent AFC absence and real process quiet originals are needed.
        const int file=_file,parent=_parent;_file=_parent=-1;
        const bool fileClosed=::close(file)==0;
        const bool parentClosed=::close(parent)==0;
        const bool closed=fileClosed && parentClosed;
        if (!closed) {_unknown=true;} return closed;
    }
private:
    friend class IOSAudioResponseFileOwnership;
    explicit AudioReplyFileSlot(AudioReplyKind kind):_kind(kind),_instance(QUuid::createUuid().toString(QUuid::Id128)) {}
    const char* filename() const {
        switch (_kind) {
            case AudioReplyKind::Passive:return "feature-ios-audio-passive-capture.json";
            case AudioReplyKind::Received:return "feature-ios-audio-received-mixer.json";
            case AudioReplyKind::Clock:return "feature-native-observation.json";
        }
        return nullptr;
    }
    static bool hex(const QString& s) {return QRegularExpression("\\A[0-9a-f]{32}\\z").match(s).hasMatch();}
    static bool privateDirectory(const struct stat& s) {return S_ISDIR(s.st_mode) && s.st_uid==::geteuid() && (s.st_mode&0777)==0700;}
    static bool privateFile(const struct stat& s) {return S_ISREG(s.st_mode) && s.st_uid==::geteuid() && (s.st_mode&0777)==0600 && s.st_nlink==1;}
    static bool sameIdentity(const struct stat& a,const struct stat& b) {return a.st_dev==b.st_dev && a.st_ino==b.st_ino && a.st_uid==b.st_uid && a.st_gid==b.st_gid && a.st_mode==b.st_mode;}
    static bool sameStat(const struct stat& a,const struct stat& b) {
        return sameIdentity(a,b) && a.st_size==b.st_size && a.st_nlink==b.st_nlink
            && a.st_mtimespec.tv_sec==b.st_mtimespec.tv_sec && a.st_mtimespec.tv_nsec==b.st_mtimespec.tv_nsec
            && a.st_ctimespec.tv_sec==b.st_ctimespec.tv_sec && a.st_ctimespec.tv_nsec==b.st_ctimespec.tv_nsec;
    }
    static bool sameRoot(int fd,const QString& root) {
        struct stat opened,path;
        return fd>=0 && !::fstat(fd,&opened) && privateDirectory(opened)
            && !::lstat(QFile::encodeName(root).constData(),&path) && sameIdentity(opened,path)
            && QFileInfo(root).canonicalFilePath()==root;
    }
    static bool bytes(int fd,const struct stat& expected,const QByteArray& raw) {
        struct stat before,after;
        if (::fstat(fd,&before) || !sameStat(before,expected)) {return false;}
        QByteArray actual(raw.size()+1,'\0');qint64 used=0;
        while (used<actual.size()) {
            const auto count=::pread(fd,actual.data()+used,static_cast<size_t>(actual.size()-used),used);
            if (count<0 && errno==EINTR) {continue;}
            if (count<0) {return false;} if (!count) {break;} used+=count;
        }
        actual.resize(used);
        return actual==raw && !::fstat(fd,&after) && sameStat(before,after);
    }
    bool current() const {
        struct stat actual,path,parent;
        return _file>=0 && !::fstat(_parent,&parent) && sameIdentity(parent,_parentIdentity) && sameRoot(_parent,_root) && !::fstat(_file,&actual) && privateFile(actual)
            && sameStat(actual,_published) && !::fstatat(_parent,filename(),&path,AT_SYMLINK_NOFOLLOW)
            && sameStat(actual,path) && bytes(_file,actual,_raw);
    }
    bool retiredCurrent() {
        struct stat actual,path,parent;
        if (_file<0 || ::fstat(_parent,&parent) || !sameIdentity(parent,_parentIdentity) || !sameRoot(_parent,_root) || ::fstat(_file,&actual) || !sameIdentity(actual,_published)
                || actual.st_size!=_published.st_size || actual.st_nlink!=0 || !bytes(_file,actual,_raw)) {return false;}
        if (!::fstatat(_parent,filename(),&path,AT_SYMLINK_NOFOLLOW) || errno!=ENOENT) {return false;}
        _after=actual;return true;
    }
    const AudioReplyKind _kind;QMutex _mutex;QString _instance,_root;int _parent{-1},_file{-1},_pending{-1};
    struct stat _parentIdentity{},_published{},_pendingIdentity{},_after{};
    quint64 _attempt{0},_generation{0};bool _unknown{false},_issued{false},_retired{false};
    QByteArray _raw,_pendingRaw;QVariantMap _palette,_pendingPalette;
};
// One GUI/source lifetime; no pathname argument can select another output.
class IOSAudioResponseFileOwnership {
public:
    static IOSAudioResponseFileOwnership& instance() {static IOSAudioResponseFileOwnership owner;return owner;}
    static bool requested() {return AudioReplyFileSlot::requested();}
    static bool enabled() {return AudioReplyFileSlot::enabled();}
    static bool selected(const QString& name) {
        return name=="feature-ios-audio-passive-capture.json" || name=="feature-ios-audio-received-mixer.json" || name=="feature-native-observation.json";
    }
    bool readAllowed() {
        QMutexLocker locker(&_mutex);
        return enabled() && !_retiring && _passive.readAllowed() && _received.readAllowed() && _clock.readAllowed();
    }
    bool begin(const QString& filename,const QString& directory,int writer,const QByteArray& raw,const QVariantMap& original) {
        QMutexLocker locker(&_mutex);
        if (!enabled() || _retiring || !selected(filename) || !_passive.readAllowed() || !_received.readAllowed() || !_clock.readAllowed()) {return false;}
        const auto root=QDir::cleanPath(QDir(directory).absolutePath());
        struct stat actualRoot;
        if (!_root.isEmpty() && (_root!=root || ::lstat(QFile::encodeName(root).constData(),&actualRoot)
                || !AudioReplyFileSlot::privateDirectory(actualRoot) || !AudioReplyFileSlot::sameIdentity(actualRoot,_rootIdentity)
                || QFileInfo(root).canonicalFilePath()!=root)) {_retiring=true;return false;}
        const bool returned=slot(filename).begin(directory,writer,raw,original);
        if (returned) {
            if (_root.isEmpty()) {_rootIdentity=slot(filename)._parentIdentity;}
            _root=root;
        }
        return returned;
    }
    void committed(const QString& filename,bool returned) {
        QMutexLocker locker(&_mutex);
        if (!selected(filename)) {_retiring=true;return;}
        slot(filename).committed(returned);
    }
    bool retire(const QString& filename,const QString& command,const QString& run,const QString& lastReply,const QByteArray& rawSha) {
        QMutexLocker locker(&_mutex);
        // The first actual command permanently closes all native reply/query
        // publication before any slot validation/unlink. Remaining slots may
        // receive only their own once-only retirement command.
        _retiring=true;
        if (!enabled() || !selected(filename)) {return false;}
        return slot(filename).retire(command,run,lastReply,rawSha);
    }
private:
    IOSAudioResponseFileOwnership():_passive(AudioReplyKind::Passive),_received(AudioReplyKind::Received),_clock(AudioReplyKind::Clock) {}
    AudioReplyFileSlot& slot(const QString& name) {
        if (name=="feature-ios-audio-passive-capture.json") {return _passive;}
        if (name=="feature-ios-audio-received-mixer.json") {return _received;}
        return _clock; // Callers first require the exact finite selection.
    }
    QMutex _mutex;QString _root;struct stat _rootIdentity{};bool _retiring{false};
    AudioReplyFileSlot _passive,_received,_clock;
};
} // namespace overte::e2e
#endif
