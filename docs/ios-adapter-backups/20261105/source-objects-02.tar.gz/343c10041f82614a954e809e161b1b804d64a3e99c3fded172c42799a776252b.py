"""Canonical commitments to independently owned Lifecycle Actor originals.

The coordinator authenticates its existing Actor token and journal ordering.
This family is not the default Lifecycle UI state or a device-truth validator.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from .contract import exact,identifier
from adapters.native_feature_observation import integer,need
from adapters.native_avatar_receive import sha
from adapters.normal_feature_state import context

PROFILE='lifecycle-received-actor-original-v1'
FIELDS={'iosLifecycleActorSampleVersion','profile','binding','role','witnessIndex','ownerSha256','packetOwnerSha256',
    'nativeOriginalSha256','phaseBeforeSha256','phaseAfterSha256','bodyCollectionSha256','receivedRootsSha256',
    'bodyLifetimesSha256','receiveInstance','receiveSequence'}


def facts(value,*,captured):
    exact(value,FIELDS);need(type(value['iosLifecycleActorSampleVersion'])is int and value['iosLifecycleActorSampleVersion']==1
        and value['profile']==PROFILE and value['role']=='actor'and integer(value['witnessIndex'],1,128))
    context(value['binding']);identifier(value['receiveInstance']);need(integer(value['receiveSequence'],1,1000000000))
    for key in FIELDS-{'iosLifecycleActorSampleVersion','profile','binding','role','witnessIndex','receiveInstance','receiveSequence'}:need(sha(value[key]))
    return value
