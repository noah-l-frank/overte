"""Genuine -S -B -m package entry retained by original spawn.prepare."""
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent.parent
assert sys.flags.no_site==1 and sys.dont_write_bytecode and sys.flags.optimize==0
assert __spec__.name=='tablet_mp_variant_utility.__main__'
assert tuple(sys.orig_argv).count('-m')==1
sys.path.insert(0,str(HERE))
from mp_runner import main
if __name__=='__main__':raise SystemExit(main())
