"""One admission's topological ORIGINAL validation; no decoded/native cache.

Every dependency lookup still reads and validates the actual original frame,
manifest, bytes/hash/inode and typed journal envelope. Only repeated semantic
validation of an identical already validated LOCAL dependency may be elided.
External-parent proofs and all their transitive dependants remain independent.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from copy import deepcopy
import builtins,dis,importlib,inspect,json,re,sys,threading,time,types,wave
from contextvars import ContextVar
from pathlib import Path
from adapters.native_clock_join import digest
from adapters.native_feature_observation import need
from adapters.script_feature.history import same
from ios.adapters.emote_original_lease import EmoteOriginalLease

LOCAL_PROOFS=frozenset(('reply','chunk','birth','snapshot','once-probe-intent','once-probe','once-intent','once-reply'))
PURE_READERS=('ios.adapters.audio_passive_capture_source','ios.adapters.audio_once_custody','ios.adapters.audio_once_cue_source',
              'ios.adapters.audio_once_primary','ios.adapters.audio_once_window')

class UnsupportedCodec(TypeError):pass

PROJECT=('adapters.','ios.adapters.','feature_journeys.')
PURE_STDLIB=('json','json.decoder','json.encoder','json.scanner','base64','wave')


class ExactObject:
    """Strong identity, including code objects whose == is structural."""
    def __init__(self,value):self.value=value
    def __eq__(self,other):return type(other)is ExactObject and self.value is other.value
    def __hash__(self):return id(self.value)


def project_function(value):
    parts=Path(value.__code__.co_filename).parts
    return value.__module__.startswith(PROJECT)or any(parts[index:index+2]==('tests','device')for index in range(len(parts)-1))


def value_token(value,depth=0,*,controls=None,path='literal'):
    """Read every literal afresh; control edges do not consume literal depth.

    Control identities are independently sealed by ControlGraph. This is not
    an alias cache: all containers are traversed again on every guard, in
    their actual order, and an unknown control node cannot enter a guard.
    """
    if depth>24:raise UnsupportedCodec('literal-depth')
    kind=type(value)
    if value is None or kind in (bool,int,float,str,bytes):return (kind,value)
    if kind in (tuple,list,set,frozenset):
        return (kind,tuple(value_token(v,depth+1,controls=controls,path=path+'['+str(i)+']')for i,v in enumerate(value)))
    if kind is dict:
        return (kind,tuple((value_token(k,depth+1,controls=controls,path=path+'.key['+str(i)+']'),
            value_token(v,depth+1,controls=controls,path=path+'.value['+str(i)+']'))for i,(k,v)in enumerate(value.items())))
    if isinstance(value,Path):return (kind,str(value))
    if controls is not None:return controls.reference(value,path)
    raise UnsupportedCodec(type(value).__module__+'.'+type(value).__qualname__)


class ControlGraph:
    """Strong, finite control nodes; fresh literal shapes at every validation.

    Mark a node BEFORE following its edges. A class/function/default/closure
    cycle is thus an explicit identity edge, never a deeper literal value.
    Each edge's complete current contents are checked independently. No node
    or semantic result survives the enclosing historical admission.
    """
    def __init__(self):
        self.nodes={};self.shapes={};self.paths={};self.reading=False
    def token(self,value,path='literal'):
        return value_token(value,controls=self,path=path)
    def reference(self,value,path):
        key=id(value);known=self.nodes.get(key)
        if known is not None:
            need(known is value);return (type(value),ExactObject(value))
        if self.reading:raise UnsupportedCodec('new-control-during-guard:'+path)
        if len(self.nodes)>=2048:raise UnsupportedCodec('referenced-parser-count')
        self.nodes[key]=value;self.paths[key]=path
        self.shapes[key]=self.shape(value,path)
        return (type(value),ExactObject(value))
    def shape(self,value,path):
        kind=type(value)
        token=lambda v,suffix:self.token(v,path+suffix)
        if isinstance(value,ContextVar):return (kind,token(value.get(),'.current'))
        if kind.__module__=='_json'and kind.__name__=='Scanner':
            return (kind,tuple((key,token(getattr(value,key),'.'+key))for key in
                ('strict','object_hook','object_pairs_hook','parse_float','parse_int','parse_constant')))
        if kind.__module__=='adapters.script_feature.lock'and kind.__name__=='ScriptSourceLock':
            value.assert_held();return (kind,str(value.path),value.timeout,token(value._owner,'.owner'))
        if isinstance(value,re.Pattern):return (kind,value.pattern,value.flags)
        if kind in (json.JSONDecoder,json.JSONEncoder):
            return (kind,tuple((key,token(entry,'.'+key))for key,entry in vars(value).items()if key!='memo'))
        if isinstance(value,(types.MethodDescriptorType,types.ClassMethodDescriptorType,types.WrapperDescriptorType,types.GetSetDescriptorType,types.MemberDescriptorType)):
            return (kind,ExactObject(getattr(value,'__objclass__',None)),value.__name__)
        if isinstance(value,(types.BuiltinFunctionType,types.BuiltinMethodType)):
            receiver=getattr(value,'__self__',None)
            return (kind,('module',ExactObject(receiver))if isinstance(receiver,types.ModuleType)else token(receiver,'.receiver'))
        if isinstance(value,types.FunctionType):
            cells=tuple((name,ExactObject(cell),token(cell.cell_contents,'.closure.'+name))
                for name,cell in zip(value.__code__.co_freevars,value.__closure__ or ()))
            return (kind,ExactObject(value.__code__),token(value.__defaults__,'.defaults'),
                token(value.__kwdefaults__,'.kwdefaults'),cells,token(vars(value),'.attributes'))
        if isinstance(value,(staticmethod,classmethod)):return (kind,token(value.__func__,'.function'))
        if isinstance(value,property):
            return (kind,tuple(token(getattr(value,key),'.'+key)for key in ('fget','fset','fdel')))
        if kind.__module__=='_collections'and kind.__name__=='_tuplegetter':return (kind,)
        if isinstance(value,type):
            if type(value)is not type:raise UnsupportedCodec('reader-metaclass:'+value.__module__+'.'+value.__qualname__)
            mro=tuple(ExactObject(c)for c in value.__mro__)
            if value.__flags__&256:return (kind,mro)
            return (kind,mro,tuple((ExactObject(cls),name,token(entry,'.'+cls.__qualname__+'.'+name))
                for cls in value.__mro__ if not cls.__flags__&256 for name,entry in vars(cls).items()))
        raise UnsupportedCodec(type(value).__module__+'.'+type(value).__qualname__+':'+path)
    def guard(self):
        need(not self.reading);self.reading=True
        try:
            for key,value in self.nodes.items():need(self.shape(value,self.paths[key])==self.shapes[key])
        finally:self.reading=False


def control_implementation():
    """Seal the sealer's literal ports independently of its value tokens."""
    rows=[];namespace=globals()
    for name in ('value_token','project_function','ExactObject','ControlGraph','SemanticFence',
                 'UnsupportedCodec','control_implementation','control_implementation_unchanged',
                 'types','json','re','inspect','Path','ContextVar'):
        value=namespace[name];rows.append((namespace,name,value,getattr(value,'__code__',None)))
        if type(value)is type:
            rows.append((vars(value),None,tuple(vars(value)),None))
            for key,member in vars(value).items():
                rows.append((vars(value),key,member,getattr(member,'__code__',None)))
    for module,names in ((types,('FunctionType','BuiltinFunctionType','BuiltinMethodType','ModuleType',
            'MethodDescriptorType','ClassMethodDescriptorType','WrapperDescriptorType','GetSetDescriptorType','MemberDescriptorType')),
            (json,('JSONDecoder','JSONEncoder')),(re,('Pattern',)),(inspect,('getattr_static',))):
        for name in names:
            value=vars(module)[name];rows.append((vars(module),name,value,getattr(value,'__code__',None)))
    return tuple(rows)


def control_implementation_unchanged(rows):
    for namespace,name,value,code in rows:
        if name is None:
            need(tuple(namespace)==value);continue
        current=namespace.get(name);need(current is value)
        if code is not None:need(current.__code__ is code)


class SemanticFence:
    """Finite referenced parser graph, including nested code and literal aliases.

    No whole transport/SDK namespace is scanned. Unsupported captured state
    disables semantic sharing; it never weakens the ordinary reader.
    """
    ROOTS=('validate_entry','assembled','phase_chain','proof')
    def __init__(self,owner):
        self.bindings=[];self.functions=[];self.seen=set();self.seen_values=set();self.controls=ControlGraph();self.supported=True;self.unsupported=None;self.version=owner.version
        self.implementation=control_implementation()
        try:
            for name in PURE_READERS if owner.version==2 else PURE_READERS[:1]:importlib.import_module(name)
            self.owner_class=self.controls.token(type(owner));self.owner_admit=self.controls.token(owner.admit.__func__)
            self.file_guard=self.controls.token(owner.file_guard.__func__);self.lease_class=self.controls.token(EmoteOriginalLease)
            self.guard_lease_alias=owner.file_guard.__globals__['EmoteOriginalLease']
            for name in ('guard','snapshot','signature','record'):
                method=getattr(EmoteOriginalLease,name);self.follow(getattr(method,'__func__',method))
            for name in self.ROOTS:self.follow(getattr(owner,name).__func__)
            self.json_snapshot=self.json_policy()
            for value in (wave.open,wave.Wave_read,wave._Chunk,json.loads,json.dumps,json.JSONDecoder,json.JSONEncoder):
                if isinstance(value,types.FunctionType):self.follow(value)
                elif isinstance(value,type):
                    for cls in value.__mro__:
                        for entry in cls.__dict__.values():
                            if isinstance(entry,(staticmethod,classmethod)):entry=entry.__func__
                            if isinstance(entry,types.FunctionType):self.follow(entry)
            self.wave_snapshot=tuple((key,self.controls.token(getattr(wave,key)))for key in ('open','Wave_read','_Chunk','_wave_params','Error'))
        except (UnsupportedCodec,AttributeError,KeyError,ValueError)as error:
            self.supported=False;self.unsupported=str(error)
    def json_policy(self):
        decoder=json._default_decoder;encoder=json._default_encoder
        return (self.controls.token(json.loads),self.controls.token(json.dumps),self.controls.token(json.JSONDecoder),self.controls.token(json.JSONEncoder),
                ExactObject(decoder),ExactObject(encoder),tuple((k,self.controls.token(v))for k,v in decoder.__dict__.items()if k!='memo'),
                tuple((k,self.controls.token(v))for k,v in encoder.__dict__.items()))
    def follow_value(self,value,depth=0):
        if depth>24:raise UnsupportedCodec('referenced-value-depth')
        if isinstance(value,(types.FunctionType,type,staticmethod,classmethod,property)):
            key=id(value)
            if key in self.seen_values:return
            self.seen_values.add(key)
        if isinstance(value,(staticmethod,classmethod)):value=value.__func__
        if isinstance(value,property):
            for fn in (value.fget,value.fset,value.fdel):self.follow_value(fn)
            return
        if isinstance(value,types.FunctionType):
            if project_function(value)or value.__module__ in PURE_STDLIB:self.follow(value)
            return
        if isinstance(value,type):
            if type(value)is not type:raise UnsupportedCodec('reader-metaclass:'+value.__module__+'.'+value.__qualname__)
            if value.__flags__&256:return
            for cls in value.__mro__:
                if cls.__flags__&256:continue
                for name,entry in cls.__dict__.items():
                    functions=(entry.fget,entry.fset,entry.fdel)if isinstance(entry,property)else(entry.__func__,)if isinstance(entry,(staticmethod,classmethod))else(entry,)
                    for fn in functions:
                        if not isinstance(fn,types.FunctionType):continue
                        if project_function(fn)or fn.__module__ in PURE_STDLIB or cls.__module__ in PURE_STDLIB:self.follow(fn)
                        else:raise UnsupportedCodec('unfollowed-reader-method:'+value.__module__+'.'+value.__qualname__+'.'+name)
            return
        if type(value)is dict:
            for key,entry in value.items():self.follow_value(key,depth+1);self.follow_value(entry,depth+1)
        elif type(value)in (tuple,list,set,frozenset):
            for entry in value:self.follow_value(entry,depth+1)
    def bind(self,namespace,name,attrs):
        def current():
            value=namespace[name]
            for attr in attrs:value=inspect.getattr_static(value,attr)
            return value
        value=current();token=self.controls.token(value);self.bindings.append((current,token));self.follow_value(value)
    def code_bindings(self,code,namespace):
        instructions=list(dis.get_instructions(code))
        for index,op in enumerate(instructions):
            if op.opname=='LOAD_GLOBAL':
                source=namespace if op.argval in namespace else vars(builtins)
                if op.argval not in source:raise UnsupportedCodec('missing-global:'+str(op.argval))
                attrs=[];offset=index+1
                while offset<len(instructions)and instructions[offset].opname in ('LOAD_ATTR','LOAD_METHOD'):
                    attrs.append(instructions[offset].argval);offset+=1
                value=source[op.argval]
                if isinstance(value,types.ModuleType)and not attrs:raise UnsupportedCodec('whole-module:'+value.__name__)
                self.bind(source,op.argval,tuple(attrs))
            elif op.opname=='IMPORT_NAME':
                # This literal branch is unreachable for version1 archives.
                if self.version==1 and op.argval=='ios.adapters.audio_once_custody':continue
                module=sys.modules.get(op.argval)
                if module is None:raise UnsupportedCodec('unloaded-reader:'+str(op.argval))
                offset=index+1
                while offset<len(instructions)and instructions[offset].opname=='IMPORT_FROM':
                    self.bind(vars(module),instructions[offset].argval,());offset+=2
        for entry in code.co_consts:
            if isinstance(entry,types.CodeType):self.code_bindings(entry,namespace)
    def follow(self,function):
        if function in self.seen:return
        if len(self.seen)>=2048:raise UnsupportedCodec('referenced-parser-count')
        self.seen.add(function);self.functions.append((function,self.controls.token(function)))
        self.code_bindings(function.__code__,function.__globals__)
        for cell in function.__closure__ or ():self.follow_value(cell.cell_contents)
        self.follow_value(function.__defaults__);self.follow_value(function.__kwdefaults__);self.follow_value(vars(function))
    def _guard(self,owner):
        need(self.supported and self.controls.token(type(owner))==self.owner_class and self.controls.token(owner.admit.__func__)==self.owner_admit
            and self.controls.token(owner.file_guard.__func__)==self.file_guard and self.controls.token(EmoteOriginalLease)==self.lease_class
            and owner.file_guard.__globals__['EmoteOriginalLease']is self.guard_lease_alias
            and self.json_policy()==self.json_snapshot
            and tuple((key,self.controls.token(getattr(wave,key)))for key in ('open','Wave_read','_Chunk','_wave_params','Error'))==self.wave_snapshot)
        for function,token in self.functions:need(self.controls.token(function)==token)
        for current,token in self.bindings:need(self.controls.token(current())==token)

    def guard(self,owner):
        try:
            control_implementation_unchanged(self.implementation)
            self.controls.guard();self.controls.reading=True
            try:self._guard(owner)
            finally:self.controls.reading=False
        except (UnsupportedCodec,AttributeError,KeyError,ValueError):need(False)


class OriginalValidationGraph:
    def __init__(self,owner):
        self.owner=owner;self.thread=threading.get_ident();self.previous=owner.previous;self.state=deepcopy(owner.state);self.state_token=value_token(owner.state)
        self.context=(owner.root,deepcopy(owner.binding),owner.run,owner.lease,owner.pid,owner.version,owner.fixture_url,deepcopy(owner.root_identity))
        self.components={key:(journal,journal.files,journal.frame.__func__,journal.frame.__func__.__code__)for key,journal in owner.journals.items()}
        self.lease=EmoteOriginalLease(owner.root,[]);self.fence=SemanticFence(owner);self.enabled=self.fence.supported
        self.raws={};self.queries={};self.value_hashes={};self.tokens=frozenset();self.stack=[];self.epoch=0;self.boundary=time.monotonic()
        self.counts=dict(freshFrames=0,semanticValidations=0,reusedLocalValidations=0,timeInvalidations=0,unsupported=self.fence.unsupported,externalInvalidations=0)
    def guard(self):
        owner=self.owner;need(owner._validation_graph is self and threading.get_ident()==self.thread and owner.previous is self.previous
            and value_token(owner.state)==self.state_token and same(owner.state,self.state)and self.context==(owner.root,owner.binding,owner.run,owner.lease,owner.pid,owner.version,owner.fixture_url,owner.root_identity))
        owner.file_guard()
        for key,(journal,files,function,code)in self.components.items():
            need(owner.journals[key]is journal and journal.files is files and journal.frame.__func__ is function and function.__code__ is code)
        if self.enabled:self.fence.guard(owner)
        now=time.monotonic();need(now>=self.boundary)
        if now-self.boundary>=.05:
            self.lease.guard();self.tokens=frozenset();self.epoch+=1;self.boundary=now;self.counts['timeInvalidations']+=1
    def invalidate(self):
        # Called before ANY owner.bound external authority callback or storage
        # mutation. Already parsed local statuses never cross that boundary.
        self.guard();self.lease.guard();self.tokens=frozenset();self.epoch+=1
        self.boundary=time.monotonic();self.counts['externalInvalidations']+=1
        for row in self.stack:row['children']=False
    def register(self,journal,rows):
        self.guard();need(journal.stream not in self.raws)
        self.raws[journal.stream]=tuple(digest(row)for row in rows)
    @contextmanager
    def node(self,journal,value):
        self.guard();stream=journal.stream;index=value['ordinal'];known=self.raws.get(stream,())
        sourced=1<=index<=len(known)and digest(value)==known[index-1]
        if known and 1<=index<=len(known):need(sourced)
        base=stream in ('native','passive')or stream=='proofs'and value['value'].get('kind')in LOCAL_PROOFS
        row=dict(stream=stream,index=index,wire=digest(value),value=digest(value['value']),eligible=base and sourced,children=True,reused=False)
        self.stack.append(row);self.counts['freshFrames']+=1
        try:yield row
        finally:
            need(self.stack[-1]is row);self.stack.pop()
            if self.stack:self.stack[-1]['children']=self.stack[-1]['children']and row.get('accepted',False)
    def reuse(self,row):
        self.guard()
        if row['stream']=='proofs':
            expected={command:(stream,index,query)for command,(stream,index,query)in self.queries.items()}
            need(same(self.owner._query_index,expected))
        token=(row['stream'],row['index'],row['wire'],self.epoch)
        row['reused']=bool(self.enabled and row['eligible']and token in self.tokens)
        if row['reused']:row['accepted']=True;self.counts['reusedLocalValidations']+=1
        return row['reused']
    def accept(self,row,value):
        self.guard();self.counts['semanticValidations']+=1
        eligible=bool(self.enabled and row['eligible']and row['children']);row['accepted']=eligible
        self.value_hashes[(row['stream'],row['index'])]=row['value']
        if row['stream']in ('native','passive'):
            command=value['value']['commandId'];self.queries[command]=(row['stream'],row['index'],deepcopy(value['value']))
        if eligible:self.tokens=self.tokens|{(row['stream'],row['index'],row['wire'],self.epoch)}
    def finish(self):
        self.guard();need(not self.stack);self.lease.guard()
        # Existing derived owner bookkeeping is independently constructed by
        # admit(); cached decoded proof bodies never supply this graph's data.
        for index,value in self.owner._proof_cache.items():need(digest(value)==self.value_hashes.get(('proofs',index)))
        return deepcopy(self.counts)


@contextmanager
def original_validation_graph(owner):
    need(owner._validation_graph is None);graph=OriginalValidationGraph(owner);owner._validation_graph=graph
    try:
        yield graph
        profile=graph.finish()
    except BaseException as error:
        try:graph.finish()
        except BaseException as final:error.add_note('Original validation graph final guard also refused: '+type(final).__name__)
        raise
    finally:
        owner._validation_graph=None
        # Diagnostics only: counts, never frames/bytes/native facts or authority.
        owner._last_validation_graph_profile=deepcopy(graph.counts)
