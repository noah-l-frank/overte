"""Own Lifecycle marker bytes/lifetime through existing normal Script owners.

Only the local test marker follows its actual avatar parent. Input, navigation,
Camera, MyAvatar and feature results remain untouched by that marker Script.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import need
from adapters.original_frame_store import OriginalFrameStore
from adapters.original_marker_scope import OriginalMarkerScope,_components
from ios.adapters import lifecycle_marker_files as files,lifecycle_marker_measurements as measured,lifecycle_marker_partial as partial
from ios.adapters import avatar_world as world


class LifecycleMarkerOriginals(OriginalFrameStore):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,namespace='lifecycle-marker',schema_prefix='lifecycleMarker',**kwargs)


class IOSLifecycleMarkerScope(OriginalMarkerScope):
    PROFILE='lifecycle'

    @classmethod
    def component_types(cls):
        # Reuse the unchanged actual native Avatar-world/UI source readers.
        # Lifecycle's own Scope/Script bytes/frames have distinct namespaces;
        # the old Avatar/Emote readers never silently accept this profile.
        value=_components('avatar')
        value.profile='lifecycle';value.scope_key='iosLifecycleMarkerScopeVersion'
        value.manifest_key='lifecycleMarkerManifestVersion';value.Files=files.OwnedLifecycleMarkerFiles
        value.Originals=LifecycleMarkerOriginals;value.admitted=measured.admitted;value.restored=measured.restored
        value.body_preserved=measured.body_preserved;value.view_preserved=measured.view_preserved
        value.image_body_preserved=measured.image_body_preserved
        value.partial_execution=partial.executed;value.finished_execution=partial.finished;value.partial_restored=partial.restored
        return value

    def bind_image_world(self,value):
        from ios.adapters.lifecycle_image_join import relative_marker
        self.bound();need(self.state['phase']=='ready' and self.state['cleanupMode']=='full' and self.state['webAdmission'] is not None)
        owned=self.state['admission']['marker'];nonce=self.state['fileOwnership']['nonce']
        actual=world.owned_marker(value,nonce,owned['sourceUrl'])
        keys=('id','name','type','hostType','sourceUrl','userData','dimensions','visible','collisionless','lastEditedEpochUs')
        need(all(actual[key]==owned[key]for key in keys))
        relative_marker(value,actual)
        return deepcopy(dict(nonce=nonce,url=actual['sourceUrl']))
