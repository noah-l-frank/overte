"""Lifecycle challenge frames over existing marker Script and Vulkan owners.

Each frame retains its own native fence, GPU/resource transcript, original PNG
and source geometry. It never reuses a prior phase's pixels as current evidence.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import uuid
from adapters.native_clock_join import NativeClockAcquisition,validate_join
from adapters.native_feature_observation import need
from adapters.native_vulkan_world_frame import absent
from adapters.owned_vulkan_world_frame import VulkanWorldFrameOwner
from adapters.script_feature.history import same
from feature_journeys.evidence import MarkerNotReady
from ios.adapters import lifecycle_image_join,avatar_world
from ios.adapters.lifecycle_marker_scope import IOSLifecycleMarkerScope
from ios.adapters.lifecycle_scene_identity import same_scene
from ios.adapters.graphics_runtime import IOSGraphicsRuntime

VERSION=1


def acquire(runtime,selector,scope,root,policy,phase,lock,*,epoch_ms,monotonic,sleep):
    need(type(scope) is IOSLifecycleMarkerScope);scope.bound();lock.assert_held()
    need(scope.state['phase']=='ready' and scope.state['cleanupMode']=='full' and scope.state['webAdmission'] is not None)
    before_phase=phase.read();ticket=before_phase['ticket'];request='ios-'+uuid.uuid4().hex
    source=runtime._sources(selector);need(source['binding']==scope.binding)
    observer=source['observer'];clock=NativeClockAcquisition(source['clock_source'],epoch_ms=epoch_ms,monotonic=monotonic)
    world=observer.avatar_world(source['clock_source']);renderers=observer.avatar_renderers(source['clock_source'])
    clock.begin(epoch_ms());before=world.read(scope.run);left=renderers.read(scope.run)
    marker=scope.bind_image_world(before);nonce,url=marker['nonce'],marker['url']
    initial=scope.frames[scope.state['baseline']-1]['world']
    need(avatar_world.actual_domain(before)==avatar_world.actual_domain(initial)
        and same_scene(before['source']['sceneUrl'],initial['source']['sceneUrl']))
    graphics=IOSGraphicsRuntime(runtime.adapter)
    owner=graphics._vulkan_world_frame_owner(selector,scope.run,'primary',0,request,root,source_lock=lock)
    owner.monotonic,owner.sleep=monotonic,sleep
    capture,raw=owner.capture(ticket);retirement=owner.release();need(absent(retirement))
    right=renderers.read(scope.run);after=world.read(scope.run)
    originals=dict(worldBefore=before,renderersBefore=left,capture=capture,retirement=retirement,renderersAfter=right,worldAfter=after)
    joined=clock.finish(originals,[('capture','capturedEpochMs'),('retirement','capturedEpochMs')])
    frame=dict(originals,clockJoin=joined);after_phase=phase.read()
    need(before_phase['ticket']==after_phase['ticket'] and same(before_phase['status']['activations'],after_phase['status']['activations'])
        and before_phase['status']['instance']==after_phase['status']['instance'])
    state='observed'
    try:lifecycle_image_join.compose(scope.run,ticket,scope.binding,frame,raw,policy,marker_nonce=nonce,marker_url=url)
    except MarkerNotReady:state='marker-pending' # Actual immutable pixels remain honestly pending.
    return dict(iosLifecycleImageOriginalVersion=1,requestId=request,ticket=ticket,binding=deepcopy(scope.binding),runId=scope.run,
        markerNonce=nonce,markerUrl=url,phase=state,phaseBefore=before_phase,phaseAfter=after_phase,frame=frame,owner=deepcopy(owner.state))


def archive(value,root,policy,lock):
    from adapters.native_feature_observation import exact
    exact(value,{'iosLifecycleImageOriginalVersion','requestId','ticket','binding','runId','markerNonce','markerUrl','phase',
        'phaseBefore','phaseAfter','frame','owner'})
    need(type(value['iosLifecycleImageOriginalVersion']) is int and value['iosLifecycleImageOriginalVersion']==1
        and value['phase'] in ('observed','marker-pending'))
    from feature_journeys.phase_fixture import validate as phase_original
    for name in ('phaseBefore','phaseAfter'):
        status=value[name]['status'];phase_original(status,run=value['runId'],area='lifecycle-input',request=status['requestId'],epoch=status['capturedEpochMs'])
        need(value[name]['ticket']==value['ticket'])
    need(value['phaseBefore']['status']['instance']==value['phaseAfter']['status']['instance']
        and same(value['phaseBefore']['status']['activations'],value['phaseAfter']['status']['activations']))
    frame=value['frame'];validate_join(frame['clockJoin'],{k:v for k,v in frame.items() if k!='clockJoin'})
    owner=value['owner'];need(owner['frame']==frame['capture'] and owner['ticket']==value['ticket'])
    raw=VulkanWorldFrameOwner.archive_original(owner,root,value['binding'],value['runId'],'primary',0,value['requestId'],lock)
    try:lifecycle_image_join.compose(value['runId'],value['ticket'],value['binding'],frame,raw,policy,
        marker_nonce=value['markerNonce'],marker_url=value['markerUrl'])
    except MarkerNotReady:need(value['phase']=='marker-pending')
    else:need(value['phase']=='observed')
    return raw,owner['name']
