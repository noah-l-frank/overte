/* Actual source-defined proxy/bridge flow with explicit HTTP producer models.
 * No SDK module imports, WDA session/service or device execution. */
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash, randomUUID} from 'node:crypto';
import nodeUrl from 'node:url';
import vm from 'node:vm';
import test from 'node:test';
import {EventEmitter} from 'node:events';

const mapBytes=readFileSync(process.env.LIFECYCLE_WDA_SESSION_MODEL_MAP);
assert.equal(createHash('sha256').update(mapBytes).digest('hex'),process.env.LIFECYCLE_WDA_SESSION_MODEL_MAP_SHA256);
const map=JSON.parse(mapBytes);
function pinned(role) {
  const bytes=readFileSync(map[role].path);
  assert.equal(createHash('sha256').update(bytes).digest('hex'),map[role].sha256);
  return bytes.toString('utf8');
}
const source=pinned('proxy');
const begin=source.indexOf('const ORIGINAL_DOWNSTREAM_SESSION_EPOCHS =');
assert(begin>=0);
const body=source.slice(begin);
assert.equal(body.split('exports.JWProxy = JWProxy;').length,2);
// Actual loaded CommonJS class, import preamble excluded. Explicit dependency
// and HTTP producer DI; no SDK require/import/initializer is evaluated.
const code=body.replace('exports.JWProxy = JWProxy;','');
const modelLog={debug(){},info(){},warn(){}};
const namespace={nodeUrl,MJSONWP:'MJSONWP',W3C:'W3C',
  DEFAULT_LOG:modelLog,MAX_LOG_BODY_LENGTH:1024,
  util:{hasValue:value=>value!==null&&value!==undefined,isPlainObject:value=>value!==null&&typeof value==='object',
    truncateString:value=>String(value)},logger:{markSensitive:value=>value},
  errors:{ProxyRequestError:class extends Error{}},};
Object.assign(namespace,{node_url_1:{default:nodeUrl},support_1:{util:namespace.util,logger:namespace.logger},
  constants_1:{MAX_LOG_BODY_LENGTH:1024},errors_1:{errors:namespace.errors}});
const Proxy=vm.runInNewContext(code+';JWProxy',namespace,{filename:'pinned-ACTUAL-LOADED-nested-proxy'});
function modelProxy() {
  // Explicit HTTP producer seam; source logic under test is the ORIGINAL
  // response/epoch/receipt/getter path. It is not real HTTP/auth qualification.
  const proxy=Object.create(Proxy.prototype);
  Object.assign(proxy,{sessionId:'appium-placeholder',_log:modelLog,protocolConverter:{},_activeRequests:[],_downstreamProtocol:null});
  proxy.getUrlForProxy=(url,method)=>method==='POST'&&url.endsWith('/session')
    ? 'http://model-wda/session' : 'http://model-wda/session/'+proxy.sessionId;
  proxy.request=async()=>({status:200,headers:{},data:{value:{sessionId:'wda-original-session'}}});
  return proxy;
}

function bridgeModel() {
 const text=pinned('hostops'),at=text.indexOf('const originalKeeperRoutes ='),end=text.indexOf('\nexport function isStrictHostUtilityMode',at);
 const stringAt=text.indexOf('function stringifyLaunchEnvironment'),stringEnd=text.indexOf('\n\nfunction createSimulatorHostOps',stringAt);
 const load=vm.runInNewContext(text.slice(at,end)+'\n'+text.slice(stringAt,stringEnd)+'\n({launch:tryOriginalKeeperLaunch,bridge:d=>originalKeeperRoutes.get(d)})',{WebDriverProxy:Proxy,randomUUID,WDA_PORT:8100});
 const calls=[],instance='a'.repeat(32),proxy=modelProxy(),driver={sessionId:'original-session',opts:{udid:'model-target',bundleId:'org.example.overte'},wda:{jwproxy:proxy}};
 const remote={async originalKeeperOperation(target,request){calls.push({target,...request});return {originalKeeperOperationVersion:1,ownerInstance:instance,result:request.operation==='inspect'?{creatorMode:'userspace-keeper',nativeTouchSupport:false}:{modeled:true}};}};
 return {driver,remote,calls,proxy,async start(){await load.launch(driver,remote,{udid:'model-target',bundleId:'org.example.wda',env:{USE_PORT:'8100',WDA_PRODUCT_BUNDLE_IDENTIFIER:'org.example.wda'}});await proxy.proxy('/session','POST',{});return load.bridge(driver);}};
}
test('retained release and inspect after session drift use original tuple while new Down refuses',async()=>{
 const f=bridgeModel();await f.start();const route=f.driver[Symbol.for('overte.originalKeeperRoute.v1')];await route.request('touch-begin',{});f.driver.sessionId='foreign';
 await route.request('touch-release',{});await route.request('touch-inspect',{});await assert.rejects(route.request('touch-begin',{}));
 for(const row of f.calls.filter(r=>['touch-release','touch-inspect'].includes(r.operation))){assert.equal(row.target,'model-target');assert.equal(row.sessionId,'original-session');}
 assert.equal(f.calls.filter(r=>r.operation==='touch-begin').length,1);
});
test('retained opts drift settles original before cleanup refuses foreign mutation',async()=>{
 const f=bridgeModel(),bridge=await f.start();f.driver.opts.udid='foreign-target';f.driver.opts.bundleId='org.foreign';
 await bridge.request('touch-release',{});await bridge.request('touch-inspect',{});await assert.rejects(bridge.cleanup());
 assert.equal(f.calls.at(-1).operation,'touch-settle');assert.equal(f.calls.some(r=>r.operation==='process-terminate'),false);
 assert(f.calls.every(r=>r.target==='model-target'));
});
test('retained route calls original captured operation rather than replaced property',async()=>{
 const f=bridgeModel(),bridge=await f.start();f.remote.originalKeeperOperation=async()=>{throw Error('foreign replacement executed')};f.driver.sessionId='foreign';
 await bridge.request('touch-release',{});assert.equal(f.calls.at(-1).operation,'touch-release');
});
test('cleanup session drift never grants PID0 process termination',async()=>{
 const f=bridgeModel(),bridge=await f.start();f.driver.sessionId='foreign';await assert.rejects(bridge.cleanup());
 assert.equal(f.calls.some(r=>r.operation==='process-terminate'),false);assert.deepEqual(f.calls.slice(-2).map(r=>r.operation),['touch-settle','wda-stop']);
});
class Timers {constructor(){this.rows=new Map();this.id=0;} set=(fn,ms)=>{const id=++this.id;this.rows.set(id,{fn,ms});return id;};clear=id=>this.rows.delete(id);fire(ms){const row=[...this.rows].find(([,v])=>v.ms===ms);assert(row);this.rows.delete(row[0]);row[1].fn();}}
function keeperModel() {
 const timers=new Timers(),text=pinned('keeperHelper'),at=text.indexOf('const MAX_BYTES ='),end=text.indexOf('\nexport async function startOriginalUserspaceKeeper',at);assert(at>=0&&end>at);
 const Keeper=vm.runInNewContext(text.slice(at,end).replace('export class OriginalUserspaceKeeper','class OriginalUserspaceKeeper')+';OriginalUserspaceKeeper',{Buffer,randomUUID,setTimeout:timers.set,clearTimeout:timers.clear,performance:{now:()=>0}});
 const child=new EventEmitter();Object.assign(child,{exitCode:null,signalCode:null,stdout:new EventEmitter(),stderr:{resume(){}},records:[],kills:[]});
 child.stdin={write(raw,callback){child.records.push(JSON.parse(raw));callback?.();}};child.kill=signal=>{child.kills.push(signal);if(child.finishOnSignal){child.exitCode=0;child.emit('exit',0,null);}return true;};
 const owner=new Keeper(child,'model-target');const instance='a'.repeat(32);
 child.stdout.emit('data',Buffer.from(JSON.stringify({schemaVersion:2,event:'owner-ready',ownerInstance:instance})+'\n'));
 const request=(operation,sessionId='original-session')=>({schemaVersion:2,requestId:randomUUID().replaceAll('-',''),ownerInstance:instance,sessionId,operation,args:{}});
 owner.session='original-session';
 const reply=(request,result,status='complete')=>child.stdout.emit('data',Buffer.from(JSON.stringify({schemaVersion:2,requestId:request.requestId,ownerInstance:instance,status,result})+'\n'));
 return {owner,child,timers,request,reply,drain:{originalKeeperDrainVersion:1,ownerInstance:instance,inputAdmissionClosed:true,originalTouchWorkersSettled:true,originalOperationsSettled:true,nativeTouchSupport:false,resourceRetirementEstablished:false}};
}
async function turn(){await Promise.resolve();await Promise.resolve();await Promise.resolve();}
async function until(check){for(let i=0;i<100;i++){if(check())return;await Promise.resolve();}throw Error('Actual modeled source did not reach barrier');}
test('unknown original drain causes bounded failure zero signals and retained release route',async()=>{
 const f=keeperModel(),closing=f.owner.close();closing.catch(()=>{});await until(()=>f.child.records.length>0);assert.equal(f.child.records[0].operation,'owner-drain');
 await assert.rejects(f.owner.request(f.request('touch-begin')));f.timers.fire(5000);await assert.rejects(closing);assert.deepEqual(f.child.kills,[]);
 const release=f.owner.request(f.request('touch-release'));await until(()=>f.child.records.at(-1)?.operation==='touch-release');f.reply(f.child.records.at(-1),{modelOnly:true});await release;assert.equal(f.owner.closing,true);
});
test('only actual typed host drain allows SIGTERM and hanging exit is retained without kill',async()=>{
 for(const finish of [true,false]){const f=keeperModel();f.child.finishOnSignal=finish;const closing=f.owner.close();closing.catch(()=>{});await until(()=>f.child.records.length>0);f.reply(f.child.records[0],f.drain);await until(()=>f.child.kills.length===1 && (finish || [...f.timers.rows.values()].some(r=>r.ms===12000)));
 if(!finish){f.timers.fire(12000);await assert.rejects(closing);}else await closing;
 assert.deepEqual(f.child.kills,['SIGTERM']);assert.equal(f.owner.touchDrainConfirmed,true);}
});
function creatorModel(map,start){
 const text=pinned('creator'),setupAt=text.indexOf('function setupCleanupHandlers()'),createAt=text.indexOf('async function createTunnelForDevice('),mainAt=text.indexOf('async function main(',createAt);assert(setupAt>=0&&createAt>setupAt&&mainAt>createAt);
 const process=new EventEmitter();process.exitCode=0;process.exits=[];process.exit=code=>process.exits.push(code);
 const namespace={process,log:{warn(){},info(){}},originalUserspaceOwners:map,registryWatcherStops:[],lifecycleWatchStopByUdid:new Map(),establishedTunnelsByUdid:new Map(),creatorMode:'userspace-keeper',startOriginalUserspaceKeeper:start};
 const code='let originalCreatorStopping=false;\n'+text.slice(setupAt,mainAt)+'\n({setup:setupCleanupHandlers,create:createTunnelForDevice})';
 const actual=vm.runInNewContext(code,namespace);actual.setup();return {actual,process,namespace};
}
test('actual global cleanup closes both owners before first drain await and keeps registry',async()=>{
 let release,entered=false;const gate=new Promise(resolve=>release=resolve);const a={closing:false,async close(){entered=true;await gate;throw Error('original pending')}},b={closing:false,async close(){throw Error('original pending')}};
 const map=new Map([['a',{owner:a,closing:false,completed:true}],['b',{owner:b,closing:false,completed:true}]]),f=creatorModel(map,()=>{throw Error('must not create')});
 const closing=f.process.listeners('SIGTERM')[0]();await turn();assert(entered);assert(a.closing&&b.closing);assert(map.get('b').closing);assert.deepEqual(f.process.exits,[]);
 await assert.rejects(f.actual.create({Properties:{SerialNumber:'third'}}));release();await closing;assert.equal(map.size,2);assert.deepEqual(f.process.exits,[]);
});
test('actual pending birth stays in original map across cleanup and rejects later fresh birth',async()=>{
 let born,finish;const gate=new Promise(resolve=>finish=resolve),owner={closing:false,async close(){throw Error('pending')}};
 const map=new Map(),f=creatorModel(map,async(_device,onBirth)=>{born=onBirth;await gate;onBirth(owner);return owner;});
 const starting=f.actual.create({Properties:{SerialNumber:'first'}});starting.catch(()=>{});assert.equal(map.size,1);await f.process.listeners('SIGTERM')[0]();assert.deepEqual(f.process.exits,[]);
 finish();await assert.rejects(starting);assert.equal(map.get('first').owner,owner);assert(owner.closing);await assert.rejects(f.actual.create({Properties:{SerialNumber:'second'}}));assert.equal(map.size,1);
});
test('existing32 cap reserves cleanup slots and duplicate pending control never replays',async()=>{
 const f=keeperModel(),pending=[];for(let i=0;i<28;i++){const p=f.owner.request(f.request('process-read'));p.catch(()=>{});pending.push(p);}await turn();assert.equal(f.child.records.length,28);
 await assert.rejects(f.owner.request(f.request('process-read')));const release=f.owner.request(f.request('touch-release'));release.catch(()=>{});await turn();await assert.rejects(f.owner.request(f.request('touch-release')));assert.equal(f.child.records.length,29);
 for(const row of f.child.records)f.reply(row,{modelOnly:true});await Promise.all([...pending,release]);assert.equal(f.owner.pending.size,0);assert.equal(f.owner.touchDrainConfirmed,false);
});
test('already signaled dead child without drain refuses immediately and sends no signal',async()=>{
 const f=keeperModel();f.child.signalCode='SIGTERM';f.owner.failed=true;await assert.rejects(f.owner.close());assert.deepEqual(f.child.kills,[]);assert.equal(f.timers.rows.size,0);assert.equal(f.owner.failed,true);
});
