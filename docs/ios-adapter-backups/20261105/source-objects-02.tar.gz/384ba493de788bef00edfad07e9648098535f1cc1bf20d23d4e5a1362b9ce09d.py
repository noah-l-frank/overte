"""Declared lower SDK/candidate producers under the ACTUAL canonical factory.

The canonical IOSInstalledAdapter/InstalledCodeBinding/Runtime/End/Readmission
code is never substituted. Selected artifact preflight, ordinary SDK creation,
controlled app-launch and first-probe boundaries are declared MODELS. Kernel
artifact leases, actual original HTTP/native bytes, locks and PFS are real host
consumers. No physical installed binary or device qualification follows.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import argparse,hashlib,json
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.adapter import IOSNativeMixin
from ios.adapters.appium_adapter import WebDriver
from ios.adapters.feature_observation import FeatureObservation
from ios.adapters.installed_adapter import create_physical_adapter
from ios.adapters.normal_scripts import PROFILE
from ios.adapters.original_keeper_readmission import creation_capabilities
from ios.adapters.script_runtime import IOSScriptRuntime


def DeclaredCanonicalSDK(root,origin,session,*,case,peers=None):
    """Birth the actual canonical subclass around explicit lower data models."""
    root=Path(root);root.mkdir(mode=0o700);artifacts=root/'selected-artifact';artifacts.mkdir(mode=0o700)
    artifact=artifacts/'Overte.ipa';artifact.write_bytes(b'Explicit selected artifact model; not an installable binary.');artifact.chmod(0o600)
    artifact_hash=hashlib.sha256(artifact.read_bytes()).hexdigest()
    bundle=dict(bundleContractVersion=1,bundleId='org.overte.model',executableSha256='a'*64,bundleSha256='b'*64,nodeCount=3,fileCount=2,totalBytes=1000)
    selected=dict(platform='ios',physical=True,appId=bundle['bundleId'],serverUrl=origin,
        artifactMode='personal-team-preinstalled',_artifactMode='personal-team-preinstalled',probe=dict(kind='ios-documents'),
        nativeUiObservation=dict(kind='uikit-documents',version=1),normalScripts=dict(contractVersion=1,profile=PROFILE),
        testBuild=dict(resultsDirectory='owned-results',fixtureOrigin=origin,scenePath='/scene.json'),capabilities={})
    endpoints={'model':(root,origin,session)} if peers is None else dict(peers)
    assert endpoints and all(type(k)is str and len(v)==3 for k,v in endpoints.items())
    for state_root,_origin,_session in endpoints.values():
        Path(state_root).mkdir(mode=0o700,exist_ok=True)
    targets={key:dict(deepcopy(selected),serverUrl=value[1],testBuild=dict(selected['testBuild'],fixtureOrigin=value[1]))for key,value in endpoints.items()}
    args=argparse.Namespace(platform='ios',action='describe',physical_candidate_metadata='explicit-model-only',
        artifact_root=str(artifacts),candidate_manifest=None)
    summary=dict(physicalHandoffVersion=1,bundleIdentity=deepcopy(bundle),artifactIdentity=dict(sourceRevision='a'*40,artifactSha256=artifact_hash))
    preflight_calls=[];ready_calls=[]
    def preflight(actual_args):
        need(actual_args is args and hashlib.sha256(artifact.read_bytes()).hexdigest()==artifact_hash)
        preflight_calls.append(True);return deepcopy(summary)
    class RawSDKBase:
        def __init__(self,platform):
            need(platform=='ios');self.platform=platform;self.root=root;self.selected=targets;self.creations=0;self.generations={key:1 for key in endpoints};self.launches=0
            for key,(_root,_origin,_session)in endpoints.items():self.save_session(key,dict(sessionId=_session,generation=1,targetFingerprint=self.fingerprint(key)))
        @staticmethod
        def advertised_capabilities(target):return ['app.launch','app.foreground','app.process']
        def fingerprint(self,selector):return hashlib.sha256(json.dumps(targets[selector],sort_keys=True,separators=(',',':')).encode()).hexdigest()
        def target(self,selector):need(selector in targets);return deepcopy(targets[selector])
        def state_path(self,selector):need(selector in endpoints);return Path(endpoints[selector][0])/'session.json'
        def read_session(self,selector):return PrivateFeatureState(self.state_path(selector)).read()
        def save_session(self,selector,state):
            store=PrivateFeatureState(self.state_path(selector));store.write(state,store.read())
        def ensure_session(self,selector):
            target=self._target(selector);state=self.read_session(selector);client=WebDriver(target['serverUrl'])
            if state is None:
                need(not self._session_recreation_forbidden)
                # Actual shared typed readmission owner is mandatory. Its
                # scoped creation capability is not recreated from a DTO.
                capabilities=creation_capabilities(self,target)
                value=client.call('POST','/session',dict(capabilities=dict(alwaysMatch=capabilities,firstMatch=[{}])))
                need(type(value)is dict and type(value['sessionId'])is str)
                self.creations+=1;self.generations[selector]+=1
                state=dict(sessionId=value['sessionId'],generation=self.generations[selector],targetFingerprint=self.fingerprint(selector));self.save_session(selector,state)
            return client,state['sessionId'],deepcopy(state)
        def describe(self,selector):return dict(adapter='explicit-lower-sdk-model',physicalSDKModeled=True)
        def launch_ios_test_build(self,selector,client,session,state,target,scene_url=None,*,reactivate=False):
            need(self._binding_store(selector).read()['phase']=='preparing')
            self.launches+=1;self.assert_ios_process_identity(selector,client,session,state,target)
            state.update(iosE2ELaunchCompleted=True,iosE2ESceneUrl=target['testBuild']['fixtureOrigin']+'/scene.json');self.save_session(selector,state)
        def runtime(self):return IOSScriptRuntime(self)
    def raw_first_probe(receiver,selector,client,session,state,target,identity,launched_at):
        # This declared first-probe boundary still obtains an independently
        # fresh original NativeFeatureObservation through actual HTTP/AFC.
        # It does not claim the full generic probe script ran on a device.
        clock=FeatureObservation(client,session,target,lambda:receiver.native_process(client,session,target)).native_observer()
        original=clock.read(0);need(str(original['processId'])==identity and original['capturedEpochMs']>=launched_at)
        ready_calls.append(dict(processIdentity=identity,nativeOriginalSha256=hashlib.sha256(json.dumps(original,sort_keys=True,separators=(',',':')).encode()).hexdigest()))
    case.enterContext(patch.object(IOSNativeMixin,'wait_first_ios_probe',raw_first_probe))
    adapter=create_physical_adapter(args,RawSDKBase,preflight)
    adapter.model_boundaries=dict(artifactPreflight=preflight_calls,firstProbe=ready_calls,physicalSDKModeled=True,
        canonicalFactoryActual=True,installedBindingActual=True,wholeQualified=False)
    return adapter
