"""Root-only future metadata, no SUT imports, execution or old corpus input."""
from pathlib import Path
import argparse,contextlib,hashlib,http.client,http.server,importlib.machinery,io,json,os,shutil,signal,socket,socketserver,ssl,subprocess,sys,tempfile,threading,unittest
from metadata_reader import pin,load,sha
from utility_common import SOURCE,REPO,head
PREFIX=REPO/'.ios-host-tmp/avatar-normal-prefix4-held-https-connector-option-custody-source-private-20261104'
PREFIX_SHA='981458bc00805b9480b1673bea9bbf0f80f6ba49e9b317e7d6f21a3b4db709d4'
def packet(folder,filename,digest):
    p=folder/filename;assert sha(p)==digest;out={str(p):pin(p)}
    for name,row in load(p)['files'].items():
        q=folder/name;assert sha(q)==(row['sha256']if type(row)is dict else row);out[str(q)]=pin(q)
    return out
def main():
    p=argparse.ArgumentParser();p.add_argument('--source-freeze',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--destination',type=Path,required=True);a=p.parse_args()
    assert sys.dont_write_bytecode and sys.flags.no_site==1 and Path.cwd()==REPO and head()==a.expected_head
    physical=packet(SOURCE,'source-freeze.json',a.source_freeze);physical.update(packet(PREFIX,'source-freeze.json',PREFIX_SHA))
    previous=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller6-no-site-startup-code-preparation-20261104'
    physical.update(packet(previous,'source-freeze.json','1a517b07d8c888d79cbfe86116def12a8d65b1f9a24f971bde4afa4b5caa4fea'))
    c7=load(SOURCE/'c7-closed-origin-reference.json');physical.update(packet(Path(c7['sourcePacket']),'source-freeze.json',c7['freezeSha256']))
    own2=REPO/'.ios-host-tmp/avatar-prefix4-own-boundary4-source-bootstrap2-independent-cio-custody-private-20261104'
    physical.update(packet(own2,'source-freeze.json','81ef157b5c90f5410a4843bfd5b5a58fc417b19682aafd3bc0fd40e1ba234f42'))
    independent=REPO/'.ios-host-tmp/assets-independent-avatar-ownboundary2-full-source-review-20261104'
    physical.update(packet(independent,'freeze.json','0f5fa22eaf3efce70fc101c8e1bef42ef2e6217e9de37ed3371d9de061e4931f'))
    c8_review=REPO/'.ios-host-tmp/avatar-independent-chat-controller8-genuine-expat-child-full-source-review-private-20261104'
    physical.update(packet(c8_review,'freeze.json','3c19117f02577a04f578385b8fe678d849dcbcebf67e03993aa22f5a1c9aad56'))
    own3=REPO/'.ios-host-tmp/avatar-prefix4-own-boundary4-source-bootstrap3-c8-exact-child-origin-private-20261104'
    physical.update(packet(own3,'source-freeze.json','6b49fb59cf8d8ee57e89834a3d7b4a505ef42b0d2755766f1db33186bd12517f'))
    c9_review=REPO/'.ios-host-tmp/avatar-independent-chat-controller9-expat-wrapper-alias-full-source-review-private-20261104'
    physical.update(packet(c9_review,'freeze.json','2ae34991dfa041b6076668b9c9b38e5a770fed3b7aeec320b88630e65ec72c9f'))
    own4=REPO/'.ios-host-tmp/avatar-prefix4-own-boundary4-source-bootstrap4-c9-exact-wrapper-alias-private-20261104'
    physical.update(packet(own4,'source-freeze.json','b414f07d075913942f70a4e3f5fbce64e43bdc33526898a090cb19d070226cfc'))
    c10b_review=REPO/'.ios-host-tmp/lifecycle-independent-chat-controller10b-fresh-source-full-review2-20261104'
    physical.update(packet(c10b_review,'freeze.json','0067a382c7555b7084e421f73f9eeb2bbb1d8bfe831db78101ccd53d66703196'))
    closure=load(SOURCE/'project-definition-closure.json');modules=closure['modules'];namespaces=closure['namespaces']
    for name,row in modules.items():assert sha(row['path'])==row['sha256'];physical[row['path']]=pin(row['path'])
    for name in('metadata_reader','utility_common','utility_runtime','closed_import_origins','test_avatar_prefix_boundary'):
        path=SOURCE/(name+'.py');modules[name]=dict(path=str(path),sha256=sha(path),package=False);physical[str(path)]=pin(path)
    for name in('avatar_ports','entry_observer','assets_fixture_ports','owned_write_boundary','prefix_common'):
        path=PREFIX/(name+'.py');modules[name]=dict(path=str(path),sha256=sha(path),package=False);physical[str(path)]=pin(path)
    third=load(PREFIX/'third-party-source-declarations.json');external={}
    for name,row in third.items():
        assert sha(row['path'])==row['sha256'];physical[row['path']]=pin(row['path'])
        external[name]=dict(path=row['path'],sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    assert len(external)==39
    std=Path(os.__file__).resolve(strict=True).parent;extensions=tuple(importlib.machinery.EXTENSION_SUFFIXES);std_namespaces={}
    for folder,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(folder);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink())
        rel=folder.relative_to(std)
        if rel.parts and all(x.isidentifier()for x in rel.parts)and not(folder/'__init__.py').is_file():std_namespaces['.'.join(rel.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(extensions):continue
            assert path.resolve(strict=True)==path and not path.is_symlink();physical[str(path)]=pin(path)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    executables={}
    for name in('node','openssl'):
        path=Path(shutil.which(name));real=path.resolve(strict=True);row=pin(real);physical[str(real)]=row
        executables[name]=dict(path=str(path),realPath=str(real),device=row['device'],inode=row['inode'],sha256=row['sha256'])
    # Node is a pinned source/binary identity only, never an authorized birth.
    output=a.destination;assert output.is_absolute()and output.resolve(strict=False)==output and output.parent==REPO/'.ios-host-tmp'and not output.exists()
    cases=['test_avatar_prefix_boundary.AvatarPrefixBoundaryTests.'+name for name in(
        'test_foreign_real_thread_write_refuses_without_original_frame',
        'test_original_http_request_closes_socket_and_its_own_writer_helper',
        'test_matching_original_node_argv_foreign_caller_refuses_before_birth',
        'test_actual_tls_postbirth_precallerreturn_fault_stays_nongreen_then_rescues')]
    plan=dict(status='PRIVATE_OWN_BOUNDARY4_UNRUN_REQUIRES_ROOT_REVIEW',expectedHead=a.expected_head,sourceFreeze=a.source_freeze,prefix4Freeze=PREFIX_SHA,
        seconds=30,graceSeconds=5,cases=cases,NodeExecutions=0,maximumOpenSSLExecutions=2,maximumFixtureListeners=1,oldOriginalInputs=0,globalCensuses=0,
        physicalPins=physical,modules=modules,namespacePackages=namespaces,thirdPartyModules=external,thirdPartyNamespacePackages={},stdlibNamespacePackages=std_namespaces,stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),executables=executables,
        nativeQualified=False,wholeQualified=False,positiveActorAuthority=False)
    assert all(pin(path)==row for path,row in physical.items())and head()==a.expected_head
    output.mkdir(mode=0o700)
    with(output/'approved-inputs.json').open('x')as stream:json.dump(plan,stream,sort_keys=True,indent=2);stream.write('\n')
    (output/'approved-inputs.json').chmod(0o600)
    print(json.dumps(dict(status='METADATA_ONLY_UNRUN',input=str(output/'approved-inputs.json'),inputSha256=sha(output/'approved-inputs.json'),physicalPins=len(physical),projectModules=len(modules),externalModules=39,oldOriginalInputs=0)))
if __name__=='__main__':main()
