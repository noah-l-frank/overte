"""Distinct current-action GetAll readers independent of any file/upload birth.

The protocol resource is a bounded inventory query scope only. These readers
never stage files, create an Upload, query raw model bodies or adopt old jobs.
Each action/subject owns its own native source namespace and actual ticket.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
from adapters.native_feature_observation import integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from ios.adapters.assets_action_phase import AssetsActionPhases,AssetsActionScope
from ios.adapters.assets_generation_action_history import action_original
from ios.adapters.assets_episode_metadata_graph import readonly_store,forbidden
from ios.adapters.assets_reply_owner import OwnedAssetsReplyReads
from ios.adapters.assets_reply_sources import ReplySources


class CheckpointReplySources(ReplySources):
    SCHEMA_PREFIX='iosAssetsCheckpointReplySource'
    RECORD_KEY='iosAssetsCheckpointReplySourceRecordVersion'
    MIGRATION_KEY='iosAssetsCheckpointReplySourceMigrationVersion'
    def __init__(self,*args,index,role,**kwargs):
        need(integer(index,1,29) and role in ('primary','actor'))
        self.NAMESPACE='assets-cp-a'+str(index)+'-'+role+'-replies'
        self.MIGRATION_PREFIX='assets-cp-a'+str(index)+'-'+role+'-migration-'
        super().__init__(*args,**kwargs)


class AssetsCheckpointReplies(OwnedAssetsReplyReads):
    CURRENT_VERSION=5
    ALLOW_LEGACY=False
    EXTRA_FIELDS=frozenset({'checkpointAction'})
    def __init__(self,*args,actions,action,episode=None,**kwargs):
        need(type(actions) is AssetsActionPhases and type(action) is AssetsActionScope and action.owner is actions)
        self.actions,self.action,self.action_index,self.episode=actions,action,action.index,episode;self.historical=False
        super().__init__(*args,**kwargs);self.boundary();action.guard()
    def boundary(self):
        info=self.actions.selected.context['roles'][self.role]
        root=(Path(info['stateRoot']) if self.episode is None else Path(self.episode.descriptor['directories'][self.role]['stateRoot']['path']))
        need(self.store.path==root/('ios-assets-checkpoint-'+self.run+'-a'+str(self.action_index)+'-'+self.role+'-replies.json')
            and self.lock.path==root/'script-feature-sources.lock' and same(self.binding,info['binding']) and self.run==self.actions.run)
        if self.episode is None:need(self.action_index==1 and self.lock is self.actions.locks[self.role])
        else:need(self.episode.owner.selected is self.actions.selected and self.lock is self.episode.locks[self.role]);self.episode.guard()
    def profile(self):self.sources=CheckpointReplySources(self,self.role,self.source_guard,self.save,index=self.action_index,role=self.role)
    def ticket(self):
        if self.action is not None:return self.action.ticket
        row=action_original(self.actions,self.action_index,include_saved_pending=True);return row['ticket']
    def extra_envelope(self):
        return dict(checkpointAction=dict(path=str(self.actions.store.path),index=self.action_index,ticket=self.ticket(),
            episode=None if self.episode is None else self.episode.link()))
    def source_guard(self):
        super().source_guard();self.actions.guard();self.boundary()
        if not self.historical:self.action.guard()
        return True
    def query_context(self,query,state):
        super().query_context(query,state);need(query['ticket']==self.ticket() and state['ticket']==self.ticket())
    def query_intent(self,query):
        need(not self.historical);self.action.guard();need(query['ticket']==self.action.ticket);return query
    def reserve(self,ticket,resource='gltf-bundle/main.gltf',namespace='original'):
        need(not self.historical and ticket==self.ticket() and resource=='gltf-bundle/main.gltf' and namespace=='original')
        self.action.guard();return super().reserve(ticket,resource,namespace)
    def read(self,slot,kind='inventory',**kwargs):
        need(not self.historical and kind=='inventory' and not kwargs);self.action.guard();return super().read(slot)
    @classmethod
    def from_archive(cls,actions,index,role,*,episode=None):
        need(type(actions) is AssetsActionPhases and integer(index,1,29) and role in ('primary','actor'));action_original(actions,index,include_saved_pending=True)
        owner=object.__new__(cls);owner.actions,owner.action,owner.action_index,owner.episode=actions,None,index,episode
        owner.role,owner.run,owner.url=role,actions.run,actions.context['fixtureUrl'];owner.historical=True
        owner.binding=deepcopy(actions.context['roles'][role]['binding'])
        root=Path(actions.context['roles'][role]['stateRoot']) if episode is None else Path(episode.descriptor['directories'][role]['stateRoot']['path'])
        owner.lock=actions.locks[role] if episode is None else episode.locks[role];owner.lock.assert_held()
        owner.store=readonly_store(PrivateFeatureState(root/('ios-assets-checkpoint-'+owner.run+'-a'+str(index)+'-'+role+'-replies.json')))
        owner.previous=owner.store.read();need(owner.previous is not None);owner.state=None;owner.storage_version=5
        owner.native=SimpleNamespace(pid=int(owner.binding['processIdentity']),monotonic=actions.monotonic,guard=forbidden,
            request=forbidden,read=forbidden,send=forbidden,clock_ms=forbidden,sleep=forbidden,jobs={},last=None)
        owner.profile();owner.boundary();owner.state=owner.decode(owner.previous);owner.source_guard();return owner
