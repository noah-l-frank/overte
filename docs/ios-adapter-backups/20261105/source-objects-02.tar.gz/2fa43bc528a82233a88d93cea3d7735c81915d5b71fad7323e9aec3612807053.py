"""Exact retained-response Stop scope; no general installed-code exception.

Only the actual new ProcessEnd3/Response original and actual entry.stop frame
can create this lexical scope. It authorizes original process continuity in one
actual ensure_session branch; it cannot Stop, query, delete or grant absence.
"""
from contextvars import ContextVar
import sys,threading,types
from adapters.native_feature_observation import need
from adapters.script_feature.history import same
_CURRENT=ContextVar('overte_emote_post9_original_response_stop',default=None)


class Post9ResponseStopScope:
    def __init__(self,runtime,owner,cut):
        from ios.adapters.emote_post9_process_end import IOSEmotePost9ProcessEnd
        from ios.adapters.emote_post9_fence_cut import IOSEmotePost9FenceCut
        from ios.adapters import emote_post9_entry
        need(type(owner)is IOSEmotePost9ProcessEnd and type(cut)is IOSEmotePost9FenceCut and cut.end is owner
            and owner.runtime is runtime and owner.state['phase']=='stop-issued'and owner.state['response']['phase']=='absent')
        entry=emote_post9_entry.stop;frame=sys._getframe(1)
        need(type(frame)is types.FrameType and frame.f_code is entry.__code__ and frame.f_globals is entry.__globals__ is vars(emote_post9_entry)
            and frame.f_locals.get('owner')is owner and frame.f_locals.get('cut')is cut and frame.f_locals.get('runtime')is runtime)
        self.owner,self.cut,self.adapter=owner,cut,runtime.adapter
        self.variable=_CURRENT;self.thread=threading.get_ident();self.token=None;self.used=0
        self.entry,self.entry_code,self.entry_globals=entry,entry.__code__,entry.__globals__
        fn=type(self.adapter).__dict__['ensure_session'];module=sys.modules['ios.adapters.installed_adapter']
        need(type(fn)is types.FunctionType and fn.__globals__ is vars(module))
        self.ensure,self.ensure_code,self.ensure_globals=fn,fn.__code__,fn.__globals__;self.installed_module=module
        self.guard()
    def installation(self):
        from ios.adapters import emote_post9_entry
        need(_CURRENT is self.variable and threading.get_ident()==self.thread and emote_post9_entry.stop is self.entry
            and self.entry.__code__ is self.entry_code and self.entry.__globals__ is self.entry_globals
            and sys.modules.get('ios.adapters.installed_adapter')is self.installed_module
            and type(self.adapter).__dict__.get('ensure_session')is self.ensure
            and self.ensure.__code__ is self.ensure_code and self.ensure.__globals__ is self.ensure_globals is vars(self.installed_module))
    def guard(self):
        self.installation();p=self.owner;p.bound();self.cut.guard()
        need(p.runtime.adapter is self.adapter and p.state['phase']=='stop-issued'and p.state['response']['phase']=='absent')
        p.response.completed(p.fence_original());return True
    def __enter__(self):
        self.guard();need(self.token is None and self.variable.get()is None)
        frame=sys._getframe(1);need(frame.f_code is self.entry_code and frame.f_globals is self.entry_globals
            and frame.f_locals.get('owner')is self.owner and frame.f_locals.get('cut')is self.cut)
        self.token=self.variable.set(self);return self
    def __exit__(self,kind,original,traceback):
        problem=None
        try:
            self.installation();need(self.variable.get()is self and self.token is not None)
            if original is None:need(self.used==1)
        except BaseException as error:problem=(error,error.__traceback__)
        try:
            if self.token is not None:self.variable.reset(self.token);self.token=None
            need(self.variable.get()is None)
        except BaseException as error:
            if problem is None:problem=(error,error.__traceback__)
        if problem is not None:
            if original is not None:original.add_note('Original post9 Stop scope restoration is unresolved; original failure retained.')
            else:raise problem[0].with_traceback(problem[1])
        return False


def permits(adapter,selector,session):
    authority=_CURRENT.get()
    if authority is None:return False
    need(type(authority)is Post9ResponseStopScope);authority.guard();owner=authority.owner
    frame=sys._getframe(1)
    need(frame.f_code is authority.ensure_code and frame.f_globals is authority.ensure_globals
        and frame.f_locals.get('self')is adapter and frame.f_locals.get('selector')==selector
        and adapter is authority.adapter and selector==owner.flow.selector and session==owner.binding['sessionId']
        and adapter._operation=='app.stop'and authority.used==0)
    authority.used+=1;return True
