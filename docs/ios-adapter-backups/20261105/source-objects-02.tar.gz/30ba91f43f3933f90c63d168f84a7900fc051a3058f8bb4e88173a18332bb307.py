"""Private opt-in original World+resource parent history; AST/hash only."""
import ast,difflib,hashlib,json
from pathlib import Path
R=Path.cwd();H=R/'.ios-host-tmp/lifecycle-resource4-parent-world-history-source-proposal-20261102'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(s)
module='''"""Literal parent-retained Resource4 originals, never a new current reading."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import base64,hashlib
from copy import deepcopy
from adapters.native_feature_observation import decode,exact,integer,need
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import canonical
from ios.adapters.lifecycle_touch_resource_owner import owner_header,capture_original

VERSION=1

def original(value,binding,run,owner,preparation,*,previous=None):
    exact(value,{'iosLifecycleParentResourceOriginalVersion','ownerInstance','preparationReferenceJson',
        'reference','ownerReference','ownerBase64','captureBase64'})
    need(type(value['iosLifecycleParentResourceOriginalVersion']) is int and value['iosLifecycleParentResourceOriginalVersion']==1
        and value['ownerInstance']==owner and value['preparationReferenceJson']==canonical(preparation).decode('ascii'))
    captures={}
    for kind,key,limit in (('owner','ownerReference',65536),('capture','reference',1048576)):
        reference=value[key];exact(reference,{'index','sha256','bytes','device','inode'})
        need(integer(reference['index'],1,32) and integer(reference['bytes'],2,limit)
            and integer(reference['device'],0,2**64-1) and integer(reference['inode'],1,2**64-1))
        text=value[kind+'Base64'];need(type(text) is str and len(text)<=((limit+2)//3)*4)
        raw=base64.b64decode(text,validate=True)
        need(len(raw)==reference['bytes'] and hashlib.sha256(raw).hexdigest()==reference['sha256'])
        body=decode(raw.decode('utf-8'),limit=limit)
        need(canonical(body)+(b'\n' if kind=='owner' else b'')==raw);captures[kind]=body
    need(value['reference']['index']==value['ownerReference']['index'])
    state=owner_header(captures['owner'],binding,run)
    need(state['pending'] is None and state['frames'] and state['frames'][-1]==value['reference'])
    body=captures['capture'];exact(body,{'iosLifecycleTouchResourceFrameVersion','kind','binding','runId','role','index','frame'})
    need(type(body['iosLifecycleTouchResourceFrameVersion']) is int and body['iosLifecycleTouchResourceFrameVersion']==1
        and body['kind']=='sources' and body['binding']==binding and body['runId']==run and body['role']=='primary'
        and type(body['index']) is int and body['index']==value['reference']['index'])
    prior=None if previous is None else original(previous,binding,run,owner,preparation)['capture']
    capture=capture_original(body['frame'],state,prior)
    if previous is not None:need(value['reference']['index']==previous['reference']['index']+1)
    # These exact bytes were received under the original child's FD/Task/source
    # guards. Their parent OriginalFrameStore now supplies historical physical
    # identity. Child owner WAL mutation cannot relabel them as a fresh source.
    return dict(owner=deepcopy(captures['owner']),capture=deepcopy(capture))
'''
# Literal newline in generated Python bytes expression.
module=module.replace("b'\n' if", "b'\\n' if")
paths=['tests/device/ios/adapters/lifecycle_world_hold_runtime.py','tests/device/ios/adapters/lifecycle_world_hold.py',
 'tests/device/ios/adapters/lifecycle_resource_history.py','tests/device/contract-versions.json','tests/device/validate_contract_versions.py']
rows=[];diff=[]
for rel in paths:
 p=R/rel;before=p.read_text() if p.exists() else '';after=before
 if rel.endswith('lifecycle_resource_history.py'):after=module
 elif rel.endswith('lifecycle_world_hold_runtime.py'):
  after=after.replace('def resource_metadata(self,selector,run,*,recover=False,original_child=None):','def resource_metadata(self,selector,run,*,recover=False,original_child=None,retain_original_bytes=False):')
  after=after.replace('        if original_child is not None:\n            need(type(original_child)',"        need(type(retain_original_bytes) is bool and (not retain_original_bytes or original_child is not None))\n        if original_child is not None:\n            need(type(original_child)")
  after=after.replace('return self._resource_metadata_original_child(original_child,recover)','return self._resource_metadata_original_child(original_child,recover,retain_original_bytes)')
  after=after.replace('async def _resource_metadata_original_child(self,connection,recover):','async def _resource_metadata_original_child(self,connection,recover,retain_original_bytes=False):')
  after=after.replace('self._resource_metadata_original_read,connection.selector,args,result,value)','self._resource_metadata_original_read,connection.selector,args,result,value,retain_original_bytes)')
  after=after.replace('def _resource_metadata_original_read(self,selector,args,result,value):','def _resource_metadata_original_read(self,selector,args,result,value,retain_original_bytes=False):')
  after=after.replace('        import base64,time\n        from ios.adapters.lifecycle_touch_resource_owner import owner_header,capture_original','        import base64,time\n        need(type(retain_original_bytes) is bool)\n        from ios.adapters.lifecycle_touch_resource_owner import owner_header,capture_original')
  needle="        return dict(originalKeeperTouchResourceVersion=3,ownerInstance=result['ownerInstance'],owner=deepcopy(owner),capture=deepcopy(capture),\n            reference=deepcopy(value['reference']),ownerReference=deepcopy(value['ownerReference']),nativeTouchSupport=False,resourceRetirementEstablished=False)"
  assert after.count(needle)==1
  after=after.replace(needle,"""        output=dict(originalKeeperTouchResourceVersion=3,ownerInstance=result['ownerInstance'],owner=deepcopy(owner),capture=deepcopy(capture),
            reference=deepcopy(value['reference']),ownerReference=deepcopy(value['ownerReference']),nativeTouchSupport=False,resourceRetirementEstablished=False)
        if retain_original_bytes:
            output['rawOriginal']=dict(iosLifecycleParentResourceOriginalVersion=1,ownerInstance=result['ownerInstance'],
                preparationReferenceJson=args['preparationReferenceJson'],reference=deepcopy(value['reference']),ownerReference=deepcopy(value['ownerReference']),
                ownerBase64=base64.b64encode(artifacts['owner']).decode('ascii'),captureBase64=base64.b64encode(artifacts['capture']).decode('ascii'))
        return output""")
  after=after.replace('def child(self,selector,editors,attempt,session_factory,*,original_child=False):','def child(self,selector,editors,attempt,session_factory,*,original_child=False,resource_history=False):')
  after=after.replace('        need(type(original_child) is bool and type(editors)', '        need(type(resource_history) is bool and (not resource_history or original_child)\n            and type(original_child) is bool and type(editors)')
  after=after.replace('attempt,session_factory,original_child=connection)','attempt,session_factory,original_child=connection,resource_history=resource_history)')
 elif rel.endswith('lifecycle_world_hold.py'):
  after=after.replace('def __init__(self,store,attempt,session_factory,*,original_child=None):','def __init__(self,store,attempt,session_factory,*,original_child=None,resource_history=False):')
  after=after.replace('        need(isinstance(store,PrivateFeatureState) and type(attempt)', '        need(type(resource_history) is bool and (not resource_history or original_child is not None)\n            and isinstance(store,PrivateFeatureState) and type(attempt)')
  after=after.replace('self.version=1 if original_child is None else 2','self.version=1 if original_child is None else 3 if resource_history else 2')
  after=after.replace('self.version==2','self.version in (2,3)')
  needle="        exact(frame,{'originals','clockJoin'}|({'originalChild'} if self.version in (2,3) else set()))";assert after.count(needle)==1
  after=after.replace(needle,needle[:-1]+"|({'resourceOriginal'} if self.version==3 else set()))")
  needle="        exact(frame['originals'],{'world','worldClock'}|({'geometry','window'} if before else set()))";assert after.count(needle)==1
  after=after.replace(needle,"""        if self.version==3:
            if before:need(frame['resourceOriginal'] is None)
            else:
                from ios.adapters.lifecycle_resource_history import original
                original(frame['resourceOriginal'],self.binding,self.run,frame['originalChild']['ownerInstance'],self.frame(1)['originalChild']['reference'])
"""+needle)
  needle="        return packet\n    def envelope";assert after.count(needle)==1
  after=after.replace(needle,"""        if self.version==3 and index>2:
            from ios.adapters.lifecycle_resource_history import original
            first=self.frame(1)['originalChild'];current=self.frame(index);prior=self.frame(index-1)
            original(current['resourceOriginal'],self.binding,self.run,first['ownerInstance'],first['reference'],previous=prior['resourceOriginal'])
        return packet
    def envelope""")
  needle="""            if before:frame=await self.original_child.prepare(self.state['seconds'])
            else:
                phase='quiet' if self.state['released'] is not None else 'held' if self.state['held'] is None else 'released'
                frame=await self.original_child.capture(phase,ordinal=index-1)
            self.source_frame(frame,before=before)""";assert after.count(needle)==1
  after=after.replace(needle,"""            resource=None
            if before:frame=await self.original_child.prepare(self.state['seconds'])
            else:
                phase='quiet' if self.state['released'] is not None else 'held' if self.state['held'] is None else 'released'
                if self.version==3:
                    # Released resource bytes are retained BEFORE the unchanged
                    # native released+four-quiet batch starts. Each later parent
                    # append obtains a new original; old snapshots are never
                    # refreshed by replaying their parsed returned metadata.
                    metadata=await self.original_child.runtime.resource_metadata(self.original_child.selector,self.run,
                        original_child=self.original_child,retain_original_bytes=True)
                    resource=metadata['rawOriginal']
                frame=await self.original_child.capture(phase,ordinal=index-1)
            if self.version==3:frame['resourceOriginal']=resource
            self.source_frame(frame,before=before)""")
  after+='''
    def resource_history_proof(self):
        """Historical passive host window, distinct from native/SDK retirement."""
        from ios.adapters.lifecycle_resource_history import original
        need(self.version==3 and self.state['phase']=='quiet');self.proof()
        first=self.frame(1)['originalChild'];indices=[self.state['released'],*self.state['quiet']]
        need(len(indices)==5);rows=[];previous=None
        for index in indices:
            self.packet(index);value=self.frame(index)['resourceOriginal']
            measured=original(value,self.binding,self.run,first['ownerInstance'],first['reference'],previous=previous)
            worker=measured['capture']['worker'];source=measured['capture']['source']
            need(source['complete'] and not worker['hostResponsibility'] and not worker['workerRunning'] and worker['contextExitReturned'])
            need({row['kind'] for row in source['resources']}=={'rsd','receiver','drain','display','hid'})
            edges={row['edge'] for row in source['events']}
            need({'receiver-close-returned','source-finally-body-tail-observed','drain-await-settled','hid-context-exit-returned'}<=edges)
            if rows:need(source['events']==rows[-1]['source']['events'])
            rows.append(measured['capture']);previous=value
        a,b=rows[0]['source']['clock'],rows[-1]['source']['clock']
        elapsed=min(b['epochMs']-a['epochMs'],b['monotonicMs']-a['monotonicMs']);need(elapsed>=3000)
        return dict(iosLifecycleParentResourceHistoryProofVersion=1,historicalOnly=True,samples=len(rows),hostMilliseconds=elapsed,
            sourceInstance=rows[0]['source']['instance'],nativeTouchSupport=False,resourceRetirementEstablished=False,
            sdkResourceRetirementEstablished=False,wholeLifecycleRetirementEstablished=False)
'''
 elif rel.endswith('contract-versions.json'):
  needle='"ios-lifecycle-world-hold": {"current": 2, "reads": [1, 2]}'
  assert after.count(needle)==1;after=after.replace(needle,'"ios-lifecycle-world-hold": {"current": 3, "reads": [1, 2, 3]},\n    "ios-lifecycle-parent-resource-original": {"current": 1, "reads": [1]},\n    "ios-lifecycle-parent-resource-history-proof": {"current": 1, "reads": [1]}')
 elif rel.endswith('validate_contract_versions.py'):
  needle='"ios-lifecycle-world-hold": 2,';assert after.count(needle)==1
  after=after.replace(needle,'"ios-lifecycle-world-hold": 3,\n    "ios-lifecycle-parent-resource-original": 1,\n    "ios-lifecycle-parent-resource-history-proof": 1,')
 if rel.endswith('.py'):ast.parse(after,filename=rel)
 else:json.loads(after)
 if before:write(H/'base'/rel,before)
 write(H/'candidate'/rel,after);rows.append(dict(path=rel,baseSHA256=sha(p) if p.exists() else None,candidateSHA256=hashlib.sha256(after.encode()).hexdigest()))
 diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
write(H/'source-only.diff',''.join(diff));write(H/'plan.json',json.dumps(dict(status='PRIVATE_UNRUN_SOURCE_REVIEW_REQUIRED',sourceRows=rows,defaultProfilesUnchanged=[1,2],newProfile=3,SDKReceiverSourceChanged=False,sourceReadProtocolChanged=False,originalPreparationUnchanged=True,retirementClaims=False,testsRun=False,importsRun=False,remaining='Whole editor/pending coordination, independent Actor/image/restoration, original process/SDK end and unchanged common Journey remain open.'),indent=2)+'\n')
write(H/'freeze.json',json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(H)):sha(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(packet=str(H),freeze=sha(H/'freeze.json'),sourceRows=rows)))
