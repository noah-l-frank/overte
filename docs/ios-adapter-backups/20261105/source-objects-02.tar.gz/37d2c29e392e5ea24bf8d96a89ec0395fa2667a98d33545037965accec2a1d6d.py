"""Exactly one frozen RawMarkerWorker Node child and its real CPython pipes.

Controller custody only. No product method, native observation or process exit
is synthesized. Other subprocess and inherited-descriptor ports remain refused.
"""
from pathlib import Path
import hashlib,http.server,ipaddress,marshal,os,shutil,socket,socketserver,stat,subprocess,sys


def _original_host_reader_seal():
    # Captured before target imports, independently of any inspected frame.
    fqdn=socket.getfqdn;reverse=socket.gethostbyaddr;bind=http.server.HTTPServer.server_bind
    tcp_bind=socketserver.TCPServer.server_bind;http_class=http.server.HTTPServer
    held=(fqdn,fqdn.__code__,fqdn.__globals__,reverse,bind,bind.__code__,bind.__globals__,
        tcp_bind,tcp_bind.__code__,tcp_bind.__globals__,http_class)
    def fresh():
        assert socket.getfqdn is fqdn and fqdn.__code__ is held[1]and fqdn.__globals__ is held[2]
        assert socket.gethostbyaddr is reverse
        assert http.server.HTTPServer is http_class and http_class.server_bind is bind
        assert bind.__code__ is held[5]and bind.__globals__ is held[6]
        assert socketserver.TCPServer.server_bind is tcp_bind and tcp_bind.__code__ is held[8]and tcp_bind.__globals__ is held[9]
        assert fqdn.__globals__['gethostbyaddr']is reverse and bind.__globals__['socket']is socket
        return held
    return held,fresh


_ORIGINAL_HOST_READERS,_HOST_READERS_FRESH=_original_host_reader_seal()


class MovingNodePort:
    def __init__(self,plan,write_boundary):
        self.plan,self.boundary=plan,write_boundary
        self.script=Path(plan['movingNodeScript']['path'])
        self.node=Path(plan['nodeExecutable']['path'])
        self.command=['node',str(self.script)]
        self.popen=subprocess.Popen;self.environment_path=os.environ.get('PATH')
        self.popen_methods=tuple((name,getattr(self.popen,name),getattr(self.popen,name).__code__)
            for name in('__init__','_execute_child'))
        self.readers=(os.fstat,os.readlink,sys._getframe,shutil.which)
        self.pending=None;self.spawned=False;self.worker=None;self.start=None;self.owner=None
        self.pipe_opens=[];self.bound_pid=None
        self.script_pin=self.pin(self.script);self.node_pin=self.pin(self.node)
        assert self.script_pin==plan['movingNodeScript']['pin']and self.node_pin==plan['nodeExecutable']['pin']
        assert Path(shutil.which('node')).resolve(strict=True)==self.node

    @staticmethod
    def pin(path):
        before=path.lstat();assert stat.S_ISREG(before.st_mode)and path.resolve(strict=True)==path
        raw=path.read_bytes();after=path.lstat()
        fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        value=dict(stat=[getattr(before,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest())
        assert value['stat']==[getattr(after,key)for key in fields];return value

    def bind(self,worker_class):
        assert self.worker is None and worker_class.__module__=='lifecycle_moving_raw_worker'
        self.worker=worker_class;self.start=worker_class.start
        self.start_code=self.start.__code__;self.start_globals=self.start.__globals__
        assert self.start_globals['subprocess']is subprocess
        assert Path(self.start_code.co_filename).resolve(strict=True)==Path(self.plan['movingWorkerSource']['path'])
        assert self.pin(Path(self.start_code.co_filename))==self.plan['movingWorkerSource']['pin']

    def check(self):
        assert subprocess.Popen is self.popen and os.environ.get('PATH')==self.environment_path
        assert self.readers==(os.fstat,os.readlink,sys._getframe,shutil.which)
        for name,function,code in self.popen_methods:assert getattr(self.popen,name)is function and function.__code__ is code
        assert self.worker is not None and self.worker.start is self.start and self.start.__code__ is self.start_code
        assert self.start.__globals__ is self.start_globals and self.start_globals['subprocess']is subprocess
        assert self.pin(self.script)==self.script_pin and self.pin(self.node)==self.node_pin
        assert Path(shutil.which('node')).resolve(strict=True)==self.node

    def frames(self,frame):
        self.check();outer=None;constructor=None;execute=None
        while frame is not None:
            if frame.f_code is self.start_code and frame.f_globals is self.start_globals:outer=frame
            for name,function,code in self.popen_methods:
                if frame.f_code is code and frame.f_globals is function.__globals__:
                    if name=='__init__':constructor=frame
                    else:execute=frame
            frame=frame.f_back
        assert outer is not None and constructor is not None
        worker=outer.f_locals['self'];child=constructor.f_locals['self']
        assert type(worker)is self.worker and type(child)is self.popen and worker.process is None
        assert constructor.f_locals['args']==self.command
        assert constructor.f_locals['stdin']==subprocess.PIPE and constructor.f_locals['stdout']==subprocess.PIPE and constructor.f_locals['stderr']==subprocess.PIPE
        assert constructor.f_locals['text']is True and constructor.f_locals['shell']is False
        assert constructor.f_locals['cwd']is None and constructor.f_locals['env']is None and constructor.f_locals['executable']is None
        assert constructor.f_locals['start_new_session']is False and constructor.f_locals['pass_fds']==()
        assert constructor.f_locals['process_group']==-1 and constructor.f_locals['preexec_fn']is None
        assert constructor.f_locals['close_fds']is True
        if self.pending is None:self.pending=child;self.owner=worker
        assert self.pending is child and self.owner is worker and not self.spawned
        return constructor,execute

    def pipe_open(self,args,frame):
        if type(args[0])is not int:return False
        descriptor,mode,flags=args
        if type(mode)is not str or not any(letter in mode for letter in'wax+'):return False
        info=os.fstat(descriptor)
        if not stat.S_ISFIFO(info.st_mode):return False
        constructor,unused=self.frames(frame)
        assert mode in('w','wb')and descriptor==constructor.f_locals['p2cwrite']
        target=os.readlink('/proc/self/fd/'+str(descriptor))
        assert stat.S_ISFIFO(info.st_mode)and target=='pipe:['+str(info.st_ino)+']'
        assert not self.pipe_opens
        self.pipe_opens.append(dict(descriptor=descriptor,device=info.st_dev,inode=info.st_ino,mode=info.st_mode))
        return True

    def spawn(self,args,frame):
        constructor,execute=self.frames(frame);assert execute is not None
        executable,command,cwd,env=args
        assert executable=='node'and command==self.command and cwd is None and env is None
        assert execute.f_locals['self']is self.pending and len(self.pipe_opens)==1
        self.spawned=True

    def finish(self):
        self.check();assert self.spawned and self.pending is not None and self.owner.process is self.pending
        process=self.pending;self.bound_pid=process.pid
        assert process.poll()==0 and not Path('/proc',str(process.pid)).exists()
        assert all(stream is not None and stream.closed for stream in(process.stdin,process.stdout,process.stderr))
        assert self.owner.reader is not None and not self.owner.reader.is_alive()and not self.owner.running
        browser=self.owner.browser
        assert browser.thread is not None and not browser.thread.is_alive()
        return dict(actualNodePid=process.pid,actualNodeReturnCode=process.returncode,pipeOpens=self.pipe_opens,
            actualPipeStreamsClosed=True,actualReaderExited=True,actualBrowserExited=True,
            exactCommand=self.command,nodeScript=self.plan['movingNodeScript'],nodeExecutable=self.plan['nodeExecutable'])


    def failed_case_ledger(self,worker,expected_kernel_children):
        """Negative no-birth evidence, never the positive finish() result.

        A partially entered Popen or a real child still requires its own drain.
        This narrow branch does not repair/relabel those states as no birth.
        """
        self.check()
        assert self.pending is None and self.owner is None and not self.spawned
        assert self.pipe_opens==[] and self.bound_pid is None
        actual_children=Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
        assert type(expected_kernel_children)is str and actual_children==expected_kernel_children
        state=dict(workerConstructed=worker is not None)
        if worker is not None:
            assert type(worker)is self.worker
            assert worker.process is None and worker.reader is None and worker.running is False
            assert worker.member is None and worker.engine is None and worker.requests==[]
            browser=worker.browser;assert type(browser)is self.start_globals['RawMarkerBrowser']
            assert browser.thread is None and browser.current is None
            state.update(process=None,reader=None,running=False,manager=None,engine=None,
                requests=[],browserThread=None,browserCurrent=None)
        return dict(negativeNoNodeBirthLedgerVersion=1,actualNodePid=None,nodeSpawnAuditObserved=False,
            noNodeStartedEstablished=True,positiveNodeDrainEstablished=False,pipeOpens=[],
            noControllerObservedPopen=True,kernelChildrenBefore=expected_kernel_children,
            kernelChildrenAfter=actual_children,actualWorkerState=state,
            exactCommand=self.command,nodeScript=self.plan['movingNodeScript'],
            nodeExecutable=self.plan['nodeExecutable'],wholeFeatureQualified=False)


class OwnedLoopbacks:
    def __init__(self):
        self.servers=[]
        self.socket_class=socket.socket
        self.receivers=tuple((name,getattr(socket.socket,name))for name in('getsockname','getsockopt','fileno'))
        self.readers=(os.fstat,ipaddress.ip_address)
        self.host_readers=_ORIGINAL_HOST_READERS;self.host_readers_fresh=_HOST_READERS_FRESH
        assert self.host_readers_fresh()is self.host_readers
        self.host_reader_codes=tuple(dict(receiver=name,codeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest())
            for name,code in(('socket.getfqdn',self.host_readers[1]),('HTTPServer.server_bind',self.host_readers[5]),
                ('TCPServer.server_bind',self.host_readers[8])))
        self.resolver_reads=[]

    def check(self):
        assert socket.socket is self.socket_class and self.readers==(os.fstat,ipaddress.ip_address)
        assert self.host_readers_fresh is _HOST_READERS_FRESH and self.host_readers is _ORIGINAL_HOST_READERS
        assert self.host_readers_fresh()is self.host_readers
        assert all(getattr(self.socket_class,name)is function for name,function in self.receivers)

    def endpoint(self,family,address):
        assert type(address)is tuple
        if family==socket.AF_INET:
            assert len(address)==2 and address[0]=='127.0.0.1'
            host,port=address;tail=()
        else:
            assert family==socket.AF_INET6 and len(address)in(2,4)and address[0]=='::1'
            host,port=address[:2];tail=(0,0)if len(address)==2 else address[2:]
            assert len(tail)==2 and all(type(value)is int and value>=0 for value in tail)
        assert type(port)is int and 0<=port<=65535
        parsed=ipaddress.ip_address(host)
        assert parsed.is_loopback and parsed.version==(4 if family==socket.AF_INET else 6)
        return(host,port,*tail)

    def signature(self,owner):
        self.check();assert type(owner)is self.socket_class
        family=owner.family;assert family in(socket.AF_INET,socket.AF_INET6)
        assert self.socket_class.getsockopt(owner,socket.SOL_SOCKET,socket.SO_TYPE)==socket.SOCK_STREAM
        descriptor=self.socket_class.fileno(owner);assert descriptor>=0
        info=os.fstat(descriptor);assert stat.S_ISSOCK(info.st_mode)
        return(family,descriptor,info.st_dev,info.st_ino,info.st_mode)

    def current_servers(self):
        self.check();found=[]
        for owner,signature,requested in self.servers:
            if self.socket_class.fileno(owner)<0:continue
            assert self.signature(owner)==signature
            actual=self.endpoint(signature[0],self.socket_class.getsockname(owner))
            assert actual[0]==requested[0]and actual[2:]==requested[2:]and actual[1]>0
            found.append((signature[0],actual))
        return found

    def original_host_reverse(self,args,frame):
        self.check();held=self.host_readers
        assert type(args)is tuple and len(args)==1 and type(args[0])is str and args[0]in('127.0.0.1','::1')
        assert frame is not None and frame.f_code is held[1]and frame.f_globals is held[2]
        assert frame.f_locals.get('name')==args[0]
        parent=frame.f_back
        assert parent is not None and parent.f_code is held[5]and parent.f_globals is held[6]
        server=parent.f_locals['self']
        assert held[10]in type(server).__mro__ and type(server).server_bind is held[4]
        owner=server.socket;signature=self.signature(owner)
        own=next((row for row in self.servers if row[0]is owner),None);assert own is not None and own[1]==signature
        actual=self.endpoint(signature[0],self.socket_class.getsockname(owner))
        assert(signature[0],actual)in self.current_servers()
        assert self.endpoint(signature[0],server.server_address)==actual
        assert parent.f_locals['host']==args[0]==actual[0]and parent.f_locals['port']==actual[1]
        self.resolver_reads.append(dict(profile='scoped-original-host-resolver-read-v1',numericHost=args[0],
            family=int(signature[0]),actualBoundEndpoint=list(actual),socketDevice=signature[2],socketInode=signature[3],
            receiver='original-socket.getfqdn-to-original-HTTPServer.server_bind',nativeFact=False,
            noExternalNSSorDNSClaim=False))

    def audit(self,event,args,frame=None):
        if event=='socket.bind':
            owner,address=args;signature=self.signature(owner)
            endpoint=self.endpoint(signature[0],address);assert endpoint[1]==0
            assert not any(owner is old for old,unused,unused2 in self.servers)
            self.servers.append((owner,signature,endpoint))
        elif event=='socket.connect':
            owner,address=args;signature=self.signature(owner)
            endpoint=self.endpoint(signature[0],address)
            assert(signature[0],endpoint)in self.current_servers()
        elif event=='socket.getaddrinfo':
            # The actual urllib connection asks with numeric host/port; no DNS,
            # localhost alias, foreign family/scope or external resolver is admitted.
            host,port,family,kind,protocol=args
            assert type(host)is str and host in('127.0.0.1','::1')and type(port)is int
            assert family in(0,socket.AF_UNSPEC,socket.AF_INET,socket.AF_INET6)
            assert kind==socket.SOCK_STREAM and protocol in(0,socket.IPPROTO_TCP)
            expected_family=socket.AF_INET if host=='127.0.0.1'else socket.AF_INET6
            assert family in(0,socket.AF_UNSPEC,expected_family)
            assert any(actual_family==expected_family and actual[0]==host and actual[1]==port
                and actual[2:]==(()if expected_family==socket.AF_INET else(0,0))
                for actual_family,actual in self.current_servers())
        elif event=='socket.gethostbyaddr':self.original_host_reverse(args,frame)
        elif event in('socket.sendto','socket.sendmsg','socket.gethostbyname','socket.getnameinfo'):
            raise RuntimeError('No datagram or external/name resolution transport admitted')

    def finish(self):
        self.check();assert self.servers and all(self.socket_class.fileno(owner)==-1 for owner,unused,unused2 in self.servers)
        return dict(ownedServerSockets=len(self.servers),allOwnedServerSocketsClosed=True,
            scopedOriginalHostResolverRead=list(self.resolver_reads),originalHostReaderCodes=self.host_reader_codes,
            noExternalNSSorDNSClaim=False,
            originalBindEndpoints=[dict(family=int(signature[0]),address=list(endpoint))for owner,signature,endpoint in self.servers])
