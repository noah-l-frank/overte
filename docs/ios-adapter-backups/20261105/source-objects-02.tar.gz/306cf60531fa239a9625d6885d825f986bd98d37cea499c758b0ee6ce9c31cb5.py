"""Controller-only original ports for one owned Assets fixture prefix.

The unchanged Audio utility OwnedWrites supplies canonical FD/dir_fd custody.
This adapter admits the actual main thread, two real HTTP producers and exact
original Popen pipe construction; it supplies no product/Whole authority.
"""
from pathlib import Path
from types import MappingProxyType
import builtins,io,os,socketserver,stat,subprocess,sys,threading
from owned_write_boundary import OwnedWrites,WriteRefusal


class FixturePorts:
    def __init__(self,root,runroot,save_function,controller_namespace,controller_frame,expected_node):
        self.root=Path(root).resolve(strict=True);self.runroot=Path(runroot).resolve(strict=True)
        if self.root.parent!=self.runroot:raise WriteRefusal('Exact owned temporary room required')
        self.main=threading.current_thread();self.namespace=controller_namespace
        self.controller_codes={controller_frame.f_code};self.callback_functions=[]
        self.save=save_function;self.save_code=save_function.__code__;self.save_globals=save_function.__globals__
        self.save_ports=self.save_globals['_ORIGINAL_SAVE_PORTS'];self.save_port_items=tuple(self.save_ports)
        self.original_io,self.original_builtin=io.open,builtins.open
        names=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate',
            'fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod',
            'posix_fallocate','sendfile','copy_file_range','splice')
        self.original_items=tuple((name,getattr(os,name))for name in names if hasattr(os,name))
        self.original=MappingProxyType(dict(self.original_items));self.ports={};self.port_seals=[]
        self.helpers={};self.helper_records=[];self.servers=[];self.pipe_opens=[]
        self.popen=subprocess.Popen.__init__;self.popen_code=self.popen.__code__;self.popen_globals=self.popen.__globals__
        self.expected_node=tuple(expected_node);self.http_code=socketserver.ThreadingMixIn.process_request_thread.__code__
        self.installed=False;self.closed=False
        self.implementation=tuple((name,member,member.__code__)for name,member in type(self).__dict__.items()
            if callable(member)and hasattr(member,'__code__'))
        self.bind_callbacks((save_function,))

    def bind_callbacks(self,functions):
        if threading.current_thread()is not self.main or self.closed:raise WriteRefusal('Controller callback binding lifetime')
        for function in functions:
            if function.__globals__ is not self.namespace and function is not self.save:raise WriteRefusal('Foreign controller callback')
            self.callback_functions.append((function,function.__code__,function.__globals__))
            self.controller_codes.add(function.__code__)

    def check(self):
        for name,member,code in self.implementation:
            if type(self).__dict__.get(name)is not member or member.__code__ is not code:raise WriteRefusal('Fixture port implementation changed')
        if self.save.__code__ is not self.save_code or self.save.__globals__ is not self.save_globals:raise WriteRefusal('Observer save changed')
        if self.save_globals.get('save')is not self.save or self.save_globals.get('_ORIGINAL_SAVE_PORTS')is not self.save_ports:
            raise WriteRefusal('Actual observer save binding changed')
        if any(a is not b for a,b in zip(self.save_ports,self.save_port_items))or len(self.save_ports)!=len(self.save_port_items):
            raise WriteRefusal('Original observer syscall receivers changed')
        for function,code,namespace in self.callback_functions:
            if function.__code__ is not code or function.__globals__ is not namespace:raise WriteRefusal('Controller callback changed')
        if subprocess.Popen.__init__ is not self.popen or self.popen.__code__ is not self.popen_code:
            raise WriteRefusal('Original Popen installation changed')
        if self.popen.__globals__ is not self.popen_globals or socketserver.ThreadingMixIn.process_request_thread.__code__ is not self.http_code:
            raise WriteRefusal('Original constructor/HTTP frame changed')
        if self.installed:
            if any(getattr(os,name)is not port for name,port in self.ports.items()):raise WriteRefusal('Installed fixture port changed')
            for function,code,defaults,keywords,items,closure,contents in self.port_seals:
                if (function.__code__ is not code or function.__closure__ is not closure or function.__defaults__ is not defaults
                        or function.__kwdefaults__ is not keywords):raise WriteRefusal('Fixture router code/closure/defaults changed')
                if tuple(keywords or ())!=tuple(key for key,value in items)or any(keywords[key]is not value for key,value in items):
                    raise WriteRefusal('Fixture router keyword contents changed')
                if any(cell.cell_contents is not value for cell,value in zip(closure or (),contents)):raise WriteRefusal('Fixture router receiver changed')
        if io.open is not self.original_io or builtins.open is not self.original_builtin:raise WriteRefusal('Original C IO replaced')

    def add_server(self,server,thread,producer_root):
        self.check()
        if threading.current_thread()is not self.main or len(self.servers)>=2:raise WriteRefusal('Unexpected producer constructor')
        root=Path(producer_root).resolve(strict=True)
        if not root.is_relative_to(self.root)or root==self.root:raise WriteRefusal('HTTP producer outside own real TD')
        if not thread.is_alive()or server.socket.getsockname()[0]!='127.0.0.1':raise WriteRefusal('Actual live loopback server required')
        if any(row[0]is server for row in self.servers):raise WriteRefusal('Repeated server birth')
        self.servers.append((server,thread,root,server.socket.fileno(),server.socket.getsockname()))

    def helper(self):
        self.check()
        if self.closed:raise WriteRefusal('Fixture writes after cleanup lifetime')
        current=threading.current_thread();root=self.root
        if current is not self.main:
            frame=sys._getframe(1);found=None
            while frame is not None:
                if frame.f_code is self.http_code:
                    server=frame.f_locals.get('self')
                    found=next((row for row in self.servers if row[0]is server),None)
                    break
                frame=frame.f_back
            if found is None:raise WriteRefusal('Write outside genuine selected HTTP request frame')
            server,thread,root,descriptor,address=found
            if not thread.is_alive()or server.socket.fileno()!=descriptor or server.socket.getsockname()!=address:
                raise WriteRefusal('HTTP constructor/socket lifetime changed')
        helper=self.helpers.get(current)
        if helper is None:
            # Genuine utility constructor first. Its original-port map is
            # completed with independently held actual syscalls before its
            # first mutation, because router aliases are already installed.
            helper=OwnedWrites(root)
            helper.original=self.original;helper.original_items=self.original_items
            self.helpers[current]=helper;self.helper_records.append((current,helper,root))
        if helper.root!=root or helper.thread!=threading.get_ident()or helper.original is not self.original or helper.original_items is not self.original_items:
            raise WriteRefusal('Actual writer receiver/root/original port changed')
        helper._check();return helper

    def controller_save(self,event,args,caller):
        if event!='open'or caller.f_code is not self.save_code or caller.f_globals is not self.save_globals:return False
        if threading.current_thread()is not self.main:raise WriteRefusal('Observer write from foreign thread')
        parent=caller.f_back
        if parent is None or parent.f_globals is not self.namespace or parent.f_code not in self.controller_codes:
            raise WriteRefusal('Observer save initiated outside actual controller frame')
        value,mode,flags=args
        path=Path(os.fsdecode(value))if type(value)in(str,bytes)else None
        expected=caller.f_locals.get('path')
        if path is None or path!=expected or not path.is_absolute()or path.resolve(strict=False)!=path or path.parent!=self.runroot:
            raise WriteRefusal('Observer self/path scope changed')
        if mode is not None or flags!=(os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_CLOEXEC',0)):raise WriteRefusal('Observer original open flags changed')
        return True

    def original_node_pipe(self,event,args,caller):
        if event!='open'or type(args[0])is not int or caller.f_code is not self.popen_code:return False
        self.check();value,mode,flags=args
        owner=caller.f_locals.get('self');arguments=caller.f_locals.get('args')
        if (caller.f_globals is not self.popen_globals or type(owner)is not subprocess.Popen
                or type(arguments)not in(tuple,list)or any(type(item)is not str for item in arguments)
                or tuple(arguments)!=self.expected_node):
            raise WriteRefusal('Pipe outside exact genuine Node Popen receiver/argv')
        if value!=caller.f_locals.get('p2cwrite')or mode not in('w','wb'):raise WriteRefusal('Unknown original Popen writable FD')
        info=os.fstat(value)
        if not stat.S_ISFIFO(info.st_mode)or not os.readlink('/proc/self/fd/'+str(value)).startswith('pipe:['):raise WriteRefusal('Original Popen FD is not its actual pipe')
        self.pipe_opens.append((owner,value,info.st_dev,info.st_ino));return True

    def audit(self,event,args,caller):
        relevant=event in('open','os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.utime','os.truncate',
            'os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
        if not relevant:return
        if event=='open':
            value,mode,flags=args
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
            if not writing:return
            self.check()
            if self.controller_save(event,args,caller)or self.original_node_pipe(event,args,caller):return
        relevant=event in('open','os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.utime','os.truncate',
            'os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
        if relevant:self.helper().audit(event,args,caller)

    def install(self):
        self.check()
        if self.installed or self.closed:raise WriteRefusal('Fixture port birth repeated')
        for name,original in self.original_items:
            if name=='close':continue
            def port(*args,_name=name,**kwargs):
                helper=self.helper()
                return helper.os_open(*args,**kwargs)if _name=='open'else helper.mutate(_name,*args,**kwargs)
            self.ports[name]=port
            self.port_seals.append((port,port.__code__,port.__defaults__,port.__kwdefaults__,tuple((port.__kwdefaults__ or{}).items()),port.__closure__,tuple(c.cell_contents for c in port.__closure__ or())))
            setattr(os,name,port)
        self.installed=True;self.check()

    def restore(self):
        self.check()
        for _thread,helper,_root in self.helper_records:
            if helper.control_fds:raise WriteRefusal('Actual parent FD not drained')
            helper.close()
        for name,original in self.original_items:setattr(os,name,original)
        self.installed=False;self.closed=True
        if any(getattr(os,name)is not original for name,original in self.original_items):raise WriteRefusal('Actual OS FD/dir_fd aliases not restored')
        if io.open is not self.original_io or builtins.open is not self.original_builtin:raise WriteRefusal('C IO aliases not restored')
        return dict(originalPortsRestored=True,originalCIOUnchanged=True,writerThreads=len(self.helper_records),
            parentDescriptorsDrained=True,originalNodeWritablePipeOpens=len(self.pipe_opens),
            scope='selected fixture TDs and exact two real HTTP producer roots only',wholeAbsence=False)
