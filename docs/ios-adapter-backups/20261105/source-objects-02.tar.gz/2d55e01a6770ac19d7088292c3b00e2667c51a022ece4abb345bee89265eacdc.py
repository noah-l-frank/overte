"""Actual canonical contexts rebuilt without SDK/native acquisition.

Completed/saved-pending action originals, old episode graphs and exact page
namespace membership are mandatory. Uncommitted metadata is not adopted.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import unpack
from ios.adapters.assets_action_phase import AssetsActionPhases
from ios.adapters.assets_born_page_lease import BornAssetsPageLease
from ios.adapters.assets_dead_page_retirement import AssetsDeadPageRetirement
from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
from ios.adapters.assets_episodes import AssetsEpisodes,AssetsEpisodeScope
from ios.adapters.assets_generation_page_inventory import archive_generation_page,assert_page_namespace
from ios.adapters.assets_generation_page_lease import GenerationAssetsPageLease
from ios.adapters.assets_page_birth import AssetsPageBirth
from ios.adapters.assets_page_generations import AssetsPageGenerations,AssetsPageGenerationContext,EPISODES
from ios.adapters.assets_page_reentry import AssetsPageReentry


def reconstruct_page_generations(episodes,actions,scopes,*,live=False):
    need(type(episodes) is AssetsEpisodes and type(actions) is AssetsActionPhases and actions.selected is episodes.selected
        and type(scopes) is tuple and type(live) is bool and [scope.index for scope in scopes]==list(range(1,len(episodes.state['entries'])+1))
        and all(type(scope) is AssetsEpisodeScope and scope.owner is episodes for scope in scopes))
    for scope in scopes:
        scope.guard()
        for lock in scope.locks.values():lock.assert_held()
    root=Path(episodes.context['roles']['primary']['stateRoot'])
    store=PrivateFeatureState(root/('ios-assets-page-generations-'+episodes.run+'-primary.json'))
    value=store.read();need(value is not None)
    rows=unpack(value['payload']);need(len(rows)==1 and type(rows[0]) is dict and type(rows[0].get('entries')) is list)
    count=len(rows[0]['entries']);need(1<=count<=4);contexts={};reports=[]
    for generation in range(1,count+1):
        if generation==1:
            birth=AssetsPageBirth.from_prefix(episodes.selected,
                PrivateFeatureState(root/('ios-assets-page-birth-'+episodes.run+'-primary.json')),
                episodes.locks['primary'],actions)
        else:
            old_scope=scopes[generation-1]
            graph=AssetsEpisodeModelGraph(old_scope,reports[-1]['owner'],actions=actions,dependency_mode=True).decode()
            retirement=AssetsDeadPageRetirement.from_archive(graph,actions,
                PrivateFeatureState(graph.root/('ios-assets-dead-page-clients-'+episodes.run+'-primary.json')))
            retirement.retired();old=contexts[generation-1]
            contexts[generation-1]=AssetsPageGenerationContext(old.birth,old.page,retirement)
            birth=AssetsPageReentry.from_archive(episodes.selected,
                PrivateFeatureState(root/('ios-assets-page-reentry-'+episodes.run+'-primary-g'+str(generation)+'.json')),
                episodes.locks['primary'],actions,action_index={2:9,3:16,4:22}[generation],removal=graph.removal)
        members=tuple(scope for scope in scopes if scope.index in EPISODES[generation])
        report=archive_generation_page(episodes,generation,birth,members);reports.append(report)
        contexts[generation]=AssetsPageGenerationContext(birth,report['owner'])
    assert_page_namespace(root,episodes.run,reports,store)
    if live and not rows[0]['entries'][-1]['closed'] and not rows[0]['entries'][-1]['retirement']:
        context=contexts[count];archived=context.page
        if count==1:
            page=BornAssetsPageLease(episodes,PrivateFeatureState(archived.store.path),episodes.locks['primary'],
                birth=context.birth,pickers=archived.pickers)
        else:
            page=GenerationAssetsPageLease(episodes,PrivateFeatureState(archived.store.path),episodes.locks['primary'],
                reentry=context.birth,pickers=archived.pickers)
        for picker in page.pickers.values():picker.page_lease=page
        contexts[count]=AssetsPageGenerationContext(context.birth,page)
    owner=AssetsPageGenerations(episodes,actions,store,contexts=contexts,historical=not live)
    owner.guard();return dict(owner=owner,pageReports=reports,completeDirectoryRead=False,
        nativeFactsProduced=False,wholeEndEligible=False)
