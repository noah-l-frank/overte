"""Root exact786 old custody around original Assets nine-counter supervisor."""
from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys
R=Path.cwd()/'.ios-host-tmp';D=Path(__file__).resolve().parent
C=R/'root-ios-current786-after-world-b5-gpu-clock-negative-context-20261104'
H=R/'assets-c22-own9-prepared-head9d58-b2-20261104'
SHA='41c71038d03c8a56dacace09d62b7e959ccaaae3ce336107de7104b1f6f72003'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,v):
 p=D/n
 with p.open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 p.chmod(0o600)
assert sys.flags.no_site and sys.dont_write_bytecode
assert sha(H/'approved-inputs.json')==SHA
assert sha(C/'root-context.json')=='b10a2f8840d23d01fd2642391feb6726473694a3eac4e50a83e710ff45fb1319'
assert sha(C/'global_original_corpus.py')=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
helper=runpy.run_path(str(C/'global_original_corpus.py'));expected=json.loads((C/'global-original-corpus-baseline.json').read_text());before=helper['current']()
assert before==expected and len(before)==786
plan=json.loads((H/'approved-inputs.json').read_text());assert len(plan['qualifiedCurrentSourceExecution']['requiredOriginalRoots'])==6 and set(plan['qualifiedCurrentSourceExecution']['requiredOriginalRoots'])<=set(expected)
put('global-before.json',before);put('preflight.json',dict(status='ALL_786_OLD_ORIGINAL_BODIES_MATCH',roots=len(before)))
outer=H.with_name(H.name+'-outer');closed=H.with_name(H.name+'-closed-censuses')
put('attempted-utility.json',dict(input=str(H/'approved-inputs.json'),sha256=SHA,prospectiveOriginalRooms=list(map(str,[H,outer,closed,D])),ownProcessAbsenceNotYetEstablished=True))
print('ROOT_786_PREFLIGHT_PASS_ASSETS_OWN9_START',flush=True)
with(D/'supervisor-stdout.log').open('xb')as out,(D/'supervisor-stderr.log').open('xb')as err:
 result=subprocess.run([sys.executable,'-S','-B',str(H/'supervise-nine.py'),SHA],cwd=Path.cwd(),env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err)
put('supervisor-return.json',dict(returnCode=result.returncode))
terminal=json.loads((outer/'terminal.json').read_text());assert terminal['remainingOwned']==[]
for own in terminal['ownedProcesses']:
 try:raw=Path('/proc',str(own['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 values=raw[raw.rfind(')')+2:].split();assert int(values[19])!=own['startTicks'],'Original owned process still exists'
closed_body=json.loads((closed/'closed.json').read_text());assert closed_body['twoWholeHEREEqual']and closed_body['twoWholeOuterEqual']and closed_body['exclusions']==[]
first=helper['current']();second=helper['current']();assert first==second==expected
put('global-after-first.json',first);put('global-after-second.json',second)
put('postflight.json',dict(status='ALL_786_OLD_ORIGINAL_BODIES_UNCHANGED_BOTH_POST_STOP_CENSUSES',roots=len(first),censuses=3,supervisorReturnCode=result.returncode,actualUtilityStatus=terminal['status'],allProcessesAbsent=True))
put('freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in D.iterdir()if p.is_file()}))
print(json.dumps(dict(returnCode=result.returncode,status=terminal['status'],freeze=sha(D/'freeze.json'))),flush=True)
