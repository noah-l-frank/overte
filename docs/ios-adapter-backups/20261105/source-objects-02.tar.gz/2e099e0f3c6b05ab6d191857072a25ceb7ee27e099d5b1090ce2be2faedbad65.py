"""Actual source deadlines/worker/files; only producer SDK and latency are models."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,json,time
from unittest.mock import patch
from test_resource4_observation_models import Resource4ObservationModels


class Resource4NativeBookendModels(Resource4ObservationModels):
    def worker_phase(self,resource):
        step=resource._native_step
        if step is None or step._worker is None or asyncio.current_task() is not step._worker():return None
        lease=step._lease()
        return 'after-down' if lease.down_issued else 'before-down'
    async def test_actual_anchor_stays_inside_original_deadline_but_each_new_native_interval_starts_after_its_historical_proof(self):
        from ios.adapters.lifecycle_touch_resource_owner import _NativeMotionReference
        original=_NativeMotionReference.anchor;events={}
        def observed(reference,source,resource,owner):
            phase=self.worker_phase(resource)
            if phase is None:return original(reference,source,resource,owner)
            before=asyncio.get_running_loop().time();value=original(reference,source,resource,owner)
            events[phase]=(before,asyncio.get_running_loop().time());return value
        with patch.object(_NativeMotionReference,'anchor',observed):await self.open_motion()
        self.assertEqual({'before-down','after-down'},set(events));self.assertEqual(16,len(self.commands))
        self.assertEqual([0xC2,0xC2],self.f.states());self.assertEqual(2,len(self.source._native_current_tasks))
        # Default preparation receipt remains exactly started+1.5. No native
        # field or prior original has been changed to meet the new interval.
        old=self.resource._motion_original;self.assertEqual(old._started+1.5,old._deadline)
        for task in self.source._native_current_tasks:
            self.assertTrue(task.done());receipt=task.result();before,after=events[receipt._worker_phase]
            self.assertGreaterEqual(receipt._started,after)
            self.assertLessEqual(receipt._deadline,before+1.5)
            self.assertLess(receipt._deadline,receipt._started+1.5)
            # Inspect the ACTUAL immutable saved frame as metadata; real source
            # admission/byte read/clock join have already run before this Task
            # returned. No host dictionary can supply its original receipt.
            frame=json.loads(self.frame_path(receipt.reference).read_bytes())['frame']
            self.assertEqual(receipt._started,frame['clockJoin']['hostBeforeMonotonic'])
            self.assertLess(frame['clockJoin']['hostAfterMonotonic'],receipt._deadline)
        await self.passive_rpc('touch-release',{});self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes())
    async def delayed_anchor_refusal(self,phase):
        from ios.adapters.lifecycle_touch_resource_owner import _NativeMotionReference
        original=_NativeMotionReference.anchor;observed=[]
        def delayed(reference,source,resource,owner):
            value=original(reference,source,resource,owner)
            if self.worker_phase(resource)==phase:
                before=asyncio.get_running_loop().time();count=len(self.commands)
                # REAL elapsed latency, never a fake native/host clock jump.
                time.sleep(1.55)
                observed.append(dict(before=before,after=asyncio.get_running_loop().time(),queries=count))
            return value
        args=await self.prepare_rpc()
        with patch.object(_NativeMotionReference,'anchor',delayed):packet,_=await self.rpc_begin(args)
        self.assertEqual('failed',packet['status']);self.assertEqual(1,len(observed))
        self.assertGreaterEqual(observed[0]['after']-observed[0]['before'],1.5)
        self.assertEqual(observed[0]['queries'],len(self.commands)) # No new Native query after expired original budget.
        worker=self.ops.touch.worker;await worker
        self.assertFalse(worker.cancelled());self.assertTrue(self.ops.touch.closed)
        self.assertEqual([],self.f.states() if phase=='before-down' else self.f.states()[:-2])
        self.assertEqual([] if phase=='before-down' else [0xC2,0x02],self.f.states())
        self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes())
        self.assertTrue(all(fd.fileno()==-1 for fd in self.resource_receiver.sockets));self.assertEqual(1,len(self.resource_display.stops))
    async def test_real_delayed_before_down_anchor_cannot_restart_budget_or_issue_any_down_or_new_query(self):
        await self.delayed_anchor_refusal('before-down')
    async def test_real_delayed_after_down_anchor_cannot_restart_budget_or_issue_move_and_original_up_still_returns(self):
        await self.delayed_anchor_refusal('after-down')
