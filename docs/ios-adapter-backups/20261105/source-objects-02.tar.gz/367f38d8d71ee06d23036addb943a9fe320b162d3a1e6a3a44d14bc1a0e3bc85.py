"""Genuine original TD/cleanup scopes; no feature/native/SDK authority."""
from pathlib import Path
from types import FrameType,FunctionType
import os,stat,sys,threading
class AudioResources:
    def __init__(self,root,recipe):
        self.root=Path(root);self.recipe=recipe;self.main=threading.get_ident();self.rows=[];self.controls=[];self.objects=[]
    def bind(self):
        for module_name,class_name in(('ios.self_tests.test_ios_audio_recorded_owner','AudioRecordedOwnerTests'),('ios.self_tests.test_ios_audio_family12_dispatch','AudioFamily12DispatchTests')):
            module=sys.modules[module_name];cls=vars(module)[class_name];fn=vars(cls)['setUp']
            assert type(fn)is FunctionType and fn.__globals__ is vars(module)
            self.controls.append((module,module_name,cls,class_name,fn,fn.__code__,fn.__globals__,fn.__defaults__,fn.__kwdefaults__,fn.__closure__))
        module=sys.modules['ios.self_tests.retained_host_roots'];fn=vars(module)['retain_owned_root']
        self.retainer=(module,fn,fn.__code__,fn.__globals__,fn.__defaults__,fn.__kwdefaults__,fn.__closure__)
    def caller(self,frame,args,kwargs):
        assert type(frame)is FrameType and threading.get_ident()==self.main and not args and not kwargs
        assert len(self.rows)<self.recipe['expectedTDs'];found=[]
        for module,name,cls,class_name,fn,code,ns,defaults,keywords,closure in self.controls:
            assert sys.modules[name]is module and vars(module)[class_name]is cls and vars(cls)['setUp']is fn
            assert fn.__code__ is code and fn.__globals__ is ns and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
            if frame.f_code is code and frame.f_globals is ns and type(frame.f_locals.get('self'))is cls:found.append((name,frame.f_locals['self']))
        assert len(found)==1;return found[0]
    def retain(self,directory,caller):
        root=Path(directory.name);info=root.lstat();assert root.parent==self.root and root.resolve(strict=True)==root
        assert stat.S_ISDIR(info.st_mode)and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
        module,fn,code,ns,defaults,keywords,closure=self.retainer
        assert vars(module)['retain_owned_root']is fn and fn.__code__ is code and fn.__globals__ is ns and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
        fn(directory,expected_root=root);self.objects.append(directory)
        self.rows.append(dict(path=str(root),device=info.st_dev,inode=info.st_ino,callerModule=caller[0],actualCallerIdentity=id(caller[1])))
    def report(self):
        assert len(self.rows)==len(self.objects)==self.recipe['expectedTDs']
        for row,directory in zip(self.rows,self.objects):
            p=Path(row['path']);s=p.lstat();assert (s.st_dev,s.st_ino)==(row['device'],row['inode'])and p==Path(directory.name)and p.resolve(strict=True)==p
            assert directory._finalizer.alive is False
        return dict(actualTemporaryDirectories=self.rows,temporaryDirectoryAbsenceClaimed=False,realNodeExecutions=0,realSDKExecutions=0,nativeQualified=False,wholeQualified=False)
