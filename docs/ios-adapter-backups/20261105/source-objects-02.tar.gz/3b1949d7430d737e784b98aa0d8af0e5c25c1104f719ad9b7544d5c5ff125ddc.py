"""Actor stage admission from actual Primary End/readmission/restoration originals.

A copied replacement header never grants live admission. The independent Actor
replays the exact Primary owners and retained old/new original stores before
publishing from its separate replacement current stream. All old frames stay.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.script_feature.history import same

TRANSITIONAL=('cleaning','replacing','ending','ended','aborting','aborted')
ADOPTABLE=('cleaned','terminal-ready')
INITIAL=('ready','acting')
STATE_KEYS={'phase','bindings','baseline','actions','pending','sequence','publication','restoration','artifacts','cleanupTicket','terminal','failure','oldEnd','replacement','publicIndex','preparationDone','replacementRestoration','actorEnd'}


def primary(flow):
    from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
    f=flow;need(f.role=='actor');f.guard()
    peer=IOSAudioWholeFeature(f.adapter,f.primary_selector,f.run,'primary',f.client,f.config,
        epoch_ms=f.epoch_ms,monotonic=f.monotonic,sleep=f.sleep,
        runtimes=(f.actor_runtime,f.primary_runtime),source_locks=f.locks)
    peer.load();need(peer.state is not None and same(peer.state['bindings'],f.state['bindings']))
    return peer


def validate(flow):
    """Pure archived join; uses the actual Primary typed retired scope."""
    from ios.adapters.audio_whole_terminal import AudioWholeTerminal
    f=flow;peer=primary(f)
    need(f.state['replacement'] is not None and same(f.state['replacement'],peer.state['replacement'])
        and same(f.state['oldEnd'],peer.state['oldEnd']))
    return AudioWholeTerminal(peer).validate_replacement_restoration()


def synchronize(flow):
    from ios.adapters.audio_whole_feature import AudioWholePending,NAME
    from ios.adapters.audio_whole_terminal import AudioWholeTerminal
    f=flow;need(f.role=='actor'and f.state is not None);f.guard()
    store=PrivateFeatureState(f.adapter.state_path(f.primary_selector).with_name(NAME.format('primary')))
    header=store.read()
    exact(header,{'iosAudio11WholeVersion','runId','role','primaryTarget','fixtureUrl','settings','state'})
    need(type(header['iosAudio11WholeVersion'])is int and header['iosAudio11WholeVersion']==1
        and header['runId']==f.run and header['role']=='primary'and header['primaryTarget']==f.primary_selector
        and header['fixtureUrl']==f.client.url and same(header['settings'],f.config))
    hint=header['state'];exact(hint,STATE_KEYS);exact(hint['bindings'],{'primary','actor'})
    for binding in hint['bindings'].values():context(binding)
    need(same(hint['bindings'],f.state['bindings'])and type(hint['preparationDone'])is bool)
    phase=hint['phase'];need(type(phase)is str and phase in INITIAL+TRANSITIONAL+ADOPTABLE+('preparing',))
    if phase=='preparing':raise AudioWholePending('Actual Primary preparation remains pending')
    if phase in TRANSITIONAL:
        # Strict header/binding identity is sufficient to WAIT. Partial live
        # transaction metadata cannot authorize adoption or require historical
        # End/media replay merely to retain the current pending responsibility.
        raise AudioWholePending('Actual Primary replacement or End remains in progress')
    if phase in INITIAL and hint['replacement']is None and hint['oldEnd']is None:
        # A fully matching known initial envelope grants no stage or custody
        # change. No media replay is needed to retain the already admitted
        # initial binding; the independent live Source guards remain fresh.
        need(hint['preparationDone']and f.state['replacement']is None and f.state['oldEnd']is None);return False
    peer=primary(f)
    need(peer.state['phase']in ADOPTABLE and peer.state['replacement']is not None)
    terminal=AudioWholeTerminal(peer);proof=terminal.validate_replacement_restoration()
    need(len(peer.state['replacementRestoration']['verified'])==2
        and proof['newBinding']==peer.state['replacement']['newBinding'])
    if f.state['replacement']is None:
        need(f.state['oldEnd']is None)
        f.state['oldEnd']=deepcopy(peer.state['oldEnd']);f.state['replacement']=deepcopy(peer.state['replacement']);f.state['cleanupTicket']=peer.state['cleanupTicket'];f.save()
    else:need(same(f.state['oldEnd'],peer.state['oldEnd'])and same(f.state['replacement'],peer.state['replacement'])
        and f.state['cleanupTicket']==peer.state['cleanupTicket'])
    # Recheck all actual Parent/scope/readmission originals after the Actor CAS.
    # Fresh attach() still binds the real new installed Source independently.
    validate(f);return True
