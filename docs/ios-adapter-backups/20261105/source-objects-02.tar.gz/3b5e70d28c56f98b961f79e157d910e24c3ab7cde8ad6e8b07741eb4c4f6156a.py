"""Six separate exact Chat identity/legacy selections; no discovery/native execution."""
from pathlib import Path
import json,os,stat,sys,tempfile,threading,types,unittest
from importlib.machinery import PathFinder
from run_metadata import HERE,REPO,pin,proc,publication,save,sha,sources,registry_original,validate_frozen
assert len(sys.argv)==2 and sys.argv[1] in validate_frozen()['allowedRunKinds']
kind=sys.argv[1];plan=validate_frozen();selected=plan['suites'][kind];publication()
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/(kind+'-publication-ready-source-map.json');assert ready.is_file(),'Root must refresh after source publication'
runroot=Path(os.environ['OVERTE_CHAT_LOADED_IDENTITY_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs'/kind) and runroot!=HERE/'runs'/kind
info=runroot.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
temporary=Path(os.environ['TMPDIR']).resolve(strict=True)
assert temporary==runroot/'temporary' and Path(tempfile.gettempdir())==temporary
info=temporary.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
assert not any(temporary.iterdir()) and not (runroot/'selected-result.json').exists()
save(runroot/'runner-process-binding.json',proc(os.getpid()))
config=json.loads((HERE/'source-root-final-map.json').read_text())
approved=json.loads(ready.read_text());ready_pin=pin(ready)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
assert approved['broadSourceRoots']==plan['broadSourceRoots']
root=REPO.stat();assert approved['worktreeRoot']==str(REPO) and approved['rootIdentity']==dict(st_dev=root.st_dev,st_ino=root.st_ino)
source_before=sources(plan);assert source_before==approved['sourcePins'],'Current full Source membership/bytes differ from after-publication map'
assert 'interface/src/main.cpp' in source_before and approved['registry']==registry_original()
for row in config['modules'].values():assert row['path'] in source_before

def spec_without_import(name):
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:assert search is not None,name
    return spec

def preimport_source_roots():
    top_names={name.split('.')[0] for name in config['packageRoots']}
    assert not any(name.split('.')[0] in top_names for name in sys.modules),'Target imported before source preflight'
    expected=[str(REPO/name) for name in config['orderedRoots']];remaining=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==REPO or REPO in path.parents:continue
        if str(path) not in remaining:remaining.append(str(path))
    sys.path[:]=expected+remaining
    for name,relative in config['packageRoots'].items():
        spec=spec_without_import(name)
        assert [str(Path(path).resolve()) for path in spec.submodule_search_locations or ()]==[str(REPO/relative)],name
    actual={}
    for name,row in config['modules'].items():
        spec=spec_without_import(name);assert spec.origin is not None,name
        path=Path(spec.origin).resolve(strict=True)
        assert path==REPO/row['path'] and sha(path)==approved['sourcePins'][row['path']]['sha256'],name
        actual[name]=str(path)
    save(runroot/'preimport-source-map-actual.json',dict(orderedRoots=expected,modules=actual))
threads_before=set(threading.enumerate())
process_before_import=proc(os.getpid())
def current_group_processes():
    values=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        value=proc(int(path.name))
        if value is not None and (value['session']==process_before_import['session'] or value['processGroup']==process_before_import['processGroup']):values.append(value)
    return values
process_baseline={(row['pid'],row['startTicks']) for row in current_group_processes()}
save(runroot/'processes-before-target-imports.json',current_group_processes())
def remaining_children():
    return [row for row in current_group_processes() if (row['pid'],row['startTicks']) not in process_baseline]
def host_audit(event,args):
    if event=='import':
        assert not any(part in ('pymobiledevice3','tidevice','pyidevice','zeroconf') for part in args[0].split('.')),'SDK import forbidden'
    elif event=='subprocess.Popen':
        executable,argv=args[0],list(args[1]);name=Path(os.fsdecode(executable)).name
        node=(name=='node' and argv==['node',str(REPO/'tests/device/ios/self_tests/chat_message_script_domain.js'),str(REPO)])
        metadata=(name=='rg' and argv==['rg','--files','-0',*plan['broadSourceRoots']] and Path(args[2]).resolve()==REPO)
        assert node or metadata,'Only exact original Chat Node or pinned source metadata commands allowed'
    elif event in ('socket.connect','socket.bind'):
        address=args[1]
        if isinstance(address,tuple):assert address[0] in ('127.0.0.1','::1','localhost'),'Only owned loopback allowed'
sys.addaudithook(host_audit)
preimport_source_roots()
# Public originals remain unchanged; this explicitly tested complete private
# source is pinned alongside them, with actual import origins checked at end.
import importlib.abc,importlib.util
class Source14Overlay(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        for row in plan['privateSourceOverlays']:
            if fullname==row['module']:
                source=REPO/row['path'];assert sha(source)==row['sha256'] and str(source.relative_to(REPO)) in source_before
                return importlib.util.spec_from_file_location(fullname,source)
sys.meta_path.insert(0,Source14Overlay())
import importlib
fixture_modules=[] if kind=='profiles1' else [importlib.import_module(name) for name in (
    'ios.self_tests.test_ios_chat_draft_owner','ios.self_tests.test_ios_bundle_identity',
    'ios.self_tests.test_ios_installed_code','ios.self_tests.test_ios_chat_receive_runtime')]
from ios.self_tests.retained_host_roots import retain_owned_root
real_td=tempfile.TemporaryDirectory;retained=[];objects=[]
def retained_directory(*args,**kwargs):
    directory=real_td(*args,**kwargs);root=Path(directory.name)
    assert root.is_relative_to(temporary)
    root=retain_owned_root(directory,expected_root=root)
    retained.append(str(root));objects.append(directory)
    save(runroot/'created-original-roots.json',retained)
    print('RETAINED_ACTUAL_CHAT_IDENTITY_ROOT',root,flush=True)
    return directory
aliases=[(module,module.tempfile) for module in fixture_modules]
node_alias=None;node_children=[]
if selected['expectedNodeChildrenNotProof']>0:
    from ios.self_tests import chat_message_script_domain as node_fixture
    node_alias=node_fixture.subprocess
    def observed_node_popen(*args,**kwargs):
        # The exact existing producer is called unchanged. No wait/close, fake
        # return, new command, SDK source or process lifetime is supplied here.
        child=node_alias.Popen(*args,**kwargs)
        node_children.append((child,proc(child.pid)))
        return child
    node_fixture.subprocess=types.SimpleNamespace(Popen=observed_node_popen,PIPE=node_alias.PIPE)
result=None;actual_ids=[]

class ImmediateResult(unittest.TextTestResult):
    def report_exception(self,test,error,kind):
        import traceback
        # Preserve the original traceback immediately, BEFORE any optional
        # metadata diagnostic. Never capture generic locals or configuration.
        text=''.join(traceback.format_exception(*error))
        self.stream.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text)
        self.stream.flush()
        descriptor=os.open(runroot/'immediate-exceptions.log',os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
        with os.fdopen(descriptor,'a') as output:
            output.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text);output.flush();os.fsync(output.fileno())
    def addError(self,test,error):
        super().addError(test,error);self.report_exception(test,error,'ERROR')
    def addFailure(self,test,error):
        super().addFailure(test,error);self.report_exception(test,error,'FAILURE')
    def addSubTest(self,test,subtest,error):
        super().addSubTest(test,subtest,error)
        if error is not None:self.report_exception(subtest,error,'SUBTEST_ERROR')

try:
    for module,original in aliases:
        assert original is tempfile;module.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_directory)
    ids=selected['caseIds'];assert len(ids)==len(set(ids))==selected['count']
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for child in value:yield from flatten(child)
        else:yield value
    actual_ids=[test.id() for test in flatten(suite)]
    assert not loader.errors and actual_ids==ids and suite.countTestCases()==selected['count'],(loader.errors,actual_ids)
    save(runroot/'selected-ids-actual.json',actual_ids);print('ACTUAL_SELECTED_IDS',json.dumps(actual_ids),flush=True)
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=ImmediateResult).run(suite)
    assert result.testsRun==selected['count'] and not result.skipped,'All exact cases must execute without skip'
    if result.wasSuccessful():assert len(retained)==selected['expectedRetainedRootsNotProof'],'Unexpected actual root count'
finally:
    for module,original in aliases:module.tempfile=original
    if node_alias is not None:node_fixture.subprocess=node_alias
    assert tempfile.TemporaryDirectory is real_td and all(module.tempfile is original for module,original in aliases)
    imported={}
    for name,module in tuple(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if file is not None:
            path=Path(file).resolve()
            if REPO in path.parents:
                relative=str(path.relative_to(REPO));assert relative in source_before,(name,relative)
                imported[name]=relative
    for row in plan['privateSourceOverlays']:
        if row['module']!='ios.self_tests.test_ios_chat_loaded_historical_frame_round' or kind in ('frame3','frame4','frame6','frame7'):assert imported.get(row['module'])==row['path'],'Private changed source was not actually imported'
    save(runroot/'actual-imported-local-sources.json',imported)
    assert source_before==sources(plan) and pin(ready)==ready_pin,'Full Source/launcher/map membership changed'
    assert registry_original()==approved['registry'],'Root current registry/foreign Photo/PCM/World or own Chat6keys changed'
    def census():return {str(path.relative_to(temporary)):pin(path) for path in (temporary,*sorted(temporary.rglob('*')))}
    remaining_before=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
    nodes=[]
    for child,binding in node_children:
        nodes.append(dict(binding=binding,exitCode=child.poll(),
            stdinClosed=child.stdin.closed,stdoutClosed=child.stdout.closed,stderrClosed=child.stderr.closed))
    save(runroot/'actual-node-original-close-observations.json',nodes)
    processes_before_censuses=remaining_children()
    first=census();second=census();assert first==second,'Post-test originals changed'
    processes_after_censuses=remaining_children()
    save(runroot/'selected-originals-first.json',first);save(runroot/'selected-originals-second.json',second)
    remaining=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
    selection_complete=result is not None and result.testsRun==selected['count'] and not result.skipped
    node_close_complete=len(nodes)==selected['expectedNodeChildrenNotProof'] and all(row['binding'] is not None and row['exitCode']==0 and row['stdinClosed'] and row['stdoutClosed'] and row['stderrClosed'] for row in nodes)
    report=dict(kind=kind,testsRun=None if result is None else result.testsRun,selectedIds=actual_ids,
        successful=result is not None and result.wasSuccessful() and selection_complete and node_close_complete and not remaining_before and not remaining and not processes_before_censuses and not processes_after_censuses,skipped=[] if result is None else result.skipped,
        retainedTemporaryDirectoryRoots=retained,fixtureAliasesRestored=True,nodeProducerAliasRestored=node_alias is None or node_fixture.subprocess is node_alias,originalNodeCloseObservations=nodes,sourceLauncherPinsUnchanged=True,
        originalCensusesEqual=True,remainingOwnedChildrenBeforeCensuses=processes_before_censuses,remainingOwnedChildrenAfterCensuses=processes_after_censuses,remainingNewThreadsBeforeCensuses=remaining_before,remainingNewThreads=remaining,nativeCompiled=False,sdkExecuted=False,
        deviceQualified=False,wholeChatQualified=False,nativeDeviceQualified=False)
    save(runroot/'selected-result.json',report);print('ACTUAL_RESULT',json.dumps(report),flush=True)
    assert not remaining_before and not remaining,'New fixture/worker/listener thread remains live around censuses'
    assert not processes_before_censuses and not processes_after_censuses,'Actual Node/child process remains live around censuses'
    if result is not None and result.wasSuccessful():
        assert len(nodes)==selected['expectedNodeChildrenNotProof']
        assert all(row['binding'] is not None and row['exitCode']==0 and row['stdinClosed'] and row['stdoutClosed'] and row['stderrClosed'] for row in nodes),'Existing Node close did not actually finish cleanly'
sys.exit(0 if result is not None and result.wasSuccessful() else 1)
