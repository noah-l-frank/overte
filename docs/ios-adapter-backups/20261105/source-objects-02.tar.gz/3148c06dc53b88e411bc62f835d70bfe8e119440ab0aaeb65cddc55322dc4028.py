"""Prospective exact stdlib-only kernel identity/cleanup counters. No Parent."""
from pathlib import Path
import hashlib,importlib.util,json,os,stat,sys,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent
EXPECTED='b647806f9f3c925d15f4a78910aecf9f7e3cd13c0247b58578a651e4cdd9e82e'
plan_path=HERE/'preimport-map.json';assert hashlib.sha256(plan_path.read_bytes()).hexdigest()==EXPECTED
plan=json.loads(plan_path.read_text());assert plan['root']==str(HERE)and sys.dont_write_bytecode
assert len(plan['cases'])==4 and plan['budgetSeconds']==60 and plan['failfast']is True
source=Path(plan['sourceRoot']);refusals=[];loaded=[];initial_threads=set(threading.enumerate());initial_meta=list(sys.meta_path);initial_path=list(sys.path)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(name,value):(HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
assert digest(plan['sourceFreeze']['path'])==plan['sourceFreeze']['sha256']
for path,row in plan['privateSourcePins'].items():assert digest(path)==row['sha256']and Path(path).stat().st_size==row['bytes']
def refuse(event):
 refusals.append(event);raise RuntimeError('AUDIT_REFUSED_'+event)
def audit(event,args):
 if event=='import'and any(args[0]==p or args[0].startswith(p+'.')for p in ('ios','adapters','feature_journeys','pymobiledevice3','appium','tidevice','selenium','playwright')):refuse(event)
 elif event.startswith('socket.'):refuse(event)
 elif event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen')or event.startswith('os.spawn'):refuse(event)
 elif event=='open':
  path,mode,flags=args
  if isinstance(path,(str,bytes,os.PathLike)):
   p=Path(os.fsdecode(path)).absolute();writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or isinstance(mode,str)and any(c in mode for c in 'wax+')
   if writing and not p.is_relative_to(HERE):refuse('write-outside-own-root')
 elif event in ('os.remove','os.rmdir','os.mkdir','os.rename','os.chmod','os.link','os.symlink'):
  values=args[:2]if event in ('os.rename','os.link','os.symlink')else args[:1]
  for value in values:
   if isinstance(value,(str,bytes,os.PathLike))and not Path(os.fsdecode(value)).absolute().is_relative_to(HERE):refuse('mutation-outside-own-root')
sys.addaudithook(audit)
def fd_census():
 rows={}
 for path in Path('/proc/self/fd').iterdir():
  try:target=os.readlink(path);info=path.stat();rows[path.name]=dict(target=target,device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
  except(FileNotFoundError,ProcessLookupError):pass
 return rows
before_fd=fd_census();start=time.monotonic();result=None;cases=[];fatal=None;cleanup=[];original_cleanup=unittest.TestCase.doCleanups;receipts=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  self.started=time.monotonic();print('VERIFIER11_CASE_START',test.id(),flush=True);super().startTest(test)
 def stopTest(self,test):
  receipts.append(dict(id=test.id(),elapsedSeconds=time.monotonic()-self.started));save('case-stop-receipts.json',receipts);super().stopTest(test)
 def addError(self,test,error):
  super().addError(test,error);self.preserve(test,error,'ERROR')
 def addFailure(self,test,error):
  super().addFailure(test,error);self.preserve(test,error,'FAIL')
 def preserve(self,test,error,kind):
  raw=''.join(traceback.format_exception(*error));print(kind,test.id(),raw,flush=True)
  with(HERE/'original-exceptions.log').open('a')as stream:stream.write(kind+' '+test.id()+'\n'+raw);stream.flush();os.fsync(stream.fileno())
try:
 path=source/'test_audio_parent_verifier_boundary.py';raw=path.read_bytes();assert digest(path)==plan['privateSourcePins'][str(path)]['sha256']
 spec=importlib.util.spec_from_file_location('audio_verifier_own11',path);module=importlib.util.module_from_spec(spec);sys.modules['audio_verifier_own11']=module;spec.loader.exec_module(module)
 suite=unittest.TestSuite(module.AudioParentVerifierBoundaryTests(name.rsplit('.',1)[1])for name in plan['cases']);cases=list(suite)
 assert [case.id()for case in cases]==plan['cases'];save('actual-selected-ids.json',[case.id()for case in cases])
 result=unittest.TextTestRunner(verbosity=2,resultclass=Result,failfast=True).run(suite)
except BaseException:
 fatal=traceback.format_exc();(HERE/'original-fatal.log').write_text(fatal);print(fatal,flush=True)
finally:
 ok=True
 for case in cases:
  pending=len(case._cleanups);prior=case._outcome;drain=unittest.TestResult();success=True
  try:
   if pending:case._outcome=unittest.case._Outcome(drain);success=unittest.TestCase.doCleanups(case)
  except BaseException:
   success=False;(HERE/('cleanup-fatal-'+str(len(cleanup))+'.log')).write_text(traceback.format_exc())
  finally:case._outcome=prior
  def primitive(rows):return [dict(testId=test.id(),traceback=text)for test,text in rows]
  row=dict(id=case.id(),pending=pending,remaining=len(case._cleanups),success=success,errors=primitive(drain.errors),failures=primitive(drain.failures),originalFunctionUnchanged=unittest.TestCase.doCleanups is original_cleanup);cleanup.append(row)
  ok=ok and success and not case._cleanups and not drain.errors and not drain.failures and row['originalFunctionUnchanged']
 save('original-cleanup-chain.json',dict(success=ok,cases=cleanup))
 sys.modules.pop('audio_verifier_own11',None);sys.meta_path[:]=initial_meta;sys.path[:]=initial_path
 after_fd=fd_census();threads=[dict(name=t.name,ident=t.ident)for t in threading.enumerate()if t not in initial_threads and t.is_alive()]
 unchanged=all(digest(path)==row['sha256']and Path(path).stat().st_size==row['bytes']for path,row in plan['privateSourcePins'].items())
 success=bool(result and result.wasSuccessful()and result.testsRun==4 and not result.skipped and not fatal and ok and unchanged and not refusals and not threads and before_fd==after_fd)
 report=dict(status='PASS'if success else'FAIL_OR_ERROR',testsRun=0 if result is None else result.testsRun,failures=0 if result is None else len(result.failures),errors=0 if result is None else len(result.errors),fatal=fatal is not None,elapsedSeconds=time.monotonic()-start,actualSelected=plan['cases'],originalOuterCleanupEstablished=ok,privateSourcesUnchanged=unchanged,actualPublicDependencies=0,auditRefusals=refusals,remainingNewThreads=threads,fdBefore=before_fd,fdAfter=after_fd,actualFDDrainEstablished=before_fd==after_fd,aliasesRestored='audio_verifier_own11'not in sys.modules,originalRunnerPid=os.getpid(),NodeExecutions=0,SDKExecutions=0,socketActions=0,parentExecution=False,nativeQualified=False,wholeQualified=False)
 save('report.json',report);print('VERIFIER11_TERMINAL',json.dumps(report),flush=True)
sys.exit(0 if report['status']=='PASS'else 1)
