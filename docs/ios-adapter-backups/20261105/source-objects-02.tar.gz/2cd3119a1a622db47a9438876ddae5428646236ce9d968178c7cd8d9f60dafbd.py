"""Genuine constructor for the explicitly lower modeled checkpoint endpoint.

Existing public SceneEndpoint.send supplies its original independent world
readers. No Parsed/live owner is fabricated before the first model exists.
The actual SDK/Qt/native/render/domain interfaces remain host models.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import uuid
from adapters.native_feature_observation import NativeFeatureObservation,need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters import create_state,emote_world,assets_model_origin
from ios.adapters.assets_checkpoint_scene import AssetsCheckpointScene
from ios.self_tests.assets_peer_fixture import SceneEndpoint
from ios.self_tests.assets_whole_observation_fixture import Fixture as OriginalFixture
from ios.self_tests.assets_picker_fixture import RUN


class CheckpointEndpoint:
    send=SceneEndpoint.send

    def __init__(self,fixture,root,role,binding,lock):
        need(role in('primary','actor-primary','actor'))
        self.fixture,self.boundary,self.role=fixture,fixture.boundary,role
        self.root=Path(root);need(self.root.is_dir());self.lock=lock;lock.assert_held()
        self.world=self.boundary.peer if role=='actor'else self.boundary
        self.pid=43 if role=='actor'else 42;self.binding=deepcopy(binding)
        need(self.binding['processIdentity']==str(self.pid))
        self.raw={};self.counts=dict(clock=0,state=0,domain=0,origin=0);self.queries=[];self.good=True
        self.instance=uuid.uuid4().hex;self.domain_instance=uuid.uuid4().hex
        self.monotonic=self.boundary.monotonic;self.epoch_ms=self.world.clock


class Fixture(OriginalFixture):
    def scene_parts(self,observer,selector,role,lock):
        action,episode=observer.action,observer.episode;subject='actor'if role=='actor'else'primary'
        info=self.selected.context['roles'][subject]
        root=Path(info['stateRoot'])if episode is None else Path(episode.descriptor['directories'][subject]['stateRoot']['path'])
        need(selector==info['target'])
        expected=self.a.h.locks[subject]if episode is None else episode.locks[subject]
        need(lock is expected);lock.assert_held();key=(action.index,role)
        if key not in self.scene_endpoints:
            self.scene_endpoints[key]=CheckpointEndpoint(self,root,role,info['binding'],lock)
        endpoint=self.scene_endpoints[key]
        need(endpoint.lock is lock and endpoint.root==root and endpoint.role==role)
        def guarded():action.guard();lock.assert_held();return self.boundary.live
        native=NativeFeatureObservation(lambda query:endpoint.send('clock',query),lambda:endpoint.raw.get('clock',''),
            endpoint.world.clock,guarded,endpoint.pid,ios=True,native_clock_bound=True,
            monotonic=endpoint.monotonic,sleep=self.boundary.sleep)
        def reader(cls,kind):
            return cls(lambda query:endpoint.send(kind,query),lambda:endpoint.raw.get(kind,''),endpoint.world.clock,
                guarded,endpoint.pid,monotonic=endpoint.monotonic,sleep=self.boundary.sleep)
        source=AssetsCheckpointScene(PrivateFeatureState(root/('ios-assets-checkpoint-'+RUN+'-a'+str(action.index)+'-'+role+'-scene.json')),
            endpoint.binding,RUN,role,lock,guarded,native=native,state=reader(create_state.IOSCreateState,'state'),
            domain=reader(emote_world.IOSEmoteWorld,'domain'),origin=reader(assets_model_origin.IOSAssetsModelOrigin,'origin'),
            epoch_ms=endpoint.epoch_ms,monotonic=endpoint.monotonic,selection=self.selected,action=action,episode=episode)
        return dict(check=guarded,scene=source)
