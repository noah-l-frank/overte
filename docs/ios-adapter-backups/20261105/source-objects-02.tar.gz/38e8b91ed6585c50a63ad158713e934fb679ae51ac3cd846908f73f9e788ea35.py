"""Explicit pre-Stop join of the existing paired Avatar Scene/Final originals.

This journal owns the handoff, not an End verdict. The separate current Keeper
terminal must own its roots/inputs/OS/SDK/creator closures before it can finish.
No legacy Stop, DELETE, session recreation or capture is issued here.
"""
from copy import deepcopy

from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact, need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from ios.adapters.avatar_feature import IOSAvatarFeature
from ios.adapters.avatar_terminal import (AvatarTerminal, ROLES,
    terminal_clock_begin, terminal_clock_check, terminal_clock_validate)
from ios.adapters.graphics_runtime import IOSGraphicsRuntime
from ios.adapters.installed_code import source as process_source


def filename(run):
    from feature_journeys.contract import identifier
    return 'ios-avatar-primary-'+identifier(run)+'-keeper-reply-handoff.json'


class AvatarKeeperHandoff:
    """Genuine constructor holding the original live terminal and both locks.

    Reopening never renews the first handoff's original thirty-second finish
    clock. Historical verification checks the same retained graph and performs
    no source/target/SDK factory call. It does not assert present freshness.
    """
    def __init__(self, terminal):
        need(type(terminal) is AvatarTerminal and type(terminal.flow) is IOSAvatarFeature)
        self.terminal, self.flow = terminal, terminal.flow
        f = self.flow
        need(f.role == 'primary' and set(f.locks) == set(ROLES)
            and f.selectors['primary'] != f.selectors['actor'])
        for lock in f.locks.values():
            lock.assert_held()
        self.store = PrivateFeatureState(f.runtime.state_path(f.selector).with_name(filename(f.run)))
        self.previous = self.store.read()
        self.failed = False
        if self.previous is not None:
            self.validate(self.previous)

    def bound(self):
        f = self.flow
        for lock in f.locks.values():
            lock.assert_held()
        need(not self.failed and same(self.store.read(), self.previous))
        need(same(f.store.read(), f.previous)
            and same(self.terminal.store.read(), self.terminal.previous))
        return True

    def scene_final(self):
        """Original decoders retain every old Scene/Final/window obligation."""
        self.bound()
        t = self.terminal
        need(t.state is not None and t.state['seal'] is not None
            and all(t.state[key] is None for key in ('finish', 'archive', 'end')))
        last = t.verify_seal()
        owners = t.roles(t.state['sealedRoles'])
        for owner, _raw in owners.values():
            for event in owner.state['cleanup']:
                if event['kind'] in ('final-ready', 'final-observation'):
                    owner.terminal_live_proof(event)
                elif event['kind'] in ('scene', 'scene-publication'):
                    owner.scoped_scene(event).derive(owner.kept(event['scoped']))
            if owner.role == 'actor':
                event = next(row for row in owner.state['cleanup'] if row['kind'] == 'scene-publication')
                need(event['published'] is True)
                from adapters.phase_retirement_publisher import PhaseRetirementPublisher
                PhaseRetirementPublisher.archive(owner.kept(event['publisher']),
                    store=PrivateFeatureState(owner.store.path.with_name(
                        'phase-retirement-avatar-people-'+self.flow.run+'-actor.json')),
                    binding=owner.state['bindings']['actor'], run=self.flow.run,
                    area='avatar-people', fixture_url=self.flow.client.url,
                    phase_instance=self.flow.state['phaseInstance'],
                    validate_original=owner.retirement_original)
        return last

    def no_legacy_process_owner(self):
        """A sealed legacy process journal is already a separate owned duty."""
        from ios.adapters.process_retirement import filename as process_filename
        f = self.flow
        primary = f.runtime.state_path(f.selectors['primary'])
        for suffix in ('keeper-handoff','keeper-terminal2'):
            need(PrivateFeatureState(primary.with_name('ios-avatar-primary-'+f.run+'-'+suffix+'.json')).read() is None)
        for role in ROLES:
            sdk = f.runtime.state_path(f.selectors[role])
            paths = (sdk.with_name('ios-avatar-'+role+'-'+f.run+'-terminal-process.json'),
                sdk.with_name('ios-avatar-'+role+'-'+f.run+'-abort.json'),
                sdk.with_name(process_filename('avatar', role, 0)),
                sdk.with_name('ios-avatar-keeper-reply-'+role+'-0-process-retirement.json'))
            # The existing Keeper avatar profile and old DVT-only owner use
            # the same fixed retirement filename with different exact codecs.
            # Neither an old owner nor a pre-created Keeper can be adopted as
            # this new handoff's first-send authority.
            for path in paths:
                need(PrivateFeatureState(path).read() is None)

    def validate(self, value):
        f, t = self.flow, self.terminal
        exact(value, {'iosAvatarKeeperHandoffVersion', 'avatarReplyProfileVersion', 'runId', 'bindings',
            'selectors', 'phaseInstance', 'coordinatorSha256', 'terminalSha256',
            'seal', 'sealedRoles', 'processSources', 'operationClock'})
        need(type(value['iosAvatarKeeperHandoffVersion']) is int
            and value['iosAvatarKeeperHandoffVersion'] == 2
            and type(value['avatarReplyProfileVersion'])is int and value['avatarReplyProfileVersion']==1
            and value['runId'] == f.run and same(value['bindings'], f.state['bindings'])
            and same(value['selectors'], f.selectors)
            and value['phaseInstance'] == f.state['phaseInstance']
            and value['coordinatorSha256'] == digest(f.previous)
            and value['terminalSha256'] == digest(t.previous)
            and same(value['seal'], t.state['seal'])
            and same(value['sealedRoles'], t.state['sealedRoles']))
        terminal_clock_validate(value['operationClock'])
        exact(value['processSources'], set(ROLES))
        for role in ROLES:
            process_source(value['processSources'][role])
        self.scene_final()
        return value

    def prepare(self):
        self.bound()
        self.no_legacy_process_owner()
        if self.previous is not None:
            self.validate(self.previous)
            self.check_deadline()
            return self.original()
        t, f = self.terminal, self.flow
        t.guard()
        last = self.scene_final()
        t.fresh(last)
        # This is the original host finish-clock codec, not native evidence.
        clock = terminal_clock_begin(f.epoch_ms(), f.monotonic())
        sources = {}
        for role in ROLES:
            sources[role] = deepcopy(IOSGraphicsRuntime._graphics_final_source(
                f.runtime, f.selectors[role], f.state['bindings'][role]))
            process_source(sources[role])
        t.guard()
        self.no_legacy_process_owner()
        value = dict(iosAvatarKeeperHandoffVersion=2, avatarReplyProfileVersion=1, runId=f.run,
            bindings=deepcopy(f.state['bindings']), selectors=deepcopy(f.selectors),
            phaseInstance=f.state['phaseInstance'], coordinatorSha256=digest(f.previous),
            terminalSha256=digest(t.previous), seal=deepcopy(t.state['seal']),
            sealedRoles=deepcopy(t.state['sealedRoles']), processSources=sources,
            operationClock=clock)
        self.validate(value)
        terminal_clock_check(clock, f.epoch_ms(), f.monotonic())
        try:
            self.store.write(value, None)
            need(same(self.store.read(), value))
            self.previous = deepcopy(value)
        except BaseException:
            self.failed = True
            raise
        return self.original()

    def check_deadline(self):
        self.bound()
        need(self.previous is not None)
        return terminal_clock_check(self.previous['operationClock'],
            self.flow.epoch_ms(), self.flow.monotonic())

    def original(self):
        self.bound()
        need(self.previous is not None)
        self.validate(self.previous)
        return deepcopy(self.previous)
