from pathlib import Path
import ast,hashlib,json
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');H=R/'.ios-host-tmp/world-web-witness-decode-root22-and-world4-preparation-20261028';S=R/'.ios-host-tmp/world-web-witness-pure-decode-round-proposal-20261028';OLD=R/'.ios-host-tmp/world-web-retained-inputs-eager12-root-preparation-20261028'
H.mkdir(mode=0o700,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,s):(H/n).write_text(s)
def dump(n,v):write(n,json.dumps(v,indent=2,sort_keys=True)+'\n')
packet=json.loads((S/'plan.json').read_text())
newgeneric=[i for i in packet['exactCaseIds'] if i.startswith('self_tests.')];world=[i for i in packet['exactCaseIds'] if i.startswith('ios.')]
p=R/'tests/device/self_tests/test_phase_witness_publisher.py';t=ast.parse(p.read_bytes());c=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='PhaseWitnessPublisherTests')
oldids=['self_tests.test_phase_witness_publisher.PhaseWitnessPublisherTests.'+n.name for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(oldids)==17 and len(newgeneric)==5 and len(world)==4
suites={'generic22':dict(caseIds=oldids+newgeneric,count=22,initialTimeoutSeconds=30,killAfterSeconds=5),'world4':dict(caseIds=world,count=4,initialTimeoutSeconds=300,killAfterSeconds=5)}
assert len(set(oldids+newgeneric+world))==26
publication=[dict(path=row['path'],expectedSha256=row['candidate']['sha256']) for row in packet['paths']]
dump('expected-publication.json',publication)
roots=['tests/device','tests/device/self_tests','tests/device/ios/self_tests'];packages={'ios':'tests/device/ios','ios.adapters':'tests/device/ios/adapters','ios.self_tests':'tests/device/ios/self_tests','adapters':'tests/device/adapters','adapters.script_feature':'tests/device/adapters/script_feature','self_tests':'tests/device/self_tests','feature_journeys':'tests/device/feature_journeys','fixture':'tests/device/fixture'}
def virtual(path):
 candidate=S/'candidate'/path
 return candidate if candidate.is_file() else R/path

def modulefile(name):
 for root in roots:
  for tail in (name.replace('.','/')+'.py',name.replace('.','/')+'/__init__.py'):
   rel=Path(root)/tail
   if virtual(rel).is_file():return rel.as_posix()
 return None
queue=[i.rsplit('.',2)[0] for i in oldids+newgeneric+world]+['ios.self_tests.retained_host_roots','ios.self_tests.test_ios_emote_marker_scope','ios.self_tests.world_web_actor_fixture']
modules={}
while queue:
 name=queue.pop()
 if name in modules:continue
 rel=modulefile(name)
 if rel is None:continue
 modules[name]=dict(path=rel)
 tree=ast.parse(virtual(rel).read_bytes(),filename=rel)
 for node in ast.walk(tree):
  if isinstance(node,ast.Import):queue.extend(x.name for x in node.names)
  elif isinstance(node,ast.ImportFrom):
   base=node.module or ''
   if node.level:
    parent=name.split('.')[:-1] if not rel.endswith('/__init__.py') else name.split('.')
    base='.'.join(parent[:len(parent)-node.level+1]+([base] if base else []))
   if base:queue.append(base)
   queue.extend(base+'.'+x.name for x in node.names if base and x.name!='*')
dump('source-root-final-map.json',dict(orderedRoots=roots,packageRoots=packages,modules=dict(sorted(modules.items())),resolver='PathFinder._get_spec with explicit parent search locations; paths only until Root post-publication refresh'))
metadata=(OLD/'run_metadata.py').read_text()
start=metadata.index('def validate_frozen():');end=metadata.index('\ndef publication():',start)
metadata=metadata[:start]+'''def validate_frozen():
    own=json.loads((HERE/'freeze.json').read_text())
    for name,expected in own['files'].items():assert sha(HERE/name)==expected,name
    plan=load_plan();root=REPO/plan['frozenPacket']['path']
    assert sha(root/'freeze.json')==plan['frozenPacket']['freezeSha256']
    frozen=json.loads((root/'freeze.json').read_text())
    for row in frozen['files']:assert sha(root/row['path'])==row['sha256'],row['path']
    assert sha(HERE/'source-root-final-map.json')==plan['sourceRootMapSha256']
    assert sha(HERE/'expected-publication.json')==plan['expectedPublicationSha256']
    return plan
''' +metadata[end:]
start=metadata.index('def sources(plan):');end=metadata.index('\ndef originals(root):',start)
metadata=metadata[:start]+'''def sources(plan):
    paths=broad_sources(plan)
    own=json.loads((HERE/'freeze.json').read_text())
    paths.update(HERE/name for name in own['files']);paths.add(HERE/'freeze.json')
    root=REPO/plan['frozenPacket']['path'];frozen=json.loads((root/'freeze.json').read_text())
    paths.update(root/row['path'] for row in frozen['files']);paths.add(root/'freeze.json')
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}
''' +metadata[end:]
write('run_metadata.py',metadata)
refresh='''"""Root runs once AFTER exact public publication; no target imports/tests."""
from run_metadata import HERE,REPO,validate_frozen,publication,sources,save,sha
import json,subprocess
plan=validate_frozen();rows=publication();path=HERE/'publication-ready-source-map.json'
assert not path.exists(),'No silent replacement of an approved source map'
actual=sources(plan);config=json.loads((HERE/'source-root-final-map.json').read_text())
modulePins={name:dict(path=row['path'],sha256=actual[row['path']]['sha256']) for name,row in config['modules'].items()}
value=dict(status='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),publication=rows,sourcePins=actual,modulePins=modulePins,mainCpp=actual['interface/src/main.cpp'],testsExecuted=False,targetImportsExecuted=False)
save(path,value)
print(json.dumps(dict(sourceMap=str(path),sourceMapSha256=sha(path),pins=len(actual),modules=len(modulePins),head=value['head']),sort_keys=True))
'''
write('refresh-after-publication.py',refresh)
runner=(OLD/'run-selected.py').read_text().replace('exact12 retained input closure','publisher22 or World4 pure-decode').replace("('eager12',)","('generic22','world4')").replace('OVERTE_WORLD6_EAGER_INPUTS_RUN_ROOT','OVERTE_WORLD6_WITNESS_DECODE_RUN_ROOT')
runner=runner.replace("config=json.loads((HERE/'source-root-final-map.json').read_text())", "config=json.loads((HERE/'source-root-final-map.json').read_text())\napproved=json.loads(ready.read_text());assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'\nassert set(approved['modulePins'])==set(config['modules'])\nconfig['modules']=approved['modulePins']")
start=runner.index('from ios.self_tests import test_ios_world_web_terminal_seal');end=runner.index('real_td=',start)
runner=runner[:start]+'''if kind=='generic22':
    from self_tests import test_phase_witness_publisher as publication_fixture
    fixture_modules=[publication_fixture]
else:
    from ios.self_tests import test_ios_emote_marker_scope as scope_fixture
    from ios.self_tests import world_web_actor_fixture as actor_fixture
    fixture_modules=[scope_fixture,actor_fixture]
from ios.self_tests.retained_host_roots import retain_owned_root
''' +runner[end:]
runner=runner.replace("(seal_fixture,publication_fixture)","fixture_modules")
# No generic-locals diagnostics or stale unrelated inventory path inspection.
start=runner.index('        try:\n            inventory=[]');end=runner.index('    def addError',start)
runner=runner[:start]+runner[end:]
runner=runner.replace('wholeWorldWebQualified=False,full19CapClosed=True','wholeWorldWebQualified=False,publicAreaAcceptanceChanged=False')
write('run-selected.py',runner)
supervisor=(OLD/'root-supervise.py').read_text().replace("('eager12',)","('generic22','world4')").replace('OVERTE_WORLD6_EAGER_INPUTS_RUN_ROOT','OVERTE_WORLD6_WITNESS_DECODE_RUN_ROOT').replace('wholeWorldWebQualified=False,full19CapClosed=True','wholeWorldWebQualified=False,publicAreaAcceptanceChanged=False')
write('root-supervise.py',supervisor)
plan=dict(status='PRIVATE_ROOT_PREPARATION_UNRUN_NO_TARGET_IMPORTS',suites=suites,frozenPacket=dict(path=str(S.relative_to(R)),freezeSha256=sha(S/'freeze.json')),expectedPublicationCount=4,expectedPublicationSha256=sha(H/'expected-publication.json'),sourceRootMapSha256=sha(H/'source-root-final-map.json'),broadSourceRoots=['tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml'],explicitMainPin='interface/src/main.cpp',actualSourceHashesCapturedOnlyAfterRootPublication=True,localTempfileAliases={'generic22':['self_tests.test_phase_witness_publisher.tempfile'],'world4':['ios.self_tests.test_ios_emote_marker_scope.tempfile','ios.self_tests.world_web_actor_fixture.tempfile']},entrypointAudit='All 17 existing publisher methods and five new generic methods read: real loopback HTTP/private files, no Node/native/compiler/SDK. Four new World methods read: FeatureWorldWeb construction -> NetworkWorldWeb -> ComposedWorldWeb -> MarkerScopeTests.TemporaryDirectory; independent Actor.TemporaryDirectory separately. Feature/Network own only loopback listeners, no extra TemporaryDirectory. WholeSDK spawns original node world_web_page_fixture.js, ActiveSDK.close owns actual pipe/process close; no compiler/configure/build/native/device path. No run_flow, complete_cleanup worker600 or full19 method selected.',initialBudgetReason='Root specified BEFORE first run: generic22 fixed30+kill5, actualWorld4 fixed300+kill5. No unchanged retry; each group has exclusive first log/report. No old source maps reused.',wholeQualified=False,targetImportsExecuted=False,testsExecuted=False)
dump('suite-plan.json',plan)
print(json.dumps(dict(preparation=str(H),generic22=suites['generic22']['count'],world4=suites['world4']['count'],sourceModules=len(modules))))
