"""Executed only by the exact pinned prefix before original spawn_main.

No __spec__, target, Process, pickle, owner or clock field is fabricated.
The original command remains outside this file and runs only after setup.
"""
from pathlib import Path
import atexit,builtins,hashlib,io,json,os,stat,sys,threading,traceback
B=BOOTSTRAP
assert sys.flags.no_site and sys.dont_write_bytecode and B['role']in('actor','tracker')
policy_path=Path(B['policyPath']);before=policy_path.lstat();raw=policy_path.read_bytes()
assert hashlib.sha256(raw).hexdigest()==B['policyPin']['sha256']
assert [getattr(before,k)for k in('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')]==B['policyPin']['stat']
plan=json.loads(raw);SOURCE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()
assert plan['repositoryRoot']==str(REPO)and B['ownedRoot']==plan['controllerRoot']
assert SOURCE==Path(plan['packageSource'])and SOURCE.parent.is_relative_to(REPO/'.ios-host-tmp')
# These source imports are bootstrapped only after their physical policy pins
# and the no-site stdlib paths are independently checked, before any unpickle.
for name in('__init__.py','common.py','mp_variant_admission.py','closed_import_origins.py','imports.py'):
 p=SOURCE/name;assert p.resolve(strict=True)==p and hashlib.sha256(p.read_bytes()).hexdigest()==plan['physicalPins'][str(p)]['sha256']
sys.path.insert(0,str(SOURCE.parent))
from tablet_fresh4_bootstrap.common import pin,save,fds,kernel,no_sdk,source_pins
from tablet_fresh4_bootstrap.imports import ClosedFinder
from tablet_fresh4_bootstrap.mp_variant_admission import require_variant,ADAPTED_HELPER_SHA256
require_variant(plan['mpVariantQualification'],pin)
assert plan['actualAdaptedHelperSha256']==ADAPTED_HELPER_SHA256 and pin(SOURCE/'closed_import_origins.py')['sha256']==ADAPTED_HELPER_SHA256
assert pin(policy_path)==B['policyPin']
assert kernel(os.getppid())==dict(pid=B['parent']['pid'],parent=B['parent'].get('parentPID',B['parent'].get('parent')),group=B['parent']['processGroup'],session=B['parent']['session'],startTicks=B['parent']['startTicks'])
source_pins(plan)
child_plan=dict(plan)
if B['role']=='tracker':
 child_plan['modules']={k:v for k,v in plan['modules'].items()if k.startswith('tablet_')or k in('owned_write_boundary','closed_import_origins','raw_pipe_tee')}
 child_plan['namespacePackages']={};child_plan['thirdPartyModules']={};child_plan['thirdPartyNamespacePackages']={}
finder=ClosedFinder(child_plan,SOURCE,REPO,B);finder.install()
state=dict(actorReturnedNormally=False,actorStarted=False,errors=[],restoration=None,origins=None)
ROOT=Path(plan['controllerRoot']);room=ROOT/'child-processes';assert room.is_dir()and not room.is_symlink()
fd=os.open(room/(B['role']+'-report.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
report=os.fdopen(fd,'wb',buffering=0);report_identity=os.fstat(fd)
initial_fds=fds();initial_threads=tuple(threading.enumerate());write_boundary=None;monitor=None;ipc=None
original_dup=(os.dup,os.dup2);dups=[]
def finish_actual_child():
 errors=[]
 def attempt(label,action):
  try:return action()
  except BaseException:
   errors.append(dict(component=label,traceback=traceback.format_exc()));return None
 attempt('no-physical-sdk',no_sdk)
 state['origins']=attempt('actual-loaded-origins',lambda:finder.snapshot('after-original-child-and-stdlib-exit-function'))
 if monitor is not None:state['monitor']=attempt('monitor-original-restoration',monitor.restore)
 if write_boundary is not None:state['restoration']=attempt('original-write-port-restoration',write_boundary.restore)
 if B['role']=='actor':state['sourceLocks']=attempt('original-source-locks',source_locks.finish)
 if ipc is not None:state['ipc']=attempt('original-ipc-finish',ipc.finish)
 try:
  os.dup,os.dup2=original_dup
  state['dupRestored']=(os.dup,os.dup2)==original_dup
  state['actualFDsBefore']=initial_fds;state['actualFDsAtExit']=fds()
  allowed={tuple(row)for row in B['transportScope']['actualArenaInodes']}
  extras={fd:row for fd,row in state['actualFDsAtExit'].items()if initial_fds.get(fd)!=row}
  assert all((row['device'],row['inode'])in allowed for row in extras.values())
  state['explicitActualProcessLifetimeFDs']=extras
  state['actualThreadsAtExit']=[t.name for t in threading.enumerate()]
  assert tuple(threading.enumerate())==initial_threads
  if B['role']=='actor':assert state['actorStarted']and state['actorReturnedNormally']
  else:assert not state['actorStarted']and state.get('originalTrackerExitCode')==0
  assert state['ipc']is None or not state['ipc']['stillLiveConnections']
  assert not errors and not state['errors']and not state.get('setupFailure')and pin(policy_path)==B['policyPin']
  state['status']='PASS'
 except BaseException:
  state['status']='FAIL';state['terminalFailure']=traceback.format_exc()
 finally:
  state.update(independentRestorationErrors=errors,role=B['role'],actualPID=os.getpid(),actualParentPID=os.getppid(),
   originalCommandSha256=B['originalCommandSha256'],actualOrigArgvSha256=hashlib.sha256(json.dumps(sys.orig_argv).encode()).hexdigest(),
   processLifetimeFDsDischargedInsideChild=False,nativeQualified=False,wholeQualified=False)
  assert(os.fstat(fd).st_dev,os.fstat(fd).st_ino)==(report_identity.st_dev,report_identity.st_ino)
  report.write((json.dumps(state,sort_keys=True,indent=2)+'\n').encode());report.close()
# Register BEFORE importing multiprocessing.util; genuine util._exit_function
# will consequently run first under atexit's actual reverse registration order.
atexit.register(finish_actual_child)
import multiprocessing.connection as connection,multiprocessing.heap as heap,multiprocessing.spawn as spawn
import multiprocessing.resource_tracker as tracker,multiprocessing.sharedctypes,multiprocessing.synchronize
import multiprocessing.process as process
from tablet_constructor_custody import FunctionBinding,CustodyRefusal
from tablet_ipc_capacity import ActualIPCCapacities,MainThreadOwnWrites
from owned_write_boundary import OwnedWrites
from tablet_fresh4_bootstrap.monitor import LocalMonitor
from tablet_fresh4_bootstrap.locks import OriginalSourceLocks
source_locks=OriginalSourceLocks(Path(B['actorRoot'])if B['role']=='actor'else ROOT)
finder.after_load['adapters.script_feature.lock']=source_locks.bind
ipc=ActualIPCCapacities(connection,tracker,B['actualPassedDescriptors'],B['trackerWriteDescriptor'])
ipc.install();write_boundary=MainThreadOwnWrites(ROOT,OwnedWrites,ipc,protected=[policy_path,*map(Path,plan['physicalPins'])]);write_boundary.install()
spawn_binding=FunctionBinding(spawn.spawn_main);c_socket=__import__('_socket');socket=__import__('socket')
create=FunctionBinding(socket.create_connection);address=FunctionBinding(socket.getaddrinfo);sock_init=FunctionBinding(socket.socket.__init__)
real_socket=socket.socket;c_base=c_socket.socket;c_members={k:vars(c_base)[k]for k in('family','type','fileno','getsockopt')}
def actual_dup(descriptor):
 frame=sys._getframe(1);spawn_binding.frame(frame)
 assert descriptor==frame.f_locals['pipe_handle']and str(descriptor)in B['actualPassedDescriptors']
 info=os.fstat(descriptor);assert stat.S_ISFIFO(info.st_mode)
 assert dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode)==B['actualPassedDescriptors'][str(descriptor)]
 value=original_dup[0](descriptor);after=os.fstat(value);assert(after.st_dev,after.st_ino)==(info.st_dev,info.st_ino)
 dups.append(dict(original=descriptor,actual=value,device=after.st_dev,inode=after.st_ino));return value
def refuse_dup2(*args,**kwargs):raise CustodyRefusal('No child dup2')
os.dup,os.dup2=actual_dup,refuse_dup2
endpoints={tuple(row)for row in B['transportScope']['numericEndpoints']}
def own_create(frame):
 current=frame
 while current is not None:
  if current.f_code is create.code and current.f_globals is create.namespace:
   create.frame(current);assert current.f_locals['address']in endpoints and current.f_locals['source_address']is None;return current
  current=current.f_back
 raise CustodyRefusal('Child network requires genuine original create_connection')
def audit(event,args):
 if event=='object.__getattr__':return
 if event=='import'and args[0].split('.')[0]in ('pymobiledevice3','appium','selenium','PySide6','PyQt6'):raise CustodyRefusal('Physical SDK/native package')
 relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
 process_event=event in('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.system','os.exec','os.kill','os.killpg','os.setsid','os.setpgid','ctypes.dlopen')or event.startswith('os.spawn')
 if not(event.startswith('socket.')or process_event or relevant):return
 frame=sys._getframe(1)
 if event.startswith('socket.'):
  assert B['role']=='actor'and len(endpoints)==3
  create.guard();address.guard();sock_init.guard()
  assert socket.socket is real_socket and all(vars(c_base).get(k)is v for k,v in c_members.items())
  current=own_create(frame)
  if event=='socket.getaddrinfo':
   address.frame(frame);host,port,family,kind,proto=args
   assert(host,port)in endpoints and family in(0,socket.AF_UNSPEC,socket.AF_INET)and kind==socket.SOCK_STREAM and proto in(0,socket.IPPROTO_TCP)
  elif event=='socket.__new__':
   owner,family,kind,proto=args;sock_init.frame(frame)
   assert frame.f_locals['self']is owner and type(owner)is real_socket and family==socket.AF_INET and kind&0xf==socket.SOCK_STREAM and proto in(0,socket.IPPROTO_TCP)
  elif event=='socket.connect':
   owner,target=args;assert type(owner)is real_socket and current.f_locals['sock']is owner and target in endpoints
   assert c_members['family'].__get__(owner)==socket.AF_INET and c_members['getsockopt'](owner,socket.SOL_SOCKET,socket.SO_TYPE)==socket.SOCK_STREAM
   assert stat.S_ISSOCK(os.fstat(c_members['fileno'](owner)).st_mode)
  else:raise CustodyRefusal('No child bind/Unix/foreign resolver/datagram')
  return
 if event in('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.system','os.exec','os.kill','os.killpg','os.setsid','os.setpgid','ctypes.dlopen')or event.startswith('os.spawn'):
  raise CustodyRefusal('No child process/native/signal port')
 if event=='fcntl.flock':source_locks.audit(args,frame)
 write_boundary.audit(event,args,frame)
sys.addaudithook(audit)
monitor=LocalMonitor()
monitor.add(connection.rebuild_connection,returned=lambda frame,result:ipc.register_rebuilt_connection(frame,result))
run_binding=FunctionBinding(process.BaseProcess.run)
def original_target_start(frame):
 run_binding.frame(frame);owner=frame.f_locals['self'];target=owner._target
 assert process.current_process()is owner and type(owner)is __import__('multiprocessing.context',fromlist=['SpawnProcess']).SpawnProcess
 assert owner._parent_pid==B['parent']['pid']
 assert B['role']=='actor'and target is sys.modules['ios.self_tests.test_ios_tablet_web_open_admission'].admission_actor
 assert target.__module__=='ios.self_tests.test_ios_tablet_web_open_admission'
 assert str(Path(owner._args[0][0]).resolve(strict=True))==B['actorRoot']and owner._args[2]in ipc.connections
 state['actorStarted']=True
monitor.add(process.BaseProcess.run,start=original_target_start,
 returned=lambda frame,value:state.__setitem__('actorReturnedNormally',True),
 unwind=lambda frame,error:state['errors'].append(dict(type=type(error).__name__,message=str(error))))
def original_tracker_exit(frame,error):
 assert B['role']=='tracker'and type(error)is SystemExit
 state['originalTrackerExitCode']=error.code
 if error.code!=0:state['errors'].append(dict(type='OriginalTrackerExit',actualCode=error.code))
monitor.add(tracker.main,unwind=original_tracker_exit)
try:
 monitor.install();no_sdk();state['beforeOriginalEntry']=finder.snapshot('before-original-spawn-entry')
except BaseException:
 state['setupFailure']=traceback.format_exc()
 raise
# Return to the exact prefix; it now executes its retained original command.
