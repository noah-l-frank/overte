"""Raw native/AFC/WDA models for an actual original constructor/Current7 End.

Nothing here returns a Current7, End, replacement or Audio retirement verdict.
Every packet is newly produced at the real UTC/monotonic clock on its query.
Empty declared editor/scene models support the real seven-reader codec; they
cannot stand for an Audio baseline or acoustic acceptance. Only Root executes.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,hashlib,json,os,socket,time,uuid
from copy import deepcopy
from datetime import datetime
from pathlib import Path


def point():
    return dict(epochMs=int(time.time()*1000),monotonicMs=int(time.monotonic()*1000))


class RawAudioCurrentProducer:
    """A declared native PROCESS model, born before any SDK/Source owner."""
    FILES={'feature-native-observe':'feature-native-observation.json',
        'normal-ui-input':'ios-normal-ui-request-result.json',
        'feature-pending-commit-owner':'feature-pending-commit-owner.json',
        'feature-ios-keyboard':'feature-ios-keyboard.json',
        'feature-ios-lifecycle-world':'feature-ios-lifecycle-world.json',
        'ios-bundle-observe':'ios-installed-bundle-observation.json',
        'feature-ios-audio-settings':'feature-ios-audio-settings.json',
        'feature-ios-audio-session':'feature-ios-audio-session.json'}
    def __init__(self,root,*,pid=42,bundle_id='org.overte.model'):
        assert type(pid)is int and pid>0
        self.root=Path(root);self.root.mkdir(mode=0o700);self.pid,self.bundle_id=pid,bundle_id
        self.born=point();self.native_instance=uuid.uuid4().hex;self.bundle_instance=uuid.uuid4().hex
        self.field_instance=uuid.uuid4().hex;self.keyboard_instance=uuid.uuid4().hex
        self.world_instance=uuid.uuid4().hex;self.scene_instance=uuid.uuid4().hex;self.tree_instance=uuid.uuid4().hex
        self.origin_instance=uuid.uuid4().hex;self.avatar_id=uuid.uuid4().hex;self.pending_instance=uuid.uuid4().hex
        self.ui_instance=str(uuid.uuid4());self.window=uuid.uuid4().hex;self.geometry='a'*64
        self.sequence={};self.queries=[];self.files={};self.handles={};self.next_handle=0;self.services=[]
        self.life=dict(backgrounds=0,activations=1,launches=1)
        self.bundle=dict(bundleContractVersion=1,bundleId=bundle_id,executableSha256='a'*64,bundleSha256='b'*64,nodeCount=3,fileCount=2,totalBytes=1000)
        self.fault=None
    def next(self,name):
        self.sequence[name]=self.sequence.get(name,0)+1;return self.sequence[name]
    def native(self,q):
        seq=self.next('native');now=point()['epochMs']
        return dict(schemaVersion=1,requestId=q['commandId'],instance=self.native_instance,sequence=seq,
            capturedEpochMs=now,requestedEpochMs=now,processId=self.pid,animationFence={},animation={},
            lifecycle=deepcopy(self.life),graphics=dict(requestedResolutionScale=1.,applicationResolutionScale=1.,
                shadowsSetting=False,mirrorsSetting=False,hazeSetting=False,localLightingSetting=False,
                proceduralMaterialsSetting=False,deferredRenderingAvailable=False),
            audio=dict(recording=False,muted=False,recordedVoice=dict(active=False,capturedBytes=0,playedBytes=0,frameBytes=4,sampleRate=48000,channels=2,event={},historyVersion=1,cycle=0,startedEpochMs=0,captureSampleRate=0,captureChannels=0,historyComplete=True,events=[])),account=dict(loggedIn=False,principalSha256='b'*64))
    def ui(self,q):
        before=point();seq=self.next('field');after=point()
        inventory=dict(iosLifecycleFieldsVersion=1,instance=self.field_instance,sequence=seq,processId=self.pid,
            complete=True,clockBefore=before,clockAfter=after,objects=[],fields=[],loaders=[],pendingBindings=[])
        return dict(schemaVersion=1,commandId=q['commandId'],observation=dict(schemaVersion=1,instance=self.ui_instance,
            frameSpace='qt-window-logical',processId=self.pid,sampleEpochMs=after['epochMs'],
            elapsedMs=after['monotonicMs']-self.born['monotonicMs'],lastSequence=0,tabletShown=False,ready=True,
            controls=[],audioControlsVersion=1,lifecycleFieldsVersion=1,lifecycleFieldInventory=inventory))
    def pending(self,q):
        assert q['operation']=='observe'and q['eventId']==''
        return dict(pendingCommitOwnerVersion=1,commandId=q['commandId'],operation='observe',runId=q['runId'],
            instance=self.pending_instance,sequence=self.next('pending'),processId=self.pid,
            canonicalComponentUrl='qrc:/qml/hifi/dialogs/TabletRunningScripts.qml',capturedEpochMs=point()['epochMs'],
            lastIntentSequence=0,performed=False,current=dict(status='none'),commit={},resources=dict(pendingRuns=[],archivedEvents=0))
    def keyboard(self,q):
        before=point();sequence=self.next('keyboard');after=point()
        window=dict(id=self.window,key=True,visible=True,sceneActive=True,geometrySha256=self.geometry,responder=None)
        event=dict(sequence=1,eventId=self.window,kind='did-hide',clock=deepcopy(self.born),local=True,screenMatches=None,
            window=self.window,geometrySha256=self.geometry,frame=dict(valid=False,intersectsWindow=None))
        return dict(iosKeyboardVersion=1,requestId=q['commandId'],runId=q['runId'],instance=self.keyboard_instance,
            sequence=sequence,processId=self.pid,clockDomain='native-main-ios-keyboard',clockBefore=before,clockAfter=after,
            source=dict(registered=deepcopy(self.born),complete=True,ownerAlive=True,applicationActive=True,
                events=[event],objects=[dict(id=self.window,kind='window',born=deepcopy(self.born),expired=None,alive=True)],windows=[window]))
    def world(self,q):
        before=point();scene_before=point();seq=self.next('world')
        loads=dict(sceneLoadVersion=1,commandId=q['commandId'],runId=q['runId'],instance=self.scene_instance,
            sequence=seq,processId=self.pid,capturedEpochMs=point()['epochMs'],currentGeneration=0,pendingLeases=0,complete=True,requests=[])
        tree=dict(entityInventoryVersion=1,profile='native-entity-edit-wire-v1',treeInstance=self.tree_instance,
            revisionBefore=0,revisionAfter=0,totalEntities=0,complete=True,entities=[])
        origin=dict(iosSceneCommitOriginVersion=1,instance=self.origin_instance,processId=self.pid,currentGeneration=0,commits=0,complete=True,latest=None)
        scene=dict(iosSceneInventoryVersion=2,requestId=q['commandId'],runId=q['runId'],instance=self.scene_instance,
            sequence=seq,processId=self.pid,clockDomain='native-main-scene-inventory',clockBefore=scene_before,clockAfter=point(),
            source=dict(tree=tree,sceneLoads=loads,commitOrigin=origin))
        source=dict(scene=scene,lifecycle=deepcopy(self.life),domain=dict(connected=True,serverless=False,
            domainId='11111111-1111-4111-8111-111111111111',selfSha256='b'*64,avatarMixerSha256='c'*64,addressSha256='d'*64),
            avatar=dict(objectId=self.avatar_id,feetPosition=[0.,0.,0.],velocity=[0.,0.,0.],orientation=[0.,0.,0.,1.],inAir=False,flying=False,modelScale=1.),
            drive=dict(raw=[0.]*12,effective=[0.]*12,disabled=[False]*12))
        return dict(iosLifecycleWorldVersion=1,requestId=q['commandId'],runId=q['runId'],instance=self.world_instance,
            sequence=seq,processId=self.pid,clockDomain='native-main-lifecycle-world',clockBefore=before,clockAfter=point(),source=source)
    def audio_settings(self,q):
        from ios.adapters import audio_settings_source as grammar
        before=point();script={k:False for k in grammar.SCRIPT_BOOLS};script.update({k:0. for k in grammar.SCRIPT_NUMBERS})
        script.update(settingsLoaded=True,inputVolume=1.)
        script['persisted']={k:False for k in grammar.PERSISTED_BOOLS};script['persisted'].update({k:0. for k in grammar.PERSISTED_NUMBERS})
        client={k:False for k in grammar.CLIENT_BOOLS};mixer={k:0. for k in grammar.MIXER_NUMBERS}
        source=dict(iosAudioSettingsReadVersion=1,nativeHmd=False,scriptBefore=deepcopy(script),scriptAfter=deepcopy(script),
            clientBefore=deepcopy(client),clientAfter=deepcopy(client),mixerBefore=deepcopy(mixer),mixerAfter=deepcopy(mixer))
        return dict(iosAudioSettingsVersion=1,requestId=q['commandId'],runId=q['runId'],instance=self.native_instance,
            sequence=self.next('audio-settings'),processId=self.pid,clockDomain='native-main-ios-audio-settings',clockBefore=before,clockAfter=point(),
            lifecycle=deepcopy(self.life),source=source,**{k:False for k in grammar.UNAVAILABLE})
    def audio_session(self,q):
        before=point()
        return dict(iosAudioSessionVersion=1,requestId=q['commandId'],runId=q['runId'],instance=self.native_instance,
            sequence=self.next('audio-session'),processId=self.pid,clockDomain='native-main-ios-audio-session',clockBefore=before,clockAfter=point(),
            lifecycle=deepcopy(self.life),source=dict(available=True,osPermission=1,gatePermission=1,outcome=2,foreground=True,interrupted=False,
                captureAllowed=True,playbackAllowed=True,outputRevision=1))
    def produce(self,q):
        action=q['action'];assert action in self.FILES and q['commandId']not in {row['commandId']for row in self.queries}
        self.queries.append(deepcopy(q))
        if action=='feature-native-observe':packet=self.native(q)
        elif action=='normal-ui-input':assert q['operation']=='observe';packet=self.ui(q)
        elif action=='feature-pending-commit-owner':packet=self.pending(q)
        elif action=='feature-ios-keyboard':packet=self.keyboard(q)
        elif action=='feature-ios-lifecycle-world':packet=self.world(q)
        elif action=='feature-ios-audio-settings':packet=self.audio_settings(q)
        elif action=='feature-ios-audio-session':packet=self.audio_session(q)
        else:packet=dict(bundleObservationVersion=1,commandId=q['commandId'],instance=self.bundle_instance,
            sequence=self.next('bundle'),processId=self.pid,capturedEpochMs=point()['epochMs'],status='ready',preparedEpochMs=self.born['epochMs'],bundle=deepcopy(self.bundle))
        if self.fault=='wrong-ui-nonce'and action=='normal-ui-input':packet['commandId']='ios-'+'f'*32
        raw=json.dumps(packet,separators=(',',':'),sort_keys=True).encode();filename=self.FILES[action]
        path=self.root/(str(len(self.queries)).zfill(5)+'-'+filename);fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
        self.files[filename]=path
        return dict(filename=filename,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),query=deepcopy(q))
    def file(self,path):
        prefixes=('/Documents/owned-results/','@'+self.bundle_id+':documents/owned-results/')
        assert any(path.startswith(prefix)and '/'not in path[len(prefix):]for prefix in prefixes)
        filename=path.rsplit('/',1)[-1];assert filename in self.files
        return self.files[filename]
    def service_type(self):
        model=self
        class RawHouseArrestService:
            def __init__(self,rsd,documents_only=False):
                assert documents_only is False;self.rsd=rsd;self.sockets=socket.socketpair();self.closed=False;model.services.append(self)
            async def send_command(self,bundle,operation):assert bundle==model.bundle_id and operation=='VendContainer'and not self.closed
            async def __aenter__(self):assert not self.closed;return self
            async def stat(self,path):
                info=model.file(path).stat()
                return dict(st_ifmt='S_IFREG',st_nlink=info.st_nlink,st_size=info.st_size,st_ino=info.st_ino,
                    st_mtime=datetime.fromtimestamp(info.st_mtime).replace(tzinfo=None))
            async def fopen(self,path,mode):
                assert mode=='r'and not self.closed;model.next_handle+=1;model.handles[model.next_handle]=model.file(path).open('rb');return model.next_handle
            async def fread(self,handle,size):assert not self.closed;return model.handles[handle].read(size)
            async def fclose(self,handle):model.handles.pop(handle).close()
            async def aclose(self):
                for sock in self.sockets:sock.close()
                self.closed=True
        return RawHouseArrestService
