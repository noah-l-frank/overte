"""Historical27/235/factory2 and genuine own4 gate; no unchanged replay."""
import hashlib,json,stat
from pathlib import Path
from component_prerequisite import require as historical,passed
from foreign_publication_rebase import retained_paths
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
OLD=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/emote-callback-window-flow-cache-focused-window-corrected-root-preparation-20261103')
def require(here,repo,current=None):
 paths=historical(OLD/'window1',repo,current)+retained_paths()
 pins={}
 for pinmap in ('actual-causal-profile-pins.json','actual-current747-input-pins.json'):pins.update(json.loads((here.parent/pinmap).read_text()))
 for name,expected in pins.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();row=dict(stat=[getattr(a,k)for k in F]);assert stat.S_ISDIR(a.st_mode)or stat.S_ISREG(a.st_mode)
  if stat.S_ISREG(a.st_mode):row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert row==expected and row['stat']==[getattr(p.lstat(),k)for k in F];paths.append(p)
 for stage_name,expected_exit in (('round1',0),('literal1',1)):
  stage=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/emote-current747-constructor-foreign53-final-root-preparation-20261103')/stage_name;report=json.loads((stage/'root-run-first/report.json').read_text());assert report['exitCode']==expected_exit and all(report[k]for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged'))and not report['remainingOwnedProcesses']
 if here.name in ('remaining3','window1'):
  first=here.parent/'first1';ids=passed(first,1);assert ids==json.loads((here.parent/'own4-cases.json').read_text())[:1]
  if current is not None:assert json.loads((first/'root-run-first/root-source-map.json').read_text())==current
  frozen=set(json.loads((first/'freeze.json').read_text())['files'])|{'freeze.json'}
  paths += [p for p in first.rglob('*')if str(p.relative_to(first))not in frozen]
 if here.name=='window1':
  remaining=here.parent/'remaining3';ids=passed(remaining,3);assert ids==json.loads((here.parent/'own4-cases.json').read_text())[1:]
  if current is not None:assert json.loads((remaining/'root-run-first/root-source-map.json').read_text())==current
  frozen=set(json.loads((remaining/'freeze.json').read_text())['files'])|{'freeze.json'}
  paths += [p for p in remaining.rglob('*')if str(p.relative_to(remaining))not in frozen]
 return paths
