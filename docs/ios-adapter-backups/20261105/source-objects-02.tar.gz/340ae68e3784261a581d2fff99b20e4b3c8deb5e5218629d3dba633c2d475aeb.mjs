/* Actual Node bridge block; remote SDK/WDA replies explicitly modeled. */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash,randomUUID} from 'node:crypto';
import {join} from 'node:path';
import vm from 'node:vm';
import test from 'node:test';
const hash=v=>createHash('sha256').update(v).digest('hex');
const mapBytes=readFileSync(process.env.LIFECYCLE_SCOPED_CLEANUP_NODE_MAP);
assert.equal(hash(mapBytes),process.env.LIFECYCLE_SCOPED_CLEANUP_NODE_MAP_SHA256);
const map=JSON.parse(mapBytes),bytes=readFileSync(map.hostops.path);assert.equal(hash(bytes),map.hostops.sha256);
const text=bytes.toString('utf8'),at=text.indexOf('const originalKeeperRoutes ='),end=text.indexOf('\nexport function isStrictHostUtilityMode',at);
const stringAt=text.indexOf('function stringifyLaunchEnvironment'),stringEnd=text.indexOf('\n\nfunction createSimulatorHostOps',stringAt);
assert(at>=0&&end>at&&stringAt>=0&&stringEnd>stringAt);
const block=text.slice(at,end)+'\n'+text.slice(stringAt,stringEnd)+'\n({launch:tryOriginalKeeperLaunch,bridge:d=>originalKeeperRoutes.get(d)})';
writeFileSync(join(process.env.LIFECYCLE_CODE_BINDINGS_ROOT,'node-scoped-cleanup-'+randomUUID()+'.json'),JSON.stringify({sourceSha256:hash(bytes),selectedSourceSha256:hash(block),scope:'actual bridge with explicit no-SDK producer models'})+'\n',{flag:'wx',mode:0o600});
function model(instance){
 class Proxy {getOriginalDownstreamSessionSource(){return null;}}
 const load=vm.runInNewContext(block,{WebDriverProxy:Proxy,randomUUID,WDA_PORT:8100});
 const calls=[],driver={sessionId:'same-modeled-session',opts:{udid:'model-target',bundleId:'org.example.overte'},wda:{jwproxy:{}}};
 const remote={async originalKeeperOperation(target,request){calls.push({target,...request});return {originalKeeperOperationVersion:1,ownerInstance:instance,result:request.operation==='inspect'?{creatorMode:'userspace-keeper',nativeTouchSupport:false}:{protocolModelOnly:true}};}};
 return {driver,calls,async start(){await load.launch(driver,remote,{udid:'model-target',bundleId:'org.example.wda',env:{USE_PORT:'8100',WDA_PRODUCT_BUNDLE_IDENTIFIER:'org.example.wda'}});return driver[Symbol.for('overte.originalKeeperRoute.v1')];}};
}
const profile=owner=>({originalKeeperRetainedTouchProfileVersion:1,expectedOwnerInstance:owner,binding:{modelOnly:true},runId:'c'.repeat(32),referenceJson:'{"modelOnly":true}'});
test('same URL and session replacement cannot invoke foreign current source cleanup',async()=>{
 const original=model('a'.repeat(32)),replacement=model('b'.repeat(32));await original.start();const route=await replacement.start();
 const before=replacement.calls.length;
 for(const op of ['touch-inspect','touch-release','touch-settle'])await assert.rejects(route.request(op,profile('a'.repeat(32))));
 assert.equal(replacement.calls.length,before);
});
test('bound resource cleanup keeps original source tuple after current driver fields drift',async()=>{
 const f=model('a'.repeat(32)),route=await f.start();f.driver.sessionId='foreign';f.driver.opts.udid='foreign-target';f.driver.opts.bundleId='org.foreign';
 await route.request('touch-release',profile('a'.repeat(32)));
 const actual=f.calls.at(-1);assert.equal(actual.target,'model-target');assert.equal(actual.sessionId,'same-modeled-session');assert.equal(actual.ownerInstance,'a'.repeat(32));
 assert.equal(actual.args.expectedOwnerInstance,'a'.repeat(32));assert.equal(actual.operation,'touch-release');
});
test('legacy empty cleanup args remain literal and malformed scoped shapes refuse before dispatch',async()=>{
 const f=model('a'.repeat(32)),route=await f.start();await route.request('touch-inspect',{});
 assert.equal(Object.keys(f.calls.at(-1).args).length,0);const before=f.calls.length;
 const bad=profile('a'.repeat(32));delete bad.referenceJson;
 await assert.rejects(route.request('touch-release',bad));assert.equal(f.calls.length,before);
});
