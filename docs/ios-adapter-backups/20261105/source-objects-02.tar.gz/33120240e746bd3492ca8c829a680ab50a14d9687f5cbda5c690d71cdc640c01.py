"""Every mutable alias is read; literal parser descriptors remain authoritative."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import gc
from types import SimpleNamespace
import unittest
import weakref
from adapters.normal_ui import NativeUIError
from ios.adapters import snapshot_photos_end_round as round_module
from ios.adapters import snapshot_photos_parser_tree as tree_module
from ios.adapters.snapshot_photos_parser_tree import tree_reader


def literal_parser_identity():
    """The original full tuple grammar, without the new constant reader."""
    round_module.need(round_module.IOSSnapshotPhotosOwner.capture is round_module._CAPTURE
        and round_module.IOSSnapshotCaptureOwner.archive.__func__ is round_module._ARCHIVE
        and round_module.SnapshotPhotosArchive.guard is round_module._GUARD)
    memo={};current={}
    for name,(module,expected) in round_module._ORIGINAL.items():
        round_module.need(round_module.sys.modules.get(name) is module)
        signature=round_module.methods(vars(module),memo)
        round_module.need(signature==expected);current[name]=(module,signature)
    result=[]
    for name,module in sorted(round_module.modules().items()):
        previous=current.get(name)
        signature=previous[1] if previous is not None and previous[0] is module else round_module.methods(vars(module),memo)
        constants=tuple((key,round_module.data(value)) for key,value in sorted(vars(module).items())
            if key.isupper() and key not in ('_ORIGINAL','_BASELINES','_DEPENDENCIES'))
        result.append((name,id(module),signature,constants))
    return tuple(result)


class SnapshotPhotosParserTreeTests(unittest.TestCase):
    def reader(self,hook=None):
        self.calls=[]
        def data(value):
            self.calls.append(id(value));descriptor=round_module.data(value)
            if hook:hook(value)
            return descriptor
        self.namespace=SimpleNamespace(data=data);return tree_reader(self.namespace)
    def test_actual_complete_parser_identity_tuple_parity(self):
        self.assertEqual(literal_parser_identity(),round_module.parser_identity())
    def test_equal_mutable_aliases_avoid_only_materialization(self):
        reader=self.reader();value={'rows':[{'a':1,'b':True},('tail',)]};first=reader(value);second=reader(value)
        self.assertEqual(round_module.data(value),first);self.assertEqual(first,second);self.assertEqual(1,len(self.calls))
        value['rows'][0]['a']=2;third=reader(value);self.assertEqual(round_module.data(value),third);self.assertNotEqual(first,third)
        self.assertEqual(2,len(self.calls))
    def test_early_alias_descriptor_is_not_rewritten_after_later_mutation(self):
        reader=self.reader();value={'a':[0]};early=reader(value);value['a'][0]=1;later=reader(value)
        self.assertEqual((('a',(0,)),),early);self.assertEqual((('a',(1,)),),later)
    def test_new_string_key_and_equal_reordering(self):
        reader=self.reader();value={'b':2,'a':1};first=reader(value)
        value.clear();value.update(a=1,b=2);self.assertEqual(first,reader(value));self.assertEqual(1,len(self.calls))
        value['c']=3;self.assertEqual(round_module.data(value),reader(value));self.assertEqual(2,len(self.calls))
    def test_primitive_types_nan_and_signed_zero(self):
        for before,after in ((True,1),(1,1.0),(-0.0,0.0),(float('nan'),float('nan')),(b'x','x')):
            with self.subTest(types=(type(before),type(after))):
                reader=self.reader();value={'v':before};first=reader(value);self.assertIs(first,reader(value))
                value['v']=after;second=reader(value);self.assertEqual(2,len(self.calls));self.assertIsNot(first,second)
                self.assertIs(after,second[0][1])
    def test_depth5_6_7_identity_boundary(self):
        for depth in (5,6,7):
            with self.subTest(depth=depth):
                reader=self.reader();leaf=[];value=leaf
                for _ in range(depth):value=[value]
                first=reader(value);self.assertEqual(round_module.data(value),first)
                leaf.append('changed');self.assertEqual(round_module.data(value),reader(value))
                self.assertEqual(2 if depth==5 else 1,len(self.calls))
    def test_cycle_and_container_subclass_use_literal_fallback(self):
        class List(list):pass
        cycle=[];cycle.append(cycle)
        for value in (cycle,{'v':cycle},List([1]),{'v':List([1])},{'set':{1,2}}):
            with self.subTest(kind=type(value).__name__):
                reader=self.reader();self.assertEqual(round_module.data(value),reader(value));reader(value)
                self.assertEqual(2,len(self.calls))
    def test_opaque_key_side_effects_match_old_call_count_and_order(self):
        events=[];other={'a':0}
        class Key:
            def __str__(self):events.append('str');other['a']+=1;return 'key'
        value={Key():1};reader=self.reader();early=reader(other)
        reader(value);reader(value);later=reader(other)
        self.assertEqual(['str','str'],events);self.assertEqual((('a',0),),early);self.assertEqual((('a',2),),later)
        self.assertEqual(4,len(self.calls))
    def test_shape_construction_mutation_never_admits_stale_descriptor(self):
        mutate=[True]
        def hook(value):
            if mutate[0]:value['a']=2;mutate[0]=False
        reader=self.reader(hook);value={'a':1};first=reader(value);second=reader(value)
        self.assertEqual((('a',1),),first);self.assertEqual((('a',2),),second);self.assertEqual(2,len(self.calls))
    def test_strong_identity_leaf_and_no_cross_call_reuse(self):
        class Opaque:pass
        leaf=Opaque();weak=weakref.ref(leaf);value=leaf
        for _ in range(6):value=[value]
        reader=self.reader();reader(value)
        cursor=value
        for _ in range(5):cursor=cursor[0]
        cursor[0]=None;del leaf;gc.collect();self.assertIsNotNone(weak())
        reader(value);later=tree_reader(self.namespace);later(value);self.assertEqual(3,len(self.calls))
    def test_data_function_code_or_defaults_change_rejects_warm_entry(self):
        reader=self.reader();value={'v':1};reader(value);old=self.namespace.data;self.namespace.data=lambda _value:('wrong',)
        with self.assertRaises(NativeUIError):reader(value)
        self.namespace.data=old;code=old.__code__
        # The original function closes over both hook and self; preserve
        # closure arity while replacing its code object for this metadata case.
        hook=None
        def replacement(value):
            self.calls.append(id(value));return hook(value) if hook else value
        try:
            old.__code__=replacement.__code__
            with self.assertRaises(NativeUIError):reader(value)
        finally:old.__code__=code
        try:
            old.__defaults__=(None,)
            with self.assertRaises(NativeUIError):reader(value)
        finally:old.__defaults__=None

    def test_parser_rejects_changed_helper_alias_or_code(self):
        old=round_module.tree_reader;code=old.__code__
        try:
            round_module.tree_reader=lambda _namespace:lambda value:('wrong',)
            with self.assertRaises(NativeUIError):round_module.parser_identity()
        finally:round_module.tree_reader=old
        def replacement(namespace):return lambda value:value
        try:
            old.__code__=replacement.__code__
            with self.assertRaises(NativeUIError):round_module.parser_identity()
        finally:old.__code__=code


if __name__=='__main__':unittest.main()
