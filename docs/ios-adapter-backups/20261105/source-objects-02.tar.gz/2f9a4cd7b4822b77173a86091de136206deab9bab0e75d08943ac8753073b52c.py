from pathlib import Path
import ast,difflib,hashlib,json,urllib.request,concurrent.futures,os
root=Path.cwd();p=root/'.ios-host-tmp/lifecycle-authenticated-creator-draft-20261028';sdk=Path('/usr/local/lib/overte-ios-remotexpc/5.15.3-r12/pymobiledevice3/site-packages')
def sha(b):return hashlib.sha256(b).hexdigest()
def stat(path):
 s=path.stat();return [s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_uid,s.st_gid,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
refs=['pymobiledevice3/lockdown.py','pymobiledevice3/remote/userspace_tunnel.py','pymobiledevice3/remote/tunnel_service.py','pymobiledevice3/remote/remote_service_discovery.py','pymobiledevice3/service_connection.py','pymobiledevice3/remote/remotexpc.py']
provenance=[]
def capture(rel):
 src=sdk/rel;before=stat(src);raw=src.read_bytes();url='https://raw.githubusercontent.com/doronz88/pymobiledevice3/v11.1.5/'+rel
 official=urllib.request.urlopen(url,timeout=15).read()
 if raw!=official:raise RuntimeError('Official/local source mismatch: '+rel)
 out=p/'originals/sdk'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw)
 if before!=stat(src) or src.read_bytes()!=raw:raise RuntimeError('Source drift')
 return dict(path=str(src),relative=rel,sha256=sha(raw),stat=before,officialURL=url,officialSHA256=sha(official))
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:provenance=list(pool.map(capture,refs))
repo='tests/device/ios/pymobiledevice3_wda_xctest.py';src=root/repo;raw=src.read_bytes();out=p/'originals/repo'/repo;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw);provenance.append(dict(path=str(src),relative=repo,sha256=sha(raw),stat=stat(src)))
(p/'source-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')

def replace(s,a,b):
 if s.count(a)!=1:raise ValueError(('Expected unique anchor',a[:70],s.count(a)))
 return s.replace(a,b)
lock=(p/'originals/sdk/pymobiledevice3/lockdown.py').read_text()
lock=replace(lock,'import time\n','import time\nimport weakref\n')
cls='''class ValidatedSessionSource:
    """Non-serializable borrow of one original successful pairing validation.

    Minted at the existing successful protocol branch, never from a requested
    UDID, an endpoint or a caller-supplied boolean. This is not remote liveness
    or device-side resource retirement evidence.
    """
    def __init__(self, owner, service, writer, session, loop):
        self._owner = weakref.ref(owner)
        self._service = weakref.ref(service)
        self._writer = weakref.ref(writer)
        self._loop = weakref.ref(loop)
        self._session = session

    def current(self):
        owner, service, writer, loop = self._owner(), self._service(), self._writer(), self._loop()
        if (owner is None or service is None or writer is None or loop is None
                or asyncio.get_running_loop() is not loop
                or owner._validated_session_source is not self
                or owner.service is not service or owner.session_id != self._session
                or service.writer is not writer or writer.is_closing()
                or service.reader is None or service.reader.at_eof()):
            raise ConnectionTerminatedError("Original validated lockdown source is unavailable")
        return owner

    def __reduce__(self):
        raise TypeError("A live validated session source cannot be serialized")


'''
lock=replace(lock,'class LockdownClient(ABC, LockdownServiceProvider):\n',cls+'class LockdownClient(ABC, LockdownServiceProvider):\n')
lock=replace(lock,'        self.session_id = None\n        self.pairing_records_cache_folder','        self.session_id = None\n        self._validated_session_source = None\n        self.pairing_records_cache_folder')
lock=replace(lock,'        if self.session_id and self.service:\n            response = await self._request("StopSession"','        self._validated_session_source = None\n        if self.session_id and self.service:\n            response = await self._request("StopSession"')
lock=replace(lock,'        if self.pair_record is None:\n            await self.fetch_pair_record()','        self._validated_session_source = None\n        validation_service = self.service\n        if self.pair_record is None:\n            await self.fetch_pair_record()')
lock=replace(lock,'        self.session_id = start_session.get("SessionID")\n','        self.session_id = start_session.get("SessionID")\n        validation_session = self.session_id\n')
lock=replace(lock,'        # reload data after pairing\n        self.all_values = await self.get_value()','        # reload data after pairing\n        validation_writer = self.service.writer\n        self.all_values = await self.get_value()')
lock=replace(lock,'        self.udid = self.all_values.get("UniqueDeviceID")\n\n        return True','''        self.udid = self.all_values.get("UniqueDeviceID")
        # No extra protocol operation: retain the original successful return's
        # channel only if all awaits above still refer to that same session.
        if (self.service is validation_service and self.session_id == validation_session
                and type(validation_session) is str and validation_session
                and validation_writer is not None and self.service.writer is validation_writer
                and not validation_writer.is_closing()):
            self._validated_session_source = ValidatedSessionSource(
                self, validation_service, validation_writer, validation_session,
                asyncio.get_running_loop())

        return True''')
lock=replace(lock,'        await self.service.close()\n\n    @contextmanager','        self._validated_session_source = None\n        await self.service.close()\n\n    @contextmanager')
# Optional getter performs no protocol work and never upgrades legacy clients.
lock=replace(lock,'    @contextmanager\n    def ssl_file(self)', '''    def validated_session_source(self):
        source = self._validated_session_source
        if source is None:
            raise NotPairedError("Original successful pairing validation is unavailable")
        source.current()
        return source

    @contextmanager
    def ssl_file(self)''')

users=(p/'originals/sdk/pymobiledevice3/remote/userspace_tunnel.py').read_text()
users=replace(users,'async def _create_no_root_tunnel_provider(serial: Optional[str], autopair: bool, remotepairing_fallback: bool = True):','async def _create_no_root_tunnel_provider(serial: Optional[str], autopair: bool, remotepairing_fallback: bool = True, *, require_validated_source: bool = False):')
users=replace(users,'    try:\n        return await tunnel_service.CoreDeviceTunnelProxy.create(lockdown), lockdown','''    try:
        if require_validated_source:
            # create_using_usbmux has already awaited validate_pairing. Require
            # its actual original successful return, without a second StartSession.
            lockdown.validated_session_source().current()
        return await tunnel_service.CoreDeviceTunnelProxy.create(lockdown), lockdown''')
users=replace(users,'class UserspaceRsdTunnel:\n','''class UserspaceRsdSource:
    """Weak, source-local generation borrow; never a JSON capability."""
    def __init__(self, owner, loop, provider, lockdown, client, tun, dial_plane, rsd, authentication):
        self._owner = weakref.ref(owner)
        self._refs = tuple(weakref.ref(value) for value in
                           (loop, provider, lockdown, client, tun, dial_plane, rsd, stack))
        self._authentication = authentication
        self._local_address = tun.addr
        self._rsd_service = weakref.ref(rsd.service)
        self._rsd_writer = weakref.ref(rsd.service._writer)
        self._opener_ref = weakref.ref(rsd.open_connection)

    def current(self):
        owner = self._owner()
        values = tuple(ref() for ref in self._refs)
        if owner is None or any(value is None for value in values):
            raise PyMobileDevice3Exception("Original userspace source was released")
        loop, provider, lockdown, client, tun, dial_plane, rsd, original_stack = values
        if (asyncio.get_running_loop() is not loop or owner._source is not self
                or _active_tunnel is not owner or owner._exit_stack is None
                or owner.rsd is not rsd or owner.tun is not tun or client.tun is not tun
                or stack is not original_stack or dial_plane._tun is not tun
                or tun.addr != self._local_address or rsd.service is not self._rsd_service()
                or rsd.service._open_connection is not self._opener_ref()
                or rsd.service._writer is not self._rsd_writer()
                or self._rsd_writer() is None or self._rsd_writer().is_closing()
                or rsd.service._reader is None or rsd.service._reader.at_eof()
                or tun._closed or dial_plane._closing
                or rsd.open_connection is not self._opener_ref()
                or getattr(self._opener_ref(), "__self__", None) is not dial_plane
                or owner._transport_watcher is None or owner._transport_watcher.done()
                or lockdown.validated_session_source() is not self._authentication
                or self._authentication.current() is not lockdown
                or provider.remote_identifier != rsd.udid or lockdown.udid != rsd.udid):
            raise PyMobileDevice3Exception("Original userspace source changed")
        return rsd, self._local_address

    def udp_socket(self):
        self.current()
        receiver = pytcp_socket(AF_INET6, SOCK_DGRAM)
        try:
            # Check the actual returned receiver's bind implementation, not a
            # requested class name, against the original retained stack module.
            if type(receiver).bind.__globals__.get("stack") is not self._refs[-1]():
                raise PyMobileDevice3Exception("Original UDP stack changed")
            self.current()
            return receiver
        except BaseException:
            receiver.close()
            raise

    def __reduce__(self):
        raise TypeError("A live userspace source cannot be serialized")


class UserspaceRsdTunnel:
''')
users=replace(users,'        self, serial: Optional[str] = None, autopair: bool = True, remotepairing_fallback: bool = True\n','        self, serial: Optional[str] = None, autopair: bool = True, remotepairing_fallback: bool = True,\n        *, require_validated_source: bool = False\n')
users=replace(users,'        self.serial = serial\n','''        if require_validated_source and (autopair or remotepairing_fallback):
            raise ValueError("Strict original source requires existing USB pairing, without automatic pairing/fallback")
        self._require_validated_source = require_validated_source
        self._source = None
        self.serial = serial
''')
users=replace(users,'                self.serial, self.autopair, self.remotepairing_fallback\n','                self.serial, self.autopair, self.remotepairing_fallback,\n                require_validated_source=self._require_validated_source\n')
users=replace(users,'            stack.push_async_callback(provider.close)\n','''            authentication = (lockdown.validated_session_source()
                              if self._require_validated_source else None)
            stack.push_async_callback(provider.close)
''')
# Capture after all original resources registered, before publishing owner.
users=replace(users,'            await rsd.connect()\n        except BaseException:','''            await rsd.connect()
            if self._require_validated_source:
                authentication.current()
                if (lockdown.udid != rsd.udid or provider.remote_identifier != rsd.udid
                        or self.serial != rsd.udid):
                    raise PyMobileDevice3Exception("Original authenticated source identity changed")
                source = UserspaceRsdSource(
                    self, asyncio.get_running_loop(), provider, lockdown, tunnel_result.client,
                    self.tun, dial_plane, rsd, authentication)
        except BaseException:''')
users=replace(users,'        logger.debug("userspace RSD established (no root): %s rsd_port=%s", tunnel_result.address, tunnel_result.port)','''        if self._require_validated_source:
            self._source = source
        logger.debug("userspace RSD established (no root): %s rsd_port=%s", tunnel_result.address, tunnel_result.port)''')
users=replace(users,'    async def _watch_transport_closed(self, client:', '''    def original_source(self):
        source = self._source
        if source is None:
            raise PyMobileDevice3Exception("Original authenticated source is unavailable")
        source.current()
        return source

    async def _watch_transport_closed(self, client:''')
users=replace(users,'        async with _lifecycle_lock():\n            if self._exit_stack is None:', '        async with _lifecycle_lock():\n            self._source = None\n            if self._exit_stack is None:')

keeper=(p/'originals/repo'/repo).read_text()
keeper=replace(keeper,'from contextlib import suppress\n','from contextlib import asynccontextmanager, suppress\n')
keeper=replace(keeper,'import ipaddress\n','import ipaddress\nimport inspect\nimport weakref\n')
anchor='async def run_xctest(request: dict) -> None:\n'
addition='''class OriginalKeeperSource:
    """Same-loop borrow from the ORIGINAL creator; construction opens nothing.

    The creator must already have selected its exclusive userspace path before
    any external Node tunnel is created. Nothing in this class can prove that
    missing cross-process selection or the Appium session route.
    """
    def __init__(self, tunnel):
        from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel
        if type(tunnel) is not UserspaceRsdTunnel:
            raise LaunchError("rsd-connect")
        self._tunnel = weakref.ref(tunnel)
        self._source = tunnel.original_source()
        self._loop = asyncio.get_running_loop()
        self._leases = []
        self._closing = False

    def current(self):
        tunnel = self._tunnel()
        if (tunnel is None or asyncio.get_running_loop() is not self._loop
                or tunnel.original_source() is not self._source):
            raise LaunchError("rsd-connect")
        return self._source.current()

    def touch_lease(self, store, *, binding, run, check):
        from ios.adapters.touch_lease import TouchLease
        from ios.adapters.hid_session import touch_session
        self.current()
        if self._closing:
            raise LaunchError("session-lifetime")
        async def continuity():
            self.current()
            result = check()
            if inspect.isawaitable(result):
                result = await result
            self.current()
            return result
        @asynccontextmanager
        async def session():
            rsd, local_address = self.current()
            # Existing touch context/default PyTCP socket stays on this exact
            # original stack. Its stop/await/close obligations remain unchanged.
            async with touch_session(rsd, local_address,
                                     socket_factory=self._source.udp_socket) as hid:
                self.current()
                yield hid
        lease = TouchLease(store, session, binding=binding, run=run, check=continuity)
        self._leases.append(lease)
        return lease

    async def settle_touches(self):
        # Close admission first. Cancellation is remembered until the original
        # workers settle; no original RSD may close underneath a pending Down.
        # This does not widen TouchLease's 12s intent or the parent's existing
        # stop/kill budgets, and is not device-side retirement evidence.
        self._closing = True
        failure = None
        for lease in self._leases:
            if lease.worker is None:
                continue
            try:
                await lease.release()
            except BaseException as error:
                failure = failure or error
            while not lease.worker.done():
                try:
                    await asyncio.shield(lease.worker)
                except BaseException as error:
                    failure = failure or error
        if failure is not None:
            raise failure


@asynccontextmanager
async def create_original_keeper_source(udid):
    """Original creator extension, only after exclusive creator selection.

    Not wired to main or Node: their kernel creator must be excluded BEFORE
    this function is called. It must never be used as a second-tunnel fallback.
    """
    from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel
    tunnel = UserspaceRsdTunnel(
        serial=udid, autopair=False, remotepairing_fallback=False,
        require_validated_source=True)
    async with tunnel:
        source = OriginalKeeperSource(tunnel)
        source.current()
        try:
            yield source
        finally:
            await source.settle_touches()


@asynccontextmanager
async def original_service_provider(request, original_source):
    if original_source is None:
        async with RemoteServiceDiscoveryService(
                (request["rsdHost"], request["rsdPort"])) as service_provider:
            yield service_provider
        return
    if type(original_source) is not OriginalKeeperSource:
        raise LaunchError("rsd-connect")
    service_provider, _address = original_source.current()
    if service_provider.udid != request["udid"]:
        raise LaunchError("rsd-identity")
    # The original creator retains its AsyncExitStack through this await; the
    # keeper never closes/recreates its borrowed RSD or tunnel.
    yield service_provider


async def run_xctest(request: dict, *, original_source=None) -> None:
'''
keeper=replace(keeper,anchor,addition)
keeper=replace(keeper,'        async with RemoteServiceDiscoveryService(\n                (request["rsdHost"], request["rsdPort"])) as service_provider:\n            if service_provider.udid', '        async with original_service_provider(request, original_source) as service_provider:\n            if service_provider.udid')
keeper=replace(keeper,'            phase = "xctest-config"\n', '            if original_source is not None:\n                original_source.current()\n            phase = "xctest-config"\n')
keeper=replace(keeper,'                if runner.done():\n','                if original_source is not None:\n                    original_source.current()\n                if runner.done():\n')
keeper=replace(keeper,'                    status = await asyncio.wait_for(\n                        client.get_status(), timeout=min(2.5, remaining)\n                    )','                    status = await asyncio.wait_for(\n                        client.get_status(), timeout=min(2.5, remaining)\n                    )\n                    if original_source is not None:\n                        original_source.current()')
# No JSON/request/main/Node capability gate changed. This entry is deliberately
# reachable only via an original live object, not endpoint reconstruction.
entries=[('sdk','pymobiledevice3/lockdown.py',lock),('sdk','pymobiledevice3/remote/userspace_tunnel.py',users),('repo',repo,keeper)]
rows=[];diff=''
for kind,rel,candidate in entries:
 base=(p/'originals'/kind/rel).read_text();ast.parse(candidate)
 out=p/'candidates'/kind/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(candidate)
 rows.append(dict(kind=kind,path=rel,baseSHA256=sha(base.encode()),candidateSHA256=sha(candidate.encode()),candidate=str(out),ast='PASS'))
 diff+=''.join(difflib.unified_diff(base.splitlines(True),candidate.splitlines(True),fromfile='a/'+kind+'/'+rel,tofile='b/'+kind+'/'+rel))
(p/'proposal.diff').write_text(diff)
(p/'manifest.json').write_text(json.dumps(dict(status='PRIVATE-UNRUN-NOT-PRODUCTION',entries=rows,diffSHA256=sha(diff.encode()),sourceProvenanceSHA256=sha((p/'source-provenance.json').read_bytes())),indent=2)+'\n')
print(json.dumps(dict(files=rows,diffSHA256=sha(diff.encode())),indent=2))
