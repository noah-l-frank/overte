"""Close actual precase import failure; no case or resource admission inferred."""
from pathlib import Path
import hashlib,json,runpy
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,x):
 with(d/n).open('x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
C=B/'root-single-emote-source34-durable1-four-window-current998-b1-20261104';assert sha(C/'freeze.json')=='2f45c5394c5fa633d66cbcc157a625930d356384f8630cb2fec523523a21055f'
for n,v in load(C/'freeze.json')['files'].items():assert sha(C/n)==v['sha256']
t=load(C/'terminal.json');assert t['oldRootCount']==998 and len(t['groups'])==1 and len(t['newOriginalRoots'])==4
for k in('allOldOriginalBodiesUnchanged','wholeOwnOutputsTwiceEqual','allExecutedOwnedProcessesAbsent'):assert t[k]is True
assert len(load(C/'global-before.json'))==998 and load(C/'global-before.json')==load(C/'global-after-first.json')==load(C/'global-after-second.json')
assert load(C/'whole-output-first.json')==load(C/'whole-output-second.json')
q=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(q)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(q))['census']
for n,v in load(C/'whole-output-first.json').items():assert census(Path(n))==v
row=t['groups'][0];h=Path(row['input']).parent;assert sha(row['input'])==row['inputSha256']=='6274127d4c3bce58e76af7df7aa07dec3f730814f27b0ee92f597bed9438b010'
plan=load(row['input']);r=load(h/'child-receipts/report.json');ports=load(h/'child-receipts/actual-port-restoration.json');terminal=row['originalTerminal']
assert r['testsRun']is None and r['actualCaseReceipts']==0 and not r['cleanupEstablished']and 'No genuine declared/interpreter module named'in r['fatal']and 'test_emote_rig_measurements'in r['fatal']
assert r['retainedTemporaryDirectories']==[] and ports['toolsRestored']is False and ports['actualClassCleanupRestoration']is None
assert ports['restored']and ports['builtinsCioRestored']and ports['dupPortsRestored']and ports['count']==27 and not ports['controlDescriptors']
assert terminal['childReturnCode']==1 and terminal['ownProcessesAbsent']and not terminal['timedOut']and not terminal['forcedKill']and not terminal['problems']and not terminal['orphansRequiredKill']
assert terminal['actualClassCleanupCustodyEstablished']is False and terminal['actualFourCaseReceiptsEstablished']is False and terminal['allSubjectActualRuntimeOriginsEstablished']is False
for k in('actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','twoFullOwnOutputCensusesEqual','zeroCaseChildBirthsEstablished'):assert terminal[k]is True
outer=h.with_name(h.name+'-outer');drain=load(outer/'actual-process-drain.json');assert not drain['remaining']and not drain['forced']and not drain['timedOut']and not drain['orphansRequiredKill']
for v in drain['owned']:
 try:raw=Path('/proc',str(v['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(raw[raw.rfind(')')+2:].split()[19])!=v['startTicks']
refs={str(p):dict(path=str(p),sha256=sha(p))for root in map(Path,t['newOriginalRoots'])for p in sorted(root.rglob('*'))if p.is_file()and not p.is_symlink()}
O=B/'root-emote20-b1-missing-rig-alias-original-negative-results-20261104';O.mkdir(mode=0o700)
put(O,'results.json',dict(status='ROOT_RETAINED_EMOTE20_B1_PRECASE_MISSING_BARE_RIG_DEFINITION_FAILURE',terminal=terminal,newOriginalRoots=t['newOriginalRoots'],actualCaseExecuted=False,actualReport=r,actualPortRestoration=ports,actualProcessDrain=drain,originalCollectorFreeze=sha(C/'freeze.json'),sourceFreeze=plan['sourceFreeze'],all998OldOriginalBodiesUnchanged=True,runtimeAdmission=None,EndAdmission=None,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(O,'actual-receipt-references.json',refs);put(O,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in O.iterdir()}));print(json.dumps(dict(freeze=sha(O/'freeze.json'),references=len(refs))))
