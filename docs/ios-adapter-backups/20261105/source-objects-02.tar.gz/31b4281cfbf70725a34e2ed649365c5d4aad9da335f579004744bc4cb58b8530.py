from pathlib import Path
import ast,json,hashlib,difflib
P=Path('.ios-host-tmp/lifecycle-original-owner-readonly-preflight-ddi-proposal-20261028');root=P/'candidate/repo/tests/device/ios'
def rep(s,a,b):assert s.count(a)==1,(a[:80],s.count(a));return s.replace(a,b,1)
p=root/'appium_device_preflight.js';s=p.read_text();s=rep(s,"  const request = JSON.parse(Buffer.concat(chunks).toString('utf8'));","""  const request = JSON.parse(Buffer.concat(chunks).toString('utf8'));
  const originalOwnerRequired = request?.originalOwnerRequired === true;
  if (request && Object.hasOwn(request, 'originalOwnerRequired') && !originalOwnerRequired)
    throw new Error('invalid private request');
  if (originalOwnerRequired) delete request.originalOwnerRequired;""")
s=rep(s,'    return {...request, overteBundleId: OVERTE_ID, wdaBundleId: WDA_ID,','    return {...request, originalOwnerRequired, overteBundleId: OVERTE_ID, wdaBundleId: WDA_ID,')
s=rep(s,'    return request;','    return {...request, originalOwnerRequired};')
s=rep(s,'    return {...request, discoverRemappedBundleIds: false};','    return {...request, originalOwnerRequired, discoverRemappedBundleIds: false};')
s=rep(s,"  const remoteXpc = await import(pathToFileURL(path.join(runtime, 'appium', 'node_modules',\n    'appium-ios-remotexpc', 'build', 'src', 'index.js')).href);\n  let applications;\n  let originalOwner = null;\n  if (typeof remoteXpc.originalKeeperOperation === 'function') {","""  let applications;
  let originalOwner = null, remoteXpc = null;
  if (request.originalOwnerRequired) {
    remoteXpc = await import(pathToFileURL(path.join(runtime, 'appium', 'node_modules',
      'appium-ios-remotexpc', 'build', 'src', 'index.js')).href);
    if (typeof remoteXpc.originalKeeperOperation !== 'function') throw new Error('original owner unavailable');""")
s=rep(s,"    } else if (probe.result?.creatorMode !== 'kernel') throw new Error('original owner unavailable');","    } else throw new Error('required original userspace owner unavailable');")
p.write_text(s)
p=root/'appium_device_ddi.js';s=p.read_text();s=rep(s,"  const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));","""  const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
  const originalOwnerRequired = value?.originalOwnerRequired === true;
  if (value && Object.hasOwn(value, 'originalOwnerRequired') && !originalOwnerRequired)
    throw new Error('invalid private DDI request');
  if (originalOwnerRequired) delete value.originalOwnerRequired;""")
s=rep(s,"  if (value.action === 'status' && keys === 'action,imageSha384,udid') return value;","  if (value.action === 'status' && keys === 'action,imageSha384,udid') return {...value, originalOwnerRequired};")
s=rep(s,'    return value;','    return {...value, originalOwnerRequired};')
s=rep(s,"  if (typeof remoteXpc.originalKeeperOperation === 'function') {","  if (request.originalOwnerRequired) {\n    if (typeof remoteXpc.originalKeeperOperation !== 'function') throw new Error('original owner unavailable');")
s=rep(s,"    if (probe.result?.creatorMode !== 'kernel') throw new Error('original owner unavailable');","    throw new Error('required original userspace owner unavailable');")
p.write_text(s)
p=root/'remotexpc_tunnel.py';s=p.read_text()
a='''        validated_files = None
        if arguments.action == "device-ddi-mount":'''
s=rep(s,a,'''        if getattr(arguments, "creator_mode", "kernel") == "userspace-keeper":
            helper_request["originalOwnerRequired"] = True
        validated_files = None
        if arguments.action == "device-ddi-mount":''')
start=s.index('def device_preflight(');end=s.index('\ndef appium_server(',start);piece=s[start:end]
a='''    result = subprocess.run(
        [str(node), str(helper)], input=payload, stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL, cwd=arguments.service_runtime,
        env=environment, timeout=60, check=False,
    )'''
b='''    original_required = getattr(arguments, "creator_mode", "kernel") == "userspace-keeper"
    if original_required:
        request["originalOwnerRequired"] = True
        payload=json.dumps(request,separators=(",", ":")).encode("utf-8")
        # Same original registry route selection as existing DDI/host paths;
        # no second tunnel, session, server or dependency import is started.
        with tempfile.TemporaryDirectory(prefix="overte-ios-original-preflight-") as name:
            data_home=Path(name)/"data";data_home.mkdir(mode=0o700)
            port_file=data_home/TUNNEL_PORT_ITEM;port_file.parent.mkdir(parents=True,mode=0o700)
            descriptor=os.open(port_file,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,"O_NOFOLLOW",0),0o600)
            with os.fdopen(descriptor,"w",encoding="ascii") as output:
                output.write(str(arguments.port));output.flush();os.fsync(output.fileno())
            environment["XDG_DATA_HOME"]=str(data_home)
            result = subprocess.run(
                [str(node), str(helper)], input=payload, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, cwd=arguments.service_runtime,
                env=environment, timeout=60, check=False,
            )
    else:
'''+''.join('    '+line+'\n' for line in a.splitlines())
piece=rep(piece,a,b.rstrip('\n'));s=s[:start]+piece+s[end:]
a='    pre_session_parser = subparsers.add_parser("device-preflight")'
s=rep(s,a,a+'''\n    pre_session_parser.add_argument("--creator-mode", choices=("kernel","userspace-keeper"), default="kernel")
    pre_session_parser.add_argument("--port", type=int, default=DEFAULT_PORT)''')
a='        ddi_parser = subparsers.add_parser(action)';s=rep(s,a,a+'''\n        ddi_parser.add_argument("--creator-mode", choices=("kernel","userspace-keeper"), default="kernel")''')
ast.parse(s);p.write_text(s)
# Rebuild exact metadata after this still-unfrozen source correction.
m=json.loads((P/'manifest.json').read_text());diff=[]
for row in m['files']:
 q=Path(row['candidate']);b=q.read_bytes();row['candidateSHA256']=hashlib.sha256(b).hexdigest();base=Path(row['base']);assert hashlib.sha256(base.read_bytes()).hexdigest()==row['baseSHA256']
 diff.extend(difflib.unified_diff(base.read_text().splitlines(True),b.decode().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path']))
(P/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');(P/'proposal.diff').write_text(''.join(diff))
print(json.dumps({x['path']:x['candidateSHA256'] for x in m['files']},indent=2))
