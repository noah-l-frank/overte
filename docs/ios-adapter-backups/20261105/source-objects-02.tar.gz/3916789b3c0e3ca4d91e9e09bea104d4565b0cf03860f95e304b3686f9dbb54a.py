"""Unrun exact-collector/expected-comparison controls on real modules/classes.

No fake ModuleType/spec/context/owner/frame is synthesized. No case does IO or
constructs application/native owners. Audithooks are passivated, not removed.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextvars import ContextVar
import inspect
import sys
from types import FunctionType
import unittest
from unittest.mock import patch
from ios.adapters import chat_archive_round as rounds
from ios.self_tests import chat_archive_order_subject as subject
from ios.self_tests import chat_archive_signature_oracle as literal


def original(namespace,*,class_cache=None):
    for name in('FunctionType','ModuleType','ContextVar','_MUTATORS','function','need','sorted',
            'isinstance','type','vars','id','str','int','float','bool','tuple','frozenset'):
        if name in vars(rounds):vars(literal)[name]=vars(rounds)[name]
        else:vars(literal).pop(name,None)
    return literal.module_signature(namespace,class_cache=class_cache)


class ChatExpectedRosterComparisonTests(unittest.TestCase):
    def setUp(self):
        self.namespace=vars(subject)
        self.compile,self.compare,self.add_dependency,self.dependency_plan=rounds._make_expected_comparison()
        self.expected=original(self.namespace);self.plan=self.compile(self.expected)

    def current(self):
        value=rounds.module_signature(self.namespace)
        self.assertEqual(original(self.namespace),value)
        return value

    def equal(self):
        current=self.current();proven={}
        actual=self.compare(current,self.expected,self.plan,proven)
        self.assertEqual(current==self.expected,actual)
        return actual,proven

    def test_fresh_real_module_projection_and_same_pass_alias_roster_reuse(self):
        current=self.current();proven={}
        self.assertTrue(self.compare(current,self.expected,self.plan,proven))
        self.assertIn(subject.Child,proven)
        self.assertIs(proven[subject.Child][0],next(row[2]for row in current if row[0]=='Child'))
        first=proven[subject.Child]
        self.assertTrue(self.compare(current,self.expected,self.plan,proven));self.assertIs(first,proven[subject.Child])
        self.assertTrue(self.equal()[0])

    def test_fresh_code_changes_refuse_and_nonidentical_equal_code_uses_literal_fallback(self):
        function=subject.Parent.first;old=function.__code__
        try:
            function.__code__=old.replace()
            accepted,proven=self.equal();self.assertTrue(accepted)
            self.assertNotIn(subject.Parent,proven);self.assertNotIn(subject.Child,proven)
            function.__code__=subject.alternate.__code__;self.assertFalse(self.equal()[0])
        finally:function.__code__=old
        self.assertTrue(self.equal()[0])

    def test_mro_static_class_method_and_alias_mutations_keep_original_refusal(self):
        for key,value in(('first',subject.alternate),('static',staticmethod(subject.alternate)),('bound',classmethod(subject.alternate))):
            with self.subTest(key=key),patch.object(subject.Parent,key,value):self.assertFalse(self.equal()[0])
        bases=subject.Child.__bases__
        try:
            subject.Child.__bases__=(subject.Other,);self.assertFalse(self.equal()[0])
        finally:subject.Child.__bases__=bases
        with patch.object(subject,'Alias',subject.Other):self.assertFalse(self.equal()[0])
        self.assertTrue(self.equal()[0])

    def test_add_remove_type_primitive_and_excluded_mutator_rules_stay_literal(self):
        for key,value in(('NEW_UPPER',3),('new_lower',subject.alternate),('ignored',subject.alternate)):
            with self.subTest(key=key),patch.object(subject,key,value,create=True):self.assertFalse(self.equal()[0])
        with patch.object(subject,'CONSTANT',True):self.assertTrue(self.equal()[0])
        with patch.object(subject.Parent,'save',subject.alternate):self.assertTrue(self.equal()[0])
        old=subject.z_late
        try:del subject.z_late;self.assertFalse(self.equal()[0])
        finally:subject.z_late=old
        with patch.object(subject,'CONTEXT',ContextVar('actual-other-expected-roster',default=None)):self.assertFalse(self.equal()[0])
        with patch.object(subject,'MODULE',inspect):self.assertFalse(self.equal()[0])

    def test_shared_cycle_identity_and_foreign_cycle_error_are_literal(self):
        cycle=[];value=(cycle,);cycle.append(value)
        with patch.object(subject,'CYCLE',value,create=True):
            expected=original(self.namespace);plan=self.compile(expected);cycle.append('mutated-shared-original')
            current=rounds.module_signature(self.namespace)
            self.assertEqual(current==expected,self.compare(current,expected,plan,{}))
            other=[];replacement=(other,);other.append(replacement);other.append('mutated-shared-original')
            with patch.object(subject,'CYCLE',replacement):
                current=rounds.module_signature(self.namespace)
                with self.assertRaises(RecursionError):current==expected
                with self.assertRaises(RecursionError):self.compare(current,expected,plan,{})

    def test_custom_metaclass_equality_keeps_original_callbacks_and_acceptance(self):
        calls=[]
        class Meta(type):
            def __eq__(cls,other):calls.append((cls,other));return True
            __hash__=type.__hash__
        class First(metaclass=Meta):pass
        class Second(metaclass=Meta):pass
        with patch.object(subject,'ActualCustom',First,create=True):
            expected=original(self.namespace);plan=self.compile(expected)
            with patch.object(subject,'ActualCustom',Second):
                current=rounds.module_signature(self.namespace)
                calls.clear();wanted=current==expected;before=tuple(calls)
                calls.clear();actual=self.compare(current,expected,plan,{})
                self.assertEqual(wanted,actual);self.assertEqual(before,tuple(calls));self.assertTrue(before)

    def test_custom_scalar_equality_mutating_later_method_is_not_cached_across_passes(self):
        calls=[];active={'armed':False};function=subject.Parent.first;old=function.__code__
        class Scalar(float):
            def __eq__(self,other):
                calls.append('scalar')
                if active['armed']:active['armed']=False;function.__code__=subject.alternate.__code__
                return super().__eq__(other)
        with patch.object(subject,'A_CALLBACK',Scalar(1),create=True):
            expected=original(self.namespace);plan=self.compile(expected)
            with patch.object(subject,'A_CALLBACK',Scalar(1)):
                try:
                    current=rounds.module_signature(self.namespace);active['armed']=True;calls.clear()
                    wanted=current==expected;before=tuple(calls);self.assertIs(function.__code__,subject.alternate.__code__)
                    function.__code__=old;current=rounds.module_signature(self.namespace);active['armed']=True;calls.clear()
                    actual=self.compare(current,expected,plan,{})
                    self.assertEqual(wanted,actual);self.assertEqual(before,tuple(calls));self.assertTrue(before)
                    active['armed']=False;fresh=rounds.module_signature(self.namespace)
                    self.assertFalse(fresh==expected);self.assertFalse(self.compare(fresh,expected,plan,{}))
                finally:active['armed']=False;function.__code__=old

    def test_str_subclass_key_sort_and_isupper_callbacks_are_exact_collector_calls(self):
        calls=[]
        class Key(str):
            def __lt__(self,other):calls.append('lt');return super().__lt__(other)
            def isupper(self):calls.append('upper');return super().isupper()
        key=Key('odd_key');self.namespace[key]=object()
        try:
            calls.clear();left=original(self.namespace);before=tuple(calls)
            calls.clear();right=rounds.module_signature(self.namespace);after=tuple(calls)
            self.assertEqual(left,right);self.assertEqual(before,after);self.assertIn('upper',after)
            expected=left;plan=self.compile(expected);calls.clear()
            self.assertEqual(right==expected,self.compare(right,expected,plan,{}));self.assertEqual([],calls)
        finally:del self.namespace[key]

    def test_classifier_aliases_and_function_masquerade_keep_original_literal_results(self):
        class Masquerade:
            @property
            def __class__(self):return FunctionType
        with patch.object(subject,'masquerade',Masquerade(),create=True):self.equal()
        for key,value in(('type',subject.Other),('FunctionType',subject.Parent),('str',subject.Other),('dict',subject.Other)):
            with self.subTest(alias=key),patch.object(rounds,key,value,create=True):
                observed=[]
                for reader in(original,rounds.module_signature):
                    try:observed.append(('value',reader(self.namespace)))
                    except Exception as error:observed.append(('error',type(error)))
                self.assertEqual(observed[0],observed[1])
                if observed[0][0]=='value':self.equal()

    def test_comparison_never_repeats_actual_function_code_audit_getters(self):
        held=subject.Parent.first;active={'armed':False,'calls':0}
        def audit(event,args):
            if active['armed']and event=='object.__getattr__'and len(args)==2 and args[0]is held and args[1]=='__code__':active['calls']+=1
        sys.addaudithook(audit)
        try:
            active.update(armed=True,calls=0);current=rounds.module_signature(self.namespace)
            count=active['calls'];self.assertGreater(count,0)
            self.assertTrue(self.compare(current,self.expected,self.plan,{}));self.assertEqual(count,active['calls'])
        finally:active['armed']=False

    def test_actual_sorted_c_return_mutator_is_preserved_in_literal_and_candidate_collectors(self):
        self.assertIsNone(sys.getprofile());prior=sys.getprofile();old=subject.z_late;builtin=sorted
        state={'armed':False,'count':0};codes=(literal.module_signature.__code__,rounds.module_signature.__code__)
        def observe(frame,event,arg):
            if event=='c_return'and any(frame.f_code is code for code in codes)and arg is builtin and state['armed']:
                state['armed']=False;state['count']+=1;subject.z_late=subject.alternate
        try:
            sys.setprofile(observe);state.update(armed=True,count=0)
            left=original(self.namespace);first=state['count'];subject.z_late=old
            state.update(armed=True,count=0);right=rounds.module_signature(self.namespace);second=state['count']
            self.assertEqual(1,first);self.assertEqual(first,second);self.assertEqual(left,right)
            self.assertTrue(self.compare(right,self.expected,self.plan,{}))
            self.assertFalse(self.compare(rounds.module_signature(self.namespace),self.expected,self.plan,{}))
        finally:state['armed']=False;subject.z_late=old;sys.setprofile(prior)
        self.assertIs(sys.getprofile(),prior)

    def test_wrong_or_missing_plan_is_literal_and_equal_code_never_becomes_identity_authority(self):
        current=self.current()
        for plan in(None,(),(self.expected,),(("foreign",),()),(self.expected,())):
            self.assertEqual(current==self.expected,self.compare(current,self.expected,plan,{}))
        self.add_dependency(self.expected);self.assertIs(self.dependency_plan(0)[0],self.expected)
        self.assertIsNone(self.dependency_plan(1))
        old=subject.alternate.__code__
        try:
            subject.alternate.__code__=subject.Parent.first.__code__
            with patch.object(subject.Parent,'first',subject.alternate):self.assertFalse(self.equal()[0])
        finally:subject.alternate.__code__=old

    def test_original_methods_recollects_code_and_namespace_after_every_guard_pass(self):
        name='ios.self_tests.chat_archive_order_subject'
        with patch.multiple(rounds,_MODULES=(name,),_BASELINES={name:(self.namespace,self.expected)},_DEPENDENCIES={},
                _BASELINE_COMPARISONS={name:self.plan},_compare_expected=self.compare):
            self.assertTrue(rounds.original_methods())
            with patch.object(subject.Parent,'first',subject.alternate):self.assertFalse(rounds.original_methods())
            with patch.object(subject,'NEW_UPPER',4,create=True):self.assertFalse(rounds.original_methods())
            self.assertTrue(rounds.original_methods())

    def test_nonexact_receiver_integer_keeps_literal_custom_equality_callback(self):
        calls=[];actual_id=id
        class ReceiverId(int):
            def __eq__(self,other):calls.append('receiver-equality');return super().__eq__(other)
        def identifier(value):return ReceiverId(actual_id(value)) if value is None else actual_id(value)
        with patch.object(rounds,'id',identifier,create=True):
            current=rounds.module_signature(self.namespace)
            calls.clear();wanted=current==self.expected;before=tuple(calls)
            calls.clear();proven={};actual=self.compare(current,self.expected,self.plan,proven)
            self.assertEqual(wanted,actual);self.assertEqual(before,tuple(calls));self.assertTrue(before)
            self.assertNotIn(subject.Parent,proven);self.assertNotIn(subject.Child,proven)
