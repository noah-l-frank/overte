"""Root-only one-shot300+5 supervision; historical originals never excluded."""
from pathlib import Path
_ENTRY_SOURCE_ROOT=Path(__file__).resolve(strict=True).parent
assert not(_ENTRY_SOURCE_ROOT/'__pycache__').exists()and not any(_ENTRY_SOURCE_ROOT.glob('*.pyc')),'Fresh private control-source root must not contain bytecode'
import argparse,builtins,hashlib,io,json,os,signal,subprocess,sys,threading,time,traceback
from metadata_reader import pin,load
from kernel import process,observe,OwnedTerminal,descendants,state,census,absent as kernel_absent
from host_common import head
from admission import require
from kernel_own6_admission import require as require_kernel6
from project_namespace_admission import project_namespace_admission
import global_original_corpus as global_corpus
HERE=Path(__file__).resolve().parent;REPO=HERE.parent.parent;OUTER=HERE.with_name(HERE.name+'-outer')
PORTS=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--approved-inputs-sha',required=True);args=parser.parse_args()
    assert sys.dont_write_bytecode and sys.flags.no_site==1 and Path.cwd()==REPO
    INPUT=HERE/'approved-inputs.json';assert hashlib.sha256(INPUT.read_bytes()).hexdigest()==args.approved_inputs_sha
    plan=load(INPUT);assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)and head()==plan['expectedHead']
    assert plan['wallSeconds']==300 and plan['killGraceSeconds']==5 and len(plan['cases'])==1
    current_readiness,current_readiness_pins=require(plan['rootAdmission'],pin)
    assert current_readiness==plan['qualifiedSourceExecution']and current_readiness['consumerCompositionQualified']is False
    current_kernel,current_kernel_pins=require_kernel6(plan['rootAdmission']['kernelOwn6Proof'],pin,HERE)
    assert plan['qualifiedTerminalKernel']==plan['kernelVariantAdmission']==current_kernel and plan['currentKernelConsumerQualified']is False
    assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in current_kernel_pins.items())
    assert plan['subjectSourceFreeze']==current_readiness['subjectSourceFreeze']and plan['subjectHelperSha256']==current_readiness['helperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
    assert pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
    assert plan['helperQualificationRequiredOriginalRooms']==current_readiness['requiredOriginalRoots']
    assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in current_readiness_pins.items())
    assert plan['kernelVariantAdmission']==current_kernel and current_kernel['emoteConsumerAdmission']is None
    bare_aliases=load(HERE/'declared-bare-source-aliases.json');assert bare_aliases==plan['bareSourceAliasAdmission']
    assert set(bare_aliases)=={'schemaVersion','status','aliases'}and bare_aliases['schemaVersion']==1
    assert bare_aliases['status']=='EXACT_FOUR_GENUINE_DEFINITION_ALIASES_NOT_FALLBACK'and len(bare_aliases['aliases'])==4
    assert {r['name']for r in bare_aliases['aliases']}=={'test_native_feature_observation','test_native_script_roots','test_emote_source_profile','test_native_script_observation'}
    for alias in bare_aliases['aliases']:
        assert set(alias)=={'name','canonical','path','sha256','package'}and alias['package']is False
        path=REPO/'tests/device/self_tests'/(alias['name']+'.py');assert str(path)==alias['path']and path.resolve(strict=True)==path and not path.is_symlink()
        assert [str((base/(alias['name']+'.py')).resolve(strict=True))for base in(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests')if(base/(alias['name']+'.py')).is_file()]==[str(path)]
        assert alias['canonical']=='self_tests.'+alias['name']
        assert plan['modules'][alias['name']]==plan['modules'][alias['canonical']]==dict(path=str(path),sha256=alias['sha256'],package=False)
        assert plan['sourceAndBinaryPins'][str(path)]==pin(path)and plan['sourceAndBinaryPins'][str(path)]['sha256']==alias['sha256']
    namespace_declared=dict(plan['modules'])
    for name,row in plan['projectAliasAdmission']['unadmittedAliases'].items():
        assert name not in namespace_declared;namespace_declared[name]=row['origin']
    namespace_modules,namespace_paths,namespace_original=project_namespace_admission(namespace_declared,
        (REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests'))
    assert namespace_modules==plan['modules']and namespace_paths==plan['originPlan']['namespacePackages']and namespace_original==plan['projectAliasAdmission']
    assert plan['originPlan']['modules']==plan['modules']and plan['originPlan']['projectAliasAdmission']==plan['projectAliasAdmission']
    for name,row in namespace_declared.items():
        assert row['path']in plan['sourceAndBinaryPins']and pin(row['path'])==plan['sourceAndBinaryPins'][row['path']]
        assert row['sha256']==plan['sourceAndBinaryPins'][row['path']]['sha256']

    assert plan['cases']==load(HERE/'exact-one-selector.json')and not OUTER.exists()
    assert not(HERE/'temporary').exists()and not(HERE/'child-logs').exists()and not(HERE/'child-receipts').exists()and not(HERE/'node-raw').exists()
    pins=plan['sourceAndBinaryPins'];before_pins={p:pin(p)for p in pins};assert before_pins==pins
    input_before=pin(INPUT);parent_before=state();ports_before={n:getattr(os,n)for n in PORTS if hasattr(os,n)};io_before=(io.open,builtins.open,os.dup,os.dup2,os.read)
    old=global_corpus.guard();assert len(old)==plan['oldRootCount']
    assert set(current_readiness['requiredOriginalRoots'])<=set(old)
    OUTER.mkdir(mode=0o700)
    def save(name,value):
        path=OUTER/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'w')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    save('source-binary-before.json',before_pins);save('approved-input-before.json',input_before);save('global-before.json',old)
    for name in('temporary','child-logs','child-receipts','node-raw'):(HERE/name).mkdir(mode=0o700)
    logs=HERE/'child-logs';fds=[]
    for name in('stdin.eof','stdout.log','stderr.log','term-stack.log'):
        fd=os.open(logs/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600);os.close(fd)
    start=time.monotonic();child=None;birth=None;birth_identity=None;kernel_observations=[];observed={};forced=False;timed=False;signal_rows=[];problems=[];report=None
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(HERE/'temporary'))
    argv=[plan['pythonExecutable']['path'],'-B','-S',str(HERE/'run-one.py'),str(INPUT),args.approved_inputs_sha]
    save('actual-argv.json',dict(argv=argv,wallSeconds=300,drainSeconds=5,onlyOneSelector=plan['cases']))
    def runner_signal(sig):
        # Only the same real parent-held Popen may be signaled/waited. No
        # descendant/Z observation or process-group row grants authority.
        assert child is not None and birth is not None and birth_identity is not None
        expected=dict(birth_identity);expected['executable']=birth['executable']
        actual=observe(child.pid,expected=expected,parent=os.getpid(),group=child.pid)
        kernel_observations.append(dict(phase='before-original-runner-signal',signal=int(sig),observation=actual))
        if actual['kind']=='PRESENT_LIVE':
            assert actual['executable']==birth['executable']==plan['pythonExecutable']['path']
            child.send_signal(sig);signal_rows.append(dict(signal=int(sig),pid=child.pid,originalBirth=birth,originalFullIdentity=dict(birth_identity),groupSignal=False));return True
        assert actual['kind']in('PRESENT_TERMINAL','MISSING')
        child.wait(timeout=5);return False # Actual wait, never zombie-as-absence.
    try:
        with(logs/'stdin.eof').open('rb')as stdin,(logs/'stdout.log').open('ab',buffering=0)as stdout,(logs/'stderr.log').open('ab',buffering=0)as stderr:
            child=subprocess.Popen(argv,stdin=stdin,stdout=stdout,stderr=stderr,cwd=REPO,env=env,start_new_session=True,close_fds=True)
            original=observe(child.pid,parent=os.getpid(),group=child.pid);kernel_observations.append(dict(phase='actual-runner-birth',observation=original))
            if original['kind']=='PRESENT_TERMINAL':raise OwnedTerminal(original)
            assert original['kind']=='PRESENT_LIVE'
            identity=original['after']['identity'];birth_identity=tuple(identity.items())
            birth={name:identity[name]for name in('pid','parent','group','startTicks')}|dict(executable=original['executable'])
            assert birth['parent']==os.getpid()and birth['group']==child.pid and identity['session']==child.pid and birth['executable']==plan['pythonExecutable']['path']
            save('actual-runner-birth.json',dict(birth=birth,immutableFullIdentity=identity,originalObservation=original))
            while child.poll()is None and time.monotonic()-start<300:
                for pid,row in descendants(os.getpid()).items():
                    if pid!=child.pid:
                        assert row['group']==birth['group'];previous=observed.get(pid)
                        if previous is not None:assert all(previous[name]==row[name]for name in('pid','parent','group','startTicks'))and previous['observation']['after']['identity']['session']==row['observation']['after']['identity']['session']
                        observed.setdefault(pid,row) # First discovery is DATA, not birth/signal authority.
                        kernel_observations.append(dict(phase='descendant-discovery-data-only',pid=pid,observation=row['observation']))
                time.sleep(.1)
            if child.poll()is None:
                timed=True;runner_signal(signal.SIGTERM)
                deadline=time.monotonic()+5
                while child.poll()is None and time.monotonic()<deadline:time.sleep(.05)
                if child.poll()is None:
                    forced=True;runner_signal(signal.SIGKILL)
            child.wait()
    except BaseException:
        problems.append(dict(gate='actual-supervision',traceback=traceback.format_exc()))
        # Preserve the original failure; no second kernel error may abort all
        # later receipts/drains or create a live-exe/terminal signal waiver.
        if child is not None:
            try:
                if child.poll()is None and birth is not None:
                    if runner_signal(signal.SIGKILL):forced=True
                child.wait(timeout=5)
            except BaseException:problems.append(dict(gate='secondary-original-runner-drain',traceback=traceback.format_exc()))
    def check(name,function):
        try:return function()
        except BaseException:problems.append(dict(gate=name,traceback=traceback.format_exc()));return None
    report=check('child-result',lambda:load(HERE/'child-receipts/child-result.json'))
    resource=check('actual-resource-ledger',lambda:load(HERE/'child-receipts/actual-resources.json'))
    restoration=check('actual-current-helper-restoration',lambda:load(HERE/'child-receipts/actual-restoration.json'))
    def current_helper_receipts():
        assert type(report)is dict and type(restoration)is dict
        assert report.get('subjectHelperSha256')==plan['subjectHelperSha256']
        assert report.get('currentSourceExecutionRootFreeze')==current_readiness['rootFreeze']
        assert restoration.get('actualC10dHelperSha256')==plan['subjectHelperSha256']
        return True
    check('actual-current-helper-original-receipt-joins',current_helper_receipts)
    def original_resource_rows():
        assert type(resource)is dict and type(resource.get('nodes'))is list and len(resource['nodes'])<=3
        return resource['nodes']
    resource_rows=check('original-node-resource-rows',original_resource_rows)
    node_rows=[]if resource_rows is None else resource_rows # None remains UNKNOWN, never a zero-birth proof.
    kernel_receipt=check('actual-terminal-kernel-observations',lambda:load(HERE/'child-receipts/actual-terminal-kernel-observations.json'))
    def complete_original_node_lineage():
        assert resource_rows is not None and len(node_rows)==3 and type(kernel_receipt)is dict
        assert child is not None and birth is not None and birth_identity is not None
        assert kernel_receipt['kernelRootProof']==plan['rootAdmission']['kernelOwn6Proof']and kernel_receipt['consumerQualified']is False
        immutable=kernel_receipt['immutableOriginalBirths'];assert type(immutable)is list and len(immutable)==3
        assert {row['role']for row in node_rows}=={'vm','marker-primary','marker-actor'}
        identities={}
        for held in immutable:
            assert set(held)=={'identity','executable'}and set(held['identity'])=={'pid','parent','group','session','startTicks'}
            identity=held['identity'];assert all(type(identity[name])is int and identity[name]>0 for name in identity)
            assert identity['pid']not in identities and identity['parent']==child.pid and identity['group']==identity['session']==child.pid
            assert held['executable']==plan['node']['path'];identities[identity['pid']]=held
        assert len({row['birth']['pid']for row in node_rows})==3
        for row in node_rows:
            assert set(row)=={'role','birth','returnCode','signals','streams'}
            bound=row['birth'];assert set(bound)=={'pid','parent','group','startTicks','executable'}
            held=identities[bound['pid']];identity=held['identity']
            assert all(bound[name]==identity[name]for name in('pid','parent','group','startTicks'))and bound['executable']==held['executable']
            assert type(row['returnCode'])is int and type(row['signals'])is list and all(value in(signal.SIGTERM,signal.SIGKILL)for value in row['signals'])
            assert type(row['streams'])is list and len(row['streams'])==3 and {part['name']for part in row['streams']}=={'stdin','stdout','stderr'}
            for part in row['streams']:
                assert set(part)=={'name','path','actualBytes','closed'}and part['closed']is True and type(part['actualBytes'])is int and part['actualBytes']>=0
                assert Path(part['path']).parent==HERE/'node-raw'/row['role']
        # The constructor callback observations bind the same actual originals;
        # neither discovery nor a later file receipt may substitute a birth.
        births=[row for row in kernel_receipt['observations']if row['phase']=='actual-constructor-return']
        assert len(births)==3 and {row['role']for row in births}=={'vm','marker-primary','marker-actor'}
        for row in births:
            actual=row['observation'];assert actual['kind']=='PRESENT_LIVE'
            held=identities[actual['after']['identity']['pid']]
            assert actual['before']['identity']==actual['after']['identity']==held['identity']and actual['executable']==held['executable']
            assert next(part for part in node_rows if part['role']==row['role'])['birth']['pid']==held['identity']['pid']
        assert set(observed)<=set(identities)
        for pid,row in observed.items():
            held=identities[pid];actual=row['observation']
            assert all(row[name]==held['identity'][name]for name in('pid','parent','group','startTicks'))
            assert actual['after']['identity']==held['identity']and actual['kind']in('PRESENT_LIVE','PRESENT_TERMINAL')
            if actual['kind']=='PRESENT_LIVE':assert actual['executable']==held['executable']
        return True
    lineage=check('complete-three-original-node-lineage',complete_original_node_lineage)
    def original_case_pass():
        assert type(report)is dict
        return report['status']=='PASS'and report['testsRun']==1
    case_pass=check('actual-original-case-report',original_case_pass)
    if case_pass is True:
        def nodes():
            assert lineage is True
            for row in node_rows:
                assert kernel_absent(row['birth']['pid'])and row['returnCode']==0 and not row['signals']
            return True
        check('three-actual-node-identities',nodes)
    absence_observations={}
    def owned_absence():
        # Every retained original or discovered PID remains required even after
        # reparenting. Reused live PIDs also refuse; missing receipts are UNKNOWN.
        absence_observations['noCurrentDescendants']=not descendants(os.getpid())
        absence_observations['originalRunnerAbsent']=child is not None and kernel_absent(child.pid)
        absence_observations['retainedObservedPids']={str(pid):kernel_absent(pid)for pid in observed}
        absence_observations['reportedNodePids']={str(row['birth']['pid']):kernel_absent(row['birth']['pid'])for row in node_rows}
        return absence_observations['noCurrentDescendants']and absence_observations['originalRunnerAbsent']and all(absence_observations['retainedObservedPids'].values())and all(absence_observations['reportedNodePids'].values())
    absent=check('owned-kernel-absence',owned_absence)
    if absent is not True:problems.append(dict(gate='owned-kernel-absence',value=absent))
    quiet_admitted=absent is True and lineage is True
    save('actual-original-node-lineage-absence.json',dict(completeOriginalNodeLineage=lineage,originalResourceRowsAvailable=resource_rows is not None,
        absenceObservations=absence_observations,actualOwnedAbsence=absent,quietCensusesAdmitted=quiet_admitted,discoveryGrantsSignalAuthority=False,consumerQualified=False))
    after_pins=check('source-binary-after',lambda:{p:pin(p)for p in pins});save('source-binary-after.json',after_pins)
    input_after=check('approved-input-after',lambda:pin(INPUT));save('approved-input-after.json',input_after)
    global_first=check('global-first',lambda:global_corpus.guard(new_root=HERE/'temporary'))if quiet_admitted else None
    global_second=check('global-second',lambda:global_corpus.guard(new_root=HERE/'temporary'))if quiet_admitted else None
    save('global-after-first.json',global_first);save('global-after-second.json',global_second)
    first=check('whole-child-first',lambda:census(HERE))if quiet_admitted else None;second=check('whole-child-second',lambda:census(HERE))if quiet_admitted else None
    save('whole-child-first.json',first);save('whole-child-second.json',second)
    drain=state();save('actual-parent-drain.json',dict(before=parent_before,after=drain,equal=drain==parent_before))
    save('actual-terminal-kernel-observations.json',dict(rootProof=plan['rootAdmission']['kernelOwn6Proof'],observations=kernel_observations,immutableRunnerBirth=None if birth_identity is None else dict(birth_identity),descendantDiscoveriesAreDataOnly=True,groupSignalsGranted=False,consumerQualified=False))
    checks=dict(childReturnCode=child.returncode if child else None,actualChildReportPass=case_pass is True,completeOriginalNodeLineage=lineage is True,quietCensusesAdmitted=quiet_admitted,
        expectedHeadUnchanged=head()==plan['expectedHead'],pinsEqual=before_pins==after_pins,approvedInputEqual=input_before==input_after,
        allOldGlobalBodiesExact=bool(global_first and global_second and all(global_first.get(p)==v==global_second.get(p)for p,v in old.items())),
        twoCompleteGlobalCensusesEqual=global_first==global_second and global_first is not None,
        twoWholeChildCensusesEqual=first==second and first is not None,parentFDThreadKernelDrain=drain==parent_before,
        actualOriginalParentPorts=all(getattr(os,n)is fn for n,fn in ports_before.items())and io_before==(io.open,builtins.open,os.dup,os.dup2,os.read),
        ownedProcessesAbsent=absent is True)
    passed=child is not None and child.returncode==0 and not timed and not forced and not problems and all(v is True for k,v in checks.items()if k!='childReturnCode')
    save('terminal.json',dict(status='PASS'if passed else'FAIL',checks=checks,problems=problems,timedOut=timed,forcedKill=forced,
        actualElapsedSeconds=time.monotonic()-start,actualSignals=signal_rows,actualObservedDescendants=observed,newOriginalRootSpellings=[str(HERE),str(HERE/'temporary'),str(OUTER)],
        nativeQualified=False,wholeQualified=False,publicFinishEnabled=False))
    print(json.dumps(dict(status='PASS'if passed else'FAIL',terminal=str(OUTER/'terminal.json')),sort_keys=True));return 0 if passed else 1
if __name__=='__main__':sys.exit(main())
