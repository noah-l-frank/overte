"""Complete original validation on every call; no successful-verdict reuse.

Historical inventory scopes retain their exact entry/exit checks and profile
isolation. No input, validator, dependency, getter, time or None result is
remembered as a successful validation. Existing default direct calls stay direct.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from contextvars import ContextVar
import hashlib
import marshal
from adapters.normal_ui import NativeUIError

VERSION=5
PROFILE='ios-emote-rooted-archive-v1'
AVATAR_PROFILE='ios-avatar-held-scene-archive-v1'
AVATAR_FINAL_PROFILE='ios-avatar-held-final-archive-v1'
PROFILES=frozenset((PROFILE,AVATAR_PROFILE,AVATAR_FINAL_PROFILE))
LIMIT=4096
_ACTIVE=ContextVar('original_pure_validation_round',default=None)
_PROFILE=ContextVar('original_pure_validation_profile',default=None)


@contextmanager
def scope(profile,guard):
    if type(profile) is not str or profile not in PROFILES or not callable(guard):raise NativeUIError('Historical validation scope is unavailable')
    if guard() is False:raise NativeUIError('Historical validation inventory changed')
    token=_ACTIVE.set({});profile_token=_PROFILE.set(profile)
    try:yield
    finally:
        try:
            if guard() is False:raise NativeUIError('Historical validation inventory changed')
        finally:
            _PROFILE.reset(profile_token);_ACTIVE.reset(token)


@contextmanager
def inherited_scope(profile,guard):
    """Keep the existing enclosing historical guard/profile boundary.

    Both owners still check their own inventories. The active dictionary is
    only a compatibility scope marker; VERSION5 stores no validation successes.
    Ordinary scope() still isolates its actual ContextVar lifetime.
    """
    if _ACTIVE.get() is None:
        with scope(profile,guard):yield
        return
    if type(profile) is not str or profile not in PROFILES or profile!=_PROFILE.get() or not callable(guard):raise NativeUIError('Historical validation scope is unavailable')
    if guard() is False:raise NativeUIError('Historical validation inventory changed')
    try:yield
    finally:
        if guard() is False:raise NativeUIError('Historical validation inventory changed')


def returning_input(function,value,*context):
    """Run the supplied complete validator, including on repeated inputs.

    This wrapper grants no purity or callable provenance. Scope/file/code
    guards remain the caller's work; no previous result is an authority.
    """
    return function(value,*context)


def without_result(function,*arguments):
    """Preserve the literal result/exception, never a remembered None."""
    return function(*arguments)
