"""Durable action10/12 settings custody and independently captured live UI.

A settings response never supplies a client permission fact. Every effect is
read from an original current-generation native frame. Lost HTTP delivery is
recovered by the existing read-only command-id endpoint, never by repeating a
set. No Domain process is created, started or restarted here.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import exact,integer,need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same,pack,unpack
from ios.adapters.assets_action_phase import AssetsActionScope
from ios.adapters.assets_controls import project
from ios.adapters.assets_picker import root
from ios.adapters.assets_tree_controls import project as tree_controls
from ios.adapters.assets_usage_controls import project as usage_controls
from ios.adapters.assets_generation_view import AssetsGenerationView
from ios.adapters.assets_write_client import AssetsWriteClient


class AssetsPermissionActions:
    def __init__(self,actions,client,store):
        need(type(client) is AssetsWriteClient and isinstance(store,PrivateFeatureState)
            and client.run==actions.run and client.lock is actions.locks['primary']
            and same(client.binding,actions.binding)
            and store.path==Path(actions.context['roles']['primary']['stateRoot'])/('ios-assets-write-actions-'+actions.run+'.json')
            and client.store.path==store.path.with_name('ios-assets-write-client-'+actions.run+'.json'))
        self.actions,self.client,self.store=actions,client,store
        self.previous=store.read();self.state=dict(entries=[]) if self.previous is None else self.decode(self.previous)
    def guard(self):
        self.actions.guard();self.client.lock.assert_held()
        need(same(self.store.read(),self.previous) and same(self.client.store.read(),self.client.previous))
        if self.client.state is not None:need(same(self.client.envelope(),self.client.previous))
        return True
    def envelope(self):
        return dict(iosAssetsPermissionActionsVersion=1,runId=self.actions.run,selectedPair=self.actions.selected.link(),
            clientPath=str(self.client.store.path),payload=pack([self.state]))
    def decode(self,value):
        exact(value,{'iosAssetsPermissionActionsVersion','runId','selectedPair','clientPath','payload'})
        need(type(value['iosAssetsPermissionActionsVersion']) is int and value['iosAssetsPermissionActionsVersion']==1
            and value['runId']==self.actions.run and same(value['selectedPair'],self.actions.selected.link())
            and value['clientPath']==str(self.client.store.path))
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0];exact(state,{'entries'})
        need(type(state['entries']) is list and len(state['entries'])<=2)
        prior=0
        for ordinal,row in enumerate(state['entries']):
            exact(row,{'index','ticket','allowed','commandIndex','originalSha256','effect'})
            need(type(row['index']) is int and row['index']==(10,12)[ordinal] and type(row['allowed']) is bool
                and row['allowed'] is (row['index']==12) and integer(row['commandIndex'],prior+1,128))
            self.actions.phase_packet(self._action(row)['before'],row['index'],row['ticket']);prior=row['commandIndex']
            commands=[] if self.client.state is None else self.client.state['commands']
            if len(commands)>=row['commandIndex']:
                entry=commands[row['commandIndex']-1];query=entry['query']
                need(query['operation']=='set' and query['runId']==self.actions.run and query['allowed'] is row['allowed'])
                if row['originalSha256'] is not None:need(entry['original'] is not None and digest(entry['original'])==row['originalSha256'])
            else:need(row['originalSha256'] is None and row['effect'] is None and ordinal==len(state['entries'])-1)
            if row['effect'] is not None:
                effect=row['effect'];exact(effect,{'viewPath','frameIndex','frameSha256'})
                need(row['originalSha256'] is not None and integer(effect['frameIndex'],1,160)
                    and effect['viewPath']==str(self._view_path()))
            if row['originalSha256'] is None:need(row['effect'] is None)
        return state
    def _view_path(self):
        root_path=self.actions.selected.context['roles']['primary']['stateRoot']
        # The actual episode directory name is fixed by AssetsEpisodes.path;
        # no path from a candidate receipt or settings response is followed.
        return Path(root_path)/('assets-episode-'+self.actions.run+'-2-primary-state')/('ios-assets-'+self.actions.run+'-primary-gen2-view.json')
    def _action(self,row):
        index=row['index'];need(type(row['ticket']) is str)
        if len(self.actions.state['records'])>=index:
            value=self.actions.read(index);need(value['ticket']==row['ticket']);return dict(before=value['phaseBefore'])
        pending=self.actions.state['pending'];need(pending is not None and pending['index']==index and pending['ticket']==row['ticket'])
        return pending
    def save(self):
        self.guard();value=self.envelope();self.decode(value);self.store.write(value,self.previous);self.previous=deepcopy(value)
    def effect(self,view,row):
        need(type(view) is AssetsGenerationView and view.actions is self.actions and view.generation.generation==2
            and view.store.path==self._view_path())
        effect=row['effect'];need(effect is not None and effect['frameIndex']<=len(view.state['frames']))
        ref=view.originals.expand(view.state['frames'][effect['frameIndex']-1]);frame=view.originals.read(ref);view.frame(frame)
        need(digest(frame)==effect['frameSha256'] and frame['action']['index']==row['index'] and frame['action']['ticket']==row['ticket'])
        self._effective(frame['native']['ui'],view,row['allowed']);return deepcopy(frame['native']['ui'])
    def _effective(self,packet,view,allowed):
        actual=tree_controls(packet,view.state['page']);usage=usage_controls(packet,view.state['page']);page=root(project(packet),'page',identifier=view.state['page'])
        need(page['visible'] and page['canWrite'] is allowed and actual['canWrite'] is allowed and not actual['busy']
            and usage['permissions']['canWriteAssets'] is allowed and usage['canWrite'] is allowed
            and usage['domainId']==self.client.config['domainId'])
        controls=[row for row in project(packet)['controls'] if row['id']=='assets.delete']
        need(len(controls)==1 and controls[0]['enabled'] is allowed)
    def apply(self,action,view):
        need(type(action) is AssetsActionScope and action.owner is self.actions);action.guard()
        previous=self.client.guard
        def current():action.guard();need(previous() is not False);action.guard();return True
        self.client.guard=current
        try:return self._apply(action,view)
        finally:self.client.guard=previous
    def _apply(self,action,view):
        self.guard();need(type(action) is AssetsActionScope and action.owner is self.actions and action.index in (10,12)
            and type(view) is AssetsGenerationView and view.action is action and not view.historical)
        action.guard();allowed=action.index==12
        rows=[row for row in self.state['entries'] if row['index']==action.index]
        if not rows:
            need(len(self.state['entries'])==(0 if action.index==10 else 1)
                and (not self.state['entries'] or self.state['entries'][-1]['effect'] is not None))
            commands=[] if self.client.state is None else self.client.state['commands']
            need(not commands or commands[-1]['original'] is not None)
            row=dict(index=action.index,ticket=action.ticket,allowed=allowed,commandIndex=len(commands)+1,originalSha256=None,effect=None)
            self.state['entries'].append(row);self.save()
        else:need(len(rows)==1);row=rows[0];need(row['ticket']==action.ticket)
        commands=[] if self.client.state is None else self.client.state['commands']
        if len(commands)<row['commandIndex']:
            need(len(commands)==row['commandIndex']-1);self.client.request('set',allowed=allowed)
        else:
            need(len(commands)==row['commandIndex']);entry=commands[-1]
            need(entry['query']['operation']=='set' and entry['query']['allowed'] is allowed)
            if entry['original'] is None:self.client.recover()
        entry=self.client.state['commands'][row['commandIndex']-1]
        need(entry['original'] is not None)
        if row['originalSha256'] is None:row['originalSha256']=digest(entry['original']);self.save()
        else:need(row['originalSha256']==digest(entry['original']))
        if row['effect'] is not None:return self.effect(view,row)
        for _ in range(32):
            packet=view.capture();actual=tree_controls(packet,view.state['page'])
            if actual['canWrite'] is allowed:
                self._effective(packet,view,allowed);ref=view.originals.expand(view.state['frames'][-1]);frame=view.originals.read(ref)
                row['effect']=dict(viewPath=str(view.store.path),frameIndex=len(view.state['frames']),frameSha256=digest(frame));self.save()
                return self.effect(view,row)
            view.native.sleep(.1)
        need(False)
