"""Actual stopped current235 graph and actual27 mechanisms; no regeneration."""
import hashlib,json,stat
from pathlib import Path
from reviewed_graph_prerequisite import require as require27
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def checkpins(file):
 data=json.loads(file.read_text())
 for name,expected in data.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();v=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):v['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert v==expected and v['stat']==[getattr(p.lstat(),k) for k in F]
 return [Path(name) for name in data]
def require(here,repo,current=None):
 paths=require27(here,repo,current);plan=json.loads((here/'input-plan.json').read_text());stage=Path(plan['actualGraphStage']);out=stage/'root-run-first';report=json.loads((out/'report.json').read_text())
 assert report['exitCode']==1 and report['retainedFiles']==235 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=1,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text())
 for root in (stage,stage/'case-cleanup-1'):
  a=json.loads((root/'terminal-census-1.json').read_text());b=json.loads((root/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 receipt=json.loads((stage/'case-cleanup-1/receipt.json').read_text());assert receipt['actualStandardCaseRunReturned'] and receipt['twoCensusesPassed']
 closes=json.loads((stage/'actual-node-original-close.json').read_text());assert closes['observer']['privateToolFreed'] and closes['actualHostOwnerCount']>0
 assert all(n['returnCode']==0 and (n['current'] is None or n['birth'] is not None and n['current']['startTicks']!=n['birth']['startTicks']) and all(v is None or v is True for v in n['originalStreamsClosed'].values()) for n in closes['nodes'])
 assert all(c['entered'] and c['returned'] and not c['unwound'] and c['returnCode']==0 for c in closes['originalCloseCalls'])
 old=json.loads((out/'root-source-map.json').read_text());assert old['repositoryRoot']==str(repo)
 if current is not None:assert current['currentSourcePins']==old['currentSourcePins'] and current['reviewedCandidates']==old['reviewedCandidates']
 process=json.loads((out/'process-binding.json').read_text())['task']
 try:row=Path('/proc',str(process['pid']),'stat').read_text().rsplit(') ',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):row=None
 assert row is None or int(row[19])!=process['startTicks']
 assert Path(plan['root']).stat().st_dev==plan['currentDevice']==53
 paths+=checkpins(here/'input-graph-pins.json');paths+=checkpins(here/'actual-graph-output-pins.json')
 return paths
