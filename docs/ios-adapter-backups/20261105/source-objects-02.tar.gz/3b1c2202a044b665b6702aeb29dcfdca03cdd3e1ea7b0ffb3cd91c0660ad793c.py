"""Explicit current Callback checkpoint -> file-only copied ownership bridge.

The genuine current controller is used only on first admission. Reentry opens
only its separately typed host-copy WAL; no source/UI/phase input is replayed.
Finish remains the existing deliberately closed Callback terminal operation.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as read_scope
from adapters.script_feature.history import same
from feature_journeys import terminal
from ios.adapters.emote_callback_terminal import IOSEmoteCallbackTerminal,IOSEmoteCallbackTerminalJournal,IOSEmoteCallbackInventory
from ios.adapters.emote_callback_copied_state import metadata_paths
from ios.adapters.emote_callback_copied_ownership import IOSEmoteCallbackCopiedOwnership
from ios.adapters.emote_callback_copied_archive import IOSEmoteCallbackCopiedArchive
from ios.adapters.emote_rooted_end_lock import held_existing
from ios.adapters.emote_rooted_fence import _seal,inactive,inactive_prefixes


def existing(store,*,root,binding,run,lock,actor_lock,guard):
    """Genuine historical file owner constructor; caller holds existing locks."""
    need(store.read() is not None)
    return IOSEmoteCallbackCopiedArchive(store,root=root,binding=binding,run=run,lock=lock,actor_lock=actor_lock,guard=guard)


def freeze(controller,seal):
    need(type(controller) is IOSEmoteCallbackTerminal);terminal.sealed(seal)
    flow,actor=controller.flow,controller.actor
    need(flow.role=='primary' and flow.configured_pair is not None and seal['description']['runId']==flow.run)
    store=PrivateFeatureState(flow.store.path.with_name('ios-emote-primary-'+flow.run+'-callback-copied.json'))
    with held_existing(actor.lock),held_existing(flow.lock),actor.held(30):
        if store.read() is not None:
            # No terminal.window/components/phase.status in this recovery path.
            def guard():flow.lock.assert_held();actor.lock.assert_held();controller.clock();return True
            owner=existing(store,root=flow.root,binding=flow.state['binding'],run=flow.run,lock=flow.lock,actor_lock=actor.lock,guard=guard)
            result=owner.freeze();copies,checkpoint=owner.retained()
            need(same(checkpoint['seal'],seal));return owner,result
        controller.inventory=None
        with read_scope(fresh=True) as reads:
            window=controller.window(retired=True);controller.guard()
            journal=IOSEmoteCallbackTerminalJournal(window,check=controller.guard)
            need(journal.state is not None and journal.state['phase']=='sealed' and same(journal.state['seal'],seal))
            paths=metadata_paths(window,controller.responsibilities)+[journal.store]
            need(len({str(path.path) for path in paths})==len(paths))
            copies={str(path.path):path.read() for path in paths}
            ownership=IOSEmoteCallbackCopiedOwnership(copies,run=flow.run,lock=flow.lock,actor_lock=actor.lock)
            proof,floor,prefixes=ownership.read_with_retirement_context()
            _seal(proof,seal,run=flow.run,role='primary',binding=flow.state['binding'])
            current=flow.phase.status()
            inactive(current,run=flow.run,instance=flow.state['phaseInstance'],ticket=seal['description']['ticket'],after=floor)
            inactive_prefixes(current,prefixes,run=flow.run)
            checkpoint=dict(iosEmoteCallbackInactiveCheckpointVersion=1,runId=flow.run,phaseInstance=flow.state['phaseInstance'],
                configuredTargetPair=deepcopy(flow.configured_pair),seal=deepcopy(seal),terminalProof=deepcopy(proof),
                completionFloorEpochMs=floor,rolePhasePrefixes=deepcopy(prefixes),phaseOriginal=deepcopy(current))
            ownership.read(checkpoint)
            census=IOSEmoteCallbackInventory(journal,reads);census.guard();controller.guard()
        # Inventory's write exceptions belong only to Journal2. It is never
        # widened to tolerate this separate new host-copy owner's outputs.
        # All genuine current responsibility was fully checked above; only
        # read-only file copies are allowed from this point onward.
        def guard():
            flow.lock.assert_held();actor.lock.assert_held();controller.clock()
            need(all(same(path.read(),copies[str(path.path)]) for path in paths));return True
        owner=IOSEmoteCallbackCopiedArchive(store,root=flow.root,binding=flow.state['binding'],run=flow.run,
            lock=flow.lock,actor_lock=actor.lock,guard=guard)
        owner.begin(paths,checkpoint);result=owner.freeze();return owner,result
