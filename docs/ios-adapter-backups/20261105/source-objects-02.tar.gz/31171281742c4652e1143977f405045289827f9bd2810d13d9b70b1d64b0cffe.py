"""Root-only fresh metadata assembly. No target/project import on import."""
from pathlib import Path
import argparse
import hashlib
import importlib.machinery
import json
import os
import sys
from metadata import REPO, SOURCE, FIXTURE, FIXTURE_SHA, PHASE_FIXTURE, OLD, INPUT, CASE
from metadata import pin, sha, load, head


def check(path):
    assert Path.cwd().resolve(strict=True) == REPO
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=False).is_relative_to(REPO / '.ios-host-tmp')
    return path


def frozen(file, digest, pins):
    assert file.is_absolute() and pin(file)['sha256'] == digest
    pins[str(file)] = pin(file)
    value = load(file)
    for name, row in value['files'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        actual = file.parent / name
        assert sha(actual) == (row if type(row) is str else row['sha256'])
        pins[str(actual)] = pin(actual)
    return value


def reference(row, pins):
    file = Path(row['path'])
    assert file.is_absolute() and sha(file) == row['sha256']
    pins[str(file)] = pin(file)
    return file


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--source-freeze', required=True)
    parser.add_argument('--root-context', type=Path, required=True)
    parser.add_argument('--root-context-sha256', required=True)
    parser.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    assert sys.dont_write_bytecode and sys.flags.no_site and Path.cwd() == REPO
    assert len(args.expected_head) == 40 and head() == args.expected_head
    pins = {}
    own = frozen(SOURCE / 'source-freeze.json', args.source_freeze, pins)
    assert own['status'] == 'SOURCE_ONLY_REQUIRES_ROOT_REVIEW_AND_SEPARATE_TARGET'
    frozen(FIXTURE / 'source-freeze.json', FIXTURE_SHA, pins)
    predecessors = load(SOURCE / 'predecessor-packets.json')
    for row in predecessors.values():
        file = reference(row, pins)
        frozen(file, row['sha256'], pins)
    # Preserve every named original predecessor declaration physically.
    prior_source_refs = load(FIXTURE / 'REFERENCED-SOURCE-BYTES.json')
    for name, row in prior_source_refs.items():
        file = Path(name)
        assert file.is_absolute() and file.is_relative_to(REPO)
        if file.is_relative_to(REPO / '.ios-host-tmp'):
            assert sha(file) == row['sha256']
        pins[str(file)] = pin(file)
    prior_result = Path(predecessors['qualifiedPrior']['path']).parent
    actual = load(prior_result / 'results.json')
    assert actual['terminal']['status'] == 'PASS' and actual['originalRegisteredCleanupReturned'] is True
    assert actual['genuineOldLockHeldAndReleased'] is True and actual['inputOriginalEntries'] == 869
    assert len(actual['measurementSummary']) == 3
    for row in load(prior_result / 'actual-receipt-references.json').values():
        reference(row, pins)
    # Current public bytes get independent pins; old private bytes/inodes
    # remain the exact original sources, even when not imported by this case.
    old_origins_path = OLD / 'loaded-project-modules.json'
    old_origins = load(old_origins_path)
    assert len(old_origins) == 474
    pins[str(old_origins_path)] = pin(old_origins_path)
    old_physical_path = OLD / 'actual-code-origins-before.json'
    old_physical = load(old_physical_path)
    assert len(old_physical) == 476
    pins[str(old_physical_path)] = pin(old_physical_path)
    for name, row in old_physical.items():
        file = Path(name)
        assert file.is_absolute() and file.is_relative_to(REPO)
        current = pin(file)
        if file.is_relative_to(REPO / '.ios-host-tmp'):
            assert all(current[key] == value for key, value in row.items())
        pins[str(file)] = current
    prior_plan_path = REPO / '.ios-host-tmp/root-audio-retained-snapshot-first-root681-preparation-20261104/plan.json'
    assert sha(prior_plan_path) == '66f5c486a2defbe1180b40a68a6e65528314b7f64277ec9ebeed166a42c759db'
    pins[str(prior_plan_path)] = pin(prior_plan_path)
    prior_plan = load(prior_plan_path)
    assert prior_plan['controllerSourceFreeze'] == predecessors['controller4']['sha256']
    assert prior_plan['fixtureSourceFreeze'] == '5232010da026e2d15fa26b62d082b1d82b640a2b6e40cc77220d77ffe5eb69b5'
    for name in prior_plan['physicalPins']:
        file = Path(name)
        assert file.is_absolute()
        current = pin(file)
        # All earlier physical private origins retain original exact custody.
        if file.is_relative_to(REPO / '.ios-host-tmp'):
            assert current == prior_plan['physicalPins'][name]
        pins[name] = current
    modules = {}
    for name, row in old_origins.items():
        file = Path(row['path'])
        assert file.is_absolute() and file.is_relative_to(REPO)
        pins[str(file)] = pin(file)
        if file.is_relative_to(REPO / '.ios-host-tmp'):
            assert sha(file) == row['sha256']
        modules[name] = dict(path=str(file), package=row['package'],
            sha256=sha(file), loader='source')
    for name, file in (
            (CASE.split('.')[0], FIXTURE / (CASE.split('.')[0] + '.py')),
            ('test_audio_normal4_retained_passive_snapshot', PHASE_FIXTURE / 'test_audio_normal4_retained_passive_snapshot.py')):
        pins[str(file)] = pin(file)
        modules[name] = dict(path=str(file), package=False, sha256=sha(file), loader='source')
    namespaces = prior_plan['namespacePackages']
    source_namespaces = {}
    for roots in namespaces.values():
        for raw in roots:
            file = Path(raw)
            assert file.resolve(strict=True) == file and file.is_dir() and file.is_relative_to(REPO)
            source_namespaces[str(file)] = sorted(p.name for p in file.iterdir())
    for row in modules.values():
        folder = Path(row['path']).parent
        source_namespaces[str(folder)] = sorted(p.name for p in folder.iterdir())
    source_namespaces[str(SOURCE)] = sorted(p.name for p in SOURCE.iterdir())
    # Only exact already reviewed31 external declarations, never site wildcard.
    third_spec = load(SOURCE / 'third-party-source-rows.json')
    reference(third_spec['source'], pins)
    third = {}
    assert len(third_spec['modules']) == 31
    for name, row in third_spec['modules'].items():
        file = reference(row, pins)
        assert name == 'PIL' or name.startswith(('PIL.', 'defusedxml.')) or name == 'defusedxml'
        third[name] = dict(path=str(file), package=row['package'], sha256=row['sha256'],
            loader='extension' if row['kind'] == 'extension' else 'source')
        source_namespaces[str(file.parent)] = sorted(p.name for p in file.parent.iterdir())
    # Full genuine interpreter closure pinned before importing any candidate.
    std = Path(os.__file__).resolve(strict=True).parent
    suffixes = tuple(importlib.machinery.EXTENSION_SUFFIXES)
    std_namespaces = {}
    for current, directories, files in os.walk(std, topdown=True, followlinks=False):
        folder = Path(current)
        directories[:] = sorted(name for name in directories
            if name not in ('site-packages', 'dist-packages', '__pycache__')
            and not (folder / name).is_symlink())
        relative = folder.relative_to(std)
        if relative.parts and all(part.isidentifier() for part in relative.parts) and not (folder / '__init__.py').exists():
            std_namespaces['.'.join(relative.parts)] = [str(folder)]
        for name in files:
            file = folder / name
            if file.suffix != '.py' and not str(file).endswith(suffixes):
                continue
            assert file.resolve(strict=True) == file and not file.is_symlink()
            assert not any(part in ('site-packages', 'dist-packages') for part in file.parts)
            pins[str(file)] = pin(file)
    python = Path(sys.executable).resolve(strict=True)
    pins[str(python)] = pin(python)
    # Exact old869 membership is data read here, not rewritten or rebased.
    operands = load(FIXTURE / 'selected-original-operands.json')
    input_baseline = reference(operands['existingCensus'], pins)
    baseline869 = load(input_baseline)
    assert len(baseline869) == operands['inputEntries'] == 869
    for key in ('actorLock', 'primaryLock'):
        assert baseline869[operands[key]] == operands['pins'][operands[key]]
    # Generic Root context may add later complete bodies; never shorten it.
    context_path = reference(dict(path=str(args.root_context), sha256=args.root_context_sha256), pins)
    context = load(context_path)
    assert context['status'] == 'ROOT_REVIEWED_QUIET_CURRENT_SOURCE_AND_ORIGINAL_CONTEXT'
    assert context['expectedHead'] == args.expected_head and context['allTargetsTerminal'] is True
    custody = context['globalCustody']
    helper = reference(custody['helper'], pins)
    seed = reference(custody['seed'], pins)
    global_base = reference(custody['baseline'], pins)
    assert custody['helper']['sha256'] == 'bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
    assert seed == helper.with_name('global-original-roots-seed.json')
    global_body = load(global_base)
    assert set(global_body) == set(load(seed)['roots'])
    # Root708 is an immutable predecessor floor, never a target count cap.
    historical = REPO / '.ios-host-tmp/chat-offline-initial4-prepared-root708-head7c18-assembler8-20261104'
    historical_freeze = frozen(historical / 'freeze.json', '84f09534776351a639294c08476706d361ea6f11fb5dfe7d13957ecd5ed3f553', pins)
    old_global = historical / 'global-original-corpus-baseline.json'
    assert sha(old_global) == 'b03e3c44b294c825b9738a4780edc001d6dd09a080c3ec9cb2def03cc157addd'
    pins[str(old_global)] = pin(old_global)
    original_body = load(old_global)
    assert len(original_body) == 708 and set(original_body) <= set(global_body)
    assert all(global_body[key] == value for key, value in original_body.items())
    for addition in context['terminalAdditions']:
        assert set(addition['roots']) <= set(global_body)
        frozen(Path(addition['packet']) / addition['freezeFile'], addition['freezeSha256'], pins)
    for row in context['additionalPhysicalProofs']:
        reference(row, pins)
    # Bind current checkout metadata as independent inputs, not old00faf/06ff.
    gd = Path((REPO / '.git').read_text()[8:].strip()).resolve(strict=True)
    common = (gd / (gd / 'commondir').read_text().strip()).resolve(strict=True)
    ref = (gd / 'HEAD').read_text().strip()
    assert ref.startswith('ref: ')
    ref_path = next((base / ref[5:] for base in (gd, common) if (base / ref[5:]).is_file()), common / 'packed-refs')
    for file in (REPO / '.git', gd / 'HEAD', gd / 'index', gd / 'commondir', ref_path):
        pins[str(file)] = pin(file)
    destination = check(args.destination)
    assert destination.parent == REPO / '.ios-host-tmp' and destination.name.startswith('audio-normal4-parent-evidence-prepared-')
    assert not destination.exists() and head() == args.expected_head
    assert all(pin(path) == row for path, row in pins.items())
    destination.mkdir(mode=0o700)
    plan = dict(status='ROOT_REVIEWED_PREPARED_UNRUN', head=args.expected_head,
        controllerSourceFreeze=args.source_freeze, fixtureSourceFreeze=FIXTURE_SHA, case=CASE,
        seconds=60, graceSeconds=5, inputRoot=str(INPUT), inputEntries=869,
        temporaryDirectories=0, nodeChildren=0, sockets=0,
        inputBaseline=str(input_baseline), inputBaselineSha256=sha(input_baseline),
        oldOrigins=str(old_origins_path), oldOriginsSha256=sha(old_origins_path),
        physicalPins=pins, sourceNamespaces=source_namespaces, modules=modules,
        namespacePackages=namespaces, thirdPartyModules=third, thirdPartyNamespacePackages={},
        stdlibRoots=[str(std)], stdlibNamespacePackages=std_namespaces,
        pythonExecutable=dict(path=str(python), pin=pins[str(python)]),
        sourceHelperSha256='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb',
        sourceExecutionCounterQualified=False,
        sourceQualificationScope='Functional readonly probe only; source-execution counter result must be separately joined by Root before any full source-qualification claim.',
        globalCustody=dict(helperPath=str(helper), seedPath=str(seed), seedSha256=sha(seed),
            baselinePath=str(global_base), baselineSha256=sha(global_base)),
        rootContext=dict(path=str(context_path), sha256=args.root_context_sha256),
        old708BodiesPreserved=True, globalOriginalRoots=len(global_body),
        nativeQualified=False, normalFourthActionQualified=False, wholeQualified=False)
    output = check(destination / 'approved-inputs.json')
    with output.open('x') as stream:
        json.dump(plan, stream, sort_keys=True, indent=2)
        stream.write('\n')
    output.chmod(0o600)
    assert all(pin(path) == row for path, row in pins.items()) and head() == args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN', input=str(output),
        inputSha256=sha(output), sourcePins=len(pins), originalRoots=len(global_body), targets=0)))


if __name__ == '__main__':
    main()
