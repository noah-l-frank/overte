"""Root-only quiet metadata preparer, never a target or project import."""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,shutil,stat,sys
SOURCE=Path(__file__).resolve().parent;PKG=SOURCE/'tablet_fresh4_bootstrap';R=Path.cwd().resolve(strict=True)
assert R.name=='overte-ios-feature-adapters-resume-20261026'and(R/'.git').is_file()and sys.dont_write_bytecode
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exact_shared_source(path,info):
 if info.st_nlink==1:return None
 manifest_path=PKG/'readonly-shared-stdlib-sources.json'
 raw_manifest=manifest_path.read_bytes();assert hashlib.sha256(raw_manifest).hexdigest()=='9615f917af31ea6c7d57a2afa1be49db05c5e513197d50e92db81d270a6a36f4'
 manifest=json.loads(raw_manifest);std=Path(os.__file__).resolve(strict=True).parent
 assert manifest['version']==1 and manifest['actualStdlibRoot']==str(std)
 assert path.resolve(strict=True)==path and path.is_relative_to(std)and path.suffix=='.py'
 assert not any(p in('site-packages','dist-packages')for p in path.parts)
 row=manifest['sources'][str(path)]
 assert info.st_uid==0 and info.st_nlink>1 and not info.st_mode&0o022
 assert[info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns]==[row[k]for k in('device','inode','mode','uid','gid','nlink','bytes','mtimeNs','ctimeNs')]
 return row['sha256']
def pin(p):
 p=Path(p);a=p.lstat();assert p.resolve(strict=True)==p and stat.S_ISREG(a.st_mode)
 shared=exact_shared_source(p,a)
 raw=p.read_bytes();assert[getattr(a,k)for k in FIELDS]==[getattr(p.lstat(),k)for k in FIELDS]
 digest=hashlib.sha256(raw).hexdigest()
 if shared is not None:assert digest==shared
 return dict(stat=[getattr(a,k)for k in FIELDS],sha256=digest)
def check(p):
 assert Path.cwd().resolve(strict=True)==R;p=Path(p);assert p.resolve(strict=False).is_relative_to(R/'.ios-host-tmp');return p
def load(p):return json.loads(Path(p).read_text())
def head():
 gd=Path((R/'.git').read_text()[8:].strip()).resolve(strict=True);common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
 value=(gd/'HEAD').read_text().strip();assert value.startswith('ref: ');ref=common/value[5:]
 return ref.read_text().strip(),(R/'.git',gd/'HEAD',gd/'commondir',gd/'index',ref)
def frozen(folder,leaf,digest,pins):
 file=folder/leaf;assert sha(file)==digest;pins[str(file)]=pin(file)
 body=load(file);rows=body['files'];items=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
 for name,row in items:
  assert not Path(name).is_absolute()and'..'not in Path(name).parts
  p=folder/name;expected=row if type(row)is str else row['sha256'];assert sha(p)==expected;pins[str(p)]=pin(p)
 return body
def ref(row,pins):
 p=Path(row['path']);assert p.is_absolute()and sha(p)==row['sha256'];pins[str(p)]=pin(p);return p
def main():
 a=argparse.ArgumentParser();a.add_argument('--expected-head',required=True);a.add_argument('--source-freeze',required=True)
 a.add_argument('--root-context',type=Path,required=True);a.add_argument('--root-context-sha256',required=True)
 a.add_argument('--output',type=Path,required=True);args=a.parse_args()
 actual,git=head();assert actual==args.expected_head and len(actual)==40
 pins={};own=frozen(SOURCE,'source-freeze.json',args.source_freeze,pins)
 assert own['status']=='SOURCE_ONLY_COMPLETE_REQUIRES_INDEPENDENT_REVIEW','WIP source has no metadata/target admission'
 subject=R/'.ios-host-tmp/tablet-fresh-primary-first4-ordinary-samples-source1-private-20261104'
 frozen(subject,'source-freeze.json','b431e7eefbab8856bc8c8f930098b1f4df917f5a1988559c8baa86f7313dd85a',pins)
 # Physically preserve every authoring/review predecessor, never relabel it.
 previous=load(SOURCE/'predecessor-packets.json')
 for row in previous.values():
  path=ref(row,pins);frozen(path.parent,path.name,row['sha256'],pins)
 deps=load(subject/'SOURCE-INPUTS.json');assert deps['allOldTestBodiesUnchanged']and deps['mutatedPublicPaths']==[]
 for row in deps['public']:ref(row,pins)
 for row in deps['historicalPackets']:ref(row,pins)
 assert pin(args.root_context)['sha256']==args.root_context_sha256;pins[str(args.root_context)]=pin(args.root_context)
 context=load(args.root_context)
 assert context['status']=='ROOT_REVIEWED_QUIET_CURRENT_SOURCE_AND_ORIGINAL_CONTEXT'
 assert context['expectedHead']==actual and context['allTargetsTerminal']is True
 custody=context['globalCustody'];helper=ref(custody['helper'],pins);seedpath=ref(custody['seed'],pins);basepath=ref(custody['baseline'],pins)
 assert custody['helper']['sha256']=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
 baseline=load(basepath);seed=load(seedpath);assert set(baseline)==set(seed['roots'])
 historical=R/'.ios-host-tmp/lifecycle-moving-primary-first1-root687-source4-controller6-final-preparation-20261104'
 frozen(historical,'freeze.json','d0a91ab61a8e578fadc17c4fd9f9ecf17c81ccc2751fb617e5e29eac80f95516',pins)
 old=load(historical/'global-original-corpus-baseline.json');pins[str(historical/'global-original-corpus-baseline.json')]=pin(historical/'global-original-corpus-baseline.json')
 assert len(old)==687 and set(old)<=set(baseline)and all(baseline[k]==v for k,v in old.items())
 for addition in context['terminalAdditions']:
  assert set(addition['roots'])<=set(baseline)
  frozen(Path(addition['packet']),addition['freezeFile'],addition['freezeSha256'],pins)
 for row in context['additionalPhysicalProofs']:ref(row,pins)
 # Complete current source namespace, independent of every old literal map.
 public_roots=[Path(p)for p in load(historical/'public-source-namespace.json')['roots']];source_namespaces={}
 pins[str(historical/'public-source-namespace.json')]=pin(historical/'public-source-namespace.json')
 for root in public_roots:
  assert root.is_relative_to(R)and not root.is_relative_to(R/'.ios-host-tmp')
  for p in(root,*sorted(root.rglob('*'))):
   assert p.resolve(strict=True)==p and not p.is_symlink()
   if p.is_file():pins[str(p)]=pin(p)
   elif p.is_dir():source_namespaces[str(p)]=sorted(x.name for x in p.iterdir())
 modules={};namespaces={};ambiguous={}
 for root in(R/'tests/device',R/'tests/device/self_tests',R/'tests/device/ios/self_tests'):
  for p in sorted(root.rglob('*.py')):
   parts=list(p.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
   if package:parts.pop()
   if not parts:continue
   name='.'.join(parts);row=dict(path=str(p),sha256=sha(p),package=package,loader='source');pins[str(p)]=pin(p)
   if name in ambiguous:
    if row not in ambiguous[name]:ambiguous[name].append(row)
   elif name in modules and modules[name]!=row:ambiguous[name]=[modules.pop(name),row]
   else:modules[name]=row
   for depth in range(1,len(parts)):
    directory=root.joinpath(*parts[:depth]);prefix='.'.join(parts[:depth])
    if not(directory/'__init__.py').exists():
     values=namespaces.setdefault(prefix,[])
     if str(directory)not in values:values.append(str(directory))
 assert set(ambiguous)=={'test_appium_adapter','test_voice_roundtrip'}
 for name,rows in ambiguous.items():assert len(rows)==2 and modules['self_tests.'+name]in rows and modules['ios.self_tests.'+name]in rows
 for name in modules:namespaces.pop(name,None)
 source_namespaces[str(SOURCE)]=sorted(p.name for p in SOURCE.iterdir());source_namespaces[str(PKG)]=sorted(p.name for p in PKG.iterdir())
 for p in sorted(PKG.glob('*.py')):
  pins[str(p)]=pin(p);name='tablet_fresh4_bootstrap'+(''if p.name=='__init__.py'else'.'+p.stem)
  modules[name]=dict(path=str(p),sha256=sha(p),package=p.name=='__init__.py',loader='source')
  if p.name not in('__init__.py','__main__.py'):modules[p.stem]=dict(path=str(p),sha256=sha(p),package=False,loader='source')
 target=subject/'models/test_tablet_fresh_primary_four.py'
 modules['ios.self_tests.test_tablet_fresh_primary_four']=dict(path=str(target),sha256=sha(target),package=False,loader='source');pins[str(target)]=pin(target)
 third=load(SOURCE/'third-party-source-rows.json')['modules']
 for name,row in third.items():
  p=Path(row['path']);assert sha(p)==row['sha256'];pins[str(p)]=pin(p)
  source_namespaces[str(p.parent)]=sorted(x.name for x in p.parent.iterdir())
  row['loader']='extension'if row['kind']=='extension'else'source';row.pop('kind')
 std=Path(os.__file__).resolve(strict=True).parent;stdnames={}
 for current,dirs,files in os.walk(std,topdown=True,followlinks=False):
  directory=Path(current);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(directory/n).is_symlink())
  parts=directory.relative_to(std).parts
  if parts and all(p.isidentifier()for p in parts)and not(directory/'__init__.py').exists():stdnames['.'.join(parts)]=[str(directory)]
  for name in sorted(files):
   p=directory/name
   if p.suffix!='.py'and not any(str(p).endswith(suffix)for suffix in importlib.machinery.EXTENSION_SUFFIXES):continue
   real=p.resolve(strict=True)
   if real.is_relative_to(std)and not any(x in real.parts for x in('site-packages','dist-packages')):pins[str(real)]=pin(real)
 for p in git:pins[str(p)]=pin(p)
 python=Path(sys.executable).resolve(strict=True);node=Path(shutil.which('node')).resolve(strict=True)
 pins[str(python)]=pin(python);pins[str(node)]=pin(node)
 for filename in('tablet_web_host_app.py','tablet_web_host_app.js','tablet_web_echo_fixture.py'):
  p=R/'tests/device/ios/self_tests'/filename;pins[str(p)]=pin(p)
 out=args.output;assert out.is_absolute()and out.resolve(strict=False)==out and out.parent==R/'.ios-host-tmp'and out.name.startswith('tablet-fresh-primary-four-prepared-')and not out.exists()
 assert head()[0]==actual and {p:pin(p)for p in pins}==pins
 check(out).mkdir(mode=0o700)
 for name,path in(('global_original_corpus.py',helper),('global-original-roots-seed.json',seedpath),('global-original-corpus-baseline.json',basepath)):
  t=check(out/name)
  with t.open('xb')as stream:stream.write(path.read_bytes())
  t.chmod(0o600);pins[str(t)]=pin(t)
 def named(name):
  p=R/'tests/device/ios/self_tests'/name;return dict(path=str(p),pin=pins[str(p)])
 plan=dict(status='UNRUN_REQUIRES_ROOT_REVIEW',repositoryRoot=str(R),controllerRoot=str(out),packageSource=str(PKG),actualPublicHead=actual,
  sourceFreeze=args.source_freeze,physicalPins=pins,sourceNamespaces=source_namespaces,modules=modules,namespacePackages=namespaces,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=stdnames,stdlibRoots=[str(std)],
  pythonExecutable=dict(path=str(python),pin=pins[str(python)]),nodeExecutable=dict(path=str(node),pin=pins[str(node)]),
  tabletHostJavaScript=named('tablet_web_host_app.js'),tabletHostPython=named('tablet_web_host_app.py'),tabletEchoPython=named('tablet_web_echo_fixture.py'),
  cases=['ios.self_tests.test_tablet_fresh_primary_four.TabletFreshPrimaryFourSamplesTests.test_fresh_first_four_ordinary_inputs_produce_four_current_primary_png_originals'],wallSeconds=180,killGraceSeconds=5,
  rootContext=dict(path=str(args.root_context),sha256=args.root_context_sha256),globalOriginalRoots=list(baseline),old687Preserved=True,
  expectedTemporaryDirectories=2,expectedNodeBirths=2,maximumLiveNodes=1,expectedHTTPListeners=3,expectedActorBirths=1,maximumTrackerBirths=1,
  nativeCompiled=False,nativeQualified=False,wholeQualified=False,fullNormalObserveQualified=False,independentActorFourQualified=False,pairedEndQualified=False)
 t=check(out/'approved-inputs.json')
 with t.open('x')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
 t.chmod(0o600)
 assert {p:pin(p)for p in pins}==pins and head()[0]==actual
 print(json.dumps(dict(metadataOnly=True,targets=0,controllerRoot=str(out),inputSha256=sha(t),physicalPins=len(pins),originalRoots=len(baseline))))
if __name__=='__main__':main()
