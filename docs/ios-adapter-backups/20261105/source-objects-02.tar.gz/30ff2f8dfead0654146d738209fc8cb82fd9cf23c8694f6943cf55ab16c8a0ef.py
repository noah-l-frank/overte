    def native_passive_acquisition_read(self,args,session):
        """Historical original bytes over the EXISTING chunk operation only."""
        import base64,os
        from adapters.script_feature.history import canonical
        from ios.adapters.lifecycle_touch_resource_owner import _NativeMotionPassiveRead
        expected={'binding','runId','referenceJson','offset','nativePassiveAcquisitionVersion'}
        if (type(args) is not dict or set(args)!=expected or type(args['nativePassiveAcquisitionVersion']) is not int
                or args['nativePassiveAcquisitionVersion']!=1 or type(args['referenceJson']) is not str
                or len(args['referenceJson'])>2048 or type(args['offset']) is not int or args['offset']<0 or args['offset']%4096):
            raise LaunchError('request')
        from ios.adapters import lifecycle_world as world
        scope=_NativeMotionPassiveRead(self,session,world.ACTION,args['binding'],args['runId'])
        try:
            journal=self.native_query_journals.get(args['runId']);reference=decode_owner_packet(args['referenceJson'])
            if journal is None or journal.get('passiveCollection') is None:raise LaunchError('session-lifetime')
            cut=next((row for row in journal['passiveCollection']['cuts'] if row['reference']==reference),None)
            if cut is None:raise LaunchError('request')
            files=self._native_passive_files(journal,scope,'passiveCut');full=files.expand(reference)
            row=journal['previous']['records'][reference['index']-1]
            if row.get('passiveCut') is None or files.compact(row['passiveCut'])!=reference:raise LaunchError('session-lifetime')
            if files.read(full)!=cut['frame']:raise LaunchError('session-lifetime')
            offset=args['offset']
            if offset>=reference['bytes']:raise LaunchError('request')
            scope.current();descriptor=os.open(files.path(full),os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
            with os.fdopen(descriptor,'rb') as stream:
                files.file(files.path(full),stream.fileno(),full);stream.seek(offset);chunk=stream.read(min(4096,reference['bytes']-offset))
                files.file(files.path(full),stream.fileno(),full)
            if files.read(full)!=cut['frame'] or len(chunk)!=min(4096,reference['bytes']-offset):raise LaunchError('request')
            scope.current();payload=canonical(dict(reference=reference,offset=offset,contentBase64=base64.b64encode(chunk).decode('ascii'))).decode('ascii')
            result=dict(originalKeeperNativeAcquisitionReadVersion=2,ownerInstance=self.instance,encoding='canonical-json-ascii',originalJson=payload,
                nativeAcquisitionBound=False,installedCandidateBound=False,nativeMotionGuardAvailable=False,nativeTouchSupport=False,resourceRetirementEstablished=False)
            if len(json.dumps(result,separators=(',',':'),ensure_ascii=True).encode('ascii'))>12000:raise LaunchError('request')
            return result
        finally:scope.close()
