"""Read-only original result attestation; no imports of target/runtime modules."""
from pathlib import Path
import ast,hashlib,json,os,re,stat
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
PREP=REPO/'.ios-host-tmp/world-web-source-clock-query-memo-root25-preparation-doc-corrected-20261028'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def load(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def pin(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
    value={key:getattr(a,key) for key in FIELDS}
    if stat.S_ISREG(a.st_mode):value['sha256']=sha(path)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in FIELDS);return value
def census(root):return {str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))}
def proc(pid):
    try:v=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,processGroup=int(v[2]),session=int(v[3]),startTicks=int(v[19]))
report=load(PREP/'clock25-report.json');run=Path(report['runRoot']);temporary=run/'temporary';plan=load(PREP/'suite-plan.json')
result=load(run/'selected-result.json');ids=plan['suites']['clock25']['caseIds'];assert len(ids)==len(set(ids))==25 and result['selectedIds']==ids and result['testsRun']==25 and result['successful'] and not result['skipped']
assert load(run/'selected-ids-actual.json')==ids
log=(PREP/'clock25-first.log').read_text();assert re.search(r'Ran 25 tests in 7\.134s\s+OK\s',log)
assert report['exitCode']==1 and log.rstrip().endswith('AssertionError: Unexpected actual root count')
assert not list(run.glob('explicit-original-exception-chain-*.json')),'A unit error event would contradict this attestation'
roots=result['retainedTemporaryDirectoryRoots'];assert roots==load(run/'created-original-roots.json') and len(roots)==len(set(roots))==28
created=[line.split(' ',1)[1] for line in log.splitlines() if line.startswith('RETAINED_ACTUAL_WORLD_SOURCE_CLOCK_MEMO_ROOT ')]
# unittest's progress prefix can share a line with the emitted root receipt.
created=re.findall(r'RETAINED_ACTUAL_WORLD_SOURCE_CLOCK_MEMO_ROOT ([^\n]+)',log);assert created==roots
for name in roots:
    p=Path(name);assert p.resolve(strict=True)==p and p.is_relative_to(temporary) and p.parent==temporary
    s=p.lstat();assert stat.S_ISDIR(s.st_mode) and stat.S_IMODE(s.st_mode)==0o700 and s.st_uid==os.geteuid()
assert set(roots)=={str(p) for p in temporary.iterdir()}
for key in ('remainingOwnedChildrenBeforeCensuses','remainingOwnedChildrenAfterCensuses','remainingNewThreadsBeforeCensuses','remainingNewThreads'):assert result[key]==[]
assert result['fixtureAliasesRestored'] and result['auditChildAliasRestored'] and result['originalNodeCloseObservations']==[]
audits=result['actualAuditChildCloseObservations'];assert len(audits)==1 and audits[0]['exitCode']==0 and audits[0]['stdoutClosed'] and audits[0]['stderrClosed']
assert audits==load(run/'actual-isolated-audit-child-close-observations.json')
child=audits[0]['binding'];receipts=list(temporary.glob('*/source-clock-audit-child-result.json'));assert len(receipts)==1
receipt=load(receipts[0]);assert receipt['pid']==child['pid'] and int(receipt['startTicks'])==child['startTicks'] and receipt['exitCode']==0 and receipt['streamsClosed'] and receipt['inputBytesAndNineStatUnchanged']
assert [receipt[k] for k in ('protectedMarshalEvents','protectedBufferCalls','legacyMarshalEvents','legacyBufferCalls')]==[0,0,1,1]
# Absence is established before and after both new and prior original censuses.
def absent():
    for item in (report['taskBinding'],report['runnerBinding'],child):
        current=proc(item['pid']);assert current is None or current['startTicks']!=item['startTicks']
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            v=proc(int(p.name));assert v is None or (v['session']!=report['taskBinding']['session'] and v['processGroup']!=report['taskBinding']['processGroup'])
absent();first=census(temporary)
assert first==load(PREP/'clock25-originals-first.json')==load(PREP/'clock25-originals-second.json')==load(run/'selected-originals-first.json')==load(run/'selected-originals-second.json')
prior_first={}
for row in plan['priorOriginalCorpora']:
    actual=census(Path(row['root']));expected=load(REPO/row['reference'])
    if 'referenceRootKey' in row:expected=expected[row['referenceRootKey']]
    assert actual==expected;prior_first[row['root']]=actual
assert len(prior_first)==31 and sum(row['files'] for row in plan['priorOriginalCorpora'])==17460
assert prior_first==load(PREP/'clock25-prior-originals-before.json')==load(PREP/'clock25-prior-originals-first.json')==load(PREP/'clock25-prior-originals-second.json')
second=census(temporary);assert second==first and sum(stat.S_ISREG(v['st_mode']) for v in second.values())==229
for row in plan['priorOriginalCorpora']:assert census(Path(row['root']))==prior_first[row['root']]
absent()
before=load(PREP/'clock25-source-before.json');after=load(PREP/'clock25-source-after.json');assert before==after and len(after)==7828
assert load(PREP/'clock25-publication-ready-source-map.json')['sourcePins']==before
changed=[];fixture='tests/device/ios/self_tests/world_web_public_vertical_fixture.py'
source='tests/device/ios/adapters/world_web_sources.py'
correction=REPO/'.ios-host-tmp/world-clock-memo-eof-correction-20261028'
assert ast.dump(ast.parse((correction/'before.py').read_text()),include_attributes=True)==ast.dump(ast.parse((correction/'after.py').read_text()),include_attributes=True)
assert sha(correction/'before.py')==after[source]['sha256'] and sha(correction/'after.py')=='a1cac630218d4e5ce1ce8badc952c017913660a2e45a99f3c7c03c6db432563b'
for name,original in after.items():
    actual=pin(REPO/name)
    if actual!=original:
        allowed={fixture:('f935484f3f4f615f73ea89c216ed9339618e4c442772067221521156693219a0','Separately reviewed one-line V7 READS compatibility published after this run'),source:('a1cac630218d4e5ce1ce8badc952c017913660a2e45a99f3c7c03c6db432563b','Root EOF blank correction after run; AST including positions verified identical')}
        assert name in allowed and actual['sha256']==allowed[name][0]
        changed.append(dict(path=name,runSha256=original['sha256'],currentSha256=actual['sha256'],reason=allowed[name][1]))
assert len(changed)==2
for row in load(PREP/'expected-publication.json'):
    expected='a1cac630218d4e5ce1ce8badc952c017913660a2e45a99f3c7c03c6db432563b' if row['path']==source else row['expectedSha256']
    assert sha(REPO/row['path'])==expected
value=dict(status='READONLY_ATTESTED_ACTUAL_25_UNIT_TESTS_PASS_CONTROLLER_METADATA_FAILED',actualUnitTests=25,actualUnitSeconds=7.134,actualParentExitCode=1,actualParentSeconds=report['seconds'],controllerFailure='Predicted27 TD roots but genuine actual28:13new+5GPU+4Source+floor(2+3+1). Original parent failure is preserved; no retry.',actualRetainedRoots=28,actualOriginalFiles=229,priorCorpora=31,priorOriginalFiles=17460,allOriginalByteNineStatCensusesUnchanged=True,runSourcePins=7828,runSourceMapsUnchanged=True,currentSourceMapIsNotOldRunMap=True,onlyReviewedPostRunSourceChange=changed,originalAuditChild=audits[0],auditHookCounts={k:receipt[k] for k in ('protectedMarshalEvents','protectedBufferCalls','legacyMarshalEvents','legacyBufferCalls')},noOwnedProcessAroundBothCensuses=True,originalNoThreadsReceiptsChecked=True,targetImports=False,testsRerun=False,profileExecution=False,nativeCompiled=False,wholeQualified=False)
output=HERE/'attestation.json';assert not output.exists();output.write_text(json.dumps(value,indent=2)+'\n');output.chmod(0o600)
print(json.dumps({k:value[k] for k in ('status','actualUnitTests','actualParentExitCode','actualRetainedRoots','actualOriginalFiles','priorCorpora','priorOriginalFiles')}))
