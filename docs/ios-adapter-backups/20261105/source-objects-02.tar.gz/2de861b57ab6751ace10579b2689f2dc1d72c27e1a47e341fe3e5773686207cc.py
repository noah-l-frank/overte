"""Actual Callback9 end/cold replay/worker4 and lost-return no-replay cases.

These are declared native/SDK/OS models. No real native/device/build or complete
public28-step shared-Journey qualification is inferred from a local end case.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.script_feature.history import unpack
from feature_journeys.witness import Client
from ios import emote_observer
from ios.adapters.emote_observer import EmoteObservationPending
from ios.adapters import emote_callback_canonical_end as canonical
from ios.self_tests.emote_callback_whole_end_fixture import whole_end


class CallbackWholeEndTests(unittest.TestCase):
    def prepared(self):
        f=whole_end(self);normal=f.normal;p,a=normal.flow,normal.actor.flow
        observe=dict(contractVersion=16,runId=p.run,afterSequence=0)
        p.observe(observe);a.observe(observe);p.act(normal.call('play',name='Crying'));normal.target.native.sleep(.25)
        self.assertTrue(a.observe(observe)['state']['override']);p.act(normal.call('cancel'));self.assertFalse(a.observe(observe)['state']['override'])
        normal.call('cleanup');cleanup=dict(contractVersion=16,runId=p.run)
        def waiting(seconds):
            if p.lock._owner is None and p.primary_lock._owner is None:
                self.assertIsNone(a.lock._owner);a.cleanup(cleanup)
            normal.target.domain.sleep(seconds)
        p.sleep=waiting;self.assertEqual(dict(performed=True),p.cleanup(cleanup))
        witness=Client(normal.target.client.url,'r'*64);samples=[]
        for index in range(3):
            primary=p.observe(observe);actor=a.observe(observe);entries=witness.request('/runs/'+p.run)['entries']
            matches=[row for row in entries if row['actorSequence']==actor['sequence']]
            self.assertEqual(1,len(matches));samples.append(dict(primary=primary,actor=matches[0]))
            if index<2:normal.target.domain.sleep(1.6)
        def call(stage,**values):return dict(contractVersion=1,runId=p.run,stage=stage,**values)
        inspect=f.terminal.invoke(call('inspect'))
        sealed=f.terminal.invoke(call('seal',description=inspect['description'],samples=samples))
        witness.request('/runs/'+p.run,method='DELETE')
        return f,call,deepcopy(sealed['seal'])

    def finish(self,f,call,seal,*,fault=''):
        lost=[];f.fault=fault;result=None
        for _ in range(25):
            try:result=f.terminal.invoke(call('finish',seal=seal));break
            except EmoteObservationPending:
                self.assertIsNone(f.normal.flow.lock._owner);self.assertIsNone(f.normal.actor.flow.lock._owner)
                f.normal.target.domain.sleep(1.6)
            except OSError:
                if not fault or lost:raise
                actor=f.facades['actor'];run=actor.run
                if fault=='lost-stop':
                    self.assertEqual(['actor'],f.stops);self.assertFalse(f.alive['actor'])
                    raw=PrivateFeatureState(actor.store.path.with_name('ios-emote-actor-'+run+'-rooted-process-end.json')).read()
                    self.assertEqual('stop-issued',unpack(raw['payload'])[0]['phase'])
                else:
                    self.assertEqual({'actor'},f.deleted)
                    self.assertEqual(1,sum(row[0]=='actor' and row[1]=='DELETE' for row in f.calls))
                    raw=PrivateFeatureState(actor.store.path.with_name('ios-emote-actor-'+run+'-rooted-sdk-end.json')).read()
                    self.assertEqual('delete-issued',unpack(raw['payload'])[0]['phase'])
                lost.append(deepcopy(f.stops if fault=='lost-stop' else f.deleted));f.fault=''
        self.assertIsNotNone(result,'Bounded actual existing end owners did not complete')
        if fault:self.assertEqual(1,len(lost))
        return result

    def assert_ended(self,f,result):
        self.assertEqual('finish',result['stage']);self.assertEqual(['actor','primary'],f.stops)
        self.assertEqual({'actor','primary'},f.deleted)
        for role in ('actor','primary'):
            self.assertEqual(1,sum(row[0]==role and row[1]=='DELETE' for row in f.calls))
            self.assertIsNone(f.base.read_session(role));self.assertIsNone(f.base._binding_store(role).read())
        run=f.normal.flow.run
        end=PrivateFeatureState(f.facades['primary'].store.path.with_name('ios-emote-primary-'+run+'-rooted-end.json')).read()
        self.assertEqual(2,end['iosEmoteRootedEndArchiveVersion']);self.assertEqual('complete',unpack(end['payload'])[0]['phase'])
        archive=PrivateFeatureState(f.facades['primary'].store.path.with_name('ios-emote-primary-'+run+'-rooted-final.json')).read()
        self.assertEqual(2,archive['iosEmoteRootedFinalArchiveVersion'])
        self.assertTrue(all(PrivateFeatureState(path).read() is None for path in archive['paths']))

    def test_normal_typed_end_cold_replay_and_actual_worker4_return_zero_without_new_source_or_command(self):
        f,call,seal=self.prepared();inputs=deepcopy(f.normal.target.vm.state['events'])
        result=self.finish(f,call,seal);self.assert_ended(f,result)
        self.assertEqual(inputs,f.normal.target.vm.state['events'])
        # The physically completed End2 retains immutable typed copies. Missing
        # copied GPU responsibility is still an error, and default ownership1
        # cannot interpret the explicit Callback9 graph after metadata deletion.
        from pathlib import Path
        from ios.adapters.emote_rooted_end_lock import held_existing
        from ios.adapters.emote_callback_finish import existing_archive
        from ios.adapters.emote_callback_ownership import IOSEmoteCallbackOwnership
        from ios.adapters.emote_rooted_ownership import IOSEmoteRootedOwnership
        primary,actor=f.facades['primary'],f.facades['actor']
        with held_existing(actor.lock),held_existing(primary.lock):
            archive,ownership=existing_archive(primary,actor.lock)
            ownership.read();copies=archive.copies()
            with self.assertRaises(NativeUIError):
                IOSEmoteRootedOwnership(copies,run=primary.run,lock=primary.lock,actor_lock=actor.lock).read()
            gpu=[key for key in copies if Path(key).name.startswith('graphics-world-frame-')]
            self.assertTrue(gpu);missing=deepcopy(copies);del missing[gpu[0]]
            with self.assertRaises(NativeUIError):
                IOSEmoteCallbackOwnership(missing,run=primary.run,lock=primary.lock,actor_lock=actor.lock).read()
        before=(deepcopy(f.calls),deepcopy(f.native_reads),deepcopy(f.source_factories),deepcopy(f.stops))
        primary,actor=f.facades['primary'],f.facades['actor']
        self.assertEqual(result,canonical.completed(primary,seal,actor=actor))
        config=dict(iosEmoteObserverVersion=4,target='actor',primaryTarget='primary',runId=primary.run,durationSeconds=1800,
            artifactRoot=str(actor.root),imagePolicy=actor.policy,primaryArtifactRoot=str(primary.root),primaryImagePolicy=primary.policy,
            targetPair=f.callback_selected_pair)
        self.assertEqual(0,emote_observer.run_flow(actor,config,monotonic=actor.monotonic,sleep=actor.sleep))
        self.assertFalse(emote_observer.failure(actor,config))
        self.assertEqual(before,(f.calls,f.native_reads,f.source_factories,f.stops))

    def test_lost_actual_stop_return_never_reissues_the_once_owned_stop_and_still_requires_os_sdk_end(self):
        f,call,seal=self.prepared();result=self.finish(f,call,seal,fault='lost-stop');self.assert_ended(f,result)
        self.assertEqual(1,f.stops.count('actor'));self.assertEqual(1,f.stops.count('primary'))

    def test_lost_actual_sdk_delete_return_only_observes_404_and_never_deletes_twice(self):
        f,call,seal=self.prepared();result=self.finish(f,call,seal,fault='lost-sdk');self.assert_ended(f,result)
        self.assertEqual(1,sum(row[0]=='actor' and row[1]=='DELETE' for row in f.calls))


if __name__=='__main__':unittest.main()
