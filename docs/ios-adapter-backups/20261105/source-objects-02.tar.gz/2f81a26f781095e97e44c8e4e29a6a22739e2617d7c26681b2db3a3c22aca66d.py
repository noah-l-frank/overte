"""Read-only later closure; retain original Node refusal and partial drain."""
from pathlib import Path
import json,hashlib,runpy
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,v):
 with(d/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
h=B/'tablet-fresh-primary-four-prepared-headd483-current1238-b9-20261105';o=h.with_name(h.name+'-outer')
assert sha(h/'approved-inputs.json')=='e08e04fcd63f137eefd374b5e4ed1dd349bb9c84d4dc5eff9c1529d1efa5dcfd'
drain=load(o/'actual-kernel-drain.json');assert len(drain['actualObserved'])==2 and len(drain['remaining'])==len(drain['rescued'])==1 and drain['forced']is drain['timedOut']is False
assert not(o/'terminal.json').exists()and not(o/'global-originals-after-first.json').exists()
raw=h/'child-logs/stdout.log';text=raw.read_text();assert 'Actual original Popen parameters differ'in text and 'Ran 1 test'in text and 'FAILED (errors=1)'in text
secondary=h/'child-logs/stderr.log';assert 'Child write boundary lifetime ended'in secondary.read_text()
report=load(h/'child-receipts/report.json');assert report['testsRun']==1 and report['status']=='FAIL'
for k in('originalPortsRestored','originalCIOUnchanged','dupRestored'):assert report[k]is True
assert report['restoration']['monitor']['localOriginalConstructorToolsRestored']is True
originals=drain['actualObserved'];groups={r['group']for r in originals}
def absent():
 same=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdecimal():continue
  try:raw=(proc/'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  f=raw[raw.rfind(')')+2:].split()
  if int(f[2])in groups or int(f[3])in groups:same.append(dict(pid=int(proc.name),group=int(f[2]),session=int(f[3]),startTicks=int(f[19])))
 for r in originals:
  try:raw=Path('/proc',str(r['pid']),'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  assert int(raw[raw.rfind(')')+2:].split()[19])!=r['startTicks']
 assert same==[];return same
absent()
ctx=load(B/'root-ios-current1238-after-sdk8-b3-actual-import-refusal-context-20261105/root-context.json');expected=load(ctx['globalCustody']['baseline']['path']);assert len(expected)==1238 and load(o/'global-originals-before.json')==expected
for row in ctx['globalCustody'].values():assert sha(row['path'])==row['sha256']
tool=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(tool)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(tool))['census'];current=runpy.run_path(ctx['globalCustody']['helper']['path'])['current']
assert current()==expected
for name,row in load(h/'approved-inputs.json')['physicalPins'].items():
 fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns');p=Path(name)
 assert sha(p)==row['sha256']and[getattr(p.lstat(),k)for k in fields]==row['stat']
rooms=[h,h/'own-toys',o];first={str(p):census(p)for p in rooms};second={str(p):census(p)for p in rooms};assert first==second
one=current();two=current();assert one==two==expected;absent()
out=B/'root-tablet-first4-b9-original-node-parameters-partial-drain-later-readonly-custody-results-20261105';out.mkdir(mode=0o700)
put(out,'whole-first.json',first);put(out,'whole-second.json',second);put(out,'global-after-first.json',one);put(out,'global-after-second.json',two)
put(out,'actual-root-kernel-absence.json',dict(actualOriginals=originals,sameGroupOrSession=absent(),RootSignalsPerformed=0,originalSupervisorPartialDrainUnchanged=True))
refs={str(p):dict(path=str(p),sha256=sha(p))for room in rooms for p in sorted(room.rglob('*'))if p.is_file()and not p.is_symlink()}
terminal=dict(childReturnCode=1,returnCodeScope='Actual original supervisor Tool1259df exit1; no inner runner code is synthesized',ownProcessesAbsent=True,problems=[dict(kind='original-supervisor-partial-drain',originalRemaining=drain['remaining'],originalRescued=drain['rescued'])],timedOut=False,forcedKill=False,laterReadOnlyRootProjectionOnly=True)
put(out,'results.json',dict(status='ROOT_RETAINED_TABLET_B9_NODE_PARAMETERS_ERROR_AND_ORIGINAL_PARTIAL_DRAIN_LATER_ABSENCE',terminal=terminal,newOriginalRoots=list(map(str,rooms+[out])),originalKernelDrain=drain,originalSupervisorTerminal=None,originalInnerReport=report,actualOriginalTestCasesExecuted=1,actualCasesPassed=0,actualOldOriginalRootsUnchanged=1238,originalMissingTerminalAndCensusesNotPromoted=True,RootSignalsPerformed=0,laterEntireHEREOwnToysAndOuterTwiceEqual=True,originalPrimaryFailure=dict(path=str(raw),sha256=sha(raw),reason='Original actual_js Popen parameters refused at genuine constructor before Node birth; exact differing parameter not recorded'),originalChildAtexitSecondary=dict(path=str(secondary),sha256=sha(secondary)),resourceRetirementQualified=False,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(out,'actual-receipt-references.json',refs);put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}));print(json.dumps(dict(freeze=sha(out/'freeze.json'),results=sha(out/'results.json'),references=len(refs),newRoots=4)))
