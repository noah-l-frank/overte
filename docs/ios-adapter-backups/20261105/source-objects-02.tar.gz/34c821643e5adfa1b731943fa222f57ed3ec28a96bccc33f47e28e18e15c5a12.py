"""PRIVATE metadata experiment; no Source integration or qualification."""
from types import FunctionType,ModuleType,BuiltinFunctionType
import json.encoder as encoder
try:
    import _json
except ImportError:
    _json=None

_MAKE=None if _json is None else _json.make_encoder
_STRING=None if _json is None else _json.encode_basestring


def encoder_current():
    # Directly use the exact C branch called by JSONEncoder.iterencode. There
    # is no Python encoder-class/default callback or marshal audit boundary.
    return (_json is not None and _MAKE is not None and type(_STRING) is BuiltinFunctionType
        and _json.make_encoder is _MAKE and encoder.c_make_encoder is _MAKE
        and _json.encode_basestring is _STRING and encoder.encode_basestring is _STRING)


def scan(value):
    """Every actual member on every call; exact types and depth6 identities."""
    pending=[(value,0,False)];active=set();frontier=[];nodes=0
    while pending:
        item,depth,leave=pending.pop();kind=type(item)
        if leave:active.remove(id(item));continue
        nodes+=1
        if nodes>32768 or depth>64:return None
        if item is None or kind is str or kind is bool:continue
        if kind is int:
            if item.bit_length()>4096:return None
            continue
        if kind is float:
            if not (-1.7976931348623157e308<=item<=1.7976931348623157e308):return None
            continue
        if kind is not dict and kind is not list and kind is not tuple:return None
        if id(item) in active:return None
        active.add(id(item));pending.append((item,depth,True))
        if depth==6:frontier.append(id(item))
        if kind is dict:
            if any(type(key) is not str for key in item):return None
            # Canonical traversal is essential: insertion-order swaps must
            # never associate frontier identities with different JSON paths.
            children=tuple(item[key] for key in sorted(item))
        else:children=item
        pending.extend((child,depth+1,False) for child in reversed(children))
    return tuple(frontier)


def current_key(value):
    if not encoder_current():return None
    try:
        frontier=scan(value)
        if frontier is None or not encoder_current():return None
        # Exactly the C encoder arguments from CPython3.14 iterencode:
        # ensure_ascii=False, sort_keys=True, allow_nan=False, compact JSON.
        encode=_MAKE({},None,_STRING,None,':',',',True,False,False)
        body=''.join(encode(value,0))
        if type(body) is not str or len(body)>2*1024*1024 or not encoder_current():return None
        return body,frontier
    except Exception:
        return None


def success_reader(module):
    """One parser_identity invocation only; no cache survives the caller."""
    if type(module) is not ModuleType:raise TypeError('An actual parser module is required')
    literal=module.data;entries={}
    if type(literal) is FunctionType:
        code=literal.__code__;defaults=literal.__defaults__;keywords=literal.__kwdefaults__
    else:code=defaults=keywords=None

    def current():
        return (type(literal) is FunctionType and module.data is literal
            and literal.__code__ is code and literal.__defaults__ is defaults
            and literal.__kwdefaults__ is keywords and keywords is None
            and literal.__closure__ is None and type(defaults) is tuple
            and len(defaults)==2 and defaults[0] is None
            and type(defaults[1]) is int and defaults[1]==0)

    def read(value):
        original=module.data;kind=type(value)
        if not current() or (kind is not dict and kind is not list and kind is not tuple):return original(value)
        key=current_key(value)
        if key is None or not current():return module.data(value)
        prior=entries.get(id(value))
        if prior is not None and prior[0] is value and prior[1]==key:return prior[2]
        result=original(value)
        if current() and (id(value) in entries or len(entries)<32):entries[id(value)]=(value,key,result)
        return result
    return read
