"""Fail closed before ordinary SDK work while Lifecycle cleanup is unresolved."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from functools import wraps
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError

PREFIXES=('ios-lifecycle-','lifecycle-editor-','lifecycle-input-proof-','lifecycle-navigation-proof-','lifecycle-touch-resource-')


def ensure_released(adapter,selector):
    root=adapter.state_path(selector).parent
    if not root.exists():return True
    PrivateFeatureState(root/'lifecycle-entry-boundary.json')._parent()
    entries=list(root.iterdir());need(len(entries)<=4096)
    if any(path.name.startswith(PREFIXES) for path in entries):
        # No complete Lifecycle restoration/quiet/end proof exists yet. An
        # input ACK or retained source archive cannot retire this responsibility.
        raise NativeUIError('Lifecycle ownership requires its original complete cleanup before ordinary session operations')
    return True


def installed_entry(function):
    @wraps(function)
    def entry(self,selector,*args,**kwargs):
        operation=args[0]if function.__name__=='invoke'and args else None
        if operation=='feature.lifecycle-input.cleanup':
            # Independent original Up precedes configuration, installed-code,
            # current Source and whole-feature admission, including failures.
            import asyncio
            from feature_journeys.contract import identifier
            from ios.adapters.lifecycle_original_up import birth_path,OriginalLifecycleUp
            run=identifier(args[1]['runId']);birth=birth_path(self.state_path(selector).parent,run)
            if birth.exists():asyncio.run(OriginalLifecycleUp(birth,run).release())
        if operation in ('feature.lifecycle-input.act','feature.lifecycle-input.observe','feature.lifecycle-input.cleanup','feature.lifecycle-input.terminal'):
            from ios.adapters.feature_configuration import configuration
            config=configuration();need(config is not None and config['iosFeatureAdapterVersion']>=9
                and 'lifecycle-input'in config['areas']and config['lifecycleCoordinatorProfile']=='ios-original-keeper-process-end-v1')
            return function(self,selector,*args,**kwargs)
        ensure_released(self,selector);return function(self,selector,*args,**kwargs)
    return entry
