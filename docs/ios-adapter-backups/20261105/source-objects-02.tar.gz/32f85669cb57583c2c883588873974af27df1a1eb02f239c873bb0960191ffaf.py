"""Exact reviewed C6 file-reader definitions; no Chat validator or SUT import."""
from pathlib import Path
import hashlib,json,os,stat
SOURCE=Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def meta(info):
    return dict(device=info.st_dev, inode=info.st_ino, mode=info.st_mode,
        uid=info.st_uid, gid=info.st_gid, nlink=info.st_nlink,
        bytes=info.st_size, mtimeNs=info.st_mtime_ns, ctimeNs=info.st_ctime_ns)


def pin(path):
    path = Path(path)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode)
    shared_expected = None
    if before.st_nlink != 1:
        # Only these exact ROOT-owned, non-group/world-writable stdlib source
        # identities are shared read-only inputs. All ordinary/raw paths keep
        # the original single-link rule; no source is unlinked or rewritten.
        manifest = load(SOURCE / 'readonly-shared-stdlib-sources.json')
        actual_std = Path(os.__file__).resolve(strict=True).parent
        assert manifest['version'] == 1 and manifest['actualStdlibRoot'] == str(actual_std)
        assert path.is_absolute() and path.resolve(strict=True) == path
        assert path.is_relative_to(actual_std) and path.suffix == '.py'
        assert not any(part in ('site-packages', 'dist-packages') for part in path.parts)
        shared_expected = manifest['sources'].get(str(path))
        assert shared_expected is not None and before.st_nlink > 1
        assert before.st_uid == 0 and not before.st_mode & 0o022
        assert meta(before) == {key:value for key,value in shared_expected.items() if key != 'sha256'}
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        assert meta(os.fstat(fd)) == meta(before)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        assert meta(os.fstat(fd)) == meta(before) == meta(path.lstat())
        assert len(raw) == before.st_size
    finally:
        os.close(fd)
    result = dict(meta(before), sha256=hashlib.sha256(raw).hexdigest())
    if shared_expected is not None:
        assert result == shared_expected
    return result


def census(root):
    """Exact existing-tree census. Called only in a later Root window."""
    root = Path(root)
    result = {}
    def visit(path):
        info = path.lstat()
        row = meta(info)
        if stat.S_ISDIR(info.st_mode):
            assert not path.is_symlink()
            with os.scandir(path) as stream:
                names = sorted(entry.name for entry in stream)
            row['namespace'] = names
            for name in names:
                visit(path / name)
        else:
            row = pin(path)
        assert meta(path.lstat()) == meta(info)
        result[str(path.relative_to(root))] = row
    visit(root)
    return result


def load(path):
    return json.loads(Path(path).read_text())


