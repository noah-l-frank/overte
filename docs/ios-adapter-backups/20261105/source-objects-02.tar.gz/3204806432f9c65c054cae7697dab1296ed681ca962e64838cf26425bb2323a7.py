"""Exact fresh runtime/source constructors; native/SDK transport remains MODEL.

The installed-gate fixture uses actual private artifact/source/session guards
with its declared noninstallable IPA and modeled SDK. The source-only factory
counter creates no session/device/process. The pending guard fixture restores
actual saved floors via existing constructor methods, never injected fields.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib
import uuid
from adapters.native_feature_observation import NativeFeatureObservation
from adapters.native_script_observation import NativeScriptObservation
from adapters.native_script_roots import NativeScriptRoots
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from feature_journeys.phase_fixture import PhaseFixtureReader
from ios.adapters.emote_controls import IOSEmoteIO
from ios.adapters.emote_controls import project
from ios.adapters.emote_originals import IOSEmoteOriginals
from ios.adapters.emote_sources import IOSEmoteSources
from ios.adapters.emote_palette_original import IOSEmotePalette
from ios.adapters.emote_post_controller_runtime_sources import IOSEmotePostControllerRuntimeSources
from ios.adapters.emote_world import IOSEmoteWorld
from ios.adapters.emote_runtime import IOSEmoteRuntime
from ios.self_tests.test_ios_emote_controls import NativeBoundary
from ios.self_tests.test_ios_script_runtime import IOSScriptRuntimeTests
from ios.self_tests.test_ios_emote_sources import BINDING
from ios.self_tests.test_ios_emote_palette_original import PaletteProducer
from ios.self_tests.emote_post_controller_sources_fixture import PostControllerDomain,PhaseWire
from feature_journeys.witness import Journal
from self_tests.test_emote_rig_measurements import RigPackets
from self_tests.test_native_feature_observation import Boundary as Features


def installed_runtime(test):
    fixture=IOSScriptRuntimeTests('test_runtime_uses_real_candidate_scope_and_independent_native_clock_without_launch')
    test.addCleanup(fixture.doCleanups);fixture.setUp()
    return fixture,IOSEmoteRuntime(fixture.f.adapter)


def restored_runtime_sources(domain):
    """A genuine live source constructor used only for its pre-read refusal."""
    old=domain.sources()
    native=NativeFeatureObservation(domain.native_send,lambda:domain.raw,domain.native_clock,lambda:True,31,
        ios=True,native_clock_bound=True,monotonic=domain.monotonic,sleep=domain.sleep)
    roots=NativeScriptRoots(domain.rig.roots.send,domain.rig.roots.original,domain.native_clock,lambda:True,31,ios=True)
    code=domain.rig.code_reader
    scripts=NativeScriptObservation(code.send,code.original,domain.native_clock,lambda:True,31,ios=True)
    palette=IOSEmotePalette(domain.palette_send,domain.palette_read,domain.native_clock,lambda:True,31,
        monotonic=domain.monotonic,sleep=domain.sleep)
    def unavailable(*_args):raise NativeUIError('This guard counter must not query its lower world producer')
    world=IOSEmoteWorld(unavailable,unavailable,domain.native_clock,lambda:True,31,
        monotonic=domain.monotonic,sleep=domain.sleep)
    phase=PhaseFixtureReader(domain.phase_wire,domain.run,'emotes',epoch_ms=domain.epoch,monotonic=domain.monotonic)
    return IOSEmotePostControllerRuntimeSources(old.store,domain.root,old.binding,domain.run,'primary',domain.lock,lambda:True,phase,
        readers=dict(roots=roots,scripts=scripts,native=native,ui=IOSEmoteIO(NativeBoundary()),world=world),palette=palette,
        epoch_ms=domain.epoch,monotonic=domain.monotonic)


class IOSWireRig(RigPackets):
    def native(self,epoch,*,active=False,baseline=False,restore_epoch=None):
        self.sequence+=1
        frames=[self.frame(1,18800,10,False,position=.1)];events=[]
        if not baseline:
            events=[dict(eventSequence=1,kind='override',overrideSequence=1,capturedEpochMs=19000,request=deepcopy(self.request),caller=self.caller('override',19000))]
            frames += [self.frame(2,19200,20,True,position=.2),self.frame(3,19500,30,True,position=.3),
                self.frame(4,20000,50,True,position=.4)]
            # Continue the producer's original timeline, including frames from
            # a real earlier input-barrier acquisition. Never retime that prefix.
            if len(self.frames)>4:frames=deepcopy(self.frames)
            if not active:
                if self.restored_at is None:self.restored_at=restore_epoch
                assert self.restored_at==restore_epoch
                events.append(dict(eventSequence=2,kind='restore',overrideSequence=1,capturedEpochMs=self.restored_at,caller=self.caller('restore',self.restored_at)))
            if not active or epoch>frames[-1]['capturedEpochMs']:
                count=len(frames)+1;evaluation=frames[-1]['evaluationSequence']+10
                frames.append(self.frame(count,epoch,evaluation,active,position=.4+(count-4)*.1))
        self.frames=deepcopy(frames)
        history=dict(historyVersion=2,instance='e'*32,available=True,callSequence=len(events),overrideSequence=0 if baseline else 1,
            frameSequence=len(frames),droppedEvents=0,droppedFrames=0,events=events,frames=frames)
        latest=frames[-1];source=Features();source.sequence=self.sequence-1
        def original(value):
            animation=value['animation'];value.update(instance='a'*32,processId=31,requestedEpochMs=epoch,capturedEpochMs=epoch)
            value['animationFence']=dict(rigId=2,sequence=latest['evaluationSequence']-1,requestedEpochMs=epoch)
            animation.update(rigId=2,capturedEpochMs=epoch,evaluationSequence=latest['evaluationSequence'],overrideActive=active,
                joints=[row['pose'] for row in latest['joints']],history=history)
            if active:animation['clip']=deepcopy(latest['clip'])
            else:animation.pop('clip',None)
        source.mutate=original;source.send(dict(schemaVersion=1,commandId='ios-'+uuid.uuid4().hex,action='feature-native-observe'))
        return deepcopy(source.sample)


class IOSPostControllerDomain(PostControllerDomain):
    def __init__(self,root,lock):
        self.root,self.lock=root,lock;self.host=89000;self.native_epoch=20000;self.time=2.2
        self.rig=IOSWireRig();self.producer=PaletteProducer();self.sent=[];self.raw='';self.palette_raw=''
        self.rig.root_reader=self.rig.roots.reader(ios=True)
        # Fresh current wire grammar at model birth, before any OFS write.
        # These empty callback/scan histories model only a passive source;
        # they prove no marker effect, real VM execution or loaded actor.
        observed=self.rig.code.mutate
        def complete_script_wire(value):
            observed(value)
            value['source'].update(loadSourceVersion=1,loads=dict(complete=True,instance='9'*32,sequence=0,events=[]),
                effectSourceVersion=1,effects=dict(complete=True,scanRadiusMeters=64,scannedEntities=0,entities=[],absentIds=[]))
        self.rig.code.mutate=complete_script_wire
        self.rig.code_reader=NativeScriptObservation(self.rig.code.send,self.rig.code.original,lambda:self.rig.epoch,
            lambda:True,31,ios=True,monotonic=lambda:self.rig.code.clock,sleep=self.rig.code.sleep)
        self.journal=Journal(clock=self.epoch);self.run=self.journal.register('emotes')
        self.host=89900;self.journal.activate(self.run,uuid.uuid4().hex,'baseline',{})
        self.host=90000;phase_before=self.journal.phase(self.run,uuid.uuid4().hex)
        self.lose_palette=False;self.phase_wire=PhaseWire(self)
        before=self.rig.native(18800,baseline=True)
        group=self.rig.group(self.rig.native(20000,active=True));after=self.rig.native(20000,active=True)
        boundary=NativeBoundary();boundary.page=True;boundary.active='Waving';widgets=boundary.capture()
        actual=self.rig.roots.root+'/system/+android_phoneInterface/PhoneEmote.qml'
        [row for row in widgets['controls']if row['id']=='emote.page'][0]['componentSourceSha256']=hashlib.sha256(actual.encode()).hexdigest()
        originals=dict(group,widgets=widgets)
        join=dict(clockJoinVersion=1,hostBeforeEpochMs=90000.,hostAfterEpochMs=91200.,hostBeforeMonotonic=1.,hostAfterMonotonic=2.2,
            nativeBefore=before,nativeAfter=after,originalsSha256=digest(originals),sourceTimes=[dict(source=n,field=f,epochMs=p[f])
                for n,p in originals.items()for f in('capturedEpochMs','sampleEpochMs')if f in p])
        self.host=91200;phase_after=self.journal.phase(self.run,uuid.uuid4().hex)
        frame=dict(group=group,widgets=widgets,ui=project(widgets),clockJoin=join,phaseBefore=phase_before,phaseAfter=phase_after)
        # This fixture produces an immutable historical source using real OFS
        # writes/manifests and the actual source envelope/decoder. It never
        # creates a fake live source reader or mutates historical=False.
        source_store=PrivateFeatureState(root/'ios-emote-primary-sources.json')
        archive=IOSEmoteSources(source_store,root,BINDING,self.run,'primary',lock,lambda:True,None,historical=True)
        assert archive.validate_frame(frame)
        producer=IOSEmoteOriginals(root,BINDING,self.run,'primary',lambda:True,lambda *_:True)
        item=producer.write(1,frame);manifests=producer.append([],item)
        source_store.write(archive.envelope(dict(phase='ready',revision=1,manifests=manifests,pending=None)),None)
        self.source_reference=producer.expand(item)
        self.store=PrivateFeatureState(root/'ios-emote-primary-post-controller-sources.json')
