"""Finite fresh-source admission shared by real parent and pre-unpickle child.

Controller startup is explicitly trusted pinned HOSTBOOTSTRAP. Delegated
subjects use the exact prospective a797 source-byte execution algorithm.
"""
from pathlib import Path
import importlib.abc,importlib.machinery,sys
from closed_import_origins import ClosedOrigins
from metadata_reader import pin
VARIANT_SHA='a7977c6b9399a94df0cd9e6b44729e76ce67cbb121998d787dc5b97f27d74f44'
FORBIDDEN=('pymobiledevice3','appium','selenium','playwright','PySide6','PyQt6','PIL','defusedxml')
class Finder(importlib.abc.MetaPathFinder):
    def __init__(self,plan,source,repo,command=None):
        assert pin(Path(source)/'closed_import_origins.py')['sha256']==VARIANT_SHA
        self.plan=plan;self.loaded={};self.callbacks={};self.source=Path(source)
        self.origins=ClosedOrigins(plan,self.source,Path(repo),pin,command_binding=command)
        self.tops={name.split('.')[0]for name in (*plan['modules'],*plan['namespacePackages'])}
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in FORBIDDEN:raise ImportError('No feature/external/native source in MP3: '+name)
        if name in('__main__','__mp_main__'):raise ImportError('Interpreter aliases are held originals, never a second source execution')
        row=self.plan['modules'].get(name)
        if row is not None:
            spec=self.origins.file_spec(name,dict(row,loader='source'),'project')
            owner=self;delegate=spec.loader
            class After(importlib.abc.Loader):
                def create_module(self,s):return delegate.create_module(s)
                def exec_module(self,module):
                    delegate.exec_module(module)
                    assert vars(module)['__file__']==row['path']
                    owner.loaded[name]=dict(path=row['path'],sha256=pin(row['path'])['sha256'])
                    callback=owner.callbacks.get(name)
                    if callback is not None:callback(module)
            spec.loader=After();return spec
        roots=self.plan['namespacePackages'].get(name)
        if roots is not None:
            self.origins.namespaces(name,roots,roots,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True)
            spec.submodule_search_locations=roots
            return spec
        if name.split('.')[0]in self.tops:raise ImportError('Unplanned project alias: '+name)
        return self.origins.remaining_spec(name,path)
    def install(self):assert self not in sys.meta_path;sys.meta_path.insert(0,self)
    def restore(self):assert sys.meta_path[0]is self;sys.meta_path.remove(self)
