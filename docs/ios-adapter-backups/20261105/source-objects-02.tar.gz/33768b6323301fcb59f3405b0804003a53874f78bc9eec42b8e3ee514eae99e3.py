class _NativeMotionWorkerGuard:
    """Actual local lease/worker source; version selectors never mint this.

    This bounded optional profile supports <=3s original intent. The unchanged
    legacy lease still permits12s. Current facts expire independently at1.5s;
    unknown renewal requests original ordinary Up without cancelling SDK work.
    """
    def __init__(self,resource,source,owner_instance):
        need(type(resource) is LifecycleTouchResourceOwner and resource.version==4
            and type(resource._motion_original) is _NativeMotionReference
            and 0<resource.state['seconds']<=3 and resource._factory is None and resource._lease is None)
        original=resource._motion_original;original.anchor(source,resource,owner_instance)
        owner=original._owner();need(owner is not None and owner.source is source and owner.touch_resources is resource
            and original._selected is not None and owner.touch is None and not source._leases and not source._born)
        self._resource,self._source,self._owner,self._loop=weakref.ref(resource),weakref.ref(source),weakref.ref(owner),weakref.ref(asyncio.get_running_loop())
        self._original=weakref.ref(original);self._lease=self._worker=None;self._opening=None;self._factory=None
        self._failed=False;self._valid_until=0.;self._contact=None;self._monitor=self._expiry=None
        self._stop,self._changed=asyncio.Event(),asyncio.Event();self._current=None
        original._worker_guard=self
        selected=original._selected
        need(selected[3].get('motionGuard') is None)
        selected[3]['motionGuard']=weakref.ref(self);selected[3]['motionLease']=None;selected[3]['motionWorker']=None
    def _scope_without_ref(self):
        resource,source,owner,loop=self._resource(),self._source(),self._owner(),self._loop()
        need(not self._failed and resource is not None and source is not None and owner is not None
            and loop is asyncio.get_running_loop() and source._loop is loop and resource._native_step is self
            and owner.source is source and owner.touch_resources is resource and resource.version==5
            and resource._motion_original is self._original() and resource.state['hostProcessId']==os.getpid())
        resource.file_guard()
        if self._lease is None:
            need(owner.touch is None and not source._leases and not source._born);return
        lease=self._lease();need(type(lease) is TouchLease and lease._session_factory is self._factory
            and lease.store.path.parent==resource.store.path.parent and lease.binding==resource.binding and lease.run==resource.run
            and same(lease.store.read(),lease.previous))
        if self._worker is None:
            need(lease.worker is None and lease.previous is None and not source._born
                and (source._leases==[] and owner.touch is None or source._leases==[lease] and owner.touch is lease));return
        worker=self._worker();need(isinstance(worker,asyncio.Task) and worker is lease.worker and worker.get_loop() is loop
            and not worker.done() and owner.touch is lease and source._leases==[lease] and len(source._born)==1
            and source._born[0]['lease'] is lease and source._born[0]['worker'] is worker
            and source._born[0]['owner'] is not None and not lease.request_release.is_set() and loop.time()<lease._deadline())
        source._born[0]['owner']._status()
        from ios.adapters.lifecycle_touch_transport import intent
        need(self._opening is not None and intent(lease.previous)==intent(self._opening))
    def scope(self):
        try:
            original=self._original();need(original is not None and original._worker_guard is self)
            original._identity()
        except BaseException:
            self.fail();raise
    def fail(self):
        self._failed=True;self._changed.set()
        original=self._original()
        if original is not None:original.revoke()
        resource=self._resource()
        if resource is not None:resource._motion_failed=True
        lease=None if self._lease is None else self._lease()
        if lease is not None:lease.request_release.set()
    def bind_lease(self,lease,factory):
        need(self._lease is None and type(lease) is TouchLease and lease.worker is None and lease.previous is None
            and lease._session_factory is factory)
        self._lease,self._factory=weakref.ref(lease),factory
        self._original()._selected[3]['motionLease']=self._lease
    def born(self,lease,worker):
        source,owner,resource=self._source(),self._owner(),self._resource()
        need(self._lease is not None and self._lease() is lease and self._worker is None and worker is lease.worker
            and isinstance(worker,asyncio.Task) and worker.get_loop() is self._loop() and owner.touch is lease
            and source._leases==[lease] and len(source._born)==1 and source._born[0]['lease'] is lease
            and source._born[0]['worker'] is worker and source._born[0]['owner'] is not None
            and lease.previous is not None and lease.previous['phase']=='opening' and lease.previous['failure'] is None)
        source._born[0]['owner']._status();self._worker=weakref.ref(worker);self._opening=deepcopy(lease.previous)
        self._original()._selected[3]['motionWorker']=self._worker
    def admit(self):
        resource=self._resource()
        with resource.lock.held():self.scope()
    def checkpoint(self):
        resource=self._resource();lease=None if self._lease is None else self._lease()
        with resource.lock.held():
            self.scope();need(lease is not None and asyncio.current_task() is self._worker()
                and self._current is not None and asyncio.get_running_loop().time()<self._valid_until
                and not lease.request_release.is_set())
    def accept(self,receipt):
        need(type(receipt) is _NativeMotionReference and receipt._worker_guard is self and receipt._capture().done())
        self._current=receipt;self._valid_until=receipt._deadline;self._changed.set()
        resource=self._resource();resource.state['nativeRefreshes'].append(receipt.reference)
        need(len(resource.state['nativeRefreshes'])<=7);resource.save()
        if self._expiry is None:
            self._expiry=asyncio.create_task(self._expire_current(),name='original-native-motion-freshness')
            self._source()._native_current_tasks.append(self._expiry)
    async def continuity(self):
        resource,owner=self._resource(),self._owner();lease=self._lease()
        with resource.lock.held():
            self.scope();await owner.fresh_touch_scope(resource.binding);self.scope()
            if lease.previous['phase']=='down-issued' and not lease.down_issued:
                receipt=await owner.native_motion_step(resource,'before-down');self.accept(receipt);self.checkpoint()
    async def movement(self):
        resource,owner=self._resource(),self._owner()
        with resource.lock.held():
            self.scope();need(asyncio.current_task() is self._worker() and self._lease().down_issued)
            receipt=await owner.native_motion_step(resource,'after-down');self.accept(receipt);self.checkpoint()
    def start_monitor(self):
        self.checkpoint();need(self._monitor is None)
        self._monitor=asyncio.create_task(self._refresh_held(),name='original-native-motion-refresh')
        self._source()._native_current_tasks.append(self._monitor)
    async def _expire_current(self):
        try:
            while not self._stop.is_set():
                self._changed.clear();remaining=self._valid_until-asyncio.get_running_loop().time()
                if remaining<=0:self.fail();return
                try:await asyncio.wait_for(self._changed.wait(),remaining)
                except asyncio.TimeoutError:
                    if not self._stop.is_set() and asyncio.get_running_loop().time()>=self._valid_until:self.fail()
        finally:
            # Expiry requests the OLD lease's ordinary Up; it never sends an
            # input itself or cancels an SDK/read Task as completion.
            if not self._stop.is_set():self._lease().request_release.set()
    async def _refresh_held(self):
        try:
            while not self._stop.is_set():
                try:await asyncio.wait_for(self._stop.wait(),1.)
                except asyncio.TimeoutError:pass
                if self._stop.is_set():return
                resource=self._resource()
                with resource.lock.held():
                    self.scope();receipt=await self._owner().native_motion_step(resource,'holding');self.accept(receipt)
        except BaseException:
            self.fail();raise
    async def before_exit(self):
        self._stop.set();self._changed.set()
        for task in (self._monitor,self._expiry):
            if task is not None:
                while not task.done():
                    try:await asyncio.shield(task)
                    except BaseException:pass
                if not task.cancelled():task.exception()
        # Original source-owned SDK capture tasks are NOT cancelled/forgotten;
        # Source.settle awaits their real return before original RSD close.
