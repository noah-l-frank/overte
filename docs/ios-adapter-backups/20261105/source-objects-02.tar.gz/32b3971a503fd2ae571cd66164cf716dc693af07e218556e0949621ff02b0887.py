"""Runner-only retained lifetime for the three selected fixture aliases.

Construct actual stdlib directories; never replace global tempfile functions.
This file is preparation code, AST-only and UNRUN until Root authorizes it.
"""
import os
from pathlib import Path
import stat
import tempfile
from types import SimpleNamespace

_REAL_MKDTEMP=tempfile.mkdtemp
_REAL_TEMPORARY_DIRECTORY=tempfile.TemporaryDirectory


class RetainedTempfiles:
    def __init__(self,scope):
        self.scope=Path(scope)
        assert self.scope.is_absolute() and self.scope.resolve(strict=True)==self.scope
        info=self.scope.stat()
        assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
        self.objects=[];self.roots=set()

    def _directory(self,directory):
        assert directory is None or Path(directory)==self.scope
        return self.scope

    def _record(self,name):
        path=Path(name);info=path.stat()
        assert path.parent==self.scope and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
        self.roots.add(path)

    def mkdtemp(self,suffix=None,prefix=None,dir=None):
        name=_REAL_MKDTEMP(suffix=suffix,prefix=prefix,dir=self._directory(dir))
        self._record(name);return name

    def TemporaryDirectory(self,suffix=None,prefix=None,dir=None,*,ignore_cleanup_errors=False,delete=True):
        actual=_REAL_TEMPORARY_DIRECTORY(suffix=suffix,prefix=prefix,dir=self._directory(dir),
            ignore_cleanup_errors=ignore_cleanup_errors,delete=delete)
        self._record(actual.name)
        # Only this newly created actual object's lifetime changes. Its real
        # __enter__/__exit__/name behavior and the global tempfile API remain.
        actual._finalizer.detach();actual.cleanup=lambda:None
        self.objects.append(actual);return actual

    def namespace(self):
        return SimpleNamespace(mkdtemp=self.mkdtemp,TemporaryDirectory=self.TemporaryDirectory)
