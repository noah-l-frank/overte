"""Raw producer state counters only; no Source/SDK/Node/device is born."""
from copy import deepcopy
import unittest
from lifecycle_moving_native_initial_state import MovingNativeClock, OriginalNativeClockBoundary


class MovingInitialNativeStateModels(unittest.TestCase):
    def query(self, letter='1'):
        return dict(schemaVersion=1, action='feature-native-observe', commandId='ios-'+letter*32)

    def test_first_fresh_native_packet_changes_only_the_model_animation_override(self):
        old, moving = OriginalNativeClockBoundary(), MovingNativeClock()
        self.assertIsNone(moving.sample)
        self.assertEqual(0, moving.sequence)
        q = self.query()
        old.send(q)
        moving.send(q)
        expected = deepcopy(old.sample)
        self.assertIs(True, expected['animation']['overrideActive'])
        expected['animation']['overrideActive'] = False
        self.assertEqual(expected, moving.sample)
        self.assertEqual(old.clock, moving.clock)
        self.assertEqual(old.commands, moving.commands)

    def test_ignored_send_preserves_the_previous_sample_without_retroactive_state_change(self):
        model = MovingNativeClock()
        model.send(self.query())
        original, expected = model.sample, deepcopy(model.sample)
        model.ignored = True
        model.moving_model_override_active = True
        model.send(self.query('2'))
        self.assertIs(original, model.sample)
        self.assertEqual(expected, model.sample)
        self.assertEqual(1, model.sequence)

    def test_later_fresh_packet_does_not_mutate_previously_returned_original_dict(self):
        model = MovingNativeClock()
        model.send(self.query())
        first, expected = model.sample, deepcopy(model.sample)
        model.moving_model_override_active = True
        model.send(self.query('2'))
        self.assertIsNot(first, model.sample)
        self.assertEqual(expected, first)
        self.assertFalse(first['animation']['overrideActive'])
        self.assertTrue(model.sample['animation']['overrideActive'])


if __name__ == '__main__':
    unittest.main()
