"""Four prospective genuine host controls; not selected by Snapshot cases.

No PID/kernel observation is synthesized. A delayed-pin wrapper performs the
real binary pin and then makes its actual child exit/reap. No fake pin return,
ModuleSpec/owner/frame, native/Node/device or pid-reuse claim is introduced.
A separate closed Root utility harness is still required before execution.
"""
from pathlib import Path
import os,subprocess,sys,time,unittest
from unittest.mock import patch
from metadata_reader import pin
import kernel
from owned_node_observations import observe_binary,signal_candidate

CHILD='import sys;sys.stdout.buffer.write(b"R");sys.stdout.buffer.flush();sys.stdin.buffer.read(1)'


class OriginalNodeLifetimeObservationTests(unittest.TestCase):
    def finish(self,child):
        try:
            if child.stdin is not None and not child.stdin.closed:child.stdin.close()
            child.wait(timeout=5)
        finally:
            for stream in(child.stdout,child.stderr):
                if stream is not None:stream.close()
        self.assertIsNotNone(child.returncode);self.assertTrue(kernel.absent(child.pid))
    def child(self):
        path=Path(sys.executable).resolve(strict=True)
        child=subprocess.Popen([str(path),'-S','-B','-c',CHILD],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            bufsize=0,close_fds=True,shell=False,start_new_session=False)
        self.addCleanup(self.finish,child)
        self.assertEqual(child.stdout.read(1),b'R')
        birth=kernel.observe(child.pid,parent=os.getpid(),group=os.getpgrp())
        self.assertEqual('PRESENT_LIVE',birth['kind'])
        return child,dict(birth['after']['identity']),dict(path=str(path),pin=pin(path))
    def zombie(self,child,birth):
        deadline=time.monotonic()+5
        while True:
            row=kernel._sample(child.pid);self.assertIsNotNone(row);self.assertEqual(birth,row['identity'])
            if row['state']=='Z':return
            self.assertLess(time.monotonic(),deadline);time.sleep(.005)
    def test_original_live_lifetime_brackets_actual_binary_hash(self):
        child,birth,binary=self.child();trace={};actual=observe_binary(birth,binary,pin,trace)
        self.assertEqual('PRESENT_LIVE',actual['kind']);self.assertEqual(binary['pin'],trace['actualBinaryPin'])
        self.assertEqual(birth,trace['beforeHash']['after']['identity']);self.assertEqual(birth,trace['afterHash']['after']['identity'])
        self.assertTrue(signal_candidate(birth,binary,pin,{}));self.assertFalse(kernel.absent(child.pid))
    def test_genuine_exit_and_owner_reap_during_real_pin_retains_missing_not_live_authority(self):
        child,birth,binary=self.child();calls=[];trace={}
        def pin_then_original_exit(path):
            value=pin(path);calls.append(str(path));child.stdin.write(b'X');child.wait(timeout=5);return value
        actual=observe_binary(birth,binary,pin_then_original_exit,trace)
        self.assertEqual([binary['path']],calls);self.assertEqual('MISSING',actual['kind'])
        self.assertEqual('PRESENT_LIVE',trace['beforeHash']['kind']);self.assertEqual(binary['pin'],trace['actualBinaryPin'])
        self.assertFalse(signal_candidate(birth,binary,pin,{}));self.assertTrue(kernel.absent(child.pid))
    def test_original_unreaped_terminal_is_present_and_has_no_hash_or_signal_permission(self):
        child,birth,binary=self.child();child.stdin.write(b'X');self.zombie(child,birth);calls=[];trace={}
        def forbidden(path):calls.append(path);raise AssertionError('Terminal observation cannot demand executable hash')
        actual=observe_binary(birth,binary,forbidden,trace)
        self.assertEqual('PRESENT_TERMINAL',actual['kind']);self.assertEqual('Z',actual['after']['state'])
        self.assertEqual([],calls);self.assertFalse(signal_candidate(birth,binary,forbidden,{}));self.assertFalse(kernel.absent(child.pid))
        child.wait(timeout=5);self.assertTrue(kernel.absent(child.pid))
    def test_wrong_expected_original_lifetime_refuses_before_executable_or_pin_without_reuse_claim(self):
        child,birth,binary=self.child();wrong=dict(birth);wrong['startTicks']+=1;lookups=[];pins=[];original=kernel._executable
        def lookup(pid):lookups.append(pid);return original(pid)
        def actual_pin(path):pins.append(path);return pin(path)
        with patch.object(kernel,'_executable',lookup),self.assertRaises(AssertionError):observe_binary(wrong,binary,actual_pin,{})
        self.assertEqual([],lookups);self.assertEqual([],pins);self.assertFalse(kernel.absent(child.pid))
