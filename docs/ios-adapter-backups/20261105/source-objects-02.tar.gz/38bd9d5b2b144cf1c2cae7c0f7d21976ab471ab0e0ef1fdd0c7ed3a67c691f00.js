"use strict";
(function () {
    var companion = Script.require("./companion.js");
    var marker = Entities.addEntity({
        type: "Web", name: "e2e-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-script",
        userData: "{\"kind\":\"create-marker-v1\",\"nonce\":\"73e7ca0d90ae28c2e2db32464a1f9567\",\"runId\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"}",
        position: Vec3.sum(Camera.position,
            Vec3.multiplyQbyV(Camera.orientation, {x: -1.25, y: 0.8, z: -3})),
        rotation: Camera.orientation,
        dimensions: {x: 1.6, y: 0.4, z: 0.01},
        sourceUrl: "http://controlled.invalid/feature-fixture/v1/runs/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/tickets/bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb/graphics-marker.v1.html", visible: true, collisionless: true, dpi: 100
    }, "local");
    Script.scriptEnding.connect(function () {
        if (marker) { Entities.deleteEntity(marker); }
    });
}());
