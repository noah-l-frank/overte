"""One original Moving C10 supervisor; complete prepared/stage originals.
The reviewed supervisor supplies three global inventories. No duplicate global
scan, source/case/deadline change or partial-census qualification is introduced.
"""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,traceback
R=Path.cwd()/'.ios-host-tmp';D=Path(__file__).resolve().parent
H=R/'lifecycle-moving-primary-first1-prepared-root842-headcb793-c10-a13-20261104'
STAGE=H/'first1'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def put(name,value):
 path=D/name
 with path.open('x')as out:json.dump(value,out,sort_keys=True,separators=(',',':'));out.write('\n')
 path.chmod(0o600)
def census(root):
    assert root.resolve(strict=True) == root and root.is_dir() and not root.is_symlink()
    result = {}
    for path in (root, *sorted(root.rglob('*'))):
        before = path.lstat()
        value = {key: getattr(before, key) for key in FIELDS}
        if stat.S_ISREG(before.st_mode):
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            try:
                assert all(getattr(os.fstat(descriptor), key) == value[key] for key in FIELDS)
                digest = hashlib.sha256()
                while chunk := os.read(descriptor, 1024 * 1024):
                    digest.update(chunk)
                assert all(getattr(os.fstat(descriptor), key) == value[key] for key in FIELDS)
                value['sha256'] = digest.hexdigest()
            finally:
                os.close(descriptor)
        elif stat.S_ISLNK(before.st_mode):
            value['target'] = os.readlink(path)
        else:
            assert stat.S_ISDIR(before.st_mode)
        assert all(getattr(path.lstat(), key) == value[key] for key in FIELDS)
        result[str(path.relative_to(root))] = value
    return result
assert sys.flags.no_site and sys.dont_write_bytecode
assert sha(H/'freeze.json')=='7978f84c4ea8cb551334e3d4c4e74954ea1c04ef7526b91fbe52fb923923e6cf'
for name,row in load(H/'freeze.json')['files'].items():assert sha(H/name)==(row if type(row)is str else row['sha256'])
put('attempted-rooms.json',dict(status='DECLARED_BEFORE_ORIGINAL_SUPERVISOR_NO_ABSENCE_CLAIM',prepared=str(H),stage=str(STAGE),prospectiveRetained=str(STAGE/'retained'),prospectiveBindings=str(STAGE/'bindings'),collector=str(D),sourceReview='2ced8b01a4e3dc049c001e6d54f693e87a90aef75255f4870e85da9b62450b76',generatedReview='440cc4c1daee36f7cc59720fddaf7cefc8162540499ad3cc35d5138e0be6e93b'))
try:
 with(D/'supervisor-stdout.log').open('xb')as stdout,(D/'supervisor-stderr.log').open('xb')as stderr:
  result=subprocess.run([sys.executable,'-S','-B',str(H/'root-supervise.py'),str(STAGE)],cwd=Path.cwd(),env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
 put('supervisor-return.json',dict(returnCode=result.returncode))
 report=load(STAGE/'run/report.json');binding=load(STAGE/'run/process-binding.json')['task']
 assert report['remainingOwnedProcesses']==[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:raw=(p/'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  values=raw[raw.rfind(')')+2:].split();pid=int(raw[:raw.index('(')].strip())
  assert not(pid==binding['pid']and int(values[19])==binding['startTicks']),'Original timeout process still present'
  assert int(values[2])!=binding['pid']and int(values[3])!=binding['pid'],'Original task group/session remains'
 before=load(STAGE/'run/global-originals-before.json');first=load(STAGE/'run/global-originals-first.json');second=load(STAGE/'run/global-originals-second.json')
 expected=load(R/'root-ios-current842-after-snapshot-public39-qualified-context-20261104/global-original-corpus-baseline.json')
 assert len(before)==842 and before==first==second==expected
 assert report['allPinsEqual']and report['retainedOriginalsUnchanged']and report['globalOriginalsUnchanged']and report['globalOriginalRoots']==842
 roots=[H,STAGE,STAGE/'retained',STAGE/'bindings'];assert all(root.is_dir()for root in roots)
 whole_first={str(root):census(root)for root in roots};whole_second={str(root):census(root)for root in roots};assert whole_first==whole_second
 put('whole-output-first.json',whole_first);put('whole-output-second.json',whole_second)
 put('closed.json',dict(status='ORIGINAL_MOVING_FIRST1_SUPERVISOR_CLOSED',supervisorReturnCode=result.returncode,originalReport=report,all842OldOriginalBodiesUnchanged=True,originalSupervisorOldCorpusReads=3,additionalGlobalScans=0,wholePreparedAndStageOutputsTwiceEqual=True,fullPreparedRoot=str(H),fullOutputExclusions=[],allOwnedProcessesAbsent=True,newOriginalRoots=list(map(str,roots))+[str(D)],nativeQualified=False,wholeQualified=False))
 put('freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in sorted(D.iterdir())if p.is_file()}))
 print(json.dumps(dict(returnCode=result.returncode,freeze=sha(D/'freeze.json'))),flush=True)
except BaseException:
 try:put('unqualified-partial-close.json',dict(status='NO_QUIET_CLOSE_INFERRED',traceback=traceback.format_exc(),attemptedOriginalRooms=[str(H),str(STAGE),str(STAGE/'retained'),str(STAGE/'bindings'),str(D)]))
 except BaseException:pass
 raise
