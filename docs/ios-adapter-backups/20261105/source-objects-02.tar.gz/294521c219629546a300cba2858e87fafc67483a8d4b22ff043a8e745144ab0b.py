"""Root-only metadata assembly. Importing this file launches no target."""
from pathlib import Path
import argparse,contextlib,hashlib,http.server,io,json,os,shutil,signal,socket,socketserver,ssl,stat,subprocess,sys,tempfile,threading,unittest
from prefix_common import REPO,load,sha,pin,head,FIELDS
from root_context import root_context,later_context
CODE=Path(__file__).resolve().parent
OLD=REPO/'.ios-host-tmp/avatar-completed-login-resume3-changed-normal-root-preparation-20261103'
SOURCE1=REPO/'.ios-host-tmp/avatar-normal-primary-budget-refusal-prefix1-source-controller-code-private-20261104'
SOURCE2=REPO/'.ios-host-tmp/avatar-api-budget-refusal-original-source2-real-port-stack-private-20261104'
OWN22=REPO/'.ios-host-tmp/root-avatar-world-shared-budget-own22-qualified-results-20261104'
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript','domain-server/resources')
def frozen(folder,filename,digest):
    path=folder/filename;assert sha(path)==digest;value=load(path)
    rows=value['files'];items=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
    paths={path}
    for name,row in items:
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        file=folder/name;assert sha(file)==(row['sha256']if type(row)is dict else row);paths.add(file)
    return paths
def main():
    p=argparse.ArgumentParser();p.add_argument('--source-freeze',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--destination',required=True)
    p.add_argument('--later-terminal-results',required=True);p.add_argument('--later-sha',required=True);p.add_argument('--later-bundle-freeze',required=True);a=p.parse_args()
    assert Path.cwd()==REPO and sys.dont_write_bytecode and len(a.expected_head)==40 and head()==a.expected_head
    physical=frozen(CODE,'source-freeze.json',a.source_freeze)
    for folder,filename,digest in((OLD,'freeze.json','224630049852f0fdb8cacd7083380a8b3e2b383135eccc155767400b9835a05a'),
            (SOURCE1,'source-freeze.json','adb89825fba3daa42de5a5281ff666c5603aa1d6a497763c93c4bb06f106ac9c'),
            (SOURCE2,'freeze.json','3c14384dd0eb26ce2c2696c7b6d72d3baf8f0a25bae328b3f554f768930de348'),
            (OWN22,'freeze.json','47ca3ecfe8bf4622c60f4414d1fd9ef02e0fd7ed1e3c1488c301e77e40792665')):
        physical.update(frozen(folder,filename,digest))
    own=load(OWN22/'results.json');assert own['terminal']['status']=='PASS'and own['terminal']['ownProcessesAbsent']
    assert own['actualPassedCases']==22 and own['originalCleanupFinallyReturned']is True and own['all27PortsRestored']is True
    assert own['sharedHelperSource2Freeze']=='3c14384dd0eb26ce2c2696c7b6d72d3baf8f0a25bae328b3f554f768930de348'
    roots,expected,proofs,base,wrapper=root_context()
    roots,expected,extra,later=later_context(Path(a.later_terminal_results),a.later_sha,a.later_bundle_freeze,roots,expected)
    for row in proofs+extra:
        # Root context routines already verify every exact proof/member hash.
        # Their actual path conventions are retained as separate source proof.
        if isinstance(row,dict)and 'path'in row:
            path=Path(row['path']);physical.add(path if path.is_absolute()else REPO/path)
    # Pin every retained proof packet member, not merely its manifest. These
    # are named immutable source/status reads; no old-root census occurs here.
    for row in proofs+extra:
        if isinstance(row,dict)and 'path'in row:
            path=Path(row['path']);path=path if path.is_absolute()else REPO/path
            if path.name=='freeze.json':
                body=load(path);members=body['files'];entries=members.items()if type(members)is dict else((x['path'],x)for x in members)
                for name,member in entries:
                    assert not Path(name).is_absolute()and '..'not in Path(name).parts
                    child=path.parent/name;assert sha(child)==(member['sha256']if type(member)is dict else member);physical.add(child)
    assert set(expected)==roots
    for root,body in expected.items():
        assert type(body)is dict and '.'in body and Path(root).is_absolute()
        for name,row in body.items():
            assert not Path(name).is_absolute()and '..'not in Path(name).parts and set(FIELDS)<=set(row)
            kind=row['st_mode'];assert set(row)==set(FIELDS)|({'sha256'}if stat.S_ISREG(kind)else{'target'}if stat.S_ISLNK(kind)else set())
    public=set()
    for root in ROOTS:
        for path in(REPO/root).rglob('*'):
            assert not path.is_symlink()
            if path.is_file():public.add(path)
    physical.update(public);physical.update((REPO/'CMakeLists.txt',REPO/'interface/CMakeLists.txt'))
    modules={};namespaces={}
    for root in(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests'):
        for path in sorted(root.rglob('*.py')):
            parts=path.relative_to(root).with_suffix('').parts;name='.'.join(parts[:-1]if parts[-1]=='__init__'else parts)
            if name:modules.setdefault(name,dict(path=str(path),package=path.name=='__init__.py'))
            for i in range(1,len(parts)):namespaces.setdefault('.'.join(parts[:i]),str(root.joinpath(*parts[:i])))
    original_map=OLD/'source-root-final-map.json';physical.add(original_map)
    for name,row in load(original_map)['modules'].items():assert modules[name]['path']==str(REPO/row['path']),'Original module physical path disappeared: '+name
    overlays={
        'adapters.api_budget_refusal_original':SOURCE2/'candidate/tests/device/adapters/api_budget_refusal_original.py',
        'ios.adapters.avatar_api_entry':SOURCE2/'candidate/tests/device/ios/adapters/avatar_api_entry.py',
        'ios.self_tests.test_ios_avatar_normal_primary_budget_refusal_prefix':SOURCE1/'test_ios_avatar_normal_primary_budget_refusal_prefix.py'}
    for name,path in overlays.items():modules[name]=dict(path=str(path),package=False);physical.add(path)
    third=load(CODE/'third-party-source-declarations.json')
    for name,row in third.items():assert sha(row['path'])==row['sha256'];physical.add(Path(row['path']))
    names=('run-prefix.py','supervise-prefix.py','prefix_common.py','avatar_ports.py','entry_observer.py','assets_fixture_ports.py','owned_write_boundary.py','monitoring_observer.py')
    dest=Path(a.destination);assert dest.is_absolute()and dest.parent==REPO/'.ios-host-tmp'and dest.parent.resolve(strict=True)==dest.parent and not dest.exists()
    # All source/proof checks precede any new controller/output birth.
    binaries={}
    for name in('node','openssl','timeout'):
        selected=Path(shutil.which(name));resolved=selected.resolve(strict=True);v=pin(resolved)
        binaries[name]=dict(path=str(selected),realPath=str(resolved),device=v['st_dev'],inode=v['st_ino'],sha256=v['sha256']);physical.add(resolved)
    assert Path(binaries['node']['path']).parent==Path(binaries['openssl']['path']).parent
    for module in(contextlib,http.client,http.server,io,signal,socket,socketserver,ssl,subprocess,tempfile,threading,unittest,unittest.case,unittest.runner,unittest.result):
        filename=getattr(module,'__file__',None)
        if filename:physical.add(Path(filename).resolve(strict=True))
    physical.add(Path(sys.executable).resolve(strict=True))
    before={str(path):pin(path)for path in sorted(physical)};dest.mkdir(mode=0o700)
    for name in names:
        target=dest/name
        with target.open('xb')as stream:stream.write((CODE/name).read_bytes())
        target.chmod(0o600);before[str(target)]=pin(target)
    with(dest/'normal_prefix_receipt.py').open('xb')as stream:stream.write((SOURCE1/'normal_prefix_receipt.py').read_bytes())
    (dest/'normal_prefix_receipt.py').chmod(0o600);before[str(dest/'normal_prefix_receipt.py')]=pin(dest/'normal_prefix_receipt.py')
    for name in('normal_prefix_receipt','owned_write_boundary','assets_fixture_ports','avatar_ports','entry_observer','monitoring_observer','prefix_common'):
        modules[name]=dict(path=str(dest/(name+'.py')),package=False)
    namespaces={name:path for name,path in namespaces.items()if name not in modules}
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(dest/'child/temporary'),PATH=str(Path(binaries['node']['path']).parent),PYTHONPATH='')
    assert not any(name.startswith('NODE_')for name in env)
    plan=dict(status='PRIVATE_UNRUN_AVATAR_PREFIX_REQUIRES_ROOT_REVIEW',expectedCurrentHead=a.expected_head,qualifiedOwn22HistoricalHead=own['publicHead'],historicalAvatarSourceHead=None,historicalAvatarAuthority=dict(freezeSha256='224630049852f0fdb8cacd7083380a8b3e2b383135eccc155767400b9835a05a',mapSha256=sha(original_map)),source1HistoricalHead=load(SOURCE1/'prospective-selection.json')['currentPublicHead'],sourcePins=before,modules=modules,namespaces=namespaces,thirdPartyModules=third,
        closedTopLevels=sorted({name.split('.')[0]for name in(*modules,*third,*namespaces)}),executables=binaries,environmentSha256=hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
        caseIds=load(SOURCE1/'prospective-selection.json')['suite']['caseIds'],fixtureAliasModules=load(SOURCE1/'prospective-selection.json')['suite']['fixtureAliasModules'],
        initialTimeoutSeconds=300,killAfterSeconds=5,expectedRetainedRoots=6,expectedNodeProcesses=3,expectedTLSProcesses=1,
        apiBudgetSeconds=25,originalFinishSeconds=30,globalOriginals=expected,expectedGlobalRootCount=len(roots),rootProofs=proofs+extra,wholeQualified=False,nativeQualified=False,declaredArtifactModelOnly=True)
    with(dest/'approved-inputs.json').open('x')as stream:json.dump(plan,stream,sort_keys=True,indent=2);stream.write('\n')
    (dest/'approved-inputs.json').chmod(0o600)
    assert before=={path:pin(path)for path in before}and head()==a.expected_head
    print(json.dumps(dict(status='METADATA_ONLY_UNRUN',input=str(dest/'approved-inputs.json'),inputSha256=sha(dest/'approved-inputs.json'),roots=len(roots),modules=len(modules))))
if __name__=='__main__':main()
