"""One genuine unchanged Assets checkpoint Source2 body; original300+5 scope."""
from pathlib import Path
import builtins,hashlib,importlib,importlib.abc,importlib.machinery,io,json,os,signal,stat,subprocess,sys,tempfile,threading,time,traceback,types,unittest
from metadata_reader import pin
from host_common import head
from source_execution_readiness import qualification
from backend_utility_readiness import boundary_qualification
from project_namespace_admission import project_namespace_admission
from closed_import_origins import ClosedOrigins
from fixture_common import save,proc,processes,fds,census
from owned_write_boundary import OwnedWrites
from scoped_ports import FixturePorts
from typed_observer import NodeConstructorObserver
from monitoring_observer import OriginalProcessObserver
from assets_resources import AssetsResources
from class_cleanup_custody import ClassCleanupCustody
from definition_custody import DefinitionCustody
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert sys.flags.no_site==1 and sys.dont_write_bytecode and len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and pin(INPUT)['sha256']==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['status']=='PRIVATE_ASSETS_SOURCE2_ONE_OF_TEN_UNRUN'
assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)and head()==plan['actualPublicHead']
recipe=json.loads((HERE/'fixed-ten-groups.json').read_text())['groups'][plan['groupName']]
assert recipe==plan['resourceRecipe']and plan['cases']==recipe['caseIds']and len(plan['cases'])==1
assert plan['wallSeconds']==300 and plan['killGraceSeconds']==5 and plan['phaseAdmission']is plan['remaining6Admission']is None
assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
current,current_pins=qualification(pin);assert current==plan['qualifiedSourceExecution']
assert all(plan['sourceAndBinaryPins'].get(p)==row for p,row in current_pins.items())
backend,backend_pins=boundary_qualification(REPO,pin,HERE)
assert backend==plan['backendBoundaryQualification']and all(plan['sourceAndBinaryPins'].get(p)==row for p,row in backend_pins.items())
assert project_namespace_admission(plan['declaredProjectAliases'],[str(REPO/'tests/device')])==(plan['modules'],plan['namespaces'],plan['projectAliasAdmission'])
TOYS=HERE/'temporary';assert TOYS.is_dir()and not any(TOYS.iterdir())and Path(tempfile.gettempdir())==TOYS
started=time.monotonic();own=proc(os.getpid());assert own is not None
launch=json.loads((HERE.with_name(HERE.name+'-outer')/'supervisor-launch-binding.json').read_text());parent=proc(launch['task']['pid'])
assert launch['cases']==plan['cases']and launch['wallSeconds']==300 and launch['killGraceSeconds']==5 and launch['supervisorSource']==str(HERE/'supervise-one.py')
assert parent is not None and parent['pid']==own['parentPid']and parent['startTicks']==launch['task']['startTicks']
assert own['session']==own['processGroup']==own['pid'],'Exact original fixed-cap supervisor session required'
original_meta=tuple(sys.meta_path);original_path=tuple(sys.path)
original_cleanup=unittest.TestCase.doCleanups;original_td=tempfile.TemporaryDirectory
original_ports={n:getattr(os,n)for n in('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')if hasattr(os,n)}
original_io=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
send_signal_function=subprocess.Popen.send_signal;send_signal_code=send_signal_function.__code__;send_signal_globals=send_signal_function.__globals__
monitor=sys.monitoring;monitor_ports=tuple((n,getattr(monitor,n))for n in('get_tool','get_events','get_local_events','register_callback','use_tool_id','free_tool_id','set_events','set_local_events'))
monitor_before=tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6))
loaded={};retained=[];retained_objects=[];cleanup_calls=[];case_rows=[];binds=[];allowed_ports=set();refusals=[]
resources=AssetsResources(TOYS,recipe);origins=ClosedOrigins(plan['originPlan'],HERE,REPO,pin)
origin_before=origins.snapshot('assets-owned-before-project-imports')
bootstrap={'metadata_reader','host_common','source_execution_readiness','project_namespace_admission','closed_import_origins','fixture_common','owned_write_boundary','scoped_ports','typed_observer','monitoring_observer','assets_resources','class_cleanup_custody','definition_custody','backend_utility_readiness','c10d_admission','backend_dirfd_ports'}
for name in plan['modules']:
    if name in bootstrap:
        assert Path(vars(sys.modules[name])['__file__'])==Path(plan['modules'][name]['path'])
    else:assert name not in sys.modules,('Project imported before closed loader',name)
third=plan['thirdPartyModules'];tops={n.split('.')[0]for n in(*plan['modules'],*plan['namespaces'],*third)}
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright','PySide6','PyQt6')
def forbidden_path(path):
    return isinstance(path,(str,bytes,os.PathLike))and any(any(part==bad or part.startswith(bad+'_')for bad in forbidden)for part in Path(os.fsdecode(path)).parts)
ports=None;node_observer=None;observer=None;class_cleanup=None;definition=None
class Loader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name,self.delegate=name,delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module);path=Path(vars(module)['__file__'])
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)];loaded[self.name]=str(path);resources.loaded(self.name,module)
        if self.name in('adapters.asset_backend_files','test_asset_backend_files'):ports.bind_backend(module,path,plan['sourceAndBinaryPins'][str(path)],pin)
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in forbidden:raise ImportError('Actual installed SDK/native package refused')
        if name in plan['modules']:
            spec=origins.file_spec(name,dict(plan['modules'][name],loader='source'),'project');spec.loader=Loader(name,spec.loader);return spec
        if name in plan['namespaces']:
            rows=plan['namespaces'][name];origins.namespaces(name,rows,rows,'project');spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=rows;return spec
        if name in third:return origins.remaining_spec(name,path)
        if name.split('.')[0]in tops:raise ImportError('Undeclared source alias '+name)
        return origins.remaining_spec(name,path)
metadata_pin_function=pin;metadata_pin_code=pin.__code__;metadata_pin_globals=pin.__globals__
readonly_function=OwnedWrites.os_open;readonly_code=readonly_function.__code__;readonly_globals=readonly_function.__globals__
reader_function=ClosedOrigins.execute_python_source;reader_code=reader_function.__code__;reader_globals=reader_function.__globals__
own_definition=REPO/'tests/device/ios/adapters/appium_adapter.py';owned_metadata_paths=set(plan['ownForbiddenMetadataReadPaths'])
def exact_own_source_read(path):
    if type(path)not in(str,bytes)and not isinstance(path,os.PathLike):return False
    actual=Path(os.fsdecode(path));frame=sys._getframe(1)
    if frame.f_code is not audit_code or frame.f_globals is not audit_globals or audit_function is not audit:return False
    caller=frame.f_back
    if caller is None:return False
    pin_caller=caller
    if caller.f_code is readonly_code and caller.f_globals is readonly_globals:
        if ports is None or not ports.installed:return False
        ports.check();helper=caller.f_locals.get('self');port=ports.ports['open'];middle=caller.f_back
        if(OwnedWrites.os_open is not readonly_function or readonly_function.__code__ is not readonly_code
          or not any(helper is row for row in ports.helpers.values())or caller.f_locals.get('path')!=actual
          or caller.f_locals.get('dir_fd')is not None or middle is None or middle.f_code is not port.__code__
          or middle.f_globals is not port.__globals__ or middle.f_locals.get('self')is not ports or middle.f_locals.get('_name')!='open'
          or middle.f_locals.get('args')!=(actual,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)or middle.f_locals.get('kwargs')!={}):return False
        pin_caller=middle.f_back
    if str(actual)in owned_metadata_paths and actual.is_absolute()and actual.resolve(strict=True)==actual:
        if(pin_caller is not None and pin_caller.f_code is metadata_pin_code and pin_caller.f_globals is metadata_pin_globals and pin is metadata_pin_function
          and pin.__code__ is metadata_pin_code and pin_caller.f_locals.get('path')==actual):return True
    if actual==own_definition and caller.f_code is reader_code and caller.f_globals is reader_globals:
        delegate=caller.f_locals.get('delegate')
        return(ClosedOrigins.execute_python_source is reader_function and reader_function.__code__ is reader_code and caller.f_locals.get('self')is origins
          and getattr(delegate,'guard',None)is origins and getattr(delegate,'name',None)=='ios.adapters.appium_adapter'and getattr(delegate,'kind',None)=='project'
          and Path(delegate.row['path'])==own_definition and origins.plan['physicalPins'].get(str(actual))==plan['sourceAndBinaryPins'][str(actual)])
    return False
def audit(event,args):
    relevant=event in('open','os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if relevant and ports is not None:ports.audit(event,args,sys._getframe(1))
    if event=='import':
        name=args[0]
        if name.split('.')[0]in forbidden:refusals.append(name);raise RuntimeError('SDK import refused')
        if name.split('.')[0]in tops and name not in plan['modules']and name not in plan['namespaces']and name not in third:raise RuntimeError('Undeclared project import')
    elif event=='open'and forbidden_path(args[0]):
        assert args[1]is None and args[2]==os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC and exact_own_source_read(args[0]),'No installed SDK source authority'
    elif event=='subprocess.Popen':
        executable,argv,cwd,env=args;assert os.fsdecode(executable)=='node'and tuple(argv)==tuple(plan['expectedPickerNodeArgv'])and cwd is None and env is None
        ports.node_environment_guard()
    elif event=='socket.bind':assert args[1]==('127.0.0.1',0)and len(binds)<2;binds.append(args[0])
    elif event=='socket.connect':assert type(args[1])is tuple and args[1][0]=='127.0.0.1'and args[1][1]in allowed_ports
    elif event=='socket.getaddrinfo':assert args[0]in('127.0.0.1','localhost')and args[1]in allowed_ports
    elif event in('socket.gethostbyname','socket.gethostbyaddr'):assert args[0]in('127.0.0.1','localhost')
    elif event=='os.kill':
        caller=sys._getframe(1);owner=caller.f_locals.get('self')
        assert caller.f_code is send_signal_code and caller.f_globals is send_signal_globals and subprocess.Popen.send_signal is send_signal_function and send_signal_function.__code__ is send_signal_code
        assert observer is not None and any(row['process']is owner for row in observer.processes)and any(owner is item for item in ports.node_entries)
        row=next(row for row in observer.processes if row['process']is owner);actual=proc(row['pid']);born=row['birth']
        assert args[0]==row['pid']==owner.pid and args[1]in(signal.SIGTERM,signal.SIGKILL)and born is not None and actual is not None
        assert all(actual[name]==born[name]for name in('pid','parentPid','processGroup','session','startTicks'))
    elif event=='os.killpg':raise RuntimeError('No process-group signal authority')
    elif event=='socket.sendto':raise RuntimeError('No UDP authority')
    elif event in('os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','ctypes.dlopen')or event.startswith('os.spawn'):raise RuntimeError('No native/SDK child authority')
audit_function=audit;audit_code=audit.__code__;audit_globals=audit.__globals__
finder=Finder();sys.meta_path.insert(0,finder);sys.path[:]=[p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
sys.addaudithook(audit)
ports=FixturePorts(TOYS,HERE,save,globals(),sys._getframe(),plan['expectedPickerNodeArgv'],plan['nodePin'],hashlib.sha256(json.dumps(dict(os.environ),sort_keys=True,separators=(',',':')).encode()).hexdigest())
retain_owned_root=None
class RetainedTemporaryDirectory(original_td):
    def __init__(self,*args,**kwargs):
        role=resources.td_role(sys._getframe(1),args,kwargs);super().__init__(dir=TOYS)
        root=Path(self.name);assert root.parent==TOYS;retain_owned_root(self,expected_root=root);resources.remember(role,root);retained_objects.append(self);retained.append(str(root))
def observe_cleanup(case):
    previous=case._outcome;result=None if previous is None else previous.result
    before=0 if result is None else len(result.errors);returned=None;raised=None
    try:returned=original_cleanup(case);return returned
    except BaseException as error:raised=type(error).__name__;raise
    finally:cleanup_calls.append(dict(case=type(case).__module__+'.'+type(case).__qualname__,originalReturned=returned,originalRaised=raised,remaining=len(case._cleanups),callbackErrors=[]if result is None else[result.errors[i][1]for i in range(before,len(result.errors))]))
unittest.TestCase.doCleanups=observe_cleanup;tempfile.TemporaryDirectory=RetainedTemporaryDirectory
class_tables=[];selected=[];result=None;fatal=None;secondary=[];class_receipt=None;class_restore=None;port_restore=None
fd_before=fds(os.getpid());threads_before=tuple(threading.enumerate());children_before=Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
def source_check():
    assert tuple(sys.meta_path)==(finder,*original_meta)
    assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']and pin(INPUT)['sha256']==sys.argv[2]and head()==plan['actualPublicHead']
def methods_ok():return definition is not None and class_tables is definition.class_tables and(class_cleanup is None or class_cleanup.tables is class_tables)and definition.check()
class Result(unittest.TextTestResult):
    def startTest(self,test):
        class_cleanup.bind_result(self,test);assert methods_ok();origins.snapshot('before-'+test.id());super().startTest(test)
    def stopTest(self,test):
        origins.snapshot('after-'+test.id());row=dict(id=test.id(),remaining=len(test._cleanups),methodsUnchanged=methods_ok(),fdsEqual=fds(os.getpid())==fd_before,threadsEqual=tuple(threading.enumerate())==threads_before)
        case_rows.append(row);save(HERE/'case-stop.json',row);super().stopTest(test)
def record_secondary(label):secondary.append(dict(phase=label,traceback=traceback.format_exc()))
def class_save(name,body):save(HERE/name,body)
def terminate(*_args):raise KeyboardInterrupt('Original Assets300-second fixed boundary')
ports.bind_callbacks((observe_cleanup,Result.startTest,Result.stopTest,source_check,record_secondary,class_save,terminate))
original_term=signal.getsignal(signal.SIGTERM);signal.signal(signal.SIGTERM,terminate)
try:
    ports.install()
    observer=OriginalProcessObserver(proc);observer.start()
    node_observer=NodeConstructorObserver(ports);node_observer.start()
    from ios.self_tests.retained_host_roots import retain_owned_root
    for name in plan['subjectOriginModules']:importlib.import_module(name)
    resources.start(ports,binds,allowed_ports,node_observer,plan['nodePin'])
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for item in value:yield from flatten(item)
        else:yield value
    selected=list(flatten(suite));assert not loader.errors and[case.id()for case in selected]==plan['cases']and len(selected)==1
    save(HERE/'actual-selection.json',dict(ids=[c.id()for c in selected],loaderErrors=loader.errors))
    definition=DefinitionCustody(plan['definitionInventory'],plan,pin);class_tables=definition.class_tables
    class_cleanup=ClassCleanupCustody(class_tables,suite,selected,Result,Result.startTest,class_save)
    class_cleanup.install();assert class_cleanup.tables is class_tables is definition.class_tables
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    # Every actual restoration is attempted separately; no resource-count assert
    # may suppress the original fatal, the next restoration or the final report.
    for case in selected:
        if case._cleanups:
            old=case._outcome;drain=unittest.TestResult()
            try:case._outcome=unittest.case._Outcome(drain);observe_cleanup(case)
            except BaseException:record_secondary('remaining-real-cleanups')
            finally:case._outcome=old
    for label,operation in(('class-summary',lambda:class_cleanup.summary()if class_cleanup else None),('class-restore',lambda:class_cleanup.restore()if class_cleanup else None),
      ('resource-tool-stop',resources.stop),('node-tool-stop',lambda:node_observer.stop()if node_observer is not None else None),('process-tool-stop',lambda:observer.stop()if observer is not None else None),('actual-port-restore',lambda:ports.restore())):
        try:
            value=operation()
            if label=='class-summary':class_receipt=value
            elif label=='class-restore':class_restore=value
            elif label=='actual-port-restore':port_restore=value
        except BaseException:record_secondary(label)
    unittest.TestCase.doCleanups=original_cleanup;tempfile.TemporaryDirectory=original_td;signal.signal(signal.SIGTERM,original_term)
    resource_receipt=None;origin_after=None;definition_ok=False;source_ok=False
    for label,operation in(('resource-recipe',resources.report),('source-guard',source_check),('definition-guard',methods_ok),('origin-after',lambda:origins.snapshot('after-genuine-cleanups'))):
        try:
            value=operation()
            if label=='resource-recipe':resource_receipt=value
            elif label=='source-guard':source_ok=True
            elif label=='definition-guard':definition_ok=value is True
            else:origin_after=value
        except BaseException:record_secondary(label)
    process_rows=[]
    for row in(()if observer is None else observer.processes):
        child=row['process'];process_rows.append(dict(pid=row['pid'],birth=row['birth'],current=proc(row['pid']),commandKind=row['commandKind'],constructorOutcome=row['constructorOutcome'],returnCode=child.poll(),streams={n:None if getattr(child,n)is None else getattr(child,n).closed for n in('stdin','stdout','stderr')}))
    absent=all(row['current']is None for row in process_rows)
    kernel_now=Path('/proc/self/task/'+str(os.getpid())+'/children').read_text();quiet=absent and kernel_now==children_before
    first=second=None
    if quiet:
        try:first=census(TOYS);second=census(TOYS)
        except BaseException:record_secondary('quiet-toy-census')
    tools_ok=all(getattr(monitor,n)is v for n,v in monitor_ports)and monitor_before==tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6))
    original_ports_ok=all(getattr(os,n)is v for n,v in original_ports.items())and original_io==(io.open,builtins.open)and original_dup==(os.dup,os.dup2)
    complete_nodes=len(process_rows)==1 and all(row['birth']is not None and row['commandKind']=='node'and row['constructorOutcome']=='return'and row['returnCode']is not None and all(v is None or v for v in row['streams'].values())for row in process_rows)
    complete_nodes=complete_nodes and node_observer is not None and node_observer.entries==1 and len(ports.node_entries)==len(ports.pipe_opens)==1 and all(any(owner is source['process']for source in observer.processes)for owner,_fd,_dev,_ino in ports.pipe_opens)
    cleanup_ok=len(cleanup_calls)==7 and all(row['originalReturned']is True and row['originalRaised']is None and row['remaining']==0 and not row['callbackErrors']for row in cleanup_calls)
    passed=fatal is None and not secondary and result is not None and result.testsRun==1 and result.wasSuccessful()and not result.skipped and len(case_rows)==1
    passed=passed and cleanup_ok and class_receipt is not None and class_receipt['allActualOriginalCallsAccepted']and class_restore is not None and resource_receipt is not None
    passed=passed and quiet and complete_nodes and tools_ok and original_ports_ok and fds(os.getpid())==fd_before and tuple(threading.enumerate())==threads_before and source_ok and definition_ok and origin_after is not None and first==second and first is not None
    report=dict(status='PASS'if passed else'FAIL_OR_REFUSED',testsRun=None if result is None else result.testsRun,fatal=fatal,secondary=secondary,cases=case_rows,
      actualResources=resource_receipt,retainedTemporaryDirectories=list(retained),actualTDBirths=list(resources.rows),originalCleanupCalls=cleanup_calls,classCleanup=class_receipt,classRestoration=class_restore,originalWritePorts=port_restore,
      originalPortsRestored=original_ports_ok,actualCIOUnchanged=original_io==(io.open,builtins.open),actualOSPortCount=len(original_ports),monitorSlotsRestored=tools_ok,actualOriginalNodes=process_rows,completeOriginalNodeLineage=complete_nodes,allObservedPIDsAbsent=absent,kernelChildrenUnchanged=kernel_now==children_before,
      fdsUnchanged=fds(os.getpid())==fd_before,threadsUnchanged=tuple(threading.enumerate())==threads_before,pinsAndInputUnchanged=source_ok,definitionsUnchanged=definition_ok,
      allActualLoadedOriginsAccounted=origin_after is not None,loaded=loaded,originBefore=origin_before,originAfter=origin_after,quietCensusesPerformed=quiet,twoToyCensusesEqual=first is not None and first==second,
      phaseAdmission=None,remaining6Admission=None,normalAction2Qualified=False,nativeQualified=False,wholeQualified=False,seconds=time.monotonic()-started)
    save(HERE/'actual-report.json',report)
    if first is not None:save(HERE/'toy-first.json',first);save(HERE/'toy-second.json',second)
    sys.meta_path[:]=original_meta;sys.path[:]=original_path
raise SystemExit(0 if passed else 1)
