/* Root-only prospective bridge: actual original child/keeper/registry owners.
 * Native/OS/Appium session state are declared MODELS. This server never emits
 * a typed parent End, Current7, Audio or readmission acceptance verdict. Those
 * must come from the actual Python consumers over retained original bytes.
 */
import assert from 'node:assert/strict';
import {spawn,ChildProcess} from 'node:child_process';
import {createHash,randomUUID} from 'node:crypto';
import {readFile,writeFile,mkdtemp,chmod} from 'node:fs/promises';
import {createServer} from 'node:http';
import {isDeepStrictEqual} from 'node:util';
import {pathToFileURL} from 'node:url';
import path from 'node:path';

const config=JSON.parse(await readFile(process.argv[2],'utf8'));
const hash=raw=>createHash('sha256').update(raw).digest('hex');
for(const key of ['keeper','registry','child','wrapper','provider','producer'])
  assert.equal(hash(await readFile(config[key].path)),config[key].sha256,'Pinned source changed: '+key);
const {OriginalUserspaceKeeper}=await import(pathToFileURL(config.keeper.path));
const registryRaw=await readFile(config.registry.path,'utf8');
const begin=registryRaw.indexOf('function originalCanonical(value) {');
const finish=registryRaw.indexOf('\nasync function createTunnelForDevice(device) {',begin);
assert(begin>=0&&finish>begin&&registryRaw.indexOf('function originalCanonical(value) {',begin+1)===-1);
const selectedRegistry=registryRaw.slice(begin,finish);
const owners=new Map(),born=[],children=[],events=[];
const target='explicit-local-audio-model-only';
const device={Properties:{SerialNumber:target}};
let births=0,replacementBirths=0,canonicalCreates=0,canonicalDeletes=0;
let current=null,session=null,live=false,replacement=null,stopping=false;
const request=(owner,operation,args={},sessionId=owner.session)=>({schemaVersion:2,ownerInstance:owner.instance,
  requestId:randomUUID().replaceAll('-',''),operation,sessionId,args});
async function birth(onBirth,{replacement=false}={}) {
  const root=await mkdtemp(path.join(config.root,replacement?'replacement-original-':'initial-original-'));await chmod(root,0o700);
  const input={...config,root,nativePid:replacement?43:42};const inputPath=path.join(root,'configuration.json');
  await writeFile(inputPath,JSON.stringify(input),{mode:0o600});
  const child=spawn(config.python,['-B',config.child.path,inputPath],{cwd:'/',stdio:['pipe','pipe','pipe'],
    env:{PATH:'/usr/bin',LANG:'C.UTF-8',LC_ALL:'C.UTF-8',PYTHONDONTWRITEBYTECODE:'1',PYTHONNOUSERSITE:'1',PYTHONPATH:config.pythonPath}});
  assert.equal(Object.getPrototypeOf(child),ChildProcess.prototype);children.push(child);
  const owner=new OriginalUserspaceKeeper(child,target);born.push(owner);births++;
  const stderr=[];child.stderr.on('data',chunk=>stderr.push(Buffer.from(chunk)));
  child.once('exit',(code,signal)=>events.push({event:'exit',pid:child.pid,code,signal}));
  child.once('close',(code,signal)=>{events.push({event:'close',pid:child.pid,code,signal});
    writeFile(path.join(root,'child-stderr.log'),Buffer.concat(stderr),{mode:0o600}).catch(()=>{});});
  onBirth(owner);await owner.ready;await owner.inspect();return owner;
}
const registry=new Function('createHash','isDeepStrictEqual','startOriginalUserspaceKeeper','originalUserspaceOwners','creatorMode','originalCreatorStopping',
  selectedRegistry+'\nreturn {replaceRetiredOriginalOwner,originalDigest};')(createHash,isDeepStrictEqual,
    async(selected,onBirth)=>{assert.equal(selected,device);replacementBirths++;return birth(onBirth,{replacement:true});},owners,'userspace-keeper',false);
function json(res,status,value){res.writeHead(status,{'content-type':'application/json'});res.end(JSON.stringify({value}));}
async function readBody(req){const parts=[];let bytes=0;for await(const part of req){bytes+=part.length;assert(bytes<=1048576);parts.push(part);}return JSON.parse(Buffer.concat(parts));}
async function claim(owner,id){const value={sessionId:id,archiveBundleId:'org.overte.model',wdaBundleId:'org.overte.wda.model'};
  await owner.request(request(owner,'claim',value,id));session=id;live=true;current=owner;}
const server=createServer(async(req,res)=>{
  try {
    if(req.url==='/fixture-shutdown'&&req.method==='POST'){assert(!stopping);stopping=true;json(res,200,{});void closeAll();return;}
    if(req.url==='/fixture-inventory'&&req.method==='GET'){
      let native=null;if(current.child.exitCode===null)native=await current.request(request(current,'fixture-current-inventory'));
      json(res,200,{births,replacementBirths,canonicalCreates,canonicalDeletes,events,native,live,session,
        originalSourceConstructor:true,physicalSDKModeled:true,nativeModeled:true,wholeQualified:false});return;}
    if(req.url==='/fixture-fault'&&req.method==='POST'){
      json(res,200,await current.request(request(current,'fixture-fault',await readBody(req))));return;}
    if(req.url==='/e2e-client-command.json'&&req.method==='POST'){
      const query=await readBody(req);assert(live);
      await current.request(request(current,'fixture-native-query',{query}));
      res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify(query));return;}
    if(req.url==='/session'&&req.method==='POST'){
      const body=await readBody(req);assert(!live);const capability=body.capabilities?.alwaysMatch?.['appium:overteOriginalKeeperReplacement'];
      assert(capability);const old=owners.get(target).owner;
      replacement=await registry.replaceRetiredOriginalOwner(target,{schemaVersion:2,sessionId:null,operation:'replace-after-original-end',ownerInstance:old.instance,
        args:{binding:capability.binding,oldCreatorRetirementSha256:capability.oldCreatorRetirementSha256,
          oldOwnerInstance:capability.oldOwnerInstance,profile:capability.profile,profileKey:capability.profileKey,
          replacementGrant:capability.replacementGrant,runId:capability.runId,stage:capability.stage}});
      await claim(owners.get(target).owner,'model-audio-replacement-'+randomUUID());canonicalCreates++;
      json(res,200,{sessionId:session,capabilities:{}});return;}
    const matched=/^\/session\/([^/]+)(\/execute\/sync)?$/.exec(req.url??'');
    if(!matched){json(res,404,{error:'unknown command'});return;}
    const id=matched[1];assert.equal(id,session);
    if(!matched[2]){
      if(req.method==='GET'){json(res,live?200:404,live?{}:{error:'invalid session id'});return;}
      if(req.method==='DELETE'){
        assert(live);const original=current.creatorRetirementOriginal({ownerInstance:current.instance,sessionId:id});
        assert.equal(original.exitCode,0);assert.equal(original.signalCode,null);assert(original.originalStdioClosed.every(Boolean));
        canonicalDeletes++;live=false;json(res,200,null);return;}
    }
    assert.equal(req.method,'POST');const body=await readBody(req);assert(Array.isArray(body.args)&&body.args.length===1);
    const args=body.args[0],script=body.script;
    if(script==='mobile: overteOriginalKeeperOperation'){
      let value;
      if(args.operation==='original-process-end-creator-retire')value=await current.retireOriginalCreator(request(current,args.operation,args.args,id));
      else if(args.operation==='original-process-end-creator-status')value=current.creatorRetirementOriginal({ownerInstance:current.instance,sessionId:id});
      else {
        assert(live);value=await current.request(request(current,args.operation,args.args,id));
        if(args.operation==='original-readmission-identity')value={...value,originalCreatorReplacement:replacement};
      }
      json(res,200,value);return;
    }
    assert(live);
    if(script==='mobile: pullFile'){
      const raw=await current.request(request(current,'fixture-native-file',{path:args.remotePath},id));json(res,200,raw.contentBase64);return;
    }
    if(script==='mobile: overteProcessInfo'){
      const original=await current.request(request(current,'process-read',{bundleId:args.bundleId,originalPid:0},id));
      const pids=original.bundlePids;assert.equal(pids[0],pids[1]);json(res,200,pids[0]?{bundleId:args.bundleId,pid:pids[0],foreground:true}:null);return;
    }
    if(script==='mobile: overteProcessSourceInfo'){
      // This is the explicit outer SDK service DATA MODEL, independent of
      // actual Python original End/OS receipts. No receipt is relabeled.
      json(res,200,{processSourceVersion:1,source:'dvt-bundle-pid-xcuitest-state',instance:current.instance,
        available:true,cleanupPending:false,sdk:{appium:'3.7.0',xcuitest:'12.8.0',remoteXpc:'5.15.3'}});return;
    }
    throw Error('Undeclared SDK boundary: '+script);
  }catch(error){json(res,500,{error:'unknown error',message:String(error.stack)});}
});
let closePromise=null;
async function closeAll(){
  if(closePromise)return closePromise;
  closePromise=(async()=>{
    for(const owner of born)if(owner.child.exitCode===null&&owner.child.signalCode===null){
      await owner.close();if(owner.originalCloseEvent===null)await new Promise(resolve=>owner.child.once('close',resolve));}
    assert(children.every(c=>c.exitCode!==null||c.signalCode!==null));
    assert(children.every(c=>c.stdin.destroyed&&c.stdout.destroyed&&c.stderr.destroyed));
    server.closeIdleConnections();await new Promise(resolve=>server.close(resolve));
    await writeFile(config.report,JSON.stringify({births,replacementBirths,canonicalCreates,canonicalDeletes,events,
      allFixtureChildrenClosed:true,physicalSDKModeled:true,nativeModeled:true,wholeQualified:false},null,2)+'\n',{mode:0o600});
  })();return closePromise;
}
process.once('SIGTERM',()=>{void closeAll();});
current=await birth(owner=>owners.set(target,{device,owner,starting:null,closing:false,completed:true}));
await claim(current,'model-audio-original-'+randomUUID());
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
process.stdout.write(JSON.stringify({event:'ready',origin:'http://127.0.0.1:'+server.address().port,session,ownerInstance:current.instance})+'\n');
