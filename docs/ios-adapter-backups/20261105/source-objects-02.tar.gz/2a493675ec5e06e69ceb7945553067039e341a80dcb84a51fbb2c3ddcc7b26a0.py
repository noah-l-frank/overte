"""Existing pure Page/File4/Picker2 prefix decoder over retained actual204.

Historical selected construction plus unchanged existing Page inventory;
no full end eligibility, live runtime, native clock, SDK/input/recovery/query.
The partial WAL states stay literal, including pending uncompleted ownership.
"""
from pathlib import Path
from contextlib import ExitStack
import signal,cProfile,hashlib,importlib.machinery,json,os,pstats,stat,sys,threading,time,traceback,shutil
from run_metadata import HERE,REPO,pin,proc,publication,save,sources,registry_original,validate_frozen
assert len(sys.argv)==2 and sys.argv[1] in ('tree156','picker89')
kind=sys.argv[1];plan=dict(validate_frozen(),activeSelection=kind);publication();selected=plan['diagnosticInputsByKind'][kind]
runroot=Path(os.environ['OVERTE_ASSETS_CANONICAL_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs'/kind) and stat.S_IMODE(runroot.stat().st_mode)==0o700
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/(kind+'-publication-ready-source-map.json');approved=json.loads(ready.read_text());ready_pin=pin(ready)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
source_before=sources(plan);assert source_before==approved['sourcePins'] and registry_original()==approved['registry']
save(runroot/'runner-process-binding.json',proc(os.getpid()))
threads_before=set(threading.enumerate());self_proc=proc(os.getpid())
def group():
    result=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        row=proc(int(p.name))
        if row is not None and (row['session']==self_proc['session'] or row['processGroup']==self_proc['processGroup']):result.append(row)
    return result
baseline={(row['pid'],row['startTicks']) for row in group()}
def remaining():return [row for row in group() if (row['pid'],row['startTicks']) not in baseline]
config=json.loads((HERE/'source-root-final-map.json').read_text())
expected=[str(REPO/name) for name in config['orderedRoots']]
sys.path[:]=expected+[p for p in sys.path if not Path(p or os.getcwd()).resolve().is_relative_to(REPO)]
def spec(name):
    search=sys.path;found=None
    for i in range(len(name.split('.'))):
        found=importlib.machinery.PathFinder._get_spec('.'.join(name.split('.')[:i+1]),list(search))
        assert found is not None,name;search=found.submodule_search_locations
    return found
for name,relative in config['packageRoots'].items():assert [str(Path(x).resolve()) for x in spec(name).submodule_search_locations or ()]==[str(REPO/relative)],name
for name,row in config['modules'].items():
    path=Path(spec(name).origin).resolve(strict=True)
    assert path==REPO/row['path'] and pin(path)==source_before[row['path']],name
wal=REPO/selected['archiveWAL'];lockpaths={role:REPO/row['existingLock'] for role,row in selected['roles'].items()}
all_lockpaths={REPO/path for path in selected['allExistingLockPaths']};episode_wal=REPO/selected['episodeWAL']
assert len(all_lockpaths)==6 and set(lockpaths.values())<=all_lockpaths
assert pin(episode_wal)['sha256']==selected['episodeWALSha256']
inputs={str(p):pin(p) for p in (wal,episode_wal,*sorted(all_lockpaths))}
assert inputs[str(wal)]['sha256']==selected['archiveWALSha256']
raw=json.loads(wal.read_text())
assert raw['context']==selected['context'] and raw['context']['roles']==selected['selectedRoleMap']
provenance=REPO/selected['rootProducerReceipt'];provenance_pin=pin(provenance)
root_receipt=json.loads(provenance.read_text())
for role,info in selected['roles'].items():
    expected_root=REPO/info['directory'];root=expected_root.lstat()
    receipt=root_receipt[info['producerIndex']]
    assert receipt['root']==str(expected_root) and receipt['producer']=='genuineTemporaryDirectory'
    assert (root.st_dev,root.st_ino)==(receipt['device'],receipt['inode'])
    assert raw['context']['roles'][role]['stateRoot']==raw['context']['roles'][role]['artifactRoot']==str(expected_root)
    assert raw['context']['roles'][role]['target']==role and lockpaths[role]==expected_root/'script-feature-sources.lock'
    assert stat.S_IMODE(root.st_mode)==0o700

# Install all denials BEFORE any target import. Only pinned metadata rg and
# opening the exact already-existing lock inode can escape the output folder.
metadata_command=['rg','--files','-0',*plan['broadSourceRoots']]
rg_executable=Path(shutil.which('rg')).resolve(strict=True);rg_original_pin=pin(rg_executable)
metadata_subprocesses=[];forbidden=[];sdk_attempts=[]
sdk_bad=('pymobiledevice3','tidevice','pyidevice','zeroconf')
def sdk_path(path):
    if not isinstance(path,(str,bytes,os.PathLike)):return False
    return any(part in ('overte-ios-remotexpc',*sdk_bad) or any(part.startswith(bad+'_') for bad in sdk_bad)
        for part in Path(os.fsdecode(path)).parts)
def check_sdk():
    bad=[]
    for name,module in tuple(sys.modules.items()):
        if any(part in sdk_bad for part in name.split('.')) or sdk_path(getattr(module,'__file__',None)):bad.append(name)
    assert not bad,'Forbidden SDK source/name already imported'
    return bad
sdk_before=check_sdk()
def audit(event,args):
    if event=='import' and (any(part in sdk_bad for part in args[0].split('.')) or sdk_path(args[1])):
        sdk_attempts.append(args[0]);raise RuntimeError('Readonly diagnostic refused SDK import')
    if event=='open':
        path,mode,flags=args
        # This repository-owned receiver is pinned source text, not an SDK
        # import. Only its exact canonical READ path is admitted to metadata.
        receiver=REPO/'tests/device/ios/pymobiledevice3_wda_xctest.py'
        source_only_receiver=(isinstance(path,(str,bytes,os.PathLike)) and Path(os.fsdecode(path))==receiver
            and receiver.resolve(strict=True)==receiver
            and not flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if sdk_path(path) and not source_only_receiver:
            sdk_attempts.append('source-open');raise RuntimeError('Readonly diagnostic refused SDK source')
        if isinstance(path,(str,bytes,os.PathLike)):
            actual=Path(os.fsdecode(path)).resolve()
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            allowed_lock=actual in all_lockpaths and bool(flags&os.O_RDWR) and not flags&(os.O_CREAT|os.O_TRUNC|os.O_APPEND)
            if writing and not actual.is_relative_to(runroot) and not allowed_lock:
                forbidden.append(event);raise RuntimeError('Readonly diagnostic refused write')
    if event=='subprocess.Popen':
        executable,argv,cwd,environment=args
        allowed=executable=='rg' and type(argv) is list and argv==metadata_command and Path(cwd)==REPO and environment is None
        if allowed:
            assert Path(shutil.which('rg')).resolve(strict=True)==rg_executable and pin(rg_executable)==rg_original_pin
            metadata_subprocesses.append(dict(command=list(argv),cwd=str(cwd)));return
        forbidden.append(event);raise RuntimeError('Readonly diagnostic refused nonmetadata subprocess')
    if event in ('os.system','os.exec','os.posix_spawn','socket.__new__','socket.connect','socket.bind','os.remove','os.rename','os.rmdir','os.mkdir','os.chmod','os.truncate'):
        forbidden.append(event);raise RuntimeError('Readonly diagnostic refused external effect')
sys.addaudithook(audit)

profiler=cProfile.Profile();stages=[];primary_error=None;start=time.monotonic();reports=None
interrupts=[];policy_drift=None
def original_timeout(signum,frame):
    # Exact interrupted MAIN call stack locations only; no locals, values or
    # original edits. Profiling finalization writes only this owned run folder.
    rows=[]
    while frame is not None and len(rows)<96:
        rows.append(dict(file=frame.f_code.co_filename,function=frame.f_code.co_name,line=frame.f_lineno))
        frame=frame.f_back
    interrupts.append(dict(signal=signum,actualInterruptedFrames=rows))
    raise TimeoutError('Owned readonly diagnostic reached its fixed outer deadline')
previous_timeout=signal.signal(signal.SIGTERM,original_timeout)
def measure(label,call):
    row=dict(stage=label,entered=True,returned=False);stages.append(row);save(runroot/'actual-stages.json',stages)
    before=time.monotonic();profiler.enable()
    try:
        value=call();row['returned']=True;return value
    finally:
        profiler.disable();row['seconds']=time.monotonic()-before;save(runroot/'actual-stages.json',stages)
try:
    from adapters.normal_feature_state import PrivateFeatureState
    from adapters.original_file_reads import collect
    from adapters.script_feature.lock import ScriptSourceLock
    from ios.adapters.emote_rooted_end_lock import held_existing
    from ios.adapters.assets_end_selection import construct
    from ios.adapters.assets_end_metadata import RecordingAssetsMetadata
    locks={role:ScriptSourceLock(path) for role,path in lockpaths.items()}
    with ExitStack() as held:
        for role in ('actor','primary'):held.enter_context(held_existing(locks[role]))
        archived=measure('actual-historical-selected-pair-open',lambda:construct(PrivateFeatureState(wal),selected['context'],locks,
            [PrivateFeatureState(Path(path)) for path in raw['paths']]))
        archived.selected_guard()
        from ios.adapters.assets_episodes import AssetsEpisodes
        from ios.adapters.assets_page_ownership import AssetsPageInventoryContext,inspect_page
        episodes=measure('actual-existing-episode-original-authority',lambda:AssetsEpisodes(archived,locks))
        assert [row['index'] for row in episodes.state['entries']]==selected['readyEpisodeIndices']
        scopes=tuple(episodes.scope(index) for index in selected['readyEpisodeIndices'])
        actual_extra={scope.locks[role].path for scope in scopes for role in ('primary','actor')}
        assert actual_extra==all_lockpaths-set(lockpaths.values())
        for scope in scopes:
            for role in ('actor','primary'):held.enter_context(held_existing(scope.locks[role]))
        from copy import deepcopy
        from types import SimpleNamespace
        from adapters.original_frame_store import OriginalFrameStore
        from adapters.script_feature.history import same
        from adapters.native_feature_observation import need
        from ios.adapters.assets_end_metadata import store as metadata_store,entries as metadata_entries,coverage
        from adapters.original_file_reads import scope as original_scope
        from ios.adapters.assets_page_clients import PageLeaseUpload,PageLeaseTree
        from ios.adapters.assets_reply_owner import OwnedAssetsReplyReads
        from ios.adapters.assets_reply_sources import ReplySources
        from ios.adapters.assets_session_owners import REPLY_SOURCE,REPLY_MIGRATION,FRAME
        from ios.adapters.assets_model_sources import AssetsModelSources
        def forbidden_port(*_args,**_kwargs):raise RuntimeError('Readonly current decoder has no native/SDK/query/input/recovery port')
        view=RecordingAssetsMetadata(owned=archived.owned_paths(),selection=archived)
        header=measure('actual-current-header-read',lambda:metadata_store(REPO/selected['currentHeader'],view).read())
        assert type(header) is dict
        from ios.adapters.assets_historical_picker_snapshots import ClosedParserPolicy,_value
        import importlib.util
        drift_spec=importlib.util.spec_from_file_location('owned_assets_policy_drift',HERE/'policy_drift_observer.py')
        drift_module=importlib.util.module_from_spec(drift_spec);sys.modules[drift_spec.name]=drift_module;drift_spec.loader.exec_module(drift_module)
        policy_drift=drift_module.ParserPolicyDriftObserver(ClosedParserPolicy,_value,runroot/'actual-first-parser-policy-drift.json',save).start()
        inventory=measure('actual-existing-selected-episode-page-prefix',lambda:inspect_page(AssetsPageInventoryContext(episodes,scopes),metadata=view))
        picker=inventory['pickers'][selected['currentEpisode']];scope=scopes[selected['currentEpisode']-1];files=picker.files
        header_before=deepcopy(header);extra_reads=set();target=None
        if kind=='picker89':
            assert same(picker.previous,header_before)
            picker.state=None
            picker.state=measure('actual-cold-current-picker-decoder',lambda:picker.decode(header_before))
            target=dict(type='Picker2',phase=picker.state['phase'],captures=len(picker.state['captures']),inputs=len(picker.state['inputs']),
                cleanupRequests=0 if picker.state['cleanupWindow'] is None else len(picker.state['cleanupWindow']['requests']))
        else:
            root=Path(scope.descriptor['directories']['primary']['stateRoot']['path']);role='primary';run=episodes.run;binding=episodes.context['roles'][role]['binding'];pid=int(binding['processIdentity'])
            def metadata_guard():
                scope.guard();scope.locks[role].assert_held();archived.selected_guard();return True
            def dependencies():
                replies=object.__new__(OwnedAssetsReplyReads);replies.native=SimpleNamespace(pid=pid,monotonic=time.monotonic,guard=forbidden_port,request=forbidden_port)
                replies.run,replies.url,replies.binding,replies.role,replies.lock=run,episodes.context['fixtureUrl'],deepcopy(binding),role,scope.locks[role]
                replies.store=metadata_store(root/('ios-assets-'+run+'-primary-replies.json'),view);replies.previous=replies.store.read();replies.state=None
                replies.sources=ReplySources(replies,role,metadata_guard,forbidden_port);replies.state=replies.decode(replies.previous)
                upload=object.__new__(PageLeaseUpload);upload.files,upload.picker,upload.replies=files,picker,replies
                upload.store=metadata_store(root/('ios-assets-'+run+'-primary-upload.json'),view);upload.previous=upload.store.read()
                upload.binding,upload.role,upload.lock=deepcopy(binding),role,scope.locks[role];upload.clock=SimpleNamespace(pid=pid,guard=forbidden_port)
                upload.native=SimpleNamespace(capture=forbidden_port,deliver=forbidden_port,assets_input=forbidden_port,sleep=forbidden_port)
                upload.monotonic=time.monotonic;upload.sleep=forbidden_port;upload.page_lease=inventory['owner'];upload.episode=scope
                upload.state=None;upload._cached=[];upload._validated_refs=[];upload._projects=[]
                upload.originals=OriginalFrameStore(root,binding,run,role,metadata_guard,forbidden_port,namespace='assets-upload',schema_prefix='iosAssetsUpload')
                upload.state=upload.decode(upload.previous)
                entries=metadata_entries(root,view);reply_paths={path for path in entries if REPLY_SOURCE.fullmatch(path.name) or REPLY_MIGRATION.fullmatch(path.name)}
                upload_paths={path for path in entries if FRAME.fullmatch(path.name)}
                expected={upload.originals.path(upload.originals.expand(ref)) for ref in upload.state['frames']}
                if upload.state['pending'] is not None and upload.state['pending']['original'] is not None:
                    ref=upload.state['pending']['original'];AssetsModelSources.prefix(upload,ref)
                    if ref['phase']!='planned':expected.add(upload.originals.path(ref))
                assert reply_paths==replies.sources.owned_paths() and upload_paths==expected
                tree=object.__new__(PageLeaseTree);tree.upload,tree.store,tree.lock,tree.native,tree.monotonic=upload,metadata_store(REPO/selected['currentHeader'],view),scope.locks[role],upload.native,time.monotonic
                tree.previous=deepcopy(header_before);tree.state=None
                return replies,upload,tree,expected|reply_paths
            with original_scope(fresh=True) as reads:
                replies,upload,tree,expected=measure('actual-existing-Reply2-Upload2-dependency-decode',dependencies)
                assert coverage(expected,reads,view)
                tree.state=measure('actual-cold-current-tree-decoder',lambda:tree.decode(header_before));extra_reads=set(reads)
            target=dict(type='Tree3',phase=tree.state['phase'],captures=len(tree.state['captures']),inputs=len(tree.state['inputs']),
                uploadFrames=len(upload.state['frames']),uploadPending=upload.state['pending'] is not None,repliesPhase=replies.state['phase'])
        view.guard();assert same(metadata_store(REPO/selected['currentHeader'],view).read(),header_before)
        report=inventory['report'];all_reads=set(report['actualOriginalReads'])|extra_reads
        save(runroot/'actual-original-read-membership.json',sorted(str(path) for path in all_reads))
        reports=[dict(runId=report['runId'],role=report['role'],responsibilities=report['responsibilities']+(['upload-native-capture-prefix','tree-current-input-duty'] if kind=='tree156' else ['picker-current-quiet-prefix']),
            pagePhase=report['phase'],bornEpisodes=report['bornEpisodes'],target=target,ordinaryPartialScopeOnly=True,wholeDirectoryOwnershipRead=False,wholeEndEligible=False,currentNativeFactsProduced=False)]
        assert report['wholeEndEligible'] is False and report['currentNativeFactsProduced'] is False and report['abortAuthorized'] is False
        save(runroot/'actual-private-responsibilities.json',reports)

except BaseException as error:
    primary_error=error;text=''.join(traceback.format_exception(error));print(text,flush=True)
    save(runroot/'actual-original-error.json',dict(type=type(error).__name__,traceback=text))
finally:
    if policy_drift is not None:policy_drift.stop()
    signal.signal(signal.SIGTERM,previous_timeout)
    save(runroot/'actual-timeout-interrupts.json',interrupts)
    profiler.disable();profiler.create_stats()
    if profiler.getstats():
        profiler.dump_stats(str(runroot/'actual-decoders.pstats'));stats=pstats.Stats(profiler);rows=[]
        for (file,line,name),(cc,nc,tt,ct,callers) in stats.stats.items():
            if not Path(file).is_absolute():continue
            try:path=str(Path(file).resolve().relative_to(REPO))
            except (ValueError,OSError):continue
            rows.append(dict(path=path,line=line,function=name,primitiveCalls=cc,calls=nc,selfSeconds=tt,cumulativeSeconds=ct,
                callers=[dict(path=str(Path(f).resolve().relative_to(REPO)) if Path(f).is_absolute() and Path(f).resolve().is_relative_to(REPO) else '<external>',line=l,function=n,counts=list(counts) if type(counts) is tuple else counts) for (f,l,n),counts in callers.items()]))
        save(runroot/'actual-project-calls.json',sorted(rows,key=lambda row:row['cumulativeSeconds'],reverse=True))
    before=remaining();after_inputs={str(p):pin(p) for p in (wal,episode_wal,*sorted(all_lockpaths))}
    assert inputs==after_inputs and source_before==sources(plan) and ready_pin==pin(ready) and provenance_pin==pin(provenance)
    imported={}
    for name,module in tuple(sys.modules.items()):
        filename=getattr(module,'__file__',None)
        if filename is None:continue
        path=Path(filename).resolve()
        if path.is_relative_to(REPO):
            relative=str(path.relative_to(REPO));assert relative in source_before,(name,relative);imported[name]=relative
    save(runroot/'actual-imported-local-sources.json',imported)
    after=remaining();threads=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
    sdk_after=check_sdk()
    result=dict(status='ACTUAL_READONLY_DECODER_RETURNED' if primary_error is None else 'ACTUAL_READONLY_DECODER_ERROR',stages=stages,seconds=time.monotonic()-start,
        originalInputsUnchanged=inputs==after_inputs,sourcePinsUnchanged=True,forbiddenAttempts=forbidden,
        remainingOwnedBeforeCensuses=before,remainingOwnedAfterCensuses=after,remainingNewThreads=threads,
        sdkNameAndSourceAuditBeforeImports=True,sdkModulesBefore=sdk_before,sdkModulesAfter=sdk_after,sdkAttempts=sdk_attempts,
        metadataSubprocesses=metadata_subprocesses,rgBinaryUnchanged=pin(rg_executable)==rg_original_pin,
        nativeCompiled=False,sdkExecuted=False,wholeAssetsQualified=False,deviceQualified=False,
        interruptedStackObserved=bool(interrupts),performanceQualification=False,ordinaryPartialScopeOnly=True,wholeDirectoryOwnershipRead=False,wholeEndEligible=False,partialOwnershipKept=reports is not None and any(row['responsibilities'] for row in reports))
    save(runroot/'profile-result.json',result);print('ACTUAL_DIAGNOSTIC',json.dumps(result),flush=True)
    assert not forbidden and not before and not after and not threads and not sdk_attempts
if primary_error is not None:raise primary_error.with_traceback(primary_error.__traceback__)
