"""Root-only finite SDK constructor source assembly; no subject imports."""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,stat,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
from project_namespace_admission import project_namespace_admission

SOURCE=Path(__file__).resolve().parent
HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
EXECUTORS=('run-one.py','supervise-one.py','prepare.py','metadata_reader.py','host_common.py',
    'closed_import_origins.py','source_execution_readiness.py','owned_write_boundary.py',
    'class_cleanup_custody.py','project_namespace_admission.py','sdk_method_custody.py',
    'sdk_socket_custody.py','readonly-shared-stdlib-sources.json','fixed-eight-groups.json',
    'third-party-source-declarations.json','SUBJECT.json')


def main():
    parser=argparse.ArgumentParser()
    for n in('source-freeze','peer-freeze','peer-sha','sdk-peer-freeze','sdk-peer-sha','expected-head','destination','group'):
        parser.add_argument('--'+n,required=True)
    parser.add_argument('--root-reviewed-actual-sdk-host-constructors-only',required=True,action='store_true')
    args=parser.parse_args()
    assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and head()==args.expected_head
    groups=json.loads((SOURCE/'fixed-eight-groups.json').read_text())['groups']
    assert args.group in groups;recipe=groups[args.group]
    assert len(recipe['caseIds'])in(2,6)and recipe['wallSeconds']==30 and recipe['killGraceSeconds']==5
    physical={}
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        value=pin(path)
        if digest is not None:assert value['sha256']==digest
        previous=physical.setdefault(str(path),value);assert previous==value;return value
    def frozen(path,digest):
        path=Path(path);keep(path,digest);value=json.loads(path.read_text())
        for name,row in value['files'].items():
            assert not Path(name).is_absolute()and '..'not in Path(name).parts
            keep(path.parent/name,row if type(row)is str else row['sha256'])
        return value
    frozen(SOURCE/'source-freeze.json',args.source_freeze)
    subject=json.loads((SOURCE/'SUBJECT.json').read_text())
    subject_path=Path(subject['sourceFreeze']);frozen(subject_path,subject['sourceFreezeSha256'])
    source3=Path(subject['Source3Freeze']);frozen(source3,subject['Source3FreezeSha256'])
    assert args.sdk_peer_freeze==subject['SDKSourcePeerFreeze']and args.sdk_peer_sha==subject['SDKSourcePeerFreezeSha256']
    peers=[]
    for name,digest in((args.peer_freeze,args.peer_sha),(args.sdk_peer_freeze,args.sdk_peer_sha)):
        peer=Path(name);assert peer.is_absolute()and peer.is_relative_to(REPO/'.ios-host-tmp')
        frozen(peer,digest);peers.append(dict(path=str(peer),sha256=digest))
    current,current_pins=qualification(pin)
    for name,row in current_pins.items():assert keep(name)==row
    keep(SOURCE/'closed_import_origins.py',HELPER)
    for name,row in json.loads((SOURCE/'SOURCE-REFERENCES.json').read_text()).items():keep(name,row['sha256'])
    sdk_base=Path(subject['SDKBaseRoot']);assert sdk_base.is_dir()and sdk_base.resolve(strict=True)==sdk_base
    profile_path=subject_path.parent/'candidate-repo/tests/device/ios/original-owner-python-sources.json'
    profile=json.loads(profile_path.read_text());assert profile['sourceProfileVersion']==1 and len(profile['sources'])==3
    replacements={}
    for row in profile['sources']:
        original=sdk_base/row['path'];keep(original,row['originalSha256'])
        candidate=subject_path.parent/'candidate-sdk'/row['path'];keep(candidate,row['payloadSha256'])
        replacements[row['path']]=candidate
    # Root alone may copy this explicit SDK source definition tree. Cached
    # Python code is neither copied nor consulted, and no source is imported.
    sdk_inputs={}
    for folder,dirs,names in os.walk(sdk_base,topdown=True,followlinks=False):
        parent=Path(folder);dirs[:]=sorted(n for n in dirs if n!='__pycache__')
        assert not parent.is_symlink()
        for name in dirs:assert not(parent/name).is_symlink()
        for name in sorted(names):
            file=parent/name
            if file.suffix in('.pyc','.pyo'):continue
            assert not file.is_symlink();row=keep(file)
            relative=file.relative_to(sdk_base).as_posix()
            sdk_inputs[relative]=dict(original=str(file),originalPin=row,selected=str(replacements.get(relative,file)))
    assert set(replacements)<=set(sdk_inputs)
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14')
    stdns={};suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    for folder,dirs,names in os.walk(std,topdown=True,followlinks=False):
        parent=Path(folder);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(parent/n).is_symlink())
        rel=parent.relative_to(std)
        if rel.parts and all(n.isidentifier()for n in rel.parts)and not(parent/'__init__.py').is_file():stdns['.'.join(rel.parts)]=[str(parent)]
        for name in names:
            path=parent/name
            if path.suffix=='.py'or str(path).endswith(suffixes):keep(path)
    python=Path(sys.executable).resolve(strict=True);python_pin=keep(python)
    # Current genuine project modules plus explicit Source3 overlays. Invalid
    # historical fullnames remain pinned DATA via the exact C18 planner.
    project={}
    for folder,dirs,names in os.walk(REPO/'tests/device',topdown=True,followlinks=False):
        parent=Path(folder);dirs[:]=sorted(n for n in dirs if n!='__pycache__'and not(parent/n).is_symlink())
        for name in names:
            if name.endswith('.py'):
                path=parent/name;logical=path.relative_to(REPO).as_posix();project[logical]=path;keep(path)
    composition=json.loads((source3.parent/'COMPOSED-SOURCE-MANIFEST.json').read_text())
    for row in composition['rows']:
        keep(row['path'],row['sha256'])
        if row['logical'].startswith('tests/device/')and row['logical'].endswith('.py'):project[row['logical']]=Path(row['path'])
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'and not dest.exists()
    assert dest.name.startswith('sdk-original-'+args.group+'-prepared-')
    dest.mkdir(mode=0o700)
    def copy_actual(source,target):
        target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        raw=Path(source).read_bytes();fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:assert stream.write(raw)==len(raw)
        assert target.read_bytes()==raw;return keep(target)
    for name in EXECUTORS:copy_actual(SOURCE/name,dest/name)
    sdk=dest/'sdk-source-view';sdk.mkdir(mode=0o700)
    sdk_copies={}
    for relative,row in sorted(sdk_inputs.items()):
        target=sdk/relative;value=copy_actual(row['selected'],target)
        sdk_copies[relative]=dict(path=str(target),pin=value,original=row['original'],originalPin=row['originalPin'],selectedOriginal=row['selected'])
    declared={}
    def module_row(name,path,package):
        value=keep(path);row=dict(path=str(path),sha256=value['sha256'],package=package)
        old=declared.setdefault(name,row);assert old==row
    for logical,path in sorted(project.items()):
        parts=Path(logical).relative_to('tests/device').with_suffix('').parts
        package=parts[-1]=='__init__';parts=parts[:-1]if package else parts
        if not parts:continue
        module_row('.'.join(parts),path,package)
    tests={}
    for module,file,cls in(('sdk_constructor_controls','test_original_sdk_constructor_controls.py','OriginalSdkConstructorControls'),('sdk_partial_setup_cleanup','test_original_sdk_partial_setup_cleanup.py','OriginalSdkPartialSetupCleanupTests')):
        source=subject_path.parent/file;keep(source);target=dest/file;value=copy_actual(source,target)
        module_row(module,target,False);tests[module]=dict(module=module,className=cls,path=str(target),sha256=value['sha256'],originalSource=str(source),originalSha256=pin(source)['sha256'])
    for name in EXECUTORS:
        if name.endswith('.py')and name not in('prepare.py','run-one.py','supervise-one.py'):module_row(Path(name).stem,dest/name,False)
    modules,namespaces,aliases=project_namespace_admission(declared,[str(REPO/'tests/device')])
    assert set(tests)<=set(modules)
    sdk_declared={}
    for relative,row in sdk_copies.items():
        path=Path(row['path']);parts=Path(relative).parts;package=False;module=None
        if path.suffix=='.py':
            parts=(*parts[:-1],path.stem);package=parts[-1]=='__init__';parts=parts[:-1]if package else parts
            if parts and all(n.isidentifier()for n in parts):module='.'.join(parts)
        else:
            for suffix in suffixes:
                if path.name.endswith(suffix):
                    stem=path.name[:-len(suffix)];parts=(*parts[:-1],stem);package=stem=='__init__';parts=parts[:-1]if package else parts
                    if parts and all(n.isidentifier()for n in parts):module='.'.join(parts)
                    break
        if module:
            entry=dict(path=str(path),sha256=row['pin']['sha256'],package=package,loader='source'if path.suffix=='.py'else'extension')
            old=sdk_declared.setdefault(module,entry);assert old==entry
    third,thirdns,sdk_aliases=project_namespace_admission(sdk_declared,[str(sdk)])
    # Preserve the exact actual system PIL/defused sources supported by the
    # qualified C10d transaction. Other copied SDK files stay literal DATA.
    for name,row in json.loads((SOURCE/'third-party-source-declarations.json').read_text()).items():
        keep(row['path'],row['sha256']);third[name]=dict(path=row['path'],sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    assert not set(modules)&set(third)
    required=('pymobiledevice3.lockdown','pymobiledevice3.remote.userspace_tunnel','pymobiledevice3.service_connection','pymobiledevice3.remote.tunnel_service','pymobiledevice3.exceptions','ios.pymobiledevice3_wda_xctest',*tests)
    assert all(n in modules or n in third for n in required)
    plan=dict(status='PRIVATE_ORIGINAL_SDK8_GROUP_UNRUN',controllerRoot=str(dest),repositoryRoot=str(REPO),actualPublicHead=args.expected_head,
        sourceFreeze=args.source_freeze,reviewedPeers=peers,subjectSource=subject,groupName=args.group,cases=recipe['caseIds'],resourceRecipe=recipe,
        wallSeconds=30,killGraceSeconds=5,currentSourceExecution=current,subjectHelperSha256=HELPER,subjectActualCopiedPath=str(dest/'closed_import_origins.py'),
        sourceAndBinaryPins=physical,modules=modules,namespaces=namespaces,declaredProjectAliases=declared,projectAliasAdmission=aliases,
        thirdPartyModules=third,thirdPartyNamespacePackages=thirdns,declaredSDKAliases=sdk_declared,sdkAliasAdmission=sdk_aliases,
        sdkSourceRoot=str(sdk),sdkSourceCopies=sdk_copies,testModules=tests,requiredExecutedModules=list(required),
        expectedClassCleanupGroups=1,classCleanupObservationVersion=1,pythonExecutable=dict(path=str(python),pin=python_pin),
        hostSDKPythonExecutionExpected=True,SDKInstalled=False,deviceActionsRequested=0,remoteProtocolActionsRequested=0,caseChildProcesses=0,caseTDs=0,
        oldApplicationCorpusInputs=0,globalOriginalScans=0,authenticatedSourceAdmission=None,providerAdmission=None,consumerAdmission=None,nativeQualified=False,wholeQualified=False)
    plan['originPlan']=dict(modules=modules,namespacePackages=namespaces,projectAliasAdmission=aliases,thirdPartyModules=third,thirdPartyNamespacePackages=thirdns,
        stdlibNamespacePackages=stdns,stdlibRoots=[str(std)],pythonExecutable=plan['pythonExecutable'],physicalPins=physical)
    output=dest/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_SOURCE_METADATA_ONLY_UNRUN',input=str(output),sha256=pin(output)['sha256'],group=args.group,actualHostSDKCodeWillExecuteIfRun=True,targetStarts=0)))


if __name__=='__main__':main()
