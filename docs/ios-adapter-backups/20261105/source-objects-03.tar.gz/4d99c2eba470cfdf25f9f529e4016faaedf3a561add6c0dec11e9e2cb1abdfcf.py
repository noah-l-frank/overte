"""Private narrow codec admission/copyright correction, metadata/AST only."""
import ast,difflib,hashlib,json
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/emote-callback-live-prefix-codec-binding-copyright-overlay-20261102';OLD=REPO/'.ios-host-tmp/emote-callback-live-prefix-retained-code-own-policy-overlay-20261102'
def write(p,v):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(v)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for path in (OLD/'candidate').rglob('*.py'):
 relative=str(path.relative_to(OLD/'candidate'));before=path.read_text();after=before
 if relative.endswith('emote_callback_live_records.py'):
  after=after.replace('FunctionType,ModuleType,BuiltinFunctionType,CodeType','FunctionType,ModuleType,BuiltinFunctionType,CodeType,MethodType')
  after=after.replace('from adapters.native_feature_observation import need\n','from adapters.native_feature_observation import need\nfrom adapters.original_frame_store import OriginalFrameStore\n')
  needle="            need(owner._historical_rows is self and type(self.cache) is AvatarRecordCache)\n            return dict(formatVersion=owner.FORMAT_VERSION"
  assert after.count(needle)==1
  replacement="""            need(owner._historical_rows is self and type(self.cache) is AvatarRecordCache)
            original=owner.originals
            need(type(original) is OriginalFrameStore and original.root==owner.root
                and same(original.binding,owner.binding) and original.run==owner.run and original.role==owner.role
                and original.namespace=='emote-rooted-live' and original.schema_prefix=='iosEmoteRootedLive' and original.kind=='inputs'
                and type(original.guard) is MethodType and original.guard.__self__ is owner and original.guard.__func__ is owner.file_guard.__func__
                and type(original.intent) is MethodType and original.intent.__self__ is owner and original.intent.__func__ is owner.intent.__func__)
            return dict(formatVersion=owner.FORMAT_VERSION"""
  after=after.replace(needle,replacement)
 if relative.endswith('test_ios_emote_callback_live_history_cache.py'):
  after=after.replace('"""Physical/cache policy counterexamples; no native/feature success is modeled."""\n','"""Physical/cache policy counterexamples; no native/feature success is modeled."""\n# Copyright 2026 Overte contributors.\n# SPDX-License-Identifier: Apache-2.0\n')
  after=after.replace("owner.file_guard,lambda *_:False,","owner.file_guard,owner.intent,")
  after+='''
    def test_foreign_original_codec_cannot_borrow_warm_owner_row(self):
        self.read();self.owner.originals=OriginalFrameStore(self.root,self.owner.binding,'b'*32,'actor',
            self.owner.file_guard,self.owner.intent,namespace='emote-rooted-live',schema_prefix='iosEmoteRootedLive',kind='inputs')
        with self.assertRaises(NativeUIError):self.read()
        self.assertEqual(2,self.calls)
    def test_replaced_original_codec_guard_cannot_borrow_warm_owner_row(self):
        self.read();self.owner.originals.guard=lambda:True
        with self.assertRaises(NativeUIError):self.read()
        self.assertEqual(2,self.calls)
'''
 write(HERE/'base'/relative,before);write(HERE/'candidate'/relative,after);ast.parse(after,filename=relative)
narrow=[];cumulative=[];rows=[]
for path in sorted((HERE/'candidate').rglob('*.py')):
 relative=str(path.relative_to(HERE/'candidate'));before=(HERE/'base'/relative).read_text();after=path.read_text();original=REPO/relative
 narrow.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='reviewed-3d1fb/'+relative,tofile='bound-codec/'+relative))
 cumulative.extend(difflib.unified_diff((original.read_text() if original.exists() else '').splitlines(True),after.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
 rows.append(dict(path=relative,baseSHA256=sha(original) if original.exists() else None,candidateSHA256=sha(path)))
write(HERE/'narrow-codec-and-copyright-only.diff',''.join(narrow));write(HERE/'source3.diff',''.join(cumulative))
plan=json.loads((OLD/'plan.json').read_text());plan.update(status='PRIVATE_UNRUN_CODEC_BINDING_ROOT_REVIEW_REQUIRED',sourcePaths=rows,oldSourcePacketFreeze=sha(OLD/'freeze.json'));plan['mechanisms'].update(cases=13,realRoots=13)
plan['newCorrections']=['Actual OriginalFrameStore type/context/run/role/namespace/schema/kind must match actual owning Live2','Codec guard/intent must remain actual bound methods of same owner','Model uses actual owner.intent binding; two foreign-codec/guard counterexamples','Requested copyright/SPDX added to new testfile']
write(HERE/'plan.json',json.dumps(plan,indent=2)+'\n')
write(HERE/'freeze.json',json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(packet=str(HERE),freeze=sha(HERE/'freeze.json'),source=rows)))
