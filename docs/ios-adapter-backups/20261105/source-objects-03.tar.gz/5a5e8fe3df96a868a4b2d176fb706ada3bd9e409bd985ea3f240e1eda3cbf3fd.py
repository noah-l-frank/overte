from pathlib import Path
import ast,hashlib,json,difflib
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');O=R/'.ios-host-tmp/assets-canonical-pool-source-factory-root-preparation-20261028';P=R/'.ios-host-tmp/assets-canonical-pool-source-factory-proposal-20261028';C=R/'.ios-host-tmp/assets-canonical-pool-test-clock-selection-overlay-20261028';C.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
name='tests/device/ios/self_tests/test_ios_assets_image_pool_canonical_factory.py';base=R/name;s=base.read_text();old="        self.runtime=IOSAssetsRuntime(self.fixture.f.adapter)";assert old in s
new="""        # Select the existing declared producer clocks BEFORE factory/capture.
        # Feature readers and their containing original bracket share this
        # same fresh model host clock; no retained packet is edited/retimed.
        actual_init=existing.feature_observation.FeatureObservation.__init__;model=self.fixture.b
        def selected(observer,*args,**kwargs):
            kwargs['monotonic']=model.monotonic;kwargs['sleep']=model.sleep
            return actual_init(observer,*args,**kwargs)
        self.enterContext(patch.object(existing.feature_observation.FeatureObservation,'__init__',selected))
        self.runtime=IOSAssetsRuntime(self.fixture.f.adapter,monotonic=model.monotonic,epoch_ms=lambda:model.clock()+5000)"""
s=s.replace(old,new);target=C/'candidate'/name;target.parent.mkdir(mode=0o700,parents=True);target.write_text(s);ast.parse(s)
(C/'correction.diff').write_text(''.join(difflib.unified_diff(base.read_text().splitlines(True),s.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
rawroot=O/'runs/source7/first-a55oiuij/temporary/assets-image-pool-runtime-6q0ycyja';clocks=[]
for f in sorted(rawroot.glob('assets-image-pool-native-*')):
 v=json.loads(f.read_text())['frame'];x=json.loads(v['raw'])
 if v['query']['action']=='feature-native-observe':clocks.append(dict(path=str(f),sha256=sha(f),instance=x['instance'],sequence=x['sequence'],epoch=x['capturedEpochMs']))
assert [(x['sequence'],x['epoch']) for x in clocks]==[(6,20144),(16,20154)]
(C/'README.txt').write_text('PRIVATE TEST-ONLY fresh producer selection. Actual original raw clocks retain same instance,sequence6->16,epoch20144->20154 (10ms); aggregate case wall0.713s and validate_join line38 failed. A complete host elapsed span was not saved by failed finish, so its exact value is not claimed. Previous test selected real host callback while native boundary used its declared model clock; new selection uses existing model.monotonic/sleep on newly constructed FeatureObservation readers and the containing runtime model clock BEFORE first factory/capture, matching the established connected source model. Epoch callback model.clock()+5000 keeps original separate host/native epoch domains. Existing passed/failed14+old722 untouched; no production clock/budget/source/Native change. All7 method IDs/bodies apart from setup selection remain, UNRUN.\n')
report=json.loads((O/'source7-report.json').read_text());failedRef=O/'source7-originals-second.json'
dump(C/'plan.json',dict(status='PRIVATE_UNRUN_TEST_ONLY_CLOCK_SELECTION',path=name,baseSha256=sha(base),candidateSha256=sha(target),actualOriginalClocks=clocks,failedOriginalRoot=str(Path(report['runRoot'])/'temporary'),failedOriginalReference=str(failedRef),failedOriginalReferenceSha256=sha(failedRef),failedFiles=14,originalsRetimed=False,productionChanges=False,budgetsChanged=False,tests=False))
files={p.relative_to(C).as_posix():sha(p) for p in C.rglob('*') if p.is_file()};dump(C/'freeze.json',dict(status='FROZEN_PRIVATE_UNRUN',files=files))
H=R/'.ios-host-tmp/assets-canonical-pool-source-factory-clock-corrected-root-preparation-20261028';H.mkdir(mode=0o700,exist_ok=False)
frozen=json.loads((O/'freeze.json').read_text())
for n in frozen['files']:(H/n).write_bytes((O/n).read_bytes())
plan=json.loads((H/'suite-plan.json').read_text());plan['frozenPackets'].append(dict(path=str(C.relative_to(R)),freezeSha256=sha(C/'freeze.json')));plan['failedOriginalRoot']=str(Path(report['runRoot'])/'temporary');plan['failedOriginalReference']=str(failedRef.relative_to(R));plan['explicitExtraSourcePins'].append(str(failedRef.relative_to(R)));plan['oldProtectedFileCount']=736;plan['status']='PRIVATE_CHANGED_TEST_CLOCK_EXACT7_UNRUN';plan['testClockSelection']='Fresh existing model host clocks chosen BEFORE first factory/capture; production clocks and original20/1.5/3 unchanged; old14+722 protected.'
rows=json.loads((H/'expected-publication.json').read_text());next(x for x in rows if x['path']==name)['expectedSha256']=sha(target);dump(H/'expected-publication.json',rows);plan['expectedPublicationSha256']=sha(H/'expected-publication.json');dump(H/'suite-plan.json',plan)
md=(H/'run_metadata.py').read_text();needle="    for group in value['groups']:result.update(group['actual'])\n    return result";repl="    for group in value['groups']:result.update(group['actual'])\n    plan=load_plan();result[plan['failedOriginalRoot']]=json.loads((REPO/plan['failedOriginalReference']).read_text())\n    return result";assert needle in md;md=md.replace(needle,repl);(H/'run_metadata.py').write_text(md)
(H/'ROOT-PLAN.txt').write_text((H/'ROOT-PLAN.txt').read_text().replace(O.name,H.name)+'\nChanged TEST ONLY after actual first failure; Root publishes this one test setup correction, then fresh per-kind actual map required.60+kill5 unchanged, exact7 unchanged. New supervisor preserves both old722 and failed14 originals (736 total) before/after, no original packet retime or production clock change. Other frozen preps and Source2 untouched.\n')
for p in H.iterdir():
 if p.suffix=='.py':ast.parse(p.read_bytes())
files={p.name:sha(p) for p in H.iterdir() if p.is_file()};dump(H/'freeze.json',dict(status='FROZEN_PRIVATE_CHANGED_TEST_CLOCK_UNRUN',files=files))
print(json.dumps(dict(overlay=str(C),overlayFreeze=sha(C/'freeze.json'),prep=str(H),prepFreeze=sha(H/'freeze.json'),protectedFiles=736)))
