"""Opt-in original keeper current checkpoint over the existing original Source.

This does not advance the held/released proof journal, create a HID/RSD owner,
retime an old cut or admit input. Original close responsibility remains local.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,base64,hashlib,json,math,re,threading,time,uuid
from datetime import datetime
from collections import deque
from concurrent.futures import Future
from copy import deepcopy
from adapters.native_clock_join import digest,validate_join
from adapters.native_feature_observation import decode,exact,need,validate as native
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.operation_transport_guard import scope as transport_scope
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import canonical,same,pack
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import identifier
from ios.adapters.lifecycle_checkpoint_index import LifecycleCheckpointIndex
from ios.adapters import lifecycle_current as current,keyboard_source as keyboard,lifecycle_world as world
from ios.adapters.normal_input import observation as ui_original
from adapters import pending_commit_owner as pending
from ios.adapters.feature_observation import send_original_command
from ios.adapters.lifecycle_touch_resource_owner import _NativeMotionPassiveRead

MAX_CHECKPOINTS=512
FLAGS={'nativeAcquisitionBound','installedCandidateBound','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished'}


def afc_stat_original(value):
    # Actual reviewed AFC.stat returns naive datetime for mtime/birthtime.
    # Retain EVERY field with an exact type tag; do not accept opaque values.
    need(type(value) is dict and all(type(k) is str for k in value));result={}
    for key,item in sorted(value.items()):
        kind=type(item)
        if kind is datetime:
            need(item.tzinfo is None);result[key]=dict(type='datetime-naive',value=item.isoformat(timespec='microseconds'),fold=item.fold)
        elif kind in (str,int,bool,type(None)):result[key]=dict(type=kind.__name__,value=item)
        elif kind is float:need(math.isfinite(item));result[key]=dict(type='float',value=item.hex())
        else:need(False)
    return result


class OriginalLifecycleCurrent:
    def __init__(self,owner,args,session,owner_type,source_type,epoch_ms):
        need(type(owner) is owner_type and type(owner.source) is source_type)
        exact(args,{'nativeCurrentObservationVersion','binding','runId','role','ticket','resultsDirectory','origin','expectedOwnerInstance'})
        need(type(args['nativeCurrentObservationVersion']) is int and args['nativeCurrentObservationVersion']==1
            and args['role'] in ('primary','actor') and args['binding']['sessionId']==session)
        expected=args['expectedOwnerInstance']
        need(args['role']=='primary'or expected is not None)
        need(expected is None or identifier(expected)==owner.instance)
        identifier(args['runId']);identifier(args['ticket']);self.owner,self.source,self.loop=owner,owner.source,asyncio.get_running_loop()
        self.owner_type,self.source_type=owner_type,source_type
        need(callable(epoch_ms));self.epoch_ms=self._epoch=epoch_ms;self._epoch_code=epoch_ms.__code__
        self._epoch_time=owner_type.execute.__globals__['time'];self._epoch_callable=self._epoch_time.time
        self.binding,self.run,self.role=deepcopy(context(args['binding'])),args['runId'],args['role']
        self.origin,self.directory=args['origin'],args['resultsDirectory'];self.session,self.claim=session,owner.session;self.claim_value=deepcopy(owner.session)
        need(self.loop is self.source._loop and owner.session is not None and owner.session['sessionId']==session
            and type(self.directory) is str and re.fullmatch('[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*',self.directory) is not None)
        from ios.adapters.appium_adapter import AppiumAdapter
        need(AppiumAdapter.normalized_http_origin(self.origin,'original Lifecycle current fixture')==self.origin)
        self.rsd=owner.scope(session);self.instance=owner.instance;self.previous=None;self.pending=None
        self.store=PrivateFeatureState(owner.state_root/('ios-lifecycle-current-'+self.role+'-'+self.run+'.json'))
        self.lock=ScriptSourceLock(owner.state_root/'script-feature-sources.lock');self.bind_lock()
        # No adoption of a pre-existing JSON header as original Source birth.
        with self.lock.held():need(self.store.read() is None)
        self.frames=[];self.io_pending=None;self.receivers=tuple((obj,name,getattr(obj,name),getattr(obj,name).__func__.__code__)
            for obj,names in ((self.source,('current','_close_native_read')),(owner,('scope','fresh_touch_scope'))) for name in names)
        self.files=OriginalFrameStore(owner.state_root,self.binding,self.run,self.role,self.header_guard,self.intent,
            namespace='lifecycle-current',schema_prefix='iosLifecycleCurrent',kind='sources')
        self.index=LifecycleCheckpointIndex(self.files,self.save)

    def bind_lock(self):
        resource=self.owner.touch_resources
        if resource is not None:
            from ios.adapters.lifecycle_touch_resource_owner import LifecycleTouchResourceOwner
            need(type(resource) is LifecycleTouchResourceOwner and resource.version==4 and resource.run==self.run
                and resource.binding==self.binding and resource._motion_source() is self.source
                and resource._motion_original._owner() is self.owner
                and type(resource.lock) is ScriptSourceLock and resource.lock.path==self.lock.path)
            # Same actual source-born lock, including nested held-worker use;
            # never acquire a second object against its own open OS lock.
            self.lock=resource.lock

    def identity(self):
        self.index.guard();need(type(self.owner) is self.owner_type and type(self.source) is self.source_type
            and self.owner.source is self.source and self.owner.instance==self.instance
            and self.owner.session is self.claim and self.claim==self.claim_value and self.claim['sessionId']==self.session
            and asyncio.get_running_loop() is self.loop and self.loop is self.source._loop
            and self.owner._lifecycle_current.get(self.role) is self)
        for obj,name,bound,code in self.receivers:
            selected=getattr(obj,name);need(selected.__self__ is obj and selected.__func__ is bound.__func__
                and bound.__func__.__code__ is code)
        need(self.epoch_ms is self._epoch and self._epoch.__code__ is self._epoch_code
            and self.owner_type.execute.__globals__['time'] is self._epoch_time and self._epoch_time.time is self._epoch_callable)
        return True

    def header_guard(self):
        self.lock.assert_held();self.identity();need(same(self.store.read(),self.previous));return True

    def save(self):
        self.header_guard();value=dict(iosLifecycleCurrentOwnerVersion=3,binding=self.binding,runId=self.run,role=self.role,
            ownerInstance=self.instance,checkpointIndex=self.index.snapshot(),pending=deepcopy(self.pending),ioPending=deepcopy(self.io_pending))
        self.store.write(value,self.previous);self.previous=deepcopy(value)

    def intent(self,kind,value):
        self.header_guard()
        if kind=='manifest':
            need(self.pending is not None and self.pending['phase']=='saved');self.index.intent(value);return
        need(kind=='original');self.files.original(value);old=self.pending
        if old is None:need(value['phase']=='planned' and value['index']==len(self.frames)+1)
        else:
            need(all(same(old[k],value[k]) for k in old if k not in ('phase','file'))
                and (old['phase'],value['phase']) in (('planned','opened'),('opened','saved'))
                and (old['file'] is None or old['file']==value['file']))
        self.pending=deepcopy(value);self.save()

    def request(self,args,session):
        exact(args,{'nativeCurrentObservationVersion','binding','runId','role','ticket','resultsDirectory','origin','expectedOwnerInstance'})
        self.identity();need(session==self.session and args['binding']==self.binding and args['runId']==self.run
            and args['role']==self.role and args['origin']==self.origin and args['resultsDirectory']==self.directory)
        identifier(args['ticket']);need(type(args['nativeCurrentObservationVersion']) is int and args['nativeCurrentObservationVersion']==1)
        expected=args['expectedOwnerInstance']
        need(self.role=='primary'or expected is not None)
        need(expected==self.instance or expected is None and self.previous is None and not self.frames)

    async def acquire(self,args,session):
        self.request(args,session);self.bind_lock();need(asyncio.get_running_loop() is self.loop and self.owner._lifecycle_current_active is None
            and len(self.frames)<MAX_CHECKPOINTS and self.pending is None and self.io_pending is None)
        task=asyncio.current_task();source=self.source;owner=self.owner;started=self.loop.time();deadline=started+1.5
        resource,lease=owner.touch_resources,owner.touch;scope=None;phase='before-held';service_row=None;failure=None;data=[]
        owner._lifecycle_current_active=task
        if task not in source._lifecycle_current_tasks:source._lifecycle_current_tasks.append(task)
        def query(action,**fields):return dict(schemaVersion=1,commandId='ios-'+uuid.uuid4().hex,action=action,**fields)
        specs=[('nativeBefore','feature-native-observation.json',262144,query('feature-native-observe')),
            ('beforeUI','ios-normal-ui-request-result.json',65536,query('normal-ui-input',operation='observe')),
            ('pending',pending.FILE,32768,query('feature-pending-commit-owner',operation='observe',runId=self.run,eventId='')),
            ('ui','ios-normal-ui-request-result.json',65536,query('normal-ui-input',operation='observe')),
            ('keyboard',keyboard.FILE,keyboard.LIMIT,query(keyboard.ACTION,runId=self.run)),
            ('world',world.FILE,world.LIMIT,query(world.ACTION,runId=self.run)),
            ('nativeAfter','feature-native-observation.json',262144,query('feature-native-observe'))]
        def check():
            self.identity();need(asyncio.current_task() is task and task.get_loop() is self.loop and not source._closing
                and not owner.closed and not owner.draining and owner._lifecycle_current_active is task and self.loop.time()<deadline
                and owner.touch is lease and owner.touch_resources is resource and owner.scope(session) is self.rsd)
            if scope is not None:scope.current()
            else:need(resource is None and lease is None and source._born==source._leases==[])
            return True
        try:
            with self.lock.held():
                self.header_guard();self.io_pending=dict(index=len(self.frames)+1,ticket=args['ticket'],phase='planned',
                    startedMonotonic=started,deadlineMonotonic=deadline,queries=[dict(name=n,filename=f,limit=l,query=deepcopy(q))for n,f,l,q in specs],
                    returned=[],originalServiceCloseReturned=False,failureType=None);self.save()
            # The old source-local born tuple remains the held/released read
            # authority. Same exact scope/task is used for all checkpoint IO.
            if lease is not None:
                scope=_NativeMotionPassiveRead(owner,session,world.ACTION,self.binding,self.run);phase=scope._phase
            check();await owner.fresh_touch_scope(self.binding);check()
            from pymobiledevice3.services.house_arrest import HouseArrestService
            service=HouseArrestService(self.rsd,documents_only=False);close=service.aclose;closed=asyncio.Event()
            service_row=(service,close,task,self.loop,closed,asyncio.Lock());source._lifecycle_current_reads.append(service_row)
            # Existing original Source close contract; this own stream never
            # consumes or raises the qualified old32 native-read/history cap.
            check();await service.send_command(self.claim['archiveBundleId'],'VendContainer');check()
            actual=await service.__aenter__();check();need(actual is service)
            acquisition_before=None;acquisition_after=None
            for name,filename,limit,issued in specs:
                check();before=dict(epochMs=self.epoch_ms(),monotonic=self.loop.time())
                if acquisition_before is None:acquisition_before=deepcopy(before)
                # Original HTTP thread asks this SAME original acquisition Task
                # to run its guard. No callback impersonation or foreign loop.
                requests=deque();queue_lock=threading.Lock();finished=threading.Event();outcome={}
                def worker_guard():
                    future=Future()
                    with queue_lock:requests.append(future)
                    return future.result()
                def worker():
                    try:
                        with transport_scope(worker_guard):send_original_command(self.origin,issued,4096,before_send=worker_guard,after_send=worker_guard)
                        outcome['returned']=True
                    except BaseException as error:outcome['error']=error
                    finally:finished.set()
                thread=threading.Thread(target=worker,name='original-lifecycle-current-query',daemon=False)
                source._lifecycle_current_queries.append((task,thread,finished,self.loop));thread.start();interrupted=None
                while thread.is_alive() or requests:
                    while True:
                        with queue_lock:future=requests.popleft() if requests else None
                        if future is None:break
                        try:check();future.set_result(None)
                        except BaseException as error:future.set_exception(error)
                    try:await asyncio.sleep(.001)
                    except BaseException as error:interrupted=interrupted or error
                thread.join(timeout=0);need(finished.is_set())
                if interrupted is not None:raise interrupted
                if 'error' in outcome:raise outcome['error']
                check();path='/Documents/'+self.directory+'/'+filename
                first=await service.stat(path);check()
                need(type(first) is dict and first.get('st_ifmt')=='S_IFREG' and first.get('st_nlink')==1
                    and type(first.get('st_size')) is int and 2<=first['st_size']<=limit)
                handle=await service.fopen(path,'r');check()
                try:raw=await service.fread(handle,first['st_size']);check();last=await service.stat(path);check()
                finally:await service.fclose(handle)
                need(type(raw) is bytes and len(raw)==first['st_size'] and first==last);packet=decode(raw.decode('utf-8'),limit=limit)
                after=dict(epochMs=self.epoch_ms(),monotonic=self.loop.time());acquisition_after=deepcopy(after)
                if name in ('nativeBefore','nativeAfter'):native(packet,issued['commandId'],int(self.binding['processIdentity']),packet['capturedEpochMs'])
                elif name in ('beforeUI','ui'):
                    exact(packet,{'schemaVersion','commandId','observation'});need(type(packet['schemaVersion']) is int and packet['schemaVersion']==1 and packet['commandId']==issued['commandId'])
                elif name=='keyboard':keyboard.validate(packet,issued,int(self.binding['processIdentity']))
                elif name=='world':world.validate(packet,issued,int(self.binding['processIdentity']))
                else:pending.validate(packet,issued,int(self.binding['processIdentity']),packet['capturedEpochMs'])
                data.append(dict(name=name,query=issued,rawJson=raw.decode('utf-8'),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                    fileBefore=afc_stat_original(first),fileAfter=afc_stat_original(last),hostBefore=before,hostAfter=after))
                # Query/read summary is responsibility, not saved-original
                # or current-state authority. Any partial cut stays unfinished.
                with self.lock.held():
                    self.header_guard();self.io_pending['phase']='reading'
                    self.io_pending['returned'].append({key:deepcopy(data[-1][key])for key in ('name','query','bytes','sha256','fileBefore','fileAfter','hostBefore','hostAfter')});self.save()
            decoded={row['name']:decode(row['rawJson'],limit=1048576) for row in data}
            originals={name:(decoded[name]['observation'] if name in ('beforeUI','ui') else decoded[name])
                for name in ('beforeUI','pending','ui','keyboard','world')}
            join=dict(clockJoinVersion=1,hostBeforeEpochMs=acquisition_before['epochMs'],hostBeforeMonotonic=acquisition_before['monotonic'],
                hostAfterEpochMs=acquisition_after['epochMs'],hostAfterMonotonic=acquisition_after['monotonic'],
                nativeBefore=decoded['nativeBefore'],nativeAfter=decoded['nativeAfter'],originalsSha256=digest(originals),
                sourceTimes=[dict(source=n,field=k,epochMs=originals[n][k]) for n,k in [('beforeUI','sampleEpochMs'),('pending','capturedEpochMs'),('ui','sampleEpochMs')]])
            validate_join(join,originals)
            value=dict(iosLifecycleCurrentOriginalVersion=1,binding=self.binding,runId=self.run,originals=originals,
                pendingRequest=deepcopy(data[2]['query']),clockJoin=join)
            current.original(value,self.binding,self.run);check();await owner.fresh_touch_scope(self.binding);check()
        except BaseException as error:failure=error
        finally:
            try:
                if service_row is not None:
                    # Same born Source receiver closes only its actual retained
                    # SDK row. Current aliases cannot redirect cleanup. Changed
                    # original code leaves the close owed; no foreign call runs.
                    close,code=next((bound,code)for obj,name,bound,code in self.receivers if obj is source and name=='_close_native_read')
                    need(close.__self__ is source and close.__func__.__code__ is code)
                    if not await close(service_row):failure=failure or RuntimeError('Original Lifecycle AFC close remains unresolved')
            except BaseException as error:failure=failure or error
            finally:
                try:
                    if scope is not None:scope.close()
                except BaseException as error:failure=failure or error
                finally:
                    if owner._lifecycle_current_active is task:owner._lifecycle_current_active=None
        if failure is not None:
            # A failed pre-plan/header guard issued no SDK/native work. An
            # uncertain later CAS keeps its original durable plan unfinished;
            # failure recording itself cannot replace the acquisition cause.
            if self.io_pending is not None:
                try:
                    with self.lock.held():
                        self.header_guard();self.io_pending['phase']='failed'
                        self.io_pending['failureType']=type(failure).__module__+'.'+type(failure).__qualname__
                        self.io_pending['originalServiceCloseReturned']=service_row is not None and service_row[4].is_set();self.save()
                except BaseException:
                    failure.add_note('Original Lifecycle current failure metadata could not be committed; unfinished responsibility remains retained')
            raise failure
        need(self.loop.time()<deadline)
        frame=dict(iosLifecycleCurrentAcquisitionFrameVersion=1,ownerInstance=self.instance,phase=phase,ticket=args['ticket'],
            current=value,reads=data,queryPlan=deepcopy(self.io_pending['queries']),
            originalDeadline=dict(startedMonotonic=started,deadlineMonotonic=deadline),
            sourceContext=dict(sessionId=self.session,binding=self.binding,runId=self.run,role=self.role),
            originalServiceCloseReturned=service_row[4].is_set(),**{k:False for k in FLAGS})
        with self.lock.held():
            self.header_guard();reference=self.files.write(len(self.frames)+1,frame);self.index.append(reference);self.frames.append(reference);self.pending=None;self.io_pending=None;self.save()
        need(self.loop.time()<deadline)
        return dict(iosLifecycleCurrentAcquisitionVersion=1,ownerInstance=self.instance,reference=reference,
            ticket=args['ticket'],role=self.role,**{k:False for k in FLAGS})

    def read(self,args,session):
        exact(args,{'nativeCurrentOriginalReadVersion','binding','runId','role','reference','offset'})
        need(type(args['nativeCurrentOriginalReadVersion']) is int and args['nativeCurrentOriginalReadVersion']==1
            and session==self.session and args['binding']==self.binding and args['runId']==self.run and args['role']==self.role
            and type(args['offset']) is int and args['offset']>=0)
        self.identity();self.bind_lock()
        with self.lock.held():
            self.header_guard();reference=args['reference'];need(reference in self.frames)
            frame=self.files.read(self.files.expand(reference));body=dict(iosLifecycleCurrentFrameVersion=1,kind='sources',
                binding=self.binding,runId=self.run,role=self.role,index=reference['index'],frame=frame);raw=canonical(body)
            need(len(raw)==reference['bytes'] and hashlib.sha256(raw).hexdigest()==reference['sha256'] and args['offset']<len(raw))
        block=raw[args['offset']:args['offset']+4096]
        return dict(iosLifecycleCurrentOriginalReadVersion=1,ownerInstance=self.instance,reference=deepcopy(reference),offset=args['offset'],
            contentBase64=base64.b64encode(block).decode('ascii'),**{k:False for k in FLAGS})
