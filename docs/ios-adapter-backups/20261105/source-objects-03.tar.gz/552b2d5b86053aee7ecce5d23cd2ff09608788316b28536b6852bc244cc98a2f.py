"""Three real MP variant cases; no Source/feature/native owner is created."""
from pathlib import Path
import sys,tempfile,unittest
from mp_core import Runtime
_CONTEXT=None

def configure(context):
    global _CONTEXT
    assert _CONTEXT is None and type(context)is dict
    _CONTEXT=context

class MPVariantTests(unittest.TestCase):
    def setUp(self):
        context=_CONTEXT;assert context is not None
        self.directory=tempfile.TemporaryDirectory(dir=str(context['toys']))
        self.root=Path(self.directory.name)
        context['retain'](self.directory,expected_root=self.root)
        self.addCleanup(self.directory.cleanup)
        context['filePhase'].pause()
        self.runtime=Runtime(self.root,context['plan'],context['input'],context['finder'],context['save'],context['filePhase'])
        context['runtimeBorn'](self.runtime)
        self.addCleanup(self.runtime.finish)
        self.runtime.install()
    def test_original_command_main_guard_before_real_unpickle_and_target(self):
        value=self.runtime.execute('ordinary')
        self.assertEqual(1,value['actualSharedValue'])
        self.assertTrue(value['actualActorAbsent'])
        self.assertEqual(['tracker','actor'],[row['role']for row in self.runtime.spawn.records])
    def test_hostile_startup_source_spec_and_main_alias_refuse_before_unpickle(self):
        self.runtime.execute('hostile')
        actor=self.runtime.spawn.records[-1]
        self.assertEqual('actor',actor['role'])
        self.assertEqual('hostile',actor['startupBinding']['transportScope']['mode'])
        # Parent/outer requires each actual child negative receipt and the
        # subsequent genuine guard->unpickle->target order, not this flag alone.
    def test_live_resources_refuse_retirement_then_genuine_eof_finalizers_tracker_and_parent_exit(self):
        self.runtime.execute('lifetime')
        self.assertEqual(['retirement-while-actual-child-live-refused'],[row['kind']for row in self.runtime.negative_rows])
        self.assertFalse(self.runtime.finished)
