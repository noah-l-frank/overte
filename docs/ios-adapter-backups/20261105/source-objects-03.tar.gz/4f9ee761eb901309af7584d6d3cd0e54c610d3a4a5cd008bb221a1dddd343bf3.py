"""Prospective common-producer fixture; SDK/native/preflight remain MODELS.

This ACTIVE fixture is UNRUN. It never upgrades an old archive. Actual physical
IPA bytes are selected before the normal installed/first-attempt owners exist.
"""
import ast,asyncio,hashlib,json,marshal,os,threading,time,uuid
from copy import deepcopy
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from ios.adapters.appium_adapter import WebDriver as ActualWebDriver
from ios.adapters.feature_observation import post_request as ActualPostRequest
import test_native_passive_carrier_models as carrier_fixture


class NormalChildFixture(carrier_fixture.NativePassiveCarrierModels):
    _model_original_session='test-only' # BEFORE original Source/WDA claim birth.
    def actual_fixture_setup(self,case_class,role,*,installed=False):
        raw=Path(os.environ['LIFECYCLE_NORMAL_CHILD_MODEL_MAP']).read_bytes()
        self.assertEqual(hashlib.sha256(raw).hexdigest(),os.environ['LIFECYCLE_NORMAL_CHILD_MODEL_MAP_SHA256'])
        row=json.loads(raw)[role];path=Path(row['path']);self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),row['sha256'])
        tree=ast.parse(path.read_bytes());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==case_class.__name__)
        method=deepcopy(next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='setUp'))
        if installed:
            # Change the EXPLICIT model fixture at its birth. Production
            # InstalledCodeBinding/ArtifactLease/ZIP byte comparisons stay real.
            writes=[n for n in ast.walk(method) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)
                and n.func.attr=='write_bytes' and ast.unparse(n.func.value)=='self.artifact']
            self.assertEqual(1,len(writes));writes[0].args=[ast.Name(id='_MODEL_IPA_BYTES',ctx=ast.Load())]
            clocks=[n for n in ast.walk(method) if isinstance(n,ast.Assign)
                and any(isinstance(target,ast.Attribute) and ast.unparse(target)=='self.clock.mutate' for target in n.targets)]
            self.assertEqual(1,len(clocks))
            clocks[0].value=ast.Name(id='_MODEL_NATIVE_PRODUCER',ctx=ast.Load())
            summary=next(n for n in method.body if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='self.summary')
            pos=method.body.index(summary);method.body[pos:pos]=ast.parse('self.native.bundle=deepcopy(_MODEL_BUNDLE)\nself.native.mutate=lambda value:value.update(capturedEpochMs=_MODEL_EPOCH())').body
            artifacts=[n for n in ast.walk(summary) if isinstance(n,ast.keyword) and n.arg=='artifactSha256']
            self.assertEqual(1,len(artifacts));artifacts[0].value=ast.Name(id='_MODEL_IPA_SHA',ctx=ast.Load())
            summary.value.keywords.append(ast.keyword(arg='runtime',value=ast.parse("dict(artifact='Overte.ipa')",mode='eval').body))
            birth=next(i for i,n in enumerate(method.body) if isinstance(n,ast.Assign) and ast.unparse(n.targets[0])=='self.adapter')
            method.body[birth:birth]=ast.parse("self.target['testBuild'].update(fixtureOrigin=_MODEL_NATIVE_ORIGIN)").body
        else:
            swaps=[n for n in ast.walk(method) if isinstance(n,ast.Constant) and n.value=='http://controlled.invalid:4723']
            self.assertEqual(1,len(swaps));swaps[0].value=self.command_origin
        mod=ast.Module(body=[method],type_ignores=[]);code=compile(ast.fix_missing_locations(mod),str(path),'exec')
        def native_producer(value):
            # The FIRST installed bundle read already samples this independent
            # native producer, before KeyboardRuntime installs later hooks.
            # New snapshots only; never update any retained original packet.
            now=self.modeled_epoch()
            def fields(row):
                if isinstance(row,dict):
                    for key,child in row.items():
                        if key.endswith('EpochMs'):row[key]=now
                        else:fields(child)
                elif isinstance(row,list):
                    for child in row:fields(child)
            fields(value);value['processId']=42
        ns=dict(case_class.setUp.__globals__,_MODEL_IPA_BYTES=self.archive.path.read_bytes(),
            _MODEL_IPA_SHA=hashlib.sha256(self.archive.path.read_bytes()).hexdigest(),_MODEL_BUNDLE=deepcopy(self.measured_bundle),
            _MODEL_NATIVE_ORIGIN=self.origin,_MODEL_EPOCH=self.modeled_epoch,_MODEL_NATIVE_PRODUCER=native_producer)
        exec(code,ns)
        meta=dict(role=role,sourceSHA256=row['sha256'],selectedASTSHA256=hashlib.sha256(ast.dump(mod,include_attributes=False).encode()).hexdigest(),
            compiledCodeSHA256=hashlib.sha256(marshal.dumps(code)).hexdigest(),modelChangesOnly=True)
        side=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/('normal-fixture-'+uuid.uuid4().hex+'.json')
        side.write_text(json.dumps(meta)+'\n');side.chmod(0o600)
        return type('Prospective'+case_class.__name__,(case_class,),{'setUp':ns['setUp']})

    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.assertEqual([],self.commands);self.assertEqual({},self.ops.native_query_journals)
        self.normal=None;self.normal_worker=None;self.command_tasks=[];self.command_errors=[];self.command_closed=False;self.lose_prepare_response=False;outer=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*_):pass
            def respond(self,method):
                try:
                    body=None if method=='GET' else json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                    async def deliver():
                        outer.assertIs(asyncio.get_running_loop(),outer.loop)
                        if self.path.endswith('/execute/sync'):
                            operation=body['script'];args=body['args'][0]
                            if operation=='mobile: overteOriginalKeeperOperation':
                                request,task=outer.request(args['operation'],args['args']);outer.command_tasks.append(task);await task
                                packet=outer.ops.issued[request]['original']
                                if packet['status']!='complete':raise RuntimeError('Original keeper refused modeled HTTP operation')
                                if args['operation']=='touch-motion-prepare':
                                    from adapters.normal_feature_state import PrivateFeatureState
                                    outer.resource=outer.ops.touch_resources
                                    outer.f.context.store=PrivateFeatureState(outer.resource.store.path.with_name('ios-lifecycle-touch-lease-'+outer.run+'.json'))
                                return packet['result']
                            return outer.normal.client.execute(outer.binding['sessionId'],operation,args)
                        return outer.normal.client.call(method,self.path,body)
                    execute=self.path.endswith('/execute/sync') and type(body) is dict
                    keeper=execute and body['script']=='mobile: overteOriginalKeeperOperation'
                    if keeper:
                        # ONLY actual Keeper/source/RSD/AFC/WDA operations
                        # run on the ORIGINAL child loop and retain real Tasks.
                        future=asyncio.run_coroutine_threadsafe(deliver(),outer.loop)
                        value=future.result(timeout=15)
                    elif execute:
                        # Explicit pure host-SDK DATA MODEL, no SDK objects or
                        # services. Runtime.child() is synchronous on hostloop;
                        # scheduling these modeled GET/process/bundle replies
                        # back onto that blocked same loop would self-deadlock.
                        value=outer.normal.client.execute(outer.binding['sessionId'],body['script'],body['args'][0])
                    else:
                        value=outer.normal.client.call(method,self.path,body)
                    if (outer.lose_prepare_response and method=='POST' and self.path.endswith('/execute/sync')
                            and body['script']=='mobile: overteOriginalKeeperOperation'
                            and body['args'][0]['operation']=='touch-motion-prepare'):
                        outer.lose_prepare_response=False
                        raise OSError('Declared reply loss AFTER actual original prepare Task completed')
                    raw=json.dumps({'value':value}).encode()
                    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
                except (BrokenPipeError,ConnectionResetError):pass
                except BaseException as error:
                    outer.command_errors.append(type(error).__name__)
                    raw=json.dumps({'value':{'error':'unknown error','message':'Modeled original operation refused'}}).encode()
                    self.send_response(500);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
            def do_POST(self):self.respond('POST')
            def do_GET(self):self.respond('GET')
            def do_DELETE(self):self.respond('DELETE')
        self.command_server=HTTPServer(('127.0.0.1',0),Handler)
        self.command_origin='http://127.0.0.1:'+str(self.command_server.server_port)
        self.command_thread=threading.Thread(target=lambda:self.command_server.serve_forever(poll_interval=.01),name='normal-original-child-http',daemon=False)
        self.command_thread.start();self.addAsyncCleanup(self.close_normal_child)
        from ios.self_tests import test_ios_installed_adapter as installed_fixture,test_ios_script_runtime as script_fixture
        installed=self.actual_fixture_setup(installed_fixture.InstalledAdapterTests,'installedFixture',installed=True)
        script=self.actual_fixture_setup(script_fixture.IOSScriptRuntimeTests,'scriptFixture')
        from ios.self_tests import test_ios_keyboard_runtime as keyboard_fixture,test_ios_lifecycle_originals as originals_fixture
        # This SAME explicit elapsed clock is selected BEFORE the normal
        # editor/Scene/native originals exist. No historical field is updated.
        def common_stamp(fixture):
            fixture.tick=max(fixture.tick,round(self.modeled_epoch()-20000))
            fixture.p.k.b.time=fixture.tick
            return dict(epochMs=20000+fixture.tick,monotonicMs=fixture.tick)
        with patch.object(installed_fixture,'InstalledAdapterTests',installed),patch.object(keyboard_fixture,'IOSScriptRuntimeTests',script),patch.object(originals_fixture.LifecycleOriginalsTests,'stamp',common_stamp):
            from ios.self_tests import test_ios_lifecycle_world_attempt as attempt_fixture
            original_touch=attempt_fixture.TouchBoundary
            class ProspectiveTouch(original_touch):
                def decorate(self,value):
                    super().decorate(value)
                    value['clockAfter']=self.scene.clocks()
            with patch.object(attempt_fixture,'TouchBoundary',ProspectiveTouch):
                self.normal=attempt_fixture.AttemptDomain(self)
            self.normal.owner.act() # ACTUAL normal first intercepted editor journey.
            self.normal.d.flow.back('create') # ACTUAL ordinary close, before child birth/capture.
            # Retain the already-selected model callback on this producer;
            # restoring fixture class aliases cannot change later clocks.
            self.normal.native.stamp=self.normal.native.stamp
        f=self.normal.d.f.f.f
        self.assertEqual(self.measured_bundle,f.native.bundle)
        self.assertEqual(self.archive.path.read_bytes(),f.artifact.read_bytes())
        self.binding=deepcopy(self.normal.d.source.binding);self.assertEqual(self.run,self.normal.d.source.run)
        self.assertEqual(self._model_original_session,self.binding['sessionId'])
        self.assertEqual(self.binding['sessionId'],self.ops.session['sessionId']) # Never rewrite an original claim.
        # Continue the SAME prospective normal Scene/Touch/native/bundle
        # producers. The inherited early unused producers have no originals.
        # The original elapsed mapping was selected before normal birth.
        native=self.normal.native
        self.world_source=self.normal.boundary;self.native_source=f.clock;self.bundle_source=f.native
        self.sdk_rect.update(x=0,y=0,width=1000.0,height=640.0)
        # The old prefix's own SDK model remains captured by its owners. New
        # child calls use the ACTUAL WebDriver parser and real owned HTTP.
        native.p.k.fixture.boundary.stop()
        from ios.adapters import lifecycle_world_hold_runtime as runtime_module
        from ios.adapters.script_runtime import IOSScriptRuntime
        self.enterContext(patch.object(runtime_module,'IOSScriptRuntime',IOSScriptRuntime))
        from ios.adapters import appium_adapter
        self.assertIs(ActualWebDriver,appium_adapter.WebDriver)
        from ios.adapters import feature_observation
        host_model_post=feature_observation.post_request
        def route_original_http(request,timeout):
            # Only the ACTUAL already-registered original source HTTP thread
            # uses the existing real sender/producer. No URL/JSON/name/flag is
            # accepted as ownership. Host-SDK producer models stay separate.
            current=threading.current_thread()
            born=any(row[1] is current and row[3] is self.loop and not row[2].is_set()
                and row[0].get_loop() is self.loop and not row[0].done()
                for row in self.source._native_queries)
            return ActualPostRequest(request,timeout) if born else host_model_post(request,timeout)
        self.enterContext(patch.object(feature_observation,'post_request',side_effect=route_original_http))
        self.runtime=runtime_module.IOSLifecycleWorldHoldRuntime(f.adapter)
        self.owner=self.runtime.child('test-only',self.normal.d.flow,self.normal.owner,None,original_child=True)
        self.enterContext(patch('ios.adapters.lifecycle_touch_resource_owner.touch_session',side_effect=lambda *_a,**_k:self.f.context))
        self.addAsyncCleanup(self.close_normal_child)

    async def close_normal_child(self):
        if self.command_closed:return
        self.f.context.down_gate.set();self.f.context.enter_gate.set();self.f.context.drain_gate.set();self.window_gate.set()
        if self.ops.touch is not None:
            self.motion_lease=self.ops.touch;self.f.owner=self.ops.touch;self.ops.touch.request_release.set()
            if self.ops.touch.worker is not None:await asyncio.wait_for(asyncio.shield(self.ops.touch.worker),5)
        for task in self.command_tasks:
            if not task.done():await asyncio.wait_for(asyncio.shield(task),5)
        # No event-loop blocking server.shutdown while a request still awaits
        # that loop. Every actual original RPC task has completed first.
        await asyncio.to_thread(self.command_server.shutdown);self.command_server.server_close();self.command_thread.join(5)
        self.assertFalse(self.command_thread.is_alive());self.command_closed=True
