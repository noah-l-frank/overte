"""UNRUN metadata-only assembler; Root quiet/terminal context required."""
from pathlib import Path
import ast,hashlib,importlib.util,json,subprocess,sys

SOURCE=Path(__file__).resolve().parent
REPO=SOURCE.parent.parent
CONTROLLER=REPO/'.ios-host-tmp/audio-normal-mute-prefix-controller1-source-preparation-20261103'
PREFIX=REPO/'.ios-host-tmp/audio-normal-open-first-mute-literal-prefix-source1-private-20261103'
BASIS=REPO/'.ios-host-tmp/audio-whole-positive2-snapshot-return1-agent-run-20261103'
PREP=REPO/'.ios-host-tmp/audio-normal-mute-prefix-controller2-final-preparation-20261103'
HEAD='00fafcc4c097552198456c7e7687f243801d3ed8'
CASE='ios.self_tests.test_ios_audio_normal_mute_prefix.AudioNormalMutePrefixTests.test_actual_prepare_open_first_mute_original_inputs_silence_and_actor_publication'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def packet(root,filename,expected):
    root=Path(root);assert root.resolve(strict=True)==root and root.is_relative_to(REPO/'.ios-host-tmp')
    file=root/filename;assert sha(file)==expected
    manifest=json.loads(file.read_text());rows=manifest['files']
    items=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
    for name,row in items:
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        path=root/name;assert path.resolve(strict=True)==path
        assert sha(path)==(row['sha256']if type(row)is dict else row)
    return dict(path=str(file),sha256=expected)
def write(name,value):
    path=PREP/name;assert path.parent==PREP and not path.exists()
    with path.open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    path.chmod(0o600)
def name(path,base):
    parts=path.relative_to(base).with_suffix('').parts
    return '.'.join(parts[:-1]if parts[-1]=='__init__'else parts)
def main():
    assert sys.dont_write_bytecode and len(sys.argv)==4
    source=packet(SOURCE,'source-freeze.json',sys.argv[1])
    context_path=Path(sys.argv[2]);assert context_path.resolve(strict=True)==context_path
    assert context_path.is_relative_to(REPO/'.ios-host-tmp')and sha(context_path)==sys.argv[3]
    terminal=json.loads(context_path.read_text())
    assert terminal['publicHead']==HEAD and terminal['allTargetWindowsTerminal']is True and terminal['C6Terminal']is True
    assert terminal['expectedOldRootCount']==648 and terminal['expectedFinalRootCount']==649
    baseline=Path(terminal['baselinePath']);assert baseline.resolve(strict=True)==baseline and baseline.is_relative_to(REPO/'.ios-host-tmp')
    assert sha(baseline)==terminal['baselineSha256']
    old648=json.loads(baseline.read_text());assert len(old648)==648
    whole=Path(terminal['wholeC6Root']);assert whole.resolve(strict=True)==whole and whole.is_dir()and whole.is_relative_to(REPO/'.ios-host-tmp')
    assert str(whole)not in old648
    proofs=[]
    for row in terminal['resultPackets']:proofs.append(packet(Path(row['path']),'freeze.json',row['freezeSha256']))
    assert proofs,'Actual terminal Root proof packet is required'
    git=Path((REPO/'.git').read_text().split('gitdir: ',1)[1].strip()).resolve(strict=True)
    common=(git/(git/'commondir').read_text().strip()).resolve(strict=True);ref=(git/'HEAD').read_text().strip()
    assert ref.startswith('ref: ')and(common/ref[5:]).read_text().strip()==HEAD
    controller=packet(CONTROLLER,'code-preparation-freeze.json','a98ccf5b5032afc5b87af9a5c2d7435723c7ad4caa57204830acecd5adf1d710')
    prefix=packet(PREFIX,'freeze.json','81a7df7cd0691af5599be8f28e9fa77e3304c16009648d83bde9d065e75f5f21')
    original_map=BASIS/'preimport-map.json';assert sha(original_map)=='2e6281834267ef38fb38d83eb18dba17a8a0a59634d9e04f79c511800e0d1ed8'
    old=json.loads(original_map.read_text());private={key:dict(row)for key,row in old['modules'].items()if Path(row['path']).is_relative_to(REPO/'.ios-host-tmp')}
    assert len(private)==86 and all(sha(row['path'])==row['sha256']for row in private.values())
    assert not [row for row in private.values()if 'importer-custody7'in row['path']or 'audio_original_validation_graph.py'in row['path']]
    modules=dict(private);public=REPO/'tests/device'
    namespaces={key:[value for value in values if Path(value).is_relative_to(REPO/'.ios-host-tmp')]for key,values in old['namespacePackages'].items()}
    paths=[Path(value)for value in subprocess.check_output(['rg','--files',str(public),'-g','*.py'],text=True).splitlines()]
    for path in sorted(paths):
        assert path.resolve(strict=True)==path and not path.is_symlink()
        module=name(path,public)
        if module and module not in modules:modules[module]=dict(path=str(path),sha256=sha(path),package=path.name=='__init__.py',layer='public-current-00faf')
        parts=path.relative_to(public).with_suffix('').parts
        for index in range(1,len(parts)):
            key='.'.join(parts[:index]);directory=str(public.joinpath(*parts[:index]))
            if directory not in namespaces.setdefault(key,[]):namespaces[key].append(directory)
    test=PREFIX/'candidate/tests/device/ios/self_tests/test_ios_audio_normal_mute_prefix.py'
    modules['ios.self_tests.test_ios_audio_normal_mute_prefix']=dict(path=str(test),sha256=sha(test),package=False,layer='new-one-prefix-test-only')
    namespaces={key:values for key,values in namespaces.items()if values and key not in modules}
    assert all(modules[key]==row for key,row in private.items())
    for row in old['frozenPackets']:assert sha(row['path'])==row['sha256']
    assert not PREP.exists();PREP.mkdir(mode=0o700)
    for file in('owned_write_boundary.py','global_original_corpus.py'):(PREP/file).write_bytes((CONTROLLER/file).read_bytes())
    roots=set(old648)|{str(whole)}
    write('global-original-roots-seed.json',dict(roots=sorted(roots),allOld648Preserved=True,wholeC6Included=str(whole),noWriterExclusions=True))
    spec=importlib.util.spec_from_file_location('prefix_metadata_original_census',PREP/'global_original_corpus.py')
    census=importlib.util.module_from_spec(spec);spec.loader.exec_module(census)
    first=census.current();second=census.current();assert first==second and len(first)==649
    assert all(first[key]==row for key,row in old648.items())and str(whole)in first
    write('global-original-corpus-baseline.json',first)
    write('terminal-context.json',terminal)
    frozen=list(old['frozenPackets'])+[source,controller,prefix,*proofs]
    files=['run-prefix.py','external-supervisor.py','owned_write_boundary.py','global_original_corpus.py','preimport-map.json','global-original-roots-seed.json','global-original-corpus-baseline.json','terminal-context.json','SOURCE-READBACK.json','EXECUTION-PLAN.md']
    plan=dict(old,root=str(PREP),repository=str(REPO),reportedRootHead=HEAD,status='PRIVATE_UNRUN_PREFIX1_REQUIRES_ROOT_REVIEW',cases=[CASE],modules=modules,namespacePackages=namespaces,
        frozenPackets=frozen,controllerFiles=files,writeBoundarySource=dict(path=str(PREP/'owned_write_boundary.py'),sha256=sha(PREP/'owned_write_boundary.py')),
        historicalCorpus=None,historicalLock=None,needsTemporaryRoot=True,baseNormalMap=str(original_map),baseNormalMapSha256=sha(original_map),noSource7ProductAdoption=True)
    write('preimport-map.json',plan);map_sha=sha(PREP/'preimport-map.json')
    for template,file in(('run-prefix.template.py','run-prefix.py'),('external-supervisor.template.py','external-supervisor.py')):
        text=(CONTROLLER/template).read_text().replace('SOURCE_MAP_PENDING_ROOT_REVIEW',map_sha);ast.parse(text);(PREP/file).write_text(text)
    write('SOURCE-READBACK.json',dict(baseNormalMapSha256=sha(original_map),privateRows=len(private),allPrivateRowsPhysicallyEqual=True,publicPythonPaths=len(paths),modules=len(modules),cases=[CASE],old648BodiesExact=True,wholeC6Included=True,globalRoots=len(first),globalEntries=sum(len(value)for value in first.values()),noSource7ProductAdoption=True,targetExecutions=0,rawRootsCreated=0))
    (PREP/'EXECUTION-PLAN.md').write_bytes((CONTROLLER/'REVIEW.md').read_bytes())
    assert first==census.current()and all(sha(row['path'])==row['sha256']for row in modules.values())
    assert(common/ref[5:]).read_text().strip()==HEAD
    files={str(path.relative_to(PREP)):dict(bytes=path.stat().st_size,sha256=sha(path))for path in sorted(PREP.iterdir())if path.is_file()}
    write('freeze.json',dict(status='UNRUN_PREFIX1_REQUIRES_ROOT_REVIEW_AND_NEW_WINDOW',files=files,mapSha256=map_sha,publicHead=HEAD,sourceFreeze=source['sha256'],cases=[CASE],wallSeconds=180,killGraceSeconds=5,failfast=True,noSource7ProductAdoption=True,globalRoots=len(first),targetExecutions=0,rawRootsCreated=0))
    print(json.dumps(dict(freeze=sha(PREP/'freeze.json'),map=map_sha,modules=len(modules),globalRoots=len(first),targetExecutions=0)))
if __name__=='__main__':main()
