"""Private prospective Root launch preparation only; no target imports/tests."""
from pathlib import Path
import ast,json,hashlib,shutil,stat,difflib
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp'
B=T/'lifecycle-original-owner-native-current9-drain-corrected-root-preparation-20261028/28-native-current9'
PACK=T/'lifecycle-original-owner-native-motion-worker-scope-proposal-20261028';OVER=T/'lifecycle-original-owner-native-motion-before-down-alias-overlay-20261028'
E=T/'lifecycle-original-owner-native-motion-resource-envelope-overlay-20261028'
P=T/'lifecycle-original-owner-native-motion-worker-envelope-root-preparation-20261028';P.mkdir(mode=0o700)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(PACK/'freeze.json')=='7a0719a52f0ee44dc87b67356fa7bf23a29cd921ef0a84d6a55ceca5d2881127'
assert H(OVER/'freeze.json')=='b7d0e1573cfcd7e38477f885f5b8ef49bb89e6d1978c4c725990f66d9b9088f1'
for packet in (PACK,OVER,E):
 for rel,d in json.loads((packet/'freeze.json').read_text())['files'].items():assert H(packet/rel)==d
manifest=json.loads((PACK/'manifest.json').read_text());owned={row['path']:dict(row) for row in manifest['files']};hold='tests/device/ios/adapters/lifecycle_world_hold.py';owned[hold].update(candidate=str(OVER/'candidate/repo'/hold),candidateSHA256=H(OVER/'candidate/repo'/hold))
resource='tests/device/ios/adapters/lifecycle_touch_resource_owner.py';owned[resource].update(candidate=str(E/'candidate/repo'/resource),candidateSHA256=H(E/'candidate/repo'/resource))
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
 a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);row=dict(stat=[getattr(a,k) for k in fields]);row.update(dict(sha256=H(path)) if path.is_file() else {});assert row['stat']==[getattr(path.lstat(),k) for k in fields];return row
prior=json.loads((B/'prior-retained-original-pins.json').read_text());report=json.loads((B/'root-run-first/report.json').read_text());assert report['exitCode']==0 and report['retainedFiles']==122 and report['allPinsEqual'] and not report['remainingOwnedProcesses'];root=B/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==122
for path in [root,*sorted(root.rglob('*'))]:prior[str(path)]=pin(path)
assert sum('sha256' in row for row in prior.values())==1384
lease_module='tests/device/ios/self_tests/test_ios_touch_lease.py';world_module='tests/device/ios/self_tests/test_ios_lifecycle_world_hold.py'
def method_ids(relative,cls):
 tree=ast.parse((R/relative).read_bytes());c=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
 return ['ios.self_tests.'+Path(relative).stem+'.'+cls+'.'+n.name for n in c.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_')]
lease_ids=method_ids(lease_module,'TouchLeaseTests');assert len(lease_ids)==20
suffixes=['test_canonical_same_session_held_contact_has_independent_grounded_effect_then_actual_release','test_lost_down_never_moves_or_repeats_and_cannot_become_held','test_unknown_down_keeps_original_worker_and_late_completion_cannot_send_move','test_candidate_change_after_actual_down_still_releases_original_object_without_move','test_public_context_alias_swap_cannot_redirect_original_up_or_exit','test_context_acquisition_cannot_swap_original_coordinate_or_check_aliases']
all_world=method_ids(world_module,'LifecycleWorldHoldTests');world_ids=['ios.self_tests.test_ios_lifecycle_world_hold.LifecycleWorldHoldTests.'+n for n in suffixes];assert set(world_ids)<=set(all_world)
compat_paths=[lease_module,world_module,'tests/device/ios/adapters/hid_session.py','tests/device/ios/adapters/lifecycle_world_hold.py','tests/device/ios/adapters/lifecycle_world_hold_runtime.py','tests/device/ios/self_tests/test_ios_lifecycle_world_attempt.py','tests/device/ios/self_tests/test_ios_lifecycle_editors.py','tests/device/ios/self_tests/test_ios_lifecycle_editor_history.py','tests/device/ios/self_tests/test_ios_lifecycle_originals.py','tests/device/ios/self_tests/test_ios_lifecycle_fields.py','tests/device/ios/self_tests/test_ios_lifecycle_inputs.py','tests/device/ios/self_tests/test_ios_lifecycle_navigation.py','tests/device/ios/self_tests/test_ios_pending_runtime.py','tests/device/ios/self_tests/test_ios_keyboard_runtime.py','tests/device/ios/self_tests/test_ios_script_runtime.py','tests/device/ios/self_tests/test_ios_installed_adapter.py']
for number,name,main in [(31,'31-native-motion-worker12',True),(32,'32-legacy-touch26',False)]:
 S=P/name;S.mkdir(mode=0o700)
 for n in ['root-child.py','root-supervise.py','root_stage_guard.py','source_model_bindings.py','supervisor-plan.json','run-selected.py','sdk-original-pins.json']:shutil.copyfile(B/n,S/n)
 stage=json.loads((B/'source-manifest.json').read_text());rows={row['path']:dict(row) for row in stage['sourcePaths']};changes=[]
 for relative,row in owned.items():rows[relative]=dict(path=relative,candidate=row['candidate'],candidateSHA256=row['candidateSHA256'],observedPublicSHA256=H(R/relative),changesCurrentPublic=H(R/relative)!=row['candidateSHA256'])
 for relative in compat_paths:
  if relative in rows:continue
  out=S/'actual-current-dependency/repo'/relative;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/relative,out);rows[relative]=dict(path=relative,candidate=str(out),candidateSHA256=H(out),observedPublicSHA256=H(out),changesCurrentPublic=False)
 for relative,row in rows.items():
  if relative in owned:continue
  actual=H(R/relative)
  if actual!=row['candidateSHA256']:
   out=S/'actual-current-dependency/repo'/relative;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/relative,out);changes.append(dict(path=relative,old=row['candidateSHA256'],current=actual));row.update(candidate=str(out),candidateSHA256=actual)
  row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
 stage.update(stage=number,name=name,status='PRIVATE_UNRUN_WORKER12' if main else 'PRIVATE_UNRUN_LITERAL_COMPAT26',sourcePaths=list(rows.values()),sourcePathCount=len(rows),sourceDeltaPaths=list(owned),caseCount=12 if main else 26,pythonCaseCount=12 if main else 26,nodeCaseCount=0,initialTimeoutSeconds=60 if main else 180,killAfterSeconds=5,exactPublicMutationPlan='Root ONLY reviewed source3 keeper/resource/hold +separate before_down alias correction. No schema/registry/cap/gate changes. Same source for separate compatibility26.')
 for packet in (PACK,OVER,E):stage['orderedParentFreezes'][packet.name]=H(packet/'freeze.json')
 (S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n')
 plan=json.loads((B/'run-plan.json').read_text())
 if main:
  names=['test_native_motion_worker_scope_models.py','test_motion_selected_join_models.py','motion_reference_fixture.py','native_acquisition_fixture.py','native_file_fixture.py']
  for n in names:shutil.copyfile((E if n=='test_native_motion_worker_scope_models.py' else PACK)/n,S/n)
  plan['cases']=json.loads((E/'test-plan.json').read_text())['exactCaseIds']
 else:
  names=[];plan['cases']=lease_ids+world_ids;plan['modelMaps']={};plan['mkdtempAliases']=[];plan['retainInstalledFixture']=False
  plan['retainedTemporaryDirectoryAliases']=['ios.self_tests.test_ios_touch_lease','ios.self_tests.test_ios_installed_adapter']
 plan.update(status='PRIVATE_UNRUN_WORKER12' if main else 'PRIVATE_UNRUN_LITERAL_COMPAT26',caseCount=12 if main else 26,totalCaseCount=12 if main else 26,initialOuterSeconds=60 if main else 180,killAfterSeconds=5,expectedRetainedRoots=24 if main else 26)
 plan['privateFiles']={n:H(S/n) for n in ['root_stage_guard.py','source_model_bindings.py','run-selected.py',*names]};plan['requiredPublicDependencies']=sorted(set(plan['requiredPublicDependencies'])|set(rows)|set(compat_paths))
 plan['retentionAliasActually']='REAL per-module TemporaryDirectory aliases; main has TouchLease+BundleIdentity (2/case), compat TouchLease or InstalledAdapter (1/case). Original cleanup unchanged.'
 plan['qualification']='Source/SDK/HID/native producers explicitly modeled, actual original worker/tasks/FD/JSON/PCM/bytes/codecs/WAL where applicable. No native/SDK/auth/canonical/motionEnd qualification.'
 (S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 settings=json.loads((S/'supervisor-plan.json').read_text());settings['initialSeconds']=60 if main else 180;(S/'supervisor-plan.json').write_text(json.dumps(settings,indent=2)+'\n')
 diff=[]
 for relative,row in owned.items():diff.extend(difflib.unified_diff((R/relative).read_text().splitlines(True),Path(row['candidate']).read_text().splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
 (S/'source3-composed.diff').write_text(''.join(diff))
 (S/'clone-provenance.json').write_text(json.dumps(dict(parentStageFreezeSHA256=H(B/'freeze.json'),sourcePacketFreezeSHA256=H(PACK/'freeze.json'),aliasOverlayFreezeSHA256=H(OVER/'freeze.json'),resourceEnvelopeOverlayFreezeSHA256=H(E/'freeze.json'),actualDependencyChanges=changes,sourcePathCount=len(rows),priorActualFiles=1384,caseCount=12 if main else 26,initialSeconds=60 if main else 180,killAfterSeconds=5,expectedGenuineRoots=24 if main else 26,executed=False,publicEdits=False),indent=2)+'\n')
 (S/'README.txt').write_text('''Root ONLY / PRIVATE UNRUN. Main12 prospective60+kill5/24realTD;
separate unchanged20TouchLease+6originalWorldHold=26/180+kill5/26realTD.
Same composed Source3 on actualpublic CurrentPreDown5f45/dc8/holdc459; holdalias
overlayf4b8 requires original before_down callable pinned before awaited entry.
No registry/schema/defaultRPC/SDK/native/canonical/whole flags changed/opened.
All1384actual prior original files pinned, including all failures and new Current9
PASS122/Join8PASS92. Full actual Root/source/launcher/SDK/stat/byte maps BEFORE
target imports; canonical3roots only and local reviewed PathFinder._get_spec.
Original real fixture TD aliases/retainer, actual LIFO/IsolatedAsyncio teardown,
Source/WDA/creator/nativequery/window/server/HTTP/AFC/worker/FD closes and joins
unchanged. Baseline before target imports and two final FD/task/thread/child
and original censuses. No fake close/await/GC/FDignore or SDK services/imports.
Main positive executes unchanged original12s watchdog; 1.5 cuts only input phases,
no current native assertion during no-input hold. Compatibility original default
context path covers normalactualHID/nativeeffect+release, lost/unknownDown,
candidateafterDown, publicalias, delayedentry alias. Literal test bodies selected,
no duplicate inherited/module discovery and no fullFeature/physical qualification.
Root fromrepo: PYTHONDONTWRITEBYTECODE=1 python3 <stage>/root-supervise.py .
No agent target imports/tests/PUB; fresh actualsource map is REQUIRED after PUB.
''')
 for f in S.rglob('*.py'):ast.parse(f.read_bytes())
 (S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(f.relative_to(S)):H(f) for f in sorted(S.rglob('*')) if f.is_file()}),indent=2)+'\n')
 print(name,H(S/'freeze.json'),'sourcepaths',len(rows),'actualDependencyChanges',changes)
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_BOTH',files={str(f.relative_to(P)):H(f) for f in sorted(P.rglob('*')) if f.is_file()}),indent=2)+'\n');print('parent',H(P/'freeze.json'))
