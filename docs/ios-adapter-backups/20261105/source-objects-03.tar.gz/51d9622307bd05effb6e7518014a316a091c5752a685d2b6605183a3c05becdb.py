"""Private same-selection diagnostics; keep only this worktree's new temp roots."""
from pathlib import Path
import tempfile
import unittest

keep_root=Path.cwd()/'.ios-host-tmp'
actual_directory=tempfile.TemporaryDirectory
retained=[]
class RetainedSnapshotDirectory(actual_directory):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._snapshot_keep=Path(self.name).resolve().is_relative_to(keep_root.resolve())
        if self._snapshot_keep:
            self._finalizer.detach();retained.append(self.name)
    def cleanup(self):
        if not getattr(self,'_snapshot_keep',False):return super().cleanup()

tempfile.TemporaryDirectory=RetainedSnapshotDirectory
suite=unittest.defaultTestLoader.loadTestsFromName('test_ios_snapshot_combined_photos_return.SnapshotCombinedPhotosWholeTests.test_one_png_upload_photos_read_delete_share_archive_end_cleanup_and_return')
result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
for path in retained:print('Retained original temporary root:',path,flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
