"""Pinned host-fixture audit/import machinery; grants no product authority."""
from pathlib import Path
import hashlib,importlib.abc,importlib.util,json,os,socket,stat,sys,time

class FixtureAudit:
 def __init__(self,root,role):
  self.root=Path(root).resolve(strict=True);self.role=role
  self.plan=json.loads((self.root/'preimport-map.json').read_text());self.repo=Path(self.plan['repository'])
  self.parts=json.loads((self.root/'original-parent-source-map.json').read_text());self.pins=json.loads((self.root/'binary-pins.json').read_text())
  self.reads={};self.refusals=[];self.depth=False;self.loaded={};self.nodes=set();self.initial_meta=list(sys.meta_path);self.initial_path=list(sys.path)
  for row in [*self.plan['modules'].values(),*self.plan['frozenPackets'],*self.parts.values(),*self.pins.values()]:
   assert self.digest(row['path'])==row['sha256']
  self.tops={name.split('.')[0]for name in self.plan['modules']};self.finder=self.finder_type()(self)
  sys.meta_path.insert(0,self.finder);sys.addaudithook(self.audit)
 def digest(self,path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
 def save(self,name,value):
  path=self.root/name;path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');path.chmod(0o600)
 def refuse(self,event):
  self.refusals.append(event);self.save('audit-refusal-'+self.role+'-'+str(os.getpid())+'.json',self.refusals)
  raise RuntimeError('AUDIT_REFUSED_'+event)
 def allowed_ports(self):
  ports=set();pids=self.nodes if self.role=='parent'else {int(os.environ['AUDIO_MODEL_GATEWAY_PID'])}
  for pid in pids:
   file=self.root/('guard-node-'+str(pid)+'.json')
   if not file.exists():continue
   value=json.loads(file.read_text());assert value['pid']==pid
   ports.update(row['port']for row in value['listeners']if row['address']=='127.0.0.1')
  return ports
 def pin(self,path):
  if self.depth:return
  self.depth=True
  try:
   path=Path(path).absolute()
   if path.is_relative_to(self.repo)and not path.is_relative_to(self.repo/'.ios-host-tmp')and path.is_file():
    i=path.lstat();row=dict(sha256=self.digest(path),device=i.st_dev,inode=i.st_ino,bytes=i.st_size,mtimeNs=i.st_mtime_ns)
    if str(path)in self.reads:assert self.reads[str(path)]==row
    else:self.reads[str(path)]=row
  finally:self.depth=False
 def audit(self,event,args):
  if event=='import':
   name=args[0]
   if any(name==p or name.startswith(p+'.')for p in ('appium','tidevice','pyidevice','zeroconf','playwright','selenium')):self.refuse('vendor-import')
   if name.startswith('pymobiledevice3')and name not in sys.modules:self.refuse('unmodeled-vendor-import')
  elif event=='socket.bind':
   if self.role!='child'or args[1]!=('127.0.0.1',0):self.refuse('bind')
  elif event=='socket.connect':
   address=args[1]
   if type(address)is not tuple or len(address)!=2 or address[0]!='127.0.0.1'or address[1]not in self.allowed_ports():self.refuse('connect')
  elif event=='socket.getaddrinfo':
   if args[0]!='127.0.0.1':self.refuse('dns')
  elif event=='socket.__new__':
   if args[1]not in (socket.AF_UNIX,socket.AF_INET):self.refuse('socket-family')
  elif event.startswith('socket.')and event not in ('socket.gethostname','socket.getaddrinfo','socket.__new__','socket.bind','socket.connect'):
   self.refuse(event)
  elif event=='subprocess.Popen':
   executable,argv,cwd,env=args
   if self.role!='parent'or executable!=self.pins['node']['path']or list(argv[:4])!=[executable,'--import',str(self.root/'node-audit.mjs'),self.parts['gateway']['path']]or len(argv)!=5 or not Path(argv[4]).absolute().is_relative_to(self.root):self.refuse('subprocess')
  elif event in ('os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn')or event.startswith('os.spawn'):self.refuse(event)
  elif event=='ctypes.dlopen':self.refuse(event)
  elif event=='open'and not self.depth:
   path,mode,flags=args
   if isinstance(path,(str,bytes,os.PathLike)):
    path=Path(os.fsdecode(path)).absolute();writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or isinstance(mode,str)and any(c in mode for c in 'wax+')
    if writing and not path.is_relative_to(self.root):self.refuse('foreign-write')
    if not writing:self.pin(path)
  elif event in ('os.remove','os.rmdir','os.mkdir','os.rename','os.chmod','os.link','os.symlink'):
   for item in args[:2]if event in ('os.rename','os.link','os.symlink')else args[:1]:
    if isinstance(item,(str,bytes,os.PathLike))and not Path(os.fsdecode(item)).absolute().is_relative_to(self.root):self.refuse('foreign-fs-mutation')
 def finder_type(self):
  audit=self
  class Loader(importlib.abc.Loader):
   def __init__(self,name,row):self.name,self.row=name,row
   def create_module(self,spec):return None
   def exec_module(self,module):
    path=Path(self.row['path']);raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==self.row['sha256']
    module.__file__=str(path)
    if self.row['package']:module.__path__=[str(path.parent)]
    audit.loaded[self.name]=self.row;exec(compile(raw,str(path),'exec'),module.__dict__);assert audit.digest(path)==self.row['sha256']
  class Finder(importlib.abc.MetaPathFinder):
   def __init__(self,owner):self.owner=owner
   def find_spec(self,fullname,path=None,target=None):
    row=audit.plan['modules'].get(fullname)
    if row is not None:return importlib.util.spec_from_loader(fullname,Loader(fullname,row),is_package=row['package'])
    roots=audit.plan['namespacePackages'].get(fullname)
    if roots is not None:
     spec=importlib.machinery.ModuleSpec(fullname,None,is_package=True);spec.submodule_search_locations=roots;return spec
    if fullname.split('.')[0]in audit.tops:raise ImportError('Unmapped project import refused: '+fullname)
    if fullname.startswith('pymobiledevice3')and fullname not in sys.modules:raise ImportError('Unmodeled vendor SDK refused')
    return None
  return Finder
 def finish(self):
  after={};same=True
  for path,before in self.reads.items():
   i=Path(path).lstat();value=dict(sha256=self.digest(path),device=i.st_dev,inode=i.st_ino,bytes=i.st_size,mtimeNs=i.st_mtime_ns);after[path]=value;same=same and value==before
  for row in [*self.loaded.values(),*self.plan['frozenPackets'],*self.parts.values(),*self.pins.values()]:assert self.digest(row['path'])==row['sha256']
  self.save('public-before-'+self.role+'-'+str(os.getpid())+'.json',self.reads);self.save('public-after-'+self.role+'-'+str(os.getpid())+'.json',after)
  self.save('loaded-'+self.role+'-'+str(os.getpid())+'.json',self.loaded)
  sys.meta_path[:]=self.initial_meta;sys.path[:]=self.initial_path
  return dict(allPublicDependenciesUnchanged=same,publicDependencies=len(after),auditRefusals=self.refusals,metaPathRestored=sys.meta_path==self.initial_meta,sysPathRestored=sys.path==self.initial_path)
