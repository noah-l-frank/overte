"""Prospective actual Audio scope -> End -> SDK -> fresh idle integration.

This boundary counter begins with real empty recorded-owner custody. It does
not run normal14, a PCM/once episode, terminal seal or final process End. The
raw producer is deliberately idle-only and must refuse ordinary inputs. Whole
activation remains closed even if this prospective host counter passes.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import json,tempfile,time,unittest
from pathlib import Path
from adapters.native_feature_observation import need
from feature_journeys.witness import Client,Journal
from ios.adapters.audio_runtime import IOSAudioRuntime
from ios.adapters.audio_passive_runtime import IOSAudioPassiveRuntime
from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
from ios.adapters.audio_whole_scope_retirement import IOSAudioWholeRetiredScope
from ios.adapters.audio_whole_terminal import AudioWholeTerminal
from audio_original_parent_model import DeclaredCanonicalSDK
from test_audio_original_parent_composition import OriginalSDKGateway


class AudioOriginalWholeIdleReadmissionTests(unittest.TestCase):
    def setUp(self):
        self.primary_gateway=OriginalSDKGateway(self);self.actor_gateway=OriginalSDKGateway(self)
        temporary=tempfile.TemporaryDirectory(prefix='audio-original-whole-');self.addCleanup(temporary.cleanup)
        self.root=Path(temporary.name);self.root.chmod(0o700)
        self.adapter=DeclaredCanonicalSDK(self.root/'canonical',self.primary_gateway.ready['origin'],self.primary_gateway.ready['session'],case=self,
            peers={role:(self.root/('sdk-'+role),gateway.ready['origin'],gateway.ready['session'])for role,gateway in (
                ('primary',self.primary_gateway),('actor',self.actor_gateway))})
        for role in ('primary','actor'):self.adapter.describe(role)
        self.roots={}
        for field,name in (('artifactRoot','public'),('primaryArtifactRoot','primary-originals'),('actorArtifactRoot','actor-originals'),
                           ('primaryWholeRoot','primary-current'),('actorWholeRoot','actor-current')):
            path=self.root/name;path.mkdir(mode=0o700);self.roots[field]=str(path)
        self.run='8'*32;self.journal=Journal(clock=lambda:time.time()*1000)
        registered=self.journal.register('audio');self.journal.runs[self.run]=self.journal.runs.pop(registered)
        fixture=self
        class RawPhase(Client):
            def __init__(self):super().__init__('https://controlled.invalid/feature-fixture/v1','r'*64)
            def request(self,path,value=None,method=None,*,phase_nonce=None,**kwargs):
                need(value is None and path=='/runs/'+fixture.run+'/phase'and phase_nonce is not None)
                return fixture.journal.phase(fixture.run,phase_nonce)
        self.reader=RawPhase();self.config=dict(actorTarget='actor',**self.roots)
        self.runtimes=(IOSAudioPassiveRuntime(self.adapter),IOSAudioRuntime(self.adapter))
        self.primary=IOSAudioWholeFeature(self.adapter,'primary',self.run,'primary',self.reader,self.config,runtimes=self.runtimes)
        self.actor=IOSAudioWholeFeature(self.adapter,'primary',self.run,'actor',self.reader,self.config,runtimes=self.runtimes,source_locks=self.primary.locks)
        self.journal.activate(self.run,'0'*32,'baseline',{})
        self.primary.prepare();self.actor.prepare()
        # Retain the real empty normal owner before invoking baseline-only
        # cleanup. This is an actual owner CAS, not a supplied scope verdict.
        with self.runtimes[1].recorded_owner('primary',self.run,Path(self.roots['primaryArtifactRoot']),self.reader,source_lock=self.primary.locks[1])as owner:
            if owner.previous is None:owner.save()

    def test_actual_whole_retired_scope_parent_end_readmission_and_fresh_native_idle(self):
        f=self.primary
        with f.held():
            old_binding=deepcopy(f.state['bindings']['primary']);old_current=f.current(historical=True,stage='initial')
            retained=old_current.owned_paths()|set(Path(self.roots['primaryArtifactRoot']).rglob('*'))
            # Historical SDK metadata legitimately advances during ordinary
            # pre-End cleanup. Pin immutable external originals only; their
            # exact existing bytes/inodes cannot change under replacement.
            immutable_roots={Path(self.roots['primaryWholeRoot']),Path(self.roots['primaryArtifactRoot'])}
            retained={path:(path.stat().st_ino,path.read_bytes())for path in retained if path.is_file()and path.parent in immutable_roots}
        ticket='c'*32;self.journal.activate(self.run,ticket,'cleanup',{})
        result=f.cleanup(dict(contractVersion=16,runId=self.run));self.assertEqual(dict(performed=True),result)
        with f.held():
            self.assertEqual('cleaned',f.state['phase']);self.assertEqual(2,len(f.state['replacementRestoration']['verified']))
            terminal=AudioWholeTerminal(f);old=terminal.archived_end(0);proof=terminal.validate_replacement()
            scope=IOSAudioWholeRetiredScope(f);scope.end=terminal.actual_end(0);scope.guard_readmission(scope.readmission_original(scope.end))
            self.assertTrue(old['resourceRetirementEstablished']);self.assertEqual(old_binding,proof['oldBinding'])
            self.assertNotEqual(old_binding['sessionId'],proof['newBinding']['sessionId'])
            self.assertNotEqual(proof['oldNativeFeatureInstance'],proof['newNativeFeatureInstance'])
            for ref in f.state['replacementRestoration']['verified']:
                current=f.current(historical=True,stage='replacement');state=current.current_state(current.original(ref))
                self.assertEqual('idle',state['phase']);self.assertEqual([],state['history'])
                self.assertEqual((0,0,0),(state['recordedFrames'],state['playedFrames'],state['bufferedFrames']))
            self.assertEqual(retained,{path:(path.stat().st_ino,path.read_bytes())for path in retained})
        observation=self.actor.observe(dict(contractVersion=16,runId=self.run,afterSequence=0))
        self.assertEqual('idle',observation['state']['phase'])
        with self.actor.held():self.assertEqual(proof['newBinding'],self.actor.state['replacement']['newBinding'])
        inventory=self.primary_gateway.inventory();self.assertEqual(1,inventory['canonicalDeletes']);self.assertEqual(1,inventory['canonicalCreates'])
        self.assertEqual(1,inventory['replacementBirths']);self.assertFalse(inventory['wholeQualified'])
        # Fixture close below is only host resource teardown. It must not be
        # counted as Audio final seal/End or discharge any native PCM duty.
