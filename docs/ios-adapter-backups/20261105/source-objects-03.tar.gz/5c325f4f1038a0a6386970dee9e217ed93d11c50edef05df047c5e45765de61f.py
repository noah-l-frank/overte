"""Fresh production-captured Callback Live2 graph, never an old runtime replay.

Native/Qt/SDK/GPU producers remain explicit host models. Actual original JS,
normal inputs, HTTP, PNG, files, capture/append and resource teardown execute.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import cProfile,hashlib,json,os,pstats,stat,time,unittest
from copy import deepcopy
from pathlib import Path
from adapters.original_file_reads import collect,readonly
from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
from ios.adapters.emote_callback_live_records import CallbackLiveRecords
from ios.adapters.emote_retirement import Frozen
from ios.self_tests.emote_callback_scene_fixture import CallbackSceneFixture

FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')


def census(root):
    values={}
    for path in (root,*sorted(root.rglob('*'))):
        info=path.lstat();assert stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode)
        row=dict(stat=[getattr(info,key) for key in FIELDS])
        if stat.S_ISREG(info.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        assert row['stat']==[getattr(path.lstat(),key) for key in FIELDS];values[str(path)]=row
    return values


class FreshPostbootCallbackHistoryProfile(unittest.TestCase):
    def queries(self,f):
        return dict(native=len(f.domain.history),inputs=deepcopy(f.domain.io.actions),files=deepcopy(f.file_boundary.commands),
            keys=deepcopy(f.key_domain.commands),gpu=[deepcopy(q) for slot in f.t.callback_context.worlds.values() for q in slot.commands])

    def test_production_capture_append_then_cold_warm_historical_archive_preserves_every_original_and_read_membership(self):
        # The actual existing producer classes select their explicit model
        # variants BEFORE their first capture. No returned DTO or factory result
        # replaces capture_snapshot/currentState/native admission/owner.retain.
        f=CallbackSceneFixture(self);f.cleanup()
        live=IOSEmoteCallbackLive(f.keyed);row=live.append(f.keyed_ref)
        full=live.originals.expand(row['reference']);path=live.originals.path(full)
        descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        try:
            actual=os.fstat(descriptor);self.assertEqual(actual.st_dev,full['device']);self.assertEqual(actual.st_ino,full['inode'])
            live.originals.file(path,descriptor,full)
        finally:os.close(descriptor)
        before=census(f.root);queries=self.queries(f);history=CallbackLiveRecords();self.assertTrue(history.literal(),repr(history.unsupported))
        self.assertEqual({},history.cache.rows)
        results=[];reads=[];profiles=[];timings=[]
        for phase in ('cold','warm'):
            profile=cProfile.Profile();started=time.monotonic()
            with readonly(),collect() as membership:
                profile.enable()
                try:
                    archive=IOSEmoteCallbackLive.archive(live.previous,store=Frozen(live.store.path,live.previous),
                        lock=live.lock,primary_lock=live.primary_lock,historical_rows=history)
                    actual_rows=archive.selected_many([row['measurement']['public']])
                finally:profile.disable()
            timings.append(time.monotonic()-started);results.append(actual_rows);reads.append(set(membership));profiles.append(profile)
            self.assertEqual([row],actual_rows);self.assertEqual(before,census(f.root));self.assertEqual(queries,self.queries(f))
        self.assertEqual(results[0],results[1]);self.assertTrue(reads[0]);self.assertEqual(reads[0],reads[1])
        self.assertEqual(1,len(history.cache.rows));self.assertTrue(history.literal(),repr(history.unsupported))
        reopen=[]
        for profile in profiles:
            value=pstats.Stats(profile)
            reopen.append(sum(data[1] for (filename,line,function),data in value.stats.items()
                if filename.endswith('/ios/adapters/emote_callback_archive.py') and function=='reopen'))
        self.assertGreaterEqual(reopen[0],2);self.assertEqual(0,reopen[1])
        output=Path(os.environ['EMOTE_FRESH_GRAPH_PROFILE_OUTPUT']);self.assertTrue(output.is_absolute());self.assertFalse(output.exists())
        report=dict(status='ACTUAL_FRESH_POSTBOOT_ORIGINAL_GRAPH_COLD_WARM_HOST_READ',
            records=len(live.state['records']),cacheRows=len(history.cache.rows),readMembership=len(reads[0]),readMembershipEqual=True,
            coldReopenCalls=reopen[0],warmReopenCalls=reopen[1],coldSeconds=timings[0],warmSeconds=timings[1],
            originalDevice=full['device'],actualFDDevice=actual.st_dev,originalInode=full['inode'],actualFDInode=actual.st_ino,
            retainedFiles=sum('sha256' in value for value in before.values()),allOriginalsUnchanged=True,
            actualInputsAndQueriesUnchanged=True,old747RuntimeReplay=False,retainedOriginalsBefore=before,
            nativeCompiled=False,sdkExecuted=False,deviceAcceptance=False,wholeFeatureQualified=False)
        with output.open('x') as stream:json.dump(report,stream,indent=2,sort_keys=True);stream.write('\n')
