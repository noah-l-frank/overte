"""Actual source methods with explicit existing-WDA/HTTP models, not SDK auth."""
from __future__ import annotations
from source_model_bindings import execute_original
import ast
import asyncio
import hashlib
import json
import os
from pathlib import Path
import re
import unittest
from urllib.parse import quote

class ExistingWdaRouteModels(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        p=Path(os.environ['LIFECYCLE_EXISTING_WDA_ROUTE_SOURCE']);raw=p.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_EXISTING_WDA_ROUTE_SOURCE_SHA256']:
            raise RuntimeError('Exact source unavailable')
        tree=ast.parse(raw);cls=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='OriginalKeeperOperations')
        methods=[next(x for x in cls.body if isinstance(x,ast.AsyncFunctionDef) and x.name==name) for name in ('fresh_touch_scope','execute')]
        class Model:
            def __init__(_self):
                _self.rsd=object();_self.session={'sessionId':'original-appium-id','archiveBundleId':'org.example.overte'}
                _self.wda_session=None;_self.wda_binding_claimed=False;_self.wda=asyncio.get_running_loop().create_future()
                _self.instance='a'*32;_self.calls=[];_self.closed=False;_self.return_sid='original-wda-id'
            def scope(_self,session):
                self.assertEqual(session,_self.session['sessionId']);return _self.rsd
            async def process(_self,bundle):
                self.assertEqual(bundle,'org.example.overte');return {'bundlePids':[31,31]}
        self.model=Model()
        class HTTPModel:
            def __init__(_self,rsd,*,port,timeout):self.assertIs(rsd,self.model.rsd)
            async def _request_json(_self,method,path,payload=None):
                self.model.calls.append((method,path,payload));await asyncio.sleep(0)
                if method=='GET':return {'value':{'sessionId':self.model.return_sid}}
                self.assertEqual((method,path),('POST','/session/original-wda-id/wda/apps/state'))
                return {'value':4}
        class ModelError(RuntimeError):pass
        self.namespace={'WdaServiceClient':HTTPModel,'LaunchError':ModelError,'quote':quote,'re':re}
        execute_original(ast.Module(body=methods,type_ignores=[]),self.namespace,Path(os.environ['LIFECYCLE_EXISTING_WDA_ROUTE_SOURCE']),os.environ['LIFECYCLE_EXISTING_WDA_ROUTE_SOURCE_SHA256'],'test_existing_wda_route_models')
    async def asyncTearDown(self):
        from contextlib import suppress
        self.model.wda.cancel()
        with suppress(asyncio.CancelledError):await self.model.wda
    async def test_missing_original_wda_session_never_queries_sessionless_appstate(self):
        with self.assertRaises(RuntimeError):await self.namespace['fresh_touch_scope'](self.model,{'sessionId':'original-appium-id','processIdentity':'31'})
        self.assertEqual([],self.model.calls)
    async def test_only_read_existing_session_then_query_that_exact_original_prefixed_route(self):
        value=await self.namespace['execute'](self.model,'wda-bind',{'wdaSessionId':'original-wda-id'},'original-appium-id')
        self.assertTrue(value['existingSessionBound']);self.assertFalse(value['nativeTouchSupport'])
        await self.namespace['fresh_touch_scope'](self.model,{'sessionId':'original-appium-id','processIdentity':'31'})
        self.assertEqual([('GET','/session/original-wda-id',None),('POST','/session/original-wda-id/wda/apps/state',{'bundleId':'org.example.overte'})],self.model.calls)
    async def test_wrong_actual_existing_session_reply_remains_unbound_without_new_session_or_retry(self):
        self.model.return_sid='foreign-wda-id'
        with self.assertRaises(RuntimeError):await self.namespace['execute'](self.model,'wda-bind',{'wdaSessionId':'original-wda-id'},'original-appium-id')
        self.assertIsNone(self.model.wda_session)
        with self.assertRaises(RuntimeError):await self.namespace['execute'](self.model,'wda-bind',{'wdaSessionId':'original-wda-id'},'original-appium-id')
        self.assertEqual([('GET','/session/original-wda-id',None)],self.model.calls)
