"""Root-only metadata for one fixed genuine Audio received/ordinary Source5/6 case.

This module never imports the subject, starts a case or reads an old corpus.
Twenty-six separate original180+5 windows preserve the existing normal14 boundary.
"""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
from project_namespace_admission import project_namespace_admission
SOURCE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/audio-ordinary-received-paired-originals-cleanup-end-source6-private-20261105'
SUBJECT_SHA='5d9b109c2e0db1f34fba8b023a85ae3695e2f63ccf08db526a1cf79cb9c64819'
SOURCE5=REPO/'.ios-host-tmp/audio-received-mixer-actor-source5-sdk-whole-end-and-new-protocol-originals-private-20261104'
SOURCE5_SHA='f2ce27ae7d7e94f99e71476cc78fc8625dbdd8243f2284fe9183298e22826f3f'
STAGE=REPO/'.ios-host-tmp/audio-normal14-route-media-received-current-actor-union-staging3-private-20261104'
STAGE_SHA='e96b63201b162891121e0d2db95d7141c6b410b9aab0d97a428a690a48c14c96'
NORMAL_MAP=REPO/'.ios-host-tmp/audio-whole-positive2-snapshot-return1-agent-run-20261103/preimport-map.json'
NORMAL_SHA='2e6281834267ef38fb38d83eb18dba17a8a0a59634d9e04f79c511800e0d1ed8'
HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
COPY=REPO/'.ios-host-tmp/root-snapshot-actor25-public-copy32-provenance-20261104'
MANIFEST=REPO/'.ios-host-tmp/root-public73-exact-reviewed-dirty32-copy-manifest-20261104/copy-manifest.json'
EXECUTORS=('run-one.py','supervise-one.py','metadata_reader.py','host_common.py','closed_import_origins.py',
    'owned_write_boundary.py','source_execution_readiness.py','readonly-shared-stdlib-sources.json',
    'class_cleanup_custody.py','audio_resources.py','locks.py','project_namespace_admission.py',
    'third-party-source-declarations.json','fixed-26-groups.json','definition_custody.py','definition-inventory.json','SOURCE-OVERLAY-PRECEDENCE.json')
SUBJECTS=tuple(json.loads((SOURCE/'definition-inventory.json').read_text()))


def main():
    parser=argparse.ArgumentParser()
    for name in ('source-freeze','expected-head','destination','group','source-review-freeze','source-review-sha'):
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--root-reviewed-controller-and-source56',action='store_true',required=True)
    args=parser.parse_args()
    assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and all(c in '0123456789abcdef'for c in args.expected_head)and head()==args.expected_head
    groups=json.loads((SOURCE/'fixed-26-groups.json').read_text())['groups'];assert args.group in groups
    recipe=groups[args.group];assert len(recipe['caseIds'])==1 and recipe['wallSeconds']==180 and recipe['killGraceSeconds']==5
    physical={}
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        actual=pin(path)
        if digest is not None:assert actual['sha256']==digest
        physical[str(path)]=actual;return actual
    def frozen(folder,name,digest):
        keep(folder/name,digest);value=json.loads((folder/name).read_text())
        for leaf,row in value['files'].items():
            assert not Path(leaf).is_absolute()and '..'not in Path(leaf).parts
            keep(folder/leaf,row if type(row)is str else row['sha256'])
        return value
    frozen(SOURCE,'source-freeze.json',args.source_freeze)
    frozen(REPO/'.ios-host-tmp/audio-received-ordinary-composed26-bootstrap2-shared-genuine-class-cleanup-code-preparation-20261105','source-freeze.json','114e2c19ba09919bd9264c58d1ece1cce7721ed4e8f636ccbbf76f46827a2bfa')
    frozen(REPO/'.ios-host-tmp/root-audio26-b2-eighteen-pass-twentieth-timeout-original-results-20261105','freeze.json','ade58c139a31a09095edf095eff457e934dc4ddd99631afc663cf972d163f2ec')
    frozen(REPO/'.ios-host-tmp/audio-received-ordinary-composed26-bootstrap1-source56-code-preparation-20261105','source-freeze.json','c9c0519449bef3747964775758ec90571493dc3079dc62947b8033936e175ea7')
    frozen(REPO/'.ios-host-tmp/audio-ordinary-independent-media-six-bootstrap2-explicit-declared-definitions-source2-code-preparation-20261104','source-freeze.json','b25d1935a3b3244e7ed80b1f5d879d12ddf3e5c98493ee9341dba8f0e8354cfb')
    frozen(REPO/'.ios-host-tmp/audio-ordinary-independent-media-six-bootstrap1-source2-closed-code-preparation-20261104','source-freeze.json','e81b5a5e7870add86c99b9ce0c34f104a0d613955629b078bd22a1ce057d5acd')
    frozen(SUBJECT,'source-freeze.json',SUBJECT_SHA)
    frozen(STAGE,'source-freeze.json',STAGE_SHA);frozen(SOURCE5,'source-freeze.json',SOURCE5_SHA)
    # Actual independent subject reviews; no future runtime proof is invented.
    review=Path(args.source_review_freeze)
    assert review.is_absolute()and review.is_relative_to(REPO/'.ios-host-tmp')
    frozen(review.parent,review.name,args.source_review_sha)
    for folder,digest in (
        ('assets-independent-audio-received-source5-sdk-whole-native-full-semantic-review-20261105','13afef27c74dbda3add7a1f3b0b9bf55c55b0f133016869295fda3ede6bc2eea'),
        ('assets-independent-audio-ordinary-received-source6-composition-full-semantic-review-20261105','66b1707de7eb073d69bb1d517c6b0f9ceeb4c78d093ad3d4098e44c317b22d4a')):
        frozen(REPO/'.ios-host-tmp'/folder,'freeze.json',digest)
    for name,digest in (
        ('audio-original-handoff-first1-bootstrap3-qualified-c10d-kernel-real-namespace-code-preparation-20261104','1574ad657d6dcd33b330218b8617fbccc12e65bb8ebc573478859187d988b06d'),
        ('audio-original-keeper-profile-route-closed-utility6-bootstrap2-genuine-class-cleanup-current-actor-code-preparation-20261104','0fe609aef8f552090f075c187300398fef4363e888b08f147ecedd20b4db41d6'),
        ('c24-diagnostic-source3-closed-utility14-bootstrap2-genuine-class-cleanup-code-preparation-20261104','119d34ed5aa8c246dd880992bcbc3c3a9d154de508d2276d7503395c5b76df3d')):
        frozen(REPO/'.ios-host-tmp'/name,'source-freeze.json',digest)
    keep(NORMAL_MAP,NORMAL_SHA);normal=json.loads(NORMAL_MAP.read_text())
    old={name:row for name,row in normal['modules'].items()if Path(row['path']).is_relative_to(REPO/'.ios-host-tmp')}
    assert len(old)==86
    for row in old.values():keep(row['path'],row['sha256'])
    stage_rows=json.loads((STAGE/'STAGING-MANIFEST.json').read_text())['candidates'];assert len(stage_rows)==128
    for row in stage_rows:keep(STAGE/'candidate'/row['path'],row['sha256'])
    current,current_pins=qualification(pin);physical.update(current_pins)
    assert keep(SOURCE/'closed_import_origins.py',HELPER)
    frozen(COPY,'freeze.json','6174308eae5013a25c1edf70840e8d944639c82e6ae723ea23d22855d9ba80d3')
    keep(MANIFEST,'bac9c7b613e7c4a3a1b7be88dcd43d2c865b766240705f291ae970688f6ca934')
    manifest=json.loads(MANIFEST.read_text());copy=json.loads((COPY/'copy.json').read_text())
    assert set(manifest)=={'schemaVersion','status','expectedParentHead','stagingFreeze','publicFiles'}
    assert manifest['schemaVersion']==1 and manifest['status']=='ROOT_REVIEWED_EXACT_UNCOMMITTED_SNAPSHOT_ACTOR25_COPY'
    assert copy['parentHead']==manifest['expectedParentHead']=='cb79372ab9ec96df5e1320f9c573259ac3fbebed'
    assert copy['sourceFreeze']==manifest['stagingFreeze']=='5d8b58717b0c65f314f1b8070b7ba0f74475965be1ff1d6c25d5c64497e45594'
    assert len(copy['rows'])==copy['expectedUncommittedPaths']==len(manifest['publicFiles'])==32
    assert {row['path']:row['actualPublicSha256']for row in copy['rows']}==manifest['publicFiles']
    for row in copy['rows']:
        assert row['actualPublicPath']==str(REPO/row['path'])and row['actualPublicSha256']==row['candidateSha256']
        keep(REPO/row['path'],row['actualPublicSha256'])
    device=REPO/'tests/device';projects={}
    def module(relative):
        parts=list(Path(relative).with_suffix('').parts);package=parts[-1]=='__init__'
        if package:parts.pop()
        return '.'.join(parts),package
    for path in sorted(device.rglob('*.py')):
        name,package=module(path.relative_to(device))
        if name:row=keep(path);projects[name]=dict(path=str(path),sha256=row['sha256'],package=package)
    for name,row in old.items():projects[name]={key:row[key]for key in ('path','sha256','package')}
    overlays=json.loads((SOURCE/'SOURCE-OVERLAY-PRECEDENCE.json').read_text())
    assert len(overlays)==116
    for row in overlays:
        path=Path(row['path']);actual=keep(path,row['sha256'])
        projects[row['module']]=dict(path=str(path),sha256=actual['sha256'],package=path.name=='__init__.py')
    definitions=json.loads((SOURCE/'definition-inventory.json').read_text())
    from definition_custody import inventory
    assert set(definitions)==set(SUBJECTS)
    for name,row in definitions.items():
        assert name in projects and projects[name]['path']==row['path']and projects[name]['sha256']==row['sha256']
        keep(row['path'],row['sha256']);assert inventory(row['path'])==row['inventory'],('Definition prebirth source changed',name)
    third={};declarations=json.loads((SOURCE/'third-party-source-declarations.json').read_text());assert len(declarations)==39
    for name,row in declarations.items():
        assert name=='PIL'or name.startswith('PIL.')or name=='defusedxml'or name.startswith('defusedxml.')
        keep(row['path'],row['sha256']);third[name]=dict(path=row['path'],sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14');stdns={};suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    for current_dir,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current_dir);dirs[:]=sorted(n for n in dirs if n not in ('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink());rel=folder.relative_to(std)
        if rel.parts and all(n.isidentifier()for n in rel.parts)and not(folder/'__init__.py').is_file():stdns['.'.join(rel.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix=='.py'or str(path).endswith(suffixes):keep(path)
    python=Path(sys.executable).resolve(strict=True);python_pin=keep(python)
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ');gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for path in (REPO/'.git',gd/'HEAD',gd/'commondir',gd/'index'):keep(path)
    keep(next((base/ref[5:]for base in (gd,common)if(base/ref[5:]).is_file()),common/'packed-refs'))
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'
    assert dest.name.startswith('audio-received-ordinary-'+args.group+'-prepared-')and not dest.exists()
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    dest.mkdir(mode=0o700)
    for name in EXECUTORS:
        path=dest/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        row=keep(path)
        if path.suffix=='.py'and name not in ('run-one.py','supervise-one.py'):
            assert path.stem not in projects;projects[path.stem]=dict(path=str(path),sha256=row['sha256'],package=False)
    declared=dict(projects);projects,namespaces,alias_data=project_namespace_admission(declared,[str(device)])
    replayed,replayed_ns,replayed_data=project_namespace_admission(declared,[str(device)])
    assert (projects,namespaces,alias_data)==(replayed,replayed_ns,replayed_data)
    assert all(name in projects for name in SUBJECTS)
    subjects={name:{key:projects[name][key]for key in ('path','sha256')}for name in SUBJECTS}
    plan=dict(status='PRIVATE_AUDIO_RECEIVED_ORDINARY_ONE_OF_26_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(dest),actualPublicHead=args.expected_head,
        sourceFreeze=args.source_freeze,mediaSourceFreeze=SUBJECT_SHA,receivedSource5Freeze=SOURCE5_SHA,stage3Freeze=STAGE_SHA,definitionInventory=definitions,sourceReview=dict(path=str(review),sha256=args.source_review_sha),
        qualifiedSourceExecution=current,subjectSourceFreeze=current['subjectSourceFreeze'],subjectHelperSha256=HELPER,subjectActualCopiedPath=str(dest/'closed_import_origins.py'),
        sourceAndBinaryPins=physical,modules=projects,namespaces=namespaces,thirdPartyModules=third,subjectOriginModules=subjects,subjectOriginCount=len(subjects),
        groupName=args.group,cases=recipe['caseIds'],resourceRecipe=recipe,wallSeconds=180,killGraceSeconds=5,expectedTemporaryDirectories=recipe['expectedTDs'],
        expectedNestedCleanupCalls=recipe['expectedNestedCleanupCalls'],expectedClassCleanupGroups=1,NodeExecutions=0,SDKExecutions=0,overteNativeQueries=0,oldCorpusInputs=0,globalOriginalScans=0,realNetwork=False,
        pythonExecutable=dict(path=str(python),pin=python_pin),retainedHistoricalPrivateOrigins=old,productionAndTestOverlays=overlays,projectAliasAdmission=alias_data,declaredProjectAliases=declared,
        currentActorCopyProvenance='6174308eae5013a25c1edf70840e8d944639c82e6ae723ea23d22855d9ba80d3',copyManifestSha256='bac9c7b613e7c4a3a1b7be88dcd43d2c865b766240705f291ae970688f6ca934',
        trustedHostBootstrap='Initial interpreter/stdlib/controller modules are explicitly pinned HOSTBOOTSTRAP; actual delegated subject/fixture definitions execute fresh C10d source.',
        originalAPISeconds=25,nativeFreshnessMilliseconds=1500,clockDisagreementMilliseconds=250,modeledNativeObserversExecute=True,
        helperAlgorithmQualificationIsNotAudioComposition=True,utilityQualification=None,physicalADCQualified=False,acousticQualified=False,peerQualified=False,nativeQualified=False,wholeQualified=False)
    plan['originPlan']=dict(modules=projects,namespacePackages=namespaces,projectAliasAdmission=alias_data,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=stdns,stdlibRoots=[str(std)],pythonExecutable=plan['pythonExecutable'],physicalPins=physical)
    output=dest/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),sha256=pin(output)['sha256'],caseIds=recipe['caseIds'],group=args.group,sourcePins=len(physical),targets=0,globalCensuses=0)))


if __name__=='__main__':main()
