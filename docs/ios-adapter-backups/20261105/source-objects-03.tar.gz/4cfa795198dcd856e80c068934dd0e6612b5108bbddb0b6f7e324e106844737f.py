"""Exactly three frozen Assets12 utility methods; genuine standard cleanup."""
from pathlib import Path
import builtins,hashlib,importlib.abc,importlib.util,io,json,os,signal,stat,sys,threading,traceback,unittest
from types import SimpleNamespace
from utility_ports import UtilityPorts
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert len(plan['cases'])==len(set(plan['cases']))==3 and plan['wallSeconds']==30 and plan['killGraceSeconds']==5

def pin(path):
    path=Path(path);a=path.lstat();assert path.resolve(strict=True)==path and stat.S_ISREG(a.st_mode)
    raw=path.read_bytes();fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    assert all(getattr(a,key)==getattr(path.lstat(),key)for key in fields)
    return dict(stat=[getattr(a,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest())
def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:info=path.stat();result[path.name]=dict(target=os.readlink(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result
def children():return Path('/proc/self/task',str(threading.get_native_id()),'children').read_text().strip()
def census(root):
    value={}
    for path in(root,*sorted(root.rglob('*'))):
        info=path.lstat();assert not stat.S_ISLNK(info.st_mode)
        if stat.S_ISDIR(info.st_mode):row=dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,names=sorted(x.name for x in path.iterdir()))
        else:row=pin(path)
        value[str(path.relative_to(root))]=row
    return value
assert {name:pin(name)for name in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
original_meta=tuple(sys.meta_path);original_path=tuple(sys.path);loaded={}
assert not any(name in sys.modules for name in plan['modules'])
sys.path[:]=[p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
project_tops={'ios','adapters','feature_journeys','pymobiledevice3','appium','tidevice','zeroconf'}|set(plan['modules'])
class Loader(importlib.abc.Loader):
    def __init__(self,name,row):self.name,self.row=name,row
    def create_module(self,spec):return None
    def exec_module(self,module):
        path=Path(self.row['path']);assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
        module.__file__=str(path);exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__)
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)];loaded[self.name]=str(path)
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name in plan['modules']:return importlib.util.spec_from_loader(name,Loader(name,plan['modules'][name]),is_package=False)
        if name.split('.')[0]in project_tops:raise ImportError('Unmapped project/SDK import')
        spec=importlib.machinery.PathFinder.find_spec(name,path)
        if spec is not None and spec.origin not in(None,'built-in','frozen'):
            source=Path(spec.origin).resolve(strict=True);stdlib=Path(os.__file__).resolve(strict=True).parent
            assert source.is_relative_to(stdlib)and not any(p in source.parts for p in('site-packages','dist-packages'))
            return spec
        if spec is not None and spec.origin is None:
            assert all(Path(entry).resolve(strict=True).is_relative_to(Path(os.__file__).resolve(strict=True).parent)for entry in spec.submodule_search_locations)
            return spec
        return None
finder=Finder();sys.meta_path.insert(0,finder)
TOYS=HERE/'own-toys';RECEIPTS=HERE/'child-receipts'
assert TOYS.is_dir()and RECEIPTS.is_dir()and not any(TOYS.iterdir())and not any(RECEIPTS.iterdir())
assert os.environ['TMPDIR']==str(TOYS)
from owned_write_boundary import OwnedWrites
import tempfile
assert Path(tempfile.gettempdir())==TOYS
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={name:getattr(os,name)for name in ports if hasattr(os,name)};original_io=(io.open,builtins.open)
original_cleanup=unittest.TestCase.doCleanups
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):
    path=Path(os.readlink('/proc/self/fd/'+str(fd)));assert path.resolve(strict=True)==path and path.is_relative_to(HERE);protected.append(path)
boundary=OwnedWrites(HERE,protected=protected);socket_ports=UtilityPorts()
def audit(event,args):
    if event=='import'and args[0].split('.')[0]in('ios','adapters','feature_journeys','pymobiledevice3','appium','tidevice','zeroconf'):raise RuntimeError('No product/SDK imports')
    if event.startswith('socket.'):
        socket_ports.audit(event,args,sys._getframe(1));return
    if event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):raise RuntimeError('No utility process/native/signal ports')
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if relevant:boundary.audit(event,args,sys._getframe(1))
boundary.install();socket_ports.install();sys.addaudithook(audit)
import test_scoped_port_negatives as subject
from utility_retained_roots import retain_owned_root
socket_ports.bind_subject(subject)
real_td=tempfile.TemporaryDirectory;original_subject_tempfile=subject.tempfile;retained_objects=[];retained_rows=[]
def retained_directory(*args,**kwargs):
    directory=real_td(*args,**kwargs);root=Path(directory.name)
    assert root.parent==TOYS and root.resolve(strict=True)==root
    retain_owned_root(directory,expected_root=root);info=root.lstat()
    retained_objects.append(directory);retained_rows.append(dict(path=str(root),device=info.st_dev,inode=info.st_ino))
    return directory
subject.tempfile=SimpleNamespace(**vars(tempfile));subject.tempfile.TemporaryDirectory=retained_directory

def save(name,body):
    path=RECEIPTS/name
    with path.open('x')as stream:stream.write(json.dumps(body,sort_keys=True,indent=2)+'\n')
    path.chmod(0o600)
fd_before=fds();threads_before=tuple(threading.enumerate());children_before=children()
case_receipts=[];selected=[];result=None;fatal=None;cleanup_rows=[];cleanup_ok=True
class Result(unittest.TextTestResult):
    def startTest(self,test):
        assert socket_ports.active is None;socket_ports.active=test
        self.before=(fds(),tuple(threading.enumerate()),children());super().startTest(test)
    def stopTest(self,test):
        before_fd,before_threads,before_children=self.before
        row=dict(id=test.id(),standardStopAfterCleanup=True,remainingStandardCleanups=len(test._cleanups),fdUnchanged=fds()==before_fd,threadsUnchanged=tuple(threading.enumerate())==before_threads,kernelChildrenUnchanged=children()==before_children)
        case_receipts.append(row);save('standard-case-'+str(len(case_receipts))+'.json',row)
        socket_ports.check();socket_ports.active=None;super().stopTest(test)
original_term=signal.getsignal(signal.SIGTERM)
def interrupted(signum,frame):raise KeyboardInterrupt('Fixed30-second utility boundary')
signal.signal(signal.SIGTERM,interrupted)
try:
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(suite):
        if isinstance(suite,unittest.TestSuite):
            for item in suite:yield from flatten(item)
        else:yield suite
    selected=list(flatten(suite));ids=[case.id()for case in selected]
    save('actual-selection.json',dict(ids=ids,loaderErrors=loader.errors));assert not loader.errors and ids==plan['cases']and suite.countTestCases()==3
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    for case in selected:
        pending=len(case._cleanups);old=case._outcome;drain=unittest.TestResult();success=True
        try:
            if pending:case._outcome=unittest.case._Outcome(drain);success=unittest.TestCase.doCleanups(case)
        except BaseException:success=False;print(traceback.format_exc(),flush=True)
        finally:case._outcome=old
        row=dict(id=case.id(),pendingBeforeOuter=pending,remaining=len(case._cleanups),success=success,errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],failures=[dict(id=t.id(),traceback=text)for t,text in drain.failures]);cleanup_rows.append(row)
        if not success or case._cleanups or drain.errors or drain.failures:cleanup_ok=False
    subject.tempfile=original_subject_tempfile;assert subject.tempfile is tempfile and tempfile.TemporaryDirectory is real_td
    for row in retained_rows:
        root=Path(row['path']);info=root.lstat();assert root.parent==TOYS and root.resolve(strict=True)==root and(info.st_dev,info.st_ino)==(row['device'],row['inode'])
    socket_ports.active=None;socket_ports.restore();socket_receipt=socket_ports.terminal();save('actual-socket-fd-drain.json',socket_receipt)
    boundary._check();first=census(TOYS);second=census(TOYS)
    pins_after={name:pin(name)for name in plan['sourceAndBinaryPins']};fd_after=fds();threads_after=tuple(threading.enumerate());children_after=children()
    passed=fatal is None and result is not None and result.testsRun==3 and result.wasSuccessful()and not result.skipped and cleanup_ok
    passed=passed and len(retained_rows)==3 and len(case_receipts)==3 and all(row['remainingStandardCleanups']==0 and row['fdUnchanged']and row['threadsUnchanged']and row['kernelChildrenUnchanged']for row in case_receipts)
    passed=passed and unittest.TestCase.doCleanups is original_cleanup and pins_after==plan['sourceAndBinaryPins']and fd_after==fd_before and threads_after==threads_before and children_after==children_before and first==second
    save('actual-toy-first.json',first);save('actual-toy-second.json',second);save('outer-cleanup.json',dict(success=cleanup_ok,cases=cleanup_rows))
    report=dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=None if result is None else result.testsRun,actualCaseReceipts=len(case_receipts),fatal=fatal,fdUnchanged=fd_before==fd_after,threadsUnchanged=threads_before==threads_after,kernelChildrenUnchanged=children_before==children_after,pinsUnchanged=pins_after==plan['sourceAndBinaryPins'],twoToyCensusesEqual=first==second,cleanupEstablished=cleanup_ok,retainedTemporaryDirectories=retained_rows,temporaryDirectoryAbsenceClaimed=False,NodeExecutions=0,childProcessBirths=0,SourceInstances=0,movingQualified=False,nativeQualified=False,wholeQualified=False)
    save('report.json',report)
    signal.signal(signal.SIGTERM,original_term);boundary.restore()
    restored=all(getattr(os,name)is value for name,value in original_ports.items())and original_io==(io.open,builtins.open)
    with boundary.original_io(RECEIPTS/'actual-port-restoration.json','x')as stream:stream.write(json.dumps(dict(restored=restored,count=len(original_ports),controlDescriptors=sorted(boundary.control_fds),dupPortsRestored=socket_receipt['dupPortsRestored']))+'\n')
    boundary.close();sys.meta_path[:]=original_meta;sys.path[:]=original_path
raise SystemExit(0 if passed and restored else 1)
