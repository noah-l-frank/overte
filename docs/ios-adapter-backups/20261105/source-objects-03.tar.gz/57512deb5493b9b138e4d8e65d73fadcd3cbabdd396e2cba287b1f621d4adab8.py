"""One fixed90+kill5 Root-owned passive attribution run, never a feature test."""
from pathlib import Path
import json,os,stat,subprocess,sys,tempfile,time
from profile_metadata import HERE,REPO,frozen,group,originals,pin,process,save,sources
value=frozen();approved=json.loads((HERE/'actual-source-map.json').read_text());ready_pin=pin(HERE/'actual-source-map.json')
assert approved['status']=='ACTUAL_CURRENT_DIAGNOSTIC_SOURCE_MAP'
assert not (HERE/'root-measure-report.json').exists() and not (HERE/'root-measure-first.log').exists(),'No unchanged repeat'
before=sources(value);assert before==approved['sourcePins'];old=originals(value)
save(HERE/'root-measure-source-before.json',before);save(HERE/'root-measure-originals-before.json',old)
runs=HERE/'runs';runs.mkdir(mode=0o700,exist_ok=True)
output=Path(tempfile.mkdtemp(prefix='first-',dir=runs));output.chmod(0o700)
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='tests/device:tests/device/self_tests:tests/device/ios/self_tests',OVERTE_WORLD6_CURRENT_MEMO_PROFILE_ROOT=str(output))
command=['timeout','--signal=TERM','--kill-after='+str(value['killAfterSeconds'])+'s',str(value['outerInitialSeconds'])+'s',sys.executable,str(HERE/'measure-saved-once.py')]
print('SOURCE_LAUNCHER_PINS',len(before),flush=True);started=time.monotonic()
with (HERE/'root-measure-first.log').open('x') as log:
    task=subprocess.Popen(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    binding=process(task.pid);assert binding is not None and binding['session']==task.pid and binding['processGroup']==task.pid
    save(HERE/'root-measure-process-binding.json',dict(supervisor=process(os.getpid()),task=binding,command=command))
    print('ACTUAL_PROCESS',json.dumps(binding,sort_keys=True),flush=True);code=task.wait()
after=sources(value);save(HERE/'root-measure-source-after.json',after)
def owned():
    found=group(task.pid,task.pid);runnerpath=output/'runner-process-binding.json'
    if runnerpath.exists():
        runner=json.loads(runnerpath.read_text());current=process(runner['pid'])
        if current is not None and current['startTicks']==runner['startTicks'] and current not in found:found.append(current)
    return found
remaining_before=owned();first=originals(value);save(HERE/'root-measure-originals-first.json',first)
second=originals(value);save(HERE/'root-measure-originals-second.json',second);remaining_after=owned()
result=dict(exitCode=code,seconds=time.monotonic()-started,outputRoot=str(output),sourcePins=len(after),allPinsEqual=before==after,
    readyMapUnchanged=pin(HERE/'actual-source-map.json')==ready_pin,all789OriginalsUnchanged=old==first==second,
    ownedProcessesBeforeCensuses=remaining_before,remainingOwnedProcesses=remaining_after,postStopCensusesQualified=not remaining_before and not remaining_after,
    diagnosticOnly=True,performanceQualified=False,profilerUsed=False,completeInstalledAPI25Closure=False,nativeExecuted=False,sdkExecuted=False,inputExecuted=False,wholeQualified=False)
save(HERE/'root-measure-report.json',result);print('ACTUAL_TERMINAL',json.dumps(result,sort_keys=True),flush=True)
assert before==after and pin(HERE/'actual-source-map.json')==ready_pin and old==first==second and not remaining_before and not remaining_after
raise SystemExit(code)
