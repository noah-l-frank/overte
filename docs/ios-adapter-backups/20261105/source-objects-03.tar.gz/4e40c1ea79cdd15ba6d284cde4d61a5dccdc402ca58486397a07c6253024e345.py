"""Root-only metadata assembler for four exact Scene/order host counters.

Imports only stdlib and the independently qualified strict metadata reader.
Nothing runs merely by importing this module; no SUT/Pillow import is made.
"""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
SOURCE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/chat-controller10d-exact-defused-et-transaction-source-private-20261104'
SUBJECT_SHA='fbcc253aebc8a11883bfebe4ffae10888351337e3e0f4092c477c4550c342f4b'
HELPER_SHA='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
QUALIFICATION=REPO/'.ios-host-tmp/root-c10c-source-execution-six-cache-mutation-alias-counters-qualified-results-20261104'
QUALIFICATION_SHA='8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a'
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript')


def load(path):return json.loads(Path(path).read_text())
def packet(folder,leaf,digest):
    path=folder/leaf;assert pin(path)['sha256']==digest
    result={str(path):pin(path)};value=load(path)
    for name,row in value['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        actual=folder/name;assert actual.resolve(strict=True)==actual
        expected=row if type(row)is str else row['sha256'];result[str(actual)]=pin(actual);assert result[str(actual)]['sha256']==expected
    return result


def project_namespace_admission(declared,ordered_roots):
    """Keep impossible aliases as pinned data; admit only real parent paths.

    Splitting a fullname produced from overte.sikuli/overte.py cannot create
    the nonexistent directories overte/sikuli. No namespace is invented and
    no bare alias or fallback loader is granted for such retained source.
    """
    choices={};failed={}
    for fullname in declared:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in declared:continue
            if name not in choices:
                choices[name]=sorted({str((Path(root)/Path(*parts[:size])).resolve(strict=True))
                    for root in ordered_roots if(Path(root)/Path(*parts[:size])).is_dir()})
            if len(choices[name])!=1:
                failed.setdefault(name,dict(physicalChoices=choices[name],affectedAliases=[]))['affectedAliases'].append(fullname)
    refused={}
    for name,row in failed.items():
        row['affectedAliases']=sorted(set(row['affectedAliases']))
        for fullname in row['affectedAliases']:
            entry=refused.setdefault(fullname,dict(origin=dict(declared[fullname]),unresolvableNamespaces=[]))
            entry['unresolvableNamespaces'].append(name)
    for row in refused.values():row['unresolvableNamespaces'].sort()
    admitted={name:row for name,row in declared.items()if name not in refused}
    namespaces={}
    for fullname in admitted:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in admitted:continue
            assert name not in refused and len(choices[name])==1
            namespaces[name]=choices[name]
    return admitted,namespaces,dict(version=1,declaredAliasCount=len(declared),
        admittedAliasCount=len(admitted),unadmittedAliases=refused,unresolvableNamespaces=failed,
        unadmittedSourcesRetainedAsData=True,unadmittedImportAuthority=False)


def main():
    p=argparse.ArgumentParser();p.add_argument('--source-freeze',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--destination',required=True,type=Path);args=p.parse_args()
    assert Path.cwd()==REPO and sys.dont_write_bytecode and sys.flags.no_site==1
    assert len(args.expected_head)==40 and all(c in'0123456789abcdef'for c in args.expected_head)and head()==args.expected_head
    physical=packet(SOURCE,'source-freeze.json',args.source_freeze);recipe=load(SOURCE/'SOURCE-RECIPE.json')
    previous5=REPO/'.ios-host-tmp/snapshot-scene-source1-ordered-source3-own4-bootstrap5-qualified-c10d-original-readiness-private-20261104'
    physical.update(packet(previous5,'source-freeze.json','9ccd59d94fe0403306e733ed7e66771b15e00a9c1d25ff16f2966920917dbb21'))
    negative5=REPO/'.ios-host-tmp/root-snapshot-scene-own4-b5-two-pass-stale-after-actor-negative-results-20261104'
    physical.update(packet(negative5,'freeze.json','3a66fb7acfb91f7683cee0f91d1e4152fdfe7c395954bc56bf2d9098ed2c080b'))
    actual5_refs=load(negative5/'actual-receipt-references.json');assert len(actual5_refs)==216
    for row in actual5_refs.values():
        path=Path(row['path']);before=pin(path);assert before['sha256']==row['sha256'];physical[str(path)]=before
    changed_fixture=recipe['changedLostReturnFixture']
    assert changed_fixture=={'module': 'ios.self_tests.test_ios_snapshot_scene_capture_order', 'sourceRoot': '/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/snapshot-scene-lost-return-independent-render-event-source5-private-20261104', 'logicalPath': 'tests/device/ios/self_tests/test_ios_snapshot_scene_capture_order.py', 'sha256': '7217851e48d98a037d2d4cf4778437e297d49ce6136abd15133ae885e6720951', 'previousSourceSha256': '619be8ead5627ba5e89957352761a050db77321cc43b0d06d0eb5606472f8b2e', 'sourceFreeze': '7740672c2eec1a86a5c1c1744b9d18bebbfe499a26d64e2194bebb9ad83a0b6b'}
    previous4=REPO/'.ios-host-tmp/snapshot-scene-source1-ordered-source3-own4-bootstrap4-exact-operation-wrapper-original-refusal-private-20261104'
    physical.update(packet(previous4,'source-freeze.json','dd2a0815b6dac44e2deb66376bd5cb66e6df2f14f4abb58ac7d0b03fe9a9929f'))
    negative4=REPO/'.ios-host-tmp/root-snapshot-scene-own4-b4-actual-elementtree-receiver-negative-results-20261104'
    physical.update(packet(negative4,'freeze.json','91c3c2ea6d02afeaa6af085031875063ab2ca1d759c4221b849711ae472767e7'))
    for row in load(negative4/'actual-receipt-references.json').values():
        path=Path(row['path']);assert pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
    previous3=REPO/'.ios-host-tmp/snapshot-scene-source1-ordered-source3-own4-bootstrap3-contextlib-chain-original-refusal-private-20261104'
    physical.update(packet(previous3,'source-freeze.json','81a13512b0ca05426ab5c66285940ac2a0a8bbdd2a84f0fa3c0c74e062004c6e'))
    operation_peer=REPO/'.ios-host-tmp/lifecycle-independent-snapshot-first4-bootstrap3-wrapper-and-negative-origin-review-20261104'
    physical.update(packet(operation_peer,'freeze.json','3f68b29e4cb25ef14ee9b66f1f042cc28d37ea0599413d642c73087ec9b1d3be'))
    previous2=REPO/'.ios-host-tmp/snapshot-scene-source1-ordered-source3-own4-bootstrap2-real-namespace-code-preparation-20261104'
    physical.update(packet(previous2,'source-freeze.json','dc9a9fb6275fc8a3de8bafe0406f0ddd4cbfd6b90e439475e3aebe8e725634d2'))
    refusal=load(SOURCE/'ACTUAL-B2-CLOSED-REFUSAL-REFERENCES.json')
    for name,row in refusal.items():
        path=Path(name);physical[str(path)]=pin(path);assert physical[str(path)]['sha256']==row['sha256']
    previous=REPO/'.ios-host-tmp/snapshot-scene-source1-ordered-source3-own4-bootstrap1-c10c-code-preparation-20261104'
    physical.update(packet(previous,'source-freeze.json','3952e982055a8b2ddbf931268911662f2085753d8e83a86858afb74db7b700cc'))
    namespace_source=REPO/'.ios-host-tmp/assets-picker3-reserved-phase-controller18-real-namespace-alias-admission-source-private-20261104'
    physical.update(packet(namespace_source,'source-freeze.json','632fd9563b63356e559b69680766306dd2a74a8c77a8105614ecc686667a5b43'))
    assert recipe['caseCount']==4 and recipe['wallSeconds']==180 and recipe['killGraceSeconds']==5
    assert recipe['expectedTemporaryDirectoriesPerCase']==2 and recipe['expectedTemporaryDirectories']==8
    physical.update(packet(SUBJECT,'source-freeze.json',SUBJECT_SHA));assert pin(SOURCE/'closed_import_origins.py')['sha256']==HELPER_SHA
    physical.update(packet(QUALIFICATION,'freeze.json',QUALIFICATION_SHA)) # Historical C10c, not current helper authority.
    current_readiness,current_readiness_pins=qualification(pin);physical.update(current_readiness_pins)
    actual_refs=load(QUALIFICATION/'actual-receipt-references.json')
    for row in actual_refs.values():
        path=Path(row['path']);assert pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
    prior=REPO/'.ios-host-tmp/snapshot-ordinary-provenance-own9-bootstrap3-complete-root-input-pin-code-preparation-20261104'
    physical.update(packet(prior,'source-freeze.json','5e1c9f388f635b086aefa7127d5792dffd376dc5ec829aafde643af4f2030210'))
    own6=REPO/'.ios-host-tmp/chat-c10c-source-execution-own6-bootstrap2-outcome-custody-code-preparation-20261104'
    physical.update(packet(own6,'source-freeze.json','1df80b4b1597a4c2e896cc234ab20ea34f12b4529924ce7175d5fe61af80b681'))
    overlays={}
    for row in recipe['packets']:
        folder=Path(row['path']);physical.update(packet(folder,'source-freeze.json',row['sha256']))
        if str(folder)not in recipe['activeCandidatePackets']:continue
        candidates=load(folder/'CANDIDATES.json')
        for logical,item in candidates.items():
            source=folder/'candidate'/logical;assert pin(source)['sha256']==item['sha256'];physical[str(source)]=pin(source)
            if source.suffix!='.py':continue
            parts=Path(logical).relative_to('tests/device').with_suffix('').parts;name='.'.join(parts)
            if name in overlays:
                # Exactly one evidenced prospective test replaces its old
                # physical definition; all production/domain origins stay old.
                assert name==changed_fixture['module'] and str(folder)==changed_fixture['sourceRoot']
                assert logical==changed_fixture['logicalPath'] and item['sha256']==changed_fixture['sha256']
                assert overlays[name]['sha256']==changed_fixture['previousSourceSha256']
                assert physical[overlays[name]['path']]['sha256']==changed_fixture['previousSourceSha256']
            overlays[name]=dict(path=str(source),sha256=item['sha256'],package=False)
    assert len(overlays)==15
    assert overlays[changed_fixture['module']]==dict(path=str(Path(changed_fixture['sourceRoot'])/'candidate'/changed_fixture['logicalPath']),sha256=changed_fixture['sha256'],package=False)
    # Preserve actual historical public originals while independently admitting
    # CURRENT public definitions. Old native21 bytes are not runtime authority.
    public=set()
    for name in ROOTS:
        root=REPO/name;assert root.resolve(strict=True)==root and root.is_dir()
        for path in root.rglob('*'):
            assert not path.is_symlink()
            if path.is_file():public.add(path)
    for path in public:physical[str(path)]=pin(path)
    modules={};ambiguous={};ordered_roots=(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests')
    for root in ordered_roots:
        for path in sorted(root.rglob('*.py')):
            parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
            if package:parts.pop()
            if not parts:continue
            name='.'.join(parts);row=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=package)
            if name in ambiguous:
                if row not in ambiguous[name]:ambiguous[name].append(row)
            elif name in modules and modules[name]!=row:ambiguous[name]=[modules.pop(name),row]
            else:modules[name]=row
    assert set(ambiguous)=={'test_appium_adapter','test_voice_roundtrip'}
    for name,row in overlays.items():modules[name]=row
    # Every source has been physically pinned before any alias is narrowed.
    # No nonexistent split spelling may become an import namespace.
    modules,namespaces,alias_admission=project_namespace_admission(modules,ordered_roots)
    assert all(name in modules and modules[name]==row for name,row in overlays.items())
    external=load(SOURCE/'third-party-source-declarations.json');assert len(external)==31
    third={}
    for name,row in external.items():
        path=Path(row['path']);assert pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
        assert row['kind']in('python','extension')
        third[name]=dict(path=str(path),sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    std=Path(os.__file__).resolve(strict=True).parent;suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);std_namespaces={}
    for current,dirs,files in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink())
        relative=folder.relative_to(std)
        if relative.parts and all(part.isidentifier()for part in relative.parts)and not(folder/'__init__.py').is_file():std_namespaces['.'.join(relative.parts)]=[str(folder)]
        for name in files:
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(suffixes):continue
            assert path.resolve(strict=True)==path;physical[str(path)]=pin(path)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    gd=Path((REPO/'.git').read_text().split('gitdir: ',1)[1].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(path)]=pin(path)
    refpath=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs');physical[str(refpath)]=pin(refpath)
    destination=args.destination
    assert destination.is_absolute()and destination.resolve(strict=False)==destination and destination.parent==REPO/'.ios-host-tmp'
    assert destination.name.startswith('snapshot-scene-own4-prepared-')and not destination.exists()
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    destination.mkdir(mode=0o700)
    names=('run-own4.py','supervise-own4.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','readonly-shared-stdlib-sources.json','exact-four-selectors.json','source_execution_readiness.py')
    for name in names:
        target=destination/name;fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(target)]=pin(target)
    for name in('metadata_reader','host_common','closed_import_origins','owned_write_boundary','source_execution_readiness'):
        path=destination/(name+'.py');assert name not in modules
        modules[name]=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=False)
    declared=dict(modules)
    for name,row in alias_admission['unadmittedAliases'].items():
        assert name not in declared;declared[name]=row['origin']
    modules,final_namespaces,alias_admission=project_namespace_admission(declared,ordered_roots)
    assert final_namespaces==namespaces and all(modules[name]==row for name,row in overlays.items())
    cases=load(SOURCE/'exact-four-selectors.json');assert cases==recipe['cases']and len(cases)==len(set(cases))==4
    origin=dict(modules=modules,namespacePackages=namespaces,projectAliasAdmission=alias_admission,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=std_namespaces,
        stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='PRIVATE_SNAPSHOT_SCENE_SOURCE1_ORDERED_SOURCE3_OWN4_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(destination),actualPublicHead=args.expected_head,
        projectAliasAdmission=alias_admission,sourceFreeze=args.source_freeze,sourceAndBinaryPins=physical,modules=modules,namespaces=namespaces,thirdPartyModules=third,originPlan=origin,
        subjectOriginModules={name:dict(path=row['path'],sha256=row['sha256'])for name,row in overlays.items()},subjectOriginCount=15,
        changedLostReturnFixture=changed_fixture,actualB5NegativePreserved=True,priorB5Qualification=False,
        cases=cases,wallSeconds=180,killGraceSeconds=5,expectedTemporaryDirectories=8,expectedTemporaryDirectoriesPerCase=2,
        subjectOriginalPath=str(SUBJECT/'closed_import_origins.py'),subjectActualCopiedPath=str(destination/'closed_import_origins.py'),subjectHelperSha256=HELPER_SHA,
        NodeExecutions=0,SDKExecutions=0,physicalNativeQueries=0,declaredModelNativeObservationsAllowed=True,realNetwork=False,oldCorpusInputs=0,globalOriginalScans=0,
        helperQualificationOriginalReferenceCount=141,qualifiedSourceExecution=current_readiness,helperQualificationRequiredOriginalRooms=current_readiness['requiredOriginalRoots'],externalRootGuardMustIncludeAllHelperOriginalRooms=True,helperQualificationIsNotSnapshotQualification=True,oldOrdinaryEightOriginsAreNotNewFifteenQualification=True,
        ambiguousPublicAliasRows=ambiguous,ambiguousPublicAliasesExcluded=sorted(ambiguous),hostBootstrapScope='Held original interpreter/stdlib and fresh private entry/controller definitions are trusted HOSTBOOTSTRAP; delegated SUT/PIL/stdlib Python executes fresh pinned bytes through exact current C10d69093; historical C10c remains separate.',
        nativeCompiled=False,nativeQualified=False,wholeQualified=False)
    output=destination/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),inputSha256=pin(output)['sha256'],sourcePins=len(physical),cases=4,TDs=8,Node=0,targets=0,globalScans=0)))
    return 0


if __name__=='__main__':raise SystemExit(main())
