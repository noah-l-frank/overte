"""Versioned native original on the EXISTING native observation artifact.

No command echo is an observation. The real native return is AFC-pulled from
feature-native-observation.json; old default packets remain untouched. This
reader has no Stop/SDK/delete authority and no automatic command retry.
"""
from copy import deepcopy
import json,time,uuid
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,integer,need,number
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import pack,unpack,same
from ios.adapters.feature_observation import FeatureObservation,send_original_command
from ios.adapters.emote_palette_file_original import decode_file_original,ACTION,FILE,_hex,_nonce
from ios.adapters.emote_observer import EmoteObservationPending

RESPONSE_FILE='feature-native-observation.json'
LIMIT=262144


def command(value):
    operation=value.get('operation');need(operation in('observe','retire'))
    exact(value,{'schemaVersion','commandId','action','operation','runId'}|({'ownerInstance','generation','paletteRequestId'}if operation=='retire'else set()))
    need(type(value['schemaVersion'])is int and value['schemaVersion']==1 and value['action']==ACTION)
    _nonce(value['commandId']);_hex(value['runId'])
    if operation=='retire':_hex(value['ownerInstance']);_nonce(value['paletteRequestId']);need(integer(value['generation'],1,1000000000))
    return value


def delivery(value,query,binding,previous=None):
    command(query);exact(value,{'iosEmotePaletteFileDeliveryVersion','requestId','runId','responseFile','original'})
    need(type(value['iosEmotePaletteFileDeliveryVersion'])is int and value['iosEmotePaletteFileDeliveryVersion']==1
        and value['requestId']==query['commandId']and value['runId']==query['runId']and value['responseFile']==RESPONSE_FILE
        and len(json.dumps(value,allow_nan=False).encode())<=LIMIT)
    decode_file_original(value['original'],query,binding,None if previous is None else previous['original'])
    return deepcopy(value)


def decoded(raw):
    need(type(raw)is str and 0<len(raw.encode())<=LIMIT)
    def pairs(rows):
        out={}
        for key,value in rows:need(key not in out);out[key]=value
        return out
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:need(False))


class PaletteFileDelivery:
    """Actual FeatureObservation port + immutable WAL/OFS, never a live facade."""
    def __init__(self,observer,store,root,binding,run,lock,clock_ms,guard,*,monotonic=time.monotonic,epoch_ms=lambda:time.time()*1000,sleep=time.sleep):
        need(type(observer)is FeatureObservation and isinstance(store,PrivateFeatureState)
            and all(callable(v)for v in(clock_ms,guard,monotonic,epoch_ms,sleep)))
        self.observer,self.store,self.root,self.lock=observer,store,root,lock
        self.binding=deepcopy(context(binding));self.run=run;_hex(run)
        self.clock_ms,self.guard,self.monotonic,self.epoch_ms,self.sleep=clock_ms,guard,monotonic,epoch_ms,sleep
        need(store.path==lock.path.with_name('ios-emote-primary-'+run+'-palette-file-delivery.json'))
        need(observer.session==self.binding['sessionId']);self.failed=False
        self.remote=observer.remote.rsplit('/',1)[0]+'/'+RESPONSE_FILE
        self.frames=OriginalFrameStore(root,self.binding,run,'primary',self.bound,self.intent,
            namespace='emote-palette-file-delivery',schema_prefix='emotePaletteFileDelivery',kind='inputs',monotonic=monotonic)
        self.previous=store.read();self.state=dict(records=[],pending=None)if self.previous is None else self.decode(self.previous)
        self.bound()
    def envelope(self,state):return dict(iosEmotePaletteFileDeliveryJournalVersion=1,runId=self.run,binding=self.binding,payload=pack([state]))
    def decode(self,value):
        exact(value,{'iosEmotePaletteFileDeliveryJournalVersion','runId','binding','payload'});rows=unpack(value['payload'])
        need(type(value['iosEmotePaletteFileDeliveryJournalVersion'])is int and value['iosEmotePaletteFileDeliveryJournalVersion']==1
            and len(rows)==1 and same(value,self.envelope(rows[0])))
        state=rows[0];exact(state,{'records','pending'});need(type(state['records'])is list and len(state['records'])<=8)
        for index,ref in enumerate(state['records'],1):self.frames.expand(ref);need(ref['index']==index)
        if state['pending']is not None:
            exact(state['pending'],{'query','hostBeforeEpochMs','hostBeforeMonotonic','nativeBeforeEpochMs','storage'})
            command(state['pending']['query']);need(state['pending']['query']['runId']==self.run)
            if state['pending']['storage']is not None:
                self.frames.original(state['pending']['storage']);need(state['pending']['storage']['index']==len(state['records'])+1)
        return deepcopy(state)
    def bound(self):
        self.lock.assert_held();need(not self.failed and same(self.store.read(),self.previous)and self.guard()is not False)
        return True
    def save(self):
        self.bound();value=self.envelope(self.state);self.decode(value)
        try:self.store.write(value,self.previous);need(same(self.store.read(),value));self.previous=deepcopy(value)
        except Exception:self.failed=True;raise
    def intent(self,event,wire):
        self.bound();need(event=='original'and self.state['pending']is not None and wire['index']==len(self.state['records'])+1)
        self.frames.original(wire);old=self.state['pending']['storage']
        if old is None:need(wire['phase']=='planned')
        else:need((old['phase'],wire['phase'])in(('planned','opened'),('opened','saved'))and all(same(wire[k],old[k])for k in wire if k not in('phase','file'))and(old['file']is None or same(old['file'],wire['file'])))
        self.state['pending']['storage']=deepcopy(wire);self.save()
    def original(self,ref,previous=None):
        value=self.frames.read(self.frames.expand(ref));exact(value,{'query','delivery','acquisition'})
        delivery(value['delivery'],value['query'],self.binding,previous)
        acq=value['acquisition'];exact(acq,{'hostBeforeEpochMs','hostAfterEpochMs','hostBeforeMonotonic','hostAfterMonotonic','nativeBeforeEpochMs','nativeAfterEpochMs'})
        h=acq['hostAfterEpochMs']-acq['hostBeforeEpochMs'];m=(acq['hostAfterMonotonic']-acq['hostBeforeMonotonic'])*1000
        need(all(number(v,0,10**15)for v in acq.values())and 0<=h<1500 and 0<=m<1500 and abs(h-m)<=250)
        raw=value['delivery']['original'];need(acq['nativeBeforeEpochMs']<=raw['clockBefore']['epochMs']<=raw['clockAfter']['epochMs']<=acq['nativeAfterEpochMs']
            and 0<=acq['nativeAfterEpochMs']-acq['nativeBeforeEpochMs']<1500 and abs(acq['nativeAfterEpochMs']-acq['nativeBeforeEpochMs']-h)<=250)
        return value
    def request(self,operation='observe',*,owned=None):
        self.bound();need(self.state['pending']is None and len(self.state['records'])<8)
        query=dict(schemaVersion=1,commandId='ios-'+uuid.uuid4().hex,action=ACTION,operation=operation,runId=self.run)
        if operation=='retire':
            need(self.state['records']);prior=self.original(self.state['records'][-1])['delivery']['original']['source']['ownership']
            need(prior['phase']=='owned'and same(owned,prior))
            query.update(ownerInstance=prior['instance'],generation=prior['generation'],paletteRequestId=prior['file']['palette']['requestId'])
        command(query)
        if self.state['records']:need(self.original(self.state['records'][-1])['delivery']['original']['source']['ownership']['retirementIssued']is False)
        # Original clock query precedes the durable new fixed-file command.
        native=self.clock_ms();self.bound();self.observer.guard()
        need(self.observer.process['pid']==int(self.binding['processIdentity']))
        self.state['pending']=dict(query=deepcopy(query),hostBeforeEpochMs=self.epoch_ms(),hostBeforeMonotonic=self.monotonic(),nativeBeforeEpochMs=native,storage=None);self.save()
        send_original_command(self.observer.origin,query,4096,before_send=self.bound,after_send=self.bound)
        return self.recover()
    def recover(self):
        self.bound();pending=self.state['pending'];need(pending is not None);query=pending['query'];previous=None
        if self.state['records']:previous=self.original(self.state['records'][-1])['delivery']
        wire=pending['storage']
        if wire is not None:
            # Only complete actual opened/saved OFS can recover. Never finish
            # an empty opened inode from an expected packet or replay query.
            need(wire['phase']in('opened','saved'));body=self.frames.read(wire)
            need(same(body['query'],query));delivery(body['delivery'],query,self.binding,previous);ref=self.frames.compact(dict(wire,phase='saved'))
        else:
            value=None
            for _ in range(31):
                need(0<=self.monotonic()-pending['hostBeforeMonotonic']<1.5)
                raw=self.observer.original(remote=self.remote,limit=LIMIT)
                if raw:
                    item=decoded(raw)
                    if type(item)is dict and item.get('requestId')==query['commandId']:
                        value=delivery(item,query,self.binding,previous);break
                self.sleep(.05)
            if value is None:raise EmoteObservationPending('Original native file result remains unknown; request is not replayable')
            self.bound();native=self.clock_ms();self.bound()
            acquisition={key:pending[key]for key in('hostBeforeEpochMs','hostBeforeMonotonic','nativeBeforeEpochMs')}
            acquisition.update(hostAfterEpochMs=self.epoch_ms(),hostAfterMonotonic=self.monotonic(),nativeAfterEpochMs=native)
            body=dict(query=deepcopy(query),delivery=value,acquisition=acquisition)
            # Actual raw result goes to OFS only; PFS keeps the original intent.
            ref=self.frames.write(len(self.state['records'])+1,body)
        self.original(ref,previous);self.state['records'].append(deepcopy(ref));self.state['pending']=None;self.save()
        return self.original(ref,previous)
    def responsibility(self):
        self.bound();return dict(responseFile=RESPONSE_FILE,responseCreatorRole='primary',responseProcessLifetimeRequired=True,
            pending=deepcopy(self.state['pending']),records=deepcopy(self.state['records']),nativeFile=FILE,
            metadataRetirementAllowed=False,EndAllowed=False)


def from_runtime(primary):
    """Actual current Profile9 -> existing installed source -> real ports."""
    from ios.adapters.emote_callback_terminal import IOSEmotePostControllerCallbackFeature
    from ios.adapters.emote_runtime import IOSEmoteRuntime
    need(type(primary)is IOSEmotePostControllerCallbackFeature and primary.role=='primary'
        and type(primary.runtime)is IOSEmoteRuntime)
    primary.lock.assert_held();primary.load();need(primary.state is not None)
    selected=primary.runtime._sources(primary.selector)
    need(same(selected['binding'],primary.state['binding'])and same(selected['binding'],primary.state['primaryBinding']))
    return PaletteFileDelivery(selected['observer'],PrivateFeatureState(primary.lock.path.with_name(
        'ios-emote-primary-'+primary.run+'-palette-file-delivery.json')),primary.root,selected['binding'],primary.run,
        primary.lock,selected['native_clock'],selected['check'],monotonic=primary.monotonic,epoch_ms=primary.epoch_ms,sleep=primary.sleep)


class PaletteFileHistory:
    """Explicit readonly historical constructor, valid after creator stop.

    This object is not a PaletteFileDelivery/live observer. It only delegates
    its closed envelope/record grammar and has no send/recover/request API.
    """
    def __init__(self,store,root,binding,run,lock):
        from ios.adapters.emote_original_lease import EmoteOriginalLease
        need(isinstance(store,PrivateFeatureState));self.store,self.lock=store,lock
        self.root,self.binding,self.run=root,deepcopy(context(binding)),run;_hex(run);lock.assert_held()
        need(store.path==lock.path.with_name('ios-emote-primary-'+run+'-palette-file-delivery.json'))
        self.previous=store.read();need(self.previous is not None)
        self.signature=EmoteOriginalLease.signature(store.path.lstat())
        def forbidden(*_args):need(False)
        self.frames=OriginalFrameStore(root,self.binding,run,'primary',self.bound,forbidden,
            namespace='emote-palette-file-delivery',schema_prefix='emotePaletteFileDelivery',kind='inputs')
        self.state=PaletteFileDelivery.decode(self,self.previous)
        need(self.state['pending']is None and self.state['records'])
        prior=None
        for ref in self.state['records']:
            prior=self.original(ref,prior)['delivery']
        self.bound()
    def envelope(self,state):return PaletteFileDelivery.envelope(self,state)
    def bound(self):
        from ios.adapters.emote_original_lease import EmoteOriginalLease
        self.lock.assert_held();need(same(self.store.read(),self.previous)
            and EmoteOriginalLease.signature(self.store.path.lstat())==self.signature)
        return True
    def original(self,ref,previous=None):
        self.bound();need(ref in self.state['records'])
        return PaletteFileDelivery.original(self,ref,previous)
