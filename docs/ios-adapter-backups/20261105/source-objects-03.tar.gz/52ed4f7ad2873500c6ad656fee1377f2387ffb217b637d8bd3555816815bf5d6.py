"""Exact Audio Primary scope admission after original End, before new SDK.

The retired process's immutable child originals stay in place. Readmission
creates no media absence and cannot be obtained from a caller-supplied DTO.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same

_ACTIVE=ContextVar('ios_audio11_original_end_readmission',default=None)

class IOSAudioWholeRetiredScope:
    def __init__(self,flow):
        from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
        need(type(flow) is IOSAudioWholeFeature and flow.role=='primary')
        for lock in flow.locks:lock.assert_held()
        self.flow=flow;self.store=PrivateFeatureState(flow.adapter.state_path(flow.primary_selector).with_name('ios-audio11-scope-retirement.json'))
        self.original=self.store.read();self.end=None

    def capture(self):
        f=self.flow;need(f.state['phase']=='cleaning' and f.state['pending'] is None)
        f.validate_restoration()
        from ios.adapters.audio_whole_inventory import primary
        owner=primary(f);need(owner is not None and owner.state['pending'] is owner.state['observation'] is None)
        from ios.adapters.audio_pcm_lease import IOSAudioPCMLease
        pcm=[]
        for name in ('ios-audio-pcm-lease.json','ios-audio-close-lease.json'):
            store=PrivateFeatureState(owner.store.path.with_name(name))
            if store.read() is not None:
                lease=IOSAudioPCMLease.archive_retired(store,owner) if owner.state['pending'] is not None or owner.state['observation'] is not None else IOSAudioPCMLease.archive(store,owner);retired=lease.retired();pcm.append(dict(store=str(store.path),ownerSha256=digest(store.read()),absence=retired['absence']))
        value=dict(iosAudio11RetiredScopeVersion=1,runId=f.run,binding=deepcopy(f.state['bindings']['primary']),settings=deepcopy(f.config),
            ownerSha256=digest(owner.previous),currentStoreSha256=digest(f.current(historical=True,stage='initial').previous),baseline=deepcopy(f.state['baseline']),
            restoration=deepcopy(f.state['restoration']),pcm=pcm)
        if self.original is None:self.store.write(value,None);self.original=self.store.read()
        need(same(self.original,value));return deepcopy(value)

    def readmission_original(self,old_end):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
        f=self.flow;need(type(old_end) is IOSOriginalKeeperProcessEnd and old_end.runtime.adapter is f.adapter and old_end.selector==f.primary_selector
            and old_end.lock is f.locks[1] and old_end.role=='primary' and old_end.profile_key=='audiowhole' and old_end.stage==0)
        proof=old_end.retirement_original();need(proof['resourceRetirementEstablished'] is True)
        IOSOriginalKeeperProcessEnd.archived_original(proof,store=old_end.store,root=old_end.root,binding=old_end.binding,run=f.run,role='primary',stage=0,profile_key='audiowhole',lock=f.locks[1])
        need(self.original is not None and same(self.store.read(),self.original) and same(self.original['binding'],proof['binding']) and self.original['runId']==f.run and same(self.original['settings'],f.config))
        from ios.adapters.audio_whole_inventory import primary
        owner=primary(f);need(owner is not None and digest(owner.previous)==self.original['ownerSha256'])
        current=f.current(historical=True,stage='initial');need(digest(current.previous)==self.original['currentStoreSha256'])
        need(same(f.state['baseline'],self.original['baseline']) and same(f.state['restoration'],self.original['restoration']))
        for row in self.original['pcm']:
            from ios.adapters.audio_pcm_lease import IOSAudioPCMLease
            need(row['store'] in {str(owner.store.path.with_name(name)) for name in ('ios-audio-pcm-lease.json','ios-audio-close-lease.json')})
            store=PrivateFeatureState(row['store']);need(digest(store.read())==row['ownerSha256'])
            lease=IOSAudioPCMLease.archive_retired(store,owner) if owner.state['pending'] is not None or owner.state['observation'] is not None else IOSAudioPCMLease.archive(store,owner);need(lease.retired()['absence']==row['absence'])
        # Full per-file custody is revalidated by the feature inventory at the
        # entry boundary. This exact retained scope never sweeps old files.
        self.end=old_end
        return dict(iosAudio11ReadmissionScopeVersion=1,runId=f.run,binding=deepcopy(old_end.binding),retiredScopeSha256=digest(self.original),
            retiredScopeStore=str(self.store.path),oldEndArchiveSha256=proof['archiveSha256'],primaryOwnerSha256=self.original['ownerSha256'],
            currentStoreSha256=self.original['currentStoreSha256'],settingsSha256=digest(f.config))

    def guard_readmission(self,original):
        need(self.end is not None and same(self.readmission_original(self.end),original))
        from ios.adapters.audio_whole_inventory import admit
        admit(self.flow,skip_readmission=True)
        return True

    @contextmanager
    def admitted_readmission(self,original,*,owner):
        from ios.adapters.original_keeper_readmission import IOSOriginalKeeperReadmission
        need(type(owner) is IOSOriginalKeeperReadmission and owner.scope is self and owner.old_end is self.end
            and owner.lock is self.flow.locks[1] and owner.runtime.adapter is self.flow.adapter and owner.selector==self.flow.primary_selector)
        owner.bound();self.guard_readmission(original);token=_ACTIVE.set((self,deepcopy(original),owner))
        try:
            yield
            self.guard_readmission(original)
        finally:_ACTIVE.reset(token)


def admitted(adapter,selector):
    active=_ACTIVE.get()
    if active is None:return False
    scope,original,owner=active;need(type(scope) is IOSAudioWholeRetiredScope and scope.flow.adapter is adapter and scope.flow.primary_selector==selector)
    owner.bound();scope.guard_readmission(original);return True
