"""Future explicit Publisher2 metadata assembly only; no global/raw scan."""
from pathlib import Path
import hashlib,json,stat,sys
REPO=Path.cwd().resolve(strict=True);SOURCE=Path(__file__).resolve().parent
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode

def pin(path):
    path=Path(path);a=path.lstat();assert path.resolve(strict=True)==path and stat.S_ISREG(a.st_mode)
    raw=path.read_bytes();b=path.lstat();fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    row=dict(stat=[getattr(a,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest());assert row['stat']==[getattr(b,key)for key in fields];return row

def check_packet(path,sha):
    assert pin(path)['sha256']==sha;return json.loads(path.read_text())

def main():
    assert len(sys.argv)==3,'new private Publisher2 controller path plus independent source-freeze SHA required'
    dest=Path(sys.argv[1]);assert dest.is_absolute()and dest.resolve().is_relative_to(REPO)and not dest.exists()
    own=check_packet(SOURCE/'source-freeze.json',sys.argv[2])
    for name,row in own['files'].items():assert pin(SOURCE/name)['sha256']==row['sha256']
    base=REPO/'.ios-host-tmp/lifecycle-publisher-refusal-controller5-source4-utility-roots-final-preparation-20261103'
    frozen=check_packet(base/'freeze.json','a58a0d916c40163e9d9ee126a04807da7658a230d8809c64991d89cb8845b570')
    # Exact source-origin metadata only. No global corpus/history row is opened.
    for name in('module-origins.json','immutable-source-pins.json'):
        expected=frozen['files'][name];expected=expected['sha256']if type(expected)is dict else expected
        assert pin(base/name)['sha256']==expected
    origins=json.loads((base/'module-origins.json').read_text());old=json.loads((base/'immutable-source-pins.json').read_text())
    modules={name:dict(path=path)for name,path in origins['modules'].items()}
    original_modules=dict(modules)
    for row in modules.values():assert pin(row['path'])==old[row['path']]
    sparse=REPO/'.ios-host-tmp/lifecycle-post-acquisition-sparse-host-phases-source2-private-20261103'
    split=REPO/'.ios-host-tmp/lifecycle-sparse-eight-separated-counter-source-preparation-20261103'
    sparse_frozen=check_packet(sparse/'freeze.json','7fc244b8e9f73dd6536c6f25400521ed5cd48eb8d40588cf64782eb2025b9db5')
    split_frozen=check_packet(split/'source-freeze.json','46bfc9e3969aa4350f1d1ba47952a867ff8ae1f287c495c4857a2746832ecf16')
    for module,relative in(('adapters.phase_witness_publisher','adapters/phase_witness_publisher.py'),):
        candidate=sparse/'candidate/tests/device'/relative
        expected=sparse_frozen['files']['candidate/tests/device/'+relative]
        expected=expected['sha256']if type(expected)is dict else expected
        assert pin(candidate)['sha256']==expected
        modules[module]=dict(path=str(candidate))
    assert pin(split/'test_lifecycle_sparse_publisher_two.py')['sha256']==split_frozen['files']['test_lifecycle_sparse_publisher_two.py']['sha256']
    modules['test_lifecycle_sparse_publisher_two']=dict(path=str(split/'test_lifecycle_sparse_publisher_two.py'))
    sink=REPO/'.ios-host-tmp/lifecycle-publisher-refusal-local-original-diagnostic-source-proposal-20261103'
    sink_frozen=check_packet(sink/'freeze.json','6adcbc02b52993421de09c14bb6270cc4f746abb2e35700676c49a96e2c86e7c')
    sink_path=sink/'candidate/tests/device/adapters/phase_publication_refusal_original.py'
    expected=sink_frozen['files']['candidate/tests/device/adapters/phase_publication_refusal_original.py']
    expected=expected['sha256']if type(expected)is dict else expected
    assert pin(sink_path)['sha256']==expected
    modules['adapters.phase_publication_refusal_original']=dict(path=str(sink_path))
    host=REPO/'.ios-host-tmp/lifecycle-moving-primary-first1-original-host-resolver-controller3-code-preparation-20261103'
    host_frozen=check_packet(host/'source-freeze.json','5e872a97d32ec5805440bd89618b53d11af3750cbea51f5a03158ee85c6e1a1e')
    assert pin(host/'moving_host_ports.py')['sha256']==host_frozen['files']['moving_host_ports.py']['sha256']
    modules['controller_original_host_ports']=dict(path=str(host/'moving_host_ports.py'))
    modules['publisher_host_custody']=dict(path=str(SOURCE/'publisher_host_custody.py'))
    modules['publisher_journal_encoding']=dict(path=str(SOURCE/'publisher_journal_encoding.py'))
    modules['publisher_retained_roots']=dict(path=str(REPO/'tests/device/ios/self_tests/retained_host_roots.py'))
    helper=REPO/'.ios-host-tmp/audio-own14-canonical-fd-supervisor4-source-private-20261103/owned_write_boundary.py'
    assert pin(helper)['sha256']=='156560033c0c292aa72be6cd66af136683de28490341dceacc191398b5167bda'
    modules['publisher_owned_writes']=dict(path=str(helper))
    paths={Path(row['path'])for row in original_modules.values()}|{Path(row['path'])for row in modules.values()}|{Path(sys.executable).resolve(strict=True),base/'freeze.json',base/'module-origins.json',base/'immutable-source-pins.json',sparse/'freeze.json',split/'source-freeze.json',SOURCE/'source-freeze.json'}
    for name in own['files']:paths.add(SOURCE/name)
    paths.update(Path('/usr/lib64/python3.14')/name for name in('socket.py','socketserver.py','http/server.py','http/client.py','tempfile.py','unittest/case.py'))
    paths.update((host/'source-freeze.json',sink/'freeze.json'))
    retained=REPO/'tests/device/ios/self_tests/retained_host_roots.py';assert pin(retained)==old[str(retained)]
    before={str(path):pin(path)for path in paths}
    assert dest.resolve().is_relative_to(REPO);dest.mkdir(mode=0o700)
    for name in('run-publisher2.py','supervise-publisher2.py'):
        target=dest/name;assert target.resolve().is_relative_to(REPO)and not target.exists();target.write_bytes((SOURCE/name).read_bytes());before[str(target)]=pin(target)
    body=dict(status='UNRUN_REQUIRES_ROOT_REVIEW',repositoryRoot=str(REPO),controllerRoot=str(dest),modules=modules,namespaces=origins['namespaces'],
        sourceAndBinaryPins=before,cases=['test_lifecycle_sparse_publisher_two.LifecycleSparsePublisherRefusalBoundaryTests.test_actual_expired_original_stays_refused_with_default_none_and_no_post',
            'test_lifecycle_sparse_publisher_two.LifecycleSparsePublisherRefusalBoundaryTests.test_original_false_refuses_even_when_post_capture_observer_raises'],
        wallSeconds=30,killGraceSeconds=5,expectedTemporaryDirectories=2,expectedTemporaryDirectoriesPerCase=1,CurrentSourceBirths=0,SDKExecutions=0,NodeExecutions=0,
        preloads=['adapters.phase_witness_publisher','adapters.phase_publication_refusal_original','self_tests.test_phase_witness_publisher','test_lifecycle_sparse_publisher_two'])
    target=dest/'approved-inputs.json';assert target.resolve().is_relative_to(REPO);target.write_text(json.dumps(body,sort_keys=True,indent=2)+'\n')
    assert before=={path:pin(path)for path in before}
    print(json.dumps(dict(controllerRoot=str(dest),approvedInputsSha256=pin(target)['sha256'],targets=0,globalScans=0)))
if __name__=='__main__':main()
