"""Owned main/actual HTTP writer routers and original IPC capacities."""
from pathlib import Path
from types import MappingProxyType
import builtins,io,os,stat,sys,threading
from tablet_constructor_custody import FunctionBinding,CustodyRefusal
from owned_write_boundary import OwnedWrites
class ParentWrites:
 def __init__(self,root,ipc,http,node,mp,protected):
  self.root=Path(root).resolve(strict=True);self.ipc,self.http,self.node,self.mp=ipc,http,node,mp
  self.main=threading.current_thread();self.original=MappingProxyType({n:getattr(os,n)for n in('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')if hasattr(os,n)})
  self.items=tuple(self.original.items());self.cio=(io.open,builtins.open);self.dup=(os.dup,os.dup2)
  self.protected=tuple(Path(p)for p in protected if Path(p).is_relative_to(self.root));self.helpers={};self.ports={};self.bindings=[];self.active=False;self.closed=False
 def check(self):
  assert not self.closed and (io.open,builtins.open)==self.cio
  assert all(getattr(os,n)is value for n,value in(self.ports.items()if self.active else self.items))
  assert(os.dup,os.dup2)==(self.dup_ports if self.active else self.dup)
  for b in self.bindings:b.guard()
 def helper(self):
  self.check();thread=threading.current_thread()
  if thread is not self.main:self.http.writer_server(sys._getframe(1))
  helper=self.helpers.get(thread)
  if helper is None:
   helper=OwnedWrites(self.root,self.protected);helper.original=self.original;helper.original_items=self.items
   self.helpers[thread]=helper
  helper._check();return helper
 def install(self):
  self.check();assert not self.active
  outer=self
  for name,original in self.items:
   if name=='close':continue
   def port(*args,_name=name,**kwargs):
    outer.check()
    if _name=='write'and not kwargs and outer.ipc.tracker_write_allowed(args,sys._getframe(1)):return outer.original['write'](*args)
    if _name in('unlink','ftruncate'):
     frame=sys._getframe(1);arena=outer.mp.arena
     if frame.f_code is arena.constructor.code and frame.f_globals is arena.constructor.namespace:
      helper=outer.helper()
      if _name=='ftruncate':return arena.truncate_original(args,kwargs,frame,helper)
      row=arena.before_unlink(args,kwargs,frame,helper)
      result=helper.mutate('unlink',*args,**kwargs)
      arena.after_unlink(row,frame,helper);return result
    return outer.helper().os_open(*args,**kwargs)if _name=='open'else outer.helper().mutate(_name,*args,**kwargs)
   self.ports[name]=port;self.bindings.append(FunctionBinding(port));setattr(os,name,port)
  def refuse_dup(*args,**kwargs):raise CustodyRefusal('No parent descriptor dup/dup2 port in the selected genuine constructors')
  self.dup_ports=(refuse_dup,refuse_dup);self.bindings.append(FunctionBinding(refuse_dup));os.dup,os.dup2=self.dup_ports
  self.active=True;self.check()
 def pipe_open(self,event,args,frame):
  if event!='open'or type(args[0])is not int:return False
  mode=args[1];writing=type(mode)is str and any(c in mode for c in'wax+')
  if not writing:return False
  if frame.f_code is self.node.init.code:return self.node.pipe_open(args,frame)
  # Genuine spawn Popen writes its unmodified serialized Process to this real
  # pipe. Never tee pickle/auth material or admit another integer write FD.
  binding=self.mp.spawn.launch
  if frame.f_code is binding.code and frame.f_globals is binding.namespace:
   binding.frame(frame);fd=args[0];owner=frame.f_locals['self']
   assert fd==frame.f_locals['parent_w']and mode in('w','wb')
   info=os.fstat(fd);assert stat.S_ISFIFO(info.st_mode)
   assert any(row['role']=='actor'and row['kernel']['pid']==owner.pid for row in self.mp.spawn.records)
   return True
  return False
 def audit(self,event,args,frame):
  relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
  if not relevant:return
  self.check()
  if self.pipe_open(event,args,frame):return
  self.helper().audit(event,args,frame)
 def restore(self):
  self.check()
  for helper in self.helpers.values():
   assert not helper.control_fds;helper.close()
  for name,original in self.items:setattr(os,name,original)
  os.dup,os.dup2=self.dup
  self.active=False;self.check();self.closed=True
  assert all(getattr(os,n)is f for n,f in self.items)
  return dict(restored=True,count=len(self.items),CIOUnchanged=(io.open,builtins.open)==self.cio,
   dupPortsUnchanged=(os.dup,os.dup2)==self.dup,writerThreads=len(self.helpers),controllerParentFDs=[])
