"""Actual old Native12 retention; no upgrade to current changed Source."""
import hashlib,json,stat
from pathlib import Path
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def require(here,repo,*,parent=False):
 data=json.loads((here/'actual-component-prerequisite.json').read_text());pins=json.loads((here/'actual-component-proof-pins.json').read_text());paths=[]
 for name,digest in data['unchangedNativeSource'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest;paths.append(Path(name))
 for item in data['actualStages']:
  root=Path(item['stage']);report=json.loads((root/'root-run-first/report.json').read_text());assert report['exitCode']==0 and report['retainedFiles']==item['retainedFiles'] and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
  assert json.loads((root/'root-run-first/thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
  assert json.loads((root/'run-plan.json').read_text())['cases']==item['cases']
  assert json.loads((root/'root-run-first/source-before.json').read_text())==json.loads((root/'root-run-first/source-after.json').read_text())
  assert json.loads((root/'root-run-first/originals-first.json').read_text())==json.loads((root/'root-run-first/originals-second.json').read_text())
  for i,case in enumerate(item['cases'],1):
   c=root/('case-cleanup-'+str(i));r=json.loads((c/'receipt.json').read_text());assert r['case']==case and r['actualStandardCaseRunReturned'] and r['twoCensusesPassed']
   a=json.loads((c/'terminal-census-1.json').read_text());b=json.loads((c/'terminal-census-2.json').read_text());assert a==b and not a['threads'] and not a['pendingTasks'] and not a['sdkModules'] and a['children']==''
  process=json.loads((root/'root-run-first/process-binding.json').read_text())['task']
  try:row=Path('/proc',str(process['pid']),'stat').read_text().rsplit(') ',1)[1].split()
  except (FileNotFoundError,ProcessLookupError):row=None
  assert row is None or int(row[19])!=process['startTicks']
 for name,expected in pins.items():
  p=Path(name);assert p.is_relative_to(repo) and p.resolve(strict=True)==p;a=p.lstat();value=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):value['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert value==expected and value['stat']==[getattr(p.lstat(),k) for k in F];paths.append(p)
 if here.name=='remaining3':
  first=here.parent/'first1';out=first/'root-run-first';report=json.loads((out/'report.json').read_text())
  assert report['exitCode']==0 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
  assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
  assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
  assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text())
  cases=json.loads((first/'run-plan.json').read_text())['cases'];r=json.loads((first/'selected-result.json').read_text());assert len(cases)==1 and r['selectedIds']==cases and r['successful'] and r['testsRun']==1 and not any(r[k] for k in ('failureCount','errorCount','skippedCount'))
  c=first/'case-cleanup-1';receipt=json.loads((c/'receipt.json').read_text());assert receipt['case']==cases[0] and receipt['actualStandardCaseRunReturned'] and receipt['twoCensusesPassed']
  for name in ('terminal-census-1.json','terminal-census-2.json'):
   a=json.loads((c/name).read_text());assert a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
  process=json.loads((out/'process-binding.json').read_text())['task']
  try:row=Path('/proc',str(process['pid']),'stat').read_text().rsplit(') ',1)[1].split()
  except (FileNotFoundError,ProcessLookupError):row=None
  assert row is None or int(row[19])!=process['startTicks']
  frozen=set(json.loads((first/'freeze.json').read_text())['files'])|{'freeze.json'}
  for p in sorted(first.rglob('*')):
   if str(p.relative_to(first)) not in frozen:assert p.resolve(strict=True)==p;paths.append(p)
 return paths
