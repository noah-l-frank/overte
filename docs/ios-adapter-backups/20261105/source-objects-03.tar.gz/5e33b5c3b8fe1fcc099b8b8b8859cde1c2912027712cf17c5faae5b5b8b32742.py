"""Normal existing-SDK factories through the canonical actual page parent.

Normal removal, old-client retirement, original reentry and the new PageLease
are composed here. No new SDK session, endpoint or whole capability is created.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.assets_budget import operation
from ios.adapters.assets_dead_page_retirement import ACTIONS
from ios.adapters.assets_generation_page_lease import GenerationAssetsPageLease
from ios.adapters.assets_generation_page_inventory import archive_generation_page
from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
from ios.adapters.assets_generation_runtime import GenerationActionAssetsRuntime
from ios.adapters.assets_page_generations import AssetsPageGenerations
from ios.adapters.assets_page_reentry import AssetsPageReentry
from ios.adapters.assets_runtime import AssetsNativeInput
from ios.adapters.assets_shared_action_runtime import SharedActionAssetsRuntime


class PageGenerationAssetsRuntime(SharedActionAssetsRuntime):
    def __init__(self,*args,generations,**kwargs):
        need(type(generations) is AssetsPageGenerations and not generations.historical)
        episode=kwargs.get('episode');action=kwargs.get('assets_action')
        need(episode is not None and action is not None and action.owner is generations.actions)
        page=generations.page_for_episode(episode)
        if 'page_lease' in kwargs:need(kwargs['page_lease'] is page)
        kwargs['page_lease']=page;self.assets_generations=generations;super().__init__(*args,**kwargs)

    def _assets_sources(self,selector,lock):
        # Full context validation belongs at factory admission. Every actual
        # send keeps the existing action/SDK guards plus the physical canonical
        # CAS guard; it does not recursively replay all historical UI sources.
        self.assets_generations.guard();parts=super()._assets_sources(selector,lock);previous=parts['check']
        def checked():
            self.assets_generations.base_guard();need(previous() is not False);self.assets_generations.base_guard();return True
        parts['check']=checked
        for transport in (parts['observer'],getattr(parts['clock_source'].send,'__self__',None)):
            need(transport is not None);before=transport.before_send
            def final(before=before):
                checked()
                if before is not None:need(before() is not False)
                checked()
            transport.before_send=final
        parts['native']=AssetsNativeInput.from_original(parts['native'],checked);checked();return parts

    @operation
    def normal_remove_reenter(self,selector,run,role,fixture_url,lock,backend_config,*,parts=None):
        scope=self.assets_episode;action=self.assets_action
        need(scope.index in ACTIONS and action.index==ACTIONS[scope.index] and role=='primary')
        if parts is None:
            parts=(self._assets_unbaked_components(selector,run,role,fixture_url,lock,backend_config)
                if scope.index in (2,3) else self._assets_parsed_components(selector,run,role,fixture_url,lock,backend_config))
        if 'model_removal' not in parts:
            parts=self._assets_model_removal_components(selector,run,role,fixture_url,lock,backend_config,parts=parts)
        removal=parts['model_removal']
        if removal.state is None:removal.reserve()
        if removal.state['phase']!='model-gone':removal.remove()
        if removal.state['contextClosedBy'] is None:removal.close_context()
        parts=self._assets_retire_dead_page_clients(selector,run,role,fixture_url,lock,backend_config,parts=parts)
        retirement=parts['dead_page_retirement'];number={9:2,16:3,22:4}[action.index]
        root=Path(scope.owner.context['roles']['primary']['stateRoot']);parent_lock=scope.owner.locks['primary']
        store=PrivateFeatureState(root/('ios-assets-page-reentry-'+run+'-primary-g'+str(number)+'.json'))
        birth=AssetsPageReentry(self.assets_selection,store,parent_lock,action,parts['native'],parts['clock_source'],
            removal=removal,monotonic=self.monotonic)
        if birth.state is None:birth.reserve()
        birth.open()
        page=GenerationAssetsPageLease(scope.owner,
            PrivateFeatureState(root/('ios-assets-page-lease-'+run+'-primary-g'+str(number)+'.json')),
            parent_lock,reentry=birth,monotonic=self.monotonic)
        if page.state is None:page.reserve()
        if page.state['pending'] is not None:page.recover_capture()
        if page.state['origin'] is None:page.attach_origin()
        self.assets_generations.advance(retirement,birth,page)
        return dict(parts,page_reentry=birth,next_page_lease=page)

    def generation_view_components(self,selector,run,role,fixture_url,lock,parts,*,episode_scopes):
        # The caller supplies existing independently held episode leases. No
        # duplicate lock or new native/directory birth is invented here.
        generations=self.assets_generations;number=parts['page_reentry'].generation
        old=number-1;birth=generations.contexts[old].birth
        report=archive_generation_page(self.assets_episode.owner,old,birth,episode_scopes)
        graph=AssetsEpisodeModelGraph(self.assets_episode,report['owner'],actions=self.assets_action.owner,dependency_mode=True).decode()
        runtime=GenerationActionAssetsRuntime(self.adapter,self.assets_selection,assets_action=self.assets_action,
            phase=self.assets_phase,episode=self.assets_episode,generation=parts['page_reentry'],origin_graph=graph,
            retirement=parts['dead_page_retirement'],generations=generations,monotonic=self.monotonic,epoch_ms=self.epoch_ms)
        return runtime,runtime.generation_components(selector,run,role,fixture_url,lock)

    @operation
    def close_final_page(self,selector,run,role,fixture_url,lock):
        need(self.assets_action.index==29 and self.assets_episode.index==5 and role=='primary')
        parts=self._assets_components(selector,run,role,fixture_url,lock)
        self.assets_page.close(self.assets_episode,parts['picker']);self.assets_generations.final_closed(self.assets_action)
        parts['check']();return parts
