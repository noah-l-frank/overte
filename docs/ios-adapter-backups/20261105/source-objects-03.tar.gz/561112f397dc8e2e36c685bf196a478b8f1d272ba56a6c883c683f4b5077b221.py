"""Explicit Callback Fence2 using unchanged four-clock and inactive guards.

Only original local Scope/key/pointer acquisitions can supply this cut. This
module itself sends no Stop/SDK command or process-death fact.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_clock_join import digest
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as read_scope
from adapters.script_feature.history import same,unpack
from feature_journeys.phase_fixture import PhaseFixtureReader,validate as phase_packet
from ios.adapters.emote_keys import IOSEmoteKeys
from ios.adapters.emote_native_prefix import follow
from ios.adapters.emote_original_lease import EmoteOriginalLease
from ios.adapters.emote_pointers import IOSEmotePointers
from ios.adapters.emote_rooted_marker_scope import IOSEmoteRootedMarkerScope
from ios.adapters.emote_rooted_quiet import extend
from ios.adapters.emote_session_carriers import inventory
from ios.adapters.emote_callback_ownership import IOSEmoteCallbackOwnership
from ios.adapters.emote_callback_final_archive import IOSEmoteCallbackFinalArchive
from ios.adapters.emote_rooted_fence import _current_metadata,_metadata_unchanged,_seal,inactive,inactive_prefixes,clock_shape,current

def _local(scope,pointers,keys,phase,*,instance,ticket,after):
    """Local original acquisition only; this helper supplies no seal authority."""
    need(type(scope) is IOSEmoteRootedMarkerScope and type(pointers) is IOSEmotePointers
        and type(keys) is IOSEmoteKeys and type(phase) is PhaseFixtureReader
        and phase.run==scope.run and phase.area=='emotes' and phase.fixture_url==scope.fixture_url)
    need(scope.state['pending'] is pointers.state['pending'] is keys.state['pending'] is None)
    held=scope.held_originals();before=inactive(phase.status(),run=scope.run,instance=instance,ticket=ticket,after=after)
    counts={name:len(owner.state['records']) for name,owner in (('keys',keys),('pointers',pointers))}
    old_scope=scope.frames[-1]['clockJoin'];extend(scope,pointers,keys)
    # The extension's own typed owners durably append originals. Pin the
    # complete resulting local graph before reopening its bytes and before
    # another external phase read can change any contributing original.
    leases=[EmoteOriginalLease(root,[]) for root in {scope.root,scope.store.path.parent}]
    need(all(len(owner.state['records'])==counts[name]+2 for name,owner in (('keys',keys),('pointers',pointers))))
    key_rows=[keys.original(ref) for ref in keys.state['records'][-2:]]
    pointer_rows=[pointers.original(ref) for ref in pointers.state['records'][-2:]]
    latest=scope.frames[-1]['clockJoin'];follow(old_scope['nativeAfter'],latest['nativeBefore'])
    need(scope.held_originals()==held and pointers.closed(scope) and keys.closed(scope))
    acquisitions=[key_rows[0]['clockJoin'],pointer_rows[0]['clockJoin'],latest,
        pointer_rows[1]['clockJoin'],key_rows[1]['clockJoin']]
    # NativeFeatureObservation has no monotonic timestamp. Use the actual
    # same-instance global key source's native clocks, which span both key
    # reads around the pointer/scope originals; never invent a native clock.
    first_key,last_key=(keys.packet(row) for row in key_rows)
    need(first_key['source']['instance']==last_key['source']['instance'])
    native_clock=dict(instance=first_key['source']['instance'],before=deepcopy(first_key['clockBefore']),after=deepcopy(last_key['clockAfter']))
    final=inactive(phase.status(),run=scope.run,instance=instance,ticket=ticket,after=after)
    phase_packet(final,run=scope.run,area='emotes',request=final['requestId'],epoch=final['capturedEpochMs'],previous=before)
    need(before['capturedEpochMs']<=acquisitions[0]['hostBeforeEpochMs']
        and acquisitions[-1]['hostAfterEpochMs']<=final['capturedEpochMs'])
    for lease in leases:lease.guard()
    current(acquisitions,native_clock,epoch_ms=scope.epoch_ms,monotonic=scope.monotonic)
    return dict(iosEmoteRootedFenceVersion=2,runId=scope.run,role=scope.role,binding=deepcopy(scope.binding),
        phaseBefore=before,phaseAfter=final,scope=scope.snapshot(),keys=keys.store.read(),pointers=pointers.store.read(),
        held=deepcopy(held),acquisitions=deepcopy(acquisitions),nativeClock=native_clock)


def acquire(ownership,archive,seal,scope,pointers,keys,phase,*,end=None,cut=None):
    """Join the actual frozen paired proof before acquiring any new original.

    The caller holds the actual Actor -> Primary locks. Every old immutable
    file stays pinned; only these three existing local WALs may change. New
    scoped carriers must be reached by the actual typed original readers.
    """
    need(type(ownership) is IOSEmoteCallbackOwnership and type(archive) is IOSEmoteCallbackFinalArchive
        and type(scope) is IOSEmoteRootedMarkerScope)
    if end is None:need(cut is None)
    else:
        from ios.adapters.emote_callback_process_end import IOSEmoteCallbackProcessEnd
        from ios.adapters.emote_callback_fence_cut import IOSEmoteCallbackFenceCut
        need(type(end) is IOSEmoteCallbackProcessEnd and type(cut) is IOSEmoteCallbackFenceCut and cut.end is end
            and end.ownership is ownership and end.archive is archive and same(end.seal,seal)
            and end.role==scope.role and end.state['phase']=='prepared' and end.state['fence'] is None and end.state['pending'] is None)
        cut.unchanged()
    roles=ownership.roles;need(scope.run==roles.run and scope.role in roles.locks
        and scope.lock is roles.locks[scope.role] and archive.lock is roles.locks['primary']
        and archive.primary_lock is archive.lock and archive.role=='primary')
    for lock in roles.locks.values():lock.assert_held()
    need(archive.state is not None and archive.state['phase']=='validated'
        and same(archive.store.read(),archive.previous) and same(archive.envelope(archive.state),archive.previous))
    archive.decode(archive.previous)
    copies=deepcopy(roles.copies);copies[str(ownership.path)]=deepcopy(ownership.terminal)
    need(same(archive.copies(),copies))
    mutable={scope.store.path,pointers.store.path,keys.store.path}
    metadata_signatures=_current_metadata(archive.paths,copies) if cut is None else cut.metadata_before()
    with read_scope(fresh=True) as reads:
        if cut is not None:cut.read_peer()
        proof,after=ownership.read_with_retirement_floor();_seal(proof,seal,run=scope.run,role=scope.role,binding=scope.binding)
        for owner in (scope,pointers,keys):
            need(str(owner.store.path) in copies and same(owner.store.read(),copies[str(owner.store.path)])
                and same(owner.store.read(),owner.previous) and same(owner.envelope(owner.state),owner.previous))
        role_feature=copies[str(scope.lock.path.with_name('ios-emote-'+scope.role+'-feature.json'))]
        state=unpack(role_feature['payload'])[0];instance=state['phaseInstance'];ticket=seal['description']['ticket']
        retired=inactive(archive.state['phaseOriginal'],run=scope.run,instance=instance,ticket=ticket,after=after)
        scope_held=[{key:row[key] for key in ('resource','kind','originalSha256')} for row in scope.held_originals()]
        need(same(scope_held,seal['description']['roles'][scope.role]['heldResources']))
        roots={lock.path.parent for lock in roles.locks.values()}
        for role,lock in roles.locks.items():roots.add(Path(copies[str(lock.path.with_name('ios-emote-'+role+'-feature.json'))]['artifactRoot']))
        found=inventory(roots)
        outputs={archive.store.path}|{archive.record_store(index).path for index in range(1,len(archive.paths)+1)}
        if end is not None:outputs|=end.outputs()
        need(found<=reads|set(path.path for path in archive.paths)|outputs)
    _metadata_unchanged(metadata_signatures)
    pins={path:EmoteOriginalLease.signature(path.lstat()) for path in found-mutable}
    def unchanged():
        for lock in roles.locks.values():lock.assert_held()
        _metadata_unchanged(metadata_signatures,mutable)
        for path,signature in pins.items():
            PrivateFeatureState(path)._parent();need(EmoteOriginalLease.signature(path.lstat())==signature)
    unchanged()
    with read_scope(fresh=True) as new_reads:
        value=_local(scope,pointers,keys,phase,instance=instance,ticket=ticket,after=after)
        phase_packet(value['phaseBefore'],run=scope.run,area='emotes',request=value['phaseBefore']['requestId'],
            epoch=value['phaseBefore']['capturedEpochMs'],previous=retired)
        unchanged();need(inventory(roots)<=found|new_reads|mutable)
    value.update(archiveSha256=digest(archive.previous),sealSha256=digest(seal))
    if cut is not None:cut.acquired(value,new_reads)
    current(value['acquisitions'],value['nativeClock'],epoch_ms=scope.epoch_ms,monotonic=scope.monotonic)
    return value
