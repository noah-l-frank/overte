"""First real normal Primary observe with opt-in original Budget diagnostics.

Qt/native/GPU/SDK/OS remain the genuine fixture's declared host models.
No expected exception converts the actual normal failure into a passing test.
"""
from copy import deepcopy
from adapters.api_budget_refusal_original import ApiBudgetRefusalOriginal
from adapters.normal_ui import NativeUIError
from feature_journeys.contract import VERSION
from ios.adapters import avatar_api_entry, feature_configuration
from ios.adapters.avatar_feature import IOSAvatarFeature
from ios.adapters.avatar_runtime import IOSAvatarRuntime
from ios.self_tests.avatar_installed_full15_fixture import NativeInstalledFrontdoor, OriginalAvatarActor
from ios.self_tests.avatar_prepare_fixture import RUN
from ios.self_tests.test_ios_avatar_closed_gate_native_source import AvatarClosedGateNativeSourceTests


class AvatarNormalPrimaryBudgetRefusalPrefixTests(AvatarClosedGateNativeSourceTests):
    def test_changed_first_normal_observe_retains_original_budget_refusal_without_retiming(self):
        # These are the original normal constructor/configuration/Actor inputs.
        f=NativeInstalledFrontdoor(self);d=f.domain
        config=f.configuration(8);f.set_configuration(config)
        with self.assertRaises(NativeUIError):feature_configuration.capabilities(d.natives['primary'].target)
        primary=d.owners['primary'];actor=d.owners['actor']
        runtime=IOSAvatarRuntime(f.adapter)
        owner=IOSAvatarFeature(runtime,'primary',d.client,RUN,'primary',dict(artifactRoot=str(primary.root),
            imagePolicy=deepcopy(primary.policy),actorTarget='actor'))
        actor_config=dict(iosAvatarObserverVersion=1,target='actor',primaryTarget='primary',runId=RUN,
            candidateArguments=['declared-host-runtime-only'],fixtureUrl=d.client.url,actorToken=d.actor,
            authorityRead=dict(mode='adapter',token=d.adapter),durationSeconds=1800,
            artifactRoot=str(actor.root),imagePolicy=deepcopy(actor.policy))
        worker=OriginalAvatarActor(IOSAvatarRuntime(type(f.adapter)()),actor_config,f.root,self)
        # The first Primary @operation Budget is born inside this real call.
        # ContextVars are not inherited by the separately born Actor thread.
        self.budget_diagnostic=ApiBudgetRefusalOriginal(f.root/'api-budget-refusal-original.json','avatar',
            dict(selection='normal-primary-observe-prefix1',wholeQualification=False,
                old92CauseUnclassified=True,scope='first original Primary observe only'))
        self.prefix_returned=False
        with self.budget_diagnostic.scope(avatar_api_entry):
            self.actual_prefix_sample=owner.observe(dict(contractVersion=VERSION,runId=RUN,afterSequence=0))
        self.prefix_returned=True
        # The diagnostic stops here. No archive/next operation or extra native
        # observation runs, and the actual Actor uses its registered cleanup.
