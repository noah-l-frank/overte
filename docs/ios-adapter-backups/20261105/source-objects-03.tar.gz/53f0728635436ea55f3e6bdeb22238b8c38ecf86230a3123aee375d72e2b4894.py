"""Actual original worker/native cuts; SDK/native/HID producers are MODELS.

No SDK import, native/device execution, authenticated runtime qualification,
physical ADC/contact/end proof or canonical capability is established here.
"""
import asyncio,json,os
from copy import deepcopy
from unittest.mock import patch
import test_motion_selected_join_models as join_fixture


class NativeMotionWorkerScopeModels(join_fixture.MotionSelectedJoinModels):
    async def asyncSetUp(self):
        await super().asyncSetUp();self.motion_lease=None;self.hid_original=self.f.context.send_touchscreen
        self.down_effect=None;self.move_effect=None;self.before_model_down=None;self.downs=0
        self.model_motion_gate=asyncio.Event();self.model_motion_gate.set();self.model_motion_entered=asyncio.Event()
        outer=self
        async def hid_send(state,x,y):
            # Original modeled Context enforces the actual durable TouchLease
            # opening/down-issued/up-issued and owns its real socketpair.
            await outer.hid_original(state,x,y)
            src=outer.world_source
            if state==0xC2:
                outer.downs+=1
                # Explicit modeled native pad receives the ACTUAL HID point,
                # inverse-projected through this original modeled viewport.
                px=x*1000/65535-outer.sdk_rect['x'];py=y*640/65535-outer.sdk_rect['y']-20
                point=[px,py]
                if outer.downs==1:
                    src.event('begin','pressed',point)
                    src.pad.update(moveValid=True,moveNativeId=7,movePoint=deepcopy(point))
                    if outer.down_effect is not None:outer.down_effect()
                else:
                    src.event('update','updated',point);src.pad['movePoint']=deepcopy(point)
                    from ios.adapters import lifecycle_world as world
                    src.raw[world.FORWARD]=max(0.,(src.pad['center'][1]-point[1])/src.pad['radius'])
                    if outer.move_effect is not None:outer.move_effect()
            else:
                if src.active:src.event('end','released',deepcopy(src.pad['movePoint']))
                src.pad.update(moveValid=False,moveNativeId=-1,movePoint=None);src.raw=[0.]*len(src.raw)
        self.f.context.send_touchscreen=hid_send
        self.addAsyncCleanup(self.close_worker_scope)

    async def close_worker_scope(self):
        self.model_motion_gate.set();self.window_gate.set();self.f.context.down_gate.set();self.f.context.enter_gate.set();self.f.context.drain_gate.set()
        if self.motion_lease is not None:
            self.motion_lease.request_release.set()
            worker=self.motion_lease.worker
            if worker is not None:
                # Never cancellation-as-Up; the exact original worker returns.
                await asyncio.wait_for(asyncio.shield(worker),5)

    async def setup_motion(self,seconds=12):
        from adapters.script_feature.history import canonical
        await self.select_original();packet,_=await self.capture_selected();self.assertEqual('complete',packet['status'])
        payload=json.loads(packet['result']['acquisitionJson'])
        await self.ops.execute('touch-motion-prepare',dict(binding=deepcopy(self.binding),runId=self.run,
            referenceJson=canonical(payload['reference']).decode('ascii'),seconds=seconds),self.binding['sessionId'])
        self.resource=self.ops.touch_resources;self.prepared_original=deepcopy(self.resource.previous)
        self.prepared_bytes=self.resource.store.path.read_bytes()
        with patch('ios.adapters.lifecycle_touch_resource_owner.touch_session',side_effect=lambda *_a,**_k:self.f.context):
            lease=self.ops.motion_worker_lease(self.resource)
        self.motion_lease=lease;self.f.owner=lease;self.f.context.store=lease.store
        # The patch covers original SDK context construction during worker
        # entry, not just lease construction. Retain it through actual drain.
        patched=patch('ios.adapters.lifecycle_touch_resource_owner.touch_session',side_effect=lambda *_a,**_k:self.f.context)
        patched.start();self.addCleanup(patched.stop)
        return lease

    async def begin_motion(self,seconds=12):
        lease=await self.setup_motion(seconds);path=self.resource.state['path'];window=path['window']
        status=await lease.begin(window['width'],window['height'],*path['start'],seconds=seconds)
        return lease,status

    async def test_actual_12s_intent_and_worker_keep_two_fresh_input_cuts_then_old_native_frame_is_only_history(self):
        lease,status=await self.begin_motion();self.assertTrue(status['workerRunning']);step=self.resource._native_step
        self.assertIs(step._worker(),lease.worker);self.assertIs(self.source._born[0]['worker'],lease.worker)
        self.assertEqual([0xC2,0xC2],self.f.states());self.assertEqual(16,len(self.commands));self.assertEqual(3,len(self.journal()['previous']['frames']))
        self.assertEqual(12,lease.previous['deadlineMonotonic']-lease.previous['startedMonotonic'])
        query_count=len(self.commands);old_deadline=step._current._deadline
        await asyncio.sleep(max(0.,old_deadline-asyncio.get_running_loop().time())+.03)
        self.assertFalse(lease.worker.done());self.assertFalse(lease.request_release.is_set());self.assertEqual(query_count,len(self.commands))
        # An expired historical frame is NOT checked/relabelled as current.
        self.assertLess(step._current._deadline,asyncio.get_running_loop().time())
        self.assertEqual(self.prepared_original,self.resource.previous);self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes())
        # Exercise the actual unchanged12s watchdog rather than replacing it
        # with a modeled time jump or treating a1.5s frame as current for12s.
        await asyncio.wait_for(asyncio.shield(lease.worker),13)
        self.assertGreaterEqual(asyncio.get_running_loop().time(),lease.previous['deadlineMonotonic'])
        self.assertEqual('deadline',lease.failure);self.assertEqual(query_count,len(self.commands))
        await lease.release();await lease.release()
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)

    async def test_actual_postdown_contact_is_required_before_upper_move_and_foreign_native_pointer_refuses(self):
        self.down_effect=lambda:self.world_source.pad.update(moveNativeId=8)
        lease=await self.setup_motion();path=self.resource.state['path']
        with self.assertRaises((RuntimeError,ValueError)):await lease.begin(path['window']['width'],path['window']['height'],*path['start'],seconds=12)
        await lease.worker;self.assertEqual([0xC2,0x02],self.f.states());self.assertTrue(self.selected[3]['revoked'])
        self.assertEqual(1,self.f.context.exited);self.assertTrue(lease.closed)

    async def test_nonidle_actual_drive_after_center_down_refuses_move_but_preserves_original_up(self):
        from ios.adapters import lifecycle_world as world
        self.down_effect=lambda:self.world_source.raw.__setitem__(world.FORWARD,.5)
        lease=await self.setup_motion();path=self.resource.state['path']
        with self.assertRaises((RuntimeError,ValueError)):await lease.begin(path['window']['width'],path['window']['height'],*path['start'],seconds=12)
        await lease.worker;self.assertEqual([0xC2,0x02],self.f.states());self.assertTrue(self.selected[3]['revoked']);self.assertEqual(1,self.f.context.exited)

    async def test_wda_geometry_change_after_original_down_refuses_move_without_second_down_or_source(self):
        self.down_effect=lambda:self.sdk_rect.update(x=self.sdk_rect['x']+3)
        lease=await self.setup_motion();path=self.resource.state['path']
        with self.assertRaises((RuntimeError,ValueError)):await lease.begin(path['window']['width'],path['window']['height'],*path['start'],seconds=12)
        await lease.worker;self.assertEqual([0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.entered)
        self.assertTrue(self.selected[3]['revoked']);self.assertEqual(1,self.f.context.exited)

    async def test_observed_lease_worker_slot_substitution_revokes_and_original_worker_still_owns_up(self):
        lease,_=await self.begin_motion();original=lease.worker;foreign=asyncio.create_task(asyncio.sleep(0));await foreign
        lease.worker=foreign
        try:
            with self.resource.lock.held(),self.assertRaises((RuntimeError,ValueError)):self.resource._native_step.scope()
            self.assertTrue(self.selected[3]['revoked']);self.assertTrue(lease.request_release.is_set())
            self.assertIs(self.source._born[0]['worker'],original)
        finally:lease.worker=original
        await original;self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)

    async def test_source_loss_after_move_does_not_block_original_once_up_or_reauthenticate(self):
        lease,_=await self.begin_motion();old=self.ops.session;self.ops.session=deepcopy(old);queries=len(self.commands)
        try:
            with self.resource.lock.held(),self.assertRaises((RuntimeError,ValueError)):self.resource._native_step.scope()
            await lease.release();await lease.release()
        finally:self.ops.session=old
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(queries,len(self.commands));self.assertEqual(1,self.f.context.exited)

    async def test_original_pending_down_late_return_cannot_start_move_after_release_request(self):
        lease=await self.setup_motion();path=self.resource.state['path'];self.f.context.down_gate.clear()
        caller=asyncio.create_task(lease.begin(path['window']['width'],path['window']['height'],*path['start'],seconds=12));self.controls_motion.append(caller)
        await self.f.context.down_started.wait();original=lease.worker;lease.request_release.set();self.f.context.down_gate.set()
        with self.assertRaises((RuntimeError,ValueError)):await caller
        await original;self.assertEqual([0xC2,0x02],self.f.states());self.assertFalse(original.cancelled());self.assertEqual(1,self.f.context.exited)

    async def test_changed_opening_does_not_borrow_same_original_worker_for_new_intent(self):
        lease,_=await self.begin_motion();before=deepcopy(lease.previous);lease.previous['position'][0]+=1
        try:
            with self.resource.lock.held(),self.assertRaises((RuntimeError,ValueError)):self.resource._native_step.scope()
            self.assertTrue(lease.request_release.is_set());self.assertTrue(self.selected[3]['revoked'])
        finally:lease.previous=before
        await lease.worker;self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_actual_native_step_method_change_is_observed_and_cannot_revive_same_bridge_by_restoration(self):
        from types import MethodType
        lease,_=await self.begin_motion();original=self.ops.native_motion_step
        async def foreign(_self,*_args):return self.resource._native_step._current
        self.ops.native_motion_step=MethodType(foreign,self.ops)
        try:
            with self.resource.lock.held(),self.assertRaises((RuntimeError,ValueError)):self.resource._native_step.scope()
        finally:self.ops.native_motion_step=original
        with self.resource.lock.held(),self.assertRaises((RuntimeError,ValueError)):self.resource._native_step.scope()
        await lease.worker;self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertTrue(self.selected[3]['revoked'])

    async def test_unknown_postdown_sdk_return_retains_original_capture_and_source_until_real_return_after_once_up(self):
        def lose_window_return():
            # Clear actual completion markers AFTER the successful preDown
            # window, before the second original SDK read is issued.
            self.window_entered.clear();self.window_closed.clear();self.window_gate.clear()
        self.down_effect=lose_window_return;lease=await self.setup_motion();path=self.resource.state['path']
        caller=asyncio.create_task(lease.begin(path['window']['width'],path['window']['height'],*path['start'],seconds=12));self.controls_motion.append(caller)
        await self.window_entered.wait();capture=self.source._native_current_tasks[-1]
        try:
            with self.assertRaises((RuntimeError,ValueError)):await caller
            await lease.worker
            self.assertEqual([0xC2,0x02],self.f.states());self.assertFalse(capture.done());self.assertFalse(capture.cancelled())
            self.assertFalse(self.window_closed.is_set());self.assertTrue(any(fd.fileno()!=-1 for fd in self.window_sockets));self.assertFalse(self.creator.done())
            with self.resource.lock.held():
                drain=asyncio.create_task(self.source.settle_touches());self.controls_motion.append(drain)
                await asyncio.sleep(.02);self.assertFalse(drain.done());self.assertFalse(self.creator.done())
                self.window_gate.set()
                try:await capture
                except (RuntimeError,ValueError):pass
                with self.assertRaises((RuntimeError,ValueError)) as failure:await drain
                self.assertIs(failure.exception,capture.exception())
            self.assertTrue(capture.done());self.assertTrue(self.window_closed.is_set());self.assertTrue(all(fd.fileno()==-1 for fd in self.window_sockets))
            self.assertEqual(1,self.f.context.exited);self.assertEqual([0xC2,0x02],self.f.states())
        finally:self.window_gate.set()

    async def test_delayed_original_context_cannot_clear_bound_before_down_callback_or_accept_missing_current_receipt(self):
        from ios.adapters.lifecycle_world_hold import _MotionContext
        from adapters.native_feature_observation import need
        lease=await self.setup_motion();step=self.resource._native_step
        self.assertIsNone(step._current);calls=[];entered=asyncio.Event();gate=asyncio.Event()
        original_enter=type(self.f.context).__aenter__
        async def delayed(actual):
            self.assertIs(actual,self.f.context);entered.set();await gate.wait()
            return await original_enter(actual)
        def before_down():
            # This focused context seam has NO current acquisition/worker.
            # The mandatory original callback must observe that actual absence;
            # no bool, expected result or synthetic native verdict replaces it.
            calls.append(step);need(step._current is not None)
            return step.checkpoint('before-down')
        motion=_MotionContext(lambda:self.f.context,step._hid_start,step._hid_end,step.movement,before_down=before_down)
        with patch.object(type(self.f.context),'__aenter__',delayed):
            opening=asyncio.create_task(motion.__aenter__());self.controls_motion.append(opening)
            await entered.wait();self.assertFalse(opening.done())
            motion.before_down=None;gate.set();hid=await opening
            try:
                with self.assertRaises((RuntimeError,ValueError)):await hid.send_touchscreen(0xC2,*step._hid_start)
                self.assertEqual([step],calls);self.assertEqual([],self.f.states())
                self.assertIsNone(lease.worker);self.assertEqual([],self.source._born)
                self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes())
            finally:await motion.__aexit__(None,None,None)
        self.assertEqual(1,self.f.context.exited);self.assertTrue(all(fd.fileno()==-1 for fd in self.f.context.sockets))
