from pathlib import Path
import ast,hashlib,json,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-scoped-cleanup-raise1-avatar5-root-preparation-20261029/58-scoped-cleanup-first1-raise';ORIG=T/'lifecycle-original-owner-scoped-cleanup-prepare-copy-import15-root-preparation-20261029/56-resource-scoped-cleanup15';P=T/'lifecycle-original-owner-scoped-cleanup-remaining14-root-preparation-20261029';S=P/'59-scoped-cleanup-remaining14';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();report=json.loads((B/'root-run-first/report.json').read_text());summary=json.loads((B/'actual-source-raise-summary-first.json').read_text())
assert report['exitCode']==0 and report['retainedFiles']==16 and report['allPinsEqual'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses'];assert summary['ownedToolFreed'] and summary['records']==67 and not summary['dropped'] and not summary['writeFailures']
P.mkdir(mode=0o700);S.mkdir(mode=0o700)
for n,d in json.loads((B/'freeze.json').read_text())['files'].items():
 assert H(B/n)==d;dest=S/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/n,dest)
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((B/'prior-retained-original-pins.json').read_text());assert sum('sha256' in v for v in prior.values())==3128
root=B/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==16
for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
for n in ['report.json','thread-report.json','process-binding.json']:p=B/'root-run-first'/n;prior[str(p)]=pin(p)
for n in ['actual-source-raise-events-first.jsonl','actual-source-raise-summary-first.json']:p=B/n;prior[str(p)]=pin(p)
assert sum('sha256' in v for v in prior.values())==3149;(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n')
# The Root-reviewed original15 runner has NO monitor installation. Retain the
# diagnostic source file as a pinned unused original, not as an active hook.
shutil.copyfile(ORIG/'run-selected.py',S/'run-selected.py')
plan=json.loads((ORIG/'run-plan.json').read_text());first=plan['cases'][0];cases=plan['cases'][1:];assert len(cases)==11 and sum('ResourceScopedCleanupModels.' in c for c in cases)==5 and sum('RetainedWebDriverCleanupModels.' in c for c in cases)==6
plan.update(status='PRIVATE_UNRUN_ONLY_REMAINING_PY11_NODE3_AFTER_ACTUAL58PASS',cases=cases,caseCount=11,totalCaseCount=14,expectedRetainedRoots=10,initialOuterSeconds=90,nodeCaseCount=3,nodeInnerSeconds=15)
plan['privateFiles']['run-selected.py']=H(S/'run-selected.py');plan['requiredPriorActualPASS']=dict(path=str(B/'root-run-first/report.json'),sha256=H(B/'root-run-first/report.json'),selectedFirstCase=first,actualExitCode=0,diagnosticOnlyNoTimingQualification=True);(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
stage=json.loads((S/'source-manifest.json').read_text());changes=[]
for row in stage['sourcePaths']:
 rel=row['path'];actual=H(R/rel)
 if actual!=row['candidateSHA256']:
  dest=S/'actual-current-dependency/repo'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,dest);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(dest),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
stage.update(stage=59,name=S.name,status='PRIVATE_UNRUN_REMAINING14_NO_FIRST_CASE_REPEAT',caseCount=14,pythonCaseCount=11,nodeCaseCount=3,initialTimeoutSeconds=90,sourceDeltaPaths=[],exactPublicMutationPlan='NONE. c6f017/d7bcb/8e6bd/currentAvatar5 registry unchanged; only remainingUNRUN5receiver+HTTP6+Node3.');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');settings=json.loads((S/'supervisor-plan.json').read_text());settings['initialSeconds']=90;(S/'supervisor-plan.json').write_text(json.dumps(settings,indent=2)+'\n')
(S/'clone-provenance-remaining14.json').write_text(json.dumps(dict(parent58Freeze=H(B/'freeze.json'),actual58PASSReportSHA256=H(B/'root-run-first/report.json'),actual58DiagnosticSummarySHA256=H(B/'actual-source-raise-summary-first.json'),original56NoMonitorEntrySHA256=H(ORIG/'run-selected.py'),excludedAlreadyRunFirstCase=first,selectedPythonCases=cases,nodeCases=3,totalCases=14,expectedRoots=10,initialSeconds=90,killAfterSeconds=5,nodeInnerSeconds=15,actualOldOriginalFiles=3129,actualReports=18,actualDiagnosticFiles=2,totalPriorPinnedFiles=3149,root56FailureUnreproduced=True,timingQualification=False,sourceChanges=changes,executed=False),indent=2)+'\n')
(S/'README-remaining14.txt').write_text('Root59 ONLY remainingUNRUN5Receiver+HTTP6+Node3=14, initial90+kill5/Node15/10realTD. FirstactualReceiver alreadyPASS under Root58diagnostic1 and NOT rerun. Source/model/olddefaultguards unchanged; monitoringNOTinstalled. Source c6f017/d7bcb/8e6bd/currentAvatar5shared. Root58PASSactualreport/67StopIterationonlysummary mandatorypinned prerequisite, NO timingqualification and NO claimed fix for actualRoot56FAIL.16neworiginals+3reports+2diagnostic files added:3129actualoriginals+18reports+2diag=3149priorfiles. ExistingactualThread/Task/Child/FD/SDK/import/source/original2census strict. Allold packets/logs/56FAIL/58PASS originals preserved. No agentimports/tests/PUB.\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(stage=str(S),parentFreeze=H(P/'freeze.json'),stageFreeze=H(S/'freeze.json'),entrySHA256=H(S/'run-selected.py'),priorFiles=3149,sourceChanges=changes),indent=2))
