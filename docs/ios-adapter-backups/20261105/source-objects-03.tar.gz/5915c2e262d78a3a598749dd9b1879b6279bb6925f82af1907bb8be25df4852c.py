#!/usr/bin/env python3
"""Keep the current PyMobileDevice3 XCTest handshake alive for one WDA run."""

# Copyright 2026 Overte e.V.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager, suppress
import ctypes
from importlib.metadata import version
import ipaddress
import inspect
import weakref
import json
import os
import re
import signal
import sys

from pymobiledevice3.remote.remote_service_discovery import RemoteServiceDiscoveryService
from pymobiledevice3.exceptions import ConnectionTerminatedError
from pymobiledevice3.services.dvt.testmanaged.xcuitest import TestConfig, XCUITestService
from pymobiledevice3.services.wda import WdaServiceClient


MAX_REQUEST_BYTES = 16 * 1024
READY_TIMEOUT_SECONDS = 34.0
GRACEFUL_STOP_TIMEOUT_SECONDS = 10.0
BUNDLE_ID = re.compile(
    r"[A-Za-z0-9][A-Za-z0-9-]*(?:[.][A-Za-z0-9][A-Za-z0-9-]*)+"
)
ENVIRONMENT_KEYS = {"USE_PORT", "WDA_PRODUCT_BUNDLE_IDENTIFIER"}
FAILURE_PHASES = {
    "host-platform",
    "parent-death-signal",
    "parent-lost",
    "request",
    "request-endpoint",
    "request-environment",
    "runtime-version",
    "rsd-connect",
    "rsd-identity",
    "xctest-config",
    "xctest-start",
    "wda-ready",
    "wda-ready-runner-disconnected",
    "wda-ready-runner-error",
    "wda-ready-runner-returned",
    "wda-ready-runner-runtime",
    "wda-ready-runner-timeout",
    "wda-ready-timeout",
    "session-lifetime",
    "session-lifetime-runner-disconnected",
    "session-lifetime-runner-error",
    "session-lifetime-runner-returned",
    "session-lifetime-runner-runtime",
    "session-lifetime-runner-timeout",
    "unexpected",
}


class LaunchError(RuntimeError):
    """The private WDA launch contract could not be satisfied."""

    def __init__(self, phase: str) -> None:
        if phase not in FAILURE_PHASES:
            phase = "unexpected"
        self.phase = phase
        super().__init__(phase)


class AppiumKeepAliveEvent(asyncio.Event):
    """Keep WDA's XCTest transport open until Appium ends the session.

    WebDriverAgent's bootstrap test plan may report completion after its HTTP
    server is ready.  A normal PyMobileDevice3 run closes all DTX providers at
    that point, which also tears down the preinstalled runner.  Appium owns the
    longer session lifetime, so only an explicit keeper signal or a real DTX
    disconnect may end this run.
    """

    def set(self) -> None:
        pass

    def stop(self) -> None:
        """Complete the test plan only when Appium releases its ownership.

        XCTest's own completion callback must not end WDA while the Appium
        session is alive.  Conversely, cancelling XCUITestService.run during
        Appium cleanup closes its DTX providers abruptly and can leave
        testmanagerd unable to accept the next runner.  This explicit path
        lets the service unwind all three providers in protocol order.
        """
        super().set()


def completed_runner_phase(runner: asyncio.Task, prefix: str) -> str:
    """Reduce a completed XCTest task to an allowlisted, value-free phase."""
    if runner.cancelled():
        return f"{prefix}-runner-error"
    error = runner.exception()
    if error is None:
        return f"{prefix}-runner-returned"
    if isinstance(error, ConnectionTerminatedError):
        return f"{prefix}-runner-disconnected"
    if isinstance(error, TimeoutError):
        return f"{prefix}-runner-timeout"
    if isinstance(error, RuntimeError):
        return f"{prefix}-runner-runtime"
    return f"{prefix}-runner-error"


def parent_death_signal() -> None:
    """Ensure a crashed Appium parent cannot orphan an XCTest session."""
    if not sys.platform.startswith("linux"):
        raise LaunchError("host-platform")
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGTERM, 0, 0, 0) != 0:
        raise LaunchError("parent-death-signal")
    if os.getppid() == 1:
        raise LaunchError("parent-lost")


def read_request() -> dict:
    line = sys.stdin.buffer.readline(MAX_REQUEST_BYTES + 1)
    if (not line.endswith(b"\n") or len(line) > MAX_REQUEST_BYTES
            or b"\r" in line or b"\0" in line):
        raise LaunchError("request")
    try:
        value = json.loads(line)
    except (UnicodeError, json.JSONDecodeError) as error:
        raise LaunchError("request") from error
    keys = {"schemaVersion", "udid", "rsdHost", "rsdPort", "wdaBundleId",
            "wdaPort", "environment"}
    if (not isinstance(value, dict) or set(value) != keys
            or value.get("schemaVersion") != 1
            or isinstance(value.get("schemaVersion"), bool)
            or not isinstance(value.get("udid"), str)
            or not 8 <= len(value["udid"]) <= 128
            or any(character in value["udid"] for character in "\0\r\n")
            or not isinstance(value.get("rsdHost"), str)
            or not 2 <= len(value["rsdHost"]) <= 128
            or not isinstance(value.get("rsdPort"), int)
            or isinstance(value.get("rsdPort"), bool)
            or not 1 <= value["rsdPort"] <= 65535
            or not isinstance(value.get("wdaPort"), int)
            or isinstance(value.get("wdaPort"), bool)
            or value["wdaPort"] != 8100
            or not isinstance(value.get("wdaBundleId"), str)
            or len(value["wdaBundleId"]) > 255
            or not BUNDLE_ID.fullmatch(value["wdaBundleId"])):
        raise LaunchError("request")
    try:
        ipaddress.ip_address(value["rsdHost"].split("%", 1)[0])
    except ValueError as error:
        raise LaunchError("request-endpoint") from error
    environment = value.get("environment")
    if (not isinstance(environment, dict) or set(environment) != ENVIRONMENT_KEYS
            or any(not isinstance(item, str) or len(item) > 255
                   or any(character in item for character in "\0\r\n")
                   for item in environment.values())
            or environment.get("USE_PORT") != "8100"
            or environment.get("WDA_PRODUCT_BUNDLE_IDENTIFIER")
            != value["wdaBundleId"]):
        raise LaunchError("request-environment")
    return value


class OriginalKeeperSource:
    """Same-loop borrow from the ORIGINAL creator; construction opens nothing.

    The creator must already have selected its exclusive userspace path before
    any external Node tunnel is created. Nothing in this class can prove that
    missing cross-process selection or the Appium session route.
    """
    def __init__(self, tunnel):
        from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel
        if type(tunnel) is not UserspaceRsdTunnel:
            raise LaunchError("rsd-connect")
        self._tunnel = weakref.ref(tunnel)
        self._source = tunnel.original_source()
        self._loop = asyncio.get_running_loop()
        self._leases = []
        self._closing = False

    def current(self):
        tunnel = self._tunnel()
        if (tunnel is None or asyncio.get_running_loop() is not self._loop
                or tunnel.original_source() is not self._source):
            raise LaunchError("rsd-connect")
        return self._source.current()

    def touch_lease(self, store, *, binding, run, check):
        from ios.adapters.touch_lease import TouchLease
        from ios.adapters.hid_session import touch_session
        self.current()
        if self._closing:
            raise LaunchError("session-lifetime")
        async def continuity():
            self.current()
            result = check()
            if inspect.isawaitable(result):
                result = await result
            self.current()
            return result
        @asynccontextmanager
        async def session():
            rsd, local_address = self.current()
            # Existing touch context/default PyTCP socket stays on this exact
            # original stack. Its stop/await/close obligations remain unchanged.
            async with touch_session(rsd, local_address,
                                     socket_factory=self._source.udp_socket) as hid:
                self.current()
                yield hid
        lease = TouchLease(store, session, binding=binding, run=run, check=continuity)
        self._leases.append(lease)
        return lease

    async def settle_touches(self):
        # Close admission first. Cancellation is remembered until the original
        # workers settle; no original RSD may close underneath a pending Down.
        # This does not widen TouchLease's 12s intent or the parent's existing
        # stop/kill budgets, and is not device-side retirement evidence.
        self._closing = True
        failure = None
        for lease in self._leases:
            if lease.worker is None:
                continue
            try:
                await lease.release()
            except BaseException as error:
                failure = failure or error
            while not lease.worker.done():
                try:
                    await asyncio.shield(lease.worker)
                except BaseException as error:
                    failure = failure or error
        if failure is not None:
            raise failure


@asynccontextmanager
async def create_original_keeper_source(udid):
    """Original creator extension, only after exclusive creator selection.

    Not wired to main or Node: their kernel creator must be excluded BEFORE
    this function is called. It must never be used as a second-tunnel fallback.
    """
    from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel
    tunnel = UserspaceRsdTunnel(
        serial=udid, autopair=False, remotepairing_fallback=False,
        require_validated_source=True)
    async with tunnel:
        source = OriginalKeeperSource(tunnel)
        source.current()
        try:
            yield source
        finally:
            await source.settle_touches()


@asynccontextmanager
async def original_service_provider(request, original_source):
    if original_source is None:
        async with RemoteServiceDiscoveryService(
                (request["rsdHost"], request["rsdPort"])) as service_provider:
            yield service_provider
        return
    if type(original_source) is not OriginalKeeperSource:
        raise LaunchError("rsd-connect")
    service_provider, _address = original_source.current()
    if service_provider.udid != request["udid"]:
        raise LaunchError("rsd-identity")
    # The original creator retains its AsyncExitStack through this await; the
    # keeper never closes/recreates its borrowed RSD or tunnel.
    yield service_provider


async def run_xctest(request: dict, *, original_source=None) -> None:
    stop = asyncio.Event()
    loop = asyncio.get_running_loop()
    for signal_number in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(signal_number, stop.set)

    phase = "rsd-connect"
    try:
        async with original_service_provider(request, original_source) as service_provider:
            if service_provider.udid != request["udid"]:
                raise LaunchError("rsd-identity")
            if original_source is not None:
                original_source.current()
            phase = "xctest-config"
            configuration = await TestConfig.create_for(
                service_provider, runner_bundle_id=request["wdaBundleId"]
            )
            configuration.runner_app_env = request["environment"]
            keep_alive = AppiumKeepAliveEvent()
            phase = "xctest-start"
            runner = asyncio.create_task(
                XCUITestService(service_provider).run(
                    configuration, test_done_event=keep_alive
                ),
                name="overte-wda-xctest",
            )
            client = WdaServiceClient(
                service_provider=service_provider,
                port=request["wdaPort"],
                timeout=2.0,
            )
            deadline = loop.time() + READY_TIMEOUT_SECONDS
            phase = "wda-ready"
            while True:
                if original_source is not None:
                    original_source.current()
                if runner.done():
                    failure_phase = completed_runner_phase(runner, "wda-ready")
                    raise LaunchError(failure_phase)
                remaining = deadline - loop.time()
                if remaining <= 0:
                    raise LaunchError("wda-ready-timeout")
                try:
                    status = await asyncio.wait_for(
                        client.get_status(), timeout=min(2.5, remaining)
                    )
                    if original_source is not None:
                        original_source.current()
                except Exception:
                    await asyncio.sleep(min(0.1, max(0.0, deadline - loop.time())))
                    continue
                if (isinstance(status, dict)
                        and isinstance(status.get("value"), dict)
                        and status["value"].get("ready") is True):
                    break
                await asyncio.sleep(0.1)

            sys.stdout.write("READY\n")
            sys.stdout.flush()
            phase = "session-lifetime"
            stopped = asyncio.create_task(stop.wait(), name="overte-wda-stop")
            done, _pending = await asyncio.wait(
                {runner, stopped}, return_when=asyncio.FIRST_COMPLETED
            )
            if runner in done and not stop.is_set():
                failure_phase = completed_runner_phase(runner, "session-lifetime")
                raise LaunchError(failure_phase)
            if stop.is_set():
                keep_alive.stop()
                try:
                    await asyncio.wait_for(
                        asyncio.shield(runner),
                        timeout=GRACEFUL_STOP_TIMEOUT_SECONDS,
                    )
                except TimeoutError as error:
                    raise LaunchError("session-lifetime-runner-timeout") from error
                failure_phase = completed_runner_phase(runner, "session-lifetime")
                if failure_phase != "session-lifetime-runner-returned":
                    raise LaunchError(failure_phase)
    except LaunchError:
        raise
    except BaseException as error:
        raise LaunchError(phase) from error
    finally:
        if "runner" in locals() and not runner.done():
            runner.cancel()
            with suppress(asyncio.CancelledError, Exception):
                await runner


def main() -> int:
    try:
        parent_death_signal()
        if version("pymobiledevice3") != "11.1.5":
            raise LaunchError("runtime-version")
        asyncio.run(run_xctest(read_request()))
        return 0
    except BaseException as error:
        phase = error.phase if isinstance(error, LaunchError) else "unexpected"
        sys.stderr.write(
            f"error: immutable Fedora XCTest keeper failed phase={phase}\n"
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
