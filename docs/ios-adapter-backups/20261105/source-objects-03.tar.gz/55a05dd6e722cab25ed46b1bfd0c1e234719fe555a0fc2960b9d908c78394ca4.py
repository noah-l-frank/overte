"""Private source proposal builder. No adapter imports or execution."""
from pathlib import Path
import ast,difflib,hashlib,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
POST='tests/device/ios/adapters/avatar_postlogout_reads.py'
FINAL='tests/device/ios/adapters/avatar_final.py'
HELPER='tests/device/ios/adapters/avatar_postlogout_row_cache.py'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
helper='''"""Existing immutable original cache for one Final2 historical row.

No live owner, current pending row, input, freshness or quiet verdict enters
this memo. The complete prefix decoder still owns order/pending/inventory.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from types import FunctionType,BuiltinFunctionType
from adapters.native_feature_observation import need
from adapters.script_feature.history import same,canonical
from ios.adapters.avatar_record_cache import AvatarRecordCache

_OWNER=_GUARD=_GUARD_CODE=None
_BORN=();_BINDINGS=();_REFERENCES=[]
_CAPTURE=False


class _Unsupported(Exception):pass


def _data(value,depth=0):
    if depth>16:raise _Unsupported
    kind=type(value)
    if kind in (str,int,bool,type(None)):return (kind.__name__,value)
    if kind is float:return ('float',value.hex())
    if kind is FunctionType:
        if value.__closure__:raise _Unsupported
        if _CAPTURE:_REFERENCES.extend((value,value.__code__))
        return ('function',id(value),id(value.__code__),_data(value.__defaults__,depth+1),_data(value.__kwdefaults__,depth+1))
    if kind is BuiltinFunctionType:
        if _CAPTURE:_REFERENCES.append(value)
        return ('builtin',id(value))
    if kind in (set,frozenset):
        if not all(type(item) is str for item in value):raise _Unsupported
        return (kind.__name__,tuple(sorted(value)))
    if kind in (tuple,list):return (kind.__name__,tuple(_data(item,depth+1) for item in value))
    if kind is dict:
        if not all(type(key) is str for key in value):raise _Unsupported
        return ('dict',tuple((key,_data(value[key],depth+1)) for key in sorted(value)))
    raise _Unsupported


def _signature(function):
    if type(function) is not FunctionType or function.__closure__:raise _Unsupported
    return (function.__code__,_data(function.__defaults__),_data(function.__kwdefaults__))


def _lookup(owner,name):
    values=(owner,) if type(owner) is dict else ((vars(parent) for parent in owner.__mro__) if isinstance(owner,type) else (vars(owner),))
    for namespace in values:
        if name in namespace:
            value=namespace[name]
            return value.__func__ if type(value) in (staticmethod,classmethod) else value
    return None


def bind(owner,guard,readers,bindings):
    global _OWNER,_GUARD,_GUARD_CODE,_BORN,_BINDINGS,_CAPTURE
    _OWNER,_GUARD,_GUARD_CODE=owner,guard,guard.__code__
    _CAPTURE=True
    try:
        _BORN=tuple((container,name,_lookup(container,name),_signature(_lookup(container,name))) for container,name in readers)
        _BINDINGS=tuple((container,name,_lookup(container,name),None if mode=='identity' else _data(_lookup(container,name)))
            for container,name,mode in bindings)
    except (AttributeError,TypeError,ValueError,RecursionError,_Unsupported):_BORN=None
    finally:_CAPTURE=False


def _literal():
    if _BORN is None or _GUARD.__code__ is not _GUARD_CODE:return False
    try:
        return all(_lookup(container,name) is function and function.__code__ is signature[0]
            and _signature(function)==signature for container,name,function,signature in _BORN) and all(
            _lookup(container,name) is value and (token is None or _data(value)==token)
            for container,name,value,token in _BINDINGS)
    except (AttributeError,TypeError,ValueError,RecursionError,_Unsupported):return False


def read(owner,row,material,previous,index,policy,decode):
    cache=getattr(owner,'historical_rows',None)
    if (type(owner) is not _OWNER or not owner.historical or type(cache) is not AvatarRecordCache
            or row['status']!='observed' or owner.guard is not _GUARD or owner.originals.guard is not _GUARD
            or not _literal()):return decode()
    def header():
        owner.lock.assert_held()
        need(type(owner) is _OWNER and owner.historical and owner.historical_rows is cache
            and owner.guard is _GUARD and owner.originals.guard is _GUARD)
        original=owner.originals
        need(original.root==owner.root and same(original.binding,owner.binding) and original.run==owner.run
            and original.role==owner.role and original.kind=='sources')
        return dict(root=str(owner.root),store=str(owner.store.path),lock=str(owner.lock.path),
            binding=owner.binding,runId=owner.run,role=owner.role,subject=owner.subject,inputs=owner.inputs,
            original=dict(root=str(original.root),namespace=original.namespace,schema=original.schema_prefix,kind=original.kind))
    try:current_policy=_data(policy())
    except _Unsupported:return decode()
    before=canonical(header())
    # These are the actual current metadata, row/material and previous model.
    # Prefix length and a later pending row cannot authorize this old row.
    key=dict(avatarFinalPostLogoutRowVersion=1,owner=before.decode('ascii'),row=row,material=material,previous=previous,index=index,policy=current_policy)
    encoded=canonical(key)
    def checked():
        need(_literal() and _data(policy())==current_policy and canonical(header())==before and canonical(key)==encoded);answer=decode()
        need(_literal() and _data(policy())==current_policy and canonical(header())==before and canonical(key)==encoded);return answer
    if encoded not in cache.rows and len(cache.rows)>=512:return decode()
    answer=cache.read(key,checked)
    need(_literal() and _data(policy())==current_policy and canonical(header())==before and canonical(key)==encoded);return answer
'''
post=(ROOT/POST).read_text()
post=post.replace('from ios.adapters.emote_native_prefix import follow as native_prefix\n',
    'from ios.adapters.emote_native_prefix import follow as native_prefix\nfrom ios.adapters import avatar_postlogout_row_cache as row_cache\nfrom ios.adapters import avatar_account_reads as account_source\nfrom ios.adapters.avatar_record_cache import AvatarRecordCache\n')
post=post.replace('READS=(1,2)\n','READS=(1,2)\n\ndef _archived_guard():return True\n')
post=post.replace('monotonic=time.monotonic,historical=False):','monotonic=time.monotonic,historical=False,historical_rows=None):',1)
post=post.replace('        self.historical=historical\n','        need(historical_rows is None or historical and type(historical_rows) is AvatarRecordCache)\n        self.historical,self.historical_rows=historical,historical_rows\n        if historical_rows is not None:self.part_cache=historical_rows\n',1)
post=post.replace('            # no derived model/account/history verdict is reused.','            # Per-row historical reuse never supplies a current/quiet verdict.')
old="""            materials[index]=material;previous=self.part(material['parts'],previous)
            if row['original'] is not None:self.originals.original(row['original']);need(row['original']['index']==index)
            if row['acquisition'] is not None:self.acquisition(row['acquisition'])
            if row['status']=='observed':self._record_fields(row,material)
"""
new="""            materials[index]=material
            previous=self._historical_row(row,material,previous,index)
"""
assert post.count(old)==1;post=post.replace(old,new)
anchor='    def save(self):\n'
addition="""    def _historical_row(self,row,material,previous,index):
        def decode():
            model=self.part(material['parts'],previous)
            if row['original'] is not None:self.originals.original(row['original']);need(row['original']['index']==index)
            if row['acquisition'] is not None:self.acquisition(row['acquisition'])
            if row['status']=='observed':self._record_fields(row,material)
            return model
        def policy():return (VERSION,READS,avatar_state.VERSION,avatar_state.READS,account_source.VERSION)
        return row_cache.read(self,row,material,previous,index,policy,decode)

"""
assert post.count(anchor)==1;post=post.replace(anchor,addition+anchor)
post=post.replace('def archive(cls,value,store,root,binding,run,role,subject,lock,*,child_run,fixture_url,ticket,baseline,logout_before):',
    'def archive(cls,value,store,root,binding,run,role,subject,lock,*,child_run,fixture_url,ticket,baseline,logout_before,historical_rows=None):')
post=post.replace('return cls(Frozen(store.path),root,binding,run,role,subject,lock,lambda:True,lambda:need(False),lambda:need(False),',
    'return cls(Frozen(store.path),root,binding,run,role,subject,lock,_archived_guard,lambda:need(False),lambda:need(False),')
post=post.replace('baseline=baseline,logout_before=logout_before,historical=True)',
    'baseline=baseline,logout_before=logout_before,historical=True,historical_rows=historical_rows)')
post+='''

# These are the actual skipped parser dependencies, not a source inventory.
from adapters import native_feature_observation as native_source,native_account_observation as account_native
from adapters import native_animation_history as animation_native,recorded_preview_history as recorded_native
from adapters import native_clock_join as clock_source
from adapters.script_feature import history as history_source
from ios.adapters import avatar_bookmarks as bookmark_source,places_model as places_source
from ios.adapters import authentication_causality as causality_source,emote_native_prefix as prefix_source
from ios.adapters import authentication_origin as origin_source,login_source as login_parser
from feature_journeys import contract as feature_contract
import re as parser_re
import json as parser_json
import hashlib as parser_hashlib

row_cache.bind(IOSAvatarPostLogoutReads,_archived_guard,
    [(IOSAvatarPostLogoutReads,name) for name in ('part','_record_fields','_historical_row','row_material','row_partial_original',
        'resolved_parts','retained_partial','account','account_original','acquisition','native_file','part_parents','part_tag','part_value','part_complete')]
    +[(IOSAvatarAccountReads,name) for name in ('__init__','parse','packet','_pending','pending','command','partial_file','envelope')]
    +[(avatar_state,name) for name in ('_validate','command','history','text','identity','session','tree','exact','integer','number','need','fresh')]
    +[(bookmark_source,'original_bytes'),(places_source,'tree'),(places_source,'text')]
    +[(native_source,name) for name in ('validate','exact','integer','number','fresh','need')]
    +[(account_native,name) for name in ('validate','accept')]
    +[(animation_native,name) for name in ('validate','_validate','accept','clip')]
    +[(recorded_native,name) for name in ('validate_history','accept_history','phases')]
    +[(causality_source,name) for name in ('check','arguments','identifier','need','validate','source_nonce','accept','fixture_origin')]
    +[(origin_source,'origin'),(login_parser,'nonce')]
    +[(prefix_source,name) for name in ('follow','_follow')]
    +[(feature_contract,name) for name in ('arguments','identifier')]
    +[(clock_source,'digest')]
    +[(history_source,name) for name in ('canonical','same','pack','unpack')]
    +[(account_source,name) for name in ('validate','exact','integer','need','number','digest','pack','unpack','same','context','identifier')]
    +[(parser_re,'fullmatch'),(parser_json,'dumps'),(parser_json,'loads')]
    +[(globals(),name) for name in ('native','native_prefix','account_causality','exact','integer','need','number','canonical','same','digest')]
    +[(OriginalFrameStore,name) for name in ('__init__','read','original','file','path','key','bound','now')]
    +[(PrivateFeatureState,name) for name in ('read','_parent')]
    +[(AvatarRecordCache,name) for name in ('read','_read','signatures','absent')],
    [(module,name,'data') for module,names in (
        (avatar_state,('VERSION','READS','ACTION','LIMIT')),(account_source,('VERSION',)),
        (native_source,('LIMIT','BOUND_CLOCK_VERSION')),
        (account_native,('VERSION','SIGNALS','REPLIES','FIELDS','BOOLEANS','EVENT_FIELDS')),
        (recorded_native,('FIELDS','ACTIVE','TERMINAL','NEXT')),(causality_source,('VERSION','EMPTY')),
        (bookmark_source,('VERSION','SOURCE')),(places_source,('VERSION','LIMIT')))
        for name in names]
    +[(globals(),name,'identity') for name in ('IOSAvatarAccountReads','avatar_state','account_source','native','native_prefix','account_causality','OriginalFrameStore','PrivateFeatureState','AvatarRecordCache')]
    +[(module,name,'identity') for module,names in (
        (parser_re,('fullmatch',)),(parser_json,('dumps','loads')),(parser_hashlib,('sha256',)),
        (avatar_state,('json','re','IOSPlacesModel')),(native_source.math,('isfinite',)),
        (feature_contract,('HEX',)),(account_source,('validate','_native')))
        for name in names])
'''
final=(ROOT/FINAL).read_text()
final=final.replace("baseline=config['baseline']['state'],**common,**shared)",
    "baseline=config['baseline']['state'],historical_rows=getattr(self,'_postlogout_rows',None),**common,**shared)")
old="""            from ios.adapters.avatar_final_pure_round import scope
            with scope(self,value):return self._parse(value)
"""
new="""            from ios.adapters.avatar_final_pure_round import scope
            from ios.adapters.avatar_api_entry import original_cache
            from ios.adapters.avatar_record_cache import AvatarRecordCache
            existing=getattr(self,'_postlogout_rows',None)
            if existing is None:self._postlogout_rows=original_cache('postlogout-parts') or AvatarRecordCache()
            try:
                with scope(self,value):return self._parse(value)
            finally:
                if existing is None:del self._postlogout_rows
"""
assert final.count(old)==1;final=final.replace(old,new)
TEST='tests/device/ios/self_tests/test_ios_avatar_final_historical_row_cache.py'
test='''"""Real postlogout prefix files and Final2 wiring; native edges are models."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from adapters.normal_ui import NativeUIError
from adapters.original_frame_store import OriginalFrameStore
from adapters.original_file_reads import scope as read_scope
from ios.adapters.avatar_api_entry import scope as api_scope
from ios.adapters.avatar_postlogout_reads import IOSAvatarPostLogoutReads
from ios.adapters import avatar_state as state_source
from ios.adapters.avatar_record_cache import AvatarRecordCache
from ios.self_tests import test_ios_avatar_postlogout_reads as fixture
from ios.self_tests import test_ios_avatar_held_final as final_fixture


class AvatarHistoricalRowCacheTests(unittest.TestCase):
    def setUp(self):
        self.f=fixture.AvatarPostLogoutReadsTests();self.addCleanup(self.f.doCleanups);self.f.setUp()
        self.owner=self.f.owner();self.rows=[];self.prefixes=[]
        for _index in range(2):
            self.rows.append(self.owner.capture());self.prefixes.append(deepcopy(self.owner.previous))
        self.cache=AvatarRecordCache()

    def archive(self,value,cache):
        o=self.owner
        return IOSAvatarPostLogoutReads.archive(value,o.store,o.root,o.binding,o.run,o.role,o.subject,o.lock,
            child_run=o.inputs['childRunId'],fixture_url=o.inputs['fixtureUrl'],ticket=o.inputs['ticket'],
            baseline=o.inputs['baseline'],logout_before=o.inputs['logoutBefore'],historical_rows=cache)

    def account_path(self,history):
        parts=history.row_material(history.state['rows'][0])['parts'];before=parts['before'];o=self.owner
        originals=OriginalFrameStore(o.root,o.binding,o.run,o.role,lambda:True,lambda *_:None,
            namespace='avatar-'+o.subject+'-account-read',schema_prefix='avatar'+o.subject.capitalize()+'AccountRead')
        return originals.path(before['row']['original'])

    def test_growing_actual_prefix_reuses_completed_old_row_and_preserves_literal_membership_and_proof(self):
        literal=self.archive(self.prefixes[-1],None);expected=literal.proof(literal.state['rows'][-1]);queries=deepcopy(self.f.calls)
        first=self.archive(self.prefixes[0],self.cache)
        monitor=sys.monitoring;tool=next(i for i in range(6) if monitor.get_tool(i) is None)
        monitor.use_tool_id(tool,'avatar-actual-row-fields');seen=[];code=IOSAvatarPostLogoutReads._record_fields.__code__
        def call(actual,_offset):seen.append(actual)
        monitor.register_callback(tool,monitor.events.PY_START,call);monitor.set_local_events(tool,code,monitor.events.PY_START)
        try:
            # Only the genuinely new second row cold-decodes twice. The old
            # first row still receives the primitive's fresh original guards.
            second=self.archive(self.prefixes[-1],self.cache);self.assertEqual([code,code],seen)
            seen.clear();self.archive(self.prefixes[-1],self.cache);self.assertEqual([],seen)
            self.archive(self.prefixes[-1],None);self.assertEqual([code,code],seen);seen.clear()
            with read_scope(fresh=True) as a:actual=second.proof(second.state['rows'][-1])
            self.assertEqual([code],seen);seen.clear()
            with read_scope(fresh=True) as b:again=second.proof(second.state['rows'][-1])
            self.assertEqual([code],seen)
            self.assertEqual(expected,actual);self.assertEqual(actual,again);self.assertEqual(a,b)
            self.assertEqual(queries,self.f.calls)
            # Caller mutation cannot alter another archived state or input.
            second.state['rows'].clear();self.assertEqual(1,len(first.state['rows']))
            self.assertEqual(2,len(self.archive(self.prefixes[-1],self.cache).state['rows']))
        finally:
            monitor.set_local_events(tool,code,0);monitor.register_callback(tool,monitor.events.PY_START,None);monitor.free_tool_id(tool)

    def test_same_inode_account_bytes_changed_after_warm_prefix_refuse_without_transport(self):
        history=self.archive(self.prefixes[-1],self.cache);path=self.account_path(history);raw=path.read_bytes();before=path.stat();queries=deepcopy(self.f.calls)
        directory=TemporaryDirectory();self.addCleanup(directory.cleanup);outside=Path(directory.name);outside.chmod(0o700)
        saved=outside/'original-account-bytes';saved.write_bytes(raw);saved.chmod(0o600)
        path.write_bytes(raw[:-1]+(b' ' if raw[-1:]!=b' ' else b'\\n'));self.assertEqual(before.st_ino,path.stat().st_ino)
        with self.assertRaises(NativeUIError):history.parse(self.prefixes[-1])
        self.assertEqual(raw,saved.read_bytes());self.assertEqual(queries,self.f.calls)

    def test_same_bytes_replaced_account_inode_refuses_without_unknown_membership_mask(self):
        history=self.archive(self.prefixes[-1],self.cache);path=self.account_path(history);raw=path.read_bytes();before=path.stat();queries=deepcopy(self.f.calls)
        directory=TemporaryDirectory();self.addCleanup(directory.cleanup);outside=Path(directory.name);outside.chmod(0o700)
        saved=outside/'original-account-inode';os.replace(path,saved)
        with path.open('xb') as stream:stream.write(raw)
        path.chmod(0o600);self.assertEqual(before.st_ino,saved.stat().st_ino);self.assertNotEqual(before.st_ino,path.stat().st_ino)
        with self.assertRaises(NativeUIError):history.parse(self.prefixes[-1])
        self.assertEqual(raw,saved.read_bytes());self.assertEqual(queries,self.f.calls)

    def test_wrong_previous_model_and_changed_actual_parser_do_not_borrow_old_row(self):
        history=self.archive(self.prefixes[-1],self.cache);row=history.state['rows'][1];material=history.row_material(row)
        previous=deepcopy(history.row_parts(history.state['rows'][0])['model'])
        previous['sequence']=material['parts']['model']['sequence'];queries=deepcopy(self.f.calls)
        with self.assertRaises(NativeUIError):history._historical_row(row,material,previous,2)
        function=IOSAvatarPostLogoutReads.part;code=function.__code__;defaults=function.__defaults__
        def reject(self,value,previous=None):raise RuntimeError('Actual changed postlogout parser')
        try:
            function.__code__=reject.__code__
            with self.assertRaisesRegex(RuntimeError,'Actual changed postlogout parser'):history.parse(self.prefixes[-1])
        finally:
            function.__code__=code;function.__defaults__=defaults
            self.assertIs(function.__code__,code);self.assertIs(function.__defaults__,defaults)
        # A metadata/default change must take the literal decoder even when
        # this explicit call's successful result would otherwise be identical.
        monitor=sys.monitoring;tool=next(i for i in range(6) if monitor.get_tool(i) is None)
        monitor.use_tool_id(tool,'avatar-row-current-defaults');seen=[];observed=IOSAvatarPostLogoutReads._record_fields.__code__
        def call(actual,_offset):seen.append(actual)
        monitor.register_callback(tool,monitor.events.PY_START,call);monitor.set_local_events(tool,observed,monitor.events.PY_START)
        try:
            function.__defaults__=([],)
            history.parse(self.prefixes[-1]);self.assertEqual([observed,observed],seen);seen.clear()
            function.__defaults__=defaults
            history.parse(self.prefixes[-1]);self.assertEqual([],seen)
            reads=state_source.READS
            try:
                state_source.READS=(1,2)
                with self.assertRaises(NativeUIError):history.parse(self.prefixes[-1])
            finally:state_source.READS=reads
        finally:
            function.__defaults__=defaults
            monitor.set_local_events(tool,observed,0);monitor.register_callback(tool,monitor.events.PY_START,None);monitor.free_tool_id(tool)
        self.assertEqual(queries,self.f.calls)


class AvatarFinalHistoricalRowWiringTests(unittest.TestCase):
    def test_existing_Final2_archive_borrows_original_API_cache_and_still_computes_quiet_from_three_actual_groups(self):
        f=final_fixture.AvatarHeldFinalTests();self.addCleanup(f.doCleanups);f.setUp()
        with api_scope(lambda:f.f.clock[0]):
            owner=f.owner();references=[]
            for sequence in (1,2,3):
                if references:f.f.clock[0]+=1.7
                references.append(f.f.capture(owner,sequence))
            expected=owner.quiet(references,sequence=4);queries={subject:list(boundary.commands) for subject,boundary in f.web.items()}
            monitor=sys.monitoring;tool=next(i for i in range(6) if monitor.get_tool(i) is None)
            monitor.use_tool_id(tool,'avatar-final-real-row-wiring');seen=[];code=IOSAvatarPostLogoutReads._record_fields.__code__
            def call(actual,_offset):seen.append(actual)
            monitor.register_callback(tool,monitor.events.PY_START,call);monitor.set_local_events(tool,code,monitor.events.PY_START)
            try:
                archive=f.archive(owner)
                # Six actual archived subject/groups retain both selected-row
                # reads (proof + record); old-prefix parse interpretations hit.
                self.assertEqual(12,len(seen));self.assertEqual(expected,archive.quiet(references,sequence=4))
                self.assertEqual(queries,{subject:list(boundary.commands) for subject,boundary in f.web.items()})
            finally:
                monitor.set_local_events(tool,code,0);monitor.register_callback(tool,monitor.events.PY_START,None);monitor.free_tool_id(tool)
'''
candidates={HELPER:helper,POST:post,FINAL:final,TEST:test};manifest={};diff=''
for path,text in candidates.items():
    ast.parse(text,filename=path);target=HERE/'candidate'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
    previous=(ROOT/path).read_bytes() if (ROOT/path).exists() else None
    if previous is not None:
        before=HERE/'originals'/path;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(previous)
    manifest[path]=dict(baseSha256=None if previous is None else hashlib.sha256(previous).hexdigest(),candidateSha256=sha(target))
    diff+=''.join(difflib.unified_diff([] if previous is None else previous.decode().splitlines(True),text.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(HERE/'candidate-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n');(HERE/'proposal.diff').write_text(diff)
print(json.dumps(manifest,indent=2))
