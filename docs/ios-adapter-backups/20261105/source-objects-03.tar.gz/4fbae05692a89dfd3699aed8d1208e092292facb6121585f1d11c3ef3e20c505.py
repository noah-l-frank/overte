"""Literal Python original-keeper OS originals, separate from the Node codec."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,integer,need,number
from feature_journeys.contract import identifier


def clocks(before,after,limit=1500):
    for row in (before,after):
        exact(row,{'epochMs','monotonicMs'})
        need(number(row['epochMs'],1,1e15)and number(row['monotonicMs'],0,1e15))
    epoch=after['epochMs']-before['epochMs'];mono=after['monotonicMs']-before['monotonicMs']
    need(0<=epoch<limit and 0<=mono<limit and abs(epoch-mono)<=250)


def process(value,owner):
    exact(value,{'iosOriginalKeeperProcessVersion','source','ownerInstance','bundlePids','pidChecks','clockDomain',
        'clockBefore','clockAfter','providerExitReturned','providerDtxCleared','resourceRetirementEstablished'})
    need(type(value['iosOriginalKeeperProcessVersion'])is int and value['iosOriginalKeeperProcessVersion']==1
        and value['source']=='pmd-original-rsd-dvt'and value['clockDomain']=='python-original-keeper-host'
        and value['ownerInstance']==identifier(owner)and value['providerExitReturned']is True
        and value['providerDtxCleared']is True and value['resourceRetirementEstablished']is False
        and type(value['bundlePids'])is list and len(value['bundlePids'])==2
        and all(integer(pid,0,2147483647)for pid in value['bundlePids'])
        and type(value['pidChecks'])is list and len(value['pidChecks'])==2 and all(type(v)is bool for v in value['pidChecks']))
    clocks(value['clockBefore'],value['clockAfter']);return value


def os_row(row,*,binding,run,role,owner,instance,previous=None):
    exact(row,{'iosOriginalKeeperOSVersion','binding','runId','role','ownerInstance','nativeFeatureInstance','processId',
        'source','clockDomain','before','after','process'})
    need(type(row['iosOriginalKeeperOSVersion'])is int and row['iosOriginalKeeperOSVersion']==1
        and row['binding']==binding and row['runId']==run and row['role']==role and row['ownerInstance']==owner
        and row['nativeFeatureInstance']==instance and type(row['processId'])is int
        and str(row['processId'])==binding['processIdentity']and row['source']=='pmd-original-rsd-dvt'
        and row['clockDomain']=='python-original-keeper-host')
    clocks(row['before'],row['after']);raw=process(row['process'],owner)
    for key in ('epochMs','monotonicMs'):
        need(row['before'][key]<=raw['clockBefore'][key]<=raw['clockAfter'][key]<=row['after'][key])
        if previous is not None:need(row['before'][key]>=previous['after'][key])
    return row


def suffix(rows):
    result=[]
    for row in rows:
        if row['process']['bundlePids']==[0,0]and row['process']['pidChecks']==[False,False]:result.append(row)
        else:result=[]
    return result


def quiet(rows,*,owner,pid,complete=True):
    rows=suffix(rows)
    if len(rows)<3:return None if not complete else need(False)
    first,last=rows[0],rows[-1]
    durations=[last['before'][key]-first['after'][key]for key in ('epochMs','monotonicMs')]
    durations += [last['process']['clockBefore'][key]-first['process']['clockAfter'][key]for key in ('epochMs','monotonicMs')]
    if min(durations)<3000:return None if not complete else need(False)
    need(max(durations)<30000 and max(durations)-min(durations)<=500)
    return dict(source='pmd-original-rsd-dvt',clockDomain='python-original-keeper-host',instance=identifier(owner),
        processId=int(pid),samples=len(rows),originalSha256=digest(rows),
        hostAfterFirstEpochMs=first['after']['epochMs'],hostBeforeLastEpochMs=last['before']['epochMs'],
        hostAfterFirstMonotonic=first['after']['monotonicMs']/1000,hostBeforeLastMonotonic=last['before']['monotonicMs']/1000,
        osAfterFirstEpochMs=first['process']['clockAfter']['epochMs'],osBeforeLastEpochMs=last['process']['clockBefore']['epochMs'],
        osAfterFirstMonotonicMs=first['process']['clockAfter']['monotonicMs'],osBeforeLastMonotonicMs=last['process']['clockBefore']['monotonicMs'])
