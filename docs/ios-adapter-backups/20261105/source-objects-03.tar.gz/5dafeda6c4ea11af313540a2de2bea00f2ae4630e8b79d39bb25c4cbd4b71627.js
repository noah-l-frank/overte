"use strict";
(function () {
    var companion = Script.require("./companion.js");
    var marker = Entities.addEntity({
        type: "Web", name: "e2e-cccccccccccccccccccccccccccccccc-script",
        userData: "{\"kind\":\"avatar-marker-v1\",\"nonce\":\"ac18864d5d723e8f21d224ab53b3fcc8\",\"runId\":\"cccccccccccccccccccccccccccccccc\"}",
        position: Vec3.sum(MyAvatar.position,
            Vec3.multiplyQbyV(MyAvatar.orientation, {x: 0, y: 1.6, z: -3})),
        rotation: MyAvatar.orientation,
        dimensions: {x: 1.6, y: 0.4, z: 0.01},
        sourceUrl: "https://localhost:35951/feature-fixture/v1/runs/cccccccccccccccccccccccccccccccc/tickets/bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb/graphics-marker.v1.html", visible: true, collisionless: true, dpi: 100
    }, "local");
    Script.scriptEnding.connect(function () {
        if (marker) { Entities.deleteEntity(marker); }
    });
}());
