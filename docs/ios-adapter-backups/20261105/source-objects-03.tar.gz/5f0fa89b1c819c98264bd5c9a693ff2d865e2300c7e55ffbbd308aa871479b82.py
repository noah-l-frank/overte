"""One unchanged-body World789 measurement clone, text/AST and pins only."""
from pathlib import Path
import ast,hashlib,json,stat
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
BASE=ROOT/'.ios-host-tmp/world-web-lru-actual789-unprofiled-api25-preparation-20261028'
TABLET=ROOT/'.ios-host-tmp/tablet-parent-guard-metadata-fast-root8-preparation-20261028'
MEMO=ROOT/'.ios-host-tmp/tablet-parent-guard-metadata-fast-same328-profile-preparation-20261028'
PROJECTION=ROOT/'.ios-host-tmp/world-web-projection-detached-copy-root12-preparation-20261028'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    before=path.lstat();assert stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode)
    result={key:getattr(before,key) for key in FIELDS}
    if stat.S_ISREG(before.st_mode):result['sha256']=sha(path)
    after=path.lstat();assert all(getattr(before,key)==getattr(after,key) for key in FIELDS)
    return result
assert not (HERE/'freeze.json').exists()
for name in ('measure-saved-once.py','source-root-map.json','profile_metadata.py','prepare-actual-map.py','root-supervise-profile.py'):
    (HERE/name).write_bytes((BASE/name).read_bytes())
assert sha(HERE/'measure-saved-once.py')==sha(BASE/'measure-saved-once.py')
plan=json.loads((BASE/'profile-plan.json').read_text())
assert plan['innerExistingAPISeconds']==25 and plan['outerInitialSeconds']==90 and plan['killAfterSeconds']==5
plan['status']='FROZEN_PRIVATE_QUALIFIED_PROJECTION_COPY_SAME789_UNPROFILED_API25_UNRUN'
for name,wanted in plan['publicWorldSourceRequiredSha256'].items():assert sha(ROOT/name)==wanted,name
for name in ('tests/device/ios/adapters/world_web_snapshot_parts.py','tests/device/ios/adapters/world_web_json_pair.py'):
    plan['publicWorldSourceRequiredSha256'][name]=sha(ROOT/name)
assert plan['publicWorldSourceRequiredSha256']['tests/device/ios/adapters/world_web_snapshot_parts.py']=='a7851ad421992706518d4adbcd99c2be3afa1aa3f1ac2577d9d4ca35328cbd0b'
plan['requiredPassedSelections'].append(dict(report=str((PROJECTION/'projection12-report.json').relative_to(ROOT)),
    sourceMap=str((PROJECTION/'projection12-source-before.json').relative_to(ROOT)),count=12,
    sourcePaths=['tests/device/ios/adapters/world_web_snapshot_parts.py','tests/device/ios/adapters/world_web_json_pair.py']))
plan['comparisonBaseline']=dict(preparation=str(BASE.relative_to(ROOT)),innerSeconds=19.118008778008516,parentSeconds=21.397,
    bodySha256=sha(BASE/'measure-saved-once.py'),meaning='Same supported passive API25 closure only; never complete product flow')
plan['memoComparison']='Qualified projection-copy Source only; same original789/unprofiled body/API25/root controls. No source/method/clock replacements.'
prior=json.loads((TABLET/'retained-prior-original-pins.json').read_text())
for name,wanted in prior.items():assert pin(ROOT/name)==wanted,name
def controls(prep,kind,expected_code=None):
    report=json.loads((prep/(kind+'-report.json')).read_text())
    assert report['allPinsEqual'] and report['postStopCensusesQualified']
    if expected_code is not None:assert report['exitCode']==expected_code
    run=Path(report.get('runRoot',report.get('outputRoot')));temporary=run/'temporary'
    if temporary.is_dir():
        for path in (temporary,*sorted(temporary.rglob('*'))):prior[str(path.relative_to(ROOT))]=pin(path)
    for path in run.iterdir():
        if path.is_file():prior[str(path.relative_to(ROOT))]=pin(path)
    for path in prep.glob(kind+'-*'):
        if path.is_file():prior[str(path.relative_to(ROOT))]=pin(path)
controls(PROJECTION,'projection12',0);controls(TABLET,'target8',0);controls(MEMO,'root-profile',0);controls(BASE,'root-measure',0)
save(HERE/'retained-prior-original-pins.json',prior)
plan['retainedPriorPinsSha256']=sha(HERE/'retained-prior-original-pins.json')
plan['nativeDependencies']='No Native candidate-specific hash is required. Current broad source/registry byte-stat pins are Root-generated when ready; Native correction may remain private.'
plan['explicitExtraSourcePins'] += [str((PROJECTION/'projection12-report.json').relative_to(ROOT)),
    str((PROJECTION/'projection12-source-before.json').relative_to(ROOT)),str((TABLET/'target8-report.json').relative_to(ROOT)),
    str((MEMO/'root-profile-report.json').relative_to(ROOT)),str((BASE/'root-measure-report.json').relative_to(ROOT))]
save(HERE/'profile-plan.json',plan)
meta=(HERE/'profile_metadata.py').read_text()
meta=meta.replace("for source in value['qualifiedPureSourcePaths']:","for source in required.get('sourcePaths',value['qualifiedPureSourcePaths']):")
meta+='''
def prior_originals(value):
    path=HERE/'retained-prior-original-pins.json';assert sha(path)==value['retainedPriorPinsSha256']
    wanted=json.loads(path.read_text());actual={name:pin(REPO/name) for name in wanted}
    assert actual==wanted,'Previous actual originals/raw/control results changed'
    return actual
'''
(HERE/'profile_metadata.py').write_text(meta)
prepare=(HERE/'prepare-actual-map.py').read_text().replace('save,sources','save,sources,prior_originals')
prepare=prepare.replace('before=sources(value);old=originals(value);','before=sources(value);old=originals(value);prior_originals(value);')
(HERE/'prepare-actual-map.py').write_text(prepare)
supervisor=(HERE/'root-supervise-profile.py').read_text().replace('save,sources','save,sources,prior_originals')
supervisor=supervisor.replace('old=originals(value)\n','old=originals(value);prior_before=prior_originals(value)\n',1)
supervisor=supervisor.replace('remaining_before=owned();first=originals(value);','remaining_before=owned();prior_after=prior_originals(value);first=originals(value);')
supervisor=supervisor.replace('diagnosticOnly=True,','priorOriginalsUnchanged=prior_before==prior_after,diagnosticOnly=True,')
supervisor=supervisor.replace("and not remaining_before and not remaining_after\nraise", "and prior_before==prior_after and not remaining_before and not remaining_after\nraise")
(HERE/'root-supervise-profile.py').write_text(supervisor)
(HERE/'ROOT-REVIEW.txt').write_text('''ROOT ONLY / UNRUN. Same789 supported unprofiled measurement literal body is
byte-identical to original19.118008778inner/21.397parent baseline. Exact existing
API25, outer90+kill5, original inode/byte/membership/thread/process/root controls.
No method replacements, extra native grants, inputs, clock/cap changes.
Only current qualified projection copy Source a785 plus existing pair helper
join explicit source requirements. Old LRU3 remain byte-identical and verified
against their historical passed source maps. Projection12 has its own per-row
source requirement: old LRU runs cannot claim the newer projection hash.
All current Native source/registry are broad-pinned freshly, with no dependency
on a not-yet-published Native correction or declared authentication authority.

Preserve same789 plus measured19.118/raw controls, projection12's18 originals,
Tablet8's328 originals and newest memo328 profile controls, older original
corpora. No ready map copied; Root chooses metadata snapshot after current
publication state is stable. No Target imports/tests/run by author.
  PYTHONDONTWRITEBYTECODE=1 python3 -B <this-dir>/prepare-actual-map.py
  PYTHONDONTWRITEBYTECODE=1 python3 -B <this-dir>/root-supervise-profile.py
No full journey/native/performance claim; report actual current inner timing,
operation stages and unchangedOriginals/error. Preserve any first failure.
''')
for path in HERE.glob('*.py'):ast.parse(path.read_text(),filename=str(path))
assert sha(HERE/'measure-saved-once.py')==sha(BASE/'measure-saved-once.py')
files={str(path.relative_to(HERE)):sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!='freeze.json'}
save(HERE/'freeze.json',dict(status='FROZEN_PRIVATE_SAME789_PROJECTION_COPY_UNPROFILED_UNRUN',files=files))
print(json.dumps(dict(freezeSha256=sha(HERE/'freeze.json'),bodySha256=sha(HERE/'measure-saved-once.py'),priorNodes=len(prior),outerSeconds=90,innerSeconds=25),indent=2))
