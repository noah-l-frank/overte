"""Separate durable native2/palette2/post-controller1 source ownership.

A retained Emote source is only an immutable source/phase floor. Fresh native
and phase originals come from their genuine readers. Interrupted reads cannot
be repeated; only a complete already-opened OFS original can be recovered.
This family grants no normal input, Finish, deletion or current-effect verdict.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib
import os
from pathlib import Path
import time
from adapters.native_animation_history import accept
from adapters.native_clock_join import NativeClockAcquisition,digest,validate_join
from adapters.native_feature_observation import NativeFeatureObservation,exact,integer,need,number
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_file_reads import record as record_original_read
from adapters.original_frame_store import OriginalFrameStore,BLOCK,MAX_FRAMES
from adapters.script_feature.history import pack,unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import identifier
from feature_journeys.phase_fixture import PhaseFixtureReader,validate as phase_packet
from ios.adapters.emote_native_prefix import follow
from ios.adapters.emote_palette_original import IOSEmotePalette,ACTION,validate as palette_packet
from ios.adapters.emote_sources import IOSEmoteSources,EmotePhaseChanged

VERSION=1
NAMESPACE='emote-post-controller'
PREFIX='emotePostController'
RETURNED=('phaseBefore','nativeStart','palette','clockJoin','phaseAfter')


class IOSEmotePostControllerSources:
    def __init__(self,store,sources,*,guard=None,phase=None,native=None,palette=None,
                 historical=False,epoch_ms=lambda:time.time()*1000,monotonic=time.monotonic):
        need(type(historical)is bool and isinstance(sources,IOSEmoteSources)
            and isinstance(store,PrivateFeatureState)and isinstance(sources.lock,ScriptSourceLock))
        self.sources,self.store,self.historical=sources,store,historical
        self.root,self.binding,self.run,self.role,self.lock=sources.root,deepcopy(context(sources.binding)),identifier(sources.run),sources.role,sources.lock
        self.pid=int(self.binding['processIdentity']);need(self.pid>0 and str(self.pid)==self.binding['processIdentity'])
        need(store.path==sources.store.path.with_name('ios-emote-'+self.role+'-post-controller-sources.json'))
        self.guard,self.phase,self.native,self.palette=guard,phase,native,palette
        self.epoch_ms,self.monotonic=epoch_ms,monotonic
        need(callable(epoch_ms)and callable(monotonic))
        if historical:need(all(value is None for value in(guard,phase,native,palette)))
        else:
            need(callable(guard)and isinstance(phase,PhaseFixtureReader)and phase.run==self.run and phase.area=='emotes'
                and type(palette)is IOSEmotePalette and isinstance(native,NativeFeatureObservation)
                and native.ios and native.native_clock_bound and native.pid==palette.pid==self.pid)
        self.failed=False;self.lock.assert_held()
        self.originals=OriginalFrameStore(self.root,self.binding,self.run,self.role,
            self.file_guard,self.storage_intent,namespace=NAMESPACE,schema_prefix=PREFIX,monotonic=monotonic)
        self.previous=store.read();self.state=dict(phase='ready',revision=0,manifests=[],pending=None)
        self.frames=[]
        if self.previous is not None:self.state,self.frames=self.decode(self.previous)

    def file_guard(self):
        self.lock.assert_held()
        return self.historical or self.guard()is not False

    def envelope(self,state):
        return dict(iosEmotePostControllerSourcesVersion=VERSION,runId=self.run,role=self.role,
            binding=self.binding,artifactRoot=str(self.root),payload=pack([state]))

    def source_original(self,reference):
        """Open the actual old OFS original, not an injected frame or live DTO."""
        self.sources.lock.assert_held();need(same(self.sources.store.read(),self.sources.previous))
        self.sources.originals.original(reference)
        need(reference['phase']=='saved'and reference['index']<=self.sources.state['revision'])
        block=(reference['index']-1)//BLOCK;offset=(reference['index']-1)%BLOCK
        entries=self.sources.originals.manifest(self.sources.state['manifests'][block])
        need(same(self.sources.originals.expand(entries[offset]),reference))
        value=self.sources.originals.read(reference);need(self.sources.validate_frame(value))
        return value

    def validate_frame(self,value,previous=None):
        exact(value,{'iosEmotePostControllerFrameOriginalVersion','sourceReference','phaseBefore','phaseAfter',
            'palette','acquisition','clockJoin'})
        need(type(value['iosEmotePostControllerFrameOriginalVersion'])is int
            and value['iosEmotePostControllerFrameOriginalVersion']==VERSION)
        anchor=self.source_original(value['sourceReference']);join=value['clockJoin'];packet=value['palette']
        originals=dict(palette=packet,paletteClock=dict(capturedEpochMs=packet['clockAfter']['epochMs']))
        validate_join(join,originals);follow(anchor['clockJoin']['nativeAfter'],join['nativeBefore'])
        follow(join['nativeBefore'],join['nativeAfter']);need(join['nativeBefore']['processId']==self.pid)
        need(join['hostBeforeEpochMs']>=anchor['clockJoin']['hostAfterEpochMs']
            and join['hostBeforeMonotonic']>=anchor['clockJoin']['hostAfterMonotonic'])
        palette_packet(packet,dict(schemaVersion=1,commandId=packet['requestId'],action=ACTION,runId=self.run),
            self.pid,join['nativeAfter']['capturedEpochMs'],None if previous is None else previous['palette'])
        need(join['nativeBefore']['capturedEpochMs']<=packet['clockBefore']['epochMs']
            <=packet['clockAfter']['epochMs']<=join['nativeAfter']['capturedEpochMs'])
        # Native history and the separate post-controller record keep their
        # original evaluations/clocks. No requested clip or desired matrix.
        state=None
        for animation in(anchor['group']['native']['animation'],join['nativeBefore']['animation'],
                packet['source']['observation']['animation'],join['nativeAfter']['animation']):
            state=accept(state,animation['rigId'],animation['history'])
        acquisition=value['acquisition'];exact(acquisition,{'iosEmotePostControllerPaletteAcquisitionVersion',
            'hostBeforeMonotonic','hostAfterMonotonic','nativeRequestedEpochMs','nativeAfterEpochMs',
            'originalSha256','nativeBeforeOriginalFloorSha256'})
        need(type(acquisition['iosEmotePostControllerPaletteAcquisitionVersion'])is int
            and acquisition['iosEmotePostControllerPaletteAcquisitionVersion']==1
            and acquisition['originalSha256']==digest(packet)
            and acquisition['nativeBeforeOriginalFloorSha256']==digest(join['nativeBefore'])
            and acquisition['nativeRequestedEpochMs']==join['nativeBefore']['capturedEpochMs']
            and integer(acquisition['nativeAfterEpochMs'],packet['clockAfter']['epochMs'],join['nativeAfter']['capturedEpochMs'])
            and number(acquisition['hostBeforeMonotonic'],join['hostBeforeMonotonic'],join['hostAfterMonotonic'])
            and number(acquisition['hostAfterMonotonic'],acquisition['hostBeforeMonotonic'],join['hostAfterMonotonic'])
            and acquisition['hostAfterMonotonic']-acquisition['hostBeforeMonotonic']<1.5)
        first,last=value['phaseBefore'],value['phaseAfter']
        phase_packet(first,run=self.run,area='emotes',request=first['requestId'],epoch=join['hostBeforeEpochMs'],previous=anchor['phaseAfter'])
        phase_packet(last,run=self.run,area='emotes',request=last['requestId'],epoch=join['hostAfterEpochMs'],previous=first)
        need(first['active']and last['active']and bool(first['activations'])and bool(last['activations'])
            and first['activations'][-1]['activatedEpochMs']<=join['hostBeforeEpochMs'])
        if previous is not None:
            self.validate_frame(previous);follow(previous['clockJoin']['nativeAfter'],join['nativeBefore'])
            need(value['sourceReference']['index']>=previous['sourceReference']['index']
                and join['hostBeforeEpochMs']>=previous['clockJoin']['hostAfterEpochMs']
                and join['hostBeforeMonotonic']>=previous['clockJoin']['hostAfterMonotonic'])
            phase_packet(first,run=self.run,area='emotes',request=first['requestId'],epoch=join['hostBeforeEpochMs'],previous=previous['phaseAfter'])
        return anchor['phaseAfter']['activations'][-1]['ticket']==first['activations'][-1]['ticket']==last['activations'][-1]['ticket']

    def decode(self,value):
        exact(value,{'iosEmotePostControllerSourcesVersion','runId','role','binding','artifactRoot','payload'})
        need(type(value['iosEmotePostControllerSourcesVersion'])is int and value['iosEmotePostControllerSourcesVersion']==VERSION)
        rows=unpack(value['payload']);need(len(rows)==1 and same(value,self.envelope(rows[0])))
        state=rows[0];exact(state,{'phase','revision','manifests','pending'})
        need(state['phase']in('ready','reading')and integer(state['revision'],0,MAX_FRAMES))
        frames=self.originals.restore(state['manifests'],state['revision']);prior=None
        for frame in frames:self.validate_frame(frame,prior);prior=frame
        if state['phase']=='ready':need(state['pending']is None)
        else:
            p=state['pending'];exact(p,{'sourceReference','stage','returned','original','manifest'})
            self.source_original(p['sourceReference']);need(p['stage']in('phase-before-query','native-before-query',
                'palette-query','native-after-query','phase-after-query','storing'))
            need(type(p['returned'])is list and p['returned']==list(RETURNED[:len(p['returned'])]))
            if p['original']is not None:
                self.originals.original(p['original']);need(p['stage']=='storing'and p['returned']==list(RETURNED)
                    and p['original']['index']==state['revision']+1)
            if p['manifest']is not None:
                exact(p['manifest'],{PREFIX+'ManifestVersion','reference','phase'})
                need(type(p['manifest'][PREFIX+'ManifestVersion'])is int and p['manifest'][PREFIX+'ManifestVersion']==1
                    and p['manifest']['phase']in('planned','saved')and p['original']is not None and p['original']['phase']=='saved')
                self.originals.manifest_reference(p['manifest']['reference'])
                ref=p['manifest']['reference'];need(ref['block']==state['revision']//BLOCK+1 and ref['count']==state['revision']%BLOCK+1)
        return deepcopy(state),deepcopy(frames)

    def bound(self):
        self.lock.assert_held();need(not self.failed and same(self.store.read(),self.previous)and self.file_guard())

    def save(self):
        need(not self.historical);self.bound();value=self.envelope(self.state)
        try:
            self.store.write(value,self.previous);need(same(self.store.read(),value));self.previous=deepcopy(value)
        except Exception:self.failed=True;raise

    def storage_intent(self,kind,value):
        need(not self.historical and kind in('original','manifest')and self.state['phase']=='reading')
        pending=self.state['pending'];need(pending['stage']=='storing');old=pending[kind]
        if kind=='original':
            self.originals.original(value);need(value['index']==self.state['revision']+1)
            if old is None:need(value['phase']=='planned')
            else:need(value['phase']=={'planned':'opened','opened':'saved'}.get(old['phase'])
                and all(same(value[k],old[k])for k in value if k not in('phase','file'))
                and(old['phase']=='planned'or same(value['file'],old['file'])))
        else:
            exact(value,{PREFIX+'ManifestVersion','reference','phase'});self.originals.manifest_reference(value['reference'])
            need(type(value[PREFIX+'ManifestVersion'])is int and value[PREFIX+'ManifestVersion']==1
                and pending['original']is not None and pending['original']['phase']=='saved'
                and value['reference']['block']==self.state['revision']//BLOCK+1
                and value['reference']['count']==self.state['revision']%BLOCK+1)
            need(value['phase']=='planned'if old is None else old['phase']=='planned'and value['phase']=='saved'
                and same(value['reference'],old['reference']))
        pending[kind]=deepcopy(value);self.save()

    def stage(self,value):self.state['pending']['stage']=value;self.save()
    def returned(self,name):
        p=self.state['pending'];need(name==RETURNED[len(p['returned'])]);p['returned'].append(name);self.save()

    def read(self,source_reference):
        need(not self.historical);self.bound();need(self.state['phase']=='ready'and self.state['revision']<MAX_FRAMES)
        need(self.sources.state['phase']=='ready'and self.sources.state['pending']is None)
        anchor=self.source_original(source_reference)
        self.state.update(phase='reading',pending=dict(sourceReference=deepcopy(source_reference),stage='phase-before-query',returned=[],original=None,manifest=None));self.save()
        first=self.phase.read(anchor['phaseAfter']);self.returned('phaseBefore');self.stage('native-before-query')
        window=NativeClockAcquisition(self.native,epoch_ms=self.epoch_ms,monotonic=self.monotonic)
        window.begin(first['afterEpochMs']);self.returned('nativeStart');self.stage('palette-query')
        packet=self.palette.read(self.run,native_before_floor=window.started['nativeBefore'])
        acquisition=deepcopy(self.palette.acquisition);self.returned('palette');self.stage('native-after-query')
        originals=dict(palette=packet,paletteClock=dict(capturedEpochMs=packet['clockAfter']['epochMs']))
        join=window.finish(originals,(('paletteClock','capturedEpochMs'),));self.returned('clockJoin');self.stage('phase-after-query')
        last=self.phase.status(first['status']);self.returned('phaseAfter')
        frame=dict(iosEmotePostControllerFrameOriginalVersion=VERSION,sourceReference=deepcopy(source_reference),
            phaseBefore=first['status'],phaseAfter=last,palette=packet,acquisition=acquisition,clockJoin=join)
        self.validate_frame(frame,self.frames[-1]if self.frames else None);self.stage('storing')
        self.originals.write(self.state['revision']+1,frame)
        reference=self.resolve_saved()
        self.bound();now=self.epoch_ms();mono=self.monotonic()
        need(number(now,join['hostAfterEpochMs'],join['hostBeforeEpochMs']+1500)
            and number(mono,join['hostAfterMonotonic'],join['hostBeforeMonotonic']+1.5)
            and now-join['hostBeforeEpochMs']<1500 and mono-join['hostBeforeMonotonic']<1.5)
        if not self.validate_frame(frame,self.frames[-2]if len(self.frames)>1 else None):
            raise EmotePhaseChanged('Post-controller originals crossed the actual input phase')
        return reference

    def resolve_saved(self):
        """Recover only an actual complete opened/saved file; no reader call."""
        need(not self.historical);self.bound();need(self.state['phase']=='reading')
        pending=self.state['pending'];original=pending['original']
        need(original is not None and original['phase']in('opened','saved'))
        frame=self.originals.read(original);need(same(frame['sourceReference'],pending['sourceReference']))
        self.validate_frame(frame,self.frames[-1]if self.frames else None)
        if original['phase']=='opened':
            saved=deepcopy(original);saved['phase']='saved';self.storage_intent('original',saved);original=saved
        compact=self.originals.compact(original)
        if pending['manifest']is None:manifests=self.originals.append(self.state['manifests'],compact)
        else:
            ref=pending['manifest']['reference'];entries=self.originals.manifest(ref)
            need(same(entries[-1],compact))
            prior=[]if compact['index']%BLOCK==1 else self.originals.manifest(self.state['manifests'][-1])
            need(same(entries,prior+[compact]))
            if pending['manifest']['phase']=='planned':
                saved=deepcopy(pending['manifest']);saved['phase']='saved';self.storage_intent('manifest',saved)
            manifests=deepcopy(self.state['manifests'])
            if ref['count']==1:manifests.append(deepcopy(ref))
            else:manifests[-1]=deepcopy(ref)
        self.frames.append(deepcopy(frame));self.state.update(phase='ready',revision=len(self.frames),manifests=manifests,pending=None);self.save()
        return compact

    def original(self,reference):
        self.lock.assert_held();need(same(self.store.read(),self.previous))
        expanded=self.originals.expand(reference);need(reference['index']<=self.state['revision'])
        entries=self.originals.manifest(self.state['manifests'][(reference['index']-1)//BLOCK])
        need(same(entries[(reference['index']-1)%BLOCK],reference))
        value=self.originals.read(expanded);self.validate_frame(value,self.frames[reference['index']-2]if reference['index']>1 else None)
        return deepcopy(value)

    def retirement_manifest(self):
        """Read-only ownership inventory. It is never an End/deletion permit."""
        self.lock.assert_held();need(same(self.store.read(),self.previous));state,frames=self.decode(self.previous or self.envelope(self.state))
        pending=state['pending'];footprint=None
        if pending is not None and pending['original']is not None:
            item=pending['original'];path=self.originals.path(item)
            if item['phase']=='planned':need(not path.exists())
            else:
                fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0))
                with os.fdopen(fd,'rb')as stream:
                    self.originals.file(path,stream.fileno(),item);raw=stream.read(item['bytes']+1);self.originals.file(path,stream.fileno(),item)
                need(len(raw)<=item['bytes']);record_original_read(path)
                footprint=dict(file=deepcopy(item['file']),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),
                    complete=len(raw)==item['bytes']and hashlib.sha256(raw).hexdigest()==item['sha256'])
        return dict(iosEmotePostControllerResponsibilityVersion=1,runId=self.run,role=self.role,binding=deepcopy(self.binding),
            ownerPath=str(self.store.path),ownerValueSha256=None if self.previous is None else digest(self.previous),
            artifactRoot=str(self.root),manifests=deepcopy(state['manifests']),pending=deepcopy(pending),pendingFootprint=footprint,
            completedFrames=len(frames),uncertainRead=pending is not None,retainedOriginalsRequired=True,
            nativeFile='feature-ios-emote-palette.json',nativeProcessLifetimeRequired=True,
            metadataRetirementAllowed=False,finishAllowed=False,nativeQualified=False,wholeQualified=False)
