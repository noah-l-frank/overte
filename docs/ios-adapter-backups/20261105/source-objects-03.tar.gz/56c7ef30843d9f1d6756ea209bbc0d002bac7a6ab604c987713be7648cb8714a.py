"""Exact Root-granted Photos12 metadata boundary; no discovery or native run."""
from pathlib import Path
import json,os,stat,sys,tempfile,threading,types,unittest
from importlib.machinery import PathFinder
from run_metadata import HERE,REPO,pin,proc,publication,save,sha,validate_frozen
assert len(sys.argv)==2 and sys.argv[1] in ('photos12',)
kind=sys.argv[1];plan=validate_frozen();selected=plan['suites'][kind];publication()
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/'publication-ready-source-map.json';assert ready.is_file(),'Root must refresh after source publication'
runroot=Path(os.environ['OVERTE_PHOTOS_ORPHAN_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs'/kind) and runroot!=HERE/'runs'/kind
info=runroot.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
temporary=Path(os.environ['TMPDIR']).resolve(strict=True)
assert temporary==runroot/'temporary' and Path(tempfile.gettempdir())==temporary
info=temporary.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
assert not any(temporary.iterdir()) and not (runroot/'selected-result.json').exists()
save(runroot/'runner-process-binding.json',proc(os.getpid()))
config=json.loads((HERE/'source-root-final-map.json').read_text())
sourcepaths={REPO/row['path'] for row in config['modules'].values()}
sourcepaths.update(HERE/name for name in ('run-selected.py','run_metadata.py','suite-plan.json','source-root-final-map.json','expected-publication.json','freeze.json','publication-ready-source-map.json'))
source_before={str(path):pin(path) for path in sourcepaths}

def spec_without_import(name):
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:assert search is not None,name
    return spec

def preimport_source_roots():
    top_names={name.split('.')[0] for name in config['packageRoots']}
    assert not any(name.split('.')[0] in top_names for name in sys.modules),'Target imported before source preflight'
    expected=[str(REPO/name) for name in config['orderedRoots']];remaining=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==REPO or REPO in path.parents:continue
        if str(path) not in remaining:remaining.append(str(path))
    sys.path[:]=expected+remaining
    for name,relative in config['packageRoots'].items():
        spec=spec_without_import(name)
        assert [str(Path(path).resolve()) for path in spec.submodule_search_locations or ()]==[str(REPO/relative)],name
    actual={}
    for name,row in config['modules'].items():
        spec=spec_without_import(name);assert spec.origin is not None,name
        path=Path(spec.origin).resolve(strict=True)
        assert path==REPO/row['path'] and sha(path)==row['sha256'],name
        actual[name]=str(path)
    save(runroot/'preimport-source-map-actual.json',dict(orderedRoots=expected,modules=actual))
preimport_source_roots()
from ios.self_tests import test_ios_snapshot_photos_sdk_slot as slot_fixture
from ios.self_tests import test_ios_snapshot_photos_end_orphans as orphan_fixture
from ios.self_tests.retained_host_roots import retain_owned_root
real_td=tempfile.TemporaryDirectory;retained=[];objects=[]
def retained_directory(*args,**kwargs):
    directory=real_td(*args,**kwargs);root=Path(directory.name)
    assert root.is_relative_to(temporary)
    root=retain_owned_root(directory,expected_root=root)
    retained.append(str(root));objects.append(directory)
    save(runroot/'created-original-roots.json',retained)
    print('RETAINED_ACTUAL_PHOTOS_METADATA_ROOT',root,flush=True)
    return directory
aliases=[(module,module.tempfile) for module in (slot_fixture,orphan_fixture)]
threads_before=set(threading.enumerate());result=None;actual_ids=[]
try:
    for module,original in aliases:
        assert original is tempfile;module.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_directory)
    ids=selected['caseIds'];assert len(ids)==len(set(ids))==selected['count']
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for child in value:yield from flatten(child)
        else:yield value
    actual_ids=[test.id() for test in flatten(suite)]
    assert not loader.errors and actual_ids==ids and suite.countTestCases()==selected['count'],(loader.errors,actual_ids)
    save(runroot/'selected-ids-actual.json',actual_ids);print('ACTUAL_SELECTED_IDS',json.dumps(actual_ids),flush=True)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.testsRun==selected['count'] and not result.skipped,'All exact cases must execute without skip'
finally:
    for module,original in aliases:module.tempfile=original
    assert tempfile.TemporaryDirectory is real_td and all(module.tempfile is original for module,original in aliases)
    assert source_before=={str(path):pin(path) for path in sourcepaths},'Source/launcher/map changed'
    def census():return {str(path.relative_to(temporary)):pin(path) for path in (temporary,*sorted(temporary.rglob('*')))}
    first=census();second=census();assert first==second,'Post-test originals changed'
    save(runroot/'selected-originals-first.json',first);save(runroot/'selected-originals-second.json',second)
    remaining=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
    report=dict(kind=kind,testsRun=None if result is None else result.testsRun,selectedIds=actual_ids,
        successful=False if result is None else result.wasSuccessful(),skipped=[] if result is None else result.skipped,
        retainedTemporaryDirectoryRoots=retained,fixtureAliasesRestored=True,sourceLauncherPinsUnchanged=True,
        originalCensusesEqual=True,remainingNewThreads=remaining,nativeCompiled=False,sdkExecuted=False,
        deviceQualified=False,wholePhotosFeatureQualified=False)
    save(runroot/'selected-result.json',report);print('ACTUAL_RESULT',json.dumps(report),flush=True)
    assert not remaining,'New fixture/worker/listener thread remains live'
sys.exit(0 if result is not None and result.wasSuccessful() else 1)
