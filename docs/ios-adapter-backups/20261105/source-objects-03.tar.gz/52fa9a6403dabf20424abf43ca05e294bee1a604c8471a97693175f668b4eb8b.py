"""Explicit negative-only original Publisher locals; no clock or verdict reuse.

Test instrumentation only. This writer receives actual already read locals from
the refusal site, after the unchanged expression returned false. It cannot read
a clock/phase/SDK, admit publication, replace an original or change a deadline.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import hashlib,marshal
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState,context
from feature_journeys.contract import identifier

PROFILE='ios-lifecycle-publisher-refusal-original-locals-v1'


class PublicationRefusalOriginal:
    def __init__(self,path,binding,run):
        repo=Path.cwd().resolve(strict=True)
        need(repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file())
        self.path=Path(path);need(self.path.resolve().is_relative_to(repo)and self.path.name=='publication-refusal-original.json')
        self.binding=deepcopy(context(binding));self.run=identifier(run);self.store=PrivateFeatureState(self.path)
        need(self.store.read()is None);self.owner=None;self.receiver=None;self.written=False
        self.methods=tuple((name,getattr(type(self),name),getattr(type(self),name).__code__)for name in('__init__','bind','capture'))

    def bind(self,publisher):
        from adapters.phase_witness_publisher import PhaseWitnessPublisher
        need(self.owner is None and type(publisher)is PhaseWitnessPublisher and publisher.binding==self.binding
            and publisher.run==self.run and publisher.area=='lifecycle-input')
        self.owner=publisher;function=type(publisher).publish
        self.receiver=(function,function.__code__)
        self.code_sha256=hashlib.sha256(marshal.dumps(function.__code__)).hexdigest()
        return self

    def capture(self,publisher,stage,condition,active,pending,clock,now,epoch):
        # No publisher.bound(): it would read monotonic again and destroy this
        # instrumentation's exact original-clock-call boundary.
        need(publisher is self.owner and publisher.binding==self.binding and publisher.run==self.run
            and publisher.area=='lifecycle-input'and type(condition)is bool and condition is False
            and stage in('before-issued','after-issued')and not self.written)
        for name,function,code in self.methods:need(getattr(type(self),name)is function and function.__code__ is code)
        function,code=self.receiver;need(type(publisher).publish is function and function.__code__ is code)
        publisher.lock.assert_held()
        value=dict(publicationRefusalOriginalVersion=1,profile=PROFILE,stage=stage,condition=False,
            binding=deepcopy(self.binding),runId=self.run,area=publisher.area,publisherStore=str(publisher.store.path),
            actualPublisherCodeSha256=self.code_sha256,
            locals=dict(active=deepcopy(active),pending=deepcopy(pending),clock=deepcopy(clock),
                nowMonotonic=now,epochMs=epoch),previousPublisherWAL=deepcopy(publisher.previous))
        # An exact one-shot private original, no overwrite/adoption/retry.
        self.store.write(value,None);self.written=True
