"""Exact existing ScriptMessageModel Node constructor, real pipes and cleanup."""
from pathlib import Path
from types import FrameType
import io
import json
import os
import shutil
import signal
import subprocess
import sys
import threading
from raw_pipe_tee import install as install_raw_tee


class ChatNodePort:
    def __init__(self, plan, here, pin, proc):
        self.plan, self.here, self.pin, self.proc = plan, here, pin, proc
        assert len(plan['cases'])==1 and plan['maxTotalNodes']==plan['maxLiveNodes']==plan['maxNodePerCase']==2
        assert not any(name.startswith('NODE_')for name in os.environ)
        self.environment=dict(os.environ)
        self.node = Path(plan['node']['path'])
        self.script = Path(plan['nodeScript']['path'])
        self.command = ['node', str(self.script), str(here.parent.parent), '--initial-history-null']
        self.path = os.environ.get('PATH')
        self.popen = subprocess.Popen
        self.popen_methods = tuple((name, getattr(self.popen, name),
            getattr(self.popen, name).__code__, getattr(self.popen, name).__globals__)
            for name in ('__init__', '_execute_child', 'kill', 'send_signal', 'poll', 'wait'))
        self.model = self.bus = self.init = self.close = None
        self.pending = None
        self.entries = []
        self.current_case = None
        self.completed_cases = []
        self.abort_active = None
        self.controller_drains = []
        self._check_binary()

    def _check_binary(self):
        assert os.environ.get('PATH') == self.path and dict(os.environ)==self.environment
        assert Path(shutil.which('node')).resolve(strict=True) == self.node
        assert self.pin(self.node) == self.plan['node']['pin']
        assert self.pin(self.script) == self.plan['nodeScript']['pin']

    def bind(self, model_class, bus_class):
        assert self.model is None
        self.model, self.bus = model_class, bus_class
        self.init, self.close = model_class.__init__, model_class.close
        self.role_init=bus_class.__init__;self.role_code=self.role_init.__code__;self.role_globals=self.role_init.__globals__
        self.role_path=Path(self.plan['pairedModules']['chat_paired_offline_history_fixture']['path'])
        assert Path(self.role_code.co_filename)==self.role_path and self.pin(self.role_path)==self.plan['physicalPins'][str(self.role_path)]
        self.model_ports = tuple((name, getattr(model_class, name), getattr(model_class, name).__code__,
            getattr(model_class, name).__globals__) for name in ('__init__', 'command', 'chat_input', 'query', 'close'))
        assert Path(self.init.__code__.co_filename) == Path(self.plan['nodeModel']['path'])
        assert self.pin(Path(self.init.__code__.co_filename)) == self.plan['nodeModel']['pin']

    def check(self):
        self._check_binary()
        assert subprocess.Popen is self.popen
        for name, function, code, namespace in self.popen_methods:
            assert getattr(self.popen, name) is function and function.__code__ is code and function.__globals__ is namespace
        assert self.model is not None and self.bus is not None
        assert self.bus.__init__ is self.role_init and self.role_init.__code__ is self.role_code and self.role_init.__globals__ is self.role_globals
        for name, function, code, namespace in self.model_ports:
            assert getattr(self.model, name) is function and function.__code__ is code and function.__globals__ is namespace

    def frames(self, frame, *, at_start=False):
        self.check()
        original = constructor = execute = role_constructor = None
        while frame is not None:
            assert type(frame) is FrameType
            if frame.f_code is self.role_code and frame.f_globals is self.role_globals:role_constructor=frame
            if frame.f_code is self.init.__code__ and frame.f_globals is self.init.__globals__:
                original = frame
            for name, function, code, namespace in self.popen_methods[:2]:
                if frame.f_code is code and frame.f_globals is namespace:
                    if name == '__init__':
                        constructor = frame
                    else:
                        execute = frame
            frame = frame.f_back
        assert original is not None and constructor is not None
        owner, process = original.f_locals['self'], constructor.f_locals['self']
        assert type(owner) is self.bus and type(process) is self.popen
        assert role_constructor is not None and role_constructor.f_locals.get('self')is owner
        role=role_constructor.f_locals['role'];assert role in('primary','peer')and owner.role==role
        assert original.f_locals['initial_history_null']is True
        assert 'child' not in vars(owner) and self.current_case is not None
        values = constructor.f_locals
        assert values['args'] == self.command and values['text'] is True
        assert values['stdin'] == values['stdout'] == values['stderr'] == subprocess.PIPE
        assert values['shell'] is False and values['cwd'] is values['env'] is values['executable'] is None
        assert values['start_new_session'] is False and values['pass_fds'] == () and values['close_fds'] is True
        assert values['preexec_fn'] is None
        assert values['process_group'] is None if at_start else values['process_group'] == -1
        if at_start:
            assert values['encoding'] is values['errors'] is None
        else:
            # CPython genuinely resolves the omitted text encoding before its
            # pipe opens and process_group=None to -1 before execute_child.
            assert type(values['encoding']) is str and values['encoding'] == process.encoding
            assert values['errors'] is process.errors is None
        if self.pending is None:
            assert at_start, 'No audit-only substitution for the real constructor entry'
            assert len(self.entries)<2 and not any(row['role']==role for row in self.entries)
            assert sum(row['process'].poll()is None for row in self.entries)<2
            self.pending = dict(owner=owner, process=process, case=self.current_case, role=role,
                pipes=[], spawned=False, genuineConstructorEntry=True)
        assert self.pending['owner'] is owner and self.pending['process'] is process
        return original, constructor, execute

    def constructor_start(self, code, offset):
        assert code is self.popen.__init__.__code__ and self.pending is None
        self.frames(sys._getframe(1), at_start=True)

    def pipe_open(self, args, frame):
        if type(args[0]) is not int or type(args[1]) is not str or not any(c in args[1] for c in 'wax+'):
            return False
        import stat
        info = os.fstat(args[0])
        if not stat.S_ISFIFO(info.st_mode):
            return False
        _original, constructor, _execute = self.frames(frame)
        assert args[0] == constructor.f_locals['p2cwrite'] and args[1] in ('w', 'wb')
        assert not self.pending['pipes']
        assert os.readlink('/proc/self/fd/' + str(args[0])) == 'pipe:[' + str(info.st_ino) + ']'
        self.pending['pipes'].append(dict(fd=args[0], device=info.st_dev, inode=info.st_ino))
        return True

    def spawn(self, args, frame):
        _original, _constructor, execute = self.frames(frame)
        assert execute is not None and len(self.pending['pipes']) == 1
        executable, command, cwd, env = args
        assert executable == 'node' and command == self.command and cwd is env is None
        assert not self.pending['spawned']
        self.pending['spawned'] = True

    def constructor_return(self, code, offset, value):
        if self.pending is None:
            return
        _original, constructor, _execute = self.frames(sys._getframe(1))
        process = self.pending['process']
        assert code is self.popen.__init__.__code__ and value is None
        assert self.pending['spawned'] and process.pid is not None
        birth = self.proc(process.pid)
        assert birth is not None and birth['parent'] == os.getpid()
        own = self.proc(os.getpid())
        assert birth['group'] == own['group'] and birth['session'] == own['session']
        directory = self.here / ('node-' + format(len(self.entries) + 1, '04d'))
        directory.mkdir(mode=0o700)
        row = self.pending
        row.update(birth=birth, directory=directory, controlledKills=[], streams=[])
        self.entries.append(row)  # Retain actual birth before optional tee setup.
        row['streams'] = install_raw_tee(process, directory)
        assert len(row['streams']) == 3
        self.pending = None

    def signal(self, args, frame):
        pid, sig = args
        assert type(pid) is int and sig == signal.SIGKILL
        found = [row for row in self.entries if row['process'].pid == pid]
        assert len(found) == 1
        row = found[0]
        assert self.proc(pid) == row['birth']
        self.check()
        actual_close = actual_signal = False
        while frame is not None:
            if frame.f_code is self.close.__code__ and frame.f_globals is self.close.__globals__:
                assert frame.f_locals.get('self') is row['owner']
                actual_close = True
            if frame.f_code is self.popen.send_signal.__code__:
                assert frame.f_locals.get('self') is row['process']
                actual_signal = True
            frame = frame.f_back
        if self.abort_active is row:
            cursor = sys._getframe(1)
            genuine_abort = False
            while cursor is not None:
                if cursor.f_code is type(self).abort_all.__code__ and cursor.f_locals.get('self') is self:
                    genuine_abort = True
                cursor = cursor.f_back
            assert genuine_abort and actual_signal
        else:
            assert actual_close and actual_signal
        row['controlledKills'].append(dict(pid=pid, signal=int(sig)))

    def abort_all(self):
        """Failure-only owned resource drain; never upgrades standard cleanup."""
        if self.pending is not None and self.pending['spawned']:
            process = self.pending['process']
            pid = getattr(process, 'pid', None)
            actual = None if pid is None else self.proc(pid)
            if actual is not None and not any(row['process'] is process for row in self.entries):
                own = self.proc(os.getpid())
                assert actual['parent'] == own['pid'] and actual['group'] == own['group'] and actual['session'] == own['session']
                self.pending.update(birth=actual, streams=[], directory=self.here / ('node-' + format(len(self.entries) + 1, '04d')),
                    controlledKills=[], constructionReturned=False)
                self.entries.append(self.pending)
        for row in self.entries:
            process = row['process']
            errors = []
            try:
                if process.poll() is None:
                    assert self.proc(process.pid) == row['birth']
                    self.abort_active = row
                    try:
                        process.kill()
                    finally:
                        self.abort_active = None
                    process.wait(timeout=5)
                for name in ('stdin', 'stdout', 'stderr'):
                    stream = getattr(process, name)
                    if stream is not None:
                        try:
                            if not stream.closed:
                                stream.close()
                        except BaseException as error:
                            errors.append(type(error).__module__ + '.' + type(error).__qualname__)
            except BaseException as error:
                errors.append(type(error).__module__ + '.' + type(error).__qualname__)
            self.controller_drains.append(dict(case=row['case'], pid=process.pid,
                absent=self.proc(process.pid) is None, errors=errors))

    def finish_row(self, row):
        self.check()
        assert row in self.entries and self.pending is None
        case=row['case']
        process = row['process']
        assert row['owner'].child is process and process.poll() == 0
        assert self.proc(process.pid) is None and not row['controlledKills']
        assert len(row['streams']) == 3
        for stream in row['streams']:
            assert getattr(process, stream['name']) is stream['text']
            assert stream['text'].closed and stream['buffer'].closed and stream['log'].closed
            assert stream['path'].stat().st_size == stream['tee'].observed
        inputs = (row['directory'] / 'stdin.bin').read_bytes().splitlines()
        outputs = (row['directory'] / 'stdout.bin').read_bytes().splitlines()
        assert inputs and outputs
        assert json.loads(inputs[-1])['action'] == 'end'
        terminal = json.loads(outputs[-1])
        assert terminal['ok'] is True and terminal['source']['subscriptions'] == 0
        return dict(case=case, role=row['role'], actualNode=row['birth'], exitCode=process.returncode,
            actualScriptEndAndZeroSubscriptions=True, allRawStreamsClosed=True,
            streamBytes={stream['name']: stream['tee'].observed for stream in row['streams']})

    def finish_case(self,case):
        rows=[row for row in self.entries if row['case']==case]
        assert len(rows)==2 and {row['role']for row in rows}=={'primary','peer'}
        assert len({id(row['owner'])for row in rows})==len({row['birth']['pid']for row in rows})==2
        actual=[self.finish_row(row)for row in rows]
        self.completed_cases.append(case)
        return dict(case=case,actualNodes=[row['actualNode']for row in actual],roleOriginals=actual,
            actualScriptEndAndZeroSubscriptions=True,allRawStreamsClosed=True)
