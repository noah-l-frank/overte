"""Fail closed until Root supplies a real qualified first-four proof/schema.

Only this future exact proof join may return a map of actual retained proof pins.
No expected success field/status, fabricated proof or B2 failure can admit a run.
"""
from pathlib import Path
from metadata_reader import pin
import json

PROOF_JOIN_SCHEMA = None

def require_initial_four(path, digest):
    path = Path(path)
    assert path.is_absolute() and path.resolve(strict=True) == path
    assert path.name == 'freeze.json' and pin(path)['sha256'] == digest
    original = json.loads(path.read_text())
    assert type(original) is dict and type(original.get('files')) is dict
    for name, row in original['files'].items():
        assert type(name) is str and not Path(name).is_absolute() and '..' not in Path(name).parts
        expected = row if type(row) is str else row['sha256']
        assert pin(path.parent / name)['sha256'] == expected
    raise RuntimeError('No qualified initial-four proof schema is admitted; remaining groups stay blocked')
