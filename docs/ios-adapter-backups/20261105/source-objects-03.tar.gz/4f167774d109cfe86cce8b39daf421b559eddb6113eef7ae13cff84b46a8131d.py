"""Exactly two genuine original Publisher HTTP/WAL negatives, fixed own scope."""
from pathlib import Path
from types import SimpleNamespace
import builtins,copy,fcntl,hashlib,importlib.abc,importlib.util,io,json,os,signal,socket,stat,sys,tempfile,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode and len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['repositoryRoot']==str(REPO)and plan['controllerRoot']==str(HERE)and len(plan['cases'])==2
TDROOT=HERE/'retained';RECEIPTS=HERE/'child-receipts'
assert TDROOT.is_dir()and not list(TDROOT.iterdir())and RECEIPTS.is_dir()and not list(RECEIPTS.iterdir())

def pin(path):
    path=Path(path);a=path.lstat();assert path.resolve(strict=True)==path and stat.S_ISREG(a.st_mode)
    raw=path.read_bytes();b=path.lstat();fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    value=dict(stat=[getattr(a,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest());assert value['stat']==[getattr(b,key)for key in fields];return value
assert {path:pin(path)for path in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
original_meta=tuple(sys.meta_path);original_path=tuple(sys.path);original_sleep=time.sleep
sys.path[:]=[value for value in sys.path if value and not Path(value).resolve().is_relative_to(REPO)]
loaded={};project_tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespaces'])}
class Loader(importlib.abc.Loader):
    def __init__(self,name,row):self.name,self.row=name,row
    def create_module(self,spec):return None
    def exec_module(self,module):
        path=Path(self.row['path']);assert pin(path)==plan['sourceAndBinaryPins'][str(path)];module.__file__=str(path)
        if path.name=='__init__.py':module.__path__=[str(path.parent)]
        loaded[self.name]=str(path);exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__)
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in('ios','pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium'):raise ImportError('No Current/iOS/SDK definitions admitted in Publisher2')
        row=plan['modules'].get(name)
        if row is not None:return importlib.util.spec_from_loader(name,Loader(name,row),is_package=Path(row['path']).name=='__init__.py')
        namespace=plan['namespaces'].get(name)
        if namespace is not None:
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=[namespace];return spec
        if name.split('.')[0]in project_tops:raise ImportError('Unmapped project import refused: '+name)
        spec=importlib.machinery.PathFinder.find_spec(name,path)
        if spec is not None and spec.origin not in(None,'built-in','frozen'):
            origin=Path(spec.origin).resolve(strict=True);assert origin.is_relative_to(Path(os.__file__).resolve(strict=True).parent)and 'site-packages'not in origin.parts;return spec
        if spec is not None and spec.origin is None:
            assert all(Path(value).resolve(strict=True).is_relative_to(Path(os.__file__).resolve(strict=True).parent)for value in spec.submodule_search_locations);return spec
        return None
sys.meta_path.insert(0,Finder())
from publisher_owned_writes import OwnedWrites
from publisher_host_custody import PublisherHostCustody
from publisher_journal_encoding import encode_actual_journal
from publisher_retained_roots import retain_owned_root
host=PublisherHostCustody()
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={name:getattr(os,name)for name in ports if hasattr(os,name)};original_io=(io.open,builtins.open)
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):protected.append(Path(os.readlink('/proc/self/fd/'+str(fd))).resolve(strict=True))
boundary=OwnedWrites(HERE,protected=protected)

def audit(event,args):
    if event=='import'and args[0].split('.')[0]in('ios','pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium'):
        raise RuntimeError('No Current/SDK import in Publisher2')
    if event.startswith('socket.'):
        host.socket(event,args,sys._getframe(1));return
    if event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('No Node/subprocess/nativeSDK/device actions')
    if event=='fcntl.flock':host.flock(args,sys._getframe(1))
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if relevant:
        if event=='open':
            unused,mode,flags=args
            if not bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))and not(type(mode)is str and any(c in mode for c in'wax+')):return
        boundary.audit(event,args,sys._getframe(1))
boundary.install();sys.addaudithook(audit)
def save(name,value):
    with(RECEIPTS/name).open('x')as stream:stream.write(json.dumps(value,sort_keys=True,indent=2)+'\n')

def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:info=path.stat();result[path.name]=dict(target=os.readlink(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result

def retained_census(root):
    output={}
    def visit(path):
        info=path.lstat();assert not path.is_symlink()
        fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        row=dict(stat=[getattr(info,key)for key in fields])
        if stat.S_ISDIR(info.st_mode):
            names=sorted(item.name for item in path.iterdir());row['namespace']=names
            for name in names:visit(path/name)
        else:
            assert stat.S_ISREG(info.st_mode)and info.st_nlink==1
            row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        assert row['stat']==[getattr(path.lstat(),key)for key in fields];output[str(path.relative_to(root))]=row
    visit(root);return output

original_cleanup=unittest.TestCase.doCleanups;real_td=tempfile.TemporaryDirectory;owned=[];objects=[];case_receipts=[];actual_started=[];actual_standard_outcomes=[]
def temporary(*args,**kwargs):
    assert not args and kwargs.get('dir')is None
    kwargs['dir']=TDROOT;actual=real_td(**kwargs);root=Path(actual.name)
    assert root.parent==TDROOT and root.resolve(strict=True)==root
    retain_owned_root(actual,expected_root=root);objects.append(actual);owned.append(str(root));return actual
class Result(unittest.TextTestResult):
    def startTest(self,test):
        actual_started.append(test.id())
        self.roots_before=len(owned);self.started=time.monotonic();super().startTest(test)
    def addSuccess(self,test):
        super().addSuccess(test);actual_standard_outcomes.append(dict(id=test.id(),outcome='success-after-original-standard-cleanups'))
    def addFailure(self,test,error):
        super().addFailure(test,error);actual_standard_outcomes.append(dict(id=test.id(),outcome='failure'))
    def addError(self,test,error):
        super().addError(test,error);actual_standard_outcomes.append(dict(id=test.id(),outcome='error'))
    def stopTest(self,test):
        # Standard TestCase.run completed its actual registered callbacks.
        current=owned[self.roots_before:]
        row=dict(id=test.id(),seconds=time.monotonic()-self.started,retainedRoots=current,remainingCallbacks=len(test._cleanups),
            actualOriginals=copy.deepcopy(getattr(test,'known',None)),originalValidationCalls=getattr(test,'validations',None))
        server=getattr(test,'server',None)
        if server is not None:
            with server.journal.lock:row['actualJournalRunsAfterOriginalCleanup']=encode_actual_journal(copy.deepcopy(server.journal.runs))
        case_receipts.append(row);save('case-'+str(len(case_receipts))+'.json',row)
        super().stopTest(test)

fd_before=fds();threads_before=tuple(threading.enumerate());children_before=Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
selected=[];result=None;fatal=None;cleanup_ok=True;cleanup_rows=[];harness=None;harness_tempfile=None
original_term=signal.getsignal(signal.SIGTERM)
def interrupted(signum,frame):raise KeyboardInterrupt('Fixed30-second Publisher2 boundary')
signal.signal(signal.SIGTERM,interrupted)
try:
    import importlib
    for name in plan['preloads']:importlib.import_module(name)
    import adapters.script_feature.lock as lock_module
    host.bind_lock(lock_module,fcntl)
    import self_tests.test_phase_witness_publisher as harness
    harness_tempfile=harness.tempfile;assert harness_tempfile is tempfile
    harness.tempfile=SimpleNamespace(TemporaryDirectory=temporary)
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for part in value:yield from flatten(part)
        else:yield value
    selected=list(flatten(suite));save('actual-selection.json',dict(ids=[case.id()for case in selected],errors=loader.errors))
    assert not loader.errors and [case.id()for case in selected]==plan['cases']and suite.countTestCases()==2
    assert time.sleep is original_sleep
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    for case in selected:
        prior=case._outcome;pending=len(case._cleanups);drain=unittest.TestResult();success=True
        try:
            if pending:case._outcome=unittest.case._Outcome(drain);success=unittest.TestCase.doCleanups(case)
        except BaseException:success=False;print(traceback.format_exc(),flush=True)
        finally:case._outcome=prior
        cleanup_rows.append(dict(id=case.id(),pendingBefore=pending,remaining=len(case._cleanups),success=success,
            errors=[dict(id=test.id(),traceback=text)for test,text in drain.errors],failures=[dict(id=test.id(),traceback=text)for test,text in drain.failures]))
        if not success or case._cleanups or drain.errors or drain.failures:cleanup_ok=False
    if harness is not None and harness_tempfile is not None:harness.tempfile=harness_tempfile
    after={path:pin(path)for path in plan['sourceAndBinaryPins']}
    fd_after=fds();threads_after=tuple(threading.enumerate());children_after=Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
    actual_host=None
    try:actual_host=host.finish()
    except BaseException:fatal=(fatal or'')+traceback.format_exc();print(fatal,flush=True)
    passed=fatal is None and result is not None and result.wasSuccessful()and result.testsRun==2 and not result.skipped
    passed=passed and cleanup_ok and unittest.TestCase.doCleanups is original_cleanup and time.sleep is original_sleep
    passed=passed and len(owned)==2 and len(objects)==2 and len(case_receipts)==2 and all(len(row['retainedRoots'])==1 and row['remainingCallbacks']==0 for row in case_receipts)
    passed=passed and all(not item._finalizer.alive for item in objects)
    passed=passed and fd_before==fd_after and threads_before==threads_after and children_before==children_after and after==plan['sourceAndBinaryPins']
    retained_first=retained_census(TDROOT);retained_second=retained_census(TDROOT)
    passed=passed and retained_first==retained_second
    passed=passed and not any(name=='ios'or name.startswith('ios.')for name in sys.modules)
    save('actual-retained-first.json',retained_first);save('actual-retained-second.json',retained_second)
    save('actual-cleanup.json',dict(success=cleanup_ok,cases=cleanup_rows,host=actual_host,retainedRoots=owned))
    save('report.json',dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=None if result is None else result.testsRun,suiteReturned=result is not None,actualStartedIds=actual_started,actualStandardOutcomes=actual_standard_outcomes,fatal=fatal,
        allSourcePinsEqual=after==plan['sourceAndBinaryPins'],actualFDsEqual=fd_before==fd_after,actualThreadsEqual=threads_before==threads_after,actualKernelChildrenEqual=children_before==children_after,
        retainedRoots=owned,twoChildRetainedCensusesEqual=retained_first==retained_second,caseReceipts=len(case_receipts),loadedProjectModules=loaded,CurrentSourceBirths=0,NodeExecutions=0,SDKExecutions=0,wholeQualified=False))
    signal.signal(signal.SIGTERM,original_term);boundary.restore()
    restored=all(getattr(os,name)is value for name,value in original_ports.items())and original_io==(io.open,builtins.open)
    with boundary.original_io(RECEIPTS/'actual-port-restoration.json','x')as stream:stream.write(json.dumps(dict(restored=restored,count=len(original_ports),controlDescriptors=sorted(boundary.control_fds)))+'\n')
    boundary.close();sys.meta_path[:]=original_meta;sys.path[:]=original_path
raise SystemExit(0 if passed and restored else 1)
