"""Pure current-public fixture syntax/default checks, no observed native facts."""
from copy import deepcopy
import unittest
from fixture.serve import FixtureState
from feature_journeys.witness import Journal,projection
from feature_journeys.scenarios import SCENARIOS

class PublicSnapshotFixtureDefaults(unittest.TestCase):
    def test_default_journal_preserves_original_snapshot_ui_fact_family(self):
        journal=Journal(lambda:20000);run=journal.register('snapshots');ticket='b'*32
        journal.activate(run,ticket);facts=projection('snapshots',SCENARIOS['snapshots']['baseline'])
        journal.publish(run,dict(ticket=ticket,actor='owned-observer',actorSequence=1,capturedEpochMs=20000,facts=deepcopy(facts)))
        self.assertIs(journal.snapshot_scene_samples,False)
        self.assertEqual(facts,journal.snapshot(run)['entries'][0]['facts'])
    def test_actual_fixture_post_routing_validates_both_original_commands_and_preserves_idle(self):
        fixture=FixtureState();idle=dict(schemaVersion=1,commandId='',action='idle')
        self.assertEqual(idle,fixture.snapshot_client_command())
        for action in ('feature-ios-snapshot-provenance','feature-ios-snapshot-scene'):
            command=dict(schemaVersion=1,commandId='ios-'+'c'*32,action=action,runId='a'*32)
            self.assertEqual(command,fixture.set_client_command(command))
            self.assertEqual(command,fixture.snapshot_client_command())
            for invalid in (dict(command,expected=True),dict(command,runId='foreign'),dict(command,schemaVersion=True)):
                with self.assertRaises(ValueError):fixture.set_client_command(invalid)
                self.assertEqual(command,fixture.snapshot_client_command())
            self.assertEqual(idle,fixture.set_client_command(idle))
