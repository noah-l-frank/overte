"""Actual original-Keeper HouseArrest fixed-file reads, never native clocks.

No mutation/path selector exists here. Native one-way retirement is separate.
AFC metadata remains AFC metadata; os_stat's synthetic inode is never used.
"""
from copy import deepcopy
import asyncio,base64,hashlib,re,sys,time

FILE='feature-native-observation.json'
LIMIT=1048576

async def original(operations,args,session,creator,error):
    from pymobiledevice3.services.house_arrest import HouseArrestService
    from pymobiledevice3.services.afc import AfcError
    from pymobiledevice3.exceptions import AfcFileNotFoundError
    from adapters.normal_feature_state import context
    if type(operations)is not creator or type(args)is not dict or set(args)!={'emoteResponseFileReadVersion','binding','runId','resultsDirectory','mode'}:
        raise error('request')
    if type(args['emoteResponseFileReadVersion'])is not int or args['emoteResponseFileReadVersion']!=1 or args['mode']not in('read','absence'):
        raise error('request')
    binding=deepcopy(context(args['binding']));directory=args['resultsDirectory'];run=args['runId']
    if binding['sessionId']!=session or type(run)is not str or re.fullmatch('[0-9a-f]{32}',run)is None or type(directory)is not str or len(directory)>128 or re.fullmatch('[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*',directory)is None:
        raise error('request')
    method=creator.__dict__['emote_response_file_read'];caller=sys._getframe(1)
    if caller.f_code is not method.__code__ or caller.f_globals is not method.__globals__ or caller.f_locals.get('self')is not operations:
        raise error('session-lifetime')
    loop=asyncio.get_running_loop();task=asyncio.current_task();source=operations.source
    if loop is not source._loop or not isinstance(task,asyncio.Task)or operations.native_query_task is not None or operations.native_acquisition is not None:
        raise error('session-lifetime')
    rsd=operations.scope(session);claim=operations.session;held_claim=deepcopy(claim)
    touch,resource=operations.touch,operations.touch_resources
    if claim['sessionId']!=session:raise error('session-lifetime')
    started=loop.time();deadline=started+1.5;host_before=time.time()*1000
    def current():
        if (asyncio.get_running_loop()is not loop or operations.source is not source or source._closing or operations.closed or operations.draining
                or operations.session is not claim or claim!=held_claim or operations.scope(session)is not rsd
                or operations.touch is not touch or operations.touch_resources is not resource
                or operations.native_query_task is not None or operations.native_acquisition is not None
                or creator.__dict__['emote_response_file_read']is not method or loop.time()>=deadline):raise error('session-lifetime')
    current();await operations.fresh_touch_scope(binding);current()
    if len(source._native_reads)>=32:raise error('request')
    service=HouseArrestService(rsd,documents_only=False);close=service.aclose;closed=asyncio.Event();lock=asyncio.Lock()
    row=(service,close,task,loop,closed,lock);source._native_reads.append(row)
    path='/Documents/'+directory+'/'+FILE;handle=None;failure=None;result=None;close_problem=None
    def stat_value(value):
        if type(value)is not dict:raise error('request')
        # Preserve actual SDK fields; never call os_stat or invent st_ino/dev.
        output={}
        for key,item in value.items():
            if type(key)is not str:raise error('request')
            if type(item)in(str,int,float,bool)or item is None:output[key]=item
            elif hasattr(item,'isoformat'):output[key]=dict(actualPythonType=type(item).__module__+'.'+type(item).__qualname__,iso8601=item.isoformat())
            else:raise error('request')
        return output
    try:
        current();await service.send_command(claim['archiveBundleId'],'VendContainer');current()
        actual=await service.__aenter__();current()
        if actual is not service:raise error('session-lifetime')
        try:
            before=await service.stat(path);current()
        except AfcFileNotFoundError as absent:
            current()
            if args['mode']!='absence'or absent.status!=AfcError.READ_ERROR:raise
            result=dict(mode='absent',actualException=type(absent).__module__+'.'+type(absent).__qualname__,actualStatus=int(absent.status))
        else:
            if args['mode']=='absence':result=dict(mode='present',actualStat=stat_value(before))
            else:
                if before.get('st_ifmt')!='S_IFREG'or before.get('st_nlink')!=1 or type(before.get('st_size'))is not int or not 2<=before['st_size']<=LIMIT:raise error('request')
                handle=await service.fopen(path,'r');current()
                raw=await service.fread(handle,before['st_size']);current()
                after=await service.stat(path);current()
                if type(raw)is not bytes or len(raw)!=before['st_size']or before!=after:raise error('request')
                result=dict(mode='read',rawBase64=base64.b64encode(raw).decode('ascii'),actualRawSha256=hashlib.sha256(raw).hexdigest(),actualRawBytes=len(raw),actualStatBefore=stat_value(before),actualStatAfter=stat_value(after))
    except BaseException as original_error:
        failure=(original_error,original_error.__traceback__)
    finally:
        if handle is not None:
            try:await service.fclose(handle)
            except BaseException as original_close:close_problem=(original_close,original_close.__traceback__)
        try:
            async with lock:
                await close();closed.set()
        except BaseException as original_close:
            if close_problem is None:close_problem=(original_close,original_close.__traceback__)
    if failure is not None:raise failure[0].with_traceback(failure[1])
    if close_problem is not None:raise close_problem[0].with_traceback(close_problem[1])
    current()
    return dict(iosEmoteResponseAFCOriginalVersion=1,ownerInstance=operations.instance,runId=run,binding=binding,
        file=FILE,resultsDirectory=directory,bundleId=claim['archiveBundleId'],clockDomain='python-original-keeper-host',
        hostBeforeEpochMs=host_before,hostAfterEpochMs=time.time()*1000,hostBeforeMonotonic=started,hostAfterMonotonic=loop.time(),
        original=result,actualHandleClosed=True,actualServiceCloseReturned=closed.is_set(),nativeClockEstablished=False,
        nativeInodeEstablished=False,installedCandidateBound=False,resourceRetirementEstablished=False)
