"""Isolated stdlib-only loader/audit before the actual model child is born."""
from pathlib import Path
import asyncio,hashlib,importlib.util,json,os,runpy,sys,traceback
ROOT=Path(os.environ['AUDIO_MODEL_AUDIT_ROOT']).resolve(strict=True)
controller=json.loads((ROOT/'controller-pins.json').read_text())
for name,row in controller.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==row['sha256']
spec=importlib.util.spec_from_file_location('audio_fixture_audit_common',ROOT/'audit-common.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
verifier_spec=importlib.util.spec_from_file_location('audio_fixture_external_verifier',ROOT/'external-verifier.py');verifier=importlib.util.module_from_spec(verifier_spec);verifier_spec.loader.exec_module(verifier)
audit=module.FixtureAudit(ROOT,'child');config=Path(sys.argv[1]);assert config.is_relative_to(ROOT)
value=json.loads(config.read_text());child=Path(value['child']['path']);assert audit.digest(child)==value['child']['sha256']==audit.parts['child']['sha256']
sys.argv=[str(child),str(config)]
identity=verifier.process_table()[os.getpid()];assert identity['group']==identity['session']==int(os.environ['AUDIO_OWNED_SESSION'])
fd_before=verifier.fd_census();threads_before=verifier.thread_census();loops=[];actual_run=asyncio.run
# This invocation boundary retains the exact original main coroutine. The
# default new_event_loop class/factory and original asyncio.run shutdown run;
# no Task factory, wrapper Task, native/source callback or clock is replaced.
def observed_run(coro,*,debug=None,loop_factory=None):
 assert loop_factory is None
 def retained_loop():
  loop=asyncio.new_event_loop();loops.append(loop);return loop
 return actual_run(coro,debug=debug,loop_factory=retained_loop)
asyncio.run=observed_run
try:runpy.run_path(str(child),run_name='__main__')
except BaseException:
 audit.save('child-bootstrap-error-'+str(os.getpid())+'.json',dict(error=traceback.format_exc()));raise
finally:
 asyncio.run=actual_run
 loop_rows=[]
 for loop in loops:
  loop_rows.append(dict(closed=loop.is_closed(),remainingTasks=[dict(name=t.get_name(),done=t.done())for t in asyncio.all_tasks(loop)],
   ready=len(loop._ready),scheduled=len(loop._scheduled),selectorCleared=loop._selector is None,
   selfSocketCleared=loop._ssock is None,controlSocketCleared=loop._csock is None,
   executorCleared=loop._default_executor is None,executorShutdownCalled=loop._executor_shutdown_called))
 drain=dict(identity=identity,fdBefore=fd_before,fdAfter=verifier.fd_census(),threadsBefore=threads_before,threadsAfter=verifier.thread_census(),loops=loop_rows,
  exactOriginalRunRestored=asyncio.run is actual_run)
 drain['established']=bool(loop_rows)and drain['fdBefore']==drain['fdAfter']and drain['threadsBefore']==drain['threadsAfter']and all(r['closed']and not r['remainingTasks']and r['ready']==r['scheduled']==0 and all(r[k]for k in ('selectorCleared','selfSocketCleared','controlSocketCleared','executorCleared','executorShutdownCalled'))for r in loop_rows)
 audit.save('child-resource-drain-'+str(os.getpid())+'.json',drain)
 audit.save('child-audit-terminal-'+str(os.getpid())+'.json',dict(resourceDrainEstablished=drain['established'],**audit.finish()))
 if not drain['established']:raise RuntimeError('Actual child resource drain was not established')
