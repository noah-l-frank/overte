"""Root-only metadata for six actual source/cache utility counters. Never run on import."""
from pathlib import Path
import argparse
import hashlib
import importlib.machinery
import json
import os
import stat
import sys
from metadata_reader import pin
from host_common import REPO,head

SOURCE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller10c-copied-bootstrap-namespace-row-code-preparation-20261104'
SUBJECT_SHA='63f5ffc563996ad7793a600cb6a16c53d8df05a54d65db24321a1a2b5c020fc4'
SUBJECT_HELPER='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'

def packet(folder,leaf,digest):
    path=folder/leaf
    assert pin(path)['sha256']==digest
    value=json.loads(path.read_text())
    rows={str(path):pin(path)}
    for name,row in value['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        actual=folder/name
        assert pin(actual)['sha256']==(row if type(row)is str else row['sha256'])
        rows[str(actual)]=pin(actual)
    return rows


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--source-freeze',required=True)
    parser.add_argument('--expected-head',required=True)
    parser.add_argument('--destination',required=True,type=Path)
    args=parser.parse_args()
    assert Path.cwd()==REPO and sys.dont_write_bytecode and sys.flags.no_site==1
    assert len(args.expected_head)==40 and head()==args.expected_head
    physical=packet(SOURCE,'source-freeze.json',args.source_freeze)
    physical.update(packet(SUBJECT,'source-freeze.json',SUBJECT_SHA))
    assert pin(SOURCE/'closed_import_origins.py')['sha256']==SUBJECT_HELPER
    review=REPO/'.ios-host-tmp/lifecycle-independent-chat-controller10b-fresh-source-full-review2-20261104'
    physical.update(packet(review,'freeze.json','0067a382c7555b7084e421f73f9eeb2bbb1d8bfe831db78101ccd53d66703196'))
    original_bootstrap=REPO/'.ios-host-tmp/chat-c10b-source-execution-own6-bootstrap1-code-preparation-20261104'
    physical.update(packet(original_bootstrap,'source-freeze.json','abf162d3852d0b145102d1ffb6dac028e2e55beed92844092793d65c07d50a4f'))
    failure=REPO/'.ios-host-tmp/root-c10b-own6-first4-pass-fifth-namespace-cache-annotation-mutation-failure-results-20261104'
    physical.update(packet(failure,'freeze.json','d3995a7f5d9f938c65afb48713426f351ed3c729d9caddd640b8c836172f352d'))
    failure_refs=json.loads((failure/'actual-receipt-references.json').read_text());assert len(failure_refs)==46
    for row in failure_refs.values():
        path=Path(row['path']);assert path.is_absolute()and path.resolve(strict=True)==path
        assert pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
    retainer=REPO/'tests/device/ios/self_tests/retained_host_roots.py'
    assert pin(retainer)['sha256']=='07ddd7913819ee1c7d21bd36567c207906c7cc9df82e59d6fe80b64b0dadbcf6'
    physical[str(retainer)]=pin(retainer)
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ')
    gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):
        physical[str(path)]=pin(path)
    ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    actual_ref=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),None)
    if actual_ref is None:actual_ref=common/'packed-refs'
    physical[str(actual_ref)]=pin(actual_ref)
    std=Path(os.__file__).resolve(strict=True).parent
    suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);std_namespaces={}
    for current,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current)
        dirs[:]=sorted(name for name in dirs if name not in('site-packages','dist-packages','__pycache__')and not(folder/name).is_symlink())
        relative=folder.relative_to(std)
        if relative.parts and all(part.isidentifier()for part in relative.parts)and not(folder/'__init__.py').is_file():
            std_namespaces['.'.join(relative.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(suffixes):continue
            assert path.resolve(strict=True)==path and not path.is_symlink()
            physical[str(path)]=pin(path)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    destination=args.destination
    assert destination.is_absolute()and destination.resolve(strict=False)==destination
    assert destination.parent==REPO/'.ios-host-tmp'and destination.name.startswith('chat-c10c-own6-prepared-')and not destination.exists()
    names=('run-own6.py','supervise-own6.py','metadata_reader.py','host_common.py','closed_import_origins.py',
        'owned_write_boundary.py','test_c10_source_execution.py','readonly-shared-stdlib-sources.json','exact-six-selectors.json')
    before=dict(physical)
    assert all(pin(path)==row for path,row in before.items())and head()==args.expected_head
    destination.mkdir(mode=0o700)
    for name in names:
        target=destination/name
        descriptor=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(descriptor,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(target)]=pin(target)
    projects={}
    for name in('metadata_reader','host_common','closed_import_origins','owned_write_boundary','test_c10_source_execution'):
        path=destination/(name+'.py')
        projects[name]=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=False)
    projects['ios.self_tests.retained_host_roots']=dict(path=str(retainer),sha256=physical[str(retainer)]['sha256'],package=False)
    namespaces={'ios':[str(REPO/'tests/device/ios')],'ios.self_tests':[str(REPO/'tests/device/ios/self_tests')]}
    cases=json.loads((SOURCE/'exact-six-selectors.json').read_text())
    assert len(cases)==len(set(cases))==6
    subjects={name:dict(path=projects[name]['path'],sha256=projects[name]['sha256'])for name in('test_c10_source_execution','ios.self_tests.retained_host_roots')}
    origin=dict(modules=projects,namespacePackages=namespaces,thirdPartyModules={},thirdPartyNamespacePackages={},
        stdlibNamespacePackages=std_namespaces,stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='PRIVATE_C10B_SOURCE_EXECUTION_OWN6_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(destination),actualPublicHead=args.expected_head,
        sourceFreeze=args.source_freeze,subjectSourceFreeze=SUBJECT_SHA,sourceAndBinaryPins=physical,modules=projects,namespaces=namespaces,
        thirdPartyModules={},originPlan=origin,subjectOriginModules=subjects,subjectOriginCount=2,cases=cases,wallSeconds=30,killGraceSeconds=5,
        expectedTemporaryDirectories=6,expectedTemporaryDirectoriesPerCase=1,
        subjectOriginalPath=str(SUBJECT/'closed_import_origins.py'),subjectActualCopiedPath=str(destination/'closed_import_origins.py'),subjectHelperSha256=SUBJECT_HELPER,
        NodeExecutions=0,SDKExecutions=0,realNetwork=False,overteNativeQueries=0,oldCorpusInputs=0,globalOriginalScans=0,
        historicalFailureNamedMetadataPins=46,oldScenarioOriginalInputs=0,hostBootstrapScope='Original interpreter/stdlib and fresh private controller copies explicitly trusted; only actual delegated imports claim C10b fresh-source execution.',
        nativeQualified=False,wholeQualified=False)
    output=destination/'approved-inputs.json'
    descriptor=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(descriptor,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),inputSha256=pin(output)['sha256'],sourcePins=len(physical),cases=6,targets=0,globalScans=0)))
    return 0


if __name__=='__main__':raise SystemExit(main())
