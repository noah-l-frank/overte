"""Isolated genuine audit/monitoring visibility; no project imports."""
from pathlib import Path
import hashlib,json,os,sys,threading

def exercise(cantrace):
    monitor=sys.monitoring
    def reader():return 1
    def checker():return True
    code=checker.__code__
    active={'enabled':False,'inside':False}
    events={'readerAudits':0,'insideCheckerCalls':0,'insideReturnCallbacks':0,'outsideReturnCallbacks':0}
    tool=next(tool for tool in(2,5,4,3,1,0)if monitor.get_tool(tool)is None)
    def on_return(actual,offset,value):
        if actual is code:
            if active['inside']:events['insideReturnCallbacks']+=1
            else:events['outsideReturnCallbacks']+=1
    def audit(event,args):
        if active['enabled']and event=='object.__getattr__'and len(args)==2 and args[0]is reader and args[1]=='__code__':
            events['readerAudits']+=1;active['inside']=True
            try:
                monitor.set_local_events(tool,code,monitor.events.PY_RETURN)
                events['insideCheckerCalls']+=1;checker()
            finally:active['inside']=False
    audit.__cantrace__=cantrace
    sys.addaudithook(audit)
    monitor.use_tool_id(tool,'root-isolated-audit-return-'+str(cantrace))
    try:
        monitor.register_callback(tool,monitor.events.PY_RETURN,on_return)
        active['enabled']=True
        actual=reader.__code__
        active['enabled']=False
        checker()
    finally:
        active['enabled']=False
        monitor.set_local_events(tool,code,0)
        monitor.register_callback(tool,monitor.events.PY_RETURN,None)
        monitor.free_tool_id(tool)
    assert events['readerAudits']==events['insideCheckerCalls']==1
    assert events['outsideReturnCallbacks']==1
    assert monitor.get_tool(tool)is None
    return dict(auditCanTrace=cantrace,**events)

before=tuple(threading.enumerate())
assert sys.getprofile()is None and sys.gettrace()is None
rows=[exercise(False),exercise(True)]
assert rows[0]['insideReturnCallbacks']==0
assert rows[1]['insideReturnCallbacks']==1
assert tuple(threading.enumerate())==before
assert sys.getprofile()is None and sys.gettrace()is None
assert not any(name.split('.')[0]in('ios','adapters','feature_journeys','PIL','pymobiledevice3','appium')for name in sys.modules)
root=Path(__file__).resolve().parent
result=dict(status='ACTUAL_ISOLATED_STDLIB_AUDIT_CANTRACE_VISIBILITY_COUNTER_PASS',rows=rows,
    python=sys.version,executable=sys.executable,previousCounter='root-stdlib-checker-pyreturn-inside-audit-visibility-counter-20261104',
    previousCounterLimitation='First default-False row had one genuine event; second row reused module globals in prior still-installed hook. This counter holds independent closure state per exercise and disables each owned hook before the next.',
    auditHooksRemoved=False,ownedAuditHooksFinallyPassive=True,SUTImports=0,temporaryDirectories=0,wholeQualified=False,nativeQualified=False)
with(root/'results.json').open('x')as stream:stream.write(json.dumps(result,sort_keys=True,indent=2)+'\n')
files={q.name:dict(bytes=q.stat().st_size,sha256=hashlib.sha256(q.read_bytes()).hexdigest())for q in root.iterdir()if q.is_file()}
with(root/'freeze.json').open('x')as stream:stream.write(json.dumps(dict(files=files),sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(rows=rows,freeze=hashlib.sha256((root/'freeze.json').read_bytes()).hexdigest())))
