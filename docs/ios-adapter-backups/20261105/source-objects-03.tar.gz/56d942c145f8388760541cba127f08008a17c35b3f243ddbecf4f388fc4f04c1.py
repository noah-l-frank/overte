from pathlib import Path
import ast,difflib,hashlib,json,shutil,stat
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';OLD=T/'lifecycle-original-owner-native-file8-root-preparation-20261028/05-native8';P=T/'lifecycle-original-owner-native-file8-world-run-model-overlay-20261028';P.mkdir(mode=0o700);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=(OLD/'test_native_file_channel_models.py').read_text();a='''        b=TouchBoundary();packet=b.reader().read(self.f.run_id);self.input.write_text(json.dumps(packet))
        args=self.args();args['query']=dict(schemaVersion=1,commandId=packet['requestId'],action=world.ACTION,runId=self.f.run_id)
''';b='''        from ios.self_tests.test_ios_lifecycle_world import RUN
        # The existing Scene producer was born with RUN before this capture;
        # never rewrite its original journal/run to match the touch fixture.
        b=TouchBoundary();packet=b.reader().read(RUN);self.input.write_text(json.dumps(packet))
        self.assertEqual(RUN,packet['runId']);self.assertEqual(int(self.binding['processIdentity']),packet['processId'])
        args=self.args();args['runId']=RUN
        args['query']=dict(schemaVersion=1,commandId=packet['requestId'],action=world.ACTION,runId=RUN)
''';assert s.count(a)==1;s=s.replace(a,b);ast.parse(s);(P/'test_native_file_channel_models.py').write_text(s)
(P/'proposal.diff').write_text(''.join(difflib.unified_diff((OLD/'test_native_file_channel_models.py').read_text().splitlines(True),s.splitlines(True),fromfile='a/test_native_file_channel_models.py',tofile='b/test_native_file_channel_models.py')))
(P/'README.txt').write_text('''PRIVATE test-only UNRUN correction. Root first Native8: first geometry PASS,
second world ERROR before native-file operation. IOSLifecycleWorld subclasses
IOSPlacesModel, whose generic read error masks the scene's original RUN mismatch.
TouchLease uses d*32; original SceneBoundary is born with a*32. Select that
existing original producer RUN BEFORE capture and reuse exact native PID/run/raw
bytes. Do not mutate/rebind/retime any original scene or production source.
Original failed logs/two actual files/two genuine TD remain unchanged.
''')
(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE_TEST_ONLY_UNRUN',base=str(OLD/'test_native_file_channel_models.py'),baseSHA256=h(OLD/'test_native_file_channel_models.py'),candidateSHA256=h(P/'test_native_file_channel_models.py'),sourceChanged=False),indent=2)+'\n')
(P/'freeze.json').write_text(json.dumps(dict(files={str(p.relative_to(P)):h(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n')
TOP=T/'lifecycle-original-owner-native-file8-world-run-corrected-root-preparation-20261028';S=TOP/'05-native8';S.mkdir(mode=0o700,parents=True)
for name in json.loads((OLD/'freeze.json').read_bytes())['files']:
 src=OLD/name;dest=S/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
(S/'freeze.json').unlink(missing_ok=True);shutil.copyfile(P/'test_native_file_channel_models.py',S/'test_native_file_channel_models.py')
plan=json.loads((S/'run-plan.json').read_bytes());plan['privateFiles']['test_native_file_channel_models.py']=h(S/'test_native_file_channel_models.py');plan['status']='PRIVATE_UNRUN_CORRECTED_ROOT8_ORIGINAL_WORLD_RUN';(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
stage=json.loads((S/'source-manifest.json').read_bytes());stage['orderedParentFreezes']['lifecycle-original-owner-native-file8-world-run-model-overlay-20261028']=h(P/'freeze.json')
for row in stage['sourcePaths']:row['observedPublicSHA256']=h(R/row['path']);row['changesCurrentPublic']=row['observedPublicSHA256']!=row['candidateSHA256']
assert not any(row['changesCurrentPublic'] for row in stage['sourcePaths']);(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();v=dict(stat=[getattr(a,k) for k in fields]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
 if p.is_file():v['sha256']=h(p)
 assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
failed=OLD/'retained-first';origins=[failed,*sorted(failed.rglob('*'))];pins={str(p):pin(p) for p in origins};assert sum('sha256' in v for v in pins.values())==2
(S/'failed-first-original-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
p=S/'root-supervise.py';s=p.read_text();a=' return {str(path):pin(path) for path in sorted(paths)}';b=""" for name,expected in json.loads((HERE/'failed-first-original-pins.json').read_text()).items():
  path=Path(name);assert pin(path)==expected,str(path);paths.add(path)
 return {str(path):pin(path) for path in sorted(paths)}""";assert s.count(a)==1;p.write_text(s.replace(a,b));ast.parse(p.read_bytes())
(S/'root-parent-originals-guard.diff').write_text(''.join(difflib.unified_diff((OLD/'root-supervise.py').read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/root-supervise.py',tofile='b/root-supervise.py')))
(S/'clone-provenance.json').write_text(json.dumps(dict(parentFreezeSHA256=h(OLD/'freeze.json'),testOverlayFreezeSHA256=h(P/'freeze.json'),modelsSHA256=h(S/'test_native_file_channel_models.py'),caseCount=8,initialOuterSeconds=60,killAfterSeconds=5,expectedNewRealRoots=8,guardedFailedFiles=2,guardedFailedNodes=len(pins),publicSourceChanges=0),indent=2)+'\n')
(S/'README-correction.txt').write_text('''Root-only corrected8; fixed60+5 unchanged, exact old8 IDs. No source change.
Original Scene RUN selected before producer query; world PID/run/raw join strict.
Parent includes explicit two failed originals+all their retained nodes in both
full source censuses; actual new retained roots/FD/Task/Thread/Child boundaries
unchanged. No agent imports/tests/public edits. Old Native8 packet preserved.
''')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_CORRECTED_NATIVE8_UNRUN',files={str(p.relative_to(S)):h(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n')
(TOP/'freeze.json').write_text(json.dumps(dict(files={str(p.relative_to(TOP)):h(p) for p in sorted(TOP.rglob('*')) if p.is_file()}),indent=2)+'\n')
assert pins=={str(p):pin(p) for p in origins}
print(json.dumps(dict(testOverlayFreeze=h(P/'freeze.json'),stageFreeze=h(S/'freeze.json'),parentFreeze=h(TOP/'freeze.json'),testSHA256=h(S/'test_native_file_channel_models.py')),indent=2))
