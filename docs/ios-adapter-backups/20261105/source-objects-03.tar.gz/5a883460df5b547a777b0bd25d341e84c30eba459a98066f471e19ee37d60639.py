"""Actual original-frame/journal/source code; native/SDK/UI responses are models."""
from __future__ import annotations
import ast,asyncio,hashlib,inspect,json,os,tempfile,unittest,weakref
from contextlib import asynccontextmanager
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch


EXPECTED={'worldAttempt': '1c0b383a6c5f03afc2f2a33c1b8547cfeb49605ae546dd4ecfb42a68283a4af0', 'resourceOwner': 'aa7247dbcd93085d69a0dcb477bbb582395765f8e7567a2d22270c188b24c85a', 'keeper': 'abcc751b550dbe3b5a2a7eacf5dc503abb1c1f4265858ac8a62fe447fcd9b4b7', 'hostops': '1191c03544a8a1e02d657d6543390c9bf13d4017a769413b249159521eb14471'}

class OriginalMotionPreparationModels(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        raw=Path(os.environ['LIFECYCLE_MOTION_SOURCE_MAP']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_MOTION_SOURCE_MAP_SHA256']:
            raise RuntimeError('Reviewed full source map required before target imports')
        self.mapping=json.loads(raw)
        for name,sha in EXPECTED.items():
            if self.mapping[name]['sha256']!=sha:raise RuntimeError('Reviewed final motion source map required')
        for row in self.mapping.values():
            if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('Source pin changed')
        from ios.adapters import lifecycle_touch_resource_owner as owner
        from ios.self_tests import test_ios_lifecycle_world_hold as actual
        from adapters.normal_feature_state import PrivateFeatureState
        from adapters.script_feature.lock import ScriptSourceLock
        from adapters.native_feature_observation import need
        self.owner_module=owner;self.need=need;self.state_type=PrivateFeatureState
        self.assertEqual(Path(owner.__file__).resolve(),Path(self.mapping['resourceOwner']['path']))
        self.fixture=actual.LifecycleWorldHoldTests();self.fixture.setUp();self.addCleanup(self.fixture.doCleanups)
        self.hold=self.fixture.make()
        class MissingOriginalNativeChildGuard(RuntimeError):pass
        # Stop at the ACTUAL dependency point before any HID factory/Down.
        # All original native/frame sources up to that point execute normally.
        with patch.object(self.hold,'lease_owner',side_effect=MissingOriginalNativeChildGuard),self.assertRaises(MissingOriginalNativeChildGuard):
            await self.hold.act()
        self.frame=deepcopy(self.hold.frame(1));self.binding=deepcopy(self.hold.binding);self.run=self.hold.run
        self.assertEqual([],self.fixture.flags());self.assertEqual([],self.fixture.factories)
        self.root=Path(tempfile.mkdtemp(prefix='original-motion-preparation-'));self.root.chmod(0o700)
        self.lock=ScriptSourceLock(self.root/'script-feature-sources.lock')
        tree=ast.parse(Path(self.mapping['keeper']['path']).read_bytes())
        source=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='OriginalKeeperSource')
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='OriginalKeeperOperations')
        method=next(n for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='execute')
        selected=ast.ClassDef(name='ActualKeeperExecute',bases=[],keywords=[],body=[method],decorator_list=[],type_params=[])
        ns=dict(asyncio=asyncio,weakref=weakref,inspect=inspect,asynccontextmanager=asynccontextmanager,json=json,
                re=__import__('re'),LaunchError=RuntimeError)
        exec(compile(ast.fix_missing_locations(ast.Module(body=[source,selected],type_ignores=[])),'<actual-pinned-original-motion-keeper>','exec'),ns)
        class RSD:pass
        class Capability:
            def current(cap):return self.rsd,'fd00::1'
        class Tunnel:
            def original_source(tunnel):return self.capability
        self.rsd=RSD();self.capability=Capability();self.tunnel=Tunnel()
        self.source=ns['OriginalKeeperSource'].__new__(ns['OriginalKeeperSource'])
        self.source._source=self.capability;self.source._tunnel=weakref.ref(self.tunnel);self.source._loop=asyncio.get_running_loop()
        self.source._leases=[];self.source._born=[];self.source._closing=False
        self.ops=ns['ActualKeeperExecute']();self.ops.source=self.source;self.ops.instance='e'*32
        self.ops.session={'sessionId':self.binding['sessionId']};self.ops.state_root=self.root
        self.ops.touch=self.ops.touch_resources=None;self.fresh=[]
        def scope(session):need(session==self.binding['sessionId']);return self.source.current()[0]
        async def fresh(binding):need(binding==self.binding);self.fresh.append(deepcopy(binding));self.source.current()
        self.ops.scope=scope;self.ops.fresh_touch_scope=fresh
    def args(self):return dict(binding=deepcopy(self.binding),runId=self.run,frame=deepcopy(self.frame),seconds=3)
    async def prepare(self):return await self.ops.execute('touch-motion-prepare',self.args(),self.binding['sessionId'])
    def files(self):return {p.name:(p.stat().st_ino,p.read_bytes()) for p in self.root.iterdir() if p.is_file()}

    async def test_actual_original_path_geometry_and_native_scope_are_durable_before_any_worker_or_down(self):
        value=await self.prepare();resource=self.ops.touch_resources
        with resource.lock.held():self.assertTrue(resource.motion_current())
        packet=resource.store.read();self.assertEqual(2,packet['iosLifecycleTouchResourceOwnerVersion'])
        self.assertEqual(self.frame,packet['state']['frame']);self.assertEqual(self.binding,packet['binding'])
        self.assertEqual(dict(window={'width':1000,'height':640},start=[100,520],end=[100,505]),packet['state']['path'])
        self.assertEqual([],self.source._born);self.assertIsNone(self.ops.touch)
        self.assertFalse(value['nativeMotionGuardAvailable']);self.assertFalse(value['nativeTouchSupport'])
        self.assertEqual([],self.fixture.flags());self.assertEqual([],self.fixture.factories)

    async def test_endpoint_changed_without_original_native_geometry_is_rejected_by_same_derivation(self):
        await self.prepare();resource=self.ops.touch_resources;value=deepcopy(resource.previous)
        value['state']['path']['end'][0]+=1
        with self.assertRaises(RuntimeError):self.owner_module.motion_original(value,self.binding,self.run)
        self.assertEqual([100,505],resource.store.read()['state']['path']['end'])
        self.assertEqual([],self.source._born);self.assertEqual([],self.fixture.flags())

    async def test_unbracketed_geometry_or_foreign_native_pid_cannot_supply_preparation(self):
        from adapters.native_clock_join import digest
        from ios.adapters import lifecycle_world as world
        for kind in ('geometry','pid'):
            args=self.args();frame=args['frame']
            if kind=='geometry':frame['originals']['geometry']['observation']['sampleEpochMs']=frame['clockJoin']['nativeBefore']['capturedEpochMs']-1
            else:args['binding']['processIdentity']=str(int(self.binding['processIdentity'])+1)
            frame['clockJoin']['originalsSha256']=digest(frame['originals'])
            with self.subTest(kind=kind),self.assertRaises((RuntimeError,ValueError)):
                if kind=='geometry':await self.ops.execute('touch-motion-prepare',args,self.binding['sessionId'])
                else:
                    packet=dict(iosLifecycleTouchResourceOwnerVersion=2,binding=args['binding'],runId=self.run,
                        state=dict(phase='motion-prepared',ownerInstance='e'*32,hostProcessId=os.getpid(),frame=frame,
                            path={'window':{'width':1000,'height':640},'start':[100,520],'end':[100,505]},seconds=3,sourceContext=deepcopy(world.context(frame['originals']['world']))))
                    self.owner_module.motion_original(packet,args['binding'],self.run)
            self.assertEqual([],self.source._born);self.assertEqual([],self.fixture.flags())

    async def test_restored_literal_v2_cannot_reconstruct_original_source_pair_or_acquire_hid(self):
        await self.prepare();resource=self.ops.touch_resources;before=self.files()
        with resource.lock.held():
            restored=self.owner_module.LifecycleTouchResourceOwner(self.state_type(resource.store.path),self.binding,self.run,resource.lock,lambda:True)
            with self.assertRaises(RuntimeError):restored.motion_current()
            with self.assertRaises(RuntimeError):restored.make_lease(self.state_type(self.root/('ios-lifecycle-touch-lease-'+self.run+'.json')),
                self.rsd,'fd00::1',check=lambda:True)
        self.assertEqual(before,self.files());self.assertEqual([],self.source._born);self.assertEqual([],self.fixture.flags())

    async def test_same_source_object_with_changed_original_rsd_pair_cannot_revive_preparation(self):
        await self.prepare();resource=self.ops.touch_resources;before=self.files();original=self.rsd
        self.rsd=type(original)()
        with resource.lock.held(),self.assertRaises(RuntimeError):resource.motion_current()
        self.rsd=original
        with resource.lock.held(),self.assertRaises(RuntimeError):resource.motion_current()
        self.assertEqual(before,self.files());self.assertEqual([],self.source._born);self.assertEqual([],self.fixture.flags())

    async def test_in_memory_motion_path_mutation_cannot_change_the_original_saved_preparation(self):
        await self.prepare();resource=self.ops.touch_resources;before=self.files()
        resource.state['path']['end'][0]+=1
        with resource.lock.held(),self.assertRaises(RuntimeError):resource.motion_current()
        self.assertEqual(before,self.files());self.assertEqual([100,505],resource.store.read()['state']['path']['end'])
        self.assertEqual([],self.source._born);self.assertEqual([],self.fixture.flags())

    async def test_lost_saved_preparation_return_retains_original_bytes_and_never_replays_down_or_factory(self):
        write=self.state_type.write
        def lost(store,value,previous):
            result=write(store,value,previous)
            if value.get('iosLifecycleTouchResourceOwnerVersion')==2:raise OSError('Declared original motion journal return lost')
            return result
        with patch.object(self.state_type,'write',new=lost),self.assertRaises(OSError):await self.prepare()
        resource=self.ops.touch_resources;self.assertIsNotNone(resource);before=self.files();self.assertIsNone(resource.previous)
        self.assertEqual(2,resource.store.read()['iosLifecycleTouchResourceOwnerVersion'])
        with self.assertRaises(RuntimeError):await self.prepare()
        self.assertEqual(before,self.files());self.assertIsNone(self.ops.touch);self.assertEqual([],self.source._born)
        self.assertEqual([],self.fixture.flags());self.assertEqual([],self.fixture.factories)
