"""Callback Ownership1 joins copied State1 to Journal2 and inactive original.

Historical proof only. No clock/query/current permission is manufactured.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import exact,need
from adapters.script_feature.history import same
from feature_journeys import terminal
from ios.adapters.emote_callback_copied_state import IOSEmoteCallbackCopiedState
from ios.adapters.emote_callback_terminal import IOSEmoteCallbackTerminalJournal
from ios.adapters.emote_rooted_fence import _seal,inactive,inactive_prefixes
from ios.adapters import emote_callback_drain_originals as drains


def checkpoint_shape(value,*,run):
    exact(value,{'iosEmoteCallbackInactiveCheckpointVersion','runId','phaseInstance','configuredTargetPair',
        'seal','terminalProof','completionFloorEpochMs','rolePhasePrefixes','phaseOriginal'})
    need(type(value['iosEmoteCallbackInactiveCheckpointVersion']) is int and value['iosEmoteCallbackInactiveCheckpointVersion']==1
        and value['runId']==run)
    terminal.sealed(value['seal']);exact(value['terminalProof'],{'seal','original'})
    need(same(value['terminalProof']['seal'],value['seal']))
    inactive(value['phaseOriginal'],run=run,instance=value['phaseInstance'],ticket=value['seal']['description']['ticket'],after=value['completionFloorEpochMs'])
    inactive_prefixes(value['phaseOriginal'],value['rolePhasePrefixes'],run=run)
    return value


class IOSEmoteCallbackCopiedOwnership:
    VERSION=1
    def __init__(self,copies,*,run,lock,actor_lock):
        need(type(copies) is dict)
        self.path=lock.path.with_name('ios-emote-primary-'+run+'-terminal.json')
        need(str(self.path) in copies and type(copies[str(self.path)]) is dict)
        self.terminal=deepcopy(copies[str(self.path)])
        self.roles=IOSEmoteCallbackCopiedState({path:value for path,value in copies.items() if path!=str(self.path)},
            run=run,lock=lock,actor_lock=actor_lock)
    def read_with_retirement_context(self):
        roots={lock.path.parent for lock in self.roles.locks.values()}
        for role,lock in self.roles.locks.items():
            value=self.roles.copies.get(str(lock.path.with_name('ios-emote-'+role+'-feature.json')))
            need(type(value) is dict and type(value.get('artifactRoot')) is str);roots.add(Path(value['artifactRoot']))
        def read():
            window,prefixes=self.roles.read()
            def guarded():
                for lock in self.roles.locks.values():lock.assert_held()
                return True
            journal=IOSEmoteCallbackTerminalJournal.archive(window,self.terminal,check=guarded)
            need(journal.state is not None and journal.state['phase']=='sealed')
            proof=journal.originals.read(journal.originals.expand(journal.state['record']));journal.proof(proof,journal.state)
            original=proof['original'];need(same(original['journals'],{role:live.previous for role,live in window.roles.items()}))
            publisher=self.roles.store(self.roles.locks['actor'].path.with_name('phase-publication-emotes-'+self.roles.run+'-actor.json'))
            need(same(original['publisher'],publisher.read()))
            actual,floor=window.qualify_with_retirement_floor(journal.state['description'],original['samples'],journal.state['references'],
                publisher_store=publisher,record_store_for=self.roles.store)
            need(same(actual,proof));journal.bound();return deepcopy(actual),floor,deepcopy(prefixes)
        return drains.checked_read(roots,read)
    def read(self,checkpoint):
        checkpoint_shape(checkpoint,run=self.roles.run)
        proof,floor,prefixes=self.read_with_retirement_context()
        need(same(proof,checkpoint['terminalProof']) and floor==checkpoint['completionFloorEpochMs']
            and same(prefixes,checkpoint['rolePhasePrefixes']))
        for role,lock in self.roles.locks.items():
            value=self.roles.copies[str(lock.path.with_name('ios-emote-'+role+'-feature.json'))]
            need(value['callbackProfile']['terminalWindowVersion']==2 and value['payload'] is not None
                and same(value['targetPair'],self.roles.copies[str(self.roles.locks['primary'].path.with_name('ios-emote-primary-feature.json'))]['targetPair']))
            from ios.adapters.emote_target_pair import selected
            need(same(selected(value['targetPair']),checkpoint['configuredTargetPair']))
            _seal(proof,checkpoint['seal'],run=self.roles.run,role=role,binding=value['targetPair'][role+'Binding'])
        # Actual Live2 decoding bound the phaseInstance; compare that same
        # original header explicitly, rather than adding a field to Pair1.
        for role,lock in self.roles.locks.items():
            live=self.roles.copies[str(lock.path.with_name('ios-emote-'+role+'-'+self.roles.run+'-terminal-live.json'))]
            need(live['phaseInstance']==checkpoint['phaseInstance'])
        return dict(iosEmoteCallbackCopiedOwnershipVersion=self.VERSION,proof=proof,
            completionFloorEpochMs=floor,rolePhasePrefixes=prefixes,phaseOriginal=deepcopy(checkpoint['phaseOriginal']))
