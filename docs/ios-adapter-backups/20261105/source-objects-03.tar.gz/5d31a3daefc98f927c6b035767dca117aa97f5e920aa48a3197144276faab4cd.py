"""Unrun diagnostic proposal: only the cold historical Source's remaining CPU cost.

Fixed outer60s; original real API25 remains unchanged. Run only in an explicitly granted single-heavy slot, all repository sources
frozen, with PYTHONDONTWRITEBYTECODE=1 and the four established PYTHONPATHs.
No result can qualify an installed operation, native code or any device.
"""
from pathlib import Path
import hashlib,json,sys,time,traceback

REPO=Path.cwd()
EXPECTED=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026')
if REPO!=EXPECTED:raise AssertionError('Wrong worktree')
ROOT=REPO/'.ios-host-tmp/tmp3ieeyyp4'
OUT=REPO/'.ios-host-tmp/world-web-cold-source-next-profile-20261027'
if OUT.exists():raise AssertionError('Never reuse a diagnostic output directory')
OUT.mkdir(mode=0o700)
LAUNCHER=Path(__file__).resolve()

def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def source_census():
 paths={p for p in (REPO/'tests/device').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
 paths.update(p for p in (REPO/'scripts').rglob('*.js') if p.is_file())
 paths.update(p for p in (REPO/'interface/resources/qml/hifi').rglob('*.qml') if p.is_file())
 paths.add(LAUNCHER)
 return {str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
BEFORE=source_census();save('sources-before.json',BEFORE)
from contextlib import ExitStack
import cProfile,pstats,socket,subprocess,signal
from types import SimpleNamespace
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import unpack
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_original_lease import EmoteOriginalLease
from ios.adapters.world_web_sources import WorldWebSources
from ios.adapters.world_web_construction import construct
from ios.adapters.world_web_api_clock import scope

def originals():
 rows={}
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():
   first=EmoteOriginalLease.signature(p.lstat());raw=p.read_bytes()
   if EmoteOriginalLease.signature(p.lstat())!=first:raise AssertionError('Original changed during census')
   rows[str(p.relative_to(ROOT))]=(first,hashlib.sha256(raw).hexdigest())
 return rows
ORIGINALS=originals();save('originals-before.json',ORIGINALS)
store=PrivateFeatureState(ROOT/'ios-world-web-primary-sources.json');packet=store.read()
frame=unpack(PrivateFeatureState(ROOT/'ios-world-web-primary-sources-1.json').read()['payload'])[0]
phase=SimpleNamespace(fixture_url=frame['snapshotQueries'][0]['fixtureUrl'])
lock=ScriptSourceLock(ROOT/'script-feature-sources.lock')
effects=[]
def forbidden(*_args,**_kwargs):effects.append('forbidden transport or private-state mutation');raise AssertionError(effects[-1])
def terminated(number,frame):
 raise SystemExit(128+number)
signal.signal(signal.SIGTERM,terminated)
profile=cProfile.Profile();report=dict(profileOnly=True,wholeQualified=False,nativeCompiled=False,deviceQualified=False,originalFiles=len(ORIGINALS),apiBudgetSeconds=25)
try:
 with ExitStack() as stack:
  for obj,name in ((PrivateFeatureState,'write'),(PrivateFeatureState,'discard'),(subprocess,'Popen'),(socket,'create_connection')):
   stack.enter_context(patch.object(obj,name,side_effect=forbidden))
  stack.enter_context(lock.held());began=time.perf_counter()
  profile.enable(subcalls=False,builtins=False)
  try:
   with scope(time.monotonic):
    with construct(lambda:WorldWebSources(store,lock,packet['binding'],packet['runId'],packet['role'],lambda:True,phase=phase,historical=True)) as owner:
     report['constructedRecords']=len(owner.state['records'])
   report['diagnosticCompleted']=True
  finally:profile.disable();report['seconds']=time.perf_counter()-began
except BaseException as error:
 report.update(diagnosticCompleted=False,errorType=type(error).__name__,error=str(error));traceback.print_exc()
finally:
 profile.disable();profile.dump_stats(str(OUT/'cold-source.pstats'))
 stats=pstats.Stats(profile)
 rows=[dict(file=key[0],line=key[1],function=key[2],calls=value[1],internalSeconds=value[2],cumulativeSeconds=value[3]) for key,value in stats.stats.items()]
 report['largestCumulative']=sorted(rows,key=lambda row:row['cumulativeSeconds'],reverse=True)[:60]
 report['largestInternal']=sorted(rows,key=lambda row:row['internalSeconds'],reverse=True)[:40]
 after=originals();save('originals-after.json',after);report['originalsUnchanged']=after==ORIGINALS
 after_sources=source_census();save('sources-after.json',after_sources);report['sourcesUnchanged']=after_sources==BEFORE
 report['effects']=effects;report['builtinAndSubcallEventsEnabled']=False
 save('report.json',report);print(json.dumps({key:report[key] for key in report if key not in ('largestCumulative','largestInternal')}),flush=True)
raise SystemExit(0 if report.get('diagnosticCompleted') and report['originalsUnchanged'] and report['sourcesUnchanged'] and not effects else 1)
