from pathlib import Path
import ast,difflib,hashlib,json,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-canonical4-original-results-root-preparation-20261029/69-canonical-child4';LEGACY=T/'lifecycle-original-owner-canonical4-legacy18-root-preparation-20261029/65-legacy-hold18';FIX=T/'lifecycle-original-owner-normal-child-original-http-producer-overlay-20261029';P=T/'lifecycle-original-owner-canonical-producer4-legacy18-root-preparation-20261029';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();report=json.loads((B/'root-run-first/report.json').read_text());summary=json.loads((B/'actual-source-raise-summary-first.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==30 and report['allPinsEqual'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses'];assert summary['ownedToolFreed'] and not summary['dropped'] and not summary['writeFailures']
FIX.mkdir(mode=0o700);base=FIX/'base/normal_child_fixture.py';out=FIX/'candidate/normal_child_fixture.py';base.parent.mkdir();out.parent.mkdir();shutil.copyfile(B/'normal_child_fixture.py',base);text=base.read_text();old='from ios.adapters.appium_adapter import WebDriver as ActualWebDriver';new=old+'\nfrom ios.adapters.feature_observation import post_request as ActualPostRequest';assert text.count(old)==1;text=text.replace(old,new,1)
old="        self.runtime=runtime_module.IOSLifecycleWorldHoldRuntime(f.adapter)";new="""        from ios.adapters import feature_observation
        host_model_post=feature_observation.post_request
        def route_original_http(request,timeout):
            # Only the ACTUAL already-registered original source HTTP thread
            # uses the existing real sender/producer. No URL/JSON/name/flag is
            # accepted as ownership. Host-SDK producer models stay separate.
            current=threading.current_thread()
            born=any(row[1] is current and row[3] is self.loop and not row[2].is_set()
                and row[0].get_loop() is self.loop and not row[0].done()
                for row in self.source._native_queries)
            return ActualPostRequest(request,timeout) if born else host_model_post(request,timeout)
        self.enterContext(patch.object(feature_observation,'post_request',side_effect=route_original_http))
        self.runtime=runtime_module.IOSLifecycleWorldHoldRuntime(f.adapter)""";assert text.count(old)==1;text=text.replace(old,new,1);out.write_text(text);ast.parse(text)
(FIX/'test-only1.diff').write_text(''.join(difflib.unified_diff(base.read_text().splitlines(True),text.splitlines(True),fromfile='a/normal_child_fixture.py',tofile='b/normal_child_fixture.py')));(FIX/'manifest.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_TEST_ONLY',baseSHA256=H(base),candidateSHA256=H(out),actualFailure='SourceQuery1bundle HTTP-returned but physicalAFCinput remained401byteGeometry witholderdifferentnonce',source2Unchanged=True,onlyModelHTTPDispatchChanged=True,dispatchAuthority='exactactualregisteredThreadobject+Task/loop/unsettledrow; notURL/header/name/flag',actualOriginalPostRequestPreserved=True,allOldBytesUnchanged=True,testsRun=False),indent=2)+'\n');(FIX/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(FIX)):H(p) for p in sorted(FIX.rglob('*')) if p.is_file()}),indent=2)+'\n')
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((B/'prior-retained-original-pins.json').read_text());assert sum('sha256' in v for v in prior.values())==3361;root=B/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==30
for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
for n in ['report.json','thread-report.json','process-binding.json']:p=B/'root-run-first'/n;prior[str(p)]=pin(p)
for n in ['actual-source-raise-events-first.jsonl','actual-source-raise-summary-first.json']:p=B/n;prior[str(p)]=pin(p)
assert sum('sha256' in v for v in prior.values())==3396
P.mkdir(mode=0o700);outputs=[]
for number,label,original in [(70,'canonical-child4',B),(71,'legacy-hold18',LEGACY)]:
 S=P/(str(number)+'-'+label);S.mkdir(mode=0o700)
 for n,d in json.loads((original/'freeze.json').read_text())['files'].items():
  assert H(original/n)==d;dest=S/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original/n,dest)
 (S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n');plan=json.loads((S/'run-plan.json').read_text())
 if number==70:
  shutil.copyfile(out,S/'normal_child_fixture.py');shutil.copyfile(FIX/'test-only1.diff',S/'test-only-original-source-thread-http.diff');plan['privateFiles']['normal_child_fixture.py']=H(S/'normal_child_fixture.py')
 plan['status']='PRIVATE_UNRUN_SOURCE_HTTP_PRODUCER_FIXED4' if number==70 else 'PRIVATE_UNRUN_FIRST_LITERAL_LEGACY18_AFTER69'
 (S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n');stage=json.loads((S/'source-manifest.json').read_text());changes=[]
 for row in stage['sourcePaths']:
  rel=row['path'];actual=H(R/rel)
  if actual!=row['candidateSHA256']:
   dest=S/'actual-current-dependency/repo'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,dest);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(dest),candidateSHA256=actual)
  row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
 stage.update(stage=number,name=S.name,status=plan['status'],sourceDeltaPaths=[],exactPublicMutationPlan='NONE. ActualSource59f5/791b/current5ce/659shared unchanged; correctedtestfixture4 or FIRSTliteralold18.');
 if number==70:stage['orderedParentFreezes'][FIX.name]=H(FIX/'freeze.json')
 (S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');(S/'clone-provenance-after69.json').write_text(json.dumps(dict(parentStageFreeze=H(original/'freeze.json'),actual69ERRORReportSHA256=H(B/'root-run-first/report.json'),actual69OriginalFiles=30,totalPriorPinnedFiles=3396,actualOldOriginalFiles=3335,actualReports=45,actualDiagnosticFiles=16,caseCount=4 if number==70 else 18,initialSeconds=90,killAfterSeconds=5,expectedRealRoots=12 if number==70 else 18,modelAssertionChanges=False,sourceChanges=changes,executed=False),indent=2)+'\n')
 (S/'README-after69.txt').write_text(('Root70 corrected4/90+kill5/12realTD/expandedRAISE. Source-ownedoriginalHTTPthreads nowreachactualexistingnativeHTTPproducer andphysicalAFCinput, whilehostSDKmodelcalls keeptheirdeclaredroute. ExactactualThread/Task/loop row selectsfixturetransport, neverURL/flags. NoSource/validator/oldbytes change. ' if number==70 else 'Root71 FIRSTunchangedDefault1Legacy18/90+kill5/18realTD/noRAISE/noNative4fixtureexecution. Independent ofnew4producerfixture, original65UNRUNpreserved. ')+'All66/67/68/69originals/reports/diag retained:3335originals+45reports+16diag=3396priorfiles. Sourcepublic59f5/791b/currentregistry unchanged, noSourcePUB. Noagentimports/tests.\n')
 for p in S.rglob('*.py'):ast.parse(p.read_bytes())
 (S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2)+'\n');outputs.append(dict(path=str(S),freeze=H(S/'freeze.json'),changes=changes))
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(path=str(P),freeze=H(P/'freeze.json'),overlay=str(FIX),overlayFreeze=H(FIX/'freeze.json'),fixture=H(out),stages=outputs),indent=2))
