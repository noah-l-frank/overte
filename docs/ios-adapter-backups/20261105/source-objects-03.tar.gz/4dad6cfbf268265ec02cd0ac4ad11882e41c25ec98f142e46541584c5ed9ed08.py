"""No-build documentation/contracts checks after selected Pool host runs."""
from pathlib import Path
import hashlib,json,stat,subprocess,sys
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
ROOTS=('tests/device','interface/src/main.cpp','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics','libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    a=path.lstat();row={k:getattr(a,k) for k in FIELDS}
    if stat.S_ISREG(a.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    else:assert stat.S_ISDIR(a.st_mode)
    b=path.lstat();assert all(getattr(a,k)==getattr(b,k) for k in FIELDS),str(path)
    return row
def save(name,value):(HERE/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def sources():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    files={REPO/name for name in names if name}|{Path(__file__).resolve()}
    return {str(p.relative_to(REPO)):pin(p) for p in sorted(files)}
def originals():
    combined={}
    for mode in ('uikit-seven',):
        old=json.loads((HERE/('root-'+mode+'-first-originals-second.json')).read_text())
        for name,rows in old.items():
            root=Path(name);now={str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))}
            assert now==rows,'Retained actual originals changed: '+name
            combined[name]=now
    return combined
before=sources();retained=originals();save('root-common-source-before.json',before)
commands=[
 [sys.executable,'tests/run-project-tests.py','--profile','quick','--suite','documentation','--suite','documentation-contracts','--suite','ios-input-selection','--suite','policy-consistency','--suite','project-coverage','--timeout','240'],
 [sys.executable,'tests/device/validate_contract_versions.py'],
 [sys.executable,'tests/check-documentation.py','--all'],['git','diff','--check'],['git','diff','--cached','--check']]
code=0
try:
    for argv in commands:
        print('CHECK',json.dumps(argv),flush=True);result=subprocess.run(argv,cwd=REPO)
        if result.returncode:code=result.returncode;break
finally:
    after=sources();save('root-common-source-after.json',after)
    assert before==after,'Source/launcher changed during checks'
    assert retained==originals(),'Retained originals changed during checks'
    report=dict(exitCode=code,sourceLauncherPins=len(after),retainedFiles=sum(stat.S_ISREG(row['st_mode']) for rows in retained.values() for row in rows.values()),allPinsUnchanged=True,nativeCompiled=False,deviceQualified=False)
    save('root-common-report.json',report);print('COMMON_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
raise SystemExit(code)
