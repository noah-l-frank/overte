"""Actual source AST methods; explicit SDK/RSD/inventory DI, never SDK imports.
These eight source models do not qualify auth, installed code or native services.
"""
from __future__ import annotations
import ast
import asyncio
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import unittest

class OriginalReadonlyModels(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        raw=Path(os.environ['LIFECYCLE_READONLY_SOURCE']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_READONLY_SOURCE_SHA256']:
            raise RuntimeError('Pinned original source changed')
        tree=ast.parse(raw);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='OriginalKeeperOperations')
        names=('pre_session_rsd','preflight_apps','ddi_status','execute')
        methods=[next(n for n in cls.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name) for name in names]
        # Exactly two modeled SDK service imports replaced with explicit DI;
        # all remaining actual method bodies/ordering/guards remain unchanged.
        expected={'preflight_apps':('pymobiledevice3.services.installation_proxy','InstallationProxyService'),
                  'ddi_status':('pymobiledevice3.services.mobile_image_mounter','PersonalizedImageMounter')}
        for method in methods:
            if method.name in expected:
                module,name=expected[method.name];node=method.body[0]
                if not (isinstance(node,ast.ImportFrom) and node.module==module and len(node.names)==1 and node.names[0].name==name):
                    raise RuntimeError('Reviewed explicit SDK DI boundary changed')
                method.body=method.body[1:]
        class ModelError(RuntimeError):pass
        self.error=ModelError;self.calls=[];self.live=True;self.lookup_hook=None;self.connect_hook=None
        self.apps={
            'org.example.overte':{'CFBundleIdentifier':'org.example.overte','ApplicationType':'User',
                'OverteE2ETestBuildContractVersion':1,'UIFileSharingEnabled':True,
                'ProfileValidated':True,'SignerIdentity':'MODEL-ONLY',
                'Entitlements':{'com.apple.developer.team-identifier':'MODELTEAM0',
                    'application-identifier':'MODELTEAM0.org.example.overte','unconsumed':'do-not-transport'}},
            'org.example.wda':{'CFBundleIdentifier':'org.example.wda','ApplicationType':'User',
                'OverteE2EWebDriverAgentVersion':'16.8.0','OverteE2EXCUITestDriverVersion':'12.8.0',
                'CFBundleExecutable':'Model-Runner','ProfileValidated':True,'SignerIdentity':'MODEL-ONLY'}}
        self.signature=b's'*48;self.mounter_response={'ImagePresent':True,'ImageSignature':[b'x'*48,self.signature]}
        self.args={'overteBundleId':'org.example.overte','wdaBundleId':'org.example.wda','discoverRemappedBundleIds':False}
        outer=self
        class RsdModel:
            def get_service_port(_self,name):
                outer.calls.append(('port',name));return {'com.apple.dt.testmanagerd.remote':1234,'com.apple.instruments.dtservicehub':1235}[name]
            async def create_service_connection(_self,port):
                outer.calls.append(('connect',port));await asyncio.sleep(0)
                if outer.connect_hook:await outer.connect_hook()
                class Connection:
                    async def close(_conn):outer.calls.append(('close',port));await asyncio.sleep(0)
                return Connection()
        self.rsd=RsdModel()
        class SourceModel:
            def current(_self):
                if not outer.live:raise ModelError('source revoked')
                return (outer.rsd,)
        class InstallModel:
            def __init__(_self,rsd):outer.assertIs(rsd,outer.rsd);outer.calls.append(('install-create',rsd))
            async def __aenter__(_self):outer.calls.append(('install-enter',));return _self
            async def __aexit__(_self,*unused):outer.calls.append(('install-exit',));await asyncio.sleep(0)
            async def lookup(_self,query):
                outer.calls.append(('lookup',copy.deepcopy(query)));await asyncio.sleep(0)
                if outer.lookup_hook:await outer.lookup_hook()
                return copy.deepcopy(outer.apps)
        class MounterModel:
            def __init__(_self,rsd):outer.assertIs(rsd,outer.rsd);outer.calls.append(('mounter-create',rsd))
            async def __aenter__(_self):outer.calls.append(('mounter-enter',));return _self
            async def __aexit__(_self,*unused):outer.calls.append(('mounter-exit',));await asyncio.sleep(0)
            async def _send_recv(_self,request):
                outer.calls.append(('image-query',copy.deepcopy(request)));await asyncio.sleep(0)
                return copy.deepcopy(outer.mounter_response)
        ns={'LaunchError':ModelError,'InstallationProxyService':InstallModel,'PersonalizedImageMounter':MounterModel,
            're':re,'json':json,'BUNDLE_ID':re.compile(r'[A-Za-z0-9][A-Za-z0-9-]*(?:\.[A-Za-z0-9][A-Za-z0-9-]*)+')}
        model_class=ast.ClassDef(name=cls.name,bases=[],keywords=[],body=methods,decorator_list=[])
        exec(compile(ast.fix_missing_locations(ast.Module(body=[model_class],type_ignores=[])),'<pinned-original-owner-readonly-source>','exec'),ns)
        self.owner=ns[cls.name]();self.owner.source=SourceModel();self.owner.closed=False;self.owner.session=None;self.owner.instance='a'*32

    async def test_preflight_original_lookup_preserves_observed_fields_and_false_qualification(self):
        result=await self.owner.execute('apps-preflight',self.args,None)
        self.assertEqual(set(result['applications']),set(self.apps))
        self.assertEqual(result['applications']['org.example.overte']['SignerIdentity'],'MODEL-ONLY')
        self.assertNotIn('unconsumed',result['applications']['org.example.overte']['Entitlements'])
        self.assertFalse(result['nativeTouchSupport']);self.assertFalse(result['resourceRetirementEstablished'])
        query=next(row[1] for row in self.calls if row[0]=='lookup')
        self.assertEqual(query['BundleIDs'],['org.example.overte','org.example.wda'])
        self.assertEqual(self.calls[-1],('install-exit',))

    async def test_actual_lookup_await_source_loss_refuses_after_original_service_exit(self):
        async def lose():self.live=False
        self.lookup_hook=lose
        with self.assertRaises(self.error):await self.owner.execute('apps-preflight',self.args,None)
        self.assertEqual(self.calls[-1],('install-exit',));self.assertEqual(sum(row[0]=='lookup' for row in self.calls),1)

    async def test_same_rsd_claim_during_lookup_await_refuses_old_pre_session_result(self):
        async def claim():self.owner.session={'sessionId':'model-claimed'}
        self.lookup_hook=claim
        with self.assertRaises(self.error):await self.owner.execute('apps-preflight',self.args,None)
        self.assertEqual(self.calls[-1],('install-exit',));self.assertEqual(sum(row[0]=='lookup' for row in self.calls),1)

    async def test_discovery_ambiguous_actual_marker_candidates_refuse(self):
        self.args['discoverRemappedBundleIds']=True
        self.apps['org.example.extra']={**self.apps['org.example.overte'],'CFBundleIdentifier':'org.example.extra'}
        with self.assertRaises(self.error):await self.owner.execute('apps-preflight',self.args,None)
        query=next(row[1] for row in self.calls if row[0]=='lookup');self.assertNotIn('BundleIDs',query)

    async def test_ddi_full_original_signature_list_and_two_original_tcp_connections_close(self):
        result=await self.owner.execute('ddi-status',{'imageSha384':self.signature.hex()},None)
        self.assertTrue(result['imageSignatureMatched']);self.assertTrue(result['serviceTcpEndpointsConnected'])
        self.assertFalse(result['serviceProtocolReadinessEstablished']);self.assertFalse(result['nativeTouchSupport'])
        self.assertFalse(result['resourceRetirementEstablished'])
        self.assertEqual(next(row[1] for row in self.calls if row[0]=='image-query'),{'Command':'LookupImage','ImageType':'Personalized'})
        self.assertEqual([row for row in self.calls if row[0] in ('connect','close')],[('connect',1234),('close',1234),('connect',1235),('close',1235)])

    async def test_ddi_wrong_actual_signature_refuses_before_any_tcp_connection(self):
        self.mounter_response['ImageSignature']=[b'x'*48]
        with self.assertRaises(self.error):await self.owner.execute('ddi-status',{'imageSha384':self.signature.hex()},None)
        self.assertFalse(any(row[0]=='connect' for row in self.calls));self.assertEqual(self.calls[-1],('mounter-exit',))

    async def test_ddi_source_loss_while_tcp_connect_returns_still_closes_original_connection(self):
        async def lose():self.live=False
        self.connect_hook=lose
        with self.assertRaises(self.error):await self.owner.execute('ddi-status',{'imageSha384':self.signature.hex()},None)
        self.assertEqual([row for row in self.calls if row[0] in ('connect','close')],[('connect',1234),('close',1234)])

    async def test_pre_session_reads_refuse_claimed_owner_before_sdk_model_creation(self):
        self.owner.session={'sessionId':'already-claimed'}
        for operation,args in [('apps-preflight',self.args),('ddi-status',{'imageSha384':self.signature.hex()})]:
            with self.assertRaises(self.error):await self.owner.execute(operation,args,None)
        self.assertEqual(self.calls,[])
