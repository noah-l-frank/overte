"""Root-only fixed C11 Utility4 window; every original room retained."""
from pathlib import Path
import argparse, hashlib, json, os, runpy, stat, subprocess, sys, traceback
R = Path.cwd().resolve(strict=True)
B = R / '.ios-host-tmp'
FIELDS = ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def census(root):
    assert root.resolve(strict=True) == root and root.is_dir() and not root.is_symlink()
    result = {}
    for path in (root, *sorted(root.rglob('*'))):
        before = path.lstat()
        value = {key: getattr(before, key) for key in FIELDS}
        if stat.S_ISREG(before.st_mode):
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            try:
                assert all(getattr(os.fstat(descriptor), key) == value[key] for key in FIELDS)
                digest = hashlib.sha256()
                while chunk := os.read(descriptor, 1024 * 1024):
                    digest.update(chunk)
                assert all(getattr(os.fstat(descriptor), key) == value[key] for key in FIELDS)
                value['sha256'] = digest.hexdigest()
            finally:
                os.close(descriptor)
        elif stat.S_ISLNK(before.st_mode):
            value['target'] = os.readlink(path)
        else:
            assert stat.S_ISDIR(before.st_mode)
        assert all(getattr(path.lstat(), key) == value[key] for key in FIELDS)
        result[str(path.relative_to(root))] = value
    return result

def main():
    parser = argparse.ArgumentParser()
    for n in ('input', 'context', 'output'): parser.add_argument('--'+n, type=Path, required=True)
    for n in ('input-sha', 'context-sha'): parser.add_argument('--'+n, required=True)
    a = parser.parse_args()
    assert sys.flags.no_site and sys.dont_write_bytecode
    assert R.name == 'overte-ios-feature-adapters-resume-20261026'
    for p in (a.input, a.context):
        assert p.is_absolute() and p.resolve(strict=True) == p and p.is_relative_to(B)
    assert sha(a.input) == a.input_sha and sha(a.context) == a.context_sha
    h = a.input.parent; o = h.with_name(h.name+'-outer'); c = h.with_name(h.name+'-censuses')
    plan = load(a.input); context = load(a.context)
    assert h.parent == B and h.name.startswith('moving-c11-state-own4-prepared-')
    assert a.input == h/'approved-inputs.json' and not o.exists() and not c.exists()
    assert context['allTargetsTerminal'] and context['expectedHead'] == plan['actualPublicHead']
    assert plan['sourceFreeze'] == '9237839b6b5210841b6ab81a262a4e547d84e4670d747cbc60fff5ffbb66b56e'
    assert plan['wallSeconds'] == 30 and plan['killGraceSeconds'] == 5 and len(plan['cases']) == 4
    assert plan['PythonExecutions'] == 5 and plan['maximumLiveUtilityChildren'] == 2
    assert plan['processObservationUtilityRootProof'] is None
    assert plan['NodeExecutions'] == plan['SDKExecutions'] == plan['oldScenarioOriginalInputs'] == 0
    assert not plan['realNetwork'] and not plan['nativeQualified'] and not plan['wholeQualified']
    baseline = Path(context['globalCustody']['baseline']['path'])
    helper_path = Path(context['globalCustody']['helper']['path'])
    assert baseline.parent == helper_path.parent == a.context.parent
    assert sha(baseline) == context['globalCustody']['baseline']['sha256']
    assert sha(helper_path) == context['globalCustody']['helper']['sha256'] == 'bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
    expected = load(baseline); assert len(expected) == 875
    assert set(plan['currentSourceExecution']['requiredOriginalRoots']) <= set(expected)
    assert a.output.is_absolute() and a.output.parent == B and a.output.resolve() == a.output and not a.output.exists()
    a.output.mkdir(mode=0o700)
    def put(name, value):
        p = a.output/name
        with p.open('x') as f: json.dump(value,f,sort_keys=True,separators=(',',':')); f.write('\n')
        p.chmod(0o600)
    helper = runpy.run_path(str(helper_path))
    before = helper['current'](); assert before == expected
    put('global-before.json', before)
    put('attempt-before-target.json', dict(input=str(a.input),inputSha256=a.input_sha,
        attemptedOriginalRooms=list(map(str,(h,o,c,a.output))),ownedAbsenceEstablished=False))
    try:
        with (a.output/'supervisor-stdout.log').open('xb') as stdout, (a.output/'supervisor-stderr.log').open('xb') as stderr:
            result = subprocess.run([sys.executable,'-S','-B',str(h/'supervise-four.py'),a.input_sha],
                cwd=R, env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
        terminal = load(o/'terminal.json'); drain = load(o/'actual-process-drain.json')
        assert terminal['ownProcessesAbsent'] and drain['remaining'] == []
        for row in drain['owned']:
            try: raw = Path('/proc',str(row['pid']),'stat').read_text()
            except (FileNotFoundError, ProcessLookupError): continue
            fields = raw[raw.rfind(')')+2:].split()
            assert int(fields[19]) != row['startTicks'], 'Original process remains; no quiet close'
        qualification = load(c/'qualification.json')
        assert qualification['ownProcessesAbsent'] and qualification['noCensusExclusions']
        assert qualification['originalRoots'] == list(map(str,(h,o,c)))
        first = {str(p):census(p) for p in (h,o,c)}
        second = {str(p):census(p) for p in (h,o,c)}
        assert first == second
        put('whole-output-first.json',first); put('whole-output-second.json',second)
        after1 = helper['current'](); after2 = helper['current']()
        assert after1 == after2 == expected
        put('global-after-first.json',after1); put('global-after-second.json',after2)
        passed = result.returncode == 0 and terminal['status'] == qualification['status'] == 'PASS'
        put('terminal.json',dict(status='ROOT_C11_UTILITY4_CLOSED_PASS' if passed else 'ROOT_C11_UTILITY4_CLOSED_ORIGINAL_FAILURE',
            supervisorReturnCode=result.returncode,originalTerminal=terminal,originalQualification=qualification,
            all875OldOriginalBodiesUnchanged=True,globalCensuses=3,wholeOwnOutputsTwiceEqual=True,
            newOriginalRoots=list(map(str,(h,o,c,a.output))),ownProcessesAbsent=True,
            nativeQualified=False,movingQualified=False,wholeQualified=False))
        put('freeze.json',dict(files={p.name:dict(sha256=sha(p)) for p in sorted(a.output.iterdir()) if p.is_file()}))
        print(json.dumps(dict(status='PASS' if passed else 'FAIL',freeze=sha(a.output/'freeze.json'))),flush=True)
        return 0 if passed else 1
    except BaseException:
        put('unqualified-partial-custody.json',dict(status='NO_QUIET_CLOSE_INFERRED',originalTraceback=traceback.format_exc(),
            attemptedOriginalRooms=list(map(str,(h,o,c,a.output))),postGlobalInventoriesQualified=False))
        raise
if __name__ == '__main__': raise SystemExit(main())
