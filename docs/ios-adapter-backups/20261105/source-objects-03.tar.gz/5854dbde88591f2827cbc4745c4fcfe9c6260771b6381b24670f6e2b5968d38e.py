from pathlib import Path
import ast,hashlib,json,difflib
ROOT=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026')
D=ROOT/'.ios-host-tmp/avatar-primary-control-checkpoint-handoff-draft-20261029'
changes={}
def edit(name,old,new):
    value=changes.get(name,(ROOT/name).read_text())
    assert value.count(old)==1,(name,old[:120],value.count(old))
    changes[name]=value.replace(old,new)
common='tests/device/feature_journeys/avatar_primary_control.py'
ios='tests/device/ios/adapters/avatar_primary_control.py'
changes[common]=(D/'common.py.txt').read_text()
changes[ios]=(D/'ios.py.txt').read_text()
p='tests/device/feature_journeys/server.py'
edit(p,'from feature_journeys.avatar_accounts import AvatarAccountScopes','from feature_journeys.avatar_accounts import AvatarAccountScopes\nfrom feature_journeys.avatar_primary_control import intercept as avatar_primary_control')
edit(p,'            if not reader and not actor and not adapter_reader:\n',"            if avatar_primary_control(self,parts,reader=reader,actor=actor,adapter_reader=adapter_reader):return\n            if not reader and not actor and not adapter_reader:\n")
edit(p,'    server.journal = Journal() if browser_peer_of is None else browser_peer_of.journal','    server.journal = Journal() if browser_peer_of is None else browser_peer_of.journal\n    server.avatar_control_handoffs={}')
p='tests/device/ios/adapters/avatar_configuration.py'
edit(p,'from copy import deepcopy','from copy import deepcopy\nfrom pathlib import Path')
edit(p,"    fields={'artifactRoot','imagePolicy',peer};exact(value,fields|({'authorityRead'} if 'authorityRead' in value else set()))", "    fields={'artifactRoot','imagePolicy',peer};exact(value,fields|set(value).intersection({'authorityRead','authorityControlRoot'}))\n    if 'authorityControlRoot' in value:\n        root=value['authorityControlRoot'];need(role=='primary' and type(root) is str and root and Path(root).is_absolute())")
p='tests/device/ios/adapters/avatar_feature.py'
edit(p,'from ios.adapters.avatar_configuration import authority_client,settings','from ios.adapters.avatar_configuration import authority_client,settings\nfrom ios.adapters.avatar_primary_control import load as primary_control,checkpoint_order\nfrom adapters.feature_fixture_access import AdapterFixtureClient')
edit(p,'        config=settings(configuration,role=role,target=selector)\n',"        config=settings(configuration,role=role,target=selector)\n        self.primary_control=primary_control(client,self.run,role,config)\n        need(role!='primary' or not isinstance(client,AdapterFixtureClient) or self.primary_control is not None)\n")
edit(p,'    def initialize(self):\n        self.load();phase=self.phase.read();actual=self.actual()',"    def initialize(self):\n        if self.primary_control is not None:self.primary_control.admit()\n        self.load();phase=self.phase.read();actual=self.actual()")
edit(p,"        self.client.request('/runs/'+self.run+'/avatar/sessions',inputs,method='POST')","        (self.primary_control or self.client).request('/runs/'+self.run+'/avatar/sessions',inputs,method='POST')")
edit(p,"                    self.client.request('/runs/'+self.run+'/avatar/control',dict(operation='revoke'),method='POST')","                    (self.primary_control or self.client).request('/runs/'+self.run+'/avatar/control',dict(operation='revoke'),method='POST')")
edit(p,"        preparing=self.preparation_cleanup_requested()", "        if self.primary_control is not None:\n            with self.held():\n                self.load();terminal=self.state is not None and self.state['phase'] in ('terminal-ready','cleaned')\n            if not terminal:self.primary_control.admit()\n        preparing=self.preparation_cleanup_requested()")
edit(p,'        checker=object.__new__(PhaseWitnessPublisher);checker.run,checker.area=self.run,\'avatar-people\'\n',"        if self.primary_control is not None:\n            for _ in range(251):\n                try:return checkpoint_order(self)\n                except AvatarFeaturePending:self.sleep(.1)\n            raise AvatarFeaturePending('Independent cleanup checkpoint original has not been committed')\n        checker=object.__new__(PhaseWitnessPublisher);checker.run,checker.area=self.run,'avatar-people'\n")
p='tests/device/modules/feature_journey.py'
edit(p,'    try:\n        prepare(session, args.area)',"    try:\n        # Explicit runner-owned authority, kept separate from the adapter's\n        # GET-only client and the independent actor publisher credential.\n        control_root=os.environ.get('OVERTE_E2E_AVATAR_PRIMARY_CONTROL_HANDOFF_ROOT')\n        if args.area=='avatar-people' and control_root is not None:\n            from adapters.normal_feature_state import PrivateFeatureState\n            from feature_journeys.avatar_primary_control import prepare as prepare_control\n            root=Path(control_root)\n            if not root.is_absolute():raise ValueError('Avatar control root must be absolute')\n            prepare_control(client,PrivateFeatureState(root/('avatar-primary-control-'+run+'.json')),run)\n        prepare(session, args.area)")
changes['tests/device/ios/self_tests/test_ios_avatar_primary_control_http.py']=(D/'test_http.py.txt').read_text()
changes['tests/device/ios/self_tests/test_ios_avatar_primary_control_owner.py']=(D/'test_owner.py.txt').read_text()
rows=[];diff=[]
for name,value in changes.items():
    ast.parse(value);target=D/'candidate'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(value)
    base=(ROOT/name).read_bytes() if (ROOT/name).exists() else None
    rows.append(dict(path=name,baseSha256=None if base is None else hashlib.sha256(base).hexdigest(),candidateSha256=hashlib.sha256(value.encode()).hexdigest()))
    diff.extend(difflib.unified_diff([] if base is None else base.decode().splitlines(True),value.splitlines(True),fromfile='/dev/null' if base is None else 'a/'+name,tofile='b/'+name))
(D/'source.diff').write_text(''.join(diff));(D/'source-manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print('AST only:',len(rows),'source candidates')
