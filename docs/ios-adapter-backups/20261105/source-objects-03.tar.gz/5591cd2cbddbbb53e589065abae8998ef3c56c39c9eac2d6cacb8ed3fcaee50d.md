# Current unqualified QueueObservation1 source checkpoint

LATEST UPDATE: Root approved the unknown-Source1-parent guard, and it is now
implemented atomically in the repository snapshot under its mutex. It returns
unavailable until source1Instance is known from an actual Dispatch. The existing
gate model was sharpened (same7 test methods), docs updated, AST counted12 total.
Renewed Sourcefreeze has been sent to Root. NO tests/imports/compiler executed
yet. Private initial draft copies predate this final repository-only guard;
do not overwrite the current repository files from that old preparation script.
The historical pending-guard paragraph below is superseded by this update.

NEWEST TEST/QUEUE UPDATE: Root subsequently granted exactly12 models plus the
private source projection. They are TERMINAL PASS12/0.008s, projection EXIT0.
Actual9 used sources had identical stat/SHA before/after. Log:
.ios-host-tmp/assets-image-reader-queue-twelve-first-20261027.log; before/after
JSON alongside it. Model-only, no native/performance/whole claim. Product
TextureCache.cpp is byte-identical to b906 after removing new dedicated blocks;
old Source1 header C++ tokens unchanged; CMake only conditional appendix.
No Common or commit yet. Root's next queue is Avatar6 reader cases/fixed120;
KEEP ALL8 OWN SOURCE/DOC PATHS UNCHANGED until its actual terminal. Root promised
Assets the next doc-qualification/Common/versions/diff/exact8-commit window.
Only then replace the current document's prepared/unrun wording with exact
12-model/source-only qualification. No getters/codec/registry/native authority.

Parent Root authorized the next native source phase after b90666ae7c. Exact
eight repository WIP paths now exist, all owned by Assets:

* libraries/material-networking/CMakeLists.txt
* libraries/material-networking/src/material-networking/IOSAssetsImageReaderQueueObservation.h
* libraries/material-networking/src/material-networking/IOSAssetsImageReaderQueueObservation.cpp
* libraries/material-networking/src/material-networking/TextureCache.cpp
* tests/device/native/IOSAssetsImageReaderObservation.h
* tests/device/ios/self_tests/test_ios_assets_image_reader_queue_teardown.py
* tests/device/ios/self_tests/test_ios_assets_image_reader_queue_boundary.py
* tests/device/ios/ASSETS_IMAGE_READER_QUEUE_BOUNDARY.md

No own files staged, no current own process, no tests run. Only AST parsing of
the two Python files plus diff whitespace inspection occurred. Native C++ is
uncompiled/unexecuted. Existing Source1/History5 wire, registry, getter/Probe,
host codec and completed-source count5/14 remain unchanged. Other Photo/Avatar
WIP must remain untouched. Private preparation artifacts and original SHA pins
are in .ios-host-tmp/assets-queue-bridge-draft-20261027.

Root has been sent the exact8 path list, Sourcefreeze and planned12 pure model
cases. Wait for Root's shared freeze before ANY test. Other agents currently
work in disjoint source packets; prior Photos cProfile180 was terminal124 and
AvatarActorProfiler terminal0/13.942. Do not infer new slot permission from time.

Prepared selection is exactly5 tests in
test_ios_assets_image_reader_queue_teardown and7 in
test_ios_assets_image_reader_queue_boundary. First exercises real Python
threads/barriers/weak-State ownership: running callback, mutex waiter, late
callback, forbidden caller-held mutex, snapshot/disarm race. Second declares
missing API/marker/runtime, real opaque event identity vs equal payload,
foreign target/method/resource/owner, delivery/destruction before invoke return,
cancel without delivery, nested unobserved+duplicate, cap+weak resurrection.
These cannot prove the C++ atomic shared_ptr ABI, Qt hooks or native lifetime.
All native/SDK/device/whole/storage/GPU qualification remains false.

Teardown design: publication is atomic shared_ptr<State> via a tiny process-long
heap slot. Each callback/snapshot takes its own strong diagnostic State pin
before waiting for State mutex. State product references are weak only. Disarm
sets process-long failure, atomically clears publication, then Qt-disables
outside all Source1/Bridge locks, with NO waiting drain. Existing callback pins
keep State alive until last return; late callbacks see null. Last State release
is outside its mutex. AboutToQuit and QObject::destroyed hooks capture no State
or product owner. All Qt APIs occur before/after registry mutex scopes. Source1
context copies actual existing IDs and releases its own mutex before Bridge.

Runtime/compile gates: iOS + feature + dedicated test config + actual --testScript
+ exactQt6.11.1 + optional QtCorePrivate marker/API1. Unknown/missing API is
unavailable and cannot alter Source1 wire. Existing setup_hifi_library recursively
globs src/*.cpp (cmake/macros/SetupHifiLibrary.cmake:16), source-read only.

ONE pending readonly review edge was sent to Root AFTER Sourcefreeze: before
the first actual Dispatch context, owner->source1Instance is empty while the
internal snapshot currently sets complete from admission. No getter/reader
exposes it yet, but source snapshot should return unavailable until actual
Source1 parent is known. Root was asked not to start Common and permit one
atomic guard before tests, then immediately renew freeze. DO NOT silently edit
while other agents may already run common checks. Native fix would be a single
check inside snapshot's locked block before emitting a record. No schema change.

Current packet has no actual argument-destruction result. Qt phases retain UTC
and steady-nanosecond originals separate from Bridge UTC/elapsed-ms. Callback
delivery/destruction can finish before the producer invokeMethod returns; do
not impose a false sequential chronology. Cancel does not invent a receiver.
Argument values destroyed never means event/base allocation, arbitrary bytes,
KTX, pools, decoder, GPU, full Resource or Actor/backend/source/process/SDK end.
