"""Root-only export of an ACTUAL full frozen ledger; no original-tree census.

No source imports, root discovery, target, process, network, clock or Git action.
A current authoritative full bundle is mandatory: a partial terminalAdditions
list cannot be expanded into missing historical authority by this exporter.
"""
from pathlib import Path
import argparse,hashlib,json,os,stat,sys
REPO=Path(__file__).resolve(strict=True).parents[2]
SOURCE=Path(__file__).resolve(strict=True).parent
PRIVATE=REPO/'.ios-host-tmp'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
LEDGER_KEYS={'baseRootCount','expectedAdditionalBaseline','expectedRootCount','globalScans','noWriterExclusions','results','status','targets'}
ROW_KEYS={'freezeSha256','newOriginalRoots','path','roots','status','terminalJustification'}
LEDGER_STATUS='ROOT_TWICE_READ_CURRENT_COMPLETE_TERMINAL_ROOMS_ALL_ORIGINAL_RECEIPT_HASHES_MATCH_NO_GLOBAL_SCAN'
PROBES={
 'c5d96a6606276955270560fbf1ad102ab09dc751c33843f480ed120d0a62d4e5':('root-chat-fileless-stdlib-xml-probe-source1-20261104','50533ff3df1b344e86f0fbe4a50e6f2f48f7461400deff0a6aff7a8a44428d14','PURE_STDLIB_PROBE_EXIT0_NO_PRODUCT_OR_CHILD_LAUNCH_CODE'),
 '009034cca145412004d81e8ac65be747528d420c91815a703fe47c664ed13fb9':('root-chat-fileless-stdlib-expat-wrapper-probe-source2-20261104','d9759d748cbf51c41fd651dd00afa7f59c1cad65b96c150091ebb6cc9669624f','PURE_STDLIB_EXPAT_WRAPPER_PROBE_EXIT0_ACTUAL_SAME_ORIGINAL_CHILD_ALIASES')}

def digest(raw):return hashlib.sha256(raw).hexdigest()
def hex64(value):return type(value)is str and len(value)==64 and all(c in'0123456789abcdef'for c in value)
def private(path):
    path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_relative_to(PRIVATE)
    return path

def read(path,expected,held):
    assert hex64(expected);path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
    before=path.lstat();assert stat.S_ISREG(before.st_mode)
    identity=tuple(getattr(before,key)for key in FIELDS)
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        assert tuple(getattr(os.fstat(fd),key)for key in FIELDS)==identity
        chunks=[]
        while block:=os.read(fd,1024*1024):chunks.append(block)
        raw=b''.join(chunks)
        assert tuple(getattr(os.fstat(fd),key)for key in FIELDS)==identity
    finally:os.close(fd)
    assert tuple(getattr(path.lstat(),key)for key in FIELDS)==identity and len(raw)==before.st_size and digest(raw)==expected
    row=dict(identity=list(identity),sha256=expected)
    if str(path)in held:assert held[str(path)]==row
    else:held[str(path)]=row
    return raw

def member_digest(row):
    result=row if type(row)is str else row['sha256'];assert hex64(result);return result

def packet(folder,expected,held):
    folder=private(folder);value=json.loads(read(folder/'freeze.json',expected,held));assert type(value['files'])is dict
    for name,row in value['files'].items():
        assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
        raw=read(private(folder/name),member_digest(row),held)
        if type(row)is dict and 'bytes'in row:assert row['bytes']==len(raw)
    return value

def reference(row,held):
    assert type(row)is dict and set(row)=={'path','sha256'}
    path=private(row['path']);return path,read(path,row['sha256'],held)

def base665(held):
    base=PRIVATE/'root-terminal660-original-root-context-20261104/terminal-context.json'
    wrapper=PRIVATE/'root-terminal665-original-root-context-20261104/terminal-context.json'
    b=json.loads(read(base,'5bbdc7d787d18c7d5d2e5d456b2c9049b3054730ab952b8d8335822a10a42eac',held))
    w=json.loads(read(wrapper,'e45709c6feece4d2e0f4e70622610572baf8efa9ff47c1016bbabd09603a9837',held))
    assert w['baseContext']==dict(path=str(base),sha256='5bbdc7d787d18c7d5d2e5d456b2c9049b3054730ab952b8d8335822a10a42eac')
    for value,count in((b,660),(w,665)):
        assert value['status']=='ROOT_TERMINAL_CONTEXT_NO_TARGET_NO_GLOBAL_SCAN'and value['noWriterExclusions']is True
        assert value['targets']==value['globalScans']==0 and len(value['roots'])==len(set(value['roots']))==count
    path,raw=reference(b['base653Baseline'],held);assert path==PRIVATE/'audio-normal-mute-prefix-controller3-final-preparation-20261104/global-original-corpus-baseline.json'
    assert digest(raw)=='1e89fcf8ce75273e569fb83b2c865251bd6f2b35b4377aa30a7c570a0fa08cff'
    old=json.loads(raw);assert len(old)==653
    extra=PRIVATE/'root-chat-own17-original-extra12-baselines-20261104'
    f=packet(extra,'3e518b2df56a7fa6d3cba8e31a8e39baec0ad47000b5e8b3aaabc47be7d5fe32',held)
    additional=json.loads(read(extra/'expected-additional-originals.json',member_digest(f['files']['expected-additional-originals.json']),held))
    assert len(additional)==12 and set(old).isdisjoint(additional)
    combined=dict(old);combined.update(additional);assert len(combined)==665 and set(combined)==set(w['roots'])
    assert set(b['roots'])==set(old)|set(b['additionalOriginalRoots'])
    assert set(w['roots'])==set(b['roots'])|set(w['additionalOriginalRoots'])
    return combined

def flat_bodies(value):
    assert type(value)is dict and value
    for root,body in value.items():
        private(root);assert type(body)is dict and '.'in body
        for name,row in body.items():
            assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
            assert type(row)is dict and all(type(row.get(key))is int for key in FIELDS)
            mode=row['st_mode'];extra={'sha256'}if stat.S_ISREG(mode)else{'target'}if stat.S_ISLNK(mode)else set()
            assert stat.S_ISREG(mode)or stat.S_ISDIR(mode)or stat.S_ISLNK(mode)
            assert set(row)==set(FIELDS)|extra
            if 'sha256'in extra:assert hex64(row['sha256'])
            if 'target'in extra:assert type(row['target'])is str

def original_result(row,held):
    folder=private(row['path']);f=packet(folder,row['freezeSha256'],held)
    probe=PROBES.get(row['freezeSha256']);leaf='results.json'
    if probe is not None:
        name,expected,status=probe;assert folder==PRIVATE/name and row['status']==status
        leaf='terminal.json';assert member_digest(f['files'][leaf])==expected
    value=json.loads(read(folder/leaf,member_digest(f['files'][leaf]),held))
    assert value['status']==row['status']and value['newOriginalRoots']==row['newOriginalRoots']
    terminal=value['terminal'];assert type(terminal)is dict and terminal['ownProcessesAbsent']is True
    # Keep ORIGINAL return codes, failure/timeout/rescue/problem fields literal.
    # No status or success is derived from expected cases or exit-code guesses.
    assert type(terminal['childReturnCode'])is int
    if probe is not None:
        assert value['noGlobalCensus']is value['noProductImports']is value['noTargets']is True
        assert terminal==dict(childReturnCode=0,ownProcessesAbsent=True)
    else:
        assert 'actual-receipt-references.json'in f['files']
        refs=json.loads(read(folder/'actual-receipt-references.json',member_digest(f['files']['actual-receipt-references.json']),held))
        assert type(refs)is dict and refs
        for item in refs.values():
            assert type(item)is dict and type(item['path'])is str and hex64(item['sha256'])
            raw=read(Path(item['path']),item['sha256'],held)
            if 'bytes'in item:assert item['bytes']==len(raw)
    for key in('noWriterExclusions',):
        if key in value:assert value[key]is True
    for key in('writerExclusions','fullOwnCensusExclusions'):
        if key in value:assert value[key]==[]
    return dict(path=str(folder),freezeSha256=row['freezeSha256'],originalResultLeaf=leaf,
        originalResultSha256=member_digest(f['files'][leaf]),originalStatus=value['status'],
        originalTerminal=terminal,originalNewRoots=value['newOriginalRoots'])

def put(folder,name,raw):
    path=folder/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    try:
        assert stat.S_IMODE(os.fstat(fd).st_mode)==0o600
        with os.fdopen(fd,'wb',closefd=False)as stream:stream.write(raw);stream.flush();os.fsync(fd)
    finally:os.close(fd)
    return dict(sha256=digest(path.read_bytes()),bytes=len(raw))
def encode(value):return(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()

def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','full-bundle','full-bundle-freeze','root-context','root-context-sha','root-context-freeze','expected-head','expected-roots','destination'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--root-authorized-quiet-metadata',action='store_true',required=True);args=parser.parse_args()
    assert Path.cwd()==REPO and sys.flags.no_site==1 and sys.dont_write_bytecode
    assert len(args.expected_head)==40 and all(c in'0123456789abcdef'for c in args.expected_head)
    held={};source=json.loads(read(SOURCE/'source-freeze.json',args.source_freeze,held))
    for name,row in source['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        read(SOURCE/name,member_digest(row),held)
    bundle=private(args.full_bundle);manifest=packet(bundle,args.full_bundle_freeze,held)
    ledger_raw=read(bundle/'terminal-results.json',member_digest(manifest['files']['terminal-results.json']),held);ledger=json.loads(ledger_raw)
    assert set(ledger)==LEDGER_KEYS and ledger['status']==LEDGER_STATUS
    assert type(ledger['baseRootCount'])is int and ledger['baseRootCount']==665 and type(ledger['globalScans'])is type(ledger['targets'])is int and ledger['globalScans']==ledger['targets']==0 and ledger['noWriterExclusions']is True
    baseline,baseline_raw=reference(ledger['expectedAdditionalBaseline'],held)
    assert baseline.parent==bundle and baseline.name=='expected-additional-originals.json'
    assert member_digest(manifest['files'][baseline.name])==digest(baseline_raw)
    additional=json.loads(baseline_raw);flat_bodies(additional);base=base665(held);flat_bodies(base)
    assert set(base).isdisjoint(additional)
    declared=set();packets={};facts=[];assert type(ledger['results'])is list and ledger['results']
    for row in ledger['results']:
        assert type(row)is dict and set(row)==ROW_KEYS and hex64(row['freezeSha256'])
        assert type(row['path'])is type(row['status'])is str and row['status']
        assert row['roots']==row['newOriginalRoots']and type(row['roots'])is list and row['roots']and len(row['roots'])==len(set(row['roots']))
        assert all(type(root)is str for root in row['roots'])
        assert declared.isdisjoint(row['roots'])and type(row['terminalJustification'])is str and row['terminalJustification'].strip()
        declared.update(row['roots']);assert row['path']not in packets;packets[row['path']]=row
        facts.append(original_result(row,held))
    assert declared==set(additional)and ledger['expectedRootCount']==len(base)+len(additional)==int(args.expected_roots)
    context_path=private(args.root_context);assert context_path.name=='root-context.json'
    cm=packet(context_path.parent,args.root_context_freeze,held)
    assert member_digest(cm['files'][context_path.name])==args.root_context_sha
    context=json.loads(read(context_path,args.root_context_sha,held))
    assert context['status']=='ROOT_REVIEWED_QUIET_CURRENT_SOURCE_AND_ORIGINAL_CONTEXT'and context['allTargetsTerminal']is True and context['expectedHead']==args.expected_head
    scope=json.loads(read(context_path.with_name('ROOT-SCOPE.json'),member_digest(cm['files']['ROOT-SCOPE.json']),held))
    assert scope['allTargetsTerminal']is scope['noWriterExclusions']is True and type(scope['globalScans'])is type(scope['targets'])is int and scope['globalScans']==scope['targets']==0
    assert scope['sourceHead']==args.expected_head and scope['literalCurrentBaselineRoots']==ledger['expectedRootCount']
    assert set(context['globalCustody'])=={'baseline','seed','helper'}
    helper_path,helper_raw=reference(context['globalCustody']['helper'],held)
    assert digest(helper_raw)=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
    full_path,raw=reference(context['globalCustody']['baseline'],held);full=json.loads(raw);flat_bodies(full)
    seed_path,raw=reference(context['globalCustody']['seed'],held);seed=json.loads(raw)
    assert type(seed['roots'])is list and len(seed['roots'])==len(set(seed['roots']))and set(seed['roots'])==set(full)
    combined=dict(base);combined.update(additional);assert combined==full
    assert type(context['terminalAdditions'])is list and len({spec['packet']for spec in context['terminalAdditions']})==len(context['terminalAdditions'])
    for spec in context['terminalAdditions']:
        assert set(spec)=={'packet','freezeFile','freezeSha256','roots'}and spec['freezeFile']=='freeze.json'
        assert spec['packet']in packets;row=packets[spec['packet']]
        assert row['freezeSha256']==spec['freezeSha256']and row['roots']==spec['roots']
    # The authoritative context explicitly pins this COMPLETE bundle, not only
    # its recent addition list. Unknown or stale pairings remain unavailable.
    authorities={item['path']:item['sha256']for item in context['additionalPhysicalProofs']}
    for leaf in('freeze.json','terminal-results.json','expected-additional-originals.json'):
        assert authorities.get(str(bundle/leaf))==held[str(bundle/leaf)]['sha256']
    for path,row in tuple(held.items()):read(Path(path),row['sha256'],held)
    dest=Path(args.destination);assert dest.is_absolute()and dest.parent==PRIVATE and dest.parent.resolve(strict=True)==PRIVATE and not dest.exists()
    dest.mkdir(mode=0o700);assert stat.S_IMODE(dest.stat().st_mode)==0o700
    files={};files['expected-additional-originals.json']=put(dest,'expected-additional-originals.json',baseline_raw)
    exported=dict(ledger,expectedAdditionalBaseline=dict(path=str(dest/'expected-additional-originals.json'),sha256=digest(baseline_raw)))
    assert exported['results']==ledger['results']and set(exported)==LEDGER_KEYS
    files['terminal-results.json']=put(dest,'terminal-results.json',encode(exported))
    files['EXPORT-READBACK.json']=put(dest,'EXPORT-READBACK.json',encode(dict(
        status='EXACT_FROZEN_FULL_LEDGER_EXPORT_NO_NEW_ORIGINAL_CENSUS',baseRootCount=665,totalRoots=len(full),
        originalPacketCount=len(facts),literalOriginalFacts=facts,baselineBytesExact=True,allResultsRowsExact=True,
        onlyLedgerMetadataReferenceRebased=True,actualRootContext=dict(path=str(context_path),sha256=args.root_context_sha),
        actualInputFullBundle=dict(path=str(bundle/'freeze.json'),sha256=args.full_bundle_freeze),
        namedInputFiles=held,sourceImports=0,targets=0,originalCensuses=0,globalScans=0,publicWrites=0,GitOperations=0,
        independentCurrentQuietProofCreated=False,featureQualified=False,nativeQualified=False,wholeQualified=False)))
    for path,row in tuple(held.items()):read(Path(path),row['sha256'],held)
    freeze=put(dest,'freeze.json',encode(dict(files=files)))
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_EXPORTED_NOT_TARGET_ADMISSION',freeze=dict(path=str(dest/'freeze.json'),sha256=freeze['sha256']),terminalResults=dict(path=str(dest/'terminal-results.json'),sha256=files['terminal-results.json']['sha256']),rootCount=len(full))))
if __name__=='__main__':main()
