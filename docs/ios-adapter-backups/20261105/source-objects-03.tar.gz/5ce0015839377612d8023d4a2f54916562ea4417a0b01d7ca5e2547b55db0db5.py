"""First-phase prerequisite deliberately closed until Root supplies actual proof.

This controller contains no guessed PASS/schema or model-derived qualification.
A new immutable successor must implement the exact original Root proof join.
"""
FIRST_PHASE_ROOT_PROOF_SCHEMA = None
FIRST_PHASE_SELECTOR = 'ios.self_tests.test_ios_assets_picker_reserved_intents.AssetsReservedPickerIntentTests.test_actual_phase_advance_during_planned_intent_rejects_before_wal_progress_or_another_ui_input'
REMAINING_CASES = {'actor': 'ios.self_tests.test_ios_assets_picker_reserved_intents.AssetsReservedPickerIntentTests.test_actual_foreign_actor_binding_during_planned_intent_cannot_rebind_primary_original_context', 'inode': 'ios.self_tests.test_ios_assets_picker_reserved_intents.AssetsReservedPickerIntentTests.test_actual_samebytes_old_capture_inode_replacement_blocks_intermediate_wal_progress', 'orphan': 'ios.self_tests.test_ios_assets_picker_reserved_intents.AssetsReservedPickerIntentTests.test_actual_unadmitted_zero_byte_original_between_intents_blocks_wal_progress_and_stays_owned', 'savedCAS': 'ios.self_tests.test_ios_assets_picker_reserved_intents.AssetsReservedPickerIntentTests.test_actual_saved_original_final_cas_failure_retains_fault_wal_and_recovers_without_native_repeat', 'parser': 'ios.self_tests.test_ios_assets_picker_reserved_intents.AssetsReservedPickerIntentTests.test_actual_same_global_dictionary_parser_value_change_is_detected_during_typed_original_write', 'gate': 'ios.self_tests.test_ios_assets_picker_reserved_intents.AssetsReservedPickerIntentTests.test_actual_gate_closure_cell_contents_replacement_is_rejected_and_original_restoration_remains_typed'}

def require_first_phase(value):
    assert FIRST_PHASE_ROOT_PROOF_SCHEMA is not None, ('Remaining six admission closed: genuine qualified Root first-phase proof/schema is not yet available')
    raise AssertionError('A separately reviewed frozen successor must bind the actual complete first-phase proof; no admission from CLI or a PASS string')

def selection(kind):
    assert type(kind) is str and kind in REMAINING_CASES
    return {kind: dict(id=REMAINING_CASES[kind])}
