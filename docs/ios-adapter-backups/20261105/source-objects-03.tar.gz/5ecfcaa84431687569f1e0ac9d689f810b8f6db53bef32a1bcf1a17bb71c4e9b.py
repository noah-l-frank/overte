from pathlib import Path
import ast,hashlib,json,difflib
r=Path.cwd().resolve();assert r.name=='overte-ios-feature-adapters-resume-20261026'and(r/'.git').is_file();p=r/'.ios-host-tmp/audio-original-keeper-profile-route-closed-utility6-bootstrap2-genuine-class-cleanup-current-actor-code-preparation-20261104';assert p.resolve().is_relative_to(r)
b=p.with_name('audio-original-keeper-profile-route-closed-utility6-bootstrap1-code-preparation-20261104');c=p.with_name('c24-diagnostic-source3-closed-utility14-bootstrap2-genuine-class-cleanup-code-preparation-20261104')
route=p.with_name('audio-original-keeper-cli-profile-adapter-source2-exact-interface-inventory-private-20261104');stage=p.with_name('audio-normal14-original-handoff-integration-staging1-private-20261104');copy=p.with_name('root-snapshot-actor25-public-copy32-provenance-20261104')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,v):
 f=p/n;assert f.resolve().is_relative_to(r)and not f.exists();f.write_text(v)
def dump(v):return json.dumps(v,indent=2,sort_keys=True)+'\n'
assert sha(b/'source-freeze.json')=='26925ebf810ba29df2daf4554375fd9fd1ed8bdeeffaeae62f48c0397e0454e3'
assert sha(c/'source-freeze.json')=='119d34ed5aa8c246dd880992bcbc3c3a9d154de508d2276d7503395c5b76df3d'
assert sha(copy/'freeze.json')=='6174308eae5013a25c1edf70840e8d944639c82e6ae723ea23d22855d9ba80d3'
assert(p/'class_cleanup_custody.py').read_bytes()==(c/'class_cleanup_custody.py').read_bytes()
for n in('metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','source_execution_readiness.py','readonly-shared-stdlib-sources.json','third-party-source-declarations.json','exact-six-selectors.json'):assert(p/n).read_bytes()==(b/n).read_bytes()
py={f.name:sha(f)for f in p.glob('*.py')};assert len(py)==9
for f in p.glob('*.py'):ast.parse(f.read_text(),filename=str(f))
closure=json.loads((p/'PROJECT-DEFINING-ORIGINS.json').read_text());oldclosure=json.loads((b/'PROJECT-DEFINING-ORIGINS.json').read_text());assert len(closure['modules'])==43
changed={n for n,row in closure['modules'].items()if n in oldclosure['modules']and row['sha256']!=oldclosure['modules'][n]['sha256']}
added=set(closure['modules'])-set(oldclosure['modules']);assert changed=={'feature_journeys.server','feature_journeys.witness'}
assert added=={'feature_journeys.snapshot_actor_pixel_samples','feature_journeys.snapshot_scene_samples'}
refs={}
for name,row in closure['modules'].items():
 path=Path(row['path']);assert path.resolve(strict=True)==path and sha(path)==row['sha256'];refs[str(path)]=sha(path);ast.parse(path.read_text())
for folder in(b,c,route,stage,copy):
 f=folder/'source-freeze.json'if folder!=copy else folder/'freeze.json';refs[str(f)]=sha(f)
 for name,row in json.loads(f.read_text())['files'].items():
  actual=folder/name;expected=row if type(row)is str else row['sha256'];assert sha(actual)==expected;refs[str(actual)]=sha(actual)
actual_copy=json.loads((copy/'copy.json').read_text());assert len(actual_copy['rows'])==32
for row in actual_copy['rows']:
 path=r/row['path'];assert str(path)==row['actualPublicPath']and sha(path)==row['actualPublicSha256']==row['candidateSha256'];refs[str(path)]=sha(path)
 if row['kind']=='implementation':assert row['sourceSha256']==row['actualPublicSha256']
 else:assert row['kind']in('metadata','documentation')and row['sourceSha256']is None
for row in json.loads((stage/'STAGING-MANIFEST.json').read_text())['rows']:assert sha(stage/'candidate'/row['path'])==row['sha256']
ids=json.loads((p/'exact-six-selectors.json').read_text())['caseIds'];assert len(ids)==len(set(ids))==6
for name in('prepare.py','run-six.py','supervise-six.py','PROJECT-DEFINING-ORIGINS.json'):
 put(name+'.b1-to-b2.patch',''.join(difflib.unified_diff((b/name).read_text().splitlines(True),(p/name).read_text().splitlines(True),fromfile='Audio6B1/'+name,tofile='Audio6B2/'+name)))
for name in('run-six.py','supervise-six.py'):
 text=(p/name).read_text();assert 'actual-class-cleanup-calls.json'in text and 'actual-class-cleanup-restoration.json'in text and 'allSevenActualRuntimeOriginsEstablished'in text
assert 'subjectOriginCount=7'in(p/'prepare.py').read_text()
put('SOURCE-REFERENCES.json',dump(refs))
put('STATIC-READBACK.json',dump(dict(status='AUTHOR_CRITICAL_SOURCE_ONLY_UNRUN',ninePythonASTs=py,oldSixBodiesAndSelectorDictExact=True,old107StagedBytesPreserved=True,oldFourRouteCandidatesExact=True,classCleanupHelperByteExactC24B2=sha(p/'class_cleanup_custody.py'),actualStdlibCaller='_tearDownPreviousClass',onlyGenuineEmptyClassMetadataDeltaMayAdvanceExpectedTable=True,expectedActualClassCleanupGroups=1,requiredRuntimeOrigins=7,currentDefiningModules=43,currentChangedPublicDefinitionNames=sorted(changed),newExplicitLazySampleFamilyDefinitions=sorted(added),newSampleFamiliesSelectedOrQualified=False,RootActorCopy617Literal32SourceJoins=True,source1OldPublicDefinitionsRemainHistorical=True,sourceImports=0,builders=0,targets=0,maps=0,censuses=0,utilityQualification=None,audioEndAdmission=None)))
put('source-freeze.json',dump(dict(schemaVersion=1,status='FROZEN_SOURCE_ONLY_AUDIO6_B2_GENUINE_CLASS_CLEANUP_CURRENT_ACTOR_BYTES_UNRUN',files={f.name:sha(f)for f in sorted(p.iterdir())},predecessorFreeze=sha(b/'source-freeze.json'),sharedClassCleanupSourceFreeze=sha(c/'source-freeze.json'),sharedClassCleanupHelperSha256=sha(p/'class_cleanup_custody.py'),currentActorCopyProvenanceFreeze=sha(copy/'freeze.json'),routeSourceFreeze=sha(route/'source-freeze.json'),utilityQualification=None,audioEndAdmission=None,fullAudioQualified=False,nativeQualified=False,imports=0,builders=0,maps=0,targets=0,censuses=0)))
print(p/'source-freeze.json');print(sha(p/'source-freeze.json'));print('members',len(json.loads((p/'source-freeze.json').read_text())['files']),'ASTs',len(py),'refs',len(refs))
