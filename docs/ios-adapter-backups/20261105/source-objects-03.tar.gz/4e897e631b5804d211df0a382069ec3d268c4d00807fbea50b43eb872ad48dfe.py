"""Root metadata step AFTER exact2 publication; no target imports/resolver/tests."""
import sys
from run_metadata import HERE,REPO,pin,publication,registry_original,save,sources,validate_frozen
plan=validate_frozen();publication()
assert len(sys.argv)==2 and sys.argv[1] in plan['suites']
kind=sys.argv[1];ready=HERE/(kind+'-publication-ready-source-map.json')
assert not ready.exists(),'Do not silently replace an approved actual map'
root=REPO.stat();before=sources(plan);registry=registry_original();after=sources(plan)
assert before==after,'Source/launcher/registry changed while preparing actual map'
save(ready,dict(status='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA',worktreeRoot=str(REPO),
    rootIdentity=dict(st_dev=root.st_dev,st_ino=root.st_ino),broadSourceRoots=plan['broadSourceRoots'],
    sourcePins=before,registry=registry))
print('ACTUAL_SOURCE_LAUNCHER_PINS',len(before),flush=True)
