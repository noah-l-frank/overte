"""Actual existing RPC query/read/retained worker; SDK/native/HID are models."""
import asyncio,json
from copy import deepcopy
from unittest.mock import patch
import test_native_motion_existing_rpc_models as rpc_fixture


class NativePassiveScopeModels(rpc_fixture.NativeMotionExistingRPCModels):
    async def open_motion(self):
        args=await self.prepare_rpc();packet,_=await self.rpc_begin(args);self.assertEqual('complete',packet['status'])
        return self.ops.touch
    def passive_args(self,action):return dict(self.acquire_args(),action=action,nativePassiveReadVersion=1)
    async def passive_rpc(self,operation,args):
        # ACTUAL run_original_owner issued-row/create_task/retention statements
        # from the existing fixture. This RPC Task completes before its caller
        # can request final Source drain; unittest Task is never an SDK owner.
        request,task=self.request(operation,args);self.controls_motion.append(task)
        self.assertIsNot(task,asyncio.current_task());await task
        row=self.ops.issued[request];self.assertIs(row['task'],task)
        self.assertTrue(task.done());self.assertFalse(task.cancelled());self.assertIsNone(task.exception())
        packet=row['original']
        if packet['status']!='complete':raise RuntimeError('Actual original keeper RPC refused passive request')
        return packet['result']
    async def issue(self,action):
        value=await self.passive_rpc('touch-native-query',self.passive_args(action))
        self.assertEqual(4,value['originalKeeperNativeQueryVersion']);return value
    async def read(self,issued):
        args=dict(binding=deepcopy(self.binding),runId=self.run,resultsDirectory=self.acquire_args()['resultsDirectory'],
            query=deepcopy(issued['query']),nativePassiveReadVersion=1)
        return await self.passive_rpc('touch-native-original-read',args)
    async def observed(self):
        from ios.adapters import lifecycle_world as world
        issued=await self.issue(world.ACTION);value=await self.read(issued)
        self.assertEqual(4,value['originalKeeperNativeFileVersion']);self.assertEqual(issued['passiveLeaseId'],value['passiveLeaseId'])
        self.assertEqual(issued['passivePhase'],value['passivePhase']);packet=json.loads(value['rawJson']);world.original(packet)
        self.assertEqual(42,packet['processId']);self.assertEqual(self.run,packet['runId']);return issued,value,packet

    async def test_actual_held_world_then_after_own_up_terminal_world_share_original_source_and_unchanged_input_intent(self):
        from ios.adapters import lifecycle_world as world
        lease=await self.open_motion();source=self.source;rsd=self.rsd
        issued,held,packet=await self.observed();self.assertEqual('holding',held['passivePhase'])
        self.assertEqual(1,len(packet['source']['touch']['active']));self.assertFalse(source._closing)
        self.assertEqual(4,self.ops.native_query_journals[self.run]['previous']['originalKeeperNativeQueryOwnerVersion'])
        result=await self.ops.execute('touch-release',{},self.binding['sessionId']);self.assertEqual(2,result['iosOriginalKeeperTouchVersion'])
        self.assertFalse(result['inspection']['hostResponsibility']);self.assertFalse(source._closing)
        _,released,current=await self.observed();self.assertEqual('released',released['passivePhase'])
        proof=world.contact_released(packet,current);self.assertEqual('released',proof['terminal'])
        self.assertIs(self.source,source);self.assertIs(self.rsd,rsd);self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes());self.assertEqual(3,len(self.journal()['previous']['frames']))
        self.assertEqual({},self.ops.native_passive_tasks)
        # Assert original query/read lifetime BEFORE final drain. The prior
        # fixture directly awaited SDK operations in this still-running test
        # Task, causing the unchanged Source drain to wait for its own caller.
        for task,thread,finished,loop in source._native_queries:
            self.assertIsNot(task,asyncio.current_task());self.assertTrue(task.done())
            self.assertFalse(thread.is_alive());self.assertTrue(finished.is_set())
        for row in source._native_reads:
            self.assertIsNot(row[2],asyncio.current_task());self.assertTrue(row[2].done());self.assertTrue(row[4].is_set())
        await self.ops.execute('touch-settle',{},self.binding['sessionId']);self.assertTrue(source._closing)

    async def test_profile_without_actual_born_lease_cannot_use_preparation_or_dto_as_passive_source(self):
        from ios.adapters import lifecycle_world as world
        await self.prepare_rpc();before=len(self.commands)
        with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
        self.assertEqual(before,len(self.commands));self.assertEqual([],self.source._born);self.assertEqual([],self.f.states())
        self.assertEqual({},self.ops.native_passive_tasks)

    async def test_foreign_or_old_unprofiled_nonce_cannot_borrow_current_passive_scope_before_service_open(self):
        await self.open_motion();await self.ops.execute('touch-release',{},self.binding['sessionId'])
        await self.issue('feature-native-observe');services=len(self.services)
        old=next(row['query'] for row in self.ops.native_query_journals[self.run]['previous']['records']
            if row['query']['action']=='feature-native-observe' and 'passiveLeaseId' not in row)
        for query in (old,dict(schemaVersion=1,commandId='ios-'+'f'*32,action='feature-native-observe')):
            with self.assertRaises((RuntimeError,ValueError)):await self.read(dict(query=query))
        self.assertEqual(services,len(self.services));self.assertEqual({},self.ops.native_passive_tasks)

    async def test_foreign_finished_worker_slot_then_restoration_cannot_revive_passive_source(self):
        from ios.adapters import lifecycle_world as world
        lease=await self.open_motion();await self.ops.execute('touch-release',{},self.binding['sessionId']);original=lease.worker
        foreign=asyncio.create_task(asyncio.sleep(0));await foreign;lease.worker=foreign;before=len(self.commands)
        try:
            with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
        finally:lease.worker=original
        with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
        self.assertEqual(before,len(self.commands));self.assertTrue(self.selected[3]['revoked']);self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        self.assertEqual({},self.ops.native_passive_tasks)

    async def test_original_source_loss_refuses_new_passive_read_but_final_old_settle_remains_possible(self):
        from ios.adapters import lifecycle_world as world
        await self.open_motion();await self.ops.execute('touch-release',{},self.binding['sessionId']);before=len(self.commands);services=len(self.services)
        with patch.object(self.cap,'current',side_effect=RuntimeError('Explicit current source loss')):
            with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
            await self.ops.execute('touch-settle',{},self.binding['sessionId'])
        self.assertEqual(before,len(self.commands));self.assertEqual(services,len(self.services));self.assertTrue(self.source._closing)
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual({},self.ops.native_passive_tasks)

    async def test_profile4_journal_cannot_silently_accept_or_downgrade_unprofiled_bundle_calls(self):
        from ios.adapters import lifecycle_world as world
        await self.open_motion();await self.issue(world.ACTION);owner=self.ops.native_query_journals[self.run]
        before=deepcopy(owner['previous']);body=owner['store'].path.read_bytes();commands=len(self.commands)
        args=dict(self.acquire_args(),action='ios-bundle-observe',nativeBundleProfileVersion=1)
        with self.assertRaises((RuntimeError,ValueError)):await self.ops.execute('touch-native-query',args,self.binding['sessionId'])
        self.assertEqual(before,owner['previous']);self.assertEqual(body,owner['store'].path.read_bytes());self.assertEqual(commands,len(self.commands))
        self.assertEqual(4,owner['previous']['originalKeeperNativeQueryOwnerVersion']);self.assertEqual({},self.ops.native_passive_tasks)

    async def test_pending_original_drain_is_unavailable_then_same_original_return_allows_released_world(self):
        from ios.adapters import lifecycle_world as world
        lease=await self.open_motion();self.f.context.drain_gate.clear();self.f.context.drain_started.clear()
        release=asyncio.create_task(self.ops.execute('touch-release',{},self.binding['sessionId']));self.controls_motion.append(release)
        await self.f.context.drain_started.wait();before=len(self.commands)
        try:
            with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
            self.assertEqual(before,len(self.commands));self.assertFalse(lease.worker.done());self.assertFalse(self.resource._native_step._failed)
        finally:self.f.context.drain_gate.set()
        await release;_,value,packet=await self.observed();self.assertEqual('released',value['passivePhase']);self.assertEqual([],packet['source']['touch']['active'])
        self.assertEqual(1,self.f.context.exited);self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual({},self.ops.native_passive_tasks)

    async def test_read_crossing_actual_up_refuses_held_result_then_new_released_query_still_works(self):
        from ios.adapters import lifecycle_world as world
        lease=await self.open_motion();issued=await self.issue(world.ACTION)
        self.hook=lambda _service:lease.request_release.set()
        try:
            with self.assertRaises((RuntimeError,ValueError)):await self.read(issued)
        finally:self.hook=None
        await lease.worker;self.assertFalse(self.resource._native_step._failed);self.assertEqual({},self.ops.native_passive_tasks)
        _,value,packet=await self.observed();self.assertEqual('released',value['passivePhase']);self.assertEqual([],packet['source']['touch']['active'])
        self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_original_unprofiled_default1_release_still_closes_whole_source_and_remains_version1(self):
        lease=await self.touch();result=await self.ops.execute('touch-release',{},self.binding['sessionId'])
        self.assertEqual(1,result['iosOriginalKeeperTouchVersion']);self.assertTrue(self.source._closing)
        self.assertFalse(result['inspection']['hostResponsibility']);self.assertEqual([0xC2,0x02],self.f.states())
        self.assertTrue(lease.closed);self.assertEqual({},self.ops.native_passive_tasks)

    async def test_unrelated_loop_callback_or_foreign_task_cannot_borrow_live_original_query_scope(self):
        from ios.adapters import lifecycle_world as world
        await self.open_motion();await self.ops.execute('touch-release',{},self.binding['sessionId'])
        before=len(self.commands);self.response_gate.clear()
        query=asyncio.create_task(self.issue(world.ACTION));self.controls_motion.append(query)
        try:
            # Actual owned HTTP reaches its original producer, then waits for
            # the real response gate. The original before-send callback has
            # already run; no synthetic predicate or SDK result is supplied.
            while len(self.commands)==before:await asyncio.sleep(.001)
            actual=self.ops.native_query_task
            self.assertIsInstance(actual,asyncio.Task);self.assertIsNot(actual,query);self.assertFalse(actual.done())
            self.assertTrue(any(row['task'] is actual for row in self.ops.issued.values()))
            scope=self.ops.native_passive_tasks[actual]
            self.assertIsNotNone(scope._query_callback);self.assertFalse(scope._query_callback._active)
            with self.assertRaises((RuntimeError,ValueError)):scope.current()
            completed=asyncio.Event();outcome=[]
            def unrelated():
                self.assertIsNone(asyncio.current_task())
                try:scope.current()
                except (RuntimeError,ValueError):outcome.append('refused')
                else:outcome.append('accepted')
                finally:completed.set()
            self.loop.call_soon(unrelated);await completed.wait()
            self.assertEqual(['refused'],outcome);self.assertIsNone(self.ops.native_passive_callback)
            self.assertFalse(self.resource._native_step._failed)
        finally:self.response_gate.set()
        value=await query;self.assertEqual(4,value['originalKeeperNativeQueryVersion'])
        self.assertEqual('released',value['passivePhase']);self.assertIsNone(self.ops.native_passive_callback)
        self.assertEqual({},self.ops.native_passive_tasks);self.assertEqual([0xC2,0xC2,0x02],self.f.states())
