"""Actual owned nonce/HTTP/AFC-model FDs/frame WAL/chunks, explicit SDK models.

No installed native binary/SDK/authentication/current motion gate is qualified.
The host runtime uses an explicit modeled source provider; actual results,
original bytes, keeper functions, codecs and storage are never stubbed.
"""
from __future__ import annotations
import ast,asyncio,base64,hashlib,json,marshal,os,threading,time,unittest
from concurrent.futures import Future
from copy import deepcopy
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import native_file_fixture as original_file_fixture


class OriginalNativeAcquisitionModels(original_file_fixture.OriginalNativeFileChannelModels):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        # Source.__init__ normally creates this list; base no-SDK fixture
        # predates Query3 and explicitly constructs Source with __new__.
        self.source._native_queries=[]
        from ios.self_tests.test_ios_lifecycle_touch import TouchBoundary
        from ios.self_tests.test_ios_scene_commit_origin import Boundary as SceneBoundary
        from self_tests.test_native_feature_observation import Boundary as NativeBoundary
        from ios.adapters.lifecycle_world_hold_runtime import IOSLifecycleWorldHoldRuntime
        from adapters.original_frame_store import OriginalFrameStore
        self.frame_store_type=OriginalFrameStore;self.loop=asyncio.get_running_loop();self.started=self.loop.time();outer=self
        def epoch():return 20000+round((outer.loop.time()-outer.started)*1000)
        self.modeled_epoch=epoch
        class Scene(SceneBoundary):
            # Selected before this new producer's actual import/source birth.
            # Existing captured originals and their timestamps are never edited.
            def epoch(_):return epoch()
        self.world_source=TouchBoundary(Scene);self.native_source=NativeBoundary()
        def native_stamp(value):
            now=epoch()
            def stamp(row):
                if isinstance(row,dict):
                    for key,child in row.items():
                        if key.endswith('EpochMs'):row[key]=now
                        else:stamp(child)
                elif isinstance(row,list):
                    for child in row:stamp(child)
            stamp(value);value['processId']=42
        self.native_source.mutate=native_stamp;self.run='a'*32;self.geometry_sequence=0;self.commands=[];self.fault=None;self.delay_http=False;self.response_gate=threading.Event();self.response_gate.set()
        self.server_errors=[];self.remote=[];self.corrupt_chunk=False;self.first_native=None
        # Extract the ACTUAL existing strict owner JSON parser into exactly the
        # namespace used by the source-selected classes. No copied implementation.
        path=Path(self.mapping['keeper']['path']);tree=ast.parse(path.read_bytes());node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='decode_owner_packet')
        module=ast.Module(body=[node],type_ignores=[]);code=compile(ast.fix_missing_locations(module),str(path),'exec');ns=type(self.ops).native_acquisition_read.__globals__;exec(code,ns)
        metadata=dict(sourceSha256=self.mapping['keeper']['sha256'],selectedAstSha256=hashlib.sha256(ast.dump(module,include_attributes=False).encode()).hexdigest(),compiledCodeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest())
        sidecar=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/('owner-parser-'+str(id(self))+'.json')
        fd=os.open(sidecar,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as stream:json.dump(metadata,stream,sort_keys=True);stream.write('\n')
        def produce(query):
            self.commands.append(deepcopy(query));action=query['action']
            if action=='feature-native-observe':
                self.native_source.send(query);packet=deepcopy(self.native_source.sample)
                if self.first_native is None:self.first_native=deepcopy(packet)
            elif action=='native-geometry-snapshot':
                self.geometry_sequence+=1;sample=epoch()
                if self.fault=='old-geometry':sample=self.first_native['capturedEpochMs']-1
                packet=dict(schemaVersion=1,commandId=query['commandId'],observation=dict(schemaVersion=1,sampleEpochMs=sample,
                    sampleSequence=self.geometry_sequence,nativeUi=dict(valid=True,surfaceWidth=1000,surfaceHeight=640,
                        safeInsetLeft=0,safeInsetTop=20,safeInsetRight=0,safeInsetBottom=20),window=dict(width=1000,height=600)))
            elif action=='ios-bundle-observe':
                self.bundle_source.send(query);packet=json.loads(self.bundle_source.original())
            else:
                self.assertEqual('feature-ios-lifecycle-world',action);self.world_source.send(query);packet=json.loads(self.world_source.original())
            if self.fault=='wrong-nonce':packet['requestId' if 'requestId' in packet else 'commandId']='ios-'+'f'*32
            self.input.write_text(json.dumps(packet))
            if self.fault=='source-rsd':self.rsd=type(self.rsd)()
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*_):pass
            def do_POST(self):
                try:
                    raw=self.rfile.read(int(self.headers['Content-Length']));query=json.loads(raw);future=Future()
                    def original_producer():
                        try:produce(query);future.set_result(None)
                        except BaseException as error:future.set_exception(error)
                    outer.loop.call_soon_threadsafe(original_producer);future.result(timeout=5)
                    if outer.delay_http:time.sleep(1.55)
                    if not outer.response_gate.wait(5):raise TimeoutError('Declared HTTP gate not released')
                    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
                except (BrokenPipeError,ConnectionResetError):pass
                except BaseException as error:outer.server_errors.append(error)
        self.server=HTTPServer(('127.0.0.1',0),Handler);self.origin='http://127.0.0.1:'+str(self.server.server_address[1])
        self.server_thread=threading.Thread(target=lambda:self.server.serve_forever(poll_interval=.01),name='native-acquisition-model-http',daemon=False);self.server_thread.start();self.addAsyncCleanup(self.close_server)
        # Actual host consumer; ONLY its SDK/source-provider boundary is DI.
        # All response/body/WAL/file/chunk facts come from selected source code.
        def host_check():
            future=Future()
            def check():
                try:self.source.current();future.set_result(None)
                except BaseException as error:future.set_exception(error)
            self.loop.call_soon_threadsafe(check);future.result(timeout=5)
        def execute(session,operation,values):
            self.assertEqual('mobile: overteOriginalKeeperOperation',operation)
            future=asyncio.run_coroutine_threadsafe(self.ops.execute(values['operation'],values['args'],session),self.loop);self.remote.append(future);value=future.result(timeout=7)
            if self.corrupt_chunk and values['operation']=='touch-native-acquisition-read':
                body=json.loads(value['originalJson']);data=base64.b64decode(body['contentBase64']);body['contentBase64']=base64.b64encode(data[:-1]).decode()
                from adapters.script_feature.history import canonical
                value=dict(value,originalJson=canonical(body).decode('ascii'))
            return value
        self.host_source=dict(binding=deepcopy(self.binding),session=self.binding['sessionId'],check=host_check,
            client=SimpleNamespace(execute=execute),target=dict(testBuild=dict(fixtureOrigin=self.origin,resultsDirectory='owned')))
        self.runtime=IOSLifecycleWorldHoldRuntime(SimpleNamespace(state_path=lambda _:self.f.store.path))
        from ios.adapters import lifecycle_world_hold_runtime as runtime_module
        self.enterContext(patch.object(runtime_module,'IOSScriptRuntime',side_effect=lambda _:SimpleNamespace(_sources=lambda _selector:self.host_source)))
    def acquire_args(self):return dict(binding=deepcopy(self.binding),runId=self.run,resultsDirectory='owned',origin=self.origin)
    def start_acquire(self):
        task=asyncio.create_task(self.ops.execute('touch-native-acquire',self.acquire_args(),self.binding['sessionId']));self.tasks.append(task);return task
    async def consume(self):return await asyncio.to_thread(self.runtime.native_original_acquisition,'modeled-existing-source',self.run)
    async def close_server(self):
        self.response_gate.set()
        for task in self.tasks:
            try:await asyncio.shield(task)
            except BaseException:pass
        for future in self.remote:
            try:await asyncio.wrap_future(future)
            except BaseException:pass
        self.server.shutdown();self.server.server_close();self.server_thread.join(timeout=5)
        self.assertFalse(self.server_thread.is_alive());self.assertEqual([],self.server_errors)
    def journal(self):return self.ops.native_acquisition_journals[self.run]
    def frame_path(self,reference):
        files=self.ops._native_acquisition_files(self.journal(),lambda:None);return files.path(files.expand(reference))

    async def test_real_query_file_wal_and_chunk_consumer_preserve_four_distinct_originals_without_caps_or_fresh_flags(self):
        value=await self.consume();frame=value['originalFrame'];self.assertEqual(4,len(self.commands));self.assertEqual(4,len({q['commandId'] for q in self.commands}))
        raw=self.frame_path(value['reference']).read_bytes();self.assertGreater(len(raw),12000)
        self.assertEqual(value['reference']['sha256'],hashlib.sha256(raw).hexdigest());self.assertEqual(frame,json.loads(raw)['frame'])
        self.assertEqual(self.journal()['previous']['frames'],[value['reference']]);self.assertIsNone(self.journal()['previous']['pending'])
        self.assertEqual([q['commandId'] for q in self.commands],[r['query']['commandId'] for r in frame['reads']])
        self.assertTrue(all(value[k] is False for k in ('nativeAcquisitionBound','installedCandidateBound','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished')))
        self.assertTrue(all(row[4].is_set() for row in self.source._native_reads));self.assertTrue(all(not thread.is_alive() for task,thread,finished,loop in self.source._native_queries))

    async def test_foreign_file_nonce_refuses_without_issuing_second_native_query_or_saving_a_frame(self):
        self.fault='wrong-nonce'
        with self.assertRaises((RuntimeError,ValueError)):await self.start_acquire()
        self.assertEqual(1,len(self.commands));self.assertEqual([],self.journal()['previous']['frames']);self.assertIsNone(self.journal()['previous']['pending'])

    async def test_source_rsd_swap_during_http_refuses_same_object_claim_before_any_file_or_frame(self):
        self.fault='source-rsd'
        with self.assertRaises(RuntimeError):await self.start_acquire()
        self.assertEqual(1,len(self.commands));self.assertEqual([],self.services);self.assertEqual([],self.journal()['previous']['frames'])

    async def test_actual_global_deadline_after_first_http_does_not_expand_to_four_per_call_budgets(self):
        self.delay_http=True
        with self.assertRaises(RuntimeError):await self.start_acquire()
        self.assertEqual(1,len(self.commands));self.assertEqual([],self.services);self.assertEqual([],self.journal()['previous']['frames'])
        self.assertTrue(all(not thread.is_alive() for task,thread,finished,loop in self.source._native_queries))

    async def test_lost_saved_original_return_keeps_same_pending_frame_and_never_replays_its_queries(self):
        write=self.frame_store_type.write
        def lost(store,index,frame):
            ref=write(store,index,frame)
            if store.namespace=='lifecycle-native-acquisition':raise OSError('Declared lost return AFTER actual immutable saved frame')
            return ref
        with patch.object(self.frame_store_type,'write',new=lost),self.assertRaises(OSError):await self.start_acquire()
        previous=deepcopy(self.journal()['previous']);self.assertEqual('saved',previous['pending']['phase']);self.assertEqual(4,len(self.commands))
        with self.assertRaises(RuntimeError):await self.start_acquire()
        self.assertEqual(previous,self.journal()['previous']);self.assertEqual(4,len(self.commands))

    async def test_atomic_same_byte_inode_replacement_refuses_original_chunk_after_successful_capture(self):
        result=await self.start_acquire();reference=json.loads(result['acquisitionJson'])['reference'];path=self.frame_path(reference)
        before=path.stat().st_ino;replacement=path.with_name('foreign-atomic-replacement');replacement.write_bytes(path.read_bytes());replacement.chmod(0o600);os.replace(replacement,path)
        self.assertNotEqual(before,path.stat().st_ino)
        args=dict(binding=deepcopy(self.binding),runId=self.run,referenceJson=json.dumps(reference),offset=0)
        with self.assertRaises((RuntimeError,ValueError)):await self.ops.execute('touch-native-acquisition-read',args,self.binding['sessionId'])
        self.assertEqual(4,len(self.commands))

    async def test_real_source_chunk_truncated_by_transport_cannot_become_a_parent_original(self):
        self.corrupt_chunk=True
        with self.assertRaises((RuntimeError,ValueError)):await self.consume()
        self.assertEqual(4,len(self.commands));self.assertEqual(1,len(self.journal()['previous']['frames']))

    async def test_geometry_older_than_fresh_before_fails_join_without_retiming_any_raw_receipt(self):
        self.fault='old-geometry'
        with self.assertRaises((RuntimeError,ValueError)):await self.start_acquire()
        self.assertEqual(4,len(self.commands));self.assertEqual([],self.journal()['previous']['frames']);self.assertIsNone(self.journal()['previous']['pending'])
