"""Root-only exact base readback and own4 patch generation; NO public mutation."""
from pathlib import Path
import ast,difflib,hashlib,json,os,re,stat,subprocess
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def pin(path):
    assert path.resolve(strict=True)==path
    a=path.lstat();assert stat.S_ISREG(a.st_mode)
    value={key:getattr(a,key) for key in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')};value['sha256']=sha(path)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in value if key!='sha256');return value
frozen=json.loads((HERE/'freeze.json').read_text())
for name,digest in frozen['files'].items():assert sha(HERE/name)==digest,name
plan=json.loads((HERE/'plan.json').read_text());observed={}
for row in plan['nonRegistryPaths']:
    path=REPO/row['path']
    if row['baseExists']:
        actual=pin(path);assert actual['sha256']==row['expectedPrepublicationBaseSha256'],row['path'];observed[row['path']]=actual
    else:assert not path.exists() and not path.is_symlink(),row['path'];observed[row['path']]=None
spec=json.loads((HERE/'own-registry-spec.json').read_text());json_name='tests/device/contract-versions.json';validator_name='tests/device/validate_contract_versions.py'
texts={name:(REPO/name).read_text() for name in (json_name,validator_name)};contracts=json.loads(texts[json_name])['contracts']
def required(text):
    t=ast.parse(text);rows=[n for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='REQUIRED' for x in n.targets)]
    assert len(rows)==1;return ast.literal_eval(rows[0].value)
versions=required(texts[validator_name])
for key,values in spec.items():
    assert contracts.get(key)==values['before'],key
    assert versions.get(key)==(None if values['before'] is None else values['before']['current']),key
patched=dict(texts)
for key,values in spec.items():
    if values['before'] is None:continue
    for name in patched:
        after=values['after'] if name==json_name else values['after']['current']
        replacement='    '+json.dumps(key)+': '+json.dumps(after)+',\n'
        pattern=r'^    '+re.escape(json.dumps(key))+r': [^\n]*\n'
        patched[name],count=re.subn(pattern,lambda _m:replacement,patched[name],flags=re.MULTILINE);assert count==1,(name,key)
new='ios-emote-target-pair-original'
for name in patched:
    anchor=re.search(r'^    "ios-emote-feature": [^\n]*\n',patched[name],flags=re.MULTILINE);assert anchor
    after=spec[new]['after'] if name==json_name else spec[new]['after']['current']
    row='    '+json.dumps(new)+': '+json.dumps(after)+',\n';patched[name]=patched[name][:anchor.end()]+row+patched[name][anchor.end():]
after_contracts=json.loads(patched[json_name])['contracts'];after_versions=required(patched[validator_name])
assert {k:v for k,v in contracts.items() if k not in spec}=={k:v for k,v in after_contracts.items() if k not in spec}
assert {k:v for k,v in versions.items() if k not in spec}=={k:v for k,v in after_versions.items() if k not in spec}
for key,value in spec.items():assert after_contracts[key]==value['after'] and after_versions[key]==value['after']['current']
registry_pins={name:pin(REPO/name) for name in texts};assert all((REPO/name).read_text()==text for name,text in texts.items())
output=HERE/'root-prepublication-readback';output.mkdir(mode=0o700,exist_ok=False)
patch=''.join(line for name in texts for line in difflib.unified_diff(texts[name].splitlines(True),patched[name].splitlines(True),fromfile='a/'+name,tofile='b/'+name,n=0))
(output/'actual-own-four-key-hunks.patch').write_text(patch)
value=dict(status='ACTUAL_BEFORE_PUBLIC_MUTATION_READONLY_BASES_AND_PRIVATE_PATCH',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),nonRegistryBasePins=observed,registryBasePins=registry_pins,foreignRegistryKeysPreserved=True,foreignPCMBefore=contracts.get('ios-audio-pcm-lease'),ownAfter={key:row['after'] for key,row in spec.items()},actualPatchSha256=hashlib.sha256(patch.encode()).hexdigest(),publicMutationPerformed=False,targetImportsExecuted=False,testsExecuted=False)
(output/'readback.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(output=str(output),sourcePaths=len(observed),ownKeys=len(spec),foreignPCMBefore=value['foreignPCMBefore'],head=value['head']),sort_keys=True))
