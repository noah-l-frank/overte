"""Actual Linux identities only; no product process/OS evidence authority.

Discovery reads stat for all visible PIDs. Executable resolution is reserved
for the actual discovered owned ancestry. An unreadable owned executable is
an error, not process absence; every such read is bracketed by stat identity.
"""
from pathlib import Path
import os,stat,threading
from metadata_reader import pin


def _stat(pid):
    try:
        raw=Path('/proc/'+str(pid)+'/stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    opening=raw.find('(');closing=raw.rfind(')')
    assert opening>0 and closing>opening and int(raw[:opening].strip())==int(pid)
    fields=raw[closing+2:].split();assert len(fields)>=20
    return dict(pid=int(pid),parent=int(fields[1]),group=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))


def _executable(pid):
    return str(Path('/proc/'+str(pid)+'/exe').resolve(strict=True))


def _same_identity(before,after):
    return before is not None and after is not None and before==after


def process(pid,*,expected=None,parent=None,group=None):
    before=_stat(pid)
    if before is None:return None
    if expected is not None:
        assert type(expected)is dict and set(expected)in({'pid','parent','group','session','startTicks'},{'pid','parent','group','startTicks','executable'})
        assert all(before[name]==expected[name]for name in('pid','parent','group','startTicks')),'Already-bound PID/ancestry changed BEFORE executable read'
        if 'session'in expected:assert before['session']==expected['session'],'Bound session changed BEFORE executable read'
    else:
        # New birth is selected by the actual Popen creator/parent before any
        # executable read. Descendant discovery supplies its exact stat instead.
        assert before['parent']==(os.getpid()if parent is None else parent),'Foreign new-birth parent'
        assert before['group']==(os.getpgrp()if group is None else group),'Foreign new-birth group'
    try:executable=_executable(pid)
    except(FileNotFoundError,ProcessLookupError):
        after=_stat(pid)
        if after is None:return None
        assert _same_identity(before,after),'PID/ancestry changed while resolving an executable'
        # An alive PID with unavailable executable has not established absence.
        raise
    after=_stat(pid)
    if after is None:return None
    assert _same_identity(before,after),'PID/ancestry changed across executable resolution'
    if expected is not None and 'executable'in expected:assert executable==expected['executable'],'Already-bound executable changed'
    return {name:before[name]for name in('pid','parent','group','startTicks')}|dict(executable=executable)


def absent(pid):
    # Any live PID, including a reused foreign PID, refuses absence without
    # reading its executable. Permission/parse failures propagate unchanged.
    return _stat(pid)is None


def descendants(parent):
    parent_before=_stat(parent);assert parent_before is not None
    actual={}
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            row=_stat(int(path.name))
            if row is not None:actual[row['pid']]=row
    # No executable, cwd, environment or FD of a foreign process is read.
    assert _same_identity(parent_before,actual.get(int(parent)))
    own={int(parent)};changed=True
    while changed:
        changed=False
        for pid,row in actual.items():
            if row['parent']in own and pid not in own:own.add(pid);changed=True
    result={}
    for pid in sorted(own-{int(parent)}):
        expected=actual[pid];verified=process(pid,expected=expected)
        if verified is None:
            after=_stat(pid)
            assert after is None,'An owned PID reappeared during discovery'
            continue
        assert all(verified[name]==expected[name]for name in('pid','parent','group','startTicks')),'Discovered PID/ancestry was replaced'
        after=_stat(pid)
        if after is None:continue
        assert _same_identity(expected,after),'Discovered PID/session changed after executable validation'
        result[pid]=verified
    assert _same_identity(parent_before,_stat(parent)),'Discovery owner identity changed'
    return result

def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:
            s=path.stat();result[path.name]=dict(target=os.readlink(path),device=s.st_dev,inode=s.st_ino,mode=s.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result

def state():return dict(fds=fds(),threads=[(t.ident,t.name)for t in threading.enumerate()],children=Path('/proc/self/task/'+str(os.getpid())+'/children').read_text())
def census(root):
    root=Path(root);out={}
    for path in(root,*sorted(root.rglob('*'))):
        before=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(before.st_mode):
            row={key:getattr(before,key)for key in('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')}
            row['namespace']=sorted(p.name for p in path.iterdir())
        else:row=pin(path)
        assert all(getattr(path.lstat(),key)==getattr(before,key)for key in('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'));out[str(path.relative_to(root))]=row
    return out
