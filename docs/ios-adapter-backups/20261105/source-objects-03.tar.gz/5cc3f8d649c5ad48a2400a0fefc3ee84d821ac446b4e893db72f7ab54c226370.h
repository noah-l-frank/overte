// Copyright 2026 Overte contributors.
// SPDX-License-Identifier: Apache-2.0
#pragma once
// E2E original observer, not an audio source, engine or hardware clock.
#include "RecordedPreviewInputOrigin.h"
#include <MixedProcessedAudioStream.h>
#include <AudioConstants.h>
#include <QMutex>
#include <QMutexLocker>
#include <QRegularExpression>
#include <PortableHighResolutionClock.h>
namespace overte::e2e {
class ReceivedMixerCapture {
public:
    static constexpr int PACKETS = 64;
    static constexpr int FRAME_BYTES = AudioConstants::NETWORK_FRAME_BYTES_STEREO;
    bool start(const QString& run, const QString& lease, int seconds,
            std::shared_ptr<const RecordedPreviewAdmission> admission, MixedProcessedAudioStream* stream, QObject* output) {
        QMutexLocker lock(&_mutex);
        if (_owned || !id(run) || !id(lease) || !admission || !stream || !output || seconds < 6 || seconds > 10 ||
                !RecordedPreviewAdmission::available(admission->state()) || _generation >= 1000000000 || Q_BYTE_ORDER != Q_LITTLE_ENDIAN) { return false; }
        _owned = true; _invalid = false; _run = run; _lease = lease; _seconds = seconds;
        _admission = std::move(admission); _epoch = _admission->state(); _stream = stream; _output = output;
        _startedEpoch = QDateTime::currentMSecsSinceEpoch(); _startedMono = previewOriginMonotonicMs();
        _startedReceive = std::chrono::duration_cast<std::chrono::microseconds>(p_high_resolution_clock::now().time_since_epoch()).count();
        _lastEpoch = _startedEpoch; _lastMono = _startedMono; ++_generation;
        _rows.clear(); _pcm.clear(); _thread = nullptr; _source = 0; _sender.clear(); _codec.clear(); _decoder.clear();
        _lastReceive = 0; _lastSequence = -1;
        if (!current() || _startedEpoch <= 0 || _startedMono <= 0 || _startedReceive <= 0) { _invalid = true; return false; }
        return true;
    }
    // Synchronous under the real decoder mutex. No IO, queued buffer, pointer
    // retention, native getter, source selector or caller-supplied PCM.
    void append(ReceivedMixerDecodedOriginal* t) {
        QMutexLocker lock(&_mutex);
        if (!_owned || _invalid || _rows.size() == PACKETS) { return; }
        if (!t || t->consumed || !current() || t->stream != _stream.data() || !t->message || !t->encoded || !t->decoded ||
                t->thread != QThread::currentThread()) { _invalid = true; return; }
        t->consumed = true;
        const auto& message = *t->message; const auto raw = message.getMessage(); const auto receive = message.getFirstPacketReceiveTime();
        const auto source = message.getSourceID(); const auto sender = t->message->getSenderSockAddr().toString();
        const auto& endpoint = t->message->getSenderSockAddr();
        const auto senderAddress = endpoint.getAddress().toString(); const auto senderPort = endpoint.getPort(); const int socketType = static_cast<int>(endpoint.getType());
        const auto decoder = address(t->decoder); const auto thread = QThread::currentThread(); const auto pcm = *t->decoded;
        if (message.failed() || !message.isComplete() || message.getType() != PacketType::MixedAudio || !source || sender.isEmpty() || endpoint.getAddress().isNull() || !senderPort || socketType < 1 || socketType > 2 ||
                receive <= _startedReceive || receive < _lastReceive || receive > t->beforeReceiveClockUs ||
                t->afterReceiveClockUs < t->beforeReceiveClockUs || raw.isEmpty() || raw.size() > 2048 || t->encoded->isEmpty() || t->encoded->size() > 2048 ||
                t->originalMessageDigest != QCryptographicHash::hash(raw, QCryptographicHash::Sha256) || pcm.size() != FRAME_BYTES ||
                t->sequence <= _lastSequence || t->selectedCodec.size() > 30 || t->beforeEpoch < _lastEpoch || t->afterEpoch < t->beforeEpoch ||
                t->beforeMono < _lastMono || t->afterMono < t->beforeMono || t->afterMono - _startedMono >= _seconds * 1000 ||
                !((t->packetCodec == t->selectedCodec) || ((t->packetCodec.isEmpty() || t->packetCodec == "pcm") &&
                    (t->selectedCodec.isEmpty() || t->selectedCodec == "pcm")))) { _invalid = true; return; }
        if (_rows.isEmpty()) { _thread = thread; _source = source; _sender = sender; _endpointType = socketType; _codec = t->selectedCodec; _decoder = decoder; }
        if (_thread != thread || _source != source || _sender != sender || _endpointType != socketType || _codec != t->selectedCodec || _decoder != decoder) { _invalid = true; return; }
        QVariantMap row {{"index", _rows.size() + 1}, {"streamIdentity", address(_stream.data())}, {"messageIdentity", address(t->message)},
            {"decoderIdentity", decoder}, {"threadIdentity", address(thread)}, {"sourceLocalId", source}, {"senderSockAddr", sender}, {"senderAddress", senderAddress}, {"senderPort", senderPort}, {"senderSocketType", socketType},
            {"packetType", "MixedAudio"}, {"packetVersion", static_cast<int>(message.getVersion())}, {"packetSequence", t->sequence},
            {"arrivalEarly", t->early}, {"packetReceiveClockUs", QString::number(receive)},
            {"decodeBeforeReceiveClockUs", QString::number(t->beforeReceiveClockUs)}, {"decodeAfterReceiveClockUs", QString::number(t->afterReceiveClockUs)}, {"packetCodec", t->packetCodec}, {"selectedCodec", t->selectedCodec},
            {"decodeBeforeEpochMs", t->beforeEpoch}, {"decodeAfterEpochMs", t->afterEpoch}, {"decodeBeforeMonotonicMs", t->beforeMono}, {"decodeAfterMonotonicMs", t->afterMono},
            {"messageBase64", QString::fromLatin1(raw.toBase64())}, {"messageSha256", digest(raw)},
            {"encodedBase64", QString::fromLatin1(t->encoded->toBase64())}, {"encodedSha256", digest(*t->encoded)},
            {"offset", _pcm.size()}, {"bytes", pcm.size()}, {"pcmSha256", digest(pcm)}};
        _pcm.append(pcm); _rows.append(row); _lastSequence = t->sequence; _lastReceive = receive; _lastEpoch = t->afterEpoch; _lastMono = t->afterMono;
    }
    void stop(quint64 generation) { QMutexLocker lock(&_mutex); if (_owned && generation == _generation) { _invalid = true; } }
    void invalidateOwned() { QMutexLocker lock(&_mutex); if (_owned) { _invalid = true; } }
    quint64 generation() const { QMutexLocker lock(&_mutex); return _generation; }
    bool bound(QObject* output, const std::shared_ptr<const RecordedPreviewAdmission>& admission) const {
        QMutexLocker lock(&_mutex); return !_owned || (current() && output == _output.data() && admission == _admission);
    }
    QVariantMap snapshot(bool sourceCurrent) {
        QMutexLocker lock(&_mutex); if (_owned && (!sourceCurrent || !current() || previewOriginMonotonicMs() - _startedMono >= _seconds * 1000)) { _invalid = true; }
        return {{"receivedMixerVersion", 1}, {"profile", "accepted-mixer-packet-decode-v1"}, {"owned", _owned},
            {"runId", _run}, {"leaseId", _lease}, {"instance", _owned ? _admission->instance() : QString()}, {"role", _owned ? "actor" : ""},
            {"admissionEpoch", _epoch}, {"captureGeneration", _generation}, {"startedEpochMs", _startedEpoch}, {"startedMonotonicMs", _startedMono}, {"startedReceiveClockUs", QString::number(_startedReceive)},
            {"maximumOwnedSeconds", _seconds}, {"targetPackets", _owned ? PACKETS : 0}, {"sampleRate", _owned ? AudioConstants::SAMPLE_RATE : 0},
            {"channels", _owned ? 2 : 0}, {"sampleFormat", "pcm16le"}, {"streamIdentity", _owned ? address(_stream.data()) : QString()},
            {"outputIdentity", _owned ? address(_output.data()) : QString()}, {"bytes", _pcm.size()}, {"rows", _rows},
            {"active", _owned && !_invalid && _rows.size() < PACKETS}, {"complete", _owned && !_invalid && _rows.size() == PACKETS}, {"invalid", _invalid},
            {"receiveClockDomain", "udt-p_high_resolution_clock-us-opaque"}, {"sampleClockMeaning", "decoded-pcm-order-not-adc-dac-time"},
            {"individualPeerQualified", false}, {"physicalADCQualified", false}, {"physicalDACQualified", false}, {"renderedOutputQualified", false},
            {"acousticQualified", false}, {"nativeQualified", false}, {"wholeQualified", false}};
    }
    QByteArray wav(bool sourceCurrent) {
        QMutexLocker lock(&_mutex); if (_owned && (!sourceCurrent || !current() || previewOriginMonotonicMs() - _startedMono >= _seconds * 1000)) { _invalid = true; }
        if (!_owned || _invalid || _rows.size() != PACKETS || _pcm.size() != PACKETS * FRAME_BYTES) { return {}; }
        QByteArray out; const auto word = [&](quint32 v, int n) { for (int i = 0; i < n; ++i) { out.append(static_cast<char>((v >> (i * 8)) & 255)); } };
        out.append("RIFF"); word(36 + _pcm.size(), 4); out.append("WAVEfmt "); word(16, 4); word(1, 2); word(2, 2);
        word(AudioConstants::SAMPLE_RATE, 4); word(AudioConstants::SAMPLE_RATE * 4, 4); word(4, 2); word(16, 2);
        out.append("data"); word(_pcm.size(), 4); out.append(_pcm); return out;
    }
    bool release(const QString& run, const QString& lease, quint64 generation) {
        QMutexLocker lock(&_mutex); if (!_owned || run != _run || lease != _lease || generation != _generation) { return false; }
        _pcm.fill(0); _pcm.clear(); _pcm.squeeze(); _rows.clear(); _owned = _invalid = false; _run.clear(); _lease.clear();
        _admission.reset(); _stream.clear(); _output.clear(); _epoch = 0; _startedEpoch = _startedMono = _lastEpoch = _lastMono = _startedReceive = 0;
        _seconds = 0; _thread = nullptr; _source = 0; _sender.clear(); _codec.clear(); _decoder.clear(); _lastReceive = 0; _lastSequence = -1; return true;
    }
private:
    static bool id(const QString& s) { return QRegularExpression("\\A[0-9a-f]{32}\\z").match(s).hasMatch(); }
    static QString address(const void* p) { return QString::number(reinterpret_cast<quintptr>(p), 16); }
    static QString digest(const QByteArray& b) { return QString::fromLatin1(QCryptographicHash::hash(b, QCryptographicHash::Sha256).toHex()); }
    bool current() const { return _admission && RecordedPreviewAdmission::available(_epoch) && _admission->state() == _epoch && _stream && _output; }
    mutable QMutex _mutex; bool _owned {false}, _invalid {false}; int _seconds {0}, _lastSequence {-1}, _endpointType {0}; quint64 _generation {0}; unsigned _epoch {0}; quint16 _source {0};
    qint64 _startedEpoch {0}, _startedMono {0}, _lastEpoch {0}, _lastMono {0}, _lastReceive {0}, _startedReceive {0}; QString _run, _lease, _sender, _codec, _decoder;
    const QThread* _thread {nullptr}; QPointer<MixedProcessedAudioStream> _stream; QPointer<QObject> _output;
    std::shared_ptr<const RecordedPreviewAdmission> _admission; QVariantList _rows; QByteArray _pcm;
};
} // namespace overte::e2e
