from pathlib import Path
from importlib.machinery import PathFinder
import ast,hashlib,json,os,shutil,stat,sys
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026')
D=R/'.ios-host-tmp/avatar-primary-control-checkpoint-root-preparation-20261029';assert not D.exists();D.mkdir(mode=0o700)
B=R/'.ios-host-tmp/avatar-recovered-terminal-worker-joined600-root1-preparation-20261029'
P=R/'.ios-host-tmp/avatar-primary-control-checkpoint-handoff-draft-20261029'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
for name in ('monitoring_observer.py','root-supervise.py','run-selected.py','run_metadata.py','refresh-after-publication.py'):
    shutil.copyfile(B/name,D/name)
for name in ('root-supervise.py','run-selected.py'):
    p=D/name;s=p.read_text().replace("('terminal1',)","('tls6','owner2','checkpoint1','legacyTLS5')").replace('OVERTE_AVATAR_SCENE_FINAL_RUN','OVERTE_AVATAR_PRIMARY_CONTROL_RUN').replace('OVERTE_TABLET_OWNED_ROOT_RUN','OVERTE_AVATAR_PRIMARY_CONTROL_RUN');p.write_text(s)
# Existing exact observer/audit/census/cleanup bodies remain literal. TLS-only
# suites own no Node, but bind original owner methods before case execution.
plan=json.loads((B/'suite-plan.json').read_text());draft=json.loads((P/'test-plan.json').read_text())
http=draft['caseIDs']['test_ios_avatar_primary_control_http'];owners=draft['caseIDs']['test_ios_avatar_primary_control_owner']
suites={}
for kind,ids,cap,td,aliases in (
    ('tls6',http,120,7,['self_tests.test_account_provider','ios.self_tests.test_ios_avatar_primary_control_http']),
    ('owner2',owners[:2],300,9,['self_tests.test_account_provider','ios.self_tests.test_ios_emote_marker_scope','ios.self_tests.test_ios_installed_code']),
    ('checkpoint1',owners[2:],600,5,['self_tests.test_account_provider','ios.self_tests.test_ios_emote_marker_scope','ios.self_tests.test_ios_installed_code'])):
    suites[kind]=dict(caseIds=ids,count=len(ids),initialTimeoutSeconds=cap,killAfterSeconds=5,expectedRetainedRoots=td,fixtureAliasModules=aliases,directTemporaryDirectoryModules=[])
# Actual unchanged legacy HTTP routes directly affected by the new auth routing.
tree=ast.parse((R/'tests/device/self_tests/test_avatar_account_http.py').read_text())
ids=['self_tests.test_avatar_account_http.AvatarAccountHTTPTests.'+n.name for c in tree.body if isinstance(c,ast.ClassDef) and c.name=='AvatarAccountHTTPTests' for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(ids)==5
suites['legacyTLS5']=dict(caseIds=ids,count=5,initialTimeoutSeconds=120,killAfterSeconds=5,expectedRetainedRoots=1,fixtureAliasModules=['self_tests.test_account_provider'],directTemporaryDirectoryModules=[])
expected=[dict(path=row['path'],expectedSha256=row['candidateSha256']) for row in json.loads((P/'source-manifest.json').read_text())]
write(D/'expected-publication.json',expected);write(D/'expected-registry-own-keys.json',{})
roots=['tests/device','tests/device/self_tests','tests/device/ios/self_tests']
ordered=[str(R/p) for p in roots]
future={}
for row in expected:
    name=row['path']
    if name.endswith('.py') and name not in [r['path'] for r in json.loads((P/'source-manifest.json').read_text()) if r['baseSha256'] is not None]:
        future[name.removeprefix('tests/device/').removesuffix('.py').replace('/','.')]=dict(path=name)
options={}
for root in roots:
    for p in (R/root).rglob('*.py'):
        parts=p.relative_to(R/root).with_suffix('').parts
        if parts[-1]=='__init__':continue
        if all(x.isidentifier() for x in parts):options.setdefault('.'.join(parts),[]).append(str(p.relative_to(R)))
# Metadata only: no importlib.import_module, no target execution.
remaining=[x for x in sys.path if x and not Path(x).resolve().is_relative_to(R)]
sys.path[:]=ordered+remaining
modules={};excluded={}
for name,paths in sorted(options.items()):
    search=sys.path;spec=None;reason=None
    for i in range(len(name.split('.'))):
        part='.'.join(name.split('.')[:i+1]);spec=PathFinder._get_spec(part,list(search))
        if spec is None:reason='missing '+part;break
        search=spec.submodule_search_locations
        if i<len(name.split('.'))-1 and search is None:reason='nonpackage '+part;break
    if reason is None and spec.origin is not None:
        path=Path(spec.origin).resolve();relative=str(path.relative_to(R)) if path.is_relative_to(R) else None
        if relative in paths:modules[name]=dict(path=relative);continue
    excluded[name]=reason or 'resolved foreign path'
modules.update(future)
packageRoots={}
for name in ('adapters','feature_journeys','ios','self_tests','ios.adapters','ios.self_tests'):
    search=sys.path
    for i in range(len(name.split('.'))):
        spec=PathFinder._get_spec('.'.join(name.split('.')[:i+1]),list(search));assert spec is not None
        search=spec.submodule_search_locations
    assert len(search)==1;packageRoots[name]=str(Path(search[0]).resolve().relative_to(R))
write(D/'source-root-final-map.json',dict(orderedRoots=roots,packageRoots=packageRoots,modules=modules))
write(D/'namespace-preflight.json',dict(method='stdlib PathFinder._get_spec, no target imports',resolvedCurrent=len(modules)-len(future),futurePublicationOnly=future,excluded=excluded,allExcludedFilesStillBroadPinned=True))
# Also prove actual resolution again AFTER publication; never reuse old SHA maps.
p=D/'refresh-after-publication.py';s=p.read_text();needle="modulePins={name:dict(path=row['path'],sha256=actual[row['path']]['sha256']) for name,row in config['modules'].items()}"
replacement="""from pathlib import Path
from importlib.machinery import PathFinder
import sys,os
rest=[item for item in sys.path if not Path(item or os.getcwd()).resolve().is_relative_to(REPO)]
sys.path[:]=[str(REPO/name) for name in config['orderedRoots']]+rest
for name,row in config['modules'].items():
    search=sys.path
    for index in range(len(name.split('.'))):
        spec=PathFinder._get_spec('.'.join(name.split('.')[:index+1]),list(search));assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(name.split('.'))-1:assert search is not None,name
    assert spec.origin is not None and Path(spec.origin).resolve(strict=True)==REPO/row['path'],name
modulePins={name:dict(path=row['path'],sha256=actual[row['path']]['sha256']) for name,row in config['modules'].items()}"""
assert s.count(needle)==1;s=s.replace(needle,replacement);p.write_text(s)
# Preserve the original stable failed terminal corpus plus all inherited inputs.
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
    a=p.lstat();v={k:getattr(a,k) for k in FIELDS}
    assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
    if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
    b=p.lstat();assert all(getattr(a,k)==getattr(b,k) for k in FIELDS);return v
prior=json.loads((B/'retained-prior-original-pins.json').read_text())
report=json.loads((B/'terminal1-report.json').read_text());assert report['exitCode']==124 and report['originalFiles']==1111 and report['allPinsEqual'] and report['postStopCensusesQualified']
runroot=Path(report['runRoot']);originals=json.loads((B/'terminal1-originals-first.json').read_text())
for name,row in originals.items():
    p=runroot/'temporary'/name;assert pin(p)==row;prior[str(p.relative_to(R))]=row
for p in [B/'terminal1-report.json',B/'terminal1-originals-first.json',B/'terminal1-originals-second.json',B/'terminal1-first.log',runroot/'created-original-roots.json']:
    prior[str(p.relative_to(R))]=pin(p)
write(D/'retained-prior-original-pins.json',prior)
plan.update(status='PRIVATE_FOUR_EXACT_SELECTIONS_UNRUN_CONTROL_SOURCE_CHANGE',suites=suites,requiredSplitComponents=[],expectedPublicationCount=len(expected),frozenPackets=[dict(path=str(P.relative_to(R)),freezeSha256=sha(P/'freeze.json'))],
    sourceRootMapSha256=sha(D/'source-root-final-map.json'),expectedPublicationSha256=sha(D/'expected-publication.json'),expectedOwnRegistrySha256=sha(D/'expected-registry-own-keys.json'),retainedPriorPinsSha256=sha(D/'retained-prior-original-pins.json'))
for name in ('budgetJustification','workerJoin','requiredBeforeBudgetChoice'):
    plan.pop(name,None)
plan['budgetJustification']=dict(newProtocol6=120,newRealSessionAndClosedProfile2=300,newConnectedCheckpoint1=600,existingTLS5=120,killAfterSeconds=5,allOriginalInnerClocksUnchanged=True,noTerminal600Retry=True,noWholeClaim=True)
write(D/'suite-plan.json',plan)
(D/'ROOT-REVIEW.txt').write_text('Private exact TLS6 / Owner2 / checkpoint1 / existing legacyTLS5 selections. No tests/imports/public edits.\nRun refresh-after-publication.py ONLY after exact8 source publication; actual namespace resolution is rechecked before ready map creation. Then root-supervise.py KIND, separately. No ready map exists now.\nExisting original Popen/Node close/stdio/thread/census controls are literal qualified terminal-launcher copies. Parent/child share OVERTE_AVATAR_PRIMARY_CONTROL_RUN. TLS certificate subprocess is original exact bounded openssl recipe, host-only.\nExpected TDs TLS6=7, Owner2=9, checkpoint1=5, legacyTLS5=1. TLS listener original close/shutdown/join preserved. Three original Node owner classes monitored without extra closes or waits. Unknown timeout leaves child-final cleanup unqualified.\nActual 1111 terminal-timeout originals/report/log plus all inherited global original inputs retained. No active/running tree captured. Config/capability Avatar remains closed; no full Installed15 or native qualification.\n')
# Compare launchers to qualified source to make review of environment/selection only easy.
import difflib
diff=[]
for name in ('root-supervise.py','run-selected.py','refresh-after-publication.py'):
    diff.extend(difflib.unified_diff((B/name).read_text().splitlines(True),(D/name).read_text().splitlines(True),fromfile='qualified/'+name,tofile='proposed/'+name))
(D/'launcher-only.diff').write_text(''.join(diff))
for p in D.glob('*.py'):ast.parse(p.read_text())
files={str(p.relative_to(D)):sha(p) for p in sorted(D.rglob('*')) if p.is_file()}
write(D/'freeze.json',dict(frozen=True,testsExecuted=False,targetImportsExecuted=False,files=files))
print(str(D));print('freeze',sha(D/'freeze.json'));print('modules',len(modules),'priorpins',len(prior))
