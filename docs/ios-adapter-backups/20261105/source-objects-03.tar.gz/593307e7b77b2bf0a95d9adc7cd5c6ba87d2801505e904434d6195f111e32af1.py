"""PRIVATE checked-mutable-tree prototype contracts; AST-only, UNRUN."""
import gc
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
import weakref
from adapters.normal_ui import NativeUIError
path=Path(__file__).with_name('photos-checked-tree-descriptor-proposal.py')
spec=importlib.util.spec_from_file_location('private_checked_tree_descriptor',path)
proposal=importlib.util.module_from_spec(spec);sys.modules[spec.name]=proposal;spec.loader.exec_module(proposal)

class CheckedTreeDescriptorProposalTests(unittest.TestCase):
    def reader(self,hook=None):
        self.calls=[]
        def data(value):
            self.calls.append(id(value));descriptor=proposal.original.data(value)
            if hook:hook(value)
            return descriptor
        self.namespace=SimpleNamespace(data=data);return proposal.tree_reader(self.namespace)
    def test_actual_complete_parser_identity_tuple_parity(self):
        self.assertEqual(proposal.original.parser_identity(),proposal.parser_identity())
    def test_equal_mutable_aliases_avoid_only_materialization(self):
        reader=self.reader();value={'rows':[{'a':1,'b':True},('tail',)]};first=reader(value);second=reader(value)
        self.assertEqual(proposal.original.data(value),first);self.assertEqual(first,second);self.assertEqual(1,len(self.calls))
        value['rows'][0]['a']=2;third=reader(value);self.assertEqual(proposal.original.data(value),third);self.assertNotEqual(first,third)
        self.assertEqual(2,len(self.calls))
    def test_early_alias_descriptor_is_not_rewritten_after_later_mutation(self):
        reader=self.reader();value={'a':[0]};early=reader(value);value['a'][0]=1;later=reader(value)
        self.assertEqual((('a',(0,)),),early);self.assertEqual((('a',(1,)),),later)
    def test_new_string_key_and_equal_reordering(self):
        reader=self.reader();value={'b':2,'a':1};first=reader(value)
        value.clear();value.update(a=1,b=2);self.assertEqual(first,reader(value));self.assertEqual(1,len(self.calls))
        value['c']=3;self.assertEqual(proposal.original.data(value),reader(value));self.assertEqual(2,len(self.calls))
    def test_primitive_types_nan_and_signed_zero(self):
        for before,after in ((True,1),(1,1.0),(-0.0,0.0),(float('nan'),float('nan')),(b'x','x')):
            with self.subTest(types=(type(before),type(after))):
                reader=self.reader();value={'v':before};first=reader(value);self.assertIs(first,reader(value))
                value['v']=after;second=reader(value);self.assertEqual(2,len(self.calls));self.assertIsNot(first,second)
                self.assertIs(after,second[0][1])
    def test_depth5_6_7_identity_boundary(self):
        for depth in (5,6,7):
            with self.subTest(depth=depth):
                reader=self.reader();leaf=[];value=leaf
                for _ in range(depth):value=[value]
                first=reader(value);self.assertEqual(proposal.original.data(value),first)
                leaf.append('changed');self.assertEqual(proposal.original.data(value),reader(value))
                self.assertEqual(2 if depth==5 else 1,len(self.calls))
    def test_cycle_and_container_subclass_use_literal_fallback(self):
        class List(list):pass
        cycle=[];cycle.append(cycle)
        for value in (cycle,{'v':cycle},List([1]),{'v':List([1])},{'set':{1,2}}):
            with self.subTest(kind=type(value).__name__):
                reader=self.reader();self.assertEqual(proposal.original.data(value),reader(value));reader(value)
                self.assertEqual(2,len(self.calls))
    def test_opaque_key_side_effects_match_old_call_count_and_order(self):
        events=[];other={'a':0}
        class Key:
            def __str__(self):events.append('str');other['a']+=1;return 'key'
        value={Key():1};reader=self.reader();early=reader(other)
        reader(value);reader(value);later=reader(other)
        self.assertEqual(['str','str'],events);self.assertEqual((('a',0),),early);self.assertEqual((('a',2),),later)
        self.assertEqual(4,len(self.calls))
    def test_shape_construction_mutation_never_admits_stale_descriptor(self):
        mutate=[True]
        def hook(value):
            if mutate[0]:value['a']=2;mutate[0]=False
        reader=self.reader(hook);value={'a':1};first=reader(value);second=reader(value)
        self.assertEqual((('a',1),),first);self.assertEqual((('a',2),),second);self.assertEqual(2,len(self.calls))
    def test_strong_identity_leaf_and_no_cross_call_reuse(self):
        class Opaque:pass
        leaf=Opaque();weak=weakref.ref(leaf);value=leaf
        for _ in range(6):value=[value]
        reader=self.reader();reader(value)
        cursor=value
        for _ in range(5):cursor=cursor[0]
        cursor[0]=None;del leaf;gc.collect();self.assertIsNotNone(weak())
        reader(value);later=proposal.tree_reader(self.namespace);later(value);self.assertEqual(3,len(self.calls))
    def test_data_function_code_or_defaults_change_rejects_warm_entry(self):
        reader=self.reader();value={'v':1};reader(value);old=self.namespace.data;self.namespace.data=lambda _value:('wrong',)
        with self.assertRaises(NativeUIError):reader(value)
        self.namespace.data=old;code=old.__code__
        def changed(value):
            self.calls.append(id(value));proposal.original.data(value)
            return value if self.namespace is None else value
        # The original function closes over both hook and self; preserve
        # closure arity while replacing its code object for this metadata case.
        hook=None
        def replacement(value):
            self.calls.append(id(value));return hook(value) if hook else value
        try:
            old.__code__=replacement.__code__
            with self.assertRaises(NativeUIError):reader(value)
        finally:old.__code__=code
        try:
            old.__defaults__=(None,)
            with self.assertRaises(NativeUIError):reader(value)
        finally:old.__defaults__=None
