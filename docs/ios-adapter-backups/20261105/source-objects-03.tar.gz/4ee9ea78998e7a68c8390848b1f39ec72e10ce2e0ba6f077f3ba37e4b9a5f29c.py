"""Actual E458 composition plus finite original stdlib IPC capacities.

Ordinary writes remain canonical own-root writes. Deleted Arena descriptors,
original spawn FIFO and Connection/tracker messages are separate typed
capacities; none authorizes arbitrary /dev/shm writes, network or processes.
"""
from pathlib import Path
from types import MappingProxyType
import builtins,io,os,socket,stat,sys,threading,types,_socket,_posixsubprocess
from owned_write_boundary import OwnedWrites
from tablet_constructor_custody import FunctionBinding,CustodyRefusal
from mp_identity import fd_row
RELEVANT=('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')
class Ports:
    def __init__(self,root,ipc,modules,*,parent,transport,bridge=lambda:None):
        self.root=Path(root);self.ipc=ipc;self.m=modules;self.parent=parent;self.transport=transport;self.bridge=bridge
        self.helper=OwnedWrites(root,protected=tuple(transport['protected']))
        self.original=MappingProxyType(dict(self.helper.original));self.items=tuple(self.original.items());self.helper.original=self.original;self.helper.original_items=self.items
        self.cio=(io.open,builtins.open);self.dup=(os.dup,os.dup2);self.pipe=os.pipe
        self.fork_exec=_posixsubprocess.fork_exec;self.c_socketpair=_socket.socketpair;self.socketpair=socket.socketpair;self.socketpair_binding=FunctionBinding(socket.socketpair);self.socket=socket.socket;self.c_socket=_socket.socket;self.ports={};self.bindings=[];self.closed=False;self.installed=False;self.authority=None
        self.pipe_rows=[];self.socket_rows=[];self.arena_rows=[];self.active_pipes={};self.rebuilt=[]
        self.arena=FunctionBinding(modules['heap'].Arena.__init__);self.pipe_ctor=FunctionBinding(modules['connection'].Pipe)
        self.popen=FunctionBinding(modules['popen'].Popen._launch);self.tracker_launch=FunctionBinding(modules['tracker'].ResourceTracker._launch)
        self.spawn_main=FunctionBinding(modules['spawn'].spawn_main);self.util_spawn=FunctionBinding(modules['util'].spawnv_passfds)
        self.methods=[(k,v,FunctionBinding(v))for k,v in vars(type(self)).items()if type(v)is types.FunctionType]
        self.active=True;self.main=threading.get_ident()
        self.c_members={key:vars(self.c_socket)[key]for key in('family','type','fileno','getsockopt')}
        assert type(self.fork_exec)is types.BuiltinFunctionType and self.fork_exec.__self__ is _posixsubprocess and self.fork_exec.__name__=='fork_exec'
        assert type(self.c_socketpair)is types.BuiltinFunctionType and self.c_socketpair.__self__ is _socket and self.c_socketpair.__name__=='socketpair'
    def check(self):
        assert not self.closed and threading.get_ident()==self.main
        for key,value,binding in self.methods:assert vars(type(self))[key]is value;binding.guard()
        self.helper._check();self.ipc.check();self.socketpair_binding.guard()
        assert socket.socket is self.socket and _socket.socket is self.c_socket and _socket.socketpair is self.c_socketpair
        assert all(vars(self.c_socket).get(key)is value for key,value in self.c_members.items())
        assert self.cio==(io.open,builtins.open)
        if self.installed:
            assert all(getattr(os,key)is value for key,value in self.ports.items())
            assert socket.socketpair is self.socketpair_port and os.pipe is self.pipe_port and os.dup is self.dup_port and os.dup2 is self.dup2_port
            assert _posixsubprocess.fork_exec is self.fork_port
        for binding in self.bindings:binding.guard()
    def pipe_create(self,frame,*args,**kwargs):
        self.check();assert self.parent and not args and not kwargs
        matches=[binding for binding in(self.popen,self.tracker_launch,self.util_spawn)if frame.f_code is binding.code and frame.f_globals is binding.namespace]
        assert len(matches)==1;matches[0].frame(frame)
        if matches[0]is self.tracker_launch:assert frame.f_locals['self']is self.m['tracker']._resource_tracker
        elif matches[0]is self.popen:assert type(frame.f_locals['self'])is self.m['popen'].Popen
        else:assert self.bridge()is not None and self.bridge().active
        result=self.pipe();assert type(result)is tuple and len(result)==2
        for fd in result:
            row=fd_row(fd);assert stat.S_ISFIFO(row['mode']);self.active_pipes[fd]=row
            self.pipe_rows.append(dict(fd=fd,identity=row,actualCreator=matches[0].code.co_qualname))
        return result
    def socket_pair(self,frame,*args,**kwargs):
        self.check();assert self.parent;self.pipe_ctor.frame(frame)
        assert frame.f_locals['duplex']is True
        # Only the original Pipe's genuine default socketpair invocation.
        assert not args and not kwargs
        result=self.socketpair();assert len(result)==2
        for owner in result:
            assert type(owner)is self.socket and owner.family==socket.AF_UNIX and owner.type&0xf==socket.SOCK_STREAM
            fd=owner.fileno();row=fd_row(fd);assert stat.S_ISSOCK(row['mode'])
            self.socket_rows.append(dict(descriptor=fd,identity=row,actualFamily='AF_UNIX',actualType='SOCK_STREAM'))
        return result
    def arena_cap(self,frame,fd):
        self.arena.frame(frame);owner=frame.f_locals['self'];assert type(owner)is self.m['heap'].Arena and owner.fd==fd
        info=fd_row(fd);assert stat.S_ISREG(info['mode'])
        if self.parent:
            raw=os.readlink('/proc/self/fd/'+str(fd))
            assert raw.startswith(str(self.root)+'/own-toys/')and raw.endswith(' (deleted)')
            assert os.fstat(fd).st_uid==os.geteuid()and os.fstat(fd).st_nlink==0
        else:assert self.transport['actualPassedDescriptors'].get(str(fd))==info
        return dict(owner=owner,fd=fd,identity=info)
    def mutate(self,name,args,kwargs,caller,portframe):
        self.check()
        if name=='write'and not kwargs and self.ipc.tracker_write_allowed(args,caller):return self.original[name](*args)
        if name=='ftruncate'and not kwargs and caller.f_code is self.arena.code:
            cap=self.arena_cap(caller,args[0]);assert args[1]==cap['owner'].size
            # The genuine C call is made below from this mutate frame, not
            # from its wrapper. Retain and join BOTH original live frames.
            actual_call=sys._getframe()
            next(binding for key,fn,binding in self.methods if key=='mutate').frame(actual_call)
            wrapper=self.ports[name]
            next(binding for binding in self.bindings if binding.function is wrapper).frame(portframe)
            assert actual_call.f_back is portframe and portframe.f_back is caller
            assert portframe.f_locals['owner']is self and portframe.f_locals['_name']==name
            assert portframe.f_locals['args']is args and portframe.f_locals['kwargs']is kwargs
            assert self.authority is None;self.authority=('os.truncate',args,actual_call,portframe,caller,cap)
            try:return self.original[name](*args)
            finally:self.authority=None
        return self.helper.os_open(*args,**kwargs)if name=='open'else self.helper.mutate(name,*args,**kwargs)
    def audit_actual(self,event,args,frame):
        self.check()
        process=event in('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.system','os.exec','os.kill','os.killpg','os.setsid','os.setpgid','ctypes.dlopen')or event.startswith('os.spawn')
        sockets=event.startswith('socket.')
        if process:raise CustodyRefusal('No extra process/native/signal audit port')
        if sockets:
            assert self.parent and event=='socket.__new__'
            owner,family,kind,proto=args;assert type(owner)in(self.socket,self.c_socket)and family==socket.AF_UNIX and kind&0xf==socket.SOCK_STREAM and proto==0
            self.socketpair_binding.guard()
            current=frame;found=False
            while current is not None:
                if current.f_code is self.pipe_ctor.code and current.f_globals is self.pipe_ctor.namespace:
                    self.pipe_ctor.frame(current);found=True;break
                current=current.f_back
            assert found,'Only actual original Pipe socketpair; no network or arbitrary sockets'
            return
        if event=='mmap.__new__':
            self.arena.frame(frame);cap=self.arena_cap(frame,args[0]);assert args[1]==cap['owner'].size
            self.arena_rows.append(dict(fd=cap['fd'],identity=cap['identity'],actualArenaConstructor=True));return
        if event=='os.truncate'and self.authority is not None:
            expected,wire,actual_call,port,arena,cap=self.authority
            next(binding for key,fn,binding in self.methods if key=='mutate').frame(frame)
            wrapper=self.ports['ftruncate']
            next(binding for binding in self.bindings if binding.function is wrapper).frame(port)
            self.arena.frame(arena)
            assert frame is actual_call and actual_call.f_back is port and port.f_back is arena
            assert actual_call.f_locals['self']is self and port.f_locals['owner']is self
            assert port.f_locals['_name']=='ftruncate'and port.f_locals['args']is wire
            assert not port.f_locals['kwargs']and arena.f_locals['self']is cap['owner']
            assert event==expected and args==wire and wire==(cap['fd'],cap['owner'].size)
            assert fd_row(cap['fd'])==cap['identity'];return
        if event=='open'and type(args[0])is int:
            fd,mode,flags=args;writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
            if writing and self.parent:
                self.popen.frame(frame);owner=frame.f_locals['self'];assert type(owner)is self.m['popen'].Popen
                assert frame.f_locals['parent_w']==fd and mode=='w'and self.active_pipes[fd]==fd_row(fd)
                assert stat.S_ISFIFO(fd_row(fd)['mode'])and owner.pid is not None
                actual=self.bridge();assert actual is not None and any(row['role']=='actor'and row['kernel']['pid']==owner.pid for row in actual.records)
                return
        self.helper.audit(event,args,frame)
    def install(self):
        self.check();assert not self.installed;owner=self
        for name,unused in self.items:
            if name=='close':continue
            def port(*args,_name=name,**kwargs):return owner.mutate(_name,args,kwargs,sys._getframe(1),sys._getframe())
            self.ports[name]=port;self.bindings.append(FunctionBinding(port));setattr(os,name,port)
        def pipes(*a,**k):return owner.pipe_create(sys._getframe(1),*a,**k)
        def pair(*a,**k):return owner.socket_pair(sys._getframe(1),*a,**k)
        def dup(fd):
            owner.check();assert not owner.parent
            frame=sys._getframe(1);owner.spawn_main.frame(frame)
            assert fd==frame.f_locals['pipe_handle']and owner.transport['actualPassedDescriptors'][str(fd)]==fd_row(fd)
            assert stat.S_ISFIFO(fd_row(fd)['mode']);out=owner.dup[0](fd);assert fd_row(out)==fd_row(fd);return out
        def dup2(*a,**k):raise CustodyRefusal('No dup2 capacity')
        def fork_exec(*a,**k):
            owner.check();assert owner.parent and not k
            frame=sys._getframe(1);owner.util_spawn.frame(frame)
            bridge=owner.bridge();assert bridge is not None and bridge.active
            assert len(a)==22 and a[0]is frame.f_locals['args']and a[1]==[frame.f_locals['path']]
            assert a[3]is frame.f_locals['passfds']and a[12]==frame.f_locals['errpipe_read']and a[13]==frame.f_locals['errpipe_write']
            assert all(owner.active_pipes[fd]==fd_row(fd)for fd in(a[12],a[13]))
            return owner.fork_exec(*a)
        self.fork_port=fork_exec
        self.pipe_port,self.socketpair_port,self.dup_port,self.dup2_port=pipes,pair,dup,dup2
        for fn in(pipes,pair,dup,dup2,fork_exec):self.bindings.append(FunctionBinding(fn))
        os.pipe=pipes;socket.socketpair=pair;os.dup=dup;os.dup2=dup2;_posixsubprocess.fork_exec=fork_exec;self.installed=True;self.check()
        from mp_file_scope import select
        select(self)
    def restore(self):
        self.check();assert not self.helper.control_fds and self.authority is None
        self.helper.close()
        for key,value in self.items:setattr(os,key,value)
        os.pipe=self.pipe;socket.socketpair=self.socketpair;os.dup,os.dup2=self.dup;_posixsubprocess.fork_exec=self.fork_exec
        self.installed=False;self.closed=True;self.active=False
        from mp_file_scope import select
        select(None)
        assert all(getattr(os,key)is value for key,value in self.items)
        assert self.cio==(io.open,builtins.open)and self.dup==(os.dup,os.dup2)and socket.socketpair is self.socketpair
        return dict(all27OriginalPortsRestored=len(self.items)==27,actualPortCount=len(self.items),CIOUnchanged=True,dupRestored=True,
            actualOriginalPipeRows=self.pipe_rows,actualOriginalSocketpairRows=self.socket_rows,actualArenaMmapRows=self.arena_rows,
            noOrdinaryDevShmWritePermission=True,noNetwork=True,noSignals=True,actualForkExecRestored=_posixsubprocess.fork_exec is self.fork_exec)
