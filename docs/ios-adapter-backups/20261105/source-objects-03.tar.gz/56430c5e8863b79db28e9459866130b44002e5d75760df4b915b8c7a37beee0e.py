"""Exactly one reviewed passive historical case; no overlays or new TDs."""
import hashlib,importlib,json,os,stat,sys,unittest
from importlib.machinery import PathFinder
from pathlib import Path
from guard import PREP,REPO,target,pin,sources,input_guard
from root_stage_guard import baseline,terminal
from observer_only import sensitive_event,ActualExceptionOriginal
assert sys.dont_write_bytecode
HERE=Path(os.environ['EMOTE_SAVED_THIRD_STAGE']).resolve();assert HERE==PREP/'first1'
plan=json.loads((PREP/'plan.json').read_text());selection=json.loads((HERE/'case.json').read_text())
assert selection['case']==plan['case']and selection['wallSeconds']==180 and selection['killAfterSeconds']==5 and selection['innerAlarmSeconds']==90
assert selection['expectedTemporaryDirectories']==plan['expectedTemporaryDirectories']==0
sources();input_guard()
for name in('diagnostic','cleanup'):target(HERE/name).mkdir(mode=0o700,exist_ok=False)
os.environ.update(EMOTE_SAVED_THIRD_PLAN=plan['sourceModelPlan'],EMOTE_SAVED_THIRD_INPUT_PINS=str(PREP/'input-graph-pins.json'),
    EMOTE_SAVED_THIRD_DIAGNOSTIC_OUTPUT=str(HERE/'diagnostic'))
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf')
input_roots=tuple(Path(p)for p in plan['oldInputRoots']);locks=json.loads((PREP/'existing-lock-pins.json').read_text())
allowed_outputs=(HERE/'diagnostic',HERE/'cleanup');allowed_files={HERE/'selected-result.json'}
def sdk_free():assert not [name for name in sys.modules if name.split('.')[0]in forbidden]
# These ports belong to the controller. They never supply parser/native facts.
# All allowed output parents already exist; no namespace mutation is necessary.
current_frame=sys._getframe;real_open=os.open;real_fstat=os.fstat;real_lstat=os.lstat;real_close=os.close
held_ports=None;held_owners={};held_opens=[];held_flocks=[];own_fds={}
parent_fields=('st_dev','st_ino','st_mode','st_uid','st_gid')
parent_pins={}
for leaf in (*allowed_outputs,*[p.parent for p in allowed_files]):
    for directory in (leaf,*leaf.parents):
        assert directory.resolve(strict=True)==directory and not directory.is_symlink()
        info=real_lstat(directory);assert stat.S_ISDIR(info.st_mode)
        parent_pins[directory]=tuple(getattr(info,k)for k in parent_fields)
        if directory==REPO:break

def refuse(reason):raise RuntimeError(reason)

def port_identities():
    assert os.open is guarded_open and guarded_open.__code__ is open_port_code
    assert sys._getframe is current_frame and os.fstat is real_fstat and os.lstat is real_lstat and os.close is real_close

def path_value(value):
    if isinstance(value,(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(value));return path if path.is_absolute()else REPO/path
    return None

def parents_unchanged():
    for path,row in parent_pins.items():
        info=real_lstat(path)
        assert path.resolve(strict=True)==path and not stat.S_ISLNK(info.st_mode)
        assert tuple(getattr(info,k)for k in parent_fields)==row

def can_write(path):
    if path is None:return False
    # Reject lexical aliases, symlinks and every nested output directory.
    if path.resolve()!=path or not path.is_relative_to(REPO):return False
    if path not in allowed_files and path.parent not in allowed_outputs:return False
    parents_unchanged()
    if path.exists():
        info=real_lstat(path)
        if not stat.S_ISREG(info.st_mode)or info.st_nlink!=1:return False
    return True

def own_descriptor(descriptor):
    assert type(descriptor)is int and descriptor in own_fds
    path,device,inode=own_fds[descriptor];assert can_write(path)
    info=real_fstat(descriptor);at=real_lstat(path)
    assert stat.S_ISREG(info.st_mode)and info.st_nlink==1
    assert(info.st_dev,info.st_ino)==(device,inode)==(at.st_dev,at.st_ino)

def guarded_open(path,flags,mode=0o777,*,dir_fd=None):
    # CPython's open audit event does not expose dir_fd. Gate the actual port
    # before calling the strongly retained original C implementation.
    port_identities();assert dir_fd is None,'Unknown directory descriptor is forbidden'
    path=path_value(path);assert path is not None and path.resolve()==path
    writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
    if writing and str(path)not in locks:assert can_write(path)
    descriptor=real_open(path,flags,mode)
    try:
        if writing and str(path)not in locks:
            assert can_write(path)
            info=real_fstat(descriptor);at=real_lstat(path)
            assert stat.S_ISREG(info.st_mode)and info.st_nlink==1
            assert(info.st_dev,info.st_ino)==(at.st_dev,at.st_ino)
            own_fds[descriptor]=(path,info.st_dev,info.st_ino)
    except BaseException:
        real_close(descriptor)
        raise
    return descriptor
open_port_code=guarded_open.__code__

def original_held_frame(*,through_open=False):
    assert held_ports is not None
    module,cls,wrapper,wrapper_code,function,code,namespace,fcntl_module,flock,cells=held_ports
    assert sys.modules.get('adapters.script_feature.lock')is module and module.ScriptSourceLock is cls
    assert cls.held is wrapper and wrapper.__code__ is wrapper_code and wrapper.__wrapped__ is function
    assert function.__code__ is code and function.__globals__ is namespace
    assert sys.modules.get('fcntl')is fcntl_module and fcntl_module.flock is flock
    current_cells=wrapper.__closure__ or()
    assert len(current_cells)==len(cells)and all(cell is old and cell.cell_contents is value for cell,(old,value)in zip(current_cells,cells))
    frame=current_frame(2)
    if through_open:
        assert frame.f_code is open_port_code and frame.f_globals is globals()
        assert frame.f_locals.get('dir_fd')is None
        frame=frame.f_back
    assert frame.f_code is code and frame.f_globals is namespace
    owner=frame.f_locals.get('self');path=frame.f_locals.get('path')
    assert type(owner)is cls and isinstance(path,Path)and path==owner.path and path.resolve(strict=True)==path
    key=str(path);assert key in locks and pin(path)==locks[key]
    if key in held_owners:assert held_owners[key]is owner
    held_owners[key]=owner
    return frame,owner,key

def audit(event,args):
    if not sensitive_event(event):return
    port_identities()
    if event=='import'and args[0].split('.')[0]in forbidden:refuse('SDK import prohibited')
    if event=='open':
        path=path_value(args[0]);mode,flags=args[1:3]
        writing=type(mode)is str and any(c in mode for c in 'wax+')or type(flags)is int and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if path is not None:
            text=str(path)
            if '/overte-ios-remotexpc/'in text or any('/'+name+'/'in text for name in forbidden):refuse('Installed SDK source access prohibited')
        if writing:
            if path is None:
                # os.fdopen may consume only the actual own output descriptor.
                own_descriptor(args[0])
            elif str(path)in locks:
                frame,owner,key=original_held_frame(through_open=True)
                assert key==str(path)and owner._owner is None and mode is None
                expected=os.O_RDWR|os.O_CREAT|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0)|getattr(os,'O_CLOEXEC',0)
                assert type(flags)is int and flags==expected
                held_opens.append(dict(path=key,receiver=id(owner),frameLine=frame.f_lineno))
            else:
                assert can_write(path),'Historical/source/outside-output write prohibited'
                if mode is None:
                    frame=current_frame(1)
                    assert frame.f_code is open_port_code and frame.f_globals is globals()
                    assert frame.f_locals.get('dir_fd')is None
    if event=='fcntl.flock':
        frame,owner,key=original_held_frame();descriptor,operation=args
        assert type(descriptor)is int and descriptor==frame.f_locals.get('descriptor')
        assert operation==(held_ports[7].LOCK_EX|held_ports[7].LOCK_NB)
        info=real_fstat(descriptor)
        assert tuple(getattr(info,k)for k in('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'))==tuple(locks[key]['stat'])
        assert any(row['path']==key and row['receiver']==id(owner)for row in held_opens)
        held_flocks.append(dict(path=key,receiver=id(owner),descriptor=descriptor,operation=operation,device=info.st_dev,inode=info.st_ino))
    if event in('tempfile.mkdtemp','tempfile.mkstemp'):refuse('No temporary directory or temporary file birth allowed')
    if event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.spawn','os.fork','os.forkpty','pty.spawn'):refuse('No target subprocess/Node/SDK allowed')
    if event.startswith('socket.'):refuse('No target socket/network allowed')
    if event in('os.chdir','os.fchdir'):refuse('Diagnostic cannot change its canonical cwd')
    if event in('os.remove','os.rmdir','os.chmod','os.chown','os.truncate','os.utime','os.mkdir','os.rename','os.link','os.symlink'):
        # No such mutation is used by this case. Deny all path, integer-FD,
        # dir_fd and src_dir_fd/dst_dir_fd variants without guessing a base.
        refuse('No post-birth namespace/metadata/FD mutation is admitted')

# Own output FD is born/bound before the audit policy. It grants no target
# write port; only a real post-failure traceback can use the retained C writer.
exception_path=target(HERE/'diagnostic/controller-exception.log')
exception_descriptor=real_open(exception_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
exception_original=ActualExceptionOriginal(exception_path,exception_descriptor)
sys.excepthook=exception_original
sdk_free();os.open=guarded_open;sys.addaudithook(audit) # Before ANY target module import.
paths=[str(Path(plan['modelRoot'])),*[str(REPO/name)for name in('tests/device','tests/device/self_tests','tests/device/ios/self_tests')]]
rest=[entry for entry in sys.path if entry and not Path(entry).resolve().is_relative_to(REPO)]
sys.path[:]=paths+rest
for name,relative,parents in(('adapters','tests/device/adapters',sys.path),('feature_journeys','tests/device/feature_journeys',sys.path),
    ('ios','tests/device/ios',sys.path),('ios.adapters','tests/device/ios/adapters',[str(REPO/'tests/device/ios')]),
    ('ios.self_tests','tests/device/ios/self_tests',[str(REPO/'tests/device/ios')])):
    spec=PathFinder._get_spec(name,list(parents));assert spec is not None
    assert [str(Path(p).resolve())for p in spec.submodule_search_locations or()]==[str(REPO/relative)]
# Only origin-pinned ordinary imports; no lock owner/held() call during setup.
import fcntl
import adapters.script_feature.lock as lock_module
assert Path(lock_module.__file__).resolve(strict=True)==REPO/'tests/device/adapters/script_feature/lock.py'
cls=lock_module.ScriptSourceLock;wrapper=cls.held;function=wrapper.__wrapped__
cells=tuple((cell,cell.cell_contents)for cell in wrapper.__closure__ or())
assert wrapper.__code__.co_freevars==('func',)and len(cells)==1 and cells[0][1]is function
held_ports=(lock_module,cls,wrapper,wrapper.__code__,function,function.__code__,function.__globals__,fcntl,fcntl.flock,cells)
initial=baseline()
module_name,class_name,method=plan['case'].rsplit('.',2)
result=None;returned=False;case_id=plan['case']
try:
    module=importlib.import_module(module_name);kind=getattr(module,class_name)
    assert Path(module.__file__).resolve()==Path(plan['modelRoot'])/(module_name+'.py')
    assert method in kind.__dict__ and kind.run is unittest.TestCase.run and method.startswith('test_')
    suite=unittest.TestLoader().loadTestsFromName(case_id);assert suite.countTestCases()==1
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite);returned=True
finally:
    # Original standard TestCase.run includes all tearDown/doCleanups before
    # return. The original guard checks real tasks/FDs/threads/children twice.
    terminal(target(HERE/'cleanup'),initial,[str(HERE/'diagnostic'),*plan['oldInputRoots']])
    sdk_free();sources();input_guard();port_identities();parents_unchanged()
    assert set(held_owners)==set(locks)and all(owner._owner is None for owner in held_owners.values())
    assert {row['path']for row in held_opens}==set(locks)and {row['path']for row in held_flocks}==set(locks)
    receipt=dict(case=case_id,actualStandardCaseRunReturned=returned,twoCensusesPassed=True,retainedRoots=[],
        originalInputRoots=plan['oldInputRoots'],diagnosticRoot=str(HERE/'diagnostic'),noSDK=True,noSubprocess=True,noNetwork=True,
        originalHeldOpens=held_opens,originalHeldFlocks=held_flocks,canonicalOutputParentsGuarded=True,unknownDirFDsRefused=True,
        wholeFeatureQualified=False,uncaughtExceptionOriginal=str(exception_path),uncaughtExceptionObserved=exception_original.called)
    with target(HERE/'cleanup/receipt.json').open('x')as stream:json.dump(receipt,stream,indent=2,sort_keys=True);stream.write('\n')
if result is None:raise RuntimeError('Original standard result unavailable')
selected=dict(selectedIds=[case_id],testsRun=result.testsRun,successful=result.wasSuccessful()and result.testsRun==1 and not result.skipped,
    failureCount=len(result.failures),errorCount=len(result.errors),skippedCount=len(result.skipped),wholeFeatureQualified=False,nativeQualified=False)
with target(HERE/'selected-result.json').open('x')as stream:json.dump(selected,stream,indent=2,sort_keys=True);stream.write('\n')
raise SystemExit(0 if selected['successful']else 1)
