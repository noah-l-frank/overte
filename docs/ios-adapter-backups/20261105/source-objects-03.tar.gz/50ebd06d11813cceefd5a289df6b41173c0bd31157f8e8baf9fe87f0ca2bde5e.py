"""Ordinary phase scheduling for an independent Actor's actual mixer originals.

A phase ticket is input/source ownership, not proof of a Primary's audible
output or attribution to any talker. Missing receive data stays unavailable.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib,time
from pathlib import Path
from adapters.native_feature_observation import need
from adapters.normal_ui import NativeUIError
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.phase_fixture import PhaseFixtureReader
from feature_journeys.witness import Client
from ios.adapters.audio_api_clock import operation
from ios.adapters.audio_received_mixer import hex32
from ios.adapters.audio_received_mixer_runtime import IOSAudioReceivedMixerRuntime,ReceivedMixerSDKLedger


def lease_id(run,ticket):
    need(hex32(run)and hex32(ticket))
    return hashlib.sha256(('ios-audio-received-mixer-actor-v1:'+run+':'+ticket).encode('ascii')).hexdigest()[:32]


class IOSAudioReceivedMixerActor:
    def __init__(self,runtime,selector,run,artifact_root,client,*,epoch_ms=lambda:time.time()*1000,
                 monotonic=time.monotonic,sleep=time.sleep):
        need(type(runtime)is IOSAudioReceivedMixerRuntime and hex32(run)and isinstance(client,Client)
            and all(callable(fn)for fn in(epoch_ms,monotonic,sleep)))
        self.runtime,self.selector,self.run,self.root,self.client=runtime,selector,run,Path(artifact_root),client
        self.epoch_ms,self.monotonic,self.sleep=epoch_ms,monotonic,sleep
        self.phase=PhaseFixtureReader(client,run,'audio',epoch_ms=epoch_ms,monotonic=monotonic)
        self.lock=ScriptSourceLock(runtime.state_path(selector).with_name('script-feature-sources.lock'))

    def owner(self,ticket):
        return self.runtime.received_mixer_owner(self.selector,self.run,lease_id(self.run,ticket),self.root,self.client,
            epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep,source_lock=self.lock)

    def birth(self,owner,ticket):
        need(owner.lease==lease_id(self.run,ticket)and owner.state['birth']is not None)
        birth=owner.proof(owner.state['birth']);selection=owner.proof(birth['selection'])
        for packet in(selection['phaseBefore'],selection['phaseAfter']):
            need(packet['active']and packet['activations']and packet['activations'][-1]['ticket']==ticket
                and packet['activations'][-1]['stimulus']['verb']=='record-start')
        return dict(reference=owner.state['birth'],selection=birth['selection'],clockJoin=deepcopy(selection['clockJoin']))

    @operation
    def arm(self,ticket):
        packet=self.phase.read();need(packet['verb']=='record-start'and packet['ticket']==ticket)
        with self.owner(ticket)as owner:
            need(owner.state['release']is owner.state['absence']is None)
            if owner.state['birth']is None:owner.start(6) # Existing upper ownership limit, not a measured duration.
            return dict(runId=self.run,ticket=ticket,leaseId=owner.lease,birth=self.birth(owner,ticket),
                receivedMixerLiveAdmission=None,individualPeerQualified=False,acousticQualified=False,wholeQualified=False)

    @operation
    def capture(self,ticket):
        with self.owner(ticket)as owner:
            self.birth(owner,ticket);need(owner.state['release']is None)
            if owner.state['snapshot']is None:
                _index,reply=owner.control('observe');current=reply['packet']['source']['state']
                if not(current['owned']and current['complete']and not current['invalid']and current['watchdogOwned']and current['watchdogActive']):
                    raise NativeUIError('Actual received-mixer source has no complete original window; ownership remains unresolved')
                owner.capture()
            # This returns only the actual independently retained native files.
            # A timer, ACK or expected tone cannot manufacture availability.
            return owner.original()

    @operation
    def retire_capture(self,ticket):
        with self.owner(ticket)as owner:
            # This can resolve an uncertain issued Start/Capture/Release. The
            # owner never resends an already journaled effect command.
            if owner.state['birth']is not None:self.birth(owner,ticket)
            result=owner.retire();need(result['receivedMixerRetired']and not result['SDKRetired'])
            return result

    def original(self,ticket):
        # Pure old-original reading; no current source/transport construction.
        with self.lock.held():
            ledger=ReceivedMixerSDKLedger(self.runtime,self.selector,self.run,lease_id(self.run,ticket),self.root,self.client,self.lock)
            owner=ledger.archives.get(lease_id(self.run,ticket));need(owner is not None)
            self.birth(owner,ticket);need(owner.state['snapshot']is not None)
            return owner.original()
