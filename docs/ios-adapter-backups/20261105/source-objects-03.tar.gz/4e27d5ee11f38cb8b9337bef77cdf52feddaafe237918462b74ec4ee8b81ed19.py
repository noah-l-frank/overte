import ast,hashlib,json,shutil,difflib,pstats
from pathlib import Path
R=Path.cwd();P=R/'.ios-host-tmp/emote-callback-live-prefix-external-parser-policy-source-complete-20261102';D=R/'.ios-host-tmp/emote-callback-live-prefix-external-parser-policy-source-draft-20261102'
assert not (P/'freeze.json').exists()
for n in ('base','candidate'):shutil.copytree(D/n,P/n)
rel='tests/device/ios/adapters/emote_callback_live_records.py';q=P/'candidate'/rel;s=q.read_text().replace('import re,sys,enum,__future__,socket','import re,sys,enum,__future__,socket,functools\nfrom _collections import _tuplegetter')
s=s.replace("    if kind is BuiltinFunctionType:return ('builtin',identity)","""    if kind is functools.cached_property:
        # Exact stdlib descriptor state only, not arbitrary __get__ objects.
        if set(vars(value))!={'func','attrname','__doc__','__module__'}:raise _Unsupported(kind,'cached-property-state')
        return ('cached-property',identity,token(value.func),token(value.attrname),token(value.__doc__),token(value.__module__))
    if kind is BuiltinFunctionType:return ('builtin',identity)""")
s=s.replace("_PNG_CLASSES=(Image.Image,ImageFile.ImageFile,PngImagePlugin.PngImageFile,PngImagePlugin.PngStream,PngImagePlugin.ChunkStream)","""EXTERNAL_READERS+=((json,'decoder'),(json,'encoder'),(json.decoder,'scanner'),(json.decoder,'c_scanstring'),
    (Image,'_getencoder'),(Image,'Image'),(Image,'ImageMode'),(ImageMode,'ModeDescriptor'),(ImageMode,'sys'),
    (Image.core,'raw_encoder'),(Image.core,'fill'),(Image.core,'blend'),(ImageFile,'Image'),(ImageFile,'_Tile'),
    (PngImagePlugin,'Image'),(PngImagePlugin,'ImageFile'),(PngImagePlugin,'zlib'),
    (_binary,'i32le'),(ImageStat,'Stat'),(ImageStat,'Image'),(ImageStat,'math'),(math,'sqrt'),
    (ImageChops,'Image'),(ImageChops,'lighter'),(functools,'cached_property'),
    (functools.cached_property,'__get__'),(functools.cached_property,'__set_name__'))
_PNG_CLASSES=(Image.Image,ImageFile.ImageFile,PngImagePlugin.PngImageFile,PngImagePlugin.PngStream,PngImagePlugin.ChunkStream,ImageStat.Stat)


def _parser_global_bindings(function,references):
    # Only actual referenced global aliases of these closed dispatch probes and
    # generated namedtuple constructors. No all-globals/opaque object admission.
    if type(function) is not FunctionType:raise _Unsupported(type(function),'parser-function')
    return tuple((name,_token(function.__globals__[name],references,set()))
        for name in sorted(set(function.__code__.co_names)&function.__globals__.keys())
        if name!='__builtins__')


def _namedtuple_policy(cls,fields,references):
    if cls._fields!=fields:raise _Unsupported(type(cls),'namedtuple-fields')
    refs=[]
    for name in fields:
        descriptor=vars(cls).get(name)
        if type(descriptor) is not _tuplegetter:raise _Unsupported(type(descriptor),'namedtuple-field')
        references.append(descriptor);refs.append((name,id(descriptor)))
    return (_token(cls,references,set()),_token(cls.__new__,references,set()),
        _parser_global_bindings(cls.__new__,references),_token(cls._field_defaults,references,set()),tuple(refs))""")
s=s.replace("    if 'zip' in Image.DECODERS:raise _Unsupported(type(Image.DECODERS['zip']),'png-custom-decoder')","""    if any(name in Image.DECODERS for name in ('zip','raw')):raise _Unsupported(dict,'png-custom-decoder')
    if 'raw' in Image.ENCODERS:raise _Unsupported(type(Image.ENCODERS['raw']),'png-custom-encoder')
    probes=[]
    if type(Image.ID) is not list or 'PNG' not in Image.ID:raise _Unsupported(type(Image.ID),'png-dispatch-order')
    for format_name in Image.ID[:Image.ID.index('PNG')+1]:
        if type(format_name) is not str:raise _Unsupported(type(format_name),'png-dispatch-format')
        probe=Image.OPEN.get(format_name)
        if type(probe) is not tuple or len(probe)!=2 or type(probe[1]) is not FunctionType:
            raise _Unsupported(type(probe),'png-dispatch-probe')
        probes.append((format_name,token(probe),_parser_global_bindings(probe[1],references)))
    # cached_property's sentinel is bound by identity and retained, never
    # admitted as a general object policy value.
    references.append(functools._NOT_FOUND)
    descriptor_sentinel=(id(functools._NOT_FOUND),type(functools._NOT_FOUND).__module__,type(functools._NOT_FOUND).__qualname__)
    namedtuples=(_namedtuple_policy(ImageMode.ModeDescriptor,('mode','bands','basemode','basetype','typestr'),references),
        _namedtuple_policy(ImageFile._Tile,('codec_name','extents','offset','args'),references))""")
s=s.replace("return token(entry),tuple(classes),tuple((key,token(modes[key])) for key in sorted(modes))","return token(entry),tuple(probes),tuple(classes),namedtuples,descriptor_sentinel,tuple((key,token(modes[key])) for key in sorted(modes))")
q.write_text(s)
trel='tests/device/ios/self_tests/test_ios_emote_callback_live_history_cache.py';t=P/'candidate'/trel
extra='''
    def test_actual_image_stat_cached_property_code_change_cannot_borrow_warm_measurement(self):
        from PIL import Image,ImageStat
        self.file=self.root/'actual-stat-original.png';Image.new('L',(2,2),20).save(self.file);self.file.chmod(0o600)
        with Image.open(self.file) as image:image.load()
        self.history=CallbackLiveRecords();self.owner._historical_rows=self.history
        self.assertTrue(self.history.literal(),repr(self.history.unsupported_members()))
        def parse():
            self.calls+=1;record(self.file)
            with Image.open(self.file) as image:return ImageStat.Stat(image).mean
        first=self.history.read(self.owner,self.reference,parse);self.assertEqual([20.0],first);self.assertEqual(2,self.calls)
        descriptor=vars(ImageStat.Stat)['mean'];function=descriptor.func;code=function.__code__
        def changed(self):return [-123.0]
        function.__code__=changed.__code__
        try:
            self.assertIs(vars(ImageStat.Stat)['mean'].func,function);self.assertFalse(self.history.literal())
            self.assertEqual([-123.0],self.history.read(self.owner,self.reference,parse))
        finally:function.__code__=code
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())
        self.assertEqual(first,self.history.read(self.owner,self.reference,parse));self.assertEqual(3,self.calls)

    def test_actual_raw_encoder_registry_change_cannot_borrow_warm_original_pixels(self):
        from PIL import Image
        self.file=self.root/'actual-encoder-original.png';Image.new('RGBA',(2,2),(20,30,40,255)).save(self.file);self.file.chmod(0o600)
        with Image.open(self.file) as image:image.load()
        self.history=CallbackLiveRecords();self.owner._historical_rows=self.history
        self.assertTrue(self.history.literal(),repr(self.history.unsupported_members()))
        def parse():
            self.calls+=1;record(self.file)
            with Image.open(self.file) as image:image.load();return image.tobytes()
        first=self.history.read(self.owner,self.reference,parse);self.assertEqual(2,self.calls)
        def changed(*args):raise RuntimeError('Declared changed actual raw encoder dispatch')
        with patch.dict(Image.ENCODERS,{'raw':changed}):
            self.assertFalse(self.history.literal())
            with self.assertRaisesRegex(RuntimeError,'Declared changed actual raw encoder dispatch'):self.history.read(self.owner,self.reference,parse)
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())
        self.assertEqual(first,self.history.read(self.owner,self.reference,parse));self.assertEqual(3,self.calls)
'''
t.write_text(t.read_text()+extra)
for f in P.rglob('*.py'):ast.parse(f.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for f in sorted((P/'candidate').rglob('*.py')):
 r=f.relative_to(P/'candidate');rows.append(dict(path=str(r),baseSHA256=sha(P/'base'/r),candidateSHA256=sha(f)))
parts=[]
for row in rows:
 r=row['path'];parts.extend(difflib.unified_diff((P/'base'/r).read_text().splitlines(True),(P/'candidate'/r).read_text().splitlines(True),fromfile='a/'+r,tofile='b/'+r))
(P/'source.diff').write_text(''.join(parts))
profile=R/'.ios-host-tmp/emote-complete-live747-supported-readonly-profile-preparation-20261029/runs/profile1/first-o24euytu/actual-decoders.pstats'
ps=pstats.Stats(str(profile));functions=[]
for (filename,line,name),v in sorted(ps.stats.items()):
 if '/PIL/' in filename or '/json/' in filename:functions.append(dict(file=filename,line=line,function=name,primitiveCalls=v[0],totalCalls=v[1],cumulativeSeconds=v[3]))
(P/'actual-old-profile-external-functions.json').write_text(json.dumps(dict(source=str(profile),sha256=sha(profile),metadataOnly=True,oldFramesReplayed=False,functions=functions),indent=2)+'\n')
old=json.loads((D/'plan.json').read_text());old.update(status='PRIVATE_UNRUN_ROOT_SOURCE_REVIEW_REQUIRED',previousDraftFreeze=sha(D/'freeze.json'),sourceRows=rows,mechanismCases=25,closedDependencies='Exact JSON default instances/C scanner fields and function/global bindings; actual PNG class methods, cached_property schema/sentinel, generated namedtuple fields/constructor globals, raw/ZIP decoder and raw encoder dispatch, ordered accept probes, mode/binary/CRC/limits and statistics/math bindings. Custom decoders/encoder/descriptor or unknown policy remains literal fallback.',testsRun=False,targetImports=False,publicMutations=False)
external=set(x['path'] for x in old['externalSourcePins'])|{'/usr/lib64/python3.14/functools.py','/usr/lib64/python3.14/site-packages/PIL/ImageStat.py','/usr/lib64/python3.14/site-packages/PIL/ImageChops.py','/usr/lib64/python3.14/site-packages/PIL/BmpImagePlugin.py','/usr/lib64/python3.14/site-packages/PIL/GifImagePlugin.py','/usr/lib64/python3.14/site-packages/PIL/JpegImagePlugin.py','/usr/lib64/python3.14/site-packages/PIL/PpmImagePlugin.py'}
old['externalSourcePins']=[dict(path=p,sha256=sha(Path(p))) for p in sorted(external)]
(P/'plan.json').write_text(json.dumps(old,indent=2)+'\n')
files={str(f.relative_to(P)):sha(f) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='freeze.json'}
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files=files),indent=2)+'\n')
print(json.dumps(dict(freeze=sha(P/'freeze.json'),rows=rows,cases=25,diffLines=len(parts))))
