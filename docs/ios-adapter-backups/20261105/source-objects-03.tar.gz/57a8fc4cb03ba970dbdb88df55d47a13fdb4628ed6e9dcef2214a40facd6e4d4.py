"""Explicit runtime source cuts and typed retained-carrier inventory.

Default Sources2 and Callback8 selection do not acquire a palette. This private
opt-in acquires only beside actual inherited source cuts. No new input/capture,
unknown-read replay, native-clock replacement or End authority lives here.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as read_scope,collect
from adapters.original_frame_store import BLOCK
from adapters.script_feature.history import same
from ios.adapters.emote_sources import IOSEmoteSources
from ios.adapters.emote_post_controller_sources import IOSEmotePostControllerSources,NAMESPACE
from ios.adapters.emote_observer import EmoteObservationPending
from ios.adapters.emote_session_carriers import inventory


def source_reference(sources,index=None):
    need(isinstance(sources,IOSEmoteSources));sources.lock.assert_held()
    index=sources.state['revision']if index is None else index
    need(type(index)is int and 1<=index<=sources.state['revision'])
    entries=sources.originals.manifest(sources.state['manifests'][(index-1)//BLOCK])
    value=sources.originals.expand(entries[(index-1)%BLOCK])
    sources.originals.read(value)
    return deepcopy(value)


class IOSEmotePostControllerRuntimeSources(IOSEmoteSources):
    def __init__(self,*args,palette,**kwargs):
        super().__init__(*args,**kwargs)
        need(not self.historical and not self.ownership_only)
        self.post_controller=IOSEmotePostControllerSources(
            PrivateFeatureState(self.store.path.with_name('ios-emote-'+self.role+'-post-controller-sources.json')),
            self,guard=self.guard,phase=self.phase,native=self.readers['native'],palette=palette,
            epoch_ms=self.epoch_ms,monotonic=self.monotonic)

    def read(self):
        # A new Source acquisition must not run ahead of an uncertain palette
        # request. Recovery of a complete old original is a separate API.
        self.post_controller.bound();need(self.post_controller.state['phase']=='ready')
        value=super().read()
        ref=self.post_controller.read(source_reference(self))
        self.stable_post_controller(ref)
        return value

    def stable_post_controller(self,reference):
        """A valid retained original may still have crossed an input phase."""
        return stable_original(self.post_controller,reference)


def stable_original(owner,reference):
    need(type(owner)is IOSEmotePostControllerSources)
    original=owner.original(reference)
    previous=owner.frames[reference['index']-2]if reference['index']>1 else None
    need(owner.validate_frame(original,previous)is True)
    return original


def family_paths(sources):
    need(isinstance(sources,IOSEmoteSources));sources.lock.assert_held()
    metadata=sources.store.path.with_name('ios-emote-'+sources.role+'-post-controller-sources.json')
    # Unknown names in this exact owned namespace are not hidden by narrower
    # run/role pattern matching. They must be decoded or remain a refusal.
    result=set(sources.root.glob(NAMESPACE+'-*'))
    if metadata.exists():result.add(metadata)
    return result


class IOSEmotePostControllerInventory:
    """Actual historical constructors and OFS membership, never a DTO verdict."""
    def __init__(self,sources):
        need(isinstance(sources,IOSEmoteSources));sources.lock.assert_held()
        self.sources=sources;self.paths=family_paths(sources)
        path=sources.store.path.with_name('ios-emote-'+sources.role+'-post-controller-sources.json')
        self.owner_path=path;self.owner=None;self.manifest=None;self.reads=set();self.stable=[]
        # Local collection proves only this typed decoder's actual reads;
        # sharing the outer membership scope keeps its real terminal receipt.
        with collect()as reads,read_scope():
            value=PrivateFeatureState(path).read()
            if value is None:need(not self.paths)
            else:
                archived=IOSEmoteSources(sources.store,sources.root,sources.binding,sources.run,sources.role,sources.lock,
                    lambda:True,None,historical=True)
                self.owner=IOSEmotePostControllerSources(PrivateFeatureState(path),archived,historical=True)
                need(same(self.owner.previous,value))
                self.manifest=self.owner.retirement_manifest()
                need(self.manifest['runId']==sources.run and self.manifest['role']==sources.role
                    and same(self.manifest['binding'],sources.binding)and self.manifest['metadataRetirementAllowed']is False
                    and self.manifest['finishAllowed']is False and self.manifest['nativeProcessLifetimeRequired']is True)
                # Decoding grammar is not stable-effect consumption. Every
                # original remains readable even if this flag is false.
                self.stable=[self.owner.validate_frame(frame,self.owner.frames[i-1]if i else None)is True
                    for i,frame in enumerate(self.owner.frames)]
            self.reads=set(reads)
        need(family_paths(sources)==self.paths and self.paths<=self.reads)

    def bound(self):
        self.sources.lock.assert_held();need(family_paths(self.sources)==self.paths)
        if self.owner is None:need(PrivateFeatureState(self.owner_path).read()is None)
        else:
            need(same(self.owner.store.read(),self.owner.previous))
            need(same(self.owner.retirement_manifest(),self.manifest))
        return True

    def require_implemented_end(self):
        self.bound()
        if self.owner is not None:
            raise EmoteObservationPending('Post-controller originals retain native-file/process/SDK retirement responsibility; this End profile is unimplemented')
        return True


def callback_inventory(flow,parts):
    """Primary-source bindings also remain primary for an Actor role reader."""
    sources=parts['sources'];flow.lock.assert_held();flow.primary_lock.assert_held()
    need(isinstance(sources,IOSEmoteSources))
    if not family_paths(sources):return IOSEmotePostControllerInventory(sources)
    need(isinstance(sources,IOSEmoteSources)and sources.role==flow.role and sources.run==flow.run
        and sources.lock is flow.primary_lock and same(sources.binding,flow.state['primaryBinding'])
        and sources.store.path==flow.runtime.state_path(flow.primary_selector).with_name('ios-emote-'+flow.role+'-sources.json'))
    return IOSEmotePostControllerInventory(sources)


def block_callback_end(terminal):
    """No current/copy/fence/Stop route can omit this known unsupported family."""
    from ios.adapters.emote_callback_terminal import IOSEmoteCallbackTerminal,IOSEmotePostControllerCallbackTerminal
    need(type(terminal)in(IOSEmoteCallbackTerminal,IOSEmotePostControllerCallbackTerminal))
    roots=set()
    for flow in(terminal.flow,terminal.actor):
        flow.lock.assert_held();flow.primary_lock.assert_held()
        roots.update((flow.root,flow.store.path.parent,flow.primary_lock.path.parent))
    return require_no_post_controller_carriers(roots)


def require_no_post_controller_carriers(roots):
    """Refusal only: absence here grants no fence, Stop or deletion permit."""
    found=inventory(roots)
    if any(path.name.startswith(NAMESPACE+'-')or
            path.name in('ios-emote-primary-post-controller-sources.json','ios-emote-actor-post-controller-sources.json')for path in found):
        raise EmoteObservationPending('Retained post-controller family has no implemented process/SDK/native-file End composition')
    return True


def block_callback_stop(owner):
    from ios.adapters.emote_callback_process_end import IOSEmoteCallbackProcessEnd
    need(type(owner)is IOSEmoteCallbackProcessEnd);owner.bound()
    roles=owner.ownership.roles;roots=set()
    for role,lock in roles.locks.items():
        lock.assert_held();roots.add(lock.path.parent)
        value=roles.copies[str(lock.path.with_name('ios-emote-'+role+'-feature.json'))]
        need(value['runId']==owner.run and value['role']==role)
        root=Path(value['artifactRoot']);PrivateFeatureState(root/'post-controller-end-boundary')._parent();roots.add(root)
    return require_no_post_controller_carriers(roots)
