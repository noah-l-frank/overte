"""Prospective sparse host diagnostics. All cases remain UNRUN.

Static counters inspect the actual source AST, not a reimplemented predicate.
Publisher counters use the existing declared raw-product decoder and genuine
Phase HTTP/WAL/lock producers. The connected case uses the actual Current7 path.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import ast,time,unittest
from copy import deepcopy
from pathlib import Path
from adapters.normal_ui import NativeUIError
from adapters.phase_publication_refusal_original import PublicationRefusalOriginal
from adapters.lifecycle_sparse_host_diagnostic import LifecycleSparseHostDiagnostic
from self_tests.test_phase_witness_publisher import PhaseWitnessPublisherTests
from test_lifecycle_publisher_refusal_original_diagnostic_models import LifecyclePublisherRefusalOriginalDiagnosticModels

REPO=Path.cwd().resolve(strict=True)
NEW=REPO/'.ios-host-tmp/lifecycle-post-acquisition-sparse-host-phases-source2-private-20261103/candidate/tests/device'
OLD=REPO/'.ios-host-tmp/lifecycle-retained-owner-literal-index-inventory-source-proposal-20261103/candidate/tests/device'
PUB=REPO/'.ios-host-tmp/lifecycle-publisher-refusal-local-original-diagnostic-source-proposal-20261103/candidate/tests/device'
def tree(root,name):return ast.parse((root/name).read_text())
def dump(value):return ast.dump(value,include_attributes=False)
def method(root,name,cls,function):
 return next(node for parent in tree(root,name).body if type(parent)is ast.ClassDef and parent.name==cls
     for node in parent.body if type(node)is ast.FunctionDef and node.name==function)
def calls(node,name):
 return [value for value in ast.walk(node)if type(value)is ast.Call and type(value.func)is ast.Attribute and value.func.attr==name]


class LifecycleSparseSourceBoundaryTests(unittest.TestCase):
 def test_both_original_predicates_and_finally_refusal_guards_are_exact(self):
  old=method(PUB,'adapters/phase_witness_publisher.py','PhaseWitnessPublisher','publish')
  new=method(NEW,'adapters/phase_witness_publisher.py','PhaseWitnessPublisher','publish')
  conditions=lambda value:[dump(node.value)for node in ast.walk(value)if type(node)is ast.Assign
      and any(type(target)is ast.Name and target.id=='admitted'for target in node.targets)]
  self.assertEqual(conditions(old),conditions(new));self.assertEqual(2,len(conditions(new)))
  need_conditions=lambda value:[dump(node)for node in ast.walk(value)if type(node)is ast.Call
      and type(node.func)is ast.Name and node.func.id=='need']
  self.assertEqual(need_conditions(old),need_conditions(new))
  for node in ast.walk(new):
   if type(node)is ast.Try and node.finalbody and any(type(item)is ast.Expr
       and type(item.value)is ast.Call and type(item.value.func)is ast.Name
       and item.value.func.id=='need'for item in node.finalbody):
    self.assertEqual('admitted',node.finalbody[0].value.args[0].id)

 def test_acquisition_assignments_and_all_existing_clock_and_policy_calls_are_unchanged(self):
  a=method(OLD,'ios/adapters/lifecycle_observer.py','LifecycleObserver','observe')
  b=method(NEW,'ios/adapters/lifecycle_observer.py','LifecycleObserver','observe')
  assignments=lambda value:[dump(node)for node in ast.walk(value)if type(node)is ast.Assign and any(
      type(target)is ast.Name and target.id in('started','acquisition')for target in node.targets)]
  self.assertEqual(assignments(a),assignments(b))
  for name in('epoch_ms','monotonic','current','read'):
   self.assertEqual([dump(x)for x in calls(a,name)],[dump(x)for x in calls(b,name)])
  for function in('admitted','memo_allowed'):
   a=method(OLD,'ios/adapters/lifecycle_publication_read_phase.py','ParserPolicy'if function=='admitted'else'LifecyclePublicationReadPhase',function)
   b=method(NEW,'ios/adapters/lifecycle_publication_read_phase.py','ParserPolicy'if function=='admitted'else'LifecyclePublicationReadPhase',function)
   # Opt-in and literal branches each have the same old expression; no call is repeated in a taken branch.
   if function=='admitted':self.assertEqual(len(calls(a,'compare')),len(calls(b,'compare')))
   else:
    original=next(node.value for node in a.body if type(node)is ast.Return)
    self.assertEqual(2,sum(dump(node)==dump(original)for node in ast.walk(b)))

 def test_default_none_publish_scope_and_memo_expressions_remain_literal(self):
  a=method(OLD,'ios/adapters/lifecycle_observer.py','LifecycleObserver','publish_latest')
  b=method(NEW,'ios/adapters/lifecycle_observer.py','LifecycleObserver','publish_latest')
  original=next(node for node in a.body if type(node)is ast.With)
  default=next(node for node in b.body if type(node)is ast.If)
  self.assertEqual(dump(original),dump(default.body[0]))
  self.assertEqual('self.sparse_diagnostic is None',ast.unparse(default.test))

 def test_event_writer_cannot_touch_native_phase_clock_or_files_before_finish(self):
  module=tree(NEW,'adapters/lifecycle_sparse_host_diagnostic.py')
  cls=next(node for node in module.body if type(node)is ast.ClassDef)
  for node in cls.body:
   if type(node)is ast.FunctionDef and node.name in('begin','event','decision','phase_enter','phase_exit','refused'):
    names={call.func.attr for call in ast.walk(node)if type(call)is ast.Call and type(call.func)is ast.Attribute}
    self.assertFalse(names&{'read','write','current','request','bound','admitted','monotonic','epoch_ms'})
  finish=next(node for node in cls.body if type(node)is ast.FunctionDef and node.name=='finish')
  guard=next(node for node in finish.body if type(node)is ast.If)
  self.assertEqual('self.refusal is None',ast.unparse(guard.test));self.assertIsInstance(guard.body[0],ast.Return)
  self.assertEqual(1,len(calls(finish,'write')))


class LifecycleSparsePublisherRefusalBoundaryTests(PhaseWitnessPublisherTests):
 def test_actual_expired_original_stays_refused_with_default_none_and_no_post(self):
  self.attach('lifecycle-input')
  with self.lock.held():
   owner=self.owner();self.assertIsNone(owner.sparse_diagnostic);original=self.original()
   retained=deepcopy(self.known);time.sleep(1.55)
   with self.assertRaises(NativeUIError):owner.publish(original)
   self.assertEqual(retained,self.known);self.assertEqual([],self.server.journal.snapshot(self.run)['entries'])
   self.assertEqual('planned',owner.state['pending']['phase'])

 def test_original_false_refuses_even_when_post_capture_observer_raises(self):
  self.attach('lifecycle-input')
  class BrokenObserver:
   def event(self,*args):pass
   def refused(self,*args):raise RuntimeError('Actual post-false observer failure')
  with self.lock.held():
   owner=self.owner();sink=PublicationRefusalOriginal(self.root/'publication-refusal-original.json',owner.binding,self.run).bind(owner)
   owner.refusal_original=sink;owner.sparse_diagnostic=BrokenObserver();original=self.original()
   retained=deepcopy(self.known);time.sleep(1.55)
   with self.assertRaises(NativeUIError)as caught:owner.publish(original)
   self.assertIsInstance(caught.exception.__context__,RuntimeError)
   self.assertTrue(sink.written);self.assertIs(False,sink.store.read()['condition'])
   self.assertEqual(retained,self.known);self.assertEqual([],self.server.journal.snapshot(self.run)['entries'])
   self.assertEqual('planned',owner.state['pending']['phase'])


class LifecycleSparseConnectedOriginalModels(LifecyclePublisherRefusalOriginalDiagnosticModels):
 async def test_actual_post_acquisition_events_and_existing_policy_decisions_are_retained_only_after_original_refusal(self):
  self._capture_sparse_host_phases=True
  await self.test_actual_already_read_publisher_refusal_locals_without_clock_or_phase_reread()
  recorder=self.sparse_host_diagnostic
  if self.publication_refusal_original.written:
   packet=recorder.store.read();self.assertTrue(recorder.completed)
   events=packet['events'];self.assertEqual('acquisition-complete',events[0]['stage'])
   self.assertEqual(list(range(1,len(events)+1)),[row['sequence']for row in events])
   self.assertEqual(sorted(row['hostPerfCounterNs']for row in events),[row['hostPerfCounterNs']for row in events])
   self.assertEqual(1,len({row['threadId']for row in events}))
   self.assertEqual(1,sum(row['stage']=='original-refusal'for row in events))
   self.assertIsNone(recorder.phase.cache.rows.get('not-an-admission-key'))
   self.assertEqual({},recorder.phase.cache.rows);self.assertFalse(recorder.phase.active)
   for row in events:
    if row['stage']in('policy-admitted','memo-allowed'):self.assertIs(type(row['value']),bool)
   with self.assertRaises(NativeUIError):recorder.event(recorder.observer,'publish-latest-enter')
  else:
   self.assertFalse(recorder.completed);self.assertIsNone(recorder.store.read())

 async def test_unbound_foreign_recorder_cannot_become_an_original_owner_or_write_a_result(self):
  import os
  path=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/'publication-post-acquisition-events.json'
  recorder=LifecycleSparseHostDiagnostic(path)
  with self.assertRaises(NativeUIError):recorder.bind(object(),object(),object())
  self.assertIsNone(recorder.store.read());self.assertEqual([],recorder.events)
