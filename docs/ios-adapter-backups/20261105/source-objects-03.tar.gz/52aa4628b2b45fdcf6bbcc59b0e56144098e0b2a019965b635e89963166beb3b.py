"""One continuous original Actor WAV joined to once inputs and Primary history.

Derived frame indices never become ADC age. Whole WAV/capture bytes, native
read hashes and original offsets remain untouched. Native fixture/code/process
qualification remains separate from host grammar and sample-pattern evidence.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import array
from copy import deepcopy
import hashlib
import io
import sys
import wave
from adapters.native_feature_observation import exact,integer,need
from adapters.script_feature.history import same
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters import audio_once_cue_source as once
from ios.adapters.audio_once_cue_signal import analyze_channels
from ios.adapters import audio_acoustic_window as windows
from ios.adapters import audio_once_primary as primary
from ios.adapters.audio_pcm_lease import IOSAudioPCMLease


def derive(owner,cue_ref,pattern_ref,primary_ref):
    need(owner.version==2 and owner.state['snapshot'] is not None and owner.state['absence'] is not None)
    owner.passive_retired();ticket=owner.state['once']['ticket']
    snapshot=owner.proof(owner.state['snapshot']);value=owner.snapshot()
    raw=owner.assembled(snapshot['chunks']['capture'],'capture',snapshot['selection'],owner.state['snapshot'])
    pair=windows.analyze_native(raw,value['wav'],owner.state['capture'],owner.pid,owner.run,ticket)
    with wave.open(io.BytesIO(value['wav']),'rb') as stream:
        data=array.array('h');data.frombytes(stream.readframes(stream.getnframes()))
        if sys.byteorder!='little':data.byteswap()
        channels=[data[index::stream.getnchannels()] for index in range(stream.getnchannels())]
        cue=analyze_channels(channels,stream.getframerate(),owner.run,ticket)
    selected=[row for row in cue['matches'] if row['channel']==pair['matchedChannel']]
    need(len(selected)==1 and selected[0]['endFrame']<=pair['copies'][0]['beginFrame'])
    for kind,reference in (('cue',cue_ref),('pattern',pattern_ref)):
        proof=owner.proof(reference);need(proof['kind']=='once-reply' and proof['inputKind']==kind)
        intent=owner.proof(proof['intent']);once.finished_input(proof['packet'],intent['command'],owner.pid,owner.fixture_url)
        if kind=='cue':need(proof['packet']['pcmSha256']==cue['expectedNativeInputPCMSha256'])
    returned=owner.proof(primary_ref);need(returned['kind']=='once-primary-returned')
    authorized=owner.proof(returned['value']['authorization']);need(authorized['kind']=='once-primary-authorized')
    parent,_operation,_after=primary.returned(owner,returned['value'],authorized['value'])
    lease=IOSAudioPCMLease.archive(PrivateFeatureState(parent.store.path.with_name('ios-audio-pcm-lease.json')),parent)
    original=windows.primary_original(lease,owner.run,ticket)
    return pair|dict(cueOriginal=cue,primaryOriginal=original,onceCueReply=cue_ref,oncePatternReply=pattern_ref,
        primaryReturnedReference=primary_ref,primaryPCMReference=deepcopy(lease.state['snapshot']),
        actorSnapshotReference=owner.state['snapshot'],actorAbsenceReference=owner.state['absence'],
        unmetCausalRequirements=[],physicalADCQualified=False,physicalOutputQualified=False,acousticQualified=False,
        peerQualified=False,nativeQualified=False,wholeQualified=False,
        qualificationRequired=['actual-native-build-and-caller-profile','actual-independent-device-acoustics','original-process-end-for-residual-cache-PCM'])


def validate_original(owner,value,ordinal):
    need(type(value) is dict)
    for key in ('onceCueReply','oncePatternReply','primaryReturnedReference','actorSnapshotReference','actorAbsenceReference'):
        need(integer(value.get(key),1,ordinal-1))
    need(value['actorSnapshotReference']==owner.state['snapshot'] and value['actorAbsenceReference']==owner.state['absence'])
    expected=derive(owner,value['onceCueReply'],value['oncePatternReply'],value['primaryReturnedReference'])
    need(same(value,expected));return value


def retain(custody):
    owner=custody.owner;owner.bound();owner.recover_storage()
    existing=[(index,value) for index,value in enumerate(owner.journals['proofs'].restore(),1) if value['kind']=='once-window']
    need(len(existing)<=1)
    if existing:
        index,value=existing[0]
        return dict(original=owner.journals['proofs'].reference(index),derived=deepcopy(value['value']))
    cue,_packet=custody.finished('cue');pattern,_packet=custody.finished('pattern')
    value=derive(owner,cue,pattern,owner.state['once']['primaryReturned'])
    reference=owner.journals['proofs'].append(dict(kind='once-window',value=value))
    return dict(original=reference,derived=deepcopy(value))
