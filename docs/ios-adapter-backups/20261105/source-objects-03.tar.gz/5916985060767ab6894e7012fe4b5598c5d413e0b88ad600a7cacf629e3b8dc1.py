"""Private common Audio action route with independent Actor10 custody.

Ordinary Primary normal_act/authorization/history remain authoritative. Cue and
Actor input-pattern are separate once inputs. Product preview is automatic;
there is no Stop/Save/Preview command or modified product timer. Waits happen
outside both SDK locks under the existing outer API budget.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
import time
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import arguments
from ios.adapters.audio_api_clock import operation
from ios.adapters.audio_passive_runtime import IOSAudioPassiveRuntime,PassiveSDKLedger
from ios.adapters.audio_runtime import IOSAudioRuntime
from ios.adapters.audio_once_primary import paired_sdk_locks
from ios.adapters.audio_once_window import retain


class IOSAudioOnceJourney:
    def __init__(self,actor_runtime,actor_selector,primary_runtime,primary_selector,run,actor_root,primary_root,client,*,
                 epoch_ms=lambda:time.time()*1000,monotonic=time.monotonic,sleep=time.sleep,source_locks=None):
        need(isinstance(actor_runtime,IOSAudioPassiveRuntime) and isinstance(primary_runtime,IOSAudioRuntime)
            and all(callable(fn) for fn in (epoch_ms,monotonic,sleep)))
        self.actor_runtime,self.actor_selector=actor_runtime,actor_selector
        self.primary_runtime,self.primary_selector=primary_runtime,primary_selector
        self.run,self.actor_root,self.primary_root,self.client=run,Path(actor_root),Path(primary_root),client
        self.epoch_ms,self.monotonic,self.sleep=epoch_ms,monotonic,sleep
        self.source_locks=source_locks or (ScriptSourceLock(actor_runtime.state_path(actor_selector).with_name('script-feature-sources.lock')),
            ScriptSourceLock(primary_runtime.state_path(primary_selector).with_name('script-feature-sources.lock')))

    @contextmanager
    def paired(self):
        with paired_sdk_locks(self.actor_runtime,self.actor_selector,self.primary_runtime,self.primary_selector,source_locks=self.source_locks) as (actor_lock,primary_lock):
            with self.primary_runtime.recorded_owner(self.primary_selector,self.run,self.primary_root,self.client,source_lock=primary_lock,
                    epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep) as recorded:
                yield actor_lock,recorded

    def current_ticket(self,lock):
        """Only actual typed parent originals select an existing episode."""
        path=self.actor_runtime.state_path(self.actor_selector).with_name('ios-audio-passive-ledger.json')
        value=PrivateFeatureState(path).read()
        if value is None:return None
        need(type(value) is dict and type(value.get('leases')) is list)
        if not value['leases']:return None
        lease=value['leases'][-1]['leaseId']
        ledger=PassiveSDKLedger(self.actor_runtime,self.actor_selector,self.run,lease,self.actor_root,self.client,lock)
        ledger.transfer_completed();owner=ledger.archives.get(lease)
        if owner is None or owner.version!=2:return None
        return owner.state['once']['ticket']

    @contextmanager
    def episode(self,ticket,lock):
        with self.actor_runtime.once_input_owner(self.actor_selector,self.run,ticket,self.actor_root,self.client,
                epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep,source_lock=lock) as custody:yield custody

    def normal(self,recorded,call,profile):
        return self.primary_runtime.normal_act(self.primary_selector,recorded,call,pcm_profile=profile,defer_pcm=call['verb']=='await-completion')

    def close_inputs(self,custody):
        """Close only actual objects; cache/PCM may transfer to SDK parent."""
        for kind in ('cue','pattern'):
            slot=custody.slot(kind)
            if slot['claim'] is None:continue
            _ref,value=custody.control(kind,'observe');packet=value['packet']
            if packet['injectorLive'] or packet['playing'] or not packet['receiverInventoryComplete']:return False
            if packet['scriptFinishedReceivers']!=0 or packet['resourceReadyReceivers']>1:return False
            if slot['retire'] is None:
                custody.control(kind,'retire');return False
            if packet['wrapperLive'] or packet['resourceWrapperLive']:return False
            if slot['release'] is None:
                custody.control(kind,'release');return False
            if not packet['released']:return False
        custody.owner.episode_retired();return True

    @operation
    def act(self,call,*,pcm_profile=None):
        call=deepcopy(arguments('feature.audio.act',call));need(call['runId']==self.run)
        verb=call['verb'];normal_started=False
        while True:
            pending=False
            with self.paired() as (actor_lock,recorded):
                if verb=='record-start':
                    # The actual current Primary source chooses the muted
                    # branch. Expected scenario state is never an input.
                    if self.current_ticket(actor_lock)!=call['ticket']:
                        reference=recorded.capture(call['ticket'],'record-start')
                        observation=recorded.original(reference)
                        if observation['originals']['native']['audio']['muted']:
                            return self.normal(recorded,call,pcm_profile)
                    with self.episode(call['ticket'],actor_lock) as custody:
                        if custody.slot('cue')['claim'] is None:custody.start_input('cue')
                        _index,current=custody.control('cue','observe')
                        if not current['packet']['finished']:pending=True
                        else:
                            custody.finished('cue')
                            result=custody.start_recording(self.primary_runtime,self.primary_selector,recorded,call,pcm_profile=pcm_profile)
                            custody.start_input('pattern')
                            return result
                else:
                    ticket=self.current_ticket(actor_lock)
                    result=None
                    if not normal_started:
                        result=self.normal(recorded,call,pcm_profile);normal_started=True
                    if ticket is None:return result if result is not None else self.normal(recorded,call,pcm_profile)
                    with self.episode(ticket,actor_lock) as custody:
                        owner=custody.owner
                        if verb=='await-completion':
                            _ref,current=custody.control('pattern','observe')
                            if not current['packet']['finished']:pending=True
                            else:
                                custody.finished('pattern');_ref,actual=owner.control('observe')
                                if not actual['packet']['source']['state']['complete']:pending=True
                                else:
                                    owner.capture();owner.retire(passive_only=True)
                                    # Actual new native PCM acquisition follows the
                                    # completed independent original. No saved
                                    # snapshot timestamp is refreshed.
                                    from ios.adapters.audio_pcm_runtime import lease
                                    pcm=lease(self.primary_runtime,self.primary_selector,recorded,profile=pcm_profile)
                                    pcm.capture();pcm.retire()
                                    retain(custody)
                        elif verb in ('record-cancel','mute','background-resume','close'):
                            owner.retire(passive_only=True)
                        else:return result if result is not None else self.normal(recorded,call,pcm_profile)
                        if not pending and not self.close_inputs(custody):pending=True
                        if not pending:return self.normal(recorded,call,pcm_profile)
            # No SDK lock survives this wait. A subsequent ordinary Primary
            # observation is genuinely fresh; no saved result is retimed.
            self.sleep(.1)

    @contextmanager
    def process_end_scope(self):
        """Yield the exact predeclared final Original-Keeper End scope.

        No Primary or Actor fresh Source is constructed here. The caller uses
        the actual IOSOriginalKeeperProcessEnd factory with these scope values,
        obtains its original one-send Stop/quiet/provider/SDK close proof, and
        calls ledger.finish_process_end(end) inside this same held scope.
        """
        with paired_sdk_locks(self.actor_runtime,self.actor_selector,self.primary_runtime,self.primary_selector,
                source_locks=self.source_locks) as (actor_lock,_primary_lock):
            value=PrivateFeatureState(self.actor_runtime.state_path(self.actor_selector).with_name('ios-audio-passive-ledger.json')).read()
            need(type(value) is dict and value.get('leases'));lease=value['leases'][-1]['leaseId']
            ledger=PassiveSDKLedger(self.actor_runtime,self.actor_selector,self.run,lease,self.actor_root,self.client,actor_lock)
            parameters=ledger.prepare_process_end();yield ledger,parameters

    def finish_process(self,*,peers=()):
        """Actual Python Original-Keeper one-send End, never a supplied DTO."""
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
        with self.process_end_scope() as (ledger,parameters):
            end=IOSOriginalKeeperProcessEnd(self.actor_runtime,self.actor_selector,parameters['root'],parameters['binding'],
                self.run,'actor',0,'audioonce',parameters['lock'],epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep)
            end.finish(peers=peers)
            return ledger.finish_process_end(end)
