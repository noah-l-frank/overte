"""Finite actual defining-module/class/function/decorator custody, no authority.

The manifest is derived from pinned source ASTs. A foreign wrapper is accepted
only at its exact declared decorator position and genuine factory code/closure.
No stack search, simulated module/spec/frame, or foreign-globals exemption.
"""
from pathlib import Path
import ast,contextlib,sys,types

class DefinitionCustody:
    def __init__(self,inventory,plan,pin):
        self.inventory,self.plan,self.pin=inventory,plan,pin
        self.rows=[];self.aliases=[];self.class_tables=[];self.code_objects=[];self.method_aliases=[];self.property_rows=[]
        self.implementation=tuple((n,f,f.__code__,f.__globals__)for n,f in type(self).__dict__.items()if type(f)is types.FunctionType)
        self.context_factory=contextlib.contextmanager
        self.context_code=self.context_factory.__code__;self.context_globals=self.context_factory.__globals__
        self.context_manager=contextlib._GeneratorContextManager;self.context_base=contextlib._GeneratorContextManagerBase
        self.context_members=tuple((c,n,f,f.__code__,f.__globals__)for c in(self.context_manager,self.context_base)for n,f in c.__dict__.items()if type(f)is types.FunctionType)
        for name,declared in inventory.items():
            module=sys.modules[name];namespace=vars(module);path=Path(namespace['__file__'])
            assert str(path)==declared['path']and pin(path)==plan['sourceAndBinaryPins'][str(path)]and pin(path)['sha256']==declared['sha256']
            # Bind source-declared import aliases/control assignments as well as
            # function/class identities; unrelated warning metadata is no port.
            tree=ast.parse(path.read_text());names=set(declared['functions'])|set(declared['classes'])
            for node in tree.body:
                if isinstance(node,ast.Import):names.update(a.asname or a.name.split('.')[0]for a in node.names)
                elif isinstance(node,ast.ImportFrom):names.update(a.asname or a.name for a in node.names if a.name!='*')
                elif isinstance(node,(ast.Assign,ast.AnnAssign)):
                    targets=node.targets if isinstance(node,ast.Assign)else[node.target]
                    names.update(t.id for target in targets for t in ast.walk(target)if isinstance(t,ast.Name))
            for member in sorted(names):
                assert member in namespace
                self.aliases.append((module,name,member,namespace[member]))
            for member,decorators in declared['functions'].items():self.capture(module,member,namespace[member],decorators)
            for clsname,methods in declared['classes'].items():
                cls=namespace[clsname];assert type(cls)is type and cls.__module__==name
                self.class_tables.append((cls,tuple(cls.__dict__.items())))
                for member,decorators in methods.items():
                    descriptor=cls.__dict__[member]
                    function=descriptor.__func__ if type(descriptor)in(staticmethod,classmethod)else descriptor
                    self.capture(module,member,function,[d for d in decorators if d not in('staticmethod','classmethod')],cls,descriptor)
                for member,declaration in declared['classFunctionAliases'].get(clsname,{}).items():
                    descriptor=cls.__dict__[member]
                    assert declaration['kind']in('function','staticmethod','classmethod')
                    assert type(descriptor)is (types.FunctionType if declaration['kind']=='function'else staticmethod if declaration['kind']=='staticmethod'else classmethod)
                    def resolve(node):
                        if type(node)is ast.Name:return namespace[node.id]
                        assert type(node)is ast.Attribute
                        parent=resolve(node.value)
                        assert type(parent)in(types.ModuleType,type)
                        value=vars(parent)[node.attr]
                        return value.__func__ if type(value)in(staticmethod,classmethod)else value
                    expected=resolve(ast.parse(declaration['expression'],mode='eval').body)
                    assert (descriptor if declaration['kind']=='function'else descriptor.__func__)is expected
                    self.method_aliases.append((cls,member,descriptor,declaration['kind'],self.function(expected)))
                for member,accessors in declared['properties'].get(clsname,{}).items():
                    descriptor=cls.__dict__[member];assert type(descriptor)is property and descriptor.fdel is None
                    held=[]
                    for kind,function in(('get',descriptor.fget),('set',descriptor.fset)):
                        assert (function is not None)==accessors.get(kind,False)
                        if function is not None:
                            assert function.__globals__ is namespace and function.__name__==member and not hasattr(function,'__wrapped__')
                            held.append((kind,self.function(function)))
                    self.property_rows.append((cls,member,descriptor,tuple(held)))
        self.control_rows=[]
        # Factory and transport/context controls keep exact actual imported
        # aliases. All declared operation/retry factories are also sealed rows.
        for row in self.rows:
            for factory_row in row['factories']:
                if not any(factory_row[0]is old[0]for old in self.control_rows):self.control_rows.append(factory_row)
        self.check()
    def remember(self,code):
        if not any(code is prior for prior in self.code_objects):
            self.code_objects.append(code)
            for value in code.co_consts:
                if type(value)is types.CodeType:self.remember(value)
    def function(self,fn):
        assert type(fn)is types.FunctionType
        code=fn.__code__;namespace=fn.__globals__;owner=sys.modules[namespace['__name__']]
        assert namespace is vars(owner)
        path=Path(code.co_filename)
        if not path.is_absolute():
            spec=vars(owner)['__spec__'];assert spec.origin=='frozen'and spec.loader is __import__('importlib.machinery',fromlist=['FrozenImporter']).FrozenImporter
            assert code.co_filename=='<frozen '+namespace['__name__']+'>';path=Path(vars(owner)['__file__'])
        assert self.pin(path)==self.plan['sourceAndBinaryPins'][str(path)]
        self.remember(code)
        defaults=fn.__defaults__;keywords=fn.__kwdefaults__;closure=fn.__closure__
        return(fn,code,namespace,owner,getattr(fn,'__wrapped__',None),defaults,tuple(defaults or()),keywords,tuple((keywords or{}).items()),closure,tuple(c.cell_contents for c in closure or()))
    def check_function(self,row):
        fn,code,namespace,owner,wrapped,defaults,values,keywords,items,closure,cells=row
        assert fn.__code__ is code and fn.__globals__ is namespace is vars(owner)and sys.modules.get(namespace['__name__'])is owner
        assert getattr(fn,'__wrapped__',None)is wrapped and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
        assert len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values))
        assert tuple(keywords or())==tuple(k for k,v in items)and all(keywords[k]is v for k,v in items)
        assert len(closure or())==len(cells)and all(c.cell_contents is v for c,v in zip(closure or(),cells))
    def capture(self,module,name,function,decorators,cls=None,descriptor=None):
        original=function;chain=[];factories=[]
        for expression in decorators:
            syntax=ast.parse(expression,mode='eval').body
            called=isinstance(syntax,ast.Call);node=syntax.func if called else syntax
            assert type(node)is ast.Name and node.id in('contextmanager','operation','retry_scene','retry_observation')
            factory=vars(module)[node.id];factory_row=self.function(factory);factories.append(factory_row)
            row=self.function(function);following=row[4];assert type(following)is types.FunctionType
            candidates=[]
            def visit(code):
                for child in code.co_consts:
                    if type(child)is types.CodeType:candidates.append(child);visit(child)
            visit(factory.__code__)
            assert any(function.__code__ is code for code in candidates)
            assert function.__globals__ is factory.__globals__
            closure=dict(zip(function.__code__.co_freevars,function.__closure__ or()))
            if node.id=='contextmanager':
                assert factory is self.context_factory and function.__globals__ is vars(contextlib)
                assert set(closure)=={'func'}and closure['func'].cell_contents is following and following.__code__.co_flags&0x20
            elif node.id=='operation':
                assert factory.__globals__ is vars(sys.modules['ios.adapters.emote_operation'])
                assert set(closure)=={'function','seconds'}and closure['function'].cell_contents is following
                assert called and len(syntax.args)==1 and not syntax.keywords and type(syntax.args[0])is ast.Constant
                assert type(closure['seconds'].cell_contents)is type(syntax.args[0].value)and closure['seconds'].cell_contents==syntax.args[0].value
            else:
                assert not called and closure.get('function')is not None and closure['function'].cell_contents is following
            chain.append(row);function=following
        row=self.function(function);assert row[2]is vars(module)and row[4]is None
        chain.append(row)
        self.rows.append(dict(module=module,name=name,original=original,cls=cls,descriptor=descriptor,chain=chain,factories=factories))
    def check(self):
        for name,function,code,namespace in self.implementation:
            assert type(self).__dict__[name]is function and function.__code__ is code and function.__globals__ is namespace is globals()
        assert contextlib.contextmanager is self.context_factory and self.context_factory.__code__ is self.context_code and self.context_factory.__globals__ is self.context_globals is vars(contextlib)
        assert contextlib._GeneratorContextManager is self.context_manager and contextlib._GeneratorContextManagerBase is self.context_base
        for cls,name,fn,code,namespace in self.context_members:assert cls.__dict__[name]is fn and fn.__code__ is code and fn.__globals__ is namespace is vars(contextlib)
        for module,name,member,value in self.aliases:assert sys.modules.get(name)is module and vars(module)[member]is value
        for cls,items in self.class_tables:assert tuple(cls.__dict__)==tuple(k for k,v in items)and all(cls.__dict__[k]is v for k,v in items)
        for cls,name,descriptor,kind,row in self.method_aliases:
            assert cls.__dict__[name]is descriptor and (descriptor if kind=='function'else descriptor.__func__)is row[0];self.check_function(row)
        for cls,name,descriptor,held in self.property_rows:
            assert cls.__dict__[name]is descriptor and type(descriptor)is property and descriptor.fdel is None
            for kind,row in held:
                assert (descriptor.fget if kind=='get'else descriptor.fset)is row[0];self.check_function(row)
        for row in self.rows:
            module,name,cls=row['module'],row['name'],row['cls']
            if cls is None:assert vars(module)[name]is row['original']
            else:assert cls.__dict__[name]is row['descriptor']
            for item in(*row['chain'],*row['factories']):self.check_function(item)
        return True
