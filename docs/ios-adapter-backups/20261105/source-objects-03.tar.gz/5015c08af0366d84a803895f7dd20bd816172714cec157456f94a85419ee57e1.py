"""UNRUN exact idle boundary; Node/loopback grants require Root authorization."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,tempfile,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent
receipt_spec=importlib.util.spec_from_file_location('audio_parent_boundary_receipts',HERE/'parent-boundary-receipts.py')
receipt_module=importlib.util.module_from_spec(receipt_spec);receipt_spec.loader.exec_module(receipt_module)
pins=json.loads((HERE/'controller-pins.json').read_text())
for name,row in pins.items():assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==row['sha256']
spec=importlib.util.spec_from_file_location('audio_fixture_audit_common',HERE/'audit-common.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
audit=module.FixtureAudit(HERE,'parent');plan=audit.plan
verifier_spec=importlib.util.spec_from_file_location('audio_fixture_external_verifier',HERE/'external-verifier.py');verifier=importlib.util.module_from_spec(verifier_spec);verifier_spec.loader.exec_module(verifier)
initial_fds=verifier.fd_census();initial_control_threads=verifier.thread_census()
assert sys.dont_write_bytecode and len(plan['cases'])==1
assert plan['status']=='PRIVATE_UNRUN_NODE_LOOPBACK_PARENT_BOUNDARY_ONLY'
TEMP=HERE/'temporary';assert TEMP.is_dir()and not list(TEMP.iterdir());tempfile.tempdir=str(TEMP)
initial_threads=set(threading.enumerate());initial_modules=dict(sys.modules);initial_popen=subprocess.Popen
initial_td=tempfile.TemporaryDirectory;retained=[];node_receipts=[]
class RetainedDirectory(initial_td):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);assert Path(self.name).is_relative_to(TEMP);self._finalizer.detach();retained.append(self.name);audit.save('retained-temporary-roots.json',retained)
 def cleanup(self):self._finalizer.detach()
tempfile.TemporaryDirectory=RetainedDirectory
parts=audit.parts
os.environ.update(AUDIO_ORIGINAL_PARENT_SOURCE_MAP=str(HERE/'original-parent-source-map.json'),
 AUDIO_ORIGINAL_PARENT_SOURCE_MAP_SHA256=audit.digest(HERE/'original-parent-source-map.json'),AUDIO_ORIGINAL_PARENT_NODE=audit.pins['node']['path'])
def spawn_gateway(argv,*args,**kwargs):
 assert type(argv)is list and len(argv)==3 and argv[:2]==[audit.pins['node']['path'],parts['gateway']['path']]
 assert Path(argv[2]).is_relative_to(HERE)and len(node_receipts)<2
 effective=[argv[0],'--import',str(HERE/'node-audit.mjs'),*argv[1:]]
 assert not kwargs.get('start_new_session',False)and kwargs.get('process_group',-1)==-1 and not kwargs.get('preexec_fn')
 assert not args and kwargs.get('stdin')==subprocess.DEVNULL and kwargs.get('stdout')==subprocess.PIPE
 kwargs['env']=dict(PATH='/usr/bin',LANG='C.UTF-8',LC_ALL='C.UTF-8',AUDIO_MODEL_AUDIT_ROOT=str(HERE),AUDIO_OWNED_SESSION=str(os.getsid(0)))
 # Preserve EOF-only fixture stdin using this exact owned private empty
 # file. Do not grant /dev/null or any global write exception to the audit.
 empty=Path(argv[2]).parent/'audited-empty-parent-stdin.bin'
 descriptor=os.open(empty,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(descriptor,'wb')as stream:stream.flush();os.fsync(stream.fileno())
 with empty.open('rb')as stdin:
  kwargs['stdin']=stdin
  audit.launch_authority=(effective[0],effective,kwargs['env'])
  try:process=initial_popen(effective,**kwargs)
  finally:audit.launch_authority=None
 audit.nodes.add(process.pid)
 identity={k:value for k,value in verifier.process_table()[process.pid].items()if k!='state'};assert identity['session']==identity['group']==os.getsid(0)
 node_receipts.append(dict(pid=process.pid,identity=identity,requested=argv,effective=effective,originalStdin='DEVNULL',effectiveOwnedEmptyStdin=str(empty)));audit.save('owned-node-launches.json',node_receipts);return process
subprocess.Popen=spawn_gateway
cases=[];receipts=[];cleanup=[];result=None;fatal=None;original_cleanup=unittest.TestCase.doCleanups;started=time.monotonic()
class Result(unittest.TextTestResult):
 def startTest(self,test):
  self.started=time.monotonic();print('PARENT_IDLE4_START',test.id(),flush=True);super().startTest(test)
 def stopTest(self,test):
  row=dict(id=test.id(),elapsedSeconds=time.monotonic()-self.started);receipts.append(row);audit.save('case-stop-receipts.json',receipts)
  print('PARENT_IDLE4_STOP',json.dumps(row),flush=True);super().stopTest(test)
 def addError(self,test,error):super().addError(test,error);self.keep(test,error)
 def addFailure(self,test,error):super().addFailure(test,error);self.keep(test,error)
 def keep(self,test,error):
  raw=''.join(traceback.format_exception(*error));print(raw,flush=True)
  with(HERE/'original-exceptions.log').open('a')as stream:stream.write(test.id()+'\n'+raw);stream.flush();os.fsync(stream.fileno())
try:
 loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
 def flatten(value):
  if isinstance(value,unittest.TestSuite):
   for child in value:yield from flatten(child)
  else:yield value
 cases=list(flatten(suite));assert not loader.errors and [c.id()for c in cases]==plan['cases']and suite.countTestCases()==1
 audit.save('actual-selected-ids.json',[case.id()for case in cases]);result=unittest.TextTestRunner(verbosity=2,resultclass=Result,failfast=True).run(suite)
except BaseException:
 fatal=traceback.format_exc();(HERE/'original-fatal.log').write_text(fatal);print(fatal,flush=True)
finally:
 cleanup_ok=True
 for case in cases:
  before=len(case._cleanups);prior=case._outcome;drain=unittest.TestResult();success=True
  try:
   if before:case._outcome=unittest.case._Outcome(drain);success=unittest.TestCase.doCleanups(case)
  except BaseException:success=False;(HERE/('cleanup-fatal-'+str(len(cleanup))+'.log')).write_text(traceback.format_exc())
  finally:case._outcome=prior
  row=dict(id=case.id(),pendingBefore=before,remaining=len(case._cleanups),success=success,errors=receipt_module.cleanup_errors(drain.errors),failures=receipt_module.cleanup_errors(drain.failures),
   originalFunctionUnchanged=unittest.TestCase.doCleanups is original_cleanup);cleanup.append(row)
  cleanup_ok=cleanup_ok and success and not case._cleanups and not drain.errors and not drain.failures and row['originalFunctionUnchanged']
 audit.save('original-cleanup-chain.json',dict(success=cleanup_ok,cases=cleanup))
 subprocess.Popen=initial_popen;tempfile.TemporaryDirectory=initial_td
 restored=[]
 for name in audit.loaded:
  target=sys.modules[name]
  if getattr(target,'TemporaryDirectory',None)is RetainedDirectory:target.TemporaryDirectory=initial_td;restored.append(name+'.TemporaryDirectory')
 guards=[];all_closed=True
 for node in node_receipts:
  path=HERE/('guard-node-'+str(node['pid'])+'.json')
  if not path.exists():all_closed=False;continue
  row=json.loads(path.read_text());guards.append(row)
  all_closed=all_closed and row['exit']==0 and not row['refusals']and all(s['exit']==dict(code=0,signal=None)and s['close']and all(s['close']['stdio'])for s in row['spawns'])
 child_pids=[s['pid']for g in guards for s in g['spawns']]
 all_closed=all_closed and len(node_receipts)==2 and len(child_pids)==3
 child_audits=[]
 for pid in child_pids:
  path=HERE/('child-audit-terminal-'+str(pid)+'.json')
  if not path.exists():all_closed=False;continue
  row=json.loads(path.read_text());child_audits.append(row)
  all_closed=all_closed and row.get('resourceDrainEstablished')is True and row['allPublicDependenciesUnchanged']and not row['auditRefusals']and row['metaPathRestored']and row['sysPathRestored']
 threads=[dict(name=t.name,ident=t.ident)for t in threading.enumerate()if t not in initial_threads and t.is_alive()]
 parent_drain=dict(fdBefore=initial_fds,fdAfter=verifier.fd_census(),threadsBefore=initial_control_threads,threadsAfter=verifier.thread_census())
 parent_drain['established']=parent_drain['fdBefore']==parent_drain['fdAfter']and parent_drain['threadsBefore']==parent_drain['threadsAfter']
 audit.save('parent-resource-drain.json',parent_drain)
 verification=audit.finish();status='PASS'if result and result.wasSuccessful()and result.testsRun==1 and not result.skipped and not fatal and cleanup_ok and all_closed and parent_drain['established']and not threads and verification['allPublicDependenciesUnchanged']and not verification['auditRefusals']else'FAIL_OR_ERROR_OR_TIMEOUT'
 report=dict(status=status,testsRun=0 if result is None else result.testsRun,fatal=fatal is not None,elapsedSeconds=time.monotonic()-started,
  cleanupOriginalEstablished=cleanup_ok,allFixtureChildrenClosed=all_closed,remainingNewThreads=threads,retainedTemporaryRoots=retained,
  restoredAliases=restored,tempfileAliasRestored=tempfile.TemporaryDirectory is initial_td,popenRestored=subprocess.Popen is initial_popen,
  nodeGateways=len(node_receipts),modeledChildBirths=sum(len(g['spawns'])for g in guards),nativeQualified=False,wholeQualified=False,
  **verification)
 audit.save('report.json',report);print('PARENT_IDLE4_TERMINAL',json.dumps(report),flush=True)
sys.exit(0 if report['status']=='PASS'else 1)
