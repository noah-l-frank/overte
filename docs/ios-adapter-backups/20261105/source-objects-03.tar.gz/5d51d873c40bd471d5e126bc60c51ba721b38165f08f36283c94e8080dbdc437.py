"""Original fixed Avatar reply, durable once command, independent AFC cuts.

There is no ACK/effect equality, native inode claim or post-fence native query.
The held native descriptor's close return remains unmeasured; real original
process absence is still required to discharge any uncertain native FD duty.
"""
from copy import deepcopy
from pathlib import Path
import re, uuid

from adapters.native_feature_observation import exact, need
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same, canonical
from ios.adapters.avatar_response_command import FILE, PROFILE_KEY, command
from ios.adapters.avatar_response_contract import original as afc_original, source_reference, sdk_absence


def empty(context):
    return dict(iosAvatarNativeReplyDutyVersion=2, phase='empty', context=deepcopy(context),
        read=None, pending=None, sourceRead=None, command=None, observations=[])


def validate_state(value):
    """Pure metadata grammar; physical frame reads remain in the real view."""
    from ios.adapters.installed_code import source
    exact(value, {'iosAvatarNativeReplyDutyVersion','phase','context','read','pending',
        'sourceRead','command','observations'})
    need(type(value['iosAvatarNativeReplyDutyVersion']) is int and value['iosAvatarNativeReplyDutyVersion'] == 2
        and value['phase'] in ('empty','read','issued','absent')
        and type(value['observations']) is list and len(value['observations']) <= 8)
    context = value['context']
    exact(context, {'ownerInstance','bundleId','resultsDirectory','processSource'})
    need(type(context['ownerInstance']) is str and re.fullmatch('[0-9a-f]{32}', context['ownerInstance'])
        and type(context['bundleId']) is str and bool(context['bundleId'])
        and type(context['resultsDirectory']) is str and 1 <= len(context['resultsDirectory']) <= 128
        and re.fullmatch('[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*', context['resultsDirectory']))
    source(context['processSource'])
    if value['phase'] == 'empty':
        need(value['read'] is value['command'] is None and not value['observations'])
    else:
        need(value['read'] is not None)
    if value['phase'] == 'read':
        need(value['command'] is None and not value['observations'])
    if value['phase'] in ('issued','absent'):
        command(value['command'])
    if value['sourceRead'] is not None:
        exact(value['sourceRead'], {'operationId','mode'})
        need(type(value['sourceRead']['operationId']) is str
            and re.fullmatch('[0-9a-f]{32}', value['sourceRead']['operationId'])
            and value['sourceRead']['mode'] in ('read','absence'))
    if value['phase'] == 'absent':
        need(value['observations'] and value['pending'] is value['sourceRead'] is None)
    return value


def source_current(keeper):
    from ios.adapters.installed_code import source
    keeper.bound()
    client, session, sdk, target, scope = keeper.runtime._existing(keeper.selector)
    need(same(scope, {k:v for k,v in keeper.binding.items() if k != 'processIdentity'}))
    gate = keeper.runtime.adapter._binding(keeper.selector, client, session, sdk, target)
    row = gate.record()
    current = gate.retirement_continuity()
    actual = deepcopy(source(gate.process_source()))
    need(row is not None and row['phase'] == 'retiring' and same(row['scope'], scope)
        and current['pid'] == row['process']['pid'] == int(keeper.binding['processIdentity'])
        and same(actual, row['source']) and same(actual, keeper.state['installed']['source']))
    return actual


def cutoff(view):
    need(view.state['cutoff'] is not None)
    value = view.original(view.state['cutoff'])['sourceFrame']['frame']['original']
    return deepcopy(value['original']['current']['clockJoin']['nativeAfter'])


class AvatarReplyReadView:
    def __init__(self, parent, role):
        from ios.adapters.avatar_keeper_terminal import AvatarKeeperTerminal
        need(type(parent) is AvatarKeeperTerminal and type(self) in (AvatarReplyReadView, AvatarReplyRetirement)
            and role in ('primary','actor'))
        self.parent, self.role = parent, role
        f = parent.flow
        self.frames = OriginalFrameStore(Path(parent.state['roles'][role]['root']),
            f.state['bindings'][role], f.run, role, parent.bound, self.no_write,
            namespace='avatar-keeper-reply', schema_prefix='iosAvatarKeeperReply',
            kind='sources', monotonic=f.monotonic)

    @staticmethod
    def no_write(*_args):
        need(False)

    def state(self):
        self.parent.bound()
        value = self.parent.state['roles'][self.role]['nativeReplyDuty']
        validate_state(value)
        exact(value, {'iosAvatarNativeReplyDutyVersion','phase','context','read','pending',
            'sourceRead','command','observations'})
        need(type(value['iosAvatarNativeReplyDutyVersion']) is int and value['iosAvatarNativeReplyDutyVersion'] == 2
            and value['phase'] in ('empty','read','issued','absent')
            and type(value['observations']) is list and len(value['observations']) <= 8)
        exact(value['context'], {'ownerInstance','bundleId','resultsDirectory','processSource'})
        if value['phase'] == 'empty':
            need(value['read'] is value['command'] is None and not value['observations'])
        else:
            need(value['read'] is not None and self.frames.expand(value['read'])['index'] == 1)
        if value['phase'] == 'read':
            need(value['command'] is None and not value['observations'])
        if value['phase'] in ('issued','absent'):
            command(value['command'])
        for index, ref in enumerate(value['observations'], 2):
            need(self.frames.expand(ref)['index'] == index)
        if value['pending'] is not None:
            self.frames.original(value['pending'])
        if value['sourceRead'] is not None:
            exact(value['sourceRead'], {'operationId','mode'})
            need(type(value['sourceRead']['operationId']) is str
                and re.fullmatch('[0-9a-f]{32}', value['sourceRead']['operationId'])
                and value['sourceRead']['mode'] in ('read','absence'))
        if value['phase'] == 'absent':
            need(value['observations'] and value['pending'] is value['sourceRead'] is None)
        return value

    def decode(self, record, mode):
        import hashlib
        state, f = self.state(), self.parent.flow
        context = state['context']
        exact(record, {'sourceReference','sourceOwnerInstance','sourceFrame',
            'processSourceBefore','processSourceAfter'})
        need(record['sourceOwnerInstance'] == context['ownerInstance']
            and same(record['processSourceBefore'], record['processSourceAfter'])
            and same(record['processSourceBefore'], context['processSource']))
        ref = source_reference(record['sourceReference'])
        body = record['sourceFrame']
        exact(body, {'iosOriginalKeeperEndFrameVersion','kind','binding','runId','role','index','frame'})
        need(type(body['iosOriginalKeeperEndFrameVersion']) is int and body['iosOriginalKeeperEndFrameVersion'] == 1
            and body['kind'] == 'sources' and same(body['binding'], f.state['bindings'][self.role])
            and body['runId'] == f.run and body['role'] == 'primary' and body['index'] == ref['index'])
        raw = canonical(body)
        need(len(raw) == ref['bytes'] and hashlib.sha256(raw).hexdigest() == ref['sha256'])
        row = body['frame']
        exact(row, {'kind','role','operationId','original'})
        need(row['kind'] == 'avatar-response' and row['role'] == self.role
            and type(row['operationId']) is str and re.fullmatch('[0-9a-f]{32}', row['operationId']))
        packet = afc_original(row['original'], binding=f.state['bindings'][self.role], run=f.run,
            owner=context['ownerInstance'], bundle=context['bundleId'], directory=context['resultsDirectory'],
            role=self.role, mode=mode)
        return packet, row['original']

    def original(self, expected):
        state = self.state()
        need(state['phase'] == 'absent')
        packet, prior = self.decode(self.frames.read(self.frames.expand(state['read'])), 'read')
        need(same(packet, expected))
        for index, ref in enumerate(state['observations'], 2):
            mode = 'absent' if index == len(state['observations'])+1 else 'present'
            _packet, current = self.decode(self.frames.read(self.frames.expand(ref)), mode)
            need(current['hostBeforeEpochMs'] >= prior['hostAfterEpochMs']
                and current['hostBeforeMonotonic'] >= prior['hostAfterMonotonic'])
            prior = current
        request = command(state['command'])
        _packet, read = self.decode(self.frames.read(self.frames.expand(state['read'])), 'read')
        need(request['role'] == self.role and request['runId'] == self.parent.flow.run
            and request['lastRequestId'] == packet['requestId']
            and request['rawSha256'] == read['original']['actualRawSha256'])
        return deepcopy(state)

    def owned_paths(self):
        state = self.state()
        paths = set()
        for ref in ([state['read']] if state['read'] is not None else []) + state['observations']:
            full = self.frames.expand(ref)
            self.frames.read(full)
            paths.add(self.frames.path(full))
        if state['pending'] is not None:
            ref = state['pending']
            self.frames.original(ref)
            if ref['phase'] == 'planned':
                need(not self.frames.path(ref).exists())
            else:
                self.frames.read(ref)
                paths.add(self.frames.path(ref))
        return paths


class AvatarReplyRetirement(AvatarReplyReadView):
    def __init__(self, parent, keeper):
        from ios.adapters.avatar_keeper_terminal import AvatarKeeperTerminal
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
        need(type(parent) is AvatarKeeperTerminal and type(keeper) is IOSOriginalKeeperProcessEnd
            and keeper.profile_key == PROFILE_KEY and keeper.stage == 0
            and keeper.runtime is parent.flow.runtime and keeper.run == parent.flow.run
            and keeper.selector == parent.flow.selectors[keeper.role]
            and keeper.lock is parent.flow.locks[keeper.role] and keeper.root == parent.role_root(keeper.role)
            and same(keeper.binding, parent.flow.state['bindings'][keeper.role])
            and keeper.state['cutoff'] is not None and keeper.state['stop'] is None)
        self.keeper = keeper
        row = parent.state['roles'][keeper.role]
        target = keeper.runtime.adapter._target(keeper.selector)
        context = dict(ownerInstance=keeper.state['owner'], bundleId=target['appId'],
            resultsDirectory=target['testBuild']['resultsDirectory'], processSource=source_current(keeper))
        if row['nativeReplyDuty'] is None:
            row['nativeReplyDuty'] = empty(context)
            parent.save()
        else:
            need(same(row['nativeReplyDuty']['context'], context))
        super().__init__(parent, keeper.role)
        self.frames.intent = self.intent

    def intent(self, event, wire):
        state = self.state()
        need(event == 'original' and wire['index'] == (1 if state['read'] is None else len(state['observations'])+2)
            and state['phase'] in ('empty','issued'))
        old = state['pending']
        self.frames.original(wire)
        if old is None:
            need(wire['phase'] == 'planned')
        else:
            need((old['phase'], wire['phase']) in (('planned','opened'),('opened','saved'))
                and all(same(old[key],wire[key]) for key in old if key not in ('phase','file'))
                and (old['file'] is None or same(old['file'],wire['file'])))
        state['pending'] = deepcopy(wire)
        self.parent.save()

    def obtain(self, mode):
        state, keeper, f = self.state(), self.keeper, self.parent.flow
        need((mode == 'read' and state['phase'] == 'empty' and state['read'] is None)
            or (mode == 'absence' and state['phase'] == 'issued'))
        need(state['pending'] is None)
        if state['sourceRead'] is None:
            state['sourceRead'] = dict(operationId=uuid.uuid4().hex, mode=mode)
            self.parent.save()
        request = state['sourceRead']
        need(request['mode'] == mode)
        keeper.transport()
        before = source_current(keeper)
        status = keeper.send(keeper.binding['sessionId'], 'mobile: overteOriginalKeeperOperation',
            dict(operation='original-process-end-status', args=dict(operationId=request['operationId'])))
        exact(status, {'iosOriginalKeeperEndStatusVersion','profile','ownerInstance','binding','runId','records','pending','phase'})
        need(type(status['iosOriginalKeeperEndStatusVersion']) is int and status['iosOriginalKeeperEndStatusVersion'] == 1
            and status['profile'] == keeper.profile and status['ownerInstance'] == keeper.state['owner']
            and same(status['binding'],keeper.binding) and status['runId'] == keeper.run)
        rows = status['records']
        need(type(rows) is list and len(rows) <= 1)
        if rows:
            row = rows[0]
            need(row['kind'] == 'avatar-response' and row['role'] == self.role
                and row['operationId'] == request['operationId'])
            result = dict(iosOriginalKeeperEndReferenceVersion=1, profile=keeper.profile,
                ownerInstance=keeper.state['owner'], binding=keeper.binding, runId=keeper.run, reference=row['reference'])
        else:
            # An unknown pending SDK operation is retained, never resent.
            need(status['pending'] is None)
            result = keeper.send(keeper.binding['sessionId'], 'mobile: overteOriginalKeeperOperation',
                dict(operation='original-process-end-avatar-response', args=dict(avatarResponseFileReadVersion=1,
                    binding=deepcopy(keeper.binding), runId=f.run, role=self.role,
                    resultsDirectory=state['context']['resultsDirectory'], mode=mode, operationId=request['operationId'])))
        record = keeper.fetch(result)
        keeper.transport()
        after = source_current(keeper)
        need(same(before,after))
        record.update(processSourceBefore=before, processSourceAfter=after)
        actual_mode = record['sourceFrame']['frame']['original']['original']['mode']
        need(actual_mode in (('read',) if mode == 'read' else ('present','absent')))
        self.decode(record, actual_mode)
        return record

    def accept(self, wire):
        state = self.state()
        record = self.frames.read(wire)
        mode = 'read' if state['read'] is None else record['sourceFrame']['frame']['original']['original']['mode']
        self.decode(record, mode)
        need(state['pending'] is not None and same(state['pending'],wire) and wire['phase'] in ('opened','saved'))
        ref = self.frames.compact(dict(wire, phase='saved'))
        if mode == 'read':
            state.update(read=ref, phase='read')
        else:
            state['observations'].append(ref)
            state['phase'] = 'absent' if mode == 'absent' else 'issued'
        state.update(pending=None,sourceRead=None)
        self.parent.save()

    def recover(self):
        state = self.state()
        if state['pending'] is not None:
            need(state['pending']['phase'] in ('opened','saved'))
            self.accept(state['pending'])

    def before_stop(self):
        self.recover()
        state = self.state()
        expected = cutoff(self.parent.view(self.role))
        if state['read'] is None:
            record = self.obtain('read')
            packet, _value = self.decode(record, 'read')
            need(same(packet,expected))
            ref = self.frames.write(1, record)
            self.accept(self.frames.expand(ref))
        packet, value = self.decode(self.frames.read(self.frames.expand(self.state()['read'])), 'read')
        need(same(packet,expected))
        state = self.state()
        if state['phase'] == 'read':
            request = command(dict(schemaVersion=1, action='feature-ios-avatar-response-retire',
                commandId='ios-'+uuid.uuid4().hex, runId=self.parent.flow.run, role=self.role,
                lastRequestId=packet['requestId'], rawSha256=value['original']['actualRawSha256']))
            state.update(command=request, phase='issued')
            self.parent.save()
            from ios.adapters.feature_observation import send_original_command
            target = self.keeper.runtime.adapter._target(self.keeper.selector)
            send_original_command(target['testBuild']['fixtureOrigin'], request, 4096,
                before_send=self.parent.transport_guard, after_send=self.parent.transport_guard)
        self.recover()
        state = self.state()
        if state['phase'] == 'issued':
            need(len(state['observations']) < 8)
            record = self.obtain('absence')
            mode = record['sourceFrame']['frame']['original']['original']['mode']
            ref = self.frames.write(len(state['observations'])+2, record)
            self.accept(self.frames.expand(ref))
            need(mode == 'absent')
        return self.original(expected)


def archived_original(parent, role, view):
    from ios.adapters.avatar_keeper_terminal import AvatarKeeperTerminal, KeeperOriginalView
    need(type(parent) is AvatarKeeperTerminal and type(view) is KeeperOriginalView
        and view.role == role and view.run == parent.flow.run and view.root == parent.role_root(role)
        and view.lock is parent.flow.locks[role] and view.profile_key == PROFILE_KEY
        and same(view.binding,parent.flow.state['bindings'][role]))
    parent.inventory()
    need(view.state['stop'] is not None)
    read = AvatarReplyReadView(parent, role)
    value = read.original(cutoff(view))
    stopped = view.original(view.state['stop'])
    stop = stopped['sourceFrame']['frame']['original']
    need(type(stop['iosOriginalKeeperStopVersion']) is int and stop['iosOriginalKeeperStopVersion'] == 3)
    sdk_absence(stop['avatarResponseAbsenceOriginal'], binding=view.binding, run=view.run,
        role=role, owner=view.state['owner'], before=stop['before'], context=value['context'])
    initial = read.frames.read(read.frames.expand(value['read']))
    observations = [read.frames.read(read.frames.expand(ref)) for ref in value['observations']]
    indices = [view.original(view.state['cutoff'])['sourceReference']['index'],
        initial['sourceReference']['index'], *[row['sourceReference']['index'] for row in observations],
        stop['avatarResponseAbsenceOriginal']['reference']['index'], stopped['sourceReference']['index']]
    need(all(a < b for a,b in zip(indices,indices[1:])))
    last = observations[-1]['sourceFrame']['frame']['original']
    sdk = stop['avatarResponseAbsenceOriginal']['frame']['original']
    need(sdk['hostBeforeEpochMs'] >= last['hostAfterEpochMs']
        and sdk['hostBeforeMonotonic'] >= last['hostAfterMonotonic'])
    summary = view._summary()
    need(summary['osAbsence'] is not None)
    return dict(iosAvatarReplyRetirementVersion=1, role=role, hostOriginal=value,
        sdkAbsenceOriginal=deepcopy(stop['avatarResponseAbsenceOriginal']),
        nativeInodeEstablished=False, nativeCloseReturnMeasured=False,
        nativeDescriptorDutyDischargedByOriginalProcessAbsence=True,
        nativeQualified=False, deviceQualified=False, wholeQualified=False)
