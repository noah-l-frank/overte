from pathlib import Path
import json,os,subprocess,sys,tempfile,time
from metadata import HERE,REPO,save,pin,sources,census,proc,processes,sha
assert Path.cwd()==REPO and sys.dont_write_bytecode
assert len(sys.argv)==2 and sys.argv[1]==sha(HERE/'freeze.json')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()=='0bad4b4a6cdda7dd6979c1ac707db5b3f81db629'
assert not(HERE/'report.json').exists()and not(HERE/'test.log').exists(),'No unchanged repeat'
before=sources();assert before==json.loads((HERE/'approved-source-map.json').read_text())
runs=HERE/'runs';runs.mkdir(mode=0o700);run=Path(tempfile.mkdtemp(prefix='resume-history-first1-',dir=runs));run.chmod(0o700)
(run/'temporary').mkdir(mode=0o700);save(run/'source-before.json',before)
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='',SNAPSHOT_REVIEW_RUN=str(run),TMPDIR=str(run/'temporary'))
command=['timeout','--signal=TERM','--kill-after=5s','60s',sys.executable,'-B',str(HERE/'run-first1.py')]
started=time.monotonic()
with(HERE/'test.log').open('x')as log:
    task=subprocess.Popen(command,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    bound=proc(task.pid);assert bound is not None and bound['group']==bound['session']==task.pid
    save(run/'process-binding.json',dict(supervisor=proc(os.getpid()),task=bound,command=command));code=task.wait()
remaining=processes(task.pid);assert not remaining,'Own process absence required before original censuses'
first=census(run/'temporary');second=census(run/'temporary');assert not processes(task.pid)
after=sources();save(run/'source-after.json',after)
child=json.loads((run/'selected-result.json').read_text())if(run/'selected-result.json').exists()else None
qualified=code==0 and child is not None and child['successful']and before==after and first==second
save(HERE/'report.json',dict(qualified=qualified,exitCode=code,seconds=time.monotonic()-started,runRoot=str(run),
    allSourcePinsEqual=before==after,postStopOriginalCensusesEqual=first==second,remainingOwnedProcesses=processes(task.pid),
    originalFiles=sum('sha256'in row for row in first.values()),sourcePins=len(before),fixedBudgetSeconds=60,killGraceSeconds=5,
    historicalOriginalsProtectedByWriteBarrier=True,wholeSnapshotsQualified=False,nativeCompiled=False,devicesTested=False))
save(run/'supervisor-originals-first.json',first);save(run/'supervisor-originals-second.json',second)
print('SNAPSHOT_RESUME_HISTORY_FIRST1_TERMINAL',json.dumps(json.loads((HERE/'report.json').read_text())),flush=True)
raise SystemExit(0 if qualified else code if code else 1)
