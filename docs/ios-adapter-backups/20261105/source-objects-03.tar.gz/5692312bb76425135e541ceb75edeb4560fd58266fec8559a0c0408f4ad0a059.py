"""Existing AvatarRecordCache shared only by an explicit CallbackLive2 owner.

Historical rows keep their original measurement and clocks. Every hit retains
actual original file signatures/read membership; every outer Live decode keeps
its complete immutable inventory, row order, pending and orphan checks. Current
State/native admission, new acquisitions and resource cleanup never enter it.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from functools import partial
from importlib import import_module
from types import FunctionType,ModuleType,BuiltinFunctionType,CodeType,MethodType
from contextvars import ContextVar
import re,sys,enum,__future__,socket
from pathlib import PurePath,Path
import hashlib,json,math
from PIL import Image,ImageChops,ImageStat
from adapters.native_feature_observation import need
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import canonical,same
from ios.adapters.avatar_record_cache import AvatarRecordCache

# The actual source modules on the complete retained747 graph decode. Bind
# their full parser/class namespaces, including aliases and policy constants;
# a new/unsupported dependency takes the unchanged literal decoder.
PARSER_MODULES=('adapters.emote_rig_measurements', 'adapters.emote_source_profile', 'adapters.graphics_subject_geometry', 'adapters.native_animation_caller', 'adapters.native_animation_history', 'adapters.native_avatar_receive', 'adapters.native_clock_join', 'adapters.native_completed_frame', 'adapters.native_feature_observation', 'adapters.native_graphics_subject', 'adapters.native_script_files', 'adapters.native_script_loads', 'adapters.native_script_membership', 'adapters.native_script_observation', 'adapters.native_script_roots', 'adapters.native_script_terminal', 'adapters.native_script_work', 'adapters.native_vulkan_world_frame', 'adapters.normal_feature_state', 'adapters.original_file_reads', 'adapters.original_frame_store', 'adapters.original_key_packets', 'adapters.original_marker_clock_queries', 'adapters.original_marker_entities', 'adapters.original_marker_file_receipts', 'adapters.original_marker_holders', 'adapters.original_marker_pointers', 'adapters.original_marker_restoration_frames', 'adapters.original_marker_restoration_image', 'adapters.original_marker_scope', 'adapters.owned_vulkan_world_frame', 'adapters.phase_witness_publisher', 'adapters.pure_original_validation', 'adapters.render_view', 'adapters.script_feature.history', 'adapters.script_feature.lock', 'adapters.script_manager_status', 'adapters.script_ui_inventory', 'adapters.script_ui_root_ownership', 'adapters.token_emote_ui', 'adapters.token_script_file_ui', 'feature_journeys.contract', 'feature_journeys.evidence', 'feature_journeys.fixtures', 'feature_journeys.navigation_scene', 'feature_journeys.phase_fixture', 'feature_journeys.retirement_receipts', 'feature_journeys.scenarios', 'feature_journeys.terminal', 'ios.adapters.avatar_marker_scope', 'ios.adapters.avatar_record_cache', 'ios.adapters.avatar_renderers', 'ios.adapters.avatar_state', 'ios.adapters.create_entities', 'ios.adapters.create_state', 'ios.adapters.emote_actions', 'ios.adapters.emote_archive_round', 'ios.adapters.emote_callback_archive', 'ios.adapters.emote_callback_drain_originals', 'ios.adapters.emote_callback_live', 'ios.adapters.emote_callback_retirement', 'ios.adapters.emote_callback_samples', 'ios.adapters.emote_callback_scene', 'ios.adapters.emote_cleanup', 'ios.adapters.emote_controls', 'ios.adapters.emote_held_marker_scope', 'ios.adapters.emote_images', 'ios.adapters.emote_keyed_retirement', 'ios.adapters.emote_keys', 'ios.adapters.emote_marker_disposition', 'ios.adapters.emote_marker_files', 'ios.adapters.emote_marker_measurements', 'ios.adapters.emote_native_prefix', 'ios.adapters.emote_observation', 'ios.adapters.emote_original_lease', 'ios.adapters.emote_originals', 'ios.adapters.emote_peer', 'ios.adapters.emote_rendered_retirement', 'ios.adapters.emote_retirement', 'ios.adapters.emote_rooted_live', 'ios.adapters.emote_rooted_marker_scope', 'ios.adapters.emote_rooted_retirement', 'ios.adapters.emote_rooted_scene_retirement', 'ios.adapters.emote_samples', 'ios.adapters.emote_sources', 'ios.adapters.emote_ui_inventory', 'ios.adapters.emote_world', 'ios.adapters.graphics_history', 'ios.adapters.login_source', 'ios.adapters.native_geometry', 'ios.adapters.normal_input', 'ios.adapters.places_model', 'ios.adapters.pointer_state', 'ios.adapters.scene_inventory', 'ios.adapters.script_dialogs', 'ios.adapters.viewport', 'ios.adapters.web_closures', 'ios.adapters.world_web_keys')


class _Unsupported(Exception):
    def __init__(self,kind=None,reason='unsupported-type'):
        self.kind=None if kind is None else (kind.__module__,kind.__qualname__)
        self.reason=reason


def _token(value,refs,active,depth=0):
    if depth>32:raise _Unsupported(type(value),'depth')
    kind=type(value)
    if kind in (str,int,bool,type(None)):return (kind.__name__,value)
    if kind is float:return ('float',value.hex())
    refs.append(value);identity=id(value)
    if identity in active:return ('recursive',identity)
    active=active|{identity}
    def token(item):return _token(item,refs,active,depth+1)
    # The sole supported plain object is this actual stdlib default sentinel.
    # Its current module binding is separately part of EXTERNAL_READERS below.
    if kind is object and value is socket._GLOBAL_DEFAULT_TIMEOUT:return ('socket-default-timeout',identity)
    if kind is FunctionType:
        refs.append(value.__code__) # Mutable function binding cannot permit old-code ID reuse.
        closure=() if value.__closure__ is None else tuple(token(cell.cell_contents) for cell in value.__closure__)
        return ('function',identity,id(value.__code__),token(value.__defaults__),token(value.__kwdefaults__),closure)
    if kind is CodeType:return ('code',identity)
    if kind is BuiltinFunctionType:return ('builtin',identity)
    if kind is ModuleType:return ('module',identity)
    if isinstance(value,PurePath):return ('path',kind.__module__,kind.__qualname__,str(value))
    if isinstance(value,enum.Enum):return ('enum',id(kind),value.name,token(value.value))
    if kind is __future__._Feature:return ('future-feature',value.optional,value.mandatory,value.compiler_flag)
    if kind is partial:
        # Exact stdlib partial only. Its actual function/arguments/keyword
        # mapping all participate; keyword mutation cannot reuse an old row.
        # Unsupported nested values still force the unchanged literal parser.
        return ('partial',identity,token(value.func),token(value.args),token(value.keywords))
    if kind.__module__=='functools' and hasattr(value,'__wrapped__'):
        return ('stdlib-wrapper',identity,token(value.__wrapped__))
    if kind is ContextVar:return ('contextvar',identity) # No current validator-scope result is cached.
    if kind is re.Pattern:return ('pattern',identity,value.pattern,value.flags)
    if kind in (list,tuple):return (kind.__name__,tuple(token(item) for item in value))
    if kind in (set,frozenset):
        unsupported=next((type(item) for item in value if type(item) not in (str,int)),None)
        if unsupported is not None:raise _Unsupported(unsupported,'set-member')
        return (kind.__name__,tuple(sorted(token(item) for item in value)))
    if kind is dict:
        # Only exact str/int keys. Preserve the type in the canonical order:
        # integer1 and string'1' cannot alias, and bool/float/object keys refuse.
        unsupported=next((type(key) for key in value if type(key) not in (str,int)),None)
        if unsupported is not None:raise _Unsupported(unsupported,'mapping-key')
        entries=((token(key),token(item)) for key,item in value.items())
        return ('dict',tuple(sorted(entries,key=lambda row:row[0])))
    if kind in (staticmethod,classmethod):return (kind.__name__,token(value.__func__))
    if kind is property:return ('property',token(value.fget),token(value.fset),token(value.fdel))
    if kind is type:
        # External standard-library types are bindings, not project policies.
        if not value.__module__.startswith(('adapters.','ios.adapters.','feature_journeys.')):
            return ('external-type',identity)
        attributes=[]
        for name,item in sorted(vars(value).items()):
            if name.startswith('__') and name not in ('__init__','__enter__','__exit__','__call__'):continue
            attributes.append((name,token(item)))
        refs.append(value.__bases__) # Keep former bases alive if a class binding changes.
        return ('class',identity,tuple(id(base) for base in value.__bases__),tuple(attributes))
    raise _Unsupported(kind)


# External byte/JSON/PNG/parser entrypoints used by these actual decoders.
# External module identity alone cannot qualify a changed parser function.
EXTERNAL_READERS=((socket,'_GLOBAL_DEFAULT_TIMEOUT'),(json,'loads'),(json,'dumps'),(hashlib,'sha256'),(re,'fullmatch'),(re,'match'),(re,'compile'),
    (math,'isfinite'),(Image,'open'),(Image,'frombytes'),(ImageChops,'difference'),
    (Image.Image,'load'),(Image.Image,'convert'),(Image.Image,'crop'),(Image.Image,'getdata'),(Image.Image,'getpixel'))


class CallbackLiveRecords:
    """Feature-local reuse of byte-proved historical rows, never current facts."""
    def __init__(self):
        self.cache=AvatarRecordCache();loaded=tuple(import_module(name) for name in PARSER_MODULES)
        files={module.__file__ for module in loaded}|{__file__}
        # Own _token/function globals/PARSER_MODULES/EXTERNAL_READERS are policy
        # too. The helper has no global cache instance or mutable result rows.
        # Some shared contracts have both existing package and top-level aliases.
        # Bind every actual alias for the same reviewed parser sources too.
        self.modules=tuple(module for _name,module in sorted(sys.modules.items())
            if type(module) is ModuleType and vars(module).get('__file__') in files)
        self.module_names=tuple((module.__name__,module) for module in self.modules)
        self.references=[];self.unsupported=None;self.policy=self.signature(self.references)

    def signature(self,references):
        result=[];location=None
        try:
            if any(sys.modules.get(name) is not module for name,module in self.module_names):return None
            for module in self.modules:
                members=[]
                for name,value in sorted(vars(module).items()):
                    if name.startswith('__'):continue
                    # Module aliases and full callable/class policy are part of
                    # admission, even when a decoder imports the same function
                    # under another name. Mutable original rows live on owners,
                    # never in these source-module namespaces.
                    location=(module.__name__,name);members.append((name,_token(value,references,set())))
                result.append((module.__name__,id(module),tuple(members)))
            external=tuple((id(container),name,_token(getattr(container,name),references,set())) for container,name in EXTERNAL_READERS)
            return tuple(result),external
        except (AttributeError,TypeError,ValueError,RecursionError,_Unsupported):
            self.unsupported=location;return None

    def unsupported_members(self):
        # Diagnostic only: use the SAME closed tokenizer without granting any
        # policy/cache admission. Report module/member/type/reason, never values,
        # function locals, owner contents or a substituted decoder result.
        output=[]
        for module in self.modules:
            if sys.modules.get(module.__name__) is not module:
                output.append(dict(module=module.__name__,member=None,type=None,reason='namespace-rebound'));continue
            for name,value in sorted(vars(module).items()):
                if name.startswith('__'):continue
                try:_token(value,[],set())
                except _Unsupported as error:output.append(dict(module=module.__name__,member=name,type=error.kind,reason=error.reason))
                except (AttributeError,TypeError,ValueError,RecursionError) as error:
                    output.append(dict(module=module.__name__,member=name,type=(type(error).__module__,type(error).__qualname__),reason='token-error'))
        for container,name in EXTERNAL_READERS:
            try:_token(getattr(container,name),[],set())
            except _Unsupported as error:output.append(dict(module=container.__name__,member=name,type=error.kind,reason=error.reason))
            except (AttributeError,TypeError,ValueError,RecursionError) as error:
                output.append(dict(module=container.__name__,member=name,type=(type(error).__module__,type(error).__qualname__),reason='token-error'))
        return output

    def literal(self):
        return self.policy is not None and self.signature([])==self.policy

    def read(self,owner,reference,decode):
        from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
        if type(owner) is not IOSEmoteCallbackLive or not self.literal():return decode()
        owner.file_guard()
        need(owner._historical_rows is self and type(self.cache) is AvatarRecordCache)
        def header():
            need(owner._historical_rows is self and type(self.cache) is AvatarRecordCache)
            original=owner.originals
            need(type(original) is OriginalFrameStore and original.root==owner.root
                and same(original.binding,owner.binding) and original.run==owner.run and original.role==owner.role
                and original.namespace=='emote-rooted-live' and original.schema_prefix=='iosEmoteRootedLive' and original.kind=='inputs'
                and type(original.guard) is MethodType and original.guard.__self__ is owner and original.guard.__func__ is owner.file_guard.__func__
                and type(original.intent) is MethodType and original.intent.__self__ is owner and original.intent.__func__ is owner.intent.__func__)
            return dict(formatVersion=owner.FORMAT_VERSION,binding=owner.binding,primaryBinding=owner.primary_binding,runId=owner.run,role=owner.role,
                root=str(owner.root),store=str(owner.store.path),sourceLock=str(owner.lock.path),primaryLock=str(owner.primary_lock.path),
                fixtureUrl=owner.fixture_url,phaseInstance=owner.phase_instance,imagePolicy=owner.policy,
                original=dict(root=str(owner.originals.root),namespace=owner.originals.namespace,
                    schema=owner.originals.schema_prefix,kind=owner.originals.kind))
        context=deepcopy(header());before=canonical(context);key=dict(emoteCallbackLiveHistoricalRowVersion=1,context=context,reference=reference)
        encoded=canonical(key)
        def checked():
            owner.file_guard();need(self.literal() and canonical(key)==encoded and canonical(header())==before)
            result=decode()
            owner.file_guard();need(self.literal() and canonical(key)==encoded and canonical(header())==before)
            return result
        if encoded not in self.cache.rows and len(self.cache.rows)>=512:return decode()
        result=self.cache.read(key,checked)
        owner.file_guard();need(self.literal() and canonical(key)==encoded and canonical(header())==before)
        return result
