"""UNRUN synthetic-original counters; no Native/SDK/device authority."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json,tempfile,unittest
from adapters.native_clock_join import validate_join
from adapters.native_clock_join_refusal_original import NativeClockJoinRefusalOriginal,current_refusal_original
from adapters.normal_ui import NativeUIError
from self_tests.test_native_clock_join import NativeClockJoinTests


class NativeClockJoinRefusalOriginalTests(unittest.TestCase):
    def source(self,*,extra_native_ms=0):
        native,clocks,window,original=NativeClockJoinTests().source()
        # Existing synthetic producer is selected before the second packet's
        # birth. No existing packet, real clock, source result or bound is
        # rewritten. Binary-exact .125 removes a floating threshold ambiguity.
        clocks[:]=[1000125.,10.125]
        previous=native.mutate
        def produce(value):
            previous(value)
            if extra_native_ms:
                value['capturedEpochMs']+=extra_native_ms
                value['requestedEpochMs']+=extra_native_ms
                value['animationFence']['requestedEpochMs']+=extra_native_ms
        native.mutate=produce
        trace=[]
        def epoch():trace.append('epoch');return clocks[0]
        def monotonic():trace.append('monotonic');return clocks[1]
        window.epoch_ms=epoch;window.monotonic=monotonic
        return native,clocks,window,original,trace

    def sink(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        path=Path(temporary.name)/'native-clock-join-refusal-original.json'
        return NativeClockJoinRefusalOriginal(path,dict(case=self._testMethodName,producer='existing-synthetic-native-clock-boundary'))

    def test_positive_scope_keeps_record_contract_and_clock_query_counts_without_output(self):
        native,clocks,window,original,trace=self.source()
        sink=self.sink()
        with sink.scope():record=window.finish(original,[('execution','capturedEpochMs')])
        self.assertEqual(['epoch','monotonic'],trace);self.assertEqual(2,len(native.commands))
        self.assertEqual(1,record['clockJoinVersion']);self.assertEqual(1000000.,record['hostBeforeEpochMs'])
        self.assertEqual(1000125.,record['hostAfterEpochMs']);self.assertEqual(20000,record['nativeBefore']['capturedEpochMs'])
        self.assertEqual(20125,record['nativeAfter']['capturedEpochMs'])
        self.assertIs(validate_join(record,original),record)
        self.assertFalse(sink.written);self.assertFalse(sink.path.exists());self.assertIsNone(sink.owner)
        self.assertIsNone(current_refusal_original());self.assertTrue(window.finished)

    def test_actual_false_conjunction_retains_only_original_operands_and_no_extra_clock_or_query(self):
        baseline,clocks,window,original,trace=self.source(extra_native_ms=251)
        with self.assertRaises(NativeUIError)as plain:window.finish(original,[('execution','capturedEpochMs')])
        plain_counts=(list(trace),len(baseline.commands),baseline.guards)
        native,clocks,window,original,trace=self.source(extra_native_ms=251);sink=self.sink()
        with sink.scope():
            with self.assertRaises(NativeUIError)as observed:window.finish(original,[('execution','capturedEpochMs')])
        self.assertEqual(str(plain.exception),str(observed.exception))
        self.assertEqual(plain_counts,(list(trace),len(native.commands),native.guards))
        self.assertEqual(['epoch','monotonic'],trace);self.assertEqual(2,len(native.commands));self.assertFalse(window.finished)
        value=json.loads(sink.path.read_text());locals_=value['locals']
        self.assertIs(False,value['condition']);self.assertEqual(1000000.,locals_['start']);self.assertEqual(1000125.,locals_['end'])
        self.assertEqual(10.,locals_['before']);self.assertEqual(10.125,locals_['after'])
        self.assertEqual(20000,locals_['first']['capturedEpochMs']);self.assertEqual(20376,locals_['last']['capturedEpochMs'])
        self.assertEqual(window.started['nativeBefore'],locals_['first']);self.assertEqual(native.sample,locals_['last'])
        self.assertEqual(locals_['record']['nativeBefore'],locals_['first']);self.assertEqual(locals_['record']['nativeAfter'],locals_['last'])
        self.assertEqual(20050,original['execution']['capturedEpochMs']);self.assertTrue(sink.written)
        self.assertIsNone(sink.owner);self.assertIsNone(current_refusal_original())

    def test_other_false_stages_do_not_create_a_native_host_refusal_original(self):
        for stage in('earlier-host-deadline','later-original-range'):
            with self.subTest(stage=stage):
                native,clocks,window,original,trace=self.source();sink=self.sink()
                if stage=='earlier-host-deadline':clocks[:]=[1002000.,12.]
                else:original['execution']['capturedEpochMs']=19999
                with sink.scope(),self.assertRaises(NativeUIError):window.finish(original,[('execution','capturedEpochMs')])
                self.assertFalse(sink.written);self.assertFalse(sink.path.exists())
                self.assertEqual(2,len(native.commands));self.assertIsNone(current_refusal_original())

    def test_standalone_historical_validation_cannot_borrow_the_live_finish_receiver(self):
        native,clocks,window,original,trace=self.source(extra_native_ms=251)
        # Build an explicitly synthetic malformed historical record from the
        # same existing source state, without issuing another native request.
        from copy import deepcopy
        from adapters.native_clock_join import digest
        record=dict(window.started,hostAfterEpochMs=1000125.,hostAfterMonotonic=10.125,
            nativeAfter=deepcopy(window.started['nativeBefore']),sourceTimes=[dict(source='execution',field='capturedEpochMs',epochMs=20050)],originalsSha256=digest(original))
        record['nativeAfter'].update(sequence=2,requestId='ios-'+'e'*32,capturedEpochMs=20376,requestedEpochMs=20376)
        sink=self.sink();before=len(native.commands)
        with sink.scope(),self.assertRaises(NativeUIError):validate_join(record,original)
        self.assertFalse(sink.written);self.assertFalse(sink.path.exists());self.assertEqual(before,len(native.commands))

    def test_output_conflict_never_overwrites_or_replaces_the_original_false_refusal(self):
        native,clocks,window,original,trace=self.source(extra_native_ms=251);sink=self.sink()
        sink.path.write_text('{"actualForeignOriginal":true}\n');sink.path.chmod(0o600)
        raw=sink.path.read_bytes();inode=sink.path.stat().st_ino
        with sink.scope(),self.assertRaises(NativeUIError):window.finish(original,[('execution','capturedEpochMs')])
        self.assertFalse(sink.written);self.assertEqual(raw,sink.path.read_bytes());self.assertEqual(inode,sink.path.stat().st_ino)
        self.assertEqual(['epoch','monotonic'],trace);self.assertEqual(2,len(native.commands))
