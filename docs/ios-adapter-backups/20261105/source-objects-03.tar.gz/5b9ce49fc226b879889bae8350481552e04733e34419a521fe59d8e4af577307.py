"""Bounded source-byte/order controls only; no native compilation or execution."""
from pathlib import Path
import argparse,hashlib,json,re

START='#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(Q_OS_IOS) && defined(OVERTE_E2E_VOICE_TESTS)\n    if (overte::e2e::IOSAudioResponseFileOwnership::requested() && overte::e2e::IOSAudioResponseFileOwnership::selected(filename)) {'
ANCHOR='    QString filepath = QDir::cleanPath(_testResultsLocation + filename);\n'
SHARED='#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(Q_OS_IOS) && defined(OVERTE_E2E_VOICE_TESTS)\n    // Audio11 preserves the earlier generic writer guards before the SAME\n    // original ownership/producer/QSaveFile block can now consume the clock.\n    if (overte::e2e::IOSAudioResponseFileOwnership::requested() && overte::e2e::IOSAudioResponseFileOwnership::selected(filename)) {\n        if (!QCoreApplication::arguments().contains("--testScript") || QFileInfo(filepath).isSymLink()) {return;}\n        if (previewOrigin && !featurePreviewOriginCurrent(variant.toMap())) {return;}\n    }\n#endif\n'

def controls(baseline,candidate):
    start=baseline.index(START,baseline.index('void TestScriptingInterface::saveObject'));end=baseline.index('\n#endif',start)+len('\n#endif')
    block=baseline[start:end];position=baseline.index(ANCHOR,baseline.index('void TestScriptingInterface::saveObject'))+len(ANCHOR)
    expected=baseline[:position]+SHARED+block+'\n'+baseline[position:start]+baseline[end:]
    assert candidate==expected and candidate.count(block)==1
    hook=candidate.index(block);generic=candidate.index('    if (filename == "feature-ios-assets-image-reader-processing.json"',candidate.index('void TestScriptingInterface::saveObject'))
    assert position<hook<generic
    assert 'filename == "feature-native-observation.json"'in candidate[generic:candidate.index('\n#endif',generic)]
    assert '!QCoreApplication::arguments().contains("--testScript") || QFileInfo(filepath).isSymLink()'in SHARED
    assert 'previewOrigin && !featurePreviewOriginCurrent(variant.toMap())'in SHARED
    assert 'owner.begin(filename,_testResultsLocation,output.handle(),jsonData,value)'in block
    assert 'owner.committed(filename,output.commit());return;'in block
    # The complete prefix (all common path/preview/serialization guards) and
    # every other original function/branch are literal projected bytes.
    assert candidate[:position]==baseline[:position]
    for source in(baseline,candidate):
        depth=0
        for line in source.splitlines():
            if re.match(r'^\s*#\s*(if|ifdef|ifndef)\b',line):depth+=1
            elif re.match(r'^\s*#\s*endif\b',line):depth-=1;assert depth>=0
        assert depth==0
    return dict(exactProducerAndQSaveFileBlock=True,allPrecedingCommonGuardsLiteral=True,otherNativeFunctionsAndBranchesLiteral=True,
        newTestScriptSymlinkPreviewGuardsBeforeOwnedWrite=True,clockOwnedBranchBeforeGeneric=True,allFourCompileGatesLiteral=True,
        nativeCompiled=False,nativeExecuted=False,nativeQualified=False,wholeQualified=False)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--baseline',required=True);p.add_argument('--candidate',required=True);a=p.parse_args()
    print(json.dumps(controls(Path(a.baseline).read_text(),Path(a.candidate).read_text()),sort_keys=True))
