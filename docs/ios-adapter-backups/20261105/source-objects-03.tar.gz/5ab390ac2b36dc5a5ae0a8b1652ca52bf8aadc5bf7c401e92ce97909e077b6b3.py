"""Root metadata-only preparation AFTER reviewed exact public composition."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
BROAD=['tests/device','interface/src','libraries','ios','scripts/system','interface/resources/qml','cmake']
assert len(sys.argv)==3 and sys.argv[1] in ('prefix4end1','full26')
kind=sys.argv[1];reviewed=Path(sys.argv[2]).resolve(strict=True)
composition=json.loads(reviewed.read_text())
assert set(composition)=={'tests/device/ios/adapters/feature_configuration.py','tests/device/ios/adapters/installed_adapter.py'}
required=json.loads((HERE/'root-required-publication.json').read_text());expected=required|composition
assert len(expected)==6
h=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for name,digest in expected.items():assert h(REPO/name)==digest,name
extra=['CMakeLists.txt',str(reviewed.relative_to(REPO))]
extra.extend(str(path.relative_to(REPO)) for path in (HERE/'freeze.json',HERE/'root-preimport-entry.py',HERE/'prepare-root-map.py',HERE/'root-required-publication.json'))
def pin(path):
    value=path.lstat();assert stat.S_ISREG(value.st_mode),str(path)
    return dict(dev=value.st_dev,ino=value.st_ino,mode=value.st_mode,nlink=value.st_nlink,uid=value.st_uid,gid=value.st_gid,
                size=value.st_size,mtimeNs=value.st_mtime_ns,ctimeNs=value.st_ctime_ns,sha256=h(path))
def sources():
    names=subprocess.check_output(['rg','--files','-0',*BROAD],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name};paths.update(REPO/name for name in extra)
    assert REPO/'interface/src/main.cpp' in paths
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}
before=sources();after=sources();assert before==after
root=REPO.stat();value=dict(status='ROOT_ACTUAL_POST_PUBLICATION_APPROVED',kind=kind,worktreeRoot=str(REPO),
    rootIdentity=dict(dev=root.st_dev,ino=root.st_ino),broadRoots=BROAD,extraPins=extra,
    orderedRoots=['tests/device','tests/device/self_tests','tests/device/ios/self_tests'],
    packages={'adapters':'tests/device/adapters','feature_journeys':'tests/device/feature_journeys','fixture':'tests/device/fixture','ios':'tests/device/ios','self_tests':'tests/device/self_tests'},
    sourcePins=before,reviewedPublication=expected,reviewedComposition=composition,
    modules={name:'tests/device/'+name.replace('.','/')+'.py' for name in (
        'ios.self_tests.test_ios_tablet_web_public_vertical','ios.self_tests.tablet_web_public_vertical_fixture',
        'ios.self_tests.tablet_web_terminal_fixture','ios.self_tests.tablet_web_actor_profile','ios.tablet_web_observer',
        'ios.adapters.tablet_web_feature','ios.adapters.tablet_web_api_entry','ios.adapters.installed_adapter',
        'ios.adapters.feature_configuration','ios.self_tests.retained_host_roots')})
ready=HERE/(kind+'-actual-post-publication-map.json');assert not ready.exists()
with ready.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
print(json.dumps(dict(path=str(ready),sha256=h(ready),sourcePins=len(before)),sort_keys=True),flush=True)
