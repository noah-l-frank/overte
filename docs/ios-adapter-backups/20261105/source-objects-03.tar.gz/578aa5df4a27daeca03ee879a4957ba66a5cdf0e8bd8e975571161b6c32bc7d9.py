"""Actual HTTP/WebDriver parser and sockets; server envelopes are models only."""
import json,threading,unittest
from http.server import BaseHTTPRequestHandler,HTTPServer
from unittest.mock import patch
from ios.adapters.appium_adapter import WebDriver


class RetainedWebDriverCleanupModels(unittest.TestCase):
    def setUp(self):
        self.requests=[];self.foreign=[];self.mode='value';outer=self
        def handler(rows):
            class Handler(BaseHTTPRequestHandler):
                def log_message(self,*_):pass
                def do_POST(self):
                    raw=self.rfile.read(int(self.headers['Content-Length']));rows.append((self.path,json.loads(raw)))
                    value={'value':{'transportOnly':True}} if outer.mode=='value' else {'wrong':None}
                    body=json.dumps(value).encode();self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
            return Handler
        self.servers=[];self.threads=[]
        for rows in (self.requests,self.foreign):
            server=HTTPServer(('127.0.0.1',0),handler(rows));thread=threading.Thread(target=lambda s=server:s.serve_forever(poll_interval=.01),name='retained-webdriver-model-http',daemon=False)
            self.servers.append(server);self.threads.append(thread);thread.start();self.addCleanup(self.stop,server,thread)
        self.origin='http://127.0.0.1:'+str(self.servers[0].server_port);self.other='http://127.0.0.1:'+str(self.servers[1].server_port)
        self.client=WebDriver(self.origin)
    def stop(self,server,thread):server.shutdown();server.server_close();thread.join(5);self.assertFalse(thread.is_alive())

    def test_original_url_session_and_bound_parser_survive_later_public_client_alias_drift(self):
        cleanup=self.client.retain_original_keeper_cleanup('original-session');self.client.server_url=self.other
        def foreign(*_a,**_k):raise AssertionError('Later public client alias must not receive old cleanup')
        self.client.call=foreign;self.client.execute=foreign;self.client._read_reply=foreign
        self.assertEqual({'transportOnly':True},cleanup('touch-release'))
        self.assertEqual([('/session/original-session/execute/sync',{'script':'mobile: overteOriginalKeeperOperation','args':[{'operation':'touch-release','args':{}}]})],self.requests)
        self.assertEqual([],self.foreign)

    def test_retained_sender_rejects_forward_input_process_mutations_and_unknown_operations_before_http(self):
        cleanup=self.client.retain_original_keeper_cleanup('original-session')
        class DisguisedForward(str):
            def __eq__(self,other):return other=='touch-inspect'
        disguised=DisguisedForward('touch-begin')
        self.assertTrue(disguised=='touch-inspect');self.assertEqual('\"touch-begin\"',json.dumps(disguised))
        for operation in ('touch-begin','process-terminate','wda-start','unknown',False,disguised):
            with self.subTest(operation=operation),self.assertRaises(RuntimeError):cleanup(operation)
        self.assertEqual([],self.requests);self.assertEqual([],self.foreign)

    def test_all_three_existing_old_cleanup_routes_use_the_original_unchanged_command_envelope(self):
        cleanup=self.client.retain_original_keeper_cleanup('original-session')
        for operation in ('touch-inspect','touch-release','touch-settle'):cleanup(operation)
        self.assertEqual(['touch-inspect','touch-release','touch-settle'],[body['args'][0]['operation'] for _,body in self.requests])
        self.assertTrue(all(path=='/session/original-session/execute/sync' for path,_ in self.requests))
        self.assertTrue(all(body['args'][0]['args']=={} for _,body in self.requests));self.assertEqual([],self.foreign)

    def test_original_reply_parser_rejects_malformed_actual_http_envelope_after_alias_replacement(self):
        cleanup=self.client.retain_original_keeper_cleanup('original-session');self.mode='missing'
        self.client._read_reply=lambda *_:{'transportOnly':False}
        with self.assertRaisesRegex(RuntimeError,'Appium response does not satisfy the WebDriver protocol'):cleanup('touch-inspect')
        self.assertEqual(1,len(self.requests));self.assertEqual([],self.foreign)

    def test_existing_final_transport_guard_remains_required_and_default_call_still_uses_current_client_url(self):
        from adapters.operation_transport_guard import scope
        cleanup=self.client.retain_original_keeper_cleanup('original-session')
        with scope(lambda:True):
            with patch('adapters.operation_transport_guard.check',side_effect=RuntimeError('Declared final transport refusal')):
                with self.assertRaisesRegex(RuntimeError,'Declared final transport refusal'):cleanup('touch-settle')
        self.assertEqual([],self.requests);self.client.server_url=self.other
        self.assertEqual({'transportOnly':True},self.client.execute('normal-session','normal-script',{}))
        self.assertEqual([],self.requests);self.assertEqual(1,len(self.foreign))

    def test_scoped_sender_copies_original_owner_resource_selectors_before_later_caller_data_drift(self):
        from adapters.script_feature.history import canonical
        original=dict(ownerInstance='a'*32,binding=dict(sourceRevision='a'*40,artifactSha256='b'*64,processIdentity='42',
            sessionId='original-session',generation=1,targetFingerprint='c'*64),runId='d'*32,
            referenceJson=canonical(dict(index=1,sha256='e'*64,bytes=2000,device=1,inode=2)).decode('ascii'))
        expected=json.loads(json.dumps(original));cleanup=self.client.retain_original_keeper_cleanup('original-session',original=original)
        original['ownerInstance']='f'*32;original['binding']['sessionId']='foreign-session';self.client.server_url=self.other
        cleanup('touch-release');args=self.requests[-1][1]['args'][0]['args']
        self.assertEqual(1,args['originalKeeperRetainedTouchProfileVersion']);self.assertEqual(expected['ownerInstance'],args['expectedOwnerInstance'])
        self.assertEqual(expected['binding'],args['binding']);self.assertEqual(expected['runId'],args['runId'])
        self.assertEqual(expected['referenceJson'],args['referenceJson']);self.assertEqual([],self.foreign)
