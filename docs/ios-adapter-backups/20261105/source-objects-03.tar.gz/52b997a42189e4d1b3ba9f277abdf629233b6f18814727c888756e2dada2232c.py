from pathlib import Path
import json,hashlib,ast
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');P=R/'.ios-host-tmp/lifecycle-original-owner-root-three-stage-preparation-20261028';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
guard='''"""Root source-model run diagnostics; no resource/native qualification."""
import gc,hashlib,json,os,stat,sys,threading
from pathlib import Path

def pinned(path,expected):
    path=Path(path);raw=path.read_bytes()
    if path.is_symlink() or path.resolve()!=path or hashlib.sha256(raw).hexdigest()!=expected:raise RuntimeError('Reviewed source pin changed')
    return raw

def fds():
    output={}
    for name in os.listdir('/proc/self/fd'):
        try:output[name]=os.readlink('/proc/self/fd/'+name)
        except FileNotFoundError:pass
    return output

def baseline():return dict(threads={id(t) for t in threading.enumerate()},fds=fds(),children=Path('/proc/self/task/'+str(os.getpid())+'/children').read_text())

def originals(roots):
    output={}
    for root in roots:
        root=Path(root);nodes=[root]+sorted(root.rglob('*'))
        for path in nodes:
            info=path.lstat();row={key:getattr(info,key) for key in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')}
            if path.is_symlink():raise RuntimeError('Unexpected original symlink')
            if stat.S_ISREG(info.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
            elif not stat.S_ISDIR(info.st_mode):raise RuntimeError('Unexpected retained special file')
            output[str(path)]=row
    return output

def terminal(here,initial,roots):
    # Two real terminal censuses after original cleanup, with unchanged files.
    previous=None
    for index in (1,2):
        threads=[dict(name=t.name,ident=t.ident) for t in threading.enumerate() if id(t) not in initial['threads'] and t.is_alive()]
        async_module=sys.modules.get('asyncio');pending=[]
        if async_module is not None:
            pending=[dict(name=t.get_name(),loopClosed=t.get_loop().is_closed()) for t in gc.get_objects() if isinstance(t,async_module.Task) and not t.done()]
        children=Path('/proc/self/task/'+str(os.getpid())+'/children').read_text();actual_fds=fds();files=originals(roots)
        value=dict(threads=threads,pendingTasks=pending,children=children,fds=actual_fds,originals=files,
            sdkModules=[n for n in sys.modules if n.split('.')[0] in {'pymobiledevice3','pmd_pytcp','pmd_net_addr'}],qualification=False)
        (here/('terminal-census-'+str(index)+'.json')).write_text(json.dumps(value,indent=2)+'\\n')
        if threads or pending or children!=initial['children'] or actual_fds!=initial['fds'] or value['sdkModules']:raise RuntimeError('Owned model process/thread/task/FD or SDK import remains')
        if previous is not None and files!=previous:raise RuntimeError('Retained originals changed between terminal censuses')
        previous=files
'''
for dirname in ('01-final35','02-resource11','03-motion7'):(P/dirname/'root_stage_guard.py').write_text(guard)
# final35 retained protocol unchanged, add explicit diagnostic source/code ties.
a=P/'01-final35';s=(a/'run-exact35.py').read_text();s=s.replace('from importlib.machinery import PathFinder','from importlib.machinery import PathFinder\nfrom root_stage_guard import baseline,terminal')
s=s.replace("model_map_raw=model_map.read_bytes()","model_map_raw=pinned(model_map,manifest['nodeModelSourceMapSHA256'])")
s=s.replace('    baseline_threads=set(threading.enumerate())','    baseline_threads=set(threading.enumerate());initial_census=baseline()')
s=s.replace("        print('Exact source-model terminal; installed SDK/auth/native/whole qualification remains false.',flush=True)","        terminal(HERE,initial_census,owned_roots)\n        print('Exact source-model terminal; installed SDK/auth/native/whole qualification remains false.',flush=True)")
(a/'run-exact35.py').write_text(s);ast.parse(s)
m=json.loads((a/'manifest.json').read_text());m['modelFiles']['root_stage_guard.py']=h(a/'root_stage_guard.py');m['launcherSHA256']=h(a/'run-exact35.py');(a/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
# Resource11 and Motion7 run selected exact models after actual Root publication.
runner='''#!/usr/bin/env python3
"""Root-only exact source models; no SDK import, native or admission claim."""
from __future__ import annotations
import hashlib,json,os,sys,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
from unittest.mock import patch
from importlib.machinery import PathFinder
from root_stage_guard import pinned,baseline,terminal
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent

def main():
    stage_raw=pinned(HERE/'source-manifest.json',os.environ['LIFECYCLE_STAGE_MANIFEST_SHA256']);stage=json.loads(stage_raw)
    plan_raw=pinned(HERE/'run-plan.json',os.environ['LIFECYCLE_STAGE_PLAN_SHA256']);plan=json.loads(plan_raw)
    map_path=Path(os.environ['LIFECYCLE_STAGE_ROOT_MAP']);map_raw=pinned(map_path,os.environ['LIFECYCLE_STAGE_ROOT_MAP_SHA256']);mapping=json.loads(map_raw)
    if set(mapping)!={'repositoryRoot','currentSourcePins','reviewedCandidates'}:raise RuntimeError('Root source map schema')
    repo=Path(mapping['repositoryRoot']);expected={row['path']:row['candidateSHA256'] for row in stage['sourcePaths']}
    if str(repo)!=stage['repositoryRoot'] or not repo.is_absolute() or repo.resolve()!=repo or not (repo/'.git').exists() or mapping['reviewedCandidates']!=expected:raise RuntimeError('Actual Root/source candidates required')
    required=set(plan['requiredPublicDependencies'])|set(expected)|{'tests/device/contract-versions.json','tests/device/validate_contract_versions.py'}
    if not required<=set(mapping['currentSourcePins']):raise RuntimeError('Actual broad source census incomplete')
    guards=[]
    for relative,digest in mapping['currentSourcePins'].items():
        rel=Path(relative)
        if rel.is_absolute() or '..' in rel.parts:raise RuntimeError('Root source escape')
        guards.append((repo/rel,digest))
    guards.extend((repo/rel,digest) for rel,digest in expected.items())
    guards.extend((Path(row['candidate']),row['candidateSHA256']) for row in stage['sourcePaths'])
    guards.extend((HERE/name,digest) for name,digest in plan['privateFiles'].items())
    for path,digest in guards:pinned(path,digest)
    before={str(path):path.stat() for path,_ in guards}
    registry=json.loads((repo/'tests/device/contract-versions.json').read_text())['contracts']
    for name,value in plan['registryRequirements'].items():
        if registry.get(name)!=value:raise RuntimeError('Own protocol registry prerequisite unavailable')
    initial=baseline() # BEFORE any target module import.
    roots=[str(repo/rel) for rel in ('tests/device','tests/device/self_tests','tests/device/ios/self_tests')]
    remainder=[]
    for entry in sys.path:
        path=Path(entry or os.getcwd()).resolve()
        if path==repo or repo in path.parents:continue
        if str(path) not in remainder:remainder.append(str(path))
    sys.path[:]=roots+[str(HERE)]+remainder
    namespaces={'adapters':('tests/device/adapters',sys.path),'ios':('tests/device/ios',sys.path),'self_tests':('tests/device/self_tests',sys.path),
        'ios.adapters':('tests/device/ios/adapters',[str(repo/'tests/device/ios')]),'ios.self_tests':('tests/device/ios/self_tests',[str(repo/'tests/device/ios')])}
    for name,(relative,parents) in namespaces.items():
        spec=PathFinder._get_spec(name,list(parents))
        if spec is None or [str(Path(p).resolve()) for p in spec.submodule_search_locations or ()]!=[str(repo/relative)]:raise RuntimeError('Canonical namespace mismatch before target import')
    retained=HERE/'retained-first';retained.mkdir(mode=0o700,exist_ok=False)
    bindings=HERE/'source-code-bindings-first';bindings.mkdir(mode=0o700,exist_ok=False);os.environ['LIFECYCLE_CODE_BINDINGS_ROOT']=str(bindings)
    owned=[];objects=[];real_td=tempfile.TemporaryDirectory;real_mkdtemp=tempfile.mkdtemp
    def record(root,kind):
        root=Path(root);info=root.stat()
        if root.parent!=retained or not root.is_dir() or info.st_uid!=os.geteuid() or info.st_mode&0o077:raise RuntimeError('Real private retained root unavailable')
        owned.append(str(root));(HERE/'created-original-roots.json').write_text(json.dumps([dict(path=p,kind='genuine-owned-temp-root') for p in owned])+'\\n');return root
    def mkdtemp(suffix=None,prefix=None,dir=None):
        if dir is not None and Path(dir)!=retained:raise RuntimeError('Foreign temp root')
        return str(record(real_mkdtemp(suffix=suffix,prefix=prefix,dir=retained),'mkdtemp'))
    def temporary(suffix=None,prefix=None,dir=None,*,ignore_cleanup_errors=False,delete=True):
        if dir is not None and Path(dir)!=retained:raise RuntimeError('Foreign temp root')
        actual=real_td(suffix=suffix,prefix=prefix,dir=retained,ignore_cleanup_errors=ignore_cleanup_errors,delete=delete)
        from ios.self_tests.retained_host_roots import retain_owned_root
        root=record(actual.name,'TemporaryDirectory');retain_owned_root(actual,expected_root=root);objects.append(actual);return actual
    models={}
    for name,roles in plan['modelMaps'].items():
        value={role:dict(path=str(repo/relative),sha256=expected.get(relative,mapping['currentSourcePins'][relative])) for role,relative in roles.items()}
        path=HERE/(name+'-actual-root-map.json');raw=(json.dumps(value,indent=2)+'\\n').encode();path.write_bytes(raw)
        os.environ[name]=str(path);os.environ[name+'_SHA256']=hashlib.sha256(raw).hexdigest();models[str(path)]=hashlib.sha256(raw).hexdigest()
    try:
        from ios.self_tests.retained_host_roots import retain_owned_root
        loader=unittest.TestLoader();suite=unittest.TestSuite()
        for case in plan['cases']:suite.addTests(loader.loadTestsFromName(case))
        if suite.countTestCases()!=plan['caseCount']:raise RuntimeError('Exact unique selection changed')
        with ExitStack() as stack:
            for name in plan['mkdtempAliases']:stack.enter_context(patch.object(sys.modules[name],'tempfile',SimpleNamespace(mkdtemp=mkdtemp)))
            if plan['retainInstalledFixture']:
                from ios.self_tests import test_ios_installed_adapter as installed_fixture
                stack.enter_context(patch.object(installed_fixture,'tempfile',SimpleNamespace(TemporaryDirectory=temporary)))
            result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
        return 0 if result.wasSuccessful() else 1
    finally:
        pinned(map_path,hashlib.sha256(map_raw).hexdigest());pinned(HERE/'source-manifest.json',hashlib.sha256(stage_raw).hexdigest());pinned(HERE/'run-plan.json',hashlib.sha256(plan_raw).hexdigest())
        for path,digest in guards:
            pinned(path,digest);old=before[str(path)];new=path.stat()
            if any(getattr(old,key)!=getattr(new,key) for key in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')):raise RuntimeError('Actual source/launcher stat changed')
        for path,digest in models.items():pinned(path,digest)
        terminal(HERE,initial,owned)
        print('Host source models only; SDK/auth/native/whole gates remain false.',flush=True)
if __name__=='__main__':raise SystemExit(main())
'''
for dirname,modules,rootcase,cap in [('02-resource11',['test_resource_borrow_models','test_resource_consumer_models'],11,90),('03-motion7',['test_motion_preparation_models'],7,180)]:
 stage=P/dirname;cases=[]
 for name in modules:
  tree=ast.parse((stage/(name+'.py')).read_bytes())
  cases += [name+'.'+cls.name+'.'+method.name for cls in tree.body if isinstance(cls,ast.ClassDef) for method in cls.body if isinstance(method,(ast.FunctionDef,ast.AsyncFunctionDef)) and method.name.startswith('test_')]
 assert len(cases)==len(set(cases))==rootcase
 sm=json.loads((stage/'source-manifest.json').read_text());relative_owner='tests/device/ios/adapters/lifecycle_touch_resource_owner.py';relative_keeper='tests/device/ios/pymobiledevice3_wda_xctest.py';relative_runtime='tests/device/ios/adapters/lifecycle_world_hold_runtime.py';maps={}
 if rootcase==11:
  maps['LIFECYCLE_RESOURCE_BORROW_MAP']={'resourceOwner':relative_owner,'keeper':relative_keeper};maps['LIFECYCLE_RESOURCE_CONSUMER_MAP']={'resourceOwner':relative_owner,'keeper':relative_keeper,'runtime':relative_runtime}
 else:maps['LIFECYCLE_MOTION_SOURCE_MAP']={'resourceOwner':relative_owner,'keeper':relative_keeper,'worldAttempt':'tests/device/ios/adapters/lifecycle_world_attempt.py','hostops':'tests/device/ios/appium_wda_host_ops.js'}
 dependencies=['tests/device/ios/self_tests/retained_host_roots.py','tests/device/adapters/original_frame_store.py','tests/device/adapters/script_feature/lock.py','tests/device/ios/adapters/hid_session.py','tests/device/ios/adapters/touch_lease.py','tests/device/ios/adapters/lifecycle_touch_transport.py','tests/device/ios/adapters/lifecycle_touch_resources.py','tests/device/ios/self_tests/lifecycle_touch_resources_fixture.py']
 if rootcase==7:dependencies+=['tests/device/ios/self_tests/test_ios_lifecycle_world_hold.py','tests/device/ios/self_tests/test_ios_lifecycle_world_attempt.py','tests/device/ios/self_tests/test_ios_lifecycle_editors.py','tests/device/ios/self_tests/test_ios_lifecycle_editor_history.py','tests/device/ios/self_tests/test_ios_lifecycle_originals.py','tests/device/ios/self_tests/test_ios_pending_runtime.py','tests/device/ios/self_tests/test_ios_keyboard_runtime.py','tests/device/ios/self_tests/test_ios_script_runtime.py','tests/device/ios/self_tests/test_ios_installed_adapter.py','tests/device/ios/adapters/lifecycle_world_hold.py','tests/device/ios/adapters/lifecycle_world.py','tests/device/ios/adapters/native_geometry.py']
 registry={'original-keeper-touch-resource':dict(current=2,reads=[2])}
 if rootcase==7:registry.update({'original-keeper-motion-preparation':dict(current=1,reads=[1]),'ios-lifecycle-touch-resource-owner':dict(current=2,reads=[1,2])})
 (stage/'run-selected.py').write_text(runner);ast.parse(runner)
 plan=dict(status='PRIVATE_UNRUN_ROOT_ONLY',caseCount=rootcase,cases=cases,initialOuterSeconds=cap,killAfterSeconds=5,repositoryRoot=str(R),privateFiles={p.name:h(p) for p in stage.iterdir() if p.suffix=='.py'},modelMaps=maps,requiredPublicDependencies=dependencies,registryRequirements=registry,mkdtempAliases=modules,retainInstalledFixture=rootcase==7,expectedRetainedRoots=11 if rootcase==11 else 14,expectationOnly=True,SDKImported=False,authQualified=False,canonicalGate=False,nativeTouch=False)
 (stage/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print('Root launchers prepared AST-only; no resolver/import/test/source execution.')
