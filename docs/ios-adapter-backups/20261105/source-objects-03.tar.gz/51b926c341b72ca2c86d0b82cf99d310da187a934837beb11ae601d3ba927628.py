from pathlib import Path
import ast,json,hashlib
r=Path.cwd().resolve();assert r.name=='overte-ios-feature-adapters-resume-20261026'and(r/'.git').is_file()
p=r/'.ios-host-tmp/c24-diagnostic-source3-closed-utility14-bootstrap1-code-preparation-20261104';assert p.resolve().is_relative_to(r)and not p.exists();p.mkdir()
b=r/'.ios-host-tmp/moving-c11-process-observation-own4-bootstrap1-code-preparation-20261104'
s=r/'.ios-host-tmp/assets-c24-policy-value-bounded-diagnostic-source3-unknown-mutating-c-return-private-20261104'
def put(n,t):
 q=p/n;assert q.resolve().is_relative_to(r);q.write_bytes(t if isinstance(t,bytes)else t.encode())
for n in ['metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','source_execution_readiness.py','readonly-shared-stdlib-sources.json']:put(n,(b/n).read_bytes())
for n in ['intent_graph_diagnostic.py','test_intent_graph_diagnostic.py']:put(n,(s/n).read_bytes())
put('exact-fourteen-selectors.json',(s/'prospective-fourteen-utility-selectors.json').read_bytes())
t=(b/'run-four.py').read_text().replace('Four genuine C11 state-observation utility counters','Fourteen pure C24 diagnostic utility counters').replace('PRIVATE_MOVING_C11_STATE_UTILITY4_UNRUN','PRIVATE_C24_DIAGNOSTIC_SOURCE3_UTILITY14_UNRUN').replace('exact-four-selectors.json','exact-fourteen-selectors.json')
t=t.replace("==4 and plan['wallSeconds']==30","==14 and plan['wallSeconds']==30")
t=t.replace('from python_children import PythonChildren\npython_children=PythonChildren(plan[\'pythonExecutable\'][\'path\'],plan[\'pythonExecutable\'][\'pin\'],HERE/\'own-toys\')\n','')
t=t.replace("'closed_import_origins','python_children','source_execution_readiness'","'closed_import_origins','source_execution_readiness'")
t=t.replace("        if self.name=='test_moving_process_observation':python_children.bind(module)\n",'')
t=t.replace("    if event=='subprocess.Popen':return python_children.spawn(args,sys._getframe(1))\n    if event=='os.posix_spawn':return python_children.posix_spawn(args,sys._getframe(1))\n    if event=='open'and python_children.open(args,sys._getframe(1)):return\n",'')
t=t.replace("event in('os.system'","event in('subprocess.Popen','os.system'")
a=t.index('from ios.self_tests.retained_host_roots import retain_owned_root');z=t.index('def observe_original_cleanup',a)
t=t[:a]+'''retained=[];cleanup_calls=[]
def denied_directory(*args,**kwargs):
    raise RuntimeError('Utility14 has zero temporary-directory constructors')
tempfile.TemporaryDirectory=denied_directory
''' +t[z:]
t=t.replace("python_children.record_birth=lambda body:save('actual-python-birth-'+str(len(python_children.rows))+'.json',body)\n",'')
t=t.replace('assert original_methods_unchanged()and tools_unchanged()','assert original_methods_unchanged()')
t=t.replace('        python_children.case_start=len(python_children.rows);python_children.current_case=test\n','')
t=t.replace('self.before=(fds(),tuple(threading.enumerate()),children(),len(cleanup_calls),len(retained))','self.before=(fds(),tuple(threading.enumerate()),children(),len(cleanup_calls),monitor_snapshot())')
t=t.replace('fd,threads,kernel,cleanup_count,roots=self.before','fd,threads,kernel,cleanup_count,monitor_before_case=self.before')
t=t.replace('monitorSlotsUnchanged=tools_unchanged()','monitorMasksSlotsUnchanged=monitor_snapshot()==monitor_before_case')
t=t.replace('newTemporaryDirectories=len(retained)-roots','newTemporaryDirectories=0')
a=t.index('        expected=2 if test.id()');z=t.index('        case_receipts.append',a);t=t[:a]+t[z:]
a=t.index('method_seals=[];');z=t.index('original_term=signal.getsignal',a)
t=t[:a]+'''method_seals=[];function_seals=[];module_members=[];code_objects=[]
monitor=sys.monitoring
monitor_port_names=('get_tool','get_events','get_local_events','set_local_events','set_events','register_callback','use_tool_id','free_tool_id')
monitor_ports=tuple((name,getattr(monitor,name))for name in monitor_port_names)
def remember_code(code):
    if code in code_objects:return
    code_objects.append(code)
    for item in code.co_consts:
        if type(item)is type(code):remember_code(item)
def monitor_snapshot():
    assert sys.monitoring is monitor and all(getattr(monitor,name)is port for name,port in monitor_ports)
    return tuple((monitor.get_tool(tool),monitor.get_events(tool),tuple(monitor.get_local_events(tool,code)for code in code_objects))for tool in range(6))
def bind_original_methods():
    declarations=(('intent_graph_diagnostic',('IntentGraphDiagnostic',)),
        ('test_intent_graph_diagnostic',('ProbePolicy','ProbeParentPolicy','GraphDiagnosticUtilityTests','GraphDiagnosticRestorationTests','GraphDiagnosticUnknownReturnTests')))
    for module_name,class_names in declarations:
        module=sys.modules[module_name]
        path=Path(vars(module)['__file__']);assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
        for name,fn in tuple(vars(module).items()):
            if type(fn)is type(bind_original_methods)and fn.__globals__ is vars(module):
                function_seals.append((module,name,fn,fn.__code__,fn.__globals__,fn.__defaults__,fn.__kwdefaults__,fn.__closure__))
                remember_code(fn.__code__)
        for class_name in class_names:
            cls=vars(module)[class_name];module_members.append((module,module_name,class_name,cls))
            for name,member in cls.__dict__.items():
                fn=member.__func__ if type(member)in(classmethod,staticmethod)else member
                if hasattr(fn,'__code__'):
                    method_seals.append((module,cls,name,member,fn,fn.__code__,fn.__globals__,fn.__defaults__,fn.__kwdefaults__,fn.__closure__))
                    remember_code(fn.__code__)
def original_methods_unchanged():
    for module,name,fn,code,namespace,defaults,keywords,closure in function_seals:
        assert vars(module)[name]is fn and fn.__code__ is code and fn.__globals__ is namespace is vars(module)
        assert fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
    for module,module_name,class_name,cls in module_members:
        assert sys.modules.get(module_name)is module and vars(module)[class_name]is cls
    for module,cls,name,member,fn,code,namespace,defaults,keywords,closure in method_seals:
        assert cls.__dict__[name]is member and fn.__code__ is code and fn.__globals__ is namespace is vars(module)
        assert fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
    return True
monitor_suite_before=None
''' +t[z:]
t=t.replace("    import test_moving_process_observation as subject_tests\n    subject_tests.configure(TOYS,Path(plan['pythonExecutable']['path']),plan['pythonExecutable']['pin']['sha256'])\n",'')
t=t.replace('suite.countTestCases()==4','suite.countTestCases()==14')
t=t.replace('bind_original_methods();assert original_methods_unchanged()','bind_original_methods();monitor_suite_before=monitor_snapshot();assert original_methods_unchanged()')
a=t.index('        for row in retained:');z=t.index('        nested_ok=',a);t=t[:a]+t[z:]
t=t.replace('result.testsRun==4','result.testsRun==14')
a=t.index('        passed=passed and len(retained)==1');z=t.index('        passed=passed and after==',a)
t=t[:a]+'''        passed=passed and len(case_receipts)==14 and all(row['remainingStandardCleanups']==0 and row['fdUnchanged']and row['threadsUnchanged']and row['kernelChildrenUnchanged']and row['monitorMasksSlotsUnchanged']for row in case_receipts)
        passed=passed and monitor_suite_before is not None and monitor_snapshot()==monitor_suite_before and sys.getprofile()is original_profile
''' +t[z:]
t=t.replace("plan['subjectOriginCount']==4","plan['subjectOriginCount']==2").replace('allFourActualRuntimeOriginsEstablished','allTwoActualRuntimeOriginsEstablished')
t=t.replace("save('actual-observation-cases.json',subject_tests.actual_records());save('actual-utility-children.json',[item for row in case_receipts for item in row['actualUtilityChildren']]);",'')
t=t.replace('PythonExecutions=len(python_children.rows)','PythonExecutions=0')
a=t.index('        assert tools_unchanged()');z=t.index('        tail=RECEIPTS',a)
t=t[:a]+'''        monitor_restored=monitor_suite_before is not None and monitor_snapshot()==monitor_suite_before
        tools_restored=tempfile.TemporaryDirectory is original_td and unittest.TestCase.doCleanups is original_cleanup and time.time is original_time and monitor_restored and sys.getprofile()is original_profile
''' +t[z:]
t=t.replace("and not td_callers and original_methods_unchanged()and tools_unchanged()","and not td_callers and original_methods_unchanged()")
# SOURCE-only invalidated import masks/callback windows cannot open a feature gate.
put('run-fourteen.py',t)
t=(b/'prepare.py').read_text().replace('Moving C11 State Own4','C24 diagnostic pure Utility14')
t=t.replace("SUBJECT=REPO/'.ios-host-tmp/moving-c11-real-process-state-own4-utility-source1-private-20261104'","SUBJECT=REPO/'.ios-host-tmp/assets-c24-policy-value-bounded-diagnostic-source3-unknown-mutating-c-return-private-20261104'")
t=t.replace("SUBJECT_SHA='b54758ad7298aad59a3c26ced418e00a054a893a3d89b5d61a0efb949e229e18'","SUBJECT_SHA='5430c80f66b464f1cb233e54482323b55c1b3cb95ef794b1df2d14e382b5ddfd'")
a=t.index('EXECUTORS=');z=t.index('\ndef frozen',a)
t=t[:a]+'''EXECUTORS=('run-fourteen.py','supervise-fourteen.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','source_execution_readiness.py','readonly-shared-stdlib-sources.json','intent_graph_diagnostic.py','test_intent_graph_diagnostic.py','exact-fourteen-selectors.json')
''' +t[z:]
a=t.index("    for name in('moving_owned_identity.py'");z=t.index('    current_qualification',a)
t=t[:a]+'''    for name in('intent_graph_diagnostic.py','test_intent_graph_diagnostic.py'):assert(SOURCE/name).read_bytes()==(SUBJECT/name).read_bytes()
    for row in json.loads((SUBJECT/'SOURCE-REFERENCES.json').read_text())['rows']:
        path=Path(row['path']);actual=pin(path);assert actual['sha256']==row['sha256']and actual['bytes']==row['bytes'];physical[str(path)]=actual
''' +t[z:]
t=t.replace("startswith('moving-c11-state-own4-prepared-')","startswith('c24-diagnostic-utility14-prepared-')")
a=t.index('    modules={');z=t.index('    origin=dict',a)
t=t[:a]+'''    modules={name:dict(path=str(dest/(name+'.py')),sha256=physical[str(dest/(name+'.py'))]['sha256'],package=False,loader='source')for name in('metadata_reader','host_common','source_execution_readiness','closed_import_origins','owned_write_boundary','intent_graph_diagnostic','test_intent_graph_diagnostic')}
    cases=json.loads((SOURCE/'exact-fourteen-selectors.json').read_text());assert len(cases)==len(set(cases))==14
    subjects={name:dict(path=modules[name]['path'],sha256=modules[name]['sha256'])for name in('intent_graph_diagnostic','test_intent_graph_diagnostic')}
''' +t[z:]
t=t.replace('namespacePackages=project_namespaces','namespacePackages={}').replace('namespaces=project_namespaces','namespaces={}')
t=t.replace('PRIVATE_MOVING_C11_STATE_UTILITY4_UNRUN','PRIVATE_C24_DIAGNOSTIC_SOURCE3_UTILITY14_UNRUN')
t=t.replace("utilitySubjectSourceFreeze=SUBJECT_SHA,kernelSubjectSha256='08263283e4c2a687fbbb468cb87c6025b2e424edb70be744fddf6ed0ebdee30f'","utilitySubjectSourceFreeze=SUBJECT_SHA")
t=t.replace('subjectOriginCount=4','subjectOriginCount=2').replace('PythonExecutions=5,maximumLiveUtilityChildren=2,expectedTemporaryDirectories=1,expectedTemporaryDirectoriesPerCase=[0,0,0,1]','PythonExecutions=0,maximumLiveUtilityChildren=0,expectedTemporaryDirectories=0,expectedTemporaryDirectoriesPerCase=0,expectedJoinedThreadCases=1')
t=t.replace('processObservationUtilityRootProof=None,movingAdmissionQualified=False','utilityQualification=None,diagnosticAdmission=None,assetsPhaseQualified=False').replace('cases=4,targets=0','cases=14,targets=0')
put('prepare.py',t)
for q in p.glob('*.py'):ast.parse(q.read_text(),filename=str(q))
print(p)
