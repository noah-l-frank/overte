"""One new Callback8 vertical End; actual host producers, explicit raw models."""
from pathlib import Path
from types import FrameType
import builtins,faulthandler,hashlib,importlib.abc,importlib.machinery,importlib.util,io,json,os,signal,socket,socketserver,stat,subprocess,sys,tempfile,threading,time,traceback,unittest
from metadata_reader import pin,load
from closed_import_origins import ClosedOrigins
from host_common import head
from admission import require
from project_namespace_admission import project_namespace_admission
from resources import Resources
from locks import Locks
from kernel import process,state,census
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True);TEMP=HERE/'temporary'
assert sys.flags.no_site==1 and sys.dont_write_bytecode and len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=load(INPUT);assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)and head()==plan['expectedHead']
assert plan['status']=='PRIVATE_ONE_CALLBACK3_POSITIVE_UNRUN_ROOT_REVIEW_REQUIRED'
assert plan['cases']==load(HERE/'exact-one-selector.json')and len(plan['cases'])==1
assert plan['wallSeconds']==300 and plan['killGraceSeconds']==5 and len(plan['productionOverlays'])==20
assert not plan['nativeQualified']and not plan['wholeQualified']and not plan['publicFinishEnabled']
assert TEMP.is_dir()and not any(TEMP.iterdir())and os.environ['TMPDIR']==str(TEMP)and Path(tempfile.gettempdir())==TEMP
PINS=plan['sourceAndBinaryPins'];assert {p:pin(p)for p in PINS}==PINS
current_readiness,current_readiness_pins=require(plan['rootAdmission'],pin)
assert current_readiness==plan['qualifiedSourceExecution']and current_readiness['consumerCompositionQualified']is False
assert plan['subjectSourceFreeze']==current_readiness['subjectSourceFreeze']and plan['subjectHelperSha256']==current_readiness['helperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
assert pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
assert plan['helperQualificationRequiredOriginalRooms']==current_readiness['requiredOriginalRoots']
assert all(PINS.get(path)==row for path,row in current_readiness_pins.items())
assert plan['kernelVariantAdmission']is not None,'B12 has no qualified owned-exit/zombie kernel variant'
bare_aliases=load(HERE/'declared-bare-source-aliases.json');assert bare_aliases==plan['bareSourceAliasAdmission']
assert set(bare_aliases)=={'schemaVersion','status','aliases'}and bare_aliases['schemaVersion']==1
assert bare_aliases['status']=='EXACT_FOUR_GENUINE_DEFINITION_ALIASES_NOT_FALLBACK'and len(bare_aliases['aliases'])==4
assert {r['name']for r in bare_aliases['aliases']}=={'test_native_feature_observation','test_native_script_roots','test_emote_source_profile','test_native_script_observation'}
for alias in bare_aliases['aliases']:
    assert set(alias)=={'name','canonical','path','sha256','package'}and alias['package']is False
    path=REPO/'tests/device/self_tests'/(alias['name']+'.py');assert str(path)==alias['path']and path.resolve(strict=True)==path and not path.is_symlink()
    assert [str((base/(alias['name']+'.py')).resolve(strict=True))for base in(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests')if(base/(alias['name']+'.py')).is_file()]==[str(path)]
    assert alias['canonical']=='self_tests.'+alias['name']
    assert plan['modules'][alias['name']]==plan['modules'][alias['canonical']]==dict(path=str(path),sha256=alias['sha256'],package=False)
    assert plan['sourceAndBinaryPins'][str(path)]==pin(path)and plan['sourceAndBinaryPins'][str(path)]['sha256']==alias['sha256']
namespace_declared=dict(plan['modules'])
for name,row in plan['projectAliasAdmission']['unadmittedAliases'].items():
    assert name not in namespace_declared;namespace_declared[name]=row['origin']
namespace_modules,namespace_paths,namespace_original=project_namespace_admission(namespace_declared,
    (REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests'))
assert namespace_modules==plan['modules']and namespace_paths==plan['originPlan']['namespacePackages']and namespace_original==plan['projectAliasAdmission']
assert plan['originPlan']['modules']==plan['modules']and plan['originPlan']['projectAliasAdmission']==plan['projectAliasAdmission']
for name,row in namespace_declared.items():
    assert row['path']in plan['sourceAndBinaryPins']and pin(row['path'])==plan['sourceAndBinaryPins'][row['path']]
    assert row['sha256']==plan['sourceAndBinaryPins'][row['path']]['sha256']

assert plan['originPlan']['physicalPins']==PINS
original_path=tuple(sys.path);original_meta=tuple(sys.meta_path)
original_io=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
original_td=tempfile.TemporaryDirectory;original_cleanup=unittest.TestCase.doCleanups
original_time=time.monotonic;original_monitor=(sys.monitoring.get_tool,sys.monitoring.get_events,sys.monitoring.get_local_events,
    sys.monitoring.use_tool_id,sys.monitoring.set_events,sys.monitoring.set_local_events,sys.monitoring.register_callback,sys.monitoring.free_tool_id)
monitor_before=[(sys.monitoring.get_tool(i),sys.monitoring.get_events(i))for i in range(6)]
assert sys.gettrace()is sys.getprofile()is None
assert all(name is None and mask==0 for name,mask in monitor_before),'No existing tool slot is taken over'
resources=Resources(plan,HERE,pin,process);locks=Locks(TEMP)
origins=ClosedOrigins(plan['originPlan'],HERE,REPO,pin);origin_before=origins.snapshot('before-one-emote-positive-imports')
bootstrap={name:module for name,module in sys.modules.items()if module is not None and getattr(module,'__file__',None)and Path(module.__file__).parent==HERE}
for name,row in plan['modules'].items():
    if name in bootstrap:assert str(Path(bootstrap[name].__file__))==row['path']
    else:assert name not in sys.modules
sys.path[:]=[s for s in sys.path if s and not Path(s).resolve().is_relative_to(REPO)]
tops={name.split('.')[0]for name in(*plan['modules'],*plan['originPlan']['namespacePackages'],*plan['originPlan']['thirdPartyModules'])}
forbidden={'pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright'}
loaded={};handlers={};coverage={};coverage_seals=[];monitor_errors=[];cleanup_rows=[];retained=[];retained_objects=[];refusals=[]
closed=False;tail_births={};tail_used=set();result=None;fatal=None;resources_receipt=None;lock_receipt=None

def observe(code,offset,*rest):
    frame=sys._getframe(1)
    try:
        assert type(frame)is FrameType and frame.f_code is code
        for event,fn in handlers.get(code,()):
            if event==('return'if rest else'start'):fn(frame,*rest)
    except BaseException as error:
        monitor_errors.append(dict(code=code.co_filename+':'+code.co_name,error=repr(error)));raise

def arm(fn,event,callback):
    code=fn.__code__;handlers.setdefault(code,[]).append((event,callback))
    events=0
    for kind,unused in handlers[code]:events|=sys.monitoring.events.PY_RETURN if kind=='return'else sys.monitoring.events.PY_START
    sys.monitoring.set_local_events(tool,code,events)

def actual_cleanup(frame,value):
    assert frame.f_globals is original_cleanup.__globals__ and unittest.TestCase.doCleanups is original_cleanup
    case=frame.f_locals['self'];assert isinstance(case,unittest.TestCase)
    cleanup_rows.append(dict(case=type(case).__module__+'.'+type(case).__qualname__,returned=value,remaining=len(case._cleanups)))

def bind_module(name,module):
    resources.loaded(name,module);locks.loaded(name,module)
    if name=='ios.self_tests.emote_active_actor_fixture':arm(vars(module)['ActiveActorFixture'].receive_reader,'return',lambda frame,value:resources.reader_return(frame))
    selected={
        'ios.adapters.emote_callback_process_end':('IOSEmoteCallbackProcessEnd',('prepare','stop','advance')),
        'ios.adapters.emote_callback_session_end':('IOSEmoteCallbackSessionEnd',('qualify','finish','completed')),
        'ios.adapters.emote_callback_end_archive':('IOSEmoteCallbackEndArchive',('verify','prepare','retire')),
        'ios.adapters.emote_callback_finish':('IOSEmoteCallbackFinish',('invoke',)),
        'ios.adapters.emote_runtime':('IOSEmoteRuntime',('_emote_callback_stop','_emote_callback_end_checkpoint'))}
    if name in selected:
        cls_name,members=selected[name];cls=vars(module)[cls_name]
        for member in members:
            wrapper=cls.__dict__[member];fn=wrapper
            while hasattr(fn,'__wrapped__'):fn=fn.__wrapped__
            label=name+'.'+cls_name+'.'+member;coverage[label]=0
            coverage_seals.append((cls,member,wrapper,wrapper.__code__,wrapper.__globals__,fn,fn.__code__,fn.__globals__))
            def hit(frame,_label=label,_fn=fn):
                assert frame.f_code is _fn.__code__ and frame.f_globals is _fn.__globals__;coverage[_label]+=1
            arm(fn,'start',hit)
    # Original NativeClockAcquisition owners over the declared model readers
    # remain genuine and unchanged. No device/SDK executable endpoint is open.

class AfterActualLoader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name,self.delegate=name,delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module)
        loaded[self.name]=vars(module)['__file__'];assert pin(loaded[self.name])==PINS[loaded[self.name]]
        bind_module(self.name,module)
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in forbidden:raise ImportError('Installed SDK/browser imports are closed')
        row=plan['modules'].get(name)
        if row is not None:
            spec=origins.file_spec(name,dict(row,loader='source'),'project');spec.loader=AfterActualLoader(name,spec.loader);return spec
        namespace=plan['originPlan']['namespacePackages'].get(name)
        if namespace is not None:
            origins.namespaces(name,namespace,namespace,'project');spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=namespace;return spec
        if name in plan['originPlan']['thirdPartyModules']:return origins.remaining_spec(name,path)
        if name.split('.')[0]in tops:raise ImportError('Undeclared project/Pillow source: '+name)
        return origins.remaining_spec(name,path)

finder=Finder();sys.meta_path.insert(0,finder)
protected=[INPUT,*map(Path,PINS)]
for fd in(1,2):
    path=Path(os.readlink('/proc/self/fd/'+str(fd)));assert path.is_relative_to(HERE)and path.resolve(strict=True)==path;protected.append(path)
resources.start(protected)
metadata_pin=pin;metadata_code=pin.__code__;metadata_globals=pin.__globals__
public_reads=load(HERE/'readonly-own-public-source-verification.json')
allowed_public=set(public_reads['paths'])
assert len(allowed_public)==8 and all(p in PINS for p in allowed_public)

def tail_write(path,value):
    assert closed and path in tail_births and path not in tail_used and pin(path)==tail_births[path]
    assert all(getattr(os,k)is v for k,v in resources.original_items)and os.read is resources.original_read
    assert original_io==(io.open,builtins.open)and original_dup==(os.dup,os.dup2)
    with original_io[0](path,'w',encoding='utf-8')as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    tail_used.add(path)
tail_function=tail_write;tail_code=tail_write.__code__;tail_globals=tail_write.__globals__

def audit(event,args):
    # Exact union of the security/resource branches below. In particular,
    # sys._getframe and object.__getattr__ had no old branch; inspect no frame
    # for them. No event is admitted by a reentrancy flag or a fake caller.
    classified=(event in ('import','open','os.system','os.exec','os.posix_spawn',
        'os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.killpg','os.setsid',
        'os.setpgid','subprocess.Popen','os.kill','os.remove','os.rmdir','os.mkdir',
        'os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink',
        'os.setxattr','os.removexattr','os.chdir','os.chroot')
        or event.startswith(('os.spawn','fcntl.','socket.')))
    if not classified:return
    frame=sys._getframe(1)
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Installed SDK/browser import refused')
    if event=='open'and type(args[0])in(str,bytes):
        path=Path(os.fsdecode(args[0]));parts=path.parts
        sdk=any(x in('pymobiledevice3','appium','selenium','playwright','tidevice','pyidevice')for x in parts)
        if sdk:
            assert str(path)in allowed_public and path.is_absolute()and path.resolve(strict=True)==path
            assert args[1]is None and args[2]==os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC
            pin_frame=resources.metadata_pin_caller(args,frame)
            assert pin_frame.f_code is metadata_code and pin_frame.f_globals is metadata_globals and metadata_pin is pin and pin.__code__ is metadata_code
            assert pin_frame.f_locals.get('path')==path and path.lstat().st_nlink==1
    if event in('os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('Undeclared process/compiler/native/signal port')
    if event.startswith('fcntl.'):
        assert not closed and event=='fcntl.flock';locks.check(args,frame);return
    relevant=event=='open'or event.startswith('socket.')or event in('subprocess.Popen','os.kill','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')
    if not relevant:return
    if closed:
        if event=='open':
            path,mode,flags=args;writing=flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)or type(mode)is str and any(c in mode for c in'wax+')
            if not writing:return
            path=Path(path);assert path in tail_births and path not in tail_used and pin(path)==tail_births[path]
            assert frame.f_code is tail_code and frame.f_globals is tail_globals and tail_function is tail_write and frame.f_locals.get('path')==path
            assert mode=='w'and flags==os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC
            return
        if event in('os.listdir','os.scandir'):return
        raise RuntimeError('Mutation/process/socket after restoration')
    try:resources.audit(event,args,frame)
    except BaseException as error:refusals.append(dict(event=event,error=repr(error)));raise
sys.addaudithook(audit)
tool=next(i for i in range(6)if sys.monitoring.get_tool(i)is None);sys.monitoring.use_tool_id(tool,'emote-callback-positive-resource-custody')
sys.monitoring.register_callback(tool,sys.monitoring.events.PY_START,observe);sys.monitoring.register_callback(tool,sys.monitoring.events.PY_RETURN,observe)
arm(resources.popen_init,'start',resources.node_start);arm(resources.popen_init,'return',lambda frame,value:resources.node_return(frame))
arm(socket.socket.__init__,'return',lambda frame,value:resources.socket_return(frame))
arm(resources.http_connect,'return',lambda frame,value:resources.http_return(frame))
arm(resources.tcp_init,'return',lambda frame,value:resources.server_return(frame));arm(resources.thread_start,'start',resources.thread_birth)
arm(original_cleanup,'return',actual_cleanup)
from ios.self_tests.retained_host_roots import retain_owned_root
retain_original=retain_owned_root;retain_code=retain_original.__code__;retain_globals=retain_original.__globals__
class RetainedTemporaryDirectory(original_td):
    def __init__(self,*args,**kwargs):
        caller=sys._getframe(1);role=resources.td_role(caller);assert not args and not kwargs
        assert retain_original.__code__ is retain_code and retain_original.__globals__ is retain_globals
        super().__init__(dir=TEMP);root=Path(self.name);assert root.parent==TEMP and root.resolve(strict=True)==root
        retain_original(self,expected_root=root);info=root.lstat();retained_objects.append(self)
        resources.tds.append(dict(role=role,path=str(root),device=info.st_dev,inode=info.st_ino));retained.append(str(root))
tempfile.TemporaryDirectory=RetainedTemporaryDirectory

def save(name,value):
    path=HERE/'child-receipts'/name
    with path.open('x')as stream:stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n')
    path.chmod(0o600)

for name in('actual-restoration.json','child-result.json'):
    path=HERE/'child-receipts'/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.close(fd);tail_births[path]=pin(path)
    resources.helper.protected.add(path)

before=state();started=original_time();origin_after=None;checks={};failures=[]
term_signal=signal.getsignal(signal.SIGTERM);term_stream=(HERE/'child-logs/term-stack.log').open('ab',buffering=0)
faulthandler.register(signal.SIGTERM,file=term_stream,all_threads=True,chain=True)
def independently(name,fn):
    try:
        value=fn();checks[name]=True if value is None else value;return checks[name]
    except BaseException as error:
        failures.append(dict(gate=name,error=repr(error),traceback=traceback.format_exc()));checks[name]=False;return False
try:
    module_name,cls_name,method_name=plan['cases'][0].rsplit('.',2);assert module_name in plan['modules']
    module=importlib.import_module(module_name);case_class=vars(module)[cls_name]
    suite=unittest.defaultTestLoader.loadTestsFromName(cls_name+'.'+method_name,module)
    assert suite.countTestCases()==1
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
except BaseException:
    fatal=traceback.format_exc()
finally:
    # Each failed check is retained independently. No finalizer failure may
    # replace the actual original failure or prevent the real drain/restore.
    independently('originSnapshot',lambda:origins.snapshot('after-positive-and-real-standard-cleanup'))
    def graph_coverage():
        assert len(coverage)==12 and all(value>0 for value in coverage.values())
        for cls,member,wrapper,code,ns,fn,body,globals_ in coverage_seals:
            assert cls.__dict__[member]is wrapper and wrapper.__code__ is code and wrapper.__globals__ is ns
            current=wrapper
            while hasattr(current,'__wrapped__'):current=current.__wrapped__
            assert current is fn and fn.__code__ is body and fn.__globals__ is globals_
        for row in plan['productionOverlays']:
            name='.'.join(Path(row['logical']).relative_to('tests/device').with_suffix('').parts)
            assert name in loaded and loaded[name]==row['path']
        return True
    independently('actualTypedGraphCoverageAnd20Origins',graph_coverage)
    independently('resourceReceipt',resources.finish)
    independently('lockReceipt',locks.finish)
    independently('sourcePins',lambda:{p:pin(p)for p in PINS}==PINS)
    if result is None or not result.wasSuccessful()or fatal or failures:independently('failureOnlyDrain',resources.abort)
    tempfile.TemporaryDirectory=original_td
    independently('originalCleanupUnchanged',lambda:unittest.TestCase.doCleanups is original_cleanup)
    independently('genuineStandardCleanup',lambda:bool(cleanup_rows)and all(r['returned']is True and r['remaining']==0 for r in cleanup_rows))
    independently('monitorErrorsAbsent',lambda:not monitor_errors)
    independently('auditRefusalsAbsent',lambda:not refusals)
    for code in tuple(handlers):independently('disableLocal:'+code.co_filename+':'+code.co_name,lambda code=code:sys.monitoring.set_local_events(tool,code,0))
    independently('disableGlobal',lambda:sys.monitoring.set_events(tool,0))
    independently('unregisterStart',lambda:sys.monitoring.register_callback(tool,sys.monitoring.events.PY_START,None))
    independently('unregisterReturn',lambda:sys.monitoring.register_callback(tool,sys.monitoring.events.PY_RETURN,None))
    independently('releaseTool',lambda:sys.monitoring.free_tool_id(tool))
    independently('toolRestoration',lambda:[(sys.monitoring.get_tool(i),sys.monitoring.get_events(i))for i in range(6)]==monitor_before)
    independently('CioDupUnchanged',lambda:original_io==(io.open,builtins.open)and original_dup==(os.dup,os.dup2))
    independently('termSignalUnregister',lambda:faulthandler.unregister(signal.SIGTERM))
    independently('termStreamClose',lambda:(term_stream.close(),term_stream.closed)[1])
    independently('termSignalRestoration',lambda:signal.getsignal(signal.SIGTERM)==term_signal)
    independently('fdThreadKernelDrain',lambda:state()==before)
    first=independently('firstRetainedCensus',lambda:census(TEMP));second=independently('secondRetainedCensus',lambda:census(TEMP))
    independently('retainedCensusesEqual',lambda:first==second)
    independently('receipt:retained-first',lambda:save('retained-first.json',first))
    independently('receipt:retained-second',lambda:save('retained-second.json',second))
    independently('receipt:origins',lambda:save('actual-origins.json',checks.get('originSnapshot')))
    independently('receipt:cleanups',lambda:save('actual-original-cleanups.json',cleanup_rows))
    independently('receipt:resources',lambda:save('actual-resources.json',dict(typedResourceReceipt=checks.get('resourceReceipt'),
        nodes=[dict(role=r['role'],birth=r.get('birth'),returnCode=r['process'].poll(),signals=r.get('signals',[]),
        streams=[dict(name=q['name'],path=str(q['path']),actualBytes=q['buffer'].count,closed=q['text'].closed)for q in r.get('streams',[])])for r in resources.nodes],
        temporaryRoots=resources.tds,independentlyChosenDeclaredModelArtifact=resources.artifact,partialFailureDrains=resources.partial_drains)))
    independently('receipt:boundary',lambda:save('actual-original-boundary-model-scope.json',plan['resourceContract']))
    independently('receipt:coverage',lambda:save('actual-typed-graph-code-hits.json',coverage))
    independently('receipt:failures',lambda:save('actual-failures.json',dict(originalFatal=fatal,independentFailures=failures,monitorErrors=monitor_errors,auditRefusals=refusals)))
    independently('actualPortRestore',resources.restore);closed=True
    sys.meta_path[:]=original_meta;sys.path[:]=original_path
    restoration=dict(all27OriginalOsPorts=all(getattr(os,k)is v for k,v in resources.original_items),originalRead=os.read is resources.original_read,
        Cio=original_io==(io.open,builtins.open),dup=original_dup==(os.dup,os.dup2),controlDescriptors=list(resources.helper.control_fds),tools=checks.get('toolRestoration')is True,actualC10dHelperSha256=pin(HERE/'closed_import_origins.py')['sha256'])
    tail_write(HERE/'child-receipts/actual-restoration.json',restoration)
    ok=bool(result is not None and result.testsRun==1 and result.wasSuccessful()and fatal is None and not failures and all(v is not False for v in checks.values())and all(restoration[k]is True for k in('all27OriginalOsPorts','originalRead','Cio','dup','tools'))and not restoration['controlDescriptors'])
    tail_write(HERE/'child-receipts/child-result.json',dict(status='PASS'if ok else'FAIL',selected=plan['cases'],testsRun=None if result is None else result.testsRun,
        elapsedSeconds=original_time()-started,standardRunReturned=result is not None,standardUnittestSuccessful=result is not None and result.wasSuccessful(),
        originalFatal=fatal,independentFailures=failures,checks={k:bool(v)for k,v in checks.items()},nativeQualified=False,wholeQualified=False,publicFinishEnabled=False,
        inputSha256=sys.argv[2],source3Freeze=plan['source3Freeze'],subjectHelperSha256=plan['subjectHelperSha256'],currentSourceExecutionRootFreeze=plan['qualifiedSourceExecution']['rootFreeze']))
sys.exit(0 if ok else 1)
