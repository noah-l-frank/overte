"""Root-reviewed inputs required; exact11 pre-spawn/resolver counters only."""
from pathlib import Path
import builtins,hashlib,importlib.abc,importlib.util,io,json,os,signal,socket,stat,sys,threading,time,traceback,unittest

HERE=Path(__file__).resolve().parent
REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT.parent==HERE and INPUT.name=='approved-inputs.json'
assert hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['repositoryRoot']==str(REPO)and plan['controllerRoot']==str(HERE)
assert len(plan['cases'])==len(set(plan['cases']))==11 and plan['wallSeconds']==30 and plan['killGraceSeconds']==5

def pin(path):
    path=Path(path);before=path.lstat();assert path.resolve(strict=True)==path and stat.S_ISREG(before.st_mode)
    raw=path.read_bytes();after=path.lstat();fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    value=dict(stat=[getattr(before,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest())
    assert value['stat']==[getattr(after,key)for key in fields];return value

assert {path:pin(path)for path in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
assert all(pin(row['path'])==plan['sourceAndBinaryPins'][row['path']]for row in plan['modules'].values())
assert not any(name in sys.modules for name in plan['modules'])
project_tops={'ios','adapters','feature_journeys','pymobiledevice3','appium'}|{name.split('.')[0]for name in plan['modules']}
loaded={};original_meta=tuple(sys.meta_path);original_path=tuple(sys.path)
sys.path[:]=[entry for entry in sys.path if entry and not Path(entry).resolve().is_relative_to(REPO)]
class Loader(importlib.abc.Loader):
    def __init__(self,name,row):self.name,self.row=name,row
    def create_module(self,spec):return None
    def exec_module(self,module):
        path=Path(self.row['path']);assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
        raw=path.read_bytes();module.__file__=str(path);loaded[self.name]=str(path)
        exec(compile(raw,str(path),'exec'),module.__dict__)
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        row=plan['modules'].get(name)
        if row is not None:return importlib.util.spec_from_loader(name,Loader(name,row),is_package=False)
        if name.split('.')[0]in project_tops:raise ImportError('Unmapped project/SDK import refused: '+name)
        spec=importlib.machinery.PathFinder.find_spec(name,path)
        if spec is not None and spec.origin not in(None,'built-in','frozen'):
            origin=Path(spec.origin).resolve(strict=True);stdlib=Path(os.__file__).resolve(strict=True).parent
            assert origin.is_relative_to(stdlib)and 'site-packages'not in origin.parts,'Non-stdlib fallback import refused'
            return spec
        if spec is not None and spec.origin is None:
            assert all(Path(entry).resolve(strict=True).is_relative_to(Path(os.__file__).resolve(strict=True).parent)for entry in spec.submodule_search_locations)
            return spec
        return None
finder=Finder();sys.meta_path.insert(0,finder)
os.environ['MOVING_PRESPAWN_APPROVED_INPUTS']=str(INPUT)
os.environ['MOVING_PRESPAWN_APPROVED_INPUTS_SHA256']=sys.argv[2]
TOYS=HERE/'own-toys';RECEIPTS=HERE/'child-receipts'
assert TOYS.is_dir()and not list(TOYS.iterdir())and RECEIPTS.is_dir()and not list(RECEIPTS.iterdir())
os.environ['MOVING_PRESPAWN_OUTPUT_ROOT']=str(TOYS)
# Exact observer hook FIRST. Its genuine writable pipe gate runs before the
# independent outer own-file audit, and subprocess events always throw here.
import moving_prespawn_counter_observer as observer
observer.install()
from moving_host_ports import MovingNodePort,OwnedLoopbacks
from owned_write_boundary import OwnedWrites
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={name:getattr(os,name)for name in ports if hasattr(os,name)}
original_io=(io.open,builtins.open);original_cleanup=unittest.TestCase.doCleanups
code_seals=[]
for cls in(observer.OriginalPreSpawnObserver,MovingNodePort,OwnedLoopbacks):
    for name,member in cls.__dict__.items():
        fn=member.__func__ if type(member)is staticmethod else member
        if type(fn)is type(observer.audit):code_seals.append((cls,name,member,fn,fn.__code__,fn.__globals__))
observer_audit=(observer.audit,observer.audit.__code__,observer.audit.__globals__)
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):
    actual=Path(os.readlink('/proc/self/fd/'+str(fd)));assert actual.resolve(strict=True)==actual and actual.is_relative_to(HERE);protected.append(actual)
boundary=OwnedWrites(HERE,protected=protected)

def literal_code_guard():
    assert observer.audit is observer_audit[0]and observer.audit.__code__ is observer_audit[1]and observer.audit.__globals__ is observer_audit[2]
    for cls,name,member,fn,code,namespace in code_seals:
        assert cls.__dict__.get(name)is member and fn.__code__ is code and fn.__globals__ is namespace

def pipe_ack(args,caller):
    descriptor,mode,flags=args
    if type(descriptor)is not int:return False
    info=os.fstat(descriptor)
    if not stat.S_ISFIFO(info.st_mode):return False
    literal_code_guard();current=observer._ACTIVE
    assert type(current)is observer.OriginalPreSpawnObserver and type(current.port)is MovingNodePort
    constructor,unused=current.port.frames(caller)
    assert current.actual_constructor is current.port.pending is constructor.f_locals['self']
    assert descriptor==constructor.f_locals['p2cwrite']and mode in('w','wb')and len(current.port.pipe_opens)==1
    row=current.port.pipe_opens[0]
    assert(row['descriptor'],row['device'],row['inode'])==(descriptor,info.st_dev,info.st_ino)
    return True

created_sockets=[]
def socket_ack(event,args,caller):
    literal_code_guard()
    if event=='socket.__new__':
        owner,family,kind,protocol=args
        assert family in(socket.AF_INET,socket.AF_INET6)and kind==socket.SOCK_STREAM and protocol in(0,socket.IPPROTO_TCP)
        created_sockets.append(owner);return
    current=observer._ACTIVE
    assert type(current)is observer.OriginalPreSpawnObserver and type(current.loopbacks)is OwnedLoopbacks
    scope=current.loopbacks;scope.check()
    if event=='socket.bind':
        owner,address=args;assert any(owner is old for old in created_sockets)
        signature=scope.signature(owner);endpoint=scope.endpoint(signature[0],address);assert endpoint[1]==0
        assert any(row[0]is owner and row[1]==signature and row[2]==endpoint for row in scope.servers)
        return
    if event=='socket.gethostbyaddr':
        held=scope.host_readers
        assert caller.f_code is held[1]and caller.f_globals is held[2]
        parent=caller.f_back;assert parent.f_code is held[5]and parent.f_globals is held[6]
        owner=parent.f_locals['self'].socket;assert any(owner is old for old in created_sockets)
        signature=scope.signature(owner);assert scope.resolver_reads
        row=scope.resolver_reads[-1]
        assert row['numericHost']==args[0]and(row['socketDevice'],row['socketInode'])==signature[2:4]
        return
    raise RuntimeError('Own11 admits no connect/payload/resolution outside original server bind')

def audit(event,args):
    if event=='import':
        name=args[0]
        if name.split('.')[0]in('ios','adapters','feature_journeys','pymobiledevice3','appium','zeroconf','tidevice'):raise RuntimeError('Product/SDK import forbidden')
    if event.startswith('socket.'):
        socket_ack(event,args,sys._getframe(1));return
    if event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('No counter subprocess/native SDK/target signals admitted')
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if relevant:
        if event=='open':
            unused,mode,flags=args
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in'wax+')
            if not writing:return
            if pipe_ack(args,sys._getframe(1)):return
        boundary.audit(event,args,sys._getframe(1))

boundary.install();sys.addaudithook(audit)
def save(name,body):
    path=RECEIPTS/name
    with path.open('x')as stream:stream.write(json.dumps(body,sort_keys=True,indent=2)+'\n')
    path.chmod(0o600)

fd_before=observer.fds();threads_before=tuple(threading.enumerate());children_before=observer.children()
result=None;fatal=None;selected=[];cleanup_rows=[];cleanup_ok=True
original_term=signal.getsignal(signal.SIGTERM)
def interrupted(signum,frame):raise KeyboardInterrupt('Fixed30-second own11 boundary')
signal.signal(signal.SIGTERM,interrupted)
try:
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for part in value:yield from flatten(part)
        else:yield value
    selected=list(flatten(suite));actual=[case.id()for case in selected]
    save('actual-selection.json',dict(ids=actual,loaderErrors=loader.errors))
    assert not loader.errors and actual==plan['cases']and suite.countTestCases()==11
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    for case in selected:
        pending=len(case._cleanups);prior=case._outcome;drain=unittest.TestResult();success=True
        try:
            if pending:
                case._outcome=unittest.case._Outcome(drain);success=unittest.TestCase.doCleanups(case)
        except BaseException:success=False;print(traceback.format_exc(),flush=True)
        finally:case._outcome=prior
        row=dict(id=case.id(),pendingBeforeOuter=pending,remaining=len(case._cleanups),success=success,errors=[dict(id=test.id(),traceback=text)for test,text in drain.errors],failures=[dict(id=test.id(),traceback=text)for test,text in drain.failures])
        cleanup_rows.append(row)
        if not success or case._cleanups or drain.errors or drain.failures:cleanup_ok=False
    pins_after={path:pin(path)for path in plan['sourceAndBinaryPins']}
    fd_after=observer.fds();threads_after=tuple(threading.enumerate());children_after=observer.children()
    literal_code_guard();boundary._check()
    assert observer._ACTIVE is None
    # Original own-module source is retained and pinned; no alias reset can
    # substitute another test graph for the real completed counter receipts.
    import test_moving_prespawn_original_ports as subject
    first=subject.toy_census(TOYS);second=subject.toy_census(TOYS)
    receipts=[]
    for path in sorted(TOYS.glob('*/standard-cleanup-receipt.json')):receipts.append(json.loads(path.read_text()))
    passed=fatal is None and result is not None and result.wasSuccessful()and result.testsRun==11 and not result.skipped
    passed=passed and cleanup_ok and unittest.TestCase.doCleanups is original_cleanup and pins_after==plan['sourceAndBinaryPins']
    passed=passed and fd_after==fd_before and threads_after==threads_before and children_after==children_before and first==second
    passed=passed and len(receipts)==11 and all(row['NodeExecutions']==row['childProcessBirths']==row['SourceInstances']==0 for row in receipts)
    passed=passed and all(owner.fileno()==-1 for owner in created_sockets)
    save('actual-toy-first.json',first);save('actual-toy-second.json',second)
    save('outer-cleanup.json',dict(success=cleanup_ok,cases=cleanup_rows))
    report=dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=0 if result is None else result.testsRun,
        fatal=fatal,fdUnchanged=fd_before==fd_after,threadsUnchanged=threads_before==threads_after,kernelChildrenUnchanged=children_before==children_after,
        pinsUnchanged=pins_after==plan['sourceAndBinaryPins'],twoToyCensusesEqual=first==second,cleanupEstablished=cleanup_ok,
        actualCaseReceipts=len(receipts),NodeExecutions=0,childProcessBirths=0,SourceInstances=0,movingQualified=False,nativeQualified=False)
    save('report.json',report)
    signal.signal(signal.SIGTERM,original_term)
    boundary.restore();restored=all(getattr(os,name)is value for name,value in original_ports.items())and original_io==(io.open,builtins.open)
    with boundary.original_io(RECEIPTS/'actual-port-restoration.json','x')as stream:stream.write(json.dumps(dict(restored=restored,count=len(original_ports),controlDescriptors=sorted(boundary.control_fds)))+'\n')
    boundary.close();sys.meta_path[:]=original_meta;sys.path[:]=original_path
raise SystemExit(0 if passed and restored else 1)
