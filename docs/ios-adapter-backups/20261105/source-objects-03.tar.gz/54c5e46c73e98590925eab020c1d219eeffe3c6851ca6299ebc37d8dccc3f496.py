"""Root serial metadata preparation only; no target or corpus census."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
R=Path.cwd().resolve(strict=True);B=R/'.ios-host-tmp';D=Path(__file__).resolve().parent
S=B/'snapshot-actor25-public73-compatibility-bootstrap1-dirty-parent-source-private-20261104'
SOURCE_SHA='a38cb566c2947f917f2aafa0aa553961000df87b632663fd10e93c69368f370f'
C=B/'root-ios-current875-after-c24-utility-class-guard-negative-context-20261104/root-context.json'
C_SHA='e9dd4e86cd859a39d2ecfa8c77dfe122d83d09c587c87d03c135e2a77fe7ea5a'
M=B/'root-public73-exact-reviewed-dirty32-copy-manifest-20261104/copy-manifest.json'
M_SHA='bac9c7b613e7c4a3a1b7be88dcd43d2c865b766240705f291ae970688f6ca934'
HEAD='cb79372ab9ec96df5e1320f9c573259ac3fbebed'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(name,value):
    with(D/name).open('x')as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
assert sys.flags.no_site and sys.dont_write_bytecode and R.name=='overte-ios-feature-adapters-resume-20261026'
assert sha(S/'source-freeze.json')==SOURCE_SHA and sha(C)==C_SHA and sha(M)==M_SHA
assert load(C)['allTargetsTerminal']and load(C)['expectedHead']==HEAD
recipe=load(S/'SOURCE-RECIPE.json');assert len(recipe['groupOrder'])==21 and recipe['caseCount']==73
rows=[]
for group in recipe['groupOrder']:
    h=B/('snapshot-public73-'+group+'-root875-headcb793-b1-20261104')
    assert not h.exists()
    command=[sys.executable,'-S','-B',str(S/'build-approved-inputs.py'),'--source-freeze',SOURCE_SHA,
        '--expected-head',HEAD,'--copy-manifest',str(M),'--copy-manifest-sha',M_SHA,
        '--root-context',str(C),'--root-context-sha',C_SHA,'--group',group,'--destination',str(h)]
    with(D/(group+'-stdout.log')).open('xb')as stdout,(D/(group+'-stderr.log')).open('xb')as stderr:
        result=subprocess.run(command,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
    if result.returncode:
        put('preparation-failure.json',dict(group=group,returnCode=result.returncode,completed=rows,
            possibleMetadataRoom=str(h),targets=0,globalScans=0))
        raise SystemExit(result.returncode)
    p=h/'approved-inputs.json';plan=load(p)
    assert plan['group']==group and plan['sourceFreeze']==SOURCE_SHA
    assert plan['cases']==recipe['groups'][group]['cases']and plan['publicSubjectOriginCount']==45 and plan['privatePureOriginCount']==1
    assert plan['publicCopyManifest']==dict(path=str(M),sha256=M_SHA)
    rows.append(dict(group=group,input=str(p),inputSha256=sha(p),physicalPins=len(plan['sourceAndBinaryPins']),
        cases=len(plan['cases']),TDs=plan['expectedTemporaryDirectories']))
    put('generated-after-'+group+'.json',rows)
    print('METADATA_PREPARED '+group+' '+str(len(rows))+'/21',flush=True)
assert len(rows)==21 and sum(row['cases']for row in rows)==73 and sum(row['TDs']for row in rows)==145
put('results.json',dict(status='ROOT_METADATA_ONLY_TWENTY_ONE_PUBLIC73_INPUTS_PREPARED_UNRUN',groups=rows,
    sourceFreeze=SOURCE_SHA,rootSourceReview='082b9f557b6dd3ca20afc5bc7664c76f65f988fe6642fe96b1e5a53b77fdaaba',
    independentPeer='bb8c71aaf4c78dce384858f0ae2b29ed6536e2f050f5bf590ea0c7a5422d6bfe',
    context=dict(path=str(C),sha256=C_SHA),copyManifest=dict(path=str(M),sha256=M_SHA),
    targets=0,imports=0,globalScans=0,nativeQualified=False,wholeQualified=False))
put('freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in sorted(D.iterdir())if p.is_file()}))
print(json.dumps(dict(status='METADATA_ONLY_UNRUN',freeze=sha(D/'freeze.json'),groups=21)),flush=True)
