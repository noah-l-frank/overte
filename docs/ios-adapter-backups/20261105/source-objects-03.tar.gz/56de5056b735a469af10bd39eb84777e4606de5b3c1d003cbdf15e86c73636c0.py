"""Exact actual all29 input membership over every canonical generation.

Only typed source interpretation may cover a path. Hashes, filename matches,
copies and input acknowledgments never cover an unknown original. Scene,
marker, image, current observation and external resource duties remain blocking
until their independent typed readers are integrated into the whole closure.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import stat
from adapters.native_feature_observation import need
from adapters.original_file_reads import collect,readonly
from adapters.script_feature.history import same
from ios.adapters.assets_end_metadata import signature
from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
from ios.adapters.assets_generation_replies import GenerationActionReplyReads
from ios.adapters.assets_generation_view import AssetsGenerationView
from ios.adapters.assets_page_generation_recovery import reconstruct_page_generations
from ios.adapters.assets_permission_actions import AssetsPermissionActions

PREFIXES=('ios-assets-','assets-')


def inventory(episodes,scopes):
    episodes.guard();need(type(scopes) is tuple and [scope.index for scope in scopes]==[1,2,3,4,5])
    directories={Path(info[field]) for info in episodes.context['roles'].values() for field in ('stateRoot','artifactRoot')}
    for scope in scopes:
        scope.guard()
        for lock in scope.locks.values():lock.assert_held()
        directories.update(Path(row['path']) for role in scope.descriptor['directories'].values() for row in role.values())
    result={};identities={}
    for directory in directories:
        info=directory.lstat();need(stat.S_ISDIR(info.st_mode) and not directory.is_symlink())
        identities[directory]=(info.st_dev,info.st_ino,info.st_mode,info.st_uid)
        paths=list(directory.iterdir());need(len(paths)<=4096)
        for path in paths:
            if not path.name.startswith(PREFIXES):continue
            info=path.lstat()
            if stat.S_ISDIR(info.st_mode):
                # Only the independently pinned actual Episode births may
                # introduce directories. Their exact contents are listed above.
                need(path in directories);continue
            need(stat.S_ISREG(info.st_mode) and info.st_nlink==1 and not path.is_symlink())
            need(path not in result or result[path]==signature(path));result[path]=signature(path)
    return result,identities


def archived_view(episodes,actions,scope,canonical,graph):
    number={2:2,3:3,4:4}[scope.index];birth=canonical.contexts[number].birth
    need(birth.historical and graph.episode is scope and graph.dependency_mode)
    first,last={2:(9,13),3:(16,17),4:(22,23)}[number]
    prefix='ios-assets-'+actions.run+'-primary-gen'+str(number);root=graph.root
    from adapters.normal_feature_state import PrivateFeatureState
    store=PrivateFeatureState(root/(prefix+'-view.json'))
    owners=tuple(GenerationActionReplyReads.from_archive(PrivateFeatureState(root/(prefix+'-action'+str(index)+'-replies.json')),
        generation=birth,episode=scope,actions=actions,action_index=index) for index in range(first,last+1))
    view=AssetsGenerationView.from_archive(birth,scope,actions,graph.upload,store,reply_owners=owners,
        namespace='renamed' if number==2 else 'original',old_tree=graph.tree if number==2 else None,
        baked_parsed=graph.parsed if number==4 else None)
    need(view.state['activeAction']==last and set(view.reply_owners)==set(range(first,last+1))
        and all(owner.state['phase']=='closed' and owner.sources.pending is None for owner in owners)
        and all(owner.query_sources.state['pending'] is None for owner in owners)
        and view.state['pending'] is None)
    need(set(view.clients)==set(view.state['clients']) and 'tree' in view.clients)
    tree=view.clients['tree'];need(tree.state['phase']=='deleted')
    for owner in view.clients.values():
        need(owner.state is not None and same(owner.store.read(),owner.previous)
            and all(row['resolvedBy'] is not None and row['abandonedBy'] is None for row in owner.state['inputs']))
    return view


def inspect_whole_inputs(episodes,actions,scopes,permissions):
    need(type(permissions) is AssetsPermissionActions and permissions.actions is actions)
    before,dirs=inventory(episodes,scopes)
    with readonly(),collect() as reads:
        actions.guard();need(actions.state is not None and actions.state['complete'] and actions.state['pending'] is None
            and len(actions.state['records'])==29 and same(actions.store.read(),actions.previous)
            and same(actions.decode(actions.previous),actions.state))
        for index in range(1,30):actions.read(index)
        episodes.guard();need(len(episodes.state['entries'])==5 and all(row['phase']=='ready' for row in episodes.state['entries']))
        need(same(episodes.store.read(),episodes.previous) and same(episodes.decode(episodes.previous),episodes.state))
        recovered=reconstruct_page_generations(episodes,actions,scopes);canonical=recovered['owner'];need(canonical.state['complete'])
        need(len(canonical.state['entries'])==4 and canonical.state['entries'][-1]['closed'] is not None)
        views={};graphs={}
        for index in (2,3,4):
            old_generation={2:1,3:2,4:3}[index]
            graph=AssetsEpisodeModelGraph(scopes[index-1],recovered['pageReports'][old_generation-1]['owner'],
                actions=actions,dependency_mode=True).decode()
            need(graph.files.state['phase']=='retired' and graph.replies.state['phase']=='closed'
                and graph.upload.state['phase']=='uploaded' and graph.removal.state['phase']=='model-gone'
                and graph.removal.state['contextClosedBy'] is not None)
            graphs[index]=graph;views[index]=archived_view(episodes,actions,scopes[index-1],canonical,graph)
        for index in (1,5):
            page=canonical.contexts[1 if index==1 else 4].page;picker=page.pickers[index]
            need(picker.state['phase']=='page-borrowed-retired' and picker.files.state['phase']=='retired'
                and picker.files.sources.pending is None)
        permissions.guard();need(same(permissions.store.read(),permissions.previous)
            and same(permissions.decode(permissions.previous),permissions.state)
            and len(permissions.state['entries'])==2)
        client=permissions.client;need(client.state is not None and same(client.store.read(),client.previous)
            and same(client.decode(client.previous),client.state))
        for row in permissions.state['entries']:permissions.effect(views[2],row)
        canonical.guard()
        for graph in graphs.values():graph.guard()
        after,after_dirs=inventory(episodes,scopes);need(before==after and dirs==after_dirs)
        # This is equality over the entire owned Assets file namespace. A real
        # extra Scene/Image/checkpoint source remains visible and blocks until
        # its own typed whole reader participates; nothing is filtered out.
        known={path for path in reads if path in before};need(set(before)==known)
    return dict(assetsWholeInputOwnershipVersion=1,runId=actions.run,paths=set(before),actualOriginalReads=set(reads),
        filePins=deepcopy(before),directoryPins=deepcopy(dirs),generations=canonical,graphs=graphs,views=views,
        completedActionOriginals=29,bornEpisodes=5,actualPageGenerations=4,
        duties=['current-target-observation','independent-peer-observation','scene-resource-retirement',
                'marker-and-image-original-retirement','independent-server-blob-and-worker-restoration',
                'cleanup-activation','process-and-sdk-end'],wholeDirectoryRead=False,wholeEndEligible=False)
