"""Fresh Root-only eight-case and same328 metadata-reduction preparation."""
from pathlib import Path
import ast,hashlib,json,stat
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
OLD=ROOT/'.ios-host-tmp/tablet-parent-guard-opaque-and-constructor-corrected-root5-preparation-20261028'
OLDDIAG=ROOT/'.ios-host-tmp/tablet-parent-guard-opaque-and-constructor-corrected-root328-profile-preparation-20261028'
NEWDIAG=ROOT/'.ios-host-tmp/tablet-parent-guard-metadata-fast-same328-profile-preparation-20261028'
PACK=ROOT/'.ios-host-tmp/tablet-parent-guard-metadata-fast-shape-overlay-20261028'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    before=path.lstat();assert stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode)
    result={field:getattr(before,field) for field in FIELDS}
    if stat.S_ISREG(before.st_mode):result['sha256']=sha(path)
    after=path.lstat();assert all(getattr(before,f)==getattr(after,f) for f in FIELDS)
    return result
assert not (HERE/'freeze.json').exists() and not (NEWDIAG/'freeze.json').exists()
for package in (OLD,OLDDIAG,PACK):
    for name,expected in json.loads((package/'freeze.json').read_text())['files'].items():assert sha(package/name)==expected,name
manifest=json.loads((PACK/'candidate-manifest.json').read_text())
for name in ('run-selected.py','root-supervise.py','run_metadata.py','refresh-after-publication.py','monitoring_observer.py',
             'expected-registry-own-keys.json','source-root-final-map.json','entrypoint-ast-review.json'):
    body=(OLD/name).read_text()
    if name in ('run-selected.py','root-supervise.py'):body=body.replace("('target5',)","('target8',)")
    (HERE/name).write_text(body)
plan=json.loads((OLD/'suite-plan.json').read_text());selection=plan['suites']['target5']
newpath='tests/device/ios/self_tests/test_ios_tablet_web_parent_guard_metadata.py'
tree=ast.parse((PACK/'candidate'/newpath).read_text())
newids=['ios.self_tests.test_ios_tablet_web_parent_guard_metadata.'+node.name+'.'+method.name
    for node in tree.body if isinstance(node,ast.ClassDef) for method in node.body
    if isinstance(method,ast.FunctionDef) and method.name.startswith('test_')]
assert len(newids)==3
selection['caseIds']+=newids;selection['count']=8;selection['expectedRetainedRoots']=8
assert len(selection['caseIds'])==len(set(selection['caseIds']))==8
assert selection['initialTimeoutSeconds']==300 and selection['killAfterSeconds']==5
plan['suites']={'target8':selection};plan['status']='PRIVATE_METADATA_FAST_SHAPE_ROOT8_UNRUN'
plan['selectionJustification']='All prior5 plus new3 semantic/default cases, before-first-run fixed300+5/8TD. Prior5 took35.164 parent; new owner fixture one additional root, two pure metadata cases. No inner/native/API cap change. Old11 already passed and not selected.'
plan['frozenPackets'].append(dict(path=str(PACK.relative_to(ROOT)),freezeSha256=sha(PACK/'freeze.json')))
public={row['path']:row['expectedSha256'] for row in json.loads((OLD/'expected-publication.json').read_text())}
public.update({name:row['candidateSha256'] for name,row in manifest.items()})
save(HERE/'expected-publication.json',[dict(path=name,expectedSha256=value) for name,value in sorted(public.items())])
config=json.loads((HERE/'source-root-final-map.json').read_text())
config['modules']['ios.self_tests.test_ios_tablet_web_parent_guard_metadata']=dict(path=newpath)
save(HERE/'source-root-final-map.json',config)
prior=json.loads((OLD/'retained-prior-original-pins.json').read_text())
for name,wanted in prior.items():assert pin(ROOT/name)==wanted,name
report=json.loads((OLD/'target5-report.json').read_text())
assert report['exitCode']==0 and report['originalFiles']==280 and report['allPinsEqual'] and report['postStopCensusesQualified']
run=Path(report['runRoot']);temporary=run/'temporary'
actual={str(path.relative_to(temporary)):pin(path) for path in (temporary,*sorted(temporary.rglob('*')))}
assert actual==json.loads((OLD/'target5-originals-first.json').read_text())
for name,row in actual.items():prior[str((temporary/name).relative_to(ROOT))]=row
for path in run.iterdir():
    if path.is_file():prior[str(path.relative_to(ROOT))]=pin(path)
for path in OLD.glob('target5-*'):
    if path.is_file():prior[str(path.relative_to(ROOT))]=pin(path)
profile=json.loads((OLDDIAG/'root-profile-report.json').read_text())
assert profile['exitCode']==0 and profile['all328OriginalsUnchanged'] and profile['allPinsEqual'] and profile['postStopCensusesQualified']
for path in OLDDIAG.iterdir():
    if path.is_file():prior[str(path.relative_to(ROOT))]=pin(path)
for path in sorted(Path(profile['outputRoot']).rglob('*')):
    if path.is_file() or path.is_dir():prior[str(path.relative_to(ROOT))]=pin(path)
save(HERE/'retained-prior-original-pins.json',prior)
plan['expectedPublicationSha256']=sha(HERE/'expected-publication.json');plan['expectedPublicationCount']=len(public)
plan['sourceRootMapSha256']=sha(HERE/'source-root-final-map.json');plan['expectedOwnRegistrySha256']=sha(HERE/'expected-registry-own-keys.json')
plan['retainedPriorPinsSha256']=sha(HERE/'retained-prior-original-pins.json')
plan['measuredBaselinesPreserved']=dict(originalParentSeconds=22.954,originalInnerSeconds=20.945,
    memoParentSeconds=20.846,memoInnerSeconds=18.63,scope='same retained328 diagnostic only, no product speed claim')
save(HERE/'suite-plan.json',plan)
review=json.loads((HERE/'entrypoint-ast-review.json').read_text());review['selections']={'target8':selection['caseIds']}
review['newActualRootCount']=8;review['newCases']='2 pure key/shape semantic cases +1 actual owned-root mutable-default test; no native/SDK input/clock modification'
save(HERE/'entrypoint-ast-review.json',review)
for identifier in selection['caseIds']:
    module,cls,method=identifier.rsplit('.',2);path=ROOT/'tests/device'/Path(*module.split('.')).with_suffix('.py')
    if not path.exists():path=PACK/'candidate'/path.relative_to(ROOT)
    content=ast.parse(path.read_text());node=next(n for n in content.body if isinstance(n,ast.ClassDef) and n.name==cls)
    selected=next(n for n in node.body if isinstance(n,ast.FunctionDef) and n.name==method);assert not selected.decorator_list
(HERE/'README.txt').write_text('''ROOT ONLY / EXACT8 UNRUN /300+kill5/8 real retained TD roots. All original
directory/inode/read-membership checks, local monitoring and before/after full
source controls remain literal. Only after reviewed metadata helper de56 and
new test5db publication, Root builds actual fresh map (never copied):
  PYTHONDONTWRITEBYTECODE=1 python3 -B <this-dir>/refresh-after-publication.py
  PYTHONDONTWRITEBYTECODE=1 python3 -B <this-dir>/root-supervise.py target8
Actual corrected5 PASS280 and memo328 PASS20.846/raw profile are preserved,
as are original22.954 baseline, failed86, old11PASS235 and all older corpora.
No old11/600 Sample retry, native or whole/performance qualification.
''')
for path in HERE.glob('*.py'):ast.parse(path.read_text())
save(HERE/'freeze.json',dict(status='FROZEN_PRIVATE_METADATA_ROOT8_UNRUN',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='freeze.json'}))
for name in ('profile-saved-once.py','profile_metadata.py','prepare-actual-map.py','root-supervise-profile.py','independent-original-scope.json'):
    (NEWDIAG/name).write_bytes((OLDDIAG/name).read_bytes())
value=json.loads((OLDDIAG/'profile-plan.json').read_text())
value['publicTabletSourceRequiredSha256'].update({name:row['candidateSha256'] for name,row in manifest.items()})
value['explicitExtraSourcePins']=[name.replace(str(OLDDIAG.relative_to(ROOT)),str(NEWDIAG.relative_to(ROOT)))
    if name.endswith('/independent-original-scope.json') else name for name in value['explicitExtraSourcePins']]
value['retainedPriorPinsSha256']=sha(HERE/'retained-prior-original-pins.json')
value['status']='PRIVATE_SAME328_METADATA_ALLOCATION_REDUCED_SOURCE_PROFILE_UNRUN'
value['metadataSourcePacket']=dict(path=str(PACK.relative_to(ROOT)),freezeSha256=sha(PACK/'freeze.json'))
value['precedingActualMemoResult']=dict(report=str((OLDDIAG/'root-profile-report.json').relative_to(ROOT)),parentSeconds=20.846,innerSeconds=18.63)
(NEWDIAG/'retained-prior-original-pins.json').write_bytes((HERE/'retained-prior-original-pins.json').read_bytes())
save(NEWDIAG/'profile-plan.json',value)
(NEWDIAG/'README.txt').write_text('''ROOT ONLY / UNRUN. Same supported historical328 profile after Root exact8
qualification and separate grant. Same literal profile body, fixed60+kill5,
originalAPI60, independent preinput context and held original locks. Current
de56 helper/new5db source maps built afterPUB. Preserve both actual22.954 and
20.846/raw profiles plus all previous originals. No Sample retry/whole claim.
  PYTHONDONTWRITEBYTECODE=1 python3 -B <this-dir>/prepare-actual-map.py
  PYTHONDONTWRITEBYTECODE=1 python3 -B <this-dir>/root-supervise-profile.py
''')
assert sha(NEWDIAG/'profile-saved-once.py')==sha(OLDDIAG/'profile-saved-once.py')
for path in NEWDIAG.glob('*.py'):ast.parse(path.read_text())
save(NEWDIAG/'freeze.json',dict(status='FROZEN_PRIVATE_METADATA_SAME328_UNRUN',files={str(p.relative_to(NEWDIAG)):sha(p) for p in sorted(NEWDIAG.iterdir()) if p.is_file() and p.name!='freeze.json'}))
print(json.dumps(dict(root8=str(HERE),root8Freeze=sha(HERE/'freeze.json'),profile=str(NEWDIAG),profileFreeze=sha(NEWDIAG/'freeze.json'),priorNodes=len(prior)),indent=2))
