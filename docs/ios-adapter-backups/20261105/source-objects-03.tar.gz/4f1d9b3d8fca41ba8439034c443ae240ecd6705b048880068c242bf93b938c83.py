"""Typed controller IPC write capacities over actual original stdlib bodies.

These capacities authorize only observed own Connection/tracker FDs. They do
not decode protocol bytes or create a product owner/process-absence claim.
"""
from pathlib import Path
from types import MappingProxyType
import os,stat,sys,threading,types
from tablet_constructor_custody import FunctionBinding,CustodyRefusal

class ActualIPCCapacities:
    def __init__(self,connection_module,tracker_module,passed_descriptors):
        self.main=threading.current_thread();self.module=connection_module;self.tracker_module=tracker_module
        self.connection=connection_module.Connection;self.tracker=tracker_module._resource_tracker
        self.original_send=FunctionBinding(self.connection._send)
        self.rebuild=FunctionBinding(connection_module.rebuild_connection)
        self.tracker_write=FunctionBinding(type(self.tracker)._write)
        self.original_write=os.write;self.original_dup=os.dup;self.original_dup2=os.dup2
        self.fstat=os.fstat;self.passed=MappingProxyType(dict(passed_descriptors));self.connections={}
        self.writes=[];self.installed=False;self.closed=False;self.active=None
        if self.original_send.defaults is None or len(self.original_send.defaults)!=1 or self.original_send.defaults[0]is not self.original_write:
            raise CustodyRefusal('Connection must capture the genuine original C write before OS router installation')
        outer=self
        def guarded_send(receiver,buf,write=None):
            if write is not None:raise CustodyRefusal('Foreign explicit Connection write port')
            return outer.send(receiver,buf)
        self.send_port=guarded_send;self.send_binding=FunctionBinding(guarded_send)
        self.methods=tuple((key,value,FunctionBinding(value))for key,value in vars(type(self)).items()
            if type(value)is types.FunctionType)
    def check(self):
        if self.closed or threading.current_thread()is not self.main:raise CustodyRefusal('IPC capacity lifetime/thread')
        for key,value,binding in self.methods:
            if vars(type(self)).get(key)is not value:raise CustodyRefusal('IPC gate method changed')
            binding.guard()
        for binding in(self.original_send,self.rebuild,self.tracker_write,self.send_binding):binding.guard()
        if self.module.Connection is not self.connection or self.module.rebuild_connection is not self.rebuild.function:
            raise CustodyRefusal('Original Connection class/rebuild installation changed')
        if self.connection._send is not(self.send_port if self.installed else self.original_send.function):
            raise CustodyRefusal('Connection send port changed')
        if self.tracker_module._resource_tracker is not self.tracker or type(self.tracker)._write is not self.tracker_write.function:
            raise CustodyRefusal('Actual ResourceTracker writer changed')
        if os.fstat is not self.fstat:raise CustodyRefusal('Actual FD reader replaced')
    def signature(self,fd):
        if type(fd)is not int or fd<0:raise CustodyRefusal('Actual nonnegative descriptor required')
        info=self.fstat(fd)
        return dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
    def register_rebuilt_connection(self,frame,result):
        self.check();self.rebuild.frame(frame)
        if type(result)is not self.connection or result in self.connections:raise CustodyRefusal('Actual new rebuilt Connection required')
        fd=result.fileno();identity=self.signature(fd);expected=self.passed.get(str(fd))
        if expected!=identity or not stat.S_ISSOCK(identity['mode']):
            raise CustodyRefusal('Connection is not the actually inherited original socket descriptor')
        # Parent must separately bind the actual socketpair/AF_UNIX birth;
        # fstat here is a cross-process same-inode join, not a family probe.
        self.connections[result]=(fd,identity)
    def register_parent_connection(self,connection,*,actual_pipe_frame,pipe_binding,observed_socket_pair):
        self.check();pipe_binding.frame(actual_pipe_frame)
        if type(connection)is not self.connection or connection in self.connections:
            raise CustodyRefusal('Actual newly returned parent Pipe Connection required')
        fd=connection.fileno();identity=self.signature(fd)
        matches=[row for row in observed_socket_pair if row['descriptor']==fd and row['identity']==identity
            and row['actualFamily']=='AF_UNIX'and row['actualType']=='SOCK_STREAM']
        if len(matches)!=1 or not stat.S_ISSOCK(identity['mode']):
            raise CustodyRefusal('Parent Connection lacks the actual original socketpair constructor proof')
        self.connections[connection]=(fd,identity)
    def install(self):
        self.check()
        if self.installed:raise CustodyRefusal('IPC capacity installed twice')
        self.connection._send=self.send_port;self.installed=True;self.check()
    def connection_guard(self,receiver):
        self.check();row=self.connections.get(receiver)
        if type(receiver)is not self.connection or row is None or receiver.closed:
            raise CustodyRefusal('Unregistered actual Connection receiver')
        fd,identity=row
        if receiver.fileno()!=fd or self.signature(fd)!=identity:raise CustodyRefusal('Original Connection FD/inode changed')
        return fd
    def send(self,receiver,buf):
        fd=self.connection_guard(receiver)
        if self.active is not None:raise CustodyRefusal('Nested Connection send')
        self.active=receiver
        def original_typed_write(descriptor,chunk):
            # The unchanged original _send loop supplies these actual buffers;
            # every iteration rechecks receiver and kernel inode before the
            # genuine original C write. No bytes, lengths or replies change.
            if self.active is not receiver or descriptor!=self.connection_guard(receiver):
                raise CustodyRefusal('Original IPC write borrowed by another receiver')
            count=self.original_write(descriptor,chunk)
            self.writes.append(dict(kind='connection',descriptor=descriptor,actualReturnedBytes=count))
            return count
        binding=FunctionBinding(original_typed_write)
        try:
            binding.guard();return self.original_send.function(receiver,buf,write=original_typed_write)
        finally:self.active=None
    def tracker_write_allowed(self,args,caller):
        if caller.f_code is not self.tracker_write.code or caller.f_globals is not self.tracker_write.namespace:return False
        self.check();self.tracker_write.frame(caller)
        if len(args)!=2 or caller.f_locals.get('self')is not self.tracker or args[0]!=self.tracker._fd or args[1]is not caller.f_locals.get('msg'):
            raise CustodyRefusal('Original tracker receiver/FD/message identity mismatch')
        identity=self.signature(args[0]);expected=self.passed.get(str(args[0]))
        if expected!=identity or not stat.S_ISFIFO(identity['mode']):raise CustodyRefusal('Tracker FD is not the original inherited pipe')
        return True
    def finish(self):
        self.check()
        if self.active is not None:raise CustodyRefusal('Original IPC write still active')
        live=[dict(descriptor=fd,identity=identity)for owner,(fd,identity)in self.connections.items()if not owner.closed]
        self.connection._send=self.original_send.function;self.installed=False;self.check();self.closed=True
        return dict(originalConnectionSendRestored=True,connectionWrites=list(self.writes),
            actualRegisteredConnections=len(self.connections),stillLiveConnections=live,
            actualTrackerStillMayBeProcessLifetimeHeld=True,allIPCCapacitiesClaimedClosed=False)

class MainThreadOwnWrites:
    """Byte-exact E458 composition with one explicit original tracker pipe port.

    Actor only: no HTTP writer threads. Tracker role may use the same ordinary
    own-root filesystem helper but does not acquire a Connection capability.
    """
    def __init__(self,root,owned_writes_class,ipc,protected=()):
        self.root=Path(root).resolve(strict=True);self.ipc=ipc;self.helper=owned_writes_class(self.root,protected)
        self.original=MappingProxyType(dict(self.helper.original));self.items=tuple(self.original.items())
        self.helper.original=self.original;self.helper.original_items=self.items
        self.ports={};self.bindings=[];self.installed=False;self.closed=False
    def check(self):
        if self.closed:raise CustodyRefusal('Child write boundary lifetime ended')
        self.helper._check();self.ipc.check()
        if self.helper.original is not self.original or self.helper.original_items is not self.items:
            raise CustodyRefusal('Independent original OS ports changed')
        if self.installed and any(getattr(os,key)is not value for key,value in self.ports.items()):
            raise CustodyRefusal('Actual 27-port installation changed')
        for binding in self.bindings:binding.guard()
    def install(self):
        self.check()
        if self.installed:raise CustodyRefusal('Child write boundary installed twice')
        outer=self
        for name,original in self.items:
            if name=='close':continue
            def port(*args,_name=name,**kwargs):
                outer.check()
                if _name=='write'and not kwargs and outer.ipc.tracker_write_allowed(args,sys._getframe(1)):
                    return outer.original['write'](*args)
                return outer.helper.os_open(*args,**kwargs)if _name=='open'else outer.helper.mutate(_name,*args,**kwargs)
            self.ports[name]=port;self.bindings.append(FunctionBinding(port));setattr(os,name,port)
        self.installed=True;self.check()
    def audit(self,event,args,caller):
        relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime',
            'os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
        if relevant:self.check();self.helper.audit(event,args,caller)
    def restore(self):
        self.check()
        if self.helper.control_fds:raise CustodyRefusal('Canonical filesystem parent FDs remain live')
        self.helper.close()
        for key,value in self.items:setattr(os,key,value)
        self.installed=False;self.closed=True
        if any(getattr(os,key)is not value for key,value in self.items):raise CustodyRefusal('Actual OS ports not restored')
        return dict(originalOSPortsRestored=True,actualOSPortCount=len(self.items),
            cachedSharedMemoryAndTrackerClaimedClosed=False)
