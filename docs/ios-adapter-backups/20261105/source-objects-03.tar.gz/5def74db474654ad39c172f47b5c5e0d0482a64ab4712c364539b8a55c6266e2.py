"""Actual query/full-cut source under existing actor-worker lock scope; SDK DI.

This changes no Input/Down/caps/gates. The original source context-manager node
executes against an explicit actor context model owning real FDs/a reader Task.
"""
import ast,asyncio,hashlib,json,marshal,os,socket,uuid
from contextlib import asynccontextmanager
from copy import deepcopy
from pathlib import Path
import test_motion_selected_join_models as join_fixture


class NativeSharedLockModels(join_fixture.MotionSelectedJoinModels):
    async def test_selected_query_acquisition_and_resource_reuse_actual_lock_for_full_cut_inside_original_actor_scope(self):
        await self.select_original();packet,_=await self.capture_selected();self.assertEqual('complete',packet['status']);await self.prepared(packet['result'])
        resource=self.ops.touch_resources;query_owner=self.ops.native_query_journals[self.run]
        self.assertIs(resource.lock,self.journal()['lock']);self.assertIs(resource.lock,query_owner['lock'])
        path=Path(self.mapping['resourceOwner']['path']);tree=ast.parse(path.read_bytes());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='LifecycleTouchResourceOwner');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='make_lease');node=next(n for n in ast.walk(method) if isinstance(n,ast.AsyncFunctionDef) and n.name=='selected_factory')
        module=ast.Module(body=[deepcopy(node)],type_ignores=[]);code=compile(ast.fix_missing_locations(module),str(path),'exec')
        fd=os.open(Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/('actor-lock-'+uuid.uuid4().hex+'.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as f:json.dump(dict(sourceSha256=self.mapping['resourceOwner']['sha256'],selectedAstSha256=hashlib.sha256(ast.dump(module,include_attributes=False).encode()).hexdigest(),compiledCodeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest()),f);f.write('\n')
        sockets=[];readers=[]
        @asynccontextmanager
        async def original_actor_context_model():
            pair=socket.socketpair();sockets.extend(pair);stop=asyncio.Event();reader=asyncio.create_task(stop.wait());readers.append(reader)
            try:yield pair
            finally:
                stop.set();await reader
                for descriptor in pair:descriptor.close()
        namespace=dict(self=resource,factory=original_actor_context_model,asynccontextmanager=asynccontextmanager);exec(code,namespace)
        async def actor_worker():
            async with namespace['selected_factory']():
                owner=resource.lock._owner;resource.lock.assert_held();before=len(self.commands)
                result=await self.ops.execute('touch-native-acquire',self.acquire_args(),self.binding['sessionId'])
                self.assertEqual(1,result['originalKeeperNativeAcquisitionVersion']);self.assertEqual(before+4,len(self.commands))
                self.assertIs(owner,resource.lock._owner);resource.lock.assert_held()
                self.assertIs(asyncio.current_task(),self.source._native_queries[-1][0]);return result
        task=asyncio.create_task(actor_worker(),name='existing-source-actor-lock-model');self.controls.append(task);result=await task
        self.assertEqual(1,result['originalKeeperNativeAcquisitionVersion']);self.assertTrue(all(row.done() for row in readers));self.assertTrue(all(fd.fileno()==-1 for fd in sockets))
        self.assertIsNone(resource.lock._owner);self.assertEqual([],self.f.states());self.assertEqual([],self.source._born);self.assertEqual([],self.source._leases)

    async def test_default_acquisition_created_first_shares_its_actual_lock_with_new_query_owner(self):
        request,task=self.request('touch-native-acquire',self.acquire_args());await task;packet=self.ops.issued[request]['original'];self.assertEqual('complete',packet['status'])
        self.assertEqual(1,packet['result']['originalKeeperNativeAcquisitionVersion']);self.assertIs(self.journal()['lock'],self.ops.native_query_journals[self.run]['lock'])
        self.assertEqual(4,len(self.commands));self.assertEqual([],self.f.states())

    async def test_existing_query_owner_with_foreign_binding_cannot_supply_lock_or_create_new_acquisition_owner(self):
        await self.select_original();original=self.ops.native_query_journals[self.run]['lock'];foreign=dict(self.binding,generation=self.binding['generation']+1)
        with self.assertRaises((RuntimeError,ValueError)):self.ops._native_acquisition_owner(foreign,self.run,self.binding['sessionId'])
        self.assertIs(original,self.ops.native_query_journals[self.run]['lock']);self.assertEqual({},self.ops.native_acquisition_journals);self.assertEqual(1,len(self.commands));self.assertEqual([],self.f.states())
