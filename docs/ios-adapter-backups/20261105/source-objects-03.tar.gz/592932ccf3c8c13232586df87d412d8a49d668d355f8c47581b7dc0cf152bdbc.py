"""Stdlib-only custody for the isolated five-case Root controller."""
from pathlib import Path
import hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent
SOURCE=HERE/'source'
PUBLIC_ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript','domain-server/resources')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(name):return json.loads((HERE/name).read_text())
def save(path,value):
    descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(descriptor,'w') as stream:
        stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n');stream.flush();os.fsync(stream.fileno())
def pin(path):
    first=path.lstat();value={key:getattr(first,key) for key in FIELDS}
    if stat.S_ISREG(first.st_mode):value['sha256']=sha(path)
    elif stat.S_ISLNK(first.st_mode):value['target']=str(path.readlink())
    else:assert stat.S_ISDIR(first.st_mode),str(path)
    second=path.lstat();assert all(getattr(first,k)==getattr(second,k) for k in FIELDS),str(path)
    return value

def proc(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,state=fields[0],parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
def processes(session):
    values=[]
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            row=proc(int(path.name))
            if row is not None and (row['session']==session or row['processGroup']==session):values.append(row)
    return values

def fds(pid):
    result={};root=Path('/proc',str(pid),'fd')
    try:paths=list(root.iterdir())
    except FileNotFoundError:return result
    for path in paths:
        try:target=os.readlink(path)
        except (FileNotFoundError,PermissionError):continue
        result[path.name]=target
    return result

def census(root):
    assert root.is_dir() and root.resolve()==root
    return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
def prior_roots():
    roots={REPO/row['path'] for row in load('prior-run-corpus-roots.json')}
    # Any later Root-owned run corpora join the same guards, never an exclusion.
    for directory in (REPO/'.ios-host-tmp').iterdir():
        if directory.is_dir() and not directory.is_symlink() and directory!=HERE:
            path=directory/'runs'
            if path.is_dir() and not path.is_symlink():roots.add(path)
    if (HERE/'runs').exists():
        for directory in (HERE/'runs').iterdir():
            if directory.is_dir():
                for path in directory.iterdir():
                    if path.is_dir():roots.add(path)
    return sorted(roots)
def prior_census(roots):return {str(path):census(path) for path in roots}
def public_guard():
    expected=load('public-dependency-baselines.json')
    raw=subprocess.check_output([load('host-executable-pins.json')['rg']['realPath'],'--files','-0',*PUBLIC_ROOTS],cwd=REPO)
    actual=set(filter(None,raw.decode().split('\0')))|{'CMakeLists.txt','interface/CMakeLists.txt'}
    assert actual==set(expected),'Public source membership changed'
    result={name:pin(REPO/name) for name in sorted(actual)}
    for name,row in result.items():
        old=expected[name]
        assert row['sha256']==old['sha256'] and row['st_dev']==old['device'] and row['st_ino']==old['inode'] and row['st_size']==old['bytes'],name
    return result

def validate():
    frozen=load('freeze.json')
    for row in frozen['files']:
        path=HERE/row['path'];assert path.is_file() and not path.is_symlink() and sha(path)==row['sha256'],row['path']
    source=load('isolated-source-origins.json');paths=[SOURCE,*sorted(SOURCE.rglob('*'))];assert not any(p.is_symlink() for p in paths),'Isolated source symlink refused'
    physical=load('isolated-source-physical-pins.json');actual={str(p.relative_to(SOURCE)) for p in paths if not p.is_dir()};actual_dirs={str(p.relative_to(SOURCE)) for p in paths if p.is_dir()}
    assert actual_dirs==set(physical['directories']),'Isolated source directory membership drift'
    for name,row in {**physical['files'],**physical['directories']}.items():
        info=(SOURCE/name).lstat();assert all(getattr(info,key)==value for key,value in row.items()),name
    assert actual==set(source),'Isolated source membership drift'
    for name,row in source.items():assert sha(SOURCE/name)==row['sha256'],name
    parent=REPO/load('execution-plan.json')['parentPlanPath'];assert sha(parent/'freeze.json')==load('execution-plan.json')['parentPlanRawFreezeSha256']
    packet=REPO/load('execution-plan.json')['packetPath'];assert sha(packet/'freeze.json')==load('execution-plan.json')['packetRawFreezeSha256']
    for row in json.loads((packet/'freeze.json').read_text())['files']:assert sha(packet/row['path'])==row['sha256'],row['path']
    fix=REPO/load('execution-plan.json')['mechanicalFixtureFixPath'];assert sha(fix/'freeze.json')==load('execution-plan.json')['mechanicalFixtureFixRawFreezeSha256']
    for row in json.loads((fix/'freeze.json').read_text())['files']:assert sha(fix/row['path'])==row['sha256'],row['path']
    bridge=REPO/load('execution-plan.json')['nativeConstructorFixturePath'];assert sha(bridge/'freeze.json')==load('execution-plan.json')['nativeConstructorFixtureRawFreezeSha256']
    for row in json.loads((bridge/'freeze.json').read_text())['files']:assert sha(bridge/row['path'])==row['sha256'],row['path']
    for failure_name in ('preserved-first-failure-pins.json','preserved-second-failure-pins.json','preserved-third-failure-pins.json','preserved-fourth-failure-pins.json','preserved-fifth-partial-pins.json'):
        failure=load(failure_name)
        for name,row in failure['files'].items():
            path=REPO/name;info=path.stat();assert sha(path)==row['sha256'] and (info.st_dev,info.st_ino,info.st_size)==(row['device'],row['inode'],row['bytes']),name
    edit_fix=REPO/load('execution-plan.json')['normalEditEnvelopeFixPath'];assert sha(edit_fix/'freeze.json')==load('execution-plan.json')['normalEditEnvelopeFixRawFreezeSha256']
    for row in json.loads((edit_fix/'freeze.json').read_text())['files']:assert sha(edit_fix/row['path'])==row['sha256'],row['path']
    live_fix=REPO/load('execution-plan.json')['currentPermissionsFixPath'];assert sha(live_fix/'freeze.json')==load('execution-plan.json')['currentPermissionsFixRawFreezeSha256']
    for row in json.loads((live_fix/'freeze.json').read_text())['files']:assert sha(live_fix/row['path'])==row['sha256'],row['path']
    scene_fix=REPO/load('execution-plan.json')['sceneGuardFixPath'];assert sha(scene_fix/'freeze.json')==load('execution-plan.json')['sceneGuardFixRawFreezeSha256']
    for row in json.loads((scene_fix/'freeze.json').read_text())['files']:assert sha(scene_fix/row['path'])==row['sha256'],row['path']
    for name,row in load('host-executable-pins.json').items():
        path=Path(row['path']);actual=path.resolve(strict=True);info=actual.stat()
        assert str(actual)==row['realPath'] and sha(actual)==row['sha256'] and (info.st_dev,info.st_ino)==(row['device'],row['inode']),name
    return load('execution-plan.json')
