"""Separate actual-job cleanup; original ReplyOwner2/3 stays immutable.

Only known original native read jobs may be observed/retired here. Native DTOs
keep the exact originating job ticket/token/resource/namespace; independent
current cleanup-phase originals supply fresh authorization. No new read job,
server mutation or whole holder/feature absence is claimed by this owner.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import time
from adapters.native_feature_observation import decode,exact,integer,need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.operation_transport_guard import check as transport_check
from adapters.script_feature.history import same,pack,unpack
from feature_journeys.contract import typed_equal
from feature_journeys.phase_fixture import validate as phase_original
from ios.adapters import assets_replies as source
from ios.adapters.assets_action_reply_owner import ActionAssetsReplyReads
from ios.adapters.assets_cleanup_phase import AssetsCleanupScope
from ios.adapters.assets_episodes import AssetsEpisodeScope
from ios.adapters.assets_reply_owner import OwnedAssetsReplyReads
from ios.adapters.assets_reply_sources import ReplySources
from ios.adapters.assets_model_sources import AssetsModelSources
from ios.adapters.assets_file_sources import sync

VERSION=1


class CleanupReplySources(ReplySources):
    NAMESPACE='assets-reply-clean-native'
    SCHEMA_PREFIX='iosAssetsReplyCleanNative'
    MIGRATION_PREFIX='assets-reply-clean-migration-'
    RECORD_KEY='iosAssetsReplyCleanNativeRecordVersion'
    MIGRATION_KEY='iosAssetsReplyCleanNativeMigrationVersion'


class OwnedAssetsReplyCleanup(OwnedAssetsReplyReads):
    def __init__(self,origin,cleanup,episode,store,*,native=None,historical=False,monotonic=time.monotonic):
        need(type(origin) in (OwnedAssetsReplyReads,ActionAssetsReplyReads) and origin.storage_version in (2,3)
            and type(cleanup) is AssetsCleanupScope and type(episode) is AssetsEpisodeScope and episode.owner is cleanup.owner.episodes
            and origin.lock is episode.locks['primary'] and isinstance(store,PrivateFeatureState) and type(historical) is bool
            and origin.previous is not None and origin.state is not None and callable(monotonic) and (native is None if historical else type(native) is source.IOSAssetsReplies))
        self.origin,self.cleanup,self.episode,self.store,self.historical=origin,cleanup,episode,store,historical
        self.run,self.role,self.url,self.binding,self.lock=origin.run,origin.role,origin.url,deepcopy(origin.binding),origin.lock
        need(self.role=='primary' and self.run==cleanup.owner.run and self.url==cleanup.owner.selected.context['fixtureUrl']
            and same(self.binding,cleanup.owner.binding) and store.path.parent==origin.store.path.parent
            and store.path==origin.store.path.with_name('ios-assets-'+self.run+'-primary-reply-cleanup.json'))
        self.native=SimpleNamespace(pid=int(self.binding['processIdentity']),monotonic=monotonic) if historical else native
        need(str(self.native.pid)==self.binding['processIdentity']);self.previous=store.read();self.state=None;self.storage_version=2
        self.query_refs=[];self.query_pending=None;self.query_by_id={}
        self.origin_reference=dict(path=str(origin.store.path),version=origin.previous['iosAssetsReplyOwnerVersion'],sha256=digest(origin.previous))
        self.sources=CleanupReplySources(self,'primary',self.metadata_guard,self.save)
        self.query_originals=OriginalFrameStore(store.path.parent,self.binding,self.run,'primary',self.metadata_guard,self.intent,
            namespace='assets-reply-clean-query',schema_prefix='iosAssetsReplyCleanQuery',kind='inputs',monotonic=monotonic)
        self.origin.state=self.origin.decode(self.origin.previous);self.metadata_guard()
        if not historical:
            for record in self.origin.state['originals']:
                packet=record['packet'];job=packet['source']['job']['request']['commandId'];native.last=deepcopy(packet);native.jobs[job]=deepcopy(packet)
            before=native.guard
            def current():self.live();need(before() is not False);return True
            native.guard=current
        if self.previous is not None:
            self.state=self.decode(self.previous)
            if not historical:
                for record in self.state['originals']:
                    packet=record['packet'];job=packet['source']['job']['request']['commandId'];native.last=deepcopy(packet);native.jobs[job]=deepcopy(packet)
    def metadata_guard(self):
        self.lock.assert_held();self.episode.guard();self.cleanup.owner.metadata_guard()
        need(same(self.origin.store.read(),self.origin.previous) and same(self.store.read(),self.previous));self.origin_link();return True
    def live(self):self.metadata_guard();need(not self.historical);self.cleanup.guard();return True
    def origin_link(self):
        current=dict(path=str(self.origin.store.path),version=self.origin.previous['iosAssetsReplyOwnerVersion'],sha256=digest(self.origin.previous))
        need(same(current,self.origin_reference));return deepcopy(self.origin_reference)
    def baseline(self,state):
        old=self.origin.state;count=len(old['commands']);need(state['commands'][:count]==old['commands'] and len(state['jobs'])==len(old['jobs'])
            and all(same(state[key],old[key]) for key in ('ticket','token','resource','namespace')))
        for previous,current in zip(old['jobs'],state['jobs']):
            need(all(same(previous[key],current[key]) for key in ('slot','query','issuedEpochMs','proof')))
        return old
    def query_row(self,row,index):
        exact(row,{'iosAssetsReplyCleanupQueryVersion','index','cleanup','phaseBefore','query','jobOrigin'})
        need(type(row['iosAssetsReplyCleanupQueryVersion']) is int and row['iosAssetsReplyCleanupQueryVersion']==VERSION
            and type(row['index']) is int and row['index']==index and same(row['cleanup'],self.cleanup.owner.link()))
        query=source.command(row['query']);original=source.command(row['jobOrigin']);need(query['operation'] in ('observe','retire') and original['operation'] in source.STARTS)
        jobs=[job for job in self.origin.state['jobs'] if job['query']['commandId']==query['jobId']]
        need(len(jobs)==1 and same(original,jobs[0]['query']) and all(query[key]==original[key] for key in ('runId','ticket','ownerToken','resource','namespace')))
        original_cleanup=self.cleanup.owner.read();self.cleanup.owner.phase_packet(row['phaseBefore'])
        phase_original(row['phaseBefore'],run=self.run,area='assets',request=row['phaseBefore']['requestId'],epoch=row['phaseBefore']['capturedEpochMs'],previous=original_cleanup['phaseOriginal'])
        need(typed_equal(row['phaseBefore']['activations'],original_cleanup['phaseOriginal']['activations']));return row
    def intent(self,kind,reference):
        need(kind=='original' and self.query_pending is not None);self.query_pending['original']=deepcopy(reference);self.save()
    def decode(self,value):
        exact(value,{'iosAssetsReplyCleanupVersion','binding','runId','role','fixtureUrl','originReply','cleanup','episode','queries','payload'})
        need(type(value['iosAssetsReplyCleanupVersion']) is int and value['iosAssetsReplyCleanupVersion']==VERSION
            and same(value['binding'],self.binding) and value['runId']==self.run and value['role']=='primary' and value['fixtureUrl']==self.url
            and same(value['originReply'],self.origin_link()) and same(value['cleanup'],self.cleanup.owner.link()) and same(value['episode'],self.episode.link()))
        self.origin.state=self.origin.decode(self.origin.previous)
        queries=value['queries'];exact(queries,{'refs','pending'});need(type(queries['refs']) is list and len(queries['refs'])<=512)
        self.query_refs=deepcopy(queries['refs']);self.query_pending=deepcopy(queries['pending']);mapping={}
        for index,reference in enumerate(self.query_refs,1):
            full=self.query_originals.expand(reference);need(full['index']==index);row=self.query_row(self.query_originals.read(full),index)
            need(row['query']['commandId'] not in mapping);mapping[row['query']['commandId']]=reference
        self.query_by_id=mapping
        if self.query_pending is not None:
            pending=self.query_pending;exact(pending,{'row','original'});self.query_row(pending['row'],len(self.query_refs)+1)
            if pending['original'] is not None:
                self.query_originals.original(pending['original']);need(pending['original']['index']==len(self.query_refs)+1)
                AssetsModelSources.prefix(SimpleNamespace(originals=self.query_originals),pending['original'])
                if pending['original']['phase']=='saved':need(same(self.query_originals.read(pending['original']),pending['row']))
        rows=unpack(value['payload']);need(len(rows)==1);stored=rows[0]
        exact(stored,{'phase','ticket','token','resource','namespace','commands','jobs','sources'})
        self.sources.load(stored['sources']);need(self.sources.migration is None);entries=deepcopy(self.origin.state['originals'])
        for reference in self.sources.refs:
            record=self.sources.read_record(reference);need(record['kind']=='native');entries.append(dict(query=deepcopy(record['query']),packet=decode(record['raw'])))
        state={key:deepcopy(stored[key]) for key in ('phase','ticket','token','resource','namespace','commands','jobs')};state['originals']=entries;self.baseline(state)
        need(self.sources.pending is None or state['phase']!='closed');return self.validate_state(state)
    def save(self):
        self.live();transport_check();need(self.native.guard() is not False)
        state={key:deepcopy(self.state[key]) for key in ('phase','ticket','token','resource','namespace','commands','jobs')};state['sources']=self.sources.manifest()
        value=dict(iosAssetsReplyCleanupVersion=VERSION,binding=self.binding,runId=self.run,role='primary',fixtureUrl=self.url,
            originReply=self.origin_link(),cleanup=self.cleanup.owner.link(),episode=self.episode.link(),
            queries=dict(refs=deepcopy(self.query_refs),pending=deepcopy(self.query_pending)),payload=pack([state]))
        need(same(self.decode(value),self.state));self.store.write(value,self.previous);sync(self.store.path.parent);self.previous=deepcopy(value)
    def reserve(self):
        self.live();need(self.state is None);self.state=deepcopy(self.origin.state);self.save()
    def query_context(self,query,state):
        previous=[row for row in self.origin.state['commands'] if row['commandId']==query['commandId']]
        if previous:
            need(len(previous)==1 and same(previous[0],query));return self.origin.query_context(query,self.origin.state)
        reference=self.query_by_id.get(query['commandId']);need(reference is not None)
        row=self.query_row(self.query_originals.read(self.query_originals.expand(reference)),self.query_originals.expand(reference)['index']);need(same(row['query'],query))
    def query_ticket(self,kind,values):
        self.live();need(kind in ('observe','retire'));jobs=[job for job in self.origin.state['jobs'] if job['query']['commandId']==values.get('jobId')];need(len(jobs)==1)
        return jobs[0]['query']['ticket']
    def query_intent(self,query):
        self.live();need(self.query_pending is None and len(self.query_refs)<512)
        jobs=[job for job in self.origin.state['jobs'] if job['query']['commandId']==query.get('jobId')];need(len(jobs)==1)
        original_cleanup=self.cleanup.owner.read();phase=self.cleanup.owner.current_packet(original_cleanup)
        row=dict(iosAssetsReplyCleanupQueryVersion=VERSION,index=len(self.query_refs)+1,cleanup=self.cleanup.owner.link(),
            phaseBefore=phase,query=deepcopy(query),jobOrigin=deepcopy(jobs[0]['query']));self.query_row(row,row['index'])
        self.query_pending=dict(row=row,original=None);self.save();reference=self.query_originals.write(row['index'],row)
        self.cleanup.guard();self.query_refs.append(reference);self.query_pending=None;self.save();return query
    def recover_query(self):
        self.live();need(self.query_pending is not None);reference=self.query_pending['original'];need(reference is not None and reference['phase']=='saved')
        row=self.query_row(self.query_originals.read(reference),len(self.query_refs)+1);need(same(row,self.query_pending['row']));self.cleanup.guard()
        self.query_refs.append(self.query_originals.compact(reference));self.query_pending=None;self.save();return row
    def read(self,*_args,**_kwargs):need(False) # No new jobs in a cleanup profile.
    def report(self):
        self.metadata_guard();need(self.state is not None and self.previous is not None);state=self.decode(self.previous)
        native_ids={query['commandId'] for query in state['commands']};unissued=[]
        for reference in self.query_refs:
            row=self.query_originals.read(self.query_originals.expand(reference))
            if row['query']['commandId'] not in native_ids:unissued.append(row['query']['commandId'])
        duties=[]
        if state['phase']!='closed':duties.append('original-read-jobs')
        if self.sources.pending is not None:duties.append('cleanup-native-original-prefix')
        if self.query_pending is not None:duties.append('cleanup-query-original-prefix')
        if unissued:duties.append('unissued-cleanup-query-intent')
        if self.origin.sources.pending is not None:duties.append('origin-native-original-prefix')
        if type(self.origin) is ActionAssetsReplyReads:
            provenance=self.origin.query_sources;known={query['commandId'] for query in self.origin.state['commands']}
            if provenance.state['pending'] is not None:duties.append('origin-action-query-original-prefix')
            for reference in provenance.state['refs']:
                row=provenance.originals.read(provenance.originals.expand(reference))
                if row['query']['commandId'] not in known:duties.append('origin-unissued-query-intent')
        return dict(iosAssetsReplyCleanupObservationVersion=1,knownJobs=len(state['jobs']),knownJobsClosed=state['phase']=='closed',
            originalReplyUnchanged=True,retainedDuties=sorted(set(duties)),wholeNativeHolderAbsence=False,wholeEndEligible=False)
