"""Existing Tablet60 work bound through public candidate and final guards."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
import time
from adapters.native_feature_observation import number
from adapters.normal_ui import NativeUIError
from adapters.operation_transport_guard import scope as transport_scope

SECONDS=60
_CURRENT=ContextVar('tablet_public_api_work_budget',default=None)


@contextmanager
def scope(monotonic=time.monotonic):
    prior=_CURRENT.get()
    if prior is not None:
        with transport_scope(prior):prior();yield;prior()
        return
    started=last=monotonic();failed=False
    if not number(started,0,1e15):raise NativeUIError('Tablet API work clock is unavailable')
    def check():
        nonlocal last,failed
        now=monotonic()
        if failed or not number(now,last,started+SECONDS) or now>=started+SECONDS:
            failed=True;raise NativeUIError('Tablet API deadline exhausted or host clock changed')
        last=now
    token=_CURRENT.set(check)
    try:
        with transport_scope(check):check();yield;check()
    finally:_CURRENT.reset(token)


def installed_entry(function,*,monotonic=time.monotonic):
    @wraps(function)
    def invoke(adapter,selector,operation,values):
        if not operation.startswith('feature.tablet-web.'):return function(adapter,selector,operation,values)
        with scope(monotonic):return function(adapter,selector,operation,values)
    return invoke
