"""Bounded telemetry of actual code frames; never an Assets verdict/cache.

Callbacks retain no frame, value, owner, namespace or exception object. The
only strong object bindings are the original top-level function/code/globals
installation and original observer C ports. No IO runs in event callbacks.
"""
from types import FunctionType,FrameType,MethodType,ModuleType,CodeType,BuiltinFunctionType,MappingProxyType
import os,sys,time,threading

SCALARS=((type(None),'none'),(bool,'bool'),(int,'int'),(float,'float'),(str,'str'),(bytes,'bytes'))
_CLOCK=time.perf_counter_ns
_IDENT=threading.get_ident
_FRAME=sys._getframe
_MONITOR=sys.monitoring
_MONITOR_PORTS={name:vars(_MONITOR)[name]for name in('get_tool','get_events','get_local_events','use_tool_id','register_callback','set_local_events','set_events','free_tool_id')}
_EVENTS={name:getattr(_MONITOR.events,name)for name in('PY_START','PY_RETURN','PY_UNWIND')}
CATEGORIES=((FunctionType,'function'),(MethodType,'bound-method'),(dict,'dict'),(list,'list'),(tuple,'tuple'),(set,'set'),(frozenset,'frozenset'),(classmethod,'classmethod'),(staticmethod,'staticmethod'),(CodeType,'code'),(ModuleType,'module'),(type,'class'),(MappingProxyType,'mapping-proxy'))

class IntentGraphDiagnostic:
    MAX_ROWS=128
    MAX_NAMES=96
    MAX_LABEL=160
    MAX_THREADS=8
    MAX_DEPTH=512
    MAX_EVENTS=1000000
    MAX_NAMESPACES=256
    MAX_CLASSES=1024
    def __init__(self,bindings,namespace_labels=(),parent_bindings=(),class_labels=(),member_bindings=()):
        self.clock=_CLOCK;self.ident=_IDENT;self.frame=_FRAME
        assert type(self.clock)is BuiltinFunctionType and type(self.ident)is BuiltinFunctionType and type(self.frame)is BuiltinFunctionType
        self.monitor=_MONITOR;self.ports=dict(_MONITOR_PORTS);self.events_masks=dict(_EVENTS);self.tool=None;self.acquired_name=None;self.acquired_ever=False;self.released=False;self.pending_acquisition=None;self.pending_callbacks=set();self.global_before=None;self.local_before={};self.old_callbacks={};self.callback_objects={};self.restoration_errors=[];self.callback_faults=[];self.fault_count=0;self.disabled=False;self.abandoned_frames=0;self.main=self.ident();self.rows={};self.threads={};self.events=0;self.saturated=False;self.labels_dropped=0;self.unknown_labels=0
        self.member_bindings=tuple(member_bindings);self.namespace_labels={};self.class_labels={};self.parents={};self.bindings={};self.original=[]
        for namespace,label in namespace_labels:
            assert (type(namespace)is dict or type(namespace)is MappingProxyType)and type(label)is str and 0<len(label)<=self.MAX_LABEL
            if len(self.namespace_labels)>=self.MAX_NAMESPACES:self.labels_dropped+=1;self.saturated=True;continue
            self.namespace_labels[id(namespace)]=label
        for cls,label in class_labels:
            assert type(cls)is type and type(label)is str and 0<len(label)<=self.MAX_LABEL
            if len(self.class_labels)>=self.MAX_CLASSES:self.labels_dropped+=1;self.saturated=True;continue
            self.class_labels[id(cls)]=label
        for label,fn in parent_bindings:
            self._bind_original(fn);self.parents[id(fn.__code__)]=(fn.__code__,fn.__globals__,label)
        for kind,fn in bindings:
            assert kind in('add','value','fingerprint');self._bind_original(fn)
            code=fn.__code__;assert id(code)not in self.bindings
            if kind=='fingerprint':
                assert fn.__globals__.get(fn.__name__)is fn
                self.member_bindings+=((fn.__globals__,fn.__name__,fn),)
            self.bindings[id(code)]=(code,fn.__globals__,kind)
        assert {row[2]for row in self.bindings.values()}=={'add','value','fingerprint'}
        self.name='overte-assets-policy-graph-diagnostic-'+str(os.getpid())+'-'+str(id(self))
        self.started_ns=None;self.stopped_ns=None;self.last_snapshot_ns=None
    def _bind_original(self,fn):
        assert type(fn)is FunctionType and fn.__closure__ is None
        self.original.append((fn,fn.__code__,fn.__globals__,fn.__defaults__,fn.__kwdefaults__))
    def installation_unchanged(self):
        return (time.perf_counter_ns is self.clock and threading.get_ident is self.ident and sys._getframe is self.frame and sys.monitoring is self.monitor
            and all(vars(self.monitor).get(name)is port for name,port in self.ports.items())
            and all((container.get(name)if type(container)is dict else vars(container).get(name))is fn for container,name,fn in self.member_bindings)
            and all(fn.__code__ is code and fn.__globals__ is namespace and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords for fn,code,namespace,defaults,keywords in self.original))
    def _owned_slot(self):
        assert sys.monitoring is self.monitor and all(vars(self.monitor).get(name)is port for name,port in self.ports.items())
        assert self.tool is not None and self.acquired_name is self.name
        assert self.ports['get_tool'](self.tool)is self.acquired_name,'Unknown/replaced diagnostic slot'
        return True
    def _secondary_fault(self,phase,error):
        # No exception/traceback/frame/value retained and no IO or clock read.
        self.fault_count+=1
        if len(self.callback_faults)<16:self.callback_faults.append((phase,type(error)))
        self.disabled=True
        for row in self.threads.values():
            self.abandoned_frames+=len(row['frames']);row['frames'].clear()
            row['depth']=row['fingerprintDepth']=row['overDepth']=0
    def start(self):
        assert self.tool is None and not self.acquired_ever and self.pending_acquisition is None and not self.pending_callbacks and self.installation_unchanged()
        free=[tool for tool in(2,5,4,3,1,0)if self.ports['get_tool'](tool)is None and self.ports['get_events'](tool)==0];assert free
        tool=free[0]
        try:
            # Candidate alone is never mutation/free authority.
            self.pending_acquisition=tool # Candidate only, never ownership.
            self.ports['use_tool_id'](tool,self.name)
            self.tool=tool;self.acquired_name=self.name;self.acquired_ever=True
            self.pending_acquisition=None # Only after the actual return ledger.
            self._owned_slot();self.global_before=self.ports['get_events'](tool);assert self.global_before==0
            for event,callback in((self.events_masks['PY_START'],self.entered),(self.events_masks['PY_RETURN'],self.returned),(self.events_masks['PY_UNWIND'],self.unwound)):
                self._owned_slot();self.callback_objects[event]=callback
                self.pending_callbacks.add(event) # Prior return still unknown.
                self.old_callbacks[event]=self.ports['register_callback'](tool,event,callback)
                self.pending_callbacks.remove(event)
            for code,_namespace,_kind in self.bindings.values():
                self._owned_slot();self.local_before[code]=self.ports['get_local_events'](tool,code)
                self.ports['set_local_events'](tool,code,self.events_masks['PY_START']|self.events_masks['PY_RETURN'])
            # Original CPython3.14 global UNWIND, filtered before frame reads.
            self._owned_slot();self.ports['set_events'](tool,self.events_masks['PY_UNWIND']);self.started_ns=self.clock()
        except BaseException as original_error:
            self._secondary_fault('start',original_error)
            try:self.stop()
            except BaseException as secondary:self._secondary_fault('partial-start-stop',secondary)
            raise # Preserve original acquisition/installation exception identity.
        return self
    def _label(self,frame,kind):
        namespace=frame.f_locals.get('namespace');name=frame.f_locals.get('name')
        label=self.namespace_labels.get(id(namespace))
        if label is None:
            # Only inspect a genuine immediate known policy caller's locals,
            # never call a namespace getter or discover a convenient ancestor.
            caller=frame.f_back
            if caller is not None:
                port=self.parents.get(id(caller.f_code))
                if port is not None and caller.f_code is port[0]and caller.f_globals is port[1]:
                    local=caller.f_locals
                    actual_class=local.get('cls',local.get('value'))
                    label=self.class_labels.get(id(actual_class))if type(actual_class)is type else None
                    if label is None:label=port[2]+'/<class-unlisted>'
            if label is None:label='<unlisted-namespace>';self.unknown_labels+=1
        if kind=='add':name='<add-names-not-reiterated>'
        elif type(name)is not str or len(name)>self.MAX_NAMES:name='<non-exact-or-long-name>'
        return label,name
    def _thread(self):
        ident=self.ident();row=self.threads.get(ident)
        if row is None:
            if len(self.threads)>=self.MAX_THREADS:self.saturated=True;return None
            row=dict(main=ident==self.main,depth=0,maxDepth=0,fingerprintDepth=0,maxFingerprintDepth=0,frames=[],overDepth=0,starts=0,returns=0,unwinds=0)
            self.threads[ident]=row
        return row
    def entered(self,code,offset):
        if self.disabled:return
        try:
            binding=self.bindings.get(id(code))
            if binding is None:return
            frame=self.frame(1)
            assert type(frame)is FrameType and frame.f_code is code is binding[0]and frame.f_globals is binding[1]
            self._event('start',binding[2],frame)
        except Exception as diagnostic_error:self._secondary_fault('start',diagnostic_error)
        # KeyboardInterrupt/SystemExit retain the original cancellation path.

    def returned(self,code,offset,value):
        if self.disabled:return
        try:
            binding=self.bindings.get(id(code))
            if binding is None:return
            frame=self.frame(1)
            assert type(frame)is FrameType and frame.f_code is code is binding[0]and frame.f_globals is binding[1]
            self._event('return',binding[2],frame)
        except Exception as diagnostic_error:self._secondary_fault('return',diagnostic_error)
        # KeyboardInterrupt/SystemExit retain the original cancellation path.

    def unwound(self,code,offset,exception):
        if self.disabled:return
        try:
            binding=self.bindings.get(id(code))
            if binding is None:return
            frame=self.frame(1)
            assert type(frame)is FrameType and frame.f_code is code is binding[0]and frame.f_globals is binding[1]
            self._event('unwind',binding[2],frame)
        except Exception as diagnostic_error:self._secondary_fault('unwind',diagnostic_error)
        # KeyboardInterrupt/SystemExit retain the original cancellation path.

    def _event(self,event,kind,frame):
        if self.events>=self.MAX_EVENTS:self.saturated=True;return
        self.events+=1
        thread=self._thread()
        if thread is None:return
        now=self.clock()
        if event=='start':
            thread['starts']+=1;thread['depth']+=1;thread['maxDepth']=max(thread['maxDepth'],thread['depth'])
            if kind=='fingerprint':thread['fingerprintDepth']+=1;thread['maxFingerprintDepth']=max(thread['maxFingerprintDepth'],thread['fingerprintDepth'])
            if thread['depth']>self.MAX_DEPTH:thread['overDepth']+=1;self.saturated=True;return
            label,name=self._label(frame,kind)if kind in('value','add')else('<no-policy-value>','<none>')
            namespace_identity=id(frame.f_locals.get('namespace'))if kind in('add','value')else None
            if kind=='value'and label=='<unlisted-namespace>':
                # value normally sits below add's genuine generator frame.
                # Match only an already observed active add with the SAME
                # live namespace identity; no arbitrary ancestor-frame search.
                for parent in reversed(thread['frames']):
                    if parent[0]=='add'and parent[5]==namespace_identity:label=parent[1];break
            if kind=='fingerprint':
                value=frame.f_locals.get('value');actual=type(value);category='opaque'
                for scalar,text in SCALARS:
                    if actual is scalar:category=text;break
                for expected,text in CATEGORIES:
                    if actual is expected:category=text;break
                # Inherit only stored scalar labels from the nearest real
                # value call; no owner/namespace/value is retained in the stack.
                for parent in reversed(thread['frames']):
                    if parent[0]=='value':label,name=parent[1],parent[2];break
            else:category=kind
            key=('main'if thread['main']else'foreign',label,name,category)
            if key not in self.rows:
                if len(self.rows)>=self.MAX_ROWS:self.labels_dropped+=1;key=None;self.saturated=True
                else:self.rows[key]=dict(starts=0,returns=0,unwinds=0,inclusiveNs=0,maxInclusiveNs=0,maxDepth=0)
            if key is not None:
                row=self.rows[key];row['starts']+=1;row['maxDepth']=max(row['maxDepth'],thread['depth'])
            thread['frames'].append((kind,label,name,key,now,namespace_identity));return
        thread['returns'if event=='return'else'unwinds']+=1
        assert thread['depth']>0
        if kind=='fingerprint':
            assert thread['fingerprintDepth']>0;thread['fingerprintDepth']-=1
        if thread['overDepth']:
            thread['overDepth']-=1;thread['depth']-=1;return
        assert thread['frames'];previous=thread['frames'].pop();assert previous[0]==kind
        thread['depth']-=1;key=previous[3]
        if key is not None:
            row=self.rows[key];elapsed=now-previous[4];assert elapsed>=0
            row['returns'if event=='return'else'unwinds']+=1;row['inclusiveNs']+=elapsed;row['maxInclusiveNs']=max(row['maxInclusiveNs'],elapsed)
    def snapshot(self):
        now=self.clock();self.last_snapshot_ns=now
        rows=[dict(thread=key[0],namespace=key[1],name=key[2],category=key[3],**row)for key,row in self.rows.items()]
        threads=[dict(identity=ident,main=row['main'],depth=row['depth'],maxDepth=row['maxDepth'],fingerprintDepth=row['fingerprintDepth'],maxFingerprintDepth=row['maxFingerprintDepth'],starts=row['starts'],returns=row['returns'],unwinds=row['unwinds'],pending=[dict(kind=x[0],namespace=x[1],name=x[2],namespaceIdentity=x[5],elapsedNs=max(0,now-x[4]))for x in row['frames']])for ident,row in self.threads.items()]
        return dict(schemaVersion=1,diagnosticOnly=True,originalVerdictProvided=False,hostClockOnly=True,nativeClockRead=False,events=self.events,eventCap=self.MAX_EVENTS,saturated=self.saturated,labelsDropped=self.labels_dropped,unlistedNamespaceLabels=self.unknown_labels,rows=rows,threads=threads,installationUnchanged=self.installation_unchanged(),active=None if self.pending_acquisition is not None else self.tool is not None,successfulToolAcquisition=None if self.pending_acquisition is not None else self.acquired_ever,acquisitionOutcomeUnknown=self.pending_acquisition is not None,mutationCandidateToolId=self.pending_acquisition,callbackMutationOutcomeUnknown=bool(self.pending_callbacks),unknownCallbackEvents=sorted(self.pending_callbacks),successfulToolRelease=self.released,diagnosticDisabled=self.disabled,diagnosticFaultCount=self.fault_count,diagnosticFaultTypes=[dict(phase=phase,type=kind.__module__+'.'+kind.__qualname__)for phase,kind in self.callback_faults],abandonedFrames=self.abandoned_frames,diagnosticComplete=self.pending_acquisition is None and not self.pending_callbacks and not self.disabled and not self.saturated and all(not row['frames']for row in self.threads.values()),restorationErrors=list(self.restoration_errors),elapsedNs=None if self.started_ns is None else now-self.started_ns,inclusiveTimesOverlapAndIncludeObserverOverhead=True,totalRuntimeCauseEstablished=False,wholeAssetsQualified=False)
    def stop(self):
        # Each attempt is independent and freshly fenced to actual acquisition.
        errors=[];tool=self.tool
        def attempt(phase,function,*,owned=False):
            try:
                if owned:self._owned_slot()
                return function()
            except Exception as error:
                errors.append(dict(phase=phase,type=type(error).__module__+'.'+type(error).__qualname__));return None
        if tool is not None:
            for code,previous in self.local_before.items():
                attempt('local-mask',lambda code=code,previous=previous:self.ports['set_local_events'](tool,code,previous),owned=True)
            if self.global_before is not None:attempt('global-mask',lambda:self.ports['set_events'](tool,self.global_before),owned=True)
            for event,previous in self.old_callbacks.items():
                actual=attempt('callback',lambda event=event,previous=previous:self.ports['register_callback'](tool,event,previous),owned=True)
                if actual is not self.callback_objects[event]:errors.append(dict(phase='callback-current-identity',type='identity-mismatch'))
            def release():
                self.ports['free_tool_id'](tool)
                # Consume authority even if a later readback/clock fails.
                self.tool=None;self.acquired_name=None;self.released=True
            attempt('free-acquired-tool',release,owned=True)
            def readback():
                assert self.tool is None and self.acquired_name is None and self.ports['get_tool'](tool)is None
                if self.global_before is not None:assert self.ports['get_events'](tool)==self.global_before
                for code,previous in self.local_before.items():assert self.ports['get_local_events'](tool,code)==previous
            attempt('released-state-readback',readback)
        elif self.acquired_name is not None:errors.append(dict(phase='acquisition-ledger',type='identity-mismatch'))
        if self.acquired_ever:attempt('host-stop-clock',lambda:setattr(self,'stopped_ns',self.clock()))
        self.restoration_errors.extend(errors)
        return dict(diagnosticOnly=True,actualToolId=tool,actualToolAcquired=None if self.pending_acquisition is not None else self.acquired_ever,actualToolFreed=self.released,
            acquisitionOutcomeUnknown=self.pending_acquisition is not None,mutationCandidateToolId=self.pending_acquisition,callbackMutationOutcomeUnknown=bool(self.pending_callbacks),unknownCallbackEvents=sorted(self.pending_callbacks),
            currentOwnershipReleased=self.pending_acquisition is None and self.tool is None and self.acquired_name is None,
            actualOriginalStateRestored=self.pending_acquisition is None and not self.pending_callbacks and not self.restoration_errors,
            restorationErrors=list(self.restoration_errors),priorGlobalMask=self.global_before,priorLocalMaskCount=len(self.local_before),priorCallbackCount=len(self.old_callbacks))


def picker_diagnostic(picker_module,policy_module,project_modules):
    assert type(picker_module)is ModuleType and type(policy_module)is ModuleType
    namespace=vars(picker_module);policy=namespace['IntentCodePolicy'];base=vars(policy_module)['ClosedParserPolicy']
    bindings=(('fingerprint',namespace['_intent_value']),('add',vars(policy)['add']),('value',vars(policy)['value']))
    parents=tuple(('policy.'+name,vars(base)[name])for name in('module','function','follow'))
    labels=[];classes=[];dropped=0
    for module in project_modules:
        assert type(module)is ModuleType
        label=vars(module).get('__name__')
        if type(label)is str and 0<len(label)<=IntentGraphDiagnostic.MAX_LABEL:
            if len(labels)<IntentGraphDiagnostic.MAX_NAMESPACES:labels.append((vars(module),label))
            else:dropped+=1
            for name,value in vars(module).items():
                if type(name)is str and type(value)is type and len(label)+len(name)+1<=IntentGraphDiagnostic.MAX_LABEL:
                    if len(classes)<IntentGraphDiagnostic.MAX_CLASSES:classes.append((value,label+'.'+name))
                    else:dropped+=1
    result=IntentGraphDiagnostic(bindings,labels,parents,classes,((namespace,'IntentCodePolicy',policy),(vars(policy_module),'ClosedParserPolicy',base),(policy,'add',vars(policy)['add']),(policy,'value',vars(policy)['value']))+tuple((base,name,vars(base)[name])for name in('module','function','follow')))
    result.labels_dropped+=dropped;result.saturated=result.saturated or dropped>0
    return result
