from pathlib import Path
import ast,difflib,hashlib,json,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';OLD=T/'lifecycle-original-owner-motion-owned-root-preparation-20261028/11-owned-motion14';O=T/'lifecycle-original-owner-motion-empty-map-model-overlay-20261028';O.mkdir(mode=0o700);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
model='test_motion_owned_reference_models.py';b=(OLD/model).read_text();a="self.assertEqual([],self.journal().get('motionOriginals',{}))";c="self.assertEqual({},self.journal().get('motionOriginals',{}))";assert b.count(a)==1;s=b.replace(a,c);ast.parse(s);(O/model).write_text(s)
(O/'model-only.diff').write_text(''.join(difflib.unified_diff(b.splitlines(True),s.splitlines(True),fromfile='a/'+model,tofile='b/'+model)))
(O/'README.txt').write_text('TEST ONLY: exact one expected-value [] to {} correction for actual absent motionOriginals dictionary. No Source/budget/fixture/control changes. Original failed three-case attempt and13 genuine files preserved. Full exact Python10+Node4 remains UNRUN after correction.\n')
(O/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_MODEL_ONLY_UNRUN',files={p.name:h(p) for p in sorted(O.iterdir()) if p.is_file()}),indent=2)+'\n')
TOP=T/'lifecycle-original-owner-motion14-empty-map-corrected-root-preparation-20261028';TOP.mkdir(mode=0o700);S=TOP/'13-owned-motion14';S.mkdir(mode=0o700)
oldfreeze=json.loads((OLD/'freeze.json').read_text())['files']
for n,digest in oldfreeze.items():
 src=OLD/n;assert h(src)==digest;dst=S/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
shutil.copyfile(O/model,S/model)
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=h(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((OLD/'prior-retained-original-pins.json').read_text());added=OLD/'retained-first';count=0
for p in [added,*sorted(added.rglob('*'))]:
 prior[str(p)]=pin(p);count+=p.is_file()
assert count==13
(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n')
stage=json.loads((OLD/'source-manifest.json').read_text());updates=[]
for row in stage['sourcePaths']:
 p=R/row['path'];current=h(p)
 if row['candidateSHA256']!=current:
  dst=S/'current-dependency-snapshots/repo'/row['path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
  updates.append(dict(path=row['path'],previous=row['candidateSHA256'],current=current));row.update(candidate=str(dst),candidateSHA256=current)
 row.update(observedPublicSHA256=current,changesCurrentPublic=False)
stage.update(stage=13,name='13-owned-motion14-empty-map-corrected',status='PRIVATE_UNRUN_MODEL_ONLY_CORRECTED',sourceDeltaPaths=[],exactPublicMutationPlan='NONE. Source3/own3 already Root-published; actual current expectations preserved, strict pins not relaxed.')
stage['orderedParentFreezes'][O.name]=h(O/'freeze.json')
(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
plan=json.loads((OLD/'run-plan.json').read_text());plan['privateFiles'][model]=h(S/model);plan['status']='PRIVATE_UNRUN_EXACT10PY_NODE4_EMPTY_MAP_MODEL_CORRECTION';(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(S/'clone-provenance.json').write_text(json.dumps(dict(oldRootFreezeSHA256=h(OLD/'freeze.json'),modelOverlayFreezeSHA256=h(O/'freeze.json'),oldModelSHA256=h(OLD/model),correctedModelSHA256=h(S/model),onlyModelCorrection='Expected absent motionOriginals dictionary {}, not list []',actualPreviousFailedOriginalFiles=count,priorOriginalFilesGuarded=sum('sha256' in v for v in prior.values()),actualSourceChanges=updates,initialSeconds=60,killAfterSeconds=5,nodeInnerSeconds=15,expectedRealRoots=10,pythonCount=10,nodeCount=4,publicMutations=False,executed=False),indent=2)+'\n')
(S/'README-correction.txt').write_text('Exact prospective original Python10+Node4 retry after sole test expectation correction []->{}.60+kill5/Node15/10 genuine TD. Source3 and Source/registry gates unchanged; no PUB needed. All147 previous+13 failed originals guarded; actual current shared Source expectations snapshotted, no hashes relaxed. Inherited README/clone design historical; current clone-provenance and actual run-plan supersede old fixture hash/count provenance. No agent imports/Node/tests. Root mandatory full actual source/launcher/SDK map BEFORE imports; actual FD/task/thread/child plus two original censuses unchanged.\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes(),filename=str(p))
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_CORRECTED_EXACT14',files={str(p.relative_to(S)):h(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n')
(TOP/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(TOP)):h(p) for p in sorted(TOP.rglob('*')) if p.is_file()}),indent=2)+'\n')
print('overlay',h(O/'freeze.json'),'model',h(O/model));print('stage',h(S/'freeze.json'),'parent',h(TOP/'freeze.json'));print('snapshots',updates,'prior files',sum('sha256' in v for v in prior.values()))
