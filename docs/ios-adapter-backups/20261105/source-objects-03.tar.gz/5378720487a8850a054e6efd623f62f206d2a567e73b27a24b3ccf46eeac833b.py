"""Root-only metadata for exact new helper baseline6 or transaction8 utility.

No builder runs on import; no test, app SDK, Pillow or defused module is imported.
"""
from pathlib import Path
import argparse
import hashlib
import importlib.machinery
import json
import os
import sys
from metadata_reader import pin
from host_common import REPO, head

SOURCE = Path(__file__).resolve().parent
SUBJECT = REPO / '.ios-host-tmp/chat-controller10d-exact-defused-et-transaction-source-private-20261104'
SUBJECT_SHA = 'fbcc253aebc8a11883bfebe4ffae10888351337e3e0f4092c477c4550c342f4b'
HELPER_SHA = '69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'


def load(path):
    return json.loads(Path(path).read_text())


def packet(folder, leaf, digest):
    path = folder / leaf
    assert pin(path)['sha256'] == digest
    body = load(path)
    result = {str(path): pin(path)}
    for name, row in body['files'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        actual = folder / name
        assert actual.resolve(strict=True) == actual
        expected = row if type(row) is str else row['sha256']
        result[str(actual)] = pin(actual)
        assert result[str(actual)]['sha256'] == expected
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source-freeze', required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--selection', required=True, choices=('baseline6', 'transaction8'))
    parser.add_argument('--destination', required=True, type=Path)
    args = parser.parse_args()
    assert Path.cwd() == REPO and sys.dont_write_bytecode and sys.flags.no_site == 1 and sys.flags.optimize == 0
    assert len(args.expected_head) == 40 and all(c in '0123456789abcdef' for c in args.expected_head)
    assert head() == args.expected_head
    physical = packet(SOURCE, 'source-freeze.json', args.source_freeze)
    physical.update(packet(SUBJECT, 'source-freeze.json', SUBJECT_SHA))
    assert pin(SOURCE / 'closed_import_origins.py')['sha256'] == HELPER_SHA
    previous = REPO / '.ios-host-tmp/chat-c10c-source-execution-own6-bootstrap2-outcome-custody-code-preparation-20261104'
    physical.update(packet(previous, 'source-freeze.json', '1df80b4b1597a4c2e896cc234ab20ea34f12b4529924ce7175d5fe61af80b681'))
    assert (SOURCE / 'test_c10_source_execution.py').read_bytes() == (previous / 'test_c10_source_execution.py').read_bytes()
    baseline = REPO / '.ios-host-tmp/root-c10c-source-execution-six-cache-mutation-alias-counters-qualified-results-20261104'
    physical.update(packet(baseline, 'freeze.json', '8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a'))
    # These facts remain historical source evidence, not C10d qualification.
    for path, row in load(SUBJECT / 'SOURCE-REFERENCES.json').items():
        physical[path] = pin(Path(path))
        assert physical[path]['sha256'] == row['sha256']
    retainer = REPO / 'tests/device/ios/self_tests/retained_host_roots.py'
    physical[str(retainer)] = pin(retainer)
    assert physical[str(retainer)]['sha256'] == '07ddd7913819ee1c7d21bd36567c207906c7cc9df82e59d6fe80b64b0dadbcf6'
    third = load(SOURCE / 'exact-defused-source-declarations.json')
    assert set(third) == {'defusedxml', 'defusedxml.common', 'defusedxml.ElementTree'}
    for row in third.values():
        path = Path(row['path'])
        physical[str(path)] = pin(path)
        assert physical[str(path)]['sha256'] == row['sha256'] and row['loader'] == 'source'
    recipe = load(SOURCE / 'COUNTER-RESOURCE-RECIPE.json')
    selection = recipe['selections'][args.selection]
    cases = selection['cases']
    assert len(cases) == len(set(cases)) == selection['caseCount'] == (6 if args.selection == 'baseline6' else 8)
    selectors = 'baseline-six-selectors.json' if args.selection == 'baseline6' else 'new-eight-selectors.json'
    assert cases == load(SOURCE / selectors)
    assert selection['wallSeconds'] == 30 and selection['graceSeconds'] == 5
    assert selection['TDsPerCase'] == 1 and selection['TDs'] == selection['caseCount']
    std = Path(os.__file__).resolve(strict=True).parent
    suffixes = tuple(importlib.machinery.EXTENSION_SUFFIXES)
    std_namespaces = {}
    for current, dirs, names in os.walk(std, topdown=True, followlinks=False):
        folder = Path(current)
        dirs[:] = sorted(name for name in dirs if name not in ('site-packages', 'dist-packages', '__pycache__') and not (folder / name).is_symlink())
        relative = folder.relative_to(std)
        if relative.parts and all(part.isidentifier() for part in relative.parts) and not (folder / '__init__.py').is_file():
            std_namespaces['.'.join(relative.parts)] = [str(folder)]
        for name in names:
            path = folder / name
            if path.suffix != '.py' and not str(path).endswith(suffixes):
                continue
            assert path.resolve(strict=True) == path and not path.is_symlink()
            physical[str(path)] = pin(path)
    python = Path(sys.executable).resolve(strict=True)
    physical[str(python)] = pin(python)
    git = (REPO / '.git').read_text()
    assert git.startswith('gitdir: ')
    gd = Path(git[8:].strip())
    gd = (gd if gd.is_absolute() else REPO / gd).resolve(strict=True)
    common = (gd / (gd / 'commondir').read_text().strip()).resolve(strict=True)
    for path in (REPO / '.git', gd / 'HEAD', gd / 'index', gd / 'commondir'):
        physical[str(path)] = pin(path)
    ref = (gd / 'HEAD').read_text().strip()
    assert ref.startswith('ref: ')
    actual_ref = next((base / ref[5:] for base in (gd, common) if (base / ref[5:]).is_file()), common / 'packed-refs')
    physical[str(actual_ref)] = pin(actual_ref)
    destination = args.destination
    assert destination.is_absolute() and destination.resolve(strict=False) == destination
    assert destination.parent == REPO / '.ios-host-tmp' and destination.name.startswith('chat-c10d-source-execution-prepared-') and not destination.exists()
    before = dict(physical)
    assert all(pin(path) == row for path, row in before.items()) and head() == args.expected_head
    destination.mkdir(mode=0o700)
    names = ('run-utility.py', 'supervise-utility.py', 'metadata_reader.py', 'host_common.py', 'closed_import_origins.py',
        'owned_write_boundary.py', 'test_c10_source_execution.py', 'test_c10d_defused_transaction.py',
        'readonly-shared-stdlib-sources.json', 'baseline-six-selectors.json', 'new-eight-selectors.json',
        'COUNTER-RESOURCE-RECIPE.json', 'exact-defused-source-declarations.json')
    for name in names:
        target = destination / name
        descriptor = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write((SOURCE / name).read_bytes())
        physical[str(target)] = pin(target)
    projects = {}
    for name in ('metadata_reader', 'host_common', 'closed_import_origins', 'owned_write_boundary', 'test_c10_source_execution', 'test_c10d_defused_transaction'):
        path = destination / (name + '.py')
        projects[name] = dict(path=str(path), sha256=physical[str(path)]['sha256'], package=False)
    projects['ios.self_tests.retained_host_roots'] = dict(path=str(retainer), sha256=physical[str(retainer)]['sha256'], package=False)
    namespaces = {'ios': [str(REPO / 'tests/device/ios')], 'ios.self_tests': [str(REPO / 'tests/device/ios/self_tests')]}
    subject_names = ['test_c10_source_execution', 'ios.self_tests.retained_host_roots']
    if args.selection == 'transaction8':
        subject_names.append('test_c10d_defused_transaction')
    subjects = {name: dict(path=projects[name]['path'], sha256=projects[name]['sha256']) for name in subject_names}
    origin = dict(modules=projects, namespacePackages=namespaces, thirdPartyModules=third, thirdPartyNamespacePackages={},
        stdlibNamespacePackages=std_namespaces, stdlibRoots=[str(std)], pythonExecutable=dict(path=str(python), pin=physical[str(python)]), physicalPins=physical)
    plan = dict(status='PRIVATE_C10D_SOURCE_EXECUTION_UTILITY_UNRUN_UNQUALIFIED', repositoryRoot=str(REPO), controllerRoot=str(destination),
        actualPublicHead=args.expected_head, sourceFreeze=args.source_freeze, subjectSourceFreeze=SUBJECT_SHA,
        sourceAndBinaryPins=physical, modules=projects, namespaces=namespaces, thirdPartyModules=third, originPlan=origin,
        subjectOriginModules=subjects, subjectOriginCount=len(subjects), cases=cases, caseCount=selection['caseCount'], utilitySelection=args.selection,
        wallSeconds=30, killGraceSeconds=5, expectedTemporaryDirectories=selection['TDs'], expectedTemporaryDirectoriesPerCase=1,
        subjectOriginalPath=str(SUBJECT / 'closed_import_origins.py'), subjectActualCopiedPath=str(destination / 'closed_import_origins.py'), subjectHelperSha256=HELPER_SHA,
        NodeExecutions=0, SDKExecutions=0, realNetwork=False, overteNativeQueries=0, oldCorpusInputs=0, globalOriginalScans=0,
        helperQualified=False, consumerAdmissionClosed=True, actualHistoricalC10cProofIsNotC10dQualification=True,
        hostBootstrapScope='Original interpreter/stdlib and fresh private controller copies remain trusted; delegated Python executes independently pinned source bytes. This is new unqualified C10d utility scope.',
        nativeQualified=False, wholeQualified=False)
    output = destination / 'approved-inputs.json'
    descriptor = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    with os.fdopen(descriptor, 'w') as stream:
        json.dump(plan, stream, sort_keys=True, indent=2)
        stream.write('\n')
    assert all(pin(path) == row for path, row in physical.items()) and head() == args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN', input=str(output), inputSha256=pin(output)['sha256'], utilitySelection=args.selection, sourcePins=len(physical), cases=selection['caseCount'], targets=0, globalScans=0)))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
