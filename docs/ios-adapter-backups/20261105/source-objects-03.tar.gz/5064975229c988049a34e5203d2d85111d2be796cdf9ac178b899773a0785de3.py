"""Parent WAL for returned original Current7 bytes, never DTO admission.

A lost acquisition result remains visibly uncertain. Existing child/Source
owners retain all actual SDK/input authority; this class cannot reconstruct it.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import os,stat
from pathlib import Path
from adapters.native_feature_observation import exact,need,integer
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import identifier
from ios.adapters import lifecycle_current_transport as transport


class LifecycleCurrentStream:
    def __init__(self,store,root,source,run,role,lock,*,original_owner=None):
        need(type(source)is dict and isinstance(store,PrivateFeatureState)and isinstance(lock,ScriptSourceLock)and role in ('primary','actor'))
        self.store,self.root,self.source,self.run,self.role,self.lock=store,Path(root),source,identifier(run),role,lock
        self.receivers=tuple((name,getattr(transport,name),getattr(transport,name).__code__)for name in ('capture','returned_original','decoder_birth'))
        self.decoder_guard=transport.decoder_birth()
        self.binding=deepcopy(context(source['binding']));need(store.path.name=='ios-lifecycle-current-stream-'+role+'-'+run+'.json'
            and lock.path==store.path.parent/'script-feature-sources.lock'and self.root.is_absolute()and self.root.resolve()==self.root and self.root.is_dir())
        if original_owner is not None:identifier(original_owner)
        lock.assert_held();self.previous=store.read();self.state=dict(owner=original_owner,records=[],pending=None,storage={})if self.previous is None else deepcopy(self.previous['state'])
        need(original_owner is None or self.state['owner']==original_owner);self._owner=self.state['owner']
        self.files=OriginalFrameStore(self.root,self.binding,run,role,self.bound,self.intent,namespace='lifecycle-current-returned',schema_prefix='iosLifecycleCurrentReturned',kind='sources')
        self.bound()
        if self.previous is not None:need(same(self.previous,self.envelope()))
        self.structure()
        for reference in self.state['records']:self.record(reference)

    def envelope(self):return dict(iosLifecycleCurrentStreamVersion=1,binding=self.binding,runId=self.run,role=self.role,artifactRoot=str(self.root),state=deepcopy(self.state))

    def bound(self):
        self.lock.assert_held()
        for name,function,code in self.receivers:need(getattr(transport,name) is function and function.__code__ is code)
        self.decoder_guard()
        need(self.state['owner']==self._owner and self.source['binding']==self.binding
            and self.source['check']() is not False and same(self.store.read(),self.previous));return True

    def structure(self):
        exact(self.state,{'owner','records','pending','storage'});owner=self.state['owner']
        if owner is not None:identifier(owner)
        records=self.state['records'];need(type(records)is list and len(records)<=64 and type(self.state['storage'])is dict)
        need(owner is not None or not records)
        for index,reference in enumerate(records,1):
            self.files.expand(reference);need(reference['index']==index and str(index)in self.state['storage']
                and same(reference,self.files.compact(self.state['storage'][str(index)])))
        pending=self.state['pending']
        if pending is not None:
            exact(pending,{'index','ticket','expectedOwner','phase','returnedReference'});identifier(pending['ticket'])
            need(integer(pending['index'],1,64) and pending['index']==len(records)+1
                and (pending['expectedOwner']==owner or pending['expectedOwner']is None and not records and pending['index']==1)
                and pending['phase']in ('planned','returned'))
            reference=pending['returnedReference']
            if pending['phase']=='planned':need(reference is None)
            else:
                self.files.expand(reference);need(reference['index']==pending['index']and str(reference['index'])in self.state['storage']
                    and same(reference,self.files.compact(self.state['storage'][str(reference['index'])])))
        for key,value in self.state['storage'].items():
            need(type(key)is str and key.isdecimal()and key==str(int(key))and 1<=int(key)<=len(records)+(1 if pending is not None else 0));self.files.original(value);need(value['index']==int(key))
        self.inventory()

    def inventory(self):
        """An unrecorded parent file never becomes an invisible spare result.

        Opened partial files retain their original inode and responsibility;
        only saved records are decoded. No cleanup, completion or requery is
        attempted here, including after an unknown constructor return.
        """
        self.bound();expected={}
        for value in self.state['storage'].values():
            path=self.files.path(value)
            if value['phase']!='planned':expected[path.name]=value
        prefix=self.files.namespace+'-frame-'+self.files.kind+'-'+self.run+'-'+self.role+'-'
        actual={path.name:path for path in self.root.iterdir()if path.name.startswith(prefix)}
        need(set(actual)==set(expected))
        for name,path in actual.items():
            value=expected[name];info=path.lstat()
            need(stat.S_ISREG(info.st_mode)and info.st_nlink==1 and info.st_size<=value['bytes']
                and (os.name=='nt'or info.st_uid==os.geteuid()and stat.S_IMODE(info.st_mode)==0o600)
                and (info.st_dev,info.st_ino)==(value['file']['device'],value['file']['inode']))
            if value['phase']=='saved':need(info.st_size==value['bytes'])

    def save(self):
        self.bound();self.structure();value=self.envelope();self.store.write(value,self.previous);self.previous=deepcopy(value)

    def intent(self,kind,value):
        self.bound();need(kind=='original'and self.state['pending']is not None);self.files.original(value)
        pending=self.state['pending'];need(value['index']==pending['index']);key=str(value['index']);old=self.state['storage'].get(key)
        if old is None:need(value['phase']=='planned')
        else:need(all(same(old[k],value[k])for k in old if k not in ('phase','file'))and (old['phase'],value['phase'])in (('planned','opened'),('opened','saved'))and (old['file']is None or old['file']==value['file']))
        self.state['storage'][key]=deepcopy(value);self.save()

    def record(self,reference):
        self.bound();self.inventory();need(reference in self.state['records']);value=self.files.read(self.files.expand(reference));exact(value,{'ticket','returnedOriginal'})
        identifier(value['ticket']);original=value['returnedOriginal']
        facts=transport.returned_original(original,self.root,self.binding,self.run,self.role,value['ticket'],self.state['owner'])
        self.inventory();return dict(ticket=value['ticket'],original=original,current=deepcopy(original['originalBody']['frame']['current']),facts=facts)

    def capture(self,ticket):
        self.bound();identifier(ticket);need(self.state['pending']is None and len(self.state['records'])<64)
        self.state['pending']=dict(index=len(self.state['records'])+1,ticket=ticket,expectedOwner=self.state['owner'],phase='planned',returnedReference=None);self.save()
        # The actual remote constructor checks expected original owner BEFORE
        # any SDK/native query. An unknown return never authorizes a requery.
        returned=transport.capture(self.source,self.run,self.role,ticket,self.root,expected_owner=self.state['owner'])
        self.bound();owner=returned['ownerInstance'];need(self.state['owner']is None or owner==self.state['owner'])
        if self.state['owner']is None:self.state['owner']=self._owner=owner
        reference=self.files.write(self.state['pending']['index'],dict(ticket=ticket,returnedOriginal=returned))
        self.state['pending']['phase']='returned';self.state['pending']['returnedReference']=reference;self.save()
        self.state['records'].append(reference);self.state['pending']=None;self.save();return self.record(reference)

    def current(self,ticket):
        # The public API must call capture for each new observation. Selecting
        # a saved record here would turn history into a current fact.
        return self.capture(ticket)
