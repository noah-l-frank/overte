"""Actual utility Python Popen/stdio custody, never product process authority."""
import io,os,stat,subprocess,sys,threading
from types import FrameType

class PythonChildren:
    def __init__(self,python,python_pin,pin,save,here):
        self.callbacks=None;self.python=python;self.python_pin=python_pin;self.pin=pin;self.save=save;self.here=here;self.current_case=None;self.cls=None;self.creator=None;self.pending=None;self.rows=[]
        self.popen=subprocess.Popen;self.init=self.popen.__init__;self.execute=self.popen._execute_child
        self.init_code,self.init_globals=self.init.__code__,self.init.__globals__
        self.execute_code,self.execute_globals=self.execute.__code__,self.execute.__globals__
        self.posix=self.popen._posix_spawn;self.posix_code,self.posix_globals=self.posix.__code__,self.posix.__globals__
        self.pipe=os.pipe;self.pipe2=getattr(os,'pipe2',None)
        self.popen_helpers=tuple((name,getattr(self.popen,name),getattr(self.popen,name).__code__,getattr(self.popen,name).__globals__)for name in('_get_handles','_get_devnull','_close_pipe_fds'))
        self.original_io=io.open;self.pipe_constant=subprocess.PIPE;assert self.pipe_constant==-1
        self.fstat=os.fstat;self.original_fstat=os.fstat;self.close=os.close;self.main=threading.current_thread();self.monitor=None;self.tool=None
    def bind_callbacks(self,start,returned):
        assert self.callbacks is None
        self.callbacks=tuple((fn,fn.__code__,fn.__globals__)for fn in(start,returned))
        module=sys.modules['__main__']
        assert all(namespace is vars(module)and code.co_filename==str(self.here/'run-six.py')for fn,code,namespace in self.callbacks)
    def callback_frame(self,frame,index):
        actual=sys._getframe(2);fn,code,namespace=self.callbacks[index]
        assert type(frame)is FrameType and type(actual)is FrameType and actual.f_code is code and actual.f_globals is namespace and actual.f_back is frame
    def bind(self,module):
        assert self.cls is None
        self.module=module;self.cls=vars(module)['OriginalOwnedKernelTerminalTests'];self.creator=self.cls.__dict__['child']
        self.creator_code,self.creator_globals=self.creator.__code__,self.creator.__globals__
        self.command=vars(module)['CHILD_CODE'];assert type(self.command)is str
    def check(self):
        assert threading.current_thread()is self.main and os.fstat is self.original_fstat and os.pipe is self.pipe and getattr(os,'pipe2',None)is self.pipe2
        assert all(getattr(self.popen,name)is fn and fn.__code__ is code and fn.__globals__ is namespace is vars(subprocess)for name,fn,code,namespace in self.popen_helpers)
        assert os.close is self.close
        assert subprocess.Popen is self.popen and self.popen.__init__ is self.init and self.popen._execute_child is self.execute
        assert self.popen._posix_spawn is self.posix and self.posix.__code__ is self.posix_code and self.posix.__globals__ is self.posix_globals
        assert self.init_globals is vars(subprocess)and self.execute_globals is vars(subprocess)and self.posix_globals is vars(subprocess)
        assert subprocess.io is io and io.open is self.original_io and subprocess.os is os and subprocess.PIPE is self.pipe_constant
        assert self.init.__code__ is self.init_code and self.init.__globals__ is self.init_globals
        assert self.execute.__code__ is self.execute_code and self.execute.__globals__ is self.execute_globals
        if self.callbacks is not None:
            assert all(vars(sys.modules['__main__'])[fn.__name__]is fn and fn.__code__ is code and fn.__globals__ is namespace is vars(sys.modules['__main__'])for fn,code,namespace in self.callbacks)
        if self.cls is not None:
            assert self.module.OriginalOwnedKernelTerminalTests is self.cls and self.cls.__dict__['child']is self.creator
            assert self.creator.__code__ is self.creator_code and self.creator.__globals__ is self.creator_globals
            assert self.module.CHILD_CODE==self.command
    def begin(self,frame):
        self.check();self.callback_frame(frame,0);assert self.pending is None and self.cls is not None
        caller=frame.f_back;assert caller.f_code is self.creator_code and caller.f_globals is self.creator_globals and type(caller.f_locals['self'])is self.cls
        p=frame.f_locals['self'];assert type(p)is self.popen
        args=frame.f_locals;actual=caller.f_locals['actual'];copy_pin=None
        assert type(actual)is str
        if actual!=self.python:
            from pathlib import Path
            source=Path(actual);assert len(self.rows)==5 and self.current_case.id().endswith('test_live_deleted_owned_interpreter_executable_is_not_terminal_or_absent')
            assert caller.f_locals['executable']is not None and source==caller.f_locals['executable']
            test=caller.f_back;method=self.cls.__dict__['test_live_deleted_owned_interpreter_executable_is_not_terminal_or_absent']
            assert test.f_code is method.__code__ and test.f_globals is method.__globals__ is self.creator_globals and test.f_locals['self']is self.current_case
            assert source==test.f_locals['copied']and source.name=='original-python'and source.parent==test.f_locals['root']and source.parent.parent==self.here/'own-toys'
            assert source.resolve(strict=True)==source and stat.S_IMODE(source.lstat().st_mode)==0o700
            copy_pin=self.pin(source);assert copy_pin['sha256']==self.python_pin['sha256']and copy_pin['bytes']==self.python_pin['bytes']
        expected=[actual,'-S','-B','-c',self.command]
        assert args['bufsize']==0
        assert args['args']==expected and args['stdin']==args['stdout']==args['stderr']==subprocess.PIPE
        assert args['executable']is args['cwd']is args['env']is None and not args['shell']and not args['start_new_session']and args['close_fds']
        assert args['preexec_fn']is None and not args['pass_fds']and args['text']is None and args['encoding']is None and args['errors']is None
        assert args['startupinfo']is None and args['creationflags']==0 and args['restore_signals']is True and args['process_group']is None
        assert args['group']is args['extra_groups']is args['user']is None and args['umask']==-1 and args['pipesize']==-1
        assert len(self.rows)<6 and all(row['process'].poll()is not None for row in self.rows)
        self.pending=dict(process=p,frame=frame,creator=caller.f_locals['self'],argv=expected,pipes=None,spawned=False,posixSpawned=False,streams=None,birth=None,stat=None,copyPin=copy_pin)
    def open(self,args,frame):
        if type(args[0])is not int:return False
        self.check();row=self.pending
        if row is None or frame is not row['frame']or frame.f_code is not self.init_code or frame.f_globals is not self.init_globals:return False
        names=('p2cread','p2cwrite','c2pread','c2pwrite','errread','errwrite');local=frame.f_locals
        if row['pipes']is None:
            pipes={}
            for name in names:
                fd=local[name];s=self.fstat(fd);assert type(fd)is int and fd>=0 and stat.S_ISFIFO(s.st_mode)and s.st_uid==os.geteuid()
                pipes[name]=dict(fd=fd,device=s.st_dev,inode=s.st_ino,mode=s.st_mode)
            assert len({v['fd']for v in pipes.values()})==6
            pairs=(('p2cread','p2cwrite'),('c2pread','c2pwrite'),('errread','errwrite'))
            assert all((pipes[a]['device'],pipes[a]['inode'])==(pipes[b]['device'],pipes[b]['inode'])for a,b in pairs)
            assert len({(pipes[a]['device'],pipes[a]['inode'])for a,b in pairs})==3
            row['pipes']=pipes
        expected={'p2cwrite':('w','wb'),'c2pread':('r','rb'),'errread':('r','rb')}
        matches=[name for name in expected if args[0]==local[name]];assert len(matches)==1
        name=matches[0];s=self.fstat(args[0]);saved=row['pipes'][name]
        assert (s.st_dev,s.st_ino,s.st_mode)==(saved['device'],saved['inode'],saved['mode'])and args[1]in expected[name]
        return True
    def spawn(self,args,frame):
        self.check();row=self.pending;assert row is not None and row['pipes']is not None and not row['spawned']
        assert type(frame)is FrameType and frame.f_code is self.execute_code and frame.f_globals is self.execute_globals and frame.f_locals['self']is row['process']and frame.f_back is row['frame']
        assert args==(row['argv'][0],row['argv'],None,None);row['spawned']=True
    def posix_spawn(self,args,frame):
        self.check();row=self.pending;assert row is not None and row['spawned']and not row['posixSpawned']
        assert frame.f_code is self.posix_code and frame.f_globals is self.posix_globals and frame.f_locals['self']is row['process']
        caller=frame.f_back;assert caller.f_code is self.execute_code and caller.f_globals is self.execute_globals and caller.f_locals['self']is row['process']
        assert args==(row['argv'][0],row['argv'],None)
        local=frame.f_locals;assert local['close_fds']is local['restore_signals']is True
        expected=[(os.POSIX_SPAWN_CLOSE,row['pipes'][n]['fd'])for n in('p2cwrite','c2pread','errread')]
        expected.extend((os.POSIX_SPAWN_DUP2,row['pipes'][n]['fd'],dest)for n,dest in(('p2cread',0),('c2pwrite',1),('errwrite',2)))
        expected.append((os.POSIX_SPAWN_CLOSEFROM,3));assert local['kwargs']['file_actions']==expected
        assert set(local['kwargs'])=={'file_actions','setsigdef'}
        row['posixSpawned']=True
    def returned(self,frame):
        self.check();self.callback_frame(frame,1);row=self.pending;assert row is not None and frame is row['frame']and row['spawned']
        p=row['process'];assert type(p.pid)is int and p.pid>0 and p._child_created is True
        kernel=sys.modules['kernel'];actual=kernel.observe(p.pid,parent=os.getpid(),group=os.getpgrp());assert actual['kind']=='PRESENT_LIVE';bound=actual['after']['identity'];birth={name:bound[name]for name in('pid','parent','group','startTicks')}|dict(executable=actual['executable'])
        assert birth is not None and bound is not None and all(birth[k]==bound[k]for k in('pid','parent','group','startTicks'))
        assert birth['executable']==row['argv'][0]
        streams=[]
        for name,pipe in (('stdin','p2cwrite'),('stdout','c2pread'),('stderr','errread')):
            stream=getattr(p,name);assert not stream.closed and stream.fileno()==row['pipes'][pipe]['fd']
            s=self.fstat(stream.fileno());v=row['pipes'][pipe];assert(s.st_dev,s.st_ino,s.st_mode)==(v['device'],v['inode'],v['mode'])
            streams.append((name,stream))
        row.update(birth=birth,stat=bound,streams=streams);self.rows.append(row);self.pending=None
        self.save('actual-python-birth-'+str(len(self.rows))+'.json',dict(identity=bound,actualCommand=row['argv'],actualExecutable=birth['executable'],caseId=self.current_case.id(),copiedInterpreterOriginal=row['copyPin'],sixPipeEndpoints=row['pipes']))
    def finish_case(self,expected):
        self.check();assert self.pending is None
        rows=self.rows[self.case_start:];assert len(rows)==expected
        result=[];kernel=sys.modules['kernel']
        for row in rows:
            p=row['process'];assert p.poll()==0 and kernel.absent(p.pid)
            assert all(stream.closed for name,stream in row['streams'])
            states=[]
            for name,pipe in row['pipes'].items():
                try:s=self.fstat(pipe['fd'])
                except OSError as error:
                    import errno
                    assert error.errno==errno.EBADF;state='EBADF';same=False
                else:state='actual-reused-descriptor';same=(s.st_dev,s.st_ino,s.st_mode)==(pipe['device'],pipe['inode'],pipe['mode'])
                assert not same;states.append(dict(name=name,original=pipe,state=state,sameOriginalStillLive=same))
            result.append(dict(argv=row['argv'],actualNestedOriginalPosixSpawn=row['posixSpawned'],birth=row['birth'],actualStat=row['stat'],returnCode=p.returncode,caseId=self.current_case.id(),copiedInterpreterOriginal=row['copyPin'],allThreeParentStreamsClosed=True,pipes=states,actualKernelAbsent=True))
        return result

    def rescue_partial(self):
        """Drain actual creator-held objects after failure; never a green case.

        No signal or missing-exe bypass: original stdin EOF/owned pipe closure
        makes this exact finite child terminate, then original wait reaps it.
        """
        self.check();rescued=[]
        candidates=list(self.rows)
        if self.pending is not None and not any(row is self.pending for row in candidates):candidates.append(self.pending)
        for row in candidates:
            child=row['process']
            incomplete=row is self.pending
            if not incomplete and child.poll()is not None:continue
            closed=[];problems=[]
            for name in('stdin','stdout','stderr'):
                stream=getattr(child,name,None)
                if stream is not None and not stream.closed:
                    try:stream.close()
                    except BaseException as error:problems.append(dict(port=name,error=type(error).__qualname__))
            for name,observed in(row['pipes']or{}).items():
                try:current=self.fstat(observed['fd'])
                except OSError as error:
                    import errno
                    if error.errno!=errno.EBADF:problems.append(dict(port=name,error=repr(error)))
                else:
                    if(current.st_dev,current.st_ino,current.st_mode)==(observed['device'],observed['inode'],observed['mode']):
                        self.close(observed['fd']);closed.append(name)
            code=None
            if getattr(child,'pid',None)is not None and child._child_created:
                try:code=child.wait(timeout=5)
                except BaseException as error:problems.append(dict(port='original-wait',error=repr(error)))
            rescued.append(dict(actualPID=getattr(child,'pid',None),originalConstructorPartial=incomplete,originalPipeEndsClosed=closed,returnCode=code,problems=problems,qualification=False))
        return rescued
