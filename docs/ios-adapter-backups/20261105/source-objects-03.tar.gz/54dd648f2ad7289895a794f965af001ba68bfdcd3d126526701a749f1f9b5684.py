import ast,hashlib,json,stat
from pathlib import Path
R=Path.cwd();P=R/'.ios-host-tmp/emote-callback-live-prefix-scoped22-tail5-root-preparation-20261103';PRIOR=R/'.ios-host-tmp/emote-callback-live-prefix-scoped19-tail8-terminal-order-root-preparation-20261103';BASE=PRIOR/'tail8';SOURCE=R/'.ios-host-tmp/emote-callback-live-prefix-json-pixel-result-test-only-fix-20261103';T=P/'tail5';assert not(P/'freeze.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.open('x').write(s)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in F])
 if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
 assert v['stat']==[getattr(p.lstat(),k) for k in F];return v
oldplan=json.loads((BASE/'run-plan.json').read_text());ids=oldplan['cases'];assert len(ids)==8
report=json.loads((BASE/'root-run-first/report.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==9 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
assert (BASE/'terminal-census-1.json').exists() and (BASE/'terminal-census-2.json').exists()
frozen=set(json.loads((BASE/'freeze.json').read_text())['files'])|{'freeze.json'};newpins={str(p):pin(p) for p in sorted(BASE.rglob('*')) if str(p.relative_to(BASE)) not in frozen};newpins[str(PRIOR/'root-scoped19-report.json')]=pin(PRIOR/'root-scoped19-report.json');save(P/'actual-history-current-pins.json',newpins)
prior=json.loads((BASE/'prior-retained-original-pins.json').read_text());prior.update(newpins)
rows=json.loads((SOURCE/'plan.json').read_text())['sourceRows'];rel='tests/device/ios/self_tests/test_ios_emote_callback_live_history_cache.py';tr=next(r for r in rows if r['path']==rel);prefix=json.loads((PRIOR/'scope-plan.json').read_text())['unchangedPrefix']
save(P/'scope-plan.json',dict(priorMaster=str(PRIOR),oldStage=str(BASE),unchangedPrefix=prefix+ids[:3],newScopedCases=ids[:3],failedCase=ids[3],tail=ids[3:],oldTestFile=str(SOURCE/'base'/rel),newTestFile=str(SOURCE/'candidate'/rel),testPath=rel,oldTestSha256=tr['baseSHA256'],newTestSha256=tr['candidateSHA256'],changedMethods=json.loads((SOURCE/'plan.json').read_text())['changedMethods'],helperPath='tests/device/ios/adapters/emote_callback_live_records.py',helperSha256='4fea6757d1a6903dce66ecfd5d94e6f13138b9dbbdaa2cce78a105fcf7db7994'))
write(P/'prior_scoped_prerequisite.py',(PRIOR/'scoped_prerequisite.py').read_text())
helper='''"""Actual historical22 +same-helper smoke; no successful prefix replay."""
import ast,hashlib,json,stat
from pathlib import Path
from prior_scoped_prerequisite import historical as prior_historical,allpins as prior_allpins,delta,cleanup,exited
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def allpins(master):
 pins=json.loads((master/'actual-history-current-pins.json').read_text())
 for name,expected in pins.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();v=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
  assert v==expected and v['stat']==[getattr(p.lstat(),k) for k in F]
 return [Path(name) for name in pins]
def historical(master,repo):
 plan=json.loads((master/'scope-plan.json').read_text());prior=Path(plan['priorMaster']);a,paths=prior_historical(prior,repo)
 assert json.loads((prior/'root-scoped19-report.json').read_text())==a;paths+=[prior/'root-scoped19-report.json'];paths+=allpins(master);paths+=delta(plan,repo)
 stage=Path(plan['oldStage']);out=stage/'root-run-first';r=json.loads((out/'report.json').read_text());assert r['exitCode']==1 and r['retainedFiles']==9 and all(r[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not r['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=1,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 a=json.loads((stage/'terminal-census-1.json').read_text());b=json.loads((stage/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 selected=json.loads((stage/'selected-result.json').read_text());assert selected['selectedIds']==plan['newScopedCases']+plan['tail'] and selected['testsRun']==4 and not selected['successful'] and selected['errorCount']==1 and selected['failureCount']==selected['skippedCount']==0
 lines=(out/'first.log').read_text().splitlines();outcomes=[]
 for i,case in enumerate(plan['newScopedCases']+[plan['failedCase']],1):
  expected=case.rsplit('.',1)[1]+' ('+case+') ... '+('ERROR' if case==plan['failedCase'] else 'ok');assert lines.count(expected)==1;outcomes.append(expected);cleanup(stage,i,case)
 assert len(plan['unchangedPrefix'])==22 and plan['unchangedPrefix']==json.loads((prior/'scope-plan.json').read_text())['unchangedPrefix']+plan['newScopedCases']
 prior_allpins(prior);allpins(master)
 return dict(status='ACTUAL_HISTORICAL_SCOPED22_PASS',scopedCases=plan['unchangedPrefix'],priorScoped19Preserved=True,oldAggregate27Passed=False,oldAggregate27TerminalPresent=False,tail8AggregatePassed=False,tail8AggregateTerminalPresent=True,tail8ActualPerCaseCensuses=4,tail8OriginalFiles=9,actualTailOutcomeLines=outcomes,currentRawPinsExact=True,originalProcessAbsent=True,helperSha256=plan['helperSha256'],unchangedPrefixTestAST=True),paths

def require(here,repo,current=None):
 master=here.parent;plan=json.loads((master/'scope-plan.json').read_text());actual,paths=historical(master,repo)
 assert json.loads((master/'root-scoped22-report.json').read_text())==actual;paths.append(master/'root-scoped22-report.json')
 assert sha(repo/plan['testPath'])==plan['newTestSha256']
 prior=Path(plan['priorMaster']);pplan=json.loads((prior/'scope-plan.json').read_text());smoke=Path(pplan['smokeStage']);out=smoke/'root-run-first';r=json.loads((out/'report.json').read_text())
 assert r['exitCode']==0 and r['retainedFiles']==0 and all(r[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not r['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 ids=json.loads((smoke/'run-plan.json').read_text())['cases'];a=json.loads((smoke/'selected-result.json').read_text());assert len(ids)==1 and a['selectedIds']==ids and a['successful'] and a['testsRun']==1 and not any(a[k] for k in ('failureCount','errorCount','skippedCount'));cleanup(smoke,1,ids[0])
 old=json.loads((out/'root-source-map.json').read_text());assert old['repositoryRoot']==str(repo) and old['currentSourcePins'][plan['testPath']]==pplan['oldTestSha256']
 adjusted=dict(old['currentSourcePins']);adjusted[plan['testPath']]=plan['newTestSha256']
 if current is not None:assert current['currentSourcePins']==adjusted
 for name,digest in adjusted.items():
  p=repo/name;assert p.is_relative_to(repo) and p.resolve(strict=True)==p and sha(p)==digest
 prior_allpins(prior);allpins(master)
 return paths+[master/'scope-plan.json',master/'actual-history-current-pins.json',master/'prior_scoped_prerequisite.py']
'''
write(P/'scoped_prerequisite.py',helper)
write(P/'scope-first22.py',"import json,os,sys\nfrom pathlib import Path\nfrom scoped_prerequisite import historical\nHERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]\nassert sys.dont_write_bytecode and Path.cwd()==REPO\nreport,_=historical(HERE,REPO)\np=HERE/'root-scoped22-report.json';fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)\nwith os.fdopen(fd,'w') as f:json.dump(report,f,indent=2);f.write('\\n')\nprint(json.dumps(report))\n")
T.mkdir()
for name,digest in json.loads((BASE/'freeze.json').read_text())['files'].items():
 assert sha(BASE/name)==digest
 if name.endswith('.py') or name=='sdk-original-pins.json':write(T/name,(BASE/name).read_text())
(T/'scoped_prerequisite.py').write_text(helper);write(T/'prior_scoped_prerequisite.py',(PRIOR/'scoped_prerequisite.py').read_text())
plan=dict(oldplan,status='PRIVATE_UNRUN_TAIL5_ONLY_AFTER_ACTUAL_SCOPED22',cases=ids[3:],caseCount=5,totalCaseCount=5,expectedRetainedRoots=5,privateFiles={f.name:sha(f) for f in T.glob('*.py')});save(T/'run-plan.json',plan);save(T/'prior-retained-original-pins.json',prior)
manifest=json.loads((BASE/'source-manifest.json').read_text());manifest.update(name='tail5',stage='emote-tail5',caseCount=5,pythonCaseCount=5,status=plan['status'])
manifest['sourcePaths']=[dict(path=r['path'],candidate=str(SOURCE/'candidate'/r['path']),candidateSHA256=r['candidateSHA256'],observedPublicSHA256=sha(R/r['path']),changesCurrentPublic=r['baseSHA256']!=r['candidateSHA256']) for r in rows];manifest['orderedParentFreezes'][str(SOURCE.relative_to(R/'.ios-host-tmp'))]=sha(SOURCE/'freeze.json');save(T/'source-manifest.json',manifest);save(T/'supervisor-plan.json',json.loads((BASE/'supervisor-plan.json').read_text()))
# Same original aggregate-before-strict-root-count order, SDK audit/caps untouched.
parent=(T/'root-supervise.py').read_text().replace("('scope-plan.json','actual-history-current-pins.json','scoped_prerequisite.py','scope-first19.py')","('scope-plan.json','actual-history-current-pins.json','scoped_prerequisite.py','prior_scoped_prerequisite.py','scope-first22.py')");(T/'root-supervise.py').write_text(parent)
plan['privateFiles']={f.name:sha(f) for f in T.glob('*.py')};(T/'run-plan.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
save(T/'master-guard-pins.json',{n:sha(P/n) for n in ('scope-plan.json','actual-history-current-pins.json','scoped_prerequisite.py','prior_scoped_prerequisite.py','scope-first22.py')})
for f in P.rglob('*.py'):ast.parse(f.read_text())
save(T/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={f.name:sha(f) for f in T.iterdir() if f.is_file() and f.name!='freeze.json'}))
write(P/'ROOT-PLAN.txt','Root metadata scope-first22.py first, preserving original27FAIL/missing aggregate and tail8FAIL9files/present aggregate. Exact19+3 observedPASS, all20+4 real percase cleanup/twocensuses, native/helper unchanged. Publish TESTONLY f4ed frome974 (2PNGmethods returnhex), then tail5/root-supervise.py original30+kill5/5TD. No22 orsmoke replay. Hardgate actualRootscoped22+actualsamehelpersmoke27 via exact two reviewed test-only ASTdeltas; current publicmap onlytestdelta. Freshgraph remainsHARDHOLD untilactualtail5PASS closesdistinct27 cases.\n')
save(P/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceFreeze=sha(SOURCE/'freeze.json'),unchangedPrefix=prefix+ids[:3],tail=ids[3:],first22NotRerun=True,smokeNotRerun=True,old27AggregateFailed=True,old27AggregateTerminalMissing=True,tail8AggregateFailed=True,tail8AggregateTerminalPresent=True,initialSeconds=30,killAfterSeconds=5,expectedRoots=5,targetImports=False,testsRun=False))
save(P/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(f.relative_to(P)):sha(f) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='freeze.json'},stageFreeze=sha(T/'freeze.json')))
print(json.dumps(dict(freeze=sha(P/'freeze.json'),stageFreeze=sha(T/'freeze.json'),sourceFreeze=sha(SOURCE/'freeze.json'),pins=len(newpins))))
