from pathlib import Path
import ast,difflib,hashlib,json,shutil
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-resource-scoped-forward-draft-20261029';FIX=T/'lifecycle-original-owner-scoped-cleanup-prepare-copy-import-overlay-20261029';P=T/'lifecycle-original-owner-resource-scoped-forward-prepare-import-composition-20261029';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for pack in (B,FIX):
 for n,d in json.loads((pack/'freeze.json').read_text())['files'].items():assert H(pack/n)==d
P.mkdir(mode=0o700)
for n,d in json.loads((B/'freeze.json').read_text())['files'].items():
 dest=P/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/n,dest)
rel='tests/device/ios/pymobiledevice3_wda_xctest.py';base=P/'bases/repo'/rel;shutil.copyfile(FIX/'candidate/repo'/rel,base)
out=P/'candidate/repo'/rel;s=out.read_text();old="        if operation=='touch-motion-prepare':\n";assert s.count(old)==1;s=s.replace(old,old+'            from copy import deepcopy\n',1);out.write_text(s);ast.parse(s)
manifest=json.loads((P/'manifest.json').read_text());rows=[]
for row in manifest['files']:
 r=row['path'];row.update(base=str(P/'bases/repo'/r),baseSHA256=H(P/'bases/repo'/r),candidate=str(P/'candidate/repo'/r),candidateSHA256=H(P/'candidate/repo'/r));rows.append(row)
manifest.update(status='PRIVATE_FROZEN_SOURCE2_MODEL7_UNRUN_COMPOSED_PREPARE_IMPORT',orderedDependencies=[dict(path=str(FIX),freezeSHA256=H(FIX/'freeze.json')),dict(path=str(B),freezeSHA256=H(B/'freeze.json'))]);(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(P/'source2.diff').write_text(''.join(''.join(difflib.unified_diff(Path(row['base']).read_text().splitlines(True),Path(row['candidate']).read_text().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path'])) for row in rows))
(P/'composition.json').write_text(json.dumps(dict(originalBegin2Freeze=H(B/'freeze.json'),importFixFreeze=H(FIX/'freeze.json'),onlyCandidateChange='same local Prepare deepcopy import',originalModel7Unchanged=True,imports=False,testsRun=False,publicEdits=False),indent=2)+'\n')
(P/'README-composed-import.txt').write_text('Root-reviewed local Prepare deepcopy import composed prospectively with optional Begin2. Source delta now againstc6f017/d7bcb;7models unchanged. OriginalBegin2freeze and Root55FAIL preserved. Root56 candidate still independent and untouched.60+5/Node15/8TD prospective. No native/SDK/canonical/whole flag.\n')
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2)+'\n');print(json.dumps(dict(path=str(P),freeze=H(P/'freeze.json'),diff=H(P/'source2.diff'),files=rows),indent=2))
