"""Root-only source metadata, ten separate unchanged one-case utility groups."""
from pathlib import Path
import argparse,ast,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
from project_namespace_admission import project_namespace_admission
SOURCE=Path(__file__).resolve().parent
HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
EXECUTORS=('run-one.py','supervise-one.py','prepare.py','metadata_reader.py','host_common.py','closed_import_origins.py','source_execution_readiness.py','owned_write_boundary.py','class_cleanup_custody.py','definition_custody.py','project_namespace_admission.py','audio_resources.py','async_selfpipe_custody.py','readonly-shared-stdlib-sources.json','third-party-source-declarations.json','fixed-ten-onecase-groups.json','definition-inventory.json','PROJECT-DEFINING-ORIGINS.json','ACTUAL-FINAL-STAGE6-COMPOSITION.json')
def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','expected-head','destination','group','peer-freeze','peer-sha'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--root-reviewed-audio-eight-plus-two-host-only',required=True,action='store_true')
    args=parser.parse_args();assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and head()==args.expected_head
    groups=json.loads((SOURCE/'fixed-ten-onecase-groups.json').read_text())['groups'];assert args.group in groups;recipe=groups[args.group]
    assert len(recipe['caseIds'])==1 and recipe['wallSeconds']==30 and recipe['killGraceSeconds']==5
    physical={}
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path;row=pin(path)
        if digest is not None:assert row['sha256']==digest
        previous=physical.setdefault(str(path),row);assert previous==row;return row
    def frozen(path,digest):
        path=Path(path);keep(path,digest);body=json.loads(path.read_text())
        for name,row in body['files'].items():
            assert not Path(name).is_absolute()and '..'not in Path(name).parts;keep(path.parent/name,row if type(row)is str else row['sha256'])
        return body
    frozen(SOURCE/'source-freeze.json',args.source_freeze)
    frozen(REPO/'.ios-host-tmp/audio-source10-eight-reply-two-config-ten-closed-host-bootstrap1-code-preparation-20261105/source-freeze.json','5a4bab966f7a154a38d83532816b558d1ac8b3425562226ae340339c0a04b40c')
    frozen(REPO/'.ios-host-tmp/root-stdlib-afunix-socketpair-original-audit-caller-probe-source1-20261105/source-freeze.json','c07fce66d565208c83f3dab95b59ae4d4ad60bdb714fd39825ad07fff582dbdc')
    peer=Path(args.peer_freeze);assert peer.is_absolute()and peer.is_relative_to(REPO/'.ios-host-tmp');frozen(peer,args.peer_sha)
    for path,row in json.loads((SOURCE/'SOURCE-REFERENCES.json').read_text()).items():assert path==row['path'];keep(path,row['sha256'])
    composition=json.loads((SOURCE/'ACTUAL-FINAL-STAGE6-COMPOSITION.json').read_text());frozen(Path(composition['sourceFreeze']['path']),composition['sourceFreeze']['sha256'])
    stage_manifest=json.loads(Path(composition['manifest']['path']).read_text());assert len(stage_manifest['rows'])==242
    for row in stage_manifest['rows']:keep(row['path'],row['sha256'])
    current,current_pins=qualification(pin);physical.update(current_pins);keep(SOURCE/'closed_import_origins.py',HELPER)
    declared={};definitions=json.loads((SOURCE/'definition-inventory.json').read_text());closure=json.loads((SOURCE/'PROJECT-DEFINING-ORIGINS.json').read_text())
    assert set(definitions)==set(closure['modules'])and len(definitions)==476
    from definition_custody import inventory
    for name,row in closure['modules'].items():
        actual=keep(row['path'],row['sha256']);assert definitions[name]['path']==row['path']and definitions[name]['sha256']==actual['sha256']
        assert inventory(row['path'])==definitions[name]['inventory'];declared[name]=dict(path=row['path'],sha256=actual['sha256'],package=row['package'])
    assert not set(declared)&{'module_support','modules.feature_journey','overte_session'}
    third={}
    for name,row in json.loads((SOURCE/'third-party-source-declarations.json').read_text()).items():
        assert name=='PIL'or name.startswith('PIL.')or name=='defusedxml'or name.startswith('defusedxml.')
        keep(row['path'],row['sha256']);third[name]=dict(path=row['path'],sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    assert len(third)==39
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14');stdns={};suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    for stdlib_dir,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(stdlib_dir);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink());relative=folder.relative_to(std)
        if relative.parts and all(n.isidentifier()for n in relative.parts)and not(folder/'__init__.py').is_file():stdns['.'.join(relative.parts)]=[str(folder)]
        for name in names:
            p=folder/name
            if p.suffix=='.py'or str(p).endswith(suffixes):keep(p)
    python=Path(sys.executable).resolve(strict=True);python_pin=keep(python)
    # No current public dirty-copy/old documentation qualification is borrowed.
    # Every actually selected current public source is pinned above with its real bytes.
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'and not dest.exists()
    assert dest.name.startswith('audio-reply-'+args.group+'-prepared-')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    dest.mkdir(mode=0o700)
    for name in EXECUTORS:
        target=dest/name;fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        row=keep(target)
        if name.endswith('.py')and name not in('run-one.py','supervise-one.py','prepare.py'):
            assert target.stem not in declared;declared[target.stem]=dict(path=str(target),sha256=row['sha256'],package=False)
    control_definitions={}
    for name in('definition_custody','class_cleanup_custody','project_namespace_admission','audio_resources','async_selfpipe_custody'):
        path=dest/(name+'.py');control_definitions[name]=dict(path=str(path),sha256=physical[str(path)]['sha256'],inventory=inventory(SOURCE/(name+'.py')))
    full_definitions={**definitions,**control_definitions}
    modules,namespaces,data=project_namespace_admission(declared,[str(REPO/'tests/device')])
    assert(modules,namespaces,data)==project_namespace_admission(declared,[str(REPO/'tests/device')])
    assert set(definitions)<=set(modules)
    plan=dict(status='PRIVATE_AUDIO_REPLY10_ONECASE_UNRUN',controllerRoot=str(dest),repositoryRoot=str(REPO),actualPublicHead=args.expected_head,
      sourceFreeze=args.source_freeze,peerFreeze=dict(path=str(peer),sha256=args.peer_sha),stage6Composition=composition,
      groupName=args.group,cases=recipe['caseIds'],resourceRecipe=recipe,wallSeconds=30,killGraceSeconds=5,
      currentSourceExecution=current,subjectHelperSha256=HELPER,subjectActualCopiedPath=str(dest/'closed_import_origins.py'),
      sourceAndBinaryPins=physical,modules=modules,namespaces=namespaces,declaredProjectAliases=declared,projectAliasAdmission=data,thirdPartyModules=third,
      subjectOriginModules=definitions,definitionInventory=full_definitions,hostControlDefinitions=control_definitions,subjectOriginCount=len(definitions),
      NodeExecutions=0,SDKExecutions=0,overteNativeQueries=0,oldApplicationCorpusInputs=0,globalOriginalScans=0,realNetwork=False,
      expectedClassCleanupGroups=1,classCleanupObservationVersion=1,pythonExecutable=dict(path=str(python),pin=python_pin),
      trustedHostBootstrap='Initial actual interpreter/stdlib and explicit control source modules held HOSTBOOTSTRAP; actual project delegates compile fresh via69093. No cached project bytecode or installed SDK authority.',
      phaseAdmission=None,aggregateEndAdmission=None,nativeCompiled=False,nativeQualified=False,wholeQualified=False)
    plan['originPlan']=dict(modules=modules,namespacePackages=namespaces,projectAliasAdmission=data,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=stdns,stdlibRoots=[str(std)],pythonExecutable=plan['pythonExecutable'],physicalPins=physical)
    output=dest/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),sha256=pin(output)['sha256'],group=args.group,cases=recipe['caseIds'],targetStarts=0,censuses=0)))
if __name__=='__main__':main()
