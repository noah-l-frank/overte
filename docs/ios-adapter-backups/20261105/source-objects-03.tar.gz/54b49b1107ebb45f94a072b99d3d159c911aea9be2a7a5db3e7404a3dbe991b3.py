"""Actual16 Primary inputs/Actor originals; image/End qualification separate.

These prospective host models never claim full common journey acceptance:
required Lifecycle moving PNG/Vulkan originals and shared terminal/End must
also be composed and qualified by Root. Native/Qt/physical SDK are MODELS.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio
from copy import deepcopy
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from feature_journeys.contract import VERSION,context,expand
from feature_journeys.engine import matches
from feature_journeys.scenarios import SCENARIOS
from ios.adapters.lifecycle_original_up import OriginalLifecycleUp,birth_path
from ios.adapters.normal_input import NativeInput
from lifecycle_whole_fresh_fixture import FreshWholeFixture


class LifecycleWholeSixteenOriginalModels(FreshWholeFixture):
    def call(self,index):
        step=expand(SCENARIOS['lifecycle-input']['steps'][index],context(self.run))
        ticket=self.activate(step['verb'],step['inputs'])
        return dict(contractVersion=VERSION,runId=self.run,ticket=ticket,verb=step['verb'],inputs=step['inputs'],
            fixtureUrl=self.fixture_url+'/runs/'+self.run+'/'),step

    async def stage(self,index):
        call,step=self.call(index);self.assertEqual(dict(performed=True),await self.primary_api('act',call))
        primary=await self.primary_api();actor=await self.actor_api()
        self.assertTrue(matches(primary['state'],step['state']),(index,primary['state'],step['state']))
        self.assertTrue(matches(actor['state'],step['state']),(index,actor['state'],step['state']))
        entries=self.phase_server.journal.snapshot(self.run)['entries'];self.assertEqual(call['ticket'],entries[-1]['ticket'])
        return primary,actor

    async def test_actual_sixteen_primary_actions_and_independent_actor_originals_match_every_closed_state(self):
        first=await self.primary_api();actor=await self.actor_api()
        baseline=SCENARIOS['lifecycle-input']['baseline'];self.assertTrue(matches(first['state'],baseline));self.assertTrue(matches(actor['state'],baseline))
        values=[]
        for index in range(16):values.append(await self.stage(index))
        self.assertEqual(16,len(self.primary_actions.state['events']))
        self.assertTrue(all(event['phase']=='returned'for event in self.primary_actions.state['events']))
        self.assertEqual(['mobile: backgroundApp','mobile: activateApp'],self.os_inputs)
        self.assertEqual(4,len(self.primary_history.state['aliases']));self.assertEqual(4,len(self.observer.history.state['aliases']))
        self.assertEqual(self.primary_history.state['aliases'][-1]['identity'],self.observer.history.state['aliases'][-1]['identity'])
        self.assertNotEqual(self.primary_history.state['records'],self.observer.history.state['records'])
        self.assertEqual(['hold','attempt','release'],[row['command']['operation']for row in self.pending_rows])
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertFalse(self.source._closing)
        self.assertTrue(all(not value['artifacts']for pair in values for value in pair))
        # Absence of images is explicit: this state/input composition cannot
        # satisfy common changed/image requirements or terminal/end by itself.
        self.assertEqual(1,self.address.inputs.count('PhoneAddressGoButton'))

    async def test_lost_delivered_type_result_uses_actual_retained_input_without_a_second_native_edit(self):
        await self.primary_api();await self.actor_api();await self.stage(0)
        call,step=self.call(1);deliver=NativeInput.deliver;lost=[]
        def drop(native,command):
            result=deliver(native,command)
            if command.get('operation')=='replace'and not lost:
                lost.append(deepcopy(command));raise OSError('Declared loss AFTER actual ordinary type delivered')
            return result
        with patch.object(NativeInput,'deliver',new=drop),self.assertRaises((NativeUIError,OSError)):await self.primary_api('act',call)
        count=len(self.normal.d.commands);effects=self.normal.d.effect_count
        self.assertEqual(dict(performed=True),await self.primary_api('act',call))
        self.assertEqual(count,len(self.normal.d.commands));self.assertEqual(effects,self.normal.d.effect_count)
        primary=await self.primary_api();actor=await self.actor_api()
        self.assertTrue(matches(primary['state'],step['state']));self.assertTrue(matches(actor['state'],step['state']))
        self.assertEqual(1,len(lost))

    async def test_original_up_remains_callable_after_current_source_admission_code_changes(self):
        await self.primary_api();await self.actor_api()
        for index in range(14):await self.stage(index)
        self.assertEqual([0xC2,0xC2],self.f.states());worker=self.ops.touch.worker;before=len(self.current_queries)
        function=self.source.current.__func__;code=function.__code__
        function.__code__=code.replace(co_consts=(*code.co_consts,'explicit-invalid-new-current-source'))
        try:
            root=self.runtime.adapter.state_path('test-only').parent
            def release():return asyncio.run(OriginalLifecycleUp(birth_path(root,self.run),self.run).release())
            result=await asyncio.to_thread(release)
            self.assertTrue(result['ordinaryUpSendReturned']);self.assertTrue(worker.done())
            self.assertFalse(self.source._closing);self.assertEqual([0xC2,0xC2,0x02],self.f.states())
            self.assertEqual(before,len(self.current_queries))
        finally:function.__code__=code
