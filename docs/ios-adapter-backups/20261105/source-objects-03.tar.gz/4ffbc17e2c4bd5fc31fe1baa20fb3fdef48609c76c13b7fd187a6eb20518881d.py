"""Real readonly Callback metadata constructors, never live SDK owners."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState,context
from feature_journeys.contract import identifier
from feature_journeys.phase_fixture import validate as phase_packet
from ios.adapters.emote_callback_samples import IOSEmoteCallbackSamples
from ios.adapters.emote_callback_retirement import IOSEmoteCallbackRetirementObserver
from ios.adapters import emote_callback_drain_originals as drains


class CallbackPhaseArchive:
    def __init__(self,fixture_url,packet,*,run,instance):
        need(type(fixture_url) is str and fixture_url.endswith('/runs/'+identifier(run)+'/'))
        phase_packet(packet,run=run,area='emotes',request=packet['requestId'],epoch=packet['capturedEpochMs'])
        need(packet['instance']==identifier(instance));self.fixture_url=fixture_url;self.previous=deepcopy(packet)


class CallbackSampleArchive(IOSEmoteCallbackSamples):
    """Owns decoded historical values; no Runtime, capture or native port."""
    def __init__(self,value,*,store,root,binding,run,role,lock,policy):
        need(isinstance(store,PrivateFeatureState) and role in ('primary','actor'));lock.assert_held()
        self.store,self.root,self.binding,self.run,self.role=store,Path(root),deepcopy(context(binding)),identifier(run),role
        self.lock,self.policy=lock,deepcopy(policy)
        need(self.root.is_absolute() and self.root.resolve()==self.root and self.root.is_dir()
            and store.path==lock.path.with_name('ios-emote-'+role+'-samples.json'))
        self.state=self.decode(value);need(self.state['phase']=='ready' and self.state['rows'])
        expected={self.sample_store(row).path for row in self.state['rows']}
        need(set(self.root.glob('emote-sample-'+run+'-'+role+'-*.json'))==expected)
    def bound(self):need(False)
    def save(self):need(False)
    def before_capture(self):need(False)
    def capture(self,*args,**kwargs):need(False)
    def owner(self,*args,**kwargs):need(False)
    def drain(self):need(False)
    def release_owner(self,*args):need(False)
    def owner_original(self,*args):need(False)


class CallbackObserverArchive(IOSEmoteCallbackRetirementObserver):
    """Explicit decoder context, with no live guard/clock/query/send port."""
    def __init__(self,value,*,store,root,binding,run,role,lock,policy,sources,peers,samples,phase):
        need(isinstance(store,PrivateFeatureState) and type(samples) is CallbackSampleArchive and type(phase) is CallbackPhaseArchive
            and sources.historical and (peers is None or peers.historical));lock.assert_held()
        self.store,self.root,self.binding,self.run,self.role=store,Path(root),deepcopy(context(binding)),identifier(run),role
        self.lock,self.policy,self.sources,self.peers,self.samples,self.phase=lock,deepcopy(policy),sources,peers,samples,phase
        need(store.path==lock.path.with_name('ios-emote-'+role+'-observer.json'))
        self.state=self.decode(value);need(self.state['pending'] is None and self.state['records']);drains.history(self)
    def bound(self):need(False)
    def save(self):need(False)
    def observe(self,*args,**kwargs):need(False)
    def publish_latest(self):need(False)
    def publisher(self):need(False)
    def retain(self,*args):need(False)
    def resolve(self):need(False)
    def abandon_read(self):need(False)
