"""Pinned fixed300 typed-cache/Result2 selection, with all original retention."""
from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path.cwd();private=root/'.ios-host-tmp';prefix='snapshot-photos-typed-cache02-20261027';child=private/'run-snapshot-typed-cache-child02.py'
def pin(path):
 s=path.stat();return dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),stat=[s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns])
def census():
 paths=set()
 for folder in (root/'tests/device',root/'scripts',root/'interface/resources/qml'):
  if folder.exists():paths.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py','.js','.cjs','.mjs','.json','.qml','.html','.h','.cpp','.md') and '__pycache__' not in p.parts)
 paths.update((Path(__file__),child));return {str(p.relative_to(root)):pin(p) for p in sorted(paths)}
before=census();(private/(prefix+'-source-before.json')).write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
print('SOURCE_BEFORE',len(before),'launcherSHAs',{p.name:before[str(p.relative_to(root))]['sha256'] for p in (Path(__file__),child)},flush=True)
task_env=os.environ.copy();task_env.update(TMPDIR=str(private),PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.:tests/device:tests/device/self_tests:tests/device/ios/self_tests')
started=time.monotonic();log=private/(prefix+'.log')
with log.open('w') as stream:result=subprocess.run(['timeout','--signal=TERM','--kill-after=5s','300s','python3',str(child)],env=task_env,stdout=stream,stderr=subprocess.STDOUT)
after=census();(private/(prefix+'-source-after.json')).write_text(json.dumps(after,sort_keys=True,indent=2)+'\n');changed=sorted(name for name in set(before)|set(after) if before.get(name)!=after.get(name))
print('ACTUAL_TERMINAL',result.returncode,'elapsed',round(time.monotonic()-started,3),'changedSources',changed,'log',str(log),flush=True)
raise SystemExit(result.returncode if not changed else 98)
