def data(value,seen=None,depth=0):
    if type(value) in (str,int,float,bool,bytes,type(None)):return value
    if depth>=6:return ('identity',id(value))
    seen=set() if seen is None else seen
    if id(value) in seen:return ('cycle',id(value))
    seen=seen|{id(value)}
    if type(value) is dict:return tuple(sorted((str(key),data(item,seen,depth+1)) for key,item in value.items()))
    if type(value) in (list,tuple):return tuple(data(item,seen,depth+1) for item in value)
    if type(value) in (set,frozenset):return tuple(sorted((data(item,seen,depth+1) for item in value),key=repr))
    return ('identity',id(value))
