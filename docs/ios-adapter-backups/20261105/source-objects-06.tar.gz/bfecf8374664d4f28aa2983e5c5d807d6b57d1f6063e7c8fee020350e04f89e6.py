"""Actual Linux identities only; no product process/OS evidence authority.

Discovery reads stat for all visible PIDs. Executable resolution is reserved
for the actual discovered owned ancestry. A live unreadable owned executable is
an error; an actual zombie is retained PRESENT until original wait/reap.
Every owned lookup is bracketed by the full stat lifetime identity.
"""
from pathlib import Path
import os,stat,threading
from metadata_reader import pin


def _sample(pid):
    try:
        raw=Path('/proc/'+str(pid)+'/stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    opening=raw.find('(');closing=raw.rfind(')')
    assert opening>0 and closing>opening and int(raw[:opening].strip())==int(pid)
    fields=raw[closing+2:].split();assert len(fields)>=20 and len(fields[0])==1
    identity=dict(pid=int(pid),parent=int(fields[1]),group=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
    return dict(identity=identity,state=fields[0],rawStat=raw)


def _stat(pid):
    observed=_sample(pid)
    return None if observed is None else dict(observed['identity'])


def _executable(pid):
    return str(Path('/proc/'+str(pid)+'/exe').resolve(strict=True))


def _same_identity(before,after):
    return before is not None and after is not None and before==after


def _expected(identity,expected,parent,group):
    if expected is not None:
        assert type(expected)is dict and set(expected)in(
            {'pid','parent','group','session','startTicks'},
            {'pid','parent','group','startTicks','executable'},
            {'pid','parent','group','session','startTicks','executable'})
        assert all(identity[name]==expected[name]for name in('pid','parent','group','startTicks')),'Already-bound PID/ancestry changed BEFORE executable read'
        if 'session'in expected:assert identity['session']==expected['session'],'Bound session changed BEFORE executable read'
    else:
        assert identity['parent']==(os.getpid()if parent is None else parent),'Foreign new-birth parent'
        assert identity['group']==(os.getpgrp()if group is None else group),'Foreign new-birth group'


class OwnedTerminal(RuntimeError):
    """Actual terminal identity is PRESENT, never a live/signal/absence proof."""
    def __init__(self,observation):
        assert observation['kind']=='PRESENT_TERMINAL'and observation['after']['state']=='Z'
        self.observation=observation
        super().__init__('Original owned process is present as a zombie; original wait/reap remains required')


def observe(pid,*,expected=None,parent=None,group=None):
    """Typed original observations; no wait/signal, clock, PID adoption or retry.

    Only the actual Linux Z state is interpreted as terminal here. Other
    states do not waive an executable-read failure. Raw stat data and the
    complete lifetime identity (including SID) remain separate from exe proof.
    """
    before=_sample(pid)
    if before is None:return dict(kind='MISSING',before=None,after=None,executable=None,executableReadAttempted=False,lookupError=None)
    _expected(before['identity'],expected,parent,group)
    if before['state']=='Z':
        after=_sample(pid)
        if after is None:return dict(kind='MISSING',before=before,after=None,executable=None,executableReadAttempted=False,lookupError=None)
        assert _same_identity(before['identity'],after['identity']),'Terminal PID/ancestry changed'
        assert after['state']=='Z','Original terminal state changed unexpectedly'
        return dict(kind='PRESENT_TERMINAL',before=before,after=after,executable=None,executableReadAttempted=False,lookupError=None)
    try:executable=_executable(pid)
    except(FileNotFoundError,ProcessLookupError)as error:
        # These are actual lookup outcomes. Permission and all unknown errors
        # propagate; missing exe alone never proves absence or terminal state.
        after=_sample(pid)
        fault=dict(type=type(error).__name__,errno=error.errno)
        if after is None:return dict(kind='MISSING',before=before,after=None,executable=None,executableReadAttempted=True,lookupError=fault)
        assert _same_identity(before['identity'],after['identity']),'PID/ancestry changed while resolving an executable'
        if after['state']=='Z':
            return dict(kind='PRESENT_TERMINAL',before=before,after=after,executable=None,executableReadAttempted=True,lookupError=fault)
        raise
    after=_sample(pid)
    if after is None:return dict(kind='MISSING',before=before,after=None,executable=executable,executableReadAttempted=True,lookupError=None)
    assert _same_identity(before['identity'],after['identity']),'PID/ancestry changed across executable resolution'
    if expected is not None and 'executable'in expected:assert executable==expected['executable'],'Already-bound executable changed'
    return dict(kind='PRESENT_TERMINAL'if after['state']=='Z'else'PRESENT_LIVE',before=before,after=after,
        executable=executable,executableReadAttempted=True,lookupError=None)


def process(pid,*,expected=None,parent=None,group=None):
    # Preserve the original five-key LIVE API. Never return historical exe as
    # current authority, and never turn a terminal observation into None.
    observed=observe(pid,expected=expected,parent=parent,group=group)
    if observed['kind']=='MISSING':return None
    if observed['kind']=='PRESENT_TERMINAL':raise OwnedTerminal(observed)
    assert observed['kind']=='PRESENT_LIVE'and observed['executable']is not None
    return {name:observed['after']['identity'][name]for name in('pid','parent','group','startTicks')}|dict(executable=observed['executable'])


def absent(pid):
    return _stat(pid)is None


def descendants(parent):
    parent_before=_stat(parent);assert parent_before is not None
    actual={}
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            row=_sample(int(path.name))
            if row is not None:actual[row['identity']['pid']]=row
    assert _same_identity(parent_before,None if int(parent)not in actual else actual[int(parent)]['identity'])
    own={int(parent)};changed=True
    while changed:
        changed=False
        for pid,row in actual.items():
            if row['identity']['parent']in own and pid not in own:own.add(pid);changed=True
    result={}
    for pid in sorted(own-{int(parent)}):
        expected=actual[pid]['identity'];verified=observe(pid,expected=expected)
        if verified['kind']=='MISSING':
            assert _stat(pid)is None,'An owned PID reappeared during discovery'
            continue
        assert _same_identity(expected,verified['after']['identity']),'Discovered PID/ancestry was replaced'
        after=_sample(pid)
        if after is None:continue
        assert _same_identity(expected,after['identity']),'Discovered PID/session changed after executable validation'
        # Include terminal members as PRESENT data; they still prevent absence.
        # No new row may become signal authority or replace an original birth.
        result[pid]={name:expected[name]for name in('pid','parent','group','startTicks')}|dict(
            executable=verified['executable'],observation=verified)
    assert _same_identity(parent_before,_stat(parent)),'Discovery owner identity changed'
    return result

def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:
            s=path.stat();result[path.name]=dict(target=os.readlink(path),device=s.st_dev,inode=s.st_ino,mode=s.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result

def state():return dict(fds=fds(),threads=[(t.ident,t.name)for t in threading.enumerate()],children=Path('/proc/self/task/'+str(os.getpid())+'/children').read_text())
def census(root):
    root=Path(root);out={}
    for path in(root,*sorted(root.rglob('*'))):
        before=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(before.st_mode):
            row={key:getattr(before,key)for key in('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')}
            row['namespace']=sorted(p.name for p in path.iterdir())
        else:row=pin(path)
        assert all(getattr(path.lstat(),key)==getattr(before,key)for key in('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'));out[str(path.relative_to(root))]=row
    return out
