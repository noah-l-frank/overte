"""Exact completed Own8 boundary evidence, without feature or Actor authority."""
from pathlib import Path
from prefix_common import REPO,pin,load
from source_execution_admission import SUBJECT,HELPER,QUALIFIED,qualify


def retained_packet(path,digest):
    path=Path(path)
    assert path.is_absolute()and path.resolve(strict=True)==path
    assert path.is_relative_to(REPO/'.ios-host-tmp')and path.name in('freeze.json','source-freeze.json')
    assert pin(path)['sha256']==digest
    for name,row in load(path)['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        actual=path.parent/name
        assert pin(actual)['sha256']==(row if type(row)is str else row['sha256'])
    return path


def qualified_original(path,digest):
    root=REPO/'.ios-host-tmp/root-avatar-own8-four-boundary-counters-qualified-results-20261104'
    assert Path(path)==root/'freeze.json'and digest=='2eec044816e0d677c368e0387333f61bae93a8ab68ef52887b8f22871dedc229'
    retained_packet(path,digest)
    actual=load(root/'results.json');references=load(root/'actual-receipt-references.json')
    assert actual['schemaVersion']==1
    assert actual['status']=='ROOT_QUALIFIED_AVATAR_OWN8_FOUR_GENUINE_BOUNDARY_COUNTERS_NSS_AND_ORIGINAL_REJECTED_UNWIND'
    assert actual['prefixSourceFreeze']=='3c5d0d06fd79e0c24c0abff81a0caed89a025695e63b06e8040729281ff87f09'
    assert actual['ownSourceFreeze']=='83a59c4cb3ae47de7ccf5077e892acb7aacb8bffea23b032d4ba19a5ce6726e9'
    assert actual['actualTests']==actual['actualPassedCases']==4
    assert actual['actualRetainedTDs']==6 and actual['actualOpenSSLChildren']==2
    assert actual['actualFixtureTLSListeners']==actual['actualOriginalNSSAttempts']==1
    assert actual['actualRejectedStarts']==actual['actualMatchingOriginalUnwinds']==1
    assert actual['actualNodeExecutions']==actual['actualSDKExecutions']==0
    assert actual['actualStandardCleanupsQualified']is True
    for key in('positiveActorAuthority','avatarQualified','wholeQualified','nativeQualified','deviceQualified'):
        assert actual[key]is False
    assert actual['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
    assert actual['all969SourcePinsUnchanged']is actual['all760OldOriginalBodiesUnchanged']is actual['twoCompleteOwnOutputsEqual']is True
    assert actual['RootExternalGlobalCensuses']==3
    assert actual['RootExternalAfterRootCountIncludingOwnTemporary']==761
    ids=['test_avatar_prefix_boundary.AvatarPrefixBoundaryTests.'+name for name in(
        'test_foreign_real_thread_write_refuses_without_original_frame',
        'test_original_http_request_closes_socket_and_its_own_writer_helper',
        'test_matching_original_node_argv_foreign_caller_refuses_before_birth',
        'test_actual_tls_postbirth_precallerreturn_fault_stays_nongreen_then_rescues')]
    assert actual['actualCaseIds']==ids
    report=actual['actualChildReport'];assert report['status']=='PASS'and report['testsRun']==4 and report['selected']==ids
    assert report['suiteReturned']is True and report['fatal']is None and report['finalizationFailures']==[]
    assert report['originalCleanupEstablished']is True
    for key in('actualFDsEqual','actualThreadsEqual','actualToolsEqual','actualPortsEqual','allPinsEqual','inputPinAndCliShaEqual','twoRawCensusesEqual'):
        assert report[key]is True
    assert report['remainingKernelChildren']==report['prohibitedNativeOrNodeEntries']==[]
    outer=actual['originalSupervisorTerminal'];assert outer['status']=='PASS'and outer['childReturnCode']==0
    assert outer['forced']is outer['timedOut']is False
    assert outer['problems']==outer['remainingOwned']==outer['postRunnerResidual']==[]
    for key in('allSourcePinsEqual','actualInputPinAndCliShaEqual','twoFullOwnOutputCensusesEqual','actualParentFDThreadDrain'):
        assert outer[key]is True
    data=actual['actualResourceData'];assert len(data['cases'])==len(data['standardCleanups'])==4
    assert [row['testId']for row in data['cases']]==ids
    assert [row['testId']for row in data['standardCleanups']]==ids
    assert all(row['returned']is True and row['remaining']==0 for row in data['standardCleanups'])
    assert all(row['cleanupFailures']==[]and row['restoration']['actualPortsRestored']is True for row in data['cases'])
    processes=[row for case in data['cases']for row in case['actualProcesses']]
    assert len(processes)==2 and len({(row['birth']['pid'],row['birth']['startTicks'])for row in processes})==2
    assert all(row['kind']=='openssl'and row['returnCode']==0 and row['absenceProven']is row['originalStreamsKnown']is row['originalStreamsClosed']is True for row in processes)
    rejections=[row for case in data['cases']for row in case['actualRejectedStartOriginal']['records']]
    assert len(rejections)==1
    rejection=rejections[0];assert rejection['actualOriginalUnwindCount']==1 and rejection['exactSameOriginalException']is True
    assert rejection['processAuthorityGranted']is rejection['pidOrAbsenceAuthorityGranted']is rejection['originalConstructorBodyEntered']is False
    assert len(data['controllerRescues'])==1
    rescue=data['controllerRescues'][0]
    assert rescue['actualControllerRescue']is True and rescue['returnCode']==0
    assert rescue['processAbsent']is rescue['originalStreamsClosed']is True
    assert rescue['callerReturnEstablished']is rescue['originalTLSSetupEstablished']is rescue['rescueTimedOut']is False
    assert len(references)==41
    for name,row in references.items():
        assert set(row)=={'path','sha256'}and row['path']==name
        assert Path(name).is_absolute()and Path(name).resolve(strict=True)==Path(name)
        assert pin(Path(name))['sha256']==row['sha256']
    # The qualification applies to these unchanged helper bytes only. The
    # controller's newly admitted normal prefix has never been executed.
    previous=REPO/'.ios-host-tmp/avatar-normal-prefix8-original-rejected-popen-unwind-source-private-20261104'
    retained_packet(previous/'source-freeze.json',actual['prefixSourceFreeze'])
    current=Path(__file__).resolve(strict=True).parent
    core=('avatar_ports.py','entry_observer.py','assets_fixture_ports.py','monitoring_observer.py',
        'owned_write_boundary.py','closed_import_origins.py','metadata_reader.py','prefix_common.py','own_public_source_reads.py')
    qualified_files=[]
    for name in core:
        assert pin(current/name)['sha256']==pin(previous/name)['sha256']
        qualified_files.extend((str(current/name),str(previous/name)))
    roots=actual['newOriginalRoots'];assert len(roots)==len(set(roots))==4
    return dict(rootFreeze=dict(path=str(path),sha256=digest),actualResult=actual,
        actualReceiptReferences=references,qualifiedBoundaryFiles=qualified_files,
        requiredOriginalRoots=roots,boundaryCountersOnly=True,featureQualification=False,
        historicalProcessReceiptsAreNotCurrentAbsenceAuthority=True)


def source_execution_original(path,digest):
    assert Path(path)==REPO/'.ios-host-tmp/root-c10c-source-execution-six-cache-mutation-alias-counters-qualified-results-20261104/freeze.json'
    assert digest==QUALIFIED;retained_packet(path,digest)
    proof=dict(subjectSourceFreeze=SUBJECT,helperSha256=HELPER,rootFreeze=dict(path=str(path),sha256=digest))
    actual=qualify(dict(qualifiedSourceExecution=proof),pin)
    references=load(Path(path).parent/'actual-receipt-references.json');assert len(references)==48
    for row in references.values():assert pin(row['path'])['sha256']==row['sha256']
    return dict(qualifiedSourceExecution=proof,actualResult=actual,actualReceiptReferences=references)
