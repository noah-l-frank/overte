import ast,hashlib,json,stat,difflib
from pathlib import Path
R=Path.cwd();P=R/'.ios-host-tmp/emote-callback-live-prefix-scoped19-tail8-root-preparation-20261103';O=R/'.ios-host-tmp/emote-callback-live-prefix-regex-annotations-mechanisms27-gated-root-preparation-20261102';SOURCE=R/'.ios-host-tmp/emote-callback-live-prefix-nested-metadata-test-only-fix-20261103';OLD=O/'mechanisms27';SMOKE=O/'smoke1';T=P/'tail8';assert not(P/'freeze.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.open('x').write(s)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in F]);
 if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
 assert v['stat']==[getattr(p.lstat(),k) for k in F];return v
plan=json.loads((OLD/'run-plan.json').read_text());allids=plan['cases'];assert len(allids)==27
report=json.loads((OLD/'root-run-first/report.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==41 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
assert not list(OLD.glob('terminal-census*'))
prior=json.loads((OLD/'prior-retained-original-pins.json').read_text());newpins={}
for stage in (OLD,SMOKE):
 frozen=set(json.loads((stage/'freeze.json').read_text())['files'])|{'freeze.json'}
 for p in sorted(stage.rglob('*')):
  if str(p.relative_to(stage)) not in frozen:newpins[str(p)]=pin(p)
prior.update(newpins);save(P/'actual-history-current-pins.json',newpins)
rel='tests/device/ios/self_tests/test_ios_emote_callback_live_history_cache.py';srows=json.loads((SOURCE/'plan.json').read_text())['sourceRows'];testrow=next(r for r in srows if r['path']==rel)
scopeplan=dict(oldStage=str(OLD),smokeStage=str(SMOKE),unchangedPrefix=allids[:19],failedCase=allids[19],tail=allids[19:],oldExit=1,oldFiles=41,
 oldTestFile=str(SOURCE/'base'/rel),newTestFile=str(SOURCE/'candidate'/rel),testPath=rel,oldTestSha256=testrow['baseSHA256'],newTestSha256=testrow['candidateSHA256'],helperPath='tests/device/ios/adapters/emote_callback_live_records.py',helperSha256='4fea6757d1a6903dce66ecfd5d94e6f13138b9dbbdaa2cce78a105fcf7db7994',
 changedMethods=json.loads((SOURCE/'plan.json').read_text())['changedMethods'])
save(P/'scope-plan.json',scopeplan)
helper='''"""Historical scoped19 +actual smoke helper proof; no old test replay."""
import ast,hashlib,json,stat
from pathlib import Path
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def allpins(master):
 pins=json.loads((master/'actual-history-current-pins.json').read_text())
 for name,expected in pins.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();v=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
  assert v==expected and v['stat']==[getattr(p.lstat(),k) for k in F]
 return [Path(name) for name in pins]
def delta(plan,repo):
 old=Path(plan['oldTestFile']);new=Path(plan['newTestFile']);assert sha(old)==plan['oldTestSha256'] and sha(new)==plan['newTestSha256']
 a,b=[ast.parse(p.read_text()) for p in (old,new)];changed=[]
 for ca,cb in zip(a.body,b.body,strict=True):
  if isinstance(ca,ast.ClassDef):
   assert ca.name==cb.name
   for na,nb in zip(ca.body,cb.body,strict=True):
    if ast.dump(na,include_attributes=False)!=ast.dump(nb,include_attributes=False):assert isinstance(na,ast.FunctionDef);changed.append(ca.name+'.'+na.name)
  else:assert ast.dump(ca,include_attributes=False)==ast.dump(cb,include_attributes=False)
 assert changed==plan['changedMethods']
 assert sha(repo/plan['helperPath'])==plan['helperSha256']
 return [old,new]
def exited(out):
 p=json.loads((out/'process-binding.json').read_text())['task']
 try:row=Path('/proc',str(p['pid']),'stat').read_text().rsplit(') ',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):row=None
 assert row is None or int(row[19])!=p['startTicks']
def cleanup(stage,index,case):
 c=stage/('case-cleanup-'+str(index));r=json.loads((c/'receipt.json').read_text());assert r['case']==case and r['actualStandardCaseRunReturned'] and r['twoCensusesPassed']
 a=json.loads((c/'terminal-census-1.json').read_text());b=json.loads((c/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
def historical(master,repo):
 plan=json.loads((master/'scope-plan.json').read_text());paths=allpins(master);paths+=delta(plan,repo);stage=Path(plan['oldStage']);out=stage/'root-run-first'
 report=json.loads((out/'report.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==41 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=1,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 assert not list(stage.glob('terminal-census*'))
 r=json.loads((stage/'selected-result.json').read_text());assert r['selectedIds']==plan['unchangedPrefix']+plan['tail'] and r['testsRun']==20 and not r['successful'] and r['failureCount']==1 and r['errorCount']==r['skippedCount']==0
 lines=(out/'first.log').read_text().splitlines();parsed=[]
 for case in plan['unchangedPrefix']+[plan['failedCase']]:
  method=case.rsplit('.',1)[1];classname=case.rsplit('.',1)[0];expected=method+' ('+classname+'.'+method+') ... '+('FAIL' if case==plan['failedCase'] else 'ok')
  assert lines.count(expected)==1;parsed.append(expected)
 for index,case in enumerate(plan['unchangedPrefix']+[plan['failedCase']],1):cleanup(stage,index,case)
 allpins(master)
 return dict(status='ACTUAL_HISTORICAL_SCOPED19_PASS',scopedCases=plan['unchangedPrefix'],failedCasePreserved=plan['failedCase'],oldAggregatePassed=False,aggregateTerminalCensusesPresent=False,actualPerCaseCensuses=20,originalFiles=41,oldSourceBeforeAfterEqual=True,oldCurrentRawPinsExact=True,originalProcessAbsent=True,helperSha256=plan['helperSha256'],unchangedPrefixTestAST=True,actualOutcomeLines=parsed),paths

def require(here,repo,current=None):
 master=here.parent;plan=json.loads((master/'scope-plan.json').read_text());expected,paths=historical(master,repo)
 actual=json.loads((master/'root-scoped19-report.json').read_text());assert actual==expected;paths.append(master/'root-scoped19-report.json')
 assert sha(repo/plan['testPath'])==plan['newTestSha256']
 smoke=Path(plan['smokeStage']);out=smoke/'root-run-first';r=json.loads((out/'report.json').read_text());assert r['exitCode']==0 and r['retainedFiles']==0 and all(r[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not r['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 ids=json.loads((smoke/'run-plan.json').read_text())['cases'];a=json.loads((smoke/'selected-result.json').read_text());assert len(ids)==1 and a['selectedIds']==ids and a['successful'] and a['testsRun']==1 and not any(a[k] for k in ('failureCount','errorCount','skippedCount'));cleanup(smoke,1,ids[0])
 old=json.loads((out/'root-source-map.json').read_text());assert old['repositoryRoot']==str(repo) and old['currentSourcePins'][plan['testPath']]==plan['oldTestSha256']
 adjusted=dict(old['currentSourcePins']);adjusted[plan['testPath']]=plan['newTestSha256']
 if current is not None:assert current['currentSourcePins']==adjusted
 for name,digest in adjusted.items():
  p=repo/name;assert p.is_relative_to(repo) and p.resolve(strict=True)==p and sha(p)==digest
 allpins(master);return paths+[master/'scope-plan.json',master/'actual-history-current-pins.json']
'''
write(P/'scoped_prerequisite.py',helper)
write(P/'scope-first19.py',"import json,os,sys\nfrom pathlib import Path\nfrom scoped_prerequisite import historical\nHERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]\nassert sys.dont_write_bytecode and Path.cwd()==REPO\nreport,_=historical(HERE,REPO)\np=HERE/'root-scoped19-report.json';fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)\nwith os.fdopen(fd,'w') as f:json.dump(report,f,indent=2);f.write('\\n')\nprint(json.dumps(report))\n")
T.mkdir();frozen=json.loads((OLD/'freeze.json').read_text())['files']
for name,digest in frozen.items():
 assert sha(OLD/name)==digest
 if name.endswith('.py') or name=='sdk-original-pins.json':write(T/name,(OLD/name).read_text())
write(T/'scoped_prerequisite.py',helper)
# Existing entrypoint imports actual_smoke_prerequisite; retain the name as exact canonical shim.
(T/'actual_smoke_prerequisite.py').write_text('from scoped_prerequisite import require\n')
parent=(T/'root-supervise.py').read_text();(T/'root-supervise.py').write_text(parent)
plan.update(status='PRIVATE_UNRUN_TAIL8_ONLY_AFTER_ACTUAL_SCOPED19',cases=allids[19:],caseCount=8,totalCaseCount=8,expectedRetainedRoots=8,privateFiles={f.name:sha(f) for f in T.glob('*.py')})
save(T/'run-plan.json',plan);save(T/'prior-retained-original-pins.json',prior)
manifest=json.loads((OLD/'source-manifest.json').read_text());manifest.update(name='tail8',stage='emote-tail8',caseCount=8,pythonCaseCount=8,initialTimeoutSeconds=30,status=plan['status'])
manifest['sourcePaths']=[dict(path=r['path'],candidate=str(SOURCE/'candidate'/r['path']),candidateSHA256=r['candidateSHA256'],observedPublicSHA256=sha(R/r['path']),changesCurrentPublic=r['baseSHA256']!=r['candidateSHA256']) for r in srows]
manifest['orderedParentFreezes'][str(SOURCE.relative_to(R/'.ios-host-tmp'))]=sha(SOURCE/'freeze.json');save(T/'source-manifest.json',manifest)
save(T/'supervisor-plan.json',json.loads((OLD/'supervisor-plan.json').read_text()))
# Parent must pin shared immutable gate files before/after and verify its frozen text.
s=(T/'root-supervise.py').read_text().replace(" paths.update(require_smoke(HERE,REPO))"," paths.update(require_smoke(HERE,REPO))\n for name in ('scope-plan.json','actual-history-current-pins.json','scoped_prerequisite.py','scope-first19.py'):\n  p=HERE.parent/name;assert sha(p)==json.loads((HERE/'master-guard-pins.json').read_text())[name];paths.add(p)")
(T/'root-supervise.py').write_text(s);plan['privateFiles']={f.name:sha(f) for f in T.glob('*.py')};(T/'run-plan.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
save(T/'master-guard-pins.json',{n:sha(P/n) for n in ('scope-plan.json','actual-history-current-pins.json','scoped_prerequisite.py','scope-first19.py')})
for f in P.rglob('*.py'):ast.parse(f.read_text())
save(T/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={f.name:sha(f) for f in T.iterdir() if f.is_file() and f.name!='freeze.json'}))
write(P/'ROOT-PLAN.txt','Root-only metadata scope first: PYTHONDONTWRITEBYTECODE=1 python3 scope-first19.py fromrepo; immutable old aggregate FAIL preserved, no whole27PASS or missing aggregate census invented. Source TESTONLY e974 publication then tail8/root-supervise.py original30+kill5/8TD. No smoke/first19 rerun. Actual samehelper smoke27+19 observed ok-lines and20 genuine percase close/two censuses/PID absence gates beforeimports; full public map delta permits ONLY reviewed test12ab→e974. First7 oldscoped diagnostics retained unchanged. Freshgraph remainsheld until actual tail8PASS plus thisscoped19 verified. No source helper/native/SDK/capability changes.\n')
save(P/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceFreeze=sha(SOURCE/'freeze.json'),tail=allids[19:],first19NotRerun=True,smokeNotRerun=True,oldAggregateFailed=True,oldAggregateTerminalMissing=True,initialSeconds=30,killAfterSeconds=5,expectedRoots=8,targetImports=False,testsRun=False))
save(P/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(f.relative_to(P)):sha(f) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='freeze.json'},stageFreeze=sha(T/'freeze.json')))
print(json.dumps(dict(freeze=sha(P/'freeze.json'),tailFreeze=sha(T/'freeze.json'),sourceFreeze=sha(SOURCE/'freeze.json'),pins=len(newpins))))
