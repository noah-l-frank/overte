#!/usr/bin/env python3
"""Root-run only: source models, no SDK imports, service/device or admission."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
import threading,tempfile,stat
from contextlib import ExitStack
from types import SimpleNamespace
from unittest.mock import patch
from importlib.machinery import PathFinder

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
NODE=Path('/usr/local/lib/overte-ios-remotexpc/5.15.3-r12/bin/node')
NODE_SHA='bc17c508ffeed0ec622934f9b7fa72f8e78da65350e63c3eceb56fa688aa5e12'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pinned(path,expected):
    value=Path(path);raw=value.read_bytes()
    if value.is_symlink() or value.resolve()!=value or sha(raw)!=expected:raise RuntimeError('Source byte pin unavailable')
    return raw

def main():
    # Root supplies current full source census and explicitly reviewed candidate
    # inventory. No default or stale historical source map is adopted.
    map_path=Path(os.environ['LIFECYCLE_FINAL_ROOT_MAP'])
    map_raw=pinned(map_path,os.environ['LIFECYCLE_FINAL_ROOT_MAP_SHA256'])
    owner_map=json.loads(map_raw)
    if set(owner_map)!={'repositoryRoot','currentSourcePins','reviewedCandidates'}:raise RuntimeError('Root source map schema')
    repo=Path(owner_map['repositoryRoot'])
    if not repo.is_absolute() or repo.resolve()!=repo or not (repo/'.git').exists():raise RuntimeError('Actual source worktree unavailable')
    plan_raw=pinned(HERE/'test-plan.json',os.environ['LIFECYCLE_FINAL_PLAN_SHA256']);plan=json.loads(plan_raw)
    manifest_raw=pinned(HERE/'manifest.json',os.environ['LIFECYCLE_FINAL_MANIFEST_SHA256']);manifest=json.loads(manifest_raw)
    if plan['repositoryRoot']!=str(repo):raise RuntimeError('Wrong actual source root')
    expected={row['path']:row['candidateSHA256'] for row in manifest['repoFiles']}
    if owner_map['reviewedCandidates']!=expected:raise RuntimeError('Exact candidate source map required')
    # Current sources need not already publish the private draft. The models
    # extract these reviewed candidates; no installed-source fact follows.
    required={str(Path(row['path']).relative_to(repo)) for row in plan['closure']}
    required.update(rel for rel in expected if (repo/rel).exists())
    required.update(('tests/device/ios/self_tests/test_ios_touch_lease.py','tests/device/ios/self_tests/retained_host_roots.py'))
    if not required<=set(owner_map['currentSourcePins']):raise RuntimeError('Current dependency census incomplete')
    guards=[]
    for rel,digest in owner_map['currentSourcePins'].items():
        relative=Path(rel)
        if relative.is_absolute() or '..' in relative.parts:raise RuntimeError('Source census path escape')
        guards.append((repo/relative,digest))
    guards += [(Path(row['candidate']),row['candidateSHA256']) for row in manifest['repoFiles']]
    guards += [(Path(row['path']),row['sha256']) for row in plan['sdkOriginals']]
    guards += [(Path(row['copy']),row['sha256']) for row in plan['sdkOriginals']]
    # Historical closure original bytes stay pinned below. Current public
    # closure sources are covered by Root's fresh broad currentSourcePins.
    guards += [(Path(row['copy']),row['sha256']) for row in plan['closure']]
    model_map=HERE/'node-model-source-map.json';model_map_raw=model_map.read_bytes()
    guards += [(model_map,sha(model_map_raw)),(NODE,NODE_SHA),
               (HERE/'test_owner_readonly_preflight_models.py',os.environ['LIFECYCLE_FINAL_PYTHON8_SHA256']),
               (HERE/'test_existing_wda_route_models.py',os.environ['LIFECYCLE_FINAL_PYTHON3_SHA256']),
               (HERE/'test_actual_loaded_owner_routes.mjs',os.environ['LIFECYCLE_FINAL_NODE9_SHA256'])]
    guards += [(HERE/name,digest) for name,digest in manifest['modelFiles'].items()]
    lifetime=HERE/'lifetime-source-map.json';lifetime_raw=lifetime.read_bytes()
    guards.append((lifetime,manifest['lifetimeSourceMapSHA256']))
    for path,digest in guards:pinned(path,digest)
    before={str(path):path.stat() for path,_ in guards}
    source=next(row for row in manifest['repoFiles'] if row['path']=='tests/device/ios/pymobiledevice3_wda_xctest.py')
    os.environ['LIFECYCLE_READONLY_SOURCE']=source['candidate'];os.environ['LIFECYCLE_READONLY_SOURCE_SHA256']=source['candidateSHA256']
    os.environ['LIFECYCLE_EXISTING_WDA_ROUTE_SOURCE']=source['candidate'];os.environ['LIFECYCLE_EXISTING_WDA_ROUTE_SOURCE_SHA256']=source['candidateSHA256']
    os.environ['LIFECYCLE_LIFETIME_MAP']=str(lifetime)
    os.environ['LIFECYCLE_LIFETIME_MAP_SHA256']=sha(lifetime_raw)
    baseline_threads=set(threading.enumerate())
    roots=[str(repo/rel) for rel in ('tests/device','tests/device/self_tests','tests/device/ios/self_tests')]
    remainder=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==repo or repo in path.parents:continue
        if str(path) not in remainder:remainder.append(str(path))
    sys.path[:]=roots+[str(HERE)]+remainder
    for name,relative in {'adapters':'tests/device/adapters','ios':'tests/device/ios','self_tests':'tests/device/self_tests'}.items():
        spec=PathFinder._get_spec(name,list(sys.path))
        if spec is None or [str(Path(p).resolve()) for p in spec.submodule_search_locations or ()]!=[str(repo/relative)]:
            raise RuntimeError('Canonical namespace mismatch before target import')
    retained=HERE/'retained-exact35-first';retained.mkdir(mode=0o700,exist_ok=False)
    real_td=tempfile.TemporaryDirectory;owned_roots=[];owned_objects=[]
    result_ok=False
    try:
        # Only private model modules import after source/root/SDK byte guards.
        # Their explicit DI excludes the two original SDK service imports.
        from ios.self_tests import test_ios_touch_lease as fixture
        from ios.self_tests.retained_host_roots import retain_owned_root
        def directory(suffix=None,prefix=None,dir=None,*,ignore_cleanup_errors=False,delete=True):
            if dir is not None and Path(dir)!=retained:raise RuntimeError('Foreign temporary root')
            actual=real_td(suffix=suffix,prefix=prefix,dir=retained,ignore_cleanup_errors=ignore_cleanup_errors,delete=delete)
            root=Path(actual.name);retain_owned_root(actual,expected_root=root)
            owned_objects.append(actual);owned_roots.append(str(root))
            (HERE/'created-exact35-original-roots.json').write_text(json.dumps(owned_roots)+'\n')
            return actual
        suite=unittest.TestSuite()
        loader=unittest.TestLoader()
        for case in plan['pythonCases']:suite.addTests(loader.loadTestsFromName(case))
        if suite.countTestCases()!=16:raise RuntimeError('Unexpected exact Python selection')
        with patch.object(fixture,'tempfile',SimpleNamespace(TemporaryDirectory=directory)):
            result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
        if not result.wasSuccessful():return 1
        environment={'PATH':'/usr/bin','HOME':'/nonexistent','LANG':'C.UTF-8',
            'LIFECYCLE_WDA_SESSION_MODEL_MAP':str(model_map),
            'LIFECYCLE_WDA_SESSION_MODEL_MAP_SHA256':sha(model_map_raw)}
        child=subprocess.run([str(NODE),'--test',str(HERE/'test_actual_loaded_owner_routes.mjs'),str(HERE/'test_original_owner_lifetime_models.mjs')],
            cwd=HERE,env=environment,timeout=15,check=False)
        result_ok=child.returncode==0
        return 0 if result_ok else 1
    finally:
        new_threads=[t for t in threading.enumerate() if t not in baseline_threads and t.is_alive()]
        if new_threads:raise RuntimeError('New original model thread remains alive')
        if any(n.split('.')[0] in {'pymobiledevice3','pmd_pytcp','pmd_net_addr'} for n in sys.modules):raise RuntimeError('Unexpected SDK import')
        pinned(map_path,sha(map_raw));pinned(HERE/'test-plan.json',sha(plan_raw));pinned(HERE/'manifest.json',sha(manifest_raw))
        for path,digest in guards:
            pinned(path,digest);old=before[str(path)];new=path.stat()
            fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
            if any(getattr(old,key)!=getattr(new,key) for key in fields):raise RuntimeError('Original source stat changed')
        print('Exact source-model terminal; installed SDK/auth/native/whole qualification remains false.',flush=True)
if __name__=='__main__':raise SystemExit(main())
