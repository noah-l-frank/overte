"""Genuine utility owners over original spawn/Value/Pipe; no feature owner.

The same original creator bridge used in Tablet's source graph is supplied
actual utility functions/frames here. Nothing impersonates IOSScriptRuntime,
Source, Paired Tablet owners, a native observation, or a product clock.
"""
from pathlib import Path
import hashlib,json,multiprocessing as mp,multiprocessing.connection as connection
import multiprocessing.heap as heap,multiprocessing.popen_spawn_posix as popen
import multiprocessing.resource_tracker as tracker,multiprocessing.spawn as spawn
import multiprocessing.synchronize as synchronize,multiprocessing.util as util
import errno,os,sys,threading,time
from tablet_constructor_custody import FunctionBinding,OwnedArenaConfiguration,CustodyRefusal
from tablet_guarded_spawn import GuardedOriginalSpawn,file_pin
from tablet_ipc_capacity import ActualIPCCapacities
from local_monitor import LocalMonitor
from mp_identity import current,stat_identity,absent,fd_row
from mp_ports import Ports
_ACTIVE=None

def roots():
    assert _ACTIVE is not None;return {_ACTIVE.case_root}
def transport_scope():
    assert _ACTIVE is not None;return _ACTIVE.transport()
def save_original(name,body):
    assert _ACTIVE is not None;_ACTIVE.save(name,body)

class ToyRoot:
    def __init__(self,path):
        self.root=Path(path).resolve(strict=True);assert self.root.is_dir()and not self.root.is_symlink()
        self.birth=self.root.stat().st_dev,self.root.stat().st_ino
    def check(self):assert self.birth==(self.root.stat().st_dev,self.root.stat().st_ino)
class Paired:
    def __init__(self,root,mode):
        assert _ACTIVE is not None and _ACTIVE.case_root==root
        self.boundary=ToyRoot(root);self.mode=mode
        self.ctx=mp.get_context('spawn')
        self.clock=self.ctx.Value('i',0)  # Actual BufferWrapper/Arena/SemLock, not a device clock.
        self.inputs=(str(root),mode,os.getpid(),str(Path(__file__)),hashlib.sha256(Path(__file__).read_bytes()).hexdigest())

def actor(inputs,clock,channel):
    assert type(inputs)is tuple and len(inputs)==5
    root,mode,parent,source,digest=inputs
    assert os.getppid()==parent and Path(root).resolve(strict=True)==Path(root)
    assert Path(source).read_bytes()==Path(__file__).read_bytes()and hashlib.sha256(Path(source).read_bytes()).hexdigest()==digest
    try:
        channel.send(('ready',os.getpid(),clock.value))
        assert channel.recv()=='go'
        with clock.get_lock():clock.value+=1
        channel.send(('returned',os.getpid(),clock.value))
    finally:channel.close()

def run_open(f):
    assert type(f)is Paired and _ACTIVE is not None
    parent,child=f.ctx.Pipe(duplex=True)
    process=f.ctx.Process(target=actor,args=(f.inputs,f.clock,child))
    _ACTIVE.process=process;_ACTIVE.connections.extend((parent,child))
    try:
        process.start();child.close()
        assert parent.poll(5),'Actual pre-unpickle or actor failure; no invented ready message'
        ready=parent.recv();assert ready==('ready',process.pid,0)
        _ACTIVE.ready=ready
        birth=next(row['kernel']for row in _ACTIVE.spawn.records if row['role']=='actor')
        observation=Path(_ACTIVE.plan['controllerRoot'])/'child-receipts'/('outer-observed-%s-%s.json'%(birth['pid'],birth['startTicks']))
        deadline=time.monotonic()+5
        while not observation.is_file():
            assert time.monotonic()<deadline and process.is_alive(),'No genuine outer observation before actor exit'
            time.sleep(.005)
        observed=json.loads(observation.read_text());actual=stat_identity(birth['pid']);assert actual is not None
        assert observed['source']=='outer-actual-owned-stat'and observed['featureEvidence']is False
        assert observed['actualKernel']==dict(pid=actual['pid'],parent=actual['parentPID'],group=actual['processGroup'],session=actual['session'],startTicks=actual['startTicks'])
        assert actual['startTicks']==birth['startTicks']and actual['parentPID']==os.getpid()
        if f.mode=='lifetime':
            live_before=stat_identity(process.pid);assert live_before is not None and live_before['startTicks']==birth['startTicks']
            connection_before=[dict(fd=owner.fileno(),identity=fd_row(owner.fileno()))for owner in(parent,)if not owner.closed]
            semaphore_before=[dict(name=row['name'],device=Path(row['path']).stat().st_dev,inode=Path(row['path']).stat().st_ino)for row in _ACTIVE.semaphores]
            try:_ACTIVE.require_retired()
            except AssertionError as error:
                live_after=stat_identity(process.pid)
                connection_after=[dict(fd=owner.fileno(),identity=fd_row(owner.fileno()))for owner in(parent,)if not owner.closed]
                semaphore_after=[dict(name=row['name'],device=Path(row['path']).stat().st_dev,inode=Path(row['path']).stat().st_ino)for row in _ACTIVE.semaphores]
                assert live_before==live_after and connection_before==connection_after and semaphore_before==semaphore_after
                _ACTIVE.negative_rows.append(dict(kind='retirement-while-actual-child-live-refused',type=type(error).__name__,
                    actualLiveKernelBefore=live_before,actualLiveKernelAfter=live_after,actualConnectionBefore=connection_before,actualConnectionAfter=connection_after,
                    actualSemaphoresBefore=semaphore_before,actualSemaphoresAfter=semaphore_after,originalRefusalMessage=str(error)))
            else:raise AssertionError('Live actual IPC child was accepted as retired')
        parent.send('go');assert parent.poll(5)
        returned=parent.recv();assert returned==('returned',process.pid,1)and f.clock.value==1
        parent.close();process.join(5)
        assert process.exitcode==0 and not process.is_alive()
        binding=next(row['kernel']for row in _ACTIVE.spawn.records if row['role']=='actor')
        assert binding['pid']==process.pid and absent(process.pid)
        _ACTIVE.exitcode=process.exitcode;process.close()
        return dict(actualReady=ready,actualReturned=returned,actualSharedValue=f.clock.value,actualActorAbsent=True)
    finally:
        # No signal/terminate rescue is a positive cleanup. The outer owns any
        # still-live child after a failed case and records nongreen forced drain.
        for owner in(parent,child):
            if not owner.closed:owner.close()

class Runtime:
    def __init__(self,root,plan,input_path,finder,save,file_phase):
        self.file_phase=file_phase;self.case_root=Path(root);self.plan=plan;self.input=Path(input_path);self.finder=finder;self.record=save
        self.saved=[];self.connections=[];self.process=None;self.ready=None;self.exitcode=None;self.fixture=None
        self.negative_rows=[];self.finalizer_returns=[];self.finalizer_errors=[];self.semaphores=[];self.finished=False;self.installed=False
        self.original_registry=util._finalizer_registry;assert not self.original_registry
        self.original_heap=heap.BufferWrapper._heap;self.fresh_heap=heap.Heap()
        assert not self.fresh_heap._arenas
        self.arena=OwnedArenaConfiguration(self.case_root,heap,Paired.__init__)
        self.ipc=ActualIPCCapacities(connection,tracker,{},None)
        self.spawn=GuardedOriginalSpawn(util_module=util,spawn_module=spawn,popen_module=popen,tracker_module=tracker,
            actor_function=actor,paired_class=Paired,run_open_function=run_open,
            guard_path=Path(plan['controllerRoot'])/'mp_child_guard.py',guard_pin=file_pin(Path(plan['controllerRoot'])/'mp_child_guard.py'),
            policy_path=self.input,policy_pin=file_pin(self.input),owned_root=Path(plan['controllerRoot']),
            actor_roots=roots,save_row=save_original,transport_scope=transport_scope)
        modules=dict(connection=connection,heap=heap,popen=popen,spawn=spawn,tracker=tracker,util=util)
        self.ports=Ports(Path(plan['controllerRoot']),self.ipc,modules,parent=True,transport=dict(protected=[self.input,*map(Path,plan['sourceAndBinaryPins'])]),bridge=lambda:self.spawn)
        self.monitor=LocalMonitor()
        self.monitor.add(heap.Arena.__init__,start=self.arena.begin,returned=lambda frame,value:self.arena.returned(frame))
        self.monitor.add(connection.Pipe,returned=self.pipe_return)
        self.monitor.add(tracker.ResourceTracker._launch,returned=self.tracker_return)
        self.monitor.add(synchronize.SemLock.__init__,returned=self.sem_return)
        self.monitor.add(util.Finalize.__call__,returned=self.finalized,unwind=self.finalizer_failed)
        self.original_finalizer=FunctionBinding(util._run_finalizers)
    def save(self,name,body):
        assert '/'not in name and name.endswith('.json')
        self.record(self.case_root.name+'-'+name,body);self.saved.append(name)
    def transport(self):
        assert self.installed
        return dict(caseName=self.case_root.name,caseRoot=str(self.case_root),mode=None if self.fixture is None else self.fixture.mode,
            actualArenaInodes=[[row['device'],row['inode']]for unused,unused2,row in self.arena.arenas],
            actualSemaphores=[{k:v for k,v in row.items()if k!='owner'}for row in self.semaphores],numericEndpoints=[],
            actorFunction='mp_core.actor',parentCreatorRole='genuine-stdlib-utility-not-Tablet',expectedUnpickles=2)
    def pipe_return(self,frame,value):
        assert type(value)is tuple and len(value)==2
        for owner in value:self.ipc.register_parent_connection(owner,actual_pipe_frame=frame,pipe_binding=self.ports.pipe_ctor,observed_socket_pair=self.ports.socket_rows)
    def tracker_return(self,frame,value):
        self.ipc.bind_tracker_return(frame)
        row=next(row for row in self.spawn.records if row['role']=='tracker')
        assert tracker._resource_tracker._pid==row['kernel']['pid']
    def sem_return(self,frame,value):
        assert frame.f_code is synchronize.SemLock.__init__.__code__ and frame.f_globals is vars(synchronize)
        owner=frame.f_locals['self'];sem=owner._semlock;assert sem.name is not None
        path=Path('/dev/shm')/('sem.'+sem.name.lstrip('/'));info=path.lstat();assert info.st_uid==os.geteuid()
        self.semaphores.append(dict(owner=owner,path=str(path),name=sem.name,device=info.st_dev,inode=info.st_ino,mode=info.st_mode))
    def finalized(self,frame,value):self.finalizer_returns.append(dict(actualKey=repr(frame.f_locals['self']._key),returned=True))
    def finalizer_failed(self,frame,error):self.finalizer_errors.append(dict(type=type(error).__name__,message=str(error)))
    def install(self):
        global _ACTIVE
        assert _ACTIVE is None and not self.installed and heap.BufferWrapper._heap is self.original_heap
        _ACTIVE=self;heap.BufferWrapper._heap=self.fresh_heap
        self.arena.install();self.ipc.install();self.ports.install();self.monitor.install();self.spawn.install();self.installed=True
    def execute(self,mode):
        assert self.installed and self.fixture is None
        self.fixture=Paired(self.case_root,mode);self.fixture.boundary.check()
        result=run_open(self.fixture)
        self.require_retired();self.save('actual-original-return.json',result);return result
    def require_retired(self):
        assert self.process is not None and self.ready is not None
        actors=[row['kernel']for row in self.spawn.records if row['role']=='actor'];assert len(actors)==1
        assert absent(actors[0]['pid']), 'Actual actor remains live; no resource retirement claim'
        assert self.exitcode==0 and all(owner.closed for owner in self.connections)
    def finish(self):
        global _ACTIVE
        assert self.installed and not self.finished and _ACTIVE is self
        errors=[];receipt=dict(status='FAIL',actualCaseRoot=str(self.case_root),featureQualified=False)
        def check(label,fn):
            try:receipt[label]=fn()
            except BaseException as error:errors.append(dict(label=label,type=type(error).__name__,message=str(error)))
        def retire():
            self.require_retired();self.original_finalizer.guard();self.original_finalizer.function()
            assert util._finalizer_registry is self.original_registry and not self.original_registry and not self.finalizer_errors
            assert len(self.semaphores)==1 and all(not Path(row['path']).exists()for row in self.semaphores)
            resource=tracker._resource_tracker;pid=resource._pid
            original=next(row['kernel']for row in self.spawn.records if row['role']=='tracker')
            assert pid==original['pid'];resource._stop(wait_timeout=2)
            assert absent(pid)and resource._pid is None and resource._fd is None and resource._exitcode==0 and not getattr(resource,'_waitpid_timed_out',False)
            actual_pipe_retirements=[]
            for pipe in self.ports.pipe_rows:
                try:
                    actual=fd_row(pipe['fd'])
                    state='SAME_ORIGINAL_FIFO'if actual==pipe['identity']else'REUSED_DIFFERENT_IDENTITY'
                    row=dict(pipe,afterState=state,actualAfter=actual)
                except OSError as error:
                    assert error.errno==errno.EBADF
                    row=dict(pipe,afterState='EBADF',actualErrno=error.errno)
                actual_pipe_retirements.append(row)
            assert actual_pipe_retirements and all(row['afterState']!='SAME_ORIGINAL_FIFO'for row in actual_pipe_retirements)
            return dict(actualOriginalPipeRetirements=actual_pipe_retirements,actorOriginalExit0=True,actualTrackerPID=pid,actualTrackerExitCode=resource._exitcode,trackerStatAbsent=True,
                originalSemaphoreNamesAbsent=True,actualSemaphoreRows=[{k:v for k,v in row.items()if k!='owner'}for row in self.semaphores],
                originalFinalizerReturns=self.finalizer_returns,originalFinalizerErrors=self.finalizer_errors,killOrSignalUsed=False)
        check('originalRetirement',retire)
        check('originalSpawnPort',self.spawn.restore)
        check('monitor',self.monitor.restore)
        check('arenaDirectory',self.arena.restore)
        check('osPorts',self.ports.restore)
        check('ipc',self.ipc.finish)
        assert heap.BufferWrapper._heap is self.fresh_heap;heap.BufferWrapper._heap=self.original_heap
        # Strongly retain both actual mmap and Heap objects until parent exits.
        # The runner's dynamic FD set records them; the outer proves discharge.
        receipt['processLifetimeArenas']=[dict(row)for unused,unused2,row in self.arena.arenas]
        receipt['processLifetimeFDsClosedInsideParent']=False;receipt['actualNegativeRows']=self.negative_rows
        check('ownFilesystemPhaseResumed',self.file_phase.resume)
        receipt['errors']=errors;receipt['status']='PASS'if not errors else'FAIL'
        self.save('actual-retirement.json',receipt);self.finished=True;self.installed=False;_ACTIVE=None
        assert not errors,errors
        return receipt
