"""Pure reopened Profile9 End3 validation, never a new query or retry."""
from adapters.native_feature_observation import need,exact
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same,unpack
from feature_journeys import terminal
from feature_journeys.retirement_receipts import binding_from_context
from ios.adapters.emote_callback_terminal import IOSEmotePostControllerCallbackFeature

def completed(flow,seal):
    need(type(flow)is IOSEmotePostControllerCallbackFeature and flow.role=='primary');terminal.sealed(seal)
    path=flow.store.path.with_name('ios-emote-primary-'+flow.run+'-post9-end.json')
    raw=PrivateFeatureState(path).read();need(type(raw)is dict and raw.get('iosEmotePost9EndArchiveVersion')==2
        and raw.get('runId')==flow.run and same(raw.get('seal'),seal))
    rows=unpack(raw['payload']);need(len(rows)==1 and rows[0]['phase']=='complete'and rows[0]['pending']is None)
    from ios.adapters.emote_post9_entry import finish
    original=finish(flow,seal)
    exact(original,{'iosEmotePostControllerEndVersion','terminalEnd','profile9FamilyOriginals','nativeFileRetirementOriginalSha256',
        'retainedResponseFileDuty','responseFileRetirementOriginals','completeOriginalArchiveSha256','nativeQualified','deviceQualified','wholeQualified'})
    need(type(original['iosEmotePostControllerEndVersion'])is int and original['iosEmotePostControllerEndVersion']==3
        and all(original[k]is False for k in('nativeQualified','deviceQualified','wholeQualified')))
    exact(original['responseFileRetirementOriginals'],{'primary','actor'})
    for role,value in original['responseFileRetirementOriginals'].items():
        need(value['iosEmoteResponseRetirementVersion']==1 and value['role']==role and value['runId']==flow.run
            and same(binding_from_context(value['binding']),original['terminalEnd']['roles'][role]['binding']))
    terminal.ended(original['terminalEnd'],seal)
    for role in ('primary','actor'):
        binding=original['responseFileRetirementOriginals'][role]['binding'];scope={key:item for key,item in binding.items()if key!='processIdentity'}
        selector=flow.selector if role=='primary'else flow.actor_selector
        flow.runtime.adapter._retired_candidate_scope(selector,scope)
    return dict(stage='finish',end=original['terminalEnd'])

def verify(flow,call,result):
    call=terminal.arguments('emotes',call);need(call['stage']=='finish'and call['runId']==flow.run)
    exact(result,{'stage','end'});need(result['stage']=='finish');terminal.ended(result['end'],call['seal'])
    actual=completed(flow,call['seal']);need(same(actual,result));return actual
