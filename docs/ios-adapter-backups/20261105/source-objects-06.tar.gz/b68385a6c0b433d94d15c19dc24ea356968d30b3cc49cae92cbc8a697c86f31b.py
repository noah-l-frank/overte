"""Declared native grammar models for once-input original decoding only.

Packets/manager/code/lifetimes are explicit models, with deterministic real
fixture PCM bytes. No C++/Qt object, SDK, native playback, microphone/route,
physical output, acoustic signal, device or whole Audio claim is exercised.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib
import unittest
from adapters.normal_ui import NativeUIError
from ios.adapters import audio_once_cue_source as contract
from ios.adapters.audio_once_cue_signal import input_id,input_pcm

RUN='1'*32
TICKET='2'*32
INSTANCE='3'*32
ROOT='http://127.0.0.1:8765/feature-fixture/v1/runs/'+RUN+'/'
EPOCH=1700000000000
PID=31


class AudioOnceCueSourceTests(unittest.TestCase):
    def request(self,operation='observe',kind='cue'):
        cue=input_id(RUN,TICKET,kind)
        value=dict(schemaVersion=1,commandId='ios-'+(cue if operation=='claim' else '6'*32),action=contract.ACTION,
            operation=operation,instance=INSTANCE,runId=RUN,ticket=TICKET,cueId=cue,kind=kind)
        if operation=='claim':value['soundUrl']=contract.sound_url(ROOT,RUN,TICKET,kind)
        return value

    def caller(self,method,sequence,invoked):
        return dict(callerVersion=1,method=method,sequence=sequence,invokedEpochMs=EPOCH+invoked,
            manager=dict(instance='4'*32,assigned=True,url='file:///controlled-probe.js',loadGeneration=1,assignedEpochMs=EPOCH+10),
            code=dict(submitted=True,encoding='utf-16le-code-units',codeUnits=1,sha256='5'*64,submittedEpochMs=EPOCH+20))

    def packet(self,operation='observe',kind='cue'):
        request=self.request(operation,kind);pcm=input_pcm(RUN,TICKET,kind)
        value={name:False for name in contract.BOOLEANS}
        value.update({name:0 for name in (*contract.COUNTERS,*contract.RECEIVERS,*contract.EPOCHS)})
        value.update(iosAudioOnceCueVersion=1,**{key:request[key] for key in ('commandId','operation','instance','runId','ticket','cueId','kind')},
            soundUrl=contract.sound_url(ROOT,RUN,TICKET,kind),sequence=1,requestedEpochMs=EPOCH+245,capturedEpochMs=EPOCH+250,processId=PID,
            caller=self.caller('featureIOSAudioOnceCue',1,100),playCaller=self.caller('playSound',2,125),queryCaller=self.caller('featureIOSAudioOnceCue',3,240),
            complete=True,consumed=True,managerReturned=True,injectorBorn=True,wrapperBorn=True,finished=True,
            injectorLive=True,wrapperLive=True,resourceRequested=True,resourceWrapperBorn=True,resourceWrapperLive=True,
            resourceReady=True,resourceCacheObjectLive=True,resourcePCMStillHeld=True,
            observedInputPCMKnown=True,observedInputPCMStillHeld=True,claimedEpochMs=EPOCH+110,consumedEpochMs=EPOCH+130,
            bornEpochMs=EPOCH+140,finishedEpochMs=EPOCH+200,finishedCallbacks=1,resourceReadyReceivers=1,
            pcmSha256=hashlib.sha256(pcm).hexdigest(),pcmChannels=1,pcmFrames=len(pcm)//2,pcmBytes=len(pcm))
        self.assertEqual(set(value),contract.FIELDS);return request,value

    def test_exact_model_input_pcm_and_actual_native_finish_fields_remain_unqualified(self):
        request,value=self.packet();original=deepcopy(value)
        result=contract.finished_input(value,request,PID,ROOT)
        self.assertEqual(value,result);self.assertIsNot(value,result);self.assertEqual(original,value)
        self.assertTrue(value['consumed'] and value['finished'])
        self.assertFalse(any(value[key] for key in contract.FLAGS))

    def test_deterministic_claim_id_kind_and_exact_fixture_url_refuse_foreign_inputs(self):
        claim=self.request('claim');contract.command(claim,ROOT)
        for field,replacement in [('cueId','a'*32),('kind','pattern'),('ticket','b'*32),('soundUrl',claim['soundUrl']+'?replay=1')]:
            with self.subTest(field=field),self.assertRaises(NativeUIError):contract.command(dict(claim,**{field:replacement}),ROOT)

    def test_pid_instance_and_freshness_refuse_foreign_current_native_source(self):
        request,value=self.packet()
        for changed in [dict(value,processId=PID+1),dict(value,instance='a'*32)]:
            with self.subTest(changedIdentity=True),self.assertRaises(NativeUIError):contract.validate(changed,request,PID,ROOT)
        with self.assertRaises(NativeUIError):
            contract.validate(value,request,PID,ROOT,clock=dict(processId=PID,instance=INSTANCE,capturedEpochMs=EPOCH+100000))

    def test_duplicate_callbacks_and_false_destroy_inventory_are_not_complete(self):
        request,value=self.packet()
        for changed in [dict(value,finishedCallbacks=2),dict(value,injectorDestroyed=True),dict(value,wrapperDestroyed=True),
                dict(value,resourceWrapperDestroyed=True),dict(value,finished=False)]:
            with self.subTest(changedInventory=True),self.assertRaises(NativeUIError):contract.validate(changed,request,PID,ROOT)

    def test_play_caller_must_match_original_manager_code_and_follow_claim_sequence(self):
        request,value=self.packet()
        for field,replacement in [('manager',dict(value['playCaller']['manager'],instance='a'*32)),
                ('code',dict(value['playCaller']['code'],sha256='b'*64)),('sequence',1)]:
            changed=deepcopy(value);changed['playCaller'][field]=replacement
            with self.subTest(field=field),self.assertRaises(NativeUIError):contract.validate(changed,request,PID,ROOT)

    def test_foreign_native_input_pcm_hash_cannot_qualify_expected_fixture(self):
        request,value=self.packet();value['pcmSha256']='f'*64
        contract.validate(value,request,PID,ROOT)
        with self.assertRaises(NativeUIError):contract.finished_input(value,request,PID,ROOT)

    def test_object_release_preserves_explicit_sound_cache_and_pcm_duty(self):
        request,value=self.packet('release')
        value.update(injectorLive=False,wrapperLive=False,resourceWrapperLive=False,injectorDestroyed=True,
            wrapperDestroyed=True,resourceWrapperDestroyed=True,destroyCallbacks=1,wrapperDestroyCallbacks=1,
            resourceDestroyCallbacks=1,destroyedEpochMs=EPOCH+220,retireAttempted=True,released=True,resourceReadyReceivers=0)
        result=contract.retired_objects(value,request,PID,ROOT)
        self.assertTrue(result['objectsRetired'] and result['cacheObjectStillLive'] and result['resourcePCMStillHeld'] and result['inputPCMStillHeld'])
        self.assertFalse(result['cacheAbsenceQualified'])
        with self.assertRaises(NativeUIError):contract.validate(dict(value,soundCacheAbsenceQualified=True),request,PID,ROOT)

    def test_original_claim_lifetime_and_pcm_are_monotone_without_rearm(self):
        request,previous=self.packet();current=deepcopy(previous)
        current.update(sequence=2,requestedEpochMs=EPOCH+251,capturedEpochMs=EPOCH+260)
        contract.validate(current,request,PID,ROOT,previous=previous)
        for field,replacement in [('complete',True),('consumed',False),('pcmSha256','a'*64),('claimedEpochMs',EPOCH+111)]:
            old=deepcopy(previous);new=deepcopy(current)
            if field=='complete':old['complete']=False
            new[field]=replacement
            with self.subTest(field=field),self.assertRaises(NativeUIError):contract.follow(old,new)

    def test_unknown_keys_numeric_booleans_and_ack_only_shapes_are_rejected(self):
        request,value=self.packet()
        for changed in [dict(value,unexpected=True),dict(value,sequence=True),dict(value,finished=1),
                dict(iosAudioOnceCueVersion=1,commandId=request['commandId'],available=False)]:
            with self.subTest(changedGrammar=True),self.assertRaises(NativeUIError):contract.validate(changed,request,PID,ROOT)

    def test_live_objects_null_return_and_incomplete_provenance_cannot_supply_retirement_or_finish(self):
        request,value=self.packet('release')
        with self.assertRaises(NativeUIError):contract.retired_objects(value,request,PID,ROOT)
        changed=deepcopy(value);changed.update(released=True,retireAttempted=True,returnedNull=True)
        with self.assertRaises(NativeUIError):contract.validate(changed,request,PID,ROOT)
        request,value=self.packet();value['complete']=False
        contract.validate(value,request,PID,ROOT)
        with self.assertRaises(NativeUIError):contract.finished_input(value,request,PID,ROOT)
