from pathlib import Path
import ast,hashlib,json,shutil
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-canonical4-legacy18-root-preparation-20261029/64-canonical-child4';FIX=T/'lifecycle-original-owner-normal-child-host-model-http-loop-overlay-20261029';P=T/'lifecycle-original-owner-canonical4-sync-host-root-preparation-20261029';S=P/'66-canonical-child4';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not(B/'root-run-first').exists()
for n,d in json.loads((FIX/'freeze.json').read_text())['files'].items():assert H(FIX/n)==d
P.mkdir(mode=0o700);S.mkdir(mode=0o700)
for n,d in json.loads((B/'freeze.json').read_text())['files'].items():
 assert H(B/n)==d;dest=S/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/n,dest)
shutil.copyfile(FIX/'candidate/normal_child_fixture.py',S/'normal_child_fixture.py');shutil.copyfile(FIX/'test-only1.diff',S/'test-only-sync-host-replies.diff')
plan=json.loads((S/'run-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_CANONICAL4_SYNC_HOST_MODEL_REPLIES');plan['privateFiles']['normal_child_fixture.py']=H(S/'normal_child_fixture.py');(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
stage=json.loads((S/'source-manifest.json').read_text());changes=[]
for row in stage['sourcePaths']:
 rel=row['path'];actual=H(R/rel)
 if rel in stage['sourceDeltaPaths'] or rel in ['tests/device/contract-versions.json','tests/device/validate_contract_versions.py']:
  # Preserve exact reviewed FUTURE Source2/own3 candidates. Root has not PUB.
  row['observedPublicSHA256']=actual;continue
 if actual!=row['candidateSHA256']:
  dest=S/'actual-current-dependency/repo'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,dest);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(dest),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
stage.update(stage=66,name=S.name,status='PRIVATE_UNRUN_CANONICAL4_SYNC_HOST_MODEL_REPLIES');stage['orderedParentFreezes'][FIX.name]=H(FIX/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
(S/'clone-provenance-sync-host.json').write_text(json.dumps(dict(parent64Freeze=H(B/'freeze.json'),overlayFreeze=H(FIX/'freeze.json'),onlyModelFileChanged='normal_child_fixture.py',source2Unchanged=True,model4AssertionsUnchanged=True,originalKeeperLoopTaskUnchanged=True,noSDKObjectsInPureModelReplies=True,caseCount=4,initialSeconds=90,killAfter=5,expectedRealRoots=12,totalPriorPinnedFiles=3316,old64and65UnrunPreserved=True,otherDependencyChanges=changes,executed=False),indent=2)+'\n')
(S/'README-sync-host.txt').write_text('Root66 FIRSTcanonical4/90+kill5/12realTD, exactsameassertions/Source2/own3/RAISEobserver/3316priorpins asUNRUN64. Only fixture separates pureHostSDKmodel replies (syncHTTPhandler) from ACTUALKeeperRPCs (unchanged originalLoop+originalrequestTasks). Prevents synchronous factory GET self-deadlock without newloop/broker/session or anySDKobject movedthread. Source2 stillfuture59f5/791b, own3future5ce96d/659a7c; RootPUB/preimport actualmaps required. Old64/65 remainUNRUNfrozen. Noagentimports/tests/PUB.\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(stage=str(S),parentFreeze=H(P/'freeze.json'),stageFreeze=H(S/'freeze.json'),fixtureSHA256=H(S/'normal_child_fixture.py'),overlayFreeze=H(FIX/'freeze.json'),changes=changes),indent=2))
