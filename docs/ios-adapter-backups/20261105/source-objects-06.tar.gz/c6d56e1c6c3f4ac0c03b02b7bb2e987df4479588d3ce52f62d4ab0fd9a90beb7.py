"""Genuine constructor for the explicitly lower modeled checkpoint endpoint.

Existing public SceneEndpoint.send supplies its original independent world
readers. No Parsed/live owner is fabricated before the first model exists.
The actual SDK/Qt/native/render/domain interfaces remain host models.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import uuid,sys,types,json
from ios.adapters.normal_input import NativeInput
from ios.adapters.assets_budget import check
from adapters.native_feature_observation import NativeFeatureObservation,need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters import create_state,emote_world,assets_model_origin
from ios.adapters import assets_model_origin as origin
from ios.self_tests.assets_picker_fixture import BINDING
from ios.adapters.assets_checkpoint_scene import AssetsCheckpointScene
from ios.self_tests.assets_peer_fixture import SceneEndpoint
from ios.self_tests.assets_whole_observation_fixture import Fixture as OriginalFixture
from ios.self_tests.assets_picker_fixture import RUN


class CheckpointEndpoint:
    send=SceneEndpoint.send

    def __init__(self,fixture,root,role,binding,lock):
        need(role in('primary','actor-primary','actor'))
        self.fixture,self.boundary,self.role=fixture,fixture.boundary,role
        self.root=Path(root);need(self.root.is_dir());self.lock=lock;lock.assert_held()
        self.world=self.boundary.peer if role=='actor'else self.boundary
        self.pid=43 if role=='actor'else 42;self.binding=deepcopy(binding)
        need(self.binding['processIdentity']==str(self.pid))
        self.raw={};self.counts=dict(clock=0,state=0,domain=0,origin=0);self.queries=[];self.good=True
        self.instance=uuid.uuid4().hex;self.domain_instance=uuid.uuid4().hex
        self.monotonic=self.boundary.monotonic;self.epoch_ms=self.world.clock


class CheckpointNativeInput(NativeInput):
    """A genuine lower transport receiver, never a manufactured HTTP owner."""
    def __init__(self,original,guard):
        need(isinstance(original,NativeInput) and callable(guard))
        self.original=original;self.guard=guard;self.failed=False
        self.original_type=type(original);self.original_mro=self.original_type.__mro__
        self.ports=tuple(self.hold(getattr(original,name),original)for name in('capture','deliver'))
        self.guard_port=self.hold(guard,None);self.budget_port=self.hold(check,None)
        self.monotonic,self.sleep,self.native_epoch_ms=original.monotonic,original.sleep,original.native_epoch_ms
        self.process,self.instance=original.process,original.instance
        self.last_receipt=None
        self.bound()

    @staticmethod
    def hold(function,receiver):
        if receiver is not None:
            need(type(function)is types.MethodType and function.__self__ is receiver)
            function=function.__func__
        need(type(function)is types.FunctionType)
        module=sys.modules[function.__module__]
        need(function.__globals__ is vars(module) and Path(function.__code__.co_filename)==Path(module.__file__))
        defaults=function.__defaults__;keywords=function.__kwdefaults__;closure=function.__closure__
        return(function,function.__code__,function.__globals__,module,module.__file__,defaults,tuple(defaults or()),
            keywords,tuple((keywords or{}).items()),closure,tuple(cell.cell_contents for cell in closure or()))

    @staticmethod
    def verify(port):
        fn,code,namespace,module,path,defaults,values,keywords,items,closure,cells=port
        need(fn.__code__ is code and fn.__globals__ is namespace and namespace is vars(module)
            and sys.modules.get(fn.__module__)is module and module.__file__==path
            and Path(code.co_filename)==Path(path) and fn.__defaults__ is defaults
            and len(fn.__defaults__ or())==len(values) and all(a is b for a,b in zip(fn.__defaults__ or(),values))
            and fn.__kwdefaults__ is keywords and tuple((keywords or{}))==tuple(key for key,value in items)
            and all(keywords[key]is value for key,value in items) and fn.__closure__ is closure
            and len(closure or())==len(cells) and all(cell.cell_contents is value for cell,value in zip(closure or(),cells)))

    def bound(self):
        # Guard callbacks can change a real method; validate on BOTH sides.
        for stage in(0,1):
            need(not self.failed and type(self.original)is self.original_type and self.original_type.__mro__ is self.original_mro)
            for name,port in zip(('capture','deliver'),self.ports):
                actual=getattr(self.original,name)
                need(type(actual)is types.MethodType and actual.__self__ is self.original and actual.__func__ is port[0])
                self.verify(port)
            need(self.guard is self.guard_port[0] and check is self.budget_port[0])
            self.verify(self.guard_port);self.verify(self.budget_port)
            need(self.monotonic is self.original.monotonic and self.sleep is self.original.sleep
                and self.native_epoch_ms is self.original.native_epoch_ms)
            if stage==0:check();need(self.guard()is not False);check()

    def capture(self):
        self.bound();original=self.original
        missing=object();previous=vars(original).get('observe_intent',missing)
        intent=getattr(self,'observe_intent',getattr(original,'observe_intent',None));need(intent is None or callable(intent))
        def observed(query):
            self.bound()
            if intent is not None:intent(query)
            self.bound()
        original.observe_intent=observed
        try:
            result=self.ports[0][0](original)
        finally:
            if vars(original).get('observe_intent',missing)is observed:
                if previous is missing:del original.observe_intent
                else:original.observe_intent=previous
            else:self.failed=True
        self.bound();self.last_receipt=deepcopy(original.last_receipt)
        self.process,self.instance=original.process,original.instance
        return result

    def deliver(self,command,*,before_send=None):
        self.bound();need(before_send is None or callable(before_send))
        def final():
            self.bound()
            if before_send is not None:need(before_send()is not False)
            self.bound()
        result=self.ports[1][0](self.original,command,before_send=final)
        self.bound();self.last_receipt=deepcopy(self.original.last_receipt)
        self.process,self.instance=self.original.process,self.original.instance
        return result


class Fixture(OriginalFixture):
    def ports(self,action):
        b=self.boundary
        def checked():action.guard();return True
        clock=NativeFeatureObservation(b.native_clock.send,b.native_clock.original,b.clock,checked,42,
            ios=True,monotonic=b.monotonic,sleep=b.sleep)
        files=b.files_native();replies=b.reads.native()
        for native in (files,replies):
            previous=native.guard
            def guarded(previous=previous):checked();need(previous() is not False);checked();return True
            native.guard=guarded
        def readers(clock):return b.model_readers(clock)
        def origin_reader(clock):
            raw=['']
            def send(query):origin.command(query);raw[0]=json.dumps(b.origin(query))
            return origin.IOSAssetsModelOrigin(send,lambda:raw[0],lambda:clock.read(clock.sequence)['capturedEpochMs'],checked,42,
                monotonic=b.monotonic,sleep=b.sleep)
        observer=SimpleNamespace(sleep=b.sleep,create_state=lambda clock:readers(clock)[0],create_work=lambda clock:readers(clock)[1],assets_model_origin=origin_reader)
        return dict(binding=deepcopy(BINDING),native=CheckpointNativeInput(b.native_input(),checked),clock_source=clock,
            files=files,replies=replies,observer=observer,check=checked)

    def ordinary_input(self,index):
        # Preserve the lower self.input protocol object. The original class
        # dispatcher is called directly, once, with its actual receiver/index.
        return OriginalFixture.input(self,index)

    def scene_parts(self,observer,selector,role,lock):
        action,episode=observer.action,observer.episode;subject='actor'if role=='actor'else'primary'
        info=self.selected.context['roles'][subject]
        root=Path(info['stateRoot'])if episode is None else Path(episode.descriptor['directories'][subject]['stateRoot']['path'])
        need(selector==info['target'])
        expected=self.a.h.locks[subject]if episode is None else episode.locks[subject]
        need(lock is expected);lock.assert_held();key=(action.index,role)
        if key not in self.scene_endpoints:
            self.scene_endpoints[key]=CheckpointEndpoint(self,root,role,info['binding'],lock)
        endpoint=self.scene_endpoints[key]
        need(endpoint.lock is lock and endpoint.root==root and endpoint.role==role)
        def guarded():action.guard();lock.assert_held();return self.boundary.live
        native=NativeFeatureObservation(lambda query:endpoint.send('clock',query),lambda:endpoint.raw.get('clock',''),
            endpoint.world.clock,guarded,endpoint.pid,ios=True,native_clock_bound=True,
            monotonic=endpoint.monotonic,sleep=self.boundary.sleep)
        def reader(cls,kind):
            return cls(lambda query:endpoint.send(kind,query),lambda:endpoint.raw.get(kind,''),endpoint.world.clock,
                guarded,endpoint.pid,monotonic=endpoint.monotonic,sleep=self.boundary.sleep)
        source=AssetsCheckpointScene(PrivateFeatureState(root/('ios-assets-checkpoint-'+RUN+'-a'+str(action.index)+'-'+role+'-scene.json')),
            endpoint.binding,RUN,role,lock,guarded,native=native,state=reader(create_state.IOSCreateState,'state'),
            domain=reader(emote_world.IOSEmoteWorld,'domain'),origin=reader(assets_model_origin.IOSAssetsModelOrigin,'origin'),
            epoch_ms=endpoint.epoch_ms,monotonic=endpoint.monotonic,selection=self.selected,action=action,episode=episode)
        return dict(check=guarded,scene=source)
