from pathlib import Path
import ast,hashlib,json,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-canonical-producer4-legacy18-root-preparation-20261029/70-canonical-child4';OLD=T/'lifecycle-original-owner-canonical-producer4-legacy18-root-preparation-20261029/71-legacy-hold18';P=T/'lifecycle-original-owner-legacy18-after-canonical70-root-preparation-20261029';S=P/'72-legacy-hold18';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not(OLD/'root-run-first').exists();report=json.loads((B/'root-run-first/report.json').read_text());summary=json.loads((B/'actual-source-raise-summary-first.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==47 and report['allPinsEqual'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses'];assert summary['ownedToolFreed'] and not summary['dropped'] and not summary['writeFailures']
P.mkdir(mode=0o700);S.mkdir(mode=0o700)
for n,d in json.loads((OLD/'freeze.json').read_text())['files'].items():
 assert H(OLD/n)==d;dest=S/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OLD/n,dest)
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((B/'prior-retained-original-pins.json').read_text());assert sum('sha256' in v for v in prior.values())==3396;root=B/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==47
for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
for n in ['report.json','thread-report.json','process-binding.json']:p=B/'root-run-first'/n;prior[str(p)]=pin(p)
for n in ['actual-source-raise-events-first.jsonl','actual-source-raise-summary-first.json']:p=B/n;prior[str(p)]=pin(p)
assert sum('sha256' in v for v in prior.values())==3448;(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n');stage=json.loads((S/'source-manifest.json').read_text());changes=[]
for row in stage['sourcePaths']:
 rel=row['path'];actual=H(R/rel)
 if actual!=row['candidateSHA256']:
  dest=S/'actual-current-dependency/repo'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,dest);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(dest),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
stage.update(stage=72,name=S.name,status='PRIVATE_UNRUN_FIRST_DEFAULT1_LEGACY18_AFTER70');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');(S/'clone-provenance-after70.json').write_text(json.dumps(dict(parent71UnrunFreeze=H(OLD/'freeze.json'),actual70ERRORReportSHA256=H(B/'root-run-first/report.json'),actual70OriginalFiles=47,totalPriorPinnedFiles=3448,actualOldOriginalFiles=3382,actualReports=48,actualDiagnosticFiles=18,cases=18,initialSeconds=90,killAfterSeconds=5,realRoots=18,noRAISE=True,sourceAndCasesUnchanged=True,otherSourceChanges=changes,executed=False),indent=2)+'\n');(S/'README-after70.txt').write_text('Root72 FIRSTsameLegacy18/90+kill5/18realTD, noMonitor/noNewNative4fixture. Original65/71UNRUNpreserved. PublicSource59f5/791b/current5ce/659 unchanged. All66/67/68/69/70failedOriginals/reports retained;47new70files+3reports+2diag→3448priorfiles (3382originals+48reports+18diag). Actual70firstnew4 reachedheld/Up/quiet butstrict1.5failed; noComplete/fixclaim andnoNative4repeat here. Noagentimports/tests/PUB.\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(stage=str(S),parentFreeze=H(P/'freeze.json'),stageFreeze=H(S/'freeze.json'),changes=changes,priorFiles=3448),indent=2))
