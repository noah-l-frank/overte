"""Private Qt source assembly only; no compiler/import/test or public edits."""
from pathlib import Path
import ast,difflib,hashlib,json

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
P2=OUT.with_name('chat-qml-cache-object-transport-proposal-20261027')
P1=OUT.with_name('chat-qml-cache-originals-proposal-20261027')
refs=json.loads((P1/'reviewed-reference-originals.json').read_text())
newrefs=json.loads((OUT/'references.json').read_text())['newOfficialOriginals']
sha=lambda data:hashlib.sha256(data).hexdigest()
original={path:(ROOT/row['path']).read_bytes() for path,row in refs.items()}
assert all(sha(original[path])==row['sha256'] for path,row in refs.items())
base={path:(P2/'qt-source'/path).read_text() for path in refs}
for row in newrefs:
    data=(ROOT/row['privatePath']).read_bytes();assert sha(data)==row['sha256']
    original[row['path']]=data;base[row['path']]=data.decode()
current=dict(base)
def replace(path,before,after):
    assert current[path].count(before)==1,(path,before[:90]);current[path]=current[path].replace(before,after,1)
common='qtdeclarative/src/qml/common/qv4compileddata_p.h'
cpp='qtdeclarative/src/qml/common/qv4compileddata.cpp'
executable='qtdeclarative/src/qml/jsruntime/qv4executablecompilationunit_p.h'
resolved='qtdeclarative/src/qml/jsruntime/qv4resolvedtypereference_p.h'
script='qtdeclarative/src/qml/qml/qqmlscriptdata_p.h'
scriptcpp='qtdeclarative/src/qml/qml/qqmlscriptdata.cpp'
blob='qtdeclarative/src/qml/qml/qqmlscriptblob.cpp'
typehead='qtdeclarative/src/qml/qml/qqmltypedata_p.h'
typecpp='qtdeclarative/src/qml/qml/qqmltypedata.cpp'
replace(common,'#define QT_OVERTE_E2E_QML_CACHE_ORIGINALS 1\n','#define QT_OVERTE_E2E_QML_CACHE_ORIGINALS 1\n#define QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS 1\n')
replace(common,'#include <atomic>\n','#include <atomic>\n#include <memory>\n')
opaque='''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
struct DependencyDiagnosticState;
struct ScriptDiagnosticState;
Q_QML_EXPORT std::shared_ptr<ScriptDiagnosticState> ensureScriptDiagnostic(std::shared_ptr<ScriptDiagnosticState> &slot) noexcept;
Q_QML_EXPORT QString scriptDiagnosticIdentity(const std::shared_ptr<ScriptDiagnosticState> &state) noexcept;
Q_QML_EXPORT void publishScriptDiagnostic(const std::shared_ptr<ScriptDiagnosticState> &state,const QVariantMap &original) noexcept;
Q_QML_EXPORT void retireScriptDiagnostic(const std::shared_ptr<ScriptDiagnosticState> &state) noexcept;
Q_QML_EXPORT QVariantMap readScriptDiagnostic(const std::shared_ptr<ScriptDiagnosticState> &state,const QVariantMap &unit) noexcept;
#endif

'''
replace(common,'struct CompilationUnit final : public QQmlRefCounted<CompilationUnit>',opaque+'struct CompilationUnit final : public QQmlRefCounted<CompilationUnit>')
replace(common,'    Q_QML_EXPORT QVariantMap overteE2eCacheOriginalForCurrentUnit() const;','''    Q_QML_EXPORT QVariantMap overteE2eCacheOriginalForCurrentUnit() const;
    Q_QML_EXPORT QVariantMap overteE2eCodeIdentity() const noexcept;
    Q_QML_EXPORT QVariantMap overteE2eDependencyOriginal() const noexcept;
    mutable std::shared_ptr<DependencyDiagnosticState> overteE2eDependencyState;
    Q_QML_EXPORT std::shared_ptr<DependencyDiagnosticState> overteE2eDependencyToken() const noexcept;
    Q_QML_EXPORT void overteE2eInvalidateDependencies() noexcept;
    Q_QML_EXPORT void overteE2eRetireDependencies() noexcept;
    Q_QML_EXPORT void overteE2eCaptureDependencies() noexcept;''')
replace(common,'        overteE2eSourceReceipt.clear();','        overteE2eInvalidateDependencies();\n        overteE2eSourceReceipt.clear();')
replace(cpp,'#include <QtCore/qdir.h>','#include <QtCore/qdir.h>\n#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)\n#include <QtCore/qthread.h>\n#include <QtCore/qjsondocument.h>\n#include <algorithm>\n#endif')
replace(cpp,'QVariantMap CompilationUnit::overteE2eCacheOriginalForCurrentUnit() const',
        (OUT/'dependency_graph.cpp.txt').read_text()+'\nQVariantMap CompilationUnit::overteE2eCacheOriginalForCurrentUnit() const')
replace(cpp,'CompilationUnit::~CompilationUnit()\n{','CompilationUnit::~CompilationUnit()\n{\n#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)\n    overteE2eRetireDependencies();\n#endif')
replace(executable,'    QVariantMap overteE2eCacheOriginal() const','''    QVariantMap overteE2eCodeIdentity() const noexcept
    { return m_compilationUnit->overteE2eCodeIdentity(); }
    QVariantMap overteE2eDependencyOriginal() const noexcept
    { return m_compilationUnit->overteE2eDependencyOriginal(); }
    QVariantMap overteE2eCacheOriginal() const''')
replace(resolved,'    bool isSelfReference() const { return m_isSelfReference; }','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
    // Current product-owned identity only; no observer strong reference.
    const QV4::CompiledData::CompilationUnit *overteE2eCompilationUnitIdentity() const noexcept
    { return m_isSelfReference ? nullptr : m_compilationUnit.data(); }
#endif
    bool isSelfReference() const { return m_isSelfReference; }''')
replace(script,'    QQmlRefPointer<QV4::CompiledData::CompilationUnit> compilationUnit() const','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
    const QV4::CompiledData::CompilationUnit *overteE2eCompilationUnitIdentity() const noexcept
    { return m_precompiledScript.data(); }
    QString overteE2eScriptIdentity() const noexcept;
    std::shared_ptr<QV4::CompiledData::ScriptDiagnosticState> overteE2eScriptDiagnosticToken() const noexcept;
    QVariantMap overteE2eLastEvaluationOriginal() const noexcept;
#endif
    QQmlRefPointer<QV4::CompiledData::CompilationUnit> compilationUnit() const''')
replace(script,'    friend class QQmlScriptBlob;','''    friend class QQmlScriptBlob;
#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
    mutable std::shared_ptr<QV4::CompiledData::ScriptDiagnosticState> m_overteE2eScriptState;
    QVariantMap overteE2eBeginEvaluation(const QV4::ExecutableCompilationUnit *actual) noexcept;
    void overteE2eEndEvaluation(const QV4::ExecutableCompilationUnit *actual,
            const QVariantMap &before,bool evaluated,bool failed) noexcept;
#endif''')
replace(script,'    QV4::ReturnedValue scriptValueForContext(','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
    ~QQmlScriptData();
#endif
    QV4::ReturnedValue scriptValueForContext(''')
replace(script,'class QQmlContextData;','class QQmlContextData;\n#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)\nnamespace QV4 { class ExecutableCompilationUnit; }\n#endif')
replace(typehead,'    static Q_QML_EXPORT int overteE2eCacheObservationApiVersion();','''    static Q_QML_EXPORT int overteE2eDependencyObservationApiVersion();
    static Q_QML_EXPORT QVariantMap overteE2eDependencyOriginalForObject(
            const QObject *object,const QQmlComponent *component = nullptr);
    static Q_QML_EXPORT QVariantMap overteE2eCompilerInputOriginal(
            const QString &source,const QString &requested,const QString &resolved);
    static Q_QML_EXPORT int overteE2eCacheObservationApiVersion();''')
api='''int QQmlTypeData::overteE2eDependencyObservationApiVersion() { return 1; }
QVariantMap QQmlTypeData::overteE2eCompilerInputOriginal(
        const QString &source,const QString &requested,const QString &resolved)
{
    QT_TRY {
        auto value=overteE2eCompilerInput(source,requested,resolved);
        if (!value.isEmpty()) value.insert(QStringLiteral("sourceAfterEpochMs"),QDateTime::currentMSecsSinceEpoch());
        return value;
    } QT_CATCH (...) { QV4::OverteCacheOriginals::fail();return {}; }
}
QVariantMap QQmlTypeData::overteE2eDependencyOriginalForObject(
        const QObject *object,const QQmlComponent *component)
{
    QT_TRY {
        if (!QV4::OverteCacheOriginals::active() || !QCoreApplication::instance() || !object
                || object->thread()!=QThread::currentThread()) return {};
        QPointer<const QObject> weak(object);QPointer<const QQmlComponent> weakComponent(component);
        const auto *data=QQmlData::get(object);if (!data || !data->compilationUnit) return {};
        const auto *actual=data->compilationUnit.data();
        const auto identity=actual->overteE2eCodeIdentity();const auto executable=actual->overteE2eExecutableIdentity();
        if (identity.isEmpty() || executable.isEmpty() || (component && (component->thread()!=QThread::currentThread()
                || !component->isReady() || component->isError() || QQmlComponentPrivate::get(const_cast<QQmlComponent *>(component))
                    ->overteE2eCompilationUnitIdentity()!=actual))) return {};
        const auto graph=actual->overteE2eDependencyOriginal();
        if (graph.isEmpty() || !weak || (component && !weakComponent)) return {};
        const auto *current=QQmlData::get(object);
        if (!current || current->compilationUnit.data()!=actual || actual->overteE2eExecutableIdentity()!=executable
                || actual->overteE2eCodeIdentity()!=identity || (component
                    && QQmlComponentPrivate::get(const_cast<QQmlComponent *>(component))->overteE2eCompilationUnitIdentity()!=actual)) return {};
        return {{"qtOverteQmlObjectDependencyOriginalVersion",1},{"processId",QCoreApplication::applicationPid()},
            {"executableUnitId",executable},{"componentMatched",bool(component)},{"source",graph}};
    } QT_CATCH (...) { QV4::OverteCacheOriginals::fail();return {}; }
}

'''
replace(typecpp,'int QQmlTypeData::overteE2eCacheObservationApiVersion() { return 1; }',api+'int QQmlTypeData::overteE2eCacheObservationApiVersion() { return 1; }')
replace(typecpp,'void QQmlTypeData::done()\n{\n    assertTypeLoaderThread();','''void QQmlTypeData::done()
{
    assertTypeLoaderThread();
#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
    if (m_compiledData) m_compiledData->overteE2eInvalidateDependencies();
#endif''')
replace(typecpp,'        m_backupSourceCode = SourceCodeData();','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
        if (!isError() && m_compiledData) m_compiledData->overteE2eCaptureDependencies();
#endif
        m_backupSourceCode = SourceCodeData();''')
for assignment in ('    m_compiledData->resolvedTypes = resolvedTypeCache;','    m_compiledData->resolvedTypes = *resolvedTypeCache;'):
    replace(typecpp,assignment,'#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)\n    m_compiledData->overteE2eInvalidateDependencies();\n#endif\n'+assignment)
replace(blob,'#include <private/qqmlengine_p.h>','#include <private/qqmlengine_p.h>\n#include <private/qqmltypedata_p.h>')
replace(blob,'    QQmlRefPointer<QV4::CompiledData::CompilationUnit> unit;','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
    // The exact QString passed below, before the script branch clears it.
    const auto overteInput=QQmlTypeData::overteE2eCompilerInputOriginal(source,urlString(),finalUrlString());
#endif
    QQmlRefPointer<QV4::CompiledData::CompilationUnit> unit;''')
replace(blob,'    if (m_typeLoader->writeCacheFile()) {','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
    QT_TRY {
        if (QV4::OverteCacheOriginals::active() && !overteInput.isEmpty() && unit && unit->data
                && !unit->aotCompiledFunctions && unit->data->unitSize>=sizeof(QV4::CompiledData::Unit)
                && unit->data->unitSize<=4*1024*1024) {
            const auto *actual=unit->data;const auto generation=unit->overteE2eSourceGeneration;
            auto prefix=overteInput;prefix.insert(QStringLiteral("compilerUnitBytes"),qlonglong(actual->unitSize));
            prefix.insert(QStringLiteral("compilerUnitSha256"),QV4::OverteCacheOriginals::sha(actual,actual->unitSize));
            if (unit->data==actual && unit->overteE2eSourceGeneration==generation) unit->overteE2ePendingCompilerInput=prefix;
        }
    } QT_CATCH (...) { QV4::OverteCacheOriginals::fail(); }
#endif
    if (m_typeLoader->writeCacheFile()) {''')
replace(blob,'    if (auto cu = m_scriptData->compilationUnit()) {','''    if (auto cu = m_scriptData->compilationUnit()) {
#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
        cu->overteE2eInvalidateDependencies();
#endif''')
replace(blob,'        QQmlMetaType::registerInternalCompositeType(cu);','''        QQmlMetaType::registerInternalCompositeType(cu);
#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
        cu->overteE2eCaptureDependencies();
#endif''')
replace(scriptcpp,'#include <private/qv4module_p.h>','#include <private/qv4module_p.h>\n#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)\n#include <QtCore/qthread.h>\n#endif')
replace(scriptcpp,'QV4::ReturnedValue QQmlScriptData::scriptValueForContext(',
        '#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)\n'+(OUT/'script_evaluation.cpp.txt').read_text()+'#endif\n\nQV4::ReturnedValue QQmlScriptData::scriptValueForContext(')
replace(scriptcpp,'        QV4::Scoped<QV4::QmlContext> qmlExecutionContext(scope);','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
        const auto overteBefore=overteE2eBeginEvaluation(executableCU.data());bool overteEvaluated=false;
#endif
        QV4::Scoped<QV4::QmlContext> qmlExecutionContext(scope);''')
replace(scriptcpp,'            module->evaluate();','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
            const bool overteWasEvaluated=module->d()->evaluated;
            const bool overteModuleOwner=module->d()->unit==executableCU.data();
#endif
            module->evaluate();
#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
            overteEvaluated=overteModuleOwner && !overteWasEvaluated && module->d()->evaluated
                    && module->d()->unit==executableCU.data();
#endif''')
replace(scriptcpp,'        if (v4->hasException) {','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
        const bool overteFailed=v4->hasException;
#endif
        if (v4->hasException) {''')
replace(scriptcpp,'        return value->asReturnedValue();\n    });','''#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
        overteE2eEndEvaluation(executableCU.data(),overteBefore,overteEvaluated,overteFailed);
#endif
        return value->asReturnedValue();
    });''')

diff='';rows=[]
for path,text in sorted(current.items()):
    if text==base[path]:continue
    target=OUT/'qt-source'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
    diff+=''.join(difflib.unified_diff(base[path].splitlines(True),text.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
    rows.append(dict(path=path,upstreamSha256=sha(original[path]),baseSha256=sha(base[path].encode()),candidateSha256=sha(text.encode())))
(OUT/'native-dependencies-incremental.patch').write_text(diff)
assert all((ROOT/row['path']).read_bytes()==original[name] for name,row in refs.items())
assert all((ROOT/row['privatePath']).read_bytes()==original[row['path']] for row in newrefs)
ast.parse(Path(__file__).read_text())
(OUT/'sourcepins.json').write_text(json.dumps(dict(status='PRIVATE SOURCE ONLY/UNCOMPILED; no imports/tests',
 base='Final Chat24 Qt source from reviewed packet2, identical to combined Qt result SHA pins',paths=rows,
 incrementalPatch='native-dependencies-incremental.patch',patchSha256=sha(diff.encode()),
 known11OriginalsBeforeAfterUnchanged=True,newOfficialOriginalsBeforeAfterUnchanged=len(newrefs),
 available='Actual bounded raw dependency membership + real JS compiler-prefix/save-map hook + historical successful actual evaluation event',
 missing=['No current-root/context evaluation association; cached value never becomes a new evaluation',
 'No native-type code, dynamic graph, AOT or independent SDK source admission',
 'New optional Qt object graph getter is not yet wired to client transport/physical SDK admission',
 'Existing offline checker/manifest must be expanded to complete new inventory before later publication'],
 nativeCompiled=False,hostTestsRun=False,importGraphAvailable=False,aotGraphAvailable=False,installedQtSourceAvailable=False),indent=2)+'\n')
print(json.dumps(dict(changedQtPaths=len(rows),patchSha256=sha(diff.encode()),nativeCompiled=False),indent=2))

# Keep the SAME existing offline patch checker, with the complete next source
# inventory. These are private candidates against frozen Chat24 payload bytes.
CHAT=OUT.with_name('chat-qml-cache-integration-20261028')
qtpatch=''.join(''.join(difflib.unified_diff(original[path].decode().splitlines(True),current[path].splitlines(True),
    fromfile='a/'+path,tofile='b/'+path)) for path in sorted(current))
qtlines=['\n' if line==' \n' else line for line in qtpatch.splitlines(True)];removed=0
while qtlines and qtlines[-1]=='\n':qtlines.pop();removed+=1
if removed:
    import re
    index=max(i for i,line in enumerate(qtlines) if line.startswith('@@ '))
    match=re.fullmatch(r'@@ -(\d+),(\d+) \+(\d+),(\d+) @@\n',qtlines[index]);assert match
    a,b,c,d=map(int,match.groups());qtlines[index]=f'@@ -{a},{b-removed} +{c},{d-removed} @@\n'
qtpatch=''.join(qtlines)
changed={path:sha(original[path]) for path in current if original[path].decode()!=current[path]}
reference={path:sha(original[path]) for path in current if original[path].decode()==current[path]}
assert len(changed)==13 and len(reference)==5
public={};publicbase={}
def public_get(path):
    publicbase[path]=(CHAT/'payload'/path).read_text();public[path]=publicbase[path];return public[path]
path='ios/patches/qtdeclarative-overte-e2e-qml-source-receipts.patch';public_get(path);public[path]=qtpatch
path='tests/device/ios/qt-qml-source-patch.json';manifest=json.loads(public_get(path))
manifest['sourceSha256']=changed;manifest['referenceSha256']=reference;public[path]=json.dumps(manifest,indent=2)+'\n'
path='tests/device/ios/verify_qt_qml_source_patch.py';text=public_get(path)
for name,members in [('REVIEWED_SOURCE_PATHS',changed),('REVIEWED_REFERENCE_PATHS',reference)]:
    first=text.index(name+' = frozenset({\n');last=text.index('})\n',first)+3
    text=text[:first]+name+' = frozenset({\n'+''.join('    '+repr(key)+',\n' for key in sorted(members))+'})\n'+text[last:]
public[path]=text
path='tests/device/ios/self_tests/test_ios_qml_source_patch.py';text=public_get(path)
assert text.count("self.assertEqual(11, len(report['appliedSha256']))")==1
public[path]=text.replace("self.assertEqual(11, len(report['appliedSha256']))","self.assertEqual(18, len(report['appliedSha256']))",1)
path='tests/device/ios/adapters/chat_qml_cache_loaded.py';text=public_get(path)
public[path]=text+'\n\n'+(OUT/'dependency_reader.py.txt').read_text()
path='tests/device/ios/self_tests/test_ios_chat_qml_dependencies.py';publicbase[path]='';public[path]=(OUT/'test_ios_chat_qml_dependencies.py').read_text()
tags=('qt-overte-qml-dependency-original','qt-overte-qml-object-dependency-original','qt-overte-qml-script-evaluation')
for path in ('tests/device/contract-versions.json','tests/device/validate_contract_versions.py'):
    # These shared registry files also contain Root's later World additions.
    # Start from actual current public bytes and add only these own three tags.
    publicbase[path]=(ROOT/path).read_text();text=publicbase[path]
    marker='    "qt-overte-qml-compiler-input": '
    assert text.count(marker)==1 and not any('"'+tag+'"' in text for tag in tags)
    lines=''.join('    "'+tag+'": '+('{"current": 1, "reads": [1]},' if path.endswith('.json') else '1,')+'\n' for tag in tags)
    public[path]=text.replace(marker,lines+marker,1)
pubdiff='';pubrows=[];tests=[]
for path,text in sorted(public.items()):
    if path.endswith('.py'):
        tree=ast.parse(text,filename=path)
        if path.endswith('test_ios_chat_qml_dependencies.py'):
            tests=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    target=OUT/'payload'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
    pubdiff+=''.join(difflib.unified_diff(publicbase[path].splitlines(True),text.splitlines(True),fromfile='a/'+path if publicbase[path] else '/dev/null',tofile='b/'+path))
    pubrows.append(dict(path=path,baseSha256=sha(publicbase[path].encode()) if publicbase[path] else None,candidateSha256=sha(text.encode())))
(OUT/'integration-after-chat24.diff').write_text(pubdiff)
report=json.loads((OUT/'sourcepins.json').read_text())
report.update(publicPaths=pubrows,repositoryDiff='integration-after-chat24.diff',repositoryDiffSha256=sha(pubdiff.encode()),
    qtChangedCount=13,qtReferenceCount=5,qtOriginalCount=18,unrunCountercases=tests,
    note='Six new strict-host-codec cases + three existing real private-patch cases are UNRUN. Existing offline verifier extended, no second verifier. Current source transport stays untouched.',
    missing=['No current-root/context evaluation association; cache hits do not manufacture a new evaluate event',
        'No native-type code, dynamic graph, AOT or independent SDK source admission',
        'Optional Qt object graph getter still awaits existing native/client transport versioned wiring; strict host root-owner join is prepared',
        'No native compilation or device qualification; no new host or private-patch case executed'])
(OUT/'sourcepins.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(publicPaths=len(pubrows),completeInventory=[len(changed),len(reference)],countercasesUnrun=len(tests),diffSha256=sha(pubdiff.encode())),indent=2))
