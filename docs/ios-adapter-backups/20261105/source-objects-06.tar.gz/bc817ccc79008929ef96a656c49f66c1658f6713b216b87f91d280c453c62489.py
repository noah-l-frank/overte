"""Restricted original Up route, independent of new candidate admission.

The private born record remembers only original transport/correlation. The
remote original child checks its actual Source/RSD/loop/resource/worker for
every request. It cannot authorize new input, SDK observation or restoration.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio
import os
import stat
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit
from adapters.native_feature_observation import exact,need,number
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import canonical,same
from feature_journeys.contract import identifier
from ios.adapters.appium_adapter import WebDriver

FLAGS={'nativeAcquisitionBound','installedCandidateBound','nativeMotionGuardAvailable',
    'nativeTouchSupport','resourceRetirementEstablished','wholeCleanupQualified'}
STAT_FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')


def birth_path(root,run):
    identifier(run);root=Path(root)
    need(root.is_absolute() and root.resolve(strict=True)==root)
    return root/('ios-lifecycle-original-up-birth-'+run+'.json')


def original(value,root,run):
    exact(value,{'iosLifecycleOriginalUpBirthVersion','binding','runId','ownerInstance',
        'originalOrigin','reference','opening'}|FLAGS)
    need(type(value['iosLifecycleOriginalUpBirthVersion']) is int and value['iosLifecycleOriginalUpBirthVersion']==1
        and value['runId']==identifier(run) and all(value[key] is False for key in FLAGS))
    context(value['binding']);identifier(value['ownerInstance'])
    origin=value['originalOrigin'];need(type(origin) is str and len(origin)<=2048)
    parsed=urlsplit(origin)
    need(parsed.scheme in ('http','https') and parsed.hostname is not None and parsed.username is None
        and parsed.password is None and parsed.path in ('','/') and not parsed.query and not parsed.fragment
        and origin==origin.rstrip('/') and (parsed.scheme=='https' or parsed.hostname in ('127.0.0.1','localhost')))
    # Existing reference grammar is correlation only: no remote file is opened
    # locally and the record never asserts a new Source/resource birth.
    codec=OriginalFrameStore(root,value['binding'],run,'primary',lambda:True,lambda *_:need(False),
        namespace='lifecycle-native-acquisition',schema_prefix='iosLifecycleNativeAcquisition')
    codec.expand(value['reference'])
    opening=value['opening'];exact(opening,{'position','seconds'})
    need(type(opening['position']) is list and len(opening['position'])==2
        and all(type(n) is int and 0<=n<=65535 for n in opening['position'])
        and type(opening['seconds']) in (int,float) and number(opening['seconds'],0,12) and opening['seconds']>0)
    return value


def record_original(connection,value,lease,store):
    """Called by the actual born connection BEFORE uncertain prepare RPC."""
    from ios.adapters.lifecycle_world_hold_runtime import _OriginalKeeperWorldConnection,_OriginalKeeperMotionLease
    need(type(connection) is _OriginalKeeperWorldConnection and type(lease) is _OriginalKeeperMotionLease
        and connection._lease is lease and connection.lease is lease and connection.preparation is None
        and type(store) is PrivateFeatureState and connection.source is lease._source
        and value['ownerInstance']==connection.owner==lease._owner and value['binding']==connection.binding==lease._binding
        and value['runId']==connection.run==lease._run and value['reference']==lease._reference
        and lease._client is connection.source['client'] and lease._origin==lease._client.server_url
        and lease._session==connection.binding['sessionId'] and not lease._issued and lease._journal is None)
    connection.current()
    root=connection.runtime.adapter.state_path(connection.selector).parent
    need(store.path==birth_path(root,connection.run));lock=connection.source['check'];need(lock() is not False)
    born=dict(iosLifecycleOriginalUpBirthVersion=1,binding=deepcopy(connection.binding),runId=connection.run,
        ownerInstance=connection.owner,originalOrigin=lease._origin,reference=deepcopy(lease._reference),
        opening=deepcopy(lease._opening),**{key:False for key in FLAGS})
    original(born,root,connection.run)
    # Immutable once-born record. No later selector/current client can replace
    # this endpoint/reference with a different child's apparent responsibility.
    existing=store.read()
    if existing is None:store.write(born,None)
    else:need(same(existing,born))
    need(same(store.read(),born));connection.current()
    return born


class OriginalLifecycleUp:
    """New API sender to the same retained child, never a live touch owner."""
    def __init__(self,path,run):
        from ios.adapters.lifecycle_world_hold_runtime import _OriginalKeeperMotionLease
        self.path=Path(path);self.run=identifier(run)
        need(self.path==birth_path(self.path.parent,self.run))
        self.store=PrivateFeatureState(self.path);self.value=self.store.read();need(self.value is not None)
        original(self.value,self.path.parent,self.run)
        self.pin=self._pin();self.raw=self.path.read_bytes();need(self.pin==self._pin())
        self.client=WebDriver(self.value['originalOrigin'])
        self._parser=_OriginalKeeperMotionLease._inspection;self._parser_code=self._parser.__code__
        self._transport_birth=WebDriver.retain_original_keeper_cleanup;self._transport_code=self._transport_birth.__code__
        self._read_reply=WebDriver._read_reply;self._read_reply_code=self._read_reply.__code__
        self._send=self.client.retain_original_keeper_cleanup(self.value['binding']['sessionId'],original=dict(
            ownerInstance=self.value['ownerInstance'],binding=deepcopy(self.value['binding']),runId=self.run,
            referenceJson=canonical(self.value['reference']).decode('ascii')))
        self._send_original=self._send;self._send_code=self._send.__code__
        # This is only a context for the EXISTING pure reply parser, with no
        # Source/RSD/lease/factory methods and no ability to call begin().
        self._context=SimpleNamespace(_owner=self.value['ownerInstance'],_binding=deepcopy(self.value['binding']),
            _run=self.run,_reference=deepcopy(self.value['reference']),_opening=deepcopy(self.value['opening']),
            _issued=False,_journal=None)
        self.loop=None;self.requests=[];self.check()

    def _pin(self):
        info=self.path.lstat()
        need(stat.S_ISREG(info.st_mode) and info.st_uid==os.geteuid() and stat.S_IMODE(info.st_mode)==0o600 and info.st_nlink==1)
        return tuple(getattr(info,key) for key in STAT_FIELDS)

    def check(self):
        from ios.adapters.lifecycle_world_hold_runtime import _OriginalKeeperMotionLease
        need(self.pin==self._pin() and self.raw==self.path.read_bytes() and self.pin==self._pin()
            and self._send is self._send_original and self._send.__code__ is self._send_code
            and type(self._context) is SimpleNamespace and self._context._owner==self.value['ownerInstance']
            and self._context._binding==self.value['binding'] and self._context._run==self.run
            and self._context._reference==self.value['reference'] and self._context._opening==self.value['opening']
            and same(self.store.read(),self.value)
            and _OriginalKeeperMotionLease._inspection is self._parser and self._parser.__code__ is self._parser_code
            and WebDriver.retain_original_keeper_cleanup is self._transport_birth and self._transport_birth.__code__ is self._transport_code
            and WebDriver._read_reply is self._read_reply and self._read_reply.__code__ is self._read_reply_code)
        return True

    async def request(self,operation):
        need(operation in ('touch-inspect','touch-release','touch-settle'));self.check()
        loop=asyncio.get_running_loop()
        if self.loop is None:self.loop=loop
        need(self.loop is loop)
        # Existing final transport guards remain active. The canonical cleanup
        # dispatch must enter this route BEFORE installing fresh admission
        # guards; this component never clears/bypasses an existing guard.
        task=asyncio.create_task(asyncio.to_thread(self._send,operation),name='original-lifecycle-up-'+operation)
        self.requests.append(task);failure=None
        while not task.done():
            try:await asyncio.shield(task)
            except BaseException as error:failure=failure or error
        if failure is not None:raise failure
        reply=task.result();self.check()
        status=self._parser(self._context,reply,allow_unborn=operation!='touch-release')
        if status is not None and status['downIssued']:self._context._issued=True
        return status

    async def release(self):
        """Original ordinary Up only; a missing worker stays explicitly unsure."""
        before=await self.request('touch-inspect');released=None;settled=None
        if before is not None:
            released=await self.request('touch-release');settled=await self.request('touch-settle')
            need(released is not None and settled is not None and settled['contextExitReturned']
                and not settled['hostResponsibility'] and not settled['workerRunning'])
        self.check();need(all(task.done() for task in self.requests))
        return dict(iosLifecycleOriginalUpResultVersion=1,binding=deepcopy(self.value['binding']),runId=self.run,
            ownerInstance=self.value['ownerInstance'],originalReference=deepcopy(self.value['reference']),
            originalWorkerObserved=before is not None,ordinaryUpSendReturned=released is not None,
            uncertainDown=before is None,originalInspection=deepcopy(settled),**{key:False for key in FLAGS})
