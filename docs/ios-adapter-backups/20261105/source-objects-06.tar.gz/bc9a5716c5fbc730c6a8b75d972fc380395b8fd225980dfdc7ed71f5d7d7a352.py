"""Prospective pure host Budget counters; no installed/native/runtime owner."""
from contextlib import contextmanager
from pathlib import Path
import json
import struct
import tempfile
import unittest
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from adapters.api_budget_refusal_original import ApiBudgetRefusalOriginal, refusal_original
from ios.adapters import avatar_api_entry as api


class Clock:
    def __init__(self, value=1.):
        self.value = value
        self.calls = 0

    def __call__(self):
        self.calls += 1
        return self.value


class AvatarApiRefusalOriginalTests(unittest.TestCase):
    def setUp(self):
        # A later exact controller must retain this real TD and measure its
        # genuine cleanup; this source packet does not execute it.
        root = self.enterContext(tempfile.TemporaryDirectory(
            prefix='avatar-budget-refusal-', dir=Path.cwd()/'.ios-host-tmp'))
        self.path = Path(root)/'api-budget-refusal-original.json'

    def collector(self):
        return ApiBudgetRefusalOriginal(self.path, 'avatar', {'case': self.id()})

    def record(self):
        return json.loads(self.path.read_text())

    def test_default_none_keeps_original_refusal_and_exact_clock_call_count(self):
        clock = Clock()
        owner = api.Budget(clock)
        self.assertEqual(1, clock.calls)
        clock.value = 26.
        with self.assertRaisesRegex(NativeUIError, '^Avatar API budget exhausted or host clock changed$'):
            owner.check()
        self.assertEqual(2, clock.calls)
        self.assertTrue(owner.failed)
        self.assertFalse(self.path.exists())

    def test_real_deadline_refusal_retains_original_grant_and_no_extra_clock(self):
        clock = Clock()
        observer = self.collector()
        with observer.scope(api):
            owner = api.Budget(clock)
            clock.value = 2.
            self.assertEqual(2., owner.check())
            clock.value = 26.
            with self.assertRaisesRegex(NativeUIError, '^Avatar API budget exhausted or host clock changed$'):
                owner.check()
            self.assertTrue(owner.failed)
            self.assertEqual(3, clock.calls)
        original = self.record()
        self.assertEqual(25, original['constructorGrant']['seconds'])
        self.assertEqual(struct.pack('>d', 26.).hex(), original['constructorGrant']['grantedDeadline']['ieee754BigEndianHex'])
        self.assertEqual(struct.pack('>d', 2.).hex(), original['afterPredicateStateSnapshot']['last']['ieee754BigEndianHex'])
        self.assertFalse(original['afterPredicateStateSnapshot']['failed']['value'])
        self.assertTrue(original['snapshotIsNotExecutedShortCircuitOperandTrace'])
        self.assertFalse(original['observationAuthority'])

    def test_backwards_clock_refuses_below_unchanged_original_deadline(self):
        clock = Clock(5.)
        with self.collector().scope(api):
            owner = api.Budget(clock)
            clock.value = 4.
            with self.assertRaises(NativeUIError):
                owner.check()
            self.assertTrue(owner.failed)
        original = self.record()
        self.assertEqual(2, clock.calls)
        self.assertEqual(struct.pack('>d', 4.).hex(), original['calculatedLocalValue']['ieee754BigEndianHex'])
        self.assertEqual(struct.pack('>d', 30.).hex(), original['constructorGrant']['grantedDeadline']['ieee754BigEndianHex'])

    def test_invalid_constructor_first_clock_has_no_invented_grant(self):
        clock = Clock(float('nan'))
        with self.collector().scope(api), self.assertRaisesRegex(NativeUIError, '^Avatar API budget exhausted or host clock changed$'):
            api.Budget(clock)
        self.assertEqual(1, clock.calls)
        original = self.record()
        self.assertIsNone(original['constructorGrant'])
        self.assertEqual('float', original['calculatedLocalValue']['type'])
        self.assertEqual(struct.pack('>d', clock.value).hex(), original['calculatedLocalValue']['ieee754BigEndianHex'])

    def test_diagnostic_write_failure_keeps_original_error_and_failed_latch(self):
        clock = Clock()
        observer = self.collector()
        with observer.scope(api):
            owner = api.Budget(clock)
            clock.value = 26.
            with patch.object(observer.store, 'write', side_effect=OSError('own diagnostic output unavailable')):
                with self.assertRaisesRegex(NativeUIError, '^Avatar API budget exhausted or host clock changed$'):
                    owner.check()
            self.assertTrue(owner.failed)
            self.assertEqual(2, clock.calls)
        self.assertFalse(self.path.exists())

    def test_foreign_caller_cannot_write_actual_budget_diagnostic(self):
        clock = Clock()
        with self.collector().scope(api):
            owner = api.Budget(clock)
            with self.assertRaises(NativeUIError):
                refusal_original(owner, 26.)
            self.assertFalse(owner.failed)
            self.assertEqual(1, clock.calls)
        self.assertFalse(self.path.exists())

    def test_changed_actual_check_binding_refuses_and_does_not_write(self):
        clock = Clock()
        with self.collector().scope(api):
            owner = api.Budget(clock)
            original = api.Budget.check
            clock.value = 26.
            with patch.object(api.Budget, 'check', lambda self: original(self)):
                with self.assertRaisesRegex(NativeUIError, '^Avatar API budget exhausted or host clock changed$'):
                    owner.check()
            self.assertTrue(owner.failed)
        self.assertFalse(self.path.exists())

    def test_nested_scope_keeps_the_actual_original_thirty_second_grant(self):
        clock = Clock()
        observer = self.collector()
        with observer.scope(api):
            with self.assertRaises(NativeUIError), api.scope(clock, seconds=30):
                clock.value = 31.
                with api.scope(clock):
                    api.check()
        original = self.record()
        self.assertEqual(30, original['constructorGrant']['seconds'])
        self.assertEqual(struct.pack('>d', 31.).hex(), original['constructorGrant']['grantedDeadline']['ieee754BigEndianHex'])
