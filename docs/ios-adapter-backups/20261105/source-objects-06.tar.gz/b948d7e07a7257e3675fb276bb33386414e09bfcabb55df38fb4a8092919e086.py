"""Data-only generation completion assembly for the existing consumed seam.

The ordinary StepConsumer alone queries the live phase fixture and performs
the existing Actions recovery CAS. No SDK/native/current ActionScope is built.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from adapters.native_feature_observation import integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import unpack
from ios.adapters.assets_action_phase import AssetsActionPhases
from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
from ios.adapters.assets_generation_action_history import action_original
from ios.adapters.assets_generation_replies import GenerationActionReplyReads
from ios.adapters.assets_generation_view import AssetsGenerationView
from ios.adapters.assets_page_reentry import AssetsPageReentry
from ios.adapters.assets_step_consumer import AssetsStepConsumer
from ios.adapters.assets_dead_page_retirement import AssetsDeadPageRetirement


def generation_completion_consumer(graph,actions):
    need(type(graph) is AssetsEpisodeModelGraph and graph.dependency_mode and graph.metadata is None
        and type(actions) is AssetsActionPhases and graph.actions is actions
        and actions.selected is graph.episode.owner.selected and not actions.historical)
    graph.guard();actions.guard();episode=graph.episode
    retirement=AssetsDeadPageRetirement.from_archive(graph,actions,
        PrivateFeatureState(graph.root/('ios-assets-dead-page-clients-'+actions.run+'-primary.json')))
    retirement.retired()
    generation_number,action_index={2:(2,9),3:(3,16),4:(4,22)}[episode.index]
    parent=Path(actions.context['roles']['primary']['stateRoot'])
    generation=AssetsPageReentry.from_archive(actions.selected,
        PrivateFeatureState(parent/('ios-assets-page-reentry-'+actions.run+'-primary-g'+str(generation_number)+'.json')),
        actions.locks['primary'],actions,action_index=action_index,removal=graph.removal)
    prefix='ios-assets-'+actions.run+'-primary-gen'+str(generation_number)
    store=PrivateFeatureState(graph.root/(prefix+'-view.json'));value=store.read();need(value is not None)
    rows=unpack(value['payload']);need(len(rows)==1 and type(rows[0]) is dict)
    active=rows[0].get('activeAction');need(integer(active,action_index,{2:13,3:17,4:23}[generation_number]))
    action_original(actions,active,include_saved_pending=True)
    replies=[]
    for index in range(action_index,active+1):
        replies.append(GenerationActionReplyReads.from_archive(
            PrivateFeatureState(graph.root/(prefix+'-action'+str(index)+'-replies.json')),
            generation=generation,episode=episode,actions=actions,action_index=index))
    view=AssetsGenerationView.from_archive(generation,episode,actions,graph.upload,store,
        reply_owners=tuple(replies),namespace='renamed' if generation_number==2 else 'original',
        old_tree=graph.tree if generation_number==2 else None,baked_parsed=graph.parsed if generation_number==4 else None)
    graph.guard();return AssetsStepConsumer(actions,generation_view=view)
