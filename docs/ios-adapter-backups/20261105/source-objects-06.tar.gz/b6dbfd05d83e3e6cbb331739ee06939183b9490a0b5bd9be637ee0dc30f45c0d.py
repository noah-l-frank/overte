"""Only genuine ScriptSourceLock.held original frames may use flock."""
from pathlib import Path
from types import FrameType
import fcntl,os,stat
class Locks:
    def __init__(self,temp):self.temp=Path(temp);self.bound=None;self.observed=[];self.flock=fcntl.flock;self.fstat=os.fstat
    def loaded(self,name,module):
        if name!='adapters.script_feature.lock':return
        cls=vars(module)['ScriptSourceLock'];wrapper=cls.__dict__['held'];fn=wrapper.__wrapped__
        self.bound=(cls,wrapper,wrapper.__code__,wrapper.__globals__,wrapper.__closure__,fn,fn.__code__,fn.__globals__)
    def check(self,args,frame):
        assert self.bound is not None and fcntl.flock is self.flock
        cls,wrapper,code,ns,closure,fn,body,globals_=self.bound
        assert cls.__dict__['held']is wrapper and wrapper.__code__ is code and wrapper.__globals__ is ns and wrapper.__closure__ is closure
        assert wrapper.__wrapped__ is fn and fn.__code__ is body and fn.__globals__ is globals_
        assert type(frame)is FrameType and frame.f_code is body and frame.f_globals is globals_
        owner=frame.f_locals['self'];fd,operation=args;path=frame.f_locals['path']
        assert isinstance(owner,cls)and owner.path==path and type(fd)is int and fd==frame.f_locals['descriptor']
        assert operation==fcntl.LOCK_EX|fcntl.LOCK_NB
        path=Path(path);assert path.is_relative_to(self.temp)and path.resolve(strict=True)==path
        actual=self.fstat(fd);stored=path.lstat()
        assert stat.S_ISREG(actual.st_mode)and actual.st_nlink==stored.st_nlink==1 and actual.st_size==stored.st_size==0
        assert actual.st_uid==os.geteuid()and stat.S_IMODE(actual.st_mode)==0o600
        assert(actual.st_dev,actual.st_ino)==(stored.st_dev,stored.st_ino)
        self.observed.append((owner,path,fd,actual.st_dev,actual.st_ino))
    def finish(self):
        assert self.observed and all(owner._owner is None for owner,*unused in self.observed)
        return dict(actualOriginalHeldCalls=len(self.observed),allObservedOwnersReleased=True)
