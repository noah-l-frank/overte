"""Actual current C10d prerequisite; no Assets consumer qualification."""
from pathlib import Path
from c10d_admission import qualify as current_qualification,HELPER,SUBJECT,AGGREGATE as QUALIFIED

def qualify(plan,pin):
    physical={}
    actual=current_qualification(Path(__file__).resolve().parent.parent.parent,pin,physical)
    assert plan['qualifiedSourceExecution']==actual
    assert all(plan['physicalPins'].get(path)==row for path,row in physical.items())
    assert actual['C22PhaseAdmission']is None
    return actual
