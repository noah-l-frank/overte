"""Actual original-Keeper HouseArrest fixed-file reads, never native clocks.

No mutation/path selector exists here. Native one-way retirement is separate.
AFC metadata remains AFC metadata; os_stat's synthetic inode is never used.
"""
from copy import deepcopy
import asyncio,base64,hashlib,re,sys,time,threading
from types import BuiltinFunctionType,FrameType,FunctionType

_SYS=sys
_GETFRAME=sys._getframe

FILE='feature-native-observation.json'
LIMIT=262144

def same_original_connection(current,held):
    # Identity predicate only, no port or serialized authority. Real SDK code
    # below supplies its actual held connection; host boundary tests stay models.
    return held is not None and current is held

async def close_original_handle(service,connection,handle,error):
    """No lazy reconnect: the actual caller supplies its held original service.

    This is a close-decision helper, not Creator/SDK/native/absence authority.
    The real endpoint below first binds its genuine operation/Source/service.
    """
    if handle is None:return
    if not same_original_connection(service._service,connection):raise error('session-lifetime')
    await service.fclose(handle)

async def original(operations,args,session,creator,error):
    from pymobiledevice3.services.house_arrest import HouseArrestService
    from pymobiledevice3.services.afc import AfcError
    from pymobiledevice3.exceptions import AfcFileNotFoundError
    from adapters.normal_feature_state import context
    if type(operations)is not creator or type(args)is not dict or set(args)!={'avatarResponseFileReadVersion','binding','runId','resultsDirectory','role','mode'}:
        raise error('request')
    if type(args['avatarResponseFileReadVersion'])is not int or args['avatarResponseFileReadVersion']!=1 or args['mode']not in('read','absence')or args['role']not in('primary','actor'):
        raise error('request')
    binding=deepcopy(context(args['binding']));directory=args['resultsDirectory'];run=args['runId']
    if binding['sessionId']!=session or type(run)is not str or re.fullmatch('[0-9a-f]{32}',run)is None or type(directory)is not str or len(directory)>128 or re.fullmatch('[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*',directory)is None:
        raise error('request')
    if (sys is not _SYS or sys.modules.get('sys')is not _SYS or sys._getframe is not _GETFRAME
            or type(_GETFRAME)is not BuiltinFunctionType or _GETFRAME.__self__ is not _SYS or _GETFRAME.__name__!='_getframe'):
        raise error('session-lifetime')
    method=creator.__dict__['avatar_response_file_read'];caller=_GETFRAME(1)
    if type(method)is not FunctionType:raise error('session-lifetime')
    code,namespace=method.__code__,method.__globals__
    defaults,keywords,closure=method.__defaults__,method.__kwdefaults__,method.__closure__
    values,items,cells=tuple(defaults or()),tuple((keywords or{}).items()),tuple(cell.cell_contents for cell in closure or())
    wrapped=getattr(method,'__wrapped__',None)
    if type(caller)is not FrameType or _GETFRAME(0).f_back is not caller or caller.f_code is not method.__code__ or caller.f_globals is not method.__globals__ or caller.f_locals.get('self')is not operations:
        raise error('session-lifetime')
    loop=asyncio.get_running_loop();task=asyncio.current_task();source=operations.source
    current_task=asyncio.current_task;running_loop=asyncio.get_running_loop
    current_thread=threading.current_thread;thread=current_thread()
    if loop is not source._loop or not isinstance(task,asyncio.Task)or operations.native_query_task is not None or operations.native_acquisition is not None:
        raise error('session-lifetime')
    rsd=operations.scope(session);claim=operations.session;held_claim=deepcopy(claim)
    touch,resource=operations.touch,operations.touch_resources
    if claim['sessionId']!=session:raise error('session-lifetime')
    started=loop.time();deadline=started+1.5;host_before=time.time()*1000
    connection=None;service=None;closed=None
    def current(*,after_close=False):
        if (asyncio.current_task is not current_task or asyncio.get_running_loop is not running_loop
                or current_task()is not task or running_loop()is not loop or threading.current_thread is not current_thread or current_thread()is not thread
                or method.__code__ is not code or method.__globals__ is not namespace
                or method.__defaults__ is not defaults or method.__kwdefaults__ is not keywords or method.__closure__ is not closure
                or getattr(method,'__wrapped__',None)is not wrapped
                or len(defaults or())!=len(values)or any(a is not b for a,b in zip(defaults or(),values))
                or tuple(keywords or())!=tuple(k for k,v in items)or any(keywords[k]is not v for k,v in items)
                or len(closure or())!=len(cells)or any(cell.cell_contents is not value for cell,value in zip(closure or(),cells))
                or operations.source is not source or source._closing or operations.closed or operations.draining
                or operations.session is not claim or claim!=held_claim or operations.scope(session)is not rsd
                or operations.touch is not touch or operations.touch_resources is not resource
                or operations.native_query_task is not None or operations.native_acquisition is not None
                or creator.__dict__['avatar_response_file_read']is not method or loop.time()>=deadline):raise error('session-lifetime')
        if connection is not None:
            if after_close:
                if closed is None or not closed.is_set()or service._service is not None or service._afc_reader_task is not None or service._afc_pending:raise error('session-lifetime')
            elif not same_original_connection(service._service,connection):raise error('session-lifetime')
    current();await operations.fresh_touch_scope(binding);current()
    if len(source._native_reads)>=32:raise error('request')
    service=HouseArrestService(rsd,documents_only=False);close=service.aclose;closed=asyncio.Event();lock=asyncio.Lock()
    row=(service,close,task,loop,closed,lock);source._native_reads.append(row)
    path='/Documents/'+directory+'/'+FILE;handle=None;failure=None;result=None;close_problem=None
    def stat_value(value):
        if type(value)is not dict:raise error('request')
        # Preserve actual SDK fields; never call os_stat or invent st_ino/dev.
        output={}
        for key,item in value.items():
            if type(key)is not str:raise error('request')
            if type(item)in(str,int,float,bool)or item is None:output[key]=item
            elif hasattr(item,'isoformat'):output[key]=dict(actualPythonType=type(item).__module__+'.'+type(item).__qualname__,iso8601=item.isoformat())
            else:raise error('request')
        return output
    try:
        current();await service.send_command(claim['archiveBundleId'],'VendContainer');current()
        connection=service._service
        if connection is None:raise error('session-lifetime')
        actual=await service.__aenter__();current()
        if actual is not service:raise error('session-lifetime')
        try:
            before=await service.stat(path);current()
        except AfcFileNotFoundError as absent:
            current()
            if args['mode']!='absence'or absent.status!=AfcError.READ_ERROR:raise
            result=dict(mode='absent',actualException=type(absent).__module__+'.'+type(absent).__qualname__,actualStatus=int(absent.status))
        else:
            if args['mode']=='absence':result=dict(mode='present',actualStat=stat_value(before))
            else:
                if before.get('st_ifmt')!='S_IFREG'or before.get('st_nlink')!=1 or type(before.get('st_size'))is not int or not 2<=before['st_size']<=LIMIT:raise error('request')
                handle=await service.fopen(path,'r');current()
                raw=await service.fread(handle,before['st_size']);current()
                after=await service.stat(path);current()
                if type(raw)is not bytes or len(raw)!=before['st_size']or before!=after:raise error('request')
                result=dict(mode='read',rawBase64=base64.b64encode(raw).decode('ascii'),actualRawSha256=hashlib.sha256(raw).hexdigest(),actualRawBytes=len(raw),actualStatBefore=stat_value(before),actualStatAfter=stat_value(after))
    except BaseException as original_error:
        failure=(original_error,original_error.__traceback__)
    finally:
        if handle is not None:
            # Actual AFC fclose->_send_and_wait calls connect(). The helper
            # rejects missing/replaced original connections BEFORE that call.
            try:await close_original_handle(service,connection,handle,error)
            except BaseException as original_close:close_problem=(original_close,original_close.__traceback__)
        try:
            # Reuse the genuine existing Source cleanup: its original bound
            # close/row/loop and actual reader/pending drain are all checked.
            if not await source._close_native_read(row):raise error('session-lifetime')
        except BaseException as original_close:
            if close_problem is None:close_problem=(original_close,original_close.__traceback__)
    if failure is not None:
        if close_problem is not None:failure[0].add_note('Original response handle/connection cleanup is unresolved; original Source duty retained.')
        raise failure[0].with_traceback(failure[1])
    if close_problem is not None:raise close_problem[0].with_traceback(close_problem[1])
    current(after_close=True)
    return dict(iosAvatarResponseAFCOriginalVersion=1,ownerInstance=operations.instance,runId=run,binding=binding,
        file=FILE,requestRole=args['role'],resultsDirectory=directory,bundleId=claim['archiveBundleId'],clockDomain='python-original-keeper-host',
        hostBeforeEpochMs=host_before,hostAfterEpochMs=time.time()*1000,hostBeforeMonotonic=started,hostAfterMonotonic=loop.time(),
        original=result,actualHandleClosed=True,actualServiceCloseReturned=closed.is_set(),nativeClockEstablished=False,
        nativeInodeEstablished=False,installedCandidateBound=False,resourceRetirementEstablished=False)
