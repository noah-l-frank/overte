"""Actual per-action complete world/parser source over the selected SDK pair.

Each action/role gets a distinct owned source namespace, preserving the existing
32-frame/40-attempt limits and strict literal scene/raw codecs. The namespace
split bounds replay history; it never raises a cap, caches a live interpretation
or treats a source/header string as a successful native observation.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
from adapters.native_feature_observation import integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same
from ios.adapters.assets_action_phase import AssetsActionScope
from ios.adapters.assets_checkpoint_context import checkpoint_descriptor
from ios.adapters.assets_scene_sources import AssetsSceneSources,SceneRawSources

LABELS={'primary':'p','actor':'a','actor-primary':'r'}


class AssetsCheckpointScene(AssetsSceneSources):
    OWNER_VERSION=4
    EXTRA_FIELDS=frozenset({'selectedPair','checkpointAction','episode'})
    def __init__(self,*args,selection,action,episode=None,**kwargs):
        need(type(action) is AssetsActionScope and action.owner.selected is selection)
        self.selection,self.action,self.actions,self.action_index,self.episode=selection,action,action.owner,action.index,episode
        self.historical=False;super().__init__(*args,**kwargs);self.boundary();action.guard()
    def source_name(self):return 'ios-assets-checkpoint-'+self.run+'-a'+str(self.action_index)+'-'+self.role+'-scene.json'
    def original_profile(self):return dict(namespace='assets-cps-a'+str(self.action_index)+'-'+LABELS[self.role]+'-source',schema_prefix='iosAssetsCheckpointScene')
    def raw_profile(self):return dict(namespace='assets-cps-a'+str(self.action_index)+'-'+LABELS[self.role]+'-native',
        schema_prefix='iosAssetsCheckpointSceneRaw',record_key='iosAssetsCheckpointSceneRawRecordVersion',migration_key='iosAssetsCheckpointSceneRawMigrationVersion')
    def ticket(self):return self.action.ticket if self.action is not None else checkpoint_descriptor(self.actions,self.action_index,allow_active_pending=getattr(self,'archive_active_pending',False))['ticket']
    def extra_envelope(self):return dict(selectedPair=self.selection.link(),
        checkpointAction=dict(path=str(self.actions.store.path),index=self.action_index,ticket=self.ticket()),
        episode=None if self.episode is None else self.episode.link())
    def boundary(self):
        subject='actor' if self.role=='actor' else 'primary';info=self.selection.context['roles'][subject]
        root=Path(info['stateRoot']) if self.episode is None else Path(self.episode.descriptor['directories'][subject]['stateRoot']['path'])
        need(self.run==self.selection.run and same(self.binding,info['binding']) and self.store.path==root/self.source_name()
            and self.lock.path==root/'script-feature-sources.lock')
        if self.episode is None:need(self.action_index==1 and self.lock is self.actions.locks[subject])
        else:self.episode.guard();need(self.episode.owner.selected is self.selection and self.lock is self.episode.locks[subject])
    def envelope_guard(self):
        self.selection.selected_guard();self.actions.guard();self.boundary()
        if not self.historical:need(self.selection.state==dict(phase='selected'))
        return True
    def guard(self):
        # local_guard/envelope_guard protect immutable metadata reads. Every
        # capture/save/SDK operation still checks the actual current action,
        # followed by the unchanged source/native guards in the base method.
        if not self.historical:self.action.guard()
        return super().guard()
    @classmethod
    def from_archive(cls,actions,index,role,*,episode=None,allow_active_pending=False):
        from ios.adapters.assets_episode_metadata_graph import readonly_store,forbidden
        need(integer(index,1,29) and role in LABELS);checkpoint_descriptor(actions,index,allow_active_pending=allow_active_pending)
        owner=object.__new__(cls);owner.archive_active_pending=allow_active_pending;owner.selection,owner.actions,owner.action,owner.action_index,owner.episode=actions.selected,actions,None,index,episode
        owner.run,owner.role,owner.historical=actions.run,role,True;subject='actor' if role=='actor' else 'primary';owner.storage_role=subject
        owner.binding=deepcopy(actions.context['roles'][subject]['binding']);owner.pid=int(owner.binding['processIdentity'])
        owner.lock=actions.locks[subject] if episode is None else episode.locks[subject];owner.monotonic=actions.monotonic;owner.epoch_ms=forbidden
        root=Path(actions.context['roles'][subject]['stateRoot']) if episode is None else Path(episode.descriptor['directories'][subject]['stateRoot']['path'])
        owner.store=readonly_store(PrivateFeatureState(root/owner.source_name()));owner.previous=owner.store.read();need(owner.previous is not None)
        owner.native=SimpleNamespace(pid=owner.pid,monotonic=owner.monotonic,read=forbidden,send=forbidden,original=forbidden)
        owner.readers={};owner.check=forbidden;owner._cached=[];owner.active=False;owner.state=None
        owner.raws=SceneRawSources(owner,owner.local_guard,forbidden)
        owner.originals=OriginalFrameStore(root,owner.binding,owner.run,subject,owner.local_guard,forbidden,monotonic=owner.monotonic,**owner.original_profile())
        owner.state=owner.decode(owner.previous);owner.local_guard();return owner
