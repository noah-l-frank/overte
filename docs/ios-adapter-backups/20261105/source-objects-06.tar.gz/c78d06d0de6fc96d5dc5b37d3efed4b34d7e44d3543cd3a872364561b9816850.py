"""Prospective host-model counters with genuine OFS/lock/files/WAV constructors.

No AudioClient/ReceivedMessage/decoder is executed. Pointer labels below are
explicit modeled provenance data, never real native authority or a fake owner.
All cases remain UNRUN in this source packet.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import base64
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest
import wave
from adapters.normal_ui import NativeUIError
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters import audio_received_mixer as source

BINDING=dict(sourceRevision='d'*40,artifactSha256='e'*64,processIdentity='42',sessionId='received-mixer-model',generation=1,targetFingerprint='f'*64)
RUN='1'*32
INSTANCE='2'*32
LEASE='3'*32


def modeled_originals():
    """Explicit lower transport model. No source constructor or native claim."""
    request=dict(schemaVersion=1,commandId='ios-'+'5'*32,action=source.ACTION,operation='capture',
        instance=INSTANCE,runId=RUN,role='actor',leaseId=LEASE,startCommandId='ios-'+'4'*32)
    rows=[];pcm=bytearray()
    for index in range(source.PACKETS):
        # Actual bytes later written to WAV/OFS, not a requested acoustic cue.
        chunk=b''.join(struct.pack('<hh',(index*997+j)%32768,-((index*997+j)%32768)) for j in range(240))
        packet=struct.pack('<HI',index+100,3)+b'pcm'+chunk
        rows.append(dict(index=index+1,streamIdentity='a1',messageIdentity=format(1000+index,'x'),decoderIdentity='0',decoderLifetimeGeneration=5,threadIdentity='a3',
            sourceLocalId=7,senderSockAddr='UDP 127.0.0.1:40103',senderAddress='127.0.0.1',senderPort=40103,senderSocketType=1,packetType='MixedAudio',packetVersion=1,packetSequence=index+100,
            arrivalEarly=False,packetReceiveClockUs=str(1000000+index*10000),decodeBeforeReceiveClockUs=str(1000100+index*10000),
            decodeAfterReceiveClockUs=str(1000200+index*10000),packetCodec='pcm',selectedCodec='pcm',
            decodeBeforeEpochMs=100001+index*10,decodeAfterEpochMs=100002+index*10,
            decodeBeforeMonotonicMs=1001+index*10,decodeAfterMonotonicMs=1002+index*10,
            messageBase64=base64.b64encode(packet).decode(),messageSha256=source.sha(packet),
            encodedBase64=base64.b64encode(chunk).decode(),encodedSha256=source.sha(chunk),offset=len(pcm),bytes=len(chunk),pcmSha256=source.sha(chunk)))
        pcm.extend(chunk)
    stream=io.BytesIO()
    with wave.open(stream,'wb') as writer:
        writer.setnchannels(2);writer.setsampwidth(2);writer.setframerate(24000);writer.writeframes(bytes(pcm))
    wav=stream.getvalue()
    state=dict(receivedMixerVersion=2,profile=source.PROFILE,owned=True,runId=RUN,leaseId=LEASE,instance=INSTANCE,role='actor',admissionEpoch=5,decoderLifetimeGeneration=5,currentDecoderLifetimeGeneration=5,
        captureGeneration=1,startedEpochMs=100000,startedMonotonicMs=1000,startedReceiveClockUs='999999',maximumOwnedSeconds=6,targetPackets=64,
        sampleRate=24000,channels=2,sampleFormat='pcm16le',streamIdentity='a1',outputIdentity='a2',bytes=len(pcm),rows=rows,
        active=False,complete=True,invalid=False,receiveClockDomain='udt-p_high_resolution_clock-us-opaque',
        sampleClockMeaning='decoded-pcm-order-not-adc-dac-time',watchdogOwned=True,watchdogActive=True,**{key:False for key in source.FLAGS})
    value=dict(receivedMixerOriginalVersion=2,instance=INSTANCE,runId=RUN,role='actor',leaseId=LEASE,processId=42,
        requestedEpochMs=100700,capturedEpochMs=100701,captureCommand=request,source=state,
        wav=dict(kind='wav',exists=True,complete=True,bytes=len(wav),sha256=source.sha(wav),device='1',inode='2'))
    return value,wav,bytes(pcm)


class DeclaredDecoderLifetime:
    """Lower boundary model of native mutation scopes, NOT a native stream."""
    def __init__(self,address='0'):self.generation=5;self.active=0;self.valid=True;self.listeners=[];self.address=address
    def current(self):return self.generation if self.valid and self.active==0 else 0
    def begin(self):
        self.active+=1
        if self.active>16 or self.generation>=1000000000:self.valid=False
        else:self.generation+=1
        for callback in self.listeners:callback() # Declared direct invalidation BEFORE release/setup.
    def end(self,returned=True):
        if not returned or self.active==0 or self.generation>=1000000000:self.valid=False
        else:self.generation+=1
        self.active-=1


class DeclaredReceiveWindow:
    """Copies already modeled rows unchanged; cannot reanchor them to a new life."""
    def __init__(self,lifetime,value):
        self.lifetime=lifetime;self.value=deepcopy(value);self.invalid=False
        self.generation=value['source']['decoderLifetimeGeneration']
        if not self.generation or lifetime.current()!=self.generation or lifetime.address!=value['source']['rows'][0]['decoderIdentity']:raise NativeUIError('Model old rows cannot join a new decoder lifetime')
        lifetime.listeners.append(self.invalidate)
    def invalidate(self):self.invalid=True
    def snapshot(self):
        if self.invalid or self.lifetime.current()!=self.generation:raise NativeUIError('Model received decoder lifetime is no longer original')
        return deepcopy(self.value)


class ReceivedMixerOriginalTests(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        self.root=Path(temporary.name);self.root.chmod(0o700);self.lock=ScriptSourceLock(self.root/'script-feature-sources.lock')
        self.intents=[]
        self.store=OriginalFrameStore(self.root,BINDING,RUN,'actor',self.guard,self.intent,
            namespace=source.NAMESPACE,schema_prefix=source.PREFIX,kind='inputs')
        self.value,self.wav,self.pcm=modeled_originals()
    def guard(self):self.lock.assert_held();return True
    def intent(self,event,value):self.intents.append((event,deepcopy(value)));return True
    def raw(self,value=None):return json.dumps(self.value if value is None else value,sort_keys=True,separators=(',',':')).encode()+b'\n'
    def intent_raw(self):
        start=deepcopy(self.value['captureCommand']);start.update(operation='start',commandId=start['startCommandId'],seconds=6)
        value=dict(receivedMixerIntentVersion=2,instance=INSTANCE,runId=RUN,leaseId=LEASE,role='actor',processId=42,issuedEpochMs=99999,command=start)
        return json.dumps(value,sort_keys=True,separators=(',',':')).encode()+b'\n'
    def frame(self):return dict(receivedMixerSavedVersion=2,request=self.value['captureCommand'],intentBase64=base64.b64encode(self.intent_raw()).decode(),
        captureBase64=base64.b64encode(self.raw()).decode(),wavBase64=base64.b64encode(self.wav).decode())
    def owner(self,reference):return source.ReceivedMixerOriginalOwner(self.root,BINDING,RUN,LEASE,self.lock,reference,instance=INSTANCE,pid=42)
    def reject(self,value,wav=None):
        with self.assertRaises((NativeUIError,ValueError,UnicodeError)):
            source.original_capture(self.raw(value),self.wav if wav is None else wav,self.value['captureCommand'],42,intent_raw=self.intent_raw())
    def test_actual_wav_and_original_packet_pcm_are_read_without_live_query_or_retiming(self):
        with self.lock.held():
            reference=self.store.expand(self.store.write(1,self.frame()));result=self.owner(reference).original()
            self.assertEqual(self.pcm,result['pcm']);self.assertEqual(self.value,result['original'])
            self.assertIsNone(result['liveAdmission']);self.assertTrue(result['historicalOnly'])
            self.assertTrue(all(result[key] is False for key in source.FLAGS));self.assertFalse(result['resourceRetirementQualified'])
    def test_stale_watchdog_window_and_original_decode_clock_regression_refuse(self):
        value=deepcopy(self.value);value['requestedEpochMs']=106000;value['capturedEpochMs']=106001;self.reject(value)
        value=deepcopy(self.value);value['source']['rows'][1]['decodeAfterMonotonicMs']=1000;self.reject(value)
        value=deepcopy(self.value);value['source']['watchdogActive']=False;self.reject(value)
        value=deepcopy(self.value);value['source']['startedReceiveClockUs']='1000001';self.reject(value)
    def test_foreign_mixer_stream_decoder_or_thread_cannot_join_one_window(self):
        for key,value in (('sourceLocalId',8),('senderSockAddr','UDP 127.0.0.1:40104'),('streamIdentity','a4'),('decoderIdentity','b4'),('threadIdentity','a4')):
            changed=deepcopy(self.value);changed['source']['rows'][1][key]=value;self.reject(changed)
    def test_microphone_wrong_process_role_and_native_or_peer_promotion_refuse(self):
        for key,new in (('profile','qt-source-read-to-passive-acoustic-tap'),('individualPeerQualified',True),('physicalDACQualified',True)):
            value=deepcopy(self.value);value['source'][key]=new;self.reject(value)
        value=deepcopy(self.value);value['processId']=43;self.reject(value)
        value=deepcopy(self.value);value['source']['role']='primary';self.reject(value)
    def test_changed_real_wav_cannot_be_laundered_by_updated_outer_digest(self):
        raw=bytearray(self.wav);raw[44]^=1;raw=bytes(raw);value=deepcopy(self.value)
        value['wav']['sha256']=source.sha(raw);value['source']['rows'][0]['pcmSha256']=source.sha(raw[44:44+source.FRAME_BYTES])
        self.reject(value,raw) # Original encoded packet still contains the actually different PCM.
    def test_reused_or_wrong_sequence_and_changed_encoded_packet_body_refuse(self):
        value=deepcopy(self.value);value['source']['rows'][1]['packetSequence']=100;self.reject(value)
        value=deepcopy(self.value);row=value['source']['rows'][0];raw=bytearray(base64.b64decode(row['messageBase64']));raw[0]^=1
        row['messageBase64']=base64.b64encode(raw).decode();row['messageSha256']=source.sha(raw);self.reject(value)
    def test_genuine_source_lock_and_unchanged_original_inode_are_required(self):
        with self.lock.held():reference=self.store.expand(self.store.write(1,self.frame()))
        owner=self.owner(reference)
        with self.assertRaises(NativeUIError):owner.original()
        with self.lock.held():
            path=self.store.path(reference);old=path.read_bytes();replacement=self.root/'replacement.json'
            replacement.write_bytes(old);replacement.chmod(0o600);replacement.replace(path)
            with self.assertRaises(NativeUIError):owner.original()
    def test_lost_saved_return_recovers_only_same_original_and_reread_never_creates_live_admission(self):
        def lost(event,value):
            self.intent(event,value)
            if event=='original' and value['phase']=='saved':raise NativeUIError('Declared lost saved return after genuine original write')
            return True
        self.store.intent=lost
        with self.lock.held():
            with self.assertRaises(NativeUIError):self.store.write(1,self.frame())
            reference=deepcopy(self.intents[-1][1]);owner=self.owner(reference);before=len(self.intents)
            first=owner.original();second=owner.original()
            self.assertEqual(first,second);self.assertEqual(before,len(self.intents));self.assertIsNone(second['liveAdmission'])

    def test_same_address_new_generation_null_decoder_and_nested_or_unknown_transition_refuse(self):
        for before,after in (('0','0'),('abc','abc'),('abc','0'),('0','abc')):
            with self.subTest(original_address=before,replacement_address=after):
                life=DeclaredDecoderLifetime(before);value=deepcopy(self.value)
                for row in value['source']['rows']:row['decoderIdentity']=before
                # The first counter is an incomplete window: eight genuine
                # fixture rows, no native original capture/export assertion.
                value['source']['rows']=value['source']['rows'][:8]
                value['source'].update(bytes=8*source.FRAME_BYTES,complete=False,active=True)
                window=DeclaredReceiveWindow(life,value);self.assertEqual(8,len(window.snapshot()['source']['rows']))
                # Actual source mutation path is setup -> nested cleanup; a
                # same-address replacement has a DIFFERENT real epoch.
                life.begin();self.assertEqual(0,life.current())
                life.begin();life.address=after;life.end();self.assertEqual(0,life.current())
                life.end();self.assertGreater(life.current(),5)
                self.assertEqual(before,value['source']['rows'][0]['decoderIdentity']);self.assertEqual(after,life.address)
                with self.assertRaises(NativeUIError):window.snapshot()
                with self.assertRaises(NativeUIError):DeclaredReceiveWindow(life,value)
        for unknown,overflow in ((True,False),(False,True)):
            life=DeclaredDecoderLifetime();window=DeclaredReceiveWindow(life,self.value)
            if overflow:life.generation=1000000000
            life.begin();life.end(returned=not unknown);self.assertEqual(0,life.current())
            with self.assertRaises(NativeUIError):window.snapshot()
        changed=deepcopy(self.value);changed['source']['rows'][1]['decoderLifetimeGeneration']=9;self.reject(changed)
        changed=deepcopy(self.value);changed['receivedMixerOriginalVersion']=1;self.reject(changed)
    def test_replacement_after_sixty_four_rows_refuses_export_without_changing_historical_originals(self):
        life=DeclaredDecoderLifetime();window=DeclaredReceiveWindow(life,self.value)
        before=window.snapshot();self.assertEqual(64,len(before['source']['rows']))
        accepted,pcm=source.original_capture(self.raw(before),self.wav,self.value['captureCommand'],42,intent_raw=self.intent_raw())
        self.assertEqual(self.pcm,pcm)
        # No extra packet arrives: the source lifetime callback itself closes
        # the completed window before any subsequent snapshot/WAV export.
        life.begin();life.end()
        with self.assertRaises(NativeUIError):window.snapshot()
        self.assertEqual(before,self.value)
        # The already saved actual original stays a historical original; its
        # clocks, rows and generation are NOT changed to the current lifetime.
        again,old_pcm=source.original_capture(self.raw(before),self.wav,self.value['captureCommand'],42,intent_raw=self.intent_raw())
        self.assertEqual(accepted,again);self.assertEqual(pcm,old_pcm)
        changed=deepcopy(before);changed['source']['currentDecoderLifetimeGeneration']=life.current();self.reject(changed)
