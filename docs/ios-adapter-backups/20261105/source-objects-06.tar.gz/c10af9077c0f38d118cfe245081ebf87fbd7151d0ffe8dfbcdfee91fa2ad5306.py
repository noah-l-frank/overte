"""Separate real host loops and original retained Source loop; SDK/native MODELS."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio
from copy import deepcopy
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from ios.adapters.appium_adapter import WebDriver,WebDriverRequestError
from ios.adapters.lifecycle_editors_runtime import IOSLifecycleEditorsRuntime
from test_parent_resource_world_history_models import ParentResourceWorldHistoryModels


class OriginalChildCrossAPIRecoveryModels(ParentResourceWorldHistoryModels):
    async def asyncSetUp(self):
        await super().asyncSetUp();self.host_loops=[];self.last_host_owner=None
        # End the genuine birth fixture's held host lock before separately
        # entered API calls. Do not mutate thread/lock guards or borrow it on
        # a different thread; ordinary each-call runtime locks remain actual.
        fixture=self.normal.d.f;lock=self.normal.d.lock;matches=[]
        for row in fixture._cleanups:
            function,args,keywords=row
            generator=getattr(args[0],'gen',None) if args else None
            frame=getattr(generator,'gi_frame',None)
            if frame is not None and frame.f_locals.get('self') is lock and function.__name__=='__exit__':matches.append(row)
        self.assertEqual(1,len(matches));row=matches[0];fixture._cleanups.remove(row);row[0](*row[1],**row[2])
        self.assertIsNone(lock._owner)

    async def api(self,operation):
        def call():
            runtime=IOSLifecycleEditorsRuntime(self.runtime.adapter)
            with runtime.editors('test-only',self.run) as editors:
                attempt=runtime.world_attempt_child('test-only',editors)
                owner=self.runtime.child('test-only',editors,attempt,None,original_child=True,resource_history=True)
                self.last_host_owner=owner
                async def invoke():
                    self.assertIsNot(asyncio.get_running_loop(),self.source._loop)
                    if operation=='begin':return await owner.act(seconds=12)
                    self.assertFalse(owner.lease_owner()._issued)
                    original=await owner.recover_original_child()
                    self.assertTrue(original['downIssued']);self.assertTrue(owner.lease_owner()._issued)
                    if operation=='observe':return await owner.observe()
                    if operation=='release':return await owner.release()
                    if operation=='original-up-only':return await owner.lease_owner().release()
                    raise AssertionError('Unknown exact API model operation')
                with asyncio.Runner() as runner:
                    loop=runner.get_loop()
                    try:return runner.run(invoke())
                    finally:self.host_loops.append(loop)
        try:return await asyncio.to_thread(call)
        finally:
            self.assertTrue(all(loop.is_closed() for loop in self.host_loops))
            self.assertEqual(len(self.host_loops),len({id(loop) for loop in self.host_loops}))
            self.assertIs(asyncio.get_running_loop(),self.source._loop)

    async def test_separate_host_api_loops_observe_and_release_same_original_remote_worker_without_new_down(self):
        await self.api('begin');worker=self.ops.touch.worker;self.assertIs(worker.get_loop(),self.source._loop)
        self.assertFalse(worker.done());await self.api('observe')
        self.assertIs(worker,self.ops.touch.worker);self.assertEqual([0xC2,0xC2],self.f.states())
        await self.api('release');self.assertIs(worker,self.ops.touch.worker);self.assertTrue(worker.done())
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(3,len(self.host_loops))
        self.assertTrue(all(fd.fileno()==-1 for fd in self.metadata_receiver.sockets))

    async def test_lost_begin_return_recovers_actual_original_issued_status_without_repeating_down(self):
        original=WebDriver.execute;lost=[]
        def drop(client,session,operation,values):
            result=original(client,session,operation,values)
            if operation=='mobile: overteOriginalKeeperOperation' and values.get('operation')=='touch-begin' and not lost:
                lost.append(True);raise OSError('Declared lost host begin reply AFTER actual original child returned')
            return result
        with patch.object(WebDriver,'execute',new=drop):
            with self.assertRaisesRegex(OSError,'Declared lost host begin reply'):await self.api('begin')
        self.assertEqual([True],lost);worker=self.ops.touch.worker
        self.assertEqual([0xC2,0xC2],self.f.states());await self.api('observe');await self.api('release')
        self.assertIs(worker,self.ops.touch.worker);self.assertTrue(worker.done());self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_foreign_actual_resource_birth_owner_refuses_local_issued_transition_before_original_up(self):
        await self.api('begin');birth=self.ops.retained_motion_resource
        foreign=type(self.ops)(self.source,self.ops.state_root);foreign.session=deepcopy(self.ops.session)
        queries=len(self.commands);states=self.f.states();foreign_issued=deepcopy(foreign.issued)
        self.ops.retained_motion_resource=(foreign,*birth[1:])
        try:
            with self.assertRaises(WebDriverRequestError) as failure:await self.api('observe')
            self.assertEqual(500,failure.exception.status);self.assertEqual(queries,len(self.commands))
            self.assertEqual(states,self.f.states());self.assertEqual(foreign_issued,foreign.issued);self.assertEqual(set(),foreign.operations)
            self.assertFalse(self.last_host_owner.lease_owner()._issued)
            self.assertEqual([0xC2,0xC2],self.f.states())
        finally:self.ops.retained_motion_resource=birth
        await self.api('original-up-only');self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertTrue(self.ops.touch.worker.done())

    async def test_current_source_slot_drift_keeps_original_born_source_only_for_recovery_and_ordinary_up(self):
        await self.api('begin');original=self.ops.source;birth=self.ops.retained_motion_resource
        self.ops.source=object() # Cannot become the original source by occupying a slot.
        try:
            result=await self.api('original-up-only')
            self.assertTrue(result['contextExitReturned']);self.assertFalse(result['hostResponsibility'])
            self.assertIs(birth[2],original);self.assertIs(birth[3],self.source._loop)
        finally:self.ops.source=original
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertTrue(self.ops.touch.worker.done())
