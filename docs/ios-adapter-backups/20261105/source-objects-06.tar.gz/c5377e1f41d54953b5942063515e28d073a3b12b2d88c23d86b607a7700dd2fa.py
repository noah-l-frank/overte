from pathlib import Path
import ast,difflib,hashlib,json,shutil,stat
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
N=T/'lifecycle-original-owner-native-file8-world-run-corrected-root-preparation-20261028/05-native8';Q=T/'lifecycle-original-owner-native-query10-own-registry-corrected-root-preparation-20261028/06-query10'
P=T/'lifecycle-original-owner-native-channel-model-socket-overlay-20261028';P.mkdir(mode=0o700);rows=[];diff=[]
for parent,name in ((N,'test_native_file_channel_models.py'),(Q,'test_native_query_owner_models.py')):
 base=parent/name;s=base.read_text()
 if name=='test_native_query_owner_models.py':
  a='import ast,asyncio,hashlib,inspect,json,marshal,os,re,threading,time,unittest,uuid,weakref';b='import ast,asyncio,hashlib,inspect,json,marshal,os,re,socket,threading,time,unittest,uuid,weakref';assert s.count(a)==1;s=s.replace(a,b)
 a='        class Capability:\n            def current(_)';b='        class Capability:\n            # Explicit original SDK socket-factory model, resolved before the\n            # injected HID context call; never an authentication/source claim.\n            udp_socket=staticmethod(socket.socket)\n            def current(_)';assert s.count(a)==1;s=s.replace(a,b);ast.parse(s);(P/name).write_text(s)
 rows.append(dict(path=name,base=str(base),baseSHA256=h(base),candidateSHA256=h(P/name)));diff.extend(difflib.unified_diff(base.read_text().splitlines(True),s.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(P/'proposal.diff').write_text(''.join(diff));(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE_MODEL_ONLY_UNRUN',files=rows,productionSourceChanges=0,assertionsAndBudgetsChanged=False),indent=2)+'\n')
(P/'README.txt').write_text('''Root correctedNative8 first4 passed; fifth failed acquire before Down.
Retained actual journal phase=failed/failure=acquire. Actual Source.touch_lease
resolves original _source.udp_socket before the injected touch_session call.
Capability SDK model omitted this method. Add explicit real host socket factory
on both file8/query10 models; the existing injected HID context still owns its
actual socketpairs and once Down/Up/drain. No product/source/flags/assertions/
budgets changed. Socket factory is not authentication. All earlier freezes and
failed originals remain intact. AST only; no agent test execution/import.
''')
(P/'freeze.json').write_text(json.dumps(dict(files={str(p.relative_to(P)):h(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n')
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();v=dict(stat=[getattr(a,k) for k in fields]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
 if p.is_file():v['sha256']=h(p)
 assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
for parent,topname,stage_name,model in ((N,'lifecycle-original-owner-native-file8-socket-corrected-root-preparation-20261028','05-native8','test_native_file_channel_models.py'),(Q,'lifecycle-original-owner-native-query10-socket-corrected-root-preparation-20261028','06-query10','test_native_query_owner_models.py')):
 TOP=T/topname;S=TOP/stage_name;S.mkdir(mode=0o700,parents=True)
 for name in json.loads((parent/'freeze.json').read_bytes())['files']:
  dest=S/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(parent/name,dest)
 shutil.copyfile(P/model,S/model)
 plan=json.loads((S/'run-plan.json').read_bytes());plan['privateFiles'][model]=h(S/model);plan['status']='PRIVATE_UNRUN_SOCKET_FACTORY_MODEL_CORRECTED';(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 stage=json.loads((S/'source-manifest.json').read_bytes());stage['orderedParentFreezes']['lifecycle-original-owner-native-channel-model-socket-overlay-20261028']=h(P/'freeze.json')
 for row in stage['sourcePaths']:row['observedPublicSHA256']=h(R/row['path']);row['changesCurrentPublic']=row['observedPublicSHA256']!=row['candidateSHA256']
 (S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
 if stage_name=='05-native8':
  pins=json.loads((S/'failed-first-original-pins.json').read_bytes());failed=parent/'retained-first'
  fresh={str(p):pin(p) for p in [failed,*sorted(failed.rglob('*'))]};assert sum('sha256' in v for v in fresh.values())==6;pins.update(fresh)
  (S/'failed-first-original-pins.json').write_text(json.dumps(pins,indent=2)+'\n');assert sum('sha256' in v for v in pins.values())==8
  for name,expected in pins.items():assert pin(Path(name))==expected
 (S/'socket-correction-provenance.json').write_text(json.dumps(dict(parentFreezeSHA256=h(parent/'freeze.json'),overlayFreezeSHA256=h(P/'freeze.json'),modelSHA256=h(S/model),productionSourceChanges=0,exactCases=plan['caseCount'],fixedOuterSeconds=60,killAfterSeconds=5,failedOriginalFilesPinned=8 if stage_name=='05-native8' else 0),indent=2)+'\n')
 (S/'README-socket-correction.txt').write_text('''PRIVATE UNRUN model-only socket-factory correction. Same exact IDs/60+5,
real retained TD/FD/Task/Thread/Child boundaries and terminal checks unchanged.
Native8 guards both failed attempts: old2 + new6 actual retained files plus
all actual retained nodes. Query10 keeps its exact one-line registry proposal.
No source capability/admission/budget changes. Root owns all execution.
''')
 for p in S.rglob('*.py'):ast.parse(p.read_bytes())
 (S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_MODEL_SOCKET_CORRECTED',files={str(p.relative_to(S)):h(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2)+'\n')
 (TOP/'freeze.json').write_text(json.dumps(dict(files={str(p.relative_to(TOP)):h(p) for p in sorted(TOP.rglob('*')) if p.is_file()}),indent=2)+'\n')
 print(json.dumps(dict(stage=str(S),stageFreeze=h(S/'freeze.json'),parentFreeze=h(TOP/'freeze.json'),modelSHA256=h(S/model))))
print('OVERLAY',h(P/'freeze.json'))
