"""Fresh Picker3 storage: full immutable UI/input/value originals, compact WAL.

Existing Picker1/2 decoders and WALs remain literal. No record is migrated,
trimmed, hashed in place of retaining bytes or adopted from an unknown inode.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace,FunctionType,MethodType,ModuleType,CodeType,MappingProxyType
import hashlib,os,re,sys,stat
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.operation_transport_guard import check as transport_check
from adapters.script_feature.history import MAX_RAW,canonical,pack,unpack,same
from ios.adapters.assets_budget import operation
from ios.adapters.assets_controls import project
from ios.adapters.assets_model_sources import AssetsModelSources
from ios.adapters.assets_page_picker import PageLeasePicker

VERSION=3
VALUES=('workBeforeSelect','negativeWindow','cleanupWindow')
FIELDS={'phase','page','picker','captures','inputs',*VALUES}
PROFILES={'capture':('assets-picker-capture','iosAssetsPickerCapture','sources',96),
          'input':('assets-picker-input','iosAssetsPickerInput','inputs',64),
          'value':('assets-picker-value','iosAssetsPickerValue','sources',131)}


def digest(value):return hashlib.sha256(canonical(value)).hexdigest()


class OriginalPageLeasePicker(PageLeasePicker):
    OWNER_VERSION=VERSION
    def __init__(self,*args,**kwargs):
        self.storage=None;self.stores=None;self._writing=None;self._wire=None;self.historical=False;self._intent_validation=None
        super().__init__(*args,**kwargs);self._init_storage()
        if self.previous is None:self.storage=self.empty_storage()
        else:self._wire=deepcopy(unpack(self.previous['payload'])[0]);self.storage=deepcopy(self._wire['originals'])
    @staticmethod
    def empty_storage():return dict(captures=[],inputs=[],inputHistory=[],values={key:None for key in VALUES},valueHistory=[],pending=None)
    def _init_storage(self):
        if getattr(self,'stores',None) is not None:return
        self.stores={}
        for kind,(namespace,schema,mode,_limit) in PROFILES.items():
            self.stores[kind]=OriginalFrameStore(self.store.path.parent,self.binding,self.files.run,self.files.role,
                self.metadata_guard,lambda transition,ref,kind=kind:self.intent_original(kind,transition,ref),
                namespace=namespace,schema_prefix=schema,kind=mode,monotonic=self.monotonic)
    def metadata_guard(self):
        self.lock.assert_held();self.files.envelope_guard();PrivateFeatureState(self.store.path)._parent()
        need(same(self.store.read(),self.previous));return True
    def ready(self):
        self._init_storage();self.metadata_guard();transport_check()
        need(not getattr(self,'historical',False) and self.storage is not None and self.storage['pending'] is None)
        if self.previous is not None:
            current=unpack(self.previous['payload']);need(len(current)==1 and same(self.storage,current[0]['originals']))
        self._shape(self.storage);self.membership(self.storage);need(self.files.native.guard() is not False);return True
    def context(self):
        return dict(pickerHeader=str(self.store.path),fileOwnerToken=self.files.state['token'],
            ticket=self.files.state['ticket'],resource=self.files.state['resource'],extra=self.extra_envelope())
    def envelope(self,wire):
        return dict(iosAssetsPickerOwnerVersion=VERSION,**self.extra_envelope(),runId=self.files.run,binding=self.binding,
            fileOwnerToken=self.files.state['token'],payload=pack([wire]))
    def _persist(self,wire):
        self.metadata_guard();transport_check();need(not getattr(self,'historical',False) and self.files.native.guard() is not False)
        value=self.envelope(wire);self._decode(value,membership=wire['originals'])
        self.store.write(value,self.previous);need(same(self.store.read(),value));self.previous=deepcopy(value);self._wire=deepcopy(wire)
    def _persist_transition(self,wire):
        validation=getattr(self,'_intent_validation',None)
        if validation is None:return self._persist(wire)
        return validation.persist(wire)
    def intent_original(self,kind,transition,ref):
        need(transition=='original' and self._writing==kind and self.storage['pending'] is not None)
        pending=self.storage['pending'];need(pending['kind']==kind);store=self.stores[kind];store.original(ref)
        prior=pending['original']
        if prior is None:need(ref['phase']=='planned')
        else:
            need(ref['index']==prior['index'] and ref['sha256']==prior['sha256'] and ref['bytes']==prior['bytes'])
            need((prior['phase'],ref['phase']) in (('planned','opened'),('opened','saved')))
            if prior['phase']=='opened':need(same(ref['file'],prior['file']))
        pending['original']=deepcopy(ref);wire=deepcopy(self._wire);wire['originals']=deepcopy(self.storage);self._persist_transition(wire);return True
    def _read(self,kind,ref):
        body=self.stores[kind].read(self.stores[kind].expand(ref));exact(body,{'pickerOriginalVersion','context','kind','key','previous','data'})
        need(type(body['pickerOriginalVersion']) is int and body['pickerOriginalVersion']==1 and body['kind']==kind
            and same(body['context'],self.context()));return body
    def membership(self,storage):
        known=set();root=self.store.path.parent;prefixes=[]
        groups={'capture':storage['captures'],'input':storage['inputHistory'],'value':storage['valueHistory']}
        for kind,refs in groups.items():
            store=self.stores[kind];prefixes.append(store.namespace+'-frame-'+store.kind+'-')
            for ref in refs:known.add(store.path(store.expand(ref)))
        pending=storage['pending']
        if pending is not None and pending['original'] is not None:
            store=self.stores[pending['kind']];ref=pending['original'];store.original(ref);path=store.path(ref)
            if ref['phase']=='planned':need(not os.path.lexists(path))
            else:known.add(path);AssetsModelSources.prefix(SimpleNamespace(originals=store),ref)
        entries=list(root.iterdir());need(len(entries)<=4096)
        actual={p for p in entries if p.name.startswith(tuple(prefixes))}
        need(actual==known);return known
    def _shape(self,s):
        exact(s,{'captures','inputs','inputHistory','values','valueHistory','pending'})
        for kind,key in (('capture','captures'),('input','inputHistory'),('value','valueHistory')):
            need(type(s[key]) is list and len(s[key])<=PROFILES[kind][3])
            for index,ref in enumerate(s[key],1):need(self.stores[kind].expand(ref)['index']==index)
        need(type(s['inputs']) is list and len(s['inputs'])<=16);exact(s['values'],set(VALUES))
        if s['pending'] is not None:
            p=s['pending'];exact(p,{'kind','key','bodySha256','original','target'})
            need(p['kind'] in PROFILES and type(p['bodySha256']) is str and re.fullmatch('[0-9a-f]{64}',p['bodySha256']))
            exact(p['target'],{'phase','page','picker'})
            need(p['target']['phase'] in ('reserved','page-open','picker-open','primary-chosen','checking-unavailable','unavailable',
                'canceling','picker-closed','closing-page','page-closed','retired',self.retirement_phase()))
            from ios.adapters.assets_controls import identity
            for field in ('page','picker'):
                if p['target'][field] is not None:identity(p['target'][field])
            group={'capture':'captures','input':'inputHistory','value':'valueHistory'}[p['kind']]
            need(len(s[group])<PROFILES[p['kind']][3])
            if p['kind']=='capture':need(type(p['key']) is int and p['key']==len(s['captures'])+1)
            elif p['kind']=='input':need(type(p['key']) is str and re.fullmatch('[a-z][a-z-]{0,39}',p['key']))
            else:need(p['key'] in VALUES)
            if p['original'] is not None:
                self.stores[p['kind']].original(p['original']);need(p['original']['index']==len(s[group])+1)
        return s
    def _input_transition(self,old,new):
        exact(new,{'slot','id','action','text','reference','command','receipt','resolvedBy'})
        if old is None:need(new['command'] is None and new['receipt'] is None and new['resolvedBy'] is None);return
        need(same({k:v for k,v in old.items() if k not in ('command','receipt','resolvedBy')},
            {k:v for k,v in new.items() if k not in ('command','receipt','resolvedBy')}))
        changes=0
        for key in ('command','receipt','resolvedBy'):
            if old[key] is not None:need(same(old[key],new[key]))
            elif new[key] is not None:changes+=1
        need(changes==1)
    def _value_transition(self,key,old,new):
        need(key in VALUES and new is not None)
        if key!='workBeforeSelect':
            exact(new,{'kind','requests','hostBrackets'});need(new['kind']==('unavailable' if key=='negativeWindow' else 'cleanup'))
        if old is None:return
        need(key!='workBeforeSelect');exact(old,{'kind','requests','hostBrackets'})
        need(new['kind']==old['kind'] and len(new['requests'])==len(old['requests'])+1
            and same(new['requests'][:-1],old['requests']) and same(new['hostBrackets'][:-1],old['hostBrackets']))
    def _hydrate(self,wire):
        exact(wire,{'phase','page','picker','originals'});s=self._shape(wire['originals']);captures=[]
        for index,ref in enumerate(s['captures'],1):
            body=self._read('capture',ref);need(body['key']==index and body['previous'] is None)
            data=body['data'];exact(data,{'packet','receipt'});receipt=data['receipt'];exact(receipt,{'schemaVersion','commandId','observation'})
            need(type(receipt['schemaVersion']) is int and receipt['schemaVersion']==1 and type(receipt['commandId']) is str
                and re.fullmatch('ios-[0-9a-f]{32}',receipt['commandId']) and same(receipt['observation'],data['packet']))
            captures.append(deepcopy(data['packet']))
        inputs={};latest={};counts={}
        for ref in s['inputHistory']:
            body=self._read('input',ref);key=body['key'];entry=body['data'];need(type(key) is str and entry.get('slot')==key)
            need(same(body['previous'],latest.get(key)));self._input_transition(inputs.get(key),entry)
            counts[key]=counts.get(key,0)+1;need(counts[key]<=4);inputs[key]=deepcopy(entry);latest[key]=ref
        need(same(s['inputs'],list(latest.values())))
        values={key:None for key in VALUES};value_refs={};value_counts={}
        for ref in s['valueHistory']:
            body=self._read('value',ref);key=body['key'];need(key in VALUES and same(body['previous'],value_refs.get(key)))
            self._value_transition(key,values[key],body['data']);values[key]=deepcopy(body['data']);value_refs[key]=ref
            value_counts[key]=value_counts.get(key,0)+1;need(value_counts[key]<=(1 if key=='workBeforeSelect' else 65))
        need(all(same(s['values'][key],value_refs.get(key)) for key in VALUES))
        state=dict(phase=wire['phase'],page=wire['page'],picker=wire['picker'],captures=captures,inputs=list(inputs.values()),**values)
        need(len(canonical([state]))<=MAX_RAW);return self.validate_state(state)
    def _decode(self,value,*,membership):
        self._init_storage();exact(value,{'iosAssetsPickerOwnerVersion','runId','binding','fileOwnerToken','payload'}|set(self.extra_envelope()))
        self.validate_extra(value);need(type(value['iosAssetsPickerOwnerVersion']) is int and value['iosAssetsPickerOwnerVersion']==VERSION
            and value['runId']==self.files.run and same(value['binding'],self.binding) and value['fileOwnerToken']==self.files.state['token'])
        rows=unpack(value['payload']);need(len(rows)==1);state=self._hydrate(rows[0]);self._shape(membership);self.membership(membership);return state
    def decode(self,value):
        self._init_storage()
        current=unpack((self.previous if self.previous is not None else value)['payload']);need(len(current)==1)
        return self._decode(value,membership=current[0]['originals'])
    def _record(self,kind,key,data,previous):
        need(self.storage['pending'] is None and self._writing is None)
        group={'capture':'captures','input':'inputHistory','value':'valueHistory'}[kind];index=len(self.storage[group])+1
        need(index<=PROFILES[kind][3]);body=dict(pickerOriginalVersion=1,context=self.context(),kind=kind,key=key,previous=deepcopy(previous),data=deepcopy(data))
        need(getattr(self,'_intent_validation',None) is None)
        validation=IntentTransitions(self,body) if _intent_default(self) else nullcontext(None)
        with validation as current:
            self._intent_validation=current
            try:
                self.storage['pending']=dict(kind=kind,key=key,bodySha256=digest(body),original=None,
                    target={field:deepcopy(self.state[field]) for field in ('phase','page','picker')})
                wire=deepcopy(self._wire);wire['originals']=deepcopy(self.storage);self._persist_transition(wire);self._writing=kind
                try:ref=self.stores[kind].write(index,body)
                finally:self._writing=None
            finally:self._intent_validation=None
        need(self.storage['pending']['original']['phase']=='saved');self._accept_pending(ref,body)
    def _accept_pending(self,ref,body):
        p=self.storage['pending'];need(p is not None and p['original'] is not None and p['original']['phase']=='saved'
            and same(self.stores[p['kind']].compact(p['original']),ref) and digest(body)==p['bodySha256']
            and body['kind']==p['kind'] and body['key']==p['key'] and same(body['context'],self.context()))
        kind,key=p['kind'],p['key'];s=self.storage
        if kind=='capture':need(key==len(s['captures'])+1);s['captures'].append(ref)
        elif kind=='input':
            refs=s['inputHistory'];old=[self._read('input',r) for r in s['inputs']];keys=[r['key'] for r in old]
            self._input_transition(None if key not in keys else old[keys.index(key)]['data'],body['data'])
            need(same(body['previous'],None if key not in keys else s['inputs'][keys.index(key)]))
            refs.append(ref)
            if key in keys:s['inputs'][keys.index(key)]=ref
            else:need(len(s['inputs'])<16);s['inputs'].append(ref)
        else:
            previous=None if s['values'][key] is None else self._read('value',s['values'][key])['data']
            self._value_transition(key,previous,body['data']);s['valueHistory'].append(ref);s['values'][key]=ref
        target=p['target'];s['pending']=None;wire=dict(**deepcopy(target),originals=deepcopy(s));self._persist(wire)
    def save(self):
        self._init_storage();self.ready();self.validate_state(self.state);need(len(canonical([self.state]))<=MAX_RAW)
        if self._wire is None:
            need(not self.state['captures'] and not self.state['inputs'] and all(self.state[k] is None for k in VALUES))
            self._wire=dict(**{k:deepcopy(self.state[k]) for k in ('phase','page','picker')},originals=deepcopy(self.storage));self._persist(self._wire);return
        need(len(self.storage['captures'])<=len(self.state['captures'])<=len(self.storage['captures'])+1)
        if len(self.state['captures'])>len(self.storage['captures']):
            self._record('capture',len(self.state['captures']),dict(packet=deepcopy(self.state['captures'][-1]),receipt=deepcopy(self.native.last_receipt)),None)
        for index,entry in enumerate(self.state['inputs']):
            old_ref=self.storage['inputs'][index] if index<len(self.storage['inputs']) else None
            old=None if old_ref is None else self._read('input',old_ref)['data']
            if not same(old,entry):self._record('input',entry['slot'],entry,old_ref)
        need(len(self.storage['inputs'])==len(self.state['inputs']))
        for key in VALUES:
            ref=self.storage['values'][key];old=None if ref is None else self._read('value',ref)['data']
            if not same(old,self.state[key]):self._record('value',key,self.state[key],ref)
        wire=dict(**{k:deepcopy(self.state[k]) for k in ('phase','page','picker')},originals=deepcopy(self.storage));self._persist(wire)
    @operation
    def recover_storage_saved(self):
        self._init_storage();self.metadata_guard();transport_check();need(not getattr(self,'historical',False) and self.files.native.guard() is not False)
        p=self.storage['pending'];need(p is not None and p['original'] is not None and p['original']['phase']=='saved')
        ref=self.stores[p['kind']].compact(p['original']);body=self._read(p['kind'],ref);self._accept_pending(ref,body)
        self.state=self.decode(self.previous);return dict(recorded=True,nativeQueryRepeated=False,nativeInputRepeated=False,currentFactProduced=False)

    @operation
    def capture(self):self.ready();return super().capture()
    @operation
    def input(self,*args,**kwargs):self.ready();return super().input(*args,**kwargs)
    @operation
    def resolve_pending(self):self.ready();return super().resolve_pending()
    @operation
    def open_page(self):self.ready();return super().open_page()
    @operation
    def open_picker(self):self.ready();return super().open_picker()
    @operation
    def choose_primary(self):self.ready();return super().choose_primary()
    @operation
    def prepare(self):self.ready();return super().prepare()
    @operation
    def select_after_primary(self):self.ready();return super().select_after_primary()
    @operation
    def retire_and_select(self):self.ready();return super().retire_and_select()
    @operation
    def observe_unavailable(self):self.ready();return super().observe_unavailable()
    @operation
    def cancel(self):self.ready();return super().cancel()
    @operation
    def recover_cancel(self):self.ready();return super().recover_cancel()
    @operation
    def close_page(self):self.ready();return super().close_page()
    @operation
    def recover_close(self):self.ready();return super().recover_close()
    @operation
    def cancel_owned(self):self.ready();return super().cancel_owned()
    @operation
    def retire_inputs(self):self.ready();return super().retire_inputs()
    @operation
    def close_shared_page(self):self.ready();return super().close_shared_page()
    def _window(self,*args,**kwargs):self.ready();return super()._window(*args,**kwargs)
    @operation
    def release(self):self.ready();return super().release()
    @operation
    def recover_release(self):self.ready();return super().recover_release()


def picker_type(value):
    if value is None:return OriginalPageLeasePicker
    need(type(value) is dict and type(value.get('iosAssetsPickerOwnerVersion')) is int)
    version=value['iosAssetsPickerOwnerVersion'];need(version in (2,VERSION))
    return PageLeasePicker if version==2 else OriginalPageLeasePicker


def admit_page_picker(picker):
    """Admit only the two explicit shared-page storage profiles.

    This is a storage/type binding check. The caller still performs its same
    page/action/lock/native checks before an actual operation. No subclass or
    missing/mismatched stored profile gains authority through this function.
    """
    actual=type(picker)
    need(actual in (PageLeasePicker,OriginalPageLeasePicker))
    expected=2 if actual is PageLeasePicker else VERSION
    need(type(picker.OWNER_VERSION) is int and picker.OWNER_VERSION==expected)
    stored=picker.store.read();need(same(stored,picker.previous))
    if stored is None:need(picker.state is None)
    else:
        need(type(stored) is dict and type(stored.get('iosAssetsPickerOwnerVersion')) is int
            and stored['iosAssetsPickerOwnerVersion']==expected and picker.state is not None)
    return True


def page_picker_owner(native,files,store,binding,**kwargs):
    # This is an explicit fresh-birth storage selection. Existing2 is read and
    # written by its SAME literal class; no new original or version is emitted.
    return picker_type(store.read())(native,files,store,binding,**kwargs)


class IntentTransitions:
    """One synchronous original-write custody span, never a native verdict.

    Only pending-write metadata changes here. Every final publication still
    enters the complete original decoder in _persist/_accept_pending. No parsed
    frame/result or native/guard verdict is retained by this object.
    """
    def __init__(self,owner,body):
        self.owner,self.body=owner,deepcopy(body);owner.metadata_guard()
        need(owner.previous is not None and owner.storage['pending'] is None)
        owner._decode(owner.previous,membership=owner.storage)
        self.context=deepcopy(owner.context());self.binding=canonical(owner.binding)
        self.file_state=canonical(owner.files.state);self.file_header=deepcopy(owner.files.previous)
        self.logical_state=canonical(owner.state);self.files,self.page,self.episode=owner.files,owner.page_lease,owner.episode
        self.lock,self.file_lock=owner.lock,owner.files.lock;self.stores=dict(owner.stores)
        self.store_contexts={kind:self.store_context(store) for kind,store in self.stores.items()}
        self.base=deepcopy(owner._wire);self.target={key:deepcopy(owner.state[key]) for key in ('phase','page','picker')}
        # Warm only actual typed pending fields before closing parser namespaces.
        warm=deepcopy(owner.storage);warm['pending']=dict(kind=body['kind'],key=body['key'],bodySha256=digest(body),original=None,target=self.target)
        owner._shape(warm)
        self.policy=_intent_code_policy(owner);self.policy.module(sys.modules[__name__])
        paths={Path(vars(module)['__file__']).resolve() for module in self.policy.modules if type(vars(module).get('__file__')) is str}
        self.source_bytes={path:self.source_file(path) for path in paths}
        self.disabled=False;self.typed_transitions=0;self.fast()
    def __enter__(self):return self
    def __exit__(self,kind,error,traceback):
        # A mutation may use the literal decoder while active; successful close
        # still requires original namespaces/context restored and unchanged.
        self.full();need(self.policy.unchanged());return False
    @staticmethod
    def source_file(path):
        fields=('st_dev','st_ino','st_mode','st_uid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        before=path.lstat();need(stat.S_ISREG(before.st_mode) and before.st_nlink==1)
        descriptor=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0)|getattr(os,'O_CLOEXEC',0))
        with os.fdopen(descriptor,'rb') as stream:
            opened=os.fstat(stream.fileno());need(tuple(getattr(opened,key) for key in fields)==tuple(getattr(before,key) for key in fields))
            raw=stream.read();after=os.fstat(stream.fileno())
        need(tuple(getattr(after,key) for key in fields)==tuple(getattr(before,key) for key in fields)
            and tuple(getattr(path.lstat(),key) for key in fields)==tuple(getattr(before,key) for key in fields)
            and len(raw)==before.st_size)
        return tuple(getattr(before,key) for key in fields),raw
    def store_context(self,store):
        return canonical(dict(root=str(store.root),binding=store.binding,run=store.run,role=store.role,
            namespace=store.namespace,schema=store.schema_prefix,kind=store.kind))
    def fast(self):
        owner=self.owner
        need(owner.lock is self.lock and owner.files.lock is self.file_lock)
        self.lock.assert_held();self.file_lock.assert_held();need(same(owner.store.read(),owner.previous))
        need(set(owner.stores)==set(self.stores))
        for kind,store in self.stores.items():
            need(owner.stores[kind] is store and self.store_context(store)==self.store_contexts[kind]
                and getattr(store.guard,'__self__',None) is owner
                and _same_intent_function(store.guard,owner.metadata_guard))
        need(owner.files is self.files and owner.page_lease is self.page and owner.episode is self.episode
            and canonical(owner.binding)==self.binding and canonical(owner.files.state)==self.file_state
            and canonical(owner.state)==self.logical_state and same(owner.files.previous,self.file_header)
            and same(owner.files.store.read(),self.file_header))
        need(all(same(owner._wire[key],self.base[key]) for key in ('phase','page','picker')))
        left={key:value for key,value in owner._wire['originals'].items() if key!='pending'}
        right={key:value for key,value in self.base['originals'].items() if key!='pending'};need(same(left,right))
        return True
    def full(self):
        self.owner.metadata_guard();self.fast();self.owner.membership(self.owner.storage)
        need(self.owner.files.native.guard() is not False and same(self.owner.context(),self.context))
        need(all(self.source_file(path)==raw for path,raw in self.source_bytes.items()))
        self.fast();self.owner.membership(self.owner.storage);self.owner.metadata_guard();return True
    def transition(self,wire):
        owner=self.owner;exact(wire,{'phase','page','picker','originals'});owner._shape(wire['originals'])
        old=unpack(owner.previous['payload']);need(len(old)==1 and same(old[0],owner._wire))
        need(all(same(wire[key],old[0][key]) for key in ('phase','page','picker')))
        before=old[0]['originals'];after=wire['originals']
        need(same({key:value for key,value in before.items() if key!='pending'},
            {key:value for key,value in after.items() if key!='pending'}))
        pending=after['pending'];need(pending is not None and pending['kind']==self.body['kind'] and pending['key']==self.body['key']
            and pending['bodySha256']==digest(self.body) and same(pending['target'],self.target))
        prior=before['pending']
        if prior is None:need(pending['original'] is None)
        else:
            need(same({key:value for key,value in prior.items() if key!='original'},
                {key:value for key,value in pending.items() if key!='original'}))
            a,b=prior['original'],pending['original'];need(b is not None)
            if a is None:need(b['phase']=='planned')
            else:
                need((a['phase'],b['phase']) in (('planned','opened'),('opened','saved'))
                    and all(same(a[key],b[key]) for key in a if key not in ('phase','file')))
                if a['phase']=='opened':need(same(a['file'],b['file']))
        return pending
    def persist(self,wire):
        owner=self.owner;self.full();self.transition(wire)
        if self.disabled or not self.policy.unchanged():
            self.disabled=True;return owner._persist(wire)
        groups={'capture':wire['originals']['captures'],'input':wire['originals']['inputHistory'],'value':wire['originals']['valueHistory']}
        owner.membership(wire['originals'])
        for kind,refs in groups.items():
            for ref in refs:
                self.fast()
                if not self.policy.unchanged():self.disabled=True;return owner._persist(wire)
                # OriginalFrameStore retains its actual before/after guard,
                # body hash, typed envelope, inode, mode, size and deadline.
                body=owner.stores[kind].read(owner.stores[kind].expand(ref))
                exact(body,{'pickerOriginalVersion','context','kind','key','previous','data'})
                need(type(body['pickerOriginalVersion']) is int and body['pickerOriginalVersion']==1
                    and body['kind']==kind and same(body['context'],self.context));self.fast()
                if not self.policy.unchanged():self.disabled=True;return owner._persist(wire)
        owner.membership(wire['originals']);self.full()
        if not self.policy.unchanged():self.disabled=True;return owner._persist(wire)
        value=owner.envelope(wire)
        need(type(value['iosAssetsPickerOwnerVersion']) is int and value['iosAssetsPickerOwnerVersion']==VERSION
            and value['runId']==owner.files.run and same(value['binding'],owner.binding)
            and value['fileOwnerToken']==owner.files.state['token']);owner.validate_extra(value)
        need(same({key:item for key,item in value.items() if key!='payload'},
            {key:item for key,item in owner.previous.items() if key!='payload'}))
        self.fast();need(self.policy.unchanged())
        owner.store.write(value,owner.previous);need(same(owner.store.read(),value))
        owner.previous=deepcopy(value);owner._wire=deepcopy(wire)
        self.full();need(self.policy.unchanged());self.typed_transitions+=1;return True



def _intent_function(value):
    receiver=value.__self__ if type(value) is MethodType else None
    function=value.__func__ if type(value) is MethodType else value
    return receiver,function,function.__code__ if type(function) is FunctionType else None


def _same_intent_function(left,right):
    a,b=_intent_function(left),_intent_function(right)
    return a[0] is b[0] and a[1] is b[1] and a[2] is b[2]


class _IntentIdentity:
    __slots__=('value',)
    def __init__(self,value):self.value=value
    def __eq__(self,other):return type(other) is _IntentIdentity and self.value is other.value
    def __hash__(self):return id(self.value)


def _intent_value(value,seen=None):
    # Strong code/function/receiver installation identities. All ordinary codec
    # containers and instance dictionaries retain complete recursive contents.
    seen=set() if seen is None else seen
    if type(value) in (type(None),bool,int,float,str,bytes):return type(value),value
    if id(value) in seen:return 'cycle',_IntentIdentity(value)
    seen=seen|{id(value)}
    if type(value) is FunctionType:
        return (FunctionType,_IntentIdentity(value),_IntentIdentity(value.__code__),
            _intent_value(value.__defaults__,seen),_intent_value(value.__kwdefaults__,seen),
            tuple(_intent_value(cell.cell_contents,seen) for cell in value.__closure__ or ()))
    if type(value) is MethodType:return MethodType,_IntentIdentity(value.__self__),_intent_value(value.__func__,seen)
    if type(value) in (classmethod,staticmethod):return type(value),_intent_value(value.__func__,seen)
    if type(value) is dict:return dict,tuple((_intent_value(key,seen),_intent_value(item,seen)) for key,item in value.items())
    if type(value) in (tuple,list):return type(value),tuple(_intent_value(item,seen) for item in value)
    if type(value) in (set,frozenset):return type(value),frozenset(_intent_value(item,seen) for item in value)
    if type(value) in (CodeType,ModuleType,type):return type(value),_IntentIdentity(value)
    attributes=getattr(value,'__dict__',None)
    if type(attributes) is dict:return type(value),_IntentIdentity(value),_intent_value(attributes,seen)
    return type(value),_IntentIdentity(value)


_TRANSPORT_PORTS=MappingProxyType({'adapters.asset_backend_client':frozenset(('build_opener',)),
    'ios.adapters.normal_input':frozenset(('urlopen',))})


def _transport_code(value,seen=None):
    """Code/binding identity of exactly two IO ports, never live IO state."""
    seen=set() if seen is None else seen
    if id(value) in seen:return type(value),_IntentIdentity(value)
    seen=seen|{id(value)}
    if type(value) is MethodType:
        return MethodType,_IntentIdentity(value.__self__),_transport_code(value.__func__,seen)
    if type(value) is FunctionType:
        return (FunctionType,_IntentIdentity(value),_IntentIdentity(value.__code__),
            _IntentIdentity(value.__defaults__),_IntentIdentity(value.__kwdefaults__),
            None if value.__kwdefaults__ is None else tuple(value.__kwdefaults__),
            tuple(_IntentIdentity(cell) for cell in value.__closure__ or ()))
    implementation=getattr(type(value),'__call__',None)
    attributes=vars(value) if hasattr(value,'__dict__') else {}
    callbacks=tuple((name,_transport_code(item,seen)) for name,item in attributes.items() if callable(item))
    receiver,function,code=_intent_function(implementation)
    return (type(value),_IntentIdentity(value),_IntentIdentity(receiver),_IntentIdentity(function),_IntentIdentity(code),callbacks)


def _intent_code_policy(owner):
    from ios.adapters.assets_historical_picker_snapshots import ClosedParserPolicy
    checker=_intent_default;check_code=checker.__code__;ports=_TRANSPORT_PORTS
    class CodePolicy(ClosedParserPolicy):
        def value(self,namespace,name):
            if name in ports.get(namespace.get('__name__'),()):
                port=namespace[name];need(callable(port));return 'transport-code-only',_transport_code(port)
            return _intent_value(namespace[name])
        def add(self,namespace,names):
            names=tuple(names);self.rows.append((namespace,names,tuple(self.value(namespace,name) for name in names)))
        def unchanged(self):
            if _intent_default is not checker or checker.__code__ is not check_code or not checker(owner):return False
            for namespace,names,values in self.rows:
                if any(name not in namespace for name in names):return False
                if tuple(self.value(namespace,name) for name in names)!=values:return False
            for module,names in self.module_names.items():
                if tuple(vars(module))!=names:return False
            for cls,names in self.classes.items():
                if tuple(vars(cls))!=names:return False
            return checker(owner)
    policy=CodePolicy();policy.follow(CodePolicy);return policy


def _make_intent_profile():
    namespace=globals();owner_class=OriginalPageLeasePicker;ports=_TRANSPORT_PORTS;identity=_IntentIdentity
    eq=identity.__eq__;eq_code=eq.__code__;identity_init=identity.__init__;identity_init_code=identity_init.__code__
    identity_hash=identity.__hash__;identity_hash_code=identity_hash.__code__
    helpers=tuple((name,namespace[name],namespace[name].__code__,namespace[name].__defaults__,namespace[name].__kwdefaults__) for name in
        ('_intent_function','_same_intent_function','_intent_value','_transport_code','_intent_code_policy','_make_intent_profile'))
    names={name for cls in owner_class.__mro__ for name,value in vars(cls).items() if type(value) is FunctionType}
    rows=tuple((name,getattr(owner_class,name),getattr(owner_class,name).__code__,_intent_value(getattr(owner_class,name))) for name in sorted(names))
    methods=MappingProxyType({name:(function,code) for name,function,code,_pin in rows})
    def allowed(owner):
        # The immutable view is checked against this independent closed-over
        # installation tuple; replacing the public map cannot attest itself.
        if namespace.get('_INTENT_METHODS') is not methods or namespace.get('_intent_default') is not allowed:return False
        if allowed.__code__ is not gate_code or namespace.get('OriginalPageLeasePicker') is not owner_class:return False
        if namespace.get('_TRANSPORT_PORTS') is not ports or namespace.get('_IntentIdentity') is not identity:return False
        if identity.__eq__ is not eq or eq.__code__ is not eq_code:return False
        if identity.__init__ is not identity_init or identity_init.__code__ is not identity_init_code:return False
        if identity.__hash__ is not identity_hash or identity_hash.__code__ is not identity_hash_code:return False
        if type(owner) is not owner_class or type(owner.OWNER_VERSION) is not int or owner.OWNER_VERSION!=VERSION:return False
        for name,function,code,defaults,kwdefaults in helpers:
            if (namespace.get(name) is not function or function.__code__ is not code
                or function.__defaults__ is not defaults or function.__kwdefaults__ is not kwdefaults):return False
        for name,function,code,pin in rows:
            actual=getattr(owner,name)
            if (type(actual) is not MethodType or actual.__self__ is not owner or actual.__func__ is not function
                or function.__code__ is not code or _intent_value(function)!=pin):return False
        return True
    gate_code=allowed.__code__
    return methods,allowed


_INTENT_METHODS,_intent_default=_make_intent_profile()
