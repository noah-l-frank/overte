"""Actual complete historical Emote Callback Live2 on preserved747 originals.

No live constructor, resolve/bound/save, SDK/native/input/clock callback or
original write is used. cProfile attributes decoder work, never performance.
"""
from pathlib import Path
import cProfile,hashlib,importlib.machinery,json,os,pstats,stat,sys,threading,time,traceback,shutil
from run_metadata import HERE,REPO,pin,proc,publication,save,sources,registry_original,validate_frozen
assert len(sys.argv)==2 and sys.argv[1]=='profile1'
plan=validate_frozen();publication();selected=plan['diagnosticInputs']
runroot=Path(os.environ['OVERTE_EMOTE_FRAME_CONTEXT_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs/profile1') and stat.S_IMODE(runroot.stat().st_mode)==0o700
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/'profile1-publication-ready-source-map.json';approved=json.loads(ready.read_text());ready_pin=pin(ready)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
source_before=sources(plan);assert source_before==approved['sourcePins'] and registry_original()==approved['registry']
save(runroot/'runner-process-binding.json',proc(os.getpid()))
# Baselines precede every target import.
threads_before=set(threading.enumerate());self_proc=proc(os.getpid())
def group():
    result=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        row=proc(int(p.name))
        if row is not None and (row['session']==self_proc['session'] or row['processGroup']==self_proc['processGroup']):result.append(row)
    return result
baseline={(row['pid'],row['startTicks']) for row in group()}
def remaining():return [row for row in group() if (row['pid'],row['startTicks']) not in baseline]
config=json.loads((HERE/'source-root-final-map.json').read_text())
expected=[str(REPO/name) for name in config['orderedRoots']]
sys.path[:]=expected+[p for p in sys.path if not Path(p or os.getcwd()).resolve().is_relative_to(REPO)]
def spec(name):
    search=sys.path;found=None
    for i in range(len(name.split('.'))):
        found=importlib.machinery.PathFinder._get_spec('.'.join(name.split('.')[:i+1]),list(search))
        assert found is not None,name;search=found.submodule_search_locations
    return found
for name,relative in config['packageRoots'].items():assert [str(Path(x).resolve()) for x in spec(name).submodule_search_locations or ()]==[str(REPO/relative)],name
for name,row in config['modules'].items():
    path=Path(spec(name).origin).resolve(strict=True)
    assert path==REPO/row['path'] and pin(path)==source_before[row['path']],name
wal=REPO/selected['liveWAL'];feature=REPO/selected['featureWAL'];lockpath=REPO/selected['existingPrimaryLock']
inputs={str(p):pin(p) for p in (wal,feature,lockpath)}
raw=json.loads(wal.read_text());original_feature=json.loads(feature.read_text())
assert raw['role']==original_feature['role']=='primary' and raw['iosEmoteRootedLiveVersion']==2
from adapters.script_feature.history import unpack
state=unpack(original_feature['payload'])[0]
assert raw['binding']==state['binding'] and raw['runId']==original_feature['runId'] and raw['artifactRoot']==original_feature['artifactRoot']
assert Path(raw['sourceLock'])==Path(raw['primaryLock'])==lockpath
live_payload=unpack(raw['payload'])[0];assert len(live_payload['records'])==2 and live_payload['pending'] is None
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_rooted_end_lock import held_existing
from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
# Only the already-frozen metadata sources() command may launch rg, including
# the mandatory final pin check. No target operation can use a subprocess.
metadata_command=['rg','--files','-0',*plan['broadSourceRoots']]
rg_executable=Path(shutil.which('rg')).resolve(strict=True);rg_original_pin=pin(rg_executable)
metadata_subprocesses=[]
# Audit denial applies AFTER imports, before the actual decoder work. Existing
# lock opening uses O_RDWR without creating/truncating/writing its contents.
forbidden=[]
def audit(event,args):
    if event=='open':
        path,mode,flags=args
        if isinstance(path,(str,bytes,os.PathLike)):
            actual=Path(os.fsdecode(path)).resolve()
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            allowed_lock=actual==lockpath and bool(flags&os.O_RDWR) and not flags&(os.O_CREAT|os.O_TRUNC|os.O_APPEND)
            if writing and not actual.is_relative_to(runroot) and not allowed_lock:forbidden.append(event);raise RuntimeError('Readonly diagnostic refused a write')
    if event=='subprocess.Popen':
        executable,argv,cwd,environment=args
        allowed=executable=='rg' and type(argv) is list and argv==metadata_command and Path(cwd)==REPO and environment is None
        if allowed:
            assert Path(shutil.which('rg')).resolve(strict=True)==rg_executable and pin(rg_executable)==rg_original_pin
            metadata_subprocesses.append(dict(command=list(argv),cwd=str(cwd)));return
        forbidden.append(event);raise RuntimeError('Readonly diagnostic refused nonmetadata subprocess')
    if event in ('os.system','socket.__new__','socket.connect','os.remove','os.rename','os.rmdir','os.mkdir','os.chmod','os.truncate'):
        forbidden.append(event);raise RuntimeError('Readonly diagnostic refused external effect')
sys.addaudithook(audit)
profiler=cProfile.Profile();stages=[];primary_error=None;start=time.monotonic();reader=None

def measure(label,call):
    row=dict(stage=label,entered=True,returned=False);stages.append(row);save(runroot/'actual-stages.json',stages)
    before=time.monotonic();profiler.enable()
    try:
        value=call();row['returned']=True;return value
    finally:
        profiler.disable();row['seconds']=time.monotonic()-before;save(runroot/'actual-stages.json',stages)

try:
    lock=ScriptSourceLock(lockpath)
    with held_existing(lock):
        reader=measure('actual-complete-primary-live2-archive',lambda:IOSEmoteCallbackLive.archive(raw,
            store=PrivateFeatureState(wal),lock=lock,primary_lock=lock))
        assert reader.historical is True and len(reader.state['records'])==2 and reader.state['pending'] is None

except BaseException as error:
    primary_error=error
    text=''.join(traceback.format_exception(error));print(text,flush=True)
    save(runroot/'actual-original-error.json',dict(type=type(error).__name__,traceback=text))
finally:
    profiler.disable();profiler.create_stats()
    if profiler.getstats():
        profiler.dump_stats(str(runroot/'actual-decoders.pstats'));stats=pstats.Stats(profiler)
        rows=[]
        for (file,line,name),(cc,nc,tt,ct,callers) in stats.stats.items():
            if not Path(file).is_absolute():continue
            try:path=str(Path(file).resolve().relative_to(REPO))
            except (ValueError,OSError):continue
            rows.append(dict(path=path,line=line,function=name,primitiveCalls=cc,calls=nc,selfSeconds=tt,cumulativeSeconds=ct,
                callers=[dict(path=str(Path(f).resolve().relative_to(REPO)) if Path(f).is_absolute() and Path(f).resolve().is_relative_to(REPO) else '<external>',line=l,function=n,counts=list(counts) if type(counts) is tuple else counts) for (f,l,n),counts in callers.items()]))
        save(runroot/'actual-project-calls.json',sorted(rows,key=lambda row:row['cumulativeSeconds'],reverse=True))
    before=remaining();after_inputs={str(p):pin(p) for p in (wal,feature,lockpath)}
    assert inputs==after_inputs and source_before==sources(plan) and ready_pin==pin(ready)
    after=remaining();threads=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
    result=dict(status='ACTUAL_READONLY_DECODERS_RETURNED' if primary_error is None else 'ACTUAL_READONLY_DECODER_ERROR',stages=stages,seconds=time.monotonic()-start,
        originalInputsUnchanged=inputs==after_inputs,sourcePinsUnchanged=True,forbiddenAttempts=forbidden,
        remainingOwnedBeforeCensuses=before,remainingOwnedAfterCensuses=after,remainingNewThreads=threads,
        completeLiveRecords=None if reader is None else len(reader.state['records']),metadataSubprocesses=metadata_subprocesses,rgBinaryUnchanged=pin(rg_executable)==rg_original_pin,nativeCompiled=False,sdkExecuted=False,wholeEmoteQualified=False,deviceQualified=False,interruptedStackObserved=False,performanceQualification=False)
    save(runroot/'profile-result.json',result);print('ACTUAL_DIAGNOSTIC',json.dumps(result),flush=True)
    assert not forbidden and not before and not after and not threads
if primary_error is not None:raise primary_error.with_traceback(primary_error.__traceback__)
