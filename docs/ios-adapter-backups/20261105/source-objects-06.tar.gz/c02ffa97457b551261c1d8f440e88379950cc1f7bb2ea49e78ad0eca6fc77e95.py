"""Future reviewed metadata operands only; importing performs no scan."""
from pathlib import Path
import hashlib
import json
import os
import re
import stat

SOURCE = Path(__file__).resolve().parent
REPO = SOURCE.parent.parent
FIXTURE = REPO / '.ios-host-tmp/audio-normal4-retained-parent-evidence-traversal-source1-private-20261104'
PHASE_FIXTURE = REPO / '.ios-host-tmp/audio-normal4-retained-passive-snapshot-cold-diagnostic-source2-phase-entry-private-20261104'
FIXTURE_SHA = '6edf16b0bff311324a42f873d2cd0c7673f76c75cf2008fd4aacf2ab8a7d4483'
OLD = REPO / '.ios-host-tmp/audio-normal-four-action-controller4-final-preparation-20261104'
INPUT = OLD / 'temporary'
HISTORICAL_NORMAL4_HEAD = '00fafcc4c097552198456c7e7687f243801d3ed8'
CASE = 'test_audio_normal4_retained_parent_evidence.AudioNormal4RetainedParentEvidenceTests.test_actual_retired_parent_load_and_evidence_traversal_from_original_headers'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def meta(info):
    return dict(device=info.st_dev, inode=info.st_ino, mode=info.st_mode,
        uid=info.st_uid, gid=info.st_gid, nlink=info.st_nlink,
        bytes=info.st_size, mtimeNs=info.st_mtime_ns, ctimeNs=info.st_ctime_ns)


def exact_shared_source(path,info):
 if info.st_nlink==1:return None
 manifest_path=SOURCE/'readonly-shared-stdlib-sources.json'
 raw_manifest=manifest_path.read_bytes();assert hashlib.sha256(raw_manifest).hexdigest()=='9615f917af31ea6c7d57a2afa1be49db05c5e513197d50e92db81d270a6a36f4'
 manifest=json.loads(raw_manifest);std=Path(os.__file__).resolve(strict=True).parent
 assert manifest['version']==1 and manifest['actualStdlibRoot']==str(std)
 assert path.resolve(strict=True)==path and path.is_relative_to(std)and path.suffix=='.py'
 assert not any(p in('site-packages','dist-packages')for p in path.parts)
 row=manifest['sources'][str(path)]
 assert info.st_uid==0 and info.st_nlink>1 and not info.st_mode&0o022
 assert[info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns]==[row[k]for k in('device','inode','mode','uid','gid','nlink','bytes','mtimeNs','ctimeNs')]
 return row['sha256']

def pin(path):
    path = Path(path)
    before = path.lstat()
    assert path.resolve(strict=True) == path and stat.S_ISREG(before.st_mode)
    shared = exact_shared_source(path, before)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        assert meta(os.fstat(fd)) == meta(before)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        assert meta(os.fstat(fd)) == meta(before) == meta(path.lstat())
        assert len(raw) == before.st_size
    finally:
        os.close(fd)
    digest = hashlib.sha256(raw).hexdigest()
    if shared is not None:
        assert digest == shared
    return dict(meta(before), sha256=digest)


def census(root):
    """Exact existing-tree census. Called only in a later Root window."""
    root = Path(root)
    result = {}
    def visit(path):
        info = path.lstat()
        row = meta(info)
        if stat.S_ISDIR(info.st_mode):
            assert not path.is_symlink()
            with os.scandir(path) as stream:
                names = sorted(entry.name for entry in stream)
            row['namespace'] = names
            for name in names:
                visit(path / name)
        else:
            row = pin(path)
        assert meta(path.lstat()) == meta(info)
        result[str(path.relative_to(root))] = row
    visit(root)
    return result


def load(path):
    return json.loads(Path(path).read_text())


def validate(plan_path, plan_sha, source_sha, expected_head):
    assert pin(plan_path)['sha256'] == plan_sha
    assert sha(SOURCE / 'source-freeze.json') == source_sha
    frozen = load(SOURCE / 'source-freeze.json')
    assert frozen['status'] == 'SOURCE_ONLY_REQUIRES_ROOT_REVIEW_AND_SEPARATE_TARGET'
    for name, row in frozen['files'].items():
        assert sha(SOURCE / name) == row['sha256']
    plan = load(plan_path)
    assert plan['status'] == 'ROOT_REVIEWED_PREPARED_UNRUN'
    assert re.fullmatch('[0-9a-f]{40}', expected_head)
    assert plan['head'] == expected_head and head() == expected_head
    assert plan['controllerSourceFreeze'] == source_sha
    assert plan['fixtureSourceFreeze'] == FIXTURE_SHA and plan['case'] == CASE
    assert plan['seconds'] == 60 and plan['graceSeconds'] == 5
    assert plan['inputRoot'] == str(INPUT) and plan['inputEntries'] == 869
    assert plan['temporaryDirectories'] == plan['nodeChildren'] == plan['sockets'] == 0
    assert plan['inputBaseline'] == str(OLD / 'actual-originals-first.json')
    assert sha(plan['inputBaseline']) == plan['inputBaselineSha256']
    assert plan['oldOrigins'] == str(OLD / 'loaded-project-modules.json')
    assert sha(plan['oldOrigins']) == plan['oldOriginsSha256']
    for path, row in plan['physicalPins'].items():
        assert pin(path) == row
    for path, names in plan['sourceNamespaces'].items():
        assert sorted(item.name for item in Path(path).iterdir()) == names
    originals = load(plan['oldOrigins'])
    assert len(originals) == 474
    old_physical = load(OLD / 'actual-code-origins-before.json')
    assert len(old_physical) == 476
    for path, row in old_physical.items():
        assert path in plan['physicalPins']
        if Path(path).is_relative_to(REPO / '.ios-host-tmp'):
            assert all(plan['physicalPins'][path][key] == value for key, value in row.items())
    for name, row in originals.items():
        current = plan['modules'][name]
        assert current['path'] == row['path'] and current['package'] == row['package']
        if Path(row['path']).is_relative_to(REPO / '.ios-host-tmp'):
            assert current['sha256'] == row['sha256']
    for module, path in ((CASE.rsplit('.', 2)[0], FIXTURE / (CASE.split('.')[0] + '.py')),
            ('test_audio_normal4_retained_passive_snapshot', PHASE_FIXTURE / 'test_audio_normal4_retained_passive_snapshot.py')):
        assert plan['modules'][module] == dict(path=str(path), package=False,
            sha256=sha(path), loader='source')
    assert set(plan['modules']) == set(originals) | {CASE.split('.')[0], 'test_audio_normal4_retained_passive_snapshot'}
    assert plan['pythonExecutable']['pin'] == pin(plan['pythonExecutable']['path'])
    assert plan['sourceHelperSha256'] == '387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
    assert sha(SOURCE / 'closed_import_origins.py') == plan['sourceHelperSha256']
    operands = load(FIXTURE / 'selected-original-operands.json')
    assert operands['existingCensus']['path'] == plan['inputBaseline']
    assert operands['existingCensus']['sha256'] == plan['inputBaselineSha256']
    for key in ('actorLock', 'primaryLock'):
        assert pin(INPUT / operands[key]) == operands['pins'][operands[key]]
    assert pin(plan_path)['sha256'] == plan_sha
    return plan, operands


def head():
    git = Path((REPO / '.git').read_text().strip().split('gitdir: ', 1)[1])
    if not git.is_absolute():
        git = REPO / git
    common = (git / (git / 'commondir').read_text().strip()).resolve(strict=True)
    selected = (git / 'HEAD').read_text().strip()
    assert selected.startswith('ref: ')
    ref = selected[5:]
    for base in (git, common):
        if (base / ref).is_file():
            return (base / ref).read_text().strip()
    for line in (common / 'packed-refs').read_text().splitlines():
        if line and not line.startswith(('#', '^')):
            value, name = line.split(' ', 1)
            if name == ref:
                return value
    raise AssertionError('Reviewed checkout HEAD unavailable')


def fds():
    result = {}
    for path in Path('/proc/self/fd').iterdir():
        try:
            info = path.stat()
            result[path.name] = dict(target=os.readlink(path), device=info.st_dev,
                inode=info.st_ino, mode=info.st_mode)
        except (FileNotFoundError, ProcessLookupError):
            pass
    return result


def proc(pid):
    directory = Path('/proc') / str(pid)
    try:
        text = (directory / 'stat').read_text()
        executable = str((directory / 'exe').resolve(strict=True))
        second = (directory / 'stat').read_text()
        first_fields = text[text.rfind(')') + 2:].split()
        second_fields = second[second.rfind(')') + 2:].split()
        assert text[:text.index('(')] == second[:second.index('(')]
        assert [first_fields[n] for n in (1, 2, 3, 19)] == [second_fields[n] for n in (1, 2, 3, 19)]
    except (FileNotFoundError, ProcessLookupError):
        return None
    fields = text[text.rfind(')') + 2:].split()
    return dict(pid=int(text[:text.index('(')].strip()), parent=int(fields[1]),
        group=int(fields[2]), session=int(fields[3]), startTicks=int(fields[19]),
        executable=executable)
