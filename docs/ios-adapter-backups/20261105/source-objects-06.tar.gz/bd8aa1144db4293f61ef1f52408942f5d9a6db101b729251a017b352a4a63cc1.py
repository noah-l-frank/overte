"""Exact observed stdlib timeout-sentinel policy, metadata/AST only."""
import ast,difflib,hashlib,json
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/emote-callback-live-prefix-exact-socket-timeout-policy-source-fix-20261102';BASE=REPO/'.ios-host-tmp/emote-callback-live-prefix-exact-partial-policy-source-fix-20261102'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(v)
paths=['tests/device/ios/adapters/emote_callback_live.py','tests/device/ios/adapters/emote_callback_live_records.py','tests/device/ios/self_tests/test_ios_emote_callback_live_history_cache.py'];rows=[];patch=[]
for relative in paths:
 before=(REPO/relative).read_text();assert sha(REPO/relative)==next(r['candidateSHA256'] for r in json.loads((BASE/'plan.json').read_text())['sourceRows'] if r['path']==relative)
 after=before
 if relative.endswith('emote_callback_live_records.py'):
  after=after.replace('import re,sys,enum,__future__','import re,sys,enum,__future__,socket')
  needle="    if kind is FunctionType:\n";assert after.count(needle)==1
  after=after.replace(needle,"    # The sole supported plain object is this actual stdlib default sentinel.\n    # Its current module binding is separately part of EXTERNAL_READERS below.\n    if kind is object and value is socket._GLOBAL_DEFAULT_TIMEOUT:return ('socket-default-timeout',identity)\n"+needle)
  needle="EXTERNAL_READERS=((json,'loads'),";assert after.count(needle)==1
  after=after.replace(needle,"EXTERNAL_READERS=((socket,'_GLOBAL_DEFAULT_TIMEOUT'),(json,'loads'),")
 if relative.endswith('test_ios_emote_callback_live_history_cache.py'):
  after+='''
    def test_changed_actual_socket_timeout_singleton_binding_cannot_reuse_warm_history(self):
        import socket
        from urllib.request import urlopen
        original=socket._GLOBAL_DEFAULT_TIMEOUT
        self.assertIs(type(original),object);self.assertIs(urlopen.__defaults__[-1],original)
        self.assertTrue(any(value is original for value in self.history.references));self.read()
        with patch.object(socket,'_GLOBAL_DEFAULT_TIMEOUT',object()):
            self.assertFalse(self.history.literal());self.read()
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())
'''
 ast.parse(after,filename=relative);write(HERE/'base'/relative,before);write(HERE/'candidate'/relative,after)
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative));rows.append(dict(path=relative,baseSHA256=hashlib.sha256(before.encode()).hexdigest(),candidateSHA256=hashlib.sha256(after.encode()).hexdigest()))
write(HERE/'exact-socket-timeout-fix-only.diff',''.join(patch))
stdlib=[dict(path=str(p),sha256=sha(p)) for p in (Path('/usr/lib64/python3.14/urllib/request.py'),Path('/usr/lib64/python3.14/socket.py'))]
plan=dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceRows=rows,actualUnsupported=['ios.adapters.native_geometry','urlopen'],actualFailure='.ios-host-tmp/emote-callback-live-prefix-exact-partial-mechanisms14-root-preparation-20261102/smoke1/root-run-first/report.json',staticCause='Raw urllib.request.urlopen function timeout default is exact socket._GLOBAL_DEFAULT_TIMEOUT = object(); no urlopen decorator at the reviewed source definition',stdlibSourcePins=stdlib,newTreatment='ONLY exact current socket timeout singleton plain object identity, strongly retained by existing refs and explicitly bound external policy; arbitrary objects remain unsupported',mechanismCases=15,prospectiveSmoke=dict(firstSeconds=15,killAfterSeconds=5,realRoots=0),prospectiveMechanisms=dict(firstSeconds=30,killAfterSeconds=5,realRoots=15),old747ReplayForbidden=True,freshGraph='HARDHOLD pending actual changed smoke and mechanisms15 PASS',sourcePublished=False,testsRun=False,targetImported=False,SDKImported=False)
write(HERE/'plan.json',json.dumps(plan,indent=2)+'\n')
write(HERE/'freeze.json',json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(packet=str(HERE),freeze=sha(HERE/'freeze.json'),source=rows)))
