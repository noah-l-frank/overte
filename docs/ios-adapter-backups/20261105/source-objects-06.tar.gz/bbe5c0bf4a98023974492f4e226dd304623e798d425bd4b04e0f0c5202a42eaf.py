"""Actual30+5 child/kernel boundary; complete closed outputs, no old corpus."""
from pathlib import Path
import json,os,signal,subprocess,sys,threading,time,traceback
from common import SOURCE,REPO,admitted,pin,load,fds,identity,census,head
assert len(sys.argv)==4
expected_head,freeze_sha,output=sys.argv[1:];decl,before=admitted(expected_head,freeze_sha)
HERE=Path(output);OUTER=Path(output+'-outer')
assert HERE.is_absolute()and HERE.resolve()==HERE and HERE.parent==REPO/'.ios-host-tmp'and HERE.name.startswith('moving-native-idle-own5-output-')and HERE!=SOURCE and not HERE.exists()and not OUTER.exists()
old_fds,old_threads=fds(),tuple(threading.enumerate())
HERE.mkdir(mode=0o700);OUTER.mkdir(mode=0o700)
def save(name,value):
    p=OUTER/name
    with p.open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    p.chmod(0o600)
def table():
    out={}
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            v=identity(int(p.name))
            if v is not None:out[v['pid']]=v
    return out
save('source-pins-before.json',before)
initial=table();owned={};task=None;born=None;problems=[];timed_out=forced=False;term_at=None;started=time.monotonic()
try:
    with(HERE/'stdin.eof').open('xb'):pass
    with(HERE/'stdin.eof').open('rb')as incoming,(HERE/'stdout.log').open('xb')as stdout,(HERE/'stderr.log').open('xb')as stderr:
        task=subprocess.Popen([sys.executable,'-B',str(SOURCE/'run-own5.py'),expected_head,freeze_sha,str(HERE)],cwd=REPO,stdin=incoming,stdout=stdout,stderr=stderr,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    born=identity(task.pid);assert born is not None and born['parent']==os.getpid()and born['group']==born['session']==born['pid'];owned[born['pid']]=born;save('runner-birth.json',born)
    while True:
        rows=table();changed=True
        while changed:
            changed=False
            for pid,row in rows.items():
                if pid not in owned and(row['parent']in owned or row['group']==born['group']or row['session']==born['session']):
                    assert pid not in initial;owned[pid]=row;problems.append(dict(kind='forbidden-child-birth',identity=row));changed=True
        for pid,row in owned.items():
            actual=identity(pid)
            if actual is not None and actual!=row:problems.append(dict(kind='identity-changed',before=row,after=actual))
        if task.poll()is not None:break
        if time.monotonic()-started>=30 and term_at is None:assert identity(task.pid)==born;timed_out=True;term_at=time.monotonic();os.kill(task.pid,signal.SIGTERM)
        if term_at is not None and time.monotonic()-term_at>=5:assert identity(task.pid)==born;forced=True;os.kill(task.pid,signal.SIGKILL);break
        time.sleep(.025)
    task.wait()
except BaseException:problems.append(dict(kind='supervisor-exception',traceback=traceback.format_exc()))
finally:
    # Also bind a real child left by an interrupted/failed parent Popen before
    # its Python return. No absent task variable can establish process quiet.
    rows=table();changed=True
    while changed:
        changed=False
        for pid,row in rows.items():
            direct=row['parent']==os.getpid()and row!=initial.get(pid)
            linked=row['parent']in owned or born is not None and(row['group']==born['group']or row['session']==born['session'])
            if pid not in owned and(direct or linked):
                owned[pid]=row;problems.append(dict(kind='late-or-partial-constructor-child',identity=row));changed=True
    residual=[]
    for pid,row in owned.items():
        actual=identity(pid)
        if actual is not None:
            residual.append(dict(bound=row,current=actual))
            if actual==row:os.kill(pid,signal.SIGKILL)
    if task is not None:task.wait()
    remaining=[dict(bound=row,current=identity(pid))for pid,row in owned.items()if identity(pid)is not None]
    save('process-drain.json',dict(owned=list(owned.values()),residualRequiredKill=residual,remaining=remaining))
    assert not remaining
    first=census(HERE);second=census(HERE);save('whole-output-first.json',first);save('whole-output-second.json',second)
    after={p:pin(p)for p in before};save('source-pins-after.json',after)
    result=load(HERE/'result.json')if(HERE/'result.json').is_file()else None
    restoration=load(HERE/'port-restoration.json')if(HERE/'port-restoration.json').is_file()else None
    fd_after,threads_after=fds(),tuple(threading.enumerate())
    passed=task is not None and task.returncode==0 and not problems and not residual and not remaining and not timed_out and not forced and first==second and before==after and head()==expected_head and old_fds==fd_after and old_threads==threads_after
    passed=passed and result is not None and result['status']=='PASS'and result['selected']==decl['cases']and result['testsRun']==5 and result['toolRestored']and result['fdThreadDrain']and not result['nativeObservationEntries']and not result['refusals']
    passed=passed and restoration is not None and restoration['restored']and restoration['count']==27 and not restoration['controlDescriptors']
    save('parent-drain.json',dict(fdsEqual=old_fds==fd_after,threadsEqual=old_threads==threads_after))
    save('terminal.json',dict(status='PASS'if passed else'FAIL_OR_REFUSED',childReturnCode=None if task is None else task.returncode,seconds=time.monotonic()-started,timedOut=timed_out,forced=forced,problems=problems,sourcePinsEqual=before==after,twoWholeClosedOutputsEqual=first==second,ownProcessesAbsent=not remaining,temporaryDirectories=0,NodeExecutions=0,oldOriginalInputs=0,globalCensuses=0,nativeQualified=False,wholeQualified=False))
raise SystemExit(0 if passed else 1)
