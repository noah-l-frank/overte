    def _selected_motion_original_result(self,source,run,selected_query,result,reference,frame,transfer_current):
        """Decode the existing selected3 source original; no host-created owner."""
        import re
        from urllib.parse import quote,unquote
        from adapters.native_feature_observation import number
        from adapters.native_clock_join import validate_join
        from ios.adapters.lifecycle_world_attempt import source_frame_original,gesture
        from ios.adapters.lifecycle_touch_resource_owner import selected_motion_original
        from ios.adapters import native_geometry
        binding=source['binding']
        exact(frame,{'originalKeeperNativeAcquisitionFrameVersion','originals','clockJoin','reads','sdkWindow','selectedCandidate'})
        need(type(frame['originalKeeperNativeAcquisitionFrameVersion']) is int and frame['originalKeeperNativeAcquisitionFrameVersion']==3)
        originals=frame['originals'];exact(originals,{'world','worldClock','geometry','window'})
        joined=validate_join(frame['clockJoin'],originals);packet=source_frame_original(frame,binding,run)
        candidate=frame['selectedCandidate'];selected_motion_original(candidate,frame,binding,run,result['ownerInstance'])
        need(candidate['selectionQueryId']==selected_query)
        geometry=originals['geometry'];native_geometry.validate(geometry,geometry['commandId'],native_epoch_ms=joined['nativeAfter']['capturedEpochMs'])
        need(joined['nativeBefore']['capturedEpochMs']<=geometry['observation']['sampleEpochMs']<=packet['clockBefore']['epochMs'])
        sdk=frame['sdkWindow'];exact(sdk,{'method','path','reply','hostBeforeMonotonic','hostAfterMonotonic'})
        need(sdk['method']=='GET' and type(sdk['path']) is str and len(sdk['path'])<=512
            and sdk['path'].startswith('/session/') and sdk['path'].endswith('/window/rect'))
        session=unquote(sdk['path'][9:-12]);need(re.fullmatch('[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}',session) is not None
            and sdk['path']=='/session/'+quote(session,safe='')+'/window/rect')
        need(type(sdk['reply']) is dict and sdk['reply'].get('value')==originals['window']
            and number(sdk['hostBeforeMonotonic'],joined['hostBeforeMonotonic'],joined['hostAfterMonotonic'])
            and number(sdk['hostAfterMonotonic'],sdk['hostBeforeMonotonic'],joined['hostAfterMonotonic']))
        # Actual same raw UIKit geometry/window derives the complete path;
        # no x/y or dimensions arrive as caller-chosen movement authority.
        gesture(packet,geometry,originals['window'],'selected-original-reader')
        transfer_current()
        return dict(originalKeeperNativeAcquisitionVersion=3,ownerInstance=result['ownerInstance'],binding=deepcopy(binding),runId=run,
            reference=deepcopy(reference),originalFrame=deepcopy(frame),nativeAcquisitionBound=False,installedCandidateBound=False,
            nativeMotionGuardAvailable=False,nativeTouchSupport=False,resourceRetirementEstablished=False)

