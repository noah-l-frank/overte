"""Explicit Audio11 installed dispatch and retained ownership entry boundary.

Legacy configs do not acquire Audio11. Ordinary operations remain blocked until
original ends and complete current scope membership have been independently
validated; the shared readmission owner gets only its exact scoped exception.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from functools import wraps
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
from ios.adapters.audio_session_owners import PREFIX


def configuration():
    from ios.adapters.feature_configuration import configuration as read
    config=read();need(type(config) is dict and config.get('iosFeatureAdapterVersion')==11 and 'audio' in config['areas'] and config['audioCoordinatorVersion']==1)
    return config


def factory(adapter,selector,run):
    from ios.adapters.feature_configuration import reader
    config=configuration();return IOSAudioWholeFeature(adapter,selector,run,'primary',reader(config),config['audio'])


def stored(adapter,selector):
    paths=[adapter.state_path(selector).with_name('ios-audio11-whole-'+role+'.json') for role in ('primary','actor')]
    rows=[(path,PrivateFeatureState(path).read()) for path in paths];rows=[row for row in rows if row[1] is not None]
    need(len(rows)<=1);return rows[0][1] if rows else None


def existing(adapter,selector):
    value=stored(adapter,selector)
    if value is None:return None
    if value['state']['phase'] in ('ended','aborted'):
        from feature_journeys.witness import Client
        class HistoricalOnly(Client):
            def request(self,*_args,**_kwargs):raise ValueError('Historical Audio admission cannot access a fixture transport')
        client=HistoricalOnly(value['fixtureUrl'],'historical-audio-reader-with-no-transport-authority')
    else:
        config=configuration();need(value['settings']==config['audio'])
        from ios.adapters.feature_configuration import reader
        client=reader(config);need(client.url==value['fixtureUrl'])
    flow=IOSAudioWholeFeature(adapter,value['primaryTarget'],value['runId'],value['role'],client,value['settings'])
    need(flow.selector==selector);return flow


def admit_feature(adapter,selector,operation,values):
    flow=factory(adapter,selector,values['runId'])
    with flow.held():
        if flow.state is None:
            from ios.adapters.audio_session_owners import owners_absent
            need(owners_absent(adapter,selector))
            if not owners_absent(adapter,flow.actor_selector):
                peer=stored(adapter,flow.actor_selector);need(peer is not None and peer['runId']==flow.run and peer['primaryTarget']==selector and peer['settings']==flow.config)
                from ios.adapters.audio_whole_inventory import admit
                admit(flow)
        else:
            from ios.adapters.audio_whole_inventory import admit
            admit(flow)
    return flow


def ordinary(function,self,selector,args,kwargs):
    from ios.adapters.audio_whole_scope_retirement import admitted
    if not self.state_path(selector).parent.exists():return function(self,selector,*args,**kwargs)
    if admitted(self,selector):return function(self,selector,*args,**kwargs)
    name=function.__name__
    if name=='invoke' and args and type(args[0]) is str and args[0].startswith('feature.audio.'):
        need(len(args)==2 and not kwargs);admit_feature(self,selector,args[0],args[1]);return function(self,selector,*args,**kwargs)
    flow=existing(self,selector)
    if flow is None:
        from ios.adapters.audio_session_owners import ensure_released
        ensure_released(self,selector);return function(self,selector,*args,**kwargs)
    if name=='cleanup':
        with flow.held():
            closed=flow.state['phase'] in ('ended','aborted')
        if not closed:
            # Timeout/general cleanup owns abort, independent of fixture HTTP
            # availability. No new cleanup ticket or peer fact is invented.
            flow.abort()
    with flow.held():
        from ios.adapters.audio_whole_inventory import admit
        admit(flow)
        need(flow.state['phase'] in ('ended','aborted'))
        from ios.adapters.audio_whole_terminal import AudioWholeTerminal
        AudioWholeTerminal(flow).admit_archives()
        if name=='cleanup':return function(self,selector,*args,**kwargs)
    return function(self,selector,*args,**kwargs)
