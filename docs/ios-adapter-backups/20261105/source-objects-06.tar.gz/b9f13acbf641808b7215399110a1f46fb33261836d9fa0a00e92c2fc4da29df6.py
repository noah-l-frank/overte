"""Private text/AST proposal builder. Does not import any adapter."""
from pathlib import Path
import ast
import hashlib
import json
import difflib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
HELPER='tests/device/ios/adapters/tablet_web_parent_decode_handoff.py'
OWNER='tests/device/ios/adapters/tablet_web_aggregate_root.py'
TEST='tests/device/ios/self_tests/test_ios_tablet_web_parent_decode_handoff.py'

helper='''"""Reuse one already executed pure decode within one parent guard only.

No file result, successful original inventory or mutable owner epoch is cached.
All actual parent/child/copy reads remain with the caller. Unknown data or a
different literal parser epoch uses the current original copy_body decoder.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import base64
import copy
import json
import math
import re
import types

from adapters import native_feature_observation as native
from adapters import normal_feature_state as state
from adapters.script_feature import history
from feature_journeys import contract
from ios.adapters import tablet_web_child_rotation as closed
from ios.adapters import tablet_web_rotation_fence as fence

_BUILTIN_BOUND=type(re.compile('').match)


class _Unsupported(Exception):pass


def _tree(value,*,metadata=False):
    remaining=[4096];active=set()
    def visit(item,depth):
        remaining[0]-=1
        if remaining[0]<0 or depth>32:raise _Unsupported
        kind=type(item)
        if kind in (str,int,bool,type(None)):return kind,item
        if kind is float:
            if not math.isfinite(item):raise _Unsupported
            return kind,item.hex()
        if metadata and kind in (types.BuiltinFunctionType,_BUILTIN_BOUND,types.MethodDescriptorType,
                types.WrapperDescriptorType,type):return kind,item
        if kind not in (dict,list,tuple,set,frozenset):raise _Unsupported
        if not metadata and kind in (tuple,set,frozenset):raise _Unsupported
        if id(item) in active:raise _Unsupported
        active.add(id(item))
        try:
            if kind is dict:
                if not all(type(key) is str for key in item):raise _Unsupported
                result=tuple((key,visit(item[key],depth+1)) for key in sorted(item))
            elif kind in (set,frozenset):
                if not all(type(key) is str for key in item):raise _Unsupported
                result=tuple(sorted(item))
            else:result=tuple(visit(part,depth+1) for part in item)
            return kind,result
        finally:active.remove(id(item))
    return visit(value,0)


def _function(value):
    if type(value) is types.FunctionType:
        return value.__code__,_tree(value.__defaults__,metadata=True),_tree(value.__kwdefaults__,metadata=True)
    if type(value) in (types.BuiltinFunctionType,_BUILTIN_BOUND,types.MethodDescriptorType,types.WrapperDescriptorType,type):return None
    raise _Unsupported


# This is the closed pure call graph of decode/copy_body; filesystem readers
# deliberately do NOT enter this epoch, and continue executing in the caller.
_FUNCTIONS=[(closed,name) for name in ('decode','copy_body','_name','exact','need','canonical','same','deepcopy')]
_FUNCTIONS += [(fence,name) for name in ('decode','_scope','scope','_signature','_legacy','_copy','exact','need','canonical','same','context','identifier','deepcopy')]
_FUNCTIONS += [(native,'need'),(state,'need'),(state.re,'fullmatch'),(history.json,'dumps'),
    (fence.json,'loads'),(fence.base64,'b64decode'),(fence.base64,'b64encode'),
    (base64.binascii,'a2b_base64'),(base64.binascii,'b2a_base64'),(fence.hashlib,'sha256'),
    (fence.zlib,'decompressobj'),(fence.stat,'S_ISREG'),(fence.stat,'S_IMODE')]
_FUNCTIONS += [(json.JSONEncoder,name) for name in ('__init__','encode','iterencode')]
_FUNCTIONS += [(json.JSONDecoder,name) for name in ('__init__','decode','raw_decode')]
_FUNCTIONS += [(json.encoder,name) for name in ('_make_iterencode','encode_basestring','encode_basestring_ascii')]
_FUNCTIONS += [(json.decoder,name) for name in ('JSONObject','JSONArray','scanstring')]
_FUNCTIONS += [(json.scanner,'make_scanner')]
_ALIASES=[(closed,'base'),(fence,'json'),(fence,'base64'),(fence,'hashlib'),(fence,'stat'),(fence,'zlib'),
    (history,'json'),(state,'re'),(json,'JSONEncoder'),(json,'JSONDecoder'),(json,'encoder'),(json,'decoder'),(json,'scanner'),
    (json.encoder,'c_make_encoder'),(contract,'HEX')]
_CONSTANTS=[(closed,name) for name in ('VERSION','PROFILE','ORDER','MAX_FRAMES','LIMIT')]
_CONSTANTS += [(fence,name) for name in ('VERSION','LEGACY','MAX_HEAD_BYTES','COPY_KEY','MAX_FRAMES','LIMIT')]
_CONSTANTS += [(state,'CONTEXT'),(state,'COMPONENT_CONTEXT')]
_BORN_FUNCTIONS=tuple((owner,name,getattr(owner,name),_function(getattr(owner,name))) for owner,name in _FUNCTIONS)
_BORN_ALIASES=tuple((owner,name,getattr(owner,name)) for owner,name in _ALIASES)
_BORN_CONSTANTS=tuple((owner,name,_tree(getattr(owner,name),metadata=True)) for owner,name in _CONSTANTS)
_DISPATCH=tuple((kind,copy._deepcopy_dispatch[kind],_function(copy._deepcopy_dispatch[kind]))
    for kind in (dict,list,tuple,str,int,float,bool,type(None)))
_DISPATCH_TABLE=copy._deepcopy_dispatch


def _literal():
    try:
        if any(getattr(owner,name) is not original or _function(original)!=signature
                for owner,name,original,signature in _BORN_FUNCTIONS):return False
        if any(getattr(owner,name) is not original for owner,name,original in _BORN_ALIASES):return False
        if any(_tree(getattr(owner,name),metadata=True)!=value for owner,name,value in _BORN_CONSTANTS):return False
        if copy._deepcopy_dispatch is not _DISPATCH_TABLE:return False
        if any(copy._deepcopy_dispatch.get(kind) is not original or _function(original)!=signature
                for kind,original,signature in _DISPATCH):return False
        return True
    except (AttributeError,KeyError,TypeError,ValueError,RecursionError,_Unsupported):return False


def begin(value,expected):
    if not _literal():return None
    try:return _tree([value,expected])
    except _Unsupported:return None


def copy_body(value,expected,ticket):
    if ticket is None or not _literal():return closed.copy_body(value,expected)
    try:current=_tree([value,expected])
    except _Unsupported:return closed.copy_body(value,expected)
    if current!=ticket:return closed.copy_body(value,expected)
    # Literal body of closed.copy_body, after its same invocation's successful
    # complete decode. Default deepcopy receives only the exact JSON tree.
    answer=dict(tabletWebChildClosedHeaderBodyVersion=closed.VERSION,profile=closed.PROFILE,
        scope=closed.deepcopy(value['scope']),parent=closed.deepcopy(value['parent']),children=closed.deepcopy(value['children']))
    if not _literal() or _tree([value,expected])!=ticket:return closed.copy_body(value,expected)
    return answer
'''

owner=(ROOT/OWNER).read_text()
owner=owner.replace('from ios.adapters import tablet_web_rotation_fence as fence\n',
    'from ios.adapters import tablet_web_rotation_fence as fence\nfrom ios.adapters import tablet_web_parent_decode_handoff as handoff\n')
owner=owner.replace('VERSION=1\nOWNER_VERSION=4\n','VERSION=1\nOWNER_VERSION=4\n_HANDOFF_BEGIN=handoff.begin\n_HANDOFF_BEGIN_CODE=handoff.begin.__code__\n_HANDOFF_COPY=handoff.copy_body\n_HANDOFF_COPY_CODE=handoff.copy_body.__code__\n')
owner=owner.replace('        need(same(self.legacy,fence._legacy(closed.decode(self.parent,self.expected),self.expected)))\n',
    '        literal_handoff=(handoff.begin is _HANDOFF_BEGIN and handoff.begin.__code__ is _HANDOFF_BEGIN_CODE\n'
    '            and handoff.copy_body is _HANDOFF_COPY and handoff.copy_body.__code__ is _HANDOFF_COPY_CODE)\n'
    '        ticket=handoff.begin(self.parent,self.expected) if literal_handoff else None\n'
    '        need(same(self.legacy,fence._legacy(closed.decode(self.parent,self.expected),self.expected)))\n')
owner=owner.replace('        need(same(copies.read(reference),closed.copy_body(self.parent,self.expected)))\n',
    '        original=copies.read(reference)\n'
    '        literal_handoff=(literal_handoff and handoff.begin is _HANDOFF_BEGIN\n'
    '            and handoff.begin.__code__ is _HANDOFF_BEGIN_CODE and handoff.copy_body is _HANDOFF_COPY\n'
    '            and handoff.copy_body.__code__ is _HANDOFF_COPY_CODE)\n'
    '        body=(handoff.copy_body(self.parent,self.expected,ticket) if literal_handoff\n'
    '            else closed.copy_body(self.parent,self.expected))\n'
    '        need(same(original,body))\n')

test='''"""Same-invocation pure decode reuse, with actual owned originals."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from adapters.normal_ui import NativeUIError
from adapters.original_file_reads import scope
from adapters.original_frame_store import OriginalFrameStore
from ios.adapters import tablet_web_aggregate_root as aggregate
from ios.adapters import tablet_web_child_rotation as closed
from ios.adapters import tablet_web_rotation_fence as fence
from ios.self_tests import test_ios_tablet_web_aggregate_root as fixture


class TabletParentDecodeHandoffTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):fixture.TabletOwnedAggregateRootTests.setUpClass()

    def setUp(self):
        self.f=fixture.TabletOwnedAggregateRootTests();self.addCleanup(self.f.doCleanups)
        self.f.setUp();self.owner=self.f.open()

    def test_actual_guard_decodes_once_but_rereads_every_original_on_each_invocation(self):
        monitor=sys.monitoring;tool=next(i for i in range(6) if monitor.get_tool(i) is None)
        monitor.use_tool_id(tool,'tablet-parent-pure-decode-test');seen=[]
        def call(code,_offset):seen.append(code)
        monitor.register_callback(tool,monitor.events.PY_START,call)
        monitor.set_local_events(tool,closed.decode.__code__,monitor.events.PY_START)
        try:
            calls=list(self.f.boundary.calls)
            with scope(fresh=True) as first:self.owner._parent_guard()
            self.assertEqual(1,len(seen));self.assertTrue(first)
            with scope(fresh=True) as second:self.owner._parent_guard()
            self.assertEqual(2,len(seen));self.assertEqual(first,second)
            required=set(self.f.canonical_paths)
            self.assertTrue(required<=first);self.assertEqual(calls,self.f.boundary.calls)
            self.assertEqual(self.f.canonical,self.f.pins(self.f.canonical_paths))
        finally:
            monitor.set_local_events(tool,closed.decode.__code__,0)
            monitor.register_callback(tool,monitor.events.PY_START,None);monitor.free_tool_id(tool)

    def test_same_bytes_replaced_canonical_child_inode_refuses_after_successful_guard(self):
        self.owner._parent_guard();path=self.f.source.children['dom'].store.path
        raw=path.read_bytes();before=path.stat();calls=list(self.f.boundary.calls)
        tmp=TemporaryDirectory();self.addCleanup(tmp.cleanup);outside=Path(tmp.name);outside.chmod(0o700)
        retained=outside/'original-child';os.replace(path,retained)
        with path.open('xb') as stream:stream.write(raw)
        path.chmod(0o600)
        self.assertEqual(raw,retained.read_bytes());self.assertEqual(before.st_ino,retained.stat().st_ino)
        self.assertNotEqual(before.st_ino,path.stat().st_ino)
        with self.assertRaises(NativeUIError):self.owner._parent_guard()
        self.assertEqual(calls,self.f.boundary.calls)

    def test_current_memory_mutation_during_actual_copy_read_keeps_literal_late_validation(self):
        original=OriginalFrameStore.read;changed=[];calls=list(self.f.boundary.calls)
        def actual(store,reference):
            result=original(store,reference)
            if store.namespace=='tabletweb-closed-headers' and not changed:
                changed.append(True);self.owner.parent['copyIntent']['phase']='foreign-phase'
            return result
        saved=deepcopy(self.owner.parent)
        try:
            with patch.object(OriginalFrameStore,'read',actual),self.assertRaises(NativeUIError):self.owner._parent_guard()
            self.assertEqual([True],changed);self.assertEqual(calls,self.f.boundary.calls)
            self.assertEqual(self.f.canonical,self.f.pins(self.f.canonical_paths))
        finally:self.owner.parent=saved

    def test_inplace_parser_code_change_during_actual_copy_read_keeps_literal_late_rejection(self):
        original=OriginalFrameStore.read;parser=fence._legacy;code=parser.__code__;defaults=parser.__defaults__
        changed=[];calls=list(self.f.boundary.calls)
        def reject(raw,expected):raise NativeUIError('Actual changed legacy parser')
        def actual(store,reference):
            result=original(store,reference)
            if store.namespace=='tabletweb-closed-headers' and not changed:
                changed.append(True);parser.__code__=reject.__code__
            return result
        try:
            with patch.object(OriginalFrameStore,'read',actual),self.assertRaisesRegex(NativeUIError,'Actual changed legacy parser'):
                self.owner._parent_guard()
            self.assertEqual([True],changed);self.assertEqual(calls,self.f.boundary.calls)
        finally:
            parser.__code__=code;parser.__defaults__=defaults
            self.assertIs(parser.__code__,code);self.assertIs(parser.__defaults__,defaults)

    def test_changed_decode_alias_runs_both_literal_calls_in_the_original_guard(self):
        original=closed.decode;calls=[];native=list(self.f.boundary.calls)
        def actual(value,expected):calls.append(True);return original(value,expected)
        with patch.object(closed,'decode',actual):self.owner._parent_guard()
        self.assertEqual([True,True],calls);self.assertEqual(native,self.f.boundary.calls)
'''

candidates={HELPER:helper,OWNER:owner,TEST:test};manifest={}
for path,body in candidates.items():
    ast.parse(body,filename=path)
    target=HERE/'candidate'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(body)
    current=ROOT/path;base=current.read_bytes() if current.exists() else None
    if base is not None:
        targetbase=HERE/'originals'/path;targetbase.parent.mkdir(parents=True,exist_ok=True);targetbase.write_bytes(base)
    manifest[path]={'baseSha256':None if base is None else hashlib.sha256(base).hexdigest(),
        'candidateSha256':hashlib.sha256(body.encode()).hexdigest(),'new':base is None}
diff=''.join(''.join(difflib.unified_diff((ROOT/path).read_text().splitlines(True) if (ROOT/path).exists() else [],body.splitlines(True),
    fromfile='a/'+path,tofile='b/'+path)) for path,body in candidates.items())
(HERE/'proposal.diff').write_text(diff)
(HERE/'candidate-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps(manifest,indent=2,sort_keys=True))
