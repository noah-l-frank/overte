"""Read exact C24PASS14 and WorldERROR1 originals; retain negative port state."""
from pathlib import Path
import hashlib,json,os,stat,runpy
R=Path.cwd().resolve();B=R/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,x):
 with(d/n).open('x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
c=B/'root-c24-world-two-utility-window-current929-b1-20261104'
assert sha(c/'freeze.json')=='7cc7674d4463f111852bbfafdace4b81febe7c9b58197e0a6abc9036fc3cb692'
for n,v in load(c/'freeze.json')['files'].items():assert sha(c/n)==v['sha256']
t=load(c/'terminal.json');assert len(t['groups'])==2 and t['unrunGroups']==[] and len(t['newOriginalRoots'])==7 and t['oldRootCount']==929
assert t['allExecutedOwnedProcessesAbsent']and t['allOldOriginalBodiesUnchanged']and t['wholeOwnOutputsTwiceEqual']
assert load(c/'global-before.json')==load(c/'global-after-first.json')==load(c/'global-after-second.json')
assert len(load(c/'global-before.json'))==929
assert load(c/'whole-output-first.json')==load(c/'whole-output-second.json')
tool=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(tool)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be'
census=runpy.run_path(str(tool))['census']
for n,v in load(c/'whole-output-first.json').items():assert census(Path(n))==v
rows=[];refs={}
for ix,row in enumerate(t['groups']):
 h=Path(row['input']).parent;o=h.with_name(h.name+'-outer');a=h.with_name(h.name+'-censuses')
 assert sha(row['input'])==row['inputSha256'];plan=load(row['input'])
 assert plan['wallSeconds']==30 and plan['killGraceSeconds']==5 and plan['utilityQualification']is None
 assert load(o/'source-binary-before.json')==load(o/'source-binary-after.json')==plan['sourceAndBinaryPins']
 for name,v in plan['sourceAndBinaryPins'].items():
  p=Path(name);z=p.lstat();assert stat.S_ISREG(z.st_mode)
  actual=dict(device=z.st_dev,inode=z.st_ino,mode=z.st_mode,uid=z.st_uid,gid=z.st_gid,nlink=z.st_nlink,bytes=z.st_size,mtimeNs=z.st_mtime_ns,ctimeNs=z.st_ctime_ns,sha256=sha(p))
  assert actual==v and p.lstat()==z
 for first,second in [('approved-input-before.json','approved-input-after.json'),('actual-child-output-first.json','actual-child-output-second.json'),('actual-child-subtrees-first.json','actual-child-subtrees-second.json')]:assert load(o/first)==load(o/second)
 assert load(a/'whole-first.json')==load(a/'whole-second.json')
 assert load(o/'actual-parent-drain.json')==dict(fdsEqual=True,threadsEqual=True)
 drain=load(o/'actual-process-drain.json');assert not drain['remaining']and not drain['forced']
 for owned in drain['owned']:
  try:raw=Path('/proc',str(owned['pid']),'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  assert int(raw[raw.rfind(')')+2:].split()[19])!=owned['startTicks']
 report=load(h/'child-receipts/report.json');ports=load(h/'child-receipts/actual-port-restoration.json');final=load(h/'child-receipts/actual-class-cleanup-restoration.json')
 assert report['fatal']is None
 for k in ('fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','twoToyCensusesEqual','allActualLoadedOriginsAccounted'):assert report[k]is True
 assert final['originalDescriptorRestored']and final['originalFunctionCodeGlobalsUnchanged']and final['summary']['descriptorRestored']
 assert ports['builtinsCioRestored']and ports['dupPortsRestored']and ports['actualC10dHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
 assert all(report[k]==0 for k in('PythonExecutions','NodeExecutions','SDKExecutions','overteNativeQueries'))and not report['realNetwork']and report['retainedTemporaryDirectories']==[]
 cases=[load(h/('child-receipts/standard-case-'+str(j)+'.json'))for j in range(1,report['actualCaseReceipts']+1)]
 assert [x['id']for x in cases]==plan['cases'][:len(cases)]
 origins=load(h/'child-receipts/actual-source-model-origins.json')
 assert len(origins['subjectOrigins'])==3
 for v in origins['subjectOrigins'].values():assert v['exactOriginMatched']and v['actualModulePresent']and v['actualLoaderExecutedPath']==v['expectedPath']
 for case in cases:
  for k in('fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','profileRestored','originalMethodsUnchanged','standardStopAfterCleanup'):assert case[k]is True
  assert case['remainingStandardCleanups']==case['newTemporaryDirectories']==0
  for call in case['actualNestedCleanupCalls']:assert call['remaining']==0 and not call['newCallbackErrors']and not call['newCallbackFailures']and call['originalRaised']is None
 if ix==0:
  assert row['supervisorReturnCode']==0 and row['originalTerminal']['status']==row['originalQualification']['status']=='PASS'
  assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==14 and report['cleanupEstablished']
  assert ports['restored']and ports['toolsRestored']and final['summary']['actualOriginalClassCleanupCalls']==3 and final['summary']['allActualOriginalCallsAccepted']
  assert all(case['monitorMasksSlotsUnchanged']and all(call['outcomeSuccessAfter']for call in case['actualNestedCleanupCalls'])for case in cases)
  detail=dict(status='PASS_FOURTEEN_REAL_DIAGNOSTIC_CASES_ONLY',diagnosticUtilityQualified=True,diagnosticAdmission=None,assetsPhaseQualified=False)
 else:
  assert row['supervisorReturnCode']==1 and row['originalTerminal']['status']==row['originalQualification']['status']=='FAIL_OR_REFUSED'
  assert report['status']=='FAIL_OR_ERROR'and report['testsRun']==report['actualCaseReceipts']==1 and report['cleanupEstablished']is False
  assert cases[0]['monitorMasksSlotsUnchanged']is False and ports['toolsRestored']is False
  assert cases[0]['actualNestedCleanupCalls'][0]['failedReturnRemainsFailed']
  stderr=(h/'child-logs/stderr.log').read_text();assert 'ValueError: invalid local event set 0x2005'in stderr and 'Ran 1 test'in stderr and 'FAILED (errors=1)'in stderr
  detail=dict(status='ORIGINAL_FIRST_CASE_LOCAL_EVENT_VALUEERROR',plannedCases=8,unrunCases=plan['cases'][1:],originalMonitorSlotRestorationFalsePreserved=True,worldTimingUtilityQualified=False,worldConsumerAdmission=None)
 rows.append(dict(group=row['group'],input=row['input'],inputSha256=row['inputSha256'],sourceFreeze=plan['sourceFreeze'],originalReport=report,originalPortRestoration=ports,originalClassCleanupFinal=final,originalTerminal=row['originalTerminal'],originalQualification=row['originalQualification'],**detail))
for root in map(Path,t['newOriginalRoots']):
 for p in sorted(root.rglob('*')):
  if p.is_file()and not p.is_symlink():refs[str(p)]=dict(path=str(p),sha256=sha(p))
out=B/'root-c24-pass14-world-fail1-original-qualified-results-20261104';out.mkdir(mode=0o700)
put(out,'results.json',dict(status='ROOT_C24_DIAGNOSTIC14_PASS_WORLD_ORIGINAL_FIRST_CASE_ERROR_RETAINED',groups=rows,terminal=dict(childReturnCode=1,ownProcessesAbsent=True,problems=[],timedOut=False,forcedKill=False),newOriginalRoots=t['newOriginalRoots'],all929OldOriginalBodiesUnchanged=True,wholeNewOutputsTwiceEqual=True,globalCensuses=3,originalCollectorFreeze=sha(c/'freeze.json'),featureQualified=False,nativeQualified=False,wholeQualified=False))
put(out,'actual-receipt-references.json',refs);put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}));print(json.dumps(dict(freeze=sha(out/'freeze.json'),references=len(refs))))
