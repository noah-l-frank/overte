"""Foreign recorder refusal without Current/Source/HTTP fixture birth; UNRUN."""
import unittest
from pathlib import Path
from adapters.normal_ui import NativeUIError
from adapters.lifecycle_sparse_host_diagnostic import LifecycleSparseHostDiagnostic

class LifecycleSparseForeignRecorderTests(unittest.IsolatedAsyncioTestCase):
 async def test_unbound_foreign_recorder_cannot_become_an_original_owner_or_write_a_result(self):
  import os
  path=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/'publication-post-acquisition-events.json'
  recorder=LifecycleSparseHostDiagnostic(path)
  with self.assertRaises(NativeUIError):recorder.bind(object(),object(),object())
  self.assertIsNone(recorder.store.read());self.assertEqual([],recorder.events)
