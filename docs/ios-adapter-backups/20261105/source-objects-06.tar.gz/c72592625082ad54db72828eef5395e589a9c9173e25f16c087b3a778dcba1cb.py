"""Literal private Source12 composition over held actual public Snapshot copy."""
from pathlib import Path
import ast,hashlib,json
from host_common import REPO,head
from historical_public_readiness import readiness as previous_readiness,packet
SOURCE=Path(__file__).resolve().parent
S12=REPO/'.ios-host-tmp/snapshot-temporal-png-photos-result2-source13-query-born-phase-clock-private-20261104'

def readiness(pin,copy_manifest,copy_manifest_sha):
    old,physical=previous_readiness(pin,copy_manifest,copy_manifest_sha)
    packet(S12,'source-freeze.json','f76f0db6ad880f48b602e5711e7ba81c0541471b2b20cb527a86b872c9c18d90',pin,physical)
    packet(REPO/'.ios-host-tmp/lifecycle-independent-snapshot-source13-query-born-phase-clock-source-review-20261104','freeze.json','dab31215da0a929ee228f283dc1453f7ec36eef05517eecc0916e5dcd770509b',pin,physical)
    packet(REPO/'.ios-host-tmp/snapshot-actor-before-capture-after-png-temporal-join-source10-private-20261104','source-freeze.json','ce0aad33395181606a63812ed968952f9b9a2b6cfca567b52ac377946e6397ae',pin,physical)
    packet(REPO/'.ios-host-tmp/snapshot-temporal-png-source10-paired-source11-twelve-bootstrap1-closed-code-preparation-20261104','source-freeze.json','352cc6563acbb7f8abf99c068244c13c6017c7feae77cc2d21726d53677311ae',pin,physical)
    declarations=SOURCE/'SUBJECT-DECLARATIONS.json';recipe_path=SOURCE/'SOURCE-RECIPE.json'
    physical[str(declarations)]=pin(declarations);physical[str(recipe_path)]=pin(recipe_path)
    rows=json.loads(declarations.read_text())['subjects'];recipe=json.loads(recipe_path.read_text())
    public={};pure={};private={};origins={}
    for name,row in rows.items():
        path=Path(row['path']);assert path.is_absolute()and path.resolve(strict=True)==path
        actual=pin(path);assert actual['sha256']==row['sha256'];physical[str(path)]=actual
        origin=dict(path=str(path),sha256=row['sha256']);origins[name]=origin
        if row['category']=='current-public-definition':
            assert path==REPO/row['logicalPath'];public[name]=origin
            if name in old['publicSubjectOrigins']:assert origin==old['publicSubjectOrigins'][name]
        elif row['category']=='explicit-private-pure-test-only':
            assert old['privatePureTestOrigins'][name]==origin;pure[name]=origin
        else:
            assert row['category']=='explicit-private-subject-overlay';private[name]=origin
            assert path.is_relative_to(REPO/'.ios-host-tmp')
    assert len(public)==79 and len(private)==5 and len(pure)==1 and len(origins)==85
    assert all(public.get(name)==row for name,row in old['publicSubjectOrigins'].items())
    assert len(recipe['groups'])==recipe['groupCount']==recipe['caseCount']==6
    cases=[case for group in recipe['groupOrder']for case in recipe['groups'][group]['cases']]
    assert len(cases)==len(set(cases))==6
    test_name='ios.self_tests.test_ios_snapshot_capture_png_photos_join'
    test_path=Path(origins[test_name]['path']);tree=ast.parse(test_path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name=='SnapshotCapturePNGPhotosJoinTests')
    bodies={n.name:n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')}
    assert [test_name+'.'+cls.name+'.'+name for name in bodies]==cases
    for row in recipe['originalBodyRecords']:
        method=row['id'].rsplit('.',1)[-1]
        assert row['originalSourcePath']==row['expectedActualPath']==str(test_path)
        assert hashlib.sha256(ast.dump(bodies[method],include_attributes=False).encode()).hexdigest()==row['expectedBodyASTSha256']
    return dict(old,subjectOrigins=origins,publicSubjectOrigins=public,privatePureTestOrigins=pure,privateOverlayOrigins=private,
        expectedParentHead=head(),copyHistoricalParentHead=old['expectedParentHead'],allImplementationDefiningOriginsPublic=False,
        source12Freeze='f76f0db6ad880f48b602e5711e7ba81c0541471b2b20cb527a86b872c9c18d90',source12Peer='dab31215da0a929ee228f283dc1453f7ec36eef05517eecc0916e5dcd770509b',
        currentConsumerCompositionQualified=False,liveCombinedPhotosDestinationQualified=False,nativeAdmission=None,nativeQualified=False,wholeQualified=False),physical
