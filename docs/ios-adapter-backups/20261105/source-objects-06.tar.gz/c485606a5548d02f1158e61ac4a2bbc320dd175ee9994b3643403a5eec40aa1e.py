"""Actual inactive Callback8 checkpoint before any process/SDK authority.

The existing typed pair/window/journal decoders supply all facts. No copied
State is reinterpreted as Rooted2/3, no native cut is renewed and no Stop or SDK
operation is available here. The returned private projection is not an End.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as read_scope
from adapters.script_feature.history import same
from feature_journeys import terminal
from ios.adapters import emote_callback_archive as archive
from ios.adapters.emote_rooted_fence import _seal,inactive,inactive_prefixes

VERSION=1


def capture(controller,seal):
    # Import only at this explicit internal entry; default/legacy paths do not
    # acquire a new dependency or a second terminal factory.
    from ios.adapters.emote_callback_terminal import IOSEmoteCallbackTerminal
    need(type(controller) is IOSEmoteCallbackTerminal)
    terminal.sealed(seal)
    flow=controller.flow
    need(flow.role=='primary' and flow.configured_pair is not None)
    controller.inventory=None
    with controller.actor.held(30):
        with read_scope(fresh=True) as reads:
            # This is the genuine current role constructor path. It requires
            # cleaned roles, existing retired cleanup phase, original receipt
            # membership and complete current ordinary responsibility.
            window=controller.window(retired=True)
            controller.guard()
            journal=controller.Journal(window,check=controller.guard)
            need(journal.state is not None and journal.state['phase']=='sealed'
                and same(journal.state['seal'],seal))
            proof=journal.originals.read(journal.originals.expand(journal.state['record']))
            journal.proof(proof,journal.state)
            publisher=PrivateFeatureState(controller.actor.store.path.with_name(
                'phase-publication-emotes-'+flow.run+'-actor.json'))
            actual,floor=window.qualify_with_retirement_floor(journal.state['description'],
                proof['original']['samples'],journal.state['references'],publisher_store=publisher)
            need(same(actual,proof))
            _seal(proof,seal,run=flow.run,role='primary',binding=flow.state['binding'])
            prefixes={}
            for role,live in window.roles.items():
                # Original native/source/peer operands come from the SAME
                # checked current live row, not a manufactured completion time.
                snapshot=live.read_frame(live.state['records'][-1])['snapshot']
                keyed=archive.reopen(snapshot,lock=live.lock,primary_lock=live.primary_lock)
                rendered=keyed.rendered_owner;native=rendered.native_owner
                rendered_row=rendered.original(keyed.original(snapshot['reference'])['renderedReference'])
                raw=native.original(rendered_row['nativeReference'])
                sources,peers,unused=native.owners(raw)
                need(sources.frames and (peers is None or peers.frames))
                prefixes[role]=[deepcopy(part.frames[-1]['phaseAfter'])
                    for part in (sources,peers) if part is not None]
            # Exactly this original status request supplies the final current
            # inactive phase. No desired phase, copied DTO or DELETE ACK does.
            phase=flow.phase.status()
            inactive(phase,run=flow.run,instance=flow.state['phaseInstance'],
                ticket=seal['description']['ticket'],after=floor)
            inactive_prefixes(phase,prefixes,run=flow.run)
            controller.inventory=controller.Inventory(journal,reads)
            controller.guard();journal.bound()
            value=dict(iosEmoteCallbackInactiveCheckpointVersion=VERSION,runId=flow.run,
                phaseInstance=flow.state['phaseInstance'],configuredTargetPair=deepcopy(flow.configured_pair),
                seal=deepcopy(seal),terminalProof=deepcopy(proof),
                completionFloorEpochMs=floor,rolePhasePrefixes=deepcopy(prefixes),phaseOriginal=deepcopy(phase))
            controller.guard()
        controller.guard()
    controller.clock()
    return value
