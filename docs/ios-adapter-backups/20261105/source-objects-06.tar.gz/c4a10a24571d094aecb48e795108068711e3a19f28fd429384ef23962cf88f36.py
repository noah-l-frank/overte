"""Read-only diagnostic on a retained Source/Input graph. Never dispatch input."""
from contextlib import ExitStack
import cProfile
from hashlib import sha256
import json
from pathlib import Path
import pstats
import socket
import subprocess
import time
from types import SimpleNamespace
from unittest.mock import patch

from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUI
from adapters.script_feature.history import unpack
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_original_lease import EmoteOriginalLease
from ios.adapters.world_web_sources import WorldWebSources
from ios.adapters.world_web_input import WorldWebInput
from ios.adapters.world_web_construction import construct
from ios.adapters.world_web_api_clock import scope

REPO = Path.cwd()
ROOT = REPO / '.ios-host-tmp/tmp3ieeyyp4'
OUTPUT = REPO / '.ios-host-tmp/world-web-key-validation-complete-boundary-api25-20261027.json'


def forbidden(*args, **kwargs):
    raise AssertionError('Read-only diagnostic forbids native/SDK/network/process/write effects')


def signatures():
    result = {}
    for path in ROOT.rglob('*'):
        if path.is_file():
            before = path.lstat(); raw = path.read_bytes(); after = path.lstat()
            need(EmoteOriginalLease.signature(before) == EmoteOriginalLease.signature(after))
            result[str(path.relative_to(ROOT))] = (EmoteOriginalLease.signature(after), sha256(raw).hexdigest())
    return result


need(ROOT.is_dir() and ROOT.resolve() == ROOT)
lock_path = ROOT / 'script-feature-sources.lock'
need(lock_path.is_file() and not lock_path.is_symlink())
originals = signatures()
source_store = PrivateFeatureState(ROOT / 'ios-world-web-primary-sources.json')
value = source_store.read(); need(value is not None)
state = unpack(value['payload'])[0]; need(state['pending'] is None)
first = PrivateFeatureState(ROOT / 'ios-world-web-primary-sources-1.json').read()
frame = unpack(first['payload'])[0]
phase = SimpleNamespace(fixture_url=frame['snapshotQueries'][0]['fixtureUrl'])
input_store = PrivateFeatureState(ROOT / 'ios-world-web-inputs.json')
input_value = input_store.read(); need(input_value is not None)
rows = unpack(input_value['payload'])[0]['records']
report = dict(scope='Read-only Source/Input real API-clock component only; no SDK/preflight/Scope/Actor/PNG/whole or native/device acceptance',
    sourceRecords=len(state['records']), inputRecords=len(rows), originalFiles=len(originals), samples=[])
lock = ScriptSourceLock(lock_path)
with ExitStack() as stack:
    for target in ((PrivateFeatureState, 'write'), (PrivateFeatureState, 'discard'),
                   (subprocess, 'Popen'), (socket, 'create_connection')):
        stack.enter_context(patch.object(*target, side_effect=forbidden))
    stack.enter_context(lock.held())
    begun=time.perf_counter()
    try:
        with scope(time.monotonic):
            with construct(lambda:WorldWebSources(source_store,lock,value['binding'],value['runId'],value['role'],
                    lambda:True,phase=phase,historical=True)) as source:
                report['coldSourceSeconds']=time.perf_counter()-begun
                entered=time.perf_counter()
                owner=WorldWebInput(input_store,source,NativeUI(None,value['binding']['sessionId'],forbidden),input_value['entityId'],forbidden)
                report['inputSeconds']=time.perf_counter()-entered
                need(owner.state==unpack(input_value['payload'])[0] and len(owner._proof_cache)==len(rows))
        report['api25ComponentPassed']=True
    except BaseException as error:
        import traceback
        traceback.print_exc()
        report.update(api25ComponentPassed=False,errorType=type(error).__name__,error=str(error))
    report['completeScopeSeconds']=time.perf_counter()-begun
need(signatures() == originals)
need(input_store.read() == input_value)
report.update(originalFilesUnchanged=True, nativeExecuted=False, inputIssued=False, deviceQualified=False)
OUTPUT.write_text(json.dumps(report, indent=2) + '\n'); OUTPUT.chmod(0o600)
print(json.dumps(report),flush=True)

raise SystemExit(0 if report['api25ComponentPassed'] else 1)
