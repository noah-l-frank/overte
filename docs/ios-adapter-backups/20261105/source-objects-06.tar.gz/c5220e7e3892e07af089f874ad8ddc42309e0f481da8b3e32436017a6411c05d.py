"""Root-only C24 diagnostic pure Utility14 metadata; never imports the utility subject or starts it."""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
SOURCE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/assets-c24-policy-value-bounded-diagnostic-source3-unknown-mutating-c-return-private-20261104'
SUBJECT_SHA='5430c80f66b464f1cb233e54482323b55c1b3cb95ef794b1df2d14e382b5ddfd'
HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
EXECUTORS=('run-fourteen.py','supervise-fourteen.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','source_execution_readiness.py','readonly-shared-stdlib-sources.json','intent_graph_diagnostic.py','test_intent_graph_diagnostic.py','exact-fourteen-selectors.json')

def frozen(folder,name,sha,physical):
    path=folder/name;assert pin(path)['sha256']==sha;physical[str(path)]=pin(path);value=json.loads(path.read_text())
    for leaf,row in value['files'].items():
        assert not Path(leaf).is_absolute()and '..'not in Path(leaf).parts
        actual=folder/leaf;assert pin(actual)['sha256']==(row if type(row)is str else row['sha256']);physical[str(actual)]=pin(actual)
    return value

def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','expected-head','destination'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and head()==args.expected_head
    physical={};frozen(SOURCE,'source-freeze.json',args.source_freeze,physical);frozen(SUBJECT,'source-freeze.json',SUBJECT_SHA,physical)
    for name in('intent_graph_diagnostic.py','test_intent_graph_diagnostic.py'):assert(SOURCE/name).read_bytes()==(SUBJECT/name).read_bytes()
    frozen(REPO/'.ios-host-tmp/assets-c24-policy-value-bounded-diagnostic-source2-owned-secondary-restoration-private-20261104','source-freeze.json','c0c98bf83d9198c4e20291c3978a435ed216f498a2b8c15a483448128538bfc2',physical)
    frozen(REPO/'.ios-host-tmp/lifecycle-independent-c24-diagnostic-source3-full-unknown-return-review-20261104','freeze.json','9ebd3548a6e79542b833f0d05389f6851af983227c9096e5600f6c69ff0b1e4c',physical)
    current_qualification,current_physical=qualification(pin);physical.update(current_physical)
    assert pin(SOURCE/'closed_import_origins.py')['sha256']==HELPER
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ');gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(path)]=pin(path)
    ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    refpath=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs');physical[str(refpath)]=pin(refpath)
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14')
    suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);namespaces={}
    for current,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink())
        rel=folder.relative_to(std)
        if rel.parts and all(n.isidentifier()for n in rel.parts)and not(folder/'__init__.py').is_file():namespaces['.'.join(rel.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(suffixes):continue
            assert path.resolve(strict=True)==path and not path.is_symlink();physical[str(path)]=pin(path)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'and dest.name.startswith('c24-diagnostic-utility14-prepared-')and not dest.exists()
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    dest.mkdir(mode=0o700)
    for name in EXECUTORS:
        path=dest/name;assert path.resolve().is_relative_to(REPO)
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(path)]=pin(path)
    modules={name:dict(path=str(dest/(name+'.py')),sha256=physical[str(dest/(name+'.py'))]['sha256'],package=False,loader='source')for name in('metadata_reader','host_common','source_execution_readiness','closed_import_origins','owned_write_boundary','intent_graph_diagnostic','test_intent_graph_diagnostic')}
    cases=json.loads((SOURCE/'exact-fourteen-selectors.json').read_text());assert len(cases)==len(set(cases))==14
    subjects={name:dict(path=modules[name]['path'],sha256=modules[name]['sha256'])for name in('intent_graph_diagnostic','test_intent_graph_diagnostic')}
    origin=dict(modules=modules,namespacePackages={},thirdPartyModules={},thirdPartyNamespacePackages={},stdlibNamespacePackages=namespaces,stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='PRIVATE_C24_DIAGNOSTIC_SOURCE3_UTILITY14_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(dest),actualPublicHead=args.expected_head,sourceFreeze=args.source_freeze,utilitySubjectSourceFreeze=SUBJECT_SHA,
        sourceAndBinaryPins=physical,modules=modules,namespaces={},thirdPartyModules={},originPlan=origin,subjectOriginModules=subjects,subjectOriginCount=2,cases=cases,wallSeconds=30,killGraceSeconds=5,
        pythonExecutable=dict(path=str(python),pin=physical[str(python)]),PythonExecutions=0,maximumLiveUtilityChildren=0,expectedTemporaryDirectories=0,expectedTemporaryDirectoriesPerCase=0,expectedJoinedThreadCases=1,
        subjectSourceFreeze=SUBJECT_SHA,currentSourceExecution=current_qualification,consumerCompositionQualified=False,subjectHelperSha256=HELPER,subjectActualCopiedPath=str(dest/'closed_import_origins.py'),
        NodeExecutions=0,SDKExecutions=0,realNetwork=False,overteNativeQueries=0,oldApplicationCorpusInputs=0,globalOriginalScans=0,oldScenarioOriginalInputs=0,
        trustedHostBootstrap='Actual interpreter/stdlib/initial controller modules are explicitly trusted physical origins; delegated kernel/test modules use actual C10d fresh source bytes. No entire-interpreter cache absence claim.',nativeQualified=False,wholeQualified=False,utilityQualification=None,diagnosticAdmission=None,assetsPhaseQualified=False,historicalApplicationReferenceLedgerRole='Pinned literal source metadata only; original C24 raw log/phase outputs are not utility inputs.')
    output=dest/'approved-inputs.json';assert output.resolve().is_relative_to(REPO)
    fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),sha256=pin(output)['sha256'],sourcePins=len(physical),cases=14,targets=0,globalScans=0)))
if __name__=='__main__':main()
