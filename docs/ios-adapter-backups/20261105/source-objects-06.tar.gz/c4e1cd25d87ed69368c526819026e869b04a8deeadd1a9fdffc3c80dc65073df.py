"""Read the literal qualified Utility14 originals; never grants Chat adoption."""
from pathlib import Path
import json
from host_common import REPO
ROOT=REPO/'.ios-host-tmp/root-chat14-b2-expected-comparison-original-host-qualified-results-20261105'
FREEZE='072a289348ebbf2f70ad7156c4dac1da283e1823c40b83fbeaca923d93b90cb5'
RESULTS='411fbea73e1e14632d971aaa4e4dd4075843c4ab9ab8466c2ee66c9c5b1579c0'
SUBJECT='530f269df9057b3ce57d691d751713086eb9bef57702ab9bd8402369deba5b92'
CONTROLLER='c951ad10e3dc88d3fb531e5a5a7f86814097144c1eeef8939257e697a5cb2679'
def qualification(pin):
    physical={}
    def read(path,digest):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        row=pin(path);assert row['sha256']==digest;physical[str(path)]=row
        return json.loads(path.read_text())
    freeze=read(ROOT/'freeze.json',FREEZE)
    for leaf,row in freeze['files'].items():
        assert not Path(leaf).is_absolute()and '..'not in Path(leaf).parts
        path=ROOT/leaf;actual=pin(path);assert actual['sha256']==(row if type(row)is str else row['sha256']);physical[str(path)]=actual
    results=read(ROOT/'results.json',RESULTS)
    references=json.loads((ROOT/'actual-receipt-references.json').read_text());assert len(references)==73
    for key,row in references.items():
        assert key==row['path'];path=Path(key);actual=pin(path);assert path.resolve(strict=True)==path and actual['sha256']==row['sha256'];physical[key]=actual
    assert results['status']=='ROOT_QUALIFIED_EXACT_FOURTEEN_SOURCE2_EXPECTED_COMPARISON_HOST_CONTROLS'
    assert results['sourceFreeze']==CONTROLLER and results['subjectSourceFreeze']==SUBJECT
    assert results['comparisonUtilityHostCasesQualified']is True and results['actualCaseCount']==14 and results['actualFreshSubjectOrigins']==7
    for key in('performanceMeasured','speedOrCPUCauseConclusion','featureQualified','nativeQualified','wholeQualified'):assert results[key]is False
    for key in('runtimeAdmission','chatAdoptionAdmission','EndAdmission'):assert results[key]is None
    rows=results['actualCaseReceipts'];assert len(rows)==14 and len({row['id']for row in rows})==14
    for row in rows:
        assert row['remainingStandardCleanups']==row['newTemporaryDirectories']==0
        for key in('standardStopAfterCleanup','originalMethodsUnchanged','monitorMasksSlotsUnchanged','fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','profileRestored'):assert row[key]is True
        assert len(row['actualNestedCleanupCalls'])==1
        cleanup=row['actualNestedCleanupCalls'][0];assert cleanup['originalReturned']is True and cleanup['remaining']==0 and cleanup['originalRaised']is None and not cleanup['newCallbackErrors']and not cleanup['newCallbackFailures']
    terminal=results['terminal'];assert terminal['status']=='PASS'and terminal['childReturnCode']==0 and terminal['problems']==[]and terminal['orphansRequiredKill']==[]
    for key in('actualClassCleanupCustodyEstablished','actualFourteenCaseReceiptsEstablished','actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allSubjectActualRuntimeOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','ownProcessesAbsent','twoFullOwnOutputCensusesEqual','zeroCaseChildBirthsEstablished'):assert terminal[key]is True
    assert terminal['forcedKill']is terminal['timedOut']is False
    report=results['actualReport'];assert report['status']=='PASS'and report['testsRun']==14 and report['cleanupEstablished']is True and report['allActualLoadedOriginsAccounted']is True
    restore=results['actualPortRestoration'];assert restore['count']==27 and restore['controlDescriptors']==[]
    for key in('restored','dupPortsRestored','toolsRestored','builtinsCioRestored'):assert restore[key]is True
    assert restore['actualC10dHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
    roots=results['newOriginalRoots'];assert len(roots)==len(set(roots))==4
    assert all(Path(path).is_absolute()and Path(path).resolve(strict=True)==Path(path)for path in roots)
    assert all(pin(path)==row for path,row in physical.items())
    return dict(profile='literal-source2-expected-comparison-utility14-only',rootFreeze=dict(path=str(ROOT/'freeze.json'),sha256=FREEZE),resultsSha256=RESULTS,actualReferenceCount=73,actualCases=14,subjectSourceFreeze=SUBJECT,sourceFreeze=CONTROLLER,requiredOriginalRoots=roots,comparisonAlgorithmQualified=True,measurementQualified=False,chatAdoptionAdmission=None,nativeQualified=False,wholeQualified=False),physical
