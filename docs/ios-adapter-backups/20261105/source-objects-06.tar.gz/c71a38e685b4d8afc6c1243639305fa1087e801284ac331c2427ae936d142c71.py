from pathlib import Path
import ast,json,hashlib,shutil,difflib
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');P=R/'.ios-host-tmp/lifecycle-original-owner-native-query-owner-proposal-20261028'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not (P/'freeze.json').exists()
m=json.loads((P/'manifest.json').read_bytes())
for row in m['files']:
 q=Path(row['candidate']);b=Path(row['base']);assert h(q)==row['candidateSHA256'] and h(b)==row['baseSHA256']
 if q.suffix=='.py':ast.parse(q.read_bytes())
 copy=P/'bases/repo'/row['path'];copy.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(b,copy);row['retainedBase']=str(copy);row['retainedBaseSHA256']=h(copy)
model=P/'test_native_query_owner_models.py';tree=ast.parse(model.read_bytes());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='OriginalNativeQueryOwnerModels')
ids=['test_native_query_owner_models.OriginalNativeQueryOwnerModels.'+n.name for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name.startswith('test_')];assert len(ids)==10
m.update(status='PRIVATE_REVIEWABLE_SOURCE3_MODEL10_UNRUN',modelPath=str(model),modelSHA256=h(model),initialFixedTestBudgetSeconds=60,killGraceSeconds=5,modelCases=ids,sourceMapRequiredBeforeImports=True,queryWalProfile='Source-built version1; cold WAL refused; pending write acknowledgement never rebased',nativeFileDependencyFreeze='9a70d441b67985dc6b01b2c6565c9ef7add09e5486a9f486f42e68b0f63ea082')
(P/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
plan=dict(status='PROSPECTIVE_UNRUN_NO_LAUNCHER_OR_IMPORT_EXECUTED',initialFixedOuterSeconds=60,killGraceSeconds=5,caseIds=ids,actualRootMapBeforeImports=dict(keeper=m['files'][1]['candidateSHA256'],featureObservation=m['files'][0]['candidateSHA256'],hostOperations=m['files'][2]['candidateSHA256']),namespace='Exactly three explicit device roots; reviewed PathFinder._get_spec for nested namespace. Never repo root as namespace path.',retention='Expected TEN actual TouchLease TemporaryDirectory roots. Retain only fixture-local test_ios_touch_lease.tempfile alias with real retained TemporaryDirectory factory. Original socketpair close and asyncTearDown callbacks transfer to current IsolatedAsyncioTestCase, preserving LIFO.',boundary='Save real FD/Thread/Task/Child baseline before target imports, full Root source/launcher/SDK map before and after, actual code hash evidence. Actual HTTPServer.shutdown/server_close/thread.join, real query Thread death and original Task completion, two retained-file censuses. No SDK import, device or native execution.',models='Actual extracted selected OriginalKeeperSource and OriginalKeeperOperations AST + compiled hashes, actual existing sender/urllib/loopback HTTP/WAL fsync/replace/TouchLease/socketpair. Fresh RSD/WDA/native/SDK APIs explicitly modeled, no result/source facts synthesized as qualification.',remaining='Independent installed candidate binding and original native clocks/current geometry+world+release/native-end join are still separate closed interfaces.')
(P/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(P/'README.txt').write_text('''Feature 14/14: source-owned diagnostic native query (PRIVATE / UNRUN)

Dependency order: committed67df Source37 -> frozen native-file-channel Source2
(9a70d441...) -> this Source3. Apply only exact reviewed hunks on current bases;
public/index remain Root-owned. All original packets/freezes are unchanged.

FeatureObservation keeps its validators/initial guard and delegates its existing
HTTP body to send_original_command. This is the original POST/timeout5/echo/no-
redirect/duplicate-key path. The original keeper creates the nonce, stores its
exact intent with existing PrivateFeatureState+ScriptSourceLock BEFORE starting
its actual non-daemon HTTP Thread. It captures Source/RSD/claim/loop/Task/touch/
resource identities. Final transport guards synchronously bridge from the HTTP
Thread onto the ORIGINAL asyncio loop; no SDK/AFC/RSD call runs in that Thread.

Source-built live WAL snapshots, exact pending attempted envelopes and unchanged
original-owner references are mandatory. Cold JSON histories are refused. Lost
write acknowledgement blocks later send, never adopts/rebases. Lost HTTP return
keeps the old query as uncertain; a later separate diagnostic query gets a NEW
nonce, never an old-query resend. Only HTTP return/echo is observed; it is no
native delivery acknowledgement. Cancellation/closing retain the original Task
and Thread until actual return; Source settle cannot unwind the original RSD
under the live worker. Existing once-Up/drain path remains unchanged.

All native acquisition, candidate binding, motion/touch/resource-retirement and
canonical completion gates remain FALSE. The result does not by itself join a
native-file reply, native timestamp bracket, or selected installed IPA bytes.
Stat and caller nonce remain correlation only in the earlier file-channel stage.
No new broker/session/tunnel/authentication is created or inferred.

Ten source-DI cases are concrete UNRUN code: actual loopback HTTP and fsynced WAL,
intent-before-send, no caller nonce, lost HTTP/new nonce, committed lost intent,
cold owner refusal, actual1.55s timeout vs unchanged1.5s guard, cancelled caller+
closing under blocked actual HTTP, foreign loop, real once-Down/original-Up, and
actual WAL mutation during HTTP. Source APIs, RSD/WDA/native/HID producers are
explicit models. Source AST and compiled code hashes are diagnostic provenance,
never authentication. Root must prepare/review the final60+5 runner before run.

Payload check: read-only analysis of160 retained Motion7 originals, byte/stat
before=after. Source-confirmed default JSON serialization of retained model
dictionaries plus full outer escaping fits12000 result/16384 pipe: World7210/
7453, NativeClock1909/2152, Geometry944/1187 max bytes. This is shape analysis;
original native-file raw whitespace is not retained in nested WALs and no native
capacity qualification is claimed. No limit was increased or truncated.
''')
# Verify original legacy command validators and helper body only moved as documented.
base=ast.parse(Path(m['files'][0]['retainedBase']).read_bytes());candidate=ast.parse(Path(m['files'][0]['candidate']).read_bytes())
def send(t):return next(n for c in t.body if isinstance(c,ast.ClassDef) and c.name=='FeatureObservation' for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='send')
old=send(base);new=send(candidate);start=next(i for i,n in enumerate(old.body) if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='payload' for x in n.targets));assert ast.dump(ast.Module(body=old.body[:start],type_ignores=[]),include_attributes=False)==ast.dump(ast.Module(body=new.body[:-1],type_ignores=[]),include_attributes=False)
(P/'ast-review.json').write_text(json.dumps(dict(pythonCandidatesParsed=2,modelParsed=True,exactCases=10,legacyCommandValidationAndInitialGuardUnchanged=True,sourceDeltaOnly=True,targetImportsExecuted=False,testsExecuted=False,publicFilesEdited=False),indent=2)+'\n')
files=[p for p in P.rglob('*') if p.is_file()];freeze=dict(status='PRIVATE_SOURCE3_MODEL10_UNRUN',files=[dict(path=str(p.relative_to(P)),sha256=h(p),bytes=p.stat().st_size) for p in sorted(files)])
(P/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');print(json.dumps(dict(freeze=h(P/'freeze.json'),manifest=h(P/'manifest.json'),diff=h(P/'proposal.diff'),models=h(model),candidate=[(r['path'],r['candidateSHA256']) for r in m['files']]),indent=2))
