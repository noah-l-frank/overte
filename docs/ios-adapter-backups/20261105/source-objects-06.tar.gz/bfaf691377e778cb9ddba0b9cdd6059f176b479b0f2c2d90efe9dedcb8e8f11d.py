"""One historical pending-14 intent, existing cold operation record scope.

No current observation, transport, publication recovery or whole-journey proof.
The original head/receipt and every owned file remain untouched.
"""
import builtins
import cProfile
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import pstats
import signal
import socket
import subprocess
import time
import traceback
from unittest.mock import patch
import urllib.request

from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as read_scope
from adapters.phase_witness_publisher import PhaseWitnessPublisher
from adapters.script_feature.history import unpack
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.witness import Client
from ios.adapters.tablet_web_record_cache import TabletRecordCache, scope as record_scope
from ios.adapters.tablet_web_runtime import IOSTabletWebRuntime

BASE = Path(__file__).resolve().parent
ROOT = BASE / 'tmpkcb904kx'
RUN = 'a' * 32
SELECTOR = 'existing-tablet-host-sdk'
forbidden_calls = []
actual_opens = []


def forbidden(name):
    def fail(*_args, **_kwargs):
        forbidden_calls.append(name)
        raise AssertionError('Read-only original profile attempted ' + name)
    return fail


class ReadOnlyAdapter:
    _candidate_guard = staticmethod(forbidden('candidate'))
    _binding = staticmethod(forbidden('binding'))

    def state_path(self, selector):
        assert selector == SELECTOR
        return ROOT / 'session.json'

    def _binding_store(self, selector):
        assert selector == SELECTOR
        return PrivateFeatureState(ROOT / 'paired-installed-code.json')

    def __getattr__(self, name):
        return forbidden('adapter.' + name)()


class ReadOnlyRuntime(IOSTabletWebRuntime):
    _existing = forbidden('SDK existing')
    observer_runtime = forbidden('live observer')


def inventory():
    rows = {}
    for path in sorted(ROOT.rglob('*')):
        if path.is_file():
            stat = path.lstat()
            rows[str(path.relative_to(ROOT))] = dict(
                device=stat.st_dev, inode=stat.st_ino, bytes=stat.st_size,
                ctimeNs=stat.st_ctime_ns, mtimeNs=stat.st_mtime_ns,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    return rows


real_os_open, real_open, real_io_open = os.open, builtins.open, io.open


def read_only_os_open(path, flags, *args, **kwargs):
    if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
        return forbidden('os.open write')()
    actual_opens.append(os.fsdecode(path))
    return real_os_open(path, flags, *args, **kwargs)


def read_only_open(original):
    def opened(file, mode='r', *args, **kwargs):
        if any(flag in mode for flag in 'wax+'):
            return forbidden('file open write')()
        return original(file, mode, *args, **kwargs)
    return opened


def interrupted(_number, _frame):
    raise TimeoutError('Outer read-only diagnostic CPU/wall budget')


before = inventory()
(BASE / 'intent-context-profile-inventory-before.json').write_text(json.dumps(before, sort_keys=True))
profile = cProfile.Profile()
report = {}
members = set()
started, cpu = time.monotonic(), time.process_time()
signal.signal(signal.SIGALRM, interrupted)
signal.signal(signal.SIGTERM, interrupted)
signal.setitimer(signal.ITIMER_REAL, 50)
try:
    head = PrivateFeatureState(ROOT / ('phase-publication-tablet-web-' + RUN + '-actor.json')).read()
    state = unpack(head['payload'])[0]
    pending = state['pending']
    assert len(state['records']) == 13 and pending['ordinal'] == 14
    assert pending['phase'] == 'issued'
    assert pending['body']['facts']['page'] == 'B'
    original_hash = digest(pending)
    receipt = PrivateFeatureState(ROOT / ('phase-publication-tablet-web-' + RUN + '-actor-14.json')).read()
    assert digest(unpack(receipt['payload'])[0]['intent']) == original_hash
    feature = PrivateFeatureState(ROOT / ('tabletweb-feature-' + RUN + '-actor.json')).read()
    bootstrap = PrivateFeatureState(ROOT / ('tabletweb-context-' + RUN + '-actor.json')).read()
    runtime = ReadOnlyRuntime(ReadOnlyAdapter())
    lock = ScriptSourceLock(ROOT / 'script-feature-sources.lock')
    # Production lock acquisition opens the existing stable inode O_RDWR;
    # acquire before the absolute no-write fence, never create a new lock.
    assert lock.path.is_file()
    with lock.held(), ExitStack() as blocked:
        blocked.enter_context(patch.object(os, 'open', read_only_os_open))
        blocked.enter_context(patch.object(builtins, 'open', read_only_open(real_open)))
        blocked.enter_context(patch.object(io, 'open', read_only_open(real_io_open)))
        for name in ('write', 'pwrite', 'truncate', 'ftruncate', 'rename', 'replace',
                     'unlink', 'remove', 'mkdir', 'rmdir', 'link', 'symlink', 'chmod', 'chown', 'utime'):
            if hasattr(os, name):
                blocked.enter_context(patch.object(os, name, forbidden('os.' + name)))
        for owner, name in ((PrivateFeatureState, 'write'), (PrivateFeatureState, 'discard'),
                            (Client, 'request'), (socket, 'socket'), (socket, 'create_connection'),
                            (subprocess, 'Popen'), (urllib.request, 'urlopen')):
            blocked.enter_context(patch.object(owner, name, forbidden(name)))
        with read_scope(fresh=True) as actual_members:
            members = actual_members
            setup_start = time.monotonic()
            observer = runtime.historical_observer(SELECTOR, RUN, 'actor', feature['binding'],
                bootstrap['setupNative'], feature['origins'], lock,
                fixture_url=head['fixtureUrl'] + '/runs/' + RUN + '/', monotonic=time.monotonic)
            report['historicalSetupSeconds'] = time.monotonic() - setup_start
            report['setupOsOpens'] = len(actual_opens)
            scope = object.__new__(PhaseWitnessPublisher)
            scope.area, scope.run = 'tablet-web', RUN
            scope.validate_original = observer.publication_original
            cache = TabletRecordCache()
            target_start, target_cpu = time.monotonic(), time.process_time()
            profile.enable()
            try:
                # Exact method called by decode/receipt. A cold existing cache
                # covers this one target; historical setup is not a live parts
                # benchmark and is deliberately outside the measured scope.
                with record_scope(cache):
                    result = scope.intent(pending)
                assert digest(result) == original_hash
                report.update(completed=True, intentSha256=original_hash,
                    outputSha256=digest(result), originalDerivedSha256=digest(pending['derived']))
            finally:
                profile.disable()
                report.update(targetWallSeconds=time.monotonic() - target_start,
                    targetCpuSeconds=time.process_time() - target_cpu,
                    targetOsOpens=len(actual_opens) - report['setupOsOpens'],
                    existingRecordCacheEntries=len(cache.originals.rows),
                    existingRecordCacheBytes=cache.bytes)
except BaseException as error:
    profile.disable()
    report.update(completed=False, errorType=type(error).__name__, errorTraceback=traceback.format_exc())
finally:
    signal.setitimer(signal.ITIMER_REAL, 0)
    after = inventory()
    report.update(capturedAtUtc=datetime.now(timezone.utc).isoformat(),
        wallSeconds=time.monotonic() - started, cpuSeconds=time.process_time() - cpu,
        originalFiles=len(after), originalsUnchanged=before == after,
        actualOsOpens=len(actual_opens), readMembers=len(members), forbiddenCalls=forbidden_calls,
        qualification='one historical pending intent only; no live publication or whole prefix qualification')
    (BASE / 'intent-context-profile-inventory-after.json').write_text(json.dumps(after, sort_keys=True))
    (BASE / 'intent-context-profile-membership.json').write_text(json.dumps(sorted(str(path) for path in members)))
    (BASE / 'intent-context-profile-opens.json').write_text(json.dumps(actual_opens))
    profile.dump_stats(str(BASE / 'intent-context-profile.pstats'))
    stream = io.StringIO()
    if profile.getstats():
        pstats.Stats(profile, stream=stream).sort_stats('cumulative').print_stats(45)
    else:
        stream.write('Target profiling did not start.\n')
    (BASE / 'intent-context-profile-cpu.log').write_text(stream.getvalue())
    (BASE / 'intent-context-profile-result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)
    assert before == after and not forbidden_calls
raise SystemExit(0 if report.get('completed') else 1)
