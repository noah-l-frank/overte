"""Actual physical adapter/IPA/native codecs/query WAL; SDK/native births modeled.

No authentication, installed binary execution or child candidate authority is
established by these host source-DI cases. No returned query receipt is stubbed.
"""
from __future__ import annotations
import ast,asyncio,hashlib,inspect,json,marshal,os,re,threading,time,unittest,uuid,weakref
from concurrent.futures import Future
from contextlib import asynccontextmanager
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch


class InstalledOwnedQueryCandidateModels(unittest.TestCase):
    def setUp(self):
        raw=Path(os.environ['LIFECYCLE_INSTALLED_QUERY_MAP']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_INSTALLED_QUERY_MAP_SHA256']:raise RuntimeError('Actual reviewed source map required before target imports')
        self.mapping=json.loads(raw)
        for row in self.mapping.values():
            if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('Actual candidate source changed')
        from adapters.ios import binding
        from adapters.normal_feature_state import PrivateFeatureState
        from ios.adapters import appium_adapter
        from ios.self_tests import test_ios_bundle_identity as archive_fixture,test_ios_installed_adapter as installed_fixture
        from ios.self_tests.retained_host_roots import retain_owned_root
        self.archive=archive_fixture.BundleIdentityTests();self.archive.setUp();self.addCleanup(self.archive.doCleanups)
        retain_owned_root(self.archive.temp,expected_root=Path(self.archive.temp.name))
        for i,(callback,args,kwargs) in enumerate(self.archive._cleanups):
            if getattr(callback,'__self__',None) is self.archive.temp:self.archive._cleanups[i]=(self.archive.temp.cleanup,args,kwargs)
        digest=self.archive.archive();observed=self.archive.actual_directory_manifest();self.measured_directory_bundle=deepcopy(observed)
        self.f=installed_fixture.InstalledAdapterTests();self.f.setUp();self.addCleanup(self.f.doCleanups)
        retain_owned_root(self.f.temp,expected_root=self.f.root)
        for i,(callback,args,kwargs) in enumerate(self.f._cleanups):
            if getattr(callback,'__self__',None) is self.f.temp:self.f._cleanups[i]=(self.f.temp.cleanup,args,kwargs)
        # New candidate selection and model native-directory byte measurement
        # occur BEFORE any binding admission. No old native record is rewritten.
        self.f.artifact.write_bytes(self.archive.path.read_bytes());self.f.native.bundle=deepcopy(observed)
        self.f.summary.update(bundleIdentity=deepcopy(observed),runtime=dict(artifact='Overte.ipa'))
        self.f.summary['artifactIdentity']['artifactSha256']=digest;self.f.target['serverUrl']='http://controlled.invalid:4723'
        self.f.adapter=binding.create_adapter(self.f.args,self.f.Base);self.f.adapter.describe('test-only')
        self.sdk_store=PrivateFeatureState(self.f.root/'actual-modeled-sdk-session.json');self.sdk_store.write(self.f.adapter.read_session('test-only'),None)
        self.f.adapter.read_session=lambda selector:self.sdk_store.read()
        self.f.adapter.save_session=lambda selector,value:self.sdk_store.write(value,self.sdk_store.read())
        self.before_sdk=deepcopy(self.sdk_store.read());self.before_counts=(self.f.sessions,self.f.launches);self.after_query=None;self.lost_return=False;self.executed=[];self.sdk_calls=[]
        path=Path(self.mapping['keeper']['path']);tree=ast.parse(path.read_bytes());nodes=[next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name) for name in ('OriginalKeeperSource','OriginalKeeperOperations')]
        method=next(n for n in nodes[1].body if isinstance(n,ast.AsyncFunctionDef) and n.name=='native_original_read')
        sdk=method.body[1];self.assertIsInstance(sdk,ast.ImportFrom);self.assertEqual('pymobiledevice3.services.house_arrest',sdk.module)
        self.assertEqual(['HouseArrestService'],[v.name for v in sdk.names]);method.body.remove(sdk)
        module=ast.Module(body=nodes,type_ignores=[]);code=compile(ast.fix_missing_locations(module),str(path),'exec')
        metadata=dict(sourceSha256=self.mapping['keeper']['sha256'],selectedAstSha256=hashlib.sha256(ast.dump(module,include_attributes=False).encode()).hexdigest(),compiledCodeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest())
        out=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT']);info=out.stat();self.assertEqual(0o700,info.st_mode&0o777);self.assertEqual(os.geteuid(),info.st_uid)
        fd=os.open(out/(uuid.uuid4().hex+'.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as stream:json.dump(metadata,stream,sort_keys=True);stream.write('\n')
        ns=dict(asyncio=asyncio,weakref=weakref,inspect=inspect,asynccontextmanager=asynccontextmanager,uuid=uuid,re=re,json=json,time=time,LaunchError=RuntimeError)
        outer=self;self.services=[];self.native_file=self.f.root/'child-original-bundle.json'
        original_native_send=self.f.native.send
        def native_send(query):
            original_native_send(query);self.native_file.write_text(self.f.native.original());self.native_file.chmod(0o600)
        self.f.native.send=native_send
        class HouseArrestModel:
            def __init__(self,rsd,documents_only=False):
                outer.assertIs(outer.rsd,rsd);outer.assertFalse(documents_only);outer.services.append(self)
                self._service=object();self._afc_reader_task=None;self._afc_pending={};self.descriptors={};self.sockets=__import__('socket').socketpair();self.stop=asyncio.Event()
            async def send_command(self,bundle,command):
                outer.assertIs(asyncio.get_running_loop(),outer.loop);outer.assertEqual(('org.example.overte','VendContainer'),(bundle,command));outer.assertIsNone(self._afc_reader_task)
            async def __aenter__(self):self._afc_reader_task=asyncio.create_task(self.stop.wait());return self
            async def stat(self,path):
                outer.assertEqual('/Documents/owned-results/ios-installed-bundle-observation.json',path);v=outer.native_file.stat()
                return dict(st_ifmt='S_IFREG',st_nlink=v.st_nlink,st_size=v.st_size,st_mtime=v.st_mtime_ns)
            async def fopen(self,path,mode):
                outer.assertEqual('r',mode);fd=os.open(outer.native_file,os.O_RDONLY|os.O_NOFOLLOW);self.descriptors[fd]=fd;return fd
            async def fread(self,handle,size):return os.read(handle,size)
            async def fclose(self,handle):os.close(self.descriptors.pop(handle))
            async def aclose(self):
                if self._afc_reader_task is not None:
                    self._afc_reader_task.cancel()
                    try:await self._afc_reader_task
                    except asyncio.CancelledError:pass
                    self._afc_reader_task=None
                for fd in tuple(self.descriptors):os.close(self.descriptors.pop(fd))
                for resource in self.sockets:resource.close()
                self._afc_pending.clear();self._service=None
        ns['HouseArrestService']=HouseArrestModel
        exec(code,ns);self.source_type=ns['OriginalKeeperSource'];self.ops_type=ns['OriginalKeeperOperations'];self.loop=asyncio.new_event_loop();ready=Future()
        def run_loop():
            asyncio.set_event_loop(self.loop)
            try:
                class RSD:pass
                class Capability:
                    def current(_):
                        outer.assertIs(asyncio.get_running_loop(),outer.loop);return outer.rsd,'fd00::1'
                class Tunnel:
                    def original_source(_):return outer.cap
                self.rsd=RSD();self.cap=Capability();self.tunnel=Tunnel()
                self.source=self.source_type.__new__(self.source_type);self.source._tunnel=weakref.ref(self.tunnel);self.source._source=self.cap
                self.source._loop=self.loop;self.source._born=[];self.source._leases=[];self.source._native_reads=[];self.source._native_queries=[];self.source._closing=False
                self.ops=self.ops_type(self.source,self.f.root);self.ops.session=dict(sessionId='test-only',archiveBundleId='org.example.overte',wdaBundleId='org.example.wda')
                async def fresh(value):self.source.current();self.assertEqual('42',value['processIdentity'])
                self.ops.fresh_touch_scope=fresh;self.loop.call_soon(ready.set_result,True);self.loop.run_forever()
            except BaseException as error:
                if not ready.done():ready.set_exception(error)
                else:self.loop_error=error
        self.loop_error=None;self.loop_thread=threading.Thread(target=run_loop,name='modeled-original-rsd-loop',daemon=False);self.loop_thread.start();ready.result(timeout=5)
        self.addCleanup(self.close_original)
        original_execute=self.f.adapter.client.execute
        def execute(session,operation,values):
            if operation!='mobile: overteOriginalKeeperOperation':return original_execute(session,operation,values)
            self.assertIn(values['operation'],('touch-native-query','touch-native-original-read'));self.executed.append(deepcopy(values))
            result=asyncio.run_coroutine_threadsafe(self.ops.execute(values['operation'],values['args'],session),self.loop).result(timeout=7)
            if self.after_query:self.after_query()
            if self.lost_return:raise OSError('Declared lost keeper RPC return AFTER actual original query task/WAL')
            return result
        def call(method,path,*args):self.sdk_calls.append((method,path));self.assertEqual(('GET','/session/test-only'),(method,path));return {}
        self.enterContext(patch.object(appium_adapter,'WebDriver',return_value=SimpleNamespace(call=call,execute=execute)))
        self.run='a'*32
    def close_original(self):
        async def settle():
            await self.source.settle_touches()
            self.assertTrue(all(task.done() and not thread.is_alive() for task,thread,finished,loop in self.source._native_queries))
            self.assertEqual([], [task for task in asyncio.all_tasks() if task is not asyncio.current_task() and not task.done()])
        # Root owns the fixed outer cap. Unknown original responsibility must
        # not be hidden by stopping this live loop or cancelling its tasks.
        asyncio.run_coroutine_threadsafe(settle(),self.loop).result()
        self.loop.call_soon_threadsafe(self.loop.stop);self.loop_thread.join(timeout=5)
        self.assertFalse(self.loop_thread.is_alive());self.loop.close();self.assertIsNone(self.loop_error)
    def query(self):return self.f.adapter._lifecycle_owned_native_query('test-only',self.run,'feature-native-observe')
    def wal(self):
        from adapters.normal_feature_state import PrivateFeatureState
        return PrivateFeatureState(self.f.root/('ios-lifecycle-native-query-owner-'+self.run+'.json')).read()
    def assert_no_new_session(self):
        self.assertEqual(self.before_counts,(self.f.sessions,self.f.launches));self.assertTrue(all(row==('GET','/session/test-only') for row in self.sdk_calls))

    def test_actual_selected_ipa_native_bundle_and_source_owned_query_compose_without_child_authority(self):
        result=self.query();self.assertEqual(self.before_sdk,self.sdk_store.read());self.assertEqual(1,len(self.executed))
        self.assertEqual(self.wal()['records'][0]['query'],result['queryOriginal']['query'])
        self.assertEqual(self.measured_directory_bundle,result['selectedArtifactBundle'])
        self.assertEqual(self.f.summary['bundleIdentity'],result['selectedArtifactBundle'])
        self.assertEqual(result['selectedArtifactBundle'],result['installedBefore']['observation']['bundle']);self.assertEqual(result['selectedArtifactBundle'],result['installedAfter']['observation']['bundle'])
        self.assertGreater(result['installedAfter']['observation']['sequence'],result['installedBefore']['observation']['sequence'])
        self.assertNotEqual(result['installedBefore']['observation']['commandId'],result['installedAfter']['observation']['commandId'])
        self.assertTrue(all(result[key] is False for key in ('nativeAcquisitionBound','originalChildCandidateBound','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished')));self.assert_no_new_session()

    def test_actual_selected_ipa_replacement_before_entry_refuses_before_original_query(self):
        self.f.artifact.write_bytes(self.f.artifact.read_bytes()+b'actual changed selected IPA')
        with self.assertRaises((ValueError,RuntimeError)):self.query()
        self.assertEqual([],self.executed);self.assertIsNone(self.wal());self.assert_no_new_session()

    def test_session_store_generation_drift_during_original_query_refuses_without_new_session_or_replay(self):
        def change():
            state=self.sdk_store.read();self.sdk_store.write(dict(state,generation=state['generation']+1),state)
        self.after_query=change
        with self.assertRaises((ValueError,RuntimeError)):self.query()
        original=self.wal();self.assertEqual(1,len(self.executed));self.assertEqual('http-returned',original['records'][0]['phase'])
        with self.assertRaises((ValueError,RuntimeError)):self.query()
        self.assertEqual(original,self.wal());self.assertEqual(1,len(self.executed));self.assert_no_new_session()

    def test_original_pid_drift_after_query_refuses_retained_success_without_repeating_nonce(self):
        self.after_query=lambda:self.f.process.update(pid=43)
        with self.assertRaises((ValueError,RuntimeError)):self.query()
        original=self.wal()
        with self.assertRaises((ValueError,RuntimeError)):self.query()
        self.assertEqual(original,self.wal());self.assertEqual(1,len(self.executed));self.assert_no_new_session()

    def test_actual_ipa_byte_change_after_query_refuses_before_any_returned_candidate_receipt(self):
        self.after_query=lambda:self.f.artifact.write_bytes(self.f.artifact.read_bytes()+b'changed during actual modeled query')
        with self.assertRaises((ValueError,RuntimeError)):self.query()
        self.assertEqual(1,len(self.executed));self.assertEqual('http-returned',self.wal()['records'][0]['phase']);self.assert_no_new_session()

    def test_lost_original_rpc_return_never_recovers_success_from_wal_and_next_query_uses_new_nonce(self):
        self.lost_return=True
        with self.assertRaises(OSError):self.query()
        first=self.wal();self.lost_return=False;value=self.query();last=self.wal()
        self.assertEqual(first['records'][0],last['records'][0]);self.assertNotEqual(first['records'][0]['query']['commandId'],value['queryOriginal']['query']['commandId'])
        self.assertEqual(2,len(self.executed));self.assertEqual(2,len(last['records']));self.assert_no_new_session()
