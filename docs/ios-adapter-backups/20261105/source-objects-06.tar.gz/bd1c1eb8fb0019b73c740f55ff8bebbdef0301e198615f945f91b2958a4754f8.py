"""One existing Actor SDK, two fully decoded original families; no End verdict.

The explicit coordinator is additional metadata, never a source observation.
Outside its actual lexical scope the original single-family guards still run.
"""
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from pathlib import Path
from types import FunctionType
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import identifier

NAME='ios-audio-shared-actor-ledger.json'
_CURRENT=ContextVar('overte_audio_shared_actor_original_membership',default=None)


def port_chain(owner,name):
    port=getattr(owner,name);receiver=getattr(port,'__self__',None);fn=getattr(port,'__func__',port);rows=[];seen=[]
    while fn is not None:
        need(type(fn)is FunctionType and not any(fn is old for old in seen));seen.append(fn)
        defaults=fn.__defaults__;keywords=fn.__kwdefaults__;closure=fn.__closure__;following=getattr(fn,'__wrapped__',None)
        rows.append((fn,fn.__code__,fn.__globals__,defaults,tuple(defaults or()),keywords,tuple((keywords or{}).items()),closure,tuple(cell.cell_contents for cell in closure or()),following))
        fn=following
    return(owner,name,receiver,rows)


def check_port(row):
    owner,name,receiver,rows=row;port=getattr(owner,name)
    need(getattr(port,'__self__',None)is receiver and getattr(port,'__func__',port)is rows[0][0])
    for fn,code,namespace,defaults,values,keywords,items,closure,cells,following in rows:
        need(fn.__code__ is code and fn.__globals__ is namespace and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
            and getattr(fn,'__wrapped__',None)is following)
        need(len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values)))
        need(tuple(keywords or())==tuple(key for key,value in items)and all(keywords[key]is value for key,value in items))
        need(len(closure or())==len(cells)and all(cell.cell_contents is value for cell,value in zip(closure or(),cells)))


def families():
    from ios.adapters.audio_passive_runtime import PassiveSDKLedger
    from ios.adapters.audio_received_mixer_runtime import ReceivedMixerSDKLedger
    return dict(microphone=PassiveSDKLedger,received=ReceivedMixerSDKLedger)


def selected(runtime,selector,run,root,client,lock):
    owner=_CURRENT.get()
    if owner is None:return None
    need(type(owner)is SharedActorCoordinator)
    owner.bound()
    need(runtime.adapter is owner.runtime.adapter and selector==owner.selector and run==owner.run
        and Path(root)==owner.root and client.url==owner.client.url and lock is owner.lock
        and runtime.state_path(selector).parent==owner.sdkroot)
    return owner


@contextmanager
def scope_for_flow(flow):
    """Read only the explicit existing shared family on the original locks."""
    from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
    for lock in flow.locks:lock.assert_held()
    path=flow.actor_runtime.state_path(flow.actor_selector).with_name(NAME)
    if PrivateFeatureState(path).read()is None:
        yield None;return
    need(type(flow)is IOSAudioWholeFeature)
    current=_CURRENT.get()
    if current is None:
        current=SharedActorCoordinator(flow.actor_runtime,flow.actor_selector,flow.run,flow.actor_root,flow.client,flow.locks[0])
    else:
        need(type(current)is SharedActorCoordinator and current.runtime.adapter is flow.actor_runtime.adapter
            and current.selector==flow.actor_selector and current.run==flow.run and current.root==flow.actor_root and current.lock is flow.locks[0])
    with current.scope():yield current


def join_shared_actor(flow):
    """Explicit enrollment after the original microphone parent already exists.

    No extra SDK, target, input, query or artifact root is constructed here.
    The original Whole grammar and full inventory are read around enrollment.
    """
    from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
    from ios.adapters.audio_whole_inventory import admit
    need(type(flow)is IOSAudioWholeFeature and flow.role=='primary')
    with flow.held():
        need(flow.state is not None and flow.state['phase']=='ready'and flow.state['replacement']is None)
        current=_CURRENT.get()
        if current is None:current=SharedActorCoordinator(flow.actor_runtime,flow.actor_selector,flow.run,flow.actor_root,flow.client,flow.locks[0])
        need(current.binding==flow.state['bindings']['actor'])
        with current.scope():admit(flow)
        return current


@contextmanager
def received_owner(flow,ticket):
    """Actual received owner on the EXISTING Actor SDK and common root."""
    from ios.adapters.audio_received_mixer_runtime import IOSAudioReceivedMixerRuntime
    from ios.adapters.audio_received_mixer_actor import lease_id
    identifier(ticket)
    with flow.held():
        coordinator=_CURRENT.get();need(type(coordinator)is SharedActorCoordinator)
        need(coordinator.binding==flow.state['bindings']['actor'])
        lease=lease_id(flow.run,ticket);coordinator.plan_received(lease)
        runtime=IOSAudioReceivedMixerRuntime(flow.adapter)
        with runtime.received_mixer_owner(flow.actor_selector,flow.run,lease,flow.actor_root,flow.client,
                epoch_ms=flow.epoch_ms,monotonic=flow.monotonic,sleep=flow.sleep,source_lock=flow.locks[0])as owner:
            yield owner


def phase_originals(flow):
    """Pure exact ordinary/capture-phase join, not a causal audio assertion."""
    from ios.adapters.audio_ordinary_independent_originals import IOSAudioOrdinaryIndependentOriginals
    from ios.adapters.audio_received_mixer_actor import lease_id
    with flow.held():
        coordinator=_CURRENT.get();need(type(coordinator)is SharedActorCoordinator and flow.role=='primary')
        normal=IOSAudioOrdinaryIndependentOriginals(flow).original();ticket=normal['sourceTicket']
        family=coordinator.originals()['received'];owner=family.owners.get(lease_id(flow.run,ticket))
        need(owner is not None and owner.historical and same(coordinator.binding,flow.state['bindings']['actor']))
        received=owner.original();owner.episode_retired()
        parent=flow.primary_parent();operations=[row for row in parent.state['operations']if row['ticket']==ticket and row['verb']=='record-start']
        need(len(operations)==1 and operations[0]['after']is not None)
        primary=parent.original(operations[0]['before']);selection=owner.proof(owner.proof(owner.state['birth'])['selection'])
        for phase in(selection['phaseBefore'],selection['phaseAfter']):
            need(phase['instance']==primary['phaseBefore']['instance']and phase['runId']==flow.run)
            activation=phase['activations'][-1]
            need(activation['ticket']==ticket and activation['stimulus']['verb']=='record-start'
                and same(activation['stimulus']['inputs'],parent.phase_original(primary['phaseBefore'],ticket,'record-start')))
        return dict(iosAudioSharedActorPhaseOriginalsVersion=2,runId=flow.run,sourceTicket=ticket,
            normalMedia=normal,received=received,sharedActorParents=coordinator.original(),
            sameExistingActorSDK=True,sameOriginalPhaseTicket=True,
            individualTalkerQualified=False,causalOutputToMixerQualified=False,crossDeviceClockComparisonPerformed=False,
            physicalADCQualified=False,physicalDACQualified=False,acousticQualified=False,nativeQualified=False,wholeQualified=False)


class FamilyOriginals:
    """Pure counterpart of each literal parent grammar, not a live parent DTO."""
    def __init__(self,coordinator,kind):
        from ios.adapters.audio_passive_runtime import identity
        self.coordinator,self.kind=coordinator,kind;cls=families()[kind]
        self.path=coordinator.sdkroot/cls.LEDGER_FILE;self.raw=PrivateFeatureState(self.path).read()
        self.children=set();self.owners={};self.pending=[]
        entry=coordinator.state['families'][kind]
        if self.raw is None:
            need(entry['phase']in('unselected','planned'));return
        need(entry['phase']in('planned','opened'))
        value=self.raw;version=value.get(cls.LEDGER_KEY)
        need(type(version)is int and version in cls.LEDGER_VERSIONS)
        exact(value,{cls.LEDGER_KEY,'binding','runId','role','sdkStateRoot','artifactRoot','rootIdentity','fixtureUrl','leases'}|({'processEnd'}if version==2 else set()))
        need(same(context(value['binding']),coordinator.binding)and value['runId']==coordinator.run and value['role']=='actor'
            and value['sdkStateRoot']==str(coordinator.sdkroot)and value['artifactRoot']==str(coordinator.root)
            and value['rootIdentity']==coordinator.root_identity and value['fixtureUrl']==coordinator.client.url+'/runs/'+coordinator.run+'/')
        # No existing individual Stop may be laundered into a shared End.
        need(value.get('processEnd')is None)
        rows=value['leases'];need(type(rows)is list and len(rows)<=16);seen=set()
        for row in rows:
            exact(row,{'leaseId','phase','rootIdentity'}|({'onceCacheCustody'}if'onceCacheCustody'in row else set()))
            lease=identifier(row['leaseId']);need(lease not in seen);seen.add(lease)
            need(row['phase']in('planned','opened')and('onceCacheCustody'not in row or version==2 and row['phase']=='opened'))
            child=coordinator.root/(cls.CHILD_PREFIX+lease)
            if row['phase']=='planned':
                need(lease==rows[-1]['leaseId']and row['rootIdentity']is None and not child.exists());self.pending.append(dict(leaseId=lease,stage='directory-planned'));continue
            exact(row['rootIdentity'],{'device','inode'})
            need(integer(row['rootIdentity']['device'],0)and integer(row['rootIdentity']['inode'],1)and identity(child)==row['rootIdentity']);self.children.add(child)
            store=PrivateFeatureState(child/cls.OWNER_TYPE.STORE_NAME)
            if store.read()is None:
                need(lease==rows[-1]['leaseId']and not list(child.iterdir()));self.pending.append(dict(leaseId=lease,stage='owner-not-yet-born'));continue
            owner=cls.OWNER_TYPE.archive(store,child,coordinator.binding,coordinator.run,lease,coordinator.lock,
                coordinator.client.url+'/runs/'+coordinator.run+'/')
            need(type(owner)is cls.OWNER_TYPE and owner.historical)
            if'onceCacheCustody'in row:need(owner.version==2 and same(row['onceCacheCustody'],owner.episode_retired()['cacheCustody']))
            self.owners[lease]=owner
        self.rows=deepcopy(rows)

    def original(self):
        need(self.raw is not None)
        return dict(family=self.kind,parent=deepcopy(self.raw),parentSha256=digest(self.raw),pending=deepcopy(self.pending),
            children=[dict(leaseId=lease,owner=deepcopy(owner.previous),ownerSha256=digest(owner.previous))for lease,owner in sorted(self.owners.items())])


class SharedActorCoordinator:
    def __init__(self,runtime,selector,run,root,client,lock):
        from ios.adapters.audio_passive_runtime import IOSAudioPassiveRuntime,identity
        need(isinstance(runtime,IOSAudioPassiveRuntime)and type(lock)is ScriptSourceLock)
        from ios.adapters.audio_response_command import target_flags
        target_flags(runtime.adapter._target(selector))
        identifier(run);self.runtime,self.selector,self.run=runtime,selector,run
        self.adapter=runtime.adapter;self.runtime_ports=[]
        for name in('state_path','_sources','existing_input_session'):self.runtime_ports.append(port_chain(runtime,name))
        self.runtime_ports.append(port_chain(self.adapter,'state_path'))
        self.root,self.client,self.lock=Path(root),client,lock;self.sdkroot=runtime.state_path(selector).parent
        need(self.root!=self.sdkroot and lock.path==self.sdkroot/'script-feature-sources.lock');lock.assert_held()
        self.root_identity=identity(self.root);identity(self.sdkroot)
        self.family_function=(families,families.__code__,families.__globals__)
        self.family_ports=[]
        for kind,cls in families().items():
            fields=tuple((name,getattr(cls,name))for name in('OWNER_TYPE','LEDGER_FILE','LEDGER_KEY','LEDGER_VERSIONS','CHILD_PREFIX'))
            fn=cls.OWNER_TYPE.archive.__func__
            self.family_ports.append((kind,cls,fields,fn,fn.__code__,fn.__globals__))
        self.store=PrivateFeatureState(self.sdkroot/NAME);self.previous=self.store.read();self.failed=False
        self.binding=self.state=None
        if self.previous is None:
            # Enrollment starts from the genuine existing microphone parent,
            # BEFORE this new metadata is born. It does not invent a binding.
            cls=families()['microphone'];raw=PrivateFeatureState(self.sdkroot/cls.LEDGER_FILE).read()
            need(raw is not None and PrivateFeatureState(self.sdkroot/families()['received'].LEDGER_FILE).read()is None)
            rows=raw['leases'];need(type(rows)is list and rows)
            parent=cls(runtime,selector,run,rows[-1]['leaseId'],self.root,client,lock)
            need(parent.process_end is None and parent.binding is not None)
            self.binding=deepcopy(parent.binding)
            self.state=dict(families=dict(microphone=dict(phase='opened',selectedLease=None),received=dict(phase='unselected',selectedLease=None)),end=None)
            self.save()
        else:
            value=self.previous
            exact(value,{'iosAudioSharedActorParentsVersion','binding','runId','sdkStateRoot','artifactRoot','rootIdentity','fixtureUrl','state'})
            need(type(value['iosAudioSharedActorParentsVersion'])is int and value['iosAudioSharedActorParentsVersion']==2
                and value['runId']==run and value['sdkStateRoot']==str(self.sdkroot)and value['artifactRoot']==str(self.root)
                and value['rootIdentity']==self.root_identity and value['fixtureUrl']==client.url+'/runs/'+run+'/')
            self.binding=deepcopy(context(value['binding']));self.state=deepcopy(value['state']);self.shape()
        self.guard()

    def shape(self):
        exact(self.state,{'families','end'});exact(self.state['families'],{'microphone','received'})
        for kind,row in self.state['families'].items():
            exact(row,{'phase','selectedLease'});need(row['phase']in('unselected','planned','opened'))
            need(kind!='microphone'or row['phase']=='opened')
            if row['phase']=='planned':identifier(row['selectedLease'])
            else:need(row['selectedLease']is None)
        if self.state['end']is not None:
            exact(self.state['end'],{'phase','rootIdentity','proof'});need(self.state['end']['phase']in('planned','opened','complete'))
            if self.state['end']['phase']=='complete':
                exact(self.state['end']['proof'],{'archiveSha256','keeperArchiveSha256'})
                need(all(type(value)is str and len(value)==64 and set(value)<=set('0123456789abcdef')for value in self.state['end']['proof'].values()))
            else:need(self.state['end']['proof']is None)

    def envelope(self):
        return dict(iosAudioSharedActorParentsVersion=2,binding=deepcopy(self.binding),runId=self.run,
            sdkStateRoot=str(self.sdkroot),artifactRoot=str(self.root),rootIdentity=self.root_identity,
            fixtureUrl=self.client.url+'/runs/'+self.run+'/',state=deepcopy(self.state))

    def bound(self,*,writing=False):
        from ios.adapters.audio_passive_runtime import identity
        self.lock.assert_held();need(not self.failed and identity(self.root)==self.root_identity and same(self.store.read(),self.previous))
        need(self.runtime.adapter is self.adapter)
        from ios.adapters.audio_response_command import target_flags
        target_flags(self.adapter._target(self.selector))
        for row in self.runtime_ports:check_port(row)
        need(self.runtime.state_path(self.selector).parent==self.sdkroot)
        fn,code,namespace=self.family_function
        need(families is fn and fn.__code__ is code and fn.__globals__ is namespace)
        current=families()
        for kind,cls,fields,archive,code,namespace in self.family_ports:
            need(current[kind]is cls and all(getattr(cls,name)is value for name,value in fields))
            need(cls.OWNER_TYPE.archive.__func__ is archive and archive.__code__ is code and archive.__globals__ is namespace)
        if not writing and self.previous is not None:need(same(self.previous,self.envelope()))
        return True

    def save(self):
        try:
            self.bound(writing=True);self.shape();value=self.envelope();self.store.write(value,self.previous)
            need(same(self.store.read(),value));self.previous=deepcopy(value)
        except BaseException:self.failed=True;raise

    def originals(self):
        self.bound();self.shape()
        values={kind:FamilyOriginals(self,kind)for kind in families()}
        scope=PrivateFeatureState(self.sdkroot/'ios-audio-scope.json')
        need(same(scope.read(),dict(iosAudioScopeVersion=1,binding=self.binding,runId=self.run,artifactRoot=str(self.root))))
        sdk={scope.path,self.store.path}|{owner.path for owner in values.values()if owner.raw is not None}
        children=set().union(*(owner.children for owner in values.values()))
        if self.state['end']is not None:
            from ios.adapters.audio_shared_actor_end import SharedActorEnd,end_root,end_store
            row=self.state['end'];path=end_root(self)
            if row['phase']=='planned':need(row['rootIdentity']is None and row['proof']is None and not path.exists())
            else:
                from ios.adapters.audio_passive_runtime import identity
                need(identity(path)==row['rootIdentity']);children.add(path)
                end=SharedActorEnd(self)
                if end.previous is None:need(not list(path.iterdir())and end_store(self).read()is None)
                else:
                    sdk.update(p for p in end.owned_paths()if p.parent==self.sdkroot)
                    if row['phase']=='complete':
                        need(end.state['phase']=='complete'and row['proof']==dict(archiveSha256=digest(end.previous),keeperArchiveSha256=end.state['keeperProof']['archiveSha256']))
        need({p for p in self.sdkroot.iterdir()if p.name.startswith('ios-audio-')}==sdk)
        need(set(self.root.iterdir())==children)
        return values

    def guard(self):self.originals();return True

    @contextmanager
    def scope(self):
        self.guard();prior=_CURRENT.get();need(prior is None or prior is self);token=_CURRENT.set(self)
        try:yield self;self.guard()
        finally:_CURRENT.reset(token)

    def kind(self,ledger):
        selected=[name for name,cls in families().items()if type(ledger)is cls];need(len(selected)==1)
        need(ledger.runtime.adapter is self.runtime.adapter and ledger.selector==self.selector and ledger.run==self.run
            and ledger.root==self.root and ledger.lock is self.lock and ledger.client.url==self.client.url)
        return selected[0]

    def plan_received(self,lease):
        identifier(lease);self.guard();need(self.state['end']is None)
        row=self.state['families']['received']
        if row['phase']=='unselected':row.update(phase='planned',selectedLease=lease);self.save()
        elif row['phase']=='planned':need(row['selectedLease']==lease)
        return True

    def first_parent(self,ledger):
        self.bound();kind=self.kind(ledger);row=self.state['families'][kind]
        need(kind=='received'and row==dict(phase='planned',selectedLease=ledger.selected_lease)and self.state['end']is None)
        value=self.originals()[kind];need(value.raw is None);return True

    def membership(self,ledger,own_sdk,own_children,*,live=False):
        if live:self.require_live()
        kind=self.kind(ledger);values=self.originals();family=values[kind]
        need(family.raw is not None and same(family.raw,ledger.previous)and same(family.raw,ledger.envelope()))
        need(own_sdk=={ledger.scope.path,ledger.store.path}and own_children==family.children)
        return True

    def require_live(self,*,writing=False):
        self.bound();need(self.state['end']is None)
        # The original parent CAS owns its exact planned->mkdir->opened span.
        # Inspect full durable membership only outside that existing write span.
        if not writing:self.guard()
        return True

    def parent_opened(self,ledger):
        kind=self.kind(ledger);row=self.state['families'][kind]
        if row['phase']=='planned':
            need(row['selectedLease']==ledger.selected_lease and same(ledger.binding,self.binding))
            row.update(phase='opened',selectedLease=None);self.save()
        self.guard()

    def original(self):
        values=self.originals()
        return dict(iosAudioSharedActorOriginalsVersion=2,binding=deepcopy(self.binding),runId=self.run,
            sdkStateRoot=str(self.sdkroot),artifactRoot=str(self.root),families={kind:value.original()for kind,value in values.items()if value.raw is not None},
            familyMembershipComplete=True,sourceObservation=False,processEndEstablished=False,wholeQualified=False)

    def individual_end_refused(self):
        need(False)

    def before_original_stop(self,keeper):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
        from ios.adapters.audio_shared_actor_end import NativeReplyRetirementMissing,reply_retirement_duty,SharedActorEnd,PROFILE_KEY,end_root
        need(type(keeper)is IOSOriginalKeeperProcessEnd and keeper.shared_actor is self and keeper.runtime is self.runtime
            and keeper.binding==self.binding and keeper.run==self.run and keeper.lock is self.lock
            and keeper.profile_key==PROFILE_KEY and keeper.role=='actor'and keeper.stage==0 and keeper.root==end_root(self)
            and keeper.state['cutoff']is not None and keeper.state['stop']is None)
        self.guard();SharedActorEnd(self).original_snapshot()
        from ios.adapters.audio_shared_actor_response_retirement import AudioResponseRetirement
        end=SharedActorEnd(self)
        return AudioResponseRetirement(end,keeper).before_stop()
