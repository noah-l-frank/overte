/* Prospective real ChildProcess/pipe/registry composition; device SDKs MODELS.
 * Root alone executes. No Appium/vendor module, device or installed SDK import.
 * Exact candidate keeper class is imported; exact registry replacement function
 * is evaluated with an explicit local process-birth/SDK boundary model.
 */
import assert from 'node:assert/strict';
import {spawn, ChildProcess} from 'node:child_process';
import {createHash,randomUUID} from 'node:crypto';
import {readFile,writeFile,mkdir,mkdtemp,chmod} from 'node:fs/promises';
import {createServer} from 'node:http';
import {isDeepStrictEqual} from 'node:util';
import {pathToFileURL} from 'node:url';
import path from 'node:path';

const config=JSON.parse(await readFile(process.argv[2],'utf8'));
const digest=raw=>createHash('sha256').update(raw).digest('hex');
for(const row of [config.keeper,config.registry,config.child,config.wrapper,config.provider])
  assert.equal(digest(await readFile(row.path)),row.sha256,'Pinned prospective source changed');
const {OriginalUserspaceKeeper}=await import(pathToFileURL(config.keeper.path));
const registryRaw=await readFile(config.registry.path,'utf8');
const begin=registryRaw.indexOf('function originalCanonical(value) {');
const finish=registryRaw.indexOf('\nasync function createTunnelForDevice(device) {',begin);
assert(begin>=0&&finish>begin);assert.equal(registryRaw.indexOf('function originalCanonical(value) {',begin+1),-1);
const selectedRegistry=registryRaw.slice(begin,finish);
const owners=new Map();const children=[];const born=[];let replacementBirths=0;
const target='explicit-local-model-only';
const device={Properties:{SerialNumber:target}}; // No physical selector.
const report={prospectiveFixtureVersion:1,scenario:config.scenario,physicalSDKModeled:true,
  nativeCutoffModeled:true,current7Qualified:false,parentEndArchiveQualified:false,
  keeperSourceSha256:config.keeper.sha256,registrySourceSha256:config.registry.sha256,
  registrySelectedSourceSha256:digest(selectedRegistry),childSourceSha256:config.child.sha256,
  childExitEvents:[],childCloseEvents:[],births:0,canonicalDeletes:0,canonicalCreates:0};
const request=(owner,operation,args={},sessionId=owner.session)=>({schemaVersion:2,ownerInstance:owner.instance,
  requestId:randomUUID().replaceAll('-',''),operation,sessionId,args});
async function birth(onOriginalBirth,{replacement=false}={}) {
  const root=await mkdtemp(path.join(config.root,replacement?'new-original-':'old-original-'));await chmod(root,0o700);
  const input={...config,root,fault:replacement?null:config.scenario==='unregistered-task'?'unregistered-task':null};
  const inputPath=path.join(root,'fixture-input.json');await writeFile(inputPath,JSON.stringify(input),{mode:0o600});
  const child=spawn(config.python,['-B',config.child.path,inputPath],{cwd:'/',stdio:['pipe','pipe','pipe'],
    env:{PATH:'/usr/bin',LANG:'C.UTF-8',LC_ALL:'C.UTF-8',PYTHONDONTWRITEBYTECODE:'1',PYTHONNOUSERSITE:'1',
      PYTHONPATH:config.pythonPath}});
  assert.equal(Object.getPrototypeOf(child),ChildProcess.prototype);children.push(child);
  let stderr='';child.stderr.on('data',chunk=>{stderr=(stderr+chunk.toString('utf8')).slice(-16384);});
  child.once('close',()=>{if(stderr)report.modelChildStderr=(report.modelChildStderr??[]).concat(stderr);});
  const owner=new OriginalUserspaceKeeper(child,target);born.push(owner);report.births+=1;
  child.once('exit',(code,signal)=>report.childExitEvents.push({pid:child.pid,code,signal}));
  child.once('close',(code,signal)=>report.childCloseEvents.push({pid:child.pid,code,signal}));
  onOriginalBirth(owner);await owner.ready;
  if(replacement&&config.scenario==='replacement-failure')throw new Error('Declared failure AFTER actual replacement child birth');
  await owner.inspect();return owner;
}
const factory=async (selectedDevice,onOriginalBirth)=>{
  assert.equal(selectedDevice,device);replacementBirths+=1;return await birth(onOriginalBirth,{replacement:true});
};
const registry=new Function('createHash','isDeepStrictEqual','startOriginalUserspaceKeeper','originalUserspaceOwners','creatorMode','originalCreatorStopping',
  selectedRegistry+'\nreturn {replaceRetiredOriginalOwner,originalDigest};')(createHash,isDeepStrictEqual,factory,owners,'userspace-keeper',false);
let sessionLive=true;let canonicalSDK={sessionId:'model-original',generation:1};let installedBinding={phase:'bound'};
const remote=createServer(async (req,res)=>{
  // Explicit SDK/session DATA MODEL. Requests and responses use a real local
  // HTTP listener; a device SDK or installed server is never contacted.
  if(req.method==='DELETE'&&req.url==='/session/model-original') {
    assert.equal(report.creatorQualified,true,'Canonical deletion before actual creator retirement');
    assert.equal(report.resourceQualified,true,'Canonical deletion before actual resource proof');
    report.canonicalDeletes+=1;sessionLive=false;res.writeHead(200,{'content-type':'application/json'});res.end('{"value":null}');return;
  }
  if(req.method==='GET'&&req.url==='/session/model-original') {
    res.writeHead(sessionLive?200:404,{'content-type':'application/json'});
    res.end(JSON.stringify({value:sessionLive?{}:{error:'invalid session id'}}));return;
  }
  res.writeHead(404);res.end();
});
await new Promise(resolve=>remote.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+remote.address().port;
let oldOwner=null;let newOwner=null;
try {
  oldOwner=await birth(owner=>owners.set(target,{device,owner,starting:null,closing:false,completed:true}));
  const claim={sessionId:'model-original',archiveBundleId:'org.overte.model',wdaBundleId:'org.overte.wda.model'};
  await oldOwner.request(request(oldOwner,'claim',claim,claim.sessionId));
  const prepared=await oldOwner.request(request(oldOwner,'fixture-resource-prepare'));
  assert.equal(prepared.nativeCutoffModel,true);assert.equal(prepared.current7Qualified,false);
  assert.equal(prepared.keeperProcessId,oldOwner.child.pid);report.sourceBindings=prepared.sourceBindings;
  const foreignControl=await oldOwner.request(request(oldOwner,'fixture-foreign-control-registration'));
  assert.equal(foreignControl.refused,true);report.foreignControlRefused=true;
  if(config.scenario==='source-code') {
    const before=await oldOwner.request(request(oldOwner,'fixture-source-code-mutate'));
    await assert.rejects(oldOwner.request(request(oldOwner,'fixture-resource-sample')));
    const restored=await oldOwner.request(request(oldOwner,'fixture-source-code-restore'));
    assert.equal(restored.processQueries,before.processQueries);assert.equal(restored.pending,null);
    report.sameSourceCodeMutationRefusedBeforeQuery=true;
  }
  for(let index=0;index<10;index++) {
    await oldOwner.request(request(oldOwner,'fixture-resource-sample'));
    if(index<9)await new Promise(resolve=>setTimeout(resolve,360));
  }
  if(config.scenario==='unregistered-task') {
    await assert.rejects(oldOwner.request(request(oldOwner,'fixture-resource-close')));
    const state=await oldOwner.request(request(oldOwner,'fixture-end-state'));
    assert.equal(state.sdk,null);assert.equal(state.pending.kind,'sdk');
    await assert.rejects(oldOwner.retireOriginalCreator(request(oldOwner,'original-process-end-creator-retire',
      {binding:prepared.binding,runId:prepared.runId,stage:0,sdkReference:{}})));
    assert.equal(oldOwner.originalExit,null);assert.equal(report.canonicalDeletes,0);assert.equal(replacementBirths,0);
    report.failurePendingRetained=true;report.resourceQualified=false;report.creatorQualified=false;
    report.failureOriginal=await oldOwner.request(request(oldOwner,'fixture-release-fault'));
  } else {
    const closed=await oldOwner.request(request(oldOwner,'fixture-resource-close'));
    const proof=closed.resourceOriginal;
    assert.equal(proof.resourceRetirementEstablished,true);assert.equal(proof.canonicalSessionDeleted,false);
    assert.equal(proof.originalThreadCensusOnlyControl,true);assert.equal(proof.originalRemainingTaskCensusOnlyControlAndEnd,true);
    assert.deepEqual(proof.originalControlTasks.map(row=>row.kind).sort(),['reading','stopping']);
    assert(proof.providers.length>=3);assert(proof.providers.every(row=>row.originalSocketFd===-1&&row.originalDtxCloseAwaitReturned===true));
    assert.deepEqual(proof.originalStreamSocketFds,[-1,-1,-1]);assert.deepEqual(proof.tunSocketFds,[-1,-1]);
    report.resourceQualified=true;report.resourceOriginal=proof;report.sdkReference=closed.sdkReference;
    const retirementRequest=request(oldOwner,'original-process-end-creator-retire',
      {binding:closed.binding,runId:closed.runId,stage:0,sdkReference:closed.sdkReference});
    const retired=await oldOwner.retireOriginalCreator(retirementRequest);
    // Deliberately lose the first caller return, then recover ONLY the exact
    // completed original from the retained dead owner. No second close/kill.
    const replay=oldOwner.creatorRetirementOriginal({ownerInstance:oldOwner.instance,sessionId:oldOwner.session});
    assert.deepEqual(replay,retired);assert.deepEqual(await oldOwner.retireOriginalCreator(retirementRequest),retired);
    assert.equal(retired.keeperProcessId,oldOwner.child.pid);assert.equal(retired.exitCode,0);assert.equal(retired.signalCode,null);
    assert.deepEqual(retired.originalStdioClosed,[true,true,true]);assert(oldOwner.child.stdin.destroyed&&oldOwner.child.stdout.destroyed&&oldOwner.child.stderr.destroyed);
    assert.equal(report.childExitEvents.filter(row=>row.pid===oldOwner.child.pid).length,1);
    assert.equal(report.childCloseEvents.filter(row=>row.pid===oldOwner.child.pid).length,1);
    report.creatorQualified=true;report.creatorOriginal=retired;report.creatorReplayEqual=true;
    assert.throws(()=>OriginalUserspaceKeeper.prototype.captureCreatorRetirement.call({...oldOwner,
      creatorRetirement:null,child:{exitCode:0,signalCode:null,stdin:{destroyed:true},stdout:{destroyed:true},stderr:{destroyed:true}}}));
    const deleted=await fetch(origin+'/session/model-original',{method:'DELETE'});assert.equal(deleted.status,200);
    const absent=await fetch(origin+'/session/model-original');assert.equal(absent.status,404);
    // These are explicit canonical PFS DATA MODELS, discarded only after the
    // actual known HTTP404. The typed outer End archive is not synthesized.
    canonicalSDK=null;installedBinding=null;report.canonicalStateAbsent=canonicalSDK===null&&installedBinding===null;
    const args={binding:closed.binding,oldCreatorRetirementSha256:registry.originalDigest(retired),oldOwnerInstance:oldOwner.instance,
      profile:'ios-original-keeper-readmission-v1',profileKey:'audiowhole',replacementGrant:retired.replacementGrant,runId:closed.runId,stage:0};
    const replacement={schemaVersion:2,sessionId:null,operation:'replace-after-original-end',ownerInstance:oldOwner.instance,args};
    await assert.rejects(registry.replaceRetiredOriginalOwner(target,{...replacement,args:{...args,replacementGrant:'f'.repeat(32)}}));
    assert.equal(replacementBirths,0);
    if(config.scenario==='replacement-failure') {
      await assert.rejects(registry.replaceRetiredOriginalOwner(target,replacement));
      const record=owners.get(target);assert.equal(record.previous.owner,oldOwner);assert.equal(record.closing,true);assert(record.owner instanceof OriginalUserspaceKeeper);
      await assert.rejects(registry.replaceRetiredOriginalOwner(target,replacement));assert.equal(replacementBirths,1);
      assert.equal(record,owners.get(target));report.failedReplacementRetained=true;
    } else {
      const [first,second]=await Promise.all([registry.replaceRetiredOriginalOwner(target,replacement),registry.replaceRetiredOriginalOwner(target,replacement)]);
      assert.deepEqual(first,second);assert.equal(replacementBirths,1);assert.notEqual(first.ownerInstance,oldOwner.instance);
      assert.deepEqual(await registry.replaceRetiredOriginalOwner(target,replacement),first);assert.equal(replacementBirths,1);
      newOwner=owners.get(target).owner;assert.equal(owners.get(target).previous.owner,oldOwner);
      const newClaim={...claim,sessionId:'model-replacement'};
      await newOwner.request(request(newOwner,'claim',newClaim,newClaim.sessionId));report.canonicalCreates+=1;
      canonicalSDK={sessionId:newClaim.sessionId,generation:2};installedBinding={phase:'bound'};
      const identity=await newOwner.request(request(newOwner,'original-readmission-identity'));
      assert.equal(identity.ownerInstance,newOwner.instance);assert.equal(identity.sessionId,newClaim.sessionId);
      assert.equal(identity.sourceLive,true);assert.equal(identity.existingWdaBound,true);assert.notEqual(newOwner.child.pid,oldOwner.child.pid);
      // Appium's actual host route joins this exact registry receipt to its
      // identity response; this fixture checks both original owners directly.
      report.replacementOriginal=first;report.newSourceIdentity=identity;report.oneBirthReplayEqual=true;
      report.nativeIdleQualified=false;report.readmissionArchiveQualified=false;
    }
  }
  report.replacementBirths=replacementBirths;report.observedCanonicalDeletes=report.canonicalDeletes;
} catch(error) {
  report.fixtureError=String(error.stack);throw error;
} finally {
  // Fixture teardown releases real local modeled owners without converting
  // cleanup/drain into an End/resource/readmission qualification.
  for(const owner of born) {
    if(owner.child.exitCode===null&&owner.child.signalCode===null) {
      try {await owner.close();} catch(error) {report.teardownFailure=String(error.message);}
      if(owner.originalCloseEvent===null)await new Promise(resolve=>owner.child.once('close',resolve));
    }
  }
  remote.closeIdleConnections();await new Promise(resolve=>remote.close(resolve));
  if(report.fixtureError)await writeFile(config.report,JSON.stringify(report,null,2)+'\n',{mode:0o600});
}
assert(children.every(child=>child.exitCode!==null||child.signalCode!==null));
assert(children.every(child=>child.stdin.destroyed&&child.stdout.destroyed&&child.stderr.destroyed));
report.allFixtureChildrenClosed=true;
await writeFile(config.report,JSON.stringify(report,null,2)+'\n',{mode:0o600});
