"""UNRUN retained-original diagnostic, requiring a separately reviewed controller.

This never rebuilds the normal fixture, opens a session, queries a producer or
creates a raw root. It cannot measure the live owner's construction cost.
"""
from contextlib import ExitStack
from copy import deepcopy
import json
import importlib
from pathlib import Path
import time

from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.witness import Client
from ios.adapters import chat_archive_round
from ios.adapters.chat_draft_runtime import IOSChatDraftRuntime
from ios.adapters.chat_receive_sources import IOSChatReceiveSources
from ios.adapters.chat_send_receive import original_sent


def unavailable(*_args, **_kwargs):
    raise AssertionError('Retained-original diagnosis cannot use live authority or transport')


class HistoricalPaths:
    """File mapping only. Genuine runtime construction gets refusing live ports."""
    _candidate_guard = staticmethod(unavailable)
    _binding = staticmethod(unavailable)

    def __init__(self, paths):
        self.paths = dict(paths)

    def state_path(self, selector):
        return self.paths[selector] / 'session.json'


class NoTransportClient(Client):
    request = unavailable


def measured(label, operation):
    print(json.dumps(dict(phase=label, event='begin')), flush=True)
    started = time.monotonic()
    try:
        result = operation()
    except BaseException:
        print(json.dumps(dict(phase=label, event='error', seconds=time.monotonic()-started)), flush=True)
        raise
    print(json.dumps(dict(phase=label, event='end', seconds=time.monotonic()-started,
        construction=deepcopy(chat_archive_round._LAST_CONSTRUCTION.get()),
        decodeCounts=chat_archive_round._LAST_COUNTS.get(), frameCounts=chat_archive_round._LAST_FRAME_COUNTS.get(),
        activeRound=chat_archive_round._ACTIVE.get() is not None)), flush=True)
    return result


def select_cuts(receive, sender, send, role):
    """Only candidate selection; original_sent performs the full actual join."""
    first = sender.original(send['before'])['clockJoin']
    last = sender.original(send['after'])['clockJoin']
    eligible = []
    for reference in receive.state['records']:
        original = receive.original(reference)
        before = original['joins']['peer']
        if (before['hostAfterEpochMs'] <= first['hostBeforeEpochMs']
                and before['hostAfterMonotonic'] <= first['hostBeforeMonotonic']):
            eligible.append(reference)
    assert eligible
    before = eligible[-1]
    recipient = 'primary' if role == 'peer' else 'peer'
    baseline = receive.original(before)['sample'][recipient]['source']['events']
    for reference in receive.state['records'][before['index']:]:
        original = receive.original(reference)
        after = original['joins']['primary']
        if (last['hostAfterEpochMs'] <= after['hostBeforeEpochMs']
                and last['hostAfterMonotonic'] <= after['hostBeforeMonotonic']):
            events = original['sample'][recipient]['source']['events']
            assert same(events[:len(baseline)], baseline)
            if len(events) > len(baseline):
                return deepcopy(before), deepcopy(reference)
    raise AssertionError('Actual retained receive originals contain no qualifying append')


def diagnose(raw, artifact):
    """Inputs must be independently pinned by the future controller before imports.

    The only admitted writable open is each *existing* zero-byte lock inode,
    solely for genuine flock. A controller must reject O_CREAT on any absent
    path before this function. No successful candidate/native guard is supplied.
    """
    # The future controller pins artifact bytes/inode independently BEFORE
    # importing this module or consulting any historical header. These imports
    # are the existing declared pure parser frontier, not new authorities.
    for name in (*chat_archive_round._MODULES, *chat_archive_round._QML_AUTHORITIES):
        importlib.import_module(name)
    assert chat_archive_round.original_methods()
    measured('current-qml-parser-fence', chat_archive_round.qml_authority)
    paths = {'primary': raw / 'tmpm0n175js', 'peer': raw / 'tmp4anb7giw'}
    locks = {role: ScriptSourceLock(path / 'script-feature-sources.lock') for role, path in paths.items()}
    stores = {role: PrivateFeatureState(path / 'ios-chat-draft-owner.json') for role, path in paths.items()}
    headers = {role: store.read() for role, store in stores.items()}
    assert all(type(value) is dict for value in headers.values())
    assert headers['primary']['runId'] == headers['peer']['runId']
    run = headers['primary']['runId']
    suffix = '/runs/' + run + '/'
    fixture_url = headers['primary']['fixtureUrl']
    assert fixture_url == headers['peer']['fixtureUrl'] and fixture_url.endswith(suffix)
    # Constructor validates URL shape. No request method can succeed; the token
    # is an explicit noncredential diagnostic placeholder, never read from WALs.
    client = NoTransportClient(fixture_url[:-len(suffix)], 'diagnostic-no-transport-no-secret-token')
    runtime = IOSChatDraftRuntime(HistoricalPaths(paths))
    receive_store = PrivateFeatureState(paths['peer'] / 'ios-chat-receive-sources.json')
    receive_header = receive_store.read()
    with ExitStack() as lifetime:
        for role in ('primary', 'peer'):
            lifetime.enter_context(locks[role].held())
        source = measured('receive-archive', lambda: IOSChatReceiveSources.archive(receive_store,
            headers['primary']['binding'], headers['peer']['binding'], run,
            headers['primary']['artifactRoot'], headers['peer']['artifactRoot'],
            receive_header['peerBindingRecord'], locks['primary'], locks['peer']))
        contexts = measured('genuine-receipt-factory', lambda: runtime._chat_receipt_contexts(
            'primary', 'peer', run, client, source, qml_artifacts={role: artifact for role in paths}))
        # The exact original sender factory decodes the actual completed peer
        # archive. The raw payload is used only to select its actual Send ticket
        # and after-frontier; the real archive decoder must admit both again.
        from adapters.script_feature.history import unpack
        state = unpack(headers['peer']['payload'])[0]
        sends = [row for row in state['operations'] if row['verb'] == 'send' and row['after'] is not None]
        assert len(sends) == 1
        send = sends[0]
        factory = contexts['primary'].sender(send['ticket'], send['after'])
        sender = measured('peer-bounded-archive-enter', lambda: lifetime.enter_context(factory))
        before, after = measured('retained-outer-cut-selection', lambda: select_cuts(source, sender, send, 'peer'))
        fact = measured('peer-original-sent-join', lambda: original_sent(sender, source,
            send['ticket'], before, after, sender_role='peer'))
        measured('primary-receipt-link', lambda: contexts['primary'].link(fact))
        assert chat_archive_round._ACTIVE.get() is None
    assert chat_archive_round.original_methods()
    measured('final-current-qml-parser-fence', chat_archive_round.qml_authority)
    return dict(diagnosticOnly=True, wholeChatQualified=False, nativeQualified=False,
        deviceQualified=False, sdkExecuted=False, normalFlowRetried=False)
