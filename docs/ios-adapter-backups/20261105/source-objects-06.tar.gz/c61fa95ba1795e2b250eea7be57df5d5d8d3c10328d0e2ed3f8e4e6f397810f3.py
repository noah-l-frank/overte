"""Close immutable failed MP setup originals; never rerun a case or invent missing exits."""
from pathlib import Path
import hashlib,json,runpy
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,v):
 with(d/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
C=B/'root-tablet17-chat-onepair-window-current1138-20261105';partial=load(C/'unqualified-partial-custody.json');assert partial['status']=='NO_QUIET_CLOSE_INFERRED'and len(partial['completedGroups'])==1
base=partial['completedGroups'][0];assert base['group']=='baseline6'and base['originalTerminal']['status']=='PASS'and base['supervisorReturnCode']==0
H1=Path(base['input']).parent;O1=H1.with_name(H1.name+'-outer');C1=H1.with_name(H1.name+'-censuses')
H2=Path(partial['attempt']['input']).parent;O2=H2.with_name(H2.name+'-outer');C2=H2.with_name(H2.name+'-censuses')
assert sha(H1/'approved-inputs.json')=='97ebf81a72fb791e776152d4c553b672290b522424feb19693fc19914a29bc43'
assert sha(H2/'approved-inputs.json')=='829f8641e92cebd3fe50b6e2be8c85258a7a777d943c214edd93fe6b06159f02'
assert not(C/'freeze.json').exists()and not(O2/'terminal.json').exists()and not C2.exists()
assert not(H2/'child-receipts/report.json').exists()and(H2/'child-receipts/actual-port-restoration.json').read_bytes()==b''
report=load(H1/'child-receipts/report.json');ports=load(H1/'child-receipts/actual-port-restoration.json')
assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==6 and report['cleanupEstablished']and report['fatal']is None
assert len(report['retainedTemporaryDirectories'])==6 and ports['count']==27 and ports['controlDescriptors']==[]
for k in('restored','toolsRestored','dupPortsRestored','builtinsCioRestored'):assert ports[k]is True
cases=[load(H1/('child-receipts/standard-case-'+str(n)+'.json'))for n in range(1,7)]
assert [r['id']for r in cases]==load(H1/'approved-inputs.json')['cases']
for r in cases:
 assert r['remainingStandardCleanups']==0 and r['newTemporaryDirectories']==1
 for k in('standardStopAfterCleanup','originalMethodsUnchanged','monitorSlotsUnchanged','fdUnchanged','threadsUnchanged','kernelChildrenUnchanged'):assert r[k]is True
q=load(C1/'qualification.json');assert q==base['originalQualification']and q['status']=='PASS'and q['ownProcessesAbsent']is True
mp_error=(H2/'child-logs/stderr.log').read_text();outer_error=(C/'mp3-stderr.log').read_text()
assert 'ValueError: invalid local event set 0x2005'in mp_error and 'self.runtime.install()'in mp_error
assert 'JSONDecodeError'in outer_error and 'restore_path.read_text()'in outer_error
assert not(C/'completed-after-mp3.json').exists()
identities=[];drains=[]
for o in(O1,O2):
 birth=load(o/'actual-runner-birth.json');drain=load(o/'actual-process-drain.json');assert drain['remaining']==drain['orphansRequiredKill']==[]and drain['timedOut']is drain['forced']is False
 identities.append(birth);identities+=drain['owned'];drains.append(drain)
groups={r['group']for r in identities};seen=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdecimal():continue
 try:raw=(proc/'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 f=raw[raw.rfind(')')+2:].split()
 if int(f[2])in groups or int(f[3])in groups:seen.append(dict(pid=int(proc.name),group=int(f[2]),session=int(f[3]),startTicks=int(f[19])))
assert seen==[]
for row in identities:
 try:raw=Path('/proc',str(row['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(raw[raw.rfind(')')+2:].split()[19])!=row['startTicks']
ctx=load(B/'root-ios-current1138-after-audio26-partial19-context-20261105/root-context.json');helper=Path(ctx['globalCustody']['helper']['path']);assert sha(helper)=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
expected=load(ctx['globalCustody']['baseline']['path']);assert len(expected)==1138 and expected==load(C/'global-before.json')
a=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(a)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(a))['census'];current=runpy.run_path(str(helper))['current']
OUT=B/'root-tablet-b2-baseline6-qualified-mp-setup-negative-complete-custody-20261105';OUT.mkdir(mode=0o700)
put(OUT,'actual-recorded-kernel-absence.json',dict(originalIdentities=identities,actualSameGroupOrSession=seen,originalDrainReceipts=drains,unknownUnrecordedCreatorAuthorityGranted=False))
one=current();put(OUT,'global-after-first.json',one);two=current();put(OUT,'global-after-second.json',two);assert one==two==expected
rooms=[H1,O1,C1,H2,O2,C];first={str(p):census(p)for p in rooms};second={str(p):census(p)for p in rooms};assert first==second
put(OUT,'whole-first.json',first);put(OUT,'whole-second.json',second)
refs={str(p):dict(path=str(p),sha256=sha(p))for root in rooms for p in sorted(root.rglob('*'))if p.is_file()and not p.is_symlink()}
# This is the actual ROOT DRIVER return observed by tool write_stdin54750,
# chunk4fe894, exit1. Missing MP supervisor/runner terminal codes stay None.
observed=dict(provider='exec_command/write_stdin',sessionId=54750,chunkId='4fe894',observedRootControllerExitCode=1,rootException=partial['originalTraceback'],mpSupervisorTerminalReceipt=None,mpRunnerTerminalReceipt=None,inferenceFromExpectedExitConvention=False)
put(OUT,'actual-root-tool-completion-observation.json',observed)
terminal=dict(status='ROOT_CONTROLLER_ACTUAL_EXIT1_AFTER_ORIGINAL_MP_SETUP_AND_OUTER_REPORT_FAILURE',childReturnCode=observed['observedRootControllerExitCode'],childReturnCodeScope='Actual Root controller tool completion; NOT the missing MP supervisor or runner return',ownProcessesAbsent=True,problems=[dict(kind='original-mp-setup-and-incomplete-report',originalRootTraceback=partial['originalTraceback'])],timedOut=False,forcedKill=False,mpSupervisorChildReturnCode=None,mpRunnerChildReturnCode=None)
put(OUT,'results.json',dict(status='ROOT_QUALIFIED_VARIANT_BASELINE6_ONLY_AND_RETAINED_ACTUAL_MP_LOCAL_EVENT_SETUP_FAILURE',terminal=terminal,newOriginalRoots=list(map(str,rooms+[OUT])),baselineSixHostControlsQualified=True,actualBaselineTerminal=base['originalTerminal'],actualBaselineQualification=q,actualBaselineReport=report,actualBaselineCases=cases,actualBaselinePortRestoration=ports,actualMPOuterDrain=drains[1],actualMPObserverTerminal=None,actualMPRunnerReport=None,actualMPRestorationEmpty=True,actualRootToolCompletion=observed,originalRootBeforeAndTwoReadOnlyRepairPostsAll1138Literal=True,allExistingWholeRoomsTwiceEqual=True,absentMPThirdCensusRoomNotInvented=True,transactionEightUnrun=True,chatSinglePairUnrun=True,remainingTwoMPBodiesUnrun=True,sourceFreeze='15b852e58ba0ba7e046c2cc63975306d455147c4ce08bccfd3fea5b59c8ec229',variantHelperSha256='a7977c6b9399a94df0cd9e6b44729e76ce67cbb121998d787dc5b97f27d74f44',MPVariantQualification=None,helperQualified=False,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(OUT,'actual-receipt-references.json',refs);put(OUT,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in OUT.iterdir()}));print(json.dumps(dict(freeze=sha(OUT/'freeze.json'),results=sha(OUT/'results.json'),references=len(refs),newRoots=7)))
