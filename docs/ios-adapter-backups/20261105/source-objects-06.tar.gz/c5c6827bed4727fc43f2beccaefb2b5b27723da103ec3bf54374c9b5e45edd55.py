"""One new readonly historical entry; requires future reviewed prepared plan."""
from pathlib import Path
import builtins
import faulthandler
import importlib.abc
import importlib.machinery
import importlib.util
import io
import json
import os
import signal
import sys
import threading
import traceback
import unittest
from metadata import SOURCE, REPO, INPUT, CASE, FIXTURE, head, validate, sha, pin, census, load, fds, proc
from original_lock_port import OriginalLockPort

assert sys.dont_write_bytecode and Path.cwd() == REPO and len(sys.argv) == 6
expected_head, source_sha, plan_sha, plan_path, output = sys.argv[1:]
plan, operands = validate(Path(plan_path), plan_sha, source_sha, expected_head)
assert head() == expected_head
HERE = Path(output)
assert HERE.is_absolute() and HERE.resolve(strict=True) == HERE
assert HERE.parent == REPO / '.ios-host-tmp' and HERE.name.startswith('audio-normal4-retained-probe-')
assert HERE != SOURCE and not (HERE / 'temporary').exists()
assert census(INPUT) == load(plan['inputBaseline'])
old_meta, old_path = list(sys.meta_path), list(sys.path)
old_fds, old_threads = fds(), tuple(threading.enumerate())
identity = proc(os.getpid())
assert identity is not None and identity['group'] == identity['session'] == identity['pid']
refusals, loaded, cleanup = [], {}, []
case = result = selected_module = None
returned = False
failure = None
real_cleanup = unittest.TestCase.doCleanups
real_cleanup_code = real_cleanup.__code__


def save(name, body):
    path = HERE / name
    with path.open('x') as stream:
        json.dump(body, stream, sort_keys=True, indent=2)
        stream.write('\n')
    path.chmod(0o600)


save('preimport-proof.json', dict(status='ALL_APPROVED_SOURCE_PINS_AND869_INPUT_CHECKED',
    planSha256=plan_sha, sourceFreeze=source_sha, selected=CASE, inputEntries=869))
boundary_file = SOURCE / 'owned_write_boundary.py'
assert sha(boundary_file) == '156560033c0c292aa72be6cd66af136683de28490341dceacc191398b5167bda'
spec = importlib.util.spec_from_file_location('audio_retained_e458_boundary_controller', boundary_file)
boundary_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(boundary_module)
boundary = boundary_module.OwnedWrites(HERE, protected=[
    Path(os.readlink('/proc/self/fd/' + str(fd))).resolve(strict=True) for fd in (1, 2)])
original_io = (io.open, builtins.open)
original_ports = dict(boundary.original)
boundary.install()
lock_port = OriginalLockPort(INPUT / operands['lock'], operands['lockPin'], original_ports['open'])
lock_port.attach(boundary)
project_tops = {name.split('.')[0] for name in (*plan['modules'], *plan['namespacePackages'])}
forbidden = ('pymobiledevice3', 'tidevice', 'pyidevice', 'appium', 'zeroconf', 'selenium', 'playwright', 'PySide6', 'PyQt6')


def refuse(event, detail):
    refusals.append(dict(event=event, detail=detail))
    raise RuntimeError('AUDIO_RETAINED_READONLY_REFUSED_' + event)


def audit(event, args):
    if event == 'import':
        name = args[0]
        if any(name == prefix or name.startswith(prefix + '.') for prefix in forbidden):
            refuse(event, 'SDK/native/browser module')
    if event.startswith('socket.') or event.startswith('tempfile.'):
        refuse(event, 'No network or TD birth')
    if event == 'os.mkdir':
        refuse(event, 'No target directory birth, including manual TDs')
    if event == 'os.fchdir':
        refuse(event, 'No cwd descriptor mutation')
    if event in ('subprocess.Popen', 'os.system', 'os.exec', 'os.fork', 'os.forkpty',
            'os.posix_spawn', 'pty.spawn', 'ctypes.dlopen', 'os.kill', 'os.killpg',
            'os.setsid', 'os.setpgid', 'os.putenv', 'os.unsetenv') or event.startswith('os.spawn'):
        refuse(event, 'No subprocess/SDK/compiler/device/service action')
    if event in ('open', 'fcntl.flock'):
        if lock_port.audit(event, args, sys._getframe(1)):
            return
    if event in ('open', 'os.remove', 'os.rmdir', 'os.mkdir', 'os.chmod', 'os.chown',
            'os.utime', 'os.truncate', 'os.rename', 'os.link', 'os.symlink', 'os.setxattr',
            'os.removexattr', 'os.chdir', 'os.fchdir', 'os.chroot') or event.startswith('fcntl.'):
        boundary.audit(event, args, sys._getframe(1))


sys.addaudithook(audit)
monitoring = sys.monitoring
initial_tool_slots = [(monitoring.get_tool(n), monitoring.get_events(n)) for n in range(6)]
monitor_ports = tuple((name, getattr(monitoring, name)) for name in (
    'get_tool', 'use_tool_id', 'register_callback', 'set_local_events',
    'get_local_events', 'get_events', 'free_tool_id'))
tool = next((n for n in (5, 4, 3) if monitoring.get_tool(n) is None), None)
assert tool is not None and monitoring.get_events(tool) == 0
monitoring.use_tool_id(tool, 'audio-retained-definition-only-native-refusal')
native_codes, native_entries = [], []


def native_entry(code, offset):
    native_entries.append(dict(name=code.co_qualname, path=code.co_filename, offset=offset))
    refuse('native-definition-entry', code.co_qualname)


monitoring.register_callback(tool, monitoring.events.PY_START, native_entry)


class Loader(importlib.abc.Loader):
    def __init__(self, name, row):
        self.name, self.row = name, row
    def create_module(self, spec):
        return None
    def exec_module(self, module):
        path = Path(self.row['path'])
        assert pin(path) == plan['physicalPins'][str(path)]
        raw = path.read_bytes()
        assert sha(path) == self.row['sha256']
        module.__file__ = str(path)
        if self.row['package']:
            module.__path__ = [str(path.parent)]
        loaded[self.name] = self.row
        exec(compile(raw, str(path), 'exec'), module.__dict__)
        assert pin(path) == plan['physicalPins'][str(path)]
        if self.name in ('adapters.native_clock_join', 'adapters.native_feature_observation'):
            cls = module.NativeClockAcquisition if self.name.endswith('native_clock_join') else module.NativeFeatureObservation
            for member in cls.__dict__.values():
                function = member.__func__ if type(member) in (classmethod, staticmethod) else member
                if hasattr(function, '__code__'):
                    native_codes.append(function.__code__)
                    monitoring.set_local_events(tool, function.__code__, monitoring.events.PY_START)


class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        row = plan['modules'].get(fullname)
        if row is not None:
            return importlib.util.spec_from_loader(fullname, Loader(fullname, row), is_package=row['package'])
        roots = plan['namespacePackages'].get(fullname)
        if roots is not None:
            spec = importlib.machinery.ModuleSpec(fullname, None, is_package=True)
            spec.submodule_search_locations = roots
            return spec
        if fullname.split('.')[0] in project_tops:
            raise ImportError('Project import absent from exact origin map: ' + fullname)
        return None


assert not any(name.split('.')[0] in project_tops for name in sys.modules)
sys.meta_path.insert(0, Finder())
trace = (HERE / 'term-stack.log').open('x')
def interrupted(_signum, _frame):
    faulthandler.dump_traceback(file=trace, all_threads=True)
    trace.flush()
    raise KeyboardInterrupt('Fixed new readonly60+5 boundary; no Normal4 retry')
prior_term = signal.signal(signal.SIGTERM, interrupted)


class Result(unittest.TextTestResult):
    def stopTest(self, value):
        cleanup.append(dict(id=value.id(), pendingCleanups=len(value._cleanups)))
        super().stopTest(value)


try:
    import fcntl
    from adapters.script_feature import lock as actual_lock
    lock_port.bind(actual_lock, fcntl)
    module_name, class_name, method_name = CASE.rsplit('.', 2)
    selected_module = __import__(module_name, fromlist=[class_name])
    kind = vars(selected_module)[class_name]
    assert method_name in kind.__dict__
    suite = unittest.defaultTestLoader.loadTestsFromName(class_name + '.' + method_name, selected_module)
    assert suite.countTestCases() == 1
    def flatten(value):
        if isinstance(value, unittest.TestSuite):
            for part in value:
                yield from flatten(part)
        else:
            yield value
    cases = list(flatten(suite))
    assert len(cases) == 1 and type(cases[0]) is kind
    case = cases[0]
    assert case.id() == CASE
    result = unittest.TextTestRunner(verbosity=2, failfast=True, resultclass=Result).run(suite)
    returned = True
except BaseException:
    failure = traceback.format_exc()
finally:
    # Preserve genuine unittest cleanup on interruption; this probe has no
    # fixture TD or borrowed cleanup implementation.
    assert unittest.TestCase.doCleanups is real_cleanup and real_cleanup.__code__ is real_cleanup_code
    if case is not None and case._cleanups:
        assert real_cleanup(case)
    signal.signal(signal.SIGTERM, prior_term)
    trace.close()
    for code in native_codes:
        monitoring.set_local_events(tool, code, 0)
    monitoring.register_callback(tool, monitoring.events.PY_START, None)
    assert all(monitoring.get_local_events(tool, code) == 0 for code in native_codes)
    assert monitoring.get_events(tool) == 0
    monitoring.free_tool_id(tool)
    monitor_restored = monitoring.get_tool(tool) is None and all(getattr(monitoring, name) is value for name, value in monitor_ports)
    monitor_restored = monitor_restored and initial_tool_slots == [(monitoring.get_tool(n), monitoring.get_events(n)) for n in range(6)]
    sys.meta_path[:] = old_meta
    sys.path[:] = old_path
    first, second = census(INPUT), census(INPUT)
    all_pins = all(pin(path) == row for path, row in plan['physicalPins'].items())
    measured = {} if selected_module is None else selected_module.MEASURED
    phases = [] if selected_module is None else selected_module.CLOSED_PHASES
    lease = '8eb395de1aefbac3fa8c68fb47eef9e4'
    model_complete = lease in measured and len(measured[lease]['phases']) == 3
    model_complete = model_complete and all(row['collectionEntered'] and row['profileStarted']
        and row['operationReturned'] and type(row['elapsedHostPerfNsWithProfiler']) is int
        for row in measured[lease]['phases'])
    lock_released = lock_port.released() if lock_port.opens else False
    passed = returned and result is not None and result.wasSuccessful() and result.testsRun == 1 and not result.skipped
    passed = passed and cleanup == [dict(id=CASE, pendingCleanups=0)]
    passed = passed and not failure and not refusals and not native_entries and monitor_restored and model_complete
    passed = passed and first == second == load(plan['inputBaseline']) and all_pins and lock_released
    passed = passed and fds() == old_fds and tuple(threading.enumerate()) == old_threads
    passed = passed and proc(os.getpid()) == identity and sys.meta_path == old_meta and sys.path == old_path
    passed = passed and head() == expected_head
    passed = passed and sys.getprofile() is None and sys.gettrace() is None
    save('child-input-first.json', first)
    save('child-input-second.json', second)
    save('child-result.json', dict(status='PASS' if passed else 'FAIL_OR_REFUSED',
        suiteReturned=returned, testsRun=0 if result is None else result.testsRun,
        selected=CASE, failure=failure, refusals=refusals, cleanup=cleanup,
        measured=measured, closedPhases=phases, originalLockReleased=lock_released,
        originalHeldOpens=lock_port.opens, originalHeldFlocks=lock_port.flocks,
        nativeDefinitionEntries=native_entries, monitorRestored=monitor_restored,
        importedOrigins=loaded, allPhysicalPinsUnchanged=all_pins,
        twoComplete869InputCensusesUnchanged=first == second == load(plan['inputBaseline']),
        actualFDThreadDrain=fds() == old_fds and tuple(threading.enumerate()) == old_threads,
        nativeQualified=False, normalFourthActionQualified=False, wholeQualified=False))
    boundary.restore()
    restored = all(getattr(os, name) is value for name, value in original_ports.items())
    restored = restored and (io.open, builtins.open) == original_io and not boundary.control_fds
    save('write-port-restoration.json', dict(restored=restored, actualCportCount=len(original_ports)))
    boundary.close()
sys.exit(0 if passed and restored else 1)
