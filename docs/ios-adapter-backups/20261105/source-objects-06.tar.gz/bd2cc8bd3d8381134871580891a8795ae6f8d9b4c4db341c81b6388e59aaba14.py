"""Actual original setUp return and comparison-factory closure custody.

No monitoring hook, frame fabrication, comparison oracle or current authority
cache is introduced. Mutable schema registries may grow through the actual
compiler; each already-retained tuple and port cell keeps its original identity.
"""
import builtins,sys,types,unittest


class ExpectedComparisonCustody:
    def __init__(self,module,case_class):
        self.module,self.case_class=module,case_class
        self.builtins=builtins;self.builtin_ports=tuple((name,getattr(builtins,name))for name in('type','tuple','list','len','int','str'))
        self.factory=module._make_expected_comparison
        self.factory_code=self.factory.__code__;self.factory_globals=self.factory.__globals__
        assert self.factory_globals is vars(module)
        self.codes={code.co_name:code for code in self.factory_code.co_consts if type(code)is types.CodeType}
        assert set(self.codes)=={'<lambda>','identity_roster','compile_expected','compare','add_dependency','dependency_plan'}
        self.ports=dict(actual_type=type,actual_tuple=tuple,actual_list=list,actual_len=len,actual_int=int,actual_str=str,
            actual_function=types.FunctionType,actual_code=types.CodeType)
        self.module_functions=tuple(getattr(module,name)for name in('_compile_expected','_compare_expected','_add_dependency_comparison','_dependency_comparison'))
        self.module_names=('_compile_expected','_compare_expected','_add_dependency_comparison','_dependency_comparison')
        self.module_seals=self.family(self.module_functions)
        self.setup=case_class.__dict__['setUp'];self.setup_code=self.setup.__code__;self.setup_globals=self.setup.__globals__
        self.original=unittest.TestCase._callSetUp;self.original_code=self.original.__code__;self.original_globals=self.original.__globals__
        self.bound=[];self.installed=False;self.wrapper=None;self.wrapper_code=None;self.wrapper_closure=None;self.wrapper_cells=None
        self.implementation=tuple((name,fn,fn.__code__,fn.__globals__)for name,fn in type(self).__dict__.items()if type(fn)is types.FunctionType)
    def function(self,function):
        assert type(function)is types.FunctionType and function.__globals__ is self.factory_globals
        assert function.__code__ is self.codes[function.__code__.co_name]
        defaults=function.__defaults__;keywords=function.__kwdefaults__;closure=function.__closure__
        cells=tuple((name,cell,cell.cell_contents)for name,cell in zip(function.__code__.co_freevars,closure or()))
        return(function,function.__code__,defaults,tuple(defaults or()),keywords,tuple((keywords or{}).items()),closure,cells)
    def family(self,functions):
        assert len(functions)==4
        assert tuple(fn.__code__.co_name for fn in functions)==('compile_expected','compare','add_dependency','dependency_plan')
        all_functions=list(functions)
        for fn in functions:
            for cell in fn.__closure__ or():
                value=cell.cell_contents
                if type(value)is types.FunctionType and not any(value is held for held in all_functions):all_functions.append(value)
        assert {fn.__code__.co_name for fn in all_functions}=={'compile_expected','compare','add_dependency','dependency_plan','identity_roster'}
        seals=tuple(self.function(fn)for fn in all_functions)
        self.check_family(seals)
        return seals
    def check_family(self,seals):
        for fn,code,defaults,values,keywords,items,closure,cells in seals:
            assert fn.__code__ is code and fn.__globals__ is self.factory_globals and sys.modules.get(self.factory_globals['__name__'])is self.module
            assert fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
            assert len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values))
            assert tuple(keywords or())==tuple(k for k,v in items)and all(keywords[k]is v for k,v in items)
            assert len(closure or())==len(cells)
            for name,cell,value in cells:
                assert cell.cell_contents is value
                if name in self.ports:assert value is self.ports[name]
                elif name in('identity_roster','compile_expected'):assert any(value is held[0]for held in seals)
                elif name=='rosters':self.rosters(value)
                elif name=='dependency_plans':
                    assert type(value)is list
                    for plan in value:self.plan(plan)
                else:raise AssertionError('Undeclared comparison closure cell: '+name)
    def roster(self,value):
        assert type(value)is tuple
        for row in value:
            assert type(row)is tuple and len(row)==3 and type(row[0])is type and type(row[1])is str
            target=row[2];assert type(target)is tuple and len(target)==3
            assert type(target[0])is types.FunctionType and type(target[1])is types.CodeType and type(target[2])is int
    def rosters(self,value):
        assert type(value)is dict
        for cls,bucket in value.items():
            assert type(cls)is type and type(bucket)is list
            for row in bucket:self.roster(row)
    def plan(self,plan):
        assert type(plan)is tuple and len(plan)==2 and type(plan[1])is tuple
        # Unknown expected shapes are explicitly legal literal-only plans.
        if type(plan[0])is not tuple:assert plan[1]==();return
        for row in plan[1]:
            assert type(row)is tuple and len(row)==3
            index,expected,canonical=row
            assert type(index)is int and 0<=index<len(plan[0])and expected is plan[0][index]
            assert type(expected)is tuple and len(expected)==3 and type(expected[0])is str and type(expected[1])is type
            self.roster(expected[2]);self.roster(canonical)
    def tuple_cells(self,values):
        # Capture only existing exact tuples; do not traverse mutable primitive
        # payloads or call user equality/getters. Strong references prevent reuse.
        rows=[]
        def visit(value):
            if type(value)is not tuple or any(value is held[0]for held in rows):return
            rows.append((value,tuple(list(value))))
            for item in value:visit(item)
        for value in values:visit(value)
        return tuple(rows)
    def bind(self,case):
        assert type(case)is self.case_class and not any(row['case']is case for row in self.bound)
        functions=tuple(vars(case)[name]for name in('compile','compare','add_dependency','dependency_plan'))
        seals=self.family(functions);expected=vars(case)['expected'];plan=vars(case)['plan']
        assert type(expected)is tuple and plan[0]is expected
        self.plan(plan)
        row=dict(case=case,functions=functions,seals=seals,expected=expected,plan=plan,tuples=self.tuple_cells((expected,plan)))
        self.bound.append(row);self.check_case(case)
    def check_case(self,case):
        found=[row for row in self.bound if row['case']is case];assert len(found)==1
        row=found[0];assert type(case)is self.case_class
        assert all(vars(case)[name]is fn for name,fn in zip(('compile','compare','add_dependency','dependency_plan'),row['functions']))
        assert vars(case)['expected']is row['expected']and vars(case)['plan']is row['plan']
        self.check_family(row['seals']);self.plan(row['plan'])
        for value,items in row['tuples']:assert len(value)==len(items)and all(a is b for a,b in zip(value,items))
        return True
    def check(self):
        assert sys.modules['builtins']is self.builtins and all(getattr(builtins,name)is port for name,port in self.builtin_ports)
        for name,fn,code,namespace in self.implementation:assert type(self).__dict__[name]is fn and fn.__code__ is code and fn.__globals__ is namespace is globals()
        assert self.module._make_expected_comparison is self.factory and self.factory.__code__ is self.factory_code and self.factory.__globals__ is self.factory_globals
        assert self.case_class.__dict__['setUp']is self.setup and self.setup.__code__ is self.setup_code and self.setup.__globals__ is self.setup_globals
        assert self.original.__code__ is self.original_code and self.original.__globals__ is self.original_globals is vars(sys.modules['unittest.case'])
        assert all(getattr(self.module,name)is fn for name,fn in zip(self.module_names,self.module_functions));self.check_family(self.module_seals)
        if self.installed:
            assert unittest.TestCase._callSetUp is self.wrapper and self.wrapper.__code__ is self.wrapper_code and self.wrapper.__closure__ is self.wrapper_closure and self.wrapper.__globals__ is globals()
            assert all(cell.cell_contents is value for cell,value in zip(self.wrapper_closure,self.wrapper_cells))
        else:assert unittest.TestCase._callSetUp is self.original
        return True
    def install(self):
        self.check();assert not self.installed
        def call_setup(case):
            self.check();assert type(case)is self.case_class and getattr(type(case),'setUp')is self.setup
            returned=self.original(case) # actual original setUp invoked exactly once
            self.bind(case);return returned
        self.wrapper=call_setup;self.wrapper_code=call_setup.__code__;self.wrapper_closure=call_setup.__closure__;self.wrapper_cells=tuple(c.cell_contents for c in call_setup.__closure__)
        unittest.TestCase._callSetUp=call_setup;self.installed=True;self.check()
    def restore(self):
        self.check();unittest.TestCase._callSetUp=self.original;self.installed=False;self.check()
        return dict(originalCallSetUpRestored=unittest.TestCase._callSetUp is self.original,actualBoundCases=len(self.bound),originalSetupCalledByOriginalCallSetUp=True)
