"""One synchronous Lifecycle publication's immutable historical subgraphs.

Every current PFS, namespace inventory, live callback, phase transport and WAL
transition still runs. Only successfully decoded immutable historical files
may reuse their typed value between real inode/signature/read-membership checks.
No memo survives this actual publication or contains a new native acquisition.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from importlib import import_module
from pathlib import Path
from types import MethodType,ModuleType
import sys
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import readonly
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import canonical,same
from ios.adapters.avatar_record_cache import AvatarRecordCache
from ios.adapters import emote_callback_live_records as tokens

PROFILE='ios-lifecycle-publication-original-read-phase-v1'
PARSER_MODULES=tuple(sorted(set(tokens.PARSER_MODULES)|{
    'adapters.pending_commit_owner','adapters.prepared_field_commit',
    'ios.adapters.keyboard_source','ios.adapters.lifecycle_actor_history',
    'ios.adapters.lifecycle_checkpoint_index','ios.adapters.lifecycle_current',
    'ios.adapters.lifecycle_current_archive','ios.adapters.lifecycle_current_stream',
    'ios.adapters.lifecycle_current_transport','ios.adapters.lifecycle_fields',
    'ios.adapters.lifecycle_observer','ios.adapters.lifecycle_originals',
    'ios.adapters.lifecycle_publication_read_phase','ios.adapters.lifecycle_touch',
    'ios.adapters.lifecycle_world'}))
_ACTIVE=ContextVar('ios_lifecycle_publication_original_read_phase',default=None)


class ParserPolicy:
    """Reuse the reviewed closed tokenizer, never an Emote cache/profile.

    Every original member must retain its full callable/code/data token. New
    namespace members select literal reads; they cannot conceal mutation of an
    original member. Unsupported initial policies always use literal readers.
    """
    def __init__(self):
        loaded=tuple(import_module(name)for name in PARSER_MODULES)
        files={module.__file__ for module in loaded}|{tokens.__file__}
        self.files=files
        self.modules=tuple((name,module)for name,module in sorted(sys.modules.items())
            if type(module)is ModuleType and vars(module).get('__file__')in files)
        self.references=[];self.members=None;self.external=None
        try:
            self.members=tuple((name,module,tuple((key,tokens._token(value,self.references,set()))
                for key,value in sorted(vars(module).items())if not key.startswith('__')))for name,module in self.modules)
            self.external=tuple((container,key,tokens._token(getattr(container,key),self.references,set()))
                for container,key in tokens.EXTERNAL_READERS)
        except(tokens._Unsupported,AttributeError,TypeError,ValueError,RecursionError):
            self.members=self.external=None

    def admitted(self):
        if self.members is None:return False
        complete=True;references=[]
        aliases=tuple((name,module)for name,module in sorted(sys.modules.items())
            if type(module)is ModuleType and vars(module).get('__file__')in self.files)
        if any(sys.modules.get(name)is not module for name,module in self.modules):raise RuntimeError('Lifecycle historical parser alias changed')
        complete=aliases==self.modules
        try:
            for name,module,members in self.members:
                if sys.modules.get(name)is not module:raise RuntimeError('Lifecycle historical parser module changed')
                current=vars(module);names={key for key in current if not key.startswith('__')}
                if not {key for key,_value in members}<=names:raise RuntimeError('Lifecycle historical parser member disappeared')
                complete=complete and names=={key for key,_value in members}
                for key,expected in members:
                    if tokens._token(current[key],references,set())!=expected:raise RuntimeError('Lifecycle historical parser receiver/code/data changed')
            for container,key,expected in self.external:
                if tokens._token(getattr(container,key),references,set())!=expected:raise RuntimeError('Lifecycle historical external parser changed')
        except(tokens._Unsupported,AttributeError,TypeError,ValueError,RecursionError)as error:
            raise RuntimeError('Lifecycle original historical parser policy changed')from error
        return complete


class LifecyclePublicationReadPhase:
    def __init__(self,owner):
        from ios.adapters.lifecycle_observer import LifecycleObserver
        need(type(owner)is LifecycleObserver and owner.live is True and owner.role=='actor')
        owner.bound();self.owner=owner;self.policy=owner._publication_parser_policy
        need(type(self.policy)is ParserPolicy);self.cache=AvatarRecordCache()
        self.retained=(owner.stream,owner.history,owner.files,owner.index,owner.phase,owner.lock,owner.store)
        self.header=canonical(self.context());self.stats=dict(cold=0,hits=0,literal=0)
        self.metadata=tuple((store,deepcopy(previous))for store,previous in(
            (owner.store,owner.previous),(owner.stream.store,owner.stream.previous),(owner.history.store,owner.history.previous)))
        self.phase_receivers=tuple((obj,key,getattr(obj,key),getattr(getattr(obj,key),'__func__',getattr(obj,key)),
            getattr(getattr(getattr(obj,key),'__func__',getattr(obj,key)),'__code__',None))
            for obj,key in((owner.phase,'read'),(owner.phase,'status'),(owner.phase.client,'request')))
        self.guard()

    def context(self):
        o=self.owner
        return dict(profile=PROFILE,root=str(o.root),binding=o.binding,runId=o.run,role=o.role,
            observerStore=str(o.store.path),streamStore=str(o.stream.store.path),historyStore=str(o.history.store.path),
            sourceLock=str(o.lock.path),fixtureUrl=o.phase.fixture_url,phaseInstance=o.phase_instance)

    def guard(self):
        o=self.owner;o.lock.assert_held();o.index.guard()
        need(all(a is b for a,b in zip(self.retained,(o.stream,o.history,o.files,o.index,o.phase,o.lock,o.store))))
        need(o._publication_parser_policy is self.policy)
        need(canonical(self.context())==self.header)
        for store,previous in self.metadata:need(same(store.read(),previous))
        o.inventory() # Never memoize orphan/pending membership.
        for obj,key,_bound,function,code in self.phase_receivers:
            now=getattr(obj,key);current=getattr(now,'__func__',now)
            need(current is function and getattr(current,'__code__',None)is code)
            if type(now)is MethodType:need(now.__self__ is obj)
        return True

    def admits(self,files):
        from ios.adapters.lifecycle_current_archive import LifecycleCurrentArchive
        o=self.owner
        return (type(files)is OriginalFrameStore and files.root==o.root and files.binding==o.binding
            and files.run==o.run and files.role==o.role and files.namespace=='lifecycle-current-returned'
            and files.schema_prefix=='iosLifecycleCurrentReturned'and files.kind=='sources'
            and type(files.guard)is MethodType and type(files.guard.__self__)is LifecycleCurrentArchive
            and files.guard.__func__ is LifecycleCurrentArchive.bound)

    def read(self,key,decode,guard):
        self.guard();guard()
        if not self.policy.admitted()or len(self.cache.rows)>=512 and canonical(key)not in self.cache.rows:
            self.stats['literal']+=1;result=decode();self.guard();guard();return result
        encoded=canonical(key);cold=encoded not in self.cache.rows
        def actual():
            self.guard();guard();self.policy.admitted()
            # This read-only area ends before every publisher CAS/intent/POST.
            with readonly():value=decode()
            self.guard();guard();need(self.policy.admitted());return value
        result=self.cache.read(key,actual)
        self.guard();guard();need(self.policy.admitted())
        self.stats['cold'if cold else'hits']+=1;return result


@contextmanager
def publication_scope(owner):
    need(_ACTIVE.get()is None) # Each actual synchronous publication owns its memo.
    phase=LifecyclePublicationReadPhase(owner);token=_ACTIVE.set(phase)
    try:yield phase
    finally:
        try:phase.guard();phase.policy.admitted()
        finally:_ACTIVE.reset(token)


def historical_record(archive,reference):
    phase=_ACTIVE.get()
    if phase is None or not phase.admits(archive.files):return archive._record_body(reference)
    key=dict(profile=PROFILE,kind='returned-current-record',root=str(archive.root),binding=archive.binding,
        runId=archive.run,role=archive.role,snapshot=archive.snapshot,reference=reference)
    return phase.read(key,lambda:archive._record_body(reference),archive.bound)


def historical_manifest(files,reference):
    phase=_ACTIVE.get()
    if phase is None or not phase.admits(files):return files.manifest(reference)
    key=dict(profile=PROFILE,kind='returned-current-index',root=str(files.root),binding=files.binding,
        runId=files.run,role=files.role,namespace=files.namespace,reference=reference)
    return phase.read(key,lambda:files.manifest(reference),files.guard)


def historical_prefix(files,path,body):
    phase=_ACTIVE.get()
    def actual():return same(PrivateFeatureState(path).read(),body)
    if phase is None or not phase.admits(files):return actual()
    need(Path(path).parent==files.root)
    key=dict(profile=PROFILE,kind='returned-current-index-prefix',path=str(path),body=body)
    return phase.read(key,actual,files.guard)
