"use strict";
(function () {
    var companion = Script.require("./companion.js");
    var page = "http://127.0.0.1:39041/feature-fixture/v1/runs/2785bf7315b513d21a70abf15880a853/tickets/7ac5db6050ef4f98b1cff9cfde1977b7/reference.html", injected = "http://127.0.0.1:39041/feature-fixture/v1/runs/2785bf7315b513d21a70abf15880a853/tickets/7ac5db6050ef4f98b1cff9cfde1977b7/injected.js", entity = null, stopped = false, call = 0;
    var observer = typeof Test !== "undefined" && typeof Test.featureIOSWorldWebEvent === "function" ? Test : null;
    function event(kind, sequence, payload) {
        if (observer) observer.featureIOSWorldWebEvent({worldWebWorkEventVersion:1,runId:"2785bf7315b513d21a70abf15880a853",nonce:"962a1ba1a5c61563e37ed595d074925a",event:kind,call:sequence,payload:payload});
    }
    function tracked(kind, payload, closure) {
        if (!observer) return closure();
        var sequence = ++call;
        event(kind + "-enter", sequence, payload);
        try { var result = closure(); event(kind + "-return", sequence, payload); return result; }
        finally { event(kind + "-finally", sequence, payload); }
    }
    function respond(message, surface, send) {
        var packet;
        if (typeof message !== "string" || message.length > 4096) return;
        try { packet = JSON.parse(message); } catch (_) { return; }
        if (!packet || packet.contract !== "overte-web-parity-v1" || packet.action !== "echo" ||
                typeof packet.sequence !== "number" || !isFinite(packet.sequence) ||
                packet.sequence < 1 || packet.sequence > 1000000 || Math.floor(packet.sequence) !== packet.sequence) return;
        send(JSON.stringify({contract: packet.contract, action: "echo", sequence: packet.sequence, surface: surface}));
    }

    function worldEvent(id, message) {
        if (!stopped && entity && String(id) === String(entity)) {
            return tracked("world-event", {entityId:String(id),message:message}, function () {
                return respond(message, "world", function (reply) {
                    return tracked("script-reply", {entityId:String(entity),message:reply}, function () {
                        return Entities.emitScriptEvent(entity, reply);
                    });
                });
            });
        }
    }
    entity = Entities.addEntity({type:"Web",name:"e2e-2785bf7315b513d21a70abf15880a853-script",userData:"{\"kind\":\"emote-marker-v1\",\"nonce\":\"962a1ba1a5c61563e37ed595d074925a\",\"runId\":\"2785bf7315b513d21a70abf15880a853\"}",sourceUrl:page,scriptURL:injected,
        position:Vec3.sum(Camera.position,Vec3.multiplyQbyV(Camera.orientation,{x:0,y:0,z:-1.5})),rotation:Camera.orientation,
        dimensions:{x:1.8,y:1.4,z:0.01},dpi:12,maxFPS:30,grab:{grabbable:false},visible:true,collisionless:true},"local");
    Entities.webEventReceived.connect(worldEvent);
    event("loaded", 0, {entityId:entity ? String(entity) : null});
    Script.scriptEnding.connect(function () {
        return tracked("ending", {entityId:entity ? String(entity) : null}, function () {
            stopped = true;
            Entities.webEventReceived.disconnect(worldEvent);
            if (entity) Entities.deleteEntity(entity);
        });
    });
}());
