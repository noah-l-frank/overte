"""Actual source methods + real TouchLease; SDK/HID/source facts explicit DI."""
from __future__ import annotations
from source_model_bindings import execute_original
import ast,asyncio,hashlib,inspect,json,os,re,time,unittest,uuid,weakref
from contextlib import asynccontextmanager
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch

class OriginalOwnerLifetimeModels(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        raw=Path(os.environ['LIFECYCLE_LIFETIME_MAP']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_LIFETIME_MAP_SHA256']:raise RuntimeError('Root source map required')
        self.mapping=json.loads(raw)
        for row in self.mapping.values():
            if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('Source changed')
        from ios.self_tests import test_ios_touch_lease as fixture
        from ios.adapters import touch_lease,lifecycle_touch_transport
        for role,module in [('fixture',fixture),('lease',touch_lease),('retained',lifecycle_touch_transport)]:
            self.assertEqual(Path(module.__file__).resolve(),Path(self.mapping[role]['path']))
        self.fixture=fixture;self.f=fixture.TouchLeaseTests();self.f.setUp()
        for fn,args,kwargs in self.f._cleanups:self.addCleanup(fn,*args,**kwargs)
        self.f._cleanups.clear()
        tree=ast.parse(Path(self.mapping['keeper']['path']).read_bytes());names=('LaunchError','OriginalKeeperSource','OriginalKeeperOperations')
        nodes=[next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FAILURE_PHASES' for t in n.targets))]
        nodes += [next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name) for name in names]
        ns=dict(asyncio=asyncio,asynccontextmanager=asynccontextmanager,inspect=inspect,weakref=weakref,uuid=uuid,re=re,time=time,deepcopy=deepcopy)
        execute_original(ast.Module(body=nodes,type_ignores=[]),ns,self.mapping['keeper']['path'],self.mapping['keeper']['sha256'],'test_original_owner_lifetime_models')
        self.Source,self.Ops=ns['OriginalKeeperSource'],ns['OriginalKeeperOperations'];self.sources=[];self.contexts=[self.f.context];self.workers=[];self.tasks=[];self.gates=[];self.tunnels=[]
        self.source=self.new_source();self.ops=self.Ops(self.source,self.f.store.path.parent)
        self.ops.session={'sessionId':self.f.binding['sessionId'],'archiveBundleId':'org.example.overte','wdaBundleId':'org.example.wda'}
    def new_source(self):
        class Cap:
            valid=True
            def __init__(cap):cap.rsd=object()
            def current(cap):
                if not cap.valid:raise RuntimeError('Modeled original SDK source revoked')
                return cap.rsd,'fd00::1'
            def udp_socket(cap):raise AssertionError('No real SDK socket in model')
        class Tunnel:
            def __init__(t,cap):t.cap=cap
            def original_source(t):return t.cap
        cap=Cap();tunnel=Tunnel(cap);self.tunnels.append(tunnel)
        owner=self.Source.__new__(self.Source);owner._tunnel=weakref.ref(tunnel);owner._source=cap;owner._loop=asyncio.get_running_loop();owner._leases=[];owner._born=[];owner._closing=False
        self.sources.append(owner);return owner
    async def start(self,*,context=None,store=None,seconds=2):
        context=context or self.f.context;store=store or self.f.store
        with patch('ios.adapters.hid_session.touch_session',side_effect=lambda *_a,**_k:context):
            lease=self.source.touch_lease(store,binding=self.f.binding,run=self.f.run_id,check=lambda:True);self.ops.touch=lease;self.f.owner=lease
            task=asyncio.create_task(lease.begin(100,50,25,10,seconds=seconds));self.tasks.append(task)
            await context.down_started.wait();self.workers.append(lease.worker)
            if context.down_gate.is_set():await task
        return lease
    async def asyncTearDown(self):
        for event in self.gates:event.set()
        for context in self.contexts:context.enter_gate.set();context.down_gate.set();context.drain_gate.set()
        for source in self.sources:
            for row in source._born:row['release'].set()
        if self.tasks:await asyncio.gather(*self.tasks,return_exceptions=True)
        for worker in self.workers:
            if not worker.done():await asyncio.wait_for(asyncio.shield(worker),2)
        await self.f.asyncTearDown()
    async def test_original_release_after_source_loss_sends_once_up_and_repeated_inspection(self):
        lease=await self.start();intent=deepcopy(lease.previous);self.source._source.valid=False
        first=await self.ops.execute('touch-release',{},self.f.binding['sessionId'])
        second=await self.ops.execute('touch-release',{},self.f.binding['sessionId'])
        inspected=await self.ops.execute('touch-inspect',{},self.f.binding['sessionId'])
        self.assertEqual([0xC2,0x02],[r[0] for r in self.f.context.events]);self.assertEqual(1,self.f.context.exited)
        self.assertFalse(first['nativeTouchSupport']);self.assertFalse(second['resourceRetirementEstablished']);self.assertFalse(inspected['inspection']['workerRunning'])
        self.assertEqual({k:v for k,v in intent.items() if k not in ('phase','failure')},{k:v for k,v in lease.previous.items() if k not in ('phase','failure')})
    async def test_pending_original_down_is_retained_until_original_up_and_drain(self):
        self.f.context.down_gate.clear();lease=await self.start();self.source._source.valid=False
        releasing=asyncio.create_task(self.ops.execute('touch-settle',{},self.f.binding['sessionId']));self.tasks.append(releasing)
        await asyncio.sleep(0);await lease.request_release.wait()
        self.assertTrue(self.source._closing);self.assertFalse(releasing.done());self.assertFalse(lease.worker.done());self.assertFalse(lease.worker.cancelled())
        self.assertEqual([0xC2],[r[0] for r in self.f.context.events]);self.f.context.down_gate.set();await releasing
        self.assertEqual([0xC2,0x02],[r[0] for r in self.f.context.events]);self.assertEqual(1,self.f.context.exited)
    async def test_wrong_session_and_changed_retained_worker_cannot_supply_a_success(self):
        with self.assertRaises(RuntimeError):await self.ops.execute('touch-release',{},'foreign-session')
        lease=await self.start();original=lease.worker;foreign=asyncio.create_task(asyncio.sleep(0));await foreign
        lease.worker=foreign
        try:
            with self.assertRaises(Exception):await self.ops.execute('touch-inspect',{},self.f.binding['sessionId'])
        finally:lease.worker=original
        await self.ops.execute('touch-release',{},self.f.binding['sessionId']);self.assertEqual([0xC2,0x02],[r[0] for r in self.f.context.events])
    async def test_owner_drain_waits_original_forward_task_and_closes_new_admission(self):
        gate=asyncio.Event();self.gates.append(gate);forward=asyncio.create_task(gate.wait());self.tasks.append(forward)
        self.ops.issued['forward']={'request':{'operation':'process-read'},'task':forward,'original':None}
        draining=asyncio.create_task(self.ops.execute('owner-drain',{},None));self.tasks.append(draining);await asyncio.sleep(0)
        self.assertTrue(self.ops.draining);self.assertTrue(self.source._closing);self.assertFalse(draining.done())
        with self.assertRaises(RuntimeError):self.source.touch_lease(self.f.store,binding=self.f.binding,run=self.f.run_id,check=lambda:True)
        with self.assertRaises(RuntimeError):await self.ops.execute('process-read',{},self.f.binding['sessionId'])
        gate.set();result=await draining;self.assertTrue(result['originalOperationsSettled']);self.assertTrue(result['originalTouchWorkersSettled']);self.assertFalse(result['resourceRetirementEstablished'])
    async def test_done_original_worker_with_up_or_drain_failure_never_mints_drain_receipt(self):
        from adapters.normal_feature_state import PrivateFeatureState
        for failure in ('up','drain'):
            with self.subTest(failure=failure):
                self.source=self.new_source();self.ops=self.Ops(self.source,self.f.store.path.parent);self.ops.session={'sessionId':self.f.binding['sessionId']}
                store=PrivateFeatureState(self.f.store.path.with_name('failed-'+failure+'.json'));context=self.fixture.Context(store);self.contexts.append(context);self.addCleanup(context.close)
                setattr(context,failure+'_error',True);lease=await self.start(context=context,store=store)
                lease.request_release.set();await lease.worker;self.assertTrue(lease.worker.done());self.assertFalse(lease.closed)
                with self.assertRaises(RuntimeError):await self.ops.execute('owner-drain',{},None)
                self.assertEqual([0xC2,0x02],[r[0] for r in context.events]);self.assertIn(lease.failure,('up','drain'))
