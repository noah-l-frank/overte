"""Action/subject-owned actual AssetServer exports for current checkpoints.

The existing strict segmented backend codec and original endpoint are reused.
A separate explicit namespace retains every sample/prefix. No Upload, baseline,
permission input, server mutation or restoration verdict is manufactured.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json,os
from adapters.asset_backend_client import AssetsBackendClient,configuration,export as decode_export
from adapters import asset_backend_source as source
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same,pack,unpack,canonical
from ios.adapters.assets_action_phase import AssetsActionScope
from ios.adapters.assets_backend_owner import OwnedAssetsBackend,BackendSegments,public_configuration,MAX_SAMPLES
from ios.adapters.assets_budget import operation
from ios.adapters.assets_checkpoint_context import checkpoint_descriptor


class CheckpointBackendParts(BackendSegments):
    def __init__(self,*args,index,**kwargs):
        need(integer(index,1,29));super().__init__(*args,**kwargs)
        root,binding,run,role,_subject,guard,_intent=args
        # BackendSegments construction performs no source acquisition/write.
        # The unchanged bounded parent/body codec gets an explicit new frame
        # namespace before a reference or original can be constructed.
        self.store=OriginalFrameStore(root,binding,run,role,guard,self.transition,
            namespace='assets-cp-a'+str(index)+'-'+role+'-backend',
            schema_prefix='iosAssetsCheckpointBackendPart',monotonic=kwargs['monotonic'])


class AssetsCheckpointBackend:
    tag=OwnedAssetsBackend.tag
    config_for_decode=OwnedAssetsBackend.config_for_decode
    raw=OwnedAssetsBackend.raw
    packet=OwnedAssetsBackend.packet
    parts_intent=OwnedAssetsBackend.parts_intent
    acquire=OwnedAssetsBackend.acquire
    sample=OwnedAssetsBackend.sample
    recover=OwnedAssetsBackend.recover
    checkpoint=OwnedAssetsBackend.checkpoint
    def __init__(self,action,role,client,store,*,episode=None,monotonic,sleep):
        need(type(action) is AssetsActionScope and role in ('primary','actor') and isinstance(client,AssetsBackendClient)
            and isinstance(store,PrivateFeatureState) and callable(monotonic) and callable(sleep))
        self.actions,self.action,self.role,self.client,self.store=action.owner,action,role,client,store
        self.episode,self.monotonic,self.sleep,self.historical=episode,monotonic,sleep,False
        self.run,self.binding=action.owner.run,deepcopy(action.owner.context['roles'][role]['binding'])
        self.config=public_configuration(client.config);self.lock=action.owner.locks[role] if episode is None else episode.locks[role]
        self.previous=store.read();self.state=None;self.boundary()
        self.parts=CheckpointBackendParts(store.path.parent,self.binding,self.run,role,role,self.guard,self.parts_intent,index=action.index,monotonic=monotonic)
        if self.previous is not None:self.state=self.decode(self.previous)
    def boundary(self):
        root=Path(self.actions.context['roles'][self.role]['stateRoot']) if self.episode is None else Path(self.episode.descriptor['directories'][self.role]['stateRoot']['path'])
        need(self.store.path==root/('ios-assets-checkpoint-'+self.run+'-a'+str(self.action.index)+'-'+self.role+'-backend.json'))
        self.lock.assert_held()
        if self.episode is None:need(self.action.index==1)
        else:self.episode.guard();need(self.episode.owner.selected is self.actions.selected)
    def guard(self):
        self.boundary();self.actions.guard();need(same(self.store.read(),self.previous))
        if not self.historical:self.action.guard();need(self.client.guard() is not False)
        return True
    def envelope(self):return dict(iosAssetsCheckpointBackendVersion=1,runId=self.run,role=self.role,binding=self.binding,
        action=dict(path=str(self.actions.store.path),index=self.action.index,ticket=self.action.ticket),backendConfiguration=self.config,
        episode=None if self.episode is None else self.episode.link(),payload=pack([self.state]))
    def decode(self,value):
        source.digest(self.config.get('tokenSha256'));configuration(self.config_for_decode())
        exact(value,{'iosAssetsCheckpointBackendVersion','runId','role','binding','action','backendConfiguration','episode','payload'})
        need(type(value['iosAssetsCheckpointBackendVersion']) is int and value['iosAssetsCheckpointBackendVersion']==1 and value['runId']==self.run
            and value['role']==self.role and same(value['binding'],self.binding) and same(value['backendConfiguration'],self.config)
            and same(value['action'],dict(path=str(self.actions.store.path),index=self.action.index,ticket=self.action.ticket))
            and same(value['episode'],None if self.episode is None else self.episode.link()))
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0];exact(state,{'phase','samples'})
        need(state['phase']=='observing' and type(state['samples']) is list and len(state['samples'])<=MAX_SAMPLES)
        from fixture.asset_backend_control import command
        previous=None;next_chunk=1;pending=False
        for index,row in enumerate(state['samples'],1):
            exact(row,{'slot','query','requests','parts'});need(not pending and row['slot']=='checkpoint-'+str(index))
            query=command(row['query']);need(query['operation']=='observe' and query['runId']==self.run and query['ticket']==self.action.ticket)
            need(type(row['requests']) is list and len(row['requests'])<=32)
            for ordinal,request in enumerate(row['requests']):command(request);need(same(request,dict(query,operation='observe' if ordinal==0 else 'poll')))
            parts=row['parts'];pending=parts is None or not parts['complete']
            if parts is not None:
                self.parts.parent(parts);need(parts['label']=='raw' and parts['first']==next_chunk and parts['tag']==self.tag(row));next_chunk+=max(1,(parts['bytes']+524287)//524288)
                if parts['complete']:
                    need(row['requests']);raw=self.parts.read(parts);original=json.loads(raw);need(canonical(original)==raw)
                    packet=decode_export(original,query,self.config_for_decode());source.accept(previous,packet);previous=packet
                else:self.parts.inspect(parts)
        return state
    def save(self):
        need(not self.historical);self.guard();value=self.envelope();self.decode(value);self.store.write(value,self.previous)
        fd=os.open(self.store.path.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
        try:os.fsync(fd)
        finally:os.close(fd)
        self.previous=deepcopy(value)
    @operation
    def current(self):
        need(not self.historical);self.guard()
        if self.state is None:self.state=dict(phase='observing',samples=[]);self.save()
        pending=self.state['samples'][-1] if self.state['samples'] and (self.state['samples'][-1]['parts'] is None or not self.state['samples'][-1]['parts']['complete']) else None
        slot=pending['slot'] if pending is not None else 'checkpoint-'+str(len(self.state['samples'])+1)
        for _ in range(32):
            packet=self.checkpoint(slot,self.action.ticket)
            if packet is not None:return packet
            self.sleep(.1)
        need(False)
    @classmethod
    def from_archive(cls,actions,index,role,*,episode=None,allow_active_pending=False):
        from ios.adapters.assets_episode_metadata_graph import readonly_store,forbidden
        row=checkpoint_descriptor(actions,index,allow_active_pending=allow_active_pending);need(role in ('primary','actor'))
        owner=object.__new__(cls);owner.actions,owner.action,owner.role=actions,SimpleNamespace(index=index,ticket=row['ticket']),role
        owner.episode,owner.monotonic,owner.sleep,owner.historical=episode,actions.monotonic,forbidden,True
        owner.run,owner.binding=actions.run,deepcopy(actions.context['roles'][role]['binding']);owner.client=SimpleNamespace(guard=forbidden,request=forbidden)
        owner.lock=actions.locks[role] if episode is None else episode.locks[role]
        root=Path(actions.context['roles'][role]['stateRoot']) if episode is None else Path(episode.descriptor['directories'][role]['stateRoot']['path'])
        owner.store=readonly_store(PrivateFeatureState(root/('ios-assets-checkpoint-'+actions.run+'-a'+str(index)+'-'+role+'-backend.json')))
        owner.previous=owner.store.read();need(owner.previous is not None);owner.config=deepcopy(owner.previous['backendConfiguration']);owner.state=None
        owner.parts=CheckpointBackendParts(root,owner.binding,owner.run,role,role,owner.guard,forbidden,index=index,monotonic=actions.monotonic)
        owner.boundary();owner.state=owner.decode(owner.previous);owner.guard();return owner
