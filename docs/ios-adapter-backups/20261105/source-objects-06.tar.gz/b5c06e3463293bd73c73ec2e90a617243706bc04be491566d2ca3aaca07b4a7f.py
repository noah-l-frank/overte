"""FORENSIC ONLY: untrusted policy selector never grants historical authority.

Prepare/run only under the separately approved fixed180 host window.
No SDK, native producer, transport, process or original-file mutation is allowed.
The random policy instance/token digest was not independently saved at birth.
Consequently every decoded result is diagnostic input, never an acceptance fact.
"""
from contextlib import ExitStack
from copy import deepcopy
import cProfile
import hashlib
import inspect
import json
import os
from pathlib import Path
import stat
import signal
import sys
import time
import traceback
from unittest.mock import patch

from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import collect
from adapters.script_feature.history import unpack
from ios.adapters.snapshot_page_owner import IOSSnapshotPageOwner
from ios.adapters.snapshot_journey_files import IOSSnapshotJourneyFilesOwner
from ios.adapters.snapshot_share_owner import IOSSnapshotShareOwner
from ios.adapters.snapshot_share_archive_end_owner import SnapshotShareArchiveEndOwner
from ios.adapters.snapshot_page_return_owner import SnapshotPageReturnOwner
from ios.adapters.snapshot_upload_owner import IOSSnapshotUploadOwner
from ios.adapters.snapshot_upload_backend_owner import IOSSnapshotUploadBackendOwner
from ios.adapters.snapshot_photos_archive import SnapshotPhotosArchive
from ios.adapters.snapshot_photos_owner import IOSSnapshotPhotosOwner
from ios.adapters.snapshot_capture_owner import IOSSnapshotCaptureOwner
from ios.adapters.snapshot_photos_end_originals import SnapshotPhotosEndOriginals
from ios.adapters.snapshot_photos_end_owner import SnapshotPhotosEndOwner
from ios.adapters.snapshot_photos_end_graph import SnapshotPhotosEndGraph
from ios.adapters.snapshot_photos_end_position import SnapshotPhotosRetiredSDKPosition

LABEL='FORENSIC_UNTRUSTED_POLICY_NO_AUTHORITY'
ROOT=Path.cwd()
PRIVATE=ROOT/'.ios-host-tmp'
OUTPUT=PRIVATE/'snapshot-photos-end-normal17-forensic-cprofile02'
OUTPUT.mkdir(mode=0o700,exist_ok=True)
MAIN=PRIVATE/'tmpb5jf228l'
PHOTOS=PRIVATE/'snapshot-companion-oh487x71'
ARCHIVE=PRIVATE/'snapshot-companion-gz75s566'
ROOTS=(MAIN,PHOTOS,ARCHIVE)
RUN='a'*32
URL='https://controlled.invalid/feature-fixture/v1/runs/'+RUN+'/'

def pin(path):
    before=path.lstat()
    row=dict(stat=[before.st_dev,before.st_ino,before.st_mode,before.st_uid,before.st_gid,before.st_nlink,before.st_size,before.st_mtime_ns,before.st_ctime_ns])
    if stat.S_ISREG(before.st_mode):
        descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        with os.fdopen(descriptor,'rb') as stream:
            actual=os.fstat(stream.fileno())
            if (actual.st_dev,actual.st_ino)!=(before.st_dev,before.st_ino):raise AssertionError('Original inode changed during census')
            sha=hashlib.sha256()
            for body in iter(lambda:stream.read(1024*1024),b''):sha.update(body)
        row['sha256']=sha.hexdigest()
    elif not stat.S_ISDIR(before.st_mode):raise AssertionError('Nonregular original')
    after=path.lstat()
    if row['stat']!=[after.st_dev,after.st_ino,after.st_mode,after.st_uid,after.st_gid,after.st_nlink,after.st_size,after.st_mtime_ns,after.st_ctime_ns]:raise AssertionError('Original changed during census')
    return row

def originals():
    result={}
    for root in ROOTS:
        for path in (root,*sorted(root.rglob('*'))):result[str(path)]=pin(path)
    return result

def sources():
    result={str(path.relative_to(ROOT)):pin(path) for path in sorted((ROOT/'tests/device').rglob('*'))
        if path.is_file() and path.suffix in ('.py','.js','.cjs','.json','.qml','.html','.h','.cpp','.md') and '__pycache__' not in path.parts}
    result[str(Path(__file__).relative_to(ROOT))]=pin(Path(__file__))
    return result

def save(name,value):
    (OUTPUT/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')

# Independent model selections come from reviewed source literals, not a saved
# owner header: test_ios_snapshot_manifest.setUp; snapshot_companion_domain;
# snapshot_photos_domain.PhotosCompanionDomain; snapshot_share_domain constants
# and ShareArchiveDomain(archive_pid=85). Each selected IPA is a caller-chosen
# original path whose actual bytes are hashed independently.
main_binding=dict(sourceRevision='a'*40,artifactSha256='b'*64,processIdentity='42',sessionId='owned-session',generation=0,targetFingerprint='c'*64)
DEVICE='HOST-PHYSICAL-SHARE-DEVICE-MODEL'
system_ui=dict(select=dict(using='accessibility id',value='Snapshot Original Receiver'),cancel=dict(using='accessibility id',value='System Share Cancel'))
def selected(root,bundle,pid,capabilities,admission):
    target=dict(platform='ios',physical=True,appId=bundle,serverUrl='http://already-bound.invalid',capabilities=capabilities)
    artifact=root/'selected.ipa'
    binding=dict(sourceRevision='c'*40,artifactSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),processIdentity=str(pid),
        sessionId='companion-session',generation=1,targetFingerprint=digest(target))
    return dict(root=str(root),binding=binding,artifactPath=str(artifact),sessionPath=str(root/'session.json'),admissionPath=str(root/admission),target=target)

before=originals();source_before=sources();save('originals-before.json',before);save('sources-before.json',source_before)
effects=[]
lock_paths={str(root/'script-feature-sources.lock') for root in ROOTS}
def forbidden(kind):
    effects.append(kind);raise AssertionError('Forbidden forensic effect: '+kind)

def audit(event,args):
    if event.startswith(('socket.','subprocess.','os.exec','os.spawn','os.fork')) or event in ('os.system','os.posix_spawn','pty.spawn','ctypes.dlopen'):
        forbidden(event)
    if event in ('os.remove','os.rmdir','os.rename','os.mkdir','os.chmod','os.chown','os.utime','os.link','os.symlink','os.truncate'):
        forbidden(event)
    if event=='open':
        path,mode,flags=args
        if isinstance(path,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):forbidden('descriptor-write-open')
        if isinstance(path,(str,bytes,os.PathLike)):
            path=str(Path(os.fsdecode(path)).absolute())
            write=flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)
            if write:
                if Path(path).parent==OUTPUT:return
                if path in lock_paths and mode is None and not flags&(os.O_TRUNC|os.O_APPEND|os.O_EXCL):
                    row=Path(path).lstat()
                    if [row.st_dev,row.st_ino]==before[path]['stat'][:2]:return
                forbidden('open-write:'+path)

targets={}
def target(cls,*names):
    for name in names:
        fn=inspect.unwrap(getattr(cls,name))
        if hasattr(fn,'__func__'):fn=fn.__func__
        targets[fn.__code__]=cls.__name__+'.'+name

target(IOSSnapshotPageOwner,'archive')
target(IOSSnapshotJourneyFilesOwner,'archive')
target(IOSSnapshotShareOwner,'history')
target(SnapshotShareArchiveEndOwner,'history')
target(SnapshotPageReturnOwner,'history')
target(IOSSnapshotUploadOwner,'history')
target(IOSSnapshotUploadBackendOwner,'history')
target(SnapshotPhotosArchive,'history','_read_history','result')
target(IOSSnapshotPhotosOwner,'capture','decode','proof','cleanup_proof','quiet')
target(IOSSnapshotCaptureOwner,'archive','decode','result')
target(SnapshotPhotosEndOwner,'history','_initialize','load','proof','bound')
target(SnapshotPhotosEndGraph,'verify','proof_originals','replay')
started=time.perf_counter()
profiler=cProfile.Profile(subcalls=False,builtins=False)
cutpoint=None
def profile_stats():
    import pstats
    values=pstats.Stats(profiler).stats
    stats={}
    for code,label in targets.items():
        key=(code.co_filename,code.co_firstlineno,code.co_name)
        if key in values:
            primitive,total,own,cumulative,_callers=values[key]
            stats[label]=dict(primitiveCalls=primitive,totalCalls=total,selfSeconds=own,inclusiveSeconds=cumulative)
    return stats
def terminate(signum,frame):
    global cutpoint
    profiler.disable()
    stack=[]
    while frame is not None:
        stack.append(dict(file=frame.f_code.co_filename,line=frame.f_lineno,function=frame.f_code.co_qualname))
        frame=frame.f_back
    cutpoint=dict(signal=signum,elapsedSeconds=time.perf_counter()-started,stack=stack,
        partialCountsAndTimings=profile_stats(),actualReadPaths=sorted(map(str,globals().get('actual_reads',()))))
    save('sigterm-cutpoint.json',dict(label=LABEL,authority=False,cutpoint=cutpoint))
    profiler.dump_stats(str(OUTPUT/'decoder-costs-cutpoint.pstats'))
    print(LABEL,'SIGTERM_CUTPOINT_SAVED',round(time.perf_counter()-started,6),flush=True)
    raise SystemExit(128+signum)

error=None;reads=set();identities={}
sys.addaudithook(audit)
signal.signal(signal.SIGTERM,terminate)
try:
    with collect() as actual_reads:
        # UNTRUSTED random public configuration is intentionally selected from
        # recorded Backend4 input only to exercise identical decoder work.
        # This selector has no independent authority and invalidates ALL
        # acceptance claims, even when the unchanged decoder returns a result.
        raw=PrivateFeatureState(MAIN/'snapshot-upload-backend-owner.json').read()
        recorded_state=unpack(raw['payload'])[0]
        policy_selector=deepcopy(recorded_state['result']['domainPolicy'])
        main=dict(root=str(MAIN),binding=main_binding)
        photos=selected(PHOTOS,'org.example.snapshot.photos',84,{'appium:udid':DEVICE,'appium:platformVersion':'99.1'},'ios-snapshot-companion-owner.json')
        archive=selected(ARCHIVE,'org.example.snapshot.sharearchive',85,{'appium:udid':DEVICE},'ios-snapshot-share-code-owner.json')
        save('selection-boundary.json',dict(label=LABEL,authority=False,main=main,photos=photos,archive=archive,run=RUN,fixtureUrl=URL,
            primaryBundle='org.example.client',systemUI=system_ui,policySelectorOrigin='UNTRUSTED recorded Backend4 state.result.domainPolicy',
            policySelectorSha256=digest(policy_selector),configurationSource='Reviewed fixture source literals plus independently selected original IPA bytes'))
        factory=SnapshotPhotosEndOriginals(main,photos,archive,run=RUN,fixture_url=URL,primary_bundle='org.example.client',system_ui=system_ui,domain_policy=policy_selector)
        print(LABEL,'FACTORY_READY; no qualification is possible',flush=True)
        with ExitStack() as stack:
            stack.enter_context(patch.object(PrivateFeatureState,'write',side_effect=lambda *_a,**_k:forbidden('PFS.write')))
            stack.enter_context(patch.object(PrivateFeatureState,'discard',side_effect=lambda *_a,**_k:forbidden('PFS.discard')))
            for name in ('write','pwrite','writev','ftruncate','fchmod','fchown'):
                if hasattr(os,name):stack.enter_context(patch.object(os,name,side_effect=lambda *_a,_name=name,**_k:forbidden('os.'+_name)))
            profiler.enable()
            try:
                with factory.read() as ended:
                    print(LABEL,'FACTORY_READ_ENTERED',round(time.perf_counter()-started,6),flush=True)
                    if not ended.historical or ended.ctx.client is not None:raise AssertionError('Nonhistorical forensic reader')
                    identities['recordedResultSha256']=digest(ended.state['result'])
                    value=ended.proof();identities['decodedDiagnosticSha256']=digest(value)
                    print(LABEL,'EXPLICIT_PROOF_RETURNED',round(time.perf_counter()-started,6),flush=True)
                    position=SnapshotPhotosRetiredSDKPosition(ended)
                    original=ended.graph.replay(position)
                    identities['decodedLiteralResult2Sha256']=digest(original)
                    print(LABEL,'EXPLICIT_GRAPH_REPLAY_RETURNED',round(time.perf_counter()-started,6),flush=True)
            finally:profiler.disable()
        reads=set(actual_reads)
except BaseException as exc:
    profiler.disable();error=dict(type=type(exc).__name__,message=str(exc));traceback.print_exc()
finally:
    if 'actual_reads' in globals():reads=set(actual_reads)
    after=originals();source_after=sources()
    changed=[path for path in set(before)|set(after) if before.get(path)!=after.get(path)]
    changed_source=[path for path in set(source_before)|set(source_after) if source_before.get(path)!=source_after.get(path)]
    save('originals-after.json',after);save('sources-after.json',source_after)
    profiler.dump_stats(str(OUTPUT/'decoder-costs-final.pstats'))
    report=dict(label=LABEL,authority=False,policyAcceptance=False,coldAcceptance=False,endAcceptance=False,featureAcceptance=False,
        elapsedSeconds=time.perf_counter()-started,error=error,forbiddenEffects=effects,changedOriginals=sorted(changed),changedSources=sorted(changed_source),
        actualReadPaths=sorted(map(str,reads)),countsAndInclusiveTimings=profile_stats(),diagnosticIdentities=identities,cutpoint=cutpoint,
        timingLimitations='CProfile Python calls only, builtins/caller edges disabled; inclusive durations overlap; interrupted call counts are partial; no device/native or isolated performance claim.')
    save('report.json',report)
    print(LABEL,json.dumps(report,sort_keys=True),flush=True)
if error or effects or changed or changed_source:raise SystemExit(1)
