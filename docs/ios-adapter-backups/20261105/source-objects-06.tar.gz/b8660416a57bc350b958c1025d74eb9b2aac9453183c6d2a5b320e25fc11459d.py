"""Real normal prefix/original HTTP return loss; SDK/native remain MODELS."""
from normal_child_fixture import NormalChildFixture

class NativeTerminalNormalReturnModels(NormalChildFixture):
    async def test_unknown_terminal_http_return_keeps_original_worker_and_requires_saved_only_recovery_before_host_quiet_reads(self):
        await self.owner.act(seconds=12);await self.owner.observe();self.lose_terminal_response=True
        with self.assertRaises((RuntimeError,ValueError)):await self.owner.release()
        connection=self.owner._original_child
        self.assertTrue(connection._terminal_started);self.assertIsNone(connection._terminal_references)
        self.assertIsNone(self.owner.state['released']);self.assertEqual(30,len(self.commands))
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        source_records=len(self.ops.issued);commands=len(self.commands)
        with self.assertRaises((RuntimeError,ValueError)):await self.owner.capture()
        self.assertEqual(source_records,len(self.ops.issued));self.assertEqual(commands,len(self.commands))
        await connection.recover_terminal();self.assertEqual(5,len(connection._terminal_references))
        released=await self.owner.release();self.assertEqual('released',released['terminal'])
        for _ in range(4):proof=await self.owner.sample_quiet()
        self.assertEqual(4,proof['quiet']['samples']);self.assertGreaterEqual(proof['quiet']['nativeMilliseconds'],3000)
        self.assertEqual(commands,len(self.commands));self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        self.assertEqual(1,self.f.context.exited);self.assertEqual(7,len(self.owner.state['frames']))
