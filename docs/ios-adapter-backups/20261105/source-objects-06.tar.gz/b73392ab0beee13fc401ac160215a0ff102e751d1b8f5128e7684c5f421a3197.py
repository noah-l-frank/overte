"""Exact Source9/7 host subjects over actual public32 bases; no native verdict."""
from pathlib import Path
import json
from host_common import REPO
SOURCE=Path(__file__).resolve().parent
SOURCE9=REPO/'.ios-host-tmp/snapshot-actor-bounded-frame-index-replay-refusal-source9-private-20261104'
SOURCE7=REPO/'.ios-host-tmp/snapshot-independent-actor-primary-original-png-source7-private-20261104'
STAGING=REPO/'.ios-host-tmp/snapshot-scene-ordered-canonical-source1354-integration-staging1-private-20261104'
PUBLIC39=REPO/'.ios-host-tmp/root-snapshot-public39-current-origin-compatibility-qualified-results-20261104'

def packet(folder,leaf,digest,pin,physical):
    path=folder/leaf;value=pin(path);assert value['sha256']==digest;physical[str(path)]=value
    data=json.loads(path.read_text())
    for name,row in data['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        path=folder/name;value=pin(path)
        assert value['sha256']==(row if type(row)is str else row['sha256']);physical[str(path)]=value
    return data

def readiness(pin):
    physical={}
    review_folder=REPO/'.ios-host-tmp/root-snapshot-actor-source9-static-source-review-20261104'
    packet(review_folder,'freeze.json','df058b123a7ae523c4c557d00f37dd56fc7fb721bcbf3b1ddfb8166453e3a328',pin,physical)
    assert pin(review_folder/'review.json')['sha256']=='e37e7b687c11bebb59755bce32e883f6aabaeacd6dcc9df26ada6c68ca49281c'
    review=json.loads((review_folder/'review.json').read_text())
    assert review['schemaVersion']==1 and review['status']=='ROOT_STATIC_REVIEWED_SNAPSHOT_ACTOR_SOURCE9_NO_RUNTIME_QUALIFICATION'
    assert review['sourceFreeze']=='e4ccc186b69aa290f6af84cca771a9fa78bb500d807a1c4637108d4afda42ce5'
    assert review['hostSourceStaticReviewComplete']is review['allowsHostModelSourcePreparationOnly']is review['allActorCasesUnrun']is True
    assert review['prospectiveActorCases']==22 and review['pythonCandidates']==14 and review['nativeProbeCandidates']==7
    assert all(review[key]is False for key in('hostRuntimeCompositionQualified','nativeCompiled','nativeQualified','devicesQualified','wholeQualified'))
    assert review['independentPeerFreeze']=='c77b411ff8cc6409cc102e9d524acf766f7b0968ef528349471ecf977ce53bf6'
    for name,row in json.loads((review_folder/'references.json').read_text()).items():
        assert row['path']==name;path=Path(name);value=pin(path);assert value['sha256']==row['sha256'];physical[str(path)]=value
    packet(REPO/'.ios-host-tmp/lifecycle-independent-snapshot-actor-source9-bounded-replay-full-delta-review-20261104','freeze.json','c77b411ff8cc6409cc102e9d524acf766f7b0968ef528349471ecf977ce53bf6',pin,physical)
    packet(REPO/'.ios-host-tmp/avatar-independent-snapshot-source7-typed-original-png-join-full-review-20261104','freeze.json','1fe26ff7d1045d8acf7eca891137ecf197fd46bea45c3f3976a982b26f61410c',pin,physical)
    source_review=dict(rootFreeze='df058b123a7ae523c4c557d00f37dd56fc7fb721bcbf3b1ddfb8166453e3a328',reviewSHA256='e37e7b687c11bebb59755bce32e883f6aabaeacd6dcc9df26ada6c68ca49281c',hostModelSourcePreparationOnly=True,hostRuntimeCompositionQualified=False,nativeQualified=False,wholeQualified=False)
    packet(SOURCE9,'source-freeze.json','e4ccc186b69aa290f6af84cca771a9fa78bb500d807a1c4637108d4afda42ce5',pin,physical)
    packet(SOURCE7,'source-freeze.json','7d6bdfd1828b631e137492ee1828ee31317a222aa87a8c9eb14e00df830e877d',pin,physical)
    packet(REPO/'.ios-host-tmp/snapshot-scene-independent-actor-rendered-pixels-source6-private-20261104','source-freeze.json','d28c3e2a8239bffc9e8c0e0883f762bb25375abf6569192eeb4f00329af4a32c',pin,physical)
    packet(REPO/'.ios-host-tmp/snapshot-actor-same-frame-original-invalidation-source8-private-20261104','source-freeze.json','563e53cd7251d899988dd062ddb3eae5ade7e254e9f4443708cc5e832fe40aad',pin,physical)
    packet(STAGING,'source-freeze.json','6cf5883ecb43431f468392c3467dbcef3683707c105b0545765a2ab28e10c9d2',pin,physical)
    stage=json.loads((STAGING/'STAGING-MANIFEST.json').read_text());public={};origins={}
    for logical,row in stage['mergedCandidatePaths'].items():
        path=REPO/logical;value=pin(path);assert value['sha256']==row['sha256'];physical[str(path)]=value;public[logical]=value['sha256']
        if logical.endswith('.py'):
            name='.'.join(Path(logical).relative_to('tests/device').with_suffix('').parts)
            origins[name]=dict(path=str(path),sha256=value['sha256'])
    assert len(public)==32
    # Bind genuine ordinary fixture/capture/provenance definitions at current
    # public paths; old candidate origin fields are historical source data.
    ordinary=REPO/'.ios-host-tmp/snapshot-ordinary-provenance-own9-bootstrap3-complete-root-input-pin-code-preparation-20261104/source-inputs.json'
    physical[str(ordinary)]=pin(ordinary)
    for name in json.loads(ordinary.read_text())['modules']:
        if name=='validate_contract_versions':continue
        path=REPO/'tests/device'/Path(*name.split('.')).with_suffix('.py');value=pin(path);physical[str(path)]=value
        origins[name]=dict(path=str(path),sha256=value['sha256'])
    # Actual root/Native lower-fixture definitions are separately receipted,
    # not assumed present merely because transitive imports usually load them.
    for name in('ios.self_tests.test_ios_snapshot_manifest','ios.self_tests.test_ios_snapshot_captures'):
        path=REPO/'tests/device'/Path(*name.split('.')).with_suffix('.py');value=pin(path);physical[str(path)]=value
        origins[name]=dict(path=str(path),sha256=value['sha256'])
    declarations=json.loads((SOURCE/'PRIVATE-SUBJECTS.json').read_text())['rows']
    assert len(declarations)==25 and sum(row['kind']=='python'for row in declarations)==18
    overlays={}
    for row in declarations:
        path=Path(row['path']);logical=row['logicalPath'];value=pin(path);assert value['sha256']==row['sha256'];physical[str(path)]=value
        current=REPO/logical
        if row['baseSha256']is None:assert not current.exists(),'New candidate/public collision'
        else:
            current_pin=pin(current);assert current_pin['sha256']==row['baseSha256'];physical[str(current)]=current_pin
        if row['kind']=='python':
            name='.'.join(Path(logical).relative_to('tests/device').with_suffix('').parts)
            overlays[name]=dict(path=str(path),sha256=value['sha256']);origins[name]=overlays[name]
    assert len(overlays)==18
    controls=json.loads((SOURCE/'SUBJECT-METHOD-AND-FREE-FACTORY-INVENTORY.json').read_text())
    control_modules={row[0]for row in(*controls['classDeclarations'],*controls['freeFunctionDeclarations'])}
    for name in sorted(control_modules):
        if name=='closed_import_origins' or name in origins:continue
        assert name.startswith(('ios.','adapters.','feature_journeys.'))
        path=REPO/'tests/device'/Path(*name.split('.')).with_suffix('.py');value=pin(path);physical[str(path)]=value
        origins[name]=dict(path=str(path),sha256=value['sha256'])
    packet(PUBLIC39,'freeze.json','f668d54434f1c069897dbb6828a168987b60867422d0353ae3a11a283c0b3ee1',pin,physical)
    previous=json.loads((PUBLIC39/'results.json').read_text())
    assert previous['status']=='ROOT_QUALIFIED_CURRENT_PUBLIC_SNAPSHOT39_COMPATIBILITY_COMPONENTS'
    assert previous['actualCases']==previous['actualPassedCases']==39 and previous['currentPublicCompatibilityQualified']is True
    assert previous['nativeQualified']is previous['wholeQualified']is previous['actorPixelsQualified']is False
    return dict(publicBasePaths=public,subjectOrigins=origins,privateOverlayOrigins=overlays,source9RootReview=source_review,
        source9Freeze='e4ccc186b69aa290f6af84cca771a9fa78bb500d807a1c4637108d4afda42ce5',source7Freeze='7d6bdfd1828b631e137492ee1828ee31317a222aa87a8c9eb14e00df830e877d',
        historicalPublic39Proof='f668d54434f1c069897dbb6828a168987b60867422d0353ae3a11a283c0b3ee1',requiredOriginalRoots=previous['requiredOriginalRoots'],
        source9HostCountersQualified=False,source7ComparisonQualified=False,nativeAdmission=None,nativeQualified=False,wholeQualified=False),physical
