"""Actual Files4/Picker2/Reply3/QML episode with declared SDK factories.

Normal input, file bytes/inodes, backend originals, Geometry/HFM delivery and
Create/Model removal execute through existing host producers. SDK/Qt/parser/
server/device boundaries remain models. No whole29 or hardware result is claimed.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import json
from unittest.mock import patch
from adapters.native_feature_observation import NativeFeatureObservation,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from ios.adapters import assets_model_origin as origin
from ios.adapters.assets_action_phase import AssetsActionPhases
from ios.adapters.assets_born_page_lease import BornAssetsPageLease
from ios.adapters.assets_episodes import AssetsEpisodes
from ios.adapters.assets_page_birth import AssetsPageBirth
from ios.adapters.assets_page_picker import PageLeasePicker
from ios.adapters.assets_selected_profile import EpisodeAssetsFiles
from ios.adapters.assets_shared_action_runtime import SharedActionAssetsRuntime
from ios.adapters.assets_runtime import AssetsNativeInput
from ios.adapters.assets_page_ownership import AssetsPageInventoryContext,inspect_page
from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
from ios.adapters.normal_input import NativeInput
from ios.self_tests.assets_picker_fixture import RUN,URL,BINDING
from ios.self_tests.assets_shared_page_fixture import Boundary as PageBoundary
from ios.self_tests.assets_model_removal_fixture import Boundary as RemovalBoundary
from ios.self_tests.assets_unbaked_fixture import Fixture as OriginalFixture
from ios.self_tests.assets_paired_end_boundary_fixture import Boundary as OriginalBoundary


class Boundary(OriginalBoundary,PageBoundary):
    def ui(self):
        value=PageBoundary.ui(self);tree=self.host_state['treeInfo']
        for row in value['roots']:
            if row['role']=='page' and row['alive']:
                row.update(selectedPath=tree['currentPath'],selectedUrl=tree['currentUrl'],modelRevision=tree['treeRevision'],canWrite=tree['canWrite'])
        return value
    def native_input(self):
        create=super().native_input();assets=super(RemovalBoundary,self).native_input();boundary=self
        class Input(NativeInput):
            def __init__(self):
                self.monotonic,self.sleep,self.native_epoch_ms=boundary.monotonic,boundary.sleep,boundary.clock
                self.process=dict(pid=42);self.instance=boundary.normal_instance;self.last_receipt=None
            def capture(self):
                port=create if boundary.create_widgets is not None else assets
                previous=getattr(port,'observe_intent',None);port.observe_intent=getattr(self,'observe_intent',None)
                try:
                    result=port.capture();self.last_receipt=deepcopy(port.last_receipt);return result
                finally:port.observe_intent=previous
            def deliver(self,command,*,before_send=None):
                current=boundary.normal();targets=[row for row in current['controls'] if row['token']==command['fieldToken']];need(len(targets)==1)
                port=assets if targets[0]['id'].startswith(('assets.','asset-file.')) else create
                result=port.deliver(command,before_send=before_send);self.last_receipt=deepcopy(port.last_receipt);return result
        return Input()


class Fixture(OriginalFixture):
    boundary_type=Boundary
    def __init__(self,test):
        from ios.self_tests.test_ios_assets_action_phase import AssetsActionPhaseTests
        self.a=AssetsActionPhaseTests();self.a.setUp();test.addCleanup(self.a.doCleanups)
        super().__init__(self.a.h.roots['primary']);test.addCleanup(self.close)
        self.test=test;self.selected=self.a.selected;self.episodes=AssetsEpisodes(self.selected,self.a.h.locks)
        self.scopes=[];self.pickers={};self.scope=None;self.action=None;self.page=None
        def phase_request(path,**kwargs):
            self.boundary.tick(max(1,self.a.epoch-self.boundary.clock()+1));self.a.epoch=self.boundary.clock()
            self.a.requests.append((path,deepcopy(kwargs)));return self.a.journal.phase(RUN,kwargs['phase_nonce'])
        self.a.phase.client.request=phase_request
        test.enterContext(patch('adapters.asset_backend_client.build_opener',return_value=self))

    def activate(self,index):
        self.a.epoch=max(self.a.epoch,self.boundary.clock())+1;ticket,row=self.a.activate(index)
        self.action=self.a.owner.begin(index,ticket,row['verb'],row['inputs']);return self.action

    def complete(self):
        self.a.epoch=max(self.a.epoch,self.boundary.clock())+1;return self.a.owner.complete(self.action)

    def native_channel(self,action,guard):
        return AssetsNativeInput.from_original(self.boundary.native_input(),guard)

    def ports(self,action):
        b=self.boundary
        def checked():action.guard();return True
        clock=NativeFeatureObservation(b.native_clock.send,b.native_clock.original,b.clock,checked,42,
            ios=True,monotonic=b.monotonic,sleep=b.sleep)
        files=b.files_native();replies=b.reads.native()
        for native in (files,replies):
            previous=native.guard
            def guarded(previous=previous):checked();need(previous() is not False);checked();return True
            native.guard=guarded
        def readers(clock):return b.model_readers(clock)
        def origin_reader(clock):
            raw=['']
            def send(query):origin.command(query);raw[0]=json.dumps(b.origin(query))
            return origin.IOSAssetsModelOrigin(send,lambda:raw[0],lambda:clock.read(clock.sequence)['capturedEpochMs'],checked,42,
                monotonic=b.monotonic,sleep=b.sleep)
        observer=SimpleNamespace(sleep=b.sleep,create_state=lambda clock:readers(clock)[0],create_work=lambda clock:readers(clock)[1],assets_model_origin=origin_reader)
        return dict(binding=deepcopy(BINDING),native=self.native_channel(action,checked),clock_source=clock,
            files=files,replies=replies,observer=observer,check=checked)

    def runtime(self):
        fixture=self
        class Adapter:
            def state_path(_self,selector):return fixture.a.h.roots[selector]/'session.json'
            def _candidate_guard(_self):return True
            def _binding(_self,*_args):raise AssertionError('Declared SDK factory boundary must not acquire a real SDK')
        runtime=SharedActionAssetsRuntime(Adapter(),self.selected,assets_action=self.action,phase=self.a.phase,episode=self.scope,
            page_lease=self.page,monotonic=self.boundary.monotonic,epoch_ms=lambda:self.boundary.clock()+5000)
        def sources(selector,lock):
            need(selector=='primary' and lock is runtime.assets_episode.locks['primary']);lock.assert_held();runtime.assets_action.guard();return self.ports(runtime.assets_action)
        runtime._assets_sources=sources
        return runtime

    def episode(self,index):
        self.scope=self.episodes.begin(index,self.action.ticket);self.scopes.append(self.scope)
        held=self.scope.held();held.__enter__();self.test.addCleanup(held.__exit__,None,None,None)
        self.lock=self.scope.locks['primary'];return self.scope

    def prepare(self):
        self.activate(1);ports=self.ports(self.action);parent=self.a.h.roots['primary']
        birth_store=PrivateFeatureState(parent/('ios-assets-page-birth-'+RUN+'-primary.json'))
        birth=AssetsPageBirth(self.selected,birth_store,self.a.h.locks['primary'],self.action,ports['native'],ports['clock_source'],monotonic=self.boundary.monotonic)
        birth.reserve();birth.open()
        page_store=PrivateFeatureState(parent/('ios-assets-page-lease-'+RUN+'-primary.json'))
        self.page=BornAssetsPageLease(self.episodes,page_store,self.a.h.locks['primary'],birth=birth,monotonic=self.boundary.monotonic)
        self.page.reserve();self.page.attach_birth();self.complete()
        self.birth=AssetsPageBirth.from_archive(self.selected,birth_store,self.a.h.locks['primary'],self.a.owner,monotonic=self.boundary.monotonic)
        self.page=BornAssetsPageLease(self.episodes,page_store,self.a.h.locks['primary'],birth=self.birth,monotonic=self.boundary.monotonic)
        self.activate(2);self.episode(1);ports=self.ports(self.action);state=Path(self.scope.descriptor['directories']['primary']['stateRoot']['path'])
        files=EpisodeAssetsFiles(ports['files'],PrivateFeatureState(state/('ios-assets-'+RUN+'-primary-files.json')),BINDING,RUN,URL,
            lock=self.lock,selection=self.selected,episode=self.scope)
        files.reserve(self.action.ticket,'gltf-bundle/main.gltf');files.stage()
        picker=PageLeasePicker(ports['native'],files,PrivateFeatureState(state/('ios-assets-'+RUN+'-primary-picker.json')),BINDING,
            lock=self.lock,page_lease=self.page,episode=self.scope,monotonic=self.boundary.monotonic,sleep=self.boundary.sleep)
        picker.reserve();picker.open_page();picker.open_picker();picker.choose_primary();self.pickers[1]=picker;self.complete()
        self.activate(3)
        # Fresh current ports reopen exactly the already-born File4/Picker2.
        ports=self.ports(self.action);files=EpisodeAssetsFiles(ports['files'],files.store,BINDING,RUN,URL,lock=self.lock,selection=self.selected,episode=self.scope)
        picker=PageLeasePicker(ports['native'],files,picker.store,BINDING,lock=self.lock,page_lease=self.page,episode=self.scope,
            monotonic=self.boundary.monotonic,sleep=self.boundary.sleep)
        picker.cancel_owned();picker.retire_inputs();self.pickers[1]=picker;self.complete()
        self.activate(4);self.episode(2);self.boundary.reads.resource='gltf-bundle/main.gltf';runtime=self.runtime()
        self.parts=runtime._assets_prepare_unbaked_upload('primary',RUN,'primary',URL,self.action.ticket,self.lock,self.backend.config,resource='gltf-bundle/main.gltf')
        self.pickers[2]=self.parts['picker'];self.complete()
        self.activate(5);runtime=self.runtime();self.parts=runtime._assets_components('primary',RUN,'primary',URL,self.lock)
        tree=self.parts['tree'];tree.reserve();tree.browse();self.complete()
        self.activate(6);runtime=self.runtime();self.parts=runtime._assets_components('primary',RUN,'primary',URL,self.lock)
        self.parts['tree'].rename();self.complete()
        self.activate(7);runtime=self.runtime();self.parts=runtime._assets_components('primary',RUN,'primary',URL,self.lock)
        usage=self.parts['usage'];usage.reserve();usage.select();packet=usage.capture()
        from ios.adapters.assets_usage_controls import project
        actual=project(packet,usage.source.state['page']);need(not actual['baking']['enabled'] and not actual['baking']['checked']);self.complete()
        self.activate(8);runtime=self.runtime();self.parts=runtime._assets_unbaked_components('primary',RUN,'primary',URL,self.lock,self.backend.config)
        runtime._assets_import_unbaked(self.parts);self.complete()
        self.activate(9);return self.removal_parts()

    def removal_parts(self):
        runtime=self.runtime();parts=runtime._assets_unbaked_components('primary',RUN,'primary',URL,self.lock,self.backend.config)
        parts=runtime._assets_model_removal_components('primary',RUN,'primary',URL,self.lock,self.backend.config,parts=parts)
        removal=parts['model_removal']
        if removal.state is None:removal.reserve()
        if removal.state['phase']!='model-gone':
            self.boundary.attach_create();removal.remove()
        self.parts=parts;return runtime,parts

    def close_context(self):self.parts['model_removal'].close_context()

    def retirement(self,*,parts=None):
        runtime=self.runtime();return runtime._assets_dead_page_retirement_components('primary',RUN,'primary',URL,self.lock,self.backend.config,
            parts=self.parts if parts is None else parts)

    def archive_graph(self):
        context=AssetsPageInventoryContext(self.episodes,tuple(self.scopes),self.birth)
        page=inspect_page(context)['owner']
        return AssetsEpisodeModelGraph(self.scope,page,actions=self.a.owner,dependency_mode=True).decode()
