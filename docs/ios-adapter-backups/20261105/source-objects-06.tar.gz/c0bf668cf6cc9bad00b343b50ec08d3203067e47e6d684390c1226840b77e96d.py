"""Root-only fresh metadata for five actual constructor/model counters.

No project/Pillow import or historical raw corpus acquisition is used here.
"""
from pathlib import Path
import argparse,hashlib,json,os,stat,sys
R=Path.cwd().resolve(strict=True);SOURCE=Path(__file__).resolve().parent
assert R.name=='overte-ios-feature-adapters-resume-20261026' and (R/'.git').is_file() and sys.dont_write_bytecode
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript')
def pin(path):
    path=Path(path);a=path.lstat();assert path.resolve(strict=True)==path and not path.is_symlink() and stat.S_ISREG(a.st_mode)
    raw=path.read_bytes();assert all(getattr(a,k)==getattr(path.lstat(),k)for k in FIELDS)
    return dict(stat=[getattr(a,k)for k in FIELDS],sha256=hashlib.sha256(raw).hexdigest())
def checked(path):
    assert Path.cwd().resolve(strict=True)==R and (R/'.git').is_file()
    path=Path(path);assert path.resolve().is_relative_to(R/'.ios-host-tmp');return path
def current_head():
    raw=(R/'.git').read_text();assert raw.startswith('gitdir: ')
    gd=Path(raw[8:].strip()).resolve(strict=True);common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    h=(gd/'HEAD').read_text().strip();assert h.startswith('ref: ')
    ref=common/h[5:];return ref.read_text().strip(),[R/'.git',gd/'HEAD',gd/'index',gd/'commondir',ref]
def frozen(folder,digest):
    f=folder/'source-freeze.json';assert pin(f)['sha256']==digest
    value=json.loads(f.read_text())
    for name,row in value['files'].items():assert pin(folder/name)['sha256']==row['sha256']
    return value
p=argparse.ArgumentParser();p.add_argument('--destination',required=True);p.add_argument('--source-freeze',required=True);p.add_argument('--expected-head',required=True);args=p.parse_args()
actual,git=current_head();assert actual==args.expected_head and len(actual)==40
own=frozen(SOURCE,args.source_freeze);cfg=json.loads((SOURCE/'source-inputs.json').read_text())
source=Path(cfg['sourcePacket']);s4=Path(cfg['source4Packet']);subject=frozen(source,cfg['sourceFreezeSha256']);old=frozen(s4,cfg['source4FreezeSha256'])
assert len(cfg['cases'])==len(set(cfg['cases']))==5 and len(cfg['modules'])==3
assert cfg['wallSeconds']==30 and cfg['killGraceSeconds']==5
physical=set(git);physical.update((SOURCE/'source-freeze.json',source/'source-freeze.json',s4/'source-freeze.json',Path(sys.executable).resolve(strict=True)))
for folder,body in((SOURCE,own),(source,subject),(s4,old)):physical.update(folder/name for name in body['files'])
# Readonly source references are definitions, not historical raw sample inputs.
for raw,row in json.loads((source/'SOURCE-REFERENCES.json').read_text()).items():
    path=Path(raw);assert pin(path)['sha256']==row['sha256'];physical.add(path)
public=set()
for name in ROOTS:
    root=R/name;assert root.is_dir() and root.resolve(strict=True)==root
    for path in root.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():public.add(path)
physical.update(public);physical.update((R/'CMakeLists.txt',R/'interface/CMakeLists.txt'))
modules={};namespaces={}
for base in(R/'tests/device',R/'tests/device/self_tests',R/'tests/device/ios/self_tests'):
    for path in sorted(base.rglob('*.py')):
        assert path in public and path.resolve(strict=True)==path
        parts=path.relative_to(base).with_suffix('').parts;name='.'.join(parts[:-1]if parts[-1]=='__init__'else parts)
        if name:modules.setdefault(name,dict(path=str(path),package=path.name=='__init__.py'))
        for i in range(1,len(parts)):namespaces.setdefault('.'.join(parts[:i]),str(base.joinpath(*parts[:i])))
# Independently preserve original public source paths before exact three overlays.
physical.update(Path(row['path'])for row in modules.values());origins={}
for name,row in cfg['modules'].items():
    path=Path(row['path']);assert pin(path)['sha256']==row['sha256'];physical.add(path)
    modules[name]=dict(path=str(path),package=False);origins[name]=dict(path=str(path),sha256=row['sha256'])
for name,row in cfg['thirdPartyModules'].items():
    path=Path(row['path']);assert pin(path)['sha256']==row['sha256'];physical.add(path)
helper=cfg['ownedWriteHelper'];assert pin(helper['path'])['sha256']==helper['sha256'];modules['owned_write_boundary']=dict(path=helper['path'],package=False);physical.add(Path(helper['path']))
retained=cfg['retainedRoots'];assert pin(retained['path'])['sha256']==retained['sha256'];physical.add(Path(retained['path']))
namespaces={name:path for name,path in namespaces.items()if name not in modules}
for name in('subprocess','threading','tempfile','unittest','unittest.case','unittest.runner','unittest.result','io','signal','socket','socketserver','http.server','fcntl','select','selectors'):
    module=__import__(name,fromlist=['__name__']);path=getattr(module,'__file__',None)
    if path and Path(path).is_file():physical.add(Path(path).resolve(strict=True))
dest=Path(args.destination);assert dest.is_absolute() and dest.parent==R/'.ios-host-tmp' and dest.parent.resolve(strict=True)==dest.parent and not dest.exists()
before={str(path):pin(path)for path in sorted(physical)}
checked(dest).mkdir(mode=0o700)
for name in('run-own5.py','supervise-own5.py'):
    target=checked(dest/name);assert not target.exists()
    with checked(target).open('xb')as stream:stream.write((SOURCE/name).read_bytes())
    target.chmod(0o600);before[str(target)]=pin(target)
plan=dict(status='UNRUN_REQUIRES_ROOT_REVIEW',repositoryRoot=str(R),controllerRoot=str(dest),actualPublicHead=actual,
    sourceFreeze=cfg['sourceFreezeSha256'],sourceAndBinaryPins=before,modules=modules,namespaces=namespaces,thirdPartyModules=cfg['thirdPartyModules'],subjectOriginModules=origins,
    cases=cfg['cases'],wallSeconds=30,killGraceSeconds=5,expectedTemporaryDirectories=5,expectedTemporaryDirectoriesPerCase=1,
    NodeExecutions=0,SDKExecutions=0,realNetwork=False,declaredModelNativeObservationsAllowed=True,
    nativeCompiled=False,nativeQualified=False,movingQualified=False,wholeQualified=False,oldCorpusInputs=0,globalOriginalScans=0)
target=checked(dest/'approved-inputs.json');assert not target.exists()
with checked(target).open('x')as stream:json.dump(plan,stream,sort_keys=True,indent=2);stream.write('\n')
target.chmod(0o600)
assert before=={name:pin(name)for name in before} and current_head()[0]==actual
print(json.dumps(dict(controllerRoot=str(dest),inputSha256=pin(target)['sha256'],sourcePins=len(before),cases=5,metadataOnly=True,targets=0,globalOriginalScans=0)))
