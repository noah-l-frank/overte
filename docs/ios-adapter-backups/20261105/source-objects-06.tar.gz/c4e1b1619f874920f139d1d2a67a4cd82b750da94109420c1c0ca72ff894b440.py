"""Retain actual B17 TERM stack and missing child proofs; no rerun or cause claim."""
from pathlib import Path
import hashlib,json
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,v):
 with(d/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
C=B/'root-emote-b17-whole-outputs-window-current1149-20261105';assert sha(C/'freeze.json')=='108d87b79f819ae7c66cc5964add88f38137084edf67c001c28b90f9a9921878'
for n,v in load(C/'freeze.json')['files'].items():assert sha(C/n)==v['sha256']
t=load(C/'terminal.json');assert t['status']=='ROOT_ORIGINAL_EMOTE_ONE_FAILURE_CLOSED'and t['all1149OldOriginalBodiesUnchanged']is t['wholeHEREAndOuterTwiceEqual']is t['ownProcessesAbsent']is True and len(t['newOriginalRoots'])==4
h=Path(t['newOriginalRoots'][0]);o=h.with_name(h.name+'-outer');assert t['newOriginalRoots'][1]==str(h/'temporary')
assert sha(h/'approved-inputs.json')=='d01527fe7cd4aebdf153d4f2851424681c9b54ddd58cdae808981261a97b9486'
raw=load(o/'terminal.json');assert raw==t['originalSupervisorTerminal']and raw['status']=='FAIL'and raw['checks']['childReturnCode']==-15 and raw['timedOut']is True and raw['forcedKill']is False
for k in('ownedProcessesAbsent','parentFDThreadKernelDrain','pinsEqual','approvedInputEqual','expectedHeadUnchanged','actualOriginalParentPorts'):assert raw['checks'][k]is True
for k in('actualChildReportPass','completeOriginalNodeLineage','quietCensusesAdmitted','allOldGlobalBodiesExact','twoCompleteGlobalCensusesEqual','twoWholeChildCensusesEqual'):assert raw['checks'][k]is False
assert(h/'child-receipts/child-result.json').read_bytes()==b''and(h/'child-receipts/actual-restoration.json').read_bytes()==b''
assert not(h/'child-receipts/actual-resources.json').exists()
stack=h/'child-logs/term-stack.log';assert stack.stat().st_size==6104 and sha(stack)=='b61a76e1dc71e091f49b18fd1c77b1eeb5aa2e4bf84e33b9785eb9fd2b0f570a'
text=stack.read_text();assert all(x in text for x in('native_feature_observation.py','emote_native_prefix.py','emote_keyed_retirement.py','emote_archive_round.py','phase_retirement_publisher.py','publish_retirement',' in cleanup'))
assert len(raw['actualObservedDescendants'])==3
ctx=load(B/'root-ios-current1149-after-chat-singlepair-context-20261105/root-context.json');old=load(ctx['globalCustody']['baseline']['path']);assert len(old)==1149 and load(o/'global-before.json')==old
assert load(o/'global-after-first.json')is load(o/'global-after-second.json')is None
one=load(C/'independent-global-after-first.json');two=load(C/'independent-global-after-second.json');assert one==two and set(one)==set(old)|{str(h/'temporary')}and all(one[n]==v for n,v in old.items())
whole=load(C/'whole-first.json');assert whole==load(C/'whole-second.json')and one[str(h/'temporary')]==whole[str(h/'temporary')]
scope=load(C/'actual-global-window-scope.json');assert scope['originalBeforeUnchanged']is scope['allOldOriginalsLiteral']is scope['missingChildLineageNeverPromoted']is True and scope['originalPostsPresent']is False and scope['independentRootPostScans']==2
absence=load(C/'actual-root-kernel-absence.json');assert absence['actualSameGroupOrSession']==[]and absence['originalResourceLedgerAvailable']is absence['originalResourceQualificationGranted']is False
for row in absence['checkedIdentities']:
 try:rawstat=Path('/proc',str(row['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(rawstat[rawstat.rfind(')')+2:].split()[19])!=row['startTicks']
terminal=dict(childReturnCode=raw['checks']['childReturnCode'],ownProcessesAbsent=True,problems=raw['problems'],timedOut=raw['timedOut'],forcedKill=raw['forcedKill'],actualSignals=raw['actualSignals'],custodyProjectionOnly=True)
refs={str(f):dict(path=str(f),sha256=sha(f))for root in map(Path,t['newOriginalRoots'])for f in sorted(root.rglob('*'))if f.is_file()and not f.is_symlink()}
OUT=B/'root-emote-b17-original-five-minute-timeout-stack-negative-results-20261105';OUT.mkdir(mode=0o700)
put(OUT,'results.json',dict(status='ROOT_RETAINED_EMOTE_B17_ORIGINAL_300_SECOND_TERM_TIMEOUT_AND_ACTUAL_PYTHON_STACK_WITH_CHILD_PROOFS_MISSING',terminal=terminal,newOriginalRoots=t['newOriginalRoots'],actualOriginalSupervisorTerminal=raw,actualOriginalChildReport=None,actualOriginalResourceReceipt=None,actualPortRestoration=None,childReportAndRestorationFilesActuallyEmpty=True,actualTermStack=dict(path=str(stack),bytes=6104,sha256=sha(stack)),actualStackCut='original native_prefix/archive/keyed retirement/phase publication chain',stackIsNotCPUTimeAttribution=True,speedOrCPUCauseConclusion=False,actualThreeNodeDiscoveriesNotCreatorLineageQualification=True,originalBeforeGlobalScanRetained=True,originalInternalPostScansAdmitted=False,rootIndependentPostGlobalScans=2,all1149OldOriginalBodiesUnchanged=True,ownTemporaryExplicitlyIncluded=True,sourceFreeze='3ee248af2b7ae6dda860c19e5e43dadea40d6f289e013033cfb36d8c0d5a46e8',originalCollectorFreeze=sha(C/'freeze.json'),pairedConsumerAdmission=None,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(OUT,'actual-receipt-references.json',refs);put(OUT,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in OUT.iterdir()}));print(json.dumps(dict(freeze=sha(OUT/'freeze.json'),results=sha(OUT/'results.json'),references=len(refs))))
