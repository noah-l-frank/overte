"""Private bounded Native bookend source-model controller; metadata/AST only."""
import ast,difflib,hashlib,json,stat
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/lifecycle-resource4-native-bookend-first3-root-preparation-20261102';STAGE=HERE/'first3';STAGE.mkdir(mode=0o700)
BASE=REPO/'.ios-host-tmp/lifecycle-resource4-released-observer-four-selected-stages-root-preparation-20261102/first1';SOURCE=REPO/'.ios-host-tmp/lifecycle-resource4-native-bookend-overall-deadline-source-proposal-20261102'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(v)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
for packet in (BASE,SOURCE):
 for name,digest in json.loads((packet/'freeze.json').read_text())['files'].items():assert sha(packet/name)==digest,(packet,name)
for name in json.loads((BASE/'freeze.json').read_text())['files']:
 if name in ('source-manifest.json','run-plan.json','prior-retained-original-pins.json','supervisor-plan.json','README.txt'):continue
 write(STAGE/name,(BASE/name).read_text())
model=SOURCE/'models/test_resource4_native_cut_bookend_models.py';write(STAGE/model.name,model.read_text())
source_plan=json.loads((SOURCE/'plan.json').read_text());plan=json.loads((BASE/'run-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_NATIVE_BOOKEND_FIRST3',cases=source_plan['models'],caseCount=3,totalCaseCount=3,initialOuterSeconds=30,expectedRetainedRoots=6)
plan['privateFiles']={p.name:sha(p) for p in sorted(STAGE.glob('*.py'))}
save(STAGE/'run-plan.json',plan)
manifest=json.loads((BASE/'source-manifest.json').read_text());rows=[];changes={row['path']:row for row in source_plan['source']}
for row in manifest['sourcePaths']:
 row=dict(row)
 if row['path'] in changes:
  candidate=SOURCE/'candidate'/row['path'];row.update(candidate=str(candidate),candidateSHA256=sha(candidate),baseSHA256=changes[row['path']]['baseSHA256'])
 row['observedPublicSHA256']=sha(REPO/row['path']);row['changesCurrentPublic']=row['observedPublicSHA256']!=row['candidateSHA256'];rows.append(row)
manifest.update(name='first3',stage='native-bookend-overall-deadline-first3',status=plan['status'],sourcePaths=rows,sourcePathCount=3,caseCount=3,pythonCaseCount=3,initialTimeoutSeconds=30,actualPublicBasis='Actual Source3 observations plus reviewed postrelease lock and NEW deadline-preserving bookend refinement; supervisor captures current full map AFTER exact Source2 publication.')
manifest['orderedParentFreezes']=dict(manifest['orderedParentFreezes']);manifest['orderedParentFreezes'][str(SOURCE.relative_to(REPO/'.ios-host-tmp'))]=sha(SOURCE/'freeze.json');save(STAGE/'source-manifest.json',manifest)
superplan=json.loads((BASE/'supervisor-plan.json').read_text());superplan['initialSeconds']=30;save(STAGE/'supervisor-plan.json',superplan)
# Preserve actual failed first1(c5)15 corpus and complete terminal/source/error
# receipts before any changed-source attempt, retaining older failures via base.
prior=json.loads((BASE/'prior-retained-original-pins.json').read_text());fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);r=dict(stat=[getattr(a,k) for k in fields])
 if stat.S_ISREG(a.st_mode):r['sha256']=sha(p)
 assert r['stat']==[getattr(p.lstat(),k) for k in fields];return r
root=BASE/'retained-first';expected=json.loads((BASE/'root-run-first/originals-first.json').read_text());actual={str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))};assert actual==expected
for name,row in actual.items():prior[str(root/name)]=row
for path in (BASE/'root-run-first').glob('*'):
 if path.is_file():prior[str(path)]=pin(path)
for pattern in ('case-cleanup-*/*.json','actual-source-raise*','terminal-census-*.json','created-original-roots.json','baseline-fds-first.json'):
 for path in BASE.glob(pattern):
  if path.is_file():prior[str(path)]=pin(path)
save(STAGE/'prior-retained-original-pins.json',prior)
for path in STAGE.glob('*.py'):ast.parse(path.read_bytes(),filename=str(path))
write(STAGE/'README.txt','PRIVATE UNRUN first3 NEW Source2 refinement: positive actual anchor/source/ref/frame coordinates +real1.55s delayedanchor beforeDown andafterDown cases. Original first30+kill5/6realTD, no cap/250ms/1.5s change. Receiver77e08b83, resourcefb249bcc, runtime55f243ae required BEFORE import. Corrected explicit ignored dependencies, pre-importSDK/path/loopback/zero-subprocess, actual per-case standardRunner.close andtwoFD/task/thread/child/originalcensuses remain unchanged. No source/callback replacement in implementation; models only inject explicit historical latency or observe actual anchor returns, no new clocks/native outcome. All previous failed15/16/18 plus c5first15/actualtimelines/maps/raw originals preserved.\n')
save(STAGE/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(STAGE)):sha(p) for p in sorted(STAGE.rglob('*')) if p.is_file() and p.name!='freeze.json'}))
write(HERE/'launcher-only.diff',''.join(difflib.unified_diff((BASE/'root-supervise.py').read_text().splitlines(True),(STAGE/'root-supervise.py').read_text().splitlines(True),fromfile='corrected/root-supervise.py',tofile='bookend/root-supervise.py')))
save(HERE/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceFreeze=sha(SOURCE/'freeze.json'),stageFreeze=sha(STAGE/'freeze.json'),cases=source_plan['models'],initialSeconds=30,killAfterSeconds=5,realRoots=6,retainedRawPins=len(prior),sourcePublished=False,testsRun=False,SDKImported=False,remainingResourceStages='HARDHOLD until actual newfirst3 and changed first1 pass; Root must clone old remaining stages with exact Source2 candidates and new stopped originals before their maps.'))
save(HERE/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'},stageFreeze=sha(STAGE/'freeze.json')))
print(json.dumps(dict(packet=str(HERE),freeze=sha(HERE/'freeze.json'),stageFreeze=sha(STAGE/'freeze.json'),retainedPins=len(prior))))
