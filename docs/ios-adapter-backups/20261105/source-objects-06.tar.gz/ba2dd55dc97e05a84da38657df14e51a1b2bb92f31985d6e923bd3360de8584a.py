"""Creator-bound original lifetime observations across a canonical binary hash.

Missing/terminal rows retain receipts only. No process discovery, wait/reap,
new signal authority, binary-result cache or terminal-to-absence conversion.
"""
from pathlib import Path
import kernel


def original_birth(value):
    assert type(value)is dict and set(value)=={'pid','parent','group','session','startTicks'}
    assert all(type(x)is int and x>0 for x in value.values())
    return value


def observe_binary(original,binary,pin,diagnostic):
    original_birth(original)
    assert type(binary)is dict and set(binary)=={'path','pin'}and type(diagnostic)is dict
    # Diagnostic state never becomes birth or signal authority. Each invocation
    # freshly observes the actual original identity, even after a prior exit.
    diagnostic['calls']=diagnostic.get('calls',0)+1
    first=kernel.observe(original['pid'],expected=original);diagnostic['beforeHash']=first
    diagnostic['afterHash']=None;diagnostic['actualBinaryPin']=None
    if first['kind']in('MISSING','PRESENT_TERMINAL'):
        diagnostic['kind']=first['kind'];return first
    assert first['kind']=='PRESENT_LIVE'and first['executable']==binary['path'],('Original owned executable mismatch',original,first)
    actual=pin(Path(first['executable']));diagnostic['actualBinaryPin']=actual
    assert actual==binary['pin'],('Original canonical executable pin changed',binary,actual)
    last=kernel.observe(original['pid'],expected=original);diagnostic['afterHash']=last
    assert last['kind']in('MISSING','PRESENT_TERMINAL','PRESENT_LIVE')
    if last['kind']=='PRESENT_LIVE':assert last['executable']==binary['path'],('Original live executable changed after hash',original,last)
    diagnostic['kind']=last['kind']
    # A natural original exit during hashing is neither a failed binary match
    # nor current executable/absence authority. The original creator must still
    # provide its return/stream cleanup, and final stat absence is separate.
    return last


def signal_candidate(original,binary,pin,diagnostic):
    observed=observe_binary(original,binary,pin,diagnostic)
    if observed['kind']in('MISSING','PRESENT_TERMINAL'):return False
    # Preserve original known-birth signal scope, including exact SID. This
    # stat→kill boundary is not claimed atomic or a new pidfd qualification.
    current=kernel._sample(original['pid']);diagnostic['immediateSignalSample']=current
    if current is None:return False
    kernel._expected(current['identity'],original,None,None)
    if current['state']=='Z':return False
    assert current['state']in('R','S','D','T','t','I','W','P'),'Unknown process state has no signal authority'
    return True
