"""Deterministic run/record-start cue; sample indices never imply ADC age.

This is input fixture PCM and derived pattern structure only. Native input
ownership, actual continuous capture origins, cue-before-Primary input and
separate two-copy/quiet evidence remain mandatory external joins.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import array
import bisect
import hashlib
import io
import math
import sys
import wave
from adapters.native_feature_observation import integer,need
from ios.adapters.audio_passive_capture_source import hex32

VERSION=1
RATE=24000
FREQUENCIES=(800,1100,1400,1700,2000,2300,2600,2900)
SYMBOLS=43
LEAD=.06
TONE=.04
CELL=.05
DURATION=LEAD*2+SYMBOLS*CELL
WINDOW=.01
HOP=.005


def input_id(run,ticket,kind):
    need(hex32(run) and hex32(ticket) and kind in ('cue','pattern'))
    return hashlib.sha256(('ios-audio-once-'+kind+'-v1:'+run+':'+ticket).encode('ascii')).hexdigest()[:32]


def cue_id(run,ticket):return input_id(run,ticket,'cue')


def symbols(run,ticket):
    # All128 challenge bits, followed by one explicit zero pad, are represented.
    # No short truncated frequency code substitutes for the run/ticket binding.
    bits=bin(int(cue_id(run,ticket),16))[2:].zfill(128)+'0'
    return [int(bits[index:index+3],2) for index in range(0,129,3)]


def samples(run,ticket,*,rate=RATE):
    need(rate in (8000,16000,24000,44100,48000));out=array.array('h',[0])*round(DURATION*rate)
    for index,symbol in enumerate(symbols(run,ticket)):
        start=round((LEAD+index*CELL)*rate);count=round(TONE*rate);ramp=max(1,round(.004*rate))
        for n in range(count):
            envelope=min(1.,n/ramp,(count-n-1)/ramp)
            out[start+n]=round(.15*32767*envelope*math.sin(2*math.pi*FREQUENCIES[symbol]*n/rate))
    return out


def pcm_bytes(run,ticket):
    value=samples(run,ticket)
    if sys.byteorder!='little':value.byteswap()
    return value.tobytes()


def wav_bytes(run,ticket):
    stream=io.BytesIO()
    with wave.open(stream,'wb') as output:
        output.setparams((1,2,RATE,0,'NONE','not compressed'));output.writeframes(pcm_bytes(run,ticket))
    return stream.getvalue()


def features(pcm,rate):
    need(isinstance(pcm,array.array) and pcm.typecode=='h' and integer(rate,8000,48000))
    step=max(1,rate//8000);data=pcm[::step];effective=rate/step
    size,hop=round(WINDOW*effective),round(HOP*effective)
    coefficients=[2*math.cos(2*math.pi*f/effective) for f in FREQUENCIES];rows=[]
    for start in range(0,len(data)-size+1,hop):
        block=data[start:start+size];mean=sum(block)/size;block=[x-mean for x in block];energy=sum(x*x for x in block);label=None
        if energy/size>=(32767*10**(-50/20))**2:
            powers=[]
            for coefficient in coefficients:
                previous=older=0.
                for value in block:
                    current=value+coefficient*previous-older;older,previous=previous,current
                powers.append(previous*previous+older*older-coefficient*previous*older)
            best=max(range(len(powers)),key=powers.__getitem__)
            if 2*powers[best]/(size*energy)>=.55:label=best
        rows.append(((start+size/2)/effective,label))
    return rows


def analyze_channels(channels,rate,run,ticket):
    """One complete cue occurrence, independently on each detecting channel.

    No clock or product effect is returned. Keep the original whole WAV/native
    capture elsewhere; these frame indices are derived proof only.
    """
    need(type(channels) is list and 1<=len(channels)<=2 and integer(rate,8000,48000)
        and all(isinstance(c,array.array) and c.typecode=='h' and len(c)==len(channels[0]) for c in channels)
        and rate*6<=len(channels[0])<=rate*10)
    expected=symbols(run,ticket);matches=[]
    for channel,pcm in enumerate(channels):
        rows=features(pcm,rate);times=[row[0] for row in rows];labels=[row[1] for row in rows];candidates=[]
        for timestamp,_label in rows:
            offset=timestamp-WINDOW/2
            # Match the first tone, while retaining a complete input-cue window
            # including both actual leading and trailing quiet margins.
            start=offset-LEAD
            if start<0 or start+DURATION>len(pcm)/rate:continue
            coverage=[]
            for index,symbol in enumerate(expected):
                low=offset+index*CELL+WINDOW;high=offset+index*CELL+TONE-WINDOW
                a=bisect.bisect_left(times,low-1e-6);b=bisect.bisect_right(times,high+1e-6);part=labels[a:b]
                coverage.append(sum(value==symbol for value in part)/max(1,len(part)))
            if min(coverage)>=.65 and sum(coverage)/SYMBOLS>=.85:
                candidates.append((start,min(coverage),sum(coverage)/SYMBOLS))
        groups=[]
        for row in candidates:
            if groups and row[0]-groups[-1][-1][0]<.05:groups[-1].append(row)
            else:groups.append([row])
        for group in groups:
            first=max(group,key=lambda row:(row[1],row[2],-row[0]));start=round(first[0]*rate);end=start+round(DURATION*rate)
            fragment=pcm[start:end]
            if sys.byteorder!='little':fragment.byteswap()
            matches.append(dict(channel=channel,startFrame=start,endFrame=end,minCoverage=first[1],meanCoverage=first[2],
                originalFragmentSha256=hashlib.sha256(fragment.tobytes()).hexdigest()))
    # Stereo channels may carry the same one physical cue. A separate cue on
    # either channel is ambiguous, rather than a favorable channel selection.
    need(matches)
    earliest=min(row['startFrame'] for row in matches);latest=max(row['startFrame'] for row in matches)
    need(latest-earliest<=round(.05*rate) and len(matches)==len({row['channel'] for row in matches}))
    return dict(iosAudioOnceCueSignalVersion=VERSION,runId=run,ticket=ticket,cueId=cue_id(run,ticket),
        sampleRate=rate,matches=matches,expectedNativeInputPCMSha256=hashlib.sha256(pcm_bytes(run,ticket)).hexdigest(),
        physicalADCQualified=False,acousticQualified=False,peerQualified=False,wholeQualified=False)


def input_wav(run,ticket,kind):
    need(kind in ('cue','pattern'));input_id(run,ticket,kind)
    if kind=='cue':return wav_bytes(run,ticket)
    # Existing preview challenge fixture remains literal, emitted once through
    # its separate native input claim instead of a reusable generic sound ACK.
    from feature_journeys.fixtures import wav_bytes as pattern_wav
    return pattern_wav(run,ticket,profile='recorded-preview-v1')


def input_pcm(run,ticket,kind):
    with wave.open(io.BytesIO(input_wav(run,ticket,kind)),'rb') as source:
        need(source.getparams()[:3]==(1,2,RATE));return source.readframes(source.getnframes())
