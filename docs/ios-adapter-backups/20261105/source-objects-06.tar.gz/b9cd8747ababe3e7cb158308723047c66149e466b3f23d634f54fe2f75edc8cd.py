"""Exact current parser projections; no original/native/owner result cache."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextvars import ContextVar
from types import ModuleType
import importlib,unittest
from ios.adapters import chat_archive_round as current
from ios.self_tests.chat_source15_module_signature_literal import literal_module_signature


def reader(value=None):return value
def alternate(value=None):return (value,)


class Base:
    def read(self):return True


class OtherBase:
    def read(self):return False


class Reader(Base):
    def own(self):return None
    static=staticmethod(reader)
    @classmethod
    def class_read(cls):return cls
    @property
    def property_read(self):return True


class SubInt(int):pass
class SubString(str):pass
class SubFloat(float):pass
class SubTuple(tuple):pass
class SubFrozen(frozenset):pass
class SubModule(ModuleType):pass


class Meta(type):
    observations=[]
    def __getattribute__(self,name):
        if name in ('__mro__','__dict__'):Meta.observations.append(name)
        return type.__getattribute__(self,name)


class MetaReader(metaclass=Meta):
    def read(self):return None


class ClassProbe:
    def __init__(self):self.calls=0
    @property
    def __class__(self):
        self.calls+=1
        from types import FunctionType
        return FunctionType


class EqualityMeta(type):
    calls=0
    def __eq__(cls,other):
        EqualityMeta.calls+=1
        raise AssertionError('Type dispatch invoked a custom metaclass equality')


class OpaqueValue(metaclass=EqualityMeta):pass


class NamespaceName(str):
    calls=0
    def isupper(self):
        NamespaceName.calls+=1
        return str.isupper(self)


class ChatCurrentModuleSignatureTests(unittest.TestCase):
    def same_projection(self,namespace):
        literal=literal_module_signature(namespace)
        actual=current.module_signature(namespace)
        self.assertEqual(literal,actual)
        return actual

    def test_exact_builtin_values_keep_the_complete_source15_projection_and_int_bool_types(self):
        namespace=dict(FUNCTION=reader,CLASS=Reader,MODULE=ModuleType('actual-projection-module'),
            CONTEXT=ContextVar('module-projection',default=None),TEXT='value',INTEGER=1,BOOLEAN=True,
            FLOAT=1.25,NONE=None,TUPLE=('value',1),FROZEN=frozenset(('value',)),
            DICT={'ignored-by-generic':True},LIST=[1],SET={1},BYTES=b'unchanged',ARRAY=bytearray(b'unchanged'),
            lowercase=1)
        result=self.same_projection(namespace);rows={row[0]:row for row in result}
        self.assertIs(type(rows['INTEGER'][1]),int);self.assertIs(type(rows['BOOLEAN'][1]),bool)
        for name in ('DICT','LIST','SET','BYTES','ARRAY','lowercase'):self.assertNotIn(name,rows)

    def test_subclasses_and_custom_metaclass_keep_literal_fallback_and_its_actual_callbacks(self):
        namespace=dict(INTEGER=SubInt(1),TEXT=SubString('one'),FLOAT=SubFloat(1.5),
            TUPLE=SubTuple((1,2)),FROZEN=SubFrozen((1,2)),MODULE=SubModule('submodule'),CLASS=MetaReader)
        Meta.observations=[];literal=literal_module_signature(namespace);calls=list(Meta.observations)
        self.assertTrue(calls)
        Meta.observations=[];actual=current.module_signature(namespace)
        self.assertEqual(literal,actual);self.assertEqual(calls,Meta.observations)

    def test_spoofed_class_instance_checks_still_run_the_identical_literal_fallback(self):
        probe=ClassProbe();namespace={'PROBE':probe}
        literal=literal_module_signature(namespace);calls=probe.calls;self.assertGreater(calls,0)
        probe.calls=0;actual=current.module_signature(namespace)
        self.assertEqual(literal,actual);self.assertEqual(calls,probe.calls)
        observed=0
        for value in (None,1,True,1.25,'text',(1,),frozenset((1,)),
                ModuleType('key-module'),ContextVar('key-context'),Reader,reader,{},[],set(),b'bytes',bytearray(b'array')):
            namespace={NamespaceName('EXOTIC'):value}
            NamespaceName.calls=0;literal=literal_module_signature(namespace);calls=NamespaceName.calls
            observed+=calls;NamespaceName.calls=0
            self.assertEqual(literal,current.module_signature(namespace));self.assertEqual(calls,NamespaceName.calls)
        self.assertGreater(observed,0)

    def test_type_dispatch_adds_no_custom_metaclass_equality_callback(self):
        EqualityMeta.calls=0
        self.assertEqual((),self.same_projection({'OPAQUE':OpaqueValue()}))
        self.assertEqual(0,EqualityMeta.calls)

    def test_new_member_and_existing_ignored_value_becoming_a_reader_are_observed_fresh(self):
        namespace={'lowercase':None};before=self.same_projection(namespace)
        namespace['lowercase']=reader;after=self.same_projection(namespace);self.assertNotEqual(before,after)
        namespace['new_reader']=alternate;added=self.same_projection(namespace);self.assertNotEqual(after,added)
        del namespace['new_reader'];namespace['lowercase']=None;self.assertEqual(before,self.same_projection(namespace))

    def test_same_class_method_code_and_complete_mro_are_read_again_on_the_next_projection(self):
        namespace={'CLASS':Reader};before=self.same_projection(namespace)
        function=Reader.own;original=function.__code__;bases=Reader.__bases__
        try:
            function.__code__=alternate.__code__;changed=self.same_projection(namespace);self.assertNotEqual(before,changed)
            function.__code__=original;Reader.__bases__=(OtherBase,)
            changed=self.same_projection(namespace);self.assertNotEqual(before,changed)
        finally:Reader.__bases__=bases;function.__code__=original
        self.assertEqual(before,self.same_projection(namespace))

    def test_function_alias_metadata_and_module_identity_are_reopened_without_a_memo(self):
        namespace={'A':reader,'B':reader,'MODULE':ModuleType('identity-one')}
        before=self.same_projection(namespace)
        try:
            reader.__self__=object();changed=self.same_projection(namespace);self.assertNotEqual(before,changed)
        finally:del reader.__self__
        self.assertEqual(before,self.same_projection(namespace))
        try:
            reader.__func__=alternate
            changed=self.same_projection(namespace);self.assertNotEqual(before,changed)
        finally:del reader.__func__
        self.assertEqual(before,self.same_projection(namespace))
        namespace['MODULE']=ModuleType('identity-one');self.assertNotEqual(before,self.same_projection(namespace))

    def test_current_original_methods_still_detects_referenced_real_parser_value_change(self):
        for name in current._MODULES:importlib.import_module(name)
        from adapters import native_feature_observation
        self.assertTrue(current.original_methods())
        original=native_feature_observation.LIMIT
        try:
            native_feature_observation.LIMIT=original+1
            self.assertFalse(current.original_methods())
        finally:native_feature_observation.LIMIT=original
        self.assertTrue(current.original_methods())


if __name__=='__main__':unittest.main()
