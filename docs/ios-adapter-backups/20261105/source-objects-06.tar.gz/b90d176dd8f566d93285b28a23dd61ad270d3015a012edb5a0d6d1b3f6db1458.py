"""Seal private source candidates and explicit no-build qualification plan."""
import ast,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name,value):(HERE/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
manifest=json.loads((HERE/'candidate-manifest.json').read_text())
owner='tests/device/ios/adapters/tablet_web_aggregate_root.py'
before=ast.parse((ROOT/owner).read_text());after=ast.parse((HERE/'candidate'/owner).read_text())
old=next(n for n in ast.walk(before) if isinstance(n,ast.ClassDef) and n.name=='TabletWebAggregateRoot')
new=next(n for n in ast.walk(after) if isinstance(n,ast.ClassDef) and n.name=='TabletWebAggregateRoot')
oldbody=next(n for n in old.body if isinstance(n,ast.FunctionDef) and n.name=='_parent_guard').body
newbody=next(n for n in new.body if isinstance(n,ast.FunctionDef) and n.name=='_parent_guard_literal').body
assert [ast.dump(n,include_attributes=False) for n in oldbody]==[ast.dump(n,include_attributes=False) for n in newbody]
test='tests/device/ios/self_tests/test_ios_tablet_web_parent_guard_cache.py'
tree=ast.parse((HERE/'candidate'/test).read_text())
cases=['ios.self_tests.test_ios_tablet_web_parent_guard_cache.'+node.name+'.'+method.name
    for node in tree.body if isinstance(node,ast.ClassDef)
    for method in node.body if isinstance(method,ast.FunctionDef) and method.name.startswith('test_')]
assert len(cases)==len(set(cases))==5
dependencies=['tests/device/ios/adapters/avatar_record_cache.py','tests/device/ios/adapters/tablet_web_record_cache.py',
    'tests/device/ios/adapters/tablet_web_child_rotation.py','tests/device/ios/adapters/tablet_web_rotation_fence.py',
    'tests/device/adapters/normal_feature_state.py','tests/device/adapters/original_file_reads.py',
    'tests/device/adapters/original_frame_store.py','tests/device/adapters/script_feature/lock.py',
    'tests/device/ios/self_tests/test_ios_tablet_web_aggregate_root.py',
    'tests/device/ios/self_tests/test_ios_tablet_web_child_rotation.py',
    'tests/device/ios/self_tests/test_ios_tablet_web_source_owner.py',
    'tests/device/ios/self_tests/tablet_web_fresh_echo_boundary.py',
    'tests/device/ios/self_tests/tablet_web_history_fixture.py','tests/device/ios/self_tests/tablet_web_echo_fixture.py']
save('source-provenance.json',dict(status='PRIVATE_AST_ONLY_UNRUN',worktree=str(ROOT),
    candidatePaths=manifest,literalParentGuardBodyAstUnchanged=True,
    dependencies={path:sha(ROOT/path) for path in dependencies},
    baselineProfile='.ios-host-tmp/tablet-owned-root328-path-and-output-readonly-profile-preparation-20261028/runs/first-w9ued1e4',
    baseline328Immutable=True,publicWrites=False,targetImports=False,testsExecuted=False))
save('test-plan.json',dict(status='UNRUN_REQUIRES_ROOT_REVIEW_PUBLICATION_AND_GRANT',
    target5=dict(ids=cases,expectedCaseCount=5,outerSeconds=300,killAfterSeconds=5,expectedRetainedRoots=7,
        temporaryDirectoryAliases=[dict(module='ios.self_tests.test_ios_tablet_web_source_owner',attribute='tempfile',
            replacement='module-local namespace with only real retained TemporaryDirectory',expectedRoots=5),
            dict(module='ios.self_tests.test_ios_tablet_web_parent_guard_cache',attribute='TemporaryDirectory',
                replacement='direct module alias of real retained TemporaryDirectory',expectedRoots=2)],
        producer='actual generated host JS and real files; modeled native/UIKit callbacks',
        observer='existing local sys.monitoring OriginalProcessObserver before target imports; no global PY_START/PY_RETURN',
        requirements=['Root actual broad source+importable canonical3 map AFTER publication; include main.cpp, interface/CMakeLists.txt, root CMakeLists.txt',
            'Keep all current prior original roots/reports, especially328/221/150 and the failed/read-only profile prework outputs',
            'Exact rg metadata argv only; preserve immediate full exception chain and original raw logs',
            'Real Popen PID/startticks/PGID-SID; original returncode and stdin/out/err.closed observed, no invented owner-close count',
            'Thread baseline before imports; doCleanups retains real roots; process absence BEFORE both original poststop censuses']),
    following328=dict(status='SEPARATE_NOT_STARTED',outerSeconds=60,killAfterSeconds=5,innerOriginalAPISeconds=60,
        cloneOnly='.ios-host-tmp/tablet-owned-root328-path-and-output-readonly-profile-preparation-20261028/',
        body='profile-saved-once.py same supported historical constructor/history; only output/preparation references may change',
        currentSourceMap='Root refresh after publication, including new helper and test Source; all broad membership remains pinned',
        corpus='same original328 independently scoped before inputs, held original Source lock, no native/SDK/status/input callback or writer',
        expectedHistoricalFrames=11,expectedActualOriginalPaths=233,
        measuredBaseline=dict(parentSeconds=22.954,innerSeconds=20.945,constructorSeconds=16.803,historySeconds=4.039),
        qualifyOnlyActualRun=True,wholeQualified=False,nativeQualified=False,
        forbidden=['unchanged600 Sample retry','new caps','new Source budgets','mutable WAL exclusion','refresh changed pins','new independent file cache'])) )
(HERE/'ROOT-REVIEW.txt').write_text('''PRIVATE / AST ONLY / ALL FIVE CASES UNRUN

Goal: reduce the actual 2,564 complete immutable Source3 parent-guard replays
without moving or caching the mutable Root4/child WAL checks. The existing
TabletRecordCache and AvatarRecordCache implementations remain byte-identical.
The complete original _parent_guard body is retained verbatim as
_parent_guard_literal (AST equivalence checked). No active cache => old body.

Only an exact owned Root4, exact existing operation cache and exact original
literal method may memoize. Unknown parser aliases/code/defaults or unsupported
key/default shape falls back to that actual old body. Each hit checks the same
actual private directories and immutable original signatures and restores their
read membership through AvatarRecordCache. Current expected context, parent,
legacy, original parent signature/hash and codec policies form a detached key;
context/lock/header/epoch checks surround each use. No live outcome is cached.

The existing primitive cold-decodes twice and compares complete membership,
signatures and results. Every hit checks both original signature inventories.
Changed original pins fail; no catch/refresh/retry is added. Namespace membership
outside the actual leaf proof remains guarded by the existing caller histories'
EmoteOriginalLease exactly as before. Root4 and active child WAL reads remain
in bound/_bound and aggregate_epoch, outside this cache and unchanged.

Five real-fixture cases: literal two-decode vs warm zero-decode/membership then
two actual nine-query appends and historical reads in the SAME scope; new inode
with same canonical bytes (old inode retained externally); same inode with
changed bytes (original bytes retained externally); independent active child
and Root4 WAL refusal; wrong expected memory and actual in-place parser code
change refuse. Monitoring is LOCAL on the actual closed.decode code object;
no decoder replacement masks the positive cache path.

No speed/whole/native/device claim exists. First run target5 (300+5), then one
separate same-supported-readonly328 profile (60+5/old innerAPI60) only after Root
review and explicit grant. The prior 600-second full sample timeouts remain
unqualified. Retain all prior original corpora and failed attempts.

Rejected earlier whole-decode same-invocation shortcut remains private in its
separate draft directory. Its stdlib-dependency hole makes it unsuitable for
publication. No micro regex/comparator optimization is included here.
''')
for path,row in manifest.items():
    current=ROOT/path
    assert (sha(current) if current.exists() else None)==row['baseSha256'],path
    assert sha(HERE/'candidate'/path)==row['candidateSha256'],path
    text=(HERE/'candidate'/path).read_text();assert text.endswith('\n') and not text.endswith('\n\n')
    assert all(line.rstrip()==line for line in text.splitlines())
files={str(path.relative_to(HERE)):sha(path) for path in sorted(HERE.rglob('*')) if path.is_file() and path.name!='freeze.json'}
save('freeze.json',dict(status='FROZEN_PRIVATE_UNRUN',files=files))
print(json.dumps(dict(freezeSha256=sha(HERE/'freeze.json'),caseCount=len(cases),paths=manifest),indent=2))
