"""Exact declared module origins; genuine interpreter fallback only.

This module imports no project/Pillow/SDK source. All origin pins must already
be in Root's approved input before a project or external module executes.
"""
from pathlib import Path
from types import ModuleType
import importlib.machinery as machinery
import importlib.util as util
import os
import sys


class ClosedOrigins:
    def __init__(self, plan, source, repo, pin):
        self.plan, self.source, self.repo, self.pin = plan, source, repo, pin
        self.projects = plan['modules']
        self.third = plan['thirdPartyModules']
        self.project_namespaces = plan['namespacePackages']
        self.third_namespaces = plan['thirdPartyNamespacePackages']
        self.std_namespaces = plan['stdlibNamespacePackages']
        self.std = tuple(Path(value) for value in plan['stdlibRoots'])
        # os is a genuine already bootstrapped interpreter module. Its actual
        # source location is used, not sysconfig's unrelated /usr/local prefix.
        actual_std = Path(vars(os)['__file__']).resolve(strict=True).parent
        assert self.std == (actual_std,)
        assert actual_std.is_dir() and not self.excluded(actual_std)
        self.python = Path(sys.executable).resolve(strict=True)
        assert str(self.python) == plan['pythonExecutable']['path']
        assert self.pin(self.python) == plan['pythonExecutable']['pin'] == plan['physicalPins'][str(self.python)]
        assert not set(self.projects).intersection(self.third)
        assert not set(self.project_namespaces).intersection(self.third_namespaces)
        self.admissions = {}
        self.observed_files = {}
        self.observed_namespaces = {}
        self.snapshot_count = 0
        self.source_class = machinery.SourceFileLoader
        self.extension_class = machinery.ExtensionFileLoader
        self.path_finder = machinery.PathFinder
        self.builtin = machinery.BuiltinImporter
        self.frozen = machinery.FrozenImporter
        self.initial_modules = dict(sys.modules)
        self.snapshot('before-project-imports')

    @staticmethod
    def excluded(path):
        return any(part in ('site-packages', 'dist-packages') for part in path.parts)

    def physical(self, raw):
        path = Path(raw)
        assert path.is_absolute() and path.resolve(strict=True) == path
        expected = self.plan['physicalPins'].get(str(path))
        assert expected is not None, 'Module origin not independently pinned before import: ' + str(path)
        actual = self.pin(path)
        assert actual == expected
        if str(path) in self.observed_files:
            assert self.observed_files[str(path)] == actual
        else:
            self.observed_files[str(path)] = actual
        return path

    def namespaces(self, name, raw_roots, expected, kind):
        assert type(raw_roots) in (list, tuple) and raw_roots
        # Resolve each actual and each separately declared root exactly once.
        actual = tuple(Path(raw).resolve(strict=True) for raw in raw_roots)
        declared = tuple(Path(raw).resolve(strict=True) for raw in expected)
        assert actual == declared and len(set(actual)) == len(actual)
        if kind == 'stdlib':
            assert all(any(real.is_relative_to(root) for root in self.std)
                and not self.excluded(real) for real in actual)
        else:
            assert all(real.is_dir() for real in actual)
        value = dict(kind=kind, roots=[str(real) for real in actual])
        if name in self.observed_namespaces:
            assert self.observed_namespaces[name] == value
        else:
            self.observed_namespaces[name] = value
        return value

    def genuine_special(self, spec):
        assert spec is not None
        if spec.origin == 'built-in':
            actual = self.builtin.find_spec(spec.name)
            assert spec.loader is self.builtin and actual is not None and actual.origin == 'built-in'
            return 'builtin'
        if spec.origin == 'frozen':
            actual = self.frozen.find_spec(spec.name)
            assert spec.loader is self.frozen and actual is not None and actual.origin == 'frozen'
            return 'frozen'
        raise AssertionError('Not a genuine interpreter module')

    def source_row(self, name, module, row, kind):
        namespace = vars(module)
        assert namespace.get('__file__') is not None
        actual = self.physical(namespace['__file__'])
        assert actual == Path(row['path'])
        assert self.plan['physicalPins'][str(actual)]['sha256'] == row['sha256']
        return dict(kind=kind, origin=str(actual), pin=self.plan['physicalPins'][str(actual)])

    def project_loaded(self, name, module, row):
        assert self.projects.get(name) == row
        self.admissions[name] = self.source_row(name, module, row, 'project')

    def file_spec(self, name, row, kind):
        path = self.physical(row['path'])
        assert self.plan['physicalPins'][str(path)]['sha256'] == row['sha256']
        if row['loader'] == 'extension':
            original = self.extension_class(name, str(path))
        else:
            assert row['loader'] == 'source' and path.suffix == '.py'
            original = self.source_class(name, str(path))
        loader = PinnedDelegate(self, name, original, row, kind)
        locations = [str(path.parent)] if row['package'] else None
        return util.spec_from_file_location(name, str(path), loader=loader,
            submodule_search_locations=locations)

    def remaining_spec(self, name, search):
        if name in self.third:
            return self.file_spec(name, self.third[name], 'third-party')
        if name in self.third_namespaces:
            roots = self.third_namespaces[name]
            self.namespaces(name, roots, roots, 'third-party')
            spec = machinery.ModuleSpec(name, None, is_package=True)
            spec.submodule_search_locations = roots
            return spec
        spec = self.builtin.find_spec(name)
        if spec is None:
            spec = self.frozen.find_spec(name)
        if spec is not None:
            self.genuine_special(spec)
            assert self.pin(self.python) == self.plan['pythonExecutable']['pin']
            return spec
        spec = self.path_finder.find_spec(name, search)
        assert spec is not None, 'Undeclared import: ' + name
        if spec.origin is None:
            expected = self.std_namespaces.get(name)
            assert expected is not None, 'Undeclared namespace import: ' + name
            roots = tuple(spec.submodule_search_locations or ())
            self.namespaces(name, roots, expected, 'stdlib')
            return spec
        real = Path(spec.origin).resolve(strict=True)
        assert any(real.is_relative_to(root) for root in self.std) and not self.excluded(real), 'Undeclared non-stdlib import: ' + name
        self.physical(real)
        assert type(spec.loader) in (self.source_class, self.extension_class)
        row = dict(path=str(real), sha256=self.plan['physicalPins'][str(real)]['sha256'],
            package=spec.submodule_search_locations is not None,
            loader='extension' if type(spec.loader) is self.extension_class else 'source')
        return self.file_spec(name, row, 'stdlib')

    def snapshot(self, phase):
        # The genuinely bootstrapped module receivers are independently held.
        # An authentic importer spec does not authorize a replacement module.
        for name, original in self.initial_modules.items():
            if original is not None:
                assert sys.modules.get(name) is original, 'Initial module receiver changed: ' + name
        rows = {}
        for name, module in tuple(sys.modules.items()):
            if module is None:
                continue
            assert type(module) is ModuleType, 'Non-module sys.modules entry: ' + name
            namespace = vars(module)
            file = namespace.get('__file__')
            spec = namespace.get('__spec__')
            if name in self.projects:
                row = self.source_row(name, module, self.projects[name], 'project')
            elif name in self.third:
                row = self.source_row(name, module, self.third[name], 'third-party')
            elif spec is not None and spec.origin in ('built-in', 'frozen'):
                kind = self.genuine_special(spec)
                assert sys.modules.get(spec.name) is module
                row = dict(kind=kind, interpreter=str(self.python))
                if file is not None:
                    row['sourceRepresentation'] = str(self.physical(file))
            elif file is not None:
                actual = self.physical(file)
                if actual.parent == self.source:
                    # Only the exact already independently pinned controller
                    # modules may predate target admission.
                    assert name in self.initial_modules and self.initial_modules[name] is module
                    kind = 'controller'
                else:
                    assert any(actual.is_relative_to(root) for root in self.std) and not self.excluded(actual), 'Unaccounted loaded external origin: ' + name
                    kind = 'stdlib'
                row = dict(kind=kind, origin=str(actual), pin=self.plan['physicalPins'][str(actual)])
            else:
                assert spec is not None and spec.origin is None
                roots = tuple(spec.submodule_search_locations or ())
                if name in self.project_namespaces:
                    row = self.namespaces(name, roots, self.project_namespaces[name], 'project')
                elif name in self.third_namespaces:
                    row = self.namespaces(name, roots, self.third_namespaces[name], 'third-party')
                else:
                    assert name in self.std_namespaces, 'Unaccounted loaded namespace: ' + name
                    row = self.namespaces(name, roots, self.std_namespaces[name], 'stdlib')
            if name in self.admissions:
                assert self.admissions[name] == row
            rows[name] = row
        assert self.pin(self.python) == self.plan['pythonExecutable']['pin']
        self.snapshot_count += 1
        return dict(phase=phase, modules=rows, observedFiles=dict(self.observed_files),
            namespaces=dict(self.observed_namespaces), snapshots=self.snapshot_count)


class PinnedDelegate:
    """Delegate actual source/extension creation+execution, pinning both sides."""
    def __init__(self, guard, name, original, row, kind):
        self.guard, self.name, self.original, self.row, self.kind = guard, name, original, row, kind
        assert type(original) in (guard.source_class, guard.extension_class)
    def create_module(self, spec):
        self.guard.physical(self.row['path'])
        module = self.original.create_module(spec)
        self.guard.physical(self.row['path'])
        return module
    def exec_module(self, module):
        self.guard.physical(self.row['path'])
        # Genuine ExtensionFileLoader is used even for its create_module
        # phase above; no custom binary decoder or substitute module exists.
        self.original.exec_module(module)
        value = self.guard.source_row(self.name, module, self.row, self.kind)
        self.guard.admissions[self.name] = value
