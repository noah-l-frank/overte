"""Private Root run metadata only; no target imports or process launch on import."""
from pathlib import Path
import ast,hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(descriptor,'w') as output:
        output.write(json.dumps(value,indent=2,sort_keys=True)+'\n');output.flush();os.fsync(output.fileno())
def pin(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode),str(path)
    value={key:getattr(a,key) for key in FIELDS}
    if stat.S_ISREG(a.st_mode):value['sha256']=sha(path)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in FIELDS),str(path)
    return value

def proc(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))

def load_plan():return json.loads((HERE/'suite-plan.json').read_text())
def validate_frozen():
    own=json.loads((HERE/'freeze.json').read_text())
    for name,expected in own['files'].items():assert sha(HERE/name)==expected,name
    plan=load_plan()
    for row in plan['frozenPackets']:
        root=REPO/row['path'];assert sha(root/'freeze.json')==row['freezeSha256']
        frozen=json.loads((root/'freeze.json').read_text())
        for name,expected in frozen.get('files',frozen).items():assert sha(root/name)==expected,name
    foreign=plan['approvedPendingForeignPublication'];receipt_path=REPO/foreign['receipt']
    assert receipt_path.resolve(strict=True)==receipt_path and receipt_path.is_file(),'Actual reviewed Root publication receipt is required'
    receipt_pin=pin(receipt_path);actual_receipt=json.loads(receipt_path.read_text())
    assert actual_receipt==foreign['expectedReceipt'],'Actual foreign publication receipt differs from exact Root-approved scope'
    assert pin(receipt_path)==receipt_pin
    for row in actual_receipt['files']:assert sha(REPO/row['path'])==row['sha256'],row['path']
    for approved in plan['approvedActualPublicationReceipts']:
        receipt=REPO/approved['path'];assert receipt.resolve(strict=True)==receipt and sha(receipt)==approved['sha256']
        actual=json.loads(receipt.read_text());assert actual==approved['expectedReceipt'],'Actual reviewed publication scope changed'
        assert actual['registryChanged'] is False and actual['testsExecutedByPublication'] is False and actual['wholeFeatureFlagsUnchanged'] is True
        for row in actual['files']:assert sha(REPO/row['path'])==row['sha256'],row['path']
    validate_gpu_first_scope(plan)
    assert sha(HERE/'source-root-final-map.json')==plan['sourceRootMapSha256']
    assert sha(HERE/'expected-publication.json')==plan['expectedPublicationSha256']
    return plan

def publication():
    rows=json.loads((HERE/'expected-publication.json').read_text())
    assert len(rows)==load_plan()['expectedPublicationCount']
    for row in rows:
        path=REPO/row['path'];assert path.resolve(strict=True)==path and sha(path)==row['expectedSha256'],row['path']
    return rows

def broad_sources(plan):
    names=subprocess.check_output(['rg','--files','-0',*plan['broadSourceRoots']],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}
    paths.update(REPO/name for name in plan['explicitExtraSourcePins'])
    paths.update(REPO/name for name in plan.get('selectionConditionalExtraPins',{}).get(plan.get('activeSelection'),[]))
    assert REPO/'interface/src/main.cpp' in paths,'Explicit main.cpp pin missing'
    return paths

def sources(plan):
    paths=broad_sources(plan)
    for required in plan.get('requiredAvatarCounterSelections',[]):
        if plan.get('activeSelection') not in required['onlyForKinds']:continue
        report_path=REPO/required['report'];report=json.loads(report_path.read_text())
        assert report['kind']==required['kind'] and report['exitCode']==0
        assert report['postStopCensusesQualified'] and not report['ownedProcessesBeforeCensuses'] and not report['remainingOwnedProcesses']
        run=Path(report['runRoot']);assert run.resolve(strict=True)==run and run.is_relative_to(REPO/required['runRootParent'])
        paths.update((report_path,REPO/required['reference']))
        for path in run.iterdir():
            if path.is_file():
                assert path.resolve(strict=True)==path
                paths.add(path)
    for root in (HERE,*[REPO/row['path'] for row in plan['frozenPackets']]):
        frozen=json.loads((root/'freeze.json').read_text())
        paths.update(root/name for name in frozen.get('files',frozen));paths.add(root/'freeze.json')
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}

def originals(root):
    return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}


def registry_original():
    raw=(REPO/'tests/device/contract-versions.json').read_bytes();value=json.loads(raw)
    required=load_plan()['registryRequired']
    assert all(value['contracts'].get(key)==row for key,row in required.items()),'Previously observed Emote8/foreign registry keys changed'
    validator=REPO/'tests/device/validate_contract_versions.py';tree=ast.parse(validator.read_text())
    assignments=[node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='REQUIRED' for target in node.targets)]
    assert len(assignments)==1;actual=ast.literal_eval(assignments[0].value)
    assert all(actual[key]==row['current'] for key,row in required.items()),'Previously observed Emote8 validator versions changed'
    return dict(sha256=hashlib.sha256(raw).hexdigest(),required=required,validator=pin(validator))


def prior_originals(plan):
    actual={}
    for row in completed_prior_rows(plan):
        root=Path(row['root']);expected=json.loads((REPO/row['reference']).read_text())
        if 'referenceRootKey' in row:expected=expected[row['referenceRootKey']]
        current=originals(root);assert current==expected,row['reference']
        assert sum(stat.S_ISREG(value['st_mode']) for value in current.values())==row['files']
        actual[row['root']]=current
    for row in plan.get('additionalPriorFilePins',[]):
        path=REPO/row['path'];assert sha(path)==row['sha256']
        expected=__import__('json').loads(path.read_text());current={name:pin(REPO/name) for name in expected}
        assert current==expected,'Supplemental retained Photo/Tablet originals changed'
        actual['flat:'+row['path']]=current
    for row in plan.get('additionalRootOriginalCorpora',[]):
        root=Path(row['root']);assert root.resolve(strict=True)==root and root.is_relative_to(REPO/'.ios-host-tmp')
        reference=REPO/row['reference'];assert sha(reference)==row['referenceSha256']
        expected=json.loads(reference.read_text());current=originals(root)
        if row['schema']=='stat-list':
            fields=row['statFields'];current={name:dict(stat=[value[field] for field in fields],**({'sha256':value['sha256']} if 'sha256' in value else {})) for name,value in current.items()}
        else:assert row['schema']=='named-stat-fields'
        assert current==expected,row['label']
        assert sum('sha256' in value for value in current.values())==row['files']
        actual['root25769:'+row['label']]=current
    return actual


def completed_prior_rows(plan):
    for required in plan.get('requireActualStoppedDiagnostics',[]):
        actual=json.loads((REPO/required['report']).read_text())
        assert actual['runRoot']==required['runRoot'] and actual['originalFiles']==required['files'] and actual['exitCode']==required['exitCode']
        assert actual['allPinsEqual'] and actual['postStopOriginalCensusesEqual'] and actual['priorOriginalCensusesUnchanged'] and actual['postStopCensusesQualified']
        assert not actual['ownedProcessesBeforeCensuses'] and not actual['remainingOwnedProcesses']
        first=REPO/required['firstCensus'];second=REPO/required['secondCensus'];a=pin(first);b=pin(second)
        assert json.loads(first.read_text())==json.loads(second.read_text())
        assert a==pin(first) and b==pin(second)
        assert required['childFinalQualified'] is False  # Outer termination is not a child-final-drain PASS.
    rows=[dict(row) for row in plan['priorOriginalCorpora']]
    # A prerequisite is NOT claimed complete by this frozen plan. Require
    # its actual parent and child result before this selection can be mapped.
    for required in plan.get('requireActualCompletedSelections',[]):
        if required.get('onlyForKinds') is not None and plan.get('activeSelection') not in required['onlyForKinds']:continue
        path=REPO/required['report'];actual=json.loads(path.read_text())
        assert actual['kind']==required['kind'] and actual['exitCode']==0
        assert actual['allPinsEqual'] and actual['postStopOriginalCensusesEqual']
        assert actual['priorOriginalCensusesUnchanged'] and actual['postStopCensusesQualified']
        assert not actual['ownedProcessesBeforeCensuses'] and not actual['remainingOwnedProcesses']
        root=Path(actual['runRoot']);assert root.resolve(strict=True)==root
        assert root.is_relative_to(REPO/required['runRootParent'])
        child=json.loads((root/'selected-result.json').read_text())
        assert child['successful'] and child['testsRun']==required['count']
        assert child['caseAuditFailures']==[]
        row=dict(root=str(root/'temporary'),reference=required['reference'],files=actual['originalFiles'])
        previous=[item for item in rows if item['root']==row['root']]
        if previous:
            assert len(previous)==1,'More than one preexisting original cohort for one root'
            prior=previous[0]
            allowed={'root','files','reference','referenceRootKey'}
            assert set(prior)<=allowed and set(row)<=allowed,'Unknown repeated original cohort grammar'
            assert prior['root']==row['root'] and prior['files']==row['files'],'Conflicting repeated original cohort scope/count'
            def retained_reference(item):
                path=REPO/item['reference']
                assert path.resolve(strict=True)==path and path.is_relative_to(REPO/'.ios-host-tmp')
                before=pin(path);value=json.loads(path.read_text())
                if 'referenceRootKey' in item:
                    assert type(item['referenceRootKey']) is str and item['referenceRootKey'] in value
                    value=value[item['referenceRootKey']]
                assert pin(path)==before,'Repeated original census reference changed while reading'
                return value,before
            original,first_pin=retained_reference(prior);requested,second_pin=retained_reference(row)
            assert original==requested,'Repeated original census references differ'
            assert pin(REPO/prior['reference'])==first_pin and pin(REPO/row['reference'])==second_pin
            # Keep exactly the already-retained row, including its original
            # reference identity. Equivalence does not replace old provenance.
        else:rows.append(row)
    for required in plan.get('requiredAvatarCounterSelections',[]):
        if plan.get('activeSelection') not in required['onlyForKinds']:continue
        report=json.loads((REPO/required['report']).read_text())
        assert report['kind']==required['kind'] and report['exitCode']==0
        assert report['allPinsEqual'] and report['postStopOriginalCensusesEqual'] and report['priorOriginalCensusesUnchanged']
        assert report['postStopCensusesQualified'] and not report['ownedProcessesBeforeCensuses'] and not report['remainingOwnedProcesses']
        run=Path(report['runRoot']);assert run.resolve(strict=True)==run and run.is_relative_to(REPO/required['runRootParent'])
        child=json.loads((run/'selected-result.json').read_text())
        wanted=plan['suites'][required['kind']]['caseIds']
        assert child['successful'] and child['testsRun']==required['count'] and child['selectedIds']==wanted
        assert not child['skipped'] and not child['remainingNewThreadsBeforeCensuses'] and not child['remainingNewThreads']
        receipts=[json.loads(line) for line in (run/'case-stop-receipts.jsonl').read_text().splitlines()]
        assert [row['testId'] for row in receipts]==wanted
        assert all(row['caseSuccessful'] and row['allKnownNodeProcessesGone'] and row['allOriginalStreamsClosed'] and
            row['allObservedOriginalHostClosesCompleted'] and not row['remainingNewThreads'] for row in receipts)
        row=dict(root=str(run/'temporary'),reference=required['reference'],files=report['originalFiles'])
        previous=[item for item in rows if item['root']==row['root']]
        if previous:
            assert previous==[row],'Repeated counter cohort must retain exact original reference/count'
        else:rows.append(row)
    assert len(rows)==len({row['root'] for row in rows})
    return rows

def validate_gpu_first_scope(plan):
    required=plan['actualGPUFirstScopedReceipt'];path=REPO/required['path'];assert sha(path)==required['sha256']
    receipt=json.loads(path.read_text());assert receipt['status']=='ACTUAL_GPU_PIXEL_FIRST1_SCOPE_ONLY_FROM_FAILED_AGGREGATE2'
    assert receipt['originalAggregateSuccessful'] is False and receipt['originalParentExitCode']==1
    assert receipt['wholeCurrentSourceQualified'] is False and receipt['nativeQualified'] is False and receipt['wholeAvatarQualified'] is False
    assert receipt['newChangedTailPassRequired'] is True and receipt['qualifiedScopedFiles']==13 and receipt['originalAggregateFiles']==27
    for row in receipt['originalEvidencePins']:assert sha(REPO/row['path'])==row['sha256'],row['path']
    report=json.loads((REPO/receipt['originalReport']).read_text());run=Path(receipt['originalRunRoot'])
    assert report['runRoot']==str(run) and report['kind']=='gpuPixels2' and report['exitCode']==1 and report['originalFiles']==27
    assert all(report[key] for key in ('allPinsEqual','postStopOriginalCensusesEqual','priorOriginalCensusesUnchanged','postStopCensusesQualified'))
    assert not report['ownedProcessesBeforeCensuses'] and not report['remainingOwnedProcesses']
    child=json.loads((run/'selected-result.json').read_text());rows=[json.loads(line) for line in (run/'case-stop-receipts.jsonl').read_text().splitlines()]
    wanted=receipt['qualifiedIds']+[receipt['failedId']]
    assert child['selectedIds']==wanted and child['testsRun']==2 and child['successful'] is False and not child['skipped']
    assert not child['remainingNewThreadsBeforeCensuses'] and not child['remainingNewThreads']
    assert [row['testId'] for row in rows]==wanted and rows[0]['caseSuccessful'] is True and rows[1]['caseSuccessful'] is False
    assert all(row['allKnownNodeProcessesGone'] and row['allOriginalStreamsClosed'] and row['allObservedOriginalHostClosesCompleted'] and not row['remainingNewThreads'] for row in rows)
    assert rows[0]['newNodeCount']==rows[0]['newHostOwnerCount']==1 and child['retainedTemporaryDirectoryRoots'][:6]==receipt['scopedRoots']
    source=REPO/receipt['sourcePacket'];module=receipt['sourceModule'];before=source/'base'/module;after=source/'candidate'/module
    assert sha(source/'freeze.json')==receipt['sourceFreezeSha256'] and sha(before)==receipt['originalSourceSha256'] and sha(after)==receipt['changedTailSourceSha256']
    old=before.read_text();new=after.read_text();assert old.count("d.widgets['primary'].scale*=2")==1
    assert new==old.replace("d.widgets['primary'].scale*=2","d.widgets['primary'].scale*=1.1")
    def method(text,name):
        tree=ast.parse(text);cls=next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name=='AvatarGPUOriginalPixelLeaseTests')
        return ast.dump(next(node for node in cls.body if isinstance(node,ast.FunctionDef) and node.name==name),include_attributes=False)
    for name,expected in receipt['unchangedFirstScopeAST'].items():
        original=method(old,name);assert original==method(new,name) and hashlib.sha256(original.encode()).hexdigest()==expected
    subset=json.loads((HERE/'ACTUAL-FIRST1-ORIGINAL-CENSUS-SUBSET.json').read_text())
    census=json.loads((run/'selected-originals-second.json').read_text());names=[Path(root).name for root in receipt['scopedRoots']]
    assert subset=={key:value for key,value in census.items() if any(key==name or key.startswith(name+'/') for name in names)}
    assert sum('sha256' in row for row in subset.values())==13

