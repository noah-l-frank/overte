"""Root-only one saved-third passive diagnostic, fixed180+5; no retry."""
import hashlib,json,os,stat,subprocess,sys,time
from pathlib import Path
from guard import PREP,REPO,target,pin,census,sources,input_guard,qualified_pass
from global_original_corpus import guard as global_guard
assert sys.dont_write_bytecode
plan=json.loads((PREP/'plan.json').read_text());HERE=PREP/'first1';case=json.loads((HERE/'case.json').read_text())
assert Path.cwd()==REPO and plan['status']=='FROZEN_UNRUN_REQUIRES_ROOT_REVIEW_AND_WINDOW'
assert case['wallSeconds']==plan['wallSeconds']==180 and case['killAfterSeconds']==plan['killAfterSeconds']==5
assert case['innerAlarmSeconds']==plan['innerAlarmSeconds']==90 and plan['expectedTemporaryDirectories']==0
sources();input_guard();global_guard()
OUT=target(HERE/'run');OUT.mkdir(mode=0o700,exist_ok=False)
def save(name,value):
    path=target(OUT/name);fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def process(pid):
    try:row=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except(FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(row[1]),pgid=int(row[2]),sid=int(row[3]),startTicks=int(row[19]))
def remaining(bound):
    rows=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        row=process(int(path.name))
        if row is not None and(row['pgid']==bound['pid']or row['sid']==bound['pid']):rows.append(row)
    return rows
before=sources();inputs=input_guard();prior=global_guard();locks=json.loads((PREP/'existing-lock-pins.json').read_text())
save('source-before.json',before);save('input-before.json',inputs);save('global-before.json',prior)
map_pin=pin(PREP/'source-map.json')
assert Path(sys.executable).resolve(strict=True)==Path(plan['originalHostRuntime']['python']).resolve(strict=True),'Keep the actual C9 interpreter; never substitute a new SDK/compiler/runtime origin'
command=[plan['originalHostRuntime']['timeout'],'--signal=TERM','--kill-after=5s','180s',plan['originalHostRuntime']['python'],'-B',str(PREP/'run-selected.py')]
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',EMOTE_SAVED_THIRD_STAGE=str(HERE))
started=time.monotonic()
with target(OUT/'test.log').open('x')as log:
    task=subprocess.Popen(command,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    bound=process(task.pid);assert bound is not None and bound['pgid']==bound['sid']==task.pid
    save('process-binding.json',dict(task=bound,supervisor=process(os.getpid()),command=command));code=task.wait()
assert not remaining(bound),'Owned process present: original census prohibited'
after=sources();save('source-after.json',after)
first_input=input_guard();save('input-first.json',first_input)
first_global=global_guard();save('global-first.json',first_global)
output_roots=[path for path in(HERE/'diagnostic',HERE/'cleanup',HERE/'selected-result.json')if path.exists()]
first_output=census(output_roots);save('output-first.json',first_output)
assert not remaining(bound)
second_input=input_guard();save('input-second.json',second_input)
second_global=global_guard();save('global-second.json',second_global)
second_output=census(output_roots);save('output-second.json',second_output)
lock_after={name:pin(name)for name in locks};save('existing-locks-after.json',lock_after)
value=dict(exitCode=code,seconds=time.monotonic()-started,sourcePins=len(before),allPinsEqual=before==after,
    inputOriginalsUnchanged=inputs==first_input==second_input,inputOriginalFiles=sum('sha256'in row for row in second_input.values()),
    existingLockInodesUnchanged=locks==lock_after,diagnosticOutputUnchanged=first_output==second_output,
    outputFiles=sum('sha256'in row for row in second_output.values()),
    diagnosticFiles=sum('sha256'in row for row in census([HERE/'diagnostic']).values())if(HERE/'diagnostic').exists()else 0,globalOriginalsUnchanged=prior==first_global==second_global,
    globalOriginalRoots=len(prior),rootMapUnchanged=pin(PREP/'source-map.json')==map_pin,remainingOwnedProcesses=remaining(bound),
    newTemporaryDirectories=0,nativeQualified=False,wholeFeatureQualified=False)
save('report.json',value)
assert before==after and inputs==first_input==second_input and locks==lock_after and first_output==second_output
assert prior==first_global==second_global and not remaining(bound)and value['rootMapUnchanged']
if code==0:
    qualified_pass(HERE)
    save('qualified-pass.json',dict(status='QUALIFIED_PASSIVE_HISTORICAL_DIAGNOSTIC_ONLY',reportSha256=hashlib.sha256((OUT/'report.json').read_bytes()).hexdigest(),
        nativeQualified=False,wholeFeatureQualified=False,windowRetryAuthorized=False))
raise SystemExit(code)
