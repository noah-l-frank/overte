"""Actual bytes at the existing Popen pipe buffers, not reconstructed DTOs.

The genuine constructor and arguments remain unchanged. The controller inserts
these lossless buffer observers at its original constructor return, before the
model consumes its first response. No production/model method body is patched.
"""
import io
import os


class BinaryTee(io.BufferedIOBase):
    def __init__(self, actual, log, process, *, reading):
        super().__init__()
        self.actual, self.log, self.process = actual, log, process
        self.reading = reading
        self.observed = 0

    def readable(self):
        return self.reading

    def writable(self):
        return not self.reading

    def seekable(self):
        return False

    def fileno(self):
        return self.actual.fileno()

    def record(self, raw):
        assert type(raw) is bytes
        if raw:
            assert self.log.write(raw) == len(raw)
            self.observed += len(raw)
        return raw

    def read1(self, size=-1):
        assert self.reading
        return self.record(self.actual.read1(size))

    def read(self, size=-1):
        assert self.reading
        return self.record(self.actual.read(size))

    def readinto(self, buffer):
        raw = self.read(len(buffer))
        buffer[:len(raw)] = raw
        return len(raw)

    def write(self, raw):
        assert not self.reading
        count = self.actual.write(raw)
        assert type(count) is int and 0 <= count <= len(raw)
        self.record(bytes(raw[:count]))
        return count

    def flush(self):
        if not self.actual.closed:
            self.actual.flush()
        if not self.log.closed:
            self.log.flush()

    def close(self):
        if self.closed:
            return
        try:
            if self.reading and not self.actual.closed:
                # Never create an unbounded wait on a live writer. Genuine
                # ScriptMessageModel.close waits/kills before reader close.
                assert self.process.poll() is not None
                while True:
                    raw = self.actual.read(65536)
                    if not raw:
                        break
                    self.record(raw)
            self.flush()
        finally:
            try:
                self.actual.close()
            finally:
                self.log.close()
                super().close()


def install(process, directory):
    """Keep original decoding/newline behavior over the same actual buffers."""
    rows = []
    for name in ('stdin', 'stdout', 'stderr'):
        stream = getattr(process, name)
        if stream is None:continue
        assert type(stream) is io.TextIOWrapper and stream.newlines is None
        encoding, errors = stream.encoding, stream.errors
        line_buffering, write_through = stream.line_buffering, stream.write_through
        path = directory / (name + '.bin')
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        log = os.fdopen(fd, 'wb', buffering=0)
        actual = stream.detach()
        tee = BinaryTee(actual, log, process, reading=name != 'stdin')
        wrapped = io.TextIOWrapper(tee, encoding=encoding, errors=errors,
            newline=None, line_buffering=line_buffering, write_through=write_through)
        setattr(process, name, wrapped)
        rows.append(dict(name=name, originalDetachedText=stream, buffer=actual,
            tee=tee, text=wrapped, log=log, path=path))
    return rows
