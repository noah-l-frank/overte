"""Genuine read-only Actions view sharing the complete existing decoder.

This has no act/runtime/native/SDK method and is never a live Actions owner.
It replays original input intent only; returned/ACK is not a restored effect.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.phase_fixture import PhaseFixtureReader
from feature_journeys.contract import identifier
from ios.adapters.lifecycle_actions import LifecycleActions
from ios.adapters.lifecycle_independent_actor_world import _function_original,_function_unchanged

FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')


class LifecycleActionsArchive:
    def __init__(self,store,binding,run,phase,lock):
        need(type(store)is PrivateFeatureState and type(lock)is ScriptSourceLock and type(phase)is PhaseFixtureReader)
        self.store,self.binding,self.run,self.phase,self.lock=store,deepcopy(context(binding)),identifier(run),phase,lock
        need(store.path.name=='ios-lifecycle-actions.json'and lock.path==store.path.with_name('script-feature-sources.lock')
            and phase.run==run and phase.area=='lifecycle-input')
        self.phase_members=(phase.run,phase.area,phase.fixture_url,phase.client)
        self.decoder=_function_original(LifecycleActions.decode);lock.assert_held()
        self.signature=self.metadata();self.previous=store.read();need(self.previous is not None and self.metadata()==self.signature)
        # The original method is pure over exactly binding/run/phase.fixture_url.
        # It retains every existing call/closed-scenario/prefix/pending check.
        self.state=LifecycleActions.decode(self,self.previous);self.bound()

    def metadata(self):
        info=self.store.path.lstat();return tuple(getattr(info,key)for key in FIELDS)

    def bound(self):
        self.lock.assert_held();_function_unchanged(self.decoder)
        need(LifecycleActions.decode is self.decoder[0]and self.phase_members==(self.phase.run,self.phase.area,self.phase.fixture_url,self.phase.client)
            and self.metadata()==self.signature and same(self.store.read(),self.previous)and self.metadata()==self.signature)
        need(same(self.state,LifecycleActions.decode(self,self.previous)));return True

    def original(self):
        self.bound();return deepcopy(self.previous)
