"""Root-only metadata assembler for four exact Scene/order host counters.

Imports only stdlib and the independently qualified strict metadata reader.
Nothing runs merely by importing this module; no SUT/Pillow import is made.
"""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
SOURCE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller10c-copied-bootstrap-namespace-row-code-preparation-20261104'
SUBJECT_SHA='63f5ffc563996ad7793a600cb6a16c53d8df05a54d65db24321a1a2b5c020fc4'
HELPER_SHA='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
QUALIFICATION=REPO/'.ios-host-tmp/root-c10c-source-execution-six-cache-mutation-alias-counters-qualified-results-20261104'
QUALIFICATION_SHA='8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a'
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript')


def load(path):return json.loads(Path(path).read_text())
def packet(folder,leaf,digest):
    path=folder/leaf;assert pin(path)['sha256']==digest
    result={str(path):pin(path)};value=load(path)
    for name,row in value['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        actual=folder/name;assert actual.resolve(strict=True)==actual
        expected=row if type(row)is str else row['sha256'];result[str(actual)]=pin(actual);assert result[str(actual)]['sha256']==expected
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--source-freeze',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--destination',required=True,type=Path);args=p.parse_args()
    assert Path.cwd()==REPO and sys.dont_write_bytecode and sys.flags.no_site==1
    assert len(args.expected_head)==40 and all(c in'0123456789abcdef'for c in args.expected_head)and head()==args.expected_head
    physical=packet(SOURCE,'source-freeze.json',args.source_freeze);recipe=load(SOURCE/'SOURCE-RECIPE.json')
    assert recipe['caseCount']==4 and recipe['wallSeconds']==180 and recipe['killGraceSeconds']==5
    assert recipe['expectedTemporaryDirectoriesPerCase']==2 and recipe['expectedTemporaryDirectories']==8
    physical.update(packet(SUBJECT,'source-freeze.json',SUBJECT_SHA));assert pin(SOURCE/'closed_import_origins.py')['sha256']==HELPER_SHA
    physical.update(packet(QUALIFICATION,'freeze.json',QUALIFICATION_SHA));actual=load(QUALIFICATION/'results.json')
    assert actual['subjectSourceFreeze']==SUBJECT_SHA and actual['subjectHelperSha256']==HELPER_SHA
    assert actual['sourceExecutionCounterQualified']is True and actual['actualStartedCases']==actual['actualPassedCases']==6
    assert actual['actualFailedCases']==actual['actualUnrunCases']==actual['actualCallbackErrors']==0
    assert actual['NodeExecutions']==actual['SDKExecutions']==actual['overteNativeQueries']==0
    assert actual['parentFDThreadAndKernelDrain']and actual['twoWholeOwnCensusesEqual']and actual['all27OsCioDupToolsRestored']
    assert actual['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
    actual_refs=load(QUALIFICATION/'actual-receipt-references.json');assert len(actual_refs)==48
    for row in actual_refs.values():
        path=Path(row['path']);assert path.resolve(strict=True)==path and pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
    prior=REPO/'.ios-host-tmp/snapshot-ordinary-provenance-own9-bootstrap3-complete-root-input-pin-code-preparation-20261104'
    physical.update(packet(prior,'source-freeze.json','5e1c9f388f635b086aefa7127d5792dffd376dc5ec829aafde643af4f2030210'))
    own6=REPO/'.ios-host-tmp/chat-c10c-source-execution-own6-bootstrap2-outcome-custody-code-preparation-20261104'
    physical.update(packet(own6,'source-freeze.json','1df80b4b1597a4c2e896cc234ab20ea34f12b4529924ce7175d5fe61af80b681'))
    overlays={}
    for row in recipe['packets']:
        folder=Path(row['path']);physical.update(packet(folder,'source-freeze.json',row['sha256']))
        if str(folder)not in recipe['activeCandidatePackets']:continue
        candidates=load(folder/'CANDIDATES.json')
        for logical,item in candidates.items():
            source=folder/'candidate'/logical;assert pin(source)['sha256']==item['sha256'];physical[str(source)]=pin(source)
            if source.suffix!='.py':continue
            parts=Path(logical).relative_to('tests/device').with_suffix('').parts;name='.'.join(parts)
            assert name not in overlays;overlays[name]=dict(path=str(source),sha256=item['sha256'],package=False)
    assert len(overlays)==15
    # Preserve actual historical public originals while independently admitting
    # CURRENT public definitions. Old native21 bytes are not runtime authority.
    public=set()
    for name in ROOTS:
        root=REPO/name;assert root.resolve(strict=True)==root and root.is_dir()
        for path in root.rglob('*'):
            assert not path.is_symlink()
            if path.is_file():public.add(path)
    for path in public:physical[str(path)]=pin(path)
    modules={};namespaces={};ambiguous={}
    for root in(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests'):
        for path in sorted(root.rglob('*.py')):
            parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
            if package:parts.pop()
            if not parts:continue
            name='.'.join(parts);row=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=package)
            if name in ambiguous:
                if row not in ambiguous[name]:ambiguous[name].append(row)
            elif name in modules and modules[name]!=row:ambiguous[name]=[modules.pop(name),row]
            else:modules[name]=row
            for depth in range(1,len(parts)):
                directory=root.joinpath(*parts[:depth]);prefix='.'.join(parts[:depth])
                if not(directory/'__init__.py').is_file():
                    roots=namespaces.setdefault(prefix,[])
                    if str(directory)not in roots:roots.append(str(directory))
    assert set(ambiguous)=={'test_appium_adapter','test_voice_roundtrip'}
    for name in modules:namespaces.pop(name,None)
    for name,row in overlays.items():modules[name]=row
    external=load(SOURCE/'third-party-source-declarations.json');assert len(external)==31
    third={}
    for name,row in external.items():
        path=Path(row['path']);assert pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
        assert row['kind']in('python','extension')
        third[name]=dict(path=str(path),sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    std=Path(os.__file__).resolve(strict=True).parent;suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);std_namespaces={}
    for current,dirs,files in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink())
        relative=folder.relative_to(std)
        if relative.parts and all(part.isidentifier()for part in relative.parts)and not(folder/'__init__.py').is_file():std_namespaces['.'.join(relative.parts)]=[str(folder)]
        for name in files:
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(suffixes):continue
            assert path.resolve(strict=True)==path;physical[str(path)]=pin(path)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    gd=Path((REPO/'.git').read_text().split('gitdir: ',1)[1].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(path)]=pin(path)
    refpath=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs');physical[str(refpath)]=pin(refpath)
    destination=args.destination
    assert destination.is_absolute()and destination.resolve(strict=False)==destination and destination.parent==REPO/'.ios-host-tmp'
    assert destination.name.startswith('snapshot-scene-own4-prepared-')and not destination.exists()
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    destination.mkdir(mode=0o700)
    names=('run-own4.py','supervise-own4.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','readonly-shared-stdlib-sources.json','exact-four-selectors.json')
    for name in names:
        target=destination/name;fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(target)]=pin(target)
    for name in('metadata_reader','host_common','closed_import_origins','owned_write_boundary'):
        path=destination/(name+'.py');assert name not in modules
        modules[name]=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=False)
    cases=load(SOURCE/'exact-four-selectors.json');assert cases==recipe['cases']and len(cases)==len(set(cases))==4
    origin=dict(modules=modules,namespacePackages=namespaces,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=std_namespaces,
        stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='PRIVATE_SNAPSHOT_SCENE_SOURCE1_ORDERED_SOURCE3_OWN4_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(destination),actualPublicHead=args.expected_head,
        sourceFreeze=args.source_freeze,sourceAndBinaryPins=physical,modules=modules,namespaces=namespaces,thirdPartyModules=third,originPlan=origin,
        subjectOriginModules={name:dict(path=row['path'],sha256=row['sha256'])for name,row in overlays.items()},subjectOriginCount=15,
        cases=cases,wallSeconds=180,killGraceSeconds=5,expectedTemporaryDirectories=8,expectedTemporaryDirectoriesPerCase=2,
        subjectOriginalPath=str(SUBJECT/'closed_import_origins.py'),subjectActualCopiedPath=str(destination/'closed_import_origins.py'),subjectHelperSha256=HELPER_SHA,
        NodeExecutions=0,SDKExecutions=0,physicalNativeQueries=0,declaredModelNativeObservationsAllowed=True,realNetwork=False,oldCorpusInputs=0,globalOriginalScans=0,
        helperQualificationOriginalReferenceCount=48,helperQualificationIsNotSnapshotQualification=True,oldOrdinaryEightOriginsAreNotNewFifteenQualification=True,
        ambiguousPublicAliasesExcluded=sorted(ambiguous),hostBootstrapScope='Held original interpreter/stdlib and fresh private entry/controller definitions are trusted HOSTBOOTSTRAP; delegated SUT/PIL/stdlib Python executes fresh pinned bytes through exact C10c.',
        nativeCompiled=False,nativeQualified=False,wholeQualified=False)
    output=destination/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),inputSha256=pin(output)['sha256'],sourcePins=len(physical),cases=4,TDs=8,Node=0,targets=0,globalScans=0)))
    return 0


if __name__=='__main__':raise SystemExit(main())
