"""Whole Lifecycle restored originals, independently published Actor and End.

The live seal retains real surviving Qt objects. Only the separate explicit
Python original-keeper end can retire those process-bound responsibilities.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.phase_witness_publisher import PhaseWitnessPublisher
from adapters.script_feature.history import pack,unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys import terminal as protocol
from ios.adapters.lifecycle_observer import LifecycleObserver,retained_roots
from ios.adapters.lifecycle_current_archive import LifecycleCurrentArchive
from ios.adapters.lifecycle_marker_scope import IOSLifecycleMarkerScope
from ios.adapters.lifecycle_restoration import LifecycleRestoration
from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd,PROFILE
from ios.adapters.navigation_terminal_resources import binding as public_binding


class LifecycleTerminal:
    def __init__(self,flow):
        from ios.adapters.lifecycle_feature import IOSLifecycleFeature
        need(type(flow)is IOSLifecycleFeature and flow.role=='primary')
        self.flow=flow;self.lock=ScriptSourceLock(flow.store.path.with_name('script-feature-sources.lock'))
        self.store=PrivateFeatureState(flow.store.path.with_name('ios-lifecycle-terminal-'+flow.run+'.json'))
        with self.lock.held():
            flow.load();need(flow.state is not None and flow.state['phase']=='cleaned')
            self.binding=deepcopy(flow.state['binding']);self.previous=self.store.read()
            self.state=None if self.previous is None else self.decode(self.previous)

    def envelope(self):
        return dict(iosLifecycleTerminalVersion=1,binding=self.binding,runId=self.flow.run,payload=pack([self.state]))

    def decode(self,value):
        exact(value,{'iosLifecycleTerminalVersion','binding','runId','payload'});rows=unpack(value['payload'])
        need(len(rows)==1 and type(value['iosLifecycleTerminalVersion'])is int and value['iosLifecycleTerminalVersion']==1
            and value['binding']==self.binding and value['runId']==self.flow.run)
        state=rows[0];exact(state,{'description','references','seal','samples','live','end'})
        protocol.description(state['description'],area='lifecycle-input',run=self.flow.run)
        need(state['description']['profile']==PROFILE)
        if state['seal']is not None:
            protocol.sealed(state['seal'],state['description'],state['samples']);need(digest(state['live'])==state['seal']['liveOriginalSha256'])
        else:need(state['samples']is state['live']is state['end']is None)
        if state['end']is not None:protocol.ended(state['end'],state['seal'])
        return deepcopy(state)

    def save(self):
        self.lock.assert_held();need(same(self.store.read(),self.previous));value=self.envelope();self.decode(value)
        self.store.write(value,self.previous);self.previous=deepcopy(value)

    def observers(self):
        f=self.flow;self.lock.assert_held();result={}
        for role,root in (('primary',f.primary_root),('actor',f.actor_root)):
            state=PrivateFeatureState(f.store.path.with_name('ios-lifecycle-'+role+'-'+f.run+'-feature.json')).read()
            need(state is not None and state['state']['binding']==self.binding and state['state']['phase']in ('ready','cleaned'))
            result[role]=LifecycleObserver.archived(
                PrivateFeatureState(f.store.path.with_name('ios-lifecycle-observer-'+role+'-'+f.run+'.json')),
                PrivateFeatureState(f.store.path.with_name('ios-lifecycle-current-stream-'+role+'-'+f.run+'.json')),
                root,self.binding,f.run,role,self.lock,f.policy,f.phase.fixture_url,state['state']['phaseInstance'])
        return result

    def cleanup_original(self):
        f=self.flow;self.lock.assert_held();source=PrivateFeatureState(f.store.path.with_name('ios-lifecycle-current-stream-primary-'+f.run+'.json'))
        snapshot=source.read();need(snapshot is not None)
        stream=LifecycleCurrentArchive(source,snapshot,f.primary_root,self.binding,f.run,'primary',self.lock)
        restoration=LifecycleRestoration.archived(PrivateFeatureState(f.store.path.with_name('ios-lifecycle-restoration.json')),
            stream,self.binding,f.run,self.lock)
        marker_store=PrivateFeatureState(f.store.path.with_name('ios-lifecycle-primary-marker.json'));marker=marker_store.read();need(marker is not None)
        scope=IOSLifecycleMarkerScope.archive(marker,root=f.primary_root,binding=self.binding,run=f.run,role='primary',lock=self.lock)
        need(scope.state['phase']=='released'and scope.state['pending']is None and scope.state['cleanupMode']=='full'
            and not any(scope.state['leases'].values())and len(scope.state['quiet'])>=3)
        baseline=scope.frames[scope.state['baseline']-1];admitted=scope.frames[scope.state['webAdmission']-1]
        quiet=[scope.frames[n-1]for n in scope.state['quiet']]
        for row in quiet:
            scope.restored_marker(baseline,row,scope.state['admission'],scope.state['stopBarrier'])
            scope.ui_absent(row);scope.dialog_drained(row);scope.quiet_web(row,admitted)
        need(scope.quiet_interval(quiet[0],quiet[-1]))
        return dict(restorationSha256=digest(restoration.previous),markerSha256=digest(marker))

    def held(self,observer,reference):
        derived=observer.validate_original(reference);value=observer.original(reference)
        stream=LifecycleCurrentArchive(observer.stream.store,value['stream'],observer.root,self.binding,self.flow.run,observer.role,self.lock)
        cut=stream.record(value['source'])['current'];roots=retained_roots(cut,value['history']['aliases'])
        public=derived['public'];state=public['state']
        need(state['editor']=='none'and not state['keyboard']and not state['focused']and state['heldInputs']==[]
            and state['deferredInputs']==0 and state['worldDisplacement']<=.025)
        resources=[]if not roots else [dict(resource='panel:lifecycle-qt-roots',kind='qt-root',
            originalSha256=digest(dict(inventory=cut['originals']['ui']['lifecycleFieldInventory'],roots=roots)))]
        need(public['resources']==[row['resource']for row in resources])
        return dict(binding=public_binding(self.binding),heldResources=resources,originalSha256=digest(value))

    def inspect(self):
        f=self.flow;phase=f.phase.read();need(phase['verb']=='cleanup'and phase['inputs']=={})
        if self.state is None:
            # Both actual role streams acquire NEW native/HTTP/AFC originals.
            call=dict(contractVersion=1,runId=f.run,afterSequence=0)
            f.observe(call)
            # A separate Actor holder owns its publisher credential and fresh
            # own-role reads. The adapter's GET-only client never publishes.
            started=f.monotonic()
            for attempt in range(101):
                with self.lock.held():
                    store=PrivateFeatureState(f.store.path.with_name('ios-lifecycle-observer-actor-'+f.run+'.json'));value=store.read()
                    ready=False
                    if value is not None:
                        state=unpack(value['payload'])[0]
                        if state['pending']is None and state['checkpointIndex']['count']:
                            owner=self.observers()['actor'];last=owner.validate_original(owner.state['records'][-1]);ready=last['ticket']==phase['ticket']
                if ready:break
                need(f.monotonic()-started<5 and attempt<100);f.sleep(.05)
        with self.lock.held():
            owners=self.observers();self.cleanup_original()
            if self.state is None:
                references={role:deepcopy(owner.state['records'][-1])for role,owner in owners.items()}
                descriptor=dict(featureTerminalVersion=1,profile=PROFILE,area='lifecycle-input',runId=f.run,ticket=phase['ticket'],
                    roles={role:self.held(owner,references[role])for role,owner in owners.items()})
                protocol.description(descriptor)
                self.state=dict(description=descriptor,references=references,seal=None,samples=None,live=None,end=None);self.save()
            else:
                need(self.state['description']['ticket']==phase['ticket'])
                for role,owner in owners.items():need(same(self.held(owner,self.state['references'][role]),self.state['description']['roles'][role]))
            return deepcopy(self.state['description'])

    def live_original(self,descriptor,samples):
        self.lock.assert_held();protocol.window(samples,descriptor);owners=self.observers();actual={}
        for role,owner in owners.items():
            need(same(self.held(owner,self.state['references'][role]),descriptor['roles'][role]))
            actual[role]={ref['index']:(ref,owner.validate_original(ref))for ref in owner.state['records']}
        actor=owners['actor'];publication_store=PrivateFeatureState(self.flow.store.path.with_name('phase-publication-lifecycle-input-'+self.flow.run+'-actor.json'))
        publication=publication_store.read();need(publication is not None)
        journal=PhaseWitnessPublisher.archive(publication,store=publication_store,binding=self.binding,run=self.flow.run,area='lifecycle-input',
            fixture_url=self.flow.phase.client.url,phase_instance=actor.phase_instance,validate_original=actor.validate_original)
        need(journal['pending']is None)
        reader=object.__new__(PhaseWitnessPublisher);reader.store=publication_store;reader.binding=self.binding
        reader.run,reader.area,reader.url=self.flow.run,'lifecycle-input',self.flow.phase.client.url
        reader.instance,reader.validate_original,reader.live=actor.phase_instance,actor.validate_original,False
        receipts=[(ref,reader.load(ref))for ref in journal['records']];rows=[]
        for pair in samples:
            p,a=pair['primary'],pair['actor'];ps,as_=p['sequence'],a['actorSequence']
            need(ps in actual['primary']and as_ in actual['actor']and same(p,actual['primary'][ps][1]['public'])
                and actual['actor'][as_][1]['ticket']==descriptor['ticket'])
            for role,sequence in (('primary',ps),('actor',as_)):
                held=self.held(owners[role],actual[role][sequence][0])
                need([row['resource']for row in held['heldResources']]==[row['resource']for row in descriptor['roles'][role]['heldResources']])
            matches=[ref for ref,row in receipts if row['mode']=='published'and same(row['entry'],a)];need(len(matches)==1)
            rows.append(dict(primary=deepcopy(actual['primary'][ps][0]),actor=deepcopy(actual['actor'][as_][0]),publication=matches[0]))
        return dict(iosLifecycleTerminalLiveVersion=1,descriptionSha256=digest(descriptor),windowSha256=digest(samples),
            cleanup=self.cleanup_original(),samples=rows)

    def seal(self,descriptor,samples):
        with self.lock.held():
            need(self.state is not None and same(descriptor,self.state['description'])and same(self.store.read(),self.previous))
            actual=self.live_original(descriptor,samples)
            seal=dict(featureTerminalSealVersion=1,description=deepcopy(descriptor),windowSha256=digest(samples),liveOriginalSha256=digest(actual))
            if self.state['seal']is None:self.state.update(seal=seal,samples=deepcopy(samples),live=actual);self.save()
            else:need(same(seal,self.state['seal'])and same(actual,self.state['live']))
            return deepcopy(self.state['seal'])

    def finish(self,seal):
        with self.lock.held():
            need(self.state is not None and same(seal,self.state['seal'])and same(self.store.read(),self.previous))
            actual=self.live_original(self.state['description'],self.state['samples']);need(same(actual,self.state['live']))
            ends={role:IOSOriginalKeeperProcessEnd(self.flow.script,self.flow.selector,root,self.binding,self.flow.run,role,0,'lifecycle',self.lock,
                epoch_ms=self.flow.epoch_ms,monotonic=self.flow.monotonic,sleep=self.flow.sleep)
                for role,root in (('primary',self.flow.primary_root),('actor',self.flow.actor_root))}
            ends['primary'].finish(peers=(ends['actor'],));roles={}
            for role,end in ends.items():
                proof=end.retirement_original();prior=self.state['description']['roles'][role]
                roles[role]=dict(binding=deepcopy(prior['binding']),heldOriginalSha256=prior['originalSha256'],
                    stopOriginalSha256=proof['stopOriginalSha256'],osAbsence=proof['osAbsence'],
                    sdkDeletionOriginalSha256=proof['sdkDeletionOriginalSha256'],archiveSha256=proof['archiveSha256'])
            value=dict(featureTerminalEndVersion=1,seal=deepcopy(seal),roles=roles);protocol.ended(value,seal)
            if self.state['end']is None:self.state['end']=value;self.save()
            else:need(same(value,self.state['end']))
            return value

    def invoke(self,call):
        call=protocol.arguments('lifecycle-input',call);need(call['runId']==self.flow.run);stage=call['stage']
        if stage=='inspect':return dict(stage=stage,description=self.inspect())
        if stage=='seal':return dict(stage=stage,seal=self.seal(call['description'],call['samples']))
        return dict(stage=stage,end=self.finish(call['seal']))
