import ast,hashlib,json,shutil,difflib
from pathlib import Path
R=Path.cwd();D=R/'.ios-host-tmp/emote-callback-live-prefix-external-parser-policy-class-closure-20261102';P=R/'.ios-host-tmp/emote-callback-live-prefix-regex-bound-inert-annotations-source-fix-20261102'
assert not (P/'freeze.json').exists()
for n in ('base','candidate'):shutil.copytree(D/n,P/n)
# Preserve25 as immediate base for narrow review, cumulative base19 still retained.
shutil.copytree(D/'candidate',P/'previous-candidate')
rel='tests/device/ios/adapters/emote_callback_live_records.py';q=P/'candidate'/rel;s=q.read_text()
needle="    if kind is BuiltinFunctionType:return ('builtin',identity)"
assert s.count(needle)==1
s=s.replace(needle,"""    if kind is type(json.decoder.WHITESPACE.match):
        # Python3.14's native regex bound-method type differs from the ordinary
        # builtin function/method type. Only the actual immutable Pattern.match
        # receiver/name/descriptor is supported; no arbitrary native receiver.
        receiver=getattr(value,'__self__',None);name=getattr(value,'__name__',None)
        if type(receiver) is not re.Pattern or name!='match':raise _Unsupported(kind,'regex-bound-method')
        descriptor=vars(re.Pattern)['match'];refs.append(descriptor)
        return ('regex-match',identity,token(receiver),id(descriptor))
"""+needle)
s=s.replace("if type(value) in (FunctionType,staticmethod,classmethod,property))", "if name not in ('__annotations__','__annotate__','__annotate_func__','__annotations_cache__')\n        and type(value) in (FunctionType,staticmethod,classmethod,property))")
s=s.replace("            if name in ('__dict__','__weakref__'):","""            if name in ('__annotations__','__annotate__','__annotate_func__','__annotations_cache__'):
                # The actual PNG/JSON decode graph never reads annotations.
                # Keep namespace membership, without evaluating or traversing
                # typing's inert lazy closures/ForwardRefs. Runtime behavior
                # methods and added call/lookup overrides still bind fully.
                members.append((name,('inert-annotation-metadata',)))
            elif name in ('__dict__','__weakref__'):""")
q.write_text(s)
trel='tests/device/ios/self_tests/test_ios_emote_callback_live_history_cache.py';t=P/'candidate'/trel
t.write_text(t.read_text()+'''
    def test_actual_json_regex_default_receiver_change_cannot_borrow_warm_parse(self):
        import json,re
        def parse():
            self.calls+=1;record(self.file);return json.loads(self.file.read_text())
        first=self.history.read(self.owner,self.reference,parse);self.assertEqual({'historical':'one'},first);self.assertEqual(2,self.calls)
        function=json.JSONDecoder.decode;defaults=function.__defaults__
        self.assertIs(type(defaults[0].__self__),re.Pattern);self.assertEqual('match',defaults[0].__name__)
        function.__defaults__=(re.compile(r'.*').match,)
        try:
            self.assertFalse(self.history.literal())
            with self.assertRaises(json.JSONDecodeError):self.history.read(self.owner,self.reference,parse)
        finally:function.__defaults__=defaults
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())
        self.assertEqual(first,self.history.read(self.owner,self.reference,parse));self.assertEqual(3,self.calls)

    def test_unsupported_native_regex_search_method_default_remains_literal(self):
        import json,re
        self.read();function=json.decoder._decode_uXXXX;defaults=function.__defaults__
        function.__defaults__=(re.compile(r'[0-9A-Fa-f]{4}').search,)
        try:
            self.assertFalse(self.history.literal());self.read()
            self.assertTrue(any(row['type']==('builtins','builtin_method') and row['reason']=='regex-bound-method'
                for row in self.history.unsupported_members()))
        finally:function.__defaults__=defaults
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())
''')
for f in P.rglob('*.py'):ast.parse(f.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[];parts=[];narrow=[]
for f in sorted((P/'candidate').rglob('*.py')):
 r=f.relative_to(P/'candidate');rows.append(dict(path=str(r),baseSHA256=sha(P/'previous-candidate'/r),candidateSHA256=sha(f)))
 parts.extend(difflib.unified_diff((P/'base'/r).read_text().splitlines(True),f.read_text().splitlines(True),fromfile='a/'+str(r),tofile='b/'+str(r)))
 narrow.extend(difflib.unified_diff((P/'previous-candidate'/r).read_text().splitlines(True),f.read_text().splitlines(True),fromfile='previous/'+str(r),tofile='candidate/'+str(r)))
(P/'source.diff').write_text(''.join(parts));(P/'narrow-source.diff').write_text(''.join(narrow));shutil.copyfile(D/'actual-old-profile-external-functions.json',P/'actual-old-profile-external-functions.json')
old=json.loads((D/'plan.json').read_text());old.update(previousDraftFreeze=sha(D/'freeze.json'),sourceRows=rows,mechanismCases=27,actualFailure=dict(stage=str(R/'.ios-host-tmp/emote-callback-live-prefix-external-parser-mechanisms25-gated-root-preparation-20261102/smoke1'),expectedExit=1,retainedFiles=0),diagnosis='Actual Python3.14 builtins.builtin_method is re.Pattern.match defaults; strict receiver/name/immutable Pattern/descriptor token. Static exact lazy path ImageMode.ModeDescriptor.__annotate__ originates typing._make_eager_annotate checked_types ForwardRefs for future-annotation strings. No PIL import or annotations evaluated by child. Known inert annotation metadata values excluded, all namespace names and runtime behavior remain guarded.')
(P/'plan.json').write_text(json.dumps(old,indent=2)+'\n')
files={str(f.relative_to(P)):sha(f) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='freeze.json'};(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files=files),indent=2)+'\n')
print(json.dumps(dict(freeze=sha(P/'freeze.json'),rows=rows,cases=27,narrowDiffLines=len(narrow))))
