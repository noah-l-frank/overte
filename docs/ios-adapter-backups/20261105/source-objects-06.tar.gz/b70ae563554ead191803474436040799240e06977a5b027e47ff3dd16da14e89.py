"""Original-only family/deletion context beside the full Profile9 GPU graph."""
from copy import deepcopy
from pathlib import Path
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.original_file_reads import collect,scope as read_scope
from adapters.script_feature.history import unpack,same
from ios.adapters.emote_sources import IOSEmoteSources
from ios.adapters.emote_post_controller_sources import IOSEmotePostControllerSources
from ios.adapters.emote_palette_file_delivery import PaletteFileDelivery,delivery
from ios.adapters.emote_original_lease import EmoteOriginalLease


def family_metadata_paths(role):
    role.lock.assert_held();role.primary_lock.assert_held()
    paths=[role.primary_lock.path.with_name('ios-emote-'+role.role+'-post-controller-sources.json'),
        role.primary_lock.path.with_name('ios-emote-'+role.role+'-'+role.run+'-post-controller-end-owned.json')]
    if role.role=='primary':paths.append(role.primary_lock.path.with_name('ios-emote-primary-'+role.run+'-palette-file-delivery.json'))
    return paths


class CopiedNativeFileHistory:
    """Genuine historical grammar on the actual copied delivery WAL, no SDK."""
    def __init__(self,store,root,binding,run,lock):
        self.store,self.root,self.binding,self.run,self.lock=store,root,deepcopy(binding),run,lock;lock.assert_held()
        self.previous=store.read();need(self.previous is not None)
        self.frames=OriginalFrameStore(root,binding,run,'primary',lambda:lock.assert_held(),lambda *_:need(False),
            namespace='emote-palette-file-delivery',schema_prefix='emotePaletteFileDelivery',kind='inputs')
        self.state=PaletteFileDelivery.decode(self,self.previous);need(self.state['pending']is None and self.state['records'])
        previous=None
        for ref in self.state['records']:previous=self.original(ref,previous)['delivery']
    def envelope(self,state):return PaletteFileDelivery.envelope(self,state)
    def original(self,ref,previous=None):
        self.lock.assert_held();need(ref in self.state['records']and same(self.store.read(),self.previous))
        return PaletteFileDelivery.original(self,ref,previous)


class CopiedPostFamily:
    def __init__(self,role,sources,store_for,copies,*,retirement=None):
        from ios.adapters.emote_post_controller_copied_role import Profile9RoleState
        need(type(role)is Profile9RoleState and isinstance(sources,IOSEmoteSources)and sources.historical
            and same(sources.binding,role.state['primaryBinding'])and sources.role==role.role)
        self.role,self.sources,self.store_for,self.copies,self.retirement=role,sources,store_for,copies,retirement
        paths=family_metadata_paths(role);store=store_for(paths[0]);self.owner=IOSEmotePostControllerSources(store,sources,historical=True)
        need(self.owner.state['phase']=='ready'and self.owner.state['pending']is None and self.owner.frames)
        need(all(self.owner.validate_frame(frame,self.owner.frames[i-1]if i else None)is True for i,frame in enumerate(self.owner.frames)))
        copied=store_for(paths[1]);raw=copied.read();need(raw is not None)
        exact(raw,{'iosEmotePostControllerEndOwnedArchiveVersion','runId','role','creatorBinding','artifactRoot','payload'})
        need(type(raw['iosEmotePostControllerEndOwnedArchiveVersion'])is int and raw['iosEmotePostControllerEndOwnedArchiveVersion']==1
            and raw['runId']==role.run and raw['role']==role.role and same(raw['creatorBinding'],sources.binding)and raw['artifactRoot']==str(sources.root))
        state=unpack(raw['payload']);need(len(state)==1);state=state[0]
        exact(state,{'phase','ownershipSha256','record','pending'});need(state['phase']=='copied'and state['pending']is None and state['record']is not None)
        frames=OriginalFrameStore(sources.root,sources.binding,role.run,role.role,lambda:role.lock.assert_held(),lambda *_:need(False),
            namespace='emote-callback-post-copied',schema_prefix='emoteCallbackPostSourceCopied',kind='inputs')
        snapshot=frames.read(frames.expand(state['record']));need(digest(snapshot)==state['ownershipSha256'])
        need(snapshot['runId']==role.run and snapshot['role']==role.role and snapshot['creatorRole']=='primary'
            and same(snapshot['sourceBinding'],sources.binding)and same(snapshot['sourceOwnerValue'],sources.previous)
            and same(snapshot['familyOwnerValue'],self.owner.previous)and snapshot['stableOriginalFlags']
            and all(flag is True for flag in snapshot['stableOriginalFlags'])
            and snapshot['responsibility']['uncertainRead']is False)
        for name,signature in snapshot['actualSourceSignatures'].items():
            path=Path(name)
            if name in copies:
                need(same(store_for(path).read(),copies[name]))
                # The per-path typed End view, not a missing path/name, admits
                # later original metadata absence. Raw OFS is never removed.
                if retirement is not None:retirement.guard()
                else:need(list(EmoteOriginalLease.signature(path.lstat()))==signature)
            else:need(list(EmoteOriginalLease.signature(path.lstat()))==signature)
        self.snapshot=deepcopy(snapshot);self.raw=deepcopy(raw);self.native=None
        if role.role=='primary':
            self.native_history=CopiedNativeFileHistory(store_for(paths[2]),role.root,role.state['binding'],role.run,role.lock)
            self.native=self.native_history.original(self.native_history.state['records'][-1])
            value=self.native['delivery']['original']['source']['ownership']
            need(self.native['query']['operation']=='retire'and value['phase']=='retired'and value['retirementIssued']is True
                and value['pendingPublication']is False and value['processId']==int(sources.binding['processIdentity']))
        self.bound()
    def bound(self):
        self.role.lock.assert_held();self.role.primary_lock.assert_held();self.owner.bound()
        need(same(self.store_for(family_metadata_paths(self.role)[1]).read(),self.raw));return True


def qualify_families(roles):
    need(set(roles.families)=={'primary','actor'})
    families=roles.families;p=families['primary'];a=families['actor'];p.bound();a.bound()
    need(same(p.sources.binding,a.sources.binding))
    native=p.native['delivery']['original']['source']['ownership'];last=native['file']['palette']
    palettes=[frame['palette']for family in(p,a)for frame in family.owner.frames]
    need(any(same(value,last)for value in palettes)and all(value['processId']==last['processId']and value['instance']==last['instance']
        and value['clockAfter']['epochMs']<=last['clockAfter']['epochMs']for value in palettes))
    return dict(profile9FamilyOriginals={role:digest(owner.snapshot)for role,owner in families.items()},
        profile9NativeFileRetirementOriginalSha256=digest(p.native),responseFileDuty=dict(name='feature-native-observation.json',creatorRole='primary',retainedHistoricalArtifact=True))
