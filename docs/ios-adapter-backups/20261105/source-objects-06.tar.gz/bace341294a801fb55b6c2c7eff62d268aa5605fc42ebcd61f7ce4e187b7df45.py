import hashlib,json,runpy,sys
from pathlib import Path
repo=Path.cwd()
selected=set(json.loads((repo/'.ios-host-tmp/world-web-construction-current-before-20261027.json').read_text()))
selected.update(['.ios-host-tmp/profile-world-web-construction-api25-readonly-20261027.py','.ios-host-tmp/run-world-web-construction-api25-readonly-20261027.py'])
def hashes(names):return {n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in sorted(names)}
before=hashes(selected)
(repo/'.ios-host-tmp/world-web-construction-api25-source-before-20261027.json').write_text(json.dumps(before,indent=2)+'\n')
code=0
try:runpy.run_path(str(repo/'.ios-host-tmp/profile-world-web-construction-api25-readonly-20261027.py'),run_name='__main__')
except SystemExit as error:code=error.code
used={str(p.relative_to(repo)) for p in [Path(getattr(m,'__file__','')).resolve() for m in tuple(sys.modules.values()) if getattr(m,'__file__',None)] if p.suffix=='.py' and p.is_relative_to(repo)}
used.update(['.ios-host-tmp/profile-world-web-construction-api25-readonly-20261027.py','.ios-host-tmp/run-world-web-construction-api25-readonly-20261027.py'])
after=hashes(used);changed=[n for n in sorted(used) if before.get(n)!=after[n]]
report=dict(exitCode=code,actualUsedSources=len(used),changed=changed)
(repo/'.ios-host-tmp/world-web-construction-api25-source-after-20261027.json').write_text(json.dumps(dict(report=report,sources=after),indent=2)+'\n')
print(json.dumps(report),flush=True)
sys.exit(code if not changed else 2)
