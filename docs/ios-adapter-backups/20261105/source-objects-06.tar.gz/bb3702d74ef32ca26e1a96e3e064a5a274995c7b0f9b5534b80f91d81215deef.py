"""Bind the original existing metadata receiver and actual models; AST only."""
import ast,difflib,hashlib,json
from pathlib import Path
R=Path.cwd();H=R/'.ios-host-tmp/lifecycle-resource4-parent-world-history-bound-overlay-20261102';B=R/'.ios-host-tmp/lifecycle-resource4-parent-world-history-source-proposal-20261102'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(s)
rows=[];patch=[]
for row in json.loads((B/'plan.json').read_text())['sourceRows']:
 rel=row['path'];p=B/'candidate'/rel;assert sha(p)==row['candidateSHA256'];before=p.read_text();after=before
 if rel.endswith('lifecycle_resource_history.py'):after=after.replace('from adapters.original_frame_store import OriginalFrameStore\n','')
 if rel.endswith('lifecycle_world_hold.py'):
  needle='        self._child_bind_preparation=None if original_child is None else original_child.bind_preparation\n';assert after.count(needle)==1
  after=after.replace(needle,needle+"        self._resource_runtime=None if not resource_history else original_child.runtime\n        self._resource_capture=None if not resource_history else original_child.runtime.resource_metadata\n")
  needle="                    metadata=await self.original_child.runtime.resource_metadata(self.original_child.selector,self.run,\n                        original_child=self.original_child,retain_original_bytes=True)";assert after.count(needle)==1
  after=after.replace(needle,"                    need(self.original_child.runtime is self._resource_runtime\n                        and self._resource_runtime.resource_metadata.__func__ is self._resource_capture.__func__)\n                    metadata=await self._resource_capture(self.original_child.selector,self.run,\n                        original_child=self.original_child,retain_original_bytes=True)")
 if rel.endswith('.py'):ast.parse(after,filename=rel)
 write(H/'candidate'/rel,after);rows.append(dict(row,candidateSHA256=hashlib.sha256(after.encode()).hexdigest()))
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='draft/'+rel,tofile='bound/'+rel))
write(H/'bound-only.diff',''.join(patch))
model='''"""Actual normal original-child World/resource history; SDK/native are MODELS."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import base64
from copy import deepcopy
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from ios.adapters.lifecycle_resource_history import original
from test_resource4_normal_frontdoor_models import Resource4NormalFrontdoorModels


class ParentResourceWorldHistoryModels(Resource4NormalFrontdoorModels):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.owner=self.runtime.child('test-only',self.normal.d.flow,self.normal.owner,None,original_child=True,resource_history=True)
        self.assertEqual(3,self.owner.version);self.assertIsNone(self.owner.previous)

    async def test_actual_parent_world_history_retains_original_bytes_across_later_child_headers_and_passive_three_second_window(self):
        await self.owner.act(seconds=12);await self.owner.observe()
        first=self.owner.frame(2);old=deepcopy(first['resourceOriginal'])
        self.assertTrue(original(old,self.binding,self.run,self.ops.instance,self.owner.frame(1)['originalChild']['reference'])['capture']['worker']['workerRunning'])
        prepared=self.ops.touch_resources.store.path.read_bytes()
        await self.owner.release()
        for _ in range(4):await self.owner.sample_quiet()
        proof=self.owner.resource_history_proof();self.assertGreaterEqual(proof['hostMilliseconds'],3000)
        self.assertTrue(proof['historicalOnly']);self.assertEqual(5,proof['samples'])
        self.assertFalse(proof['sdkResourceRetirementEstablished']);self.assertFalse(proof['wholeLifecycleRetirementEstablished'])
        self.assertEqual(first,self.owner.frame(2));self.assertEqual(old,self.owner.frame(2)['resourceOriginal'])
        self.assertNotEqual(old['ownerReference'],self.owner.frame(7)['resourceOriginal']['ownerReference'])
        self.assertEqual(prepared,self.ops.touch_resources.store.path.read_bytes());self.assertEqual(6,len(self.ops.touch_resources._observation_owner.state['frames']))
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(30,len(self.commands))
        calls=len(self.command_tasks);self.assertEqual(proof,self.owner.resource_history_proof())
        self.assertEqual(calls,len(self.command_tasks));self.assertEqual(30,len(self.commands))

    async def test_changed_parent_raw_original_bytes_or_reference_cannot_qualify_archive(self):
        await self.owner.act(seconds=12);await self.owner.observe();frame=self.owner.frame(2)
        first=self.owner.frame(1)['originalChild'];before=deepcopy(frame)
        changed=deepcopy(frame);raw=base64.b64decode(changed['resourceOriginal']['ownerBase64']);changed['resourceOriginal']['ownerBase64']=base64.b64encode(raw+b' ').decode('ascii')
        with self.assertRaises((NativeUIError,ValueError)):self.owner.source_frame(changed)
        changed=deepcopy(frame);changed['resourceOriginal']['reference']['inode']+=1
        # A compact physical identity is part of BOTH original header/frame
        # membership, not just a syntactically valid caller-supplied reference.
        with self.assertRaises((NativeUIError,ValueError)):self.owner.source_frame(changed)
        self.assertEqual(before,self.owner.frame(2));await self.owner.lease_owner().release()
        self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_replaced_metadata_receiver_cannot_mint_parent_source_and_original_up_stays_available(self):
        await self.owner.act(seconds=12);queries=len(self.commands)
        def foreign(*args,**kwargs):raise AssertionError('Foreign metadata callback was invoked')
        with patch.object(type(self.runtime),'resource_metadata',new=foreign):
            with self.assertRaises(NativeUIError):await self.owner.observe()
        self.assertEqual(queries,len(self.commands));self.assertEqual([],self.ops.touch_resources._observation_owner.state['frames'])
        await self.owner.lease_owner().release();self.assertEqual([0xC2,0xC2,0x02],self.f.states())
'''
ast.parse(model);write(H/'models/test_parent_resource_world_history_models.py',model)
write(H/'plan.json',json.dumps(dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',baseFreeze=sha(B/'freeze.json'),sourceRows=rows,models=3,actualDataProducer='Existing original-child Resource4 actual per-chunk source/FD/Task read with exact raw bytes; existing original World batches unchanged',fullJourneyEntrypoint='Not yet implemented; these models exercise existing normal runtime child opt-in profile3 only',defaultProfilesUnchanged=[1,2],native250msAnd15sUnchanged=True,retirementFlagsRemainFalse=True,targetImports=False,testsRun=False),indent=2)+'\n')
write(H/'freeze.json',json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(H)):sha(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(packet=str(H),freeze=sha(H/'freeze.json'),sourceRows=rows)))
