"""Read actual closed receipts; no target, import, mutation of originals or scan."""
from pathlib import Path
import hashlib
import json
import os

R = Path(__file__).resolve().parents[2]
B = R / '.ios-host-tmp'
C = B / 'root-snapshot-public73-serial-window-current875-b1-20261104'
OUT = B / 'root-snapshot-public73-current-public-compatibility-qualified-results-20261104'
refs = {}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    p = p.resolve(strict=True)
    refs[str(p)] = dict(path=str(p), sha256=sha(p))
    return json.loads(p.read_text())

def packet(p, expected):
    assert sha(p / 'freeze.json') == expected
    for name, row in read(p / 'freeze.json')['files'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts
        target = p / name
        assert sha(target) == (row if type(row) is str else row['sha256'])
        refs[str(target)] = dict(path=str(target), sha256=sha(target))

def put(name, value):
    data = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
    with (OUT / name).open('xb') as f:
        f.write(data)
    return dict(sha256=sha(OUT / name))

packet(C, 'b2576d55aa0eeb93b21c950d01a7c41b8b6955a47436cfa069a70261ee31db07')
t = read(C / 'terminal.json')
assert t['status'] == 'ROOT_SERIAL_TWENTY_ONE_PUBLIC73_GROUPS_COMPLETED'
assert t['allExecutedOwnedProcessesAbsent'] and t['allOldOriginalBodiesUnchanged']
assert t['wholeOwnOutputCensusesEqual'] and t['globalCensuses'] == 3
assert t['oldRootCount'] == 875 and not t['unrunGroups']
assert len(t['groups']) == 21 and len(t['newOriginalRoots']) == 43
assert not any(t[k] for k in ('featureQualified', 'nativeQualified', 'wholeQualified'))
before = read(C / 'global-before.json')
assert len(before) == 875
assert before == read(C / 'global-after-first.json') == read(C / 'global-after-second.json')
assert read(C / 'all-complete-own-output-first.json') == read(C / 'all-complete-own-output-second.json')
groups, all_ids, total_td, total_cleanup, seconds = [], [], 0, 0, 0.0
for g in t['groups']:
    h = Path(g['input']).parent
    o = Path(str(h) + '-outer')
    assert sha(Path(g['input'])) == g['inputSha256']
    a = read(Path(g['input']))
    terminal = read(o / 'terminal.json')
    assert terminal == g['originalTerminal']
    assert g['supervisorReturnCode'] == terminal['childReturnCode'] == 0
    assert terminal['status'] == 'PASS' and not terminal['problems']
    assert terminal['ownProcessesAbsent'] and not terminal['timedOut'] and not terminal['forcedKill']
    assert not terminal['fullOwnCensusExclusions'] and not terminal['orphansRequiredKill']
    for key in ('actualStdlibParentFDThreadDrain', 'allDeclaredActualRuntimeOriginsEstablished',
                'allSourceBinaryPinsEqual', 'approvedInputsExactPinAndCliShaUnchanged',
                'originalChildSubtreesCensusesEqual', 'twoFullOwnOutputCensusesEqual'):
        assert terminal[key] is True, (g['group'], key)
    assert a['wallSeconds'] == 180 and a['killGraceSeconds'] == 5 and a['nativeAdmission'] is None
    assert a['subjectOriginCount'] == 46 and a['physicalNativeQueries'] == 0
    assert not any(a[k] for k in ('realNetwork', 'nativeCompiled', 'nativeQualified', 'wholeQualified'))
    for first, second in [('actual-child-output-first.json', 'actual-child-output-second.json'),
                          ('actual-child-subtrees-first.json', 'actual-child-subtrees-second.json'),
                          ('approved-input-before.json', 'approved-input-after.json'),
                          ('source-binary-before.json', 'source-binary-after.json')]:
        assert read(o / first) == read(o / second)
    cr = h / 'child-receipts'
    report = read(cr / 'report.json')
    assert report['status'] == 'PASS' and report['fatal'] is None
    n = a['caseCount']
    assert report['testsRun'] == report['actualCaseReceipts'] == report['expectedCaseCount'] == n
    for key in ('allActualLoadedOriginsAccounted', 'cleanupEstablished', 'fdUnchanged',
                'kernelChildrenUnchanged', 'pinsUnchanged', 'threadsUnchanged', 'twoToyCensusesEqual'):
        assert report[key] is True, (g['group'], key)
    selected = read(cr / 'actual-selection.json')
    assert not selected['loaderErrors'] and selected['ids'] == a['cases']
    origins = read(cr / 'actual-source-model-origins.json')
    assert origins['allDeclaredActualRuntimeOriginsEstablished']
    assert len(origins['subjectOrigins']) == 46
    private = 0
    for name, row in origins['subjectOrigins'].items():
        assert row['actualModulePresent'] and row['exactOriginMatched']
        assert row['actualLoaderExecutedPath'] == row['actualModuleFile'] == row['expectedPath']
        p = Path(row['expectedPath'])
        assert sha(p) == row['expectedSha256']
        private += p.is_relative_to(B)
    assert private == 1
    ports = read(cr / 'actual-port-restoration.json')
    assert ports['count'] == 27 and not ports['controlDescriptors']
    assert all(ports[k] is True for k in ('restored', 'builtinsCioRestored', 'dupPortsRestored', 'toolsRestored'))
    assert ports['actualC10dHelperSha256'] == '69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
    cleanup = read(cr / 'outer-cleanup.json')
    assert cleanup['success'] and cleanup['nestedActualCleanupSucceeded'] and len(cleanup['cases']) == n
    for row in cleanup['cases']:
        assert row['success'] and row['remaining'] == 0 and not row['errors'] and not row['failures']
    td = len(report['retainedTemporaryDirectories'])
    assert td == a['expectedTemporaryDirectories']
    for i, cid in enumerate(selected['ids'], 1):
        case = read(cr / ('standard-case-%s.json' % i))
        assert case['id'] == cid and case['remainingStandardCleanups'] == 0
        assert case['newTemporaryDirectories'] == a['expectedTemporaryDirectoriesPerCase'][cid]
        for key in ('fdUnchanged', 'kernelChildrenUnchanged', 'monitorSlotsUnchanged',
                    'originalMethodsUnchanged', 'standardStopAfterCleanup', 'threadsUnchanged'):
            assert case[key] is True
    for root in (h, o):
        for p in root.rglob('*'):
            if p.is_file() and not p.is_symlink():
                refs[str(p)] = dict(path=str(p), sha256=sha(p))
    total_td += td
    total_cleanup += len(cleanup['nestedActualCalls'])
    all_ids.extend(selected['ids'])
    # Original unittest stderr owns the case runtime, not supervisor/census runtime.
    stderr = (h / 'child-logs/stderr.log').read_text()
    import re
    elapsed = re.findall(r'Ran (\d+) tests? in ([0-9.]+)s', stderr)
    assert len(elapsed) == 1 and int(elapsed[0][0]) == n
    seconds += float(elapsed[0][1])
    groups.append(dict(group=g['group'], cases=selected['ids'], temporaryDirectories=td,
                       standardCleanupCalls=len(cleanup['nestedActualCalls']),
                       actualSourceOrigins=46, privateOrigins=private, originalTerminal=terminal))
assert len(all_ids) == len(set(all_ids)) == 73 and total_td == 145
OUT.mkdir(mode=0o700)
result = dict(schemaVersion=1, status='ROOT_QUALIFIED_CURRENT_PUBLIC_SNAPSHOT73_COMPATIBILITY_COMPONENTS',
    actualCases=73, actualPassedCases=73, actorOriginalCases=22, primaryPngJoinCases=12, ordinaryCases=9, sceneCases=17, canonicalPublicationCases=10, pureDefaultCases=3, currentPublicCompatibilityQualified=True,
    actualPublicHead='cb79372ab9ec96df5e1320f9c573259ac3fbebed',
    actualSerialCollectorFreeze=sha(C / 'freeze.json'), actualSourceBootstrapFreeze=a['sourceFreeze'],
    actualPublicCopyProvenance='6174308eae5013a25c1edf70840e8d944639c82e6ae723ea23d22855d9ba80d3',
    actualPublicUncommitted32=json.loads((B / 'root-public73-exact-reviewed-dirty32-copy-manifest-20261104/copy-manifest.json').read_text())['publicFiles'],
    cases=all_ids, groups=groups, genuineTemporaryDirectories=total_td,
    standardCleanupCalls=total_cleanup, caseSeconds=round(seconds, 3),
    actualDeclaredOriginsPerGroup=46, actualPrivateOriginsPerGroup=1, actualPublicOriginsPerGroup=45,
    all875OldOriginalBodiesUnchanged=True, globalCensuses=3, wholeHEREAndOutersTwiceEqual=True,
    newOriginalRoots=t['newOriginalRoots'],
    terminal=dict(childReturnCode=0, ownProcessesAbsent=True, problems=[], timedOut=False, forcedKill=False),
    hostActorOriginalModelsQualified=True, hostPrimaryActorOriginalCropEqualityQualified=True,
    nativeCompiled=False, nativeQualified=False, devicesQualified=False,
    actorAuthenticationOrProcessSeparationQualified=False, actualActorRenderedPixelsQualified=False,
    temporalBracketQualified=False, fullAppearanceQualified=False, snapshotFeatureQualified=False,
    wholeQualified=False)
files = {'results.json': put('results.json', result),
         'actual-receipt-references.json': put('actual-receipt-references.json', refs)}
put('freeze.json', dict(files=files))
print(json.dumps(dict(freeze=sha(OUT / 'freeze.json'), results=sha(OUT / 'results.json'),
                      cases=73, temporaryDirectories=total_td, standardCleanupCalls=total_cleanup,
                      caseSeconds=round(seconds,3), references=len(refs), newRoots=len(t['newOriginalRoots']))))
