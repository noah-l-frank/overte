"""Exact actual C10d Root6+8 prerequisite; no Avatar composition authority.

Only frozen retained originals are read. No SUT module, clock, query, process
or original corpus census is opened by this reader. Old Own8 is historical.
"""
from pathlib import Path
import json
REPO=Path(__file__).resolve().parents[2]
PRIVATE=REPO/'.ios-host-tmp'
SUBJECT=PRIVATE/'chat-controller10d-exact-defused-et-transaction-source-private-20261104'
SUBJECT_SHA='fbcc253aebc8a11883bfebe4ffae10888351337e3e0f4092c477c4550c342f4b'
HELPER_SHA='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
BOOTSTRAP=PRIVATE/'chat-c10d-baseline6-transaction8-closed-utility-bootstrap1-code-preparation-20261104'
BOOTSTRAP_SHA='ca3dadde214da0b296fc7df3298fa232706db65fd681b4afbcd553fbd97f70a2'
ROOT=PRIVATE/'root-c10d-current-helper-baseline6-transaction8-qualified-readiness-20261104'
ROOT_SHA='fbfffcd6e329efd65d6fbfe84a3e7d535241263046f70f313173b52436d65d2b'
RESULT_SHA='345df0a0c71de9c298cb37b2b5dfc80c52f59c3a233284ec590e77200ac32d46'
OWN8=PRIVATE/'avatar-prefix8-own-boundary4-source-bootstrap8-rejected-entry-unwind-private-20261104'
OWN8_SHA='83a59c4cb3ae47de7ccf5077e892acb7aacb8bffea23b032d4ba19a5ce6726e9'
PREFIX8=PRIVATE/'avatar-normal-prefix8-original-rejected-popen-unwind-source-private-20261104'
PREFIX8_SHA='3c5d0d06fd79e0c24c0abff81a0caed89a025695e63b06e8040729281ff87f09'
OLD_OWN_ROOT=PRIVATE/'root-avatar-own8-four-boundary-counters-qualified-results-20261104'
OLD_OWN_SHA='2eec044816e0d677c368e0387333f61bae93a8ab68ef52887b8f22871dedc229'
GROUPS=(
 ('baseline6',6,62,'root-c10d-baseline6-current-helper-qualified-results-20261104',
  'e8d88ebdc37d5ac5844f5ec8dc9ff77a29d29f781bfb3a7fe515e9c64af4177c',
  'ef0fefb4e771cd6bfc157c8c45b2a79317e462254683b8b3fbf5b26bcc2aef35',
  'ROOT_QUALIFIED_C10D_BASELINE6_CURRENT_HELPER_SOURCE_CACHE_ALIAS_COUNTERS_ONLY'),
 ('transaction8',8,65,'root-c10d-transaction8-current-helper-qualified-results-20261104',
  '753c44af4b0621e2f4a4a6ae734bf969a2da92b1d430fd5fee0cc2baaff1959a',
  '591ec105487d4733570fd84f51dad45c93c2e8a041f2595f37cce8b885bb178b',
  'ROOT_QUALIFIED_C10D_TRANSACTION8_GENUINE_ET_IMPORT_RESTORE_AND_HOSTILE_COUNTERS_ONLY'))


def checked(path,expected,pin,physical):
 path=Path(path)
 assert path.is_absolute()and path.resolve(strict=True)==path
 before=pin(path);assert before['sha256']==expected
 previous=physical.setdefault(str(path),before);assert previous==before
 return path

def read(path,expected,pin,physical):
 path=checked(path,expected,pin,physical);value=json.loads(path.read_text())
 assert pin(path)==physical[str(path)];return value

def packet(folder,leaf,expected,pin,physical):
 body=read(folder/leaf,expected,pin,physical);assert type(body['files'])is dict
 for name,row in body['files'].items():
  assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
  checked(folder/name,row if type(row)is str else row['sha256'],pin,physical)
 return body

def references(folder,body,count,pin,physical):
 entry=body['files']['actual-receipt-references.json'];digest=entry if type(entry)is str else entry['sha256']
 refs=read(folder/'actual-receipt-references.json',digest,pin,physical)
 assert type(refs)is dict and len(refs)==count
 for name,row in refs.items():
  assert type(row)is dict and set(row)=={'path','sha256'}and row['path']==name
  checked(name,row['sha256'],pin,physical)
 return refs


def require_current(path,digest,pin):
 assert Path(path)==ROOT/'freeze.json'and digest==ROOT_SHA
 physical={};body=packet(ROOT,'freeze.json',ROOT_SHA,pin,physical)
 actual=read(ROOT/'results.json',RESULT_SHA,pin,physical)
 assert actual['schemaVersion']==1 and actual['status']=='ROOT_QUALIFIED_C10D_CURRENT_HELPER_BASELINE6_AND_GENUINE_TRANSACTION8'
 assert actual['subjectSourceFreeze']==SUBJECT_SHA and actual['helperSha256']==HELPER_SHA and actual['bootstrapSourceFreeze']==BOOTSTRAP_SHA
 assert actual['actualBaseline6Qualified']is actual['actualTransaction8Qualified']is actual['actualStandardCleanupsQualified']is True
 assert actual['actualCounterCases']==14 and actual['actualSeparateFreshProcessGroups']==2
 assert actual['actualNodeSDKNetworkNativeExecutions']==0 and actual['actualExternalGlobalCensusesPerGroup']==3
 assert actual['actualWholeRoomsTwiceCensusedPerGroup']is True
 assert actual['historicalC10cHelperPreserved']=='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
 assert actual['historicalC10cSourceProofPreserved']=='8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a'
 assert actual['historicalProofsAreNotCurrentCompositionQualification']is True
 assert actual['consumerCompositionsQualified']is actual['wholeQualified']is actual['nativeQualified']is actual['deviceQualified']is False
 aggregate_refs=references(ROOT,body,141,pin,physical)
 packet(SUBJECT,'source-freeze.json',SUBJECT_SHA,pin,physical)
 packet(BOOTSTRAP,'source-freeze.json',BOOTSTRAP_SHA,pin,physical)
 checked(SUBJECT/'closed_import_origins.py',HELPER_SHA,pin,physical)
 checked(BOOTSTRAP/'closed_import_origins.py',HELPER_SHA,pin,physical)
 assert len(actual['groups'])==2;roots=[]
 for row,(selection,count,refcount,name,freeze_sha,result_sha,status)in zip(actual['groups'],GROUPS):
  folder=PRIVATE/name
  assert row['rootFreeze']==dict(path=str(folder/'freeze.json'),sha256=freeze_sha)and row['resultsSha256']==result_sha
  group_body=packet(folder,'freeze.json',freeze_sha,pin,physical)
  group=read(folder/'results.json',result_sha,pin,physical)
  assert group['schemaVersion']==1 and group['status']==status and group['utilitySelection']==selection
  assert group['subjectSourceFreeze']==SUBJECT_SHA and group['subjectHelperSha256']==HELPER_SHA and group['bootstrapSourceFreeze']==BOOTSTRAP_SHA
  assert group['actualTests']==group['actualRetainedTDs']==row['actualCases']==count
  assert group['actualCaseIds']==row['actualCaseIds']and len(set(group['actualCaseIds']))==count
  assert group['actualSourceOrigins']==row['actualSourceOrigins']and group['newOriginalRoots']==row['originalRoots']
  for name,entry in group['actualSourceOrigins'].items():
   assert set(entry)=={'path','sha256'}
   checked(entry['path'],entry['sha256'],pin,physical)
  assert group['actualStandardCleanupsQualified']is group['twoCompleteOwnOutputsEqual']is group['all716SourcePinsUnchanged']is True
  assert group['RootExternalGlobalCensuses']==3 and group['consumerAdmissionQualified']is False
  assert group['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
  child=group['actualChildReport'];outer=group['originalSupervisorTerminal']
  assert child['status']=='PASS'and child['testsRun']==child['actualCaseReceipts']==count and child['fatal']is None
  for key in('cleanupEstablished','fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','twoToyCensusesEqual','allActualLoadedOriginsAccounted'):assert child[key]is True
  assert child['NodeExecutions']==child['SDKExecutions']==child['overteNativeQueries']==0 and child['realNetwork']is False
  assert outer['status']=='PASS'and outer['childReturnCode']==0 and outer['caseCount']==count and outer['utilitySelection']==selection
  assert outer['forcedKill']is outer['timedOut']is False and outer['problems']==outer['orphansRequiredKill']==outer['fullOwnCensusExclusions']==[]
  for key in('actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allTwoActualRuntimeOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','ownProcessesAbsent','twoFullOwnOutputCensusesEqual'):assert outer[key]is True
  refs=references(folder,group_body,refcount,pin,physical)
  assert all(aggregate_refs[name]==entry for name,entry in refs.items())
  if selection=='transaction8':
   transactions=group['actualOriginalTransactionReceipts'];assert len(transactions)==1
   original=transactions[0];assert aggregate_refs[original['path']]['sha256']==original['sha256']
   transaction=read(original['path'],original['sha256'],pin,physical)
   assert transaction==original['actual']and transaction['profile']=='defusedxml-original-single-et-transaction-v1'
   for key in('actualFinallyRestoredCanonicalAndAcceleratorAndPackage','originalCanonicalExecutionPreserved','pureFreshSourceExecuted','pureParseErrorPatchEstablished'):assert transaction[key]is True
   assert transaction['currentReceiverHistoryAdmission']is transaction['productNativeEvidence']is False
  roots.extend(row['originalRoots'])
 assert roots==actual['requiredOriginalRoots']and len(set(roots))==6
 return dict(rootFreeze=dict(path=str(ROOT/'freeze.json'),sha256=ROOT_SHA),resultsSha256=RESULT_SHA,
  subjectSourceFreeze=SUBJECT_SHA,helperSha256=HELPER_SHA,bootstrapSourceFreeze=BOOTSTRAP_SHA,
  actualBaseline6Qualified=True,actualTransaction8Qualified=True,actualSourceHead=actual['sourceHead'],
  requiredOriginalRoots=roots,consumerCompositionsQualified=False,wholeQualified=False),physical


def historical_own8(pin):
 physical={};body=packet(OLD_OWN_ROOT,'freeze.json',OLD_OWN_SHA,pin,physical)
 row=body['files']['results.json'];digest=row if type(row)is str else row['sha256']
 actual=read(OLD_OWN_ROOT/'results.json',digest,pin,physical)
 assert actual['status']=='ROOT_QUALIFIED_AVATAR_OWN8_FOUR_GENUINE_BOUNDARY_COUNTERS_NSS_AND_ORIGINAL_REJECTED_UNWIND'
 assert actual['prefixSourceFreeze']==PREFIX8_SHA and actual['ownSourceFreeze']==OWN8_SHA
 assert actual['actualTests']==actual['actualPassedCases']==4 and actual['actualRetainedTDs']==6
 assert actual['actualOpenSSLChildren']==2 and actual['actualFixtureTLSListeners']==actual['actualOriginalNSSAttempts']==1
 assert actual['actualRejectedStarts']==actual['actualMatchingOriginalUnwinds']==1 and actual['actualNodeExecutions']==actual['actualSDKExecutions']==0
 assert actual['actualStandardCleanupsQualified']is True
 assert actual['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
 references(OLD_OWN_ROOT,body,41,pin,physical)
 packet(OWN8,'source-freeze.json',OWN8_SHA,pin,physical)
 packet(PREFIX8,'source-freeze.json',PREFIX8_SHA,pin,physical)
 checked(OWN8/'closed_import_origins.py','387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb',pin,physical)
 checked(PREFIX8/'closed_import_origins.py','387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb',pin,physical)
 return dict(rootFreeze=dict(path=str(OLD_OWN_ROOT/'freeze.json'),sha256=OLD_OWN_SHA),
  prefixSourceFreeze=PREFIX8_SHA,ownSourceFreeze=OWN8_SHA,helperSha256='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb',
  historicalCounterScopeOnly=True,currentC10dCompositionQualified=False),physical
