from pathlib import Path
from types import SimpleNamespace
import json,sys,signal,time,traceback,importlib.abc,importlib.util
REPO=Path.cwd();HERE=Path(__file__).resolve().parent
controller=REPO/'.ios-host-tmp/chat-role-original-graph-source11-private-overlay-root-preparation-20261103'
sys.path.insert(0,str(controller));import run_metadata as meta
plan=meta.validate_frozen();meta.publication();before=meta.sources(plan);own=meta.pin(Path(__file__).resolve())
corpus=Path(json.loads((controller/'paired1-report.json').read_text())['runRoot'])/'temporary';originals=meta.originals(corpus)
assert originals==json.loads((controller/'paired1-originals-second.json').read_text())
meta.save(HERE/'source-before.json',before)
def audit(event,args):
    if event=='import':assert not any(part in ('pymobiledevice3','tidevice','pyidevice','zeroconf') for part in args[0].split('.'))
    elif event=='subprocess.Popen':assert list(args[1])==['rg','--files','-0',*plan['broadSourceRoots']] and Path(args[2]).resolve()==REPO
    elif event in ('socket.connect','socket.bind'):raise AssertionError('Historical diagnostic cannot use a service')
    elif event=='open' and isinstance(args[0],(str,bytes)):
        p=Path(args[0]).absolute();flags=args[2]
        if p.is_relative_to(corpus) and isinstance(flags,int):
            assert not flags & (512|1024),'No original truncate/append'
            if flags & 64:assert p.exists() and p.name=='script-feature-sources.lock' and p.stat().st_size==0,'Only open an existing original lock inode'
sys.addaudithook(audit)
sys.path[:0]=[str(REPO/'tests/device'),str(REPO/'tests/device/self_tests'),str(REPO/'tests/device/ios/self_tests')]
overlays=plan['privateSourceOverlays']
class Overlay(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        for row in overlays:
            if fullname==row['module']:
                source=REPO/row['path'];assert meta.sha(source)==row['sha256']
                return importlib.util.spec_from_file_location(fullname,source)
sys.meta_path.insert(0,Overlay())
from ios.adapters import chat_draft_runtime,chat_archive_round as a
from ios.adapters import chat_peer_receipts,chat_send_receive
from ios.adapters.chat_receive_sources import IOSChatReceiveSources
from ios.adapters.chat_draft_owner import IOSChatDraftOwner
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.script_runtime import IOSScriptRuntime
from feature_journeys.phase_fixture import Client
for label in a._QML_AUTHORITIES:__import__(label,fromlist=['__name__'])
assert a.original_methods()
paths={};headers={}
for path in corpus.rglob('ios-chat-draft-owner.json'):
    value=json.loads(path.read_text());role={9:'primary',11:'peer'}[value['iosChatDraftOwnerVersion']]
    assert role not in paths;paths[role]=path;headers[role]=value
assert set(paths)=={'primary','peer'}
receive_paths=list(corpus.rglob('ios-chat-receive-sources.json'));assert len(receive_paths)==1
receive_path=receive_paths[0];saved=json.loads(receive_path.read_text())
locks={role:ScriptSourceLock(paths[role].with_name('script-feature-sources.lock')) for role in paths}
possible=list(corpus.rglob('*.ipa'));assert len(possible)==1;artifact=possible[0]
artifacts={role:(artifact,headers[role]['binding']['artifactSha256']) for role in paths}
runtime=object.__new__(chat_draft_runtime.IOSChatDraftRuntime);runtime.adapter=SimpleNamespace(state_path=lambda selector:paths[selector].with_name('session.json'))
client=object.__new__(Client);client.url=headers['primary']['fixtureUrl'].split('/runs/')[0]
rows={};refusals=[];status=None;round_path=a.__file__
watch=REPO/'tests/device'
def observer(frame,event,arg):
    # Fast filename comparison first; do not profile every project function or
    # materialize generic locals. This records only proof fallback metadata.
    code=frame.f_code
    if code.co_filename!=round_path:return
    if event=='call' and code.co_name=='disable':
        caller=frame.f_back;local=caller.f_locals;scope=frame.f_locals['self']
        row=dict(kind='actual-disable',caller=caller.f_code.co_name,line=caller.f_lineno,
            entries=len(scope.memo),bytes=scope.memo_bytes,roots=[str(p)for p in scope.roots])
        if 'size'in local:row['newEntrySize']=local['size']
        if 'dependencies'in local:row['outsideRootReads']=[str(p) for p in local['dependencies'] if p.parent not in scope.roots]
        if len(refusals)<40:refusals.append(row)
    elif event=='return' and code.co_name=='eligible' and arg is False:
        key=('ineligible',type(frame.f_locals.get('owner')).__name__);rows[key]=rows.get(key,0)+1
    elif event=='return' and code.co_name=='original_methods' and arg is False:
        rows[('parser-authority-false','')]=rows.get(('parser-authority-false',''),0)+1

def alarm(*_args):raise TimeoutError('Pure frozen historical diagnostic fixed60-second cap')
started=time.monotonic();signal.signal(signal.SIGALRM,alarm)
try:
    with locks['primary'].held(),locks['peer'].held():
        sys.setprofile(observer);signal.setitimer(signal.ITIMER_REAL,60)
        receive=IOSChatReceiveSources.archive(PrivateFeatureState(receive_path),saved['primaryBinding'],saved['binding'],saved['runId'],saved['peerBindingRecord']['primaryArtifactRoot']['path'],saved['artifactRoot'],saved['peerBindingRecord'],locks['primary'],locks['peer'])
        contexts=runtime._chat_receipt_contexts('primary','peer',saved['runId'],client,receive,qml_artifacts=artifacts)
        for role in ('peer','primary'):
            h=headers[role]
            IOSChatDraftOwner.archive(PrivateFeatureState(paths[role]),h['artifactRoot'],h['binding'],h['runId'],locks[role],h['fixtureUrl'],source_bound=True,peer_actor=role=='peer',peer_receipts=contexts[role],qml_bound=True,qml_artifact=artifacts[role])
        status='HISTORICAL_DIAGNOSTIC_RETURNED'
except BaseException as exc:status=type(exc).__name__;meta.save(HERE/'exception.json',dict(type=type(exc).__name__,traceback=traceback.format_exc()))
finally:signal.setitimer(signal.ITIMER_REAL,0);sys.setprofile(None)
after=meta.sources(plan);assert before==after and own==meta.pin(Path(__file__).resolve()) and originals==meta.originals(corpus)
meta.save(HERE/'source-after.json',after)
report=dict(diagnosticInstrumentation='Exact ArchiveRound-only passive profile observer; historical fallback reasons only, no live target retry',status=status,seconds=time.monotonic()-started,authorityOriginal=a.original_methods(),lastCounts=a._LAST_COUNTS.get(),refusals=refusals[:30],refusalCount=len(refusals),counts=[dict(kind=k[0],owner=k[1],count=v)for k,v in rows.items()],sourcePins=len(before),allPinsUnchanged=True,originalsUnchanged=True,noServicesOrSDKOrNode=True,wholeChatQualified=False)
meta.save(HERE/'report.json',report);print(json.dumps(report))
