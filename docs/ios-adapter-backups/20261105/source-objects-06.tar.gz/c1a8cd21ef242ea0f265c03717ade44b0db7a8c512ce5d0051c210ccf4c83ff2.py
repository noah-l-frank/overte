"""Whole negative source lifetime and original lost-return counters, unrun."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import unittest
from adapters.normal_ui import NativeUIError
from ios.self_tests.audio_whole_fixture import AudioWholeFixture

class AudioNegativeAcquisitionTests(unittest.TestCase):
    def setUp(self):
        self.f=AudioWholeFixture(self);self.f.primary.prepare();self.f.actor.prepare();self.f.step('open','1'*32)
    def test_one_actual_owner_keeps_all_fresh_native_nonces_and_retained_negative_evidence(self):
        f=self.f;actual=f.actor_runtime._sources;factories=[]
        def counted(*args,**kwargs):factories.append((args,kwargs));return actual(*args,**kwargs)
        f.actor_runtime._sources=counted
        try:f.primary.act(f.activate('mute','2'*32,dict(enabled=True)))
        finally:f.actor_runtime._sources=actual
        self.assertEqual(1,len(factories));commands=f.once.boundary.commands
        self.assertEqual(1,sum(q['operation']=='start'for q in commands));self.assertGreater(sum(q['operation']=='observe'for q in commands),1)
        self.assertEqual(len(commands),len({q['commandId']for q in commands}));self.assertEqual([],f.once.boundary.once.inputs)
        with f.primary.held():
            rows=[row for row in f.primary.state['artifacts']if row['ticket']=='2'*32]
            self.assertEqual(1,len(rows));self.assertEqual('audio',rows[0]['kind'])
            self.assertGreater(len(f.primary.evidence.read(rows[0])),44)
    def test_unknown_observe_return_reconstructs_original_custody_without_second_start_or_mute(self):
        f=self.f;send=f.once.boundary.send;faults=[]
        def lost(query):
            result=send(query)
            if query['operation']=='observe'and not faults:
                faults.append(query['commandId']);raise NativeUIError('Declared lost actual negative observe return')
            return result
        f.once.boundary.send=lost;call=f.activate('mute','2'*32,dict(enabled=True))
        with self.assertRaises((NativeUIError,ValueError)):f.primary.act(call)
        f.once.boundary.send=send;count=f.m.actions.count('audio.mute');f.primary=f.flow('primary');f.primary.act(call)
        self.assertTrue(faults);self.assertEqual(count,f.m.actions.count('audio.mute'))
        self.assertEqual(1,sum(q['operation']=='start'for q in f.once.boundary.commands))
        with f.primary.held():self.assertTrue(f.primary.state['actions'][-1]['completed'])
    def test_foreign_sdk_duty_during_wait_still_blocks_the_same_bound_source(self):
        from adapters.normal_feature_state import PrivateFeatureState
        f=self.f;actual=f.primary.sleep;created=[]
        def mutation(seconds):
            result=actual(seconds)
            if not created:
                store=PrivateFeatureState(f.once.actor_root/'ios-audio-foreign-duty.json');store.write(dict(declaredForeignDuty=True),None);created.append(store.path)
            return result
        f.primary.sleep=mutation
        try:
            with self.assertRaises((NativeUIError,ValueError)):f.primary.act(f.activate('mute','2'*32,dict(enabled=True)))
        finally:f.primary.sleep=actual
        self.assertTrue(created);self.assertTrue(created[0].exists())
        self.assertEqual(1,sum(q['operation']=='start'for q in f.once.boundary.commands))
