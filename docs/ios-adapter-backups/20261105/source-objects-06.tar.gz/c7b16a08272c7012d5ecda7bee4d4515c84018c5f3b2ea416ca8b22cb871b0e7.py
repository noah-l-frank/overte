from pathlib import Path
import ast,difflib,hashlib,json
r=Path.cwd();p=r/'.ios-host-tmp/lifecycle-original-owner-route-draft-20261028';p.chmod(0o700);b=r/'.ios-host-tmp/lifecycle-authenticated-keeper-drain-overlay-20261028'
n=Path('/usr/local/lib/overte-ios-remotexpc/5.15.3-r12/appium/node_modules/appium-ios-remotexpc')
def sha(x):return hashlib.sha256(x).hexdigest()
def replace(s,a,z):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
entries=[]
rel='tests/device/ios/pymobiledevice3_wda_xctest.py';raw=(b/'candidates'/rel).read_bytes();s=raw.decode()
s=replace(s,'import signal\n','import signal\nimport time\nimport uuid\n')
s=replace(s,'    keys = {"schemaVersion", "udid", "rsdHost", "rsdPort", "wdaBundleId",', '''    if type(value) is dict and type(value.get("schemaVersion")) is int and value["schemaVersion"]==2:
        value=decode_owner_packet(line)
        if (set(value)!={"schemaVersion","creatorMode","udid","stateRoot"}
                or value["creatorMode"]!="original-userspace-owner" or type(value["udid"]) is not str
                or not 8<=len(value["udid"])<=128 or any(ch in value["udid"] for ch in "\\0\\r\\n")
                or type(value["stateRoot"]) is not str or not value["stateRoot"].startswith("/")
                or any(ch in value["stateRoot"] for ch in "\\0\\r\\n")):
            raise LaunchError("request")
        return value
    keys = {"schemaVersion", "udid", "rsdHost", "rsdPort", "wdaBundleId",''')
s=replace(s,'async def run_xctest(request: dict, *, original_source=None) -> None:\n    stop = asyncio.Event()','async def run_xctest(request: dict, *, original_source=None, owned_stop=None, owned_ready=None) -> None:\n    stop = asyncio.Event() if owned_stop is None else owned_stop')
s=replace(s,'    for signal_number in (signal.SIGINT, signal.SIGTERM):\n        loop.add_signal_handler(signal_number, stop.set)','    if owned_stop is None:\n        for signal_number in (signal.SIGINT, signal.SIGTERM):\n            loop.add_signal_handler(signal_number, stop.set)')
s=replace(s,'            sys.stdout.write("READY\\n")\n            sys.stdout.flush()','            if owned_ready is None:\n                sys.stdout.write("READY\\n")\n                sys.stdout.flush()\n            else:\n                owned_ready.set_result(None)')
s=replace(s,'def main() -> int:\n', (p/'keeper-operations.py.fragment').read_text()+'\n\ndef main() -> int:\n')
s=replace(s,'        asyncio.run(run_xctest(read_request()))','        request=read_request()\n        asyncio.run(run_original_owner(request) if request["schemaVersion"]==2 else run_xctest(request))')
ast.parse(s);entries.append(('repo',rel,raw,s))
# Original Node creator switch occurs before any old provider/TLS/kernel call.
rel='scripts/tunnel-creation.mjs';raw=(n/rel).read_bytes();s=raw.decode()
s=replace(s,"import path from 'node:path';", "import path from 'node:path';\nimport {startOriginalUserspaceKeeper} from './lib/userspace-keeper.mjs';")
s=replace(s,'let registryServer = null;','let registryServer = null;\nlet creatorMode = \'kernel\';\nconst originalUserspaceOwners = new Map();')
s=replace(s,'async function createTunnelForDevice(device) {\n  const udid = device.Properties.SerialNumber;', '''async function createTunnelForDevice(device) {
  const udid = device.Properties.SerialNumber;
  if (creatorMode === 'userspace-keeper') {
    // Exclusive ORIGINAL creator branch. No lockdown/TLS/kernel provider below
    // is opened for this device, and an owner failure NEVER falls back to it.
    if (originalUserspaceOwners.has(udid)) throw new Error('Original owner already exists');
    const owner = await startOriginalUserspaceKeeper(device);
    originalUserspaceOwners.set(udid, owner);
    return {success: true, device, originalUserspaceOwner: owner};
  }''')
s=replace(s,"    .option('-k, --keep-open',", "    .option('--creator-mode <mode>', 'Original creator backend: kernel or userspace-keeper', 'kernel')\n    .option('-k, --keep-open',")
s=replace(s,'  const options = program.opts();','  const options = program.opts();\n  creatorMode = options.creatorMode;\n  if (![\'kernel\', \'userspace-keeper\'].includes(creatorMode)) throw new Error(\'Invalid original creator mode\');')
s=replace(s,'      readiness,\n      refreshServices:', '''      readiness,
      originalOwnerOperation: async (udid, request) => {
        if (creatorMode === 'kernel') {
          if (request?.operation !== 'inspect') throw new Error('Original owner unavailable');
          return {originalKeeperOperationVersion: 1, ownerInstance: null, result: {originalKeeperOwnerVersion: 1, creatorMode: 'kernel'}};
        }
        const owner = originalUserspaceOwners.get(udid);
        if (!owner) throw new Error('Original userspace owner unavailable');
        const result = request?.operation === 'inspect' && request.sessionId === null
          ? await owner.inspect() : await owner.request(request);
        return {originalKeeperOperationVersion: 1, ownerInstance: owner.instance, result};
      },
      refreshServices:''')
s=replace(s,'      if (result.success) {\n        attachTunnelRegistryLifecycleWatch', '''      if (result.originalUserspaceOwner) {
        // An in-process address MUST NOT be published as a kernel TunnelEndpoint.
        successful.push(result);
        continue;
      }
      if (result.success) {
        attachTunnelRegistryLifecycleWatch''')
s=replace(s,'    for (const {tunnelConnection} of establishedTunnelsByUdid.values()) {', '''    for (const owner of originalUserspaceOwners.values()) {
      try { await owner.close(); } catch (_) { process.exitCode = 1; }
    }
    for (const {tunnelConnection} of establishedTunnelsByUdid.values()) {''')
# Original script summary assumes first successful result is a kernel endpoint only
# in log metadata, not operational authority. Do not log userspace endpoint.
entries.append(('node-sdk',rel,raw,s))
entries.append(('node-sdk','scripts/lib/userspace-keeper.mjs',b'',(p/'userspace-keeper.mjs.fragment').read_text()))
rel='src/lib/tunnel/tunnel-registry-server.ts';raw=(n/rel).read_bytes();s=raw.decode()
s=replace(s,'  readiness?: TunnelReadinessCoordinator;','  readiness?: TunnelReadinessCoordinator;\n  originalOwnerOperation?: (udid: string, request: unknown) => Promise<unknown>;')
s=replace(s,"  private readonly refreshServices?: TunnelRegistryServerOptions['refreshServices'];", "  private readonly refreshServices?: TunnelRegistryServerOptions['refreshServices'];\n  private readonly originalOwnerOperation?: TunnelRegistryServerOptions['originalOwnerOperation'];")
s=replace(s,'    this.refreshServices = options.refreshServices;','    this.refreshServices = options.refreshServices;\n    this.originalOwnerOperation = options.originalOwnerOperation;')
s=replace(s,'  private tunnelRegistryRouteTable(): RouteRecord[] {','''  private async originalOwnerRequest(req: http.IncomingMessage, res: http.ServerResponse, udid: string): Promise<void> {
    if (!this.originalOwnerOperation) { sendJSON(res, 404, {error: 'Original owner unavailable'}); return; }
    const chunks: Buffer[] = []; let size = 0;
    for await (const value of req) {
      const chunk = Buffer.isBuffer(value) ? value : Buffer.from(value);
      size += chunk.length; if (size > 16384) { sendJSON(res, 413, {error: 'Request too large'}); return; }
      chunks.push(chunk);
    }
    const request: unknown = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    const result = await this.originalOwnerOperation(udid, request);
    sendJSON(res, 200, result);
  }

  private tunnelRegistryRouteTable(): RouteRecord[] {''')
s=replace(s,'        path: `${base}/:udid/refresh-services`,','        path: `${base}/:udid/refresh-services`,') if False else s
# Insert before broad parameter route; existing API/port/dispatcher is reused.
anchor="      {\n        method: 'POST',\n        path: `${base}/:udid/refresh-services`,"
s=replace(s,anchor,"      {\n        method: 'POST',\n        path: `${base}/:udid/original-owner`,\n        handler: async (req, res, params) => this.originalOwnerRequest(req, res, params.udid),\n      },\n"+anchor)
entries.append(('node-sdk',rel,raw,s))
rel='src/lib/tunnel/tunnel-api-client.ts';raw=(n/rel).read_bytes();s=raw.decode()
s=replace(s,'  getApiBaseUrl(): string {','''  async originalKeeperOperation(udid: string, request: unknown): Promise<unknown> {
    const response = await this.fetchWithTimeout(`${this.apiBaseUrl}/${encodeURIComponent(udid)}/original-owner`, {
      method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(request),
    }, 35000);
    if (!response.ok) throw new TunnelAvailabilityError('Original owner operation unavailable');
    return await response.json();
  }

  getApiBaseUrl(): string {''')
entries.append(('node-sdk',rel,raw,s))
rel='src/index.ts';raw=(n/rel).read_bytes();s=raw.decode()
s="import {createValidatedStrictRegistryClient as createOriginalRegistryClient} from './lib/tunnel/tunnel-availability.js';\n"+s
s+='''\n/** Same existing registry route; DTOs are routing data, not live-owner proof. */
export async function originalKeeperOperation(udid: string, request: unknown): Promise<unknown> {
  const client = await createOriginalRegistryClient();
  return await client.originalKeeperOperation(udid, request);
}
''';entries.append(('node-sdk',rel,raw,s))
# Existing service's original creator selection, kernel default unchanged.
rel='tests/device/ios/remotexpc_tunnel.py';raw=(r/rel).read_bytes();s=raw.decode()
start=s.index("def serve(");head=s[:start];tail=s[start:]
tail=replace(tail,'    if not Path("/dev/net/tun").exists():\n        fail("/dev/net/tun is unavailable")','    if arguments.creator_mode == "kernel" and not Path("/dev/net/tun").exists():\n        fail("/dev/net/tun is unavailable")')
s=head+tail
s=replace(s,'        "--reconnect-retries", "3",\n    ]','        "--reconnect-retries", "3",\n        "--creator-mode", arguments.creator_mode,\n    ]')
s=replace(s,'    serve_parser.add_argument("--port", type=int, default=DEFAULT_PORT)','    serve_parser.add_argument("--port", type=int, default=DEFAULT_PORT)\n    serve_parser.add_argument("--creator-mode", choices=("kernel","userspace-keeper"), default="kernel")')
s=replace(s,'    child = subprocess.Popen(\n        command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,\n        text=True, bufsize=1,\n    )', '    environment=None\n    if arguments.creator_mode == "userspace-keeper":\n        environment=os.environ.copy()\n        environment["OVERTE_PYMOBILEDEVICE3_SITE_PACKAGES"]=str(arguments.service_runtime/PYMOBILEDEVICE3_SITE_PACKAGES)\n        environment["OVERTE_PYMOBILEDEVICE3_XCTEST_HELPER"]=str(arguments.service_runtime/PYMOBILEDEVICE3_XCTEST_FILE.name)\n        environment["OVERTE_IOS_ADAPTER_SOURCE_ROOT"]=str(arguments.service_runtime/"original-owner-adapters")\n    child = subprocess.Popen(\n        command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,\n        text=True, bufsize=1, env=environment,\n    )')
ast.parse(s);entries.append(('repo',rel,raw,s))
# Existing Appium launch/terminate and plugin execute routes reuse the owner pipe.
rel='tests/device/ios/appium_wda_host_ops.js';raw=(r/rel).read_bytes();s=raw.decode()
s=replace(s,"import {spawn} from 'node:child_process';", "import {spawn} from 'node:child_process';\nimport {randomUUID} from 'node:crypto';")
s=replace(s,'const activeXctestKeepers = new Map();','const activeXctestKeepers = new Map();\n'+(p/'appium-route.js.fragment').read_text())
s=replace(s,'    const remoteXpc = await driver.remoteXPCFacade.requireModule();\n    const endpoint =', '    const remoteXpc = await driver.remoteXPCFacade.requireModule();\n    if (await tryOriginalKeeperLaunch(driver, remoteXpc, options)) return;\n    const endpoint =')
s=replace(s,'async function terminateExactRunner(driver, udid, bundleId) {','async function terminateExactRunner(driver, udid, bundleId) {\n    const original = originalKeeperRoutes.get(driver);\n    if (original) { await original.request(\'process-terminate\', {bundleId, originalPid: 0}, true); return; }')
a='        async terminate({udid, bundleId}) {\n            try {\n                const key = keeperKey(udid, bundleId);'
z='        async terminate({udid, bundleId}) {\n            const original = originalKeeperRoutes.get(driver);\n            if (original) { await original.cleanup(); return; }\n            try {\n                const key = keeperKey(udid, bundleId);'
s=replace(s,a,z);entries.append(('repo',rel,raw,s))
rel='tests/device/ios/process_plugin/index.cjs';raw=(r/rel).read_bytes();s=raw.decode()
s=replace(s,'  async execute(next, driver, script, args) {', "  async execute(next, driver, script, args) {\n    if (script === 'mobile: overteOriginalKeeperOperation') {\n      if (!Array.isArray(args) || args.length !== 1 || !args[0] || typeof args[0] !== 'object' ||\n          Object.keys(args[0]).sort().join(',') !== 'args,operation') throw new Error('OVT_IOS_ORIGINAL_KEEPER_UNAVAILABLE');\n      const original = driver[Symbol.for('overte.originalKeeperRoute.v1')];\n      if (!original || typeof original.request !== 'function') throw new Error('OVT_IOS_ORIGINAL_KEEPER_UNAVAILABLE');\n      // New typed source profile only. Never fabricate old Node DVT socket\n      // callbacks/connectionClosed-v1 from a Python provider exit.\n      return await original.request(args[0].operation, args[0].args);\n    }");entries.append(('repo',rel,raw,s))

rows=[];diff=''
for kind,rel,raw,s in entries:
 out=p/'candidates'/kind/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s)
 original=p/'originals'/kind/rel;original.parent.mkdir(parents=True,exist_ok=True);original.write_bytes(raw)
 rows.append(dict(kind=kind,path=rel,baseSHA256=sha(raw),candidateSHA256=sha(s.encode()),candidate=str(out),AST='PASS' if rel.endswith('.py') else 'UNPARSED SOURCE ONLY'))
 diff+=''.join(difflib.unified_diff(raw.decode().splitlines(True),s.splitlines(True),fromfile='a/'+kind+'/'+rel,tofile='b/'+kind+'/'+rel))
(p/'proposal.diff').write_text(diff);(p/'manifest.json').write_text(json.dumps({'status':'PRIVATE ACTIVE UNRUN NOT FROZEN','entries':rows,'diffSHA256':sha(diff.encode())},indent=2)+'\n');print(json.dumps({'paths':len(rows),'diffSHA256':sha(diff.encode())},indent=2))
