"""Complete quiet historical original inventories, including explicit new roots."""
from pathlib import Path
import hashlib,json,stat
HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    info=path.lstat();row={name:getattr(info,name)for name in FIELDS}
    if stat.S_ISREG(info.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    elif stat.S_ISLNK(info.st_mode):row['target']=str(path.readlink())
    else:assert stat.S_ISDIR(info.st_mode),'Historical special raw file'
    assert all(row[name]==getattr(path.lstat(),name)for name in FIELDS)
    return row
def roots():
    seed=json.loads((HERE/'global-original-roots-seed.json').read_text())
    found={Path(path)for path in seed['roots']}
    for directory in(REPO/'.ios-host-tmp').iterdir():
        if directory.is_dir()and not directory.is_symlink():
            for name in('temporary','runs'):
                path=directory/name
                if path.is_dir()and not path.is_symlink():found.add(path)
    for path in found:assert path.is_absolute()and path.resolve(strict=True)==path and not path.is_symlink()
    return sorted(found)
def current():
    return {str(root):{str(path.relative_to(root)):pin(path)for path in(root,*sorted(root.rglob('*')))}for root in roots()}
def guard(*,new_root=None):
    expected=json.loads((HERE/'global-original-corpus-baseline.json').read_text());actual=current()
    extra=set()
    if new_root is not None:
        new_root=Path(new_root);assert new_root==HERE/'temporary'and new_root.resolve(strict=True)==new_root
        extra={str(new_root)}
    assert set(actual)==set(expected)|extra,'Global historical/new-root namespace changed'
    assert all(actual[path]==row for path,row in expected.items()),'Historical original bytes/inodes changed'
    # The admitted own root is INCLUDED in this complete quiet inventory. It
    # never excludes a writer or hides its bytes from the terminal census.
    return actual
