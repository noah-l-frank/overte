"""Unrun lower transport controls; no SDK/native/model-effect authority."""
import unittest
from copy import deepcopy
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from ios.self_tests.assets_checkpoint_owned_fixture import Fixture,CheckpointNativeInput

class AssetsCheckpointNativeCompositionTests(unittest.TestCase):
    def setUp(self):
        self.f=Fixture(self)
        self.original=self.f.boundary.native_input()
        self.calls=[]
        def guard():self.calls.append('guard');return self.f.boundary.live
        self.native=CheckpointNativeInput(self.original,guard)

    def test_capture_uses_actual_original_receiver_and_original_receipt_once(self):
        seen=[];before=deepcopy(self.f.boundary.inputs);old=vars(self.original).get('observe_intent')
        self.native.observe_intent=lambda query:seen.append(deepcopy(query))
        result=self.native.capture()
        self.assertEqual(len(seen),1);self.assertEqual(seen[0]['operation'],'observe')
        self.assertEqual(self.native.last_receipt,self.original.last_receipt)
        self.assertEqual(result,self.original.last_receipt['observation'])
        self.assertEqual(self.f.boundary.inputs,before)
        self.assertIs(vars(self.original).get('observe_intent'),old)
        self.assertGreater(len(self.calls),1)

    def test_changed_actual_capture_function_refuses_before_query_or_input(self):
        before=deepcopy(self.f.boundary.inputs);called=[]
        def wrong(owner):called.append(owner);raise AssertionError('must not execute')
        with patch.object(type(self.original),'capture',wrong):
            with self.assertRaises((NativeUIError,AssertionError)):self.native.capture()
        self.assertEqual(called,[]);self.assertEqual(self.f.boundary.inputs,before)

    def test_lost_observe_intent_return_keeps_original_error_and_restores_callback_without_replay(self):
        error=NativeUIError('genuine observe-intent return was lost');calls=[]
        def lost(query):calls.append(deepcopy(query));raise error
        self.native.observe_intent=lost;before=deepcopy(self.f.boundary.inputs)
        old=vars(self.original).get('observe_intent');present='observe_intent'in vars(self.original)
        with self.assertRaises(NativeUIError)as actual:self.native.capture()
        self.assertIs(actual.exception,error);self.assertEqual(len(calls),1)
        self.assertEqual(self.f.boundary.inputs,before)
        self.assertEqual('observe_intent'in vars(self.original),present)
        self.assertIs(vars(self.original).get('observe_intent'),old)
