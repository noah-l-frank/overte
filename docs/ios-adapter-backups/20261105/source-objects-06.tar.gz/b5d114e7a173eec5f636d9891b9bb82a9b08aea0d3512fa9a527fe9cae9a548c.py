"""Read-only diagnostic on a retained Source/Input graph. Never dispatch input."""
from contextlib import ExitStack
import cProfile
from hashlib import sha256
import json
from pathlib import Path
import pstats
import socket
import subprocess
import time
from types import SimpleNamespace
from unittest.mock import patch

from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUI
from adapters.script_feature.history import unpack
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_original_lease import EmoteOriginalLease
from ios.adapters.world_web_sources import WorldWebSources
from ios.adapters.world_web_input import WorldWebInput
from ios.adapters.world_web_scope import IOSWorldWebScope
from ios.adapters.world_web_identity import WorldWebLease
from ios.adapters.world_web_api_clock import scope

REPO = Path.cwd()
ROOT = REPO / '.ios-host-tmp/tmp0c_d6uuj'
OUTPUT = REPO / '.ios-host-tmp/world-web-browser-history-readonly-profile-20261027.json'


def forbidden(*args, **kwargs):
    raise AssertionError('Read-only diagnostic forbids native/SDK/network/process/write effects')


def signatures():
    result = {}
    for path in ROOT.rglob('*'):
        if path.is_file():
            before = path.lstat(); raw = path.read_bytes(); after = path.lstat()
            need(EmoteOriginalLease.signature(before) == EmoteOriginalLease.signature(after))
            result[str(path.relative_to(ROOT))] = (EmoteOriginalLease.signature(after), sha256(raw).hexdigest())
    return result


need(ROOT.is_dir() and ROOT.resolve() == ROOT)
lock_path = ROOT / 'script-feature-sources.lock'
need(lock_path.is_file() and not lock_path.is_symlink())
originals = signatures()
source_store = PrivateFeatureState(ROOT / 'ios-world-web-primary-sources.json')
value = source_store.read(); need(value is not None)
state = unpack(value['payload'])[0]; need(state['pending'] is None)
first = PrivateFeatureState(ROOT / 'ios-world-web-primary-sources-1.json').read()
frame = unpack(first['payload'])[0]
phase = SimpleNamespace(fixture_url=frame['snapshotQueries'][0]['fixtureUrl'])
input_store = PrivateFeatureState(ROOT / 'ios-world-web-inputs.json')
input_value = input_store.read(); need(input_value is not None)
rows = unpack(input_value['payload'])[0]['records']
report = dict(scope='Read-only retained Source/Input model; no current product or timing acceptance',
    sourceRecords=len(state['records']), inputRecords=len(rows), originalFiles=len(originals), samples=[])
lock = ScriptSourceLock(lock_path)
with ExitStack() as stack:
    for target in ((PrivateFeatureState, 'write'), (PrivateFeatureState, 'discard'),
                   (subprocess, 'Popen'), (socket, 'create_connection')):
        stack.enter_context(patch.object(*target, side_effect=forbidden))
    stack.enter_context(lock.held())
    begun = time.perf_counter()
    source = WorldWebSources(source_store, lock, value['binding'], value['runId'], value['role'],
        lambda: True, phase=phase, historical=True)
    report['coldSourceSeconds'] = time.perf_counter() - begun
    begun = time.perf_counter()
    owner = WorldWebInput(input_store, source, NativeUI(None, value['binding']['sessionId'], forbidden),
        input_value['entityId'], forbidden)
    report['coldInputSeconds'] = time.perf_counter() - begun
    marker_store = PrivateFeatureState(ROOT / 'ios-worldweb-primary-marker.json')
    marker = marker_store.read(); need(marker is not None)
    marker_scope = IOSWorldWebScope.archive(marker, root=ROOT, binding=value['binding'],
        run=value['runId'], role='primary', lock=lock)
    marker_scope.store, marker_scope.previous = marker_store, marker
    marker_scope.files.store = PrivateFeatureState(ROOT / 'ios-worldweb-primary-marker-files.json')
    action_store = PrivateFeatureState(ROOT / 'ios-world-web-actions.json')
    action_value = action_store.read(); need(action_value is not None)
    action_state = unpack(action_value['payload'])[0]
    opening = action_state['calls'][0]; need(opening['call']['verb'] == 'open' and opening['phase'] == 'returned')
    lease = WorldWebLease(marker_scope, source, opening['before'], opening['after'])
    owned = lease.packet()
    profile = cProfile.Profile()
    # Historical sources must never enter their live append/input round.
    # Exercise actual readonly guards and its separate inventory lease instead.
    continuity = EmoteOriginalLease(ROOT, [source_store.path, input_store.path])
    with scope(time.monotonic), source.validation_round():
        for label, call in (('complete-browser-derivation', lambda: source.derive_browser(
                ownership=owned['files'], directory=owned['directory'],
                entity=owned['returned']['returned']['entityId'], origins=action_value['origins'])),):
            begun = time.perf_counter(); profile.enable()
            try:
                result = call()
            finally:
                profile.disable()
            report['samples'].append(dict(label=label, seconds=time.perf_counter() - begun))
    stats = pstats.Stats(profile)
    report['largestCumulative'] = [dict(file=key[0], line=key[1], function=key[2], calls=entry[1],
        internalSeconds=entry[2], cumulativeSeconds=entry[3])
        for key, entry in sorted(stats.stats.items(), key=lambda item: item[1][3], reverse=True)[:25]]
need(signatures() == originals)
need(input_store.read() == input_value)
report.update(originalFilesUnchanged=True, nativeExecuted=False, inputIssued=False, deviceQualified=False)
OUTPUT.write_text(json.dumps(report, indent=2) + '\n'); OUTPUT.chmod(0o600)
print(json.dumps(report))
