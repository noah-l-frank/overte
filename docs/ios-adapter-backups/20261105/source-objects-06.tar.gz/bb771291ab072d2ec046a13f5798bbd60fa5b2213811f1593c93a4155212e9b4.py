"""Prospective paired-factory lifetime/role/input counters; no device runtime."""
import unittest
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.script_feature.history import unpack
from adapters.script_feature.lock import ScriptSourceLock
from ios.self_tests.snapshot_paired_png_scope_domain import PairedPNGScopeDomain,TICKET
from ios.self_tests.test_ios_snapshot_actor_primary_png_join import counts,originals


class SnapshotPairedPNGScopeTests(unittest.TestCase):
    def test_genuine_sorted_paired_roles_feed_original_temporal_png_join_and_retire_scope_only(self):
        d=PairedPNGScopeDomain(self)
        with d.paired()as scope:
            self.assertEqual([('primary','primary'),('actor','actor')],d.source_calls)
            self.assertIs(scope.page.lock,scope.locks[0]if scope.locks[0].path==scope.page.lock.path else scope.locks[1])
            self.assertIs(scope.actors.lock,scope.actor.actors.lock)
            self.assertEqual(sorted(str(lock.path)for lock in scope.locks),[str(lock.path)for lock in scope.locks])
            for lock in scope.locks:lock.assert_held()
            scope.page.open(TICKET);scope.actor.observe_original(1,TICKET);anchor=scope.page.observe()
            scope.page.capture(TICKET);capture=d.primary.runtime.capture_child(scope.page);capture.provenance()
            slots=[row for row in capture.state['slots']if row['kind']=='provenance'];self.assertEqual(1,len(slots))
            scope.actor.observe_original(2,TICKET);before=counts(d);saved=originals(d)
            value=scope.originals(anchor,slots[0]['index']).proof()
            self.assertTrue(value['actorBeforePrimaryCaptureActorAfterOriginalOrderEstablished'])
            self.assertEqual(1,d.primary.capture.capture_count);self.assertEqual(2,len(d.pixel_queries));self.assertEqual(2,len(d.posts))
            self.assertEqual(before,counts(d));self.assertEqual(saved,originals(d))
            self.assertTrue(scope.nativeLatestFrameProcessLifetimeRequired);self.assertFalse(scope.pairedEndEstablished)
            held=d.renderer.current;lock_stats=[(lock.path,lock.path.stat().st_dev,lock.path.stat().st_ino)for lock in scope.locks]
        self.assertTrue(scope.closed);self.assertIs(held,d.renderer.current)
        with self.assertRaises(NativeUIError):scope.originals(anchor,slots[0]['index'])
        for path,device,inode in lock_stats:
            self.assertEqual((device,inode),(path.stat().st_dev,path.stat().st_ino))
            with ScriptSourceLock(path).held():pass

    def test_explicit_pixel_optin_false_refuses_before_sources_inputs_or_lock_birth(self):
        d=PairedPNGScopeDomain(self);before=counts(d);saved=originals(d)
        with self.assertRaises(NativeUIError):
            with d.paired(pixel_originals=False):self.fail('Missing explicit PNG opt-in entered the scope')
        self.assertEqual([],d.source_calls);self.assertEqual(before,counts(d));self.assertEqual(saved,originals(d))

    def test_same_genuine_reader_role_token_cannot_become_actor_role(self):
        d=PairedPNGScopeDomain(self);before=counts(d)
        with self.assertRaises(NativeUIError):
            with d.paired(actor_client=d.client()):self.fail('Same reader token entered Actor scope')
        self.assertEqual([],d.source_calls);self.assertEqual(before,counts(d))

    def test_actual_same_target_source_binding_refuses_without_ordinary_capture_or_actor_query(self):
        d=PairedPNGScopeDomain(self,same_target=True);before=counts(d)
        with self.assertRaises(NativeUIError):
            with d.paired():self.fail('Same target received two independent role owners')
        self.assertEqual([('primary','primary'),('actor','actor')],d.source_calls)
        self.assertEqual(before,counts(d));self.assertEqual(0,d.primary.capture.capture_count)
        for ctx in(d.primary.ctx,d.actor.ctx):
            with ScriptSourceLock(ctx.root/'script-feature-sources.lock').held():pass

    def test_real_false_actor_guard_during_constructor_releases_both_original_lock_domains(self):
        d=PairedPNGScopeDomain(self);d.actor.ctx.good=False;before=counts(d)
        with self.assertRaises(NativeUIError):
            with d.paired():self.fail('Failed actual source guard constructed a PixelSet')
        self.assertEqual(before,counts(d));self.assertEqual(0,d.primary.capture.capture_count)
        for ctx in(d.primary.ctx,d.actor.ctx):
            with ScriptSourceLock(ctx.root/'script-feature-sources.lock').held():pass

    def test_original_body_exception_survives_scope_exit_without_clearing_native_frame_or_sources(self):
        d=PairedPNGScopeDomain(self);error=RuntimeError('Original caller body failure');before=counts(d);held=d.renderer.current
        try:
            with d.paired()as scope:raise error
        except RuntimeError as actual:self.assertIs(error,actual)
        else:self.fail('Original caller exception was suppressed')
        self.assertTrue(scope.closed);self.assertIs(held,d.renderer.current);self.assertEqual(before,counts(d))
        for lock in scope.locks:
            with ScriptSourceLock(lock.path).held():pass

    def test_unknown_normal_capture_return_leaves_issued_original_and_never_runs_actor_after(self):
        d=PairedPNGScopeDomain(self);d.primary.capture.lost=True
        with d.paired()as scope:
            scope.page.open(TICKET);scope.actor.observe_original(1,TICKET);scope.page.observe()
            with self.assertRaises(OSError):scope.page.capture(TICKET)
            path=scope.page.store.path.with_name('ios-snapshot-primary-inputs.json')
            original=PrivateFeatureState(path).read();self.assertIsNotNone(original)
            events=unpack(original['payload'])[0]['events'];self.assertEqual('issued',events[-1]['phase'])
            self.assertEqual('snapshot.capture',events[-1]['controlId'])
            before=counts(d);saved=originals(d)
        self.assertTrue(scope.closed);self.assertEqual(1,d.primary.capture.capture_count)
        self.assertEqual(1,len(d.pixel_queries));self.assertEqual(1,len(d.posts))
        self.assertEqual(original,PrivateFeatureState(path).read());self.assertEqual(saved,originals(d));self.assertEqual(before,counts(d))
