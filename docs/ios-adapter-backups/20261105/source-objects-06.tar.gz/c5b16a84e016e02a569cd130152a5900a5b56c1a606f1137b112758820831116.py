"""Prospective normal14+new received-original composition; no hardware/End.

The original normal14 body must actually pass. Missing real Keeper/replacement
producers remain negative controls, never expected normal-flow success.
"""
from copy import deepcopy
import unittest
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from ios.adapters.audio_ordinary_received_pair import IOSAudioOrdinaryReceivedPair
from ios.self_tests.audio_ordinary_received_pair_fixture import AudioOrdinaryReceivedFixture
from ios.self_tests.test_ios_audio_whole import AudioWholeTests


class AudioOrdinaryReceivedPairTests(unittest.TestCase):
    def setUp(self):self.f=AudioOrdinaryReceivedFixture(self)
    def prepare(self):return AudioWholeTests.prepare(self)
    def normal(self):
        AudioWholeTests.test_normal14_actual_whole_runtime_actor_publication_and_original_evidence(self)
        self.f.primary.original_evidence_handoff();self.f.pair=self.f.pair_owner()
        return self.f.pair.retain()
    def test_normal14_new_received_originals_join_exact_phase_without_sound_route_promotion(self):
        value=self.normal();f=self.f
        self.assertTrue(value['normalAndReceivedOriginalsJoined']);self.assertEqual(f.capture_ticket,value['sourceTicket'])
        self.assertEqual(b''.join(packet[9:]for packet in f.packet_input.packets),f.received_actor.original(f.capture_ticket)['pcm'])
        self.assertNotEqual(value['received']['binding']['sessionId'],value['normalMedia']['actor']['binding']['sessionId'])
        for key in('individualTalkerQualified','causalOutputToMixerQualified','physicalADCQualified','physicalDACQualified','acousticQualified','nativeQualified','wholeQualified'):
            self.assertIs(value[key],False)
        self.assertFalse(f.manager.files);self.assertFalse(f.manager.owned)
    def test_pure_reopen_uses_actual_originals_without_any_live_sdk_or_input_replay(self):
        first=self.normal();f=self.f;commands=deepcopy(f.manager.commands);normal=deepcopy(f.once.boundary.commands);calls=f.source_calls
        f.manager.block=True;pair=f.pair_owner()
        with patch.object(f.received_runtime,'_sources',side_effect=AssertionError('No received SDK reacquisition')),patch.object(f.once.runtime,'_sources',side_effect=AssertionError('No original Actor reacquisition')),patch.object(f.once.p.runtime,'_sources',side_effect=AssertionError('No Primary reacquisition')):
            self.assertEqual(first,pair.original());self.assertEqual(first,pair.retain())
        self.assertEqual(commands,f.manager.commands);self.assertEqual(normal,f.once.boundary.commands);self.assertEqual(calls,f.source_calls)
    def test_normal_prefix_cannot_mint_pair_or_start_received_sdk_duty(self):
        self.prepare();f=self.f;pair=f.pair_owner();calls=f.source_calls
        with self.assertRaises((NativeUIError,ValueError)):pair.retain()
        self.assertIsNone(f.manager);self.assertEqual(0,f.received_adapter.original_guard_calls)
        self.assertEqual(calls,f.source_calls);self.assertIsNone(pair.state['frame'])
    def test_existing_normal_actor_sdk_cannot_be_relabelled_received_independence(self):
        self.normal();f=self.f;bad=deepcopy(f.configuration);bad['receivedTarget']=f.primary.actor_selector
        with self.assertRaises((NativeUIError,ValueError)):IOSAudioOrdinaryReceivedPair(f.primary,f.received_actor,bad)
        self.assertEqual(0,f.received_adapter.original_guard_calls)
    def test_changed_pair_original_inode_refuses_without_reacquisition(self):
        self.normal();f=self.f
        with f.pair.held():path=f.pair.codec().path(f.pair.codec().expand(f.pair.state['frame']))
        raw=path.read_bytes();path.rename(path.with_suffix('.retained'));path.write_bytes(raw);path.chmod(0o600)
        calls=f.source_calls;commands=deepcopy(f.manager.commands)
        with self.assertRaises((NativeUIError,ValueError,OSError)):f.pair.original()
        self.assertEqual(calls,f.source_calls);self.assertEqual(commands,f.manager.commands)
    def test_missing_actual_terminal_graph_never_completes_retained_media_pair(self):
        self.normal();f=self.f;commands=deepcopy(f.manager.commands);calls=f.source_calls
        with self.assertRaises((NativeUIError,ValueError)):f.pair.completed_original()
        self.assertFalse(f.pair.state['terminalFinishReturned']);self.assertIsNone(f.pair.state['receivedEnd'])
        self.assertEqual(commands,f.manager.commands);self.assertEqual(calls,f.source_calls)
    def test_repeated_real_cleanup_attempts_preserve_originals_and_missing_external_end_duty(self):
        original=self.normal();f=self.f;call=f.activate('cleanup','f'*32)
        # No consumer verdict is mocked. The declared fixture genuinely lacks
        # a composed Keeper/OS/replacement producer; the original failure and
        # durable process duty must survive each actual recovery attempt.
        for _ in range(2):
            with self.assertRaises((NativeUIError,ValueError,AttributeError)):f.pair.cleanup(call)
        self.assertEqual(2,f.pair.state['cleanupIssued']);self.assertEqual(0,f.pair.state['cleanupReturned'])
        self.assertFalse(f.pair.state['terminalFinishReturned']);self.assertEqual(original['sourceTicket'],f.pair.state['sourceTicket'])
        with f.pair.held():self.assertEqual(original,f.pair.codec().read(f.pair.codec().expand(f.pair.state['frame'])))
        self.assertEqual(1,f.manager.count('start'));self.assertEqual(1,f.manager.count('capture'));self.assertEqual(1,f.manager.count('release'))
