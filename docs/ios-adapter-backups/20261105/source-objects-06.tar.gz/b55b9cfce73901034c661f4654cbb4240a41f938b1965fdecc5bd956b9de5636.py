from pathlib import Path
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');H=R/'.ios-host-tmp/chat-root-loaded-object-identity-interface-20261028';C=H/'candidate';C.mkdir(mode=0o700,parents=True,exist_ok=False)
def put(name,text):
 p=C/name;p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.write_text(text)
name='libraries/qml/src/qml/IOSQmlSourceObservation.h';s=(R/name).read_text().replace('    static QList<QObject*> liveObjects() noexcept;','''    static QList<QObject*> liveObjects() noexcept;
    // Native diagnostic identity only: this exact live weak QObject's
    // existing observed-load birth. No code/source/retirement authority.
    static QVariantMap objectIdentity(QObject* object) noexcept;''');put(name,s)
name='libraries/qml/src/qml/IOSQmlSourceObservation.cpp';s=(R/name).read_text();needle='QVariantMap IOSQmlSourceObservation::read(QObject* object) noexcept {'
method='''QVariantMap IOSQmlSourceObservation::objectIdentity(QObject* object) noexcept {
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    try {
        if (!enabled() || !object || object->thread()!=QThread::currentThread()) return {};
        QPointer<QObject> selected(object);auto& owner=state();
        if (owner.failed || !selected) return {};
        const auto before=owner.clock();QVariantMap result;
        for (qsizetype index=0;index<owner.loads.size();++index) {
            const auto& row=owner.loads.at(index);
            if (!row.completed || !row.object || row.object!=selected) continue;
            // Pointer comparison stays internal and is guarded by the OLD
            // zeroing weak birth. A new object at a reused address cannot
            // revive that old row. Duplicate matches remain unavailable.
            if (!result.isEmpty() || row.ticket.isEmpty() || row.objectId.isEmpty()
                    || !row.context || !row.objectContext
                    || row.context->thread()!=QThread::currentThread()
                    || row.objectContext->thread()!=QThread::currentThread()
                    || QQmlEngine::contextForObject(selected.data())!=row.objectContext
                    || row.context->baseUrl().toString(QUrl::FullyEncoded)!=row.creationContextUrl
                    || row.objectContext->baseUrl().toString(QUrl::FullyEncoded)!=row.objectContextUrl) return {};
            result={{"qmlObservedLoadObjectIdentityVersion",1},{"observerInstance",owner.instance},
                {"loadSequence",qlonglong(index+1)},{"loadId",row.ticket},{"objectId",row.objectId},
                {"processId",QCoreApplication::applicationPid()},{"clockDomain","native-main-qml-load"},
                {"readBefore",before}};
        }
        if (!selected || selected.data()!=object || result.isEmpty() || owner.failed) return {};
        result.insert("readAfter",owner.clock());return result;
    } catch (...) { return {}; }
#else
    Q_UNUSED(object);return {};
#endif
}

'''
assert s.count(needle)==1;s=s.replace(needle,method+needle);put(name,s)
name='tests/device/native/IOSChatRootOwnership.h';s=(R/name).read_text().replace('#include <QVariantMap>','#include <QVariantMap>\n#include <qml/IOSQmlSourceObservation.h>\n#include <limits>')
s=s.replace('        QVariantMap ids;','        QVariantMap ids,loadedObjectIdentity;')
s=s.replace('    bool _ready {false},_failed {false};','    bool _ready {false},_failed {false},_observeLoadedObjects {false};\n    quint64 _census {0};')
s=s.replace('''    void begin() noexcept {
        _pages.clear();_ready=true;
    }''','''    void begin(bool observeLoadedObjects=false) noexcept {
        _pages.clear();_ready=true;_observeLoadedObjects=observeLoadedObjects;
        if (_census==std::numeric_limits<quint64>::max()) {_failed=true;_ready=false;return;}
        ++_census;
    }
    quint64 census() const noexcept { return _census; }''')
s=s.replace('            row.ids={{"page",_ledger.observe(item,"page",source)},','''            if (_observeLoadedObjects) {
                // This is the EXACT item being added by the existing walk,
                // never a URL/SHA/serialized-address association.
                row.loadedObjectIdentity=hifi::qml::IOSQmlSourceObservation::objectIdentity(item);
            }
            row.ids={{"page",_ledger.observe(item,"page",source)},''')
needle='    QVariantMap read(bool wholeTreeReady) noexcept {'
method='''    QVariantMap loadedObjectLinks(quint64 expectedCensus) const noexcept {
        if (!script_ui_roots::enabled() || _failed || !_ready || !_observeLoadedObjects
                || !expectedCensus || expectedCensus!=_census) return {};
        try {
            QVariantList links;
            for (const auto& row:_pages) {
                if (!row.item || row.item->thread()!=QThread::currentThread()
                        || row.loadedObjectIdentity.isEmpty()) return {};
                const auto current=hifi::qml::IOSQmlSourceObservation::objectIdentity(row.item.data());
                if (current.isEmpty()) return {};
                auto first=row.loadedObjectIdentity,second=current;
                first.remove("readBefore");first.remove("readAfter");
                second.remove("readBefore");second.remove("readAfter");
                if (first!=second || !row.item || expectedCensus!=_census) return {};
                const auto root=row.ids.value("page").toString();if (root.isEmpty()) return {};
                links.append(QVariantMap{{"rootIdentity",root},{"atWalk",row.loadedObjectIdentity},{"atRead",current}});
            }
            if (expectedCensus!=_census) return {};
            return {{"chatRootLoadedObjectLinksVersion",1},{"census",QString::number(_census)},{"links",links}};
        } catch (...) { return {}; }
    }
'''
assert s.count(needle)==1;s=s.replace(needle,method+needle);put(name,s)
name='tests/device/native/ChatViewObservation.h';s=(R/name).read_text();needle='''    QVariantMap request(const QVariantMap& input,const QList<QQuickItem*>& roots,bool tabletShown,const QVariantMap& nativeKeyboard) {
'''
replacement='''    QVariantMap request(const QVariantMap& input,const QList<QQuickItem*>& roots,bool tabletShown,const QVariantMap& nativeKeyboard) {
        return requestOriginal(input,roots,tabletShown,nativeKeyboard,false);
    }
#if defined(Q_OS_IOS)
    // Native-only opt-in diagnostic interface. No Probe/action, public DTO,
    // Draft/WAL/version or ordinary request output is changed by this packet.
    QVariantMap requestWithLoadedObjectIdentities(const QVariantMap& input,const QList<QQuickItem*>& roots,
            bool tabletShown,const QVariantMap& nativeKeyboard) {
        return requestOriginal(input,roots,tabletShown,nativeKeyboard,true);
    }
#endif
private:
    QVariantMap requestOriginal(const QVariantMap& input,const QList<QQuickItem*>& roots,bool tabletShown,
            const QVariantMap& nativeKeyboard,bool loadedObjectIdentities) {
'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
s=s.replace('        _roots.begin();','        _roots.begin(loadedObjectIdentities);const auto rootCensus=_roots.census();')
needle='''        return {{"chatViewVersion",version},{"commandId",id},{"runId",run},{"instance",_instance},
            {"sequence",static_cast<qulonglong>(++_sequence)},{"processId",QCoreApplication::applicationPid()},
            {"capturedEpochMs",captured},{"source",source}};'''
replacement='''        QVariantMap original{{"chatViewVersion",version},{"commandId",id},{"runId",run},{"instance",_instance},
            {"sequence",static_cast<qulonglong>(++_sequence)},{"processId",QCoreApplication::applicationPid()},
            {"capturedEpochMs",captured},{"source",source}};
#if defined(Q_OS_IOS)
        if (loadedObjectIdentities) {
            const auto links=_roots.loadedObjectLinks(rootCensus);if (links.isEmpty()) return {};
            return {{"chatViewLoadedObjectIdentityCutVersion",1},{"view",original},{"objectLinks",links}};
        }
#else
        Q_UNUSED(loadedObjectIdentities);
#endif
        return original;'''
assert s.count(needle)==1;s=s.replace(needle,replacement);put(name,s)
print(H)
