from pathlib import Path
import ast,difflib,hashlib,json,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';P=T/'lifecycle-original-owner-child-bundle-profile-proposal-20261028';OLD=T/'lifecycle-original-owner-motion14-empty-map-corrected-root-preparation-20261028/13-owned-motion14';REG=T/'lifecycle-original-owner-motion-owned-root-preparation-20261028/12-default-acquisition8';INST=T/'lifecycle-original-owner-installed-query6-root-preparation-20261028/08-installed-query6';QUERY=T/'lifecycle-original-owner-native-query10-final-compat-root-preparation-20261028/06-query10';FILE=T/'lifecycle-original-owner-native-file8-post-query-root-preparation-20261028/07-native8-regression';TOP=T/'lifecycle-original-owner-child-bundle-root-preparation-20261028';TOP.mkdir(mode=0o700);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(P/'freeze.json')=='bf8f9d1af61b75fc926a470a45cd28c375b2701217c2b9180f7c27df10ce4015'
for rel,digest in json.loads((P/'freeze.json').read_text())['files'].items():assert h(P/rel)==digest
source=json.loads((OLD/'source-manifest.json').read_text());bundle=json.loads((P/'manifest.json').read_text());inst_plan=json.loads((INST/'run-plan.json').read_text());native_plan=json.loads((REG/'run-plan.json').read_text());query_plan=json.loads((QUERY/'run-plan.json').read_text());file_plan=json.loads((FILE/'run-plan.json').read_text())
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=h(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((OLD/'prior-retained-original-pins.json').read_text())
for parent,count in [(OLD,47),(REG,36)]:
 root=parent/'retained-first';assert root.is_dir();assert sum(p.is_file() for p in root.rglob('*'))==count
 for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
assert sum('sha256' in v for v in prior.values())==243
for number,name,new in [(14,'14-child-bundle12',True),(15,'15-default-native-query-installed24',False)]:
 S=TOP/name;S.mkdir(mode=0o700)
 for filename in ['root-child.py','root-supervise.py','root_stage_guard.py','source_model_bindings.py','sdk-original-pins.json','supervisor-plan.json']:shutil.copyfile(OLD/filename,S/filename)
 shutil.copyfile(INST/'run-selected.py',S/'run-selected.py')
 stage=json.loads(json.dumps(source));rows={r['path']:r for r in stage['sourcePaths']};owned={r['path']:r for r in bundle['files']}
 req=set().union(*(set(p['requiredPublicDependencies']) for p in [inst_plan,native_plan,query_plan,file_plan]))
 req|={'tests/device/ios/self_tests/test_ios_bundle_observation.py'}
 snapshots=[]
 for relative in sorted(set(rows)|req|set(owned)):
  if relative in owned:
   row=owned[relative];rows[relative]=dict(path=relative,candidate=row['candidate'],candidateSHA256=row['candidateSHA256'],observedPublicSHA256=h(R/relative),changesCurrentPublic=h(R/relative)!=row['candidateSHA256'],ownThreeLinesOnly=row.get('ownThreeLinesOnly',False));continue
  current=h(R/relative)
  if relative not in rows or rows[relative]['candidateSHA256']!=current:
   old=rows.get(relative,{}).get('candidateSHA256');out=S/'actual-dependency-snapshots/repo'/relative;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/relative,out)
   snapshots.append(dict(path=relative,previous=old,current=current));rows[relative]=dict(path=relative,candidate=str(out),candidateSHA256=current,observedPublicSHA256=current,changesCurrentPublic=False)
 stage.update(stage=number,name=name,status='PRIVATE_UNRUN_BUNDLE_SOURCE12' if new else 'PRIVATE_UNRUN_DEFAULT24_POST_BUNDLE',caseCount=12 if new else 24,pythonCaseCount=12 if new else 24,nodeCaseCount=0,sourcePaths=list(rows.values()),sourcePathCount=len(rows),sourceDeltaPaths=list(owned),exactPublicMutationPlan='Root only exact Source2 +own3 family lines per shared file. NEVER stale whole shared apply; actual full Root map before imports.')
 stage['orderedParentFreezes'][P.name]=h(P/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n')
 plan=json.loads(json.dumps(inst_plan));plan.update(status='PRIVATE_UNRUN_EXACT_NEW_BUNDLE12' if new else 'PRIVATE_UNRUN_EXACT_OLD_NATIVE8_QUERY10_INSTALLED6',caseCount=12 if new else 24,totalCaseCount=12 if new else 24,initialOuterSeconds=60,killAfterSeconds=5,expectedRetainedRoots=24 if new else 30,mkdtempAliases=[],retainInstalledFixture=False)
 plan['requiredPublicDependencies']=sorted(req|set(rows))
 plan['modelMaps']=dict(inst_plan['modelMaps'])
 plan['modelMaps']['LIFECYCLE_NATIVE_FILE_MAP']=native_plan['modelMaps']['LIFECYCLE_NATIVE_FILE_MAP']
 if new:
  model_names=['test_child_bundle_profile_models.py','test_installed_child_bundle_models.py','installed_query_fixture.py','native_file_fixture.py']
  for n in model_names:shutil.copyfile(P/n,S/n)
  plan['cases']=json.loads((P/'test-plan.json').read_text())['cases']
 else:
  model_names=['test_native_file_channel_models.py','test_native_query_owner_models.py','test_installed_query_candidate_models.py']
  for folder,n in [(FILE,model_names[0]),(QUERY,model_names[1]),(INST,model_names[2])]:shutil.copyfile(folder/n,S/n)
  plan['cases']=file_plan['cases']+query_plan['cases']+inst_plan['cases'];plan['modelMaps']['LIFECYCLE_NATIVE_QUERY_MAP']=query_plan['modelMaps']['LIFECYCLE_NATIVE_QUERY_MAP']
 plan['retainedTemporaryDirectoryAliases']=['ios.self_tests.test_ios_touch_lease','ios.self_tests.test_ios_bundle_identity','ios.self_tests.test_ios_installed_adapter']
 for key in ['original-keeper-native-file','original-keeper-native-query','original-keeper-installed-query']:plan['registryRequirements'][key]=dict(current=2,reads=[1,2])
 for key,value in native_plan['registryRequirements'].items():
  if key not in plan['registryRequirements']:plan['registryRequirements'][key]=value
 plan['privateFiles']={n:h(S/n) for n in ['root_stage_guard.py','source_model_bindings.py','run-selected.py',*model_names]}
 plan['qualification']='Explicit source/RSD/AFC/native/WDA producer models. New source8 actual loopback HTTP/raw FDs/WAL; physical4 actual selected IPA and directory files/InstalledCodeBinding/SessionStore with existing modeledHTTP transport. No SDK/native/auth/canonical/child-candidate qualification.'
 (S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 (S/'source2.diff').write_bytes((P/'source2.diff').read_bytes());(S/'own-three-lines.diff').write_bytes((P/'own-registry-three-lines.diff').read_bytes())
 (S/'clone-provenance.json').write_text(json.dumps(dict(parentRootFreezeSHA256=h(OLD/'freeze.json'),bundleFreezeSHA256=h(P/'freeze.json'),actualPriorFiles=243,sourcePathCount=len(rows),currentDependencyUpdates=snapshots,pythonCount=plan['caseCount'],initialSeconds=60,killAfterSeconds=5,expectedRealRoots=plan['expectedRetainedRoots'],oldDefaultModelsLiteral=not new,sourceModelsOnly=True,executed=False,publicChanges=False),indent=2)+'\n')
 (S/'README.txt').write_text(('Exact NEW12 (source8+physical4), expected24 genuine retained roots.\n' if new else 'Exact unchanged old default Native8+Query10+Installed6=24, expected30 real roots.\n')+'''Root ONLY / PRIVATE UNRUN. Initial fixed60+kill5 selected BEFORE first run.
Source2 depends on Motion3/1497 now Root-published. Own file/query/installed-query
registry families1->2 reads1/2 only; never apply whole old shared candidates.
Strict actual Source+launcher+SDK bytes/stat pins, actual broad Root map AFTER
publication BEFORE any target imports. Every old243 actual original file and
all recorded nodes remain byte/stat pinned. Two fresh original censuses after
actual task/thread/child/FD cleanup, no fake await/close/GC or FD ignore. Three
fixture-local REAL TemporaryDirectory aliases + existing retain_owned_root,
global tempfile stays literal. Original fixture callbacks LIFO and asyncTearDown
preserved. Explicit full IDs exclude inherited/imported legacy duplicates.
Actual selected AST/code hashes describe model provenance, not executed binary.
Source8 real loopback HTTP; physical4 HTTP/nativeSDK boundaries remain modeled.
Native file/SDK auth/child installed-candidate/motion/end/canonical remain false.
All model modules AST-only; no agent test/import/Node/compiler/device execution.
Root from repo: PYTHONDONTWRITEBYTECODE=1 python3 <stage>/root-supervise.py
''')
 for p in S.rglob('*.py'):ast.parse(p.read_bytes(),filename=str(p))
 (S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_ROOT_BUNDLE12_AND_DEFAULT24',files={str(p.relative_to(S)):h(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n')
 print(name,h(S/'freeze.json'),'sources',len(rows),'snapshots',snapshots)
(TOP/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_BOTH_STAGES',files={str(p.relative_to(TOP)):h(p) for p in sorted(TOP.rglob('*')) if p.is_file()}),indent=2)+'\n');print('parent',h(TOP/'freeze.json'))
