"""Exact declared module origins; genuine interpreter fallback only.

This module imports no project/Pillow/SDK source. All origin pins must already
be in Root's approved input before a project or external module executes.
"""
from pathlib import Path
from types import ModuleType, BuiltinFunctionType, FunctionType, CodeType, FrameType
import builtins
import hashlib
import stat
import importlib.machinery as machinery
import importlib.util as util
import os
import sys

# Interpreter entry points are retained at controller-module birth, before
# any project admission. No replacement compile/exec hook is installed.
_ORIGINAL_COMPILE = builtins.compile
_ORIGINAL_EXEC = builtins.exec
_ORIGINAL_GETFRAME = sys._getframe
_ORIGINAL_IMPORT_MODULE = sys.modules['importlib'].import_module
_CFFI_RUST_NAME = 'cryptography.hazmat.bindings._rust'
_CFFI_CARRIER_NAME = '_openssl.lib'
_CFFI_BINARY_SHA256 = (('cryptography.hazmat.bindings._rust', '3d6423664bffe926fd91d1913d1c5ddda5c31ee7ff1cae06fc8b71c47c9501a1'), ('_cffi_backend', '7d1eff7fbb874ee72228fd426103da2b9eef528979156077bdec736d5b4f61a2'))
# This is one qualified original-source transaction profile, not authority
# for arbitrary same-name modules or future library versions.
_DEFUSED_ET_SOURCE = '/usr/lib/python3.14/site-packages/defusedxml/ElementTree.py'
_DEFUSED_ET_SHA256 = '18b4aaa42cf9f285c63c6cb37ff1f296c3d2f7f75c1953f948de1d2bbcafc8fc'
_STDLIB_ET_SHA256 = '850760098750fbce571ca4411ec444e70d73a0afe3efe74541d4eb99b3ab1b63'


class ClosedOrigins:
    def __init__(self, plan, source, repo, pin):
        self.plan, self.source, self.repo, self.pin = plan, source, repo, pin
        self.projects = plan['modules']
        self.third = plan['thirdPartyModules']
        self.project_namespaces = plan['namespacePackages']
        self.third_namespaces = plan['thirdPartyNamespacePackages']
        self.std_namespaces = plan['stdlibNamespacePackages']
        self.std = tuple(Path(value) for value in plan['stdlibRoots'])
        # os is a genuine already bootstrapped interpreter module. Its actual
        # source location is used, not sysconfig's unrelated /usr/local prefix.
        actual_std = Path(vars(os)['__file__']).resolve(strict=True).parent
        assert self.std == (actual_std,)
        assert actual_std.is_dir() and not self.excluded(actual_std)
        self.python = Path(sys.executable).resolve(strict=True)
        assert str(self.python) == plan['pythonExecutable']['path']
        assert self.pin(self.python) == plan['pythonExecutable']['pin'] == plan['physicalPins'][str(self.python)]
        assert not set(self.projects).intersection(self.third)
        assert not set(self.project_namespaces).intersection(self.third_namespaces)
        self.admissions = {}
        self.observed_files = {}
        self.observed_namespaces = {}
        self.snapshot_count = 0
        self.python_executions = {}
        self.extension_executions = {}
        self.compiler, self.executor = _ORIGINAL_COMPILE, _ORIGINAL_EXEC
        self.source_read_ports = (os.open, os.read, os.fstat, os.close)
        self.compilation_ports_bound()
        self.extension_child_receivers = {}
        self.extension_alias_receivers = {}
        self.cffi_export = None
        self.cffi_export_failed = False
        self.source_class = machinery.SourceFileLoader
        self.extension_class = machinery.ExtensionFileLoader
        self.path_finder = machinery.PathFinder
        self.builtin = machinery.BuiltinImporter
        self.frozen = machinery.FrozenImporter
        self.initial_modules = dict(sys.modules)
        self.defused_outer = None
        self.defused_et = None
        self.defused_failed = False
        self.defused_modules = sys.modules
        self.defused_importer = (_ORIGINAL_IMPORT_MODULE, _ORIGINAL_IMPORT_MODULE.__code__, _ORIGINAL_IMPORT_MODULE.__globals__)
        self.defused_controls = tuple((owner, name, function, function.__code__, function.__globals__)
            for owner in (ClosedOrigins, PinnedDelegate)
            for name, member in owner.__dict__.items()
            for function in (member.__func__ if type(member) is staticmethod else member,)
            if type(function) is FunctionType)
        self.snapshot('before-project-imports')

    @staticmethod
    def excluded(path):
        return any(part in ('site-packages', 'dist-packages') for part in path.parts)

    def physical(self, raw):
        path = Path(raw)
        assert path.is_absolute() and path.resolve(strict=True) == path
        expected = self.plan['physicalPins'].get(str(path))
        assert expected is not None, 'Module origin not independently pinned before import: ' + str(path)
        actual = self.pin(path)
        assert actual == expected
        if str(path) in self.observed_files:
            assert self.observed_files[str(path)] == actual
        else:
            self.observed_files[str(path)] = actual
        return path

    def namespaces(self, name, raw_roots, expected, kind):
        assert type(raw_roots) in (list, tuple) and raw_roots
        # Resolve each actual and each separately declared root exactly once.
        actual = tuple(Path(raw).resolve(strict=True) for raw in raw_roots)
        declared = tuple(Path(raw).resolve(strict=True) for raw in expected)
        assert actual == declared and len(set(actual)) == len(actual)
        if kind == 'stdlib':
            assert all(any(real.is_relative_to(root) for root in self.std)
                and not self.excluded(real) for real in actual)
        else:
            assert all(real.is_dir() for real in actual)
        value = dict(kind=kind, roots=[str(real) for real in actual])
        if name in self.observed_namespaces:
            assert self.observed_namespaces[name] == value
        else:
            self.observed_namespaces[name] = value
        return value

    def genuine_special(self, spec):
        assert spec is not None
        if spec.origin == 'built-in':
            actual = self.builtin.find_spec(spec.name)
            assert spec.loader is self.builtin and actual is not None and actual.origin == 'built-in'
            return 'builtin'
        if spec.origin == 'frozen':
            actual = self.frozen.find_spec(spec.name)
            assert spec.loader is self.frozen and actual is not None and actual.origin == 'frozen'
            return 'frozen'
        raise AssertionError('Not a genuine interpreter module')

    def defused_controls_bound(self):
        assert type(self) is ClosedOrigins and sys.modules is self.defused_modules and type(sys.modules) is dict
        for owner, name, function, code, namespace in self.defused_controls:
            member = owner.__dict__.get(name)
            actual = member.__func__ if type(member) is staticmethod else member
            assert actual is function and function.__code__ is code and function.__globals__ is namespace
        function, code, namespace = self.defused_importer
        importer = sys.modules['importlib']
        assert importer.import_module is function is _ORIGINAL_IMPORT_MODULE
        assert function.__code__ is code and function.__globals__ is namespace is vars(importer)
        assert sys._getframe is _ORIGINAL_GETFRAME

    def defused_begin_outer(self, delegate, module, namespace, code, path, digest, size):
        if delegate.name != 'defusedxml.ElementTree':
            return None
        self.defused_controls_bound()
        assert self.defused_outer is None and self.defused_et is None and not self.defused_failed
        assert delegate.kind == 'third-party' and self.third.get(delegate.name) == delegate.row
        assert path == Path(_DEFUSED_ET_SOURCE) and digest == _DEFUSED_ET_SHA256
        assert delegate.row['loader'] == 'source' and type(delegate.original) is self.source_class
        assert vars(module)['__spec__'].loader is delegate and sys.modules.get(delegate.name) is module
        assert namespace is vars(module) and code.co_filename == str(path)
        caller = _ORIGINAL_GETFRAME(1)
        assert type(caller) is FrameType and caller.f_code is type(self).execute_python_source.__code__
        assert caller.f_globals is type(self).execute_python_source.__globals__ and caller.f_locals.get('self') is self
        assert caller.f_locals.get('delegate') is delegate and caller.f_locals.get('module') is module and caller.f_locals.get('code') is code
        codes = [value for value in code.co_consts if type(value) is CodeType and value.co_name == '_get_py3_cls']
        assert len(codes) == 1 and not codes[0].co_flags & 0x20
        entry = dict(delegate=delegate, module=module, namespace=namespace, code=code, path=path,
            digest=digest, size=size, sourceFrame=caller, functionCode=codes[0], state='outer-executing')
        self.defused_outer = entry
        return entry

    def defused_live_function(self):
        self.defused_controls_bound()
        entry = self.defused_outer
        assert entry is not None and not self.defused_failed
        assert sys.modules.get('defusedxml.ElementTree') is entry['module']
        assert vars(entry['module']) is entry['namespace'] and entry['namespace'].get('sys') is sys
        assert entry['namespace'].get('importlib') is sys.modules['importlib']
        function = entry['namespace'].get('_get_py3_cls')
        assert type(function) is FunctionType and function.__code__ is entry['functionCode']
        assert function.__globals__ is entry['namespace'] and function.__closure__ is None
        assert function.__defaults__ is None and function.__kwdefaults__ is None
        frame = _ORIGINAL_GETFRAME(1);matches = []
        for _ in range(64):
            if frame is None:break
            if frame.f_code is entry['functionCode'] and frame.f_globals is entry['namespace']:
                parent = frame.f_back
                if (type(parent) is FrameType and parent.f_code is entry['code'] and parent.f_globals is entry['namespace']
                        and parent.f_back is entry['sourceFrame']):matches.append(frame)
            frame = frame.f_back
        assert len(matches) == 1
        original = entry['sourceFrame']
        assert original.f_code is type(self).execute_python_source.__code__ and original.f_globals is type(self).execute_python_source.__globals__
        assert original.f_locals.get('self') is self and original.f_locals.get('delegate') is entry['delegate']
        assert original.f_locals.get('module') is entry['module'] and original.f_locals.get('code') is entry['code']
        return entry, function, matches[0]

    def defused_begin_pure(self, delegate, module, namespace, code, path, digest, size):
        if delegate.name != 'xml.etree.ElementTree':
            return None
        previous = self.python_executions.get(delegate.name)
        if previous is None:
            # A saved HOSTBOOTSTRAP receiver is not a fabricated fresh source
            # execution proof. The actual pure branch cannot use that absence.
            original = self.initial_modules.get(delegate.name)
            assert original is None or original is module, 'Unsupported preloaded-only ET receiver replacement'
            assert self.defused_outer is None or '_get_py3_cls' not in self.defused_outer['namespace'], 'Pure ET import lacks original canonical execution proof'
            return None
        if previous[0] is module:
            assert self.defused_et is None or self.defused_et.get('pure') is not module
            return None
        entry, function, frame = self.defused_live_function()
        caller = _ORIGINAL_GETFRAME(1)
        assert type(caller) is FrameType and caller.f_code is type(self).execute_python_source.__code__ and caller.f_globals is type(self).execute_python_source.__globals__
        assert caller.f_locals.get('self') is self and caller.f_locals.get('delegate') is delegate and caller.f_locals.get('module') is module and caller.f_locals.get('code') is code
        assert self.defused_et is None and entry['state'] == 'outer-executing'
        assert delegate.kind == 'stdlib' and path == self.std[0] / 'xml' / 'etree' / 'ElementTree.py'
        assert digest == _STDLIB_ET_SHA256
        assert type(delegate.original) is self.source_class and delegate.original.name == delegate.name
        assert vars(module)['__spec__'].loader is delegate and namespace is vars(module) and sys.modules.get(delegate.name) is module
        local = frame.f_locals
        assert local.get('pymodname') == delegate.name and local.get('cmodname') == '_elementtree'
        canonical = local.get('pymod');accelerator = local.get('cmod')
        assert type(canonical) is ModuleType and canonical is previous[0] and canonical is not module
        assert previous[1] == path and previous[2] == digest and previous[3] == size
        assert self.python_executions[delegate.name] is previous
        admission = self.admissions.get(delegate.name);assert type(admission) is dict
        binary = self.extension_executions.get('_elementtree')
        assert type(accelerator) is ModuleType and binary is not None and binary[0] is accelerator
        assert '_elementtree' in sys.modules and sys.modules['_elementtree'] is None
        package = sys.modules['xml.etree'];assert type(package) is ModuleType and vars(package).get('ElementTree') is canonical
        canonical_spec = vars(canonical)['__spec__'];binary_spec = vars(accelerator)['__spec__']
        assert type(canonical_spec) is machinery.ModuleSpec and type(binary_spec) is machinery.ModuleSpec
        assert type(canonical_spec.loader) is PinnedDelegate and canonical_spec.loader.guard is self
        assert canonical_spec.loader.name == delegate.name and canonical_spec.origin == str(path)
        assert type(binary_spec.loader) is PinnedDelegate and binary_spec.loader.guard is self
        assert binary_spec.loader.name == '_elementtree' and type(binary_spec.loader.original) is self.extension_class
        assert self.physical(vars(canonical)['__file__']) == path and self.physical(vars(accelerator)['__file__']) == binary[1]
        parse_error = entry['namespace'].get('ParseError');assert parse_error is vars(canonical).get('ParseError')
        record = dict(state='pure-executing', outer=entry, function=function, frame=frame, canonical=canonical,
            canonicalExecution=previous, canonicalAdmission=admission, canonicalSpec=canonical_spec,
            accelerator=accelerator, acceleratorExecution=binary, acceleratorSpec=binary_spec, package=package,
            pure=module, pureSpec=vars(module)['__spec__'], delegate=delegate, path=path, digest=digest, size=size,
            code=code, pureSourceFrame=caller, pureExecution=None, pureAdmission=None, parseError=parse_error)
        self.defused_et = record
        return record

    def defused_complete_pure(self, record, module, path, digest, size):
        entry, function, frame = self.defused_live_function()
        assert self.defused_et is record and record['state'] == 'pure-executing'
        caller = _ORIGINAL_GETFRAME(1)
        assert caller is record['pureSourceFrame'] and caller.f_code is type(self).execute_python_source.__code__ and caller.f_globals is type(self).execute_python_source.__globals__
        assert caller.f_locals.get('self') is self and caller.f_locals.get('delegate') is record['delegate'] and caller.f_locals.get('module') is module
        assert entry is record['outer'] and function is record['function'] and frame is record['frame']
        assert sys.modules.get('xml.etree.ElementTree') is module is record['pure']
        assert '_elementtree' in sys.modules and sys.modules['_elementtree'] is None
        assert path == record['path'] and digest == record['digest'] and size == record['size']
        assert self.python_executions['xml.etree.ElementTree'] is record['canonicalExecution']
        assert self.admissions['xml.etree.ElementTree'] is record['canonicalAdmission']
        record['pureExecution'] = (module, path, digest, size)
        record['state'] = 'pure-executed'

    def defused_pure_execution_row(self, name, module, actual):
        record = self.defused_et
        assert record is not None and self.defused_outer is record['outer'] and not self.defused_failed
        entry, function, frame = self.defused_live_function()
        assert record['state'] == 'pure-executed' and function is record['function'] and frame is record['frame']
        assert name == 'xml.etree.ElementTree' and module is record['pure'] and sys.modules.get(name) is module
        assert actual == record['path'] and record['pureExecution'][0] is module
        # This special receipt is usable only in the real pure delegate's
        # internal source_row call, not a full snapshot or arbitrary lookup.
        caller = _ORIGINAL_GETFRAME(1);source = caller.f_back;delivery = None if source is None else source.f_back
        assert caller.f_code is type(self).execution_row.__code__ and caller.f_globals is type(self).execution_row.__globals__
        assert type(source) is FrameType and source.f_code is type(self).source_row.__code__ and source.f_globals is type(self).source_row.__globals__
        assert source.f_locals.get('self') is self and source.f_locals.get('module') is module
        assert type(delivery) is FrameType and delivery.f_code is PinnedDelegate.exec_module.__code__ and delivery.f_globals is PinnedDelegate.exec_module.__globals__
        assert delivery.f_locals.get('self') is record['delegate'] and delivery.f_locals.get('module') is module
        return dict(kind='fresh-pinned-python-source-bytes', sourceSha256=record['digest'], sourceBytes=record['size'], cachedBytecodeConsulted=False)

    def defused_admission(self, delegate, module, value):
        record = self.defused_et
        if record is not None and module is record['pure']:
            self.defused_live_function()
            caller = _ORIGINAL_GETFRAME(1)
            assert type(caller) is FrameType and caller.f_code is PinnedDelegate.exec_module.__code__ and caller.f_globals is PinnedDelegate.exec_module.__globals__
            assert caller.f_locals.get('self') is delegate and caller.f_locals.get('module') is module and caller.f_locals.get('value') is value
            assert self.defused_outer is record['outer'] and record['state'] == 'pure-executed'
            assert delegate is record['delegate'] and record['pureAdmission'] is None
            assert self.python_executions['xml.etree.ElementTree'] is record['canonicalExecution']
            assert self.admissions['xml.etree.ElementTree'] is record['canonicalAdmission']
            record['pureAdmission'] = value
            return
        self.admissions[delegate.name] = value

    def defused_abort(self, outer, pure, error):
        # Preserve the real Source exception. This is failed-state retention,
        # not a successful restoration or retry permission.
        self.defused_failed = True
        if pure is not None:pure['state'] = 'failed';pure['originalError'] = error
        if outer is not None:outer['state'] = 'failed';outer['originalError'] = error;self.defused_outer = None

    def defused_complete_outer(self, entry):
        self.defused_controls_bound()
        record = self.defused_et
        assert self.defused_outer is entry and record is not None and record['outer'] is entry
        caller = _ORIGINAL_GETFRAME(1)
        assert caller is entry['sourceFrame'] and caller.f_code is type(self).execute_python_source.__code__ and caller.f_globals is type(self).execute_python_source.__globals__
        assert caller.f_locals.get('self') is self and caller.f_locals.get('delegate') is entry['delegate'] and caller.f_locals.get('module') is entry['module'] and caller.f_locals.get('code') is entry['code']
        assert record['state'] == 'pure-executed' and record['pureAdmission'] is not None
        frame = record['frame'];function = record['function'];local = frame.f_locals
        assert type(frame) is FrameType and frame.f_code is entry['functionCode'] and frame.f_globals is entry['namespace']
        assert entry['namespace'].get('_get_py3_cls') is function and function.__code__ is entry['functionCode'] and function.__globals__ is entry['namespace']
        assert local.get('pymodname') == 'xml.etree.ElementTree' and local.get('cmodname') == '_elementtree'
        assert local.get('pymod') is record['canonical'] and local.get('cmod') is record['accelerator']
        assert local.get('pure_pymod') is record['pure'] and local.get('etree_pkg') is record['package']
        assert sys.modules.get('xml.etree.ElementTree') is record['canonical'] and sys.modules.get('_elementtree') is record['accelerator']
        assert sys.modules.get('xml.etree') is record['package'] and vars(record['package']).get('ElementTree') is record['canonical']
        assert vars(record['canonical']).get('__spec__') is record['canonicalSpec'] and vars(record['accelerator']).get('__spec__') is record['acceleratorSpec']
        assert vars(record['pure']).get('__spec__') is record['pureSpec'] and record['pureSpec'].loader is record['delegate']
        assert self.python_executions['xml.etree.ElementTree'] is record['canonicalExecution']
        assert self.extension_executions['_elementtree'] is record['acceleratorExecution']
        assert self.admissions['xml.etree.ElementTree'] is record['canonicalAdmission']
        assert vars(record['pure']).get('ParseError') is record['parseError'] is entry['namespace'].get('ParseError')
        assert local.get('_XMLParser') is vars(record['pure']).get('XMLParser') is entry['namespace'].get('_XMLParser')
        assert local.get('_iterparse') is vars(record['pure']).get('iterparse') is entry['namespace'].get('_iterparse')
        assert record['pureExecution'] == (record['pure'],record['path'],record['digest'],record['size'])
        self.physical(record['path']);self.physical(record['acceleratorExecution'][1]);self.physical(entry['path'])
        record['state'] = 'complete';entry['state'] = 'complete';self.defused_outer = None

    def defused_transaction_original(self):
        self.defused_controls_bound()
        record = self.defused_et
        assert record is not None and record['state'] == 'complete' and self.defused_outer is None and not self.defused_failed
        assert sys.modules.get('xml.etree.ElementTree') is record['canonical'] and sys.modules.get('_elementtree') is record['accelerator']
        assert vars(record['package']).get('ElementTree') is record['canonical']
        assert self.python_executions['xml.etree.ElementTree'] is record['canonicalExecution']
        assert self.admissions['xml.etree.ElementTree'] is record['canonicalAdmission']
        assert self.extension_executions['_elementtree'] is record['acceleratorExecution']
        entry = record['outer'];function = record['function']
        assert sys.modules.get('defusedxml.ElementTree') is entry['module'] and vars(entry['module']) is entry['namespace']
        assert entry['namespace'].get('_get_py3_cls') is function and function.__code__ is entry['functionCode'] and function.__globals__ is entry['namespace']
        assert sys.modules.get('xml.etree') is record['package']
        assert vars(record['canonical']).get('__spec__') is record['canonicalSpec'] and vars(record['accelerator']).get('__spec__') is record['acceleratorSpec']
        assert vars(record['pure']).get('__spec__') is record['pureSpec'] and record['pureSpec'].loader is record['delegate']
        assert vars(record['pure']).get('ParseError') is record['parseError'] is entry['namespace'].get('ParseError')
        assert vars(record['pure']).get('XMLParser') is entry['namespace'].get('_XMLParser')
        assert vars(record['pure']).get('iterparse') is entry['namespace'].get('_iterparse')
        self.physical(record['path']);self.physical(record['outer']['path']);self.physical(record['acceleratorExecution'][1])
        return dict(profile='defusedxml-original-single-et-transaction-v1',canonicalName='xml.etree.ElementTree',
            canonicalReceiverIdentity=id(record['canonical']),pureReceiverIdentity=id(record['pure']),
            sourcePath=str(record['path']),sourceSha256=record['digest'],sourceBytes=record['size'],
            defusedSourcePath=str(record['outer']['path']),defusedSourceSha256=record['outer']['digest'],
            originalCanonicalExecutionPreserved=True,pureFreshSourceExecuted=True,
            actualFinallyRestoredCanonicalAndAcceleratorAndPackage=True,pureParseErrorPatchEstablished=True,
            currentReceiverHistoryAdmission=False,productNativeEvidence=False)

    def source_row(self, name, module, row, kind):
        namespace = vars(module)
        assert namespace.get('__file__') is not None
        actual = self.physical(namespace['__file__'])
        assert actual == Path(row['path'])
        assert self.plan['physicalPins'][str(actual)]['sha256'] == row['sha256']
        value = dict(kind=kind, origin=str(actual), pin=self.plan['physicalPins'][str(actual)])
        execution = self.execution_row(name, module, actual)
        if execution is not None:
            value['actualExecution'] = execution
        return value

    def execution_row(self, name, module, actual):
        if self.defused_et is not None and module is self.defused_et['pure']:
            return self.defused_pure_execution_row(name, module, actual)
        execution = self.python_executions.get(name)
        if execution is not None:
            original_module, path, digest, size = execution
            assert module is original_module and actual == path
            assert digest == self.plan['physicalPins'][str(actual)]['sha256']
            return dict(kind='fresh-pinned-python-source-bytes',
                sourceSha256=digest, sourceBytes=size, cachedBytecodeConsulted=False)
        if name in self.extension_executions:
            original_module, path = self.extension_executions[name]
            assert module is original_module and actual == path
            return dict(kind='genuine-pinned-extension-loader',
                compiledThroughPythonSourceBranch=False)
        return None

    def project_loaded(self, name, module, row):
        assert self.projects.get(name) == row
        self.admissions[name] = self.source_row(name, module, row, 'project')

    def file_spec(self, name, row, kind):
        path = self.physical(row['path'])
        assert self.plan['physicalPins'][str(path)]['sha256'] == row['sha256']
        if row['loader'] == 'extension':
            original = self.extension_class(name, str(path))
        else:
            assert row['loader'] == 'source' and path.suffix == '.py'
            original = self.source_class(name, str(path))
        loader = PinnedDelegate(self, name, original, row, kind)
        locations = [str(path.parent)] if row['package'] else None
        return util.spec_from_file_location(name, str(path), loader=loader,
            submodule_search_locations=locations)

    def remaining_spec(self, name, search):
        if name in self.third:
            return self.file_spec(name, self.third[name], 'third-party')
        if name in self.third_namespaces:
            roots = self.third_namespaces[name]
            self.namespaces(name, roots, roots, 'third-party')
            spec = machinery.ModuleSpec(name, None, is_package=True)
            spec.submodule_search_locations = roots
            return spec
        spec = self.builtin.find_spec(name)
        if spec is None:
            spec = self.frozen.find_spec(name)
        if spec is not None:
            self.genuine_special(spec)
            assert self.pin(self.python) == self.plan['pythonExecutable']['pin']
            return spec
        spec = self.path_finder.find_spec(name, search)
        if spec is None:
            raise ModuleNotFoundError('No genuine declared/interpreter module named '+repr(name), name=name)
        if spec.origin is None:
            expected = self.std_namespaces.get(name)
            assert expected is not None, 'Undeclared namespace import: ' + name
            roots = tuple(spec.submodule_search_locations or ())
            self.namespaces(name, roots, expected, 'stdlib')
            return spec
        real = Path(spec.origin).resolve(strict=True)
        assert any(real.is_relative_to(root) for root in self.std) and not self.excluded(real), 'Undeclared non-stdlib import: ' + name
        self.physical(real)
        assert type(spec.loader) in (self.source_class, self.extension_class)
        row = dict(path=str(real), sha256=self.plan['physicalPins'][str(real)]['sha256'],
            package=spec.submodule_search_locations is not None,
            loader='extension' if type(spec.loader) is self.extension_class else 'source')
        return self.file_spec(name, row, 'stdlib')

    def compilation_ports_bound(self):
        assert self.compiler is _ORIGINAL_COMPILE and self.executor is _ORIGINAL_EXEC
        assert builtins.compile is self.compiler and builtins.exec is self.executor
        for function, name in ((self.compiler, 'compile'), (self.executor, 'exec')):
            assert type(function) is BuiltinFunctionType
            assert function.__self__ is builtins and function.__module__ == 'builtins'
            assert function.__name__ == function.__qualname__ == name

    @staticmethod
    def source_stat(info):
        return tuple(getattr(info, name) for name in ('st_dev', 'st_ino', 'st_mode',
            'st_uid', 'st_gid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns'))

    def execute_python_source(self, delegate, module):
        # Keep the actual SourceFileLoader as original creator/metadata owner,
        # but do not call its get_code/exec_module bytecode-cache branch.
        assert type(delegate) is PinnedDelegate and delegate.guard is self
        assert delegate.row['loader'] == 'source'
        assert type(delegate.original) is self.source_class
        assert delegate.original.name == delegate.name
        path = self.physical(delegate.row['path'])
        assert Path(delegate.original.path) == path and path.suffix == '.py'
        assert type(module) is ModuleType and sys.modules.get(delegate.name) is module
        namespace = vars(module)
        assert namespace.get('__name__') == delegate.name
        spec = namespace['__spec__']
        assert type(spec) is machinery.ModuleSpec and spec.name == delegate.name
        assert spec.origin == str(path) and Path(namespace['__file__']) == path
        # A genuine outer project-observation loader may wrap this delegate;
        # it preserves the real module spec and invokes this actual port.
        before = path.lstat()
        assert stat.S_ISREG(before.st_mode) and path.resolve(strict=True) == path
        original_open, original_read, original_fstat, original_close = self.source_read_ports
        descriptor = original_open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
        try:
            signature = self.source_stat(before)
            assert self.source_stat(original_fstat(descriptor)) == signature
            pieces = []
            while True:
                piece = original_read(descriptor, 65536)
                if not piece:
                    break
                pieces.append(piece)
            raw = b''.join(pieces)
            assert len(raw) == before.st_size
            assert self.source_stat(original_fstat(descriptor)) == signature
            assert self.source_stat(path.lstat()) == signature
        finally:
            original_close(descriptor)
        digest = hashlib.sha256(raw).hexdigest()
        assert digest == delegate.row['sha256'] == self.plan['physicalPins'][str(path)]['sha256']
        self.physical(path)
        self.compilation_ports_bound()
        code = self.compiler(raw, str(path), 'exec', dont_inherit=True, optimize=-1)
        self.compilation_ports_bound()
        # Actual interpreter compile+exec, actual normal import namespace. A
        # .pyc is neither opened, removed, rewritten nor reported missing.
        outer = self.defused_begin_outer(delegate, module, namespace, code, path, digest, len(raw))
        pure = self.defused_begin_pure(delegate, module, namespace, code, path, digest, len(raw))
        try:
            self.executor(code, namespace)
            self.compilation_ports_bound()
            self.physical(path)
            if pure is not None:
                self.defused_complete_pure(pure, module, path, digest, len(raw))
            if outer is not None:
                self.defused_complete_outer(outer)
        except BaseException as error:
            if outer is not None or pure is not None:self.defused_abort(outer, pure, error)
            raise
        if pure is None:self.python_executions[delegate.name] = (module, path, digest, len(raw))

    def hold_extension_children(self, name, module, delegate):
        # These are the two actual modules born by the real pinned Expat C
        # extension before its original import returns to project code. This
        # is not authority for arbitrary spec-less or invented modules.
        if name != 'pyexpat':
            return
        assert delegate.guard is self and delegate.name == name
        assert delegate.kind == 'stdlib' and delegate.row['loader'] == 'extension'
        assert type(delegate.original) is self.extension_class
        assert delegate.original.name == name
        path = self.physical(delegate.row['path'])
        assert Path(delegate.original.path) == path
        assert any(path.is_relative_to(root) for root in self.std) and not self.excluded(path)
        assert type(module) is ModuleType and sys.modules.get(name) is module
        assert vars(module)['__spec__'].loader is delegate
        assert Path(vars(module)['__file__']) == path
        for leaf in ('errors', 'model'):
            child_name = name + '.' + leaf
            child = vars(module).get(leaf)
            assert type(child) is ModuleType and sys.modules.get(child_name) is child
            assert vars(child).get('__name__') == child_name
            assert vars(child).get('__file__') is None and vars(child).get('__spec__') is None
            assert vars(child).get('__package__') is None and vars(child).get('__loader__') is None
            held = (module, child, leaf, delegate, path)
            if child_name in self.extension_child_receivers:
                previous = self.extension_child_receivers[child_name]
                assert all(actual is original for actual, original in zip(held[:4], previous[:4]))
                assert path == previous[4]
            else:
                self.extension_child_receivers[child_name] = held

    def extension_child_row(self, name, module):
        parent, child, leaf, delegate, path = self.extension_child_receivers[name]
        assert module is child and sys.modules.get('pyexpat') is parent
        assert vars(parent).get(leaf) is child
        assert vars(parent)['__spec__'].loader is delegate
        assert delegate.guard is self and delegate.name == 'pyexpat' and delegate.kind == 'stdlib'
        assert type(delegate.original) is self.extension_class
        assert delegate.original.name == 'pyexpat' and Path(delegate.original.path) == path
        assert vars(child).get('__name__') == name
        assert vars(child).get('__file__') is None and vars(child).get('__spec__') is None
        assert vars(child).get('__package__') is None and vars(child).get('__loader__') is None
        assert self.physical(vars(parent)['__file__']) == path
        return dict(kind='stdlib-extension-created-module', parent='pyexpat',
            originalAttribute=leaf, origin=str(path), pin=self.plan['physicalPins'][str(path)])

    def hold_extension_aliases(self, name, module, delegate):
        # The actual pinned Python wrapper reexports the two already held C
        # children. Its sys.modules aliases do not create new module origins.
        if name != 'xml.parsers.expat':
            return
        assert type(delegate) is PinnedDelegate and delegate.guard is self and delegate.name == name
        assert delegate.kind == 'stdlib' and delegate.row['loader'] == 'source'
        assert type(delegate.original) is self.source_class and delegate.original.name == name
        path = self.physical(delegate.row['path'])
        assert path == self.std[0] / 'xml' / 'parsers' / 'expat.py'
        assert Path(delegate.original.path) == path and not self.excluded(path)
        assert type(module) is ModuleType and sys.modules.get(name) is module
        assert vars(module).get('__name__') == name and vars(module).get('__loader__') is delegate
        spec = vars(module)['__spec__']
        assert type(spec) is machinery.ModuleSpec and spec.name == name and spec.loader is delegate
        assert spec.origin == str(path) and Path(vars(module)['__file__']) == path
        assert vars(module).get('__package__') == 'xml.parsers'
        for leaf in ('errors', 'model'):
            original_name = 'pyexpat.' + leaf
            original = self.extension_child_receivers.get(original_name)
            assert original is not None
            child = vars(module).get(leaf)
            alias_name = name + '.' + leaf
            assert child is original[1] and sys.modules.get(alias_name) is child
            self.extension_child_row(original_name, child)
            held = (module, child, leaf, delegate, path, original)
            if alias_name in self.extension_alias_receivers:
                previous = self.extension_alias_receivers[alias_name]
                assert all(actual is expected for actual, expected in zip(held[:4], previous[:4]))
                assert path == previous[4] and original is previous[5]
            else:
                self.extension_alias_receivers[alias_name] = held

    def extension_alias_row(self, name, module):
        wrapper, child, leaf, delegate, path, original = self.extension_alias_receivers[name]
        assert leaf in ('errors', 'model') and name == 'xml.parsers.expat.' + leaf
        assert module is child and sys.modules.get(name) is child and sys.modules.get('xml.parsers.expat') is wrapper
        assert type(wrapper) is ModuleType and vars(wrapper).get(leaf) is child
        assert vars(wrapper).get('__name__') == 'xml.parsers.expat' and vars(wrapper).get('__loader__') is delegate
        assert type(delegate) is PinnedDelegate and delegate.guard is self and delegate.name == 'xml.parsers.expat'
        assert delegate.kind == 'stdlib' and delegate.row['loader'] == 'source'
        assert type(delegate.original) is self.source_class and delegate.original.name == 'xml.parsers.expat'
        assert path == self.std[0] / 'xml' / 'parsers' / 'expat.py'
        assert Path(delegate.original.path) == path and Path(delegate.row['path']) == path
        spec = vars(wrapper)['__spec__']
        assert type(spec) is machinery.ModuleSpec and spec.name == 'xml.parsers.expat' and spec.loader is delegate
        assert spec.origin == str(path) and vars(wrapper).get('__package__') == 'xml.parsers'
        assert self.physical(vars(wrapper)['__file__']) == self.physical(delegate.row['path']) == path
        original_name = 'pyexpat.' + leaf
        assert self.extension_child_receivers.get(original_name) is original and original[1] is child
        actual = self.extension_child_row(original_name, child)
        return dict(kind='stdlib-source-reexported-extension-module', parent='pyexpat',
            wrapper='xml.parsers.expat', originalAttribute=leaf, origin=actual['origin'], pin=actual['pin'],
            wrapperOrigin=str(path), wrapperPin=self.plan['physicalPins'][str(path)])

    def cffi_create_profile(self, delegate, spec):
        if delegate.name != _CFFI_RUST_NAME:
            return False
        self.defused_controls_bound()
        assert self.cffi_export is None and not self.cffi_export_failed
        assert _CFFI_CARRIER_NAME not in sys.modules
        assert delegate.guard is self and delegate.kind == 'third-party'
        assert delegate.row == self.third[_CFFI_RUST_NAME] and delegate.row['loader'] == 'extension'
        assert type(delegate.original) is self.extension_class and delegate.original.name == _CFFI_RUST_NAME
        assert type(spec) is machinery.ModuleSpec and spec.name == _CFFI_RUST_NAME and spec.loader is delegate and spec.origin == delegate.row['path']
        for name, digest in _CFFI_BINARY_SHA256:
            row = self.third[name]
            assert row['loader'] == 'extension' and row['sha256'] == digest
            path = self.physical(row['path'])
            assert self.plan['physicalPins'][str(path)]['sha256'] == digest
        return True

    def hold_cffi_created_export(self, delegate, spec, parent):
        # Only a real create return may establish the pending parent duty.
        try:
            self.defused_controls_bound()
            caller = _ORIGINAL_GETFRAME(1)
            assert caller.f_code is PinnedDelegate.create_module.__code__ and caller.f_globals is PinnedDelegate.create_module.__globals__
            assert caller.f_locals.get('self') is delegate and caller.f_locals.get('spec') is spec and caller.f_locals.get('module') is parent
            assert caller.f_locals.get('cffi') is True and delegate.guard is self and delegate.name == _CFFI_RUST_NAME
            assert type(parent) is ModuleType and self.cffi_export is None and not self.cffi_export_failed
            self.cffi_export = dict(state='pending-exec',parent=parent,delegate=delegate,spec=spec,path=Path(delegate.row['path']))
            if _CFFI_CARRIER_NAME not in sys.modules and '_openssl' not in vars(parent):
                # Genuine multi-phase extension: no export is invented here.
                # The SAME created parent/spec/loader remains mandatory.
                return
            self.capture_cffi_export(delegate, spec, parent, 'create-return')
        except BaseException:
            self.cffi_export_failed = True
            raise

    def capture_cffi_export(self, delegate, spec, parent, phase):
        try:
            self.defused_controls_bound()
            caller = _ORIGINAL_GETFRAME(1);original = caller.f_back
            if phase == 'create-return':
                assert caller.f_code is type(self).hold_cffi_created_export.__code__ and caller.f_globals is type(self).hold_cffi_created_export.__globals__
                assert original.f_code is PinnedDelegate.create_module.__code__ and original.f_globals is PinnedDelegate.create_module.__globals__
                assert original.f_locals.get('cffi') is True and original.f_locals.get('spec') is spec
            else:
                assert phase == 'exec-return'
                assert caller.f_code is type(self).complete_cffi_export.__code__ and caller.f_globals is type(self).complete_cffi_export.__globals__
                assert original.f_code is PinnedDelegate.exec_module.__code__ and original.f_globals is PinnedDelegate.exec_module.__globals__
                assert self.extension_executions[_CFFI_RUST_NAME][0] is parent
            assert caller.f_locals.get('self') is self and caller.f_locals.get('delegate') is delegate and caller.f_locals.get('parent') is parent
            assert original.f_locals.get('self') is delegate and original.f_locals.get('module') is parent
            entry = self.cffi_export
            assert entry is not None and entry['state'] == 'pending-exec' and not self.cffi_export_failed
            assert entry['parent'] is parent and entry['delegate'] is delegate and entry['spec'] is spec
            assert entry['path'] == Path(delegate.row['path']) and delegate.guard is self and delegate.name == _CFFI_RUST_NAME
            shim = vars(parent)['_openssl'];assert type(shim) is ModuleType
            library, ffi = vars(shim)['lib'], vars(shim)['ffi']
            assert sys.modules.get(_CFFI_CARRIER_NAME) is library and type(library) is not ModuleType and library is not ffi
            backend = sys.modules['_cffi_backend'];assert type(backend) is ModuleType
            execution = self.extension_executions['_cffi_backend']
            assert execution[0] is backend and execution[1] == Path(self.third['_cffi_backend']['path'])
            backend_spec = vars(backend)['__spec__'];backend_delegate = backend_spec.loader
            assert type(backend_delegate) is PinnedDelegate and backend_delegate.guard is self
            assert backend_delegate.name == '_cffi_backend' and type(backend_delegate.original) is self.extension_class
            assert backend_spec.origin == self.third['_cffi_backend']['path'] and vars(backend)['__file__'] == backend_spec.origin
            assert type(ffi) is vars(backend)['FFI']
            # Types/objects are retained from the actual native initializer,
            # never guessed from a label or supplied successful record.
            entry.update(state='created',shim=shim,library=library,libraryType=type(library),ffi=ffi,ffiType=type(ffi),
                backend=backend,backendSpec=backend_spec,backendDelegate=backend_delegate,backendExecution=execution,
                actualInitializationPhase=phase)
        except BaseException:
            self.cffi_export_failed = True
            raise

    def complete_cffi_export(self, delegate, parent):
        if delegate.name != _CFFI_RUST_NAME:
            return
        try:
            self.defused_controls_bound()
            entry = self.cffi_export
            assert entry is not None and entry['state'] in ('pending-exec','created') and not self.cffi_export_failed
            assert entry['parent'] is parent and entry['delegate'] is delegate
            assert vars(parent)['__spec__'] is entry['spec'] and entry['spec'].loader is delegate
            assert sys.modules.get(_CFFI_RUST_NAME) is parent
            assert self.extension_executions[_CFFI_RUST_NAME] == (parent,entry['path'])
            if entry['state'] == 'pending-exec':
                self.capture_cffi_export(delegate, entry['spec'], parent, 'exec-return')
            # A create-time capture is NEVER replaced by whatever exec produced.
            # The complete row below compares the actual same retained exports.
            assert entry['state'] == 'created'
            entry['rustExecution'] = self.extension_executions[_CFFI_RUST_NAME]
            entry['state'] = 'complete'
            self.cffi_carrier_row(_CFFI_CARRIER_NAME, sys.modules.get(_CFFI_CARRIER_NAME))
        except BaseException:
            self.cffi_export_failed = True
            raise

    def cffi_carrier_row(self, name, library):
        try:
            self.defused_controls_bound()
            entry = self.cffi_export
            assert name == _CFFI_CARRIER_NAME and entry is not None and entry['state'] == 'complete' and not self.cffi_export_failed
            parent,shim,backend = entry['parent'],entry['shim'],entry['backend']
            assert sys.modules.get(_CFFI_RUST_NAME) is parent and type(parent) is ModuleType
            assert vars(parent)['_openssl'] is shim and type(shim) is ModuleType
            assert vars(shim)['lib'] is library is entry['library'] and type(library) is entry['libraryType']
            assert vars(shim)['ffi'] is entry['ffi'] and type(entry['ffi']) is entry['ffiType']
            assert sys.modules.get(_CFFI_CARRIER_NAME) is library and sys.modules.get('_cffi_backend') is backend
            assert vars(backend)['FFI'] is entry['ffiType'] and vars(backend)['__spec__'] is entry['backendSpec']
            assert entry['backendSpec'].loader is entry['backendDelegate'] and entry['backendDelegate'].guard is self
            assert vars(backend)['__file__'] == entry['backendSpec'].origin == self.third['_cffi_backend']['path']
            assert entry['backendDelegate'].name == '_cffi_backend' and entry['backendDelegate'].row == self.third['_cffi_backend']
            assert type(entry['backendDelegate'].original) is self.extension_class
            assert entry['backendDelegate'].original.name == '_cffi_backend' and entry['backendDelegate'].original.path == vars(backend)['__file__']
            assert self.extension_executions['_cffi_backend'] is entry['backendExecution']
            delegate,spec = entry['delegate'],entry['spec']
            assert delegate.guard is self and delegate.name == _CFFI_RUST_NAME and type(delegate.original) is self.extension_class
            assert delegate.row == self.third[_CFFI_RUST_NAME] and delegate.original.name == _CFFI_RUST_NAME and delegate.original.path == str(entry['path'])
            assert vars(parent)['__spec__'] is spec and spec.loader is delegate and spec.name == _CFFI_RUST_NAME
            assert spec.origin == vars(parent)['__file__'] == str(entry['path']) == delegate.row['path']
            assert self.extension_executions[_CFFI_RUST_NAME] is entry['rustExecution']
            assert entry['rustExecution'] == (parent,entry['path'])
            for binary,digest in _CFFI_BINARY_SHA256:
                path = self.physical(self.third[binary]['path'])
                assert self.third[binary]['sha256'] == self.plan['physicalPins'][str(path)]['sha256'] == digest
            return dict(kind='genuine-pinned-rust-cffi-export-carrier',parent=_CFFI_RUST_NAME,
                origin=str(entry['path']),pin=self.plan['physicalPins'][str(entry['path'])],backend='_cffi_backend',
                backendOrigin=str(entry['backendExecution'][1]),backendPin=self.plan['physicalPins'][str(entry['backendExecution'][1])],
                actualCarrierIdentity=id(library),actualParentIdentity=id(parent),actualShimIdentity=id(shim),
                actualFFIIdentity=id(entry['ffi']),opaqueTypeHeldFromActualCInitializer=True,actualInitializationPhase=entry['actualInitializationPhase'],
                fabricatedModuleOrSpec=False,deviceOrProviderAuthority=False)
        except BaseException:
            self.cffi_export_failed = True
            raise

    def snapshot(self, phase):
        assert self.defused_outer is None and not self.defused_failed, 'Unfinished or failed original defused ET transaction'
        # The genuinely bootstrapped module receivers are independently held.
        # An authentic importer spec does not authorize a replacement module.
        for name, original in self.initial_modules.items():
            if original is not None:
                assert sys.modules.get(name) is original, 'Initial module receiver changed: ' + name
        assert not self.cffi_export_failed, 'Failed CFFI original export custody'
        if self.cffi_export is not None:
            self.cffi_carrier_row(_CFFI_CARRIER_NAME, sys.modules.get(_CFFI_CARRIER_NAME))
        rows = {}
        for name, module in tuple(sys.modules.items()):
            if module is None:
                continue
            if type(module) is not ModuleType:
                rows[name] = self.cffi_carrier_row(name, module)
                continue
            namespace = vars(module)
            file = namespace.get('__file__')
            spec = namespace.get('__spec__')
            if name in self.projects:
                row = self.source_row(name, module, self.projects[name], 'project')
            elif name in self.third:
                row = self.source_row(name, module, self.third[name], 'third-party')
            elif name in self.extension_child_receivers:
                row = self.extension_child_row(name, module)
            elif name in self.extension_alias_receivers:
                row = self.extension_alias_row(name, module)
            elif spec is not None and spec.origin in ('built-in', 'frozen'):
                kind = self.genuine_special(spec)
                assert sys.modules.get(spec.name) is module
                row = dict(kind=kind, interpreter=str(self.python))
                if file is not None:
                    row['sourceRepresentation'] = str(self.physical(file))
            elif file is not None:
                actual = self.physical(file)
                if actual.parent == self.source:
                    # Only the exact already independently pinned controller
                    # modules may predate target admission.
                    assert name in self.initial_modules and self.initial_modules[name] is module
                    kind = 'controller'
                else:
                    assert any(actual.is_relative_to(root) for root in self.std) and not self.excluded(actual), 'Unaccounted loaded external origin: ' + name
                    kind = 'stdlib'
                row = dict(kind=kind, origin=str(actual), pin=self.plan['physicalPins'][str(actual)])
            else:
                assert spec is not None and spec.origin is None, 'Unaccounted fileless module: ' + name
                roots = tuple(spec.submodule_search_locations or ())
                if name in self.project_namespaces:
                    row = self.namespaces(name, roots, self.project_namespaces[name], 'project')
                elif name in self.third_namespaces:
                    row = self.namespaces(name, roots, self.third_namespaces[name], 'third-party')
                else:
                    assert name in self.std_namespaces, 'Unaccounted loaded namespace: ' + name
                    row = self.namespaces(name, roots, self.std_namespaces[name], 'stdlib')
            if name in self.python_executions or name in self.extension_executions:
                assert file is not None
                # The same actual receipt grammar is used for project,
                # external and generic stdlib rows. Never drop a real fresh
                # execution record before the admission equality check.
                row['actualExecution'] = self.execution_row(name, module, self.physical(file))
            if name in self.admissions:
                assert self.admissions[name] == row
            if name in self.initial_modules:
                row = dict(row)
                row['hostBootstrap'] = dict(kind='held-original-host-bootstrap',
                    compiledThroughC10=False)
            rows[name] = row
        assert self.pin(self.python) == self.plan['pythonExecutable']['pin']
        self.snapshot_count += 1
        transaction = None if self.defused_et is None else self.defused_transaction_original()
        return dict(phase=phase, modules=rows, observedFiles=dict(self.observed_files),
            namespaces=dict(self.observed_namespaces), snapshots=self.snapshot_count,
            executionScope=dict(pythonDelegates='fresh-pinned-python-source-bytes',
                preloaded='held-host-bootstrap-only', extensions='genuine-pinned-extension-loader',
                entryScriptAndPrivateBootstrap='outside-this-loader-scope',
                cacheFilesReadByThisSourceBranch=False, cacheFilesChanged=False),
            **({} if transaction is None else {'originalDefusedETTransaction': transaction}))


class PinnedDelegate:
    """Delegate actual source/extension creation+execution, pinning both sides."""
    def __init__(self, guard, name, original, row, kind):
        self.guard, self.name, self.original, self.row, self.kind = guard, name, original, row, kind
        assert type(original) in (guard.source_class, guard.extension_class)
    def create_module(self, spec):
        self.guard.physical(self.row['path'])
        cffi = self.guard.cffi_create_profile(self, spec)
        module = self.original.create_module(spec)
        self.guard.physical(self.row['path'])
        if cffi:
            self.guard.hold_cffi_created_export(self, spec, module)
        return module
    def exec_module(self, module):
        self.guard.physical(self.row['path'])
        # Genuine ExtensionFileLoader is used even for its create_module
        # phase above; no custom binary decoder or substitute module exists.
        if self.row['loader'] == 'source':
            self.guard.execute_python_source(self, module)
        else:
            assert self.row['loader'] == 'extension'
            assert type(self.original) is self.guard.extension_class
            self.original.exec_module(module)
            self.guard.extension_executions[self.name] = (module, Path(self.row['path']))
            self.guard.complete_cffi_export(self, module)
        value = self.guard.source_row(self.name, module, self.row, self.kind)
        self.guard.defused_admission(self, module, value)
        self.guard.hold_extension_children(self.name, module, self)
        self.guard.hold_extension_aliases(self.name, module, self)
