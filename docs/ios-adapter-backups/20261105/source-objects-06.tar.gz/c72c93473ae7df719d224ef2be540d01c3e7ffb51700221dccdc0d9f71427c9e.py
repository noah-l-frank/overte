"""Correct the expected foreign codec refusal, private metadata/AST only."""
import ast,difflib,hashlib,json
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/emote-callback-live-prefix-foreign-role-counter-overlay-20261102';OLD=REPO/'.ios-host-tmp/emote-callback-live-prefix-codec-binding-copyright-overlay-20261102'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(v)
rows=[];diff=[];cumulative=[]
for path in (OLD/'candidate').rglob('*.py'):
 relative=str(path.relative_to(OLD/'candidate'));before=path.read_text();after=before
 if relative.endswith('test_ios_emote_callback_live_history_cache.py'):
  needle="        self.read(other);self.assertEqual(4,self.calls);self.assertEqual(2,len(self.history.cache.rows))\n";assert after.count(needle)==1
  after=after.replace(needle,"        with self.assertRaises(NativeUIError):self.read(other)\n        self.assertEqual(2,self.calls);self.assertEqual(1,len(self.history.cache.rows))\n")
 write(HERE/'base'/relative,before);write(HERE/'candidate'/relative,after);ast.parse(after,filename=relative)
 diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='codec-08fb/'+relative,tofile='corrected-foreign-role/'+relative))
 old=REPO/relative;cumulative.extend(difflib.unified_diff((old.read_text() if old.exists() else '').splitlines(True),after.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
 rows.append(dict(path=relative,baseSHA256=sha(old) if old.exists() else None,candidateSHA256=hashlib.sha256(after.encode()).hexdigest()))
write(HERE/'foreign-role-counter-only.diff',''.join(diff));write(HERE/'source3.diff',''.join(cumulative))
plan=json.loads((OLD/'plan.json').read_text());plan.update(status='PRIVATE_UNRUN_ROOT_COUNTER_CORRECTION',sourcePaths=rows,predecessorFreeze=sha(OLD/'freeze.json'))
write(HERE/'plan.json',json.dumps(plan,indent=2)+'\n')
write(HERE/'freeze.json',json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(packet=str(HERE),freeze=sha(HERE/'freeze.json'),source=rows)))
