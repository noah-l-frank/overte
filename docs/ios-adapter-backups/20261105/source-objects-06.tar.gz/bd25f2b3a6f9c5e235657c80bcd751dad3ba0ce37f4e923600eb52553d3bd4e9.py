"""Real-frame observer utility counters; no Assets owner/verdict qualification."""
import threading,unittest,weakref
from intent_graph_diagnostic import IntentGraphDiagnostic

ERROR=object()
def probe_fingerprint(value):
    if value is ERROR:raise ValueError('Actual probe unwind')
    if type(value)is list:return tuple(probe_fingerprint(item)for item in value)
    return None
class ProbePolicy:
    def add(self,namespace,names):
        for name in names:self.value(namespace,name)
    def value(self,namespace,name):return probe_fingerprint(namespace[name])

class GraphDiagnosticUtilityTests(unittest.TestCase):
    def observer(self,namespace):
        return IntentGraphDiagnostic((('fingerprint',probe_fingerprint),('add',vars(ProbePolicy)['add']),('value',vars(ProbePolicy)['value'])),[(namespace,'counter-namespace')],member_bindings=((ProbePolicy,'add',vars(ProbePolicy)['add']),(ProbePolicy,'value',vars(ProbePolicy)['value'])))
    def test_real_namespace_name_and_recursive_depth_are_observed_without_retaining_values(self):
        namespace={'tree':[[[1]],2]};observer=self.observer(namespace).start()
        try:ProbePolicy().add(namespace,('tree',));result=observer.snapshot()
        finally:observer.stop()
        rows=[row for row in result['rows']if row['category']=='list']
        self.assertTrue(rows);self.assertTrue(all(row['namespace']=='counter-namespace'and row['name']=='tree'for row in rows))
        self.assertTrue(any(row['maxFingerprintDepth']>=4 for row in result['threads']))
        self.assertTrue(all(not row['pending']and row['depth']==0 for row in result['threads']))
        self.assertFalse(result['originalVerdictProvided']);self.assertIsNone(observer.tool)
    def test_category_does_not_call_opaque_dict_getter_or_metaclass_equality(self):
        calls=[]
        class Meta(type):
            def __eq__(self,other):calls.append('metaclass-equality');return False
        class Opaque(metaclass=Meta):
            def __getattribute__(self,name):
                if name=='__dict__':calls.append('dict-getter')
                return object.__getattribute__(self,name)
        namespace={'item':Opaque()};observer=self.observer(namespace).start()
        try:ProbePolicy().add(namespace,('item',));result=observer.snapshot()
        finally:observer.stop()
        self.assertEqual([],calls);self.assertTrue(any(row['category']=='opaque'for row in result['rows']))
        reference=weakref.ref(namespace['item']);del namespace['item']
        self.assertIsNone(reference()) # Counter observed value was not retained.
    def test_real_unwind_balances_depth_and_releases_only_the_owned_tool(self):
        namespace={'item':ERROR};observer=self.observer(namespace).start()
        try:
            with self.assertRaises(ValueError):ProbePolicy().add(namespace,('item',))
            result=observer.snapshot()
        finally:observer.stop()
        self.assertTrue(any(row['unwinds']for row in result['threads']))
        self.assertTrue(all(row['depth']==row['fingerprintDepth']==0 and not row['pending']for row in result['threads']))
        self.assertIsNone(observer.tool)
    def test_one_actual_joined_foreign_thread_is_explicitly_separate(self):
        namespace={'tree':[1]};observer=self.observer(namespace).start();errors=[]
        def run():
            try:ProbePolicy().add(namespace,('tree',))
            except BaseException:errors.append(True)
        thread=threading.Thread(target=run)
        try:
            ProbePolicy().add(namespace,('tree',));thread.start();thread.join(2)
            self.assertFalse(thread.is_alive());result=observer.snapshot()
        finally:
            if thread.is_alive():thread.join(2)
            observer.stop()
        self.assertEqual([],errors);self.assertEqual({True,False},{row['main']for row in result['threads']})
        self.assertTrue(any(row['thread']=='foreign'for row in result['rows']))
    def test_label_and_event_storage_are_explicitly_bounded_and_never_an_authority(self):
        namespace={('n'+str(index)):index for index in range(200)};observer=self.observer(namespace).start()
        try:ProbePolicy().add(namespace,tuple(namespace));result=observer.snapshot()
        finally:observer.stop()
        self.assertLessEqual(len(result['rows']),observer.MAX_ROWS);self.assertTrue(result['saturated'])
        self.assertFalse(result['wholeAssetsQualified']);self.assertFalse(result['originalVerdictProvided'])
        observer=self.observer(namespace);observer.MAX_EVENTS=4;observer.start()
        try:ProbePolicy().add(namespace,tuple(namespace));limited=observer.snapshot()
        finally:observer.stop()
        self.assertEqual(4,limited['events']);self.assertTrue(limited['saturated'])
        self.assertFalse(limited['originalVerdictProvided'])
    def test_binding_change_is_reported_instead_of_attesting_replacement_execution(self):
        namespace={'item':1};observer=self.observer(namespace).start();original=probe_fingerprint.__code__
        try:
            probe_fingerprint.__code__=original.replace()
            result=observer.snapshot();self.assertFalse(result['installationUnchanged'])
        finally:probe_fingerprint.__code__=original;observer.stop()
        self.assertIsNone(observer.tool)

# Real original-module/class aliases for the factory's parent-installation
# contract. No synthetic ModuleType/spec/frame or Assets/runtime owner exists.
class ProbeParentPolicy:
    def module(self):return None
    def function(self):return None
    def follow(self):return None
IntentCodePolicy=ProbePolicy
ClosedParserPolicy=ProbeParentPolicy
_intent_value=probe_fingerprint

def foreign_callback(*_arguments):return None

def alternate_parent(self):return None

class GraphDiagnosticRestorationTests(unittest.TestCase):
    def observer(self,namespace):return GraphDiagnosticUtilityTests.observer(self,namespace)
    # Baseline six bodies remain at their actual original class; these six
    # restoration cases require a separate explicit future closed selection.
    def test_failed_genuine_tool_acquisition_preserves_other_actual_owner(self):
        import sys
        observer=self.observer({'item':1});api=sys.monitoring;original_profile=sys.getprofile();occupied=[];prior=[]
        start_code=type(observer).start.__code__;start_globals=type(observer).start.__globals__;use=api.use_tool_id
        other='actual-counter-other-tool-owner-'+str(id(observer))
        def profile(frame,event,port):
            if event=='c_call'and port is use and frame.f_code is start_code and frame.f_globals is start_globals and frame.f_locals.get('self')is observer and not occupied:
                tool=frame.f_locals['tool'];use(tool,other);occupied.append(tool)
                prior.append(api.register_callback(tool,api.events.PY_UNWIND,foreign_callback));api.set_events(tool,api.events.PY_UNWIND)
        try:
            sys.setprofile(profile)
            with self.assertRaises(ValueError):observer.start()
            sys.setprofile(original_profile);tool=occupied[0]
            self.assertIs(api.get_tool(tool),other);self.assertIsNone(observer.tool);self.assertFalse(observer.acquired_ever or observer.released)
            observer.stop();self.assertEqual(api.events.PY_UNWIND,api.get_events(tool))
            self.assertIs(api.register_callback(tool,api.events.PY_UNWIND,foreign_callback),foreign_callback)
        finally:
            sys.setprofile(original_profile)
            if occupied:
                tool=occupied[0];self.assertIs(api.get_tool(tool),other)
                api.set_events(tool,0);api.register_callback(tool,api.events.PY_UNWIND,prior[0]);api.free_tool_id(tool)

    def test_real_partial_registration_error_survives_a_secondary_stop_error(self):
        import sys
        observer=self.observer({'item':1});api=sys.monitoring;profile_before=sys.getprofile();actual=[]
        initial=RuntimeError('Original actual registration failure');secondary=LookupError('Secondary retirement failure')
        start_code=type(observer).start.__code__;start_globals=type(observer).start.__globals__;register=api.register_callback
        original_stop=observer.stop
        def stop_then_error():
            original_stop();raise secondary
        def profile(frame,event,port):
            if event=='c_call'and port is register and frame.f_code is start_code and frame.f_globals is start_globals and frame.f_locals.get('self')is observer and frame.f_locals.get('event')==api.events.PY_RETURN:
                actual.append(True);raise initial
        try:
            observer.stop=stop_then_error;sys.setprofile(profile)
            with self.assertRaises(RuntimeError)as caught:observer.start()
            self.assertIs(caught.exception,initial);self.assertEqual([True],actual)
        finally:
            sys.setprofile(profile_before);observer.stop=original_stop;observer.stop()
        self.assertTrue(observer.acquired_ever and observer.released);self.assertIsNone(observer.tool)
        self.assertTrue(observer.disabled);self.assertGreaterEqual(observer.fault_count,2)

    def test_actual_callback_depth_fault_is_secondary_to_original_parser_unwind(self):
        namespace={'item':ERROR};observer=self.observer(namespace).start();depth=observer.MAX_DEPTH
        try:
            # Fault only private diagnostic accounting, not the original parser,
            # any clock port, frame or API return. Real callback raises TypeError.
            observer.MAX_DEPTH=None
            with self.assertRaises(ValueError)as actual:ProbePolicy().add(namespace,('item',))
            self.assertEqual(('Actual probe unwind',),actual.exception.args)
            row=observer.snapshot();self.assertTrue(row['diagnosticDisabled']);self.assertEqual(1,row['diagnosticFaultCount'])
            self.assertFalse(row['diagnosticComplete']);self.assertTrue(row['installationUnchanged'])
        finally:observer.MAX_DEPTH=depth;restored=observer.stop()
        self.assertTrue(restored['actualToolFreed']and restored['actualOriginalStateRestored'])

    def test_real_prior_free_slot_masks_and_callbacks_are_restored_exactly(self):
        import sys
        api=sys.monitoring;observer=self.observer({'item':1});preference=(2,5,4,3,1,0)
        tool=next(n for n in preference if api.get_tool(n)is None and api.get_events(n)==0)
        seed='actual-prior-registration-'+str(id(observer));original_callbacks={};original_local={};events=(api.events.PY_START,api.events.PY_RETURN,api.events.PY_UNWIND)
        api.use_tool_id(tool,seed)
        try:
            for event in events:original_callbacks[event]=api.register_callback(tool,event,foreign_callback)
            for code,_namespace,_kind in observer.bindings.values():
                original_local[code]=api.get_local_events(tool,code);api.set_local_events(tool,code,api.events.PY_START)
        finally:api.free_tool_id(tool)
        try:
            observer.start();self.assertEqual(tool,observer.tool)
            ProbePolicy().add({'item':1},('item',));retired=observer.stop()
            self.assertTrue(retired['actualOriginalStateRestored']);self.assertIsNone(api.get_tool(tool))
            for code in original_local:self.assertEqual(api.events.PY_START,api.get_local_events(tool,code))
            api.use_tool_id(tool,seed)
            for event in events:self.assertIs(api.register_callback(tool,event,foreign_callback),foreign_callback)
        finally:
            if observer.tool is not None:observer.stop()
            if api.get_tool(tool)is None:api.use_tool_id(tool,seed)
            self.assertIs(api.get_tool(tool),seed);api.set_events(tool,0)
            for code,mask in original_local.items():api.set_local_events(tool,code,mask)
            for event,callback in original_callbacks.items():api.register_callback(tool,event,callback)
            api.free_tool_id(tool)

    def test_actual_parent_class_alias_replacement_invalidates_factory_installation(self):
        import sys
        from intent_graph_diagnostic import picker_diagnostic
        module=sys.modules[__name__];observer=picker_diagnostic(module,module,()).start()
        original=ProbeParentPolicy.module
        try:
            self.assertTrue(observer.snapshot()['installationUnchanged'])
            ProbeParentPolicy.module=alternate_parent
            self.assertFalse(observer.snapshot()['installationUnchanged'])
        finally:ProbeParentPolicy.module=original;observer.stop()

    def test_real_replacement_slot_owner_is_refused_without_mutation_or_free(self):
        import sys
        api=sys.monitoring;observer=self.observer({'item':1}).start();tool=observer.tool
        other='actual-replaced-slot-owner-'+str(id(observer));foreign_callbacks={}
        api.free_tool_id(tool);api.use_tool_id(tool,other)
        try:
            for event in observer.events_masks.values():foreign_callbacks[event]=api.register_callback(tool,event,foreign_callback)
            mask=api.events.PY_UNWIND;api.set_events(tool,mask)
            state={code:api.get_local_events(tool,code)for code in observer.local_before}
            receipt=observer.stop()
            self.assertFalse(receipt['actualOriginalStateRestored']or receipt['actualToolFreed']or receipt['currentOwnershipReleased'])
            self.assertIs(api.get_tool(tool),other);self.assertEqual(mask,api.get_events(tool))
            self.assertEqual(state,{code:api.get_local_events(tool,code)for code in state})
            for event in observer.events_masks.values():self.assertIs(api.register_callback(tool,event,foreign_callback),foreign_callback)
        finally:
            # This counter created the foreign replacement. Its genuine owner
            # restores the saved PRE-diagnostic registrations, not observer.stop.
            self.assertIs(api.get_tool(tool),other)
            api.set_events(tool,observer.global_before)
            for code,previous in observer.local_before.items():api.set_local_events(tool,code,previous)
            for event,previous in observer.old_callbacks.items():api.register_callback(tool,event,previous)
            api.free_tool_id(tool)
        self.assertIsNone(api.get_tool(tool));self.assertFalse(observer.released)

class GraphDiagnosticUnknownReturnTests(unittest.TestCase):
    def observer(self,namespace):return GraphDiagnosticUtilityTests.observer(self,namespace)

    def test_genuine_acquisition_c_return_failure_stays_unknown_without_false_release(self):
        import sys
        api=sys.monitoring;observer=self.observer({'item':1});profile_before=sys.getprofile()
        use=api.use_tool_id;start_code=type(observer).start.__code__;start_globals=type(observer).start.__globals__
        original_error=RuntimeError('Original genuine use_tool_id C-return lost');actual=[]
        def profile(frame,event,port):
            if event=='c_return'and port is use and frame.f_code is start_code and frame.f_globals is start_globals and frame.f_locals.get('self')is observer and not actual:
                actual.append(frame.f_locals['tool']);raise original_error
        try:
            sys.setprofile(profile)
            with self.assertRaises(RuntimeError)as caught:observer.start()
            sys.setprofile(profile_before)
            self.assertIs(caught.exception,original_error);self.assertEqual(1,len(actual));tool=actual[0]
            # Genuine C-return witness is counter custody, not observer authority.
            self.assertIs(api.get_tool(tool),observer.name);self.assertIsNone(observer.tool)
            self.assertFalse(observer.acquired_ever or observer.released)
            receipt=observer.stop();snapshot=observer.snapshot()
            self.assertTrue(receipt['acquisitionOutcomeUnknown']);self.assertEqual(tool,receipt['mutationCandidateToolId'])
            self.assertIsNone(receipt['actualToolAcquired']);self.assertIsNone(snapshot['active'])
            self.assertFalse(receipt['actualOriginalStateRestored']or receipt['currentOwnershipReleased']or receipt['actualToolFreed'])
            self.assertFalse(snapshot['diagnosticComplete']or snapshot['originalVerdictProvided'])
        finally:
            sys.setprofile(profile_before)
            if observer.tool is not None:observer.stop()
            if actual:
                # The actual counter observed THIS original port returning with
                # THIS candidate/self/name. No guessed observer acquisition.
                tool=actual[0];self.assertIs(api.get_tool(tool),observer.name);api.free_tool_id(tool)
        self.assertIsNone(api.get_tool(actual[0]))
        self.assertFalse(observer.stop()['actualOriginalStateRestored'])
        with self.assertRaises(AssertionError):observer.start() # Unknown stays closed.

    def test_genuine_callback_c_return_failure_does_not_invent_lost_previous_callback(self):
        import sys
        api=sys.monitoring;observer=self.observer({'item':1});profile_before=sys.getprofile();actual=[]
        tool=next(n for n in(2,5,4,3,1,0)if api.get_tool(n)is None and api.get_events(n)==0)
        seed='actual-counter-prior-c-return-'+str(id(observer));events=(api.events.PY_START,api.events.PY_RETURN,api.events.PY_UNWIND)
        original_callbacks={};original_local={code:api.get_local_events(tool,code)for code,_namespace,_kind in observer.bindings.values()}
        original_global=api.get_events(tool);api.use_tool_id(tool,seed)
        try:
            for event in events:original_callbacks[event]=api.register_callback(tool,event,foreign_callback)
        finally:api.free_tool_id(tool)
        register=api.register_callback;start_code=type(observer).start.__code__;start_globals=type(observer).start.__globals__
        original_error=RuntimeError('Original genuine register_callback C-return lost')
        def profile(frame,event,port):
            if event=='c_return'and port is register and frame.f_code is start_code and frame.f_globals is start_globals and frame.f_locals.get('self')is observer and frame.f_locals.get('event')==api.events.PY_RETURN and not actual:
                actual.append(frame.f_locals['tool']);raise original_error
        try:
            sys.setprofile(profile)
            with self.assertRaises(RuntimeError)as caught:observer.start()
            sys.setprofile(profile_before)
            self.assertIs(caught.exception,original_error);self.assertEqual([tool],actual)
            self.assertTrue(observer.acquired_ever and observer.released);self.assertIsNone(api.get_tool(tool))
            receipt=observer.stop();snapshot=observer.snapshot()
            self.assertTrue(receipt['callbackMutationOutcomeUnknown']);self.assertEqual([api.events.PY_RETURN],receipt['unknownCallbackEvents'])
            self.assertFalse(receipt['actualOriginalStateRestored']);self.assertTrue(receipt['currentOwnershipReleased'])
            self.assertFalse(snapshot['diagnosticComplete']or snapshot['originalVerdictProvided'])
            # Reacquire the actual free slot as THIS counter's original owner.
            # The returned real callback establishes that replacement happened;
            # it does not manufacture the unavailable old callback in observer.
            api.use_tool_id(tool,seed)
            changed=api.register_callback(tool,api.events.PY_RETURN,foreign_callback)
            self.assertIs(changed,observer.callback_objects[api.events.PY_RETURN]);self.assertIsNot(changed,foreign_callback)
        finally:
            sys.setprofile(profile_before)
            if observer.tool is not None:observer.stop()
            if api.get_tool(tool)is None:api.use_tool_id(tool,seed)
            self.assertIs(api.get_tool(tool),seed)
            api.set_events(tool,original_global)
            for code,previous in original_local.items():api.set_local_events(tool,code,previous)
            for event,previous in original_callbacks.items():api.register_callback(tool,event,previous)
            api.free_tool_id(tool)
        self.assertIsNone(api.get_tool(tool));self.assertFalse(observer.stop()['actualOriginalStateRestored'])

if __name__=='__main__':unittest.main()
