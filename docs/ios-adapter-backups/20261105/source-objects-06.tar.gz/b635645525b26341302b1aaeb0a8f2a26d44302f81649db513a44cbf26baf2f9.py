"""Real original-command proof, independent of the variant's len64 marker.

An actual child is a genuine interpreter -c receiver. No __main__ file/spec
or module receiver is installed or fabricated by this bridge.
"""
from pathlib import Path
import ast,hashlib,os,sys,types
from tablet_guarded_spawn import file_pin as pin
from mp_identity import stat_identity,own_process,fd_row

def verify(binding,policy_path,guard_path):
    assert type(binding)is dict and binding['version']==1 and binding['role']in('actor','tracker')
    assert sys.flags.no_site==1 and sys.dont_write_bytecode and sys.flags.optimize==0
    argv=tuple(sys.orig_argv);assert argv.count('-c')==1
    command=argv[argv.index('-c')+1];tree=ast.parse(command)
    final=tree.body[-1]
    assert type(final)is ast.Expr and type(final.value)is ast.Call
    call=final.value;assert type(call.func)is ast.Name and call.func.id=='exec'and len(call.args)==1 and not call.keywords
    comp=call.args[0];assert type(comp)is ast.Call and type(comp.func)is ast.Name and comp.func.id=='compile'
    assert len(comp.args)==3 and not comp.keywords
    text,filename,mode=(ast.literal_eval(value)for value in comp.args)
    assert filename=='<string>'and mode=='exec'and type(text)is str
    assert hashlib.sha256(text.encode()).hexdigest()==binding['originalCommandSha256']
    # The guarded original creator retains this precise grammar from the
    # actual stdlib caller, not from a peer command/expected result.
    original=ast.parse(text);assert len(original.body)==2
    first,last=original.body
    assert type(first)is ast.ImportFrom and first.level==0
    expected_module='multiprocessing.spawn'if binding['role']=='actor'else'multiprocessing.resource_tracker'
    expected_fn='spawn_main'if binding['role']=='actor'else'main'
    assert first.module==expected_module and len(first.names)==1 and first.names[0].name==expected_fn and first.names[0].asname is None
    assert type(last)is ast.Expr and type(last.value)is ast.Call and type(last.value.func)is ast.Name and last.value.func.id==expected_fn
    assert all(type(arg)is ast.Constant and type(arg.value)is int for arg in last.value.args)
    assert all(keyword.arg in('tracker_fd','pipe_handle')and type(keyword.value)is ast.Constant and type(keyword.value.value)is int for keyword in last.value.keywords)
    args=[arg.value for arg in last.value.args];kw={k.arg:k.value.value for k in last.value.keywords}
    if binding['role']=='actor':
        assert not args and set(kw)=={'tracker_fd','pipe_handle'}
        assert kw['tracker_fd']==binding['trackerWriteDescriptor']
        assert str(kw['pipe_handle'])in binding['actualPassedDescriptors']
    else:assert len(args)==1 and not kw and str(args[0])in binding['actualPassedDescriptors']
    main=sys.modules['__main__'];assert type(main)is types.ModuleType
    assert vars(main).get('__spec__')is None and vars(main).get('__file__')is None
    if '__mp_main__'in sys.modules:assert sys.modules['__mp_main__']is main
    assert Path(policy_path)==Path(binding['policyPath'])and pin(policy_path)==binding['policyPin']
    assert Path(guard_path)==Path(binding['guardPath'])and pin(guard_path)==binding['guardPin']
    actual_parent=stat_identity(os.getppid());assert actual_parent is not None
    expected={k:binding['parent'][k]for k in actual_parent};assert actual_parent==expected
    parent=own_process(os.getppid(),expected)
    assert binding['parentMainSpecName']=='tablet_mp_variant_utility.__main__'
    main_file=Path(binding['ownedRoot'])/'tablet_mp_variant_utility/__main__.py'
    assert Path(binding['parentMainFile'])==main_file and pin(main_file)==binding['parentMainPin']
    parent_argv=Path('/proc',str(os.getppid()),'cmdline').read_bytes().split(b'\0')
    if parent_argv[-1]==b'':parent_argv.pop()
    parent_argv=[os.fsdecode(value)for value in parent_argv]
    assert parent_argv.count('-m')==1 and parent_argv[parent_argv.index('-m')+1]=='tablet_mp_variant_utility'
    assert '-S'in parent_argv and '-B'in parent_argv and stat_identity(os.getppid())==expected
    assert parent['executable']==str(Path(sys.executable).resolve(strict=True))
    for fd,row in binding['actualPassedDescriptors'].items():assert fd_row(int(fd))==row
    return dict(actualCommandSha256=hashlib.sha256(command.encode()).hexdigest(),originalCommandSha256=binding['originalCommandSha256'],
        actualOrigArgv=list(argv),actualParentOrigArgv=parent_argv,actualParent=parent,actualChildPID=os.getpid(),actualRole=binding['role'],
        actualMainFile=None,actualMainSpec=None,noSyntheticModuleOrSpec=True)
