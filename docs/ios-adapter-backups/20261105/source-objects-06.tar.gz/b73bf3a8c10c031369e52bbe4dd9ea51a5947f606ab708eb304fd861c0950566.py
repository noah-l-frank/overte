"""Private Root-only exact policy/cache mechanism stages, metadata/AST only."""
import ast,difflib,hashlib,json,stat
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/emote-callback-live-prefix-external-parser-mechanisms25-gated-root-preparation-20261102';BASE=REPO/'.ios-host-tmp/lifecycle-resource4-released-observer-four-selected-stages-root-preparation-20261102/first1';SOURCE=REPO/'.ios-host-tmp/emote-callback-live-prefix-external-parser-policy-class-closure-20261102'
def write(p,v):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(v)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for packet in (BASE,SOURCE):
 for name,digest in json.loads((packet/'freeze.json').read_text())['files'].items():assert sha(packet/name)==digest
baseplan=json.loads((BASE/'run-plan.json').read_text());manifest=json.loads((BASE/'source-manifest.json').read_text());superplan=json.loads((BASE/'supervisor-plan.json').read_text())
testpath='tests/device/ios/self_tests/test_ios_emote_callback_live_history_cache.py';tree=ast.parse((SOURCE/'candidate'/testpath).read_bytes())
classes={n.name:n for n in tree.body if isinstance(n,ast.ClassDef)}
ids={name:['ios.self_tests.test_ios_emote_callback_live_history_cache.'+name+'.'+n.name for n in node.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')] for name,node in classes.items()}
assert len(ids['CallbackLivePolicySmokeTests'])==1 and len(ids['CallbackLiveHistoricalRowsTests'])==25
helpers=('root-child.py','root-supervise.py','root_stage_guard.py','raise_observer.py','run-selected.py','sdk-original-pins.json')
prior=json.loads((BASE/'prior-retained-original-pins.json').read_text());fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);r=dict(stat=[getattr(a,k) for k in fields])
 if stat.S_ISREG(a.st_mode):r['sha256']=sha(p)
 assert r['stat']==[getattr(p.lstat(),k) for k in fields];return r
# New source1-clock failure remains preserved. No historical runtime frame is
# imported or replayed; these are current rawpin retention checks only.
report=BASE/'root-run-first/report.json'
if report.exists():
 root=BASE/'retained-first';expected=json.loads((BASE/'root-run-first/originals-first.json').read_text());actual={str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))};assert actual==expected
 for name,row in actual.items():prior[str(root/name)]=row
 for path in (BASE/'root-run-first').glob('*'):
  if path.is_file():prior[str(path)]=pin(path)
 for pattern in ('case-cleanup-*/*.json','actual-source-raise*','terminal-census-*.json'):
  for path in BASE.glob(pattern):
   if path.is_file():prior[str(path)]=pin(path)
# Bind literal actual completed prerequisite history, never a future public source map.
NATIVE=REPO/'.ios-host-tmp/lifecycle-resource4-sdk-separated-actual-native3-gated-root-preparation-20261102'
OLD=REPO/'.ios-host-tmp/emote-callback-live-prefix-policy-mechanisms-root-preparation-20261102/smoke1'
actual=[]
def retain_actual(stage,expected_exit,expected_files):
 report=json.loads((stage/'root-run-first/report.json').read_text())
 assert report['exitCode']==expected_exit and report['retainedFiles']==expected_files
 assert all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and report['remainingOwnedProcesses']==[]
 assert json.loads((stage/'root-run-first/thread-report.json').read_text())=={'exitCode':expected_exit,'remainingNewThreads':[]}
 assert json.loads((stage/'root-run-first/source-before.json').read_text())==json.loads((stage/'root-run-first/source-after.json').read_text())
 root=stage/'retained-first';expected=json.loads((stage/'root-run-first/originals-first.json').read_text())
 current={str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))};assert current==expected==json.loads((stage/'root-run-first/originals-second.json').read_text())
 frozen=set(json.loads((stage/'freeze.json').read_text())['files'])|{'freeze.json'}
 for p in sorted(stage.rglob('*')):
  if str(p.relative_to(stage)) not in frozen:prior[str(p)]=pin(p)
 for index,case in enumerate(json.loads((stage/'run-plan.json').read_text())['cases'],1):
  receipt=json.loads((stage/('case-cleanup-'+str(index))/'receipt.json').read_text())
  assert receipt['case']==case and receipt['actualStandardCaseRunReturned'] and receipt['twoCensusesPassed']
  a=json.loads((stage/('case-cleanup-'+str(index))/'terminal-census-1.json').read_text());b=json.loads((stage/('case-cleanup-'+str(index))/'terminal-census-2.json').read_text());assert a==b
  assert a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 actual.append(dict(stage=str(stage),exitCode=expected_exit,retainedFiles=expected_files,reportSHA256=sha(stage/'root-run-first/report.json'),cases=json.loads((stage/'run-plan.json').read_text())['cases']))
retain_actual(OLD,1,0)
SECOND=REPO/'.ios-host-tmp/emote-callback-live-prefix-exact-partial-mechanisms14-root-preparation-20261102/smoke1';retain_actual(SECOND,1,0)
assert json.loads((SECOND/'selected-result.json').read_text())['successful'] is False
old_result=json.loads((OLD/'selected-result.json').read_text());assert old_result['successful'] is False and old_result['testsRun']==1
THIRD=REPO/'.ios-host-tmp/emote-callback-live-prefix-exact-socket-mechanisms15-root-preparation-20261102/smoke1';retain_actual(THIRD,1,0)
assert json.loads((THIRD/'selected-result.json').read_text())['successful'] is False
FOURTH=REPO/'.ios-host-tmp/emote-callback-live-prefix-typed-mapping-mechanisms17-root-preparation-20261102/smoke1';retain_actual(FOURTH,1,0)
assert json.loads((FOURTH/'selected-result.json').read_text())['successful'] is False
FIFTH=REPO/'.ios-host-tmp/emote-callback-live-prefix-typed-set-mechanisms19-root-preparation-20261102/smoke1';retain_actual(FIFTH,1,0)
assert json.loads((FIFTH/'selected-result.json').read_text())['successful'] is False
for name,count in (('first1',19),('foreignPostrelease1',19),('remaining6',107),('normal1',62)):retain_actual(NATIVE/name,0,count)
save(HERE/'actual-history-bindings.json',actual)
modules=ast.literal_eval(next(n.value for n in ast.parse((SOURCE/'candidate/tests/device/ios/adapters/emote_callback_live_records.py').read_bytes()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARSER_MODULES' for t in n.targets)))
source_rows=json.loads((SOURCE/'plan.json').read_text())['sourceRows'];stages=[]
for name,cls,seconds,roots in [('smoke1','CallbackLivePolicySmokeTests',15,0),('mechanisms25','CallbackLiveHistoricalRowsTests',30,25)]:
 stage=HERE/name;stage.mkdir(mode=0o700)
 for helper in helpers:write(stage/helper,(BASE/helper).read_text())
 write(stage/'actual_smoke_prerequisite.py','"""Actual changed smoke PASS before any selected mechanisms target import."""\nimport hashlib,json,stat\nfrom pathlib import Path\nF=(\'st_dev\',\'st_ino\',\'st_mode\',\'st_nlink\',\'st_uid\',\'st_gid\',\'st_size\',\'st_mtime_ns\',\'st_ctime_ns\')\ndef require(here,repo,current=None):\n if here.name==\'smoke1\':return []\n smoke=here.parent/\'smoke1\';out=smoke/\'root-run-first\';report=json.loads((out/\'report.json\').read_text())\n assert report[\'exitCode\']==0 and report[\'retainedFiles\']==0 and all(report[k] for k in (\'allPinsEqual\',\'rootMapUnchanged\',\'retainedOriginalsUnchanged\')) and not report[\'remainingOwnedProcesses\']\n assert json.loads((out/\'thread-report.json\').read_text())==dict(exitCode=0,remainingNewThreads=[])\n assert json.loads((out/\'source-before.json\').read_text())==json.loads((out/\'source-after.json\').read_text())\n assert json.loads((out/\'originals-first.json\').read_text())==json.loads((out/\'originals-second.json\').read_text())\n cases=json.loads((smoke/\'run-plan.json\').read_text())[\'cases\'];r=json.loads((smoke/\'selected-result.json\').read_text())\n assert len(cases)==1 and r[\'selectedIds\']==cases and r[\'successful\'] and r[\'testsRun\']==1 and not any(r[k] for k in (\'failureCount\',\'errorCount\',\'skippedCount\'))\n old=json.loads((out/\'root-source-map.json\').read_text());assert old[\'repositoryRoot\']==str(repo)\n if current is not None:assert current[\'currentSourcePins\']==old[\'currentSourcePins\'] and current[\'reviewedCandidates\']==old[\'reviewedCandidates\']\n for relative,digest in old[\'currentSourcePins\'].items():\n  p=repo/relative;assert p.is_relative_to(repo) and p.resolve(strict=True)==p and hashlib.sha256(p.read_bytes()).hexdigest()==digest\n c=smoke/\'case-cleanup-1\';a=json.loads((c/\'terminal-census-1.json\').read_text());b=json.loads((c/\'terminal-census-2.json\').read_text());assert a==b and a[\'threads\']==a[\'pendingTasks\']==a[\'sdkModules\']==[] and a[\'children\']==\'\'\n receipt=json.loads((c/\'receipt.json\').read_text());assert receipt[\'case\']==cases[0] and receipt[\'actualStandardCaseRunReturned\'] and receipt[\'twoCensusesPassed\']\n process=json.loads((out/\'process-binding.json\').read_text())[\'task\']\n try:row=Path(\'/proc\',str(process[\'pid\']),\'stat\').read_text().rsplit(\') \',1)[1].split()\n except (FileNotFoundError,ProcessLookupError):row=None\n assert row is None or int(row[19])!=process[\'startTicks\']\n frozen=set(json.loads((smoke/\'freeze.json\').read_text())[\'files\'])|{\'freeze.json\'};paths=[]\n for p in sorted(smoke.rglob(\'*\')):\n  if str(p.relative_to(smoke)) in frozen:continue\n  assert p.resolve(strict=True)==p;v=p.lstat();assert stat.S_ISREG(v.st_mode) or stat.S_ISDIR(v.st_mode);paths.append(p)\n return paths\n')
 parent=(stage/'root-supervise.py').read_text();parent=parent.replace('def sources(stage):','from actual_smoke_prerequisite import require as require_smoke\ndef sources(stage):');parent=parent.replace(' return {str(path):pin(path) for path in sorted(paths)}',' paths.update(require_smoke(HERE,REPO))\n return {str(path):pin(path) for path in sorted(paths)}');(stage/'root-supervise.py').write_text(parent)
 code=(stage/'run-selected.py').read_text()
 code=code.replace("namespaces={'adapters':('tests/device/adapters',sys.path),", "namespaces={'feature_journeys':('tests/device/feature_journeys',sys.path),'fixture':('tests/device/fixture',sys.path),'adapters':('tests/device/adapters',sys.path),")
 anchor="        if not result.wasSuccessful():return 1\n";assert code.count(anchor)==1
 insertion='''        actual_ids=[case.id() for case in suite]
        need_ids=plan['cases'];assert actual_ids==need_ids
        with (HERE/'selected-result.json').open('x') as output:
            json.dump(dict(status='ACTUAL_EXACT_HOST_SELECTION_RETURNED',selectedIds=actual_ids,testsRun=result.testsRun,
                successful=result.wasSuccessful() and result.testsRun==plan['caseCount'] and not result.skipped,
                failureCount=len(result.failures),errorCount=len(result.errors),skippedCount=len(result.skipped),
                nativeCompiled=False,sdkExecuted=False,wholeFeatureQualified=False),output,indent=2);output.write('\\n')
'''
 code=code.replace(anchor,insertion+anchor)
 code=code.replace('    initial=baseline() # BEFORE any target module import.', '    from actual_smoke_prerequisite import require as require_smoke\n    require_smoke(HERE,repo,mapping) # Actual same-source smoke PASS, after audit and before target imports.\n    initial=baseline() # BEFORE any target module import.')
 (stage/'run-selected.py').write_text(code)
 plan=dict(baseplan,status='PRIVATE_UNRUN_EMOTE_HISTORY_'+name,cases=ids[cls],caseCount=len(ids[cls]),totalCaseCount=len(ids[cls]),initialOuterSeconds=seconds,expectedRetainedRoots=roots,modelMaps={},registryRequirements={},mkdtempAliases=[],retainInstalledFixture=False,retainedTemporaryDirectoryAliases=['ios.self_tests.test_ios_emote_callback_live_history_cache'])
 plan['requiredPublicDependencies']=sorted(set(baseplan['requiredPublicDependencies'])|{'tests/device/'+m.replace('.','/')+'.py' for m in modules}|{r['path'] for r in source_rows})
 plan['privateFiles']={p.name:sha(p) for p in sorted(stage.glob('*.py'))};plan['qualification']='Actual existing AvatarRecordCache/file/lock/metadata/policy mechanics only; no feature/native/SDK/device/whole acceptance.'
 save(stage/'run-plan.json',plan);save(stage/'prior-retained-original-pins.json',prior)
 source_paths=[]
 for row in source_rows:
  source_paths.append(dict(path=row['path'],candidate=str(SOURCE/'candidate'/row['path']),candidateSHA256=row['candidateSHA256'],observedPublicSHA256=sha(REPO/row['path']) if (REPO/row['path']).exists() else None,changesCurrentPublic=True))
 current=dict(manifest,name=name,stage='emote-history-'+name,status=plan['status'],sourcePaths=source_paths,sourcePathCount=3,caseCount=len(ids[cls]),pythonCaseCount=len(ids[cls]),initialTimeoutSeconds=seconds,sourceDeltaPaths=[r['path'] for r in source_paths])
 current['orderedParentFreezes']=dict(manifest['orderedParentFreezes']);current['orderedParentFreezes'][str(SOURCE.relative_to(REPO/'.ios-host-tmp'))]=sha(SOURCE/'freeze.json');current['orderedParentFreezes'][str(NATIVE.relative_to(REPO/'.ios-host-tmp'))]=sha(NATIVE/'freeze.json');current['actualPublicBasis']='Actual after exact reviewed partial Source2 and Root batch publication; no old747 runtime decode or anticipated source map'
 save(stage/'source-manifest.json',current);save(stage/'supervisor-plan.json',dict(superplan,initialSeconds=seconds))
 for path in stage.glob('*.py'):ast.parse(path.read_bytes(),filename=str(path))
 save(stage/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={p.name:sha(p) for p in sorted(stage.iterdir()) if p.is_file() and p.name!='freeze.json'}))
 stages.append(dict(name=name,cases=ids[cls],initialSeconds=seconds,killAfterSeconds=5,realRoots=roots,freeze=sha(stage/'freeze.json')))
write(HERE/'launcher-delta-only.diff',''.join(difflib.unified_diff((BASE/'run-selected.py').read_text().splitlines(True),(HERE/'smoke1/run-selected.py').read_text().splitlines(True),fromfile='qualified-guarded/run-selected.py',tofile='emote-exact/run-selected.py')))
save(HERE/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceFreeze=sha(SOURCE/'freeze.json'),sourceRows=source_rows,actualHistoryBindings=actual,stages=stages,old747RuntimeReplayForbidden=True,requiredOrder='Actual smoke1 PASS before mechanisms25; fresh graph remainsHARDHOLD until actual both selections PASS with original terminal receipts.',freshGraphControllerNotYetImplemented=True,testsRun=False,targetImports=False,sourcePublished=False))
write(HERE/'ROOT-PLAN.txt','UNRUN Root-only prerequisite stages, Exact external JSON/PNG closure Source2 d6e36/7406187/dc88ce9 required before any import. Existing corrected Native source guard/supervision and actual post-standard-case Runner.close FD/task/thread/child/two-file-census remain; only add canonicalfeature_journeys/fixture namespace preflight and actual exact selected-result JSON after real standard run. Smoke first15+kill5,0TD; mechanisms25 first30+kill5,25TD. No subprocesses in either child. Original source1-native clock failure15files, all five actual old smokeFAIL0file stages, and actual Native248 all four PASS stages19+19+107+62 files preserved as exact current rawpins, source maps and original case receipts. No old747 runtime frame is decoded. Future freshpostboot graph musthardgate BOTH actual parent0/childsuccess/exactIDs/percasecleanup receipts, not plan flags. No new feature/native/SDK acceptance.\n')
save(HERE/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'},stageFreezes={v['name']:v['freeze'] for v in stages}))
print(json.dumps(dict(packet=str(HERE),freeze=sha(HERE/'freeze.json'),stages=stages)))
