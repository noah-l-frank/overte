"""Fixed300+5, one fresh unchanged Source2 case; one original Node lineage.

Discovery grants no signal authority. Unknown/missing lineage or any retained
PID keeps closure partial; no quiet full-room census is then attempted.
"""
from pathlib import Path
import hashlib,json,os,signal,stat,subprocess,sys,threading,time,traceback
from metadata_reader import pin
from host_common import head
from source_execution_readiness import qualification
from backend_utility_readiness import boundary_qualification
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert sys.flags.no_site==1 and sys.dont_write_bytecode and len(sys.argv)==2
INPUT=HERE/'approved-inputs.json';assert pin(INPUT)['sha256']==sys.argv[1]
plan=json.loads(INPUT.read_text());assert plan['status']=='PRIVATE_ASSETS_SOURCE3_FIRST_ORDINARY2_UNRUN'
assert HERE==Path(plan['controllerRoot'])and REPO==Path(plan['repositoryRoot'])and head()==plan['actualPublicHead']
assert plan['wallSeconds']==300 and plan['killGraceSeconds']==5 and len(plan['cases'])==1
current,current_pins=qualification(pin);assert current==plan['qualifiedSourceExecution']and all(plan['sourceAndBinaryPins'].get(n)==r for n,r in current_pins.items())
assert all(pin(n)==r for n,r in plan['sourceAndBinaryPins'].items())
backend,backend_pins=boundary_qualification(REPO,pin,HERE)
assert backend==plan['backendBoundaryQualification']and all(plan['sourceAndBinaryPins'].get(p)==row for p,row in backend_pins.items())
def identity(pid):
    try:text=Path('/proc',str(pid),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    fields=text[text.rfind(')')+2:].split()
    return dict(pid=int(text[:text.index('(')].strip()),parent=int(fields[1]),group=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
def table():
    result={}
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            value=identity(int(p.name))
            if value is not None:result[value['pid']]=value
    return result
def fds():
    result={}
    for p in Path('/proc/self/fd').iterdir():
        try:i=p.stat();result[p.name]=dict(target=os.readlink(p),device=i.st_dev,inode=i.st_ino,mode=i.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result
def census(root):
    result={}
    def visit(path):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):
            names=sorted(p.name for p in path.iterdir());row=dict(stat=[getattr(info,n)for n in('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')],namespace=names)
            for name in names:visit(path/name)
            fresh=path.lstat();assert all(getattr(fresh,n)==getattr(info,n)for n in('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns'))
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        result[str(path.relative_to(root))]=row
    visit(root);return result
OUTER=HERE.with_name(HERE.name+'-outer');assert not OUTER.exists();OUTER.mkdir(mode=0o700)
def save(name,value):
    p=OUTER/name;assert p.parent==OUTER
    with p.open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    p.chmod(0o600)
initial_names=sorted(p.name for p in HERE.iterdir());input_before=pin(INPUT);before={n:pin(n)for n in plan['sourceAndBinaryPins']}
parent_fds=fds();parent_threads=tuple(threading.enumerate());baseline=table()
for name in('temporary','child-logs'):(HERE/name).mkdir(mode=0o700)
LOGS=HERE/'child-logs';stdin=LOGS/'stdin.eof';stdin.write_bytes(b'')
process=None;birth=None;observed={};problems=[];timed=False;forced=False;term_at=None;started=time.monotonic();report=None
save('attempted-room.json',dict(input=str(INPUT),inputSHA=sys.argv[1],HERE=str(HERE),outer=str(OUTER),cases=plan['cases']))
save('supervisor-launch-binding.json',dict(task=identity(os.getpid()),cases=plan['cases'],wallSeconds=300,killGraceSeconds=5,supervisorSource=str(HERE/'supervise-one.py')))
def observe(row):
    old=observed.setdefault(row['pid'],row)
    if old!=row:problems.append(dict(kind='observed-process-identity-change',first=old,current=row))
def scan():
    actual=table()
    if birth is None:return actual
    selected={birth['pid']};changed=True
    while changed:
        changed=False
        for pid,row in actual.items():
            if pid in selected:continue
            if row['parent']in selected or row['group']==birth['group']or row['session']==birth['session']:
                assert pid not in baseline;selected.add(pid);observe(row);changed=True
    if len(selected)>2:problems.append(dict(kind='unselected-extra-processes',identities=[actual[p]for p in selected if p in actual]))
    for pid in observed:
        if pid in actual:observe(actual[pid])
    return actual
try:
    with stdin.open('rb')as incoming,(LOGS/'stdout.log').open('xb')as output,(LOGS/'stderr.log').open('xb')as error:
        process=subprocess.Popen([plan['pythonExecutable']['path'],'-S','-B',str(HERE/'run-one.py'),str(INPUT),sys.argv[1]],cwd=REPO,stdin=incoming,stdout=output,stderr=error,start_new_session=True,
          env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(HERE/'temporary'),'PATH':str(Path(plan['nodePin']['path']).parent)})
    birth=identity(process.pid);assert birth is not None and birth['parent']==os.getpid()and birth['session']==birth['group']==birth['pid'];observe(birth)
    save('actual-original-runner-birth.json',birth)
    while True:
        scan();code=process.poll()
        if code is not None:break
        if time.monotonic()-started>=300 and term_at is None:
            timed=True;term_at=time.monotonic();assert identity(birth['pid'])==birth;os.kill(birth['pid'],signal.SIGTERM)
        if term_at is not None and time.monotonic()-term_at>=5:
            forced=True;assert identity(birth['pid'])==birth;os.kill(birth['pid'],signal.SIGKILL);process.wait();break
        time.sleep(.025)
    process.wait()
except BaseException:problems.append(dict(kind='original-supervisor-error',traceback=traceback.format_exc()))
finally:
    scan()
    if process is not None and process.poll()is None:
        # Only the exact original child may be signalled, never a discovery.
        actual=identity(process.pid)
        if birth is not None and actual==birth:os.kill(birth['pid'],signal.SIGKILL);process.wait();forced=True
        else:problems.append(dict(kind='original-runner-ownership-unknown',actual=actual))
    path=HERE/'actual-report.json'
    if path.is_file():
        try:report=json.loads(path.read_text())
        except BaseException:problems.append(dict(kind='original-report-unreadable',traceback=traceback.format_exc()))
    rows=[]if report is None else report.get('actualOriginalNodes',[])
    node_lineage=report is not None and report.get('completeOriginalNodeLineage')is True and len(rows)==1
    reported=set()
    if node_lineage:
        for row in rows:
            b=row['birth'];assert type(b)is dict and b['pid']==row['pid']and b['parentPid']==birth['pid']and b['session']==birth['session']and b['processGroup']==birth['group']
            expected=dict(pid=b['pid'],parent=b['parentPid'],group=b['processGroup'],session=b['session'],startTicks=b['startTicks'])
            if b['pid']in observed:assert observed[b['pid']]==expected
            observed.setdefault(b['pid'],expected);reported.add(b['pid'])
        node_lineage=set(observed)<={birth['pid']}|reported
    remaining=[dict(first=old,current=identity(pid))for pid,old in observed.items()if identity(pid)is not None]
    save('actual-drain.json',dict(originalRunner=birth,observed=list(observed.values()),reportedOriginalNodes=rows,observationsGrantNoSignalAuthority=True,remaining=remaining,completeOriginalNodeLineage=node_lineage,timedOut=timed,forced=forced))
    if not node_lineage or remaining or process is None or process.poll()is None:
        save('unqualified-partial.json',dict(status='UNQUALIFIED_PARTIAL_NO_QUIET_CENSUS',allAttemptedRooms=[str(HERE),str(OUTER)],originalReport=report,problems=problems,
          originalLineageEstablished=node_lineage,remaining=remaining,noWholeOutputOrGlobalClosureClaim=True))
        raise SystemExit(1)
    # Quietness is independently established before every whole-room census.
    def absent():return all(identity(pid)is None for pid in observed)
    assert absent();first=census(HERE);assert absent();second=census(HERE);assert absent()
    save('whole-HERE-first.json',first);save('whole-HERE-second.json',second)
    after={n:pin(n)for n in plan['sourceAndBinaryPins']};input_after=pin(INPUT)
    passed=process.returncode==0 and not timed and not forced and not problems and report is not None and report['status']=='PASS'and report['testsRun']==1
    passed=passed and first==second and before==after and input_before==input_after and input_after['sha256']==sys.argv[1]and fds()==parent_fds and tuple(threading.enumerate())==parent_threads and head()==plan['actualPublicHead']
    assert all(name in first and name in second for name in initial_names)
    terminal=dict(status='PASS'if passed else'FAIL_OR_REFUSED',childReturnCode=process.returncode,timedOut=timed,forcedKill=forced,problems=problems,ownProcessesAbsent=True,
      completeOriginalNodeLineage=node_lineage,twoWholeHEREEqual=first==second,inputAndSourcePinsUnchanged=before==after and input_before==input_after,
      parentFDThreadUnchanged=fds()==parent_fds and tuple(threading.enumerate())==parent_threads,originalReport=report,elapsedSeconds=time.monotonic()-started,
      phaseAdmission=None,normalAction2Qualified=False,nativeQualified=False,wholeQualified=False)
    save('terminal.json',terminal)
CLOSED=HERE.with_name(HERE.name+'-censuses');assert not CLOSED.exists();CLOSED.mkdir(mode=0o700)
assert absent();whole_first=dict(HERE=census(HERE),outer=census(OUTER));assert absent();whole_second=dict(HERE=census(HERE),outer=census(OUTER));assert absent()
for name,value in(('whole-first.json',whole_first),('whole-second.json',whole_second)):
    p=CLOSED/name
    with p.open('x')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    p.chmod(0o600)
qualified=passed and whole_first==whole_second
with(CLOSED/'qualification.json').open('x')as stream:json.dump(dict(status='PASS'if qualified else'FAIL_OR_REFUSED',cases=plan['cases'],originalRooms=[str(HERE),str(OUTER),str(CLOSED)],twoEntireHEREAndOuterEqual=whole_first==whole_second,exclusions=[],phaseAdmission=None,nativeQualified=False,wholeQualified=False),stream,indent=2,sort_keys=True);stream.write('\n')
(CLOSED/'qualification.json').chmod(0o600)
raise SystemExit(0 if qualified else 1)
