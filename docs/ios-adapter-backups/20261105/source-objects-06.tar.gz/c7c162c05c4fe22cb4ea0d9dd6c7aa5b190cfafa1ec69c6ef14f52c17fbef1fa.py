from pathlib import Path
import ast,hashlib,json,shutil
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-passive-carrier10-single-read-root-preparation-20261029/49-native-passive-carrier10';CAD=T/'lifecycle-original-owner-passive-carrier-original-world-cadence-overlay-20261029';READER=T/'lifecycle-original-owner-selected-motion-original-reader-proposal-20261028';BIND=T/'lifecycle-original-owner-passive-carrier-host-binding-model-overlay-20261029';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not (B/'root-run-first').exists()
for packet in (CAD,READER,BIND):
 for rel,d in json.loads((packet/'freeze.json').read_text())['files'].items():assert H(packet/rel)==d
for num,label,count,cap,packet in [(50,'native-passive-cadence12',12,90,CAD),(51,'selected-motion-reader4',4,60,READER)]:
 P=T/('lifecycle-original-owner-'+label+'-root-preparation-20261029');assert not (P/'freeze.json').exists();P.mkdir(mode=0o700,exist_ok=True);S=P/(str(num)+'-'+label);S.mkdir(mode=0o700,exist_ok=True)
 for rel,d in json.loads((B/'freeze.json').read_text())['files'].items():
  assert H(B/rel)==d;out=S/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/rel,out)
 stage=json.loads((S/'source-manifest.json').read_text());cad=json.loads((CAD/'manifest.json').read_text());own={r['path']:r for r in cad['files']}
 if num==50:
  model='test_native_passive_carrier_models.py';shutil.copyfile(CAD/model,S/model);cases=cad['cases']
 else:
  for name in ['test_native_passive_carrier_models.py','test_native_passive_scope_models.py','test_native_motion_existing_rpc_models.py','test_native_motion_worker_scope_models.py','test_motion_selected_join_models.py','motion_reference_fixture.py','native_acquisition_fixture.py','native_file_fixture.py']:shutil.copyfile(READER/name,S/name)
  shutil.copyfile(BIND/'test_native_passive_carrier_models.py',S/'test_native_passive_carrier_models.py')
  model='test_selected_motion_original_reader_models.py';shutil.copyfile(READER/model,S/model);own.update({r['path']:r for r in json.loads((READER/'manifest.json').read_text())['files']});cases=json.loads((READER/'test-plan.json').read_text())['cases']
 changes=[]
 for row in stage['sourcePaths']:
  rel=row['path'];actual=H(R/rel)
  if rel in own:row.update(candidate=own[rel]['candidate'],candidateSHA256=own[rel]['candidateSHA256'],observedPublicSHA256=actual,changesCurrentPublic=actual!=own[rel]['candidateSHA256']);continue
  if actual!=row['candidateSHA256']:
   out=S/'actual-current-dependency/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(out),candidateSHA256=actual)
  row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
 stage.update(stage=num,name=S.name,status='PRIVATE_UNRUN_'+label.upper().replace('-','_'),caseCount=count,pythonCaseCount=count,initialTimeoutSeconds=cap,exactPublicMutationPlan='Root ONLY: '+('keeper311d actualWorldcadence+mandatorycallerread; runtime da56 unchanged' if num==50 else 'after Carrier Source311d qualification, runtimeb383 selected3reader; e115 fixture binding, no new registrykeys'))
 for p in (CAD,) if num==50 else (CAD,READER,BIND):stage['orderedParentFreezes'][p.name]=H(p/'freeze.json')
 (S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');plan=json.loads((S/'run-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_'+label.upper(),cases=cases,caseCount=count,totalCaseCount=count,expectedRetainedRoots=count*2,initialOuterSeconds=cap)
 if num==51:plan['privateFiles'][model]=H(S/model)
 for n in list(plan['privateFiles']):
  if (S/n).is_file():plan['privateFiles'][n]=H(S/n)
 (S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n');settings=json.loads((S/'supervisor-plan.json').read_text());settings['initialSeconds']=cap;(S/'supervisor-plan.json').write_text(json.dumps(settings,indent=2)+'\n')
 (S/('clone-provenance-'+label+'.json')).write_text(json.dumps(dict(original49UnrunPreserved=True,parent49Freeze=H(B/'freeze.json'),packetFreeze=H(packet/'freeze.json'),candidateSourcePaths=list(own),currentSharedChanged=changes,priorActualFiles=2727,futureRun50FilesNotYetAvailable=num==51,requiresFutureRetentionCloneAfter50=num==51,caseCount=count,initialSeconds=cap,killAfterSeconds=5,genuineRoots=count*2,executed=False),indent=2)+'\n')
 (S/('README-'+label+'.txt')).write_text(('Root50 exact12/90+kill5/24realTD. Candidate311d merges singlecallerread+actual original World cadence; NativeBefore oldendpoint/1500/250/3sec unchanged. Two new actual Worldinode/genuineNativeasWorld negatives. ExistingSource/globalSDK maps and original qualified45 controller,2727actual oldfiles;49 preservedUNRUN. No agent imports/tests/PUB.\n' if num==50 else 'Root51 exact4/60+kill5/8realTD. Existing selected3 reader Source1 b383 on keeper311d dependency; Source cannot execute untilRoot PUB. e115 hostFixture binding correction BEFORE native capture;4 explicitcaseIDs, no discovered inheritedtests.2727actual oldfiles currentlypinned. IMPORTANT Root50 stillUNRUN: clone once after terminal50 toadd its retained originals before this stage execution; do NOT upgrade oldmaps. Allsame FD/task/thread/child/tempdir/sockets/SDK/source guards. No agent imports/tests/PUB.\n'))
 for p in S.rglob('*.py'):ast.parse(p.read_bytes())
 (S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(stage=str(S),stageFreeze=H(S/'freeze.json'),parentFreeze=H(P/'freeze.json'),model=H(S/model),changes=changes),indent=2))
