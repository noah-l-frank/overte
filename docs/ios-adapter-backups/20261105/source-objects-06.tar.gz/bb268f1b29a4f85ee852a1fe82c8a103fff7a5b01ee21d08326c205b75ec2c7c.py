"""Stdlib-only custody for one retained Chat historical read diagnostic."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,shutil,sys
HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system',
       'scripts/communityScripts/armored-chat','interface/resources/qml','tests/javascript','domain-server/resources')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
RAW=REPO/'.ios-host-tmp/chat-send-proof-source15-paired-root-preparation-20261103/runs/paired1/first-12ss1l8w/temporary'
ARTIFACT=RAW/'tmp27bwiir_/candidate.ipa'
ARTIFACT_SHA='0c32ab52f1fa64c1f87a6ea2507debf0bb10773eead73e7e9fb5213aeb9a442f'

def load(name):return json.loads((HERE/name).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        pending=memoryview(raw)
        while pending:
            written=os.write(fd,pending);assert written>0;pending=pending[written:]
        os.fsync(fd)
    finally:os.close(fd)
def pin(path,*,retained_symlink=False):
    path=Path(path);a=path.lstat()
    assert stat.S_ISREG(a.st_mode)or stat.S_ISDIR(a.st_mode)or(retained_symlink and stat.S_ISLNK(a.st_mode)),str(path)
    row={key:getattr(a,key)for key in FIELDS}
    if stat.S_ISREG(a.st_mode):
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
        try:
            opened=os.fstat(fd);digest=hashlib.sha256()
            while True:
                chunk=os.read(fd,1024*1024)
                if not chunk:break
                digest.update(chunk)
            assert all(getattr(a,key)==getattr(opened,key)==getattr(os.fstat(fd),key)for key in FIELDS)
            row['sha256']=digest.hexdigest()
        finally:os.close(fd)
    elif stat.S_ISLNK(a.st_mode):row['target']=os.readlink(path)
    assert all(getattr(a,key)==getattr(path.lstat(),key)for key in FIELDS)
    return row
def census(root):
    assert root.resolve(strict=True)==root and root.is_dir()
    # Retained negative-model symlinks are physical evidence, never followed or
    # admitted as source/IPA/ordinary input files. Their exact link is frozen.
    return {str(p.relative_to(root)):pin(p,retained_symlink=True)for p in(root,*sorted(root.rglob('*')))}
def public_paths():
    rg=load('host-executable-pins.json')['rg']['path']if(HERE/'host-executable-pins.json').exists()else shutil.which('rg')
    assert rg
    names=subprocess.check_output([rg,'--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    return {REPO/name for name in names if name}|{REPO/'CMakeLists.txt',REPO/'interface/CMakeLists.txt'}
def global_roots():
    roots={Path(name)for name in load('global-root-seed.json')}
    for directory in(REPO/'.ios-host-tmp').iterdir():
        if directory.is_dir()and not directory.is_symlink():
            for name in('runs','temporary'):
                p=directory/name
                if p.is_dir()and not p.is_symlink():roots.add(p)
    return sorted(roots)
def global_census(roots):return {str(root):census(root)for root in roots}
def source_guard():
    expected=load('approved-source-map.json')
    actual=public_paths()
    public=set(load('public-membership.json'))
    assert set(map(str,actual))==public
    actual.update(Path(name)for name in expected if name not in public)
    assert set(map(str,actual))==set(expected)
    current={str(p):pin(p)for p in sorted(actual)}
    assert current==expected,'Source bytes/physical identity changed'
    return current
def validate():
    frozen=load('freeze.json')
    for row in frozen['files']:assert sha(HERE/row['path'])==row['sha256'],row['path']
    plan=load('plan.json')
    assert plan['publicHead']=='00fafcc4c097552198456c7e7687f243801d3ed8'
    assert len(plan['allowedSelectors'])==9 and plan['source16cFreeze']=='071818d0500f39232d60b79250421b3f1939cf3b9a0d66f5fcab8803de6c1312'
    for row in load('host-executable-pins.json').values():assert pin(Path(row['path']))==row['pin']
    assert str(Path(sys.executable).resolve())==load('host-executable-pins.json')['python']['path']
    for row in plan['packets']:assert sha(REPO/row['path']/'freeze.json')==row['freezeSha256']
    assert sha(ARTIFACT)==ARTIFACT_SHA and pin(ARTIFACT)==load('input-originals-baseline.json')['tmp27bwiir_/candidate.ipa']
    assert len([row for row in load('input-originals-baseline.json').values()if'sha256'in row])==41
    for relative in('tmpm0n175js/script-feature-sources.lock','tmp4anb7giw/script-feature-sources.lock'):
        row=load('input-originals-baseline.json')[relative]
        assert row['st_size']==0 and stat.S_IMODE(row['st_mode'])==0o600 and row['st_nlink']==1
    return plan
def proc(pid):
    try:f=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except(FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(f[1]),group=int(f[2]),session=int(f[3]),startTicks=int(f[19]))
def processes(session):
    rows=[]
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            row=proc(int(p.name))
            if row is not None and(row['group']==session or row['session']==session):rows.append(row)
    return rows
def fds():
    rows={}
    for p in Path('/proc/self/fd').iterdir():
        try:rows[p.name]=os.readlink(p)
        except(FileNotFoundError,ProcessLookupError):pass
    return rows
