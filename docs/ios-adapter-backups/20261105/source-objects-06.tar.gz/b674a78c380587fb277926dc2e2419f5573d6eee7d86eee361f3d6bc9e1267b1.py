"""Exact previously reviewed Root660/665 plus generic later context readers.

Only definitions here; never discover or census an original root. Unknown Root
schemas fail closed. Bodies stay literal flat st_* rows; no conversion exists.
"""
from pathlib import Path
import hashlib,json
SOURCE=Path(__file__).resolve().parent
REPO=SOURCE.parent.parent
PREVIOUS=REPO/'.ios-host-tmp/audio-normal-mute-prefix-controller3-final-preparation-20261104'
EXTRAS=REPO/'.ios-host-tmp/root-chat-own17-original-extra12-baselines-20261104'
BASE_CONTEXT=REPO/'.ios-host-tmp/root-terminal660-original-root-context-20261104/terminal-context.json'
CONTEXT=REPO/'.ios-host-tmp/root-terminal665-original-root-context-20261104/terminal-context.json'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def physical(path):
    path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_relative_to(REPO/'.ios-host-tmp');return path

def reference(row):
    assert type(row)is dict and set(row)=={'path','sha256'}
    path=physical(row['path']);assert path.is_file()and sha(path)==row['sha256'];return dict(path=str(path),sha256=row['sha256'])

def packet(root,filename,expected):
    root=physical(root);file=physical(root/filename);assert sha(file)==expected
    value=json.loads(file.read_text());rows=value['files']
    entries=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
    for name,row in entries:
        assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
        path=physical(root/name);assert path.is_file()and sha(path)==(row['sha256']if type(row)is dict else row)
    return dict(path=str(file),sha256=expected)

def terminal_proofs(value):
    extra=value['additionalOriginalRoots'];authority=value['authoritativeAdditionalOriginalRoots']
    assert type(extra)is list and all(type(root)is str for root in extra)and len(extra)==len(set(extra))
    assert type(authority)is dict and set(authority)==set(extra)
    proof=[]
    for root in extra:
        path=physical(root);assert path.is_dir()
        claim=authority[root];assert type(claim)is dict and set(claim)=={'freeze','result'}
        freeze=reference(claim['freeze']);result=reference(claim['result'])
        f=Path(freeze['path']);assert f.name=='freeze.json'and Path(result['path'])==f.parent/'results.json'
        proof.append(packet(f.parent,f.name,freeze['sha256']))
        manifest=json.loads(f.read_text());assert type(manifest['files'])is dict
        assert manifest['files']['results.json']['sha256']==result['sha256']
        proof.append(result)
    return proof

def terminal_common(value):
    assert value['status']=='ROOT_TERMINAL_CONTEXT_NO_TARGET_NO_GLOBAL_SCAN'
    assert type(value['globalScans'])is int and value['globalScans']==0
    assert type(value['targets'])is int and value['targets']==0 and value['noWriterExclusions']is True
    roots=value['roots'];assert type(roots)is list and all(type(root)is str for root in roots)and len(roots)==len(set(roots))
    return set(roots)

def root_context():
    # This exact two-layer contract intentionally rejects an unknown wrapper.
    # A newer Root set requires a newly reviewed metadata contract, never a
    # silent flatten/drop of baseContext or inferred writer exclusion.
    base_ref=reference(dict(path=str(BASE_CONTEXT),sha256='5bbdc7d787d18c7d5d2e5d456b2c9049b3054730ab952b8d8335822a10a42eac'))
    ctx_ref=reference(dict(path=str(CONTEXT),sha256='e45709c6feece4d2e0f4e70622610572baf8efa9ff47c1016bbabd09603a9837'))
    base=json.loads(BASE_CONTEXT.read_text());wrapper=json.loads(CONTEXT.read_text())
    common={'additionalOriginalRoots','authoritativeAdditionalOriginalRoots','globalScans','noWriterExclusions','roots','status','targets'}
    assert set(base)==common|{'base653Baseline','base653ExternalTerminal','base653Freeze','base653InputMap','base653Seed'}
    assert set(wrapper)==common|{'baseContext'}and wrapper['baseContext']==base_ref
    roots660=terminal_common(base);roots665=terminal_common(wrapper)
    assert len(roots660)==660 and len(roots665)==665
    assert len(base['additionalOriginalRoots'])==7 and len(wrapper['additionalOriginalRoots'])==5
    old=reference(base['base653Baseline']);assert old['path']==str(PREVIOUS/'global-original-corpus-baseline.json')and old['sha256']=='1e89fcf8ce75273e569fb83b2c865251bd6f2b35b4377aa30a7c570a0fa08cff'
    rows653=json.loads(Path(old['path']).read_text());assert type(rows653)is dict and len(rows653)==653
    assert set(rows653).isdisjoint(base['additionalOriginalRoots'])and roots660==set(rows653)|set(base['additionalOriginalRoots'])
    assert roots660.isdisjoint(wrapper['additionalOriginalRoots'])and roots665==roots660|set(wrapper['additionalOriginalRoots'])
    required={'base653Freeze':('freeze.json','bd27ef472d35a209f4a157deea16504ec718db0a9ce78f00d0448daa7621ab37'),
        'base653InputMap':('preimport-map.json','7eb647b3e770144f0a88f9e759063a5598fb4fe9ebd1a21345b4f2af07423090'),
        'base653Seed':('global-original-roots-seed.json','c98f202fd51111627336fac857dd1c3c8a540be2c8ae01db2b0a1ff07f8cb468'),
        'base653ExternalTerminal':('external-terminal.json','aaba3054b583be6b3c238d797852d8f7f718a91bb1e9f5c576279bdc42af9c6b')}
    proofs=[base_ref,ctx_ref,old]
    for key,(filename,expected)in required.items():
        row=reference(base[key]);assert row==dict(path=str(PREVIOUS/filename),sha256=expected);proofs.append(row)
    original_terminal=json.loads((PREVIOUS/'external-terminal.json').read_text())
    assert original_terminal['status']=='PASS'and original_terminal['childReturnCode']==0 and original_terminal['globalOldRoots']==653
    assert original_terminal['allPinsUnchanged']and original_terminal['ownProcessesAbsent']and original_terminal['twoExternalRawCensusesEqual']and original_terminal['twoFullGlobalCensusesEqual']and not original_terminal['problems']
    proofs+=terminal_proofs(base)+terminal_proofs(wrapper)
    extra_freeze=packet(EXTRAS,'freeze.json','3e518b2df56a7fa6d3cba8e31a8e39baec0ad47000b5e8b3aaabc47be7d5fe32')
    extra_path=EXTRAS/'expected-additional-originals.json';extra_proof=EXTRAS/'proofs.json'
    extra=json.loads(extra_path.read_text());assert type(extra)is dict and len(extra)==12 and set(extra)==roots665-set(rows653)
    proof=json.loads(extra_proof.read_text())
    assert proof['roots']==12 and proof['globalScans']==0 and proof['targets']==0 and proof['targetImports']==0 and proof['producerRawAndUtilityGroupsCompared']is True
    assert proof['old653RetainedBaseline']==old
    assert proof['status']=='TWICE_READ_TERMINAL_EXTRAS_MATCH_ORIGINAL_PARENT_RAW_OUTPUT_CENSUSES_AND_ALL_FROZEN_RECEIPT_HASHES'
    actual_receipts={json.dumps(claim['freeze'],sort_keys=True)for ctx in(base,wrapper)for claim in ctx['authoritativeAdditionalOriginalRoots'].values()}
    assert {json.dumps(row,sort_keys=True)for row in proof['terminalResultPackets']}==actual_receipts
    expected=dict(rows653);expected.update(extra);assert len(expected)==665
    proofs.extend((extra_freeze,dict(path=str(extra_path),sha256=sha(extra_path)),dict(path=str(extra_proof),sha256=sha(extra_proof))))
    return roots665,expected,proofs,base,wrapper

def normalized_private(value):
    assert type(value)is str and bool(value)
    path=Path(value)
    if not path.is_absolute():
        assert '..'not in path.parts
        path=REPO/path
    return physical(path)

EXACT_PROBE_TERMINAL_PROOFS = {'/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/root-chat-fileless-stdlib-xml-probe-source1-20261104': {'freezeSha256': 'c5d96a6606276955270560fbf1ad102ab09dc751c33843f480ed120d0a62d4e5', 'terminalSha256': '50533ff3df1b344e86f0fbe4a50e6f2f48f7461400deff0a6aff7a8a44428d14', 'status': 'PURE_STDLIB_PROBE_EXIT0_NO_PRODUCT_OR_CHILD_LAUNCH_CODE'}, '/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/root-chat-fileless-stdlib-expat-wrapper-probe-source2-20261104': {'freezeSha256': '009034cca145412004d81e8ac65be747528d420c91815a703fe47c664ed13fb9', 'terminalSha256': 'd9759d748cbf51c41fd651dd00afa7f59c1cad65b96c150091ebb6cc9669624f', 'status': 'PURE_STDLIB_EXPAT_WRAPPER_PROBE_EXIT0_ACTUAL_SAME_ORIGINAL_CHILD_ALIASES'}}

def later_context(path,expected_sha,bundle_freeze_sha,base_roots,base_expected):
    # The exact Root bundle binds every later whole original root and its
    # complete saved body. A failure's original status remains a failure.
    path=normalized_private(str(path));assert path.name=='terminal-results.json'
    ctx_ref=reference(dict(path=str(path),sha256=expected_sha))
    bundle=packet(path.parent,'freeze.json',bundle_freeze_sha)
    manifest=json.loads((path.parent/'freeze.json').read_text());members=manifest['files']
    assert type(members)is dict and members[path.name]['sha256']==expected_sha
    value=json.loads(path.read_text())
    assert set(value)=={'baseRootCount','expectedAdditionalBaseline','expectedRootCount','globalScans','noWriterExclusions','results','status','targets'}
    assert value['status']=='ROOT_TWICE_READ_CURRENT_COMPLETE_TERMINAL_ROOMS_ALL_ORIGINAL_RECEIPT_HASHES_MATCH_NO_GLOBAL_SCAN'
    assert type(value['baseRootCount'])is int and value['baseRootCount']==665
    assert type(value['globalScans'])is int and value['globalScans']==0 and type(value['targets'])is int and value['targets']==0
    assert value['noWriterExclusions']is True
    baseline=value['expectedAdditionalBaseline'];assert type(baseline)is dict and set(baseline)=={'path','sha256'}
    baseline_path=normalized_private(baseline['path']);assert baseline_path.parent==path.parent and baseline_path.name!='freeze.json'and baseline_path!=path
    baseline_ref=reference(dict(path=str(baseline_path),sha256=baseline['sha256']))
    assert members[baseline_path.name]['sha256']==baseline_ref['sha256']
    additional=json.loads(baseline_path.read_text());assert type(additional)is dict and bool(additional)
    assert all(type(root)is str for root in additional)and base_roots.isdisjoint(additional)
    for root,original in additional.items():
        assert normalized_private(root)==Path(root)and type(original)is dict and '.'in original
    results=value['results'];assert type(results)is list and bool(results)
    proofs=[ctx_ref,bundle,baseline_ref];declared=set();packets=set();absolute_results=[]
    for row in results:
        assert type(row)is dict and set(row)=={'freezeSha256','newOriginalRoots','path','roots','status','terminalJustification'}
        assert type(row['roots'])is list and type(row['newOriginalRoots'])is list and row['roots']==row['newOriginalRoots']and bool(row['roots'])
        assert all(type(root)is str for root in row['roots'])and len(set(row['roots']))==len(row['roots'])and declared.isdisjoint(row['roots'])
        assert type(row['status'])is str and bool(row['status'])and type(row['terminalJustification'])is str and bool(row['terminalJustification'])
        for root in row['roots']:assert normalized_private(root)==Path(root)and root in additional
        declared.update(row['roots']);root=normalized_private(row['path'])
        assert str(root)not in packets;packets.add(str(root))
        proof=packet(root,'freeze.json',row['freezeSha256'])
        result_manifest=json.loads((root/'freeze.json').read_text());assert type(result_manifest['files'])is dict
        probe=EXACT_PROBE_TERMINAL_PROOFS.get(str(root))
        if probe is None:
            # Every ordinary proof retains the original results.json schema.
            result_path=root/'results.json';assert 'results.json'in result_manifest['files']
            result_ref=reference(dict(path=str(result_path),sha256=result_manifest['files']['results.json']['sha256']))
        else:
            # Only these two genuine frozen pure-stdlib rooms put status/roots
            # in terminal.json. Their results.json remains untouched data.
            assert row['freezeSha256']==probe['freezeSha256']and row['status']==probe['status']
            result_path=root/'terminal.json'
            assert result_manifest['files']['terminal.json']['sha256']==probe['terminalSha256']
            result_ref=reference(dict(path=str(result_path),sha256=probe['terminalSha256']))
        actual=json.loads(result_path.read_text())
        assert actual['status']==row['status']and actual['newOriginalRoots']==row['newOriginalRoots']
        if probe is not None:
            assert actual['noGlobalCensus']is actual['noProductImports']is actual['noTargets']is True
            assert actual['terminal']==dict(childReturnCode=0,ownProcessesAbsent=True)
        proofs.extend((proof,result_ref));absolute_results.append(dict(row,path=str(root)))
    assert declared==set(additional)
    roots=base_roots|declared
    assert type(value['expectedRootCount'])is int and value['expectedRootCount']==len(roots)==665+len(declared)
    expected=dict(base_expected);expected.update(additional);assert set(expected)==roots
    normalized=dict(value,results=absolute_results,expectedAdditionalBaseline=baseline_ref,additionalOriginalRoots=sorted(declared))
    return roots,expected,proofs,normalized
