from pathlib import Path
import ast,difflib,hashlib,json
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');P=R/'.ios-host-tmp/lifecycle-original-owner-native-acquisition-join-proposal-20261028';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((P/'manifest.json').read_bytes());assert not (P/'freeze.json').exists()
names=['original-keeper-native-acquisition','original-keeper-native-acquisition-owner','original-keeper-native-acquisition-read','ios-lifecycle-native-acquisition-frame','ios-lifecycle-native-acquisition-original']
for rel,anchor in [('tests/device/contract-versions.json','    "original-keeper-installed-query": {"current": 1, "reads": [1]},\n'),('tests/device/validate_contract_versions.py','    "original-keeper-installed-query": 1,\n')]:
 base=R/rel;raw=base.read_text();assert raw.count(anchor)==1
 added=''.join('    '+json.dumps(name)+(': {"current": 1, "reads": [1]},\n' if rel.endswith('.json') else ': 1,\n') for name in names)
 assert all('"'+name+'"' not in raw for name in names);new=raw.replace(anchor,anchor+added,1);assert new.replace(added,'',1)==raw
 p=P/'candidate/repo'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(new);old=P/'bases/repo'/rel;old.parent.mkdir(parents=True,exist_ok=True);old.write_bytes(base.read_bytes());m['files'].append(dict(path=rel,baseSHA256=h(base),candidate=str(p),candidateSHA256=h(p),ownRegistryLinesOnly=True))
model=P/'test_native_acquisition_models.py';tree=ast.parse(model.read_bytes());ids=['test_native_acquisition_models.'+c.name+'.'+n.name for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.AsyncFunctionDef) and n.name.startswith('test_')];assert len(ids)==8
m.update(status='PRIVATE_DRAFT_SOURCE3_COMPAT2_MODEL8_UNRUN_AWAITING_FINAL_REVIEW',modelSHA256=h(model),baseFixtureSHA256=h(P/'native_file_fixture.py'),exactIds=ids,initialOuterSeconds=60,killGraceSeconds=5)
diff=[]
for row in m['files']:
 old=P/'bases/repo'/row['path'];new=Path(row['candidate']);row['candidateSHA256']=h(new)
 if new.suffix=='.py':ast.parse(new.read_bytes())
 diff.extend(difflib.unified_diff(old.read_text().splitlines(True),new.read_text().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path']))
(P/'proposal.diff').write_text(''.join(diff));(P/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
needed=['tests/device/ios/InstalledBundleIdentity.h','interface/src/scripting/TestScriptingInterface.cpp','tests/device/ios/adapters/bundle_observation.py','tests/device/ios/adapters/installed_code.py','tests/device/ios/adapters/bundle_identity.py','tests/device/ios/adapters/native_geometry.py','tests/device/ios/adapters/lifecycle_world.py','tests/device/adapters/native_clock_join.py','tests/device/adapters/original_frame_store.py','tests/device/adapters/normal_feature_state.py','tests/device/adapters/script_feature/lock.py','tests/device/ios/source-patches/original-owner-appium/node_modules/appium-ios-remotexpc/src/lib/tunnel/tunnel-api-client.ts','tests/device/ios/source-patches/original-owner-appium/node_modules/appium-ios-remotexpc/src/lib/tunnel/tunnel-registry-server.ts']
(P/'read-source-pins.json').write_text(json.dumps({rel:dict(path=str(R/rel),sha256=h(R/rel)) for rel in needed},indent=2)+'\n')
(P/'README.txt').write_text('''Feature14 original-child native acquisition / PRIVATE DRAFT, UNRUN

Dependencies actual Native2 and Query3; existing installed-candidate host entry
is independent. New existing keeper operations acquire/read + hostops allowlist
+ existing lifecycle runtime consumer; two exact own-family registry insertions.
All original packets/freezes/public/index remain unchanged. No SDK/target imports,
resolver execution, tests, compiler, device or native/service execution by agent.

Four actual source-issued query/file pairs, in order: native clock BEFORE,
UIKit geometry, World, native clock AFTER. Capture retains SAME real Source/RSD,
loop/Task/claim/touch/resource. Source-born tuple/closure is not caller supplied
or serialized; other tasks cannot start native query/read during this cut. The
same actual overall1.5s closure is called on ORIGINAL loop by every query's
actual pre-send/final transport callback and every native file guard. Individual
1.5s methods cannot turn into a6s accepted capture. Real HTTP Thread/AFC close
responsibility is still retained on cancellation, deadline or source loss.

Own queries have exact durable intent BEFORE send. The join reads the actual
live source-built nonce journal/record/index, requires original RSD/loop and
HTTP-returned phase, then reads the actual raw native file with that nonce.
Existing validate_join/source_frame_original/native_geometry enforce original
independent native BEFORE/AFTER clocks, PID/birth/counters/lifecycle, World
clock interval and geometry BEFORE World, no saved verdict or retiming. Geometry
has no standalone PID; original current OS/source guards and clock/PID bracket
remain distinct from that receipt's own schema.

Aggregate raw originals are NOT returned inline. Existing OriginalFrameStore
retains exact raw strings/byte hashes plus typed frame/join under original
private StateRoot, with original planned/opened/saved intents in durable WAL.
Cold WAL adoption, changed source/claim, lost write acknowledgement or unresolved
pending frame refuse. New captures use NEW nonces, never resend. A saved/unknown
frame is not upgraded to fresh by retry; historical recovery remains separate.
Only after actual saved readback+WAL membership does acquire return a compact
reference encoded as canonical JSON TEXT (64bit inode/device lossless through
JS). Result12000/pipe16384 limits unchanged. File/store1MiB limits unchanged.

Existing read operation uses whole OriginalFrameStore canonical/hash/inode/
private-file checks before/after actual original FD seek/read, max4096 bytes.
Same original live owner/WAL/ref membership is mandatory; read never creates a
missing owner, sends HTTP or samples another native clock. All FD contexts close
normally. Each chunk is canonical JSON text with original ref+offset+base64.
Host runtime reassembles real bytes, verifies complete byte count/SHA/canonical
frame envelope, reuses reference codec and original join/World/geometry codecs,
and independently matches all4 raw file hashes/nonces/query indices to stored
originals. It never opens a remote inode as a local file or substitutes metadata
for bytes. Separate5s historical-transfer cap; original capture clocks unchanged.

Eight meaningful UNRUN source-DI cases: actual loopback HTTP->original loop model
producer->actual AFC-model native FD->WAL/frame->4096-byte chunks->actual runtime
consumer; original frame exceeds12000 but DTO/chunks retain bounds; wrong nonce;
RSD swap; actual1.55s first HTTP expiry; lost saved frame return held without
replay; atomic same-byte inode replacement; real-source chunk truncated by
transport; geometry preceding newly acquired BEFORE clock. SDK/RSD/native/HTTP
producer and upper source-provider boundaries explicitly models, no result/body/
codec/file facts stubbed. Existing native-file fixture9bef is copied literally;
new class selected by exact8 IDs, never default inherited-test discovery.
Expected8 genuine TouchLease TD roots; fixed initial60+5 before first run. Actual
Source AST+compiled-code hashes, real source/WAL/files/server/thread/socket/task
cleanup, preimport root map/FD baselines and both original censuses required.

Still CLOSED: child installed candidate/source SDK/native execution admission,
current motion, native touch/resource retirement/canonical production_child.
Real InstalledBundleIdentity source exists: Q_OS_IOS/feature getter uses its OWN
UUID/birth, actual CF main-bundle bytes, pending asynchronous hash and immutable
file guards. It is NOT the native-clock instance and must not be inferred from
it. This packet does not add ios-bundle-observe to old3-action literal profiles
or pretend host IPA checks are a child callback. Next exact boundary is optional
source-owned bundle query/file profile + independent selected-IPA/installed owner
join on those actual raw originals. Original WDA window-rect is also absent;
never fabricate x/y from geometry to construct a motion-ready frame. Existing
resource Motion2 make_lease/production_child gates remain explicitly closed.
Post-release old TouchLease guards also stay literal; no claim that these active
query guards prove native release/end. Original file service cleanup still uses
retained original bound close regardless of current foreground/source loss.
''')
print(json.dumps(dict(sourceFiles=len(m['files']),diffSHA256=h(P/'proposal.diff'),modelSHA256=h(model),status=m['status']),indent=2))
