"""Prepare four Root-only postrelease admission stages, metadata/AST only."""
import ast,difflib,hashlib,json,os,stat
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/lifecycle-resource4-released-observer-four-selected-stages-root-preparation-20261102'
OLD=REPO/'.ios-host-tmp/lifecycle-resource4-join-bookend-timeline-root-preparation-20261102/01-source-first1'
FIX=REPO/'.ios-host-tmp/lifecycle-resource4-released-observer-lock-source-fix-20261102'
MODELS=REPO/'.ios-host-tmp/lifecycle-original-owner-resource4-observation-models-20261029'
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.parent.mkdir(mode=0o700,parents=True,exist_ok=True);path.open('x').write(value)
def save(path,value):write(path,json.dumps(value,indent=2,sort_keys=True)+'\n')
def pin(path):
 a=path.lstat();value=dict(stat=[getattr(a,k) for k in FIELDS]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode),path
 if stat.S_ISREG(a.st_mode):value['sha256']=sha(path)
 assert value['stat']==[getattr(path.lstat(),k) for k in FIELDS];return value
for packet in (OLD,FIX,MODELS):
 for name,digest in json.loads((packet/'freeze.json').read_text())['files'].items():assert sha(packet/name)==digest,(packet,name)
base_plan=json.loads((OLD/'run-plan.json').read_text());base_stage=json.loads((OLD/'source-manifest.json').read_text());base_super=json.loads((OLD/'supervisor-plan.json').read_text())
# Every required dependency, including23ignored node_modules patches, is an
# explicit physical path before source-map publication. Preserve Root's fix.
parent=(OLD/'root-supervise.py').read_text();assert "['requiredPublicDependencies']" in parent
plan_original=json.loads((MODELS/'plan.json').read_text());original_cases=plan_original['cases']['test_resource4_observation_models'];normal=plan_original['cases']['test_resource4_normal_frontdoor_models']
new_case=json.loads((FIX/'plan.json').read_text())['newCase']
stages=[('first1',[original_cases[0]],30,2),('foreignPostrelease1',[new_case],30,2),('remaining6',original_cases[1:],90,12),('normal1',normal,60,3)]
assert sum(len(cases) for _name,cases,_seconds,_roots in stages)==9
# Old maps already include both failures15/16. Add actual terminal18 timeline
# corpus plus its complete source pins, map, error/event and cleanup receipts.
prior=json.loads((OLD/'prior-retained-original-pins.json').read_text());retained=OLD/'retained-first';expected=json.loads((OLD/'root-run-first/originals-first.json').read_text())
actual={str(p.relative_to(retained)):pin(p) for p in (retained,*sorted(retained.rglob('*')))};assert actual==expected
for relative,row in actual.items():prior[str(retained/relative)]=row
for path in (OLD/'root-run-first').glob('*'):
 if path.is_file():prior[str(path)]=pin(path)
for pattern in ('actual-source-raise*','actual-original-join-bookend-timeline.json','case-cleanup-*/*.json','terminal-census-*.json','source-code-bindings-first/*.json','created-original-roots.json','baseline-fds-first.json'):
 for path in OLD.glob(pattern):
  if path.is_file():prior[str(path)]=pin(path)
for name in ('source-manifest.json','run-plan.json','freeze.json','supervisor-plan.json'):
 path=OLD/name;prior[str(path)]=pin(path)
receiver='tests/device/ios/pymobiledevice3_wda_xctest.py';fixed=FIX/'candidate'/receiver
assert sha(fixed)=='c5feb80767f19fcd1839c4e887d1d16a471eb2308e066180304de91dbc074075'
assert sha(REPO/receiver) in ('fafaab316cb29229f39b12ef649705936ec34bc813081661117334071d9a249a',sha(fixed))
model=FIX/'models/test_resource4_observation_models.py'
assert 'original_join_timeline' not in model.read_text()
summaries=[]
for name,cases,seconds,roots in stages:
 stage=HERE/name;stage.mkdir(mode=0o700)
 # Frozen launcher/helper/model bytes copied only. Do not copy prior runtime
 # outputs or retain an unselected diagnostic observer in regular test stages.
 for relative,digest in json.loads((OLD/'freeze.json').read_text())['files'].items():
  if relative in ('original_join_timeline.py','README.txt'):continue
  if relative in ('source-manifest.json','run-plan.json','supervisor-plan.json','prior-retained-original-pins.json'):continue
  source=OLD/relative;write(stage/relative,source.read_text())
 (stage/'test_resource4_observation_models.py').write_bytes(model.read_bytes())
 private={p.name:sha(p) for p in sorted(stage.glob('*.py'))}
 plan=dict(base_plan,status='PRIVATE_UNRUN_RELEASED_OBSERVER_LOCK_'+name,privateFiles=private,cases=cases,caseCount=len(cases),totalCaseCount=len(cases),initialOuterSeconds=seconds,expectedRetainedRoots=roots)
 plan['qualification']='Only actual source/FD/task/clock/metadata/owner/file semantics under explicit SDK/native/HID producer models; no native/auth/SDK/device/whole qualification.'
 plan['retentionHistory']=list(base_plan['retentionHistory'])+[dict(stage=str(OLD.relative_to(REPO)),actualExitCode=1,retainedFiles=18,sourceFreeze=sha(OLD/'freeze.json'),note='Actual both Downcuts +held capture/read passed; afterrelease lock admission failed. Full cleanup/censuses observed. This remains a failure, not a qualified feature.')]
 save(stage/'run-plan.json',plan)
 manifest=dict(base_stage,name=name,stage='resource4-released-lock-'+name,status=plan['status'],caseCount=len(cases),pythonCaseCount=len(cases),initialTimeoutSeconds=seconds)
 paths=[]
 for row in base_stage['sourcePaths']:
  row=dict(row);public=REPO/row['path'];row['observedPublicSHA256']=sha(public)
  if row['path']==receiver:row.update(candidate=str(fixed),candidateSHA256=sha(fixed),baseSHA256=sha(FIX/'base'/receiver))
  row['changesCurrentPublic']=row['candidateSHA256']!=row['observedPublicSHA256'];paths.append(row)
 manifest['sourcePaths']=paths;manifest['sourcePathCount']=len(paths)
 manifest['actualPublicBasis']='Read-only current Source3 plus Root-reviewed receiver lock fix; actual broad current map generated by supervisor AFTER exact Source1 publication.'
 manifest['orderedParentFreezes']=dict(base_stage['orderedParentFreezes']);manifest['orderedParentFreezes'][str(FIX.relative_to(REPO/'.ios-host-tmp'))]=sha(FIX/'freeze.json')
 save(stage/'source-manifest.json',manifest)
 save(stage/'prior-retained-original-pins.json',prior)
 save(stage/'supervisor-plan.json',dict(base_super,initialSeconds=seconds))
 write(stage/'README.txt','PRIVATE UNRUN '+name+'; actual Source receiver must be c5feb807 before this stage. Root source current map captures all requiredPublicDependencies explicitly, including rg-ignored source patches. SDK/path/network/zero-subprocess audit and original per-case standard runner AFTER asyncRunner.close +two real FD/task/thread/child/file censuses remain byte-identical to the corrected prior controller. No timeline observer selected. No cap,250ms join or1.5s acquisition changes. Run only after Root source/model/launcher review; PYTHONDONTWRITEBYTECODE=1 python3 -B <stage>/root-supervise.py from repo root.\n')
 for path in stage.glob('*.py'):ast.parse(path.read_bytes(),filename=str(path))
 for item,digest in private.items():assert sha(stage/item)==digest,item
 save(stage/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file() and p.name!='freeze.json'}))
 summaries.append(dict(name=name,cases=cases,initialSeconds=seconds,killAfterSeconds=5,expectedRealRoots=roots,freeze=sha(stage/'freeze.json')))
# Small reviewer-facing diffs: launchers unchanged, active model is the exact
# Root-reviewed fix packet; per-stage plans and Source hashes are explicit.
deltas=[]
for name in ('root-supervise.py','root-child.py','run-selected.py','root_stage_guard.py','raise_observer.py','normal_child_fixture.py'):
 deltas.extend(difflib.unified_diff((OLD/name).read_text().splitlines(True),(HERE/'first1'/name).read_text().splitlines(True),fromfile='actual-timeline/'+name,tofile='postrelease-lock/'+name))
write(HERE/'launcher-only.diff',''.join(deltas))
write(HERE/'active-model-only.diff',''.join(difflib.unified_diff((OLD/'test_resource4_observation_models.py').read_text().splitlines(True),model.read_text().splitlines(True),fromfile='actual-timeline/test_resource4_observation_models.py',tofile='reviewed-postrelease-lock/test_resource4_observation_models.py')))
save(HERE/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceFixFreeze=sha(FIX/'freeze.json'),baseActualTimelineFreeze=sha(OLD/'freeze.json'),sourceCandidateSHA256=sha(fixed),historicalPins=len(prior),priorFailed18FilesPreserved=True,previousFailed15And16PreservedByBasePriorPins=True,sourceModelsPublished=False,testsRun=False,SDKImported=False,sourceImported=False,stages=summaries,totalUniqueCases=9,totalExpectedRealRoots=19,requiredOrder='Root reviews/publishes exact Source1. first1 must actually pass; then foreignPostrelease1 andremaining6; normal1 only after source model scope passes. No unchanged retries/cap raises.'))
write(HERE/'ROOT-PLAN.txt','Root-only UNRUN four stages. Source1 c5feb807 is required, Source3 owner/runtime remain2b285170/55f243ae. No shared registry change. Launcher-only.diff is intentionally EMPTY: original corrected17k controller/audit/cleanup semantics copied exactly. Active-model-only.diff removes original numeric timeline instrumentation and uses the reviewed fbe7 assertions/new counter; all original7/normal1 model packets remain frozen. Source3 prior fafa and failures15/16/18 are retained exactly, including actual timeline/map/source-before-after/RAISE/cleanup receipts. Source map is generated per stage from ACTUAL post-publication sources, never copied from prior maps. First1/newforeign1 first30+kill5/2TD each; remaining6 original90+kill5/12TD; normal1 first60+kill5/3TD. No source/clock/250ms/1.5s/default/SDK admission changes beyond reviewed lock fix. Do not run a next stage after a new unresolved failure. Host checks remain device/native/auth/whole unqualified.\n')
save(HERE/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'},stageFreezes={r['name']:r['freeze'] for r in summaries}))
print(json.dumps(dict(packet=str(HERE),freeze=sha(HERE/'freeze.json'),stages=summaries,historicalPins=len(prior))))
