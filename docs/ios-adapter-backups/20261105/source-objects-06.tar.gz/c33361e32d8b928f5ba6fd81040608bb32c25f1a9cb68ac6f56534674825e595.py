"""Bounded host-only timing of exact fresh-source functions; never evidence time.

No callback reads a file or keeps a frame/runtime owner. These measurements
include observer overhead and grant no success, freshness or speed verdict.
"""
from pathlib import Path
import marshal,hashlib,sys,time,threading,types

TARGETS=(
 ('ios.adapters.world_web_retirement','WorldWebRetirement',('cleanup','capture','_measure','_decode','bound','save','pending_gpu','gpu_rows')),
 ('ios.adapters.world_web_sources','WorldWebSources',('bound','_decode_frames','guard_originals','guard_saved_state','capture','_capture','read_floor','validate_frame')),
 ('ios.adapters.world_web_sample','WorldWebSample',('retire_runtime','measure','_decode')),
 ('adapters.owned_vulkan_world_frame','VulkanWorldFrameOwner',('release','_load','_write','_reader','_query','archive','verify_owned_artifact')),
 ('adapters.native_vulkan_world_frame','NativeVulkanWorldFrame',('perform',)),
 ('adapters.native_clock_join','NativeClockAcquisition',('begin','finish')),
 ('adapters.native_clock_join',None,('validate_join',)),
 ('adapters.native_feature_observation','NativeFeatureObservation',('read',)),
 ('adapters.native_feature_observation',None,('validate',)),
 ('adapters.normal_feature_state','PrivateFeatureState',('read','write')),
 ('adapters.original_frame_store','OriginalFrameStore',('read','write','append','restore')),
 ('ios.adapters.world_web_source','IOSWorldWebSource',('read',)),
 ('ios.adapters.world_web_source',None,('validate',)),
)
TOOL_NAME='world-b7-bounded-original-host-function-timing'
_EXCLUDED_FLAGS=0x20|0x80|0x200 # generator/coroutine/async generator: no resume/yield fiction.

class HostFunctionTimings:
    def __init__(self,targets=TARGETS):
        self.targets=tuple(targets);self.api=sys.monitoring
        self.port_names=('get_tool','get_events','get_local_events','set_events','use_tool_id','free_tool_id','register_callback','set_local_events')
        self.ports=tuple((name,getattr(self.api,name))for name in self.port_names)
        self.wall=time.perf_counter_ns;self.cpu=time.thread_time_ns;self.ident=threading.get_ident;self.frame=sys._getframe
        assert type(self.wall)is types.BuiltinFunctionType and self.wall.__self__ is time and self.wall.__name__=='perf_counter_ns'
        assert type(self.cpu)is types.BuiltinFunctionType and self.cpu.__self__ is time and self.cpu.__name__=='thread_time_ns'
        self.thread=self.ident();self.modules=sys.modules;self.time_module=time
        self.tool=None;self.installed=False;self.closed=False;self.disabled=False
        self.bindings={};self.bound_modules={};self.excluded=[];self.faults=[];self.fault_count=0
        self.stack=[];self.rows={};self.other_thread_events=0;self.maximum_depth=0;self.abandoned_calls=0
        self.old_callbacks={};self.local_before={};self.callback_objects={};self.restoration=[]
        self.slot_before=tuple((self.api.get_tool(n),self.api.get_events(n))for n in range(6))
        self.control=tuple((name,value,value.__code__,value.__globals__)for name,value in vars(type(self)).items()if type(value)is types.FunctionType)
    def _control_bound(self):
        assert sys.monitoring is self.api and sys.modules is self.modules
        assert all(getattr(self.api,name)is port for name,port in self.ports)
        assert time is self.time_module and time.perf_counter_ns is self.wall and time.thread_time_ns is self.cpu
        assert threading.get_ident is self.ident and sys._getframe is self.frame
        for name,function,code,namespace in self.control:
            assert vars(type(self))[name]is function and function.__code__ is code and function.__globals__ is namespace
    def fault(self,error):
        # No traceback/str(error)/frame capture or output inside callbacks.
        self.fault_count+=1
        if len(self.faults)<16:self.faults.append(type(error))
        self.disabled=True;self.abandoned_calls+=len(self.stack);self.stack.clear()
    def bind_module(self,module,row,execution,pin):
        names=[entry for entry in self.targets if entry[0]==vars(module).get('__name__')]
        if not names:return
        self._control_bound();name=vars(module)['__name__'];namespace=vars(module)
        assert self.modules.get(name)is module and type(module)is types.ModuleType and name not in self.bound_modules
        path=Path(row['path']);assert Path(namespace['__file__'])==path and pin(path)['sha256']==row['sha256']
        assert type(execution)is tuple and len(execution)==4 and execution[0]is module and execution[1]==path and execution[2]==row['sha256']
        held=[]
        for unused,cls_name,attributes in names:
            cls=None if cls_name is None else namespace[cls_name]
            assert cls is None or type(cls)is type
            for attribute in attributes:
                member=namespace[attribute]if cls is None else vars(cls)[attribute]
                function=member.__func__ if type(member)in(classmethod,staticmethod)else member
                assert type(function)is types.FunctionType and function.__globals__ is namespace
                code=function.__code__;assert Path(code.co_filename)==path
                label=name+'.'+(''if cls_name is None else cls_name+'.')+attribute
                if code.co_flags&_EXCLUDED_FLAGS:
                    self.excluded.append(dict(label=label,reason='generator-or-coroutine-excluded',flags=code.co_flags));continue
                assert code not in self.bindings,'Same code under multiple declared labels is not disambiguated'
                defaults=function.__defaults__;keywords=function.__kwdefaults__;closure=function.__closure__
                binding=(module,namespace,name,cls,cls_name,attribute,member,function,code,defaults,tuple(defaults or()),keywords,tuple((keywords or{}).items()),closure,tuple(cell.cell_contents for cell in closure or()),label)
                metadata=dict(label=label,path=str(path),sourceSha256=row['sha256'],codeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest(),sourceExecutionKind='actual-current-fresh-pinned-python-source',generatorsExcluded=True)
                self.bindings[code]=(binding,metadata);held.append(label)
                if self.installed:self._enable(code)
        self.bound_modules[name]=held
    def _enable(self,code):
        assert self.tool is not None and code not in self.local_before
        previous=self.api.get_local_events(self.tool,code);assert previous==0
        self.local_before[code]=previous
        self.api.set_local_events(self.tool,code,self.api.events.PY_START|self.api.events.PY_RETURN|self.api.events.PY_UNWIND)
    def install(self):
        self._control_bound();assert not self.installed and not self.closed
        tool=next((n for n in(3,2,1,0,4,5)if self.api.get_tool(n)is None and self.api.get_events(n)==0),None)
        assert tool is not None,'No independent diagnostic tool available'
        self.tool=tool;self.api.use_tool_id(tool,TOOL_NAME)
        callbacks=((self.api.events.PY_START,self.started),(self.api.events.PY_RETURN,self.returned),(self.api.events.PY_UNWIND,self.unwound))
        for event,callback in callbacks:
            self.callback_objects[event]=callback
            self.old_callbacks[event]=self.api.register_callback(tool,event,callback)
        self.installed=True
        for code in self.bindings:self._enable(code)
    def tool_bound(self):
        self._control_bound()
        if self.tool is None:return True
        assert self.api.get_tool(self.tool)==TOOL_NAME and self.api.get_events(self.tool)==0
        mask=self.api.events.PY_START|self.api.events.PY_RETURN|self.api.events.PY_UNWIND
        assert all(self.api.get_local_events(self.tool,code)==mask for code in self.local_before)
        return True
    def _definition_bound(self,code):
        self._control_bound();binding,metadata=self.bindings[code]
        module,namespace,name,cls,cls_name,attribute,member,function,original_code,defaults,values,keywords,items,closure,cells,label=binding
        assert original_code is code
        assert self.modules.get(name)is module and vars(module)is namespace
        assert(namespace.get(attribute)is member)if cls is None else(namespace.get(cls_name)is cls and vars(cls).get(attribute)is member)
        assert function.__code__ is code and function.__globals__ is namespace
        assert function.__defaults__ is defaults and function.__kwdefaults__ is keywords and function.__closure__ is closure
        assert len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values))
        assert tuple(keywords or())==tuple(key for key,value in items)and all(keywords[key]is value for key,value in items)
        assert len(closure or())==len(cells)and all(cell.cell_contents is value for cell,value in zip(closure or(),cells))
        return label
    def _actual_binding(self,code,frame):
        label=self._definition_bound(code)
        binding=self.bindings[code][0]
        assert type(frame)is types.FrameType and frame.f_code is code and frame.f_globals is binding[1]
        return label
    def _event_start(self,code,frame):
        label=self._actual_binding(code,frame);wall=self.wall();cpu=self.cpu()
        retirement=label=='ios.adapters.world_web_retirement.WorldWebRetirement.cleanup'or bool(self.stack and self.stack[-1][7])
        # Numeric frame IDs are used only while the genuine interpreter keeps
        # that call alive. No frame, self, argument or result is retained.
        self.stack.append([code,id(frame),wall,cpu,0,0,label,retirement]);self.maximum_depth=max(self.maximum_depth,len(self.stack))
    def _event_end(self,code,frame,kind):
        label=self._actual_binding(code,frame);wall=self.wall();cpu=self.cpu()
        assert self.stack and self.stack[-1][0]is code and self.stack[-1][1]==id(frame)
        row=self.stack.pop();inclusive_wall=wall-row[2];inclusive_cpu=cpu-row[3]
        exclusive_wall=inclusive_wall-row[4];exclusive_cpu=inclusive_cpu-row[5]
        assert min(inclusive_wall,inclusive_cpu,exclusive_wall,exclusive_cpu)>=0
        phase='retirement-cleanup-stack'if row[7]else'other-selected-host-work'
        key=(label,phase);totals=self.rows.setdefault(key,dict(label=label,phase=phase,calls=0,returns=0,unwinds=0,inclusiveWallNs=0,inclusiveThreadCpuNs=0,exclusiveAmongSelectedWallNs=0,exclusiveAmongSelectedThreadCpuNs=0,maximumWallNs=0))
        totals['calls']+=1;totals['returns'if kind=='return'else'unwinds']+=1
        totals['inclusiveWallNs']+=inclusive_wall;totals['inclusiveThreadCpuNs']+=inclusive_cpu
        totals['exclusiveAmongSelectedWallNs']+=exclusive_wall;totals['exclusiveAmongSelectedThreadCpuNs']+=exclusive_cpu
        totals['maximumWallNs']=max(totals['maximumWallNs'],inclusive_wall)
        if self.stack:self.stack[-1][4]+=inclusive_wall;self.stack[-1][5]+=inclusive_cpu
    def started(self,code,offset):
        if self.ident()!=self.thread:self.other_thread_events+=1;return
        if self.disabled:return
        try:self._event_start(code,self.frame(1))
        except Exception as error:self.fault(error)
    def returned(self,code,offset,value):
        if self.ident()!=self.thread:self.other_thread_events+=1;return
        if self.disabled:return
        try:self._event_end(code,self.frame(1),'return')
        except Exception as error:self.fault(error)
    def unwound(self,code,offset,error):
        if self.ident()!=self.thread:self.other_thread_events+=1;return
        if self.disabled:return
        try:self._event_end(code,self.frame(1),'unwind')
        except Exception as diagnostic_error:self.fault(diagnostic_error)
    def snapshot(self):
        try:
            self._control_bound()
            for code in self.bindings:self._definition_bound(code)
        except Exception as error:self.fault(error)
        return dict(profile='world-b7-main-thread-host-function-cost-v1',diagnosticOnly=True,grantsNoAuthority=True,
            clocks='original-host-perf_counter_ns-and-thread_time_ns',nativeTimeReadOrRetimed=False,includesObserverOverhead=True,
            exclusiveMeaning='subtract directly nested SELECTED calls only; unselected work remains included',inclusiveSumsAreNotAdditive=True,
            expectedFunctions=sum(len(row[2])for row in self.targets),boundFunctions=len(self.bindings),boundModules=sorted(self.bound_modules),
            actualSourceFunctions=[metadata for binding,metadata in self.bindings.values()],excludedFunctions=self.excluded,
            excludedOtherThreadEvents=self.other_thread_events,threadScope='initial main thread only',
            maximumSelectedDepth=self.maximum_depth,unfinishedSelectedCalls=len(self.stack),abandonedCallsOnDiagnosticFault=self.abandoned_calls,
            faultCount=self.fault_count,firstFaultTypes=[kind.__module__+'.'+kind.__qualname__ for kind in self.faults],aggregate=[dict(self.rows[key])for key in sorted(self.rows)],
            timingComplete=not self.disabled and not self.stack and len(self.bindings)+len(self.excluded)==sum(len(row[2])for row in self.targets),
            consumerRuntimeQualification=False)
    def restore(self):
        # Independent actual attempts; failure never prevents another release.
        failures=[]
        def attempt(name,fn):
            try:return fn()
            except Exception as error:failures.append(dict(step=name,type=type(error).__module__+'.'+type(error).__qualname__));return None
        if self.tool is not None:
            attempt('original-zero-global-mask',lambda:self.api.set_events(self.tool,0))
            for code,previous in self.local_before.items():attempt('local-mask',lambda code=code,previous=previous:self.api.set_local_events(self.tool,code,previous))
            for event,previous in self.old_callbacks.items():
                current=attempt('callback',lambda event=event,previous=previous:self.api.register_callback(self.tool,event,previous))
                if current is not self.callback_objects[event]:failures.append(dict(step='callback-receiver-changed',type='identity-mismatch'))
            attempt('free-tool',lambda:self.api.free_tool_id(self.tool))
            if self.api.get_tool(self.tool)is not None:failures.append(dict(step='tool-still-owned',type='identity-mismatch'))
        actual_tool=self.tool
        self.closed=True;self.installed=False;self.restoration=failures
        if not failures:self.tool=None
        return dict(actualSeparateToolRestored=not failures,restorationFailures=failures,actualToolId=actual_tool,
            unfinishedCallsAtRestore=len(self.stack),noRuntimeOwnersOrFramesRetained=True)
