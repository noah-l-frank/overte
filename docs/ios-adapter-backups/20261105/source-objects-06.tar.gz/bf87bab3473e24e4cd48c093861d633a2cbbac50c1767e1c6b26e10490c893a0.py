"""Normal UI cleanup/abort with durable input intent and original baseline.

Only admitted visible Mute/Echo/page state is changed. All other twice-read
settings and actual OS permission must remain equal to their original guards.
Lost returns resolve from a new cut; the original input is never replayed.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from types import SimpleNamespace
from adapters.native_feature_observation import exact,need
from adapters.normal_ui import NativeUI
from adapters.token_audio_ui import TokenAudioUI
from adapters.script_feature.history import same
from ios.adapters.audio_page_inputs import AudioPageInputs
from ios.adapters.normal_audio import IOSAudioIO
from ios.adapters import audio_settings_source as settings_source
from ios.adapters.audio_session_source import definite_permission
from ios.adapters.tablet_launcher_controls import selection

class AudioWholeRestore:
    def __init__(self,flow,current):
        self.flow,self.current=flow,current;self.journal=flow.state['replacementRestoration' if flow.state['replacement'] is not None else 'restoration'];source=current.source;normal=source['native']
        self.io=IOSAudioIO(SimpleNamespace(capture=normal.capture,native=normal,ui=NativeUI(source['client'],source['session'],source['check'])))
        self.ui=TokenAudioUI(self.io,self.input_intent,monotonic=flow.monotonic,sleep=flow.sleep)
        self.pages=AudioPageInputs(self.io,self.io.original.ui,self.page_intent,returned=self.page_returned,monotonic=flow.monotonic,sleep=flow.sleep)

    def baseline(self):
        f=self.flow;need(f.state['baseline'] is None)
        ref,value=self.current.capture();packet=value['originals'];settings_source.admissible(packet['settings'])
        original_settings=settings_source.settings(packet['settings']);script=original_settings['script'];persisted=script['persisted']
        # The ordinary ten-second save must not rewrite a different pre-run
        # gain/PTT/mute baseline while the test is executing.
        for key in ('mutedDesktop','mutedHmd','pttDesktop','pttHmd','localInjectorGain','systemInjectorGain','noiseReduction','noiseReductionAutomatic','noiseReductionThreshold','warnWhenMuted','acousticEchoCancellation'):
            need(persisted[key]==script[key])
        for key in ('avatarGain','serverInjectorGain'):need(persisted[key]==original_settings['mixer'][key])
        need(not original_settings['client']['serverEcho'])
        state=self.current.current_state(value)
        need(state['phase']=='idle' and state['history']==[] and state['recordedFrames']==state['playedFrames']==state['bufferedFrames']==0 and not state['muted'] and not state['recording'] and not state['preview'] and state['error']=='none')
        need(definite_permission(packet['session'])=='granted' and packet['session']['source']['foreground']
            and not packet['session']['source']['interrupted'] and not packet['native']['audio']['recordedVoice']['active'])
        route=AudioPageInputs.route(packet['ui']);need(route=='closed')
        f.state['baseline']=dict(reference=ref,route=route,launcher=selection(packet['ui']) if route=='launcher' else None)
        f.save();return ref

    def guarded(self,value):
        original=self.flow.current(historical=True,stage='initial').original(self.flow.state['baseline']['reference'])['originals'];actual=value['originals']
        def fixed(packet):
            value=settings_source.settings(packet);key='mutedHmd' if value['nativeHmd'] else 'mutedDesktop'
            del value['script'][key]
            del value['script']['persisted'][key]
            for key in ('muted','localEcho','recording','voiceActive'):del value['client'][key]
            return value
        need(same(fixed(actual['settings']),fixed(original['settings'])))
        need(definite_permission(actual['session'])==definite_permission(original['session'])=='granted'
            and actual['session']['source']['foreground'] and not actual['session']['source']['interrupted'])
        return original,actual

    def input_intent(self,verb,value,identifier):
        f=self.flow;pending=self.journal['pending'];need(pending is not None)
        ref,cut=self.current.capture();self.guarded(cut)
        rows=[r for r in value['controls'] if r['id']==identifier];actual=[r for r in cut['originals']['ui']['controls'] if r['id']==identifier]
        need(len(rows)==1 and same(rows,actual))
        pending['inputs'].append(dict(verb=verb,identifier=identifier,control=deepcopy(rows[0]),before=ref,returned=False));f.save()
    def page_intent(self,label,control,value,element):
        f=self.flow;pending=self.journal['pending'];need(pending is not None)
        need(not any(i.get('label')==label for i in pending['inputs']))
        ref,cut=self.current.capture();self.guarded(cut)
        if pending.get('launcher') is None and AudioPageInputs.route(value)=='launcher':pending['launcher']=deepcopy(selection(value))
        rows=[r for r in value['controls'] if r['id']==control];actual=[r for r in cut['originals']['ui']['controls'] if r['id']==control]
        need(len(rows)==1 and same(rows,actual))
        pending['inputs'].append(dict(verb='page',identifier=control,label=label,element=element,control=deepcopy(rows[0]),before=ref,returned=False));f.save();return True
    def page_returned(self,label):
        row=next(i for i in self.journal['pending']['inputs'] if i.get('label')==label)
        row['returned']=True;self.flow.save()

    def effect(self,pending,value):
        _old,new=self.guarded(value);state=self.current.current_state(value);verb=pending['verb']
        if verb=='cancel':return not state['recording'] and not state['preview'] and state['bufferedFrames']==0
        if verb in ('muted','localEcho'):return dict(muted=settings_source.settings(new['settings'])['client']['muted'],localEcho=settings_source.settings(new['settings'])['client']['localEcho'])[verb]==pending['wanted']
        route=AudioPageInputs.route(new['ui']);baseline=self.flow.state['baseline']
        if verb=='open':return route=='audio'
        if verb=='page-close':return route=='closed'
        if verb=='page-launcher':return route=='launcher' and selection(new['ui'])['launcherCurrentIndex']==baseline['launcher']['launcherCurrentIndex']
        need(False)

    def perform(self,verb,wanted=None):
        f=self.flow;restore=self.journal;pending=restore['pending']
        if pending is not None:
            # Observe first, including an uncertain POST. No second input.
            ref,value=self.current.capture();need(self.effect(pending,value))
            pending['after']=ref;restore['operations'].append(pending);restore['pending']=None;f.save();return
        ref,value=self.current.capture();self.guarded(value)
        pending=dict(verb=verb,wanted=wanted,before=ref,inputs=[],after=None,launcher=None);restore['pending']=pending;f.save()
        if verb=='cancel':
            voice=value['originals']['native']['audio']['recordedVoice'];need(voice['active']);self.ui.cancel(voice['cycle'])
        elif verb in ('muted','localEcho'):
            identifier='audio.mute' if verb=='muted' else 'audio.live-echo';action='mute' if verb=='muted' else 'live-echo'
            control=self.ui.visible(identifier);self.ui.activate(identifier,action,token=control['token'])
        elif verb=='open':
            result=self.pages.open()
            if pending.get('launcher') is None:pending['launcher']=deepcopy(result['launcher'])
        elif verb=='page-close':
            # Actual Open normal owner retains its original launcher location.
            opens=[r for r in self.journal['operations'] if r['verb']=='open' and r.get('launcher') is not None]
            if opens:launcher=opens[0]['launcher']
            else:
                parent=f.primary_parent();normal=[r for r in parent.state['operations'] if r['verb']=='open'];need(len(normal)==1);launcher=normal[0]['launcher']
            need(launcher is not None);self.pages.close(launcher)
        elif verb=='page-launcher':
            route=AudioPageInputs.route(value['originals']['ui'])
            if route=='closed':self.pages.click('restore-open-launcher','hud.tablet')
            elif route=='audio':self.pages.click('restore-home-launcher','tablet.home')
            value=self.pages.wait(lambda p:AudioPageInputs.route(p)=='launcher');target=f.state['baseline']['launcher']['launcherCurrentIndex']
            if selection(value)['launcherCurrentIndex']!=target:
                self.pages.click('restore-launcher-page','tablet.page.'+str(target+1))
                self.pages.wait(lambda p:AudioPageInputs.route(p)=='launcher' and selection(p)['launcherCurrentIndex']==target)
        else:need(False)
        ref,value=self.current.capture();need(self.effect(pending,value));pending['after']=ref
        restore['operations'].append(pending);restore['pending']=None;f.save()

    def finish(self):
        f=self.flow;need(f.state['baseline'] is not None)
        if self.journal['pending'] is not None:self.perform('resolve')
        _ref,value=self.current.capture();old,new=self.guarded(value);state=self.current.current_state(value)
        if state['recording'] or state['preview']:self.perform('cancel')
        wanted=settings_source.selected(old['settings'])
        for key in ('localEcho','muted'):
            _ref,value=self.current.capture();self.guarded(value)
            if dict(muted=settings_source.settings(value['originals']['settings'])['client']['muted'],localEcho=settings_source.settings(value['originals']['settings'])['client']['localEcho'])[key]==wanted[key]:continue
            if AudioPageInputs.route(value['originals']['ui'])!='audio':self.perform('open')
            self.perform(key,wanted[key])
        _ref,value=self.current.capture();route=AudioPageInputs.route(value['originals']['ui']);baseline=f.state['baseline']
        if baseline['route']=='closed' and route!='closed':self.perform('page-close')
        elif baseline['route']=='launcher' and (route!='launcher' or selection(value['originals']['ui'])['launcherCurrentIndex']!=baseline['launcher']['launcherCurrentIndex']):self.perform('page-launcher')
        # Audio::saveData persists the owned active mute key on the actual
        # existing ten-second settings timer. Observe that real persistence;
        # no hidden Save/setter or fabricated equality is supplied here. The
        # shared 25-second operation budget bounds the entire cleanup.
        for attempt in range(45):
            _ref,value=self.current.capture();old,new=self.guarded(value)
            if same(settings_source.settings(new['settings']),settings_source.settings(old['settings'])):break
            old_settings,new_settings=settings_source.settings(old['settings']),settings_source.settings(new['settings'])
            key='mutedHmd' if old_settings['nativeHmd'] else 'mutedDesktop'
            wanted=old_settings['script']['persisted'][key]
            need(new_settings['script'][key]==wanted and new_settings['client']['muted']==wanted)
            changed=deepcopy(new_settings);changed['script']['persisted'][key]=wanted
            need(same(changed,old_settings) and attempt<44);f.sleep(.25)
        refs=[]
        for i in range(2):
            if i:f.sleep(.35)
            ref,value=self.current.capture();old,new=self.guarded(value);actual=self.current.current_state(value)
            need(same(settings_source.settings(new['settings']),settings_source.settings(old['settings'])) and not actual['recording'] and not actual['preview'] and actual['bufferedFrames']==0
                and AudioPageInputs.route(new['ui'])==baseline['route'])
            refs.append(ref)
        self.journal['verified']=refs;f.save();return refs
