"""Typed actual counter-only descriptor faults and one genuine helper thread."""
from pathlib import Path
import os,sys,threading,types


class Own9Controls:
    def __init__(self):
        self.main=threading.get_ident();self.case=None;self.runtime=None;self.runtimes=[]
        self.dup=os.dup;self.dup2=os.dup2;self.fstat=os.fstat;self.current_thread=threading.Thread
        self.dup_rows=[];self.threads=[];self.failures=[];self.hooks=[];self.tool=None;self.codes=[];self.forbidden_entries=[];self.definition_seals=[]
        self.original_monitor=tuple((n,getattr(sys.monitoring,n))for n in('get_tool','use_tool_id','register_callback','set_local_events','get_local_events','get_events','set_events','free_tool_id'))
        self.slots=tuple((n,sys.monitoring.get_tool(n),sys.monitoring.get_events(n))for n in range(6))
        self.thread_functions={n:(threading.Thread.__dict__[n],threading.Thread.__dict__[n].__code__,threading.Thread.__dict__[n].__globals__)for n in('__init__','start','join')}

    def bind(self,subject):
        self.subject=subject;self.cls=subject.BackendDirFDBoundaryTests
        self.fault=self.cls.__dict__['test_reused_closed_root_fd_is_refused_without_adoption'];self.fault_code=self.fault.__code__
        self.thread_case=self.cls.__dict__['test_other_thread_cannot_use_genuine_backend_descriptor'];self.thread_code=self.thread_case.__code__
        self.link_case=self.cls.__dict__['test_real_reader_rejects_symlink_leaf_and_single_link_violation'];self.link_code=self.link_case.__code__

    def active_frame(self,frame,code):
        assert threading.get_ident()==self.main and self.case is not None and self.runtime is not None
        assert type(frame)is types.FrameType and frame.f_code is code and frame.f_globals is vars(self.subject)
        assert frame.f_locals.get('self')is self.case and type(self.case)is self.cls
        assert self.runtime.active and self.runtime.boundary.helper is self.runtime.helper

    @staticmethod
    def identity(info):return info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid

    def duplicate(self,fd):
        frame=sys._getframe(1);self.active_frame(frame,self.fault_code)
        assert frame.f_locals.get('root')==fd and type(fd)is int and fd in self.runtime.boundary.roots
        assert not self.dup_rows
        row=self.runtime.boundary.root(fd);before=self.identity(self.fstat(fd));result=self.dup(fd)
        assert self.identity(self.fstat(result))==before
        self.dup_rows.append(dict(original=fd,held=result,identity=before,phase='original',case=self.case.id()))
        return result

    def duplicate_to(self,fd,fd2,inheritable=True):
        frame=sys._getframe(1);self.active_frame(frame,self.fault_code)
        assert inheritable is True and len(self.dup_rows)==1
        row=self.dup_rows[0];values=frame.f_locals
        assert fd2==row['original']==values.get('root')and values.get('held')==row['held']
        assert self.identity(self.fstat(row['held']))==row['identity']
        if row['phase']=='original':
            assert fd==values.get('foreign')and type(fd)is int
            assert self.identity(self.fstat(fd2))==row['identity']
            journal=values['host'].transport.journal_fd;expected=self.identity(self.fstat(journal))
            assert self.identity(self.fstat(fd))==expected and expected!=row['identity']
            next_phase='replaced'
        else:
            assert row['phase']=='replaced'and fd==row['held'];expected=row['identity'];next_phase='restored'
        result=self.dup2(fd,fd2,inheritable=inheritable)
        assert result==fd2 and self.identity(self.fstat(fd2))==expected
        row['phase']=next_phase;return result

    def install(self):
        assert os.dup is self.dup and os.dup2 is self.dup2
        self.dup_port=self.duplicate;self.dup2_port=self.duplicate_to;os.dup=self.dup_port;os.dup2=self.dup2_port
        monitoring=sys.monitoring
        self.tool=next((n for n in(5,4,3,2,1,0)if monitoring.get_tool(n)is None),None)
        assert self.tool is not None
        monitoring.use_tool_id(self.tool,'assets-own9-definition-and-thread-custody')
        monitoring.register_callback(self.tool,monitoring.events.PY_START,self.enter)
        for fn,code,namespace in self.thread_functions.values():self.observe(code)

    def observe(self,code):
        if not any(held is code for held in self.codes):
            assert sys.monitoring.get_local_events(self.tool,code)==0
            self.codes.append(code);sys.monitoring.set_local_events(self.tool,code,sys.monitoring.events.PY_START)

    def definitions(self,module):
        # Genuine selected backend/model classes are allowed. Every other
        # class's Python body in the definition closure is observation-only.
        allowed={'adapters.asset_backend_files':{'AssetsBackendFiles'},'test_asset_backend_files':{'ProcessModel','BackendFilesTests'},
            'test_asset_backend_source':{'BackendSourceTests','NativeWorkModel','Holder'}}
        for name,cls in tuple(vars(module).items()):
            if type(cls)is not type or cls.__module__!=module.__name__ or name in allowed.get(module.__name__,set()):continue
            members=tuple(cls.__dict__.items());functions=[]
            for member in cls.__dict__.values():
                entries=(member.fget,member.fset,member.fdel)if type(member)is property else(member.__func__ if type(member)in(staticmethod,classmethod)else member,)
                for fn in entries:
                    seen=set()
                    while type(fn)is types.FunctionType:
                        assert id(fn)not in seen;seen.add(id(fn))
                        if fn.__globals__ is vars(module):self.observe(fn.__code__)
                        # Shared contextlib/reprlib wrapper code is not a
                        # native-owner body. Its own hidden generator is.
                        kw=fn.__kwdefaults__;closure=fn.__closure__
                        functions.append((fn,fn.__code__,fn.__globals__,getattr(fn,'__wrapped__',None),fn.__defaults__,kw,tuple((kw or{}).items()),closure,tuple(c.cell_contents for c in closure or())))
                        fn=getattr(fn,'__wrapped__',None)
            self.definition_seals.append((module,cls,members,functions))

    def definitions_unchanged(self):
        for module,cls,members,functions in self.definition_seals:
            assert sys.modules.get(module.__name__)is module and vars(module).get(cls.__name__)is cls
            assert tuple(cls.__dict__)==tuple(n for n,v in members)and all(cls.__dict__[n]is v for n,v in members)
            for fn,code,namespace,wrapped,defaults,kw,items,closure,cells in functions:
                assert fn.__code__ is code and fn.__globals__ is namespace and getattr(fn,'__wrapped__',None)is wrapped
                assert fn.__defaults__ is defaults and fn.__kwdefaults__ is kw and fn.__closure__ is closure
                assert tuple(kw or())==tuple(n for n,v in items)and all(kw[n]is v for n,v in items)
                assert len(closure or())==len(cells)and all(c.cell_contents is value for c,value in zip(closure or(),cells))
        return True

    def enter(self,code,offset):
        frame=sys._getframe(1)
        assert type(frame)is types.FrameType and frame.f_code is code
        matching=[(name,fn,namespace)for name,(fn,held,namespace)in self.thread_functions.items()if held is code]
        if not matching:
            self.forbidden_entries.append(dict(path=code.co_filename,name=code.co_qualname,offset=offset))
            raise RuntimeError('Definition-only class entry refused in backend utility')
        name,fn,namespace=matching[0]
        assert frame.f_globals is namespace and threading.Thread.__dict__[name]is fn and fn.__code__ is code
        self.active_frame(frame.f_back,self.thread_code);owner=frame.f_locals['self'];assert type(owner)is self.current_thread
        if name=='__init__':
            assert not self.threads and frame.f_locals['group']is None and frame.f_locals['name']is None
            assert frame.f_locals['args']==()and frame.f_locals['kwargs']is None and frame.f_locals['daemon']is None and frame.f_locals['context']is None
            target=frame.f_locals['target'];assert type(target)is types.FunctionType and target.__globals__ is vars(self.subject)
            constants=[c for c in self.thread_code.co_consts if type(c)is types.CodeType and c.co_name=='other']
            assert len(constants)==1 and target.__code__ is constants[0]
            self.threads.append(dict(owner=owner,target=target,start=0,join=0))
        else:
            assert len(self.threads)==1 and self.threads[0]['owner']is owner;row=self.threads[0]
            if name=='start':assert row['start']==0 and owner._target is row['target'];row['start']=1
            else:assert row['start']==1 and row['join']==0 and frame.f_locals['timeout']==5;row['join']=1

    def fault_audit(self,event,args,caller):
        # Extra actual C operations used solely to create two negative fixtures.
        # Their immediate invoke caller must be the real unchanged test body.
        if event not in('os.link','os.symlink'):return
        helper=self.runtime.helper;invoke=type(helper).__dict__['invoke']
        assert caller.f_code is invoke.__code__ and caller.f_globals is invoke.__globals__ and caller.f_locals['self']is helper
        parent=caller.f_back
        # Production publication is checked by BackendDirFDPorts. Fault setup
        # is allowed only for these exact absolute own sample paths.
        if parent.f_code is self.link_code:
            self.active_frame(parent,self.link_code);values=parent.f_locals;host=values['host']
            source=host.b.export/'asset-backend-admission.json'
            if event=='os.link':assert args==(str(source),str(host.b.export/'hardlink-admission'),-1,-1)
            else:assert args==('asset-backend-admission.json',str(host.b.export/'symlink-admission'),-1)
            assert source.is_relative_to(self.runtime.temporary)and source.resolve(strict=True)==source
            assert source.stat().st_nlink==1

    def finish_case(self):
        assert self.runtime is not None and self.runtime.active is False
        assert not self.runtime.drain_errors and self.runtime.original_standard_cleanup_return is True
        assert not self.runtime.boundary.roots and not self.runtime.boundary.files and not self.runtime.boundary.links
        for row in self.dup_rows:
            assert row['phase']=='restored'
            try:self.fstat(row['held'])
            except OSError as error:assert error.errno==9
            else:raise AssertionError('Actual duplicate directory FD remains open')
        for row in self.threads:assert not row['owner'].is_alive()and row['start']==row['join']==1
        receipt=dict(backend=self.runtime.receipt,duplicateFaults=[{k:v for k,v in r.items()if k!='owner'}for r in self.dup_rows],
            helperThreads=[dict(start=r['start'],join=r['join'],alive=r['owner'].is_alive())for r in self.threads],
            originalStandardCleanupReturned=self.runtime.original_standard_cleanup_return,scopeHooksPassive=self.runtime.active is False)
        self.case=None;self.runtime=None;self.dup_rows=[]
        return receipt

    def restore(self):
        problems=[]
        if os.dup is not getattr(self,'dup_port',self.dup)or os.dup2 is not getattr(self,'dup2_port',self.dup2):problems.append('Actual duplicate port changed')
        os.dup=self.dup;os.dup2=self.dup2
        monitoring=sys.monitoring
        if self.tool is not None:
            for code in self.codes:monitoring.set_local_events(self.tool,code,0)
            monitoring.register_callback(self.tool,monitoring.events.PY_START,None);monitoring.free_tool_id(self.tool)
        tools=(all(getattr(monitoring,n)is value for n,value in self.original_monitor)
            and tuple((n,monitoring.get_tool(n),monitoring.get_events(n))for n in range(6))==self.slots)
        if not tools:problems.append('Original monitoring slots/ports changed')
        if self.forbidden_entries:problems.append('Definition-only body entered')
        return dict(dupPortsRestored=os.dup is self.dup and os.dup2 is self.dup2,toolsRestored=tools,problems=problems,
            actualHelperThreads=len(self.threads),definitionOnlyEntries=self.forbidden_entries)
