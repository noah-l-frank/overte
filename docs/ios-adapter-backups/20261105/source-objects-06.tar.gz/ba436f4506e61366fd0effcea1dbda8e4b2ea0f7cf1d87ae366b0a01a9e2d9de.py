"""Actual source/HTTP/AFC-model WAL/carriers/chunks; native physics are MODELS."""
import asyncio,json,os
from copy import deepcopy
from unittest.mock import patch
import test_native_passive_scope_models as passive_fixture


class NativePassiveCarrierModels(passive_fixture.NativePassiveScopeModels):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        # New explicit PHYSICS MODEL selected before selection/firstcapture.
        # Only the actual original second HID report changes its measured
        # producer position; no retained packet or native clock is rewritten.
        self.move_effect=lambda:self.world_source.position.__setitem__(2,-.7)
    def collection(self):return self.ops.native_query_journals[self.run]['passiveCollection']
    def collector_args(self,phase):return dict(self.acquire_args(),nativePassiveAcquisitionVersion=1,phase=phase)
    async def collect_rpc(self,phase):return await self.passive_rpc('touch-native-acquire',self.collector_args(phase))
    async def collect(self,phase):return await asyncio.to_thread(self.runtime.native_passive_world,'modeled-original-source',self.run,phase)
    async def released(self):
        await self.open_motion();held=await self.collect('held');await self.passive_rpc('touch-release',{})
        return held,await self.collect('released')
    def raw_path(self,reference):
        from adapters.original_frame_store import OriginalFrameStore
        codec=OriginalFrameStore(self.f.store.path.parent,self.binding,self.run,'primary',lambda:True,lambda *_:False,
            namespace='lifecycle-passive-original',schema_prefix='iosLifecyclePassiveRaw')
        return codec.path(codec.expand(reference))

    async def test_same_original_source_collects_held_released_and_four_later_quiet_originals_with_30_queries(self):
        from ios.adapters import lifecycle_world as world
        held,released=await self.released();quiet=[await self.collect('quiet') for _ in range(4)]
        frames=[held['originalFrame'],released['originalFrame']]+[value['originalFrame'] for value in quiet]
        proof=world.stationary([frame['originals']['world'] for frame in frames[2:]])
        self.assertGreaterEqual(proof['nativeMilliseconds'],3000);self.assertEqual(4,proof['samples'])
        self.assertEqual(['held','released']+['quiet']*4,[f['phase'] for f in frames]);self.assertEqual(list(range(1,7)),[f['ordinal'] for f in frames])
        self.assertEqual(30,len(self.commands));self.assertEqual(30,len({q['commandId'] for q in self.commands}))
        self.assertEqual(3,len(self.journal()['previous']['frames']));self.assertIsNone(self.collection()['pending'])
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes());self.assertFalse(self.source._closing)
        for index,frame in enumerate(frames):
            if index>=2:
                self.assertEqual(frames[index-1]['reads'][-1],frame['reads'][0])
                self.assertEqual(frames[index-1]['clockJoin']['hostAfterMonotonic'],frame['clockJoin']['hostBeforeMonotonic'])
                self.assertEqual(frames[index-1]['clockJoin']['hostAfterEpochMs'],frame['clockJoin']['hostBeforeEpochMs'])
                self.assertNotEqual(frames[index-1]['originals']['world']['requestId'],frame['originals']['world']['requestId'])
            for row in frame['reads']:
                original=self.ops.native_query_journals[self.run]['passiveOriginals'][row['query']['commandId']]
                self.assertTrue(original[3]().done());self.assertIsNone(original[3]().exception())
        for value in (held,released,*quiet):
            self.assertTrue(all(value[k] is False for k in ('nativeAcquisitionBound','installedCandidateBound','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished')))
        await self.passive_rpc('touch-settle',{});self.assertTrue(self.source._closing)

    async def test_atomic_same_byte_previous_endpoint_inode_replacement_refuses_before_new_quiet_query(self):
        await self.released();last=self.collection()['cuts'][-1]['after'];path=self.raw_path(last[2]);body=path.read_bytes();inode=path.stat().st_ino
        replacement=path.with_name('declared-foreign-carrier');replacement.write_bytes(body);replacement.chmod(0o600);os.replace(replacement,path)
        self.assertNotEqual(inode,path.stat().st_ino);commands=len(self.commands)
        with self.assertRaises(RuntimeError):await self.collect_rpc('quiet')
        self.assertEqual(commands,len(self.commands));self.assertEqual(body,path.read_bytes());self.assertIsNotNone(self.collection()['pending'])
        with self.assertRaises(RuntimeError):await self.collect_rpc('quiet')
        self.assertEqual(commands,len(self.commands));self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_real_stale_previous_original_endpoint_is_not_reclocked_or_requeried_for_quiet(self):
        await self.released();last=self.collection()['cuts'][-1]['after'];path=self.raw_path(last[2]);original=(path.stat().st_ino,path.read_bytes());commands=len(self.commands)
        await asyncio.sleep(1.55)
        with self.assertRaises(RuntimeError):await self.collect_rpc('quiet')
        self.assertEqual(original,(path.stat().st_ino,path.read_bytes()));self.assertEqual(commands,len(self.commands));self.assertEqual(2,len(self.collection()['cuts']))

    async def test_wrong_phase_selector_never_releases_or_issues_query_and_actual_next_phase_remains_possible(self):
        await self.open_motion();await self.collect('held');commands=len(self.commands)
        with self.assertRaises(RuntimeError):await self.collect_rpc('quiet')
        with self.assertRaises(RuntimeError):await self.collect_rpc('released')
        self.assertEqual(commands,len(self.commands));self.assertIsNone(self.collection()['pending']);self.assertFalse(self.ops.touch.up_issued)
        await self.passive_rpc('touch-release',{});value=await self.collect('released');self.assertEqual('released',value['originalFrame']['phase'])
        self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_saved_raw_original_return_loss_keeps_same_pending_cut_without_native_receipt_or_requery(self):
        await self.open_motion();write=self.frame_store_type.write
        def lost(store,index,frame):
            result=write(store,index,frame)
            if store.namespace=='lifecycle-passive-original':raise OSError('Declared loss AFTER actual saved raw original')
            return result
        with patch.object(self.frame_store_type,'write',new=lost),self.assertRaises(RuntimeError):await self.collect_rpc('held')
        owner=self.ops.native_query_journals[self.run];record=owner['previous']['records'][-1];self.assertEqual('saved',record['passiveOriginal']['phase'])
        self.assertNotIn(record['query']['commandId'],owner.get('passiveOriginals',{}));path=self.raw_path({k:record['passiveOriginal'][k] for k in ('index','sha256','bytes')}|record['passiveOriginal']['file'])
        saved=(path.stat().st_ino,path.read_bytes());commands=len(self.commands)
        with self.assertRaises(RuntimeError):await self.collect_rpc('held')
        self.assertEqual(saved,(path.stat().st_ino,path.read_bytes()));self.assertEqual(commands,len(self.commands));self.assertEqual([],self.collection()['cuts'])
        await self.passive_rpc('touch-release',{});self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_saved_join_return_loss_cannot_adopt_same_frame_as_new_capture_or_replay_its_three_queries(self):
        await self.open_motion();write=self.frame_store_type.write
        def lost(store,index,frame):
            result=write(store,index,frame)
            if store.namespace=='lifecycle-passive-world':raise OSError('Declared loss AFTER actual saved passive World join')
            return result
        with patch.object(self.frame_store_type,'write',new=lost),self.assertRaises(RuntimeError):await self.collect_rpc('held')
        owner=self.ops.native_query_journals[self.run];record=next(row for row in owner['previous']['records'] if 'passiveCut' in row)
        self.assertEqual('saved',record['passiveCut']['phase']);commands=len(self.commands);self.assertEqual(19,commands)
        self.assertEqual([],self.collection()['cuts']);self.assertIsNotNone(self.collection()['pending'])
        with self.assertRaises(RuntimeError):await self.collect_rpc('held')
        self.assertEqual(commands,len(self.commands));await self.passive_rpc('touch-release',{})

    async def test_actual_original_afc_stat_change_cannot_save_raw_receipt_or_join_even_when_bytes_parse(self):
        await self.open_motion();stat=self.service_type.stat
        async def changed(service,path):
            value=await stat(service,path)
            if sum(row[0]=='stat' for row in service.calls)==2:return dict(value,st_mtime=value['st_mtime']+1)
            return value
        with patch.object(self.service_type,'stat',new=changed),self.assertRaises(RuntimeError):await self.collect_rpc('held')
        self.assertEqual(17,len(self.commands));owner=self.ops.native_query_journals[self.run]
        self.assertNotIn('passiveOriginal',owner['previous']['records'][-1]);self.assertEqual({},owner.get('passiveOriginals',{}))
        self.assertTrue(all(row[4].is_set() for row in self.source._native_reads));await self.passive_rpc('touch-release',{})

    async def test_real_chunk_truncation_cannot_turn_saved_source_join_into_host_original(self):
        await self.open_motion();self.corrupt_chunk=True
        try:
            with self.assertRaises((RuntimeError,ValueError)):await self.collect('held')
        finally:self.corrupt_chunk=False
        self.assertEqual(19,len(self.commands));self.assertEqual(1,len(self.collection()['cuts']));self.assertIsNone(self.collection()['pending'])
        self.assertFalse(self.ops.touch.worker.done());self.assertEqual([0xC2,0xC2],self.f.states())
        await self.passive_rpc('touch-release',{});self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_foreign_correctly_shaped_carrier_tuple_is_refused_before_its_callback_runs(self):
        await self.released();history=self.collection();original=history['cuts'][-1]['after']
        raw=json.loads(self.raw_path(original[2]).read_bytes())['frame'];called=[]
        def foreign(_scope):called.append('FOREIGN-CALLBACK-RAN');return deepcopy(raw)
        forged=(original[0],foreign,deepcopy(original[2]),original[3]);history['cuts'][-1]['after']=forged
        commands=len(self.commands)
        try:
            with self.assertRaises(RuntimeError):await self.collect_rpc('quiet')
        finally:history['cuts'][-1]['after']=original
        self.assertEqual([],called);self.assertEqual(commands,len(self.commands))
        self.assertEqual(2,len(history['cuts']));self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_foreign_callback_grafted_into_registry_cannot_run_as_the_source_original_producer(self):
        await self.released();owner=self.ops.native_query_journals[self.run];history=self.collection()
        original=history['cuts'][-1]['after'];raw=json.loads(self.raw_path(original[2]).read_bytes())['frame'];called=[]
        query=raw['query']['commandId']
        def foreign(_scope):called.append('FOREIGN-CALLBACK-RAN');return deepcopy(raw)
        forged=(original[0],foreign,deepcopy(original[2]),original[3]);history['cuts'][-1]['after']=forged
        self.assertIs(owner['passiveOriginals'][query],original);owner['passiveOriginals'][query]=forged
        commands=len(self.commands)
        try:
            with self.assertRaises(RuntimeError):await self.collect_rpc('quiet')
        finally:history['cuts'][-1]['after']=original;owner['passiveOriginals'][query]=original
        self.assertEqual([],called);self.assertEqual(commands,len(self.commands))
        self.assertEqual(2,len(history['cuts']));self.assertEqual([0xC2,0xC2,0x02],self.f.states())
