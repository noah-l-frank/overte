"""Pure post-End admission, with no Source reconstruction after SDK deletion."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from feature_journeys import terminal as protocol
from ios.adapters.lifecycle_terminal import LifecycleTerminal
from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd


def verify(flow,call,result):
    need(call['stage']=='finish'and result['stage']=='finish')
    protocol.ended(result['end'],call['seal']);terminal=LifecycleTerminal(flow)
    with terminal.lock.held():
        need(terminal.state is not None and same(terminal.state['end'],result['end']))
        actual=terminal.live_original(terminal.state['description'],terminal.state['samples'])
        need(same(actual,terminal.state['live']))
        for role,root in (('primary',flow.primary_root),('actor',flow.actor_root)):
            end=IOSOriginalKeeperProcessEnd(flow.script,flow.selector,root,terminal.binding,flow.run,role,0,'lifecycle',terminal.lock)
            proof=end.retirement_original();row=result['end']['roles'][role]
            need(row['archiveSha256']==proof['archiveSha256']and row['osAbsence']==proof['osAbsence']
                and row['stopOriginalSha256']==proof['stopOriginalSha256']and row['sdkDeletionOriginalSha256']==proof['sdkDeletionOriginalSha256'])
        need(PrivateFeatureState(flow.runtime.adapter.state_path(flow.selector)).read()is None
            and flow.runtime.adapter._binding_store(flow.selector).read()is None)
    return True
