// Copyright 2026 Overte contributors.
// SPDX-License-Identifier: Apache-2.0
#pragma once
// Optional, unapplied extension of the reviewed Overte Qt6.11.1 E2E patch.
// Native sources are uncompiled; this is not installed-code admission.
#include <QtCore/qglobal.h>
#if defined(Q_OS_IOS) && defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
#include <QtCore/qcoreapplication.h>
#include <QtCore/qcryptographichash.h>
#include <QtCore/qdatetime.h>
#if QT_CONFIG(temporaryfile)
#include <QtCore/qsavefile.h>
#endif
#include <QtCore/quuid.h>
#include <QtCore/qvariant.h>
#include <atomic>
#include <chrono>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

QT_BEGIN_NAMESPACE
namespace QV4::OverteCacheOriginals {
// State lives in the patched Qt binary, never a consumer-local header copy.
Q_QML_EXPORT bool active() noexcept;
Q_QML_EXPORT void setEnabled(bool value) noexcept;
Q_QML_EXPORT void fail() noexcept;
Q_QML_EXPORT quint64 next() noexcept;
inline QVariantMap clock() {
    return {{"epochMs",QDateTime::currentMSecsSinceEpoch()},
        {"monotonicMs",qlonglong(std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count())}};
}
inline QString nonce() { return QUuid::createUuid().toString(QUuid::WithoutBraces).remove('-'); }
inline QString sha(const void *data, qsizetype size) {
    return QString::fromLatin1(QCryptographicHash::hash(
        QByteArrayView(static_cast<const char *>(data),size),QCryptographicHash::Sha256).toHex());
}
inline QVariantMap file(int fd) {
    struct stat actual;
    if (::fstat(fd,&actual)!=0 || !S_ISREG(actual.st_mode) || actual.st_size<0) return {};
    // Decimal strings preserve 64-bit inode/device identity through JSON.
    return {{"device",QString::number(qulonglong(actual.st_dev))},
        {"inode",QString::number(qulonglong(actual.st_ino))},{"bytes",qlonglong(actual.st_size)},
        {"modifiedSeconds",qlonglong(actual.st_mtimespec.tv_sec)},
        {"modifiedNanoseconds",qlonglong(actual.st_mtimespec.tv_nsec)},
        {"changedSeconds",qlonglong(actual.st_ctimespec.tv_sec)},
        {"changedNanoseconds",qlonglong(actual.st_ctimespec.tv_nsec)}};
}
inline bool sameFile(const QVariantMap &a,const QVariantMap &b) {
    return !a.isEmpty() && !b.isEmpty() && a.value("device")==b.value("device") && a.value("inode")==b.value("inode");
}
#if QT_CONFIG(temporaryfile)
class Write final {
    Q_DISABLE_COPY_MOVE(Write)
public:
    Write(QSaveFile &actual,const char *data,quint32 size,const QVariantMap &compiler,
          const QString &owner,quint64 generation) noexcept {
        QT_TRY {
            if (!active() || !data || !size || size>4*1024*1024 || compiler.isEmpty()
                    || owner.isEmpty() || generation>=1000000000 || actual.handle()<0) return;
            // Retain exactly the opened QSaveFile description across commit's
            // rename/close. Never obtain identity by reopening its path.
            retained=::dup(actual.handle());if (retained<0) return;
            before=file(retained);if (before.isEmpty()) return;
            original={{"qtOverteQmlCacheWriteVersion",1},{"clockDomain",QStringLiteral("native-qt-steady-clock")},{"writerId",nonce()},
                {"processId",QCoreApplication::applicationPid()},{"compilerOwnerId",owner},
                {"compilerOwnerGeneration",qulonglong(generation)},{"compilerInput",compiler},
                {"writeSequence",qulonglong(next())},{"writeBefore",clock()},
                {"bytes",qlonglong(size)},{"writeArgumentSha256",sha(data,size)},{"fileBefore",before}};
        } QT_CATCH (...) { fail();original.clear(); }
    }
    ~Write() { if (retained>=0) ::close(retained); }
    QVariantMap committed(qint64 actualWritten,bool actualCommit) noexcept {
        QT_TRY {
            if (!active() || original.isEmpty() || retained<0 || !actualCommit
                    || actualWritten!=original.value("bytes").toLongLong()) return {};
            const auto after=file(retained);
            if (!sameFile(before,after) || after.value("bytes")!=original.value("bytes")) return {};
            auto result=original;result.insert("written",actualWritten);result.insert("committed",true);
            result.insert("fileCommitted",after);result.insert("writeAfter",clock());
            return result;
        } QT_CATCH (...) { fail();return {}; }
    }
private:
    int retained=-1;
    QVariantMap before,original;
};
#endif
inline QVariantMap mapped(int actualFd,const void *actualData,qsizetype length,
                          const QVariantMap &writeOriginal) noexcept {
    QT_TRY {
        if (!active() || !actualData || length<=0 || length>4*1024*1024 || writeOriginal.isEmpty()) return {};
        const auto before=file(actualFd);const auto started=clock();
        const auto digest=sha(actualData,length);const auto after=file(actualFd);
        if (before.isEmpty() || before!=after || before!=writeOriginal.value("fileCommitted").toMap()
                || before.value("bytes").toLongLong()!=length
                || writeOriginal.value("writeArgumentSha256").toString()!=digest
                || writeOriginal.value("processId").toLongLong()!=QCoreApplication::applicationPid()) return {};
        // Stored by the actual mapper, and copied with that mapper on a static
        // hit. No filename lookup can create or replace this association.
        return {{"qtOverteQmlCacheMappingVersion",1},{"clockDomain",QStringLiteral("native-qt-steady-clock")},{"mappingId",nonce()},
            {"mappingSequence",qulonglong(next())},{"processId",QCoreApplication::applicationPid()},
            {"mapBefore",started},{"mapAfter",clock()},
            {"mappedFile",after},{"mappedBytes",qlonglong(length)},{"mappedSha256",digest},
            {"writeOriginal",writeOriginal}};
    } QT_CATCH (...) { fail();return {}; }
}
} // namespace QV4::OverteCacheOriginals
QT_END_NAMESPACE
#endif
