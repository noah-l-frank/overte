"""Private actual keeper/TouchLease flow with explicit SDK/HID producer models.

No SDK imports/device authentication. Root publication+exact source map is
required before target imports; the source-close event is a modeled SDK close.
"""
from __future__ import annotations
import ast
import asyncio
from contextlib import asynccontextmanager
import hashlib
import inspect
import json
import os
from pathlib import Path
import unittest
from unittest.mock import patch
import weakref


def admitted_sources():
    path=Path(os.environ['LIFECYCLE_KEEPER_DRAIN_SOURCE_MAP']);raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_KEEPER_DRAIN_SOURCE_MAP_SHA256']:
        raise RuntimeError('Exact Root source map unavailable')
    value=json.loads(raw);root=Path(value['repositoryRoot'])
    names={'keeper':'tests/device/ios/pymobiledevice3_wda_xctest.py',
           'lease':'tests/device/ios/adapters/touch_lease.py',
           'fixture':'tests/device/ios/self_tests/test_ios_touch_lease.py',
           'retained':'tests/device/ios/adapters/lifecycle_touch_transport.py'}
    for key,relative in names.items():
        row=value['sources'][key];target=Path(row['path'])
        if target!=root/relative or target.resolve()!=target or hashlib.sha256(target.read_bytes()).hexdigest()!=row['sha256']:
            raise RuntimeError('Actual source changed or foreign Root')
    return value


class ModelSource:
    def __init__(self):self.rsd=object()
    def current(self):return self.rsd,'fd00::1'
    def udp_socket(self):raise AssertionError('Modeled HID factory must not instantiate SDK sockets')


class ModelTunnel:
    def __init__(self,source):self.source=source
    def original_source(self):return self.source


class KeeperDrainModels(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.map=admitted_sources()
        from ios.self_tests import test_ios_touch_lease as fixture
        from ios.adapters import touch_lease
        from ios.adapters import lifecycle_touch_transport
        for key,module in [('lease',touch_lease),('fixture',fixture),('retained',lifecycle_touch_transport)]:
            self.assertEqual(Path(module.__file__).resolve(),Path(self.map['sources'][key]['path']))
        self.fixture=fixture;self.f=fixture.TouchLeaseTests();self.f.setUp()
        for function,args,kwargs in self.f._cleanups:self.addCleanup(function,*args,**kwargs)
        self.f._cleanups.clear()
        path=Path(self.map['sources']['keeper']['path']);tree=ast.parse(path.read_text())
        nodes=[next(x for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='FAILURE_PHASES' for t in x.targets)),
               *[next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name==name) for name in ('LaunchError','OriginalKeeperSource')]]
        namespace=dict(asyncio=asyncio,asynccontextmanager=asynccontextmanager,inspect=inspect,weakref=weakref)
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(path),'exec'),namespace)
        self.owner=namespace['OriginalKeeperSource'].__new__(namespace['OriginalKeeperSource'])
        self.cap=ModelSource();self.tunnel=ModelTunnel(self.cap)
        self.owner._tunnel=weakref.ref(self.tunnel);self.owner._source=self.cap;self.owner._loop=asyncio.get_running_loop()
        self.owner._leases=[];self.owner._born=[];self.owner._closing=False
        self.original_workers=[];self.contexts=[self.f.context];self.operations=[];self.closed=asyncio.Event();self.exit_started=asyncio.Event()
    async def asyncTearDown(self):
        for context in self.contexts:
            context.enter_gate.set();context.down_gate.set();context.drain_gate.set()
        for row in self.owner._born:row['release'].set()
        for worker in self.original_workers:
            if not worker.done():await asyncio.wait_for(asyncio.shield(worker),2)
        if self.operations:await asyncio.gather(*self.operations,return_exceptions=True)
        await self.f.asyncTearDown()
    def lease(self,store):return self.owner.touch_lease(store,binding=self.f.binding,run=self.f.run_id,check=lambda:True)
    async def modeled_creator_exit(self):
        # Exact actual keeper settle method controls this model close ordering.
        # It supplies no real SDK/native retirement evidence.
        self.exit_started.set()
        try:await self.owner.settle_touches()
        finally:self.closed.set()
    async def test_idle_a_cannot_begin_while_active_b_original_drain_is_awaited(self):
        from adapters.normal_feature_state import PrivateFeatureState
        store_b=PrivateFeatureState(self.f.store.path.with_name('second-touch-lease.json'))
        context_b=self.fixture.Context(store_b);self.contexts.append(context_b);self.addCleanup(context_b.close)
        context_b.drain_gate.clear()
        with patch('ios.adapters.hid_session.touch_session',side_effect=lambda *_args,**_kwargs:context_b):
            a=self.lease(self.f.store);b=self.lease(store_b)
            await b.begin(100,50,25,10,seconds=2)
            self.original_workers.append(b.worker)
            exiting=asyncio.create_task(self.modeled_creator_exit());self.operations.append(exiting)
            await context_b.drain_started.wait()
            self.assertFalse(self.closed.is_set());self.assertFalse(exiting.done())
            with self.assertRaises(RuntimeError):await a.begin(100,50,25,10,seconds=2)
            self.assertIsNone(a.worker);self.assertIsNone(a.store.read());self.assertEqual([],self.f.context.events)
            self.assertEqual([0xC2,0x02],[e[0] for e in context_b.events])
            context_b.drain_gate.set();await exiting
        self.assertTrue(self.closed.is_set());self.assertTrue(b.worker.done());self.assertFalse(b.worker.cancelled())
    async def test_foreign_finished_public_slot_cannot_replace_pending_original_worker_at_exit(self):
        from ios.adapters.touch_lease import TouchLeasePending
        self.f.context.down_gate.clear()
        with patch('ios.adapters.hid_session.touch_session',side_effect=lambda *_args,**_kwargs:self.f.context):
            lease=self.lease(self.f.store)
            with self.assertRaises(TouchLeasePending):await lease.begin(100,50,25,10,seconds=.3)
            original=lease.worker;self.original_workers.append(original)
            foreign=asyncio.create_task(asyncio.sleep(0));await foreign
            lease.worker=foreign
            exiting=asyncio.create_task(self.modeled_creator_exit());self.operations.append(exiting)
            await self.exit_started.wait()
            await lease.request_release.wait()
            self.assertFalse(self.closed.is_set());self.assertFalse(exiting.done());self.assertFalse(original.done())
            self.assertFalse(original.cancelled());self.assertEqual([0xC2],[e[0] for e in self.f.context.events])
            self.f.context.down_gate.set();await original
            with self.assertRaises(RuntimeError):await exiting
            lease.worker=original
        self.assertTrue(self.closed.is_set());self.assertTrue(original.done());self.assertFalse(original.cancelled())
        self.assertEqual([0xC2,0x02],[e[0] for e in self.f.context.events])
        self.assertTrue(all(fd.fileno()==-1 for fd in self.f.context.sockets))
