"""Prepare byte-image observation on the existing bundle owner/Chat query."""
from pathlib import Path
import difflib,hashlib,json
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;PREVIOUS=OUT.with_name('chat-qml-cache-object-transport-proposal-20261027')
paths=['tests/device/ios/InstalledBundleIdentity.h','libraries/qml/src/qml/IOSQmlSourceObservation.h',
    'libraries/qml/src/qml/IOSQmlSourceObservation.cpp','tests/device/native/IOSChatQmlSourcesObservation.h',
    'interface/src/scripting/TestScriptingInterface.cpp']
base={path:(ROOT/path).read_text() for path in paths}
prior=json.loads((PREVIOUS/'client-candidate.json').read_text())
base[prior['path']]=(ROOT/prior['candidate']).read_text();current=dict(base)
def change(path,old,new):
 assert current[path].count(old)==1,(path,old[:60]);current[path]=current[path].replace(old,new,1)
path=paths[0]
change(path,'#include <cerrno>\n','''#include <cerrno>
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach/vm_prot.h>
#include <limits>
#include <cstring>
#if __has_feature(ptrauth_calls)
#include <ptrauth.h>
#endif
#endif
''')
change(path,'private:\n    static qint64 elapsed(', '#if defined(OVERTE_IOS_E2E_TEST_BUILD)\n'+(OUT/'installed_bundle_image_method.cpp.txt').read_text()+'#endif\nprivate:\n    static qint64 elapsed(')
change(path,'    const QString _instance{','''#if defined(OVERTE_IOS_E2E_TEST_BUILD)
    quint64 _imageSequence{0};
#endif
    const QString _instance{''')
path=paths[1]
change(path,'    static QList<QObject*> liveObjects() noexcept;','''    static QList<QObject*> liveObjects() noexcept;
    // Internal native bridge only. No pointer enters a Script/JSON receipt.
    static const void* cacheObservationSymbol(QObject* object) noexcept;''')
path=paths[2]
change(path,'QVariantMap cacheReceipt(QObject *object,QQmlComponent *component=nullptr) {','QVariantMap cacheReceipt(QObject *object,QQmlComponent *component=nullptr,const void **called=nullptr) {')
change(path,'''    if (QQmlTypeData::overteE2eCacheObservationApiVersion()==1)
        return QQmlTypeData::overteE2eCacheReceiptForObject(object,component);''','''    if (QQmlTypeData::overteE2eCacheObservationApiVersion()==1) {
        const auto actual=&QQmlTypeData::overteE2eCacheReceiptForObject;
        if (called) *called=reinterpret_cast<const void *>(actual);
        return actual(object,component);
    }''')
change(path,'    Q_UNUSED(object);Q_UNUSED(component);return {};','    Q_UNUSED(object);Q_UNUSED(component);Q_UNUSED(called);return {};')
change(path,'    bool completed { false };','    bool completed { false };\n    const void *cacheFunction { nullptr };')
change(path,'const auto cache=source.isEmpty() ? cacheReceipt(object,component) : QVariantMap();','const void *cacheFunction=nullptr;\n            const auto cache=source.isEmpty() ? cacheReceipt(object,component,&cacheFunction) : QVariantMap();')
change(path,'row.after = after; row.source = source;row.cache=cache;','row.after = after; row.source = source;row.cache=cache;row.cacheFunction=cacheFunction;')
change(path,'''                currentCache=cacheReceipt(object);
                if (!sameCacheIdentity(row.cache,currentCache)) return {};''','''                const void *currentFunction=nullptr;currentCache=cacheReceipt(object,nullptr,&currentFunction);
                if (!row.cacheFunction || currentFunction!=row.cacheFunction || !sameCacheIdentity(row.cache,currentCache)) return {};''')
change(path,'QList<QObject*> IOSQmlSourceObservation::liveObjects() noexcept {','''const void* IOSQmlSourceObservation::cacheObservationSymbol(QObject* object) noexcept {
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(QT_OVERTE_E2E_QML_CACHE_ORIGINALS)
    try {
        if (!enabled() || !object || object->thread()!=QThread::currentThread()) return nullptr;
        const auto current=reinterpret_cast<const void *>(&QQmlTypeData::overteE2eCacheReceiptForObject);
        for (const auto &row:state().loads)
            if (row.completed && row.object==object && !row.cache.isEmpty() && row.cacheFunction==current) return current;
    } catch (...) { observationFailed.store(true); }
#else
    Q_UNUSED(object);
#endif
    return nullptr;
}

QList<QObject*> IOSQmlSourceObservation::liveObjects() noexcept {''')
path=paths[3]
wire=(OUT/'variant_wire_guard.h').read_text();wire=wire[wire.index('namespace overte::e2e {'):]
change(path,'#include <QUuid>\n','#include <QUuid>\n#include <functional>\n#include <cmath>\n\n'+wire+'\n')
change(path,'    QVariantMap read(const QString& request, const QString& run) {','''    QVariantMap read(const QString& request, const QString& run,
            const std::function<QVariantMap(const void *)>& imageReader = {}) {''')
change(path,'''        const auto after = clock();
        QVariantMap result''','''        QVariantMap image;
        const bool cached=source.value("iosLoadedQmlSourceVersion").toInt()==2;
        if (cached) {
            const auto actual=hifi::qml::IOSQmlSourceObservation::cacheObservationSymbol(page);
            if (!actual || !imageReader) return {};
            image=imageReader(actual);if (image.isEmpty()) return {};
        }
        const auto after = clock();
        QVariantMap result''')
change(path,'{{"iosChatQmlSourcesVersion", 1},','{{"iosChatQmlSourcesVersion", cached?2:1},')
change(path,'''        return QJsonDocument::fromVariant(result).toJson(QJsonDocument::Compact).size() <= 65536 ? result : QVariantMap();''','''        if (cached) result.insert("qtEntryImage",image);
        // Check before the actual QVariantMap -> ScriptEngineV8 -> JSNumber
        // conversion. Filesystem IDs/offsets are strings; every Number is exact.
        return chatQmlWireValue(result) && QJsonDocument::fromVariant(result).toJson(QJsonDocument::Compact).size() <= 65536 ? result : QVariantMap();''')
path=paths[4]
change(path,'return overte::e2e::IOSChatQmlSourcesObservation::instance().read(request,run);','''return overte::e2e::IOSChatQmlSourcesObservation::instance().read(request,run,[this](const void *actualEntry) {
            return _featureIOSBundle ? _featureIOSBundle->observeQtEntryImage(actualEntry) : QVariantMap();
        });''')
rows=[];patch=''
for path in paths:
 target=OUT/'native-source'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(current[path])
 patch+=''.join(difflib.unified_diff(base[path].splitlines(True),current[path].splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 rows.append(dict(path=path,baseSha256=hashlib.sha256(base[path].encode()).hexdigest(),candidate=str(target.relative_to(ROOT)),candidateSha256=hashlib.sha256(current[path].encode()).hexdigest()))
(OUT/'native-image-bridge.patch').write_text(patch)
(OUT/'native-candidates.json').write_text(json.dumps(dict(status='PRIVATE native code only/uncompiled; no tests; observer1 fields preserved, outer2 for cached/image source',paths=rows),indent=2)+'\n');print('Private existing-native image bridge candidates',len(rows))
