"""Only actual Root proof packets may reach future joins; both are pending."""
from pathlib import Path
from prefix_common import REPO,pin,load


def retained_packet(path,digest):
    path=Path(path)
    assert path.is_absolute()and path.resolve(strict=True)==path
    assert path.is_relative_to(REPO/'.ios-host-tmp')and path.name=='freeze.json'
    assert pin(path)['sha256']==digest
    for name,row in load(path)['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        actual=path.parent/name
        assert pin(actual)['sha256']==(row if type(row)is str else row['sha256'])
    return path


def qualified_original(path,digest):
    retained_packet(path,digest)
    raise RuntimeError('Actual OwnBoundary runtime result join pending: no prefix metadata admission')


def source_execution_original(path,digest):
    retained_packet(path,digest)
    raise RuntimeError('Actual Own6 fresh-source result join pending: no prefix metadata admission')
