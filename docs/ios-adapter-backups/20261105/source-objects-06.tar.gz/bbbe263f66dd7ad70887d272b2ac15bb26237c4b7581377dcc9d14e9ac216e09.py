#!/usr/bin/env python3
"""Serve and validate the deterministic Overte physical-device E2E fixture."""

from __future__ import annotations

import argparse
import base64
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import struct
import sys
import threading
import time
from urllib.parse import parse_qs, urlencode, urlsplit


ROOT = Path(__file__).resolve().parent
PROBE = ROOT.parent / "probe" / "overte_e2e_probe.js"
URL = re.compile(r"(?:https?|ftp)://", re.IGNORECASE)
REQUEST_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
CLIENT_COMMAND_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")


def controlled_scene_url(base_url: str, manifest: dict) -> str:
    return f"{base_url}/{manifest['scene']}?{urlencode({'location': manifest['spawnPath']})}"


def asset_source(manifest: dict) -> Path:
    return (ROOT / manifest["asset"]["source"]).resolve()


def asset_payload(manifest: dict) -> bytes:
    try:
        return base64.b64decode(asset_source(manifest).read_bytes().strip(), validate=True)
    except (OSError, ValueError) as error:
        raise ValueError("controlled asset source is not valid base64") from error


def png_dimensions(payload: bytes) -> tuple[int, int]:
    if len(payload) < 24 or payload[:8] != b"\x89PNG\r\n\x1a\n" or payload[12:16] != b"IHDR":
        raise ValueError("controlled asset must be a PNG with an IHDR header")
    return struct.unpack(">II", payload[16:24])


def validate_fixture() -> dict:
    manifest = json.loads((ROOT / "fixture-manifest.json").read_text(encoding="utf-8"))
    scene = json.loads((ROOT / manifest["scene"]).read_text(encoding="utf-8"))
    if manifest.get("schemaVersion") != 1 or scene.get("DataVersion") != 3:
        raise ValueError("unsupported fixture or scene schema")
    entities = scene.get("Entities")
    if not isinstance(entities, list) or len(entities) != manifest.get("expectedEntityCount"):
        raise ValueError("fixture entity count does not match its manifest")
    ids = [entity.get("id") for entity in entities]
    names = [entity.get("name") for entity in entities]
    if len(set(ids)) != len(ids) or not all(isinstance(item, str) and item for item in ids):
        raise ValueError("fixture entity IDs must be unique and non-empty")
    interaction_contract = manifest.get("interactionTarget")
    scripted_contract = manifest.get("scriptedInteraction")
    interaction_target = next((entity for entity in entities
                               if entity.get("name") == "OVERTE_E2E_INTERACTABLE"), None)
    expected_names = list(manifest.get("requiredMarkers", []))
    if isinstance(interaction_contract, dict):
        expected_names.append(interaction_contract.get("name"))
    if sorted(names) != sorted(expected_names):
        raise ValueError("fixture marker set does not match its manifest")
    if scene.get("Paths", {}).get("/") != manifest.get("spawnPath"):
        raise ValueError("fixture spawn path does not match its manifest")
    spawn = manifest.get("spawnPosition")
    floor = next((entity for entity in entities
                  if entity.get("name") == "OVERTE_E2E_FLOOR"), None)
    collision_wall = next((entity for entity in entities
                           if entity.get("name") == "OVERTE_E2E_COLLISION_WALL"), None)
    if (not isinstance(spawn, dict) or set(spawn) != {"x", "y", "z"}
            or not all(isinstance(spawn[axis], (int, float))
                       and not isinstance(spawn[axis], bool)
                       for axis in ("x", "y", "z"))
            or spawn["y"] != 0.0):
        raise ValueError("fixture spawn feet must be on the floor surface")
    expected_spawn_path = (f"/{spawn['x']},{spawn['y']},{spawn['z']}"
                           "/0,0,0,1")
    if manifest["spawnPath"] != expected_spawn_path:
        raise ValueError("fixture spawn path and position disagree")
    if not isinstance(floor, dict):
        raise ValueError("fixture floor marker is unavailable")
    dimensions = floor.get("dimensions", {})
    position = floor.get("position", {})
    thickness = dimensions.get("y")
    minimum_thickness = manifest.get("minimumFloorThickness")
    if (not isinstance(thickness, (int, float))
            or not isinstance(minimum_thickness, (int, float))
            or thickness < minimum_thickness
            or not isinstance(position.get("y"), (int, float))
            or abs(position["y"] + thickness / 2.0) > 1e-6):
        raise ValueError("fixture floor must be thick with its top fixed at y=0")
    if (floor.get("collisionless") is not False
            or floor.get("rotation", {"x": 0, "y": 0, "z": 0, "w": 1})
                != {"x": 0, "y": 0, "z": 0, "w": 1}
            or any(not isinstance(dimensions.get(axis), (int, float))
                   or not isinstance(position.get(axis), (int, float))
                   or abs(spawn[axis] - position[axis]) >= dimensions[axis] / 2.0 - 1.0
                   for axis in ("x", "z"))):
        raise ValueError("fixture spawn must be inside its supporting collision floor")
    wall_contract = manifest.get("collisionWall")
    if (not isinstance(collision_wall, dict) or not isinstance(wall_contract, dict)
            or set(wall_contract) != {"approachDirection", "center", "dimensions", "name"}
            or wall_contract.get("name") != "OVERTE_E2E_COLLISION_WALL"
            or collision_wall.get("collisionless") is not False
            or collision_wall.get("locked") is not True
            or wall_contract.get("approachDirection") != "forward"
            or collision_wall.get("position") != wall_contract.get("center")
            or collision_wall.get("dimensions") != wall_contract.get("dimensions")):
        raise ValueError("fixture collision wall does not match its manifest")
    if (not isinstance(interaction_target, dict)
            or not isinstance(interaction_contract, dict)
            or set(interaction_contract) != {"dimensions", "name", "position", "grab"}
            or interaction_contract.get("name") != "OVERTE_E2E_INTERACTABLE"
            or interaction_target.get("collisionless") is not True
            or interaction_target.get("locked") is not False
            # The controlled script button must remain in place across clicks.
            # Its properties stay mutable for the entity script's real effect.
            or interaction_contract.get("grab") != {"grabbable": False}
            or interaction_target.get("grab") != interaction_contract.get("grab")
            or interaction_target.get("position") != interaction_contract.get("position")
            or interaction_target.get("dimensions") != interaction_contract.get("dimensions")):
        raise ValueError("fixture interaction target does not match its manifest")
    expected_script = ROOT / "scripted_interactable.js"
    if (not isinstance(scripted_contract, dict)
            or set(scripted_contract) != {
                "activeColor", "contract", "idleColor", "script"}
            or scripted_contract.get("script") != expected_script.name
            or interaction_target.get("script") != expected_script.name
            or scripted_contract.get("contract") != "overte-e2e-scripted-entity-v1"
            or interaction_target.get("color") != scripted_contract.get("idleColor")
            or not expected_script.is_file()):
        raise ValueError("fixture scripted interaction contract is invalid")
    scripted_source = expected_script.read_text(encoding="utf-8")
    if (scripted_contract["contract"] not in scripted_source
            or "this.preload" not in scripted_source
            or "this.clickDownOnEntity" not in scripted_source
            or "Entities.editEntity" not in scripted_source):
        raise ValueError("fixture client entity script is incomplete")
    if manifest.get("externalResources") is not False or URL.search(json.dumps(scene)):
        raise ValueError("controlled fixture must not depend on external resources")
    asset = manifest.get("asset")
    required_asset_fields = {
        "id", "route", "source", "encoding", "contentType", "sha256", "bytes",
        "width", "height", "entityName",
    }
    if not isinstance(asset, dict) or set(asset) != required_asset_fields:
        raise ValueError("controlled asset manifest is incomplete")
    if (not isinstance(asset["id"], str) or not asset["id"]
            or not isinstance(asset["entityName"], str)
            or not asset["entityName"].startswith("OVERTE_E2E_ASSET_LOAD")
            or not isinstance(asset["route"], str)
            or not asset["route"].startswith("/assets/")
            or asset["encoding"] != "base64"
            or asset["contentType"] != "image/png"):
        raise ValueError("controlled asset identity or route is invalid")
    repository = ROOT.parents[2].resolve()
    source = asset_source(manifest)
    if repository not in source.parents or not source.is_file():
        raise ValueError("controlled asset source must be a repository file")
    payload = asset_payload(manifest)
    if (len(payload) != asset["bytes"]
            or hashlib.sha256(payload).hexdigest() != asset["sha256"]
            or png_dimensions(payload) != (asset["width"], asset["height"])):
        raise ValueError("controlled asset bytes do not match the manifest")
    sound = manifest.get("sound")
    if not isinstance(sound, dict) or set(sound) != {
            "path", "sha256", "mimeType", "sampleRate", "channels",
            "bitsPerSample", "durationSeconds", "frequencyHz"}:
        raise ValueError("fixture sound metadata is incomplete")
    sound_path = ROOT / sound["path"]
    sound_bytes = sound_path.read_bytes()
    from generate_sound_fixture import SAMPLE_RATE, CHANNELS, SAMPLE_WIDTH_BYTES, DURATION_SECONDS, FREQUENCY_HZ
    expected_size = 44 + int(SAMPLE_RATE * DURATION_SECONDS) * CHANNELS * SAMPLE_WIDTH_BYTES
    if (sound["mimeType"] != "audio/wav" or sound["sampleRate"] != SAMPLE_RATE
            or sound["channels"] != CHANNELS or sound["bitsPerSample"] != SAMPLE_WIDTH_BYTES * 8
            or sound["durationSeconds"] != DURATION_SECONDS or sound["frequencyHz"] != FREQUENCY_HZ
            or hashlib.sha256(sound_bytes).hexdigest() != sound["sha256"]
            or len(sound_bytes) != expected_size):
        raise ValueError("fixture sound does not match its deterministic PCM WAV contract")
    probe = PROBE.read_text(encoding="utf-8")
    if "Test.saveObject" not in probe or '"overte-probe.json"' not in probe:
        raise ValueError("controlled fixture probe does not satisfy the E2E contract")
    return manifest


class RequestTelemetry:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._requests: list[dict] = []

    def begin(self, asset: dict, request_id: str) -> dict:
        record = {
            "assetId": asset["id"], "requestId": request_id,
            "method": "GET", "path": asset["route"], "status": 200,
            "contentType": asset["contentType"], "contentLength": asset["bytes"],
            "sha256": asset["sha256"], "cacheControl": "no-store",
            "completed": False,
        }
        with self._lock:
            self._requests.append(record)
        return record

    def complete(self, record: dict) -> None:
        with self._lock:
            record["completed"] = True

    def summary(self, asset_id: str, request_id: str) -> dict:
        with self._lock:
            matches = [dict(item) for item in self._requests
                       if item["assetId"] == asset_id and item["requestId"] == request_id]
        completed = [item for item in matches if item["completed"]]
        return {
            "schemaVersion": 1, "assetId": asset_id, "requestId": request_id,
            "requests": len(matches), "completedRequests": len(completed),
            "bytesServed": sum(item["contentLength"] for item in completed),
            "latest": matches[-1] if matches else None,
            "latestCompleted": completed[-1] if completed else None,
        }


class FixtureServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], handler: object, manifest: dict,
                 sound_duration_seconds: float | None = None):
        self.sound_payload = (ROOT / manifest["sound"]["path"]).read_bytes()
        if sound_duration_seconds is not None:
            if isinstance(sound_duration_seconds, bool) or not 1 <= sound_duration_seconds <= 120:
                raise ValueError("sound duration must be from 1 through 120 seconds")
            from generate_sound_fixture import wav_bytes, SAMPLE_RATE
            self.sound_payload = wav_bytes(sound_duration_seconds)
            manifest = {**manifest, "sound": {**manifest["sound"],
                "durationSeconds": int(SAMPLE_RATE * sound_duration_seconds) / SAMPLE_RATE,
                "sha256": hashlib.sha256(self.sound_payload).hexdigest()}}
        super().__init__(address, handler)
        self.manifest = manifest
        self.public_origin = f"http://{address[0]}:{self.server_address[1]}"
        self.telemetry = RequestTelemetry()
        self.fixture_state = FixtureState()
        from parity_http import load_reference
        self.parity_manifest, self.parity_payload = load_reference(ROOT)


class FixtureHandler(SimpleHTTPRequestHandler):
    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        super().end_headers()

    def do_HEAD(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        if urlsplit(self.path).path == "/parity/reference.mp4":
            from parity_http import send_reference
            send_reference(self, head=True)
            return
        super().do_HEAD()

    def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        parsed = urlsplit(self.path)
        request_path = parsed.path
        if request_path == "/parity/reference.mp4":
            from parity_http import send_reference
            send_reference(self)
            return
        if request_path == "/" + self.server.manifest["scene"]:
            # The entity loader does not resolve a relative script path
            # against an imported serverless scene. Bind the script to this
            # controlled server's configured origin, never the Host header.
            scene = json.loads((ROOT / self.server.manifest["scene"]).read_text(encoding="utf-8"))
            scripted = self.server.manifest["scriptedInteraction"]["script"]
            for entity in scene["Entities"]:
                if entity.get("script") == scripted:
                    entity["script"] = self.server.public_origin + "/" + scripted
            payload = (json.dumps(scene, sort_keys=True) + "\n").encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if request_path == "/healthz":
            payload = b'{"ready":true,"schemaVersion":1}\n'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if request_path == "/overte_e2e_probe.js":
            payload = PROBE.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "application/javascript; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        asset = self.server.manifest["asset"]
        if request_path == asset["route"]:
            query = parse_qs(parsed.query, keep_blank_values=True)
            request_ids = query.get("requestId", [])
            if (set(query) != {"requestId"} or len(request_ids) != 1
                    or not REQUEST_ID.fullmatch(request_ids[0])):
                self.send_error(400, "asset request requires one valid requestId")
                return
            payload = asset_payload(self.server.manifest)
            record = self.server.telemetry.begin(asset, request_ids[0])
            self.send_response(200)
            self.send_header("Content-Type", asset["contentType"])
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            self.wfile.flush()
            self.server.telemetry.complete(record)
            return
        if request_path == "/telemetry/asset-requests":
            query = parse_qs(parsed.query, keep_blank_values=True)
            asset_ids = query.get("assetId", [])
            request_ids = query.get("requestId", [])
            if (set(query) != {"assetId", "requestId"} or len(asset_ids) != 1
                    or len(request_ids) != 1 or asset_ids[0] != asset["id"]
                    or not REQUEST_ID.fullmatch(request_ids[0])):
                self.send_error(400, "telemetry query is invalid")
                return
            payload = (json.dumps(
                self.server.telemetry.summary(asset_ids[0], request_ids[0]),
                sort_keys=True,
            ) + "\n").encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if request_path == "/sound-command.json":
            payload = (json.dumps(self.server.fixture_state.snapshot_command(), sort_keys=True)
                       + "\n").encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if request_path == "/e2e-client-command.json":
            payload = (json.dumps(
                self.server.fixture_state.snapshot_client_command(), sort_keys=True
            ) + "\n").encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        if request_path == "/sound-requests.json":
            payload = (json.dumps({
                "schemaVersion": 1,
                "requests": self.server.fixture_state.snapshot_requests(),
            }, sort_keys=True) + "\n").encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return
        sound_path = "/" + self.server.manifest["sound"]["path"]
        if request_path == sound_path:
            payload = self.server.sound_payload
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            self.server.fixture_state.record_request(
                self.command, parsed, 200, "audio/wav", len(payload))
            return
        if request_path == "/audio/invalid.wav":
            payload = b"OVERTE_E2E_INVALID_WAV\n"
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            self.server.fixture_state.record_request(
                self.command, parsed, 200, "audio/wav", len(payload))
            return
        if request_path.startswith("/audio/"):
            payload = b'{"error":"not found"}\n'
            self.send_response(404)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            self.server.fixture_state.record_request(
                self.command, parsed, 404, "application/json", len(payload))
            return
        super().do_GET()

    def do_POST(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
        request_path = urlsplit(self.path).path
        if request_path not in {"/e2e-client-command.json", "/sound-command.json"}:
            self.send_error(404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_error(400)
            return
        maximum = 131072 if request_path == "/e2e-client-command.json" else 4096
        if not 0 < length <= maximum:
            self.send_error(400)
            return
        try:
            command = json.loads(self.rfile.read(length))
            if length > 4096 and (not isinstance(command, dict) or not (
                    command.get("action") == "normal-ui-input" and length <= 32768
                    or command.get("action") in {"feature-ios-create-files","feature-ios-assets-files"} and length <= 131072
                    or command.get("action") == "feature-ios-assets-replies" and length <= 8192)):
                raise ValueError("client command exceeds its bounded transport")
            command = (self.server.fixture_state.set_command(command)
                       if request_path == "/sound-command.json"
                       else self.server.fixture_state.set_client_command(command))
        except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
            self.send_error(400, str(error))
            return
        payload = (json.dumps(command, sort_keys=True) + "\n").encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format_string: str, *arguments: object) -> None:
        print("fixture: " + format_string % arguments, file=sys.stderr)


class FixtureState:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._requests: list[dict] = []
        self.command = {"schemaVersion": 1, "commandId": "", "action": "idle",
                        "soundUrl": ""}
        self.client_command = {"schemaVersion": 1, "commandId": "", "action": "idle"}

    @staticmethod
    def _web_url(value: object) -> bool:
        if not isinstance(value, str):
            return False
        parsed = urlsplit(value)
        try:
            parsed.port
        except ValueError:
            return False
        return (parsed.scheme in {"http", "https"} and bool(parsed.hostname)
                and parsed.username is None and parsed.password is None
                and not parsed.fragment)

    def set_client_command(self, command: object) -> dict:
        if command == {"schemaVersion": 1, "commandId": "", "action": "idle"}:
            with self._lock:
                self.client_command = dict(command)
                return dict(self.client_command)
        if (not isinstance(command, dict)
                or (command.get("schemaVersion") != 1 and not (type(command.get("schemaVersion")) is int and command.get("schemaVersion") == 2
                    and command.get("action") == "snapshot-files" and command.get("operation") == "read"))
                or not isinstance(command.get("commandId"), str)
                or not CLIENT_COMMAND_ID.fullmatch(command["commandId"])):
            raise ValueError("invalid client command envelope")
        action = command.get("action")
        if action == "voice-test":
            sys.path.insert(0, str(ROOT.parent))
            from voice_contract import command as validate_voice_command
            valid = set(command) == {"schemaVersion", "commandId", "action", "request"}
            if valid:
                request = validate_voice_command(command["request"])
                valid = request["commandId"] == command["commandId"]
        elif action == "primary-view":
            valid = (set(command) == {"schemaVersion", "commandId", "action", "operation"}
                     and type(command["schemaVersion"]) is int
                     and re.fullmatch(r"ios-[0-9a-f]{32}", command["commandId"]) is not None
                     and command.get("operation") in {"prepare", "restore"})
        elif action in {"native-crash", "native-ui-snapshot", "native-geometry-snapshot", "native-probe-snapshot", "feature-native-observe",
                        "feature-recorded-audio-observe", "feature-recorded-audio-release", "feature-recorded-audio-files", "feature-script-observe", "feature-script-roots-observe", "feature-script-terminal-observe", "feature-avatar-receive-observe", "feature-world-render-observe"}:
            valid = (set(command) == {"schemaVersion", "commandId", "action"}
                     and type(command["schemaVersion"]) is int
                     and re.fullmatch(r"ios-[0-9a-f]{32}", command["commandId"]) is not None)
        elif action == "feature-private-login-input":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.private_login_input import command as private_input_command
            try:private_input_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid private input metadata request") from None
            valid=True
        elif action == "feature-account-origin":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_account_origin import command as account_origin_command
            try:account_origin_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid native account origin request") from None
            valid=True
        elif action == "ios-bundle-observe":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.bundle_observation import command as bundle_command
            try:bundle_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid original iOS bundle read request") from None
            valid=True
        elif action == "feature-completed-frame":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_completed_frame import command as completed_frame_command
            try:completed_frame_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid original completed frame request") from None
            valid=True
        elif action == "feature-vulkan-world-frame":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_vulkan_world_frame import command as vulkan_world_command
            try:vulkan_world_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid original Vulkan world frame request") from None
            valid=True
        elif action == "feature-scene-load-observe":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_scene_loads import command as scene_load_command
            try:scene_load_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid original scene load request") from None
            valid=True
        elif action == "feature-graphics-subject-observe":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_graphics_subject import command as graphics_subject_command
            try:graphics_subject_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid original graphics subject request") from None
            valid=True
        elif action == "feature-process-presence":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_process_presence import command as process_presence_command
            try:process_presence_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid native process presence request") from None
            valid=True
        elif action == "feature-navigation-replies":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_navigation_replies import command as navigation_replies_command
            try:navigation_replies_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid native navigation reply request") from None
            valid=True
        elif action == "feature-ios-lifecycle-navigation-inputs":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.lifecycle_navigation_inputs import command as lifecycle_navigation_command
            try:lifecycle_navigation_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Lifecycle navigation request") from None
            valid=True
        elif action == "feature-ios-lifecycle-pending-commands":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.lifecycle_pending_commands import command as lifecycle_pending_command
            try:lifecycle_pending_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Lifecycle pending command observation") from None
            valid=True
        elif action == "feature-ios-lifecycle-world":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.lifecycle_world import command as lifecycle_world_command
            try:lifecycle_world_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Lifecycle world source request") from None
            valid=True
        elif action == "feature-ios-lifecycle-inputs":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.lifecycle_inputs import command as lifecycle_inputs_command
            try:lifecycle_inputs_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Lifecycle input source request") from None
            valid=True
        elif action == "feature-ios-audio-session":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.audio_session_source import command as audio_session_command
            try:audio_session_command(command)
            except (ValueError,RuntimeError):raise ValueError('Invalid passive iOS Audio session command') from None
            valid=True
        elif action == "feature-ios-audio-settings":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.audio_settings_source import command as audio_session_command
            try:audio_session_command(command)
            except (ValueError,RuntimeError):raise ValueError('Invalid passive iOS Audio session command') from None
            valid=True
        elif action == "feature-ios-keyboard":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.keyboard_source import command as keyboard_command
            try:keyboard_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS keyboard source request") from None
            valid=True
        elif action == "feature-pending-commit-owner":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.pending_commit_owner import command as pending_owner_command
            try:pending_owner_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid native pending input owner request") from None
            valid=True
        elif action == "feature-ios-tablet-sources":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.tablet_web_sources import command as tablet_sources_command
            try:tablet_sources_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS tablet source request") from None
            valid=True
        elif action == "feature-ios-tablet-web":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.tablet_web_source import command as tablet_web_command
            try:tablet_web_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS tablet Web transcript request") from None
            valid=True
        elif action in ("feature-ios-tablet-web-deferred","feature-ios-tablet-web-defer"):
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.tablet_web_deferred import command as tablet_deferred_command
            try:tablet_deferred_command(command,operation=action=="feature-ios-tablet-web-defer")
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Tablet deferred callback request") from None
            valid=True
        elif action == "feature-ios-web-script-emissions":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.web_script_emissions import command as web_emissions_command
            try:web_emissions_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Web native emissions request") from None
            valid=True
        elif action == "feature-ios-tablet-web-state":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.tablet_web_state import command as tablet_state_command
            try:tablet_state_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Tablet native state request") from None
            valid=True
        elif action == "feature-ios-tablet-app-buttons":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.tablet_web_buttons import command as tablet_buttons_command
            try:tablet_buttons_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Tablet app button source request") from None
            valid=True
        elif action == "feature-ios-uikit-input":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.uikit_input import command as uikit_input_command
            try:uikit_input_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS UIKit input source request") from None
            valid=True
        elif action == "feature-ios-tablet-web-closures":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.tablet_web_closures import command as tablet_closures_command
            try:tablet_closures_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS tablet Web closure request") from None
            valid=True
        elif action == "feature-ios-tablet-web-dom":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.tablet_web_dom import command as tablet_web_dom_command
            try:tablet_web_dom_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS tablet Web DOM request") from None
            valid=True
        elif action == "feature-ios-world-web-whole-snapshot":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.world_web_whole_snapshot import command as world_whole_snapshot_command
            try:world_whole_snapshot_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS world Web whole snapshot request") from None
            valid=True
        elif action == "feature-ios-world-web-snapshot":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.world_web_snapshot import command as world_snapshot_command
            try:world_snapshot_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS world Web snapshot request") from None
            valid=True
        elif action == "feature-ios-world-web-surfaces":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.world_web_surfaces import command as world_surfaces_command
            try:world_surfaces_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS world Web surface ownership request") from None
            valid=True
        elif action == "feature-ios-world-web-keys":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.world_web_keys import command as world_web_keys_command
            try:world_web_keys_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS world Web keyboard source request") from None
            valid=True
        elif action in ("feature-ios-world-web-work", "feature-ios-world-web-geometry"):
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters import world_web_work,world_web_geometry
            try:(world_web_work if action == "feature-ios-world-web-work" else world_web_geometry).command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS world Web passive source request") from None
            valid=True
        elif action in ("feature-ios-world-web", "feature-ios-world-web-dom"):
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters import world_web_source,world_web_dom
            try:(world_web_source if action == "feature-ios-world-web" else world_web_dom).command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS world Web source request") from None
            valid=True
        elif action == "feature-ios-web-closures":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.web_closures import command as web_closures_command
            try:web_closures_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Web closure request") from None
            valid=True
        elif action == "feature-ios-location-bookmarks":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.location_bookmarks import command as bookmarks_command
            try:bookmarks_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS location bookmarks request") from None
            valid=True
        elif action == "feature-ios-places-model":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.places_model import command as places_model_command
            try:places_model_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Places model request") from None
            valid=True
        elif action == "feature-ios-places-http":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.places_http import command as places_http_command
            try:places_http_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Places HTTP request") from None
            valid=True
        elif action == "feature-ios-scene-inventory":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.scene_inventory import command as scene_inventory_command
            try:scene_inventory_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS scene inventory request") from None
            valid=True
        elif action == "feature-ios-script-dialogs":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.script_dialogs import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS script dialogs request") from None
            valid=True
        elif action == "feature-ios-emote-world":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.emote_world import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS emote world request") from None
            valid=True
        elif action == "feature-ios-avatar-world":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.avatar_world import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS avatar world request") from None
            valid=True
        elif action == "feature-ios-avatar-inputs":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.avatar_inputs import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS avatar inputs request") from None
            valid=True
        elif action == "feature-script-work-observe":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_script_work import command as script_work_command
            try:script_work_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid original Script work request") from None
            valid=True
        elif action == "feature-ios-avatar-renderers":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.avatar_renderers import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS avatar renderers request") from None
            valid=True
        elif action == "feature-ios-create-state":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.create_state import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS create state request") from None
            valid=True
        elif action == "feature-ios-assets-image-reader":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.assets_image_reader import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Assets image reader request") from None
            valid=True
        elif action == "feature-ios-assets-image-reader-queue":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.assets_image_reader_queue import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Assets image reader queue request") from None
            valid=True
        elif action == "feature-ios-assets-image-reader-processing":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.assets_image_reader_processing import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Assets image reader processing request") from None
            valid=True
        elif action == "feature-ios-assets-image-reader-storage":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.assets_image_reader_storage import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Assets image reader storage request") from None
            valid=True
        elif action == "feature-ios-assets-model-origin":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.assets_model_origin import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Assets model origin request") from None
            valid=True
        elif action == "feature-ios-assets-model-renderers":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.assets_model_renderers import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Assets model renderers request") from None
            valid=True
        elif action == "feature-ios-create-files":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.create_files import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS create files request") from None
            valid=True
        elif action == "feature-ios-assets-files":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.assets_files import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Assets file request") from None
            valid=True
        elif action == "feature-ios-assets-replies":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.assets_replies import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Assets reply request") from None
            valid=True
        elif action == "feature-ios-avatar-social-http":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.avatar_social_http import command as avatar_social_http_command
            try:avatar_social_http_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS original social HTTP request") from None
            valid=True
        elif action == "feature-ios-snapshot-preflight-http":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.snapshot_preflight_http import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS original Snapshot preflight HTTP request") from None
            valid=True
        elif action == "feature-ios-snapshot-combined-preflight-http":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.snapshot_combined_preflight_http import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS original Combined Snapshot preflight HTTP request") from None
            valid=True
        elif action == "feature-ios-snapshot-causal-dispatch":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.snapshot_causal_dispatch import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS original Snapshot causal dispatch request") from None
            valid=True
        elif action == "feature-ios-snapshot-combined-work":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.snapshot_combined_work import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS combined Snapshot work observation") from None
            valid=True
        elif action == "feature-ios-chat-script-sources":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.chat_script_sources import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Chat Script source request") from None
            valid=True
        elif action == "feature-ios-chat-qml-sources":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.chat_qml_sources import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS Chat QML source request") from None
            valid=True
        elif action == "feature-ios-people-model":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.people_model import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS people_model request") from None
            valid=True
        elif action == "feature-ios-create-work":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.create_work import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS create_work request") from None
            valid=True
        elif action in {"feature-ios-snapshot-owned-files", "feature-ios-snapshot-file-remove"}:
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.snapshot_owned_files import command as observe_command,remove_command
            try:(remove_command if action=="feature-ios-snapshot-file-remove" else observe_command)(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS snapshot owned-file request") from None
            valid=True
        elif action in {"feature-ios-snapshot-work", "feature-ios-snapshot-file-work", "feature-ios-snapshot-exports", "feature-ios-snapshot-captures", "feature-ios-snapshot-inputs", "feature-ios-snapshot-pending-inputs", "feature-ios-snapshot-uploads"}:
            sys.path.insert(0,str(ROOT.parent))
            if action == "feature-ios-snapshot-work":
                from ios.adapters.snapshot_work import command as validate_ios_source
            elif action == "feature-ios-snapshot-file-work":
                from ios.adapters.snapshot_file_work import command as validate_ios_source
            elif action == "feature-ios-snapshot-inputs":
                from ios.adapters.snapshot_inputs import command as validate_ios_source
            elif action == "feature-ios-snapshot-pending-inputs":
                from ios.adapters.snapshot_pending_inputs import command as validate_ios_source
            elif action == "feature-ios-snapshot-captures":
                from ios.adapters.snapshot_captures import command as validate_ios_source
            elif action == "feature-ios-snapshot-uploads":
                from ios.adapters.snapshot_uploads import command as validate_ios_source
            else:
                from ios.adapters.snapshot_exports import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS snapshot source request") from None
            valid=True
        elif action == "feature-ios-avatar-scripts":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.avatar_scripts import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS avatar_scripts request") from None
            valid=True
        elif action == "feature-ios-avatar-entities":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.avatar_entities import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS avatar_entities request") from None
            valid=True
        elif action == "feature-ios-create-entities":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.create_entities import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS create_entities request") from None
            valid=True
        elif action == "feature-ios-pointer-state":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.pointer_state import command as validate_ios_source
            try:validate_ios_source(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS pointer_state request") from None
            valid=True
        elif action == "feature-ios-avatar-state":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.avatar_state import command as avatar_state_command
            try:avatar_state_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS avatar state request") from None
            valid=True
        elif action == "feature-ios-navigation-state":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.navigation_state import command as navigation_state_command
            try:navigation_state_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS native navigation state request") from None
            valid=True
        elif action == "feature-ios-navigation-dialogs":
            sys.path.insert(0,str(ROOT.parent))
            from ios.adapters.navigation_dialogs import command as navigation_dialog_command
            try:navigation_dialog_command(command)
            except (ValueError,RuntimeError):raise ValueError("invalid iOS navigation modal request") from None
            valid=True
        elif action == "feature-web-dom-observe":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_web_dom import command as web_dom_command
            try:web_dom_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid native Web DOM request") from None
            valid=True
        elif action == "feature-chat-view-observe":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_chat_view import command as chat_view_command
            try:chat_view_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid native Chat view request") from None
            valid=True
        elif action == "feature-chat-observe":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_chat_observation import command as chat_command
            try:chat_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid native Chat request") from None
            valid=True
        elif action == "feature-account-probe":
            sys.path.insert(0,str(ROOT.parent))
            from adapters.native_account_probe import command as account_probe_command
            try:account_probe_command(command,ios=True)
            except (ValueError,RuntimeError):raise ValueError("invalid native account probe request") from None
            valid=True
        elif action == "feature-world-render-receipt":
            sys.path.insert(0, str(ROOT.parent))
            from adapters.world_render_receipts import command as world_receipt_command
            world_receipt_command(command, ios=True)
            valid = True
        elif action == "feature-world-render-storage":
            sys.path.insert(0, str(ROOT.parent))
            from adapters.world_render_storage import command as world_storage_command
            world_storage_command(command, ios=True)
            valid = True
        elif action == "feature-script-files":
            sys.path.insert(0, str(ROOT.parent))
            from adapters.native_script_files import command as script_files_command
            try:
                script_files_command(command, ios=True)
            except (ValueError, RuntimeError):
                raise ValueError("invalid native Script file request") from None
            valid = True
        elif action == "normal-feature-observe":
            valid = (set(command) == {"schemaVersion", "commandId", "action", "includeAvatarEntities"}
                     and type(command["schemaVersion"]) is int
                     and re.fullmatch(r"ios-[0-9a-f]{32}", command["commandId"]) is not None
                     and type(command["includeAvatarEntities"]) is bool)
        elif action == "text-fixture":
            valid = (set(command) == {"schemaVersion", "commandId", "action", "operation"}
                     and type(command["schemaVersion"]) is int
                     and re.fullmatch(r"ios-[0-9a-f]{32}", command["commandId"]) is not None
                     and command.get("operation") in {"focus", "snapshot", "dismiss"})
        elif action == "snapshot-files":
            sys.path.insert(0, str(ROOT.parent))
            from snapshot_file_contract import read_request
            read_request(command)
            valid = True
        elif action == "normal-ui-input":
            operation = command.get("operation")
            expected = {"schemaVersion", "commandId", "action", "operation"}
            if operation == "edit":
                expected.add("input")
            valid = (set(command) == expected and type(command["schemaVersion"]) is int
                     and re.fullmatch(r"ios-[0-9a-f]{32}", command["commandId"]) is not None
                     and isinstance(operation, str) and operation in {"observe", "edit"})
            if valid and operation == "edit":
                request = command["input"]
                keys = {"schemaVersion", "commandId", "instance", "sequence", "observedElapsedMs", "fieldToken", "operation"}
                input_operation = request.get("operation") if isinstance(request, dict) else None
                if input_operation == "replace":
                    keys.add("text")
                if input_operation == "select-index":
                    keys.add("index")
                if input_operation == "scroll":
                    keys.add("direction")
                if input_operation == "set-value":
                    keys.add("value")
                uuid_pattern = r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"
                valid = (isinstance(request, dict) and set(request) == keys
                         and type(request["schemaVersion"]) is int and request["schemaVersion"] == 1
                         and isinstance(input_operation, str) and input_operation in {"activate", "replace", "submit", "select-index", "scroll", "set-value"}
                         and all(isinstance(request.get(key), str)
                                 and re.fullmatch(uuid_pattern, request[key]) is not None
                                 and request[key] != "00000000-0000-0000-0000-000000000000"
                                 for key in ("commandId", "instance", "fieldToken"))
                         and type(request.get("sequence")) is int and 1 <= request["sequence"] <= 2**53 - 1
                         and type(request.get("observedElapsedMs")) is int and 0 <= request["observedElapsedMs"] <= 2**53 - 1)
                if valid and input_operation == "replace":
                    text = request["text"]
                    try:
                        valid = (isinstance(text, str) and len(text.encode("utf-16-le")) // 2 <= 4096
                                 and all(ord(character) >= 32 and ord(character) != 127 for character in text))
                    except UnicodeError:
                        valid = False
                if valid and input_operation == "select-index":
                    valid = type(request["index"]) is int and 0 <= request["index"] < 32
                if valid and input_operation == "scroll":
                    valid = request["direction"] in ("up", "down")
                if valid and input_operation == "set-value":
                    valid = type(request["value"]) in (int,float) and 0.1 <= request["value"] <= 2.0
        elif action == "entity-script-consent":
            source = urlsplit(command.get("source") if isinstance(command.get("source"), str) else "")
            valid = (set(command) == {"schemaVersion", "commandId", "action", "operation", "source"}
                     and type(command["schemaVersion"]) is int
                     and re.fullmatch(r"ios-[0-9a-f]{32}", command["commandId"]) is not None
                     and command.get("operation") in {"review", "allow"}
                     and self._web_url(command.get("source"))
                     and source.path == "/scripted_interactable.js"
                     and not source.query and not source.fragment)
        elif action == "scene-load":
            valid = (set(command) == {"schemaVersion", "commandId", "action", "url"}
                     and self._web_url(command.get("url")))
        elif action == "navigate":
            navigation_url = command.get("url")
            parsed = urlsplit(navigation_url if isinstance(navigation_url, str) else "")
            try:
                port = parsed.port
            except ValueError:
                port = None
            valid = (set(command) == {"schemaVersion", "commandId", "action", "url"}
                     and parsed.scheme == "hifi" and bool(parsed.hostname)
                     and port is not None and parsed.username is None
                     and parsed.password is None)
        elif action == "asset-load":
            valid = (set(command) == {"schemaVersion", "commandId", "action",
                                      "assetId", "url", "entityName"}
                     and isinstance(command.get("assetId"), str)
                     and bool(command["assetId"])
                     and isinstance(command.get("entityName"), str)
                     and command["entityName"].startswith("OVERTE_E2E_ASSET_LOAD")
                     and self._web_url(command.get("url")))
        elif action == "sound-channel":
            valid = (set(command) == {"schemaVersion", "commandId", "action", "url"}
                     and self._web_url(command.get("url")))
        elif action == "set-safe-setting":
            valid = (set(command) == {"schemaVersion", "commandId", "action",
                                      "settingId", "enabled"}
                     and command.get("settingId") == "audio.warn-when-muted"
                     and type(command.get("enabled")) is bool)
        elif action == "set-audio-mute":
            valid = (set(command) == {"schemaVersion", "commandId", "action", "muted"}
                     and type(command.get("muted")) is bool)
        elif action == "key-hold":
            valid = (set(command) == {"schemaVersion", "commandId", "action",
                                      "key", "durationMs"}
                     and command.get("key") in {
                         "backward", "down", "forward", "jump", "left", "right", "tablet"
                     }
                     and isinstance(command.get("durationMs"), int)
                     and not isinstance(command["durationMs"], bool)
                     and 50 <= command["durationMs"] <= 10000)
        else:
            valid = False
        if not valid:
            raise ValueError("invalid client command")
        with self._lock:
            self.client_command = dict(command)
            return dict(self.client_command)

    def set_command(self, command: object) -> dict:
        if (not isinstance(command, dict)
                or set(command) != {"schemaVersion", "commandId", "action", "soundUrl"}
                or command.get("schemaVersion") != 1
                or command.get("action") not in {"play", "stop"}
                or not isinstance(command.get("commandId"), str)
                or not command["commandId"]
                or not isinstance(command.get("soundUrl"), str)):
            raise ValueError("invalid sound command")
        if command["action"] == "play" and urlsplit(command["soundUrl"]).scheme not in {
                "http", "https"}:
            raise ValueError("play command requires an HTTP(S) sound URL")
        with self._lock:
            self.command = dict(command)
            return dict(self.command)

    def record_request(self, method: str, target: object, status: int,
                       mime_type: str, bytes_sent: int) -> None:
        with self._lock:
            self._requests.append({
                "sequence": len(self._requests) + 1,
                "epochMs": int(time.time() * 1000),
                "method": method,
                "path": target.path,
                "query": parse_qs(target.query),
                "status": status,
                "mimeType": mime_type,
                "bytesSent": bytes_sent,
            })

    def snapshot_command(self) -> dict:
        with self._lock:
            return dict(self.command)

    def snapshot_client_command(self) -> dict:
        with self._lock:
            return dict(self.client_command)

    def snapshot_requests(self) -> list[dict]:
        with self._lock:
            return [dict(item) for item in self._requests]


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bind", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--public-host",
                        help="host/IP reachable by devices; defaults to --bind")
    parser.add_argument("--ready-file", type=Path,
                        help="atomically write connection metadata after binding")
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--sound-duration-seconds", type=float,
                        help="session-owned PCM duration for slower device observation; default fixture remains unchanged")
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        parser.error("--port must be from 0 through 65535")
    if args.sound_duration_seconds is not None and not 1 <= args.sound_duration_seconds <= 120:
        parser.error("--sound-duration-seconds must be from 1 through 120")
    return args


def main() -> int:
    args = arguments()
    manifest = validate_fixture()
    if args.check:
        from parity_http import load_reference
        load_reference(ROOT)
        print(f"PASS: controlled fixture contains {manifest['expectedEntityCount']} local entities")
        return 0
    handler = partial(FixtureHandler, directory=str(ROOT))
    server = FixtureServer((args.bind, args.port), handler, manifest, args.sound_duration_seconds)
    manifest = server.manifest
    host = args.public_host or args.bind
    if host in {"0.0.0.0", "::"}:
        raise ValueError("--public-host is required when binding all interfaces")
    base_url = f"http://{host}:{server.server_address[1]}"
    server.public_origin = base_url
    asset = manifest["asset"]
    sound_path = manifest["sound"]["path"]
    ready = {"schemaVersion": 1, "baseUrl": base_url,
             "sceneUrl": controlled_scene_url(base_url, manifest),
             "probeScriptUrl": f"{base_url}/overte_e2e_probe.js",
             "clientCommandUrl": f"{base_url}/e2e-client-command.json",
             "asset": {
                 "id": asset["id"], "url": f"{base_url}{asset['route']}",
                 "telemetryUrl": f"{base_url}/telemetry/asset-requests",
                 "contentType": asset["contentType"],
                 "sha256": asset["sha256"], "bytes": asset["bytes"],
                 "width": asset["width"], "height": asset["height"],
                 "entityName": asset["entityName"],
             },
             "soundUrl": f"{base_url}/{sound_path}",
             "invalidSoundUrl": f"{base_url}/audio/invalid.wav",
             "soundCommandUrl": f"{base_url}/sound-command.json",
             "soundRequestsUrl": f"{base_url}/sound-requests.json",
             "sound": manifest["sound"]}
    ready["webParity"] = {
        "pageUrl": f"{base_url}/parity/index.html",
        "scriptUrl": f"{base_url}/parity/client.js",
        "injectionUrl": f"{base_url}/parity/injected.js",
        "mediaUrl": f"{base_url}/parity/reference.mp4",
        "media": server.parity_manifest,
        "acceptance": "pending exact-artifact client observation",
    }
    if args.ready_file:
        args.ready_file.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.ready_file.with_suffix(args.ready_file.suffix + ".tmp")
        temporary.write_text(json.dumps(ready, sort_keys=True) + "\n", encoding="utf-8")
        temporary.replace(args.ready_file)
    print(json.dumps(ready, sort_keys=True), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(2)
