// Copyright 2026 Overte contributors.
// SPDX-License-Identifier: Apache-2.0
#pragma once
#include <QtGlobal>
#if defined(Q_OS_IOS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
#include <QObject>

namespace overte::e2e {
// One process-parent-owned sender per claim. Connections are made while the
// real receiver is alive on its owning thread. A main-thread request emits a
// queued signal; it never checks then dereferences a foreign-thread QPointer.
// Sender lifetime remains explicit parent duty until the original process end.
class IOSAudioOnceCueControl : public QObject {
    Q_OBJECT
public:
    using QObject::QObject;
    void retire() { emit retireRequested(); }
signals:
    void retireRequested();
};
}
#endif
