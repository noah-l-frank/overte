"""Metadata-only explicit terminal custody and immutable assembler inputs.

No project, SDK, vendor, native, or model imports. Called only by a separately
reviewed quiet-window finalizer; importing this module performs no inventory.
"""
import hashlib,json,os,shutil,stat,sys
from pathlib import Path
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path):
    path=Path(path);a=path.lstat();assert not path.is_symlink()and path.resolve(strict=True)==path
    assert stat.S_ISREG(a.st_mode)or stat.S_ISDIR(a.st_mode)
    result=dict(stat=[getattr(a,k)for k in FIELDS])
    if stat.S_ISREG(a.st_mode):result['sha256']=sha(path)
    assert result['stat']==[getattr(path.lstat(),k)for k in FIELDS];return result

def frozen(folder,digest,physical,filename='freeze.json'):
    folder=Path(folder);f=folder/filename;assert sha(f)==digest;physical.add(f)
    value=json.loads(f.read_text());rows=value['files']
    items=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
    for name,row in items:
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        path=folder/name;expected=row if type(row)is str else row['sha256']
        assert sha(path)==expected;physical.add(path)
    return value

def referenced(row,physical):
    assert type(row)is dict and type(row['path'])is str and type(row['sha256'])is str
    path=Path(row['path']);assert sha(path)==row['sha256'];physical.add(path);return path

def root_result(spec,physical):
    folder=Path(spec['path']);frozen(folder,spec['freezeSha256'],physical)
    path=folder/'results.json';body=json.loads(path.read_text());physical.add(path)
    refs=folder/'actual-receipt-references.json';physical.add(refs)
    for row in json.loads(refs.read_text()).values():referenced(row,physical)
    return body

def source5_own5_original(source,repo,args,physical):
    """Actual Root-qualified five-case original receipts, before any output birth."""
    cfg=json.loads((source/'assembler-inputs.json').read_text());spec=cfg['source5Own5']
    folder=Path(args.source5_own5_proof);assert folder.is_absolute()and folder.resolve(strict=True)==folder and folder==Path(spec['path'])
    assert args.source5_own5_freeze==spec['freezeSha256']
    body=root_result(spec,physical)
    boot=cfg['source5Own5Bootstrap'];frozen(boot['path'],boot['freezeSha256'],physical,boot['freezeFile'])
    inputs=json.loads((Path(boot['path'])/'source-inputs.json').read_text())
    expected=inputs['cases'];assert len(expected)==len(set(expected))==5
    assert body['qualifiedCases']==5 and body['selectedIds']==expected
    assert body['sourceFreeze']==cfg['movingUI']['freezeSha256']and body['bootstrapFreeze']==boot['freezeSha256']
    assert body['publicHead']==cfg['expectedPublicHead']and body['actualGenuineTemporaryDirectories']==5 and body['actualNestedStandardCleanups']==35
    for name in('actualParentChildFDThreadKernelDrained','all27PortsCioDupToolsRestored','inputPinAndCliShaAfterDrain','wholeClosedOutputTwiceCensused'):
        assert body[name]is True
    assert body['subjectActualOrigins']==3 and body['realNodeExecutions']==0
    assert body['movingPrimaryOneQualified']is body['nativeQualified']is body['deviceQualified']is body['wholeQualified']is False
    terminal=body['terminal'];assert terminal['status']=='PASS'and terminal['childReturnCode']==0
    for name in('actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allThreeActualModelOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','ownProcessesAbsent','twoFullOwnOutputCensusesEqual'):
        assert terminal[name]is True
    assert not terminal['timedOut']and not terminal['forcedKill']and not terminal['problems']and not terminal['orphansRequiredKill']and terminal['fullOwnCensusExclusions']==[]
    refs=json.loads((folder/'actual-receipt-references.json').read_text())
    def receipt(key):
        path=referenced(refs[key],physical);return json.loads(path.read_text())
    assert receipt('outer/terminal.json')==terminal
    selection=receipt('child/child-receipts/actual-selection.json');assert selection['ids']==expected and selection['loaderErrors']==[]
    report=receipt('child/child-receipts/report.json');assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==5 and report['fatal']is None
    for name in('cleanupEstablished','fdUnchanged','kernelChildrenUnchanged','pinsUnchanged','threadsUnchanged','twoToyCensusesEqual'):
        assert report[name]is True
    assert len(report['retainedTemporaryDirectories'])==5 and report['NodeExecutions']==report['SDKExecutions']==0 and not report['realNetwork']
    cleanup=receipt('child/child-receipts/outer-cleanup.json');assert cleanup['success']and cleanup['nestedActualCleanupSucceeded']and len(cleanup['nestedActualCalls'])==35
    assert all(row['originalReturned']is True and row['remaining']==0 for row in cleanup['nestedActualCalls'])
    ports=receipt('child/child-receipts/actual-port-restoration.json');assert ports['restored']and ports['count']==27 and ports['controlDescriptors']==[]and ports['dupPortsRestored']and ports['toolsRestored']
    origins=receipt('child/child-receipts/actual-source-model-origins.json');assert origins['allThreeActualOriginsEstablished']is True
    assert set(origins['subjectOrigins'])==set(inputs['modules'])and len(origins['subjectOrigins'])==3
    for name,expected_origin in inputs['modules'].items():
        row=origins['subjectOrigins'][name];assert row['actualModulePresent']is row['exactOriginMatched']is True
        assert row['actualModuleFile']==row['actualLoaderExecutedPath']==row['expectedPath']==expected_origin['path']==origins['actualExecutedOrigins'][name]
        assert row['expectedSha256']==expected_origin['sha256']==sha(expected_origin['path'])
    assert args.later_terminal_results is not None
    later=json.loads(Path(args.later_terminal_results).read_text())
    matching=[row for row in later['results']if Path(row['path'])==folder and row['freezeSha256']==spec['freezeSha256']]
    assert len(matching)==1 and matching[0]['newOriginalRoots']==body['newOriginalRoots']
    return body


def admit_external_manifest(args,physical):
    path=Path(args.external_manifest);assert path.is_absolute()and path.resolve(strict=True)==path
    assert sha(path)==args.external_manifest_sha256;physical.add(path)
    value=json.loads(path.read_text());assert type(value)is dict and set(value)=={'modules','namespaces'}
    assert type(value['modules'])is type(value['namespaces'])is dict
    for name,row in value['modules'].items():
        assert type(name)is str and name and type(row)is dict
        assert set(row)=={'path','sha256','package','loader'}and type(row['package'])is bool
        assert row['loader']in('source','extension');file=referenced(row,physical)
        assert file.is_absolute()and file.resolve(strict=True)==file
        if row['loader']=='source':assert file.suffix=='.py'
    for name,roots in value['namespaces'].items():
        assert type(name)is str and type(roots)is list and roots
        for raw in roots:
            path=Path(raw);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_dir();physical.add(path)
    return value

def validate_source7(cfg,physical):
    model=Path(cfg['movingModel']['path']);prior=Path(cfg['source6PhysicalPredecessor']['path'])
    identity=json.loads((model/'physical-predecessor-and-model-identity.json').read_text())
    manifest=json.loads((model/'connected-integration-manifest.json').read_text())
    assert manifest['modelRoot']==str(model/'models')and manifest['source6Codebase']==str(prior)
    assert manifest['source6Freeze']==cfg['source6PhysicalPredecessor']['freezeSha256']
    assert identity['changedFiles']==['lifecycle_moving_raw_ui.py']and identity['originalFiveMovingBodiesUnchanged']is True
    assert identity['byteIdenticalToSource6Files']==12 and identity['modelFiles']==13
    assert identity['pythonFiles']==12 and identity['mjsFiles']==1 and identity['newSource7Qualified']is False
    names=set(identity['files']);assert names=={p.name for p in(model/'models').iterdir()}=={p.name for p in(prior/'models').iterdir()}
    changed=[]
    for name,row in identity['files'].items():
        old=prior/'models'/name;new=model/'models'/name
        assert row['oldPhysicalPath']==str(old)and row['newPhysicalPath']==str(new)
        assert sha(old)==row['oldSha256']and sha(new)==row['newSha256']
        assert row['byteIdenticalToSource6']is(sha(old)==sha(new))
        physical.update((old,new))
        if sha(old)!=sha(new):changed.append(name)
    assert changed==['lifecycle_moving_raw_ui.py']
    assert sha(model/'models/lifecycle_moving_raw_ui.py')=='fc39eb3d900e3783d0d0e00d24eb69c57f867b4c88f9e7a9b3f00b38fcce38f9'
    return identity

def source7_own3_original(source,repo,args,physical):
    cfg=json.loads((source/'assembler-inputs.json').read_text());spec=cfg['source7Own3'];folder=Path(args.source7_own3_proof)
    assert folder.is_absolute()and folder.resolve(strict=True)==folder==Path(spec['path'])
    assert args.source7_own3_freeze==spec['freezeSha256']
    body=root_result(spec,physical);refs=json.loads((folder/'actual-receipt-references.json').read_text());assert len(refs)==42
    frozen(cfg['source7Own3Bootstrap']['path'],cfg['source7Own3Bootstrap']['freezeSha256'],physical,'source-freeze.json')
    expected=json.loads((Path(cfg['movingModel']['path'])/'OWN-REGRESSION-SELECTION.json').read_text())['cases']
    assert len(expected)==len(set(expected))==3 and body['actualIds']==expected and body['qualifiedCases']==3
    assert body['sourceFreeze']==cfg['movingModel']['freezeSha256']and body['bootstrapFreeze']==cfg['source7Own3Bootstrap']['freezeSha256']
    assert body['actualGenuineTemporaryDirectories']==3 and body['actualNestedStandardCleanups']==21 and body['subjectActualOrigins']==5
    for key in('actualInputAndCliShaUnchanged','actualParentChildFDThreadKernelDrained','all27PortsCioDupToolsRestored','all9149SourceBinaryPinsUnchanged','twoWholeOwnCensusesEqual'):assert body[key]is True
    assert body['NodeExecutions']==body['SDKExecutions']==0 and body['realNetwork']is False
    assert body['movingPrimaryOneQualified']is body['nativeQualified']is body['wholeQualified']is False
    assert body['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],status='PASS',timedOut=False)
    def receipt(suffix):
        rows=[row for name,row in refs.items()if name.endswith(suffix)];assert len(rows)==1
        return json.loads(referenced(rows[0],physical).read_text())
    report=receipt('/child-receipts/report.json');assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==3
    for key in('allActualLoadedOriginsAccounted','cleanupEstablished','fdUnchanged','kernelChildrenUnchanged','pinsUnchanged','threadsUnchanged','twoToyCensusesEqual'):assert report[key]is True
    assert len(report['retainedTemporaryDirectories'])==3
    cleanup=receipt('/child-receipts/outer-cleanup.json');assert cleanup['success']and cleanup['nestedActualCleanupSucceeded']and len(cleanup['nestedActualCalls'])==21
    assert all(row['originalReturned']is True and row['remaining']==0 for row in cleanup['nestedActualCalls'])
    ports=receipt('/child-receipts/actual-port-restoration.json');assert ports['restored']and ports['count']==27 and ports['controlDescriptors']==[]and ports['dupPortsRestored']and ports['toolsRestored']
    terminal=receipt('-outer/terminal.json')
    for key in('actualStdlibParentFDThreadDrain','allFiveActualModelOriginsEstablished','allSourceBinaryPinsEqual','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','ownProcessesAbsent','twoFullOwnOutputCensusesEqual'):assert terminal[key]is True
    assert terminal['childReturnCode']==0 and terminal['status']=='PASS'and not terminal['timedOut']and not terminal['forcedKill']and not terminal['problems']and not terminal['orphansRequiredKill']and terminal['fullOwnCensusExclusions']==[]
    for name,row in body['allFiveActualOrigins'].items():
        assert row['actualModulePresent']is row['exactOriginMatched']is True
        assert row['actualModuleFile']==row['actualLoaderExecutedPath']==row['expectedPath']
        assert sha(row['expectedPath'])==row['expectedSha256'];physical.add(Path(row['expectedPath']))
    assert len(body['allFiveActualOrigins'])==5
    later=json.loads(Path(args.later_terminal_results).read_text());matches=[row for row in later['results']if Path(row['path'])==folder and row['freezeSha256']==spec['freezeSha256']]
    assert len(matches)==1 and matches[0]['newOriginalRoots']==body['newOriginalRoots']
    failure=root_result(cfg['source6FailedOriginal'],physical)
    assert failure['sourceFreeze']==cfg['source6PhysicalPredecessor']['freezeSha256']and failure['actualStartedCases']==1 and failure['actualPassedCases']==0 and failure['positiveNodeDrainQualified']is False
    assert failure['terminal']['childReturnCode']==1 and failure['terminal']['ownProcessesAbsent']is True
    helper=root_result(cfg['currentHelperSix'],physical);assert helper['actualPassedCases']==6
    return body

def context_inputs(source,repo,args,physical):
    cfg=json.loads((source/'assembler-inputs.json').read_text())
    source5_own5_original(source,repo,args,physical)
    source7_own3_original(source,repo,args,physical)
    cpath=referenced(cfg['terminalContext'],physical);context=json.loads(cpath.read_text())
    assert context['status']=='ROOT_TERMINAL_CONTEXT_NO_TARGET_NO_GLOBAL_SCAN'
    assert context['globalScans']==context['targets']==0 and context['noWriterExclusions']is True
    baseline_path=referenced(context['base653Baseline'],physical)
    old=json.loads(baseline_path.read_text());assert len(old)==653 and set(old)<=set(context['roots'])
    for key in ('base653Seed','base653InputMap','base653ExternalTerminal','base653Freeze'):referenced(context[key],physical)
    names=set(context['roots']);assert len(names)==660
    assert set(context['additionalOriginalRoots'])==set(context['authoritativeAdditionalOriginalRoots'])
    assert names==set(old)|set(context['additionalOriginalRoots'])
    for name,authority in context['authoritativeAdditionalOriginalRoots'].items():
        f=referenced(authority['freeze'],physical);frozen(f.parent,authority['freeze']['sha256'],physical)
        result_path=referenced(authority['result'],physical)
        refs=f.parent/'actual-receipt-references.json'
        assert refs.exists();physical.add(refs)
        for row in json.loads(refs.read_text()).values():referenced(row,physical)
        result=json.loads(result_path.read_text())
        admitted=result.get('newOriginalRoots',[])
        if not admitted and 'controllerRoot'in result:admitted=[result['controllerRoot'],result['controllerRoot']+'-outer']
        assert name in admitted,'Terminal context authority does not name the original root'
    for spec in cfg['qualifiedAdditions']:
        body=root_result(spec,physical)
        assert body[spec['qualifiedField']]is True and body['actualTests']==spec['actualTests']
        assert body['newOriginalRoots']==spec['newOriginalRoots']
        terminal=body['terminal'];assert terminal['status']=='PASS'and terminal['childReturnCode']==0
        assert terminal['ownProcessesAbsent']and not terminal['timedOut']and not terminal['forcedKill']
        assert body['ports']['restored']is True
        names.update(body['newOriginalRoots'])
    assert len(names)==cfg['rootCountAtAuthoring']==665
    correction=cfg['setupCorrection'];frozen(correction['path'],correction['freezeSha256'],physical)
    own=root_result(cfg['own11'],physical)
    assert own['status']=='ACTUAL_ELEVEN_COUNTERS_PASS_WITH_DISTINCT_ORIGINAL_AND_CONTROLLER_CLEANUP'
    assert len(own['actualCaseReceipts'])==11 and own['NodeExecutions']==0
    assert own['parentDrain']==dict(fdsEqual=True,threadsEqual=True)
    assert not own['kernelDrain']['remaining']and not own['kernelDrain']['timedOut']and not own['kernelDrain']['forced']
    assert own['ports']['count']==27 and own['ports']['restored']
    if args.later_terminal_results is not None:
        path=Path(args.later_terminal_results).resolve(strict=True);physical.add(path)
        later=json.loads(path.read_text());assert later['noWriterExclusions']is True
        for spec in later['results']:
            body=root_result(spec,physical)
            assert body['newOriginalRoots']==spec['newOriginalRoots']
            assert body['status']==spec['status']and type(spec['terminalJustification'])is str and spec['terminalJustification'].strip()
            # A failed test may still have a genuinely drained immutable raw
            # root. Its exact Root result stays a failure; never promote it.
            terminal=body['terminal'];assert terminal['ownProcessesAbsent']is True
            names.update(body['newOriginalRoots'])
    for name in names:
        p=Path(name);assert p.is_absolute()and p.resolve(strict=True)==p and p.is_relative_to(repo)and p.is_dir()
    return old,names

def admit_context(source,repo,args):
    physical=set();old,names=context_inputs(source,repo,args,physical);return old,names,physical

def current_checkout_head(repo):
    assert repo==Path.cwd().resolve(strict=True)and repo.name=='overte-ios-feature-adapters-resume-20261026'
    raw=(repo/'.git').read_text();assert raw.startswith('gitdir: ')
    gd=Path(raw[8:].strip()).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    head=(gd/'HEAD').read_text().strip();assert head.startswith('ref: ')
    value=(common/head[5:]).read_text().strip()
    assert len(value)==40 and all(c in '0123456789abcdef'for c in value)
    return value

def assemble(source,repo,args):
    assert sys.dont_write_bytecode and repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file()
    cfg=json.loads((source/'assembler-inputs.json').read_text())
    assert cfg['currentHeadAdmission']==dict(mode='EXACT_ROOT_EXPECTED_HEAD_AND_ACTUAL_OWN_CURRENT_CHECKOUT',newPublicNamespaceIndependentPinsRequired=True,historicalProofHeadNeverRewritten=True)
    assert args.expected_head==cfg['expectedPublicHead']==current_checkout_head(repo)
    assert args.quiet_receipt.strip()
    physical=set();frozen(source,sha(source/'source-freeze.json'),physical,'source-freeze.json')
    moving=Path(cfg['movingCode']['path']);frozen(moving,cfg['movingCode']['freezeSha256'],physical,'source-freeze.json')
    for key in ('assembler7PhysicalPredecessor','source6PhysicalPredecessor','controller6PhysicalPredecessor','source7Own3Bootstrap','movingModel','movingModelPredecessor','negativeController','assemblerPredecessor','assembler3PhysicalPredecessor','source3PhysicalPredecessor','controller5PhysicalPredecessor','assembler4PhysicalPredecessor','movingUI','assembler5PhysicalPredecessor','source5Own5Bootstrap','source4PhysicalCodebase','assembler6PhysicalPredecessor','a6IndependentGapReview'):
        row=cfg[key];frozen(row['path'],row['freezeSha256'],physical,row['freezeFile'])
    model=Path(cfg['movingModel']['path']);model_prior=Path(cfg['movingModelPredecessor']['path'])
    controller_delta=Path(cfg['negativeController']['path'])
    admit_external_manifest(args,physical)
    assert sha(model/'models/test_lifecycle_moving_raw_constructor_original_models.py')==sha(model_prior/'models/test_lifecycle_moving_raw_constructor_original_models.py')
    selected_model=model;model=Path(cfg['source6PhysicalPredecessor']['path'])
    # Source6 is the COMPLETE Source4 model graph, with only the exact
    # qualified Source5 UI bytes substituted in the same physical directory.
    codebase=Path(cfg['source4PhysicalCodebase']['path']);ui=Path(cfg['movingUI']['path'])
    identity=json.loads((model/'physical-predecessor-and-model-identity.json').read_text())
    source6_manifest=json.loads((model/'connected-integration-manifest.json').read_text())
    assert source6_manifest['modelRoot']==str(model/'models')and source6_manifest['sourceVersion']==6
    assert identity['source4Freeze']['path']==str(codebase/'source-freeze.json')and identity['source4Freeze']['sha256']==cfg['source4PhysicalCodebase']['freezeSha256']
    assert identity['source5Freeze']['path']==str(ui/'source-freeze.json')and identity['source5Freeze']['sha256']==cfg['movingUI']['freezeSha256']
    names=set(identity['files']);assert len(names)==13 and sum(Path(n).suffix=='.py'for n in names)==12 and sum(Path(n).suffix=='.mjs'for n in names)==1
    assert names=={p.name for p in(codebase/'models').iterdir()}=={p.name for p in(model/'models').iterdir()}
    different4=[]
    for name,row in identity['files'].items():
        previous=codebase/'models'/name;current=model/'models'/name
        selected=ui/'models'/name if name=='lifecycle_moving_raw_ui.py'else previous
        assert row['oldPhysicalPath']==str(previous)and sha(previous)==row['oldSha256']
        assert row['newPhysicalPath']==str(current)and sha(current)==row['newSha256']
        assert row['selectedOriginalPhysicalPath']==str(selected)and sha(selected)==row['selectedOriginalSha256']==sha(current)
        assert row['byteIdenticalToSelectedOriginal']is True
        assert row['byteIdenticalToSource4']is(sha(previous)==sha(current))
        if sha(previous)!=sha(current):different4.append(name)
    assert sorted(different4)==cfg['source4ToSource6ExactChangeAllowlist']==['lifecycle_moving_raw_ui.py']
    assert sha(model/'models/lifecycle_moving_raw_ui.py')=='d0375a9296191241998ba5ab025a1b5a226e703472863714930c6a3c184afbda'
    # Source2's original model graph remains historical. Exactly two shared
    # source files legitimately differ; the two idle-native files are copied
    # unchanged from Source4 and cannot be excused by a broad exception.
    old_names={p.name for p in(model_prior/'models').iterdir()}
    assert old_names<=names and sorted(names-old_names)==cfg['source6ExactlyAddedToSource2']==['lifecycle_moving_native_initial_state.py','test_lifecycle_moving_initial_native_state_models.py']
    different2=sorted(name for name in old_names if sha(model_prior/'models'/name)!=sha(model/'models'/name))
    assert different2==cfg['source2ToSource6ExactSharedFileChangeAllowlist']==['lifecycle_moving_raw_constructor_fixture.py','lifecycle_moving_raw_ui.py']
    assert sha(model/'models/lifecycle_moving_raw_constructor_fixture.py')==sha(codebase/'models/lifecycle_moving_raw_constructor_fixture.py')
    assert all(sha(model/'models'/n)==sha(codebase/'models'/n)for n in names if n!='lifecycle_moving_raw_ui.py')

    model=selected_model
    validate_source7(cfg,physical)

    referenced(cfg['historicalAssembler'],physical)
    context_inputs(source,repo,args,physical) # All prerequisite originals BEFORE any destination birth.
    # Canonical Root-approved destination; no symlink parents, no existing tree.
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve().is_relative_to(repo)
    assert dest.parent.resolve(strict=True)==dest.parent and not dest.exists()and not dest.is_symlink()
    assert dest.parent==repo/'.ios-host-tmp'
    def target(path):
        path=Path(path);assert path.resolve().is_relative_to(repo);return path
    def put(name,data):
        p=target(dest/name);assert p.parent==dest and not p.exists()
        with target(p).open('xb')as stream:stream.write(data)
        target(p).chmod(0o600)
    target(dest).mkdir(mode=0o700)
    code_names=('guard.py','root_stage_guard.py','diagnostic_write_guard.py','global_original_corpus.py','moving_host_ports.py','run-selected.py','root-supervise.py','first-case.json','closed_import_origins.py')
    controller_sources={}
    for name in code_names:
        origin=controller_delta/name
        put(name,origin.read_bytes());controller_sources[name]=dict(path=str(origin),sha256=sha(origin))
    stage=target(dest/'first1');target(stage).mkdir(mode=0o700)
    case=target(stage/'case.json');assert not case.exists()
    with target(case).open('xb')as stream:stream.write((moving/'first-case.json').read_bytes())
    target(case).chmod(0o600)
    plan=json.loads((moving/'plan-draft.json').read_text());base=Path(plan['controllerBase']['path'])
    assert plan['sourcePacket']==str(model_prior)and plan['sourceFreezeSha256']==cfg['movingModelPredecessor']['freezeSha256']
    prior_model_root=plan['modelRoot'];assert prior_model_root==str(model_prior/'models')
    assert plan['modelSearchOrder'][0]==prior_model_root
    plan['modelRoot']=str(model/'models');plan['modelSearchOrder'][0]=str(model/'models')
    plan.update(sourcePacket=str(model),sourceFreezeSha256=cfg['movingModel']['freezeSha256'],
        sourceFreezeFile=cfg['movingModel']['freezeFile'],predecessorSourcePacket=str(model_prior),
        predecessorSourceFreezeSha256=cfg['movingModelPredecessor']['freezeSha256'],
        predecessorSourceFreezeFile=cfg['movingModelPredecessor']['freezeFile'],
        movingManifest=str(model/'connected-integration-manifest.json'),
        negativeControllerPacket=str(controller_delta),negativeControllerFreeze=cfg['negativeController']['freezeSha256'],
        negativeControllerFreezeFile=cfg['negativeController']['freezeFile'],controllerExecutorSources=controller_sources,
        sourceSelection='Complete physical Moving Source7: Source6 clock/base/Worker siblings plus actual Own3-qualified manager UI; original five bodies; one Primary selector')
    plan['modelOverrides']=[] # No mixed-directory imported UI alias.
    plan['source4PhysicalCodebase']=cfg['source4PhysicalCodebase']
    source6=Path(cfg['source6PhysicalPredecessor']['path'])
    plan['source6PhysicalComposition']=dict(sourcePacket=str(source6),sourceFreeze=cfg['source6PhysicalPredecessor']['freezeSha256'],
        modelRoot=str(source6/'models'),modelFiles=13,pythonFiles=12,mjsFiles=1,
        source4Codebase=cfg['source4PhysicalCodebase'],originalSource5UI=cfg['movingUI'],
        actualSource6UIPath=str(source6/'models/lifecycle_moving_raw_ui.py'),source6Qualified=False)
    plan['source7PhysicalComposition']=dict(sourcePacket=str(model),sourceFreeze=cfg['movingModel']['freezeSha256'],
        modelRoot=str(model/'models'),modelFiles=13,pythonFiles=12,mjsFiles=1,
        historicalSource6=cfg['source6PhysicalPredecessor'],actualSource7UIPath=str(model/'models/lifecycle_moving_raw_ui.py'),
        own3Prerequisite=cfg['source7Own3'],fullMovingQualified=False)
    plan['clockModelBase']=dict(sourcePacket=str(model),sourceFreeze=cfg['movingModel']['freezeSha256'],
        path=str(model/'models/lifecycle_moving_native_initial_state.py'),sha256=sha(model/'models/lifecycle_moving_native_initial_state.py'),
        codebaseSourcePacket=str(codebase),codebaseSourceFreeze=cfg['source4PhysicalCodebase']['freezeSha256'])
    plan['source5Own5Prerequisite']=dict(cfg['source5Own5'],bootstrapFreeze=cfg['source5Own5Bootstrap']['freezeSha256'])
    plan['source7Own3Prerequisite']=dict(cfg['source7Own3'],bootstrapFreeze=cfg['source7Own3Bootstrap']['freezeSha256'])
    plan['closedOriginController']=cfg['negativeController']
    plan['externalManifestOriginal']=dict(path=str(Path(args.external_manifest)),sha256=args.external_manifest_sha256)
    assert plan['modelRoot']==str(model/'models')and plan['modelSearchOrder'][0]==str(model/'models')

    plan['movingWorkerSource']=dict(path=str(model/'models/lifecycle_moving_raw_worker.py'),pin=None)
    plan['movingNodeScript']=dict(path=str(model/'models/lifecycle_moving_marker_worker.mjs'),pin=None)
    assert plan['cases']==[json.loads((moving/'first-case.json').read_text())['case']]
    assert plan['caseCount']==1 and plan['maximumNodeChildren']==1 and plan['expectedTemporaryDirectoriesPerCase']==3
    assert plan['wallSeconds']==180 and plan['killAfterSeconds']==5
    assert plan['overlays']==json.loads((moving/'plan-draft.json').read_text())['overlays']
    assert len(plan['overlays'])==49 and sum(Path(row['logical']).suffix=='.py'for row in plan['overlays'])==44
    assert len({row['logical']for row in plan['overlays']})==49

    frozen(base,plan['controllerBase']['freezeSha256'],physical)
    for name in ('map-inputs.json','historical-proof-scope.json','historical-clock-prerequisites.json','historical-qualified-instruction-prerequisites.json','historical-qualified-warm-prerequisites.json','historical-qualified-retained-owner-prerequisites.json'):
        put(name,(base/name).read_bytes())
    for row in plan['overlays']:
        logical=Path(row['logical']);assert not logical.is_absolute()and '..'not in logical.parts and logical.parts[:2]==('tests','device')
        if logical.suffix=='.py':
            parts=logical.relative_to('tests/device').with_suffix('').parts
            row['module']='.'.join(parts[:-1]if parts[-1]=='__init__'else parts)
        else:
            assert row['logical'] in ('tests/device/ios/appium_wda_host_ops.js', 'tests/device/ios/original-owner-appium-sources.json', 'tests/device/ios/original-owner-python-sources.json', 'tests/device/ios/source-patches/original-owner-appium/node_modules/appium-ios-remotexpc/scripts/lib/userspace-keeper.mjs', 'tests/device/ios/source-patches/original-owner-appium/node_modules/appium-ios-remotexpc/scripts/tunnel-creation.mjs')
            row['module']=None # Retained physical source; never a Python import alias.
        assert sha(row['path'])==row['sha256']
    node=Path(args.node_executable);assert node.is_absolute()and node.resolve(strict=True)==node
    assert shutil.which('node')is not None and Path(shutil.which('node')).resolve(strict=True)==node
    assert stat.S_ISREG(node.stat().st_mode)and os.access(node,os.X_OK)
    plan['nodeExecutable']=dict(path=str(node),pin=pin(node))
    for key in ('movingNodeScript','movingWorkerSource'):
        plan[key]['pin']=pin(Path(plan[key]['path']))
    assert Path(plan['movingWorkerSource']['path']).parent==Path(plan['movingNodeScript']['path']).parent==model/'models'
    assert Path(plan['movingWorkerSource']['path']).name=='lifecycle_moving_raw_worker.py'
    assert Path(plan['movingNodeScript']['path']).name=='lifecycle_moving_marker_worker.mjs'
    assert sha(Path(plan['movingWorkerSource']['path']))==sha(model_prior/'models/lifecycle_moving_raw_worker.py')
    assert sha(Path(plan['movingNodeScript']['path']))==sha(model_prior/'models/lifecycle_moving_marker_worker.mjs')

    plan.update(status='PRIVATE_DRAFT_UNRUN_REQUIRES_FINAL_PINS_AND_ROOT_REVIEW',publicHead=args.expected_head,historicalProofPublicHead=cfg['historicalPublicHead'],currentHeadAdmission=cfg['currentHeadAdmission'],codeOnlySourcePacket=str(moving),codeOnlySourceFreeze=cfg['movingCode']['freezeSha256'],terminalContext=cfg['terminalContext'],qualifiedTerminalAdditions=cfg['qualifiedAdditions'],rootCountAtAuthoring=665,rootCountIsNotExecutionCap=True)
    put('plan-draft.json',(json.dumps(plan,indent=2,sort_keys=True)+'\n').encode())
    put('moving-prerequisites.json',(json.dumps(dict(own11=cfg['own11'],foreign=cfg['qualifiedAdditions'][0],publisher=cfg['qualifiedAdditions'][1],setupCorrection=cfg['setupCorrection'],source5Own5=cfg['source5Own5'],source4PhysicalCodebase=cfg['source4PhysicalCodebase'],source6PhysicalComposition=plan['source6PhysicalComposition'],source7PhysicalComposition=plan['source7PhysicalComposition'],source7Own3=cfg['source7Own3'],currentHelperSix=cfg['currentHelperSix'],modelOverrides=plan['modelOverrides'],scope='HOST_ONLY_NO_NATIVE_OR_WHOLE_QUALIFICATION'),indent=2,sort_keys=True)+'\n').encode())
    # Full inherited source-freeze and exact executor bytes remain separate.
    code_files={name:sha(dest/name)for name in code_names}
    put('code-preparation-freeze.json',(json.dumps(dict(files=code_files,sourceMovingFreeze=cfg['movingCode']['freezeSha256'],sourceModelFreeze=cfg['movingModel']['freezeSha256'],negativeControllerFreeze=cfg['negativeController']['freezeSha256']),indent=2,sort_keys=True)+'\n').encode())
    return dest
