"""Actual old scene originals remain data; phase advance blocks native reads."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import unittest
from adapters.normal_ui import NativeUIError
from ios.self_tests.assets_whole_observation_fixture import Fixture


class AssetsCheckpointSceneMetadataAuthorityTests(unittest.TestCase):
    def test_actual_phase_advance_preserves_original_read_but_blocks_next_native_scene_query(self):
        f=Fixture(self);f.perform_action(1);f.driver.observe_current('primary')
        scene=f.driver.observers[(1,'primary')].primary_scene['scene']
        reference=scene.originals.expand(scene.state['frames'][0]);original=scene.originals.read(reference)
        endpoint=f.scene_endpoints[(1,'primary')];queries=deepcopy(endpoint.queries);inputs=deepcopy(f.boundary.inputs)
        # This is the actual independent fixture activation, not a patched
        # action guard/native packet or a requested expected state.
        ticket,_row=f.a.activate(2);self.assertNotEqual(scene.action.ticket,ticket)
        self.assertEqual(original,scene.originals.read(reference));scene.frame(original)
        self.assertEqual(queries,endpoint.queries);self.assertEqual(inputs,f.boundary.inputs)
        with self.assertRaises(NativeUIError):scene.capture(f.boundary.monotonic())
        self.assertEqual(queries,endpoint.queries);self.assertEqual(inputs,f.boundary.inputs)
        self.assertEqual(1,len(scene.state['frames']));self.assertIsNone(scene.state['pending'])


if __name__=='__main__':unittest.main()
