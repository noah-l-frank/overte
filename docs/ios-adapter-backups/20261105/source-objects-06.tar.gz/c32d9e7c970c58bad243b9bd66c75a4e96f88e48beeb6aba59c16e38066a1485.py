"""Actual original Source constructor, provider custody and Current7 child.

Root alone executes. SDK/native/OS bytes are explicit raw producer models;
source-local Tasks, sockets, threads, AFC reads and immutable files are real
host resources. No fake-cutoff command exists: End.arm uses the actual seven
readers. This WIP has not executed or qualified the composed parent/Audio End.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import ast,asyncio,hashlib,inspect,json,logging,os,re,signal,socket,sys,threading,time,uuid,weakref
from contextlib import asynccontextmanager,suppress
from contextvars import ContextVar
from copy import deepcopy
from pathlib import Path
from types import ModuleType,SimpleNamespace
from typing import Any,ClassVar,Optional,cast


class ModelBoundaryError(RuntimeError):pass


def selected(path,expected,names,namespace):
    raw=Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected:raise ModelBoundaryError('Pinned source changed')
    tree=ast.parse(raw);nodes=[node for node in tree.body if isinstance(node,ast.ClassDef)and node.name in names]
    if {node.name for node in nodes}!=set(names):raise ModelBoundaryError('Selected class inventory changed')
    module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),*nodes],type_ignores=[])
    exec(compile(ast.fix_missing_locations(module),str(path),'exec'),namespace)
    return hashlib.sha256(ast.dump(module,include_attributes=False).encode()).hexdigest()


def expose(name,**values):
    # No vendor import can escape this explicit module inventory.
    components=name.split('.')
    for index in range(1,len(components)+1):
        key='.'.join(components[:index])
        if key not in sys.modules:
            module=ModuleType(key);module.__path__=[];sys.modules[key]=module
    module=sys.modules[name]
    for key,value in values.items():setattr(module,key,value)
    return module


async def stream_pair():
    local,peer=socket.socketpair();local.setblocking(False);peer.setblocking(False)
    reader,writer=await asyncio.open_connection(sock=local)
    return reader,writer,peer


class DTXModel:
    DEFAULT_CAPABILITIES={}
    def __init__(self,reader,writer):
        self.reader,self._writer=reader,writer;self.peer=TRANSPORT_PEERS.pop(id(writer));self._reader_task=None
        self._closed=False;self._disconnected=asyncio.Event();self._channels={};self._services={}
        self._pending_replies={};self._pending_outgoing_replies=[]
    async def connect(self):self._reader_task=asyncio.create_task(self.reader.read())
    def register_services(self,*_):pass
    async def aclose(self):
        self.peer.close();await self._reader_task;self._writer.close();await self._writer.wait_closed()
        self._channels.clear();self._services.clear();self._pending_replies.clear()
        self._closed=True;self._disconnected.set()


TRANSPORT_PEERS={}
class RSDModel:
    def __init__(self):
        self.process_queries=0;self.service=SimpleNamespace(_writer=None,_reader=None);self.native_pids={'org.overte.model':42,'org.overte.wda.model':84}
    async def start_lockdown_service(self,_):
        reader,writer,peer=await stream_pair();TRANSPORT_PEERS[id(writer)]=peer
        class Service:
            async def _ensure_started(self):return reader,writer
        return Service()


class ProcessControlModel:
    def __init__(self,provider):self.provider=provider
    async def __aenter__(self):return self
    async def __aexit__(self,*_):pass
    async def process_identifier_for_bundle_identifier(self,bundle):
        self.provider.lockdown.process_queries+=1;return self.provider.lockdown.native_pids.get(bundle,0)
    async def kill(self,pid):
        for bundle,value in tuple(self.provider.lockdown.native_pids.items()):
            if value==pid:self.provider.lockdown.native_pids[bundle]=0


class DeviceInfoModel:
    def __init__(self,provider):self.provider=provider
    async def __aenter__(self):return self
    async def __aexit__(self,*_):pass
    async def is_running_pid(self,pid):return pid in self.provider.lockdown.native_pids.values()


class AuthenticationModel:
    def __init__(self,writer):self.writer=writer
    def _writer(self):return self.writer
    async def close(self):self.writer.close();await self.writer.wait_closed()


class StackModel:
    def __init__(self,tun):self.tun=tun
    def stop(self):self.tun._peer.close();self.tun._pend.close()


class TunModel:
    def __init__(self):
        self._peer,self._pend=socket.socketpair();self._closed=False;self.stack=StackModel(self)
    async def close(self):
        try:self.stack.stop()
        except BaseException:
            if hasattr(self,'_original_retirement_watch'):self._original_retirement_watch['stackStopFailed']=True
            raise
        else:
            if hasattr(self,'_original_retirement_watch'):self._original_retirement_watch['stackStopReturned']=True
        self._closed=True


class DialModel:
    def __init__(self):self._server=None;self._relay_tasks=set();self._inflight_dials=set();self._closing=False
    async def close(self):
        self._closing=True;self._server.close();await self._server.wait_closed();self._server=None


class RawSourceModel:
    def __init__(self,tunnel,refs,authentication):
        self._owner=weakref.ref(tunnel);self._refs=tuple(weakref.ref(value)for value in refs);self._authentication=authentication
    def current(self):
        refs=tuple(ref()for ref in self._refs)
        if refs[6].service._writer is None:raise ModelBoundaryError('Original modeled RSD already closed')
        return refs[6],'127.0.0.1'


class UserspaceRsdTunnelModel:
    def original_source(self):return self._source
    async def aclose(self):
        await self._authentication.close()
        for writer,peer in self._streams:
            peer.close();writer.close();await writer.wait_closed()
        await self._dial.close();await self.tun.close();self._watch_stop.set();await self._transport_watcher
        self.rsd.service._writer=None;self.rsd.service._reader=None;self._lockdown._validated_session_source=None
        self._source=None;self._exit_stack=None;self.rsd=None;self.tun=None


async def tunnel_model():
    tunnel=UserspaceRsdTunnelModel();loop=asyncio.get_running_loop();rsd=RSDModel();streams=[]
    for _ in range(3):
        reader,writer,peer=await stream_pair();streams.append((writer,peer))
        if rsd.service._writer is None:rsd.service._reader=reader;rsd.service._writer=writer
    provider=SimpleNamespace(_service=SimpleNamespace(writer=streams[2][0]))
    # These graph nodes must support weak references, as the real SDK graph does.
    class Node:pass
    proxy=Node();proxy._service=provider._service;lockdown=Node();lockdown._validated_session_source=object();client=Node();stack=Node()
    tun=TunModel();dial=DialModel();dial._server=await asyncio.start_server(lambda _r,w:w.close(),'127.0.0.1',0)
    auth=AuthenticationModel(streams[1][0]);refs=(loop,proxy,lockdown,client,tun,dial,rsd,stack)
    tunnel._graph=refs;tunnel._authentication=auth;tunnel._streams=streams;tunnel._dial=dial;tunnel._lockdown=lockdown
    tunnel.rsd=rsd;tunnel.tun=tun;tunnel._exit_stack=stack;tunnel._watch_stop=asyncio.Event()
    tunnel._transport_watcher=asyncio.create_task(tunnel._watch_stop.wait())
    tunnel._source=RawSourceModel(tunnel,refs,auth);return tunnel


def install_sdk_models(config):
    provider_module=expose('pymobiledevice3.dtx_service_provider')
    observer=ContextVar('model_original_keeper_resource_observer',default=None)
    namespace=dict(__name__=provider_module.__name__,logging=logging,ContextVar=ContextVar,_socket=socket,
        Any=Any,ClassVar=ClassVar,Optional=Optional,cast=cast,Self=Any,Version=lambda _:None,
        DTXConnection=DTXModel,DTXService=object,LockdownServiceProvider=object,RemoteServiceDiscoveryService=RSDModel,
        ORIGINAL_KEEPER_RESOURCE_OBSERVER=observer)
    provider_ast=selected(config['provider']['path'],config['provider']['sha256'],{'DtxServiceProvider'},namespace)
    provider=namespace['DtxServiceProvider'];provider_module.DtxServiceProvider=provider;provider_module.ORIGINAL_KEEPER_RESOURCE_OBSERVER=observer
    class DvtProviderModel(provider):
        SERVICE_NAME='model.shim.remote';RSD_SERVICE_NAME='model.shim.remote'
    expose('pymobiledevice3.services.dvt.instruments.dvt_provider',DvtProvider=DvtProviderModel)
    expose('pymobiledevice3.services.dvt.instruments.process_control',ProcessControl=ProcessControlModel)
    expose('pymobiledevice3.services.dvt.instruments.device_info',DeviceInfo=DeviceInfoModel)
    expose('pymobiledevice3.remote.userspace_tunnel',UserspaceRsdTunnel=UserspaceRsdTunnelModel)
    namespace=dict(asyncio=asyncio,inspect=inspect,weakref=weakref,uuid=uuid,re=re,time=time,threading=threading,
        os=os,json=json,deepcopy=deepcopy,suppress=suppress,asynccontextmanager=asynccontextmanager,LaunchError=ModelBoundaryError,
        BUNDLE_ID=re.compile(r'[A-Za-z0-9][A-Za-z0-9-]*(?:\.[A-Za-z0-9][A-Za-z0-9-]*)+'))
    wrapper_ast=selected(config['wrapper']['path'],config['wrapper']['sha256'],{'OriginalKeeperSource','OriginalKeeperOperations'},namespace)
    return namespace,dict(providerAstSha256=provider_ast,wrapperAstSha256=wrapper_ast)




def emit(value):
    sys.stdout.write(json.dumps(value,separators=(',',':'))+'\n');sys.stdout.flush()


async def main(config):
    # All SDK MODEL aliases and receiver globals are selected before the actual
    # OriginalKeeperSource constructor and OriginalKeeperOperations birth.
    from urllib.parse import quote
    from audio_original_current_producer import RawAudioCurrentProducer
    root=Path(config['root']);producer=RawAudioCurrentProducer(root/'native-originals',pid=config.get('nativePid',42))
    namespace,source_bindings=install_sdk_models(config)
    class RawWdaServiceClient:
        def __init__(self,rsd,*,port,timeout):
            if port!=8100 or timeout!=2.:raise ModelBoundaryError('Undeclared WDA boundary')
            self.rsd=rsd
        async def _request_json(self,method,path,value):
            if method!='POST'or not path.endswith('/wda/apps/state')or value!={'bundleId':producer.bundle_id}:
                raise ModelBoundaryError('Undeclared WDA request')
            return dict(value=4 if self.rsd.native_pids.get(producer.bundle_id)==producer.pid else 1)
    namespace.update(WdaServiceClient=RawWdaServiceClient,quote=quote)
    expose('pymobiledevice3.services.house_arrest',HouseArrestService=producer.service_type())
    Source,Operations=namespace['OriginalKeeperSource'],namespace['OriginalKeeperOperations']
    tunnel=await tunnel_model();tunnel.rsd.native_pids[producer.bundle_id]=producer.pid
    source=Source(tunnel);owner=Operations(source,root)
    owner.wda_stop=asyncio.Event();owner.wda_session='model-wda';owner.wda_binding_claimed=True
    provider_type=sys.modules['pymobiledevice3.services.dvt.instruments.dvt_provider'].DvtProvider
    wda_ready=asyncio.Event()
    async def modeled_wda():
        async with provider_type(tunnel.rsd),provider_type(tunnel.rsd),provider_type(tunnel.rsd):
            wda_ready.set();await owner.wda_stop.wait()
    owner.wda=asyncio.create_task(modeled_wda());await wda_ready.wait()
    await asyncio.get_running_loop().run_in_executor(None,lambda:42)
    stop=asyncio.Event();loop=asyncio.get_running_loop();loop.add_signal_handler(signal.SIGTERM,stop.set)
    reader=asyncio.StreamReader(limit=16385);pipe,_=await loop.connect_read_pipe(lambda:asyncio.StreamReaderProtocol(reader),sys.stdin.buffer)
    stopping=asyncio.create_task(stop.wait());source.register_control_task('stopping',stopping,stop.wait)
    leaks=[];failures=[];emit(dict(schemaVersion=2,event='owner-ready',ownerInstance=owner.instance))
    async def dispatch(request):
        operation=request['operation']
        try:
            if operation=='fixture-native-query':
                # Only a RAW native response is produced. The actual Current7
                # issues HTTP, reads/stats/closes AFC and creates its own proof.
                result=producer.produce(request['args']['query'])
            elif operation=='fixture-native-file':
                packet=producer.file(request['args']['path']).read_bytes()
                import base64
                result=dict(contentBase64=base64.b64encode(packet).decode())
            elif operation=='fixture-fault':
                if set(request['args'])!={'fault'}or request['args']['fault']not in (None,'wrong-ui-nonce','unregistered-task'):
                    raise ModelBoundaryError('Unknown declared fault')
                producer.fault=request['args']['fault']
                if producer.fault=='unregistered-task':leaks.append(asyncio.create_task(asyncio.Event().wait()))
                result=dict(fault=producer.fault)
            elif operation=='fixture-current-inventory':
                result=dict(queries=deepcopy(producer.queries),nativeInstance=producer.native_instance,
                    currentOwners={role:dict(frames=len(current.frames),ioPending=deepcopy(current.io_pending),pending=deepcopy(current.pending))for role,current in owner._lifecycle_current.items()},
                    serviceSocketFds=[[s.fileno()for s in service.sockets]for service in producer.services],
                    openFileHandles=len(producer.handles),failures=deepcopy(failures),sourceBindings=source_bindings,
                    actualSourceConstructor=True,nativePacketsModeled=True,physicalSDKModeled=True,
                    resourceQualified=False,parentEndArchiveQualified=False,readmissionQualified=False)
            else:
                # There is deliberately no modeled-cutoff operation here.
                # The original End.arm MUST use actual OriginalLifecycleCurrent.
                result=await owner.execute(operation,request['args'],request['sessionId'])
            packet=dict(schemaVersion=2,requestId=request['requestId'],ownerInstance=owner.instance,status='complete',result=result)
        except BaseException as error:
            failures.append(dict(operation=operation,error=type(error).__name__))
            packet=dict(schemaVersion=2,requestId=request['requestId'],ownerInstance=owner.instance,status='failed',result=None)
        owner.issued[request['requestId']]['original']=packet;emit(packet)
    try:
        while not stop.is_set():
            reading=asyncio.create_task(reader.readline());source.register_control_task('reading',reading,reader.readline)
            done,_=await asyncio.wait({reading,stopping},return_when=asyncio.FIRST_COMPLETED)
            if stopping in done:
                reading.cancel();await asyncio.gather(reading,return_exceptions=True);break
            line=reading.result()
            if not line:break
            request=json.loads(line)
            if (len(line)>16384 or not line.endswith(b'\n')or b'\0'in line or b'\r'in line
                or type(request)is not dict or set(request)!={'schemaVersion','ownerInstance','requestId','operation','sessionId','args'}
                or type(request['schemaVersion'])is not int or request['schemaVersion']!=2
                or request['ownerInstance']!=owner.instance or type(request['requestId'])is not str
                or re.fullmatch('[0-9a-f]{32}',request['requestId'])is None or type(request['args'])is not dict):
                raise ModelBoundaryError('Explicit fixture protocol refused malformed request')
            previous=owner.issued.get(request['requestId'])
            if previous is not None:
                if previous['request']!=request:raise ModelBoundaryError('Original request changed')
                if previous['original']is not None:emit(previous['original'])
                continue
            if len(owner.issued)>=4096 or len(owner.operations)>=32:raise ModelBoundaryError('Original bounded issue inventory exceeded')
            owner.issued[request['requestId']]=dict(request=deepcopy(request),original=None,task=None)
            task=asyncio.create_task(dispatch(request));owner.issued[request['requestId']]['task']=task
            owner.operations.add(task);task.add_done_callback(owner.operations.discard)
    finally:
        stopping.cancel();await asyncio.gather(stopping,return_exceptions=True)
        for task in leaks:task.cancel()
        await asyncio.gather(*leaks,return_exceptions=True)
        await asyncio.gather(*tuple(owner.operations),return_exceptions=True)
        if not owner.wda.done():owner.wda_stop.set();await owner.wda
        for service in producer.services:
            if not service.closed:await service.aclose()
        for handle in tuple(producer.handles):producer.handles.pop(handle).close()
        if tunnel._source is not None:await tunnel.aclose()
        pipe.close()


if __name__=='__main__':
    config=json.loads(Path(sys.argv[1]).read_text());asyncio.run(main(config))
