"""Fresh actual function/descriptor/closure custody, including real decorators.

No class-module globals assumption: contextlib and operation wrappers retain
and recheck their genuine defining module, source path and generator closure.
This is a controlled-host harness check, not a hostile-callback/performance seal.
"""
from pathlib import Path
from types import FunctionType
import sys

class MethodCustody:
    def __init__(self,physical,pin):self.physical,self.pin=physical,pin;self.functions=[];self.members=[];self.classes=[];self.allowed_replacement=None
    def function(self,fn):
        assert type(fn)is FunctionType
        while fn is not None:
            assert type(fn)is FunctionType
            if any(fn is row[0]for row in self.functions):return
            namespace=fn.__globals__;module=sys.modules[namespace['__name__']]
            assert vars(module)is namespace
            path=Path(module.__file__).resolve(strict=True)
            assert str(path)in self.physical and self.pin(path)==self.physical[str(path)]
            assert Path(fn.__code__.co_filename).resolve(strict=True)==path
            cells=fn.__closure__;values=()if cells is None else tuple(cell.cell_contents for cell in cells)
            assert len(fn.__code__.co_freevars)==len(values)
            attributes=tuple(vars(fn).items());wrapped=vars(fn).get('__wrapped__')
            assert wrapped is None or type(wrapped)is FunctionType
            defaults=fn.__defaults__;kwdefaults=fn.__kwdefaults__
            kwrows=None if kwdefaults is None else tuple(kwdefaults.items())
            self.functions.append((fn,fn.__code__,namespace,module,path,cells,values,attributes,defaults,kwdefaults,kwrows,wrapped))
            fn=wrapped
    def bind(self,cls,names):
        self.classes.append((cls,cls.__mro__))
        for name in names:
            raw=vars(cls)[name]
            fn=raw.__func__ if type(raw)in(staticmethod,classmethod)else raw
            self.function(fn);self.members.append((cls,name,raw))
    def allow_measured_constructor(self,cls,original,replacement):
        assert self.allowed_replacement is None and vars(cls)['__init__']is original
        self.function(original);self.function(replacement)
        self.allowed_replacement=(cls,original,replacement)
    def check(self):
        for cls,mro in self.classes:
            assert len(cls.__mro__)==len(mro)and all(a is b for a,b in zip(cls.__mro__,mro))
        for cls,name,raw in self.members:
            actual=vars(cls)[name]
            if self.allowed_replacement is not None and cls is self.allowed_replacement[0]and name=='__init__':
                assert actual is raw or actual is self.allowed_replacement[2]
            else:assert actual is raw
        for fn,code,namespace,module,path,cells,values,attributes,defaults,kwdefaults,kwrows,wrapped in self.functions:
            assert fn.__code__ is code and fn.__globals__ is namespace and sys.modules.get(namespace['__name__'])is module and vars(module)is namespace
            assert Path(module.__file__).resolve(strict=True)==path and self.pin(path)==self.physical[str(path)]
            assert fn.__closure__ is cells and fn.__defaults__ is defaults and fn.__kwdefaults__ is kwdefaults
            current=()if cells is None else tuple(cell.cell_contents for cell in cells)
            assert len(current)==len(values)and all(a is b for a,b in zip(current,values))
            current=tuple(vars(fn).items());assert len(current)==len(attributes)
            assert all(a[0]==b[0]and a[1]is b[1]for a,b in zip(current,attributes))
            if kwrows is not None:
                current=tuple(kwdefaults.items());assert len(current)==len(kwrows)
                assert all(a[0]==b[0]and a[1]is b[1]for a,b in zip(current,kwrows))
            assert vars(fn).get('__wrapped__')is wrapped
        return dict(actualFunctions=len(self.functions),actualClassMembers=len(self.members),freshCheck=True,wholeAssetsQualified=False)
