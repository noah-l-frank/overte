"""UNRUN fixed90+kill5 diagnostic parent; Root review/grant required."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import time

HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    before=path.lstat();assert stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode),str(path)
    row={key:getattr(before,key) for key in FIELDS}
    if stat.S_ISREG(before.st_mode):
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(fd,'rb') as stream:
            actual=os.fstat(stream.fileno());assert actual.st_dev==before.st_dev and actual.st_ino==before.st_ino
            row['sha256']=hashlib.sha256(stream.read()).hexdigest()
    assert all(getattr(path.lstat(),key)==row[key] for key in FIELDS),str(path)
    return row
def save(path,value):
    with path.open('w') as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def proc(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
plan=json.loads((HERE/'plan.json').read_text());frozen=json.loads((HERE/'freeze.json').read_text())
for name,sha in frozen['files'].items():assert pin(HERE/name)['sha256']==sha,name
ready_path=HERE/'actual-source-chain-after-publication.json'
ready=json.loads(ready_path.read_text());ready_pin=pin(ready_path)
assert ready['status']=='ACTUAL_98_AFTER_CORRECTED_SOURCE_PUBLICATION' and ready['sourceChain']==plan['expectedSourceChain']
for row in json.loads((HERE/'input-freezes.json').read_text()):
    packet=REPO/row['path'];assert pin(packet/'freeze.json')['sha256']==row['freezeSha256']
    for name,sha in json.loads((packet/'freeze.json').read_text())['files'].items():assert pin(packet/name)['sha256']==sha
prior_expected=json.loads((HERE/'retained-prior-attempt-pins.json').read_text())
def prior_attempts():return {name:pin(REPO/name) for name in prior_expected}
assert prior_attempts()==prior_expected,'Old diagnostic/cold originals or logs changed'
assert not list(HERE.glob('first-*')),'No unchanged diagnostic retry'
guard=plan['unchanged25Guard'];assert pin(REPO/guard['path'])['sha256']==guard['sha256']
for name,sha in plan['expectedSourceChain'].items():assert pin(REPO/name)['sha256']==sha,name
assert {str(path.relative_to(REPO)) for path in (REPO/'tests/device/ios/adapters').glob('snapshot_*.py')}=={name for name in plan['expectedSourceChain'] if name.startswith('tests/device/ios/adapters/snapshot_')},'Snapshot source membership changed'
original_root=REPO/plan['originalRoot'];expected=json.loads((HERE/'original-pins.json').read_text())
def originals():return {str(path.relative_to(REPO)):pin(path) for path in (original_root,*sorted(original_root.rglob('*')))}
def sources():
    names=subprocess.check_output(['rg','--files','-0',*plan['sourceRoots']],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name and '__pycache__' not in Path(name).parts}
    paths.update(REPO/name for name in plan['explicitPins']);paths.update(HERE/name for name in frozen['files']);paths.add(HERE/'freeze.json');paths.add(ready_path)
    for row in json.loads((HERE/'input-freezes.json').read_text()):
        packet=REPO/row['path'];paths.add(packet/'freeze.json')
        paths.update(packet/name for name in json.loads((packet/'freeze.json').read_text())['files'])
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}
assert originals()==expected,'Old425 originals changed before diagnostic'
root=Path(tempfile.mkdtemp(prefix='first-',dir=HERE));root.chmod(0o700)
before=sources();save(root/'sources-before.json',before);save(root/'originals-before.json',expected)
environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=os.pathsep.join(str(REPO/path) for path in plan['apiPYTHONPATH']))
command=['/usr/bin/timeout','--signal=TERM','--kill-after=5','90',sys.executable,'-B',str(HERE/'probe.py'),str(root)]
print('ACTUAL_DIAGNOSTIC_OUTPUT',root,flush=True)
started=time.monotonic()
with (root/'raw.log').open('wb') as log:
    worker=subprocess.Popen(command,cwd=REPO,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    timeout_binding=proc(worker.pid);assert timeout_binding is not None
    bindings={worker.pid:timeout_binding}
    save(root/'process-bindings.json',dict(command=command,timeout=timeout_binding,children=[]))
    while worker.poll() is None:
        for candidate in Path('/proc').iterdir():
            if candidate.name.isdecimal():
                row=proc(int(candidate.name))
                if row is not None and (row['processGroup']==timeout_binding['processGroup'] or row['session']==timeout_binding['session']):bindings[row['pid']]=row
        save(root/'process-bindings.json',dict(command=command,timeout=timeout_binding,children=list(bindings.values())))
        time.sleep(0.05)
    code=worker.wait();log.flush();os.fsync(log.fileno())
def owned():
    rows=[]
    for candidate in Path('/proc').iterdir():
        if candidate.name.isdecimal():
            row=proc(int(candidate.name))
            if row is not None and (row['processGroup']==timeout_binding['processGroup'] or row['session']==timeout_binding['session']):rows.append(row)
    for original in bindings.values():
        current=proc(original['pid'])
        if current is not None and current['startTicks']==original['startTicks'] and current not in rows:rows.append(current)
    return rows
gone_before=owned();first=originals();second=originals();after=sources();gone_after=owned();prior_after=prior_attempts()
save(root/'originals-first.json',first);save(root/'originals-second.json',second);save(root/'sources-after.json',after)
report=dict(actualExitCode=code,elapsedSeconds=time.monotonic()-started,sourcePins=len(before),sourcesUnchanged=before==after,
    originalFiles=sum('sha256' in row for row in expected.values()),originalNodes=len(expected),originalsUnchanged=expected==first==second,
    remainingOwnedBeforeCensuses=gone_before,remainingOwnedAfterCensuses=gone_after,timeoutSeconds=90,killAfterSeconds=5,
    priorAttemptsUnchanged=prior_after==prior_expected,sourceChainReadyUnchanged=pin(ready_path)==ready_pin,authority=False,wholeQualified=False)
save(root/'supervisor-result.json',report);print(json.dumps(report,sort_keys=True),flush=True)
assert before==after and expected==first==second and prior_after==prior_expected and pin(ready_path)==ready_pin and not gone_before and not gone_after,'Source/original/process guard failed'
raise SystemExit(code)
