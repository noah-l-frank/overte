from pathlib import Path
import ast,json
r=Path.cwd().resolve();assert r.name=='overte-ios-feature-adapters-resume-20261026'and(r/'.git').is_file()
p=r/'.ios-host-tmp/c24-diagnostic-source3-closed-utility14-bootstrap1-code-preparation-20261104';assert p.resolve().is_relative_to(r)
b=r/'.ios-host-tmp/moving-c11-process-observation-own4-bootstrap1-code-preparation-20261104'
def put(n,t):
 f=p/n;assert f.resolve().is_relative_to(r);f.write_text(t)
t=(p/'prepare.py').read_text();a=t.index("    for row in json.loads((SUBJECT/");z=t.index('    current_qualification',a)
t=t[:a]+"    frozen(REPO/'.ios-host-tmp/assets-c24-policy-value-bounded-diagnostic-source2-owned-secondary-restoration-private-20261104','source-freeze.json','c0c98bf83d9198c4e20291c3978a435ed216f498a2b8c15a483448128538bfc2',physical)\n"+t[z:]
t=t.replace("utilityQualification=None,diagnosticAdmission=None,assetsPhaseQualified=False)","utilityQualification=None,diagnosticAdmission=None,assetsPhaseQualified=False,historicalApplicationReferenceLedgerRole='Pinned literal source metadata only; original C24 raw log/phase outputs are not utility inputs.')")
put('prepare.py',t)
t=(p/'run-fourteen.py').read_text().replace('retained=[];retained_objects=[];cleanup_calls=[]\n','')
t=t.replace("raise RuntimeError('Only original controlled Python Popen is admitted; no network/native/signal/other exec')","raise RuntimeError('Utility14 admits no subprocess/network/native/signal/other exec')")
t=t.replace('    if code in code_objects:return','    if any(code is item for item in code_objects):return')
t=t.replace("    raise RuntimeError('Utility14 has zero temporary-directory constructors')","    td_callers.append(dict(positionalCount=len(args),keywordNames=sorted(kwargs)))\n    raise RuntimeError('Utility14 has zero temporary-directory constructors')")
put('run-fourteen.py',t)
t=(b/'supervise-four.py').read_text().replace('four genuine C11 state-observation utility counters','fourteen pure C24 diagnostic utility counters').replace('PRIVATE_MOVING_C11_STATE_UTILITY4_UNRUN','PRIVATE_C24_DIAGNOSTIC_SOURCE3_UTILITY14_UNRUN').replace('exact-four-selectors.json','exact-fourteen-selectors.json').replace("len(plan['cases'])==4","len(plan['cases'])==14").replace("str(HERE/'run-four.py')","str(HERE/'run-fourteen.py')")
a=t.index('# Original constructor receipts');z=t.index('def observe(row):',a)
t=t[:a]+'''# No case child is admitted. Only the genuine outer-created runner original
# may ever enter owned/signal bindings; all discovered extra PIDs are errors.
''' +t[z:]
a=t.index('    # After the writer exits');z=t.index('    if born is not None:',a)
t=t[:a]+t[z:]
t=t.replace('if len(selected)>6:','if len(selected)>1:')
t=t.replace("'run-four.py','supervise-four.py'","'run-fourteen.py','supervise-fourteen.py'")
t=t.replace("allFourActualRuntimeOriginsEstablished","allTwoActualRuntimeOriginsEstablished").replace("plan['subjectOriginCount']==4","plan['subjectOriginCount']==2")
a=t.index("    ledger_path=HERE/'child-receipts/actual-utility-children.json'");z=t.index('    parent_fd_after=fds()',a)
t=t[:a]+'''    no_case_children=set(owned)=={born['pid']}and not(set(discovered)-{born['pid']})
    case_rows=[]
    for index in range(1,15):
        path=HERE/('child-receipts/standard-case-'+str(index)+'.json')
        if path.is_file():case_rows.append(json.loads(path.read_text()))
    cases_ok=len(case_rows)==14 and[row['id']for row in case_rows]==plan['cases']
    cases_ok=cases_ok and all(row['standardStopAfterCleanup']and row['remainingStandardCleanups']==0 and row['originalMethodsUnchanged']and row['monitorMasksSlotsUnchanged']and row['fdUnchanged']and row['threadsUnchanged']and row['kernelChildrenUnchanged']for row in case_rows)
''' +t[z:]
t=t.replace("report['testsRun']==4 and report['actualCaseReceipts']==4 and report['PythonExecutions']==5","report['testsRun']==14 and report['actualCaseReceipts']==14 and report['PythonExecutions']==0")
t=t.replace('passed_ledger and observations_ok and origins_ok','no_case_children and cases_ok and origins_ok')
t=t.replace("allTwoActualRuntimeOriginsEstablished=origins_ok,actualFiveGenuineUtilityChildrenEstablished=ledger_ok,PythonExecutions=None if ledger is None else len(ledger),\n        actualFourStateObservationsEstablished=observations_ok,NodeExecutions=0,movingQualified=False","allTwoActualRuntimeOriginsEstablished=origins_ok,zeroCaseChildBirthsEstablished=no_case_children,PythonExecutions=0,\n        actualFourteenCaseReceiptsEstablished=cases_ok,NodeExecutions=0,assetsPhaseQualified=False")
t=t.replace('actualUtilityCases=4','actualUtilityCases=14').replace('movingAdmissionQualified=False','diagnosticAdmission=None,assetsPhaseQualified=False')
put('supervise-fourteen.py',t)
put('ROOT-PLAN.md','''# C24 Source3 closed Utility14 Bootstrap1

SOURCE ONLY / UNRUN / diagnosticAdmission=None / utilityQualification=None. Root alone may invoke the preparer and then one separately reviewed fixed14 selection. No diagnostic C24/phase test is selected. Current Source3 original14 methods and helper bytes are copied exactly; Source2/Source1/F5 actual negative/source references stay historical. No future Root proof schema or C24/normalAction2/native/Whole verdict is supplied.

One -S/-B fresh original interpreter, fixed30+5 outer, no case subprocess/Node/SDK/network/native/device/TD. The existing fourth counter constructs one actual thread and joins it with its unchanged original2-second bounds; other13 cases use the same main thread. No body/clock/cap is rewritten. Original Thread/class/function globals and actual case sources remain genuine. There is no additional sys.monitoring/profile meta-observer or callback wrapper: the two new c_return cases must see the actual original C-port return. The harness never calls a getter to fabricate unavailable old callback information.

The runner snapshots actual monitoring tool names/global and local masks for all recursively held compiled subject/test code before/after every original case, and actual port object identities. The selected original bodies themselves retain and assert their real previous callback objects and own teardown; these are their tested API operations, not a claim that a global callback getter exists. No independent whole-interpreter callback inspection or atomic C-return ledger guarantee is claimed. Unknown observer state must stay nongreen inside the negative cases while their separately actual counter-owned cleanup can succeed. Any actual assertion/cleanup/restoration failure is an actual utility failure, never expected-green outside these original counter assertions.

Root metadata CLI, not run here: original Python -S -B prepare.py --source-freeze <actual bootstrap SHA> --expected-head <actual Root HEAD> --destination <absolute fresh c24-diagnostic-utility14-prepared-*>. Preparer imports only trusted metadata helpers/stdlib, never the diagnostic/test module. Physical pinning retains the exact Source3/Source2 packets and current C10d69093/fcfbc2 genuine6+8/141refs/sixrooms algorithm qualification, explicit original strict7/shared stdlib sources, complete actual interpreter stdlib source/extension origins. No site/dist-packages or unrelated external fallback. The frozen original application reference ledger remains data; no prior C24 raw log/phase output or global corpus is consumed by this utility. Actual current checkout is admitted by explicit expected-head equality, with original worktree Git files pinned read-only; no Git command/index refresh is introduced.

Root entry: original -S -B supervise-fourteen.py <approved-input SHA>. Outer holds exact original runner birth/fullPID-parent-PGID-SID-startTicks; parent discovery is stat-only and performs no foreign exe read. Extra descendants remain unowned/nongreen; no observation creates rescue identity. TERM/KILL only on immediate rechecked original binding at30+5; any timeout, signal rescue, extra/remaining PID, source/port/origin mismatch is nongreen. Target code has zero process/signal/socket/native authority. Original unittest doCleanups and separate outer drain record original returns/outcome transitions/new callback errors without treating a primary-test failed return as proof of a new cleanup exception.

Byte-exact E458 restricts all ordinary writes/canonical paths/FD/dir_fd/control custody to ownRoot and protects source/input/log descriptors. No original source is rewritten, no package/installation/cache is changed. Final own27OS/CIO/dup/profile/monitor/signal/class-method restoration is mandatory. Actual source2 helper metadata/old12 methods are retained; intentional counter-local code/member mutations must be genuinely restored before after-case method/origin checks pass.

After actual wait/runner and extra-PID absence, outer takes two complete HERE censuses including input, controller code/metadata and every output. Reports reside in sibling outer. Two final complete HERE+outer censuses then reside in a third censuses room, with no exclusions, alongside actual standalone CLI input SHA/metadata and all source/binary/HEAD/FD/thread/kernel/selection/standard cleanup gates. Zero old application corpus/global scans are needed; any current external Root guard is attached by Root separately. No source import, builder, map, process/thread/test, target, census, public or Git operation occurred during authoring.
''')
put('RESOURCE-RECIPE.json',json.dumps(dict(status='SOURCE_ONLY_UNRUN_NONE_GATES',cases=14,wallSeconds=30,killGraceSeconds=5,caseChildren=0,NodeExecutions=0,SDKExecutions=0,network=False,nativeQueries=0,temporaryDirectories=0,joinedThreadCases=1,unchangedJoinedThreadSeconds=2,oldApplicationCorpusInputs=0,globalScans=0,diagnosticAdmission=None,utilityQualification=None),indent=2)+'\n')
for f in p.glob('*.py'):ast.parse(f.read_text(),filename=str(f))
print('AST-only complete source, no imports/builders/targets/censuses')
