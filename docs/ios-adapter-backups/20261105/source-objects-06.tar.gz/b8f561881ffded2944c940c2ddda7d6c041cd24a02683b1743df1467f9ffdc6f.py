"""Two separately selected readonly historical probes; no normal action retry.

UNRUN. Root must pin these operands, their complete869-entry original tree and
all actual source origins BEFORE importing this test or reading its headers.
Measured phase time includes cProfile overhead. Repeated snapshot calls are
independent complete original proofs, not current observations or cache hits.
"""
from pathlib import Path
import cProfile
import hashlib
import json
import os
import stat
import sys
import time
import unittest

from adapters.normal_feature_state import PrivateFeatureState
from adapters.native_clock_join import NativeClockAcquisition
from adapters.native_feature_observation import NativeFeatureObservation
from adapters.original_file_reads import collect, readonly
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.audio_passive_journal import AudioPassiveJournal
from ios.adapters.audio_passive_owner import IOSAudioPassiveOwner


MEASURED = {}
CLOSED_PHASES = []
SOURCE = Path(__file__).resolve().parent


def pin(path):
    """Known regular operands only; never enumerates the input root."""
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    def stable(info):
        return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
                info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
    try:
        info = os.fstat(descriptor)
        assert stable(info) == stable(before)
        with os.fdopen(descriptor, 'rb', closefd=False) as stream:
            raw = stream.read()
        assert stable(os.fstat(descriptor)) == stable(info) == stable(path.lstat())
    finally:
        os.close(descriptor)
    return raw, dict(device=before.st_dev, inode=before.st_ino,
        mode=before.st_mode, uid=before.st_uid, gid=before.st_gid,
        nlink=before.st_nlink, bytes=before.st_size,
        mtimeNs=before.st_mtime_ns, ctimeNs=before.st_ctime_ns,
        sha256=hashlib.sha256(raw).hexdigest())


def methods():
    ports = {}
    for cls, names in (
        (IOSAudioPassiveOwner, ('archive', 'initialize', 'load', 'admit',
            'file_guard', 'historical_inventory_replay', 'validate_entry',
            'proof', 'assembled', 'snapshot_original')),
        (AudioPassiveJournal, ('restore', 'frame', 'reference', 'read', 'inventory')),
        (OriginalFrameStore, ('read', 'manifest', 'bound')),
        (PrivateFeatureState, ('read',)),
        (ScriptSourceLock, ('held', 'assert_held', '_check')),
    ):
        for name in names:
            member = cls.__dict__[name]
            function = member.__func__ if type(member) is classmethod else member
            ports[(cls, name)] = (member, function, function.__code__, function.__globals__)
            if hasattr(function, '__wrapped__'):
                inner = function.__wrapped__
                ports[(cls, name + '.__wrapped__')] = (inner, inner, inner.__code__, inner.__globals__)
    return ports


def unchanged(ports):
    for (cls, name), (member, function, code, globals_) in ports.items():
        if name.endswith('.__wrapped__'):
            outer = cls.__dict__[name[:-12]]
            actual = outer.__func__ if type(outer) is classmethod else outer
            assert actual.__wrapped__ is member
        else:
            assert cls.__dict__[name] is member
        assert function.__code__ is code and function.__globals__ is globals_


def phase(label, operation, ports, root):
    unchanged(ports)
    assert sys.getprofile() is None and sys.gettrace() is None
    profile = cProfile.Profile()
    returned = False
    entered = False
    profile_started = False
    read_paths = None
    elapsed = None
    try:
        with collect() as read_paths:
            entered = True
            started = time.perf_counter_ns()
            profile.enable()
            profile_started = True
            try:
                value = operation()
                returned = True
            finally:
                profile.disable()
                if profile_started:
                    elapsed = time.perf_counter_ns() - started
    finally:
        # Also release if interruption occurred between enable() and the inner
        # try. A never-started phase reports unknown counts/time, never zero.
        profile.disable()
        unchanged(ports)
        assert sys.getprofile() is None and sys.gettrace() is None
        actual = profile.getstats() if profile_started else []
        native_entries = []
        for cls in (NativeClockAcquisition, NativeFeatureObservation):
            for name, member in cls.__dict__.items():
                function = member.__func__ if type(member) in (classmethod, staticmethod) else member
                code = getattr(function, '__code__', None)
                for entry in actual:
                    if code is not None and entry.code is code and entry.callcount:
                        native_entries.append(dict(method=cls.__name__ + '.' + name,
                                                   calls=entry.callcount))
        hits = {}
        for (cls, name), (_member, _function, code, _globals) in ports.items():
            entries = [entry for entry in actual if entry.code is code]
            assert len(entries) <= 1
            entry = entries[0] if entries else None
            hits[cls.__name__ + '.' + name] = dict(
                file=code.co_filename, firstLine=code.co_firstlineno,
                calls=(0 if entry is None else entry.callcount) if profile_started else None,
                recursiveCalls=(0 if entry is None else entry.reccallcount) if profile_started else None)
        assert all(path.is_relative_to(root) for path in (read_paths or ()))
        report = dict(phase=label, collectionEntered=entered, profileStarted=profile_started,
            operationReturned=returned,
            elapsedHostPerfNsWithProfiler=elapsed, actualCodeHits=hits,
            privateStateReadCalls=hits['PrivateFeatureState.read']['calls'],
            immutableFrameReadCalls=hits['OriginalFrameStore.read']['calls'],
            immutableManifestReadCalls=hits['OriginalFrameStore.manifest']['calls'],
            distinctActualReadPaths=(sorted(str(path.relative_to(root))
                for path in read_paths) if entered else None),
            memberSetIsNotWholeInputCensus=True,
            definitionOnlyNativeMethodEntries=native_entries,
            nativeObservationAuthority=False)
        CLOSED_PHASES.append(report)
        assert not native_entries
    return value, report


class AudioNormal4RetainedPassiveSnapshotTests(unittest.TestCase):
    def measure(self, lease):
        context = json.loads((SOURCE / 'selected-original-operands.json').read_text())
        root = Path(context['inputRoot'])
        assert root.is_absolute() and root.resolve(strict=True) == root
        chosen = [row for row in context['selected'] if row['leaseId'] == lease]
        self.assertEqual(1, len(chosen))
        selected = chosen[0]
        for relative, expected in ((context['parentHeader'], context['parentHeaderPin']),
                (context['ledgerHeader'], context['ledgerHeaderPin']),
                (selected['ownerHeader'], selected['ownerHeaderPin']),
                (context['lock'], context['lockPin'])):
            self.assertEqual(expected, pin(root / relative)[1])
        parent = json.loads(pin(root / context['parentHeader'])[0])
        ledger = json.loads(pin(root / context['ledgerHeader'])[0])
        header = json.loads(pin(root / selected['ownerHeader'])[0])
        self.assertEqual(context['binding'], parent['state']['bindings']['actor'])
        self.assertEqual(context['binding'], ledger['binding'])
        self.assertEqual(context['binding'], header['binding'])
        self.assertEqual(context['runId'], parent['runId'])
        self.assertEqual(context['runId'], ledger['runId'])
        self.assertEqual(context['runId'], header['runId'])
        self.assertEqual(context['actorArtifactRoot'], parent['settings']['actorArtifactRoot'])
        self.assertEqual(context['actorArtifactRoot'], ledger['artifactRoot'])
        self.assertEqual(context['fixtureUrl'], ledger['fixtureUrl'])
        self.assertEqual(context['fixtureUrl'], header['fixtureUrl'])
        artifacts = [row for row in parent['state']['artifacts']
                     if row['kind'] == 'audio'
                     and row['sourceReference'].get('leaseId') == lease]
        self.assertEqual(1, len(artifacts))
        self.assertEqual('saved', artifacts[0]['phase'])
        rows = [row for row in ledger['leases'] if row['leaseId'] == lease]
        self.assertEqual(1, len(rows))
        self.assertEqual('opened', rows[0]['phase'])
        artifact_root = Path(context['actorArtifactRoot']) / ('ios-audio-passive-' + lease)
        self.assertEqual(artifact_root, (root / selected['ownerHeader']).parent)
        self.assertEqual(str(artifact_root), header['artifactRoot'])
        info = artifact_root.lstat()
        self.assertEqual(rows[0]['rootIdentity'], dict(device=info.st_dev, inode=info.st_ino))
        lock_path = root / context['lock']
        lock_before = pin(lock_path)[1]
        lock = ScriptSourceLock(lock_path)
        ports = methods()
        reports = []
        with readonly(), lock.held():
            store = PrivateFeatureState(root / selected['ownerHeader'])
            owner, report = phase('genuine-historical-factory-admission',
                lambda: IOSAudioPassiveOwner.archive(store, artifact_root,
                    context['binding'], context['runId'], lease, lock,
                    context['fixtureUrl']), ports, root)
            reports.append(report)
            self.assertIs(type(owner), IOSAudioPassiveOwner)
            self.assertTrue(owner.historical)
            self.assertTrue(owner._admitted)
            self.assertEqual('retired', owner.state['phase'])
            self.assertIsNone(owner.state['pending'])
            self.assertIsNone(owner._inventory_round)
            self.assertIsNone(owner._snapshot_handoff)
            snapshot = owner.state['snapshot']
            self.assertEqual(44, snapshot)
            self.assertEqual(dict(leaseId=lease, snapshot=snapshot,
                absence=owner.state['absence']), artifacts[0]['sourceReference'])
            first, report = phase('first-independent-snapshot-original',
                owner.snapshot_original, ports, root)
            reports.append(report)
            self.assertIsNone(owner._inventory_round)
            self.assertIsNone(owner._snapshot_handoff)
            second, report = phase('second-independent-snapshot-original',
                owner.snapshot_original, ports, root)
            reports.append(report)
            self.assertEqual(first, second)
            self.assertIsNot(first, second)
            self.assertEqual(snapshot, first['original'])
            self.assertEqual(reports[1]['distinctActualReadPaths'],
                             reports[2]['distinctActualReadPaths'])
            for report in reports[1:]:
                self.assertGreater(report['immutableFrameReadCalls'], 0)
                self.assertGreater(report['privateStateReadCalls'], 0)
                self.assertEqual(1, report['actualCodeHits']['IOSAudioPassiveOwner.snapshot_original']['calls'])
                self.assertGreater(report['actualCodeHits']['IOSAudioPassiveOwner.validate_entry']['calls'], 0)
            self.assertIsNone(owner._inventory_round)
            self.assertIsNone(owner._snapshot_handoff)
            owner.file_guard()
        self.assertIsNone(lock._owner)
        self.assertEqual(lock_before, pin(lock_path)[1])
        unchanged(ports)
        MEASURED[lease] = dict(phases=reports, stateIsPostCleanupRetired=True,
            currentOrLiveAuthority=False, normalFourthActionQualified=False,
            snapshotRawBytes={kind: len(raw) for kind, raw in first['raw'].items()},
            fullInputMembershipRequiresIndependentControllerCensuses=True)

    def test_actual_retired_8eb_historical_factory_and_fresh_snapshots(self):
        self.measure('8eb395de1aefbac3fa8c68fb47eef9e4')

    def test_actual_retired_de5_historical_factory_and_fresh_snapshots(self):
        self.measure('de53187be33e16eeb1b53bac58dbef46')
