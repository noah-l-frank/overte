"""Immutable source/history prerequisites, no target imports or SDK admission."""
import hashlib,json,os,stat
from pathlib import Path
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path):
    path=Path(path);a=path.lstat();assert not path.is_symlink()and path.resolve(strict=True)==path
    assert stat.S_ISREG(a.st_mode)or stat.S_ISDIR(a.st_mode)
    value=dict(stat=[getattr(a,k)for k in FIELDS])
    if stat.S_ISREG(a.st_mode):value['sha256']=sha(path)
    assert value['stat']==[getattr(path.lstat(),k)for k in FIELDS];return value

def sources(here):
    preparation=here.parent;expected=json.loads((preparation/'immutable-source-pins.json').read_text())
    current={name:pin(name)for name in expected};assert current==expected,'Reviewed source/dependency/retained-original pin changed'
    freeze=json.loads((preparation/'freeze.json').read_text())
    for relative,digest in freeze['files'].items():assert sha(preparation/relative)==digest,relative
    history=json.loads((preparation/'historical-proof-scope.json').read_text())
    for row in history['stages']:
        stage=Path(row['path']);out=stage/'root-run-first';report=json.loads((out/'report.json').read_text())
        assert report['exitCode']==0 and report['retainedFiles']==row['retainedFiles']and not report['remainingOwnedProcesses']
        assert all(report[k]for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged'))
        assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
        assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text())
        thread=json.loads((out/'thread-report.json').read_text());assert thread==dict(exitCode=0,remainingNewThreads=[])
        selected=json.loads((stage/'selected-result.json').read_text())
        assert selected['successful']and selected['testsRun']==len(row['cases'])and selected['selectedIds']==row['cases']
        assert not any(selected[k]for k in ('failureCount','errorCount','skippedCount'))
        for index,case in enumerate(row['cases'],1):
            cleanup=stage/('case-cleanup-'+str(index));receipt=json.loads((cleanup/'receipt.json').read_text())
            assert receipt['case']==case and receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']
            a=json.loads((cleanup/'terminal-census-1.json').read_text());b=json.loads((cleanup/'terminal-census-2.json').read_text())
            assert a==b and not any(a[key]for key in ('threads','pendingTasks','sdkModules'))and a['children']==''
    return current

def first_pass(here):
    if here.name=='first1':return
    first=here.parent/'first1';report=json.loads((first/'run/report.json').read_text());selected=json.loads((first/'selected-result.json').read_text())
    assert report['exitCode']==0 and report['allPinsEqual']and report['retainedOriginalsUnchanged']and not report['remainingOwnedProcesses']
    expected=json.loads((first/'case.json').read_text())['case']
    assert selected['selectedIds']==[expected]and selected['successful']and selected['testsRun']==1 and not any(selected[k]for k in ('failureCount','errorCount','skippedCount'))
    receipt=json.loads((first/'cleanup/receipt.json').read_text());assert receipt['case']==expected and receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']
    assert json.loads((first/'run/source-before.json').read_text())==json.loads((first/'run/source-after.json').read_text())
    assert json.loads((first/'run/originals-first.json').read_text())==json.loads((first/'run/originals-second.json').read_text())
    for name in ('terminal-census-1.json','terminal-census-2.json'):
        census=json.loads((first/'cleanup'/name).read_text());assert not any(census[k]for k in ('threads','pendingTasks','sdkModules'))and census['children']==''
