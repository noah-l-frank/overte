"""Exact observed str/int policy mapping plus metadata-only AST census."""
import ast,difflib,hashlib,json
from pathlib import Path
R=Path.cwd();H=R/'.ios-host-tmp/emote-callback-live-prefix-typed-policy-mapping-source-fix-20261102';B=R/'.ios-host-tmp/emote-callback-live-prefix-exact-socket-timeout-policy-source-fix-20261102'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(s)
rows=[];diff=[]
for row in json.loads((B/'plan.json').read_text())['sourceRows']:
 rel=row['path'];p=R/rel;assert sha(p)==row['candidateSHA256'];before=p.read_text();after=before
 if rel.endswith('emote_callback_live_records.py'):
  old="""    if kind is dict:
        if not all(type(key) is str for key in value):raise _Unsupported
        return ('dict',tuple((key,token(value[key])) for key in sorted(value)))"""
  new="""    if kind is dict:
        # Only exact str/int keys. Preserve the type in the canonical order:
        # integer1 and string'1' cannot alias, and bool/float/object keys refuse.
        if not all(type(key) in (str,int) for key in value):raise _Unsupported
        entries=((token(key),token(item)) for key,item in value.items())
        return ('dict',tuple(sorted(entries,key=lambda row:row[0])))"""
  assert after.count(old)==1;after=after.replace(old,new)
 if rel.endswith('test_ios_emote_callback_live_history_cache.py'):
  after+='''
    def test_changed_actual_integer_profile_policy_cannot_reuse_warm_history(self):
        from ios.adapters.normal_input import PLACES_PROFILES
        from ios.adapters.places_controls import PROFILES
        self.assertIs(PLACES_PROFILES,PROFILES);self.assertEqual({1:'qt-places-qml-v1',2:'qt-places-qml-v2'},PROFILES)
        self.read()
        with patch.dict(PROFILES,{1:'declared-different-profile'}):
            self.assertFalse(self.history.literal());self.read()
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())

    def test_unsupported_actual_profile_mapping_object_key_uses_literal_decoder(self):
        from ios.adapters.normal_input import PLACES_PROFILES
        self.read()
        with patch.dict(PLACES_PROFILES,{object():'declared-unsupported-key'}):
            self.assertFalse(self.history.literal());self.read()
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())
'''
 ast.parse(after,filename=rel);write(H/'base'/rel,before);write(H/'candidate'/rel,after)
 rows.append(dict(path=rel,baseSHA256=sha(p),candidateSHA256=hashlib.sha256(after.encode()).hexdigest()))
 diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
write(H/'typed-mapping-only.diff',''.join(diff))
# AST-only census: namespaces and class attributes, never execute/import code.
tree=ast.parse((H/'candidate/tests/device/ios/adapters/emote_callback_live_records.py').read_bytes())
modules=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARSER_MODULES' for t in n.targets)))
def locate(m):
 p=R/'tests/device'/(m.replace('.','/')+'.py');return p if p.is_file() else None
seen={};todo=list(modules);candidates=[];integer_maps=[]
while todo:
 name=todo.pop()
 if name in seen:continue
 p=locate(name)
 if p is None:continue
 t=ast.parse(p.read_bytes());seen[name]=dict(path=str(p.relative_to(R)),sha256=sha(p))
 for n in ast.walk(t):
  if isinstance(n,ast.Import):todo.extend(a.name for a in n.names)
  elif isinstance(n,ast.ImportFrom) and n.module and n.level==0:todo.append(n.module)
 def scan(nodes,scope):
  for n in nodes:
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):continue
   if isinstance(n,ast.ClassDef):scan(n.body,scope+'.'+n.name);continue
   if isinstance(n,(ast.Assign,ast.AnnAssign)) and n.value is not None:
    targets=[ast.unparse(t) for t in n.targets] if isinstance(n,ast.Assign) else [ast.unparse(n.target)]
    for v in ast.walk(n.value):
     row=dict(module=name,path=str(p.relative_to(R)),scope=scope,line=v.lineno,targets=targets)
     if isinstance(v,ast.Call) and ast.unparse(v.func)=='object':candidates.append(dict(row,kind='object-constructor'))
     if isinstance(v,ast.Constant) and isinstance(v.value,bytes):candidates.append(dict(row,kind='bytes-literal'))
     if isinstance(v,ast.Dict):
      for key in v.keys:
       if key is None:continue
       try:k=ast.literal_eval(key)
       except (ValueError,TypeError):continue
       if type(k) is int:integer_maps.append(dict(row,key=k))
       elif type(k) is not str:candidates.append(dict(row,kind='dict-key-'+type(k).__name__))
   if isinstance(n,(ast.If,ast.Try)):
    for field in ('body','orelse','finalbody'):scan(getattr(n,field,[]),scope)
 scan(t.body,name)
root_candidates=[v for v in candidates if v['module'] in modules];assert root_candidates==[]
write(H/'static-policy-source-census.json',json.dumps(dict(method='AST namespace/class literals only; no dynamic policy evaluation or target import',rootModules=list(modules),rootUnsupportedLiteralCandidates=root_candidates,projectImportClosure=seen,transitiveCandidates=candidates,integerMappingLiterals=integer_maps,limits='Dynamic call results, external closures and aliases not evaluated; actual changed smoke remains required. Non-root transitive literal candidates are not automatically runtime namespace policy members.'),indent=2)+'\n')
plan=dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceRows=rows,actualUnsupported=['ios.adapters.normal_input','PLACES_PROFILES'],actualCause="Imported places_controls.PROFILES={1:'qt-places-qml-v1',2:'qt-places-qml-v2'} has exact integer keys",actualFailure='.ios-host-tmp/emote-callback-live-prefix-exact-socket-mechanisms15-root-preparation-20261102/smoke1/root-run-first/report.json',typedKeyPolicy='Exact str/int only, tokens include key type/value, sorted by typed token; arbitrary/bool/float/tuple keys refuse',mechanismCases=17,prospectiveSmoke=dict(firstSeconds=15,killAfterSeconds=5,realRoots=0),prospectiveMechanisms=dict(firstSeconds=30,killAfterSeconds=5,realRoots=17),staticRootModules=len(modules),staticProjectImportClosure=len(seen),old747ReplayForbidden=True,freshGraph='HARDHOLD pending actual changed smoke and17 mechanisms PASS',sourcePublished=False,testsRun=False,targetImported=False,SDKImported=False)
write(H/'plan.json',json.dumps(plan,indent=2)+'\n');write(H/'freeze.json',json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(H)):sha(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(packet=str(H),freeze=sha(H/'freeze.json'),sourceRows=rows,rootUnsupportedLiteralCandidates=root_candidates,transitiveCandidates=candidates)))
