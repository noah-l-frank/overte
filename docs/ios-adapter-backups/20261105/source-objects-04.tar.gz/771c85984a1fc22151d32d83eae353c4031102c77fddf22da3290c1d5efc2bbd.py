from pathlib import Path
import ast,hashlib,json,difflib,shutil
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';O=T/'lifecycle-original-owner-native-motion-rpc-observed-window-number-overlay-20261028';B=T/'lifecycle-original-owner-native-motion-existing-rpc6-root-preparation-20261028/40-native-motion-rpc6';P=T/'lifecycle-original-owner-native-motion-rpc-window-bool-model-overlay-20261028';P.mkdir(mode=0o700);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();name='test_native_motion_existing_rpc_models.py';old=(O/name).read_text();needle="        variants=[dict(args,x=args['x']+1),dict(args,seconds=11),dict(args,nativeMotionProfileVersion=True),";assert old.count(needle)==1
new=old.replace(needle,"        variants=[dict(args,width=True),dict(args,height=True),dict(args,x=args['x']+1),dict(args,seconds=11),dict(args,nativeMotionProfileVersion=True),");ast.parse(new);(P/name).write_text(new);(P/'test-only.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE_FROZEN_TEST_ONLY_UNRUN',floatSourceOverlayFreezeSHA256=H(O/'freeze.json'),baseModelSHA256=H(O/name),candidateModelSHA256=H(P/name),caseCount=6,initialSeconds=60,killAfterSeconds=5,expectedGenuineRoots=12,sourceChanged=False),indent=2)+'\n');(P/'README.txt').write_text('''Separate test-only extension preserves341ee3 floatSource/model freeze.
Existing badvariant case additionally rejects width=True and height=True before
input/context/newnativequeries. Same6 explicit cases, producerfloat firstpositive
unchanged, no packet/clock rewrite, no SDK/fact/result stubs or sourcechanges.
Prospective60+kill5/12actualTD; Rootalone execute/PUB, agentASTonly.
'''.replace('\n+','\n'));(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_FROZEN_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n')
Q=T/'lifecycle-original-owner-native-motion-rpc-window-number-root-preparation-20261028';Q.mkdir(mode=0o700);S=Q/'41-native-motion-rpc6';S.mkdir(mode=0o700)
for rel,d in json.loads((B/'freeze.json').read_text())['files'].items():
 assert H(B/rel)==d;out=S/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/rel,out)
shutil.copyfile(P/name,S/name);stage=json.loads((S/'source-manifest.json').read_text());rel='tests/device/ios/pymobiledevice3_wda_xctest.py';source=O/'candidate/repo'/rel;changes=[]
for row in stage['sourcePaths']:
 actual=H(R/row['path'])
 if row['path']==rel:row.update(candidate=str(source),candidateSHA256=H(source),observedPublicSHA256=actual,changesCurrentPublic=actual!=H(source));continue
 if actual!=row['candidateSHA256']:
  out=S/'actual-current-dependency/repo'/row['path'];out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/row['path'],out);changes.append(dict(path=row['path'],old=row['candidateSHA256'],current=actual));row.update(candidate=str(out),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
stage.update(stage=41,name='41-native-motion-rpc6',status='PRIVATE_UNRUN_OBSERVED_WINDOW_NUMERIC_CORRECTED',sourceDeltaPaths=[rel],exactPublicMutationPlan='Root ONLY keeper3811->840d numeric observed-window guard; touch2 registry alreadypublic, foreignTablet/Emote unchanged. Same6 tests with original newfloat producer and2bool negatives.')
stage['orderedParentFreezes'][O.name]=H(O/'freeze.json');stage['orderedParentFreezes'][P.name]=H(P/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');plan=json.loads((S/'run-plan.json').read_text());plan['privateFiles'][name]=H(S/name);plan.update(status='PRIVATE_UNRUN_OBSERVED_WINDOW_NUMERIC_CORRECTED');(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(S/'source1-window-number.diff').write_bytes((O/'source1.diff').read_bytes());(S/'test-bool-only.diff').write_bytes((P/'test-only.diff').read_bytes());(S/'clone-provenance-window-number.json').write_text(json.dumps(dict(parentStageFreezeSHA256=H(B/'freeze.json'),floatSourceOverlayFreezeSHA256=H(O/'freeze.json'),boolModelOverlayFreezeSHA256=H(P/'freeze.json'),sourceSHA256=H(source),modelSHA256=H(S/name),allPriorActualFiles=2400,initialSeconds=60,killAfterSeconds=5,caseCount=6,expectedGenuineRoots=12,actualDependencyChanges=changes,executed=False,publicEdits=False),indent=2)+'\n');(S/'README-window-number.txt').write_text('''Root41 prospective6/60+kill5/12realTD; originalRoot40 remainsUNRUN.
Source840d keeper ONLY extends exactobserved window width/height to existing
finite numeric1..10000, excludesbool/nonfinite and still exactoriginaltuple;
x/yints and all ownership/freshness/default guards unchanged. Firstpositive
newSDK producerfloat BEFOREcapture, old badvariant+2bools.2400oldactualfiles,
80strict actualsource+launcher+SDK maps before targetimports, actual realfixture
FD/task/thread/child bothcensuses unchanged. touch2 and foreignshared keys already
PUBactual; no new registryhunk. Rootalone PUB/run; no agent imports/tests/PUB.
'''.replace('\n+','\n'))
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n');(Q/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(Q)):H(p) for p in sorted(Q.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(boolOverlayFreeze=H(P/'freeze.json'),modelSHA256=H(P/name),stageFreeze=H(S/'freeze.json'),parentFreeze=H(Q/'freeze.json'),actualDependencyChanges=changes),indent=2))
