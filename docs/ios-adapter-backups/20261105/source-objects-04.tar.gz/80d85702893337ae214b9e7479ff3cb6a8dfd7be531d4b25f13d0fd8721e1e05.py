"""One selected2 no-build run with complete source pins and retained originals."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tempfile,time
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1];PRIVATE=REPO/'.ios-host-tmp'
PLAN=json.loads((HERE/'selected-suite-plan.json').read_text())
PACKET=REPO/PLAN['proposal']
ROOTS=('tests/device','interface/src/main.cpp','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics','libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    a=path.lstat();value={k:getattr(a,k) for k in FIELDS}
    if stat.S_ISREG(a.st_mode):value['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    else:assert stat.S_ISDIR(a.st_mode)
    b=path.lstat();assert all(getattr(a,k)==getattr(b,k) for k in FIELDS),str(path)
    return value
def save(name,value):(HERE/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def sources():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}
    paths.update(HERE/name for name in ('root-supervise2.py','selected-suite2.py','selected-suite-plan.json','freeze.json'))
    frozen=json.loads((PACKET/'freeze.json').read_text())
    paths.update(PACKET/name for name in frozen['files'])
    paths.update(PACKET/name for name in ('freeze.json','root-publication.json'))
    paths.update(REPO/name for name in PLAN['reviewedFixturePins'])
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}
def originals(roots):
    return {str(root):{str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))} for root in sorted(roots)}
def process(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
assert not (HERE/'root2-report.json').exists(),'No unchanged rerun'
runs=HERE/'runs';runs.mkdir(mode=0o700,exist_ok=True)
runroot=Path(tempfile.mkdtemp(prefix='root2-first-',dir=runs));runroot.chmod(0o700)
temporary=runroot/'temporary';temporary.mkdir(mode=0o700)
environment=os.environ.copy();environment.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.:tests/device:tests/device/self_tests:tests/device/ios/self_tests',TMPDIR=str(temporary),OVERTE_WORLD6_RECOVERY_RUN_ROOT=str(runroot))
before=sources();save('root2-source-before.json',before)
print('SOURCE_LAUNCHER_REFERENCE_PINS',len(before),flush=True);started=time.monotonic()
with (HERE/'root2-first.log').open('w') as log:
    task=subprocess.Popen(['timeout','--signal=TERM','--kill-after=5s','300s',sys.executable,str(HERE/'selected-suite2.py')],cwd=REPO,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    binding=process(task.pid);assert binding is not None
    save('root2-process-binding.json',binding);print('ACTUAL_PROCESS',json.dumps(binding,sort_keys=True),flush=True)
    code=task.wait()
after=sources();save('root2-source-after.json',after);assert before==after,'Source/launcher/reference changed'
roots={temporary}
first=originals(roots);save('root2-originals-first.json',first)
second=originals(roots);save('root2-originals-second.json',second);assert first==second,'Post-stop originals changed'
remaining=[]
for path in Path('/proc').iterdir():
    if not path.name.isdecimal():continue
    item=process(int(path.name))
    if item is not None and item['session']==task.pid:remaining.append(item)
report=dict(exitCode=code,seconds=time.monotonic()-started,runRoot=str(runroot),sourceLauncherReferencePins=len(after),allPinsEqual=True,originalFiles=sum(stat.S_ISREG(row['st_mode']) for rows in first.values() for row in rows.values()),originalRootCount=len(roots),postStopOriginalCensusesEqual=True,remainingOwnedProcesses=remaining,nativeCompiled=False,sdkExecuted=False,deviceQualified=False,wholeWorldWebQualified=False)
save('root2-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
assert not remaining
raise SystemExit(code)
