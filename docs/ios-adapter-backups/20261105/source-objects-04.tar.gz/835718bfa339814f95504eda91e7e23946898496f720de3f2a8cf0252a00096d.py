"""Original-only Audio three-reply codec. AFC is never a native inode/clock."""
from copy import deepcopy
import base64,hashlib,json,re
from adapters.native_feature_observation import exact,need,number,validate as native_packet
from adapters.script_feature.history import same
from ios.adapters.audio_response_command import FILES,command
AFC_FIELDS={'iosAudioResponseAFCOriginalVersion','ownerInstance','runId','binding','file','resultsDirectory','bundleId','clockDomain',
 'hostBeforeEpochMs','hostAfterEpochMs','hostBeforeMonotonic','hostAfterMonotonic','original','actualHandleClosed','actualServiceCloseReturned',
 'nativeClockEstablished','nativeInodeEstablished','installedCandidateBound','resourceRetirementEstablished'}

def parse_original(value,*,binding,run,owner,bundle,directory,filename,mode):
    exact(value,AFC_FIELDS)
    need(type(value['iosAudioResponseAFCOriginalVersion'])is int and value['iosAudioResponseAFCOriginalVersion']==1
        and value['ownerInstance']==owner and type(owner)is str and re.fullmatch('[0-9a-f]{32}',owner)
        and same(value['binding'],binding)and value['runId']==run and value['bundleId']==bundle
        and value['file']==filename and filename in FILES and value['resultsDirectory']==directory
        and value['clockDomain']=='python-original-keeper-host'and value['actualHandleClosed']is True and value['actualServiceCloseReturned']is True
        and all(value[k]is False for k in('nativeClockEstablished','nativeInodeEstablished','installedCandidateBound','resourceRetirementEstablished')))
    for k in('hostBeforeEpochMs','hostAfterEpochMs','hostBeforeMonotonic','hostAfterMonotonic'):need(number(value[k],0,1e16))
    need(0<=value['hostAfterMonotonic']-value['hostBeforeMonotonic']<1.5 and value['hostAfterEpochMs']>=value['hostBeforeEpochMs'])
    raw=value['original'];need(type(raw)is dict and raw['mode']==mode)
    if mode=='read':
        exact(raw,{'mode','rawBase64','actualRawSha256','actualRawBytes','actualStatBefore','actualStatAfter'})
        data=base64.b64decode(raw['rawBase64'],validate=True)
        need(type(raw['rawBase64'])is str and base64.b64encode(data).decode('ascii')==raw['rawBase64']
            and type(raw['actualRawBytes'])is int and 2<=len(data)==raw['actualRawBytes']<=1048576
            and hashlib.sha256(data).hexdigest()==raw['actualRawSha256']and same(raw['actualStatBefore'],raw['actualStatAfter']))
        stat=raw['actualStatBefore'];need(type(stat)is dict and stat.get('st_ifmt')=='S_IFREG'and type(stat.get('st_nlink'))is int
            and stat['st_nlink']==1 and stat.get('st_size')==len(data)and 'st_ino'not in stat and 'st_dev'not in stat)
        def pairs(items):
            out={}
            for name,item in items:need(name not in out);out[name]=item
            return out
        packet=json.loads(data.decode('utf-8'),object_pairs_hook=pairs)
        need(type(packet)is dict and type(packet.get('processId'))is int and str(packet['processId'])==binding['processIdentity'])
        return packet
    if mode=='present':exact(raw,{'mode','actualStat'});need(type(raw['actualStat'])is dict);return None
    need(mode=='absent');exact(raw,{'mode','actualException','actualStatus'})
    need(raw['actualException']=='pymobiledevice3.exceptions.AfcFileNotFoundError'and type(raw['actualStatus'])is int and raw['actualStatus']==4)
    return None


def family_last_packet(coordinator,kind):
    """Select only actual final files replies from typed original children."""
    family=coordinator.originals()[kind];need(not family.pending and family.owners)
    rows=[]
    for lease,owner in family.owners.items():
        owner.episode_retired();frame=owner.proof(owner.state['absence']);need(frame['kind']=='reply')
        query=owner.journals['passive'].read(frame['query']);packet=frame['packet'];need(query['operation']=='files')
        owner.CONTRACT.validate(packet,query,owner.pid,frame['clockJoin']['nativeAfter'])
        need(packet['source']['retired']is True and packet['source']['releaseAttempted']is True
            and packet['source']['openOriginalFds']==packet['source']['originalBytes']==0 and all(not f['exists']for f in packet['source']['files']))
        rows.append((packet['sequence'],lease,deepcopy(packet)))
    need(len({n for n,lease,packet in rows})==len(rows))
    return max(rows,key=lambda row:row[0])[2]


def cutoff_native(keeper):
    need(keeper.state['cutoff']is not None)
    record=keeper.original(keeper.state['cutoff']);cut=record['sourceFrame']['frame']['original']
    need(cut['ownerInstance']==keeper.state['owner']and cut['binding']==keeper.binding and cut['runId']==keeper.run)
    value=cut['original']['current']['clockJoin']['nativeAfter']
    native_packet(value,value['requestId'],int(keeper.binding['processIdentity']),value['capturedEpochMs'])
    return deepcopy(value)


def expected_packets(coordinator,keeper):
    return {FILES[0]:family_last_packet(coordinator,'microphone'),FILES[1]:family_last_packet(coordinator,'received'),FILES[2]:cutoff_native(keeper)}


def source_reference(reference):
    exact(reference,{'index','bytes','sha256','device','inode'})
    need(type(reference['index'])is int and 1<=reference['index']<=1024
        and type(reference['bytes'])is int and 2<=reference['bytes']<=1048576
        and type(reference['device'])is int and 0<=reference['device']<=2**64-1
        and type(reference['inode'])is int and 1<=reference['inode']<=2**64-1
        and type(reference['sha256'])is str and re.fullmatch('[0-9a-f]{64}',reference['sha256']))
    return reference


def sdk_absences(originals,*,binding,run,owner,before,context=None):
    from adapters.script_feature.history import canonical
    need(type(originals)is list and len(originals)==3)
    identities=set();indices=[];operations=set()
    for row,filename in zip(originals,FILES):
        exact(row,{'reference','frame'});reference=row['reference'];frame=row['frame']
        source_reference(reference);need(reference['index']>1)
        exact(frame,{'kind','role','operationId','original'})
        need(frame['kind']=='audio-response'and frame['role']==filename and type(frame['operationId'])is str
            and re.fullmatch('[0-9a-f]{32}',frame['operationId'])and frame['operationId']not in operations)
        operations.add(frame['operationId']);value=frame['original']
        body=dict(iosOriginalKeeperEndFrameVersion=1,kind='sources',binding=binding,runId=run,role='primary',index=reference['index'],frame=frame)
        raw=canonical(body);need(len(raw)==reference['bytes']and hashlib.sha256(raw).hexdigest()==reference['sha256'])
        indices.append(reference['index']);identities.add((value['bundleId'],value['resultsDirectory']))
        parse_original(value,binding=binding,run=run,owner=owner,bundle=value['bundleId'],directory=value['resultsDirectory'],filename=filename,mode='absent')
        if context is not None:
            need(value['bundleId']==context['bundleId']and value['resultsDirectory']==context['resultsDirectory']and value['ownerInstance']==context['ownerInstance'])
        need(value['hostAfterEpochMs']<=before['epochMs']and value['hostAfterMonotonic']*1000<=before['monotonicMs'])
    need(len(identities)==1 and len(set(indices))==3 and indices==sorted(indices));return True
