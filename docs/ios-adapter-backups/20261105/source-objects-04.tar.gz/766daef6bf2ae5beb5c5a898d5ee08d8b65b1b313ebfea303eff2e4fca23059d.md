# Private QueueObservation1 bridge checkpoint

Nothing in this directory is applied to the repository or an SDK. The C++ has
not been compiled/executed. The two Python test files are prepared but UNRUN.
Existing public ImageReader Source1 and History5 remain unchanged. Root's
latest source-only optional QtCore artifact is b90666ae7c; this bridge does not
inherit its host source-check result or any old TextureRelease whole PASS.

The exact five proposed repository source paths are:

1. libraries/material-networking/src/material-networking/IOSAssetsImageReaderQueueObservation.h
2. libraries/material-networking/src/material-networking/IOSAssetsImageReaderQueueObservation.cpp
3. libraries/material-networking/CMakeLists.txt
4. libraries/material-networking/src/material-networking/TextureCache.cpp
5. tests/device/native/IOSAssetsImageReaderObservation.h

The first two are new; the latter three are private modified copies generated
by prepare_hooks.py. repository-original-sha256.json pins those current original
repository files. This packet introduces no external getter, Probe/AFC route,
registry tag, Host reader, Source1 wire change, or History5 migration.

## Admission and identity

All code/callouts require iOS, feature instrumentation, and the dedicated iOS
test configuration. The optional CorePrivate include/link adds no SDK changes.
Unpatched headers have no marker, so all Qt API calls compile away. Runtime
admission requires actual --testScript, exact Qt6.11.1 and API version1. Missing
SDK/marker/API stays unavailable. State preparation is on the original actual
main-thread ImageReader construction path only after Source1::created returns.

Source1 creates no new IDs or wire fields. Its private context copies actual
existing owner/task/dispatch/receiver/resource identities and QPointer target,
then releases its mutex before entering the bridge. Failures of the new
optional context-copy path do not heal or expand Source1 authority. The actual
native Dispatch ID supplies the two opaque Qt binding words. Only actual
metadata indexOfMethod for the original declared
setImage(gpu::TexturePointer,int,int) is admitted. No URL/content/payload/GPU
argument inspection or FIFO inference is used. Qt callbacks validate actual
event ID, invocation identity, weak receiver and method. Actual native setImage
entry records an existing Source1 receiver ID only if the current actual Qt
event identity is nonzero and matches the sole event row.

The Qt producer's UTC/steady-nanosecond clock and native bridge UTC/elapsed-ms
clock remain separate original domains. Queue delivery and argument destruction
may finish before invokeMethod returns on its producer thread; the bridge does
not invent an order between those independent phases. Cancelled events need
neither delivery nor a receiver. Slot return alone never reports argument
destruction. Weak QObject resurrection and duplicate receiver binding refuse.

## Locks and state lifetime

No new lock spans product invocation. Source1's mutex only copies its context;
Bridge entry follows after return. Bridge's mutex only updates/copies bounded
primitive metadata plus weak QObject references. Every private Qt API call lies
before or after the Bridge mutex scope. Callback performs no Qt API calls,
product calls, queries, event pumping or payload access while holding that
mutex. It owns no strong product Resource/GPU/source/task/receiver.

The publication slot atomically holds a std::shared_ptr to diagnostic State.
Each callback/snapshot first loads its own strong State pin BEFORE waiting on
the Bridge mutex. The tiny publication slot itself is heap storage retained
for process lifetime; this avoids a late Qt callback touching a destroyed
global shared_ptr object. The State behind it can be destroyed normally.

Disarm first latches process-long unavailability, atomically exchanges the
published State to null, then calls Qt-disable without either observer mutex.
It does not wait/drain. A callback already running or waiting retains its pin;
later callbacks see null. The retired publication pin and all callback/snapshot
pins release outside the Bridge mutex. Actual State destruction occurs only
after the last such pin. A snapshot rechecks admission/API after its copy and
cannot expose a previously complete prefix after disarm/failure.

Both actual QCoreApplication::aboutToQuit and QObject::destroyed are connected
with dedicated direct diagnostic callbacks which capture no State/product
owner. In the retained exact Qt6.11.1 qobject.cpp, QObject::~QObject emits its
destroyed signal before disconnecting its connection tables. This is source
evidence only; no compiled self-context callback behavior is claimed here.
The atomic pin protocol, rather than callback timing alone, prevents State UAF.
Disarm is irreversible and cannot reinstall a clean old result.

## Prepared no-build cases (not yet run)

Five Python thread/barrier/weak-State cases cover an in-flight callback,
callback waiting for a mutex, late callback after publication cleared,
forbidden caller-held mutex, and snapshot holding an old good copy during
disarm. They exercise actual Python ownership/scheduling only; they do not
prove C++ atomic shared_ptr memory ordering, Qt ABI, or native callbacks.

Seven separate declared bridge cases cover absent API/marker/runtime, reversed
equal payload sources with different actual event IDs, foreign receiver/
method/resource/owner, delivery+destruction preceding invoke return,
cancellation without receiver, nested unobserved event and duplicate receiver,
and sticky capacity/weak-resurrection refusal. No actual device, SDK service,
network, compiler, product input or system clock qualification is involved.

Before publication, a small literal source-projection check should verify
feature-off/dedicated-off product source equivalence and exact current original
pins, and the prepared model selection needs a separately granted small slot.
Native compilation/runtime remain unverified. Event/base storage, unrelated
bytes, KTX, pools, decoder, GPU and Resource retirement stay unavailable;
Actor/backend/source/process/SDK end and overall5/14 completion remain open.
