"""Actual closed-gate Avatar raw producer component plus default prepare hook regression."""
from pathlib import Path
import json,os,stat,sys,tempfile,threading,types,unittest
from importlib.machinery import PathFinder
from run_metadata import HERE,REPO,pin,proc,publication,save,sha,validate_frozen,sources
assert len(sys.argv)==2 and sys.argv[1] in ('prepareTiming1',)
kind=sys.argv[1];plan=dict(validate_frozen(),activeSelection=kind);selected=plan['suites'][kind];publication()
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/(kind+'-publication-ready-source-map.json');assert ready.is_file(),'Root must refresh after source publication'
runroot=Path(os.environ['OVERTE_AVATAR_ROLE_SOURCE_RUN']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs'/kind) and runroot!=HERE/'runs'/kind
info=runroot.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
temporary=Path(os.environ['TMPDIR']).resolve(strict=True)
assert temporary==runroot/'temporary' and Path(tempfile.gettempdir())==temporary
info=temporary.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
assert not any(temporary.iterdir()) and not (runroot/'selected-result.json').exists()
save(runroot/'runner-process-binding.json',proc(os.getpid()))
config=json.loads((HERE/'source-root-final-map.json').read_text())
approved=json.loads(ready.read_text());assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
assert set(approved['modulePins'])==set(config['modules'])
all_sources_before=sources(plan);assert all_sources_before==approved['sourcePins'],'Actual full Source map differs before imports'
config['modules']=approved['modulePins']
sourcepaths={REPO/row['path'] for row in config['modules'].values()}
sourcepaths.update(HERE/name for name in ('run-selected.py','run_metadata.py','suite-plan.json','source-root-final-map.json','expected-publication.json','expected-registry-own-keys.json','freeze.json'))
sourcepaths.add(ready)
source_before={str(path):pin(path) for path in sourcepaths}

def spec_without_import(name):
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:assert search is not None,name
    return spec

def preimport_source_roots():
    top_names={name.split('.')[0] for name in config['packageRoots']}
    assert not any(name.split('.')[0] in top_names for name in sys.modules),'Target imported before source preflight'
    expected=[str(REPO/name) for name in config['orderedRoots']];remaining=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==REPO or REPO in path.parents:continue
        if str(path) not in remaining:remaining.append(str(path))
    sys.path[:]=expected+remaining
    for name,relative in config['packageRoots'].items():
        spec=spec_without_import(name)
        assert [str(Path(path).resolve()) for path in spec.submodule_search_locations or ()]==[str(REPO/relative)],name
    actual={}
    for name,row in config['modules'].items():
        spec=spec_without_import(name);assert spec.origin is not None,name
        path=Path(spec.origin).resolve(strict=True)
        assert path==REPO/row['path'] and sha(path)==row['sha256'],name
        actual[name]=str(path)
    save(runroot/'preimport-source-map-actual.json',dict(orderedRoots=expected,modules=actual))
threads_before=set(threading.enumerate())
sdk_bad=('pymobiledevice3','tidevice','pyidevice','zeroconf')
def forbidden_sdk_source(path):
    if type(path) not in (str,bytes):return False
    parts=Path(os.fsdecode(path)).parts
    return any(part in ('overte-ios-remotexpc',*sdk_bad) or any(part.startswith(bad+'_') for bad in sdk_bad) for part in parts)
def audit_loaded_sdk():
    assert not any(any(part in sdk_bad for part in name.split('.')) or forbidden_sdk_source(getattr(module,'__file__',None))
        for name,module in tuple(sys.modules.items())),'SDK source/name already loaded'
audit_loaded_sdk()
# Audit is actually installed BEFORE any target import, not a plan-only claim.
def audit(event,args):
    if event=='import':
        name=args[0]
        assert not any(part in sdk_bad for part in name.split('.')) and not forbidden_sdk_source(args[1]),'SDK import/source prohibited'
    elif event=='open':
        path=args[0]
        if isinstance(path,(str,bytes,os.PathLike)):
            actual=os.fsdecode(path)
            canonical_receiver=REPO/'tests/device/ios/pymobiledevice3_wda_xctest.py'
            assert Path(actual)==canonical_receiver or not forbidden_sdk_source(actual),'SDK source/read prohibited'
    elif event=='subprocess.Popen':
        executable,arguments=args[0],args[1]
        command=list(arguments)
        node=(Path(os.fsdecode(executable)).name=='node' and len(command)>=3 and command[0]=='node' and command[1]=='-e'
            and type(command[2]) is str and any(kind in row.get('onlyForKinds',[kind]) and __import__('hashlib').sha256(command[2].encode()).hexdigest()==row['programSha256']
                and command[3:]==row['tail'] for row in plan['hostExecutionAudit']['nodePrograms'])
            and (args[2] is None or Path(args[2]).resolve()==REPO))
        metadata_rg=(Path(os.fsdecode(executable)).name=='rg'
            and list(arguments)==['rg','--files','-0',*plan['broadSourceRoots']]
            and args[2] is not None and Path(args[2]).resolve()==REPO)
        command=list(arguments)
        tls_prefix=['openssl','req','-x509','-newkey','rsa:2048','-sha256','-days','1','-nodes',
            '-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1']
        openssl=(Path(os.fsdecode(executable)).name=='openssl' and command[:-4]==tls_prefix
            and command[-4]=='-keyout' and command[-2]=='-out'
            and Path(command[-3]).name=='ephemeral.key' and Path(command[-1]).name=='ephemeral.crt'
            and Path(command[-3]).parent==Path(command[-1]).parent
            and Path(command[-3]).parent.is_relative_to(temporary))
        assert node or metadata_rg or openssl,'Only original host Node/TLS certificate or exact source metadata command selected'
    elif event in ('socket.connect','socket.bind'):
        address=args[1]
        if isinstance(address,tuple):assert address[0] in ('127.0.0.1','::1','localhost'),'Only owned loopback fixture endpoints are selected'
sys.addaudithook(audit)
from monitoring_observer import OriginalProcessObserver
observer=OriginalProcessObserver(proc).start()
node_processes=observer.processes;host_owners=observer.owners;host_closes=observer.closes
# Actual Popen START/RETURN local events + UNWIND-only global observer precede target imports.
preimport_source_roots()
import importlib
fixture_modules=[importlib.import_module(name) for name in selected['fixtureAliasModules']]
from ios.self_tests import avatar_people_node,avatar_app_node,avatar_connection_node
observer.bind_owners((avatar_people_node.PeopleNode.__init__.__code__,avatar_app_node.AvatarAppNode.__init__.__code__,avatar_connection_node.ConnectionNode.__init__.__code__),
    (avatar_people_node.PeopleNode.close.__code__,avatar_app_node.AvatarAppNode.close.__code__,avatar_connection_node.ConnectionNode.close.__code__))
from ios.adapters.avatar_feature import IOSAvatarFeature
from ios.adapters.bundle_observation import NativeBundleObservation
from ios.adapters.installed_code import InstalledCodeBinding

def original_unwind_diagnostic(row):
    # Actual stack locations/types only. Never exception messages, locals,
    # credential-bearing frames, returned results or source/nonce rewrites.
    path=runroot/'actual-selected-original-unwinds.jsonl'
    descriptor=os.open(path,os.O_WRONLY|os.O_APPEND|os.O_CREAT|os.O_NOFOLLOW,0o600)
    with os.fdopen(descriptor,'a') as output:
        output.write(json.dumps(row,sort_keys=True)+'\n');output.flush();os.fsync(output.fileno())
observer.bind_diagnostics((IOSAvatarFeature.observe.__wrapped__.__code__,NativeBundleObservation.read.__code__,
    InstalledCodeBinding.verify.__code__),original_unwind_diagnostic)
from ios.self_tests.retained_host_roots import retain_owned_root
real_td=tempfile.TemporaryDirectory;retained=[];objects=[]
def retained_directory(*args,**kwargs):
    directory=real_td(*args,**kwargs);root=Path(directory.name)
    assert root.is_relative_to(temporary)
    root=retain_owned_root(directory,expected_root=root)
    retained.append(str(root));objects.append(directory)
    save(runroot/'created-original-roots.json',retained)
    print('RETAINED_ACTUAL_AVATAR_CLOSED_NATIVE_SOURCE_ROOT',root,flush=True)
    return directory
aliases=[(module,module.tempfile) for module in fixture_modules]
direct_modules=[importlib.import_module(name) for name in selected.get('directTemporaryDirectoryModules',[])]
direct_aliases=[(module,module.TemporaryDirectory) for module in direct_modules]
result=None;actual_ids=[]

class ImmediateResult(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test)
        self._case_start=dict(id=test.id(),nodeIndex=len(node_processes),ownerIndex=len(host_owners),
            failures=len(self.failures),errors=len(self.errors),skips=len(self.skipped))
    def stopTest(self,test):
        # unittest calls this AFTER this case's own doCleanups. Persist actual
        # completed per-case ownership before a later case could be interrupted.
        start=self._case_start;assert start['id']==test.id()
        def streams(process):return {name:None if getattr(process,name) is None else getattr(process,name).closed for name in ('stdin','stdout','stderr')}
        nodes=[dict(pid=row['pid'],commandKind=row['commandKind'],birth=row['birth'],current=proc(row['pid']),returnCode=row['process'].returncode,
            originalStreamsClosed=streams(row['process'])) for row in node_processes]
        closes=[dict(pid=row['process'].pid,entered=row['entered'],returned=row['returned'],unwound=row['unwound'],returnCode=row['returnCode']) for row in host_closes]
        remaining=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
            for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
        original_closed=all(any(row['process'] is owner['process'] and row['returned'] and row['returnCode']==0
            for row in host_closes) for owner in host_owners)
        known_gone=all(row['returnCode'] is not None and (row['current'] is None or row['birth'] is not None and row['current']['startTicks']!=row['birth']['startTicks']) for row in nodes)
        streams_closed=all(all(value is None or value is True for value in row['originalStreamsClosed'].values()) for row in nodes)
        passed=(len(self.failures)==start['failures'] and len(self.errors)==start['errors'] and len(self.skipped)==start['skips'])
        receipt=dict(testId=test.id(),caseSuccessful=passed,newNodeCount=sum(row['commandKind']=='node' for row in node_processes[start['nodeIndex']:]),newObservedSubprocessCount=len(node_processes)-start['nodeIndex'],
            newHostOwnerCount=len(host_owners)-start['ownerIndex'],actualCumulativeNodes=nodes,
            actualOriginalCloseCalls=closes,allKnownNodeProcessesGone=known_gone,allOriginalStreamsClosed=streams_closed,
            allObservedOriginalHostClosesCompleted=original_closed,remainingNewThreads=remaining,
            hostOnly=True,nativeQualified=False,wholeQualified=False)
        with (runroot/'case-stop-receipts.jsonl').open('a') as output:
            output.write(json.dumps(receipt)+'\n');output.flush();os.fsync(output.fileno())
        print('ACTUAL_CASE_STOP',json.dumps(receipt),flush=True)
        super().stopTest(test)
        assert known_gone and streams_closed and original_closed and not remaining,'Case original cleanup or new thread remains unresolved'
    def report_exception(self,test,error,kind):
        import traceback
        # Preserve the original traceback immediately, BEFORE any optional
        # metadata diagnostic. Never capture generic locals or configuration.
        text=''.join(traceback.format_exception(*error))
        self.stream.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text)
        self.stream.flush()
        with (runroot/'immediate-exceptions.log').open('a') as output:
            output.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text);output.flush();os.fsync(output.fileno())
        # Attached only to THIS failure event, including explicitly suppressed
        # from-None contexts. No global trace, stale exception or locals dump.
        pending=[('event',error[1])];seen=set();attached=[]
        while pending and len(attached)<16:
            edge,value=pending.pop(0)
            if id(value) in seen:continue
            seen.add(id(value));attached.append(dict(edge=edge,type=type(value).__name__,
                suppressedContext=bool(value.__suppress_context__),
                traceback=''.join(traceback.format_exception(type(value),value,value.__traceback__,chain=False))))
            if value.__cause__ is not None:pending.append(('cause',value.__cause__))
            if value.__context__ is not None:pending.append(('context',value.__context__))
        with (runroot/'event-exception-contexts.jsonl').open('a') as output:
            output.write(json.dumps(dict(testId=test.id(),kind=kind,attached=attached))+'\n');output.flush();os.fsync(output.fileno())

    def addError(self,test,error):
        super().addError(test,error);self.report_exception(test,error,'ERROR')
    def addFailure(self,test,error):
        super().addFailure(test,error);self.report_exception(test,error,'FAILURE')

try:
    for module,original in aliases:
        assert original is tempfile;module.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_directory)
    for module,original in direct_aliases:
        assert original is real_td;module.TemporaryDirectory=retained_directory
    ids=selected['caseIds'];assert len(ids)==len(set(ids))==selected['count']
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for child in value:yield from flatten(child)
        else:yield value
    actual_ids=[test.id() for test in flatten(suite)]
    assert not loader.errors and actual_ids==ids and suite.countTestCases()==selected['count'],(loader.errors,actual_ids)
    save(runroot/'selected-ids-actual.json',actual_ids);print('ACTUAL_SELECTED_IDS',json.dumps(actual_ids),flush=True)
    from selected_code_timing import SelectedCodeTiming
    from ios.adapters.script_runtime import IOSScriptRuntime
    from ios.adapters.installed_code import InstalledCodeBinding
    from ios.adapters.avatar_sources import IOSAvatarSources
    from adapters.original_marker_restoration_frames import OriginalMarkerRestorationFrames
    bindings={}
    for kind,names in ((IOSAvatarFeature,('actual','initialize','login','close_preparation_tablet','source_parts','sessions','session_inputs','preparation_closed_original','initial_original','wait_actor_preparation')),
                      (IOSScriptRuntime,('_sources',)),(InstalledCodeBinding,('verify','continuity')),
                      (IOSAvatarSources,('read',)),(OriginalMarkerRestorationFrames,('capture','frame'))):
        for name in names:bindings[kind.__name__+'.'+name]=getattr(kind,name).__code__
    timing=SelectedCodeTiming(bindings).start()
    try:
        result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=ImmediateResult).run(suite)
    finally:
        timing.stop();save(runroot/'actual-original-preparation-code-timings.json',timing.metadata())
    if result.wasSuccessful():assert result.testsRun==selected['count'] and not result.skipped,'All exact cases must execute without skip'
finally:
    observer.stop()
    audit_loaded_sdk()
    save(runroot/'monitoring-observer-mode.json',observer.metadata())
    for module,original in aliases:module.tempfile=original
    for module,original in direct_aliases:module.TemporaryDirectory=original
    assert all(module.TemporaryDirectory is original for module,original in direct_aliases)
    assert tempfile.TemporaryDirectory is real_td and all(module.tempfile is original for module,original in aliases)
    assert source_before=={str(path):pin(path) for path in sourcepaths},'Source/launcher/map changed'
    assert all_sources_before==sources(plan),'Full Source/launcher membership changed'
    imported={}
    for name,module in tuple(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if file is not None:
            path=Path(file).resolve()
            if REPO in path.parents:
                relative=str(path.relative_to(REPO));assert relative in all_sources_before,(name,relative)
                imported[name]=relative
    save(runroot/'actual-imported-local-sources.json',imported)
    def census():return {str(path.relative_to(temporary)):pin(path) for path in (temporary,*sorted(temporary.rglob('*')))}
    remaining_before=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
    first=census();second=census();assert first==second,'Post-test originals changed'
    save(runroot/'selected-originals-first.json',first);save(runroot/'selected-originals-second.json',second)
    remaining=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
    if result is not None and result.wasSuccessful() and result.testsRun==selected['count']:
        assert len(retained)==selected['expectedRetainedRoots'],'Unexpected actual fixture roots on full success'
    report=dict(kind=kind,testsRun=None if result is None else result.testsRun,selectedIds=actual_ids,
        successful=False if result is None else result.wasSuccessful(),skipped=[] if result is None else result.skipped,
        retainedTemporaryDirectoryRoots=retained,expectedRetainedRootCountOnFullSuccess=selected['expectedRetainedRoots'],fixtureAliasesRestored=True,sourceLauncherPinsUnchanged=True,
        originalCensusesEqual=True,remainingNewThreadsBeforeCensuses=remaining_before,remainingNewThreads=remaining,nativeCompiled=False,sdkExecuted=False,
        deviceQualified=False,wholeAvatarQualified=False,publicAreaAcceptanceChanged=False)
    report['modelBoundaries']=selected.get('modelBoundaries',[])
    def original_streams(process):
        return {name:None if getattr(process,name) is None else getattr(process,name).closed for name in ('stdin','stdout','stderr')}
    node_rows=[dict(pid=row['pid'],commandKind=row['commandKind'],birth=row['birth'],returnCode=row['process'].returncode,current=proc(row['pid']),originalStreamsClosed=original_streams(row['process'])) for row in node_processes]
    close_rows=[dict(pid=row['process'].pid,entered=row['entered'],returned=row['returned'],unwound=row['unwound'],returnCode=row['returnCode']) for row in host_closes]
    save(runroot/'actual-node-and-original-close.json',dict(nodes=node_rows,hostOwnerPids=[row['pid'] for row in host_owners],originalCloseCalls=close_rows))
    if result is not None and result.wasSuccessful() and 'expectedNodeProcessCount' in selected:
        assert sum(row['commandKind']=='node' for row in node_rows)==selected['expectedNodeProcessCount'],'Actual original Node count differs'
    report.update(actualPreimportAuditInstalled=True,actualNodeProcessCount=sum(row['commandKind']=='node' for row in node_rows),actualObservedSubprocessCount=len(node_rows),originalHostOwnerCount=len(host_owners),originalCloseCount=len(close_rows))
    save(runroot/'selected-result.json',report);print('ACTUAL_RESULT',json.dumps(report),flush=True)
    assert all(row['returnCode'] is not None and (row['current'] is None or row['birth'] is not None and row['current']['startTicks']!=row['birth']['startTicks']) for row in node_rows),'Original Node process remained live'
    assert all(all(closed is None or closed is True for closed in row['originalStreamsClosed'].values()) for row in node_rows),'Original Node stream still open after original cleanup'
    assert all(any(row['process'] is original['process'] and row['returned'] and row['returnCode']==0 for row in host_closes) for original in host_owners),'Original host app did not complete its own normal close/wait'
    assert not remaining_before and not remaining,'New fixture/worker/listener thread remains live around censuses'
sys.exit(0 if result is not None and result.wasSuccessful() else 1)
