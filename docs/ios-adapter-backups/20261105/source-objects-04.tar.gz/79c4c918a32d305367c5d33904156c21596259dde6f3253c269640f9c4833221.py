"""Independent Actor admission around actual Main replacement WAL boundaries.

These are negative/order counters. They do not mint any positive End proof or
claim the still-missing composed actual End/readmission/Audio integration.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import unittest
from copy import deepcopy
from ios.adapters.audio_whole_feature import AudioWholePending
from ios.self_tests.audio_whole_fixture import AudioWholeFixture

class AudioWholeActorReplacementTests(unittest.TestCase):
    def setUp(self):
        self.f=AudioWholeFixture(self);self.f.primary.prepare();self.f.actor.prepare()

    def test_actual_replacing_wal_waits_before_new_source_even_when_replacement_header_exists(self):
        f=self.f
        with f.primary.held():
            # This deliberately incomplete saved header cannot authorize any
            # replacement. A real process End may already have closed Source.
            f.primary.state['phase']='replacing'
            f.primary.state['replacement']=dict(newBinding=deepcopy(f.primary.state['bindings']['primary']))
            f.primary.save()
        before=f.source_calls
        with self.assertRaises(AudioWholePending):f.actor.observe(dict(contractVersion=16,runId=f.actor.run,afterSequence=0))
        self.assertEqual(before,f.source_calls)
        with f.actor.held():self.assertIsNone(f.actor.state['replacement']);self.assertIsNone(f.actor.state['oldEnd'])

    def test_cleaned_header_without_actual_end_readmission_and_restoration_cannot_adopt_actor_stage(self):
        f=self.f
        with f.primary.held():
            f.primary.state['phase']='cleaned'
            f.primary.state['replacement']=dict(newBinding=deepcopy(f.primary.state['bindings']['primary']))
            f.primary.save()
        before=f.source_calls
        with self.assertRaises((KeyError,ValueError)):f.actor.observe(dict(contractVersion=16,runId=f.actor.run,afterSequence=0))
        self.assertEqual(before,f.source_calls)
        with f.actor.held():self.assertIsNone(f.actor.state['replacement']);self.assertIsNone(f.actor.state['oldEnd'])

    def test_ordinary_initial_actor_keeps_its_original_stage_and_independent_fresh_source(self):
        f=self.f;before=f.source_calls
        with f.actor.held():
            initial=deepcopy(f.actor.state['bindings']);f.actor.sync_replacement()
            self.assertIsNone(f.actor.state['replacement']);self.assertIsNone(f.actor.state['oldEnd'])
            current=f.actor.current();reference,value=current.capture()
            self.assertEqual(initial['primary'],current.binding)
            self.assertEqual(reference,current.state['records'][-1]);self.assertEqual(initial,f.actor.state['bindings'])
        self.assertGreater(f.source_calls,before)
