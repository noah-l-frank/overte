"""Inspect immutable header/FD identity only; do not import runtime decoders."""
import base64,hashlib,json,os,zlib
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/emote-preserved747-post-reboot-replay-boundary-20261102'
ROOT=REPO/'.ios-host-tmp/emote-callback-window-literal-packet30-live735-normalized-root1-preparation-20261029/runs/window1/first-779325zy/temporary/tmpkxze988d'
WAL=ROOT/'ios-emote-primary-cccccccccccccccccccccccccccccccc-terminal-live.json'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
 a=path.lstat();raw=path.read_bytes();b=path.lstat();assert all(getattr(a,k)==getattr(b,k) for k in FIELDS)
 return dict(path=str(path.relative_to(REPO)),sha256=hashlib.sha256(raw).hexdigest(),stat={k:getattr(a,k) for k in FIELDS})
source=REPO/'tests/device/adapters/original_frame_store.py';source_before=pin(source);wal_before=pin(WAL)
value=json.loads(WAL.read_text());payload=value['payload'];assert payload['encoding']=='zlib-base64-json' and 2<=payload['bytes']<=16*1024*1024
encoded=base64.b64decode(payload['data'],validate=True);decoder=zlib.decompressobj();raw=decoder.decompress(encoded,payload['bytes']+1)
assert len(raw)==payload['bytes'] and decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail and hashlib.sha256(raw).hexdigest()==payload['sha256']
state=json.loads(raw);assert type(state) is list and len(state)==1 and len(state[0]['records'])==2 and state[0]['pending'] is None
rows=[]
for reference in state[0]['records']:
 path=ROOT/('emote-rooted-live-frame-inputs-'+value['runId']+'-'+value['role']+'-'+format(reference['index'],'04d')+'-'+reference['sha256']+'.json')
 before=pin(path);fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
 try:actual=os.fstat(fd)
 finally:os.close(fd)
 assert before==pin(path)
 declared=reference['device'],reference['inode'];observed=actual.st_dev,actual.st_ino
 assert declared[0]==36 and observed[0]==53 and declared[1]==observed[1]
 assert actual.st_size==reference['bytes'] and before['sha256']==reference['sha256']
 rows.append(dict(index=reference['index'],declaredRuntimeFileIdentity=dict(device=declared[0],inode=declared[1]),actualReadonlyFDIdentity=dict(device=observed[0],inode=observed[1]),actualSourceIdentityEquality=False,rawBytesAndSha256StillExact=True,filePin=before))
assert source_before==pin(source) and wal_before==pin(WAL)
result=dict(status='ARCHIVED747_RUNTIME_REPLAY_UNAVAILABLE_AFTER_REMOUNT',evidenceKind='Bounded stdlib metadata decoding and actual readonly fstat; no target import/test/runtime replay',sourceGuard='OriginalFrameStore.file requires exact FD/path/declared (st_dev,st_ino) equality; no historical retention exception exists',sourcePin=source_before,liveWALPin=wal_before,records=rows,inputsUnchanged=True,originalEvidenceRewritten=False,runtimeFileGuardsChanged=False,retentionBridgeApplicableToRuntime=False,hardHoldControllers=['.ios-host-tmp/emote-callback-live-prefix-cold-warm747-root-preparation-20261102'],nextExecutableScope='After reviewed source/counterexamples pass, create a genuine NEW postboot normal CallbackSceneFixture/Live2 graph, preserving original typed birth/file identities, then cold/warm read that new graph. No prior graph normalization or same-generation timestamp rewrite.',nativeSDKAuthWholeQualified=False)
path=HERE/'metadata-receipt.json'
with path.open('x') as stream:json.dump(result,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps(dict(status=result['status'],records=len(rows),receipt=str(path),sourceSHA256=source_before['sha256'])))
