"""Negative-only exact join locals. Never a native or timing authority."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from pathlib import Path
import hashlib,marshal,sys
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState

PROFILE='native-clock-join-native-host-refusal-original-locals-v1'
_ACTIVE=ContextVar('native_clock_join_refusal_original',default=None)

def current_refusal_original():return _ACTIVE.get()


class NativeClockJoinRefusalOriginal:
    def __init__(self,path,diagnostic_context):
        need(type(self)is NativeClockJoinRefusalOriginal)
        repo=Path.cwd().resolve(strict=True);self.path=Path(path)
        need(repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file())
        need(self.path.is_absolute()and self.path.resolve()==self.path and self.path.is_relative_to(repo/'.ios-host-tmp')
            and self.path.name=='native-clock-join-refusal-original.json'and type(diagnostic_context)is dict)
        self.context=deepcopy(diagnostic_context);self.store=PrivateFeatureState(self.path)
        need(self.store.read()is None)
        self.written=False;self.owner=None;self.ports=None;self.used=False
        self.methods=tuple((name,getattr(type(self),name),getattr(type(self),name).__code__)for name in('__init__','capture'))

    @contextmanager
    def scope(self):
        from adapters import native_clock_join as source
        need(_ACTIVE.get()is None and not self.written and self.ports is None and not self.used)
        self.used=True
        cls=source.NativeClockAcquisition;validate=source.validate_join;finish=cls.finish
        self.ports=(source,validate,validate.__code__,validate.__globals__,cls,finish,finish.__code__,finish.__globals__)
        token=_ACTIVE.set(self)
        try:yield self
        finally:
            _ACTIVE.reset(token)
            self.owner=None;self.ports=None # Never extend a live SDK/source lifetime after this scope.

    def capture(self,condition,record,originals,start,end,before,after,first,last):
        # Called only after the original single compound expression is False.
        # Do NOT call acquisition.native/read/guard, epoch_ms/monotonic, a
        # source/SDK getter, validate_join again, or recompute its predicate.
        need(type(condition)is bool and condition is False and not self.written and _ACTIVE.get()is self)
        for name,function,code in self.methods:need(getattr(type(self),name)is function and function.__code__ is code)
        source,validate,validate_code,validate_globals,cls,finish,finish_code,finish_globals=self.ports
        need(sys.modules.get('adapters.native_clock_join')is source and source.validate_join is validate
            and validate.__code__ is validate_code and validate.__globals__ is validate_globals
            and source.NativeClockAcquisition is cls and cls.finish is finish and finish.__code__ is finish_code)
        caller=sys._getframe(1);acquisition=caller.f_back
        need(caller.f_code is validate_code and caller.f_globals is validate_globals
            and caller.f_locals.get('record')is record and caller.f_locals.get('originals')is originals
            and acquisition is not None and acquisition.f_code is finish_code and acquisition.f_globals is finish_globals
            and acquisition.f_locals.get('record')is record and acquisition.f_locals.get('originals')is originals)
        owner=acquisition.f_locals.get('self');need(type(owner)is cls and (self.owner is None or self.owner is owner))
        # Strong receiver custody is diagnostic only; it never lends SDK/run
        # admission or turns this failure's values into a current observation.
        self.owner=owner
        value=dict(nativeClockJoinRefusalOriginalVersion=1,profile=PROFILE,stage='native-host-identity-order-span-lifecycle',condition=False,
            diagnosticContext=deepcopy(self.context),actualValidateCodeSha256=hashlib.sha256(marshal.dumps(validate_code)).hexdigest(),
            actualFinishCodeSha256=hashlib.sha256(marshal.dumps(finish_code)).hexdigest(),
            locals=dict(start=start,end=end,before=before,after=after,first=deepcopy(first),last=deepcopy(last),record=deepcopy(record)))
        # New one-shot original only. An output error must remain an error;
        # validate_join's finally preserves the original false need() refusal.
        self.store.write(value,None);self.written=True
