from pathlib import Path
import ast,difflib,json,hashlib
r=Path.cwd().resolve();assert r.name=='overte-ios-feature-adapters-resume-20261026'and(r/'.git').is_file();p=r/'.ios-host-tmp/world-host-timing-source9-closed-utility8-bootstrap1-real-origin-context-code-preparation-20261104';assert p.resolve().is_relative_to(r)
b=p.with_name('c24-diagnostic-source3-closed-utility14-bootstrap2-genuine-class-cleanup-code-preparation-20261104');s=p.with_name('root-world-host-timing-unknown-return-source9-private-20261104');review=p.with_name('lifecycle-independent-world-host-timing-source9-full-unknown-return-review-20261104')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,v):
 f=p/n;assert f.resolve().is_relative_to(r)and not f.exists();f.write_text(v)
def dump(v):return json.dumps(v,sort_keys=True,indent=2)+'\n'
assert sha(s/'source-freeze.json')=='15c88ca34a48ff6762e3675ac6fb8f9b9a61e679beb43377951b0dcd97835ceb'
assert sha(b/'source-freeze.json')=='119d34ed5aa8c246dd880992bcbc3c3a9d154de508d2276d7503395c5b76df3d'
assert sha(review/'freeze.json')=='cccd647fa15f3576d854622ae7035ae08f3fc35e10996afd6975c703c3f915ab'
for n in('host_function_timing.py','test_world_host_function_timing.py'):assert(p/n).read_bytes()==(s/'candidate'/n).read_bytes()
for n in('metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','class_cleanup_custody.py','source_execution_readiness.py','readonly-shared-stdlib-sources.json'):assert(p/n).read_bytes()==(b/n).read_bytes()
assert(p/'exact-eight-selectors.json').read_bytes()==(s/'PROSPECTIVE-EIGHT-SELECTORS.json').read_bytes()
py={f.name:sha(f)for f in p.glob('*.py')};assert len(py)==11
for f in p.glob('*.py'):ast.parse(f.read_text(),filename=str(f))
ids=json.loads((p/'exact-eight-selectors.json').read_text())['caseIds'];assert len(ids)==len(set(ids))==8
cls=next(n for n in ast.parse((p/'test_world_host_function_timing.py').read_text()).body if isinstance(n,ast.ClassDef))
assert {n.name for n in cls.body if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')}=={v.rsplit('.',1)[-1]for v in ids}
refs={}
for folder,leaf in((s,'source-freeze.json'),(b,'source-freeze.json'),(review,'freeze.json')):
 f=folder/leaf;refs[str(f)]=sha(f)
 for name,row in json.loads(f.read_text())['files'].items():
  q=folder/name;expected=row if type(row)is str else row['sha256'];assert sha(q)==expected;refs[str(q)]=sha(q)
for n,old in [('prepare.py','prepare.py'),('run-eight.py','run-fourteen.py'),('supervise-eight.py','supervise-fourteen.py')]:
 put(n+'.utility14b2-to-world8.patch',''.join(difflib.unified_diff((b/old).read_text().splitlines(True),(p/n).read_text().splitlines(True),fromfile='Utility14B2/'+old,tofile='WorldUtility8/'+n)))
runner=(p/'run-eight.py').read_text();outer=(p/'supervise-eight.py').read_text();prep=(p/'prepare.py').read_text()
for field in('actual-configure-current-origin-context.json','actualSourceExecutions','actual-class-cleanup-calls.json','actual-class-cleanup-restoration.json','allThreeActualRuntimeOriginsEstablished'):assert field in runner and field in outer
assert 'origins.execution_row(name,module,actual)'in runner and 'execution=origins.python_executions[name]'in runner
assert 'dict(plan=origin_plan,origins=origins,pin=pin)'in runner and 'origins.plan is origin_plan'in runner
assert outer.count('dict(HERE=census(HERE),outer=census(COLLECTOR))')==2
assert 'test_host_function_timing'not in prep and 'test_world_host_function_timing'in prep
put('SOURCE-REFERENCES.json',dump(refs))
put('STATIC-READBACK.json',dump(dict(status='AUTHOR_CRITICAL_SOURCE_ONLY_UNRUN',elevenPythonASTs=py,actualOriginalEightBodiesAndHelperBytesExact=True,oldFiveBodiesAndFortyTargetTableNotChanged=True,actualConfigurePlanIsOriginsPlan=True,actualOriginalSourceExecutionTupleAndExecutionRowRequired=True,noFakeModuleSpecFrameOriginOrExecutionTuple=True,sharedClassCleanupByteExact=sha(p/'class_cleanup_custody.py'),expectedActualClassCleanupGroups=1,requiredActualRuntimeOrigins=3,caseChildren=0,threads=0,TDs=0,NodeExecutions=0,network=False,SDKExecutions=0,overteNativeQueries=0,wallSeconds=30,killGraceSeconds=5,wholeHEREAndOuterCensusesThirdRoom=True,worldRunnableBootstrap=False,utilityQualification=None,worldConsumerAdmission=None,imports=0,builders=0,maps=0,targets=0,censuses=0)))
put('source-freeze.json',dump(dict(schemaVersion=1,status='FROZEN_SOURCE_ONLY_WORLD_HOST_TIMING8_UTILITY_REAL_ORIGIN_CONTEXT_UNRUN',files={f.name:sha(f)for f in sorted(p.iterdir())},subjectSource9Freeze=sha(s/'source-freeze.json'),subjectIndependentReviewFreeze=sha(review/'freeze.json'),sharedClassCleanupSourceFreeze=sha(b/'source-freeze.json'),utilityQualification=None,worldConsumerAdmission=None,worldNativeQualified=False,wholeQualified=False,imports=0,builders=0,maps=0,targets=0,censuses=0)))
print(p/'source-freeze.json');print(sha(p/'source-freeze.json'));print('members',len(json.loads((p/'source-freeze.json').read_text())['files']),'ASTs',len(py),'refs',len(refs))
