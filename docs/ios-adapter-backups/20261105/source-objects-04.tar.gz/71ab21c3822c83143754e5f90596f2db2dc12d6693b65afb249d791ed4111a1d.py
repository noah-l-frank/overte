"""Genuine owner/PFS/OFS/lock controls; no received-native positive producer.

The existing declared NativeClock/phase model is reused unchanged. Refused or
wrong microphone replies never become a received capture. No PCM/tone/peer
producer is added; complete live received acquisition remains unqualified.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import unpack
from feature_journeys.phase_fixture import PhaseFixtureReader
from ios.adapters.audio_received_mixer_owner import IOSAudioReceivedMixerOwner
from ios.self_tests.test_ios_audio_recorded_owner import AudioRecordedOwnerTests,BINDING,RUN
from ios.self_tests.test_ios_audio_pcm_lease import PCMModel
from ios.self_tests.test_ios_audio_passive_owner import PassiveBoundary


class UnavailableReceiveTransport:
    def __init__(self):self.commands=[]
    def send(self,query):
        self.commands.append(deepcopy(query))
        raise NativeUIError('Counter actual receive-manager return is unavailable; no producer success')
    def read(self):raise AssertionError('No getter after the genuine send raised')


class ReceivedMixerOwnerBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.fixture=AudioRecordedOwnerTests();self.fixture.setUp();self.addCleanup(self.fixture.doCleanups)
        self.model=self.fixture.model;self.root=self.fixture.root/'received';self.root.mkdir(mode=0o700)
        self.store=PrivateFeatureState(self.root/IOSAudioReceivedMixerOwner.STORE_NAME)
        self.transport=UnavailableReceiveTransport()

    @contextmanager
    def owner(self,*,store=None):
        m=self.model;native,_unused=PCMModel(m).reader()
        with self.fixture.lock.held():
            yield IOSAudioReceivedMixerOwner(self.store if store is None else store,self.root,BINDING,RUN,'4'*32,
                self.fixture.lock,m.guard,native=native,transport=dict(send=self.transport.send,read=self.transport.read),
                phase=PhaseFixtureReader(m.client(),RUN,'audio',epoch_ms=m.epoch,monotonic=lambda:m.clock),
                epoch_ms=m.epoch,monotonic=lambda:m.clock,sleep=m.sleep)

    def saved_state(self):return unpack(self.store.read()['payload'])[0]

    def test_failed_start_retains_durable_original_command_and_no_birth_or_capture_success(self):
        with self.owner()as owner,self.assertRaises(NativeUIError):owner.start(6)
        actual=self.saved_state();self.assertEqual(1,len(self.transport.commands))
        self.assertEqual(self.transport.commands[0],actual['start'])
        self.assertEqual('start-issued',actual['phase']);self.assertIsNone(actual['birth']);self.assertIsNone(actual['snapshot'])
        self.assertIsNone(actual['absence']);self.assertTrue(any(p.name.startswith('ios-audio-received-mixer-')for p in self.root.iterdir()))

    def test_reconstruction_observes_uncertain_start_without_second_start(self):
        with self.owner()as owner,self.assertRaises(NativeUIError):owner.start(6)
        first=deepcopy(self.saved_state()['start'])
        with self.owner()as owner,self.assertRaises(NativeUIError):owner.start(6)
        self.assertEqual(['start','observe'],[q['operation']for q in self.transport.commands])
        self.assertEqual(first,self.saved_state()['start']);self.assertTrue(all(q['startCommandId']==first['commandId']for q in self.transport.commands))
        self.assertIsNone(self.saved_state()['birth'])

    def test_genuine_microphone_family_reply_cannot_be_promoted_to_received_original(self):
        self.transport=PassiveBoundary(self.model)
        with self.owner()as owner,self.assertRaises(NativeUIError):owner.start(6)
        self.assertEqual(1,self.transport.count('start'));actual=self.saved_state()
        self.assertIsNone(actual['birth']);self.assertIsNone(actual['snapshot']);self.assertIsNone(actual['absence'])
        self.assertEqual(0,actual['streams']['proofs']['revision'])

    def test_wrong_microphone_store_filename_refuses_before_any_transport_or_clock_query(self):
        wrong=PrivateFeatureState(self.root/'ios-audio-passive-owner.json');before=deepcopy(self.model.native.sample)
        with self.assertRaises(NativeUIError):
            with self.owner(store=wrong):pass
        self.assertEqual([],self.transport.commands);self.assertIsNone(wrong.read());self.assertIsNone(self.store.read())
        self.assertEqual(before,self.model.native.sample)

    def test_real_historical_constructor_keeps_originals_and_cannot_allocate_or_query(self):
        with self.owner()as owner,self.assertRaises(NativeUIError):owner.start(6)
        before={p:(p.stat().st_ino,p.read_bytes())for p in self.root.iterdir()};queries=deepcopy(self.transport.commands)
        with self.fixture.lock.held():
            owner=IOSAudioReceivedMixerOwner.archive(self.store,self.root,BINDING,RUN,'4'*32,self.fixture.lock,
                self.model.client().url+'/runs/'+RUN+'/')
            self.assertTrue(owner.historical)
            with self.assertRaises(NativeUIError):owner.control('observe')
            with self.assertRaises(NativeUIError):owner.original()
        self.assertEqual(queries,self.transport.commands);self.assertEqual(before,{p:(p.stat().st_ino,p.read_bytes())for p in self.root.iterdir()})

    def test_actual_saved_intent_lost_return_recovers_same_inode_before_observe_never_resends_start(self):
        original=OriginalFrameStore.write;lost=[]
        def saved_then_lost(store,index,value):
            reference=original(store,index,value)
            if store.namespace=='ios-audio-received-mixer-passive'and not lost:
                lost.append((store.path(store.expand(reference)),reference))
                raise NativeUIError('Counter actual saved original return lost before journal completion')
            return reference
        with patch.object(OriginalFrameStore,'write',saved_then_lost):
            with self.owner()as owner,self.assertRaises(NativeUIError):owner.start(6)
        self.assertEqual([],self.transport.commands);self.assertEqual(1,len(lost))
        path,_reference=lost[0];original_identity=(path.stat().st_ino,path.read_bytes())
        with self.owner()as owner,self.assertRaises(NativeUIError):owner.start(6)
        self.assertEqual(['observe'],[q['operation']for q in self.transport.commands])
        self.assertEqual(original_identity,(path.stat().st_ino,path.read_bytes()))
        self.assertIsNotNone(self.saved_state()['start']);self.assertIsNone(self.saved_state()['pending']);self.assertIsNone(self.saved_state()['birth'])

    def test_actual_owner_family_rebinding_refuses_before_query_or_original_write(self):
        from ios.adapters import audio_passive_capture_source
        with self.owner()as owner:
            before={p:(p.stat().st_ino,p.read_bytes())for p in self.root.iterdir()}
            owner.CONTRACT=audio_passive_capture_source
            with self.assertRaises(NativeUIError):owner.file_guard()
        self.assertEqual([],self.transport.commands)
        self.assertEqual(before,{p:(p.stat().st_ino,p.read_bytes())for p in self.root.iterdir()})

    def test_existing_microphone_constructor_capture_and_retirement_keep_original_family(self):
        from ios.self_tests.test_ios_audio_passive_owner import AudioPassiveOwnerTests
        from ios.adapters.audio_passive_owner import IOSAudioPassiveOwner
        fixture=AudioPassiveOwnerTests();fixture.setUp();self.addCleanup(fixture.doCleanups)
        fixture.begin()
        with fixture.owner()as owner:
            self.assertIs(type(owner),IOSAudioPassiveOwner)
            self.assertEqual('ios-audio-passive-owner.json',owner.store.path.name)
            self.assertEqual(1,owner.envelope()['iosAudioPassiveOwnerVersion'])
            self.assertNotIn('iosAudioReceivedMixerOwnerVersion',owner.envelope())
            captured=owner.capture();self.assertEqual(96044,len(captured['wav']))
            self.assertTrue(owner.retire()['retired'])
            self.assertTrue(all(j.files.schema_prefix=='iosAudioPassive'and j.files.namespace.startswith('ios-audio-passive-')for j in owner.journals.values()))
        self.assertEqual([],self.transport.commands)
