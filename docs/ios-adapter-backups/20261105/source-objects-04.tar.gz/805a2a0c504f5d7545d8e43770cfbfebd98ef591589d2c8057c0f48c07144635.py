"""Prospective pure host Budget counters; no installed/native/runtime owner."""
from types import SimpleNamespace
import sys
from pathlib import Path
import json
import struct
import tempfile
import unittest
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from adapters.api_budget_refusal_original import ApiBudgetRefusalOriginal, refusal_original
from ios.adapters import world_web_api_clock as api


class Clock:
    def __init__(self, value=1.):
        self.value = value
        self.calls = 0

    def __call__(self):
        self.calls += 1
        return self.value


class WorldWebApiRefusalOriginalTests(unittest.TestCase):
    def setUp(self):
        # A later exact controller must retain this real TD and measure its
        # genuine cleanup; this source packet does not execute it.
        root = self.enterContext(tempfile.TemporaryDirectory(
            prefix='world-budget-refusal-', dir=Path.cwd()/'.ios-host-tmp'))
        self.path = Path(root)/'api-budget-refusal-original.json'

    def collector(self):
        return ApiBudgetRefusalOriginal(self.path, 'world-web', {'case': self.id()})

    def record(self):
        return json.loads(self.path.read_text())

    def test_default_none_keeps_original_refusal_and_exact_clock_call_count(self):
        clock = Clock()
        owner = api.Budget(clock)
        self.assertEqual(1, clock.calls)
        clock.value = 26.
        with self.assertRaisesRegex(NativeUIError, '^World Web API budget exhausted or host clock changed$'):
            owner.check()
        self.assertEqual(2, clock.calls)
        self.assertTrue(owner.failed)
        self.assertFalse(self.path.exists())

    def test_real_deadline_refusal_retains_original_grant_and_no_extra_clock(self):
        clock = Clock()
        observer = self.collector()
        with observer.scope(api):
            owner = api.Budget(clock)
            clock.value = 2.
            self.assertEqual(2., owner.check())
            self.assertFalse(self.path.exists())
            clock.value = 26.
            with self.assertRaisesRegex(NativeUIError, '^World Web API budget exhausted or host clock changed$'):
                owner.check()
            self.assertTrue(owner.failed)
            self.assertEqual(3, clock.calls)
        original = self.record()
        self.assertEqual(25, original['constructorGrant']['seconds'])
        self.assertEqual(struct.pack('>d', 26.).hex(), original['constructorGrant']['grantedDeadline']['ieee754BigEndianHex'])
        self.assertEqual(struct.pack('>d', 2.).hex(), original['afterPredicateStateSnapshot']['last']['ieee754BigEndianHex'])
        self.assertFalse(original['afterPredicateStateSnapshot']['failed']['value'])
        self.assertTrue(original['snapshotIsNotExecutedShortCircuitOperandTrace'])
        self.assertFalse(original['observationAuthority'])

    def test_backwards_clock_refuses_below_unchanged_original_deadline(self):
        clock = Clock(5.)
        with self.collector().scope(api):
            owner = api.Budget(clock)
            clock.value = 4.
            with self.assertRaises(NativeUIError):
                owner.check()
            self.assertTrue(owner.failed)
        original = self.record()
        self.assertEqual(2, clock.calls)
        self.assertEqual(struct.pack('>d', 4.).hex(), original['calculatedLocalValue']['ieee754BigEndianHex'])
        self.assertEqual(struct.pack('>d', 30.).hex(), original['constructorGrant']['grantedDeadline']['ieee754BigEndianHex'])

    def test_invalid_constructor_first_clock_has_no_invented_grant(self):
        clock = Clock(float('nan'))
        with self.collector().scope(api), self.assertRaisesRegex(NativeUIError, '^World Web API budget exhausted or host clock changed$'):
            api.Budget(clock)
        self.assertEqual(1, clock.calls)
        original = self.record()
        self.assertIsNone(original['constructorGrant'])
        self.assertEqual('float', original['calculatedLocalValue']['type'])
        self.assertEqual(struct.pack('>d', clock.value).hex(), original['calculatedLocalValue']['ieee754BigEndianHex'])

    def test_diagnostic_write_failure_keeps_original_error_and_failed_latch(self):
        clock = Clock()
        observer = self.collector()
        with observer.scope(api):
            owner = api.Budget(clock)
            clock.value = 26.
            with patch.object(observer.store, 'write', side_effect=OSError('own diagnostic output unavailable')):
                with self.assertRaisesRegex(NativeUIError, '^World Web API budget exhausted or host clock changed$'):
                    owner.check()
            self.assertTrue(owner.failed)
            self.assertEqual(2, clock.calls)
        self.assertFalse(self.path.exists())

    def test_foreign_caller_cannot_write_actual_budget_diagnostic(self):
        clock = Clock()
        with self.collector().scope(api):
            owner = api.Budget(clock)
            with self.assertRaises(NativeUIError):
                refusal_original(owner, 26.)
            self.assertFalse(owner.failed)
            self.assertEqual(1, clock.calls)
        self.assertFalse(self.path.exists())

    def test_changed_actual_check_binding_refuses_and_does_not_write(self):
        clock = Clock()
        with self.collector().scope(api):
            owner = api.Budget(clock)
            original = api.Budget.check
            clock.value = 26.
            with patch.object(api.Budget, 'check', lambda self: original(self)):
                with self.assertRaisesRegex(NativeUIError, '^World Web API budget exhausted or host clock changed$'):
                    owner.check()
            self.assertTrue(owner.failed)
        self.assertFalse(self.path.exists())

    def test_nested_scope_keeps_the_actual_original_twenty_five_second_grant(self):
        clock = Clock()
        observer = self.collector()
        previous = api._CURRENT.get()
        with observer.scope(api):
            with self.assertRaises(NativeUIError), api.scope(clock):
                owner = api._CURRENT.get()
                self.assertIsNotNone(owner)
                original_deadline = owner.deadline
                clock.value = 26.
                with api.scope(clock):
                    api.check()
            self.assertTrue(owner.failed)
            self.assertIs(owner.deadline, original_deadline)
        original = self.record()
        self.assertEqual(25, original['constructorGrant']['seconds'])
        self.assertEqual(struct.pack('>d', 26.).hex(), original['constructorGrant']['grantedDeadline']['ieee754BigEndianHex'])
        self.assertIs(previous, api._CURRENT.get())

    def test_frame_shaped_foreign_capture_cannot_mint_a_refusal(self):
        clock = Clock()
        observer = self.collector()
        with observer.scope(api):
            owner = api.Budget(clock)
            value = 26.
            fake = SimpleNamespace(f_code=api.Budget.check.__code__,
                                   f_globals=vars(api),
                                   f_locals={'self': owner, 'value': value})
            with self.assertRaises(NativeUIError):
                observer.capture(owner, value, fake)
            self.assertFalse(owner.failed)
        self.assertFalse(self.path.exists())

    def test_real_check_frame_inside_monotonic_callback_is_not_a_refusal(self):
        observer = self.collector()
        armed = False
        owner = None
        calls = []
        def clock():
            calls.append(True)
            if armed:
                genuine_check_frame = sys._getframe(1)
                with self.assertRaises(NativeUIError):
                    observer.capture(owner, genuine_check_frame.f_locals.get('value'), genuine_check_frame)
                self.assertFalse(self.path.exists())
                self.assertFalse(owner.failed)
                return 26.
            return 1.
        with observer.scope(api):
            owner = api.Budget(clock)
            armed = True
            with self.assertRaisesRegex(NativeUIError, '^World Web API budget exhausted or host clock changed$'):
                owner.check()
            self.assertTrue(owner.failed)
        self.assertEqual(2, len(calls))
        self.assertTrue(self.record()['originalPredicateRefused'])

    def test_actual_existing_pfs_cas_conflict_keeps_original_bytes_inode_and_failed_latch(self):
        clock = Clock()
        observer = self.collector()
        with observer.scope(api):
            owner = api.Budget(clock)
            observer.store.write({'actualOwnedPFSConflict': 1}, None)
            original_bytes = self.path.read_bytes()
            original_stat = self.path.stat()
            clock.value = 26.
            with self.assertRaisesRegex(NativeUIError, '^World Web API budget exhausted or host clock changed$'):
                owner.check()
            self.assertTrue(owner.failed)
            self.assertFalse(observer.written)
            self.assertEqual(2, clock.calls)
            self.assertEqual(original_bytes, self.path.read_bytes())
            current_stat = self.path.stat()
            self.assertEqual((original_stat.st_dev, original_stat.st_ino,
                              original_stat.st_mode, original_stat.st_size,
                              original_stat.st_mtime_ns, original_stat.st_ctime_ns),
                             (current_stat.st_dev, current_stat.st_ino,
                              current_stat.st_mode, current_stat.st_size,
                              current_stat.st_mtime_ns, current_stat.st_ctime_ns))
        self.assertEqual({'actualOwnedPFSConflict': 1}, self.record())
