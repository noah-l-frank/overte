"""Real canonical factory/HTTP/WAL controls over declared native lower originals.

No device, native parser, SDK service, HID authority, PNG or feature End is run.
Every posted fact is derived by the genuine received-Actor owned-packet and
publication constructors; there is no prebuilt expected journal/native proof.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import threading,time,unittest
from copy import deepcopy
from unittest.mock import patch
from feature_journeys import server as fixture_server
from feature_journeys.server import make_server,Handler
from feature_journeys.witness import Client
from feature_journeys.phase_fixture import PhaseFixtureReader
from adapters.native_feature_observation import need
from adapters.script_feature.history import unpack
from ios.adapters.lifecycle_actor_publication import LifecycleActorCanonicalPublication
from ios.self_tests.lifecycle_received_actor_domain import LifecycleReceivedActorDomain

READER='r'*64
ACTOR='a'*64
TICKET='d'*32


class ActualEndpointClient(Client):
    """Always delegates to the real original Client/HTTP path before loss."""
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.posts=[];self.lose_next_post=False
    def request(self,path,value=None,method=None,**kwargs):
        posting=path.endswith('/samples')and value is not None
        if posting:self.posts.append(deepcopy(value))
        result=super().request(path,value,method,**kwargs)
        if posting and self.lose_next_post:
            self.lose_next_post=False;raise OSError('Actual real endpoint accepted original; caller return lost')
        return result


class LifecycleActorServerRouteTests(unittest.TestCase):
    def setUp(self):self.servers=[]

    def endpoint(self,*,enabled=False,peer=None):
        server=make_server(READER,ACTOR,browser_peer_of=peer,lifecycle_actor_originals=enabled)
        self.servers.append(server);threads=[];gate=threading.Lock();worker=None
        class HeldOriginalHandler(Handler):
            def handle(receiver):
                # Actual handler callback, not a global thread-difference guess.
                need(receiver.server is server)
                with gate:threads.append(threading.current_thread())
                return super().handle()
        server.RequestHandlerClass=HeldOriginalHandler
        def stop():
            try:
                if worker is not None and worker.is_alive():server.shutdown()
            finally:
                try:
                    if worker is not None and worker.ident is not None:worker.join(timeout=2)
                finally:
                    server.server_close()
                    with gate:actual=tuple(threads)
                    deadline=time.monotonic()+2
                    for thread in actual:
                        if thread is not threading.current_thread():thread.join(timeout=max(0,deadline-time.monotonic()))
                    self.assertTrue(worker is None or not worker.is_alive())
                    self.assertTrue(all(not thread.is_alive()for thread in actual))
                    self.assertEqual(-1,server.socket.fileno())
        # Cleanup is registered before any actual Thread.start attempt.
        self.addCleanup(stop)
        worker=threading.Thread(target=lambda:server.serve_forever(poll_interval=.01),daemon=True);worker.start()
        url='http://127.0.0.1:'+str(server.server_address[1])+'/feature-fixture/v1'
        return server,url

    def originals(self,url,server):
        reader=ActualEndpointClient(url,READER);run,_=reader.register('lifecycle-input');reader.activate(TICKET)
        actor=ActualEndpointClient(url,ACTOR)
        domain=LifecycleReceivedActorDomain(self,run)
        # Original source/SDK constructors have run; no World/phase original or
        # owner exists yet. Select the real canonical client before owner birth.
        need(domain.sequence==0 and not domain.queries and domain.raw is None)
        domain.client=actor;domain.journal=server.journal
        domain.phase=PhaseFixtureReader(actor,run,'lifecycle-input',epoch_ms=domain.clock,monotonic=domain.mono)
        return reader,actor,domain

    def test_real_factory_optin_posts_genuine_owned_actor_original_and_duplicate_does_not_repost(self):
        server,url=self.endpoint(enabled=True);reader,actor,domain=self.originals(url,server)
        self.assertIs(server.journal.lifecycle_actor_originals,True)
        with domain.lock.held():
            owners=(domain.owner(1),domain.owner(2));original=owners[0].acquire(TICKET)
            publication=LifecycleActorCanonicalPublication(owners,actor)
            self.assertEqual(1,publication.publish(1));self.assertEqual(1,publication.publish(1))
            rows=publication.history();journal=reader.request('/runs/'+domain.run)
            self.assertEqual(1,len(actor.posts));self.assertEqual(1,len(journal['entries']));self.assertEqual(1,len(domain.queries))
            self.assertEqual('published',rows[0]['mode']);self.assertEqual(actor.posts[0]['facts']['ownerSha256'],original['ownerSha256'])
            self.assertEqual(journal['entries'][0],rows[0]['entry']);self.assertFalse(original['nativeQualified'])

    def test_real_default_factory_rejects_new_original_family_and_retains_issued_publication(self):
        server,url=self.endpoint();reader,actor,domain=self.originals(url,server)
        self.assertIs(server.journal.lifecycle_actor_originals,False)
        with domain.lock.held():
            owners=(domain.owner(1),domain.owner(2));saved=owners[0].acquire(TICKET)
            publication=LifecycleActorCanonicalPublication(owners,actor)
            with self.assertRaises(ValueError):publication.publish(1)
            state=unpack(publication.store.read()['payload'])[0]
            self.assertEqual('issued',state['pending']['phase']);self.assertTrue(publication.publisher.failed)
            self.assertEqual([],reader.request('/runs/'+domain.run)['entries'])
            self.assertEqual(saved,owners[0].original());self.assertEqual(1,len(actor.posts));self.assertEqual(1,len(domain.queries))

    def test_real_reader_credential_cannot_publish_new_family_or_consume_actor_originals(self):
        server,url=self.endpoint(enabled=True);reader,actor,domain=self.originals(url,server)
        with domain.lock.held():
            owners=(domain.owner(1),domain.owner(2));saved=owners[0].acquire(TICKET)
            publication=LifecycleActorCanonicalPublication(owners,reader)
            with self.assertRaises(ValueError):publication.publish(1)
            self.assertEqual([],reader.request('/runs/'+domain.run)['entries']);self.assertEqual(1,len(reader.posts))
            self.assertEqual(saved,owners[0].original());self.assertEqual(1,len(domain.queries))
            self.assertEqual('issued',unpack(publication.store.read()['payload'])[0]['pending']['phase'])

    def test_real_committed_http_return_loss_reopens_journal_without_native_or_post_replay(self):
        server,url=self.endpoint(enabled=True);reader,actor,domain=self.originals(url,server)
        with domain.lock.held():
            owners=(domain.owner(1),domain.owner(2));saved=owners[0].acquire(TICKET)
            publication=LifecycleActorCanonicalPublication(owners,actor);actor.lose_next_post=True
            with self.assertRaises(OSError):publication.publish(1)
            pending=deepcopy(unpack(publication.store.read()['payload'])[0]['pending'])
            self.assertEqual('issued',pending['phase']);self.assertEqual(1,len(reader.request('/runs/'+domain.run)['entries']))
            reopened=LifecycleActorCanonicalPublication(owners,actor);self.assertEqual(1,reopened.publish(1))
            self.assertEqual(1,len(actor.posts));self.assertEqual(1,len(domain.queries));self.assertEqual(saved,owners[0].original())
            self.assertEqual(pending,reopened.history()[0]['intent'])

    def test_real_browser_peer_shares_primary_journal_but_cannot_acquire_or_publish_family(self):
        server,url=self.endpoint(enabled=True);reader,actor,domain=self.originals(url,server)
        peer,peer_url=self.endpoint(peer=server)
        self.assertIs(peer.journal,server.journal);self.assertTrue(peer.browser_peer)
        with self.assertRaises(ValueError):make_server(READER,ACTOR,browser_peer_of=server,lifecycle_actor_originals=True)
        with domain.lock.held():
            owners=(domain.owner(1),domain.owner(2));saved=owners[0].acquire(TICKET)
            publication=LifecycleActorCanonicalPublication(owners,actor);publisher=publication.prepare()
            _,body=publisher.original(publication.reference(1));peer_actor=ActualEndpointClient(peer_url,ACTOR)
            with self.assertRaises(ValueError):peer_actor.request('/runs/'+domain.run+'/samples',body)
            self.assertEqual([],reader.request('/runs/'+domain.run)['entries']);self.assertEqual(saved,owners[0].original())
            self.assertEqual(1,len(peer_actor.posts));self.assertEqual(1,len(domain.queries))

    def test_non_boolean_optin_refuses_before_any_real_server_constructor_is_born(self):
        births=[];original=fixture_server.FixtureServer.__init__
        def observed(receiver,*args,**kwargs):
            births.append(receiver);return original(receiver,*args,**kwargs)
        # Actual constructor function observation; if reached it still delegates
        # to the genuine original constructor, never returns an expected object.
        with patch.object(fixture_server.FixtureServer,'__init__',observed):
            for value in(1,None,'true'):
                with self.subTest(valueType=type(value).__name__),self.assertRaises(ValueError):
                    make_server(READER,ACTOR,lifecycle_actor_originals=value)
        self.assertEqual([],births);self.assertEqual([],self.servers)
