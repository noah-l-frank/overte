"""Qualify the nine actual host timing counterexamples; no consumer or feature admission."""
from pathlib import Path
import json,hashlib,os,stat,runpy
R=Path.cwd().resolve();B=R/'.ios-host-tmp'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(d,n,x):
 with(d/n).open('x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
c=B/'root-single-world-utility9-window-current949-b1-20261104'
assert sha(c/'freeze.json')=='f2d093bf5a79f875beb63b51987508ad8443b63724b1e3d20131ea2982e0e3a2'
for n,v in load(c/'freeze.json')['files'].items():assert sha(c/n)==v['sha256']
t=load(c/'terminal.json');assert t['status']=='ROOT_SINGLE_WORLD_TIMING_UTILITY_COMPLETED'and len(t['groups'])==1 and t['unrunGroups']==[]
assert t['oldRootCount']==949 and len(t['newOriginalRoots'])==4 and t['allOldOriginalBodiesUnchanged']and t['wholeOwnOutputsTwiceEqual']and t['allExecutedOwnedProcessesAbsent']
assert load(c/'global-before.json')==load(c/'global-after-first.json')==load(c/'global-after-second.json')
assert len(load(c/'global-before.json'))==949
assert load(c/'whole-output-first.json')==load(c/'whole-output-second.json')
q=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py'
assert sha(q)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be'
census=runpy.run_path(str(q))['census']
for n,v in load(c/'whole-output-first.json').items():assert census(Path(n))==v
row=t['groups'][0];h=Path(row['input']).parent;o=h.with_name(h.name+'-outer');a=h.with_name(h.name+'-censuses')
assert sha(row['input'])==row['inputSha256'];plan=load(row['input'])
assert plan['sourceFreeze']=='f53394a5857b7da18c8c6e01639001b39bdfdc547c6b9cb44856248717d1b335'
assert plan['wallSeconds']==30 and plan['killGraceSeconds']==5 and plan['utilityQualification']is plan['worldConsumerAdmission']is None
assert row['supervisorReturnCode']==0 and row['originalTerminal']['status']==row['originalQualification']['status']=='PASS'
assert load(o/'source-binary-before.json')==load(o/'source-binary-after.json')==plan['sourceAndBinaryPins']
for name,v in plan['sourceAndBinaryPins'].items():
 p=Path(name);z=p.lstat();assert stat.S_ISREG(z.st_mode)
 actual=dict(device=z.st_dev,inode=z.st_ino,mode=z.st_mode,uid=z.st_uid,gid=z.st_gid,nlink=z.st_nlink,bytes=z.st_size,mtimeNs=z.st_mtime_ns,ctimeNs=z.st_ctime_ns,sha256=sha(p))
 assert actual==v and p.lstat()==z
for first,second in [('approved-input-before.json','approved-input-after.json'),('actual-child-output-first.json','actual-child-output-second.json'),('actual-child-subtrees-first.json','actual-child-subtrees-second.json')]:assert load(o/first)==load(o/second)
assert load(a/'whole-first.json')==load(a/'whole-second.json')
assert load(o/'actual-parent-drain.json')==dict(fdsEqual=True,threadsEqual=True)
drain=load(o/'actual-process-drain.json');assert not drain['remaining']and not drain['forced']
for owned in drain['owned']:
 try:raw=Path('/proc',str(owned['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(raw[raw.rfind(')')+2:].split()[19])!=owned['startTicks']
r=load(h/'child-receipts/report.json');ports=load(h/'child-receipts/actual-port-restoration.json')
assert r['status']=='PASS'and r['testsRun']==r['actualCaseReceipts']==9 and r['fatal']is None and r['cleanupEstablished']
for k in ('fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','twoToyCensusesEqual','allActualLoadedOriginsAccounted'):assert r[k]is True
assert all(r[k]==0 for k in('NodeExecutions','PythonExecutions','SDKExecutions','overteNativeQueries'))and not r['realNetwork']and not r['retainedTemporaryDirectories']
for k in('restored','builtinsCioRestored','dupPortsRestored','toolsRestored'):assert ports[k]is True
assert ports['actualC10dHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
summary=r['actualClassCleanupSummary'];assert summary['actualOriginalClassCleanupCalls']==summary['expectedSelectedClasses']==1 and summary['allActualOriginalCallsAccepted']and summary['allSelectedClassesObservedExactlyOnce']and summary['descriptorRestored']is False and not summary['problems']
final_cleanup=load(h/'child-receipts/actual-class-cleanup-restoration.json');assert final_cleanup['originalDescriptorRestored']and final_cleanup['originalFunctionCodeGlobalsUnchanged']and final_cleanup['summary']['descriptorRestored']is True
assert dict(summary,descriptorRestored=True)==final_cleanup['summary']
assert ports['actualClassCleanupRestoration']==final_cleanup and ports['classCleanupRestorationError']is None
origins=load(h/'child-receipts/actual-source-model-origins.json');assert origins['allThreeActualRuntimeOriginsEstablished']and len(origins['subjectOrigins'])==3
for v in origins['subjectOrigins'].values():assert v['exactOriginMatched']and v['actualModulePresent']and v['actualLoaderExecutedPath']==v['expectedPath']
assert all(x['newTemporaryDirectories']==0 for x in [load(h/('child-receipts/standard-case-'+str(j)+'.json'))for j in range(1,10)])
assert row['originalTerminal']['zeroCaseChildBirthsEstablished'] is True
assert origins['subjectOrigins']['host_function_timing']['expectedSha256']=='2ad2223660ddc2948066523d491feeca458c9d9fb1be277c08f862825a0dccb0'
cases=[load(h/('child-receipts/standard-case-'+str(j)+'.json'))for j in range(1,10)];assert [x['id']for x in cases]==plan['cases']
for x in cases:
 for k in('fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','monitorMasksSlotsUnchanged','profileRestored','originalMethodsUnchanged','standardStopAfterCleanup'):assert x[k]is True
 assert x['remainingStandardCleanups']==x['newTemporaryDirectories']==0
 for call in x['actualNestedCleanupCalls']:assert call['outcomeSuccessAfter']and call['remaining']==0 and call['originalRaised']is None and not call['newCallbackErrors']and not call['newCallbackFailures']
refs={}
for root in map(Path,t['newOriginalRoots']):
 for p in sorted(root.rglob('*')):
  if p.is_file()and not p.is_symlink():refs[str(p)]=dict(path=str(p),sha256=sha(p))
out=B/'root-world-host-timing-utility9-qualified-results-20261104';out.mkdir(mode=0o700)
put(out,'results.json',dict(status='ROOT_QUALIFIED_WORLD_HOST_TIMING_NINE_GENUINE_HOST_CASES_ONLY',actualInputSha256=row['inputSha256'],sourceFreeze=plan['sourceFreeze'],actualReport=r,originalTerminal=row['originalTerminal'],originalQualification=row['originalQualification'],terminal=row['originalTerminal'],newOriginalRoots=t['newOriginalRoots'],all949OldOriginalBodiesUnchanged=True,originalCollectorFreeze=sha(c/'freeze.json'),actualCases=plan['cases'],actualThreeOriginsEstablished=True,actualClassCleanupOriginalAccepted=True,currentSourceHelperSHA=ports['actualC10dHelperSha256'],hostTimingUtilityQualified=True,diagnosticObserverOverheadExcluded=False,worldConsumerAdmission=None,featureQualified=False,nativeQualified=False,wholeQualified=False))
put(out,'actual-receipt-references.json',refs)
put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}))
print(json.dumps(dict(freeze=sha(out/'freeze.json'),references=len(refs))))
