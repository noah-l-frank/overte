"""Real imported module/classes for ordering-only authority counterexamples."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextvars import ContextVar
import sys

CONSTANT=1
PRIMITIVE=(None,True,1,1.0,'actual',frozenset({'actual'}))
CONTEXT=ContextVar('chat-original-key-order-subject',default=None)
MODULE=sys
ignored={'mutable':'not an old tracked primitive'}


def a_early():return 'actual earlier function'
def z_late():return 'actual later function'
def alternate():return 'actual alternate function'


class Parent:
    def first(self):return 'actual first method'
    @staticmethod
    def static():return 'actual static method'
    @classmethod
    def bound(cls):return cls
    def save(self):return 'old excluded mutator'


class Other:
    def first(self):return 'actual other base'


class Child(Parent):
    def last(self):return 'actual child method'


Alias=Child
