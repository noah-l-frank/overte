"""Declared raw native/SDK/audio producer, real Runtime/WAL/Primary consumers.

All audio samples, native events, SDK identities, OS and clocks are models.
Actual OriginalFrameStore bytes/inodes, canonical parent custody, ordinary
recording owner/input/authorization code and fresh source admission execute.
No consumer, expected effect, archive or native return is replaced.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import array
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import sys
import time
import math
from adapters.native_feature_observation import need
from adapters.native_script_observation import NativeScriptObservation
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.script_feature.history import unpack
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import VERSION
from feature_journeys.fixtures import challenge
from ios.adapters import audio_session_source
from ios.adapters.audio_passive_actor import lease_id
from ios.adapters.audio_once_cue_signal import input_id,input_pcm,samples as cue_samples,DURATION as CUE_DURATION
from ios.adapters.audio_once_cue_source import ACTION as ONCE_ACTION,BOOLEANS,COUNTERS,RECEIVERS,EPOCHS
from ios.adapters.audio_once_journey import IOSAudioOnceJourney
from ios.adapters.audio_runtime import IOSAudioRuntime
from ios.adapters.audio_session_owners import register_scope
from ios.adapters.audio_pcm_lease import INPUT_ORIGIN_PROFILE
from ios.adapters.audio_once_primary import primary_lock_scope
from ios.self_tests.audio_background_domain import AudioBackgroundDomain
from ios.self_tests.test_ios_audio_pcm_lease import PCMModel
from ios.self_tests.test_ios_audio_pcm_input_origin_profile import InputOriginPCMModel
from ios.self_tests.test_ios_audio_passive_owner import PassiveBoundary,raw
from ios.self_tests.test_ios_audio_passive_runtime import RuntimeModel
from ios.self_tests.test_ios_audio_recorded_owner import Model,RUN
from ios.self_tests.test_ios_audio_session_source import Boundary as SessionBoundary
from self_tests.test_recorded_preview_history import voice,event
from self_tests.test_token_audio_ui import AudioBoundary
from voice_peer.voice_signal import samples as pattern_samples

RATE=8000


class ActorModel(Model):
    @property
    def clock(self):return self.primary.clock
    @clock.setter
    def clock(self,value):
        if not getattr(self,'_constructing',False):self.primary.clock=value
    def __init__(self,primary):
        self.primary=primary;self._constructing=True;super().__init__();self._constructing=False;self.native_instance='b'*32
        self.activations=primary.activations;self.client=primary.client
    def sleep(self,seconds):self.primary.sleep(seconds)
    def native_epoch(self):return 80000+round(self.clock*1000)


class OnceNativeBoundary:
    """Raw per-process max64 once claims; cached PCM intentionally stays held."""
    def __init__(self,fixture):
        self.f=fixture;self.commands=[];self.claims={};self.sequence=0;self.packet=None;self.lose=set();self.inputs=[];self.foreign_code=False;self.unknown_receivers=False
    def caller(self,method,sequence,epoch):
        return dict(callerVersion=1,method=method,sequence=sequence,invokedEpochMs=epoch,
            manager=dict(instance='c'*32,assigned=True,url='file:///declared-owned-probe.js',loadGeneration=1,assignedEpochMs=1000),
            code=dict(submitted=True,encoding='utf-16le-code-units',codeUnits=1,sha256='d'*64,submittedEpochMs=1001))
    def send(self,query):
        f=self.f;m=f.actor;kind=query['kind'];operation=query['operation'];self.commands.append(deepcopy(query));m.tick();now=m.native_epoch()
        self.sequence+=1
        if operation=='claim':
            need(query['cueId'] not in self.claims and len(self.claims)<64)
            # Read the ACTUAL parent CAS and immutable query original at send.
            ledger=PrivateFeatureState(f.actor_root/'ios-audio-passive-ledger.json').read()
            row=next(row for row in ledger['leases'] if row['leaseId']==lease_id(RUN,query['ticket']))
            child=f.artifacts/('ios-audio-passive-'+row['leaseId']);saved=PrivateFeatureState(child/'ios-audio-passive-owner.json').read()
            state=unpack(saved['payload'])[0];need(saved['iosAudioPassiveOwnerVersion']==2 and state['once']['inputs'][kind]['claim'] is not None)
            self.inputs.append(dict(kind=kind,ticket=query['ticket'],at=m.clock,cue=query['cueId']))
            pcm=input_pcm(RUN,query['ticket'],kind)
            value={name:False for name in BOOLEANS};value.update({name:0 for name in (*COUNTERS,*RECEIVERS,*EPOCHS)})
            value.update(iosAudioOnceCueVersion=2,instance=m.native_instance,runId=RUN,ticket=query['ticket'],cueId=query['cueId'],kind=kind,
                soundUrl=query['soundUrl'],complete=True,receiverInventoryComplete=True,processOwnedControlLive=True,claimedEpochMs=now,caller=self.caller('featureIOSAudioOnceCue',1,now),
                playCaller={},pcmBytes=0,pcmFrames=0,pcmChannels=0,pcmSha256='',processId=42)
            self.claims[query['cueId']]=dict(value=value,start=m.clock,pcm=pcm)
        need(query['cueId'] in self.claims);claim=self.claims[query['cueId']];value=claim['value']
        if operation!='claim' and not value['consumed']:
            value.update(consumed=True,managerReturned=True,injectorBorn=True,wrapperBorn=True,injectorLive=True,playing=True,wrapperLive=True,
                resourceRequested=True,resourceWrapperBorn=True,resourceWrapperLive=True,resourceReady=True,resourceCacheObjectLive=True,
                resourcePCMStillHeld=True,observedInputPCMKnown=True,observedInputPCMStillHeld=True,resourceReadyReceivers=1,
                consumedEpochMs=value['claimedEpochMs'],bornEpochMs=value['claimedEpochMs'],
                playCaller=self.caller('playSound',2,value['claimedEpochMs']),pcmChannels=1,pcmBytes=len(claim['pcm']),
                pcmFrames=len(claim['pcm'])//2,pcmSha256=hashlib.sha256(claim['pcm']).hexdigest())
        duration=CUE_DURATION if kind=='cue' else 3.
        if value['consumed'] and m.clock>=claim['start']+duration:
            value.update(finished=True,finishedCallbacks=1,finishedEpochMs=80000+round((claim['start']+duration)*1000),
                injectorLive=False,playing=False,injectorDestroyed=True,destroyCallbacks=1,destroyedEpochMs=80000+round((claim['start']+duration)*1000),
                wrapperLive=False,wrapperDestroyed=True,wrapperDestroyCallbacks=1)
        if operation=='retire':
            need(not value['injectorLive']);value.update(retireAttempted=True,resourceWrapperLive=False,resourceWrapperDestroyed=True,
                resourceDestroyCallbacks=1,resourceReadyReceivers=0)
        if operation=='release':
            need(value['retireAttempted'] and not value['resourceWrapperLive']);value['released']=True
        self.packet=deepcopy(value)
        if self.foreign_code:self.packet['caller']['code']['sha256']='f'*64
        if self.unknown_receivers:self.packet.update(receiverInventoryComplete=False,scriptFinishedReceivers=-1,resourceReadyReceivers=-1)
        self.packet.update(commandId=query['commandId'],operation=operation,sequence=self.sequence,
            requestedEpochMs=now,capturedEpochMs=now,queryCaller=self.caller('featureIOSAudioOnceCue',self.sequence+10,now))
        if self.foreign_code:self.packet['queryCaller']['code']['sha256']='f'*64
        if operation in self.lose:raise NativeUIError('Declared lost once-native return after actual model delivery')
    def read(self):return raw(self.packet).decode() if self.packet else None
    def count(self,operation,kind=None):return sum(row['operation']==operation and (kind is None or row['kind']==kind) for row in self.commands)


class ContinuousLeaseBoundary(PassiveBoundary):
    def __init__(self,fixture,lease):super().__init__(fixture.actor,lease);self.f=fixture;self.once=fixture.boundary.once
    def send(self,query):
        if self.owned and not self.complete and self.clock.clock>=self.started_mono/1000+self.seconds:self.finish()
        return super().send(query)
    def finish(self):
        self.complete=True;data=array.array('h',[0])*(RATE*self.seconds);start=self.started_mono/1000
        def add(at,values):
            offset=round((at-start)*RATE);need(offset>=0 and offset+len(values)<=len(data))
            for i,value in enumerate(values):data[offset+i]=max(-32768,min(32767,data[offset+i]+value))
        for item in self.once.inputs:
            if item['at']<start or item['at']>=start+self.seconds:continue
            if item['kind']=='cue':add(item['at'],cue_samples(RUN,item['ticket'],rate=RATE))
            else:
                add(item['at'],pattern_samples(challenge(RUN,item['ticket']).hex(),RATE,.15,profile='recorded-preview-v1'))
                # Explicit modeled acoustic transform: no earlier byte replay.
                add(self.f.primary_start+3,pattern_samples(challenge(RUN,item['ticket']).hex(),RATE,.11,profile='recorded-preview-v1'))
        if sys.byteorder!='little':data.byteswap()
        self.pcm=data.tobytes();self.rows=[]
        for offset in range(0,len(self.pcm),RATE*2):
            part=self.pcm[offset:offset+RATE*2];n=offset//(RATE*2);end=n+len(part)/(RATE*2)
            self.rows.append(dict(sequence=n+1,generation=1,routeRevision='1',readBeforeEpochMs=self.started+round(n*1000),
                readAfterEpochMs=self.started+round(end*1000),readBeforeMonotonicMs=self.started_mono+round(n*1000),
                readAfterMonotonicMs=self.started_mono+round(end*1000),tapEpochMs=self.started+round(end*1000),
                tapMonotonicMs=self.started_mono+round(end*1000),readBytes=len(part),readSha256=hashlib.sha256(part).hexdigest(),
                offset=offset,bytes=len(part),sha256=hashlib.sha256(part).hexdigest()))


class ContinuousActorBoundary:
    """Mirror actual IOSAudioPassiveCapture per-lease tombstones, one active slot."""
    def __init__(self,fixture):self.f=fixture;self.once=OnceNativeBoundary(fixture);self.leases={};self.commands=[];self.last=None
    def send(self,query):
        if query['action']==ONCE_ACTION:self.last=self.once;return self.once.send(query)
        self.commands.append(deepcopy(query));lease=query['leaseId']
        if lease not in self.leases:
            need(query['operation']=='start' and all(value.retired for value in self.leases.values()))
            self.leases[lease]=ContinuousLeaseBoundary(self.f,lease)
        self.last=self.leases[lease];return self.last.send(query)
    def read(self):return None if self.last is None else self.last.read()
    def count(self,operation):return sum(row['operation']==operation for row in self.commands)


class DeclaredScriptNative:
    def __init__(self,fixture):self.f=fixture;self.sequence=0;self.packet=None
    def send(self,query):
        m=self.f.actor;m.tick();self.sequence+=1;epoch=m.native_epoch()
        manager=dict(instance='c'*32,assigned=True,url='file:///declared-owned-probe.js',loadGeneration=1,assignedEpochMs=1000)
        code=dict(submitted=True,encoding='utf-16le-code-units',codeUnits=1,sha256='d'*64,submittedEpochMs=1001)
        self.packet=dict(schemaVersion=1,requestId=query['commandId'],instance='e'*32,sequence=self.sequence,
            requestedEpochMs=epoch,capturedEpochMs=epoch,processId=42,
            source=dict(complete=True,sourceIdentityVersion=1,membershipSourceVersion=1,
                membership=dict(complete=True,revision=1,managers=[manager]),
                engines=[dict(url=manager['url'],running=True,stopping=False,finished=False,
                    required=dict(instance=manager['instance'],sequence=0,modules=[]),code=code)]))
    def reader(self):
        m=self.f.actor
        return NativeScriptObservation(self.send,lambda:raw(self.packet).decode() if self.packet else None,
            m.native_epoch,m.guard,42,ios=True,monotonic=lambda:m.clock,sleep=m.sleep)


class DeclaredPrimaryRuntime(IOSAudioRuntime):
    @contextmanager
    def recorded_owner(self,*args,**kwargs):
        with super().recorded_owner(*args,**kwargs) as owner:
            previous=self.model.owner;self.model.owner=owner
            try:yield owner
            finally:self.model.owner=previous


class OnceJourneyFixture:
    def __init__(self,case,*,real_clock=False,primary_artifact_root=None,register_primary_scope=True):
        self.case=case;self.p=AudioBackgroundDomain(case,pages=True,prepare_recording=False);m=self.p.m;self.primary_start=None
        if real_clock:
            page=m.page_model;previous=page.clock
            class RealClockPage(type(page)):
                @property
                def clock(self):return time.monotonic()-self._real_origin
                @clock.setter
                def clock(self,value):
                    need(type(value) in (int,float) and math.isfinite(value) and value>=0)
                    remaining=value-self.clock
                    if remaining>0:time.sleep(remaining)
            page.__class__=RealClockPage;page._real_origin=time.monotonic()-previous
        # This is a prospective raw automatic-timer model with actual three-
        # second recording/preview intervals; no saved clock is changed.
        def sleep(seconds):
            AudioBoundary.sleep(m,seconds)
            if not m.automatic or not m.active:return
            elapsed=(m.native_epoch()-m.recorded['startedEpochMs'])/1000
            for phase,deadline,played in (('playing',3.,96000),('draining',6.,576000),('completed',6.1,576000)):
                if elapsed>=deadline and phase not in [row['phase'] for row in m.recorded['events']]:
                    m.tick();rows=m.recorded['events'];m.phase=phase;m.active=phase!='completed'
                    m.recorded=voice(rows+[event(rows[-1]['eventSequence']+1,phase,576000,played,epoch=m.native_epoch())],cycle=m.cycle,started=m.recorded['startedEpochMs'])
        m.sleep=sleep;m.automatic=True
        activate=m.activate
        def input_boundary(identifier,*,token):
            before=m.cycle;result=activate(identifier,token=token)
            if m.cycle!=before:
                self.primary_start=m.clock
                if hasattr(self,'pcm'):self.pcm.memory=True
            return result
        m.activate=input_boundary
        outer=self
        class Session(SessionBoundary):
            def stamp(self):m.tick();return dict(epochMs=m.native_epoch(),monotonicMs=round(m.clock*1000))
        self.session=Session(20000);self.session.instance=m.native_instance;source=self.p.runtime._sources
        class OriginalPCM(InputOriginPCMModel):
            def source(self):
                value=super().source();rate=value['sampleRate'];channels=value['channels']
                start=next(row for row in reversed(m.owner.state['operations']) if row['verb']=='record-start')
                values=pattern_samples(challenge(RUN,start['ticket']).hex(),rate,.15,profile='recorded-preview-v1');interleaved=array.array('h')
                for sample in values:interleaved.extend([sample]*channels)
                if sys.byteorder!='little':interleaved.byteswap()
                pcm=interleaved.tobytes()
                for kind in ('input','sink'):
                    name=value[kind]['name'];self.files[name]=pcm;value[kind].update(bytes=len(pcm),sha256=hashlib.sha256(pcm).hexdigest())
                for row in value['inputOrigin']['rows']:
                    part=pcm[row['offset']:row['offset']+row['bytes']];row.update(readSha256=hashlib.sha256(part).hexdigest(),sha256=hashlib.sha256(part).hexdigest())
                return value
        self.pcm=OriginalPCM(m)
        def sources(selector):
            value=source(selector)
            def session(clock_source):return audio_session_source.IOSAudioSession(self.session.send,lambda:self.session.raw,
                lambda:clock_source.read(clock_source.sequence)['capturedEpochMs'],m.guard,42,monotonic=lambda:m.clock,sleep=m.sleep)
            value['observer']=SimpleNamespace(audio_session=session,recorded_preview_observer=lambda:self.pcm.reader()[1])
            value['client']=m.page_model.native.client;value['session']='owned-audio-session'
            # NativeInput.scroll accepts direction; the raw widget producer
            # separately requires its actual scrollbar identifier.
            value['native'].scroll=lambda direction,*,token:m.scroll('audio.scrollbar',direction,token=token)
            return value
        self.p.runtime=DeclaredPrimaryRuntime(self.p.runtime.adapter);self.p.runtime.model=m;self.p.runtime._sources=sources
        if register_primary_scope:register_scope(self.p.runtime.adapter,'test-only',self.p.binding,RUN,self.p.root if primary_artifact_root is None else primary_artifact_root)
        self.actor=ActorModel(m);self.actor_root=self.p.root/'z-actor-sdk';self.actor_root.mkdir(mode=0o700)
        self.artifacts=self.p.root/'z-actor-artifacts';self.artifacts.mkdir(mode=0o700)
        self.boundary=ContinuousActorBoundary(self);self.runtime=RuntimeModel(SimpleNamespace(root=self.actor_root,model=self.actor),self.boundary)
        self.runtime.binding=deepcopy(self.p.binding);self.runtime.binding.update(targetFingerprint='b'*64,sessionId='declared-independent-actor')
        self.actor_lock=ScriptSourceLock(self.actor_root/'script-feature-sources.lock')
        self.script=DeclaredScriptNative(self);actor_sources=self.runtime._sources
        def actor_source(selector):
            value=actor_sources(selector);value['observer'].script_execution_observer=self.script.reader;return value
        self.runtime._sources=actor_source
        self.driver=IOSAudioOnceJourney(self.runtime,'actor',self.p.runtime,'test-only',RUN,self.artifacts,self.p.root if primary_artifact_root is None else primary_artifact_root,m.client(),
            epoch_ms=m.epoch,monotonic=lambda:m.clock,sleep=m.sleep,source_locks=(self.actor_lock,self.p.lock))
    @contextmanager
    def custody(self,ticket):
        # Primary path sorts before this explicit child Actor SDK path.
        with primary_lock_scope(self.p.lock),self.runtime.once_input_owner('actor',RUN,ticket,self.artifacts,self.actor.client(),
                epoch_ms=self.actor.epoch,monotonic=lambda:self.actor.clock,sleep=self.actor.sleep,source_lock=self.actor_lock) as owner:yield owner
    def call(self,ticket,verb,inputs=None):
        self.p.m.add_phase(verb,ticket,**(inputs or {}))
        return dict(contractVersion=VERSION,runId=RUN,fixtureUrl=self.p.parent.fixture_url,ticket=ticket,verb=verb,inputs=inputs or {})
    def parent(self):
        # Use the real existing ordinary parent and authorization entrypoint.
        return self.p.parent
