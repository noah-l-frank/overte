from pathlib import Path
import ast,hashlib,json,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-passive-thread-rpc-task11-root-preparation-20261028/45-native-passive11';PACK=T/'lifecycle-original-owner-passive-carrier-quiet-proposal-20261028';P=T/'lifecycle-original-owner-passive-carrier8-root-preparation-20261028';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
assert H(PACK/'freeze.json')=='b7d6e1af527b21d5a2af0a1530738f691166fc3dcc1f100661d85b78228af2ec'
for rel,d in json.loads((PACK/'freeze.json').read_text())['files'].items():assert H(PACK/rel)==d
report=json.loads((B/'root-run-first/report.json').read_text());assert report['exitCode']==0 and report['retainedFiles']==166 and report['allPinsEqual'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses']
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((B/'prior-retained-original-pins.json').read_text());root=B/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==166
for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
assert sum('sha256' in v for v in prior.values())==2685
P.mkdir(mode=0o700);S=P/'46-native-passive-carrier8';S.mkdir(mode=0o700)
for rel,d in json.loads((B/'freeze.json').read_text())['files'].items():
 assert H(B/rel)==d;out=S/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/rel,out)
for name in ['test_native_passive_carrier_models.py','test_native_passive_scope_models.py','test_native_motion_existing_rpc_models.py','test_native_motion_worker_scope_models.py','test_motion_selected_join_models.py','motion_reference_fixture.py','native_acquisition_fixture.py','native_file_fixture.py']:shutil.copyfile(PACK/name,S/name)
(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n');stage=json.loads((S/'source-manifest.json').read_text());manifest=json.loads((PACK/'manifest.json').read_text());own={row['path']:row for row in manifest['files']+manifest['ownRegistryPlan']};changes=[]
for row in stage['sourcePaths']:
 rel=row['path'];actual=H(R/rel)
 if rel in own:row.update(candidate=own[rel]['candidate'],candidateSHA256=own[rel]['candidateSHA256'],observedPublicSHA256=actual,changesCurrentPublic=actual!=own[rel]['candidateSHA256']);continue
 if actual!=row['candidateSHA256']:
  out=S/'actual-current-dependency/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(out),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
assert set(own)<={row['path'] for row in stage['sourcePaths']}
stage.update(stage=46,name=S.name,status='PRIVATE_UNRUN_EXACT_PASSIVE_CARRIER8_SOURCE2',caseCount=8,pythonCaseCount=8,sourceDeltaPaths=[row['path'] for row in manifest['files']],exactPublicMutationPlan='Root ONLY source2 ec98/da56 plus exact8 own protocol hunks, preserve foreign bytes; Source map mandatory after Root PUB.')
stage['orderedParentFreezes'][PACK.name]=H(PACK/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');plan=json.loads((S/'run-plan.json').read_text());testplan=json.loads((PACK/'test-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_PASSIVE_CARRIER8',cases=testplan['cases'],caseCount=8,totalCaseCount=8,expectedRetainedRoots=16);plan['privateFiles']['test_native_passive_carrier_models.py']=H(S/'test_native_passive_carrier_models.py')
for name in list(plan['privateFiles']):
 if (S/name).is_file():plan['privateFiles'][name]=H(S/name)
for row in manifest['ownRegistryPlan']:
 if row['path'].endswith('.json'):
  contracts=json.loads(Path(row['candidate']).read_text())['contracts']
  for key in row['ownFamilies']:plan['registryRequirements'][key]=contracts[key]
(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n');shutil.copyfile(PACK/'source2.diff',S/'source2-carrier.diff');shutil.copyfile(PACK/'registry-own8.diff',S/'registry-own8.diff')
(S/'clone-provenance-carrier8.json').write_text(json.dumps(dict(parent45Freeze=H(B/'freeze.json'),packetFreeze=H(PACK/'freeze.json'),parent45ActualPASS11=True,parent45ActualFiles=166,priorActualFiles=2685,old43TimeoutChildTerminalQualified=False,old43And42FilesPreserved=True,caseCount=8,initialSeconds=90,killAfterSeconds=5,genuineRoots=16,actualDependencyChanges=changes,executed=False,targetImports=False,publicEdits=False),indent=2)+'\n')
(S/'README-carrier8.txt').write_text('Root46 exact8 prospective90+kill5/16 realTD. Actual Root45 controller inherited unchanged; Source2+own8 schema required after Root PUB. Current Emote5 and all foreign registry bytes preserved by packet own hunks; Root source map actual full source/SDK/launcher statSHA before target imports. Source pair Tasks and same-source HTTP/AFC-model files/real threads+FDs, four genuinely later quiet originals, original strict clocks. Both terminal FD/task/thread/child and original file/statSHA censuses retained.2685actual oldfiles:2519priors+Root45PASS166. Root43timeout remains unqualified childterminal, never upgraded. No native/SDK/auth/whole gate. No agent imports/tests/PUB.\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(stage=str(S),stageFreeze=H(S/'freeze.json'),parentFreeze=H(P/'freeze.json'),sourceManifest=H(S/'source-manifest.json'),plan=H(S/'run-plan.json'),actualDependencyChanges=changes),indent=2))
