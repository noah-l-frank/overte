"""Actual normal original-child World/resource history; SDK/native are MODELS."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import base64
from copy import deepcopy
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from ios.adapters.lifecycle_resource_history import original
from test_resource4_normal_frontdoor_models import Resource4NormalFrontdoorModels


class ParentResourceWorldHistoryModels(Resource4NormalFrontdoorModels):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.owner=self.runtime.child('test-only',self.normal.d.flow,self.normal.owner,None,original_child=True,resource_history=True)
        self.assertEqual(3,self.owner.version);self.assertIsNone(self.owner.previous)

    async def test_actual_parent_world_history_retains_original_bytes_across_later_child_headers_and_passive_three_second_window(self):
        await self.owner.act(seconds=12);await self.owner.observe()
        first=self.owner.frame(2);old=deepcopy(first['resourceOriginal'])
        self.assertTrue(original(old,self.binding,self.run,self.ops.instance,self.owner.frame(1)['originalChild']['reference'])['capture']['worker']['workerRunning'])
        prepared=self.ops.touch_resources.store.path.read_bytes()
        await self.owner.release()
        for _ in range(4):await self.owner.sample_quiet()
        proof=self.owner.resource_history_proof();self.assertGreaterEqual(proof['hostMilliseconds'],3000)
        self.assertTrue(proof['historicalOnly']);self.assertEqual(5,proof['samples'])
        self.assertFalse(proof['sdkResourceRetirementEstablished']);self.assertFalse(proof['wholeLifecycleRetirementEstablished'])
        self.assertEqual(first,self.owner.frame(2));self.assertEqual(old,self.owner.frame(2)['resourceOriginal'])
        self.assertNotEqual(old['ownerReference'],self.owner.frame(7)['resourceOriginal']['ownerReference'])
        self.assertEqual(prepared,self.ops.touch_resources.store.path.read_bytes());self.assertEqual(6,len(self.ops.touch_resources._observation_owner.state['frames']))
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(30,len(self.commands))
        calls=len(self.command_tasks);self.assertEqual(proof,self.owner.resource_history_proof())
        self.assertEqual(calls,len(self.command_tasks));self.assertEqual(30,len(self.commands))

    async def test_changed_parent_raw_original_bytes_or_reference_cannot_qualify_archive(self):
        await self.owner.act(seconds=12);await self.owner.observe();frame=self.owner.frame(2)
        first=self.owner.frame(1)['originalChild'];before=deepcopy(frame)
        changed=deepcopy(frame);raw=base64.b64decode(changed['resourceOriginal']['ownerBase64']);changed['resourceOriginal']['ownerBase64']=base64.b64encode(raw+b' ').decode('ascii')
        with self.assertRaises((NativeUIError,ValueError)):self.owner.source_frame(changed)
        changed=deepcopy(frame);changed['resourceOriginal']['reference']['inode']+=1
        # A compact physical identity is part of BOTH original header/frame
        # membership, not just a syntactically valid caller-supplied reference.
        with self.assertRaises((NativeUIError,ValueError)):self.owner.source_frame(changed)
        self.assertEqual(before,self.owner.frame(2));await self.owner.lease_owner().release()
        # A genuinely new valid released snapshot cannot be spliced into the
        # independently retained HELD World original, even with matching owner.
        later=await self.runtime.resource_metadata('test-only',self.run,original_child=self.owner._original_child,retain_original_bytes=True)
        changed=deepcopy(frame);changed['resourceOriginal']=later['rawOriginal']
        with self.assertRaises(NativeUIError):self.owner.source_frame(changed)
        self.assertEqual(before,self.owner.frame(2));self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_replaced_metadata_receiver_cannot_mint_parent_source_and_original_up_stays_available(self):
        await self.owner.act(seconds=12);queries=len(self.commands)
        def foreign(*args,**kwargs):raise AssertionError('Foreign metadata callback was invoked')
        with patch.object(type(self.runtime),'resource_metadata',new=foreign):
            with self.assertRaises(NativeUIError):await self.owner.observe()
        self.assertEqual(queries,len(self.commands));self.assertEqual([],self.ops.touch_resources._observation_owner.state['frames'])
        await self.owner.lease_owner().release();self.assertEqual([0xC2,0xC2,0x02],self.f.states())
