"""Two actual unchanged Tablet host Node creators, maximum one live.

Controller custody only. It supplies no JS/native result and no fake PID or
pipe-drain success. It needs the later actual monitoring/audit runner.
"""
from pathlib import Path
import hashlib,os,shutil,signal,stat,subprocess,sys,threading,types
from tablet_constructor_custody import FunctionBinding,CustodyRefusal
from tablet_guarded_spawn import file_pin,kernel_identity

class TwoOriginalTabletNodes:
    def __init__(self,*,plan,repo,actual_js,host_app_class,producer_roots):
        self.plan=plan;self.repo=Path(repo).resolve(strict=True);self.main=threading.current_thread()
        self.echo=FunctionBinding(actual_js);self.host_class=host_app_class;self.host=FunctionBinding(host_app_class.__init__)
        self.host_close=FunctionBinding(host_app_class.close);self.roots=FunctionBinding(producer_roots)
        self.popen_class=subprocess.Popen;self.init=FunctionBinding(self.popen_class.__init__)
        self.execute=FunctionBinding(self.popen_class._execute_child);self.handles=FunctionBinding(self.popen_class._get_handles)
        self.signal=FunctionBinding(self.popen_class.send_signal);self.run=FunctionBinding(subprocess.run)
        self.node=Path(plan['nodeExecutable']['path']);self.node_pin=plan['nodeExecutable']['pin']
        self.host_script=Path(plan['tabletHostJavaScript']['path']);self.host_script_pin=plan['tabletHostJavaScript']['pin']
        self.environment=dict(os.environ);self.environment_digest=hashlib.sha256(repr(sorted(self.environment.items())).encode()).hexdigest()
        self.which=shutil.which;self.c_fstat=os.fstat;self.reader=os.readlink
        self.pending=None;self.entries=[];self.signal_rows=[];self.closed=False
        self.methods=tuple((key,value,FunctionBinding(value))for key,value in vars(type(self)).items()if type(value)is types.FunctionType)
        self.check()
    def check(self):
        if self.closed or threading.current_thread()is not self.main:raise CustodyRefusal('Node creator lifetime/thread')
        for key,value,binding in self.methods:
            if vars(type(self)).get(key)is not value:raise CustodyRefusal('Node gate method replaced')
            binding.guard()
        for binding in(self.echo,self.host,self.host_close,self.roots,self.init,self.execute,self.handles,self.signal,self.run):binding.guard()
        if subprocess.Popen is not self.popen_class or subprocess.run is not self.run.function:
            raise CustodyRefusal('Actual original Node Popen/run installations changed')
        for key,binding in(('__init__',self.init),('_execute_child',self.execute),('_get_handles',self.handles),('send_signal',self.signal)):
            if getattr(self.popen_class,key)is not binding.function:raise CustodyRefusal('Actual Popen method changed')
        if self.host_class.__init__ is not self.host.function or self.host_class.close is not self.host_close.function:
            raise CustodyRefusal('Actual host app constructor/close changed')
        if self.which is not shutil.which or self.c_fstat is not os.fstat or self.reader is not os.readlink:
            raise CustodyRefusal('Node binary/FD reader changed')
        if dict(os.environ)!=self.environment:raise CustodyRefusal('Node environment changed after scope birth')
        # This host scope does not admit injected Node preload/alternate
        # command/proxy startup semantics. No existing setting is rewritten.
        if self.environment.get('NODE_OPTIONS','')or self.environment.get('NODE_USE_ENV_PROXY','')not in('','0'):
            raise CustodyRefusal('Unreviewed Node startup/proxy option')
        if Path(self.which('node')).resolve(strict=True)!=self.node or file_pin(self.node)!=self.node_pin:
            raise CustodyRefusal('Actual canonical Node executable changed')
        if file_pin(self.host_script)!=self.host_script_pin:
            raise CustodyRefusal('Actual host JS sibling changed')
        if Path(self.host.namespace['__file__']).with_suffix('.js')!=self.host_script:
            raise CustodyRefusal('Actual original host Python/JS sibling mismatch')
        for binding,key in((self.echo,'tabletEchoPython'),(self.host,'tabletHostPython')):
            path=Path(binding.code.co_filename)
            if path!=Path(self.plan[key]['path'])or file_pin(path)!=self.plan[key]['pin']:
                raise CustodyRefusal('Actual unchanged Node producer source origin mismatch')
    def find(self,frame,binding):
        found=[]
        while frame is not None:
            if frame.f_code is binding.code and frame.f_globals is binding.namespace:binding.frame(frame);found.append(frame)
            frame=frame.f_back
        if len(found)!=1:raise CustodyRefusal('Exact genuine Node producer frame required')
        return found[0]
    def fd_row(self,descriptor):
        info=self.c_fstat(descriptor)
        if not stat.S_ISFIFO(info.st_mode)or not self.reader('/proc/self/fd/'+str(descriptor)).startswith('pipe:['):
            raise CustodyRefusal('Actual original Node FIFO required')
        return dict(descriptor=descriptor,device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
    def begin(self,frame):
        self.check();self.init.frame(frame);values=frame.f_locals;owner=values.get('self')
        if type(owner)is not self.popen_class or self.pending is not None or len(self.entries)>=2:
            raise CustodyRefusal('Unexpected actual Node constructor receiver/count')
        if self.entries and(self.entries[0]['owner'].poll()!=0 or self.entries[0]['owner'].stdout is None
                or not self.entries[0]['owner'].stdout.closed or not self.entries[0]['owner'].stderr.closed):
            raise CustodyRefusal('Previous actual Node still live or original streams unclosed')
        if not self.entries:
            producer=self.find(frame,self.echo)
            if producer.f_locals.get('session')is not False:raise CustodyRefusal('Only original non-session actual_js')
            program=producer.f_locals.get('program');expected=['node','-e',program]
            if type(program)is not str or values.get('args')!=expected or values['args'][2]is not program:
                raise CustodyRefusal('Original generated Node program identity mismatch')
            kind='actual-js';host_owner=None;stdin=None;bufsize=-1;cwd=self.repo
        else:
            producer=self.find(frame,self.host);host_owner=producer.f_locals.get('self');filename=producer.f_locals.get('filename')
            if type(host_owner)is not self.host_class or type(filename)is not type(Path()):
                raise CustodyRefusal('Actual original persistent host receiver/file required')
            actual_file=Path(filename)
            if actual_file.resolve(strict=True)!=actual_file or not any(actual_file.is_relative_to(root)for root in self.roots.function()):
                raise CustodyRefusal('Actual generated host Script outside retained producer roots')
            file_pin(actual_file)
            if producer.f_locals.get('script')!=self.host_script:raise CustodyRefusal('Original host JS sibling receiver mismatch')
            expected=['node',str(self.host_script),str(filename)];kind='host-app';stdin=subprocess.PIPE;bufsize=1;cwd=None
        desired=dict(stdin=stdin,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=bufsize,text=True,
            shell=False,executable=None,env=None,close_fds=True,start_new_session=False,pass_fds=(),
            preexec_fn=None,process_group=-1,creationflags=0,startupinfo=None,restore_signals=True)
        if values.get('args')!=expected or any(values.get(key)!=value for key,value in desired.items()):
            raise CustodyRefusal('Actual original Popen parameters differ')
        if values.get('cwd')!=cwd:raise CustodyRefusal('Original genuine Node cwd mismatch')
        self.pending=dict(owner=owner,hostOwner=host_owner,kind=kind,argv=expected,pipes={},spawnObserved=False,
            producerCode=producer.f_code,producerGlobals=producer.f_globals,originalConstructorFrame=frame)
    def collect_pipes(self,frame):
        self.check();self.init.frame(frame);row=self.pending
        if row is None or frame is not row['originalConstructorFrame']or frame.f_locals.get('self')is not row['owner']:
            raise CustodyRefusal('Actual original Node pipe receiver/frame mismatch')
        for name in('p2cread','p2cwrite','c2pread','c2pwrite','errread','errwrite'):
            fd=frame.f_locals.get(name)
            if type(fd)is not int:raise CustodyRefusal('Original pipe locals not available')
            if fd<0:continue
            actual=self.fd_row(fd)
            if name in row['pipes']and row['pipes'][name]!=actual:raise CustodyRefusal('Original FIFO replaced during constructor')
            row['pipes'][name]=actual
        if len(row['pipes'])!=(4 if row['kind']=='actual-js'else 6):raise CustodyRefusal('Actual original FIFO inventory incomplete')
    def pipe_open(self,args,frame):
        if type(args[0])is not int:return False
        self.check();self.init.frame(frame);self.collect_pipes(frame)
        fd,mode,flags=args;row=self.pending
        if fd!=frame.f_locals.get('p2cwrite')or row['kind']!='host-app'or mode not in('w','wb'):
            raise CustodyRefusal('Only original persistent Popen writable stdin FIFO')
        if self.fd_row(fd)!=row['pipes']['p2cwrite']:raise CustodyRefusal('Original stdin pipe FD/inode changed')
        return True
    def spawn(self,args,frame):
        self.check();self.execute.frame(frame);row=self.pending
        if row is None or frame.f_locals.get('self')is not row['owner']or row['spawnObserved']:
            raise CustodyRefusal('Node spawn lacks actual original pending constructor')
        original_init=self.find(frame,self.init);self.collect_pipes(original_init)
        executable,argv,cwd,env=args
        if executable!='node'or argv!=row['argv']or env is not None or cwd!=(self.repo if row['kind']=='actual-js'else None):
            raise CustodyRefusal('Actual original Node audit argv/cwd/environment mismatch')
        row['spawnObserved']=True
    def executed_returned(self,frame,value):
        # Capture the real executable at its earliest original successful
        # execute return, before binary hashing/tee setup can outlive a short
        # Node. This is immutable OS creator evidence, no native verdict cache.
        self.execute.frame(frame);row=self.pending;owner=frame.f_locals.get('self')
        if row is None or row['owner']is not owner or not row['spawnObserved']:
            raise CustodyRefusal('Unobserved genuine Node execute return')
        identity=kernel_identity(owner.pid)
        if identity['parentPID']!=os.getpid()or identity['executable']!=str(self.node):
            raise CustodyRefusal('Actual earliest Node kernel executable mismatch')
        row['actualExecuteReturnKernel']=identity
        self.check()
    def returned(self,frame):
        self.check();self.init.frame(frame);row=self.pending;owner=frame.f_locals.get('self')
        if row is None or row['owner']is not owner or not row['spawnObserved']or owner._child_created is not True:
            raise CustodyRefusal('Actual Node returned without original observed birth')
        identity=row.get('actualExecuteReturnKernel')
        if identity is None or identity['pid']!=owner.pid or identity['parentPID']!=os.getpid()or identity['executable']!=str(self.node):
            raise CustodyRefusal('Actual earliest original Node kernel proof missing')
        row['kernel']=identity;row.pop('originalConstructorFrame');self.entries.append(row);self.pending=None
    def signal_allowed(self,args,frame):
        self.check();self.signal.frame(frame);owner=frame.f_locals.get('self')
        row=next((row for row in self.entries if row['owner']is owner),None)
        if row is None or args!=(owner.pid,frame.f_locals.get('sig')):
            raise CustodyRefusal('Signal lacks exact original owned Popen receiver')
        if row['kind']=='host-app':self.find(frame,self.host_close)
        else:self.find(frame,self.echo)
        if frame.f_locals.get('sig')not in(signal.SIGTERM,signal.SIGKILL):raise CustodyRefusal('Unexpected original cleanup signal')
        actual=kernel_identity(owner.pid)
        if any(actual[key]!=row['kernel'][key]for key in('pid','parentPID','startTicks','executable')):
            raise CustodyRefusal('Original Node PID identity changed before cleanup signal')
        self.signal_rows.append(dict(kind=row['kind'],kernel=actual,signal=int(args[1])))
    def failure_ledger(self):
        # Pure observation before controller/OS exit; never closes a guessed
        # FD or converts missing birth/standard cleanup into positive finish.
        rows=[]
        for row in (*self.entries,*(()if self.pending is None else(self.pending,))):
            actual=[]
            for name,original in row['pipes'].items():
                try:info=self.c_fstat(original['descriptor'])
                except OSError as error:
                    state='EBADF'if error.errno==9 else'OTHER_OS_ERROR'
                    current=dict(errno=error.errno)
                else:
                    state='SAME_ORIGINAL_FIFO'if(info.st_dev,info.st_ino)==(original['device'],original['inode'])else'DIFFERENT_INODE'
                    current=dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
                actual.append(dict(name=name,original=original,actualState=state,current=current))
            owner=row['owner']
            rows.append(dict(kind=row['kind'],actualPID=getattr(owner,'pid',None),
                actualChildCreated=getattr(owner,'_child_created',False),actualOriginalFIFOStates=actual,
                observedOriginalKernel=row.get('kernel',row.get('actualExecuteReturnKernel'))))
        return dict(actualConstructorEntries=len(rows),actualSuccessfulBirths=len(self.entries),
            actualPendingConstructor=self.pending is not None,originalRows=rows,
            positiveFinishClaimed=False,controllerRetirementClaimed=False)
    def finish(self):
        self.check()
        if self.pending is not None or len(self.entries)!=2 or [row['kind']for row in self.entries]!=['actual-js','host-app']:
            raise CustodyRefusal('Exactly two original successful Node births required')
        result=[]
        for row in self.entries:
            owner=row['owner'];code=owner.poll()
            if row['kind']=='host-app'and row['hostOwner'].process is not owner:
                raise CustodyRefusal('Actual original host app no longer owns its original Node')
            if code!=0:raise CustodyRefusal('Original Node did not really exit normally')
            for stream in(owner.stdin,owner.stdout,owner.stderr):
                if stream is not None and not stream.closed:raise CustodyRefusal('Original Node standard stream still live')
            for original in row['pipes'].values():
                try:current=self.c_fstat(original['descriptor'])
                except OSError as error:
                    if error.errno!=9:raise
                else:
                    if (current.st_dev,current.st_ino)==(original['device'],original['inode']):
                        raise CustodyRefusal('Original own Node FIFO still live after genuine cleanup')
            result.append(dict(kind=row['kind'],kernel=row['kernel'],actualReturnCode=code,originalFIFOInventory=row['pipes']))
        self.closed=True
        return dict(actualNodeBirths=2,maxAllowedLiveNodes=1,normalOriginalExits=result,
            originalCleanupSignals=list(self.signal_rows),wholeOrNativeQualified=False,
            rawTeeOutputsClaimedComplete=False)
