"""Literal qualified four-control lifetime composition, no Snapshot case verdict."""
from pathlib import Path
import json
ROOT='root-snapshot-original-lifetime-four-original-host-qualified-results-20261105'
ROOT_SHA='94181fec5f347340ea14404191fa65a35ac2e448bd435ce1dd9b49efabbcf7e5'
RESULT_SHA='b16ee3e68e4e4d00d4c43fc4e2e691cb93e675f1d6b551a435a82d09264a0fc4'
SUBJECT='snapshot-capture-phase-png-photos-six-bootstrap6-owned-natural-exit-observations-code-preparation-20261105'
SUBJECT_SHA='e2c604b309759f38658b814347988d069a7cd339dce3f382976d9100762159dc'
UTILITY='snapshot-original-lifetime-own4-bootstrap1-closed-python-source-code-preparation-20261105'
UTILITY_SHA='6d5e579fcb6fd59aefcdc1663e5bc706053b72cf18ec28369ca46f1786e2d088'
SUBJECT_BYTES={'kernel.py':'bfecf8374664d4f28aa2983e5c5d807d6b57d1f6063e7c8fee020350e04f89e6','owned_node_observations.py':'ba2dd55dc97e05a84da38657df14e51a1b2bb92f31985d6e923bd3360de8584a','test_owned_node_natural_exit.py':'357c9058a6342d6b4f6dead00a36623fb0bda3ff665f95028717964e692a56b4'}
SUFFIXES=('test_original_live_lifetime_brackets_actual_binary_hash','test_genuine_exit_and_owner_reap_during_real_pin_retains_missing_not_live_authority','test_original_unreaped_terminal_is_present_and_has_no_hash_or_signal_permission','test_wrong_expected_original_lifetime_refuses_before_executable_or_pin_without_reuse_claim')
def qualification(repo,source,pin,packet):
    repo=Path(repo);source=Path(source);physical={};folder=repo/'.ios-host-tmp'/ROOT
    packet(folder,'freeze.json',ROOT_SHA,pin,physical)
    packet(repo/'.ios-host-tmp'/SUBJECT,'source-freeze.json',SUBJECT_SHA,pin,physical)
    packet(repo/'.ios-host-tmp'/UTILITY,'source-freeze.json',UTILITY_SHA,pin,physical)
    assert pin(folder/'results.json')['sha256']==RESULT_SHA
    references=json.loads((folder/'actual-receipt-references.json').read_text());assert type(references)is dict and len(references)==67
    for key,row in references.items():
        path=Path(row['path']);assert key==str(path)and path.is_absolute()and path.resolve(strict=True)==path
        actual=pin(path);assert actual['sha256']==row['sha256'];physical[str(path)]=actual
    value=json.loads((folder/'results.json').read_text())
    assert value['status']=='ROOT_QUALIFIED_SNAPSHOT_ORIGINAL_LIFETIME_FOUR_GENUINE_HOST_CONTROLS_ONLY'
    assert value['lifetimeUtilityHostCasesQualified']is True and value['sourceFreeze']==UTILITY_SHA and value['subjectSourceFreeze']==SUBJECT_SHA
    assert value['actualCaseCount']==4 and value['actualFreshSubjectOrigins']==6
    cases=['test_owned_node_natural_exit.OriginalNodeLifetimeObservationTests.'+name for name in SUFFIXES]
    assert value['actualCases']==cases and [row['id']for row in value['actualCaseReceipts']]==cases
    assert value['snapshotConsumerAdmission']is None and value['nativeQualified']is value['featureQualified']is value['wholeQualified']is False
    children=value['actualChildren'];assert len(children)==4 and [row['caseId']for row in children]==cases
    assert len({row['birth']['pid']for row in children})==4
    for child in children:
        assert child['returnCode']==0 and child['actualKernelAbsent']is True and child['allThreeParentStreamsClosed']is True
        assert child['actualNestedOriginalPosixSpawn']is True and child['copiedInterpreterOriginal']is None
        assert len(child['pipes'])==6 and len({row['name']for row in child['pipes']})==6
        assert all(row['sameOriginalStillLive']is False for row in child['pipes'])
    for row in value['actualCaseReceipts']:
        assert row['remainingStandardCleanups']==row['newTemporaryDirectories']==0
        for name in('standardStopAfterCleanup','originalMethodsUnchanged','monitorSlotsUnchanged','fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','utilityChildScopeEstablished'):assert row[name]is True
        assert len(row['actualUtilityChildren'])==len(row['actualNestedCleanupCalls'])==1
        cleanup=row['actualNestedCleanupCalls'][0];assert cleanup['originalReturned']is True and cleanup['remaining']==0 and cleanup['originalRaised']is None and not cleanup['newCallbackErrors']and not cleanup['newCallbackFailures']
    report=value['actualReport'];assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==4 and report['fatal']is None and report['retainedTemporaryDirectories']==[]
    for name in('cleanupEstablished','allActualLoadedOriginsAccounted','fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','twoToyCensusesEqual'):assert report[name]is True
    terminal=value['terminal'];assert terminal['status']=='PASS'and terminal['childReturnCode']==0 and terminal['problems']==terminal['orphansRequiredKill']==[]
    for name in('actualFourGenuineUtilityChildrenEstablished','actualStdlibParentFDThreadDrain','allSixSelectedActualRuntimeOriginsEstablished','allSourceBinaryPinsEqual','approvedInputsExactPinAndCliShaUnchanged','ownProcessesAbsent','twoFullOwnOutputCensusesEqual'):assert terminal[name]is True
    assert terminal['forcedKill']is terminal['timedOut']is False
    restore=value['actualPortRestoration'];assert restore['count']==27 and restore['controlDescriptors']==[]and restore['classCleanupRestorationError']is None
    for name in('restored','dupPortsRestored','toolsRestored','builtinsCioRestored'):assert restore[name]is True
    assert restore['actualC10dHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
    roots=value['newOriginalRoots'];assert type(roots)is list and len(roots)==len(set(roots))==4
    for root in roots:assert Path(root).is_absolute()and Path(root).resolve(strict=True)==Path(root)
    prepared=Path(terminal['fullOwnCensusRoot']);assert str(prepared)in roots
    origin_path=prepared/'child-receipts/actual-source-model-origins.json';assert str(origin_path)in references
    origins=json.loads(origin_path.read_text());assert origins['allSixSelectedActualRuntimeOriginsEstablished']is True
    assert len(origins['subjectOrigins'])==6
    for leaf,digest in SUBJECT_BYTES.items():
        name=leaf[:-3];row=origins['subjectOrigins'][name];actual=prepared/leaf
        assert row['actualModulePresent']is row['exactOriginMatched']is True
        assert row['actualModuleFile']==row['actualLoaderExecutedPath']==row['expectedPath']==origins['actualExecutedOrigins'][name]==str(actual)
        assert row['expectedSha256']==digest==pin(actual)['sha256']
        for path in(source/leaf,repo/'.ios-host-tmp'/SUBJECT/leaf,repo/'.ios-host-tmp'/UTILITY/leaf):
            current=pin(path);assert current['sha256']==digest;physical[str(path)]=current
    assert all(pin(path)==row for path,row in physical.items())
    return dict(rootFreeze=dict(path=str(folder/'freeze.json'),sha256=ROOT_SHA),resultsSha256=RESULT_SHA,
        actualReferenceCount=67,actualFourParentLifetimeControlsQualified=True,requiredOriginalRoots=roots,
        subjectFreeze=SUBJECT_SHA,utilityFreeze=UTILITY_SHA,subjectBytes=dict(SUBJECT_BYTES),
        SnapshotConsumerCompositionQualified=False,nativeQualified=False,featureQualified=False,wholeQualified=False,
        scope='FOUR_ACTUAL_BINARY_HASH_BRACKET_TERMINAL_MISSING_AND_WRONG_IDENTITY_HOST_CONTROLS_ONLY_NOT_SNAPSHOT_CASE_OR_ATOMIC_SIGNALING'),physical
