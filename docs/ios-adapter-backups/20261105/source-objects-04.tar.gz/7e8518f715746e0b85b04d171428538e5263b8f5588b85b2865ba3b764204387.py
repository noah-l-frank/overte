"""Four prospective REAL Linux child/state controls; no Moving/native claim.

Nothing is spawned on import. A separately reviewed closed Root utility must
configure its actual owned toys root and original interpreter before selection.
"""
from pathlib import Path
from copy import deepcopy
import hashlib,os,shutil,subprocess,sys,tempfile,time,unittest
import moving_owned_identity as kernel
from moving_process_observation import NoPositiveExecutable,observe_owned_executable,stat_original

_CHILD='import sys; sys.stdin.buffer.read(1)'
_CONTEXT=None
_ACTUAL=[]

def configure(toys,python_path,python_sha256):
    global _CONTEXT
    assert _CONTEXT is None and isinstance(toys,Path)
    toys=Path(toys);python_path=Path(python_path)
    repository=Path.cwd().resolve(strict=True)
    assert repository.name=='overte-ios-feature-adapters-resume-20261026'and(repository/'.git').is_file()
    assert toys.is_absolute()and toys.resolve(strict=True)==toys and toys.is_dir()and toys.is_relative_to(repository/'.ios-host-tmp')
    # Future closed utility must additionally bind this exact actual ownRoot
    # in its IO/FD/dir_fd/Source/input boundary; this is no blanket Private port.
    assert python_path==Path(sys.executable).resolve(strict=True)
    assert hashlib.sha256(python_path.read_bytes()).hexdigest()==python_sha256
    _CONTEXT=dict(toys=toys,python=python_path,pythonSha256=python_sha256)

def actual_records():return deepcopy(_ACTUAL)

class MovingProcessObservationTests(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(_CONTEXT);self.actual_children=[]
    def child(self,executable=None):
        path=_CONTEXT['python']if executable is None else executable
        process=subprocess.Popen([str(path),'-S','-B','-c',_CHILD],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        self.addCleanup(self.close_child,process)
        binding=kernel.process(process.pid)
        self.assertIsNotNone(binding);self.assertEqual(os.getpid(),binding['parentPid'])
        self.assertEqual(binding['pid'],binding['pgid']);self.assertEqual(binding['pid'],binding['sid'])
        self.actual_children.append(dict(binding=binding,process=process));return process,binding
    def close_child(self,process):
        if process.stdin is not None and not process.stdin.closed:process.stdin.close()
        # Genuine parent wait/stdio cleanup only. No synthetic PID, kill or
        # quiet claim; timeout/failure is an actual failed cleanup for outer.
        process.wait(timeout=5)
        for stream in(process.stdout,process.stderr):
            if stream is not None:stream.close()
        self.assertIsNone(kernel.process(process.pid))
    def test_actual_unreaped_zombie_is_no_positive_executable_never_absence(self):
        process,binding=self.child();process.stdin.close();deadline=time.monotonic()+5
        while True:
            row=stat_original(process.pid)
            if row is not None and row['state']=='Z':break
            self.assertLess(time.monotonic(),deadline);time.sleep(.005)
        # Do not poll()/wait(): that would reap the real zombie before read.
        self.assertIsNone(process.returncode);events=[]
        value=observe_owned_executable(binding,binding,events=events)
        self.assertIs(type(value),NoPositiveExecutable)
        self.assertEqual(binding,value.record['before']['identity']);self.assertEqual(binding,value.record['after']['identity'])
        self.assertEqual('Z',value.record['before']['state']);self.assertEqual('Z',value.record['after']['state'])
        self.assertFalse(value.record['positiveExecutableEstablished']or value.record['processAbsenceEstablished'])
        self.assertIsNotNone(kernel.process(process.pid));self.close_child(process)
        _ACTUAL.append(dict(id=self.id(),birth=binding,observation=deepcopy(events),actualWaitReturn=process.returncode,actualPIDGoneAfterWait=kernel.process(process.pid)is None))
    def test_actual_reaped_child_missing_stat_has_no_positive_or_absence_authority(self):
        process,binding=self.child();self.close_child(process);events=[]
        value=observe_owned_executable(binding,binding,events=events)
        self.assertIs(type(value),NoPositiveExecutable);self.assertIsNone(value.record['before']);self.assertIsNone(value.record['after'])
        self.assertFalse(value.record['positiveExecutableEstablished']or value.record['processAbsenceEstablished'])
        _ACTUAL.append(dict(id=self.id(),birth=binding,observation=deepcopy(events),actualWaitReturn=process.returncode,actualPIDGoneAfterWait=kernel.process(process.pid)is None))
    def test_two_genuine_sessions_refuse_foreign_identity_before_executable_read(self):
        own,own_binding=self.child();foreign,foreign_binding=self.child();events=[]
        self.assertNotEqual(own_binding['sid'],foreign_binding['sid'])
        with self.assertRaises(AssertionError):observe_owned_executable(foreign_binding,own_binding,events=events)
        self.assertEqual('ObservationError',events[0]['outcome']);self.assertIsNone(events[0]['before'])
        self.assertFalse(events[0]['positiveExecutableEstablished']or events[0]['processAbsenceEstablished'])
        self.close_child(foreign);self.close_child(own)
        _ACTUAL.append(dict(id=self.id(),birth=own_binding,foreignBirth=foreign_binding,observation=deepcopy(events),actualBothWaited=True))
    def test_actual_live_deleted_executable_remains_original_error_not_zombie_or_absence(self):
        # Real ELF copy and real live child: no monkey-patched readlink/error,
        # process dictionary, state flag, fake PID or substitute /proc file.
        with tempfile.TemporaryDirectory(dir=_CONTEXT['toys'])as temporary:
            path=Path(temporary)/'owned-original-python';shutil.copyfile(_CONTEXT['python'],path);path.chmod(0o700)
            self.assertEqual(_CONTEXT['pythonSha256'],hashlib.sha256(path.read_bytes()).hexdigest())
            process,binding=self.child(path)
            before=stat_original(process.pid);self.assertNotEqual('Z',before['state'])
            path.unlink();actual_link=os.readlink('/proc/'+str(process.pid)+'/exe')
            self.assertTrue(actual_link.endswith(' (deleted)'));events=[]
            with self.assertRaises(FileNotFoundError):observe_owned_executable(binding,binding,events=events)
            self.assertEqual('ObservationError',events[0]['outcome']);self.assertIsNotNone(events[0]['originalKernelError'])
            self.assertEqual(binding,events[0]['before']['identity']);self.assertEqual(binding,events[0]['after']['identity'])
            self.assertNotEqual('Z',events[0]['after']['state'])
            self.assertFalse(events[0]['positiveExecutableEstablished']or events[0]['processAbsenceEstablished'])
            self.close_child(process)
            _ACTUAL.append(dict(id=self.id(),birth=binding,actualDeletedExecutableLink=actual_link,observation=deepcopy(events),actualWaitReturn=process.returncode,actualPIDGoneAfterWait=kernel.process(process.pid)is None))
