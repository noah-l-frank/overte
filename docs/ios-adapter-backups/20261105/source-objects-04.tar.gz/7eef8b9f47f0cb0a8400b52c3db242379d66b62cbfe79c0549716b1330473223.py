"""Pure original membership before Audio11 permits another live source or SDK.

Unknown names, foreign originals, missing parents and changed immutable bytes
fail closed. Familiar prefixes never establish ownership on their own.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import collect,scope,readonly
from adapters.script_feature.history import unpack,same
from ios.adapters.audio_passive_runtime import PassiveSDKLedger,stored_actor_ledger
from ios.adapters.audio_recorded_owner import IOSAudioRecordedOwner

PREFIXES=('ios-audio-','ios-audio11-')

def census(flow):
    paths=set();sdk={flow.adapter.state_path(s).parent for s in (flow.primary_selector,flow.actor_selector)}
    roots={flow.primary_root,flow.actor_root,Path(flow.config['primaryWholeRoot']),Path(flow.config['actorWholeRoot']),flow.public_root}
    need(not sdk.intersection(roots))
    for directory in sdk|roots:
        need(directory.is_absolute() and directory.resolve(strict=True)==directory)
        for index,path in enumerate(directory.iterdir()):
            need(index<16384 and not path.is_symlink())
            selected=directory in roots or path.name.startswith(PREFIXES) or path.name.startswith('phase-publication-audio-'+flow.run)
            if not selected:continue
            if path.is_dir():
                for i,child in enumerate(path.rglob('*')):
                    need(i<32768 and not child.is_symlink())
                    if child.is_file():paths.add(child)
            else:paths.add(path)
    return paths


def primary(flow):
    root=flow.adapter.state_path(flow.primary_selector).parent
    owner_store=PrivateFeatureState(root/'ios-audio-recorded-owner.json');value=owner_store.read()
    scope_store=PrivateFeatureState(root/'ios-audio-scope.json');scoped=scope_store.read()
    if value is None:
        if scoped is not None:need(scoped==dict(iosAudioScopeVersion=1,binding=flow.state['bindings']['primary'],runId=flow.run,artifactRoot=str(flow.primary_root)))
        return None
    owner=IOSAudioRecordedOwner.archive(owner_store,flow.primary_root,flow.state['bindings']['primary'],flow.run,flow.locks[1],flow.client.url+'/runs/'+flow.run+'/')
    need(scoped==dict(iosAudioScopeVersion=1,binding=owner.binding,runId=flow.run,artifactRoot=str(flow.primary_root)))
    from ios.adapters.audio_authorization_sources import AudioAuthorizationSources
    from ios.adapters.audio_authorized_start import AudioAuthorizedStarts
    store=PrivateFeatureState(root/'ios-audio-authorization-owner.json');grants=AudioAuthorizationSources.archive(store,owner) if store.read() is not None else None
    store=PrivateFeatureState(root/'ios-audio-authorized-starts.json')
    if store.read() is not None:need(grants is not None);AudioAuthorizedStarts.archive(store,owner,grants)
    from ios.adapters.audio_pcm_lease import IOSAudioPCMLease
    for name in ('ios-audio-pcm-lease.json','ios-audio-close-lease.json'):
        store=PrivateFeatureState(root/name)
        if store.read() is not None:IOSAudioPCMLease.archive_retired(store,owner) if owner.state['pending'] is not None or owner.state['observation'] is not None else IOSAudioPCMLease.archive(store,owner)
    store=PrivateFeatureState(root/'ios-audio-background.json');value=store.read()
    if value is not None:
        from ios.adapters.audio_background import AudioBackground
        from ios.adapters.audio_background_bridge import RecordedPrefix
        rows=unpack(value['payload']);need(len(rows)==1)
        prefix=RecordedPrefix(owner,rows[0]['parent'],owner.state)
        # Bundle identity is the original declared target; it is not queried
        # from a new process or a substitute OS observation.
        target=flow.adapter._target(flow.primary_selector)
        AudioBackground.archive(store,prefix,target['appId'])
    return owner


def actor(flow):
    # Complete typed original admission for exactly one actual existing family.
    return stored_actor_ledger(flow.actor_runtime,flow.actor_selector,flow.run,flow.actor_root,flow.client,flow.locks[0])


def read_scope(flow,*,skip_readmission=False):
    need(same(flow.store.read(),flow.previous))
    if flow.state is None:return
    if flow.public_index is not None:flow.public_index.owned_paths();flow.public_index.originals()
    initial=flow.current(historical=True,stage='initial');initial.owned_paths()
    if flow.state.get('replacement') is not None:flow.current(historical=True,stage='replacement').owned_paths()
    baseline=flow.state['baseline']
    if baseline is not None:need(baseline['reference'] in initial.state['records']);initial.original(baseline['reference'])
    primary(flow);actor(flow)
    for row in flow.state['artifacts']:
        if row['phase']=='saved':flow.evidence.read(row);flow.validate_artifact_source(row)
        elif row['phase']=='opened':flow.evidence.read_partial(row)
    from ios.adapters.audio_whole_terminal import AudioWholeTerminal
    AudioWholeTerminal(flow).admit_archives(skip_readmission=skip_readmission)
    store=PrivateFeatureState(flow.adapter.state_path(flow.actor_selector).with_name('phase-publication-audio-'+flow.run+'-actor.json'));value=store.read()
    if value is not None:
        from adapters.phase_witness_publisher import PhaseWitnessPublisher
        from adapters.script_feature.history import unpack
        # The Actor's original reader rederives every published sample; no
        # publisher credential is needed by this pure admission.
        owner=flow
        if flow.role!='actor':
            from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
            owner=IOSAudioWholeFeature(flow.adapter,flow.primary_selector,flow.run,'actor',flow.client,flow.config,epoch_ms=flow.epoch_ms,monotonic=flow.monotonic,sleep=flow.sleep,runtimes=(flow.actor_runtime,flow.primary_runtime),source_locks=flow.locks);owner.load();need(owner.state is not None)
        PhaseWitnessPublisher.archive(value,store=store,binding=owner.state['bindings']['actor'],run=flow.run,area='audio',fixture_url=flow.client.url,phase_instance=value['phaseInstance'],validate_original=owner.publication_original)


def admit(flow,*,include_peer=True,skip_readmission=False):
    for lock in flow.locks:lock.assert_held()
    def selected():
        paths=census(flow)
        if skip_readmission and flow.state is not None and flow.state['oldEnd'] is not None:
            root=Path(flow.state['oldEnd']['root'])
            # The shared original readmission owner independently guards only
            # these exact new files. No other name/prefix is delegated.
            paths={p for p in paths if not (p.parent==root and p.name.startswith('original-readmission-frame-sources-'+flow.run+'-primary-'))}
        return paths
    before=selected()
    with collect() as reads,scope(fresh=True),readonly():
        read_scope(flow,skip_readmission=skip_readmission)
        if include_peer:
            from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
            role='actor' if flow.role=='primary' else 'primary'
            peer=IOSAudioWholeFeature(flow.adapter,flow.primary_selector,flow.run,role,flow.client,flow.config,epoch_ms=flow.epoch_ms,monotonic=flow.monotonic,sleep=flow.sleep,runtimes=(flow.actor_runtime,flow.primary_runtime),source_locks=flow.locks)
            peer.load()
            if peer.state is not None:read_scope(peer,skip_readmission=skip_readmission)
        need(before==selected() and before.issubset(reads))
    return before
