"""UNRUN controller utilities: actual sockets/FDs/stdlib member custody only.

No product imports, Node/SDK/native process or fixture verdict is constructed.
A future reviewed retaining harness must own every temporary original and FD.
"""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
import json,os,socket,socketserver,sys,tempfile,threading,types,unittest
from scoped_ports import FixturePorts
from owned_write_boundary import WriteRefusal

_ORIGINAL_SAVE_PORTS=(os.open,os.write,os.fsync,os.close)
def save(path,value):
    fd=_ORIGINAL_SAVE_PORTS[0](path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:_ORIGINAL_SAVE_PORTS[1](fd,json.dumps(value).encode());_ORIGINAL_SAVE_PORTS[2](fd)
    finally:_ORIGINAL_SAVE_PORTS[3](fd)


class ScopedPortNegativeTests(unittest.TestCase):
    def actual_server(self):
        directory=tempfile.TemporaryDirectory();self.addCleanup(directory.cleanup)
        run=Path(directory.name);temporary=run/'temporary';temporary.mkdir(mode=0o700)
        producer=temporary/'actual-producer';producer.mkdir(mode=0o700)
        server=ThreadingHTTPServer(('127.0.0.1',0),BaseHTTPRequestHandler)
        thread=threading.Thread(target=server.serve_forever,kwargs={'poll_interval':.01},daemon=True);thread.start()
        self.addCleanup(server.server_close);self.addCleanup(thread.join,2);self.addCleanup(server.shutdown)
        scope=FixturePorts(temporary,run,save,globals(),sys._getframe(),(),{},'unused-no-node-utility')
        self.addCleanup(scope.restore);scope.add_server(server,thread,producer)
        return scope,server,scope.servers[0]

    def test_actual_same_socket_object_foreign_fd_inode_is_rejected_and_descriptor_restored(self):
        scope,server,row=self.actual_server();sock=server.socket;descriptor=scope.c_fileno(sock)
        before=scope.real_fstat(descriptor);saved=os.dup(descriptor)
        foreign=socket.socket(socket.AF_INET,socket.SOCK_STREAM);foreign.bind(('127.0.0.1',0));foreign.listen()
        try:
            os.dup2(foreign.fileno(),descriptor)
            changed=scope.real_fstat(descriptor)
            self.assertNotEqual((before.st_dev,before.st_ino),(changed.st_dev,changed.st_ino))
            with self.assertRaises(WriteRefusal):scope.server_guard(row)
        finally:os.dup2(saved,descriptor);os.close(saved);foreign.close()
        self.assertEqual((before.st_dev,before.st_ino),(scope.real_fstat(descriptor).st_dev,scope.real_fstat(descriptor).st_ino))
        self.assertEqual(row[2],scope.server_guard(row))

    def test_foreign_socket_answer_proxy_is_rejected_without_calling_fake_methods(self):
        scope,server,row=self.actual_server();original=server.socket;calls=[]
        class AnswerProxy:
            def fileno(self):calls.append('fileno');return row[4][0]
            def getsockname(self):calls.append('getsockname');return row[4][4]
            def getsockopt(self,*args):calls.append('getsockopt');return socket.SOCK_STREAM
        try:
            server.socket=AnswerProxy()
            with self.assertRaises(WriteRefusal):scope.server_guard(row)
            self.assertFalse(calls)
        finally:server.socket=original
        self.assertEqual(row[2],scope.server_guard(row))

    def test_original_http_function_binding_and_globals_are_required_then_restored(self):
        scope,server,row=self.actual_server();cls=socketserver.ThreadingMixIn;original=cls.process_request_thread
        replacement=types.FunctionType(original.__code__,dict(original.__globals__),original.__name__,original.__defaults__,original.__closure__)
        try:
            cls.process_request_thread=replacement
            with self.assertRaises(WriteRefusal):scope.check()
        finally:cls.process_request_thread=original
        scope.check();self.assertEqual(row[2],scope.server_guard(row))
