"""Actual existing Source/HTTP/AFC + ordinary marker frontdoor composition.

The only replacements are declared lower SDK/Qt/native data producers. No
product constructor, manager, picker, renderer decoder or clock is replaced.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,base64,hashlib,inspect,io,json,marshal,os,uuid
from concurrent.futures import Future
from copy import deepcopy
from pathlib import Path
from urllib.request import Request
from unittest.mock import patch
from ios.adapters import feature_observation,normal_input
from ios.self_tests import test_ios_lifecycle_world_attempt as attempt_fixture
from ios.self_tests import test_ios_installed_adapter as installed_fixture
from lifecycle_moving_native_initial_state import MovingNativeClock,OriginalNativeClockBoundary
from normal_child_fixture import ActualPostRequest
from lifecycle_moving_constructor_fixture import LifecycleMovingConstructorFixture
from lifecycle_moving_raw_world_renderer import SELF
from lifecycle_moving_raw_paths import guarded_path
from lifecycle_moving_raw_channels import RawMovingChannels
from lifecycle_moving_raw_ui import RawMovingUI


class LifecycleMovingRawConstructorFixture(LifecycleMovingConstructorFixture):
    async def asyncSetUp(self):
        old_touch=attempt_fixture.TouchBoundary;old_native_clock=installed_fixture.ClockBoundary
        self.assertIs(old_native_clock,OriginalNativeClockBoundary)
        class MovingNativeTouch(old_touch):
            def decorate(receiver,value):
                super().decorate(value)
                # Independent model identity selected before ANY first normal
                # Source/Current7/baseline packet, never a saved original edit.
                value['source']['domain']['selfSha256']=hashlib.sha256(uuid.UUID(SELF).bytes).hexdigest()
        with patch.object(attempt_fixture,'TouchBoundary',MovingNativeTouch),patch.object(installed_fixture,'ClockBoundary',MovingNativeClock):
            await super().asyncSetUp()
        self.assertIsNone(self.feature.store.read())
        root=guarded_path(self.current_root.with_name('moving-explicit-raw-producers'))
        self.moving_channels=RawMovingChannels(self,root);self.moving_ui=RawMovingUI(self,self.moving_channels)
        self.bind_raw_moving_transport()
        # Exact selected class/MRO/source identities are retained before the
        # NEW genuine marker Scope, original Feature.parts and image acquisition.
        side=guarded_path(Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/'moving-raw-producer-boundary.json')
        names=['lifecycle_moving_raw_paths.py','lifecycle_moving_raw_files.py','lifecycle_moving_raw_worker.py',
            'lifecycle_moving_marker_worker.mjs','lifecycle_moving_raw_world_renderer.py','lifecycle_moving_raw_gpu.py',
            'lifecycle_moving_raw_channels.py','lifecycle_moving_raw_ui.py','lifecycle_moving_raw_constructor_fixture.py',
            'lifecycle_moving_native_initial_state.py']
        files={name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()for name in names}
        value=dict(movingRawProducerBoundaryVersion=1,sdkNativeQtVulkanExplicitModels=True,
            actualHostWork=['canonical original Source/Current7','existing loopback handler','actual AFC files','Node VM',
                'real physics/HID thread','actual page HTTP polling','CPU mesh rasterization/PNG','real worker Event/buffer'],
            noNativeDeviceQualification=True,selectedBeforeNewMarkerScope=True,retrofittedOldOriginals=False,
            identitySelectedBeforeFirstSource=True,nativeInitialStateSelectedBeforeFirstSource=True,
            oldNativeClockMro=[k.__module__+'.'+k.__qualname__ for k in old_native_clock.__mro__],
            movingNativeClockMro=[k.__module__+'.'+k.__qualname__ for k in MovingNativeClock.__mro__],
            originalNativeSendCodeSha256=hashlib.sha256(marshal.dumps(old_native_clock.send.__code__)).hexdigest(),
            movingNativeSendCodeSha256=hashlib.sha256(marshal.dumps(MovingNativeClock.send.__code__)).hexdigest(),
            movingNativeInitialOverrideActive=False,oldTouchMro=[k.__module__+'.'+k.__qualname__ for k in old_touch.__mro__],
            movingTouchMro=[k.__module__+'.'+k.__qualname__ for k in MovingNativeTouch.__mro__],
            movingDecorateCodeSha256=hashlib.sha256(marshal.dumps(MovingNativeTouch.decorate.__code__)).hexdigest(),
            originalSenderSourceSha256=hashlib.sha256(Path(inspect.getsourcefile(ActualPostRequest)).read_bytes()).hexdigest(),
            producerSourceSha256=files,origin=self.origin,existingServerAddress=list(self.server.server_address),
            originalRawRoot=str(root))
        side.write_text(json.dumps(value,sort_keys=True)+'\n');side.chmod(0o600)

    def bind_raw_moving_transport(self):
        channels,ui=self.moving_channels,self.moving_ui;native=self.normal.native.b
        previous_observed=native.observed;previous_post=native.post;previous_call=self.normal.client.call
        previous_execute=self.normal.client.execute;previous_handler=self.server.RequestHandlerClass
        previous_feature_post=feature_observation.post_request.side_effect
        def observed():return ui.decorate(previous_observed())
        native.observed=observed
        def native_post(request,timeout):
            query=json.loads(request.data)
            if query.get('action')=='normal-ui-input':
                if query['operation']=='observe':
                    native.requests.append(deepcopy(query));native.receipt=dict(schemaVersion=1,commandId=query['commandId'],observation=observed())
                    native.response=json.dumps(query).encode();return native
                if query.get('input')is not None and ui.edit(query,observed()):
                    native.requests.append(deepcopy(query));return native
            return previous_post(request,timeout)
        native.post=native_post
        def call(method,path,body=None):
            chosen,returned=ui.call(method,path,body,observed())
            return returned if chosen else previous_call(method,path,body)
        self.normal.client.call=call
        target=self.normal.d.source.source['target'];session=self.normal.d.source.source['session']
        remote_root='@'+target['appId']+':documents/'+target['testBuild']['resultsDirectory']+'/'
        def execute(current_session,operation,arguments):
            if operation=='mobile: pullFile'and type(arguments)is dict:
                remote=arguments['remotePath'];name=remote.removeprefix(remote_root)
                if remote.startswith(remote_root)and name in channels.outputs:
                    self.assertEqual(session,current_session)
                    return base64.b64encode(channels.original_bytes(name)).decode()
            return previous_execute(current_session,operation,arguments)
        self.normal.client.execute=execute
        outer=self
        class MovingRawHandler(previous_handler):
            def do_POST(handler):
                raw=handler.rfile.read(int(handler.headers['Content-Length']));query=json.loads(raw)
                if query.get('action')not in channels.ACTION_FILES:
                    original=handler.rfile;handler.rfile=io.BytesIO(raw)
                    try:return super().do_POST()
                    finally:handler.rfile=original
                complete=Future()
                def produce():
                    try:
                        value=channels.produce(query)
                        # This is the SAME actual original Source AFC endpoint;
                        # the query's immutable per-nonce raw body is also kept.
                        guarded_path(outer.input).write_text(json.dumps(value))
                        complete.set_result(None)
                    except BaseException as error:complete.set_exception(error)
                outer.loop.call_soon_threadsafe(produce)
                try:
                    complete.result(timeout=5);handler.send_response(200);handler.send_header('Content-Length',str(len(raw)))
                    handler.end_headers();handler.wfile.write(raw)
                except(BrokenPipeError,ConnectionResetError):pass
                except BaseException as error:outer.server_errors.append(error)
        self.server.RequestHandlerClass=MovingRawHandler
        def route(request,timeout):
            query=json.loads(request.data)
            return ActualPostRequest(request,timeout)if query.get('action')in channels.ACTION_FILES else previous_feature_post(request,timeout)
        # Ordinary NativeInput also reaches the actual existing handler. Its
        # original native receipt, sequence, focused token and AFC path remain.
        self.enterContext(patch.object(normal_input,'urlopen',new=ActualPostRequest))
        self.enterContext(patch.object(feature_observation,'post_request',side_effect=route))

    async def cleanup_real_frontdoor(self):
        try:await super().cleanup_real_frontdoor()
        finally:
            if hasattr(self,'moving_channels'):
                # Emergency host drain is independent from the genuine product
                # cleanup result and cannot convert its failure into success.
                await asyncio.to_thread(self.moving_channels.close)
