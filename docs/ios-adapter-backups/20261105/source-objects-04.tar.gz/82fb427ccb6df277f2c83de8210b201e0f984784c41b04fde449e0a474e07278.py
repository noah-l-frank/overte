"""Qualify only actual four genuine original-lifetime host controls."""
from pathlib import Path
import hashlib,json,runpy
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,v):
 with(d/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
C=B/'root-single-snapshot-original-lifetime4-window-current1043-b1-20261105';assert sha(C/'freeze.json')=='41d15fc4bec0304de66f2aacf108bf0de04122700af6a28c55bd8a22d2f0af31'
for n,x in load(C/'freeze.json')['files'].items():assert sha(C/n)==x['sha256']
t=load(C/'terminal.json');assert t['oldRootCount']==1043 and len(t['groups'])==1 and len(t['newOriginalRoots'])==4
for k in ('allOldOriginalBodiesUnchanged','wholeOwnOutputsTwiceEqual','allExecutedOwnedProcessesAbsent'):assert t[k]is True
assert load(C/'global-before.json')==load(C/'global-after-first.json')==load(C/'global-after-second.json') and len(load(C/'global-before.json'))==1043
assert load(C/'whole-output-first.json')==load(C/'whole-output-second.json')
a=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(a)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(a))['census']
for n,v in load(C/'whole-output-first.json').items():assert census(Path(n))==v
row=t['groups'][0];h=Path(row['input']).parent;assert sha(row['input'])==row['inputSha256']=='cca899685c9cf348d251c5da7115a0dcff8a1d989743dfba8f88f2fed3a3974b';p=load(row['input']);terminal=row['originalTerminal'];assert row['supervisorReturnCode']==0 and terminal['status']=='PASS'and terminal['childReturnCode']==0 and not terminal['timedOut']and not terminal['forcedKill']and not terminal['problems']and not terminal['orphansRequiredKill']
for k in ('actualFourGenuineUtilityChildrenEstablished','actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allSixSelectedActualRuntimeOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','twoFullOwnOutputCensusesEqual','ownProcessesAbsent'):assert terminal[k]is True
r=load(h/'child-receipts/report.json');assert r['status']=='PASS'and r['testsRun']==r['actualCaseReceipts']==r['PythonExecutions']==4 and r['cleanupEstablished']and r['fatal']is None and not r['retainedTemporaryDirectories']and not r['partialConstructorRescue']and r['partialConstructorRescueError']is None
cases=[]
for i,selected in enumerate(p['cases'],1):
 v=load(h/f'child-receipts/standard-case-{i}.json');assert v['id']==selected and v['newTemporaryDirectories']==v['remainingStandardCleanups']==0 and len(v['actualNestedCleanupCalls'])==1
 for k in ('fdUnchanged','kernelChildrenUnchanged','monitorSlotsUnchanged','originalMethodsUnchanged','standardStopAfterCleanup','threadsUnchanged','utilityChildScopeEstablished'):assert v[k]is True
 assert len(v['actualUtilityChildren'])==1;cases.append(v)
children=load(h/'child-receipts/actual-utility-children.json');assert len(children)==4 and len({v['birth']['pid']for v in children})==4
for child,case in zip(children,p['cases']):
 assert child['caseId']==case and child['actualKernelAbsent']is child['allThreeParentStreamsClosed']is child['actualNestedOriginalPosixSpawn']is True and child['returnCode']==0 and child['copiedInterpreterOriginal']is None
 assert len(child['pipes'])==6 and all(v['sameOriginalStillLive']is False for v in child['pipes'])
ports=load(h/'child-receipts/actual-port-restoration.json');assert ports['restored']and ports['builtinsCioRestored']and ports['dupPortsRestored']and ports['toolsRestored']and ports['count']==27 and not ports['controlDescriptors']
pre=load(h/'child-receipts/actual-class-cleanup-calls.json');assert pre['descriptorRestored']is False and pre['actualOriginalClassCleanupCalls']==1 and pre['allSelectedClassesObservedExactlyOnce']and pre['allActualOriginalCallsAccepted']
assert ports['actualClassCleanupRestoration']['originalDescriptorRestored']and ports['actualClassCleanupRestoration']['summary']['descriptorRestored']
q=load(h.with_name(h.name+'-censuses')/'qualification.json');assert q['status']=='PASS'and q['actualUtilityCases']==4 and q['ownProcessesAbsent']and q['noCensusExclusions']and q['snapshotConsumerAdmission']is None
drain=load(h.with_name(h.name+'-outer')/'actual-process-drain.json');assert not drain['remaining']and not drain['orphansRequiredKill']
for v in drain['owned']:
 try:raw=Path('/proc',str(v['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(raw[raw.rfind(')')+2:].split()[19])!=v['startTicks']
refs={str(f):dict(path=str(f),sha256=sha(f))for root in map(Path,t['newOriginalRoots'])for f in sorted(root.rglob('*'))if f.is_file()and not f.is_symlink()}
O=B/'root-snapshot-original-lifetime-four-original-host-qualified-results-20261105';O.mkdir(mode=0o700)
put(O,'results.json',dict(status='ROOT_QUALIFIED_SNAPSHOT_ORIGINAL_LIFETIME_FOUR_GENUINE_HOST_CONTROLS_ONLY',terminal=terminal,newOriginalRoots=t['newOriginalRoots'],lifetimeUtilityHostCasesQualified=True,actualCases=p['cases'],actualCaseCount=4,actualChildren=children,actualCaseReceipts=cases,actualReport=r,actualPortRestoration=ports,sourceFreeze=p['sourceFreeze'],subjectSourceFreeze=p['subjectSourceFreeze'],originalCollectorFreeze=sha(C/'freeze.json'),all1043OldOriginalBodiesUnchanged=True,actualFreshSubjectOrigins=6,actualClassCleanupPreRestorationFalsePreserved=True,snapshotConsumerAdmission=None,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(O,'actual-receipt-references.json',refs);put(O,'freeze.json',dict(files={f.name:dict(sha256=sha(f))for f in O.iterdir()}));print(json.dumps(dict(freeze=sha(O/'freeze.json'),results=sha(O/'results.json'),references=len(refs))))
