"""Actual per-generation Page originals, with exact namespace membership.

Only the selected page namespace is inventoried here. Episode files, Models,
images, server and complete SDK directories remain separate typed duties.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from contextlib import nullcontext
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import collect
from ios.adapters.assets_born_page_lease import BornAssetsPageLease
from ios.adapters.assets_episode_metadata_graph import readonly_store
from ios.adapters.assets_episodes import AssetsEpisodes,AssetsEpisodeScope
from ios.adapters.assets_generation_page_lease import GenerationAssetsPageLease
from ios.adapters.assets_historical_picker_snapshots import historical_picker_snapshots
from ios.adapters.assets_page_ownership import skeleton
from ios.adapters.assets_page_generations import EPISODES
from ios.adapters.assets_end_metadata import signature


def archive_generation_page(episodes,generation,birth,scopes):
    need(type(episodes) is AssetsEpisodes and generation in EPISODES and birth.historical
        and birth.selected is episodes.selected and type(scopes) is tuple)
    episodes.guard();born=len(episodes.state['entries'])
    wanted_indices=[index for index in EPISODES[generation] if index<=born]
    need([scope.index for scope in scopes]==wanted_indices and all(type(scope) is AssetsEpisodeScope and scope.owner is episodes for scope in scopes))
    for scope in scopes:
        scope.guard()
        for lock in scope.locks.values():lock.assert_held()
    root=Path(episodes.context['roles']['primary']['stateRoot']);run=episodes.run
    suffix='' if generation==1 else '-g'+str(generation)
    header=root/('ios-assets-page-lease-'+run+'-primary'+suffix+'.json')
    namespace='assets-page-lease'+suffix+'-frame-'
    before={path:signature(path) for path in root.iterdir() if path==header or path.name.startswith(namespace)}
    with collect() as reads:
        pickers={}
        for scope in scopes:
            path=Path(scope.descriptor['directories']['primary']['stateRoot']['path'])/('ios-assets-'+run+'-primary-picker.json')
            if PrivateFeatureState(path).read() is not None:pickers[scope.index]=skeleton(scope,None)
        # Literal known profiles may use the existing operation-local snapshot
        # scope. Generation3 parents retain its explicit literal fallback.
        scoped=historical_picker_snapshots(episodes,pickers,None) if generation==1 else nullcontext(None)
        with scoped as snapshot_scope:
            Parent=BornAssetsPageLease if generation==1 else GenerationAssetsPageLease
            page=Parent.from_archive(episodes,readonly_store(PrivateFeatureState(header)),episodes.locks['primary'],pickers,
                context=birth,snapshot_scope=snapshot_scope)
            paths={header}
            for ref in page.state['records']:
                paths.add(page.originals.path(page.originals.expand(ref)));page.read(ref)
            if page.state['pending'] is not None:
                ref=page.state['pending']['original']
                if ref is not None and ref['phase']!='planned':paths.add(page.originals.path(ref))
            need(paths==set(before) and paths<=reads)
    after={path:signature(path) for path in root.iterdir() if path==header or path.name.startswith(namespace)}
    need(before==after);episodes.guard()
    return dict(owner=page,paths=paths,actualOriginalReads=set(reads),generation=generation,
        pendingSourceDuty=page.state['pending'] is not None,completeDirectoryRead=False,nativeFactsProduced=False,wholeEndEligible=False)


def assert_page_namespace(root,run,pages,canonical_store):
    root=Path(root);known={canonical_store.path}
    for report in pages:known.update(report['paths'])
    actual={path for path in root.iterdir() if path.name.startswith(('assets-page-lease-','ios-assets-page-lease-','ios-assets-page-generations-'))}
    need(actual==known);return True
