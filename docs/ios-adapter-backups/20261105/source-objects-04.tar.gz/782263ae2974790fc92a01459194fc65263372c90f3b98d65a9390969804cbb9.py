"""Exact current parser projections; no original/native/owner result cache."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextvars import ContextVar
from types import ModuleType
import importlib,sys,unittest
from ios.adapters import chat_archive_round as current
from ios.self_tests import chat_source15_module_signature_literal as reference
from ios.self_tests.chat_source15_module_signature_literal import literal_module_signature


def reader(value=None):return value
def alternate(value=None):return (value,)


class Base:
    def read(self):return True


class OtherBase:
    def read(self):return False


class Reader(Base):
    def own(self):return None
    static=staticmethod(reader)
    @classmethod
    def class_read(cls):return cls
    @property
    def property_read(self):return True


class SubInt(int):pass
class SubString(str):pass
class SubFloat(float):pass
class SubTuple(tuple):pass
class SubFrozen(frozenset):pass
class SubModule(ModuleType):pass


class Meta(type):
    observations=[]
    def __getattribute__(self,name):
        if name in ('__mro__','__dict__'):Meta.observations.append(name)
        return type.__getattribute__(self,name)


class MetaReader(metaclass=Meta):
    def read(self):return None


class ClassProbe:
    def __init__(self):self.calls=0
    @property
    def __class__(self):
        self.calls+=1
        from types import FunctionType
        return FunctionType


class EqualityMeta(type):
    calls=0
    def __eq__(cls,other):
        EqualityMeta.calls+=1
        raise AssertionError('Type dispatch invoked a custom metaclass equality')


class OpaqueValue(metaclass=EqualityMeta):pass


class NamespaceName(str):
    calls=0
    def isupper(self):
        NamespaceName.calls+=1
        return str.isupper(self)


class ChatCurrentModuleSignatureTests(unittest.TestCase):
    def same_projection(self,namespace):
        literal=literal_module_signature(namespace)
        actual=current.module_signature(namespace)
        self.assertEqual(literal,actual)
        return actual

    def test_exact_builtin_values_keep_the_complete_source15_projection_and_int_bool_types(self):
        namespace=dict(FUNCTION=reader,CLASS=Reader,MODULE=ModuleType('actual-projection-module'),
            CONTEXT=ContextVar('module-projection',default=None),TEXT='value',INTEGER=1,BOOLEAN=True,
            FLOAT=1.25,NONE=None,TUPLE=('value',1),FROZEN=frozenset(('value',)),
            DICT={'ignored-by-generic':True},LIST=[1],SET={1},BYTES=b'unchanged',ARRAY=bytearray(b'unchanged'),
            lowercase=1)
        result=self.same_projection(namespace);rows={row[0]:row for row in result}
        self.assertIs(type(rows['INTEGER'][1]),int);self.assertIs(type(rows['BOOLEAN'][1]),bool)
        for name in ('DICT','LIST','SET','BYTES','ARRAY','lowercase'):self.assertNotIn(name,rows)

    def test_subclasses_and_custom_metaclass_keep_literal_fallback_and_its_actual_callbacks(self):
        namespace=dict(INTEGER=SubInt(1),TEXT=SubString('one'),FLOAT=SubFloat(1.5),
            TUPLE=SubTuple((1,2)),FROZEN=SubFrozen((1,2)),MODULE=SubModule('submodule'),CLASS=MetaReader)
        Meta.observations=[];literal=literal_module_signature(namespace);calls=list(Meta.observations)
        self.assertTrue(calls)
        Meta.observations=[];actual=current.module_signature(namespace)
        self.assertEqual(literal,actual);self.assertEqual(calls,Meta.observations)

    def test_spoofed_class_instance_checks_still_run_the_identical_literal_fallback(self):
        probe=ClassProbe();namespace={'PROBE':probe}
        literal=literal_module_signature(namespace);calls=probe.calls;self.assertGreater(calls,0)
        probe.calls=0;actual=current.module_signature(namespace)
        self.assertEqual(literal,actual);self.assertEqual(calls,probe.calls)
        observed=0
        for value in (None,1,True,1.25,'text',(1,),frozenset((1,)),
                ModuleType('key-module'),ContextVar('key-context'),Reader,reader,{},[],set(),b'bytes',bytearray(b'array')):
            namespace={NamespaceName('EXOTIC'):value}
            NamespaceName.calls=0;literal=literal_module_signature(namespace);calls=NamespaceName.calls
            observed+=calls;NamespaceName.calls=0
            self.assertEqual(literal,current.module_signature(namespace));self.assertEqual(calls,NamespaceName.calls)
        self.assertGreater(observed,0)

    def test_type_dispatch_adds_no_custom_metaclass_equality_callback(self):
        EqualityMeta.calls=0
        self.assertEqual((),self.same_projection({'OPAQUE':OpaqueValue()}))
        self.assertEqual(0,EqualityMeta.calls)

    def test_new_member_and_existing_ignored_value_becoming_a_reader_are_observed_fresh(self):
        namespace={'lowercase':None};before=self.same_projection(namespace)
        namespace['lowercase']=reader;after=self.same_projection(namespace);self.assertNotEqual(before,after)
        namespace['new_reader']=alternate;added=self.same_projection(namespace);self.assertNotEqual(after,added)
        del namespace['new_reader'];namespace['lowercase']=None;self.assertEqual(before,self.same_projection(namespace))

    def test_same_class_method_code_and_complete_mro_are_read_again_on_the_next_projection(self):
        namespace={'CLASS':Reader};before=self.same_projection(namespace)
        function=Reader.own;original=function.__code__;bases=Reader.__bases__
        try:
            function.__code__=alternate.__code__;changed=self.same_projection(namespace);self.assertNotEqual(before,changed)
            function.__code__=original;Reader.__bases__=(OtherBase,)
            changed=self.same_projection(namespace);self.assertNotEqual(before,changed)
        finally:Reader.__bases__=bases;function.__code__=original
        self.assertEqual(before,self.same_projection(namespace))

    def test_function_alias_metadata_and_module_identity_are_reopened_without_a_memo(self):
        namespace={'A':reader,'B':reader,'MODULE':ModuleType('identity-one')}
        before=self.same_projection(namespace)
        try:
            reader.__self__=object();changed=self.same_projection(namespace);self.assertNotEqual(before,changed)
        finally:del reader.__self__
        self.assertEqual(before,self.same_projection(namespace))
        try:
            reader.__func__=alternate
            changed=self.same_projection(namespace);self.assertNotEqual(before,changed)
        finally:del reader.__func__
        self.assertEqual(before,self.same_projection(namespace))
        namespace['MODULE']=ModuleType('identity-one');self.assertNotEqual(before,self.same_projection(namespace))

    def test_current_original_methods_still_detects_referenced_real_parser_value_change(self):
        for name in current._MODULES:importlib.import_module(name)
        from adapters import native_feature_observation
        self.assertTrue(current.original_methods())
        original=native_feature_observation.LIMIT
        try:
            native_feature_observation.LIMIT=original+1
            self.assertFalse(current.original_methods())
        finally:native_feature_observation.LIMIT=original
        self.assertTrue(current.original_methods())

    def test_rebound_new_and_existing_classifier_aliases_use_complete_independent_literal_path(self):
        missing=object()
        aliases=('dict','list','set','bytes','bytearray','str','int','float','bool','frozenset',
            'type','FunctionType','ModuleType','ContextVar')
        def same_getattr(*args):return getattr(*args)
        def same_id(value):return id(value)
        def same_sorted(*args,**kwargs):return sorted(*args,**kwargs)
        for name,replacement in tuple((name,ClassProbe)for name in aliases)+(
                ('tuple',SubTuple),('getattr',same_getattr),('id',same_id),('sorted',same_sorted)):
            namespace={'PROBE':ClassProbe()}
            before=current.__dict__.get(name,missing);old_reference=reference.__dict__.get(name,missing)
            try:
                current.__dict__[name]=replacement;reference.__dict__[name]=replacement
                expected=reference.literal_module_signature(namespace)
                self.assertEqual(expected,current.module_signature(namespace))
                self.assertEqual('literal-alias-change',current._LAST_MODULE_DISPATCH.get()['mode'])
            finally:
                if before is missing:current.__dict__.pop(name,None)
                else:current.__dict__[name]=before
                if old_reference is missing:reference.__dict__.pop(name,None)
                else:reference.__dict__[name]=old_reference
        def reject_all(*_args):return False
        before=current.__dict__.get('isinstance',missing);old_reference=reference.__dict__.get('isinstance',missing)
        try:
            current.__dict__['isinstance']=reject_all;reference.__dict__['isinstance']=reject_all
            namespace={'VALUE':1}
            self.assertEqual(reference.literal_module_signature(namespace),current.module_signature(namespace))
            self.assertEqual('literal-alias-change',current._LAST_MODULE_DISPATCH.get()['mode'])
        finally:
            if before is missing:current.__dict__.pop('isinstance',None)
            else:current.__dict__['isinstance']=before
            if old_reference is missing:reference.__dict__.pop('isinstance',None)
            else:reference.__dict__['isinstance']=old_reference


        cells=dict(zip(current.module_signature.__code__.co_freevars,current.module_signature.__closure__))
        checker=cells['aliases_unchanged'].cell_contents
        cells=dict(zip(checker.__code__.co_freevars,checker.__closure__))
        held=cells['expected'].cell_contents
        try:
            cells['expected'].cell_contents=tuple(list(held))
            self.assertIsNot(held,cells['expected'].cell_contents)
            with self.assertRaises(ValueError):current.module_signature({'VALUE':1})
        finally:cells['expected'].cell_contents=held
        self.assertEqual(reference.literal_module_signature({'VALUE':1}),current.module_signature({'VALUE':1}))


    def test_callback_during_literal_scan_cannot_replace_checker_code_or_seal_namespace(self):
        main=current.module_signature
        cells=dict(zip(main.__code__.co_freevars,main.__closure__))
        checker=cells['aliases_unchanged'].cell_contents
        checker_code=checker.__code__;seal=cells['seal_class'].cell_contents
        old_new_descriptor=seal.__dict__['__new__'];old_doc=seal.__doc__;missing=object()
        old_dict=current.__dict__.get('dict',missing)
        # Real function code with the exact original freevar names. It returns
        # True while still reading every closure variable, so code assignment
        # is structurally valid and is caught by independent current custody.
        names=checker_code.co_freevars
        source='def outer():\n'
        for name in names:source+='    '+name+'=None\n'
        source+='    def forged():\n        held=('+','.join(names)+',)\n        return True\n    return forged\n'
        environment={};exec(compile(source,'<modeled-checker-code-replacement>','exec'),environment)
        forged_code=environment['outer']().__code__
        self.assertEqual(checker_code.co_freevars,forged_code.co_freevars)
        for mutation in ('checker-code-and-dict','seal-member','seal-value','seal-new'):
            for path in ('next-entry','return','literal-key-return'):
                observed=[]
                def mutate():
                    if observed:return
                    observed.append(mutation)
                    if mutation=='checker-code-and-dict':
                        checker.__code__=forged_code;current.__dict__['dict']=ClassProbe
                    elif mutation=='seal-member':seal.injected_member=object()
                    elif mutation=='seal-value':seal.__doc__='modeled-intrascan-replacement'
                    else:seal.__new__=staticmethod(lambda *_args:None)
                class Callback:
                    @property
                    def __class__(self):
                        mutate()
                        from types import FunctionType
                        return FunctionType
                key=NamespaceName('A_CALLBACK')if path=='literal-key-return'else 'A_CALLBACK'
                namespace={key:Callback()}
                if path=='next-entry':namespace['Z_PROBE']=ClassProbe()
                try:
                    with self.assertRaises(ValueError):main(namespace)
                    self.assertEqual([mutation],observed)
                finally:
                    checker.__code__=checker_code;seal.__new__=old_new_descriptor;seal.__doc__=old_doc
                    if 'injected_member'in seal.__dict__:del seal.injected_member
                    if old_dict is missing:current.__dict__.pop('dict',None)
                    else:current.__dict__['dict']=old_dict
                self.assertEqual(reference.literal_module_signature({'VALUE':1}),main({'VALUE':1}))


    def test_actual_reader_code_audit_mutation_refuses_before_another_value_callback(self):
        main=current.module_signature
        cells=dict(zip(main.__code__.co_freevars,main.__closure__))
        checker=cells['aliases_unchanged'].cell_contents;old_code=checker.__code__
        names=old_code.co_freevars;source='def outer():\n'
        for name in names:source+='    '+name+'=None\n'
        source+='    def forged():\n        held=('+','.join(names)+',)\n        return True\n    return forged\n'
        environment={};exec(compile(source,'<modeled-audit-checker-replacement>','exec'),environment)
        forged=environment['outer']().__code__;self.assertEqual(names,forged.co_freevars)
        missing=object();old_dict=current.__dict__.get('dict',missing);armed={'active':True,'hits':0}
        probe=ClassProbe()
        def audit(event,args):
            if armed['active']and event=='object.__getattr__'and len(args)==2 and args[0]is reader and args[1]=='__code__':
                armed['active']=False;armed['hits']+=1
                checker.__code__=forged;current.__dict__['dict']=ClassProbe
        sys.addaudithook(audit)
        try:
            with self.assertRaises(ValueError):main({'A_READER':reader,'Z_PROBE':probe})
            self.assertEqual(1,armed['hits']);self.assertEqual(0,probe.calls)
        finally:
            armed['active']=False;checker.__code__=old_code
            if old_dict is missing:current.__dict__.pop('dict',None)
            else:current.__dict__['dict']=old_dict
        self.assertEqual(reference.literal_module_signature({'VALUE':1}),main({'VALUE':1}))

    def test_reader_code_audit_change_then_restoration_is_read_fresh_for_two_function_aliases(self):
        original=reader.__code__;changed=alternate.__code__
        armed={'active':False,'reads':0}
        def audit(event,args):
            if armed['active']and event=='object.__getattr__'and len(args)==2 and args[0]is reader and args[1]=='__code__':
                armed['reads']+=1
                if armed['reads']==1:reader.__code__=changed
                elif armed['reads']==2:reader.__code__=original
        sys.addaudithook(audit)
        namespace={'A_READER':reader,'B_READER':reader,'Z_CONSTANT':1}
        try:
            armed.update(active=True,reads=0)
            expected=reference.literal_module_signature(namespace)
            armed['active']=False;self.assertEqual(2,armed['reads']);self.assertIs(reader.__code__,original)
            self.assertIs(expected[0][1][1],changed);self.assertIs(expected[1][1][1],original)
            armed.update(active=True,reads=0)
            actual=current.module_signature(namespace)
            armed['active']=False;self.assertEqual(2,armed['reads']);self.assertEqual(expected,actual)
            self.assertIs(reader.__code__,original)
        finally:armed['active']=False;reader.__code__=original


    def test_actual_local_monitor_mask_uses_whole_literal_projection_without_fast_spans(self):
        monitor=sys.monitoring;free=[tool for tool in(0,1,2,3,4,5)if monitor.get_tool(tool)is None]
        self.assertTrue(free);tool=free[0];code=current.module_signature.__code__;hits=[]
        def observed(*args):hits.append(True)
        namespace={'FUNCTION':reader,'VALUE':1,'IGNORED':{}}
        expected=reference.literal_module_signature(namespace)
        monitor.use_tool_id(tool,'chat-classifier-actual-local-mask-counter')
        try:
            monitor.register_callback(tool,monitor.events.PY_START,observed)
            monitor.set_local_events(tool,code,monitor.events.PY_START)
            self.assertEqual(expected,current.module_signature(namespace))
            self.assertTrue(hits)
            self.assertEqual('literal-observer',current._LAST_MODULE_DISPATCH.get()['mode'])
            self.assertEqual(0,current._LAST_MODULE_DISPATCH.get()['fastEntries'])
        finally:
            monitor.set_local_events(tool,code,0)
            monitor.register_callback(tool,monitor.events.PY_START,None)
            monitor.free_tool_id(tool)
        self.assertIsNone(monitor.get_tool(tool))


    def test_actual_checker_return_monitor_mutation_from_reader_audit_refuses_before_next_callback(self):
        main=current.module_signature;cells=dict(zip(main.__code__.co_freevars,main.__closure__))
        checker=cells['aliases_unchanged'].cell_contents;original_code=checker.__code__
        names=original_code.co_freevars;source='def outer():\n'
        for name in names:source+='    '+name+'=None\n'
        source+='    def forged():\n        held=('+','.join(names)+',)\n        return True\n    return forged\n'
        environment={};exec(compile(source,'<modeled-checker-return-replacement>','exec'),environment)
        forged=environment['outer']().__code__;monitor=sys.monitoring
        free=[tool for tool in(0,1,2,3,4,5)if monitor.get_tool(tool)is None];self.assertTrue(free);tool=free[0]
        armed={'active':False,'auditReads':0,'returns':0};missing=object();old_dict=current.__dict__.get('dict',missing)
        probe=ClassProbe()
        def on_return(code,offset,value):
            if code is original_code and armed['active']:
                armed['returns']+=1;checker.__code__=forged;current.__dict__['dict']=ClassProbe
        def audit(event,args):
            if armed['active']and event=='object.__getattr__'and len(args)==2 and args[0]is reader and args[1]=='__code__':
                armed['auditReads']+=1
                monitor.set_local_events(tool,original_code,monitor.events.PY_RETURN)
                checker()
        audit.__cantrace__=True
        sys.addaudithook(audit);monitor.use_tool_id(tool,'chat-classifier-checker-return-counter')
        try:
            monitor.register_callback(tool,monitor.events.PY_RETURN,on_return);armed['active']=True
            with self.assertRaises(ValueError):main({'A_READER':reader,'Z_PROBE':probe})
            self.assertEqual(1,armed['auditReads']);self.assertEqual(1,armed['returns']);self.assertEqual(0,probe.calls)
        finally:
            armed['active']=False;monitor.set_local_events(tool,original_code,0)
            monitor.register_callback(tool,monitor.events.PY_RETURN,None);monitor.free_tool_id(tool)
            checker.__code__=original_code
            if old_dict is missing:current.__dict__.pop('dict',None)
            else:current.__dict__['dict']=old_dict
        self.assertIsNone(monitor.get_tool(tool))
        self.assertEqual(reference.literal_module_signature({'VALUE':1}),main({'VALUE':1}))

    def test_real_observer_receivers_ignore_missing_module_attribute_and_fake_mask_function(self):
        main=current.module_signature;cells=dict(zip(main.__code__.co_freevars,main.__closure__))
        checker=cells['aliases_unchanged'].cell_contents;original_code=checker.__code__
        missing=object();old_trace=sys.__dict__['gettrace'];old_dynamic=sys.__dict__.get('__getattr__',missing);dynamic_calls=[]
        def dynamic(name):
            if name=='gettrace':dynamic_calls.append(name);checker.__code__=original_code.replace();return old_trace
            if old_dynamic is not missing:return old_dynamic(name)
            raise AttributeError(name)
        namespace={'VALUE':1,'IGNORED':{}};expected=reference.literal_module_signature(namespace)
        try:
            del sys.gettrace;sys.__getattr__=dynamic
            self.assertEqual(expected,main(namespace));self.assertFalse(dynamic_calls);self.assertIs(checker.__code__,original_code)
        finally:
            sys.gettrace=old_trace;checker.__code__=original_code
            if old_dynamic is missing:del sys.__getattr__
            else:sys.__getattr__=old_dynamic
        monitor=sys.monitoring;old_get_events=monitor.get_events;fake_calls=[];observed=[]
        free=[tool for tool in(0,1,2,3,4,5)if monitor.get_tool(tool)is None];self.assertTrue(free);tool=free[0];code=main.__code__
        def fake_mask(*args):fake_calls.append(args);return 0
        def on_start(*args):observed.append(True)
        monitor.use_tool_id(tool,'chat-classifier-true-mask-receiver-counter')
        try:
            monitor.register_callback(tool,monitor.events.PY_START,on_start)
            monitor.set_local_events(tool,code,monitor.events.PY_START);monitor.get_events=fake_mask
            self.assertEqual(expected,main(namespace));self.assertTrue(observed);self.assertFalse(fake_calls)
            self.assertEqual('literal-observer',current._LAST_MODULE_DISPATCH.get()['mode'])
        finally:
            monitor.get_events=old_get_events;monitor.set_local_events(tool,code,0)
            monitor.register_callback(tool,monitor.events.PY_START,None);monitor.free_tool_id(tool)
        self.assertIsNone(monitor.get_tool(tool))


    def test_cold_same_c_type_foreign_observer_function_never_authorizes_fast_spans(self):
        original=sys.gettrace
        try:
            sys.gettrace=sys.getprofile
            bounded=current._make_module_signature()
        finally:sys.gettrace=original
        namespace={'VALUE':1,'IGNORED':{}}
        self.assertEqual(reference.literal_module_signature(namespace),bounded(namespace))
        self.assertEqual('literal-observer',current._LAST_MODULE_DISPATCH.get()['mode'])
        self.assertEqual(0,current._LAST_MODULE_DISPATCH.get()['fastEntries'])


    def test_private_seal_holds_actual_exact_tuple_data_and_fresh_builtin_span(self):
        main=current.module_signature;cells=dict(zip(main.__code__.co_freevars,main.__closure__))
        seal=cells['seal'].cell_contents
        self.assertIs(type(seal),tuple);self.assertIs(type(seal[2]),tuple);self.assertIs(type(seal[4]),tuple)
        self.assertEqual(len(seal[4]),seal[5])
        self.assertTrue(all(type(row)is tuple for row in seal[4]))
        namespace={'VALUE':1,'BOOLEAN':True,'IGNORED':{},'lowercase':None}
        self.assertEqual(reference.literal_module_signature(namespace),main(namespace))
        self.assertGreater(current._LAST_MODULE_DISPATCH.get()['fastEntries'],0)


if __name__=='__main__':unittest.main()
