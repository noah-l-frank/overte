"""Productive current primary/actor checkpoint composition on the selected SDK.

UI is independently read for each subject. Actor GetAll, API rights and complete
world/parser facts come from Actor's own canonical app. Existing child originals
retain every input birth; new passive readers never manufacture an Upload.
The combined facts still need marker/image/file publication and terminal joins.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.asset_backend_client import AssetsBackendClient
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from ios.adapters.assets_budget import operation
from ios.adapters.assets_checkpoint_membership import checkpoint_membership
from ios.adapters.assets_checkpoint_backend import AssetsCheckpointBackend
from ios.adapters.assets_checkpoint_replies import AssetsCheckpointReplies
from ios.adapters.assets_checkpoint_ui import AssetsCheckpointUI
from ios.adapters.assets_checkpoint_scene import AssetsCheckpointScene
from ios.adapters.assets_current_state import project_state,independent_peer,AssetsCheckpointNotReady
from ios.adapters.assets_input_lineage import validate as lineage_valid
from ios.adapters.assets_permissions import current as permissions
from ios.adapters.assets_selected_profile import EpisodeAssetsFiles


def owned_lineage(driver):
    result={};canonical=driver.generations
    if canonical is not None:
        canonical.guard()
        for context in canonical.contexts.values():
            retired=context.retirement
            if retired is not None:
                retired.retired();parsed=retired.origins['parsed'][0];need(parsed.state['phase']=='observed')
                value=deepcopy(parsed.state['result']);lineage_valid(value);result[value['entityId']]=value
    parts=driver.last['parts'];parsed=parts.get('parsed')
    if parsed is not None and parsed.state is not None and parsed.state['phase']=='observed':
        parsed.guard();value=deepcopy(parsed.state['result']);lineage_valid(value)
        need(value['entityId'] not in result or same(result[value['entityId']],value));result[value['entityId']]=value
    need(all(value['runId']==driver.run for value in result.values()));return result


class AssetsWholeObservation:
    def __init__(self,driver,subject):
        from ios.adapters.assets_whole_input import AssetsWholeInput
        need(type(driver) is AssetsWholeInput and subject in ('primary','actor'));driver.guard();need(driver.last is not None)
        self.driver,self.subject,self.runtime=driver,subject,driver.last['runtime'];self.action=self.runtime.assets_action;self.action.guard()
        self.episode=self.runtime.assets_episode;self.monotonic=driver.monotonic
        self.locks=driver.actions.locks if self.episode is None else self.episode.locks
        info=driver.selected.context['roles'][subject];self.selector=info['target']
        self.root=Path(info['stateRoot']) if self.episode is None else Path(self.episode.descriptor['directories'][subject]['stateRoot']['path'])
        # A fresh actual primary source channel is constructed for each subject;
        # the actor never borrows a primary observation/receipt/cache object.
        self.primary=self.runtime._assets_sources(driver.selector,self.locks['primary'])
        self.local=self.primary if subject=='primary' else self.runtime._assets_sources(self.selector,self.locks[subject])
        prefix='ios-assets-checkpoint-'+driver.run+'-a'+str(self.action.index)+'-'+subject
        self.ui=AssetsCheckpointUI(self.action,subject,self.primary,PrivateFeatureState(self.root/(prefix+'-ui.json')),
            episode=self.episode,monotonic=driver.monotonic)
        self.node=(self.ui if subject=='primary' else AssetsCheckpointUI(self.action,subject,self.local,
            PrivateFeatureState(self.root/(prefix+'-node.json')),episode=self.episode,channel='node',monotonic=driver.monotonic))
        self.replies=AssetsCheckpointReplies(self.local['replies'],PrivateFeatureState(self.root/(prefix+'-replies.json')),
            self.local['binding'],driver.run,driver.url,lock=self.locks[subject],role=subject,
            actions=driver.actions,action=self.action,episode=self.episode)
        self.backend=AssetsCheckpointBackend(self.action,subject,AssetsBackendClient(driver.backend_config,self.guard),
            PrivateFeatureState(self.root/(prefix+'-backend.json')),episode=self.episode,monotonic=driver.monotonic,sleep=self.local['observer'].sleep)
        self.primary_scene=self.scene_parts(driver.selector,'primary' if subject=='primary' else 'actor-primary',self.locks['primary'])
        self.peer_scene=(None if subject=='primary' else self.scene_parts(self.selector,'actor',self.locks['actor']))
        self.files=None
        if self.episode is not None:
            path=Path(self.episode.descriptor['directories']['primary']['stateRoot']['path'])/('ios-assets-'+driver.run+'-primary-files.json')
            self.files=EpisodeAssetsFiles(self.primary['files'],PrivateFeatureState(path),self.primary['binding'],driver.run,driver.url,
                lock=self.locks['primary'],role='primary',selection=driver.selected,episode=self.episode)
            need(self.files.state is not None and self.files.sources.pending is None)
        self.last=None;self.guard();checkpoint_membership(self)
    def scene_parts(self,selector,role,lock):
        driver=self.driver;parts=self.runtime._assets_sources(selector,lock);observer,clock=parts['observer'],parts['clock_source']
        subject='actor' if role=='actor' else 'primary'
        root=(Path(driver.actions.context['roles'][subject]['stateRoot']) if self.episode is None else
            Path(self.episode.descriptor['directories'][subject]['stateRoot']['path']))
        source=AssetsCheckpointScene(PrivateFeatureState(root/('ios-assets-checkpoint-'+driver.run+'-a'+str(self.action.index)+'-'+role+'-scene.json')),
            parts['binding'],driver.run,role,lock,parts['check'],native=observer.bound_native_observer(clock),
            state=observer.create_state(clock),domain=observer.emote_world(clock),origin=observer.assets_model_origin(clock),
            epoch_ms=driver.epoch_ms,monotonic=driver.monotonic,selection=driver.selected,action=self.action,episode=self.episode)
        parts['check']();return dict(parts,scene=source)

    def guard(self):
        self.driver.guard();self.action.guard()
        for part in (self.primary,self.local):need(part['check']() is not False)
        for lock in self.locks.values():lock.assert_held()
        return True
    def scene(self,parts,barrier):
        source=parts['scene'];need(parts['check']() is not False)
        if source.state is None:source.reserve()
        value=source.recover_capture() if source.state['pending'] is not None else source.capture(barrier)
        need(source.state['pending'] is None);return value,deepcopy(source.state['frames'][-1])
    @operation
    def current(self):
        self.guard();checkpoint_membership(self);start=self.monotonic();phase_before=self.driver.actions.phase.status()
        self.driver.actions.phase_packet(phase_before,self.action.index,self.action.ticket)
        before=self.ui.sample();before_ref=deepcopy(self.ui.state['frames'][-1])
        files=None if self.files is None else self.files.observe()
        if self.replies.state is None:self.replies.reserve(self.action.ticket)
        need(self.replies.state['phase']=='open')
        pending=[job for job in self.replies.state['jobs'] if job['phase']=='issued']
        if pending:
            need(len(pending)==1);slot=pending[0]['slot'];inventory=self.replies.recover(slot)
        else:
            slot='checkpoint-'+str(len(self.replies.state['jobs'])+1);inventory=self.replies.read(slot)
        server=self.backend.current();backend_index=len(self.backend.state['samples'])
        primary,primary_ref=self.scene(self.primary_scene,start)
        peer,peer_ref=(None,None) if self.peer_scene is None else self.scene(self.peer_scene,start)
        node=self.node.sample() if self.subject=='actor' else None
        node_ref=None if node is None else deepcopy(self.node.state['frames'][-1])
        after=self.ui.sample();after_ref=deepcopy(self.ui.state['frames'][-1])
        end=self.monotonic();need(start<=end<start+1.5)
        phase_after=self.driver.actions.phase.status();self.driver.actions.phase_packet(phase_after,self.action.index,self.action.ticket)
        need(phase_before['activations']==phase_after['activations'])
        self.action.guard();known=owned_lineage(self.driver)
        value,models=project_state(self.driver.run,after,inventory,server,primary if peer is None else peer,known,files=files)
        previous,_old_models=project_state(self.driver.run,before,inventory,server,primary if peer is None else peer,known,files=files)
        if not same(previous,value):raise AssetsCheckpointNotReady('Current Assets UI changed during its actual checkpoint cohort')
        if peer is not None:
            remote=independent_peer(primary,peer,known);need(set(remote)==set(models))
            rights=permissions(node,pid=int(self.local['binding']['processIdentity']),domain_id=inventory['binding']['domainId'])
            need(rights['binding']['clientNodeId']==peer['originals']['createAfter']['source']['localSessionId'])
            if rights['permissions']['canWriteAssets']!=value['canWrite']:
                raise AssetsCheckpointNotReady('Independent Actor has not observed the actual current write permission')
        for packet in (before,after):need(abs(packet['sampleEpochMs']-inventory['captured']['epochMs'])<=1500)
        self.last=dict(assetsCurrentFactsVersion=1,runId=self.driver.run,subject=self.subject,index=self.action.index,ticket=self.action.ticket,
            state=deepcopy(value),ownedModels=models,hostBefore=start,hostAfter=end,phaseBefore=phase_before,phaseAfter=phase_after,
            ui=dict(path=str(self.ui.store.path),before=before_ref,after=after_ref),
            node=None if node_ref is None else dict(path=str(self.node.store.path),source=node_ref),
            replies=dict(path=str(self.replies.store.path),slot=slot),backend=dict(path=str(self.backend.store.path),sample=backend_index),
            primaryScene=dict(path=str(self.primary_scene['scene'].store.path),source=primary_ref),
            peerScene=None if peer_ref is None else dict(path=str(self.peer_scene['scene'].store.path),source=peer_ref),
            files=None if files is None else dict(path=str(self.files.store.path),requestId=files['requestId'],token=self.files.state['token']),
            publicObservationReady=False,currentNativeFactsProduced=True,wholeEndEligible=False)
        self.guard();checkpoint_membership(self);return deepcopy(self.last)
    def close_reads(self):
        self.guard();need(self.last is not None and self.replies.state is not None
            and self.ui.state['pending'] is None and self.node.state['pending'] is None
            and self.replies.sources.pending is None
            and all(row['parts'] is not None and row['parts']['complete'] for row in self.backend.state['samples']))
        for part in (self.primary_scene,self.peer_scene):
            if part is not None:need(part['scene'].state['pending'] is None and part['scene'].raws.pending is None)
        self.replies.close();self.guard();checkpoint_membership(self);return self.replies.state['phase']=='closed'
