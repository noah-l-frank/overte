"""Explicit Callback copy/OS archive interfaces; no legacy object upcast."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import need,integer
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.script_feature.history import same
from feature_journeys.contract import identifier
from ios.adapters.installed_code import source as process_source
from ios.adapters.process_retirement import IOSProcessRetirement,filename
from ios.adapters.emote_post9_copied_archive import IOSEmotePost9CopiedArchive
from ios.adapters.emote_post9_copied_ownership import IOSEmotePost9CopiedOwnership


def checked(archive):
    need(type(archive) is IOSEmotePost9CopiedArchive and archive.state is not None and archive.state['phase']=='validated'
        and same(archive.store.read(),archive.previous) and same(archive.envelope(archive.state),archive.previous))
    archive.lock.assert_held();archive.actor_lock.assert_held();archive.decode(archive.previous);return archive


def archive_paths(archive):return [PrivateFeatureState(path) for path in checked(archive).state['paths']]
def archive_copies(archive):return checked(archive).retained()[0]
def archive_checkpoint(archive):return checked(archive).retained()[1]
def copy_outputs(archive):return checked(archive).owned_paths()


def retained_context(ownership,archive):
    need(type(ownership) is IOSEmotePost9CopiedOwnership)
    copies,checkpoint=checked(archive).retained()
    expected=deepcopy(ownership.roles.copies);expected[str(ownership.path)]=deepcopy(ownership.terminal)
    need(same(copies,expected));archive.validate_context(copies)
    end_path=archive.store.path.with_name('ios-emote-primary-'+archive.run+'-post9-end.json')
    if PrivateFeatureState(end_path).read() is not None:
        from ios.adapters.emote_post9_retirement_view import Post9RetirementView
        view=Post9RetirementView(archive,checkpoint['seal'])
        # A new real historical reader, never injected state in a live owner.
        reader=IOSEmotePost9CopiedOwnership(copies,run=archive.run,lock=archive.lock,actor_lock=archive.actor_lock,retirement=view)
    else:reader=ownership
    value=reader.read(checkpoint)
    return value['proof'],value['completionFloorEpochMs'],value['rolePhasePrefixes']
def retained_floor(ownership,archive):
    proof,floor,_=retained_context(ownership,archive);return proof,floor
def retained_proof(ownership,archive):return retained_context(ownership,archive)[0]


class OSOriginalArchive:
    """Real readonly constructor for the existing literal OS record reader."""
    def __init__(self,path,*,binding,source,bundle,run,role,stage):
        self.profile,self.store='emote',PrivateFeatureState(path)
        self.binding,self.source=deepcopy(context(binding)),deepcopy(process_source(source))
        self.bundle,self.run,self.role,self.stage=bundle,identifier(run),role,stage
        need(role in ('primary','actor') and type(stage) is int and stage in (0,1)
            and self.store.path.name==filename('emote',role,stage))
        self.pid=int(binding['processIdentity']);need(str(self.pid)==binding['processIdentity'] and integer(self.pid,1,2147483647))
        self._archives=None
        value=self.store.read();need(value is not None)
        self.state=IOSProcessRetirement.archive(value,path=self.store.path,binding=binding,source=source,bundle=bundle,run=run,role=role,stage=stage,profile='emote')
    def record_store(self,ordinal):return IOSProcessRetirement.record_store(self,ordinal)
    def load(self,reference):return IOSProcessRetirement.load(self,reference)
