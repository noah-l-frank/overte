"""Stdlib-only exact component evidence; no target imports or execution."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent;PRIVATE=ROOT.parent;REPO=PRIVATE.parent

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def ref(name,file='freeze.json'):
 path=PRIVATE/name/file;return dict(path=str(path),sha256=sha(path))
def group(key,name,scope):
 path=PRIVATE/name/'report.json';r=json.loads(path.read_text())
 return dict(id=key,scope=scope,report=ref(name,'report.json'),executionFreeze=ref(name),status=r['status'],testsRun=r['testsRun'],elapsedSeconds=r['elapsedSeconds'],actualSelections=r['selected'],publicDependencies=r.get('actualPublicDependencies',r.get('publicDependencies')),allPublicDependenciesUnchanged=r['allPublicDependenciesUnchanged'],auditRefusals=r['auditRefusals'],newThreads=r.get('remainingNewThreads',[]),originalCleanupEstablished=r.get('originalRegisteredCleanupEstablished',r.get('cleanupOriginalEstablished')),nativeQualified=False,wholeQualified=False)

PASS_ROWS=[
('early4','audio-whole-early4-agent-run-20261103','Closed grammar and before-input duty/settings/current-epoch refusal boundaries'),
('public-replay1','audio-whole-replay1-agent-run-20261103','Independent historical constructors and changed-original inode refusal'),
('inventory-round3','audio-inventory3-round1-agent-run-20261103','Actual complete census rounds and mutation/callback invalidation'),
('inventory-scan3','audio-inventory3-scan2-agent-run-20261103','Equivalent full names/signatures scan with independent lstat'),
('poll-model1','audio-negative-poll-model1-agent-run-20261103','Unchanged raw model PCM/rows/6s at100ms versus500ms host status; not hardware'),
('reconcile3','audio-negative-reconcile3-agent-run-20261103','Same original negative job; released-without-snapshot refusal; immutable media handoff'),
('acquisition3','audio-negative-acquisition3-reconcile4-agent-run-20261103','Single actual owner/fresh nonces/negative evidence; lost observe; foreign SDK duty refusal'),
('actor-own4','audio-whole-actor-typed-refusal5-own4-agent-preparation-20261103','Strict initial envelope/bindings; pending; missing real parent refusal; independent fresh initial Source'),
('snapshot-own3','audio-passive-snapshot-return1-own3-agent-preparation-20261103','One complete immutable snapshot validation/return; exact bytes/native/epoch; fresh independent call; mutations refuse'),
('raw-afc-own2','audio-raw-afc-custody6-own2-agent-run-20261103','Raw MODEL actual own socket/EOF/reader/file close; no SDK/Node/Parent admission'),
]
qualified=[group(*row)for row in PASS_ROWS];assert all(row['status']=='PASS'for row in qualified)
LAYER_ROWS=[
('source5','audio-once-actor10-runtime-primary-journey-source5-private-20261103','Foundational imported dependencies; native and positive once/Primary behavior remain separate/unqualified'),
('shared0ef','lifecycle-whole-executable-composition-source-proposal-20261103','Explicit original Python End/Readmission dependencies; positive Audio join unqualified'),
('whole-source6','audio-whole11-connected-source6-private-20261103','Connected private Whole11; full normal14/cleanup/terminal HELD'),
('scroll-fixture','audio-whole-source6-scroll-fixture-fix1-private-20261103','Fixture only'),
('public-replay','audio-whole-source6-public-replay1-private-20261103','Fresh historical per-round constructor graph'),
('inventory-round','audio-passive-inventory-round1-private-20261103','Synchronous complete inventory round guards'),
('inventory-scan','audio-passive-inventory-scan2-private-20261103','Complete exact names/signature scan'),
('single-owner','audio-whole-negative-single-acquisition2-private-20261103','One actual bounded negative-capture owner'),
('owner-address-test','audio-negative-acquisition-owner-address-fix1-private-20261103','Fixture only'),
('host-poll','audio-negative-host-poll500-source3-private-20261103','Host status500ms only; native sampler/rows unchanged'),
('original-job','audio-negative-original-job-reconcile4-private-20261103','Exact durable negative-job reconciliation'),
('actor-strict','audio-whole-original-replacement-actor-transitional4-private-20261103','Exact initial parser/identity phase gate and typed replacement admission'),
('typed-refusal-test','audio-whole-actor-typed-refusal-fixture5-private-20261103','Exact existing NativeUIError expectation; no productive change'),
('snapshot-return','audio-passive-original-snapshot-return1-private-20261103','Immutable snapshot data returned within first complete proof call'),
]
source_chain=[dict(id=key,freeze=ref(name),scope=scope)for key,name,scope in LAYER_ROWS]
failures=[]
for name in ('audio-whole-positive2-reconcile4-agent-run-20261103','audio-whole-positive2-actor-transitional4-agent-run-20261103','audio-whole-positive2-snapshot-return1-agent-run-20261103'):
 value=json.loads((PRIVATE/name/'selection-observation.json').read_text())
 failures.append(dict(kind='NORMAL2_FIXED180_TIMEOUT_NOT_PASS',report=ref(name,'report.json'),executionFreeze=ref(name),case1Started=True,case2Started=False,completedOriginalActions=value['completedOriginalActions'],pending=value['pending'],artifacts=value['artifacts'],wholeQualified=False))
for name in ('audio-parent-idle4-afc-verifier-preparation7-20261103','audio-parent-idle4-owned-empty-stdin-preparation8-20261103'):
 r=json.loads((PRIVATE/name/'report.json').read_text());s=json.loads((PRIVATE/name/'supervisor-terminal.json').read_text())
 failures.append(dict(kind='PARENT_ERROR_NOT_PASS',report=ref(name,'report.json'),preexecutionFreeze=ref(name),executionFreeze=ref(name,'execution-freeze.json'),supervisor=ref(name,'supervisor-terminal.json'),status=r['status'],NodeGatewayBirths=r['nodeGateways'],modelChildBirths=r['modeledChildBirths'],ownProcessesRemaining=s['remainingOwnedProcesses'],orphanCleanupRequired=s['hadPostRunnerOrphans'],originalCensusesEqual=s['originalCensus']['twoIndependentFullByteCensusesEqual'],qualification='No completed Audio End/readmission/Whole. Real host drains are separate facts.',wholeQualified=False))

mapping=json.loads((PRIVATE/'audio-whole-positive2-snapshot-return1-agent-run-20261103/preimport-map.json').read_text());loaded={}
for _key,name,_scope in PASS_ROWS:
 path=PRIVATE/name/'loaded-project-modules.json'
 if path.exists():loaded.update(json.loads(path.read_text()))
surface=[]
for module,old in loaded.items():
 row=mapping['modules'].get(module,old);path=Path(row['path']);needle='/candidate/tests/device/'
 if needle not in str(path)or '/self_tests/'in str(path)or path.suffix!='.py':continue
 relative='tests/device/'+str(path).split(needle,1)[1]
 if '/adapters/'not in relative and not relative.startswith('tests/device/feature_journeys/'):continue
 public=REPO/relative
 surface.append(dict(module=module,publicRelativePath=relative,candidatePath=str(path),candidateSha256=row['sha256'],currentPublicSha256=sha(public)if public.is_file()else None,basis='Imported dependency surface of exact selected PASS scopes, not whole-module qualification',publication='ROOT_REVIEW_ONLY_FLAGS_CLOSED'))
surface.sort(key=lambda row:row['publicRelativePath'])
direct=[
('tests/device/ios/adapters/audio_passive_journal.py','Independent raw journal reads and complete guard-bounded rounds'),
('tests/device/ios/adapters/audio_passive_owner.py','Complete namespace/signature guard and immutable snapshot return; native/version2 duty separate'),
('tests/device/ios/adapters/audio_whole_silence.py','Single actual owner and same durable job;500ms host status only'),
('tests/device/ios/adapters/audio_whole_actor_replacement.py','Exact known initial envelope and typed stage gate'),
('tests/device/ios/adapters/audio_whole_feature.py','Connected consumer dependency; entire Whole behavior HELD'),
('tests/device/ios/adapters/audio_whole_terminal.py','Typed missing-parent refusal; positive terminal/End HELD'),
]
holds=[
'No completion/sourcecount/capability/feature-flag change',
'Whole11 configuration/coordinator/Actor/evidence/restoration/abort/terminal remain private until complete normal14/cleanup/seal/final Ends qualify',
'Shared original End/readmission and actual PCM/control retirement are not proven by raw model drains',
'Native Source5 receiver-thread design uncompiled; no device/native/ADC/acoustic qualification',
'Foundational once/cue/Primary WAL dependencies cannot inherit positive qualification from negative-capture host cases',
'Actual PASS applies to exact recorded historical source map; no newer map inherits it automatically',
'All original failure packets remain retained; timeout/benchmark/error never promotes to PASS',
'After Root HEAD4a8287 new execution maps require fresh complete pins; no public mutation in this manifest',
]
manifest=dict(status='PRIVATE_MINIMAL_INTEGRATION_MANIFEST_HOST_COMPONENT_EVIDENCE_ONLY',rootReportedPublicHead='4a8287f147ad33555c34dbda420b0f09162fb368',sourceChain=source_chain,qualifiedHostScopes=qualified,unqualifiedFailures=failures,minimalDirectIntegrationPoints=[dict(path=path,scope=scope)for path,scope in direct],effectiveImportedCandidateSurface=surface,effectiveSourceMap=ref('audio-whole-positive2-snapshot-return1-agent-run-20261103','preimport-map.json'),explicitHolds=holds,nativeQualified=False,wholeQualified=False,publicMutation=False,targetsExecutedByThisManifest=0)
(ROOT/'manifest.json').write_text(json.dumps(manifest,sort_keys=True,indent=2)+'\n')
(ROOT/'README.txt').write_text('Exact successful host scopes and their necessary frozen source chain are recorded here. Imported modules are not classified as fully qualified.\n\nMinimal direct points: passive journal/owner, negative acquisition, strict Actor gate and snapshot return. Their connected Whole/configuration/terminal dependencies remain HELD. Root must preserve every completion/capability/native/Whole/End flag.\n\nReconcile3, Acquisition3, ActorOwn4 and SnapshotOwn3 have actual PASS reports. Normal2 remains fixed180 TIMEOUT and Parent remains ERROR. Raw AFC Own2 qualifies only its explicit model boundary. No public edits or target execution occur in this packet.\n')
(ROOT/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_FROZEN_EVIDENCE_ONLY',files={path.name:dict(sha256=sha(path),bytes=path.stat().st_size)for path in sorted(ROOT.iterdir())if path.is_file()and path.name!='freeze.json'},nativeQualified=False,wholeQualified=False,publicMutation=False),sort_keys=True,indent=2)+'\n')
print(json.dumps(dict(freeze=sha(ROOT/'freeze.json'),manifest=sha(ROOT/'manifest.json'),hostPASSGroups=len(qualified),effectiveImportedDependencies=len(surface),unqualifiedFailures=len(failures))))
