import hashlib,json,sys,unittest
from pathlib import Path
repo=Path.cwd()
selected=set(json.loads((repo/'.ios-host-tmp/world-web-cpu19-joined-round-source-before-20261027.json').read_text()))
selected.add('tests/device/ios/self_tests/test_ios_world_web_parts_round.py')
selected.add('.ios-host-tmp/run-world-web-parts-round-canonical-unicode-20261027.py')
paths=selected|{str(p.relative_to(repo)) for p in (repo/'tests/device').rglob('*.py')}
def measure(names):
 return {name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in sorted(names)}
before=measure(paths)
(repo/'.ios-host-tmp/world-web-parts-round-canonical-unicode-source-before-20261027.json').write_text(json.dumps(before,indent=2)+'\n')
suite=unittest.defaultTestLoader.loadTestsFromName('ios.self_tests.test_ios_world_web_parts_round.WorldWebPartsRoundTests.test_actual_normal_unicode_factory_reconstruction_and_changed_carrier_exit')
result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
used=set(selected)
for mod in tuple(sys.modules.values()):
 path=getattr(mod,'__file__',None)
 if path:
  try:
   p=Path(path).resolve();name=str(p.relative_to(repo))
  except (ValueError,OSError):continue
  if p.suffix=='.py':used.add(name)
after=measure(used)
changed=[name for name in sorted(used) if before.get(name)!=after[name]]
report=dict(testPassed=result.wasSuccessful(),selectedSources=len(selected),actualUsedAndSelectedSources=len(used),changed=changed)
(repo/'.ios-host-tmp/world-web-parts-round-canonical-unicode-source-after-20261027.json').write_text(json.dumps(dict(sources=after,report=report),indent=2)+'\n')
print(json.dumps(report),flush=True)
sys.exit(0 if result.wasSuccessful() and not changed else 1)
