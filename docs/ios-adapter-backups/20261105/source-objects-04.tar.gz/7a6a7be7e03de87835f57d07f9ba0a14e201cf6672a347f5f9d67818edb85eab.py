"""Explicit semantic/Kernel history plus actual current C10d utility facts."""
from pathlib import Path
import json
from kernel_admission import require as require_kernel
from source_execution_readiness import qualification,SUBJECT_SHA as C10D,HELPER_SHA as HELPER,ROOT_SHA as QUALIFIED
SOURCE2='b28f623ffbad2a1a331dd29fc3abe6dc5b1e8ec61e803a161cfa728f68a702da'
SOURCE3='164487ed9c7f8eb64811957f06ead32b41becdfd0b70abb00d79a3064e681cae'
def read_ref(row,pin):
    assert type(row)is dict and set(row)=={'path','sha256'}
    path=Path(row['path']);assert path.is_absolute()and path.resolve(strict=True)==path
    assert pin(path)['sha256']==row['sha256'];return json.loads(path.read_text())
def packet(row,pin):
    value=read_ref(row,pin);root=Path(row['path']).parent;assert type(value['files'])is dict
    for name,entry in value['files'].items():
        assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
        assert pin(root/name)['sha256']==entry['sha256']
    return value

def require(value,pin):
    require_kernel(value['kernelOwn5Proof'],pin)
    # Root explicitly supplies a NEW semantic review of the two unrun product
    # packets. Neither this loader utility PASS nor old Source1 model assembly
    # constitutes that semantic admission.
    assert value['status']=='ROOT_REVIEWED_EMOTE_SOURCE3_ONE_POSITIVE_METADATA_ADMISSION'
    assert value['source2Freeze']==SOURCE2 and value['source3Freeze']==SOURCE3
    review=value['sourceSemanticReviewFreeze'];assert review['sha256']=='7ec477b361087c0abcb6a09c9167cfd83f1f8d29b810745cc912bcd276be1c6a'
    body=packet(review,pin);path=Path(review['path']).parent/'READBACK.json'
    result=read_ref(dict(path=str(path),sha256=body['files']['READBACK.json']['sha256']),pin)
    assert result['status']=='INDEPENDENT_FULL_SEMANTIC_SOURCE_REVIEW_NO_NEW_CONCRETE_BLOCKER'
    assert result['actualSource2And3CounterBodiesRead']==16 and result['actualNewLiveDunderNew']is False
    assert result['sources']['emote-callback-copied-state-ownership-source2-private-20261104']['freeze']==SOURCE2
    assert result['sources']['emote-callback-typed-fence-process-sdk-end-source3-private-20261104']['freeze']==SOURCE3
    current,physical=qualification(pin)
    assert value['currentSourceExecutionRootFreeze']==current['rootFreeze']
    assert current['subjectSourceFreeze']==C10D and current['helperSha256']==HELPER
    assert current['currentHelperAlgorithmQualified']is True and current['consumerCompositionQualified']is False
    return current,physical
