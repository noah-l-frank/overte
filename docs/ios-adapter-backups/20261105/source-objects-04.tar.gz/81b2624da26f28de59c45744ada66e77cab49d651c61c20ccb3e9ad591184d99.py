"""CPython observer-only event classification and original exception custody."""
import os,sys,traceback
from pathlib import Path
from types import TracebackType

# No active flag or previous verification result. Every handled event checks
# identities afresh; introspective events are outside this IO policy frontier.
HANDLED=frozenset(('import','open','fcntl.flock','tempfile.mkdtemp','tempfile.mkstemp',
    'subprocess.Popen','os.system','os.exec','os.posix_spawn','os.spawn','os.fork','os.forkpty','pty.spawn',
    'os.chdir','os.fchdir','os.remove','os.rmdir','os.chmod','os.chown','os.truncate','os.utime','os.mkdir','os.rename','os.link','os.symlink'))

def sensitive_event(event):return event in HANDLED or event.startswith('socket.')

class ActualExceptionOriginal:
    def __init__(self,path,descriptor):
        self.path=Path(path);self.descriptor=descriptor
        assert self.path.is_absolute()and self.path.resolve(strict=True)==self.path
        self.fstat,self.lstat,self.write,self.fsync=os.fstat,os.lstat,os.write,os.fsync
        self.format_exception=traceback.format_exception;self.format_code=self.format_exception.__code__
        self.original_hook=sys.excepthook
        self.identity=self.signature(self.fstat(descriptor));assert self.identity==self.signature(self.lstat(self.path))
        self.called=False
    @staticmethod
    def signature(info):return tuple(getattr(info,n)for n in('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink'))
    def observe(self,kind,error,tb):
        # Called only from an actual caught exception or interpreter's original
        # uncaught-exception path. No speculative verdict/facts are produced.
        assert isinstance(error,BaseException)and kind is type(error)and type(tb)is TracebackType and error.__traceback__ is tb
        assert not self.called and self.path.resolve(strict=True)==self.path
        assert self.signature(self.fstat(self.descriptor))==self.signature(self.lstat(self.path))==self.identity
        assert self.format_exception.__code__ is self.format_code
        raw=''.join(self.format_exception(kind,error,tb)).encode('utf-8','backslashreplace')
        self.called=True
        offset=0
        while offset<len(raw):
            count=self.write(self.descriptor,raw[offset:]);assert count>0;offset+=count
        self.fsync(self.descriptor)
    def __call__(self,kind,error,tb):
        try:self.observe(kind,error,tb)
        finally:self.original_hook(kind,error,tb)
