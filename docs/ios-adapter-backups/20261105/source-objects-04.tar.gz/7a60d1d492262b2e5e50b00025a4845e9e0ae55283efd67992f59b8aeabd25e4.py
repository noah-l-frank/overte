"""Typed actual version sets plus complete unsupported-location diagnostics."""
import ast,difflib,hashlib,json
from pathlib import Path
R=Path.cwd();H=R/'.ios-host-tmp/emote-callback-live-prefix-typed-set-diagnostics-source-fix-20261102';B=R/'.ios-host-tmp/emote-callback-live-prefix-typed-policy-mapping-complete-source-fix-20261102'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(s)
rows=[];diff=[]
for row in json.loads((B/'plan.json').read_text())['sourceRows']:
 rel=row['path'];p=R/rel;assert sha(p)==row['candidateSHA256'];before=p.read_text();after=before
 if rel.endswith('emote_callback_live_records.py'):
  after=after.replace('class _Unsupported(Exception):pass',"""class _Unsupported(Exception):
    def __init__(self,kind=None,reason='unsupported-type'):
        self.kind=None if kind is None else (kind.__module__,kind.__qualname__)
        self.reason=reason""")
  after=after.replace('if depth>32:raise _Unsupported','if depth>32:raise _Unsupported(type(value),\'depth\')')
  old="""    if kind in (set,frozenset):
        if not all(type(item) is str for item in value):raise _Unsupported
        return (kind.__name__,tuple(sorted(value)))""";assert after.count(old)==1
  new="""    if kind in (set,frozenset):
        unsupported=next((type(item) for item in value if type(item) not in (str,int)),None)
        if unsupported is not None:raise _Unsupported(unsupported,'set-member')
        return (kind.__name__,tuple(sorted(token(item) for item in value)))"""
  after=after.replace(old,new)
  after=after.replace("if not all(type(key) in (str,int) for key in value):raise _Unsupported","unsupported=next((type(key) for key in value if type(key) not in (str,int)),None)\n        if unsupported is not None:raise _Unsupported(unsupported,'mapping-key')")
  after=after.replace('    raise _Unsupported\n','    raise _Unsupported(kind)\n')
  needle='    def literal(self):\n';assert after.count(needle)==1
  method="""    def unsupported_members(self):
        # Diagnostic only: use the SAME closed tokenizer without granting any
        # policy/cache admission. Report module/member/type/reason, never values,
        # function locals, owner contents or a substituted decoder result.
        output=[]
        for module in self.modules:
            if sys.modules.get(module.__name__) is not module:
                output.append(dict(module=module.__name__,member=None,type=None,reason='namespace-rebound'));continue
            for name,value in sorted(vars(module).items()):
                if name.startswith('__'):continue
                try:_token(value,[],set())
                except _Unsupported as error:output.append(dict(module=module.__name__,member=name,type=error.kind,reason=error.reason))
                except (AttributeError,TypeError,ValueError,RecursionError) as error:
                    output.append(dict(module=module.__name__,member=name,type=(type(error).__module__,type(error).__qualname__),reason='token-error'))
        for container,name in EXTERNAL_READERS:
            try:_token(getattr(container,name),[],set())
            except _Unsupported as error:output.append(dict(module=container.__name__,member=name,type=error.kind,reason=error.reason))
            except (AttributeError,TypeError,ValueError,RecursionError) as error:
                output.append(dict(module=container.__name__,member=name,type=(type(error).__module__,type(error).__qualname__),reason='token-error'))
        return output

"""
  after=after.replace(needle,method+needle)
 if rel.endswith('test_ios_emote_callback_live_history_cache.py'):
  old='self.assertTrue(history.literal(),repr(history.unsupported))';assert after.count(old)==1
  after=after.replace(old,'self.assertTrue(history.literal(),repr(history.unsupported_members()))')
  after+='''
    def test_changed_actual_integer_version_set_cannot_reuse_warm_history(self):
        from ios.adapters import web_closures
        self.assertEqual({1,2,3,4,5},web_closures.READS);self.read()
        with patch.object(web_closures,'READS',web_closures.READS|{99}):
            self.assertFalse(self.history.literal());self.read()
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())

    def test_unsupported_actual_version_set_object_member_uses_literal_decoder(self):
        from ios.adapters import web_closures
        self.read()
        with patch.object(web_closures,'READS',web_closures.READS|{object()}):
            self.assertFalse(self.history.literal());self.read()
            diagnostics=self.history.unsupported_members()
            self.assertIn(dict(module='ios.adapters.web_closures',member='READS',type=('builtins','object'),reason='set-member'),diagnostics)
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())
'''
 ast.parse(after,filename=rel);write(H/'base'/rel,before);write(H/'candidate'/rel,after)
 rows.append(dict(path=rel,baseSHA256=sha(p),candidateSHA256=hashlib.sha256(after.encode()).hexdigest()));diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
write(H/'typed-set-diagnostics-only.diff',''.join(diff))
# Literal/constructed sets are now included. This never calls target code.
tree=ast.parse((H/'candidate/tests/device/ios/adapters/emote_callback_live_records.py').read_bytes());mods=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PARSER_MODULES' for t in n.targets)))
sets=[];unknown=[];pins={}
def symbolic(node):
 if isinstance(node,ast.Constant):return node.value
 if isinstance(node,(ast.Tuple,ast.List,ast.Set)):
  values=[symbolic(v) for v in node.elts]
  return tuple(values) if isinstance(node,ast.Tuple) else values if isinstance(node,ast.List) else set(values)
 if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ('range','set','frozenset','list','tuple'):
  args=[symbolic(v) for v in node.args]
  if node.func.id=='range':
   assert len(args)<=3 and all(type(v) is int for v in args);value=range(*args);assert len(value)<=4096;return value
  return {'set':set,'frozenset':frozenset,'list':list,'tuple':tuple}[node.func.id](*args)
 if isinstance(node,ast.BinOp) and isinstance(node.op,ast.BitOr):return symbolic(node.left)|symbolic(node.right)
 raise ValueError('Dynamic/nonliteral AST expression')
def scan(nodes,module,path):
 for n in nodes:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):continue
  if isinstance(n,ast.ClassDef):scan(n.body,module,path);continue
  if isinstance(n,(ast.Assign,ast.AnnAssign)) and n.value is not None:
   targets=[ast.unparse(v) for v in n.targets] if isinstance(n,ast.Assign) else [ast.unparse(n.target)]
   for v in ast.walk(n.value):
    if not (isinstance(v,ast.Set) or isinstance(v,ast.Call) and isinstance(v.func,ast.Name) and v.func.id in ('set','frozenset')):continue
    row=dict(module=module,path=str(path.relative_to(R)),line=v.lineno,targets=targets,expression=ast.unparse(v))
    try:value=symbolic(v)
    except (ValueError,TypeError,AssertionError):unknown.append(row);continue
    kinds=sorted({type(i).__name__ for i in value});sets.append(dict(row,memberTypes=kinds,supported=all(type(i) in (str,int) for i in value)))
  if isinstance(n,(ast.If,ast.Try)):
   for field in ('body','orelse','finalbody'):scan(getattr(n,field,[]),module,path)
for m in mods:
 p=R/'tests/device'/(m.replace('.','/')+'.py');pins[m]=dict(path=str(p.relative_to(R)),sha256=sha(p));scan(ast.parse(p.read_bytes()).body,m,p)
write(H/'static-set-constructor-census.json',json.dumps(dict(method='AST only, namespace/class set literals and bounded literal range/set/frozenset/tuple/list constructors; unknown expressions retained explicitly',sourcePins=pins,sets=sets,unknownSetExpressions=unknown,limitations='Imported alias values and dynamic constructor results require actual smoke diagnostics. No claim that this AST census proves runtime policy admission.'),indent=2)+'\n')
plan=dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceRows=rows,actualUnsupported=['ios.adapters.web_closures','READS'],actualCause='Exact literal integer version set {1,2,3,4,5}; prior AST census omitted set literals',actualFailure='.ios-host-tmp/emote-callback-live-prefix-typed-mapping-mechanisms17-root-preparation-20261102/smoke1/root-run-first/report.json',typedSetPolicy='Exact str/int items tokenized and sorted by typed key; bool/float/object/tuple members refuse',diagnostics='Same closed tokenizer collects ALL unsupported module/member+nested type/reason in smoke while policy remains None/fallback; no values/locals',mechanismCases=19,prospectiveSmoke=dict(firstSeconds=15,killAfterSeconds=5,realRoots=0),prospectiveMechanisms=dict(firstSeconds=30,killAfterSeconds=5,realRoots=19),staticKnownSets=len(sets),staticUnknownSetExpressions=len(unknown),old747ReplayForbidden=True,freshGraph='HARDHOLD pending actual changed smoke and19 mechanisms PASS',sourcePublished=False,testsRun=False,targetImported=False,SDKImported=False)
write(H/'plan.json',json.dumps(plan,indent=2)+'\n');write(H/'freeze.json',json.dumps(dict(status=plan['status'],files={str(p.relative_to(H)):sha(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(packet=str(H),freeze=sha(H/'freeze.json'),sourceRows=rows,staticKnownSets=len(sets),staticUnknownSetExpressions=len(unknown))))
