"""Actual normal Assets page re-entry after original Model-removal Home.

This is a distinct generation/native-frame owner. It never retimes/relabels
an old upload, page, picker, file manifest or original. New Tree/Usage views
and global generation/episode closure remain separate responsibilities.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import re
import time
from types import SimpleNamespace
from adapters.native_feature_observation import NativeFeatureObservation,exact,integer,need,number
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same,pack,unpack
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.assets_action_phase import AssetsActionScope,AssetsActionPhases
from ios.adapters.assets_controls import project,identity
from ios.adapters.assets_end_graph import AssetsFinalArchive
from ios.adapters.assets_model_removal import OwnedAssetsModelRemoval
from ios.adapters.assets_model_sources import AssetsModelSources
from ios.adapters.assets_page_birth import AssetsPageBirth,SLOTS
from ios.adapters.assets_picker import root
from ios.adapters.assets_upload import OwnedAssetsUpload
from ios.adapters.normal_input import NativeInput

VERSION=1
GENERATIONS={9:2,16:3,22:4}


class AssetsPageReentry(AssetsPageBirth):
    def __init__(self,selected,store,lock,action,native,clock,*,removal,monotonic=time.monotonic):
        need(type(selected) is AssetsFinalArchive and type(action) is AssetsActionScope and action.owner.selected is selected
            and action.index in GENERATIONS and isinstance(store,PrivateFeatureState) and isinstance(lock,ScriptSourceLock)
            and isinstance(native,NativeInput) and isinstance(clock,NativeFeatureObservation) and clock.ios and not clock.native_clock_bound
            and type(removal) is OwnedAssetsModelRemoval and callable(monotonic))
        self.selected,self.store,self.lock,self.action,self.actions=selected,store,lock,action,action.owner
        self.binding=deepcopy(selected.context['roles']['primary']['binding']);self.run,self.role,self.ticket=selected.run,'primary',action.ticket
        self.action_index,self.generation,self.removal=action.index,GENERATIONS[action.index],removal
        self.native,self.clock,self.monotonic=native,clock,monotonic;self.historical=False;self._native_capture=native.capture;self._cached=[]
        self.previous=store.read();self.state=None;self.prior_link=self.prior_context()
        self.originals=OriginalFrameStore(store.path.parent,self.binding,self.run,'primary',self.guard,self.frame_intent,
            namespace='assets-page-reentry-g'+str(self.generation),schema_prefix='iosAssetsPageReentrySource',monotonic=monotonic)
        self.boundary()
        if self.previous is not None:self.state=self.decode(self.previous)
    @classmethod
    def from_archive(cls,selected,store,lock,actions,*,action_index,removal,monotonic=time.monotonic):
        need(type(selected) is AssetsFinalArchive and type(actions) is AssetsActionPhases and actions.selected is selected
            and type(action_index) is int and action_index in GENERATIONS and type(removal) is OwnedAssetsModelRemoval
            and isinstance(store,PrivateFeatureState) and isinstance(lock,ScriptSourceLock))
        completed=actions.read(action_index);need(completed['input']==dict(verb='remove-owned-model',inputs={}))
        owner=object.__new__(cls);owner.selected,owner.store,owner.lock,owner.actions=selected,store,lock,actions
        owner.action=None;owner.action_index,owner.generation,owner.removal=action_index,GENERATIONS[action_index],removal
        owner.ticket=completed['ticket'];owner.binding=deepcopy(selected.context['roles']['primary']['binding'])
        owner.run,owner.role,owner.monotonic,owner.historical=selected.run,'primary',monotonic,True
        owner.clock=SimpleNamespace(pid=int(owner.binding['processIdentity']));owner.native=None;owner._cached=[];owner.previous=store.read();owner.state=None
        need(owner.previous is not None);owner.prior_link=deepcopy(owner.previous['priorPage']);owner.boundary()
        owner.originals=OriginalFrameStore(store.path.parent,owner.binding,owner.run,'primary',owner.guard,owner.frame_intent,
            namespace='assets-page-reentry-g'+str(owner.generation),schema_prefix='iosAssetsPageReentrySource',monotonic=monotonic)
        owner.state=owner.decode(owner.previous);return owner
    def removal_link(self):
        owner=self.removal;need(owner.state is not None and owner.state['phase']=='model-gone' and owner.state['contextClosedBy'] is not None
            and same(owner.store.read(),owner.previous))
        owner.decode(owner.previous)
        return dict(path=str(owner.store.path),sha256=digest(owner.previous),entityId=owner.target(),result=deepcopy(owner.state['result']),contextClosedBy=owner.state['contextClosedBy'])
    def source(self):
        owner=self.removal;source=owner.usage.source
        need(isinstance(source,OwnedAssetsUpload) and source.files.run==self.run and source.role=='primary' and same(source.binding,self.binding)
            and source.store.path.is_relative_to(Path(self.selected.context['roles']['primary']['stateRoot']))
            and same(source.store.read(),source.previous) and source.state is not None)
        owner.guard();self.removal_link();return source
    def prior_context(self):
        source=self.source();source.decode(source.previous);alive=[];dead=[];wanted=source.state['page']
        for ref in source.state['frames']:
            frame=source.originals.read(source.originals.expand(ref));source.frame(frame)
            rows=[row for row in project(frame['ui'])['inventory']['roots'] if row['role']=='page' and row['rootId']==wanted]
            if len(rows)==1:(alive if rows[0]['alive'] else dead).append((ref,rows[0]))
        need(alive and dead and dead[-1][0]['index']>alive[0][0]['index'])
        return dict(sourcePath=str(source.store.path),fileOwnerToken=source.files.state['token'],page=deepcopy(alive[0][1]),aliveFrame=deepcopy(alive[0][0]),deadFrame=deepcopy(dead[-1][0]))
    def prior(self):
        source=self.source();value=self.prior_link
        exact(value,{'sourcePath','fileOwnerToken','page','aliveFrame','deadFrame'})
        need(value['sourcePath']==str(source.store.path) and value['fileOwnerToken']==source.files.state['token'] and value['page']['rootId']==source.state['page']
            and value['aliveFrame'] in source.state['frames'] and value['deadFrame'] in source.state['frames']
            and value['deadFrame']['index']>value['aliveFrame']['index'])
        before=source.originals.read(source.originals.expand(value['aliveFrame']));after=source.originals.read(source.originals.expand(value['deadFrame']))
        source.frame(before);source.frame(after)
        old=root(project(before['ui']),'page',identifier=source.state['page']);need(same(old,value['page']))
        root(project(after['ui']),'page',alive=False,identifier=old['rootId']);need(after['ui']['sampleEpochMs']>=before['ui']['sampleEpochMs'])
        return old
    def boundary(self):
        need(self.store.path==Path(self.selected.context['roles']['primary']['stateRoot'])/('ios-assets-page-reentry-'+self.run+'-primary-g'+str(self.generation)+'.json')
            and self.lock.path==self.store.path.with_name('script-feature-sources.lock') and self.clock.pid==int(self.binding['processIdentity']))
        self.lock.assert_held();self.selected.selected_guard();self.prior()
    def link(self):
        self.guard();need(self.state is not None)
        return dict(iosAssetsPageReentryLinkVersion=1,path=str(self.store.path),generation=self.generation,actionIndex=self.action_index,ticket=self.ticket)
    def envelope(self):
        return dict(iosAssetsPageReentryVersion=VERSION,binding=self.binding,runId=self.run,role='primary',selectedPair=self.selected.link(),
            action=dict(path=str(self.actions.store.path),index=self.action_index,ticket=self.ticket),generation=self.generation,
            removal=self.removal_link(),priorPage=deepcopy(self.prior_link),payload=pack([self.state]))
    def frame(self,value,previous=None):
        result=OwnedAssetsUpload.frame(self,value,previous)
        if self.historical:
            action=self.actions.read(self.action_index);need(action['phaseBefore']['capturedEpochMs']<=value['ui']['sampleEpochMs']<=action['phaseAfter']['capturedEpochMs'])
        else:
            pending=self.actions.state['pending'];need(pending is not None and pending['index']==self.action_index and pending['ticket']==self.ticket
                and value['ui']['sampleEpochMs']>=pending['before']['capturedEpochMs'])
        root(project(value['ui']),'page',alive=False,identifier=self.prior_link['page']['rootId']);return result
    def page(self):
        page=super().page();need(page['rootId']!=self.prior_link['page']['rootId']);return page
    def decode(self,value):
        exact(value,{'iosAssetsPageReentryVersion','binding','runId','role','selectedPair','action','generation','removal','priorPage','payload'})
        need(type(value['iosAssetsPageReentryVersion']) is int and value['iosAssetsPageReentryVersion']==VERSION
            and same(value['binding'],self.binding) and value['runId']==self.run and value['role']=='primary'
            and same(value['selectedPair'],self.selected.link()) and same(value['action'],dict(path=str(self.actions.store.path),index=self.action_index,ticket=self.ticket)))
        need(type(value['generation']) is int and value['generation']==self.generation
            and same(value['removal'],self.removal_link()) and same(value['priorPage'],self.prior_link))
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0];exact(state,{'phase','frames','pending','inputs','openedBy'})
        need(state['phase'] in ('reserved','opening','opened') and type(state['frames']) is list and len(state['frames'])<=32
            and type(state['inputs']) is list and len(state['inputs'])<=2)
        frames=[];prior=None
        for index,ref in enumerate(state['frames'],1):
            full=self.originals.expand(ref);need(full['index']==index);frame=self.originals.read(full);self.frame(frame,prior);frames.append(frame);prior=frame
        slots=set()
        for entry in state['inputs']:
            exact(entry,{'slot','before','command','receipt','resolvedBy'});slot=entry['slot'];need(slot in SLOTS and slot not in slots);slots.add(slot)
            need(integer(entry['before'],1,len(frames)));packet=frames[entry['before']-1]['ui'];reference=project(packet)
            targets=[row for row in reference['controls'] if row['id']==SLOTS[slot]];need(len(targets)==1)
            command=entry['command'];receipt=entry['receipt']
            if command is None:need(receipt is None and entry['resolvedBy'] is None);continue
            exact(command,{'schemaVersion','commandId','instance','sequence','observedElapsedMs','fieldToken','operation'});identity(command['commandId'])
            need(type(command['schemaVersion']) is int and command['schemaVersion']==1 and command['instance']==packet['instance']
                and type(command['sequence']) is int and command['sequence']==packet['lastSequence']+1 and command['observedElapsedMs']==packet['elapsedMs']
                and type(command['observedElapsedMs']) is int and command['fieldToken']==targets[0]['token'] and command['operation']=='activate')
            if receipt is not None:
                exact(receipt,{'schemaVersion','commandId','status'});status=receipt['status'];exact(status,{'schemaVersion','commandId','instance','sequence','performed','processId','sampleEpochMs'})
                need(receipt['schemaVersion']==status['schemaVersion']==1 and type(receipt['schemaVersion']) is type(status['schemaVersion']) is int
                    and status['commandId']==command['commandId'] and status['instance']==command['instance'] and status['sequence']==command['sequence']
                    and type(status['sequence']) is int and status['performed'] is True and type(status['processId']) is int and status['processId']==self.clock.pid
                    and number(status['sampleEpochMs'],packet['sampleEpochMs'],packet['sampleEpochMs']+1500));need(type(receipt['commandId']) is str and re.fullmatch('ios-[a-f0-9]{32}',receipt['commandId']) is not None)
            if entry['resolvedBy'] is not None:
                need(integer(entry['resolvedBy'],entry['before']+1,len(frames)));self.effect(entry,frames[entry['resolvedBy']-1]['ui'])
        pending=state['pending']
        if pending is not None:
            exact(pending,{'hostBefore','hostAfter','queries','clocks','ui','uiReceipt','original'})
            need(number(pending['hostBefore'],0,1e15) and type(pending['queries']) is list and type(pending['clocks']) is list)
            if pending['original'] is not None:self.originals.original(pending['original']);AssetsModelSources.prefix(self,pending['original'])
        if state['phase']=='opened':
            need(pending is None and 'open-assets' in slots and all(entry['resolvedBy'] is not None for entry in state['inputs'])
                and integer(state['openedBy'],1,len(frames)));page=root(project(frames[state['openedBy']-1]['ui']),'page')
            need(page['visible'] and not page['busy'] and not page['bundleRequest'] and not page['pendingBundle'] and not page['destinationOpen'])
        else:need(state['openedBy'] is None)
        self._cached=frames;return state

