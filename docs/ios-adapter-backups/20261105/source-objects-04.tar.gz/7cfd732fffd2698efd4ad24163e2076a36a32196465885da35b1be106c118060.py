from pathlib import Path
import ast,difflib,hashlib,json
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-native-motion-worker-scope-proposal-20261028';A=T/'lifecycle-original-owner-native-motion-before-down-alias-overlay-20261028';P=T/'lifecycle-original-owner-native-motion-resource-envelope-overlay-20261028';P.mkdir(mode=0o700);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rel='tests/device/ios/adapters/lifecycle_touch_resource_owner.py';base=B/'candidate/repo'/rel;old=base.read_text()
first="        original=resource._motion_original;original.anchor(source,resource,owner.instance)"
second="        resource.file_guard()\n        if self._lease is None:"
assert old.count(first)==old.count(second)==1
new=old.replace(first,"        need(same(resource.envelope(),resource.previous))\n"+first).replace(second,"        resource.file_guard();need(same(resource.envelope(),resource.previous))\n        if self._lease is None:")
target=P/'candidate/repo'/rel;target.parent.mkdir(parents=True);target.write_text(new);ast.parse(new)
(P/'source1.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
name='test_native_motion_worker_scope_models.py';oldmodel=(A/name).read_text();model=oldmodel+'''
    async def test_mutable_resource_path_cannot_change_original_prepared_input_or_acquire_context(self):
        lease=await self.setup_motion();path=deepcopy(self.prepared_original['state']['path'])
        self.resource.state['path']['start'][0]+=15
        with self.assertRaises((RuntimeError,ValueError)):
            await lease.begin(path['window']['width'],path['window']['height'],*path['start'],seconds=12)
        await lease.worker
        self.assertEqual([],self.f.states());self.assertEqual(0,self.f.context.entered)
        self.assertTrue(self.selected[3]['revoked']);self.assertTrue(lease.request_release.is_set())
        self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes())
        self.assertIs(self.source._born[0]['worker'],lease.worker)
''';ast.parse(model);(P/name).write_text(model)
(P/'test1.diff').write_text(''.join(difflib.unified_diff(oldmodel.splitlines(True),model.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
plan=json.loads((A/'test-plan.json').read_text());c=next(c for c in ast.parse(model).body if isinstance(c,ast.ClassDef));ids=['test_native_motion_worker_scope_models.'+c.name+'.'+n.name for n in c.body if isinstance(n,ast.AsyncFunctionDef) and n.name.startswith('test_')];assert len(ids)==12;plan.update(status='PRIVATE_SOURCE_MODEL12_UNRUN',exactCaseIds=ids,caseCount=12,expectedGenuineRoots=24);(P/'test-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE_FROZEN_SOURCE1_MODEL1_UNRUN',workerFreezeSHA256=H(B/'freeze.json'),beforeDownAliasFreezeSHA256=H(A/'freeze.json'),path=rel,baseSHA256=H(base),candidate=str(target),candidateSHA256=H(target),modelSHA256=H(P/name),caseCount=12,initialSeconds=60,killAfterSeconds=5,expectedGenuineRoots=24,canonicalGate=False,nativeTouchSupport=False),indent=2)+'\n')
(P/'README.txt').write_text('''Separate own-review correction: file_guard pins WAL==previous but mutable
Resource.state/envelope was not joined to that exact original opening. Require
same(envelope,previous) BEFORE installing the typed bridge and at EVERY actual
weak-worker scope. Full state/path/seconds/context/acquisition identity stay
original; no rebasing or extra input. Actual new countercase changes only memory
path after local lease construction; original begin/worker must refuse before
context entry/Down, retain actual born Task, preserve old preparation bytes.
Composed12/60+5/24 real TD, original7a071/b7d0e freezes unchanged. No imports,
execution, Source publication or SDK/native/canonical qualification.
''')
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_FROZEN_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(freeze=H(P/'freeze.json'),resourceSHA256=H(target),modelSHA256=H(P/name)),indent=2))
