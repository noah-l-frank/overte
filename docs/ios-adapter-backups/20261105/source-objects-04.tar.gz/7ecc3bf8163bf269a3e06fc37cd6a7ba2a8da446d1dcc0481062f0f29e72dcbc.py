"""Private source models: no SDK import or real authentication/transport.

Root must provide an exact source-map file and its SHA before running.
Only pinned actual source class/function AST nodes are executed with explicit
protocol models. Six cases qualify the source control flow, not an SDK/device.
"""
from __future__ import annotations
import ast
import asyncio
import hashlib
import json
import os
from pathlib import Path
import ssl
import unittest
import weakref


def source(path_key):
    path = Path(os.environ['LIFECYCLE_AUTH_MODEL_SOURCE_MAP'])
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != os.environ['LIFECYCLE_AUTH_MODEL_SOURCE_MAP_SHA256']:
        raise RuntimeError('Exact source map unavailable')
    row = json.loads(raw)[path_key]
    target = Path(row['path'])
    body = target.read_bytes()
    if hashlib.sha256(body).hexdigest() != row['sha256']:
        raise RuntimeError('Actual source changed')
    return ast.parse(body, filename=str(target))


def extract(nodes, namespace):
    # Compiler future directive only; this does not import any SDK module.
    tree = ast.Module(body=[ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0), *nodes], type_ignores=[])
    exec(compile(ast.fix_missing_locations(tree), '<pinned-source-model>', 'exec'), namespace)


class ModelError(RuntimeError):
    pass


class Writer:
    def __init__(self): self.closed = False
    def is_closing(self): return self.closed


class Reader:
    def at_eof(self): return False


class Service:
    def __init__(self):
        self.writer = Writer(); self.reader = Reader()
        self.entered = asyncio.Event(); self.gate = asyncio.Event(); self.gate.set()
    async def close(self):
        self.entered.set(); await self.gate.wait(); self.writer.closed = True


class ValidationEpochModels(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        tree = source('lockdown')
        actual = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'LockdownClient')
        capsule = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == 'ValidatedSessionSource')
        methods = [next(x for x in actual.body if isinstance(x, ast.AsyncFunctionDef) and x.name == name)
                   for name in ('validate_pairing', 'stop_session', 'close')]
        namespace = dict(asyncio=asyncio, weakref=weakref, Version=lambda value: tuple(int(p) for p in value.split('.')),
                         DeviceClass=type('DeviceClass', (), {'WATCH': object()}),
                         InvalidHostIDError=ModelError, InvalidConnectionError=ModelError, PairingError=ModelError,
                         ConnectionTerminatedError=ModelError, CannotStopSessionError=ModelError,
                         SSLZeroReturnError=ssl.SSLZeroReturnError)
        extract([capsule, *methods], namespace)
        class ProtocolModel:
            def __init__(self):
                self.service=Service(); self.pair_record={'HostID':'model-host','SystemBUID':'model-buid'}
                self.host_id='model-host'; self.system_buid='model-buid'; self.product_version='17.4'
                self.device_class=object(); self.session_id=None; self.paired=False; self.udid=None
                self._validated_session_source=None; self._validated_session_epoch=object()
                self.entered={name:asyncio.Event() for name in ('A','B')}
                self.gates={name:asyncio.Event() for name in ('A','B')}
                self.stop_entered=asyncio.Event(); self.stop_gate=asyncio.Event(); self.calls=[]
            async def _request(self, command, payload):
                name=asyncio.current_task().get_name(); self.calls.append((command,name))
                if command=='StartSession':return {'SessionID':'model-session', 'EnableSessionSSL':False}
                if command=='StopSession':
                    self.stop_entered.set(); await self.stop_gate.wait(); return {'Result':'Success'}
                raise AssertionError('Unexpected extra protocol operation')
            async def get_value(self):
                name=asyncio.current_task().get_name(); self.entered[name].set(); await self.gates[name].wait()
                return {'UniqueDeviceID':'model-target'}
        for name in ('validate_pairing','stop_session','close'):setattr(ProtocolModel,name,namespace[name])
        self.model=ProtocolModel(); self.tasks=[]
    async def start_validation(self, name):
        task=asyncio.create_task(self.model.validate_pairing(),name=name); self.tasks.append(task)
        await self.model.entered[name].wait(); return task
    async def asyncTearDown(self):
        for gate in self.model.gates.values():gate.set()
        self.model.stop_gate.set(); self.model.service.gate.set()
        if self.tasks:await asyncio.gather(*self.tasks,return_exceptions=True)
    async def test_original_getvalue_cannot_remint_after_stop_entry_while_stop_return_pending(self):
        a=await self.start_validation('A')
        stop=asyncio.create_task(self.model.stop_session(),name='STOP'); self.tasks.append(stop)
        await self.model.stop_entered.wait(); self.model.gates['A'].set()
        self.assertIs(True,await a); self.assertIsNone(self.model._validated_session_source)
        self.assertFalse(stop.done()); self.assertEqual([('StartSession','A'),('StopSession','STOP')],self.model.calls)
        self.model.stop_gate.set(); await stop
    async def test_original_getvalue_cannot_remint_after_close_entry_while_close_pending(self):
        self.model.service.gate.clear(); a=await self.start_validation('A')
        close=asyncio.create_task(self.model.close(),name='CLOSE'); self.tasks.append(close)
        await self.model.service.entered.wait(); self.model.gates['A'].set()
        self.assertIs(True,await a); self.assertIsNone(self.model._validated_session_source)
        self.assertFalse(close.done()); self.assertEqual([('StartSession','A')],self.model.calls)
        self.model.service.gate.set(); await close
    async def overlap(self, first):
        a=await self.start_validation('A'); b=await self.start_validation('B')
        tasks={'A':a,'B':b}; self.model.gates[first].set(); self.assertIs(True,await tasks[first])
        winner=self.model._validated_session_source
        if first=='A':self.assertIsNone(winner)
        else:self.assertIs(winner.current(),self.model)
        second='B' if first=='A' else 'A'; self.model.gates[second].set(); self.assertIs(True,await tasks[second])
        final=self.model._validated_session_source; self.assertIsNotNone(final); self.assertIs(final.current(),self.model)
        if first=='B':self.assertIs(final,winner)
        self.assertEqual([('StartSession','A'),('StartSession','B')],self.model.calls)
    async def test_overlapping_validations_old_returns_first_only_latest_birth_can_mint(self):await self.overlap('A')
    async def test_overlapping_validations_latest_returns_first_old_completion_keeps_winner(self):await self.overlap('B')


class Model:
    pass


class DialIdentityModels(unittest.TestCase):
    def setUp(self):
        tree=source('userspace')
        dial_class=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='UserspaceDialPlane')
        dial=next(x for x in dial_class.body if isinstance(x,ast.AsyncFunctionDef) and x.name=='dial')
        capsule=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='UserspaceRsdSource')
        namespace=dict(asyncio=asyncio,weakref=weakref,PyMobileDevice3Exception=ModelError,stack=Model())
        extract([dial],namespace); namespace['_USERSPACE_DIAL_IMPLEMENTATION']=namespace['dial']
        extract([capsule],namespace); self.namespace=namespace
        # Use the actual extracted original function as expected hook. Its body
        # is never invoked; no network/SDK transport operation is modeled here.
        self.plane_type=type('ModeledPlane',(),{'dial':namespace['dial']}); self.plane=self.plane_type()
        self.values=[Model() for _ in range(8)]; self.values[6]=self.plane; self.values[5].addr='fd00::1'
        self.rsd=self.values[7]; self.rsd.service=Model(); self.rsd.service._writer=Writer()
    def create(self):
        self.rsd.open_connection=self.plane.dial
        return self.namespace['UserspaceRsdSource'](*self.values,Model())
    def test_different_bound_method_installed_before_source_creation_is_refused(self):
        async def foreign(_self,*_args,**_kwargs):raise AssertionError('Never execute foreign dial')
        self.plane.dial=foreign.__get__(self.plane,type(self.plane))
        with self.assertRaisesRegex(ModelError,'dial implementation'):self.create()
    def test_exact_original_function_is_retained_without_strong_owner_or_dialplane(self):
        cap=self.create(); self.assertIs(cap._expected_dial,self.namespace['dial'])
        self.assertIs(cap._opener_ref(),self.rsd.open_connection)
        self.assertIs(cap._owner(),self.values[0]); self.assertIs(cap._refs[5](),self.plane)
