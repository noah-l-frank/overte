"""Retain one actual original fixture error; no changed source or rerun."""
from pathlib import Path
import json,hashlib
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(o,n,v):
 with(o/n).open('x')as s:json.dump(v,s,sort_keys=True,indent=2);s.write('\n')
C=B/'root-audio10-bootstrap3-ten-window-current1200-20261105'
assert sha(C/'freeze.json')=='08396382ddc369143bfdbb112b80fb90b62b68181b535f86fde907ce20db1e00'
for n,r in load(C/'freeze.json')['files'].items():assert sha(C/n)==r['sha256']
t=load(C/'terminal.json');assert t['status']=='ROOT_AUDIO10_STOPPED_ON_ORIGINAL_FAILURE'and t['oldRootCount']==1200
assert t['allOldOriginalBodiesUnchanged']is t['allRecordedOriginalProcessesAndGroupsAbsent']is t['wholeOwnRoomsTwiceEqual']is True
assert len(t['completedGroups'])==1 and t['unrunGroups']==['audioReply'+format(n,'02d')for n in range(2,11)]
g=t['completedGroups'][0];assert g['group']=='audioReply01'and g['supervisorReturnCode']==1 and g['passed']is False and g['rootObservedAbsence']is True
h=Path(g['input']).parent;o=h.with_name(h.name+'-outer');c=h.with_name(h.name+'-censuses')
assert sha(h/'approved-inputs.json')==g['inputSha256']=='8cc5a7be2623af36ebe4e71dd9b94d1464acbea50c1a7d5c2622ae6041486613'
terminal=load(o/'terminal.json');q=load(c/'qualification.json');assert terminal==g['originalTerminal']and q==g['originalQualification']
assert terminal['status']==q['status']=='FAIL_OR_REFUSED'and terminal['childReturnCode']==1 and terminal['ownProcessesAbsent']is q['ownProcessesAbsent']is True
assert terminal['problems']==terminal['orphansRequiredKill']==[]and terminal['timedOut']is terminal['forcedKill']is False
for key in('allActualRuntimeOriginsEstablished','allSourceBinaryPinsEqual','actualOneCaseReceiptEstablished','actualClassCleanupCustodyEstablished','zeroCaseChildBirthsEstablished','actualStdlibParentFDThreadDrain'):assert terminal[key]is True
report=load(h/'child-receipts/report.json');assert report['testsRun']==report['actualCaseReceipts']==1 and report['status']=='FAIL_OR_ERROR'and report['fatal']is None and report['secondary']==[]and report['cleanupEstablished']is False
for key in('fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','allActualLoadedOriginsAccounted','allActualRuntimeOriginsEstablished'):assert report[key]is True
for key in('SDKExecutions','NodeExecutions','PythonExecutions','overteNativeQueries'):assert report[key]==0
restore=load(h/'child-receipts/actual-port-restoration.json');assert restore['count']==27 and restore['controlDescriptors']==restore['secondary']==[]
for key in('builtinsCioRestored','dupPortsRestored','restored','toolsRestored'):assert restore[key]is True
raw=h/'child-logs/stderr.log';text=raw.read_text();assert 'DeclaredTargetAdapter'not in text and 'super().__init__(original.adapter)'in text and 'callable(getattr(adapter' in text and 'NativeUIError' in text and 'FAILED (errors=1)'in text
absence=load(C/'actual-root-absence-audioReply01.json');assert absence['remainingSameGroupOrSession']==[]and absence['originalDrain']['remaining']==[]
for row in absence['recordedOriginals']:
 try:proc=Path('/proc',str(row['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(proc[proc.rfind(')')+2:].split()[19])!=row['startTicks']
ctx=load(B/'root-ios-current1200-after-tablet-b7-seventeen-host-controls-context-20261105/root-context.json');old=load(ctx['globalCustody']['baseline']['path'])
assert len(old)==1200 and load(C/'global-before.json')==load(C/'global-after-first.json')==load(C/'global-after-second.json')==old
assert load(C/'whole-first.json')==load(C/'whole-second.json')
roots=t['newOriginalRoots'];assert len(roots)==5 and str(h/'own-toys')in roots
refs={str(p):dict(path=str(p),sha256=sha(p))for root in map(Path,roots)for p in sorted(root.rglob('*'))if p.is_file()and not p.is_symlink()}
out=B/'root-audio10-b3-first-original-fixture-constructor-error-negative-results-20261105';out.mkdir(mode=0o700)
put(out,'results.json',dict(status='ROOT_RETAINED_AUDIO10_B3_FIRST_ORIGINAL_BODY_FIXTURE_CONSTRUCTOR_ERROR',terminal=terminal,newOriginalRoots=roots,originalRootTerminal=t,originalReport=report,originalRestoration=restore,originalQualification=q,actualOriginalCasesExecuted=1,actualOriginalCasesPassed=0,originalCaseFailure=dict(path=str(raw),sha256=sha(raw),message='ReceivedRuntime original constructor refuses modeled DeclaredTargetAdapter missing candidate_guard/binding callable protocol'),remainingNineOriginalCasesUnrun=True,cleanupEstablished=False,finalDefinitionCheckDirectReceiptAvailable=False,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(out,'actual-receipt-references.json',refs);put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}));print(json.dumps(dict(freeze=sha(out/'freeze.json'),results=sha(out/'results.json'),references=len(refs))))
