"""Explicit version9 caller route; v6-v8/coordinator2 behavior stays literal."""
from adapters.native_feature_observation import need
from adapters.script_feature.history import same
from ios.adapters.emote_runtime import IOSEmoteRuntime
from ios.adapters.emote_callback_terminal import IOSEmotePostControllerCallbackFeature
from ios.adapters.feature_configuration import validate
from feature_journeys import terminal

FLAGS={'--emote-palette-observe','--e2e-emote-palette-file-ownership','--e2e-emote-response-file-ownership'}
def target_flags(target):
    values=target.get('testBuild',{}).get('launchArguments',[])
    need(type(values)is list and all(type(item)is str for item in values)and FLAGS<=set(values))
    # --testScript is supplied by the existing Appium test-build launcher.
    # Presence of flags is configuration, never installed/native qualification.
    return target

def configured_factory(runtime,config):
    validate(config);need(isinstance(runtime,IOSEmoteRuntime)and config['iosFeatureAdapterVersion']==9
        and config['emoteCoordinatorVersion']==2 and config['emotePostControllerFamilyVersion']==1)
    pair=config['emoteTargets']
    for selector in (pair['primaryTarget'],pair['actorTarget']):target_flags(runtime.adapter.target(selector))
    return runtime._emote_post_controller_feature

def terminal_call(flow,call,config):
    need(type(flow)is IOSEmotePostControllerCallbackFeature and flow.role=='primary')
    configured_factory(flow.runtime,config);call=terminal.arguments('emotes',call)
    need(call['runId']==flow.run and same(flow.configured_pair,config['emoteTargets']))
    if call['stage']!='finish':
        from ios.adapters.emote_post9_terminal import IOSEmotePost9Terminal
        return IOSEmotePost9Terminal(flow).invoke(call)
    from ios.adapters.emote_post9_entry import finish
    original=finish(flow,call['seal'])
    need(original['iosEmotePostControllerEndVersion']==3)
    terminal.ended(original['terminalEnd'],call['seal'])
    # Existing result grammar is preserved. Independent canonical verification
    # below reopens the new typed originals; this projection supplies no facts.
    return dict(stage='finish',end=original['terminalEnd'])
