from pathlib import Path
import ast,hashlib,json,difflib,shutil
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-child-bundle-profile-proposal-20261028';S=T/'lifecycle-original-owner-child-selected-ipa-source-checkpoint-20261028';O=T/'lifecycle-original-owner-child-selected-ipa-revocation-overlay-20261028';P=T/'lifecycle-original-owner-child-selected-ipa-model-proposal-20261028';P.mkdir(mode=0o700);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['native_file_fixture.py','test_child_bundle_profile_models.py']:shutil.copyfile(B/n,P/n)
b=(B/'installed_query_fixture.py').read_text();s=b
needle="self.ops.fresh_touch_scope=fresh;self.loop.call_soon(ready.set_result,True);self.loop.run_forever()"
replacement="""self.ops.fresh_touch_scope=fresh
                original_tree=ast.parse(path.read_bytes());original_source=next(n for n in original_tree.body if isinstance(n,ast.ClassDef) and n.name=='OriginalKeeperSource')
                constructor=next(n for n in original_source.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
                assignments=[n for n in constructor.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Attribute) and t.attr=='_creator_task' for t in n.targets)]
                self.assertEqual(1,len(assignments));birth=ast.Module(body=deepcopy(assignments),type_ignores=[]);birth_code=compile(ast.fix_missing_locations(birth),str(path),'exec')
                fd=os.open(out/('creator-'+uuid.uuid4().hex+'.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
                with os.fdopen(fd,'w') as f:json.dump(dict(sourceSha256=self.mapping['keeper']['sha256'],selectedAstSha256=hashlib.sha256(ast.dump(birth,include_attributes=False).encode()).hexdigest(),compiledCodeSha256=hashlib.sha256(marshal.dumps(birth_code)).hexdigest()),f);f.write('\\n')
                self.creator_stop=asyncio.Event()
                async def original_creator_model():
                    exec(birth_code,dict(self=self.source,weakref=weakref,asyncio=asyncio));ready.set_result(True);await self.creator_stop.wait()
                self.creator=asyncio.create_task(original_creator_model(),name='modeled-original-selected-ipa-creator')
                self.loop.run_forever()"""
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle="await self.source.settle_touches()\n            self.assertTrue(all(task.done()";replacement="await self.source.settle_touches()\n            self.creator_stop.set();await self.creator\n            self.assertTrue(all(task.done()";assert s.count(needle)==1;s=s.replace(needle,replacement)
ast.parse(s);(P/'selected_installed_fixture.py').write_text(s);(P/'installed-fixture-creator-task.diff').write_text(''.join(difflib.unified_diff(b.splitlines(True),s.splitlines(True),fromfile='bundle-fixture/installed_query_fixture.py',tofile='selected-fixture/selected_installed_fixture.py')))
(P/'dependencies.json').write_text(json.dumps(dict(bundleFreeze=H(B/'freeze.json'),selectedSourceFreeze=H(S/'freeze.json'),selectedRevocationFreeze=H(O/'freeze.json'),keeperCandidateSHA256=H(O/'candidate/repo/tests/device/ios/pymobiledevice3_wda_xctest.py'),installedCandidateSHA256=H(S/'candidate/repo/tests/device/ios/adapters/installed_adapter.py'),sourcePublic=False,SDKImported=False,executed=False),indent=2)+'\n')
print(P)
