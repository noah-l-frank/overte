"""Private Root run metadata only; no target imports or process launch on import."""
from pathlib import Path
import ast,hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def pin(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode),str(path)
    value={key:getattr(a,key) for key in FIELDS}
    if stat.S_ISREG(a.st_mode):value['sha256']=sha(path)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in FIELDS),str(path)
    return value

def proc(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))

def load_plan():return json.loads((HERE/'suite-plan.json').read_text())
def validate_frozen():
    own=json.loads((HERE/'freeze.json').read_text())
    for name,expected in own['files'].items():assert sha(HERE/name)==expected,name
    plan=load_plan()
    assert sha(HERE/'source-root-final-map.json')==plan['sourceRootMapSha256']
    assert sha(HERE/'expected-publication.json')==plan['expectedPublicationSha256']
    assert sha(HERE/'expected-registry-own-keys.json')==plan['expectedOwnRegistrySha256']
    for row in plan['frozenPackets']:
        root=REPO/row['path'];assert sha(root/'freeze.json')==row['freezeSha256']
        frozen=json.loads((root/'freeze.json').read_text())
        for name,expected in frozen['files'].items():assert sha(root/name)==expected,name
    return plan

def publication():
    plan=load_plan();rows=json.loads((HERE/'expected-publication.json').read_text())
    assert len(rows)==plan['expectedPublicationCount']
    for row in rows:
        path=REPO/row['path'];assert path.resolve(strict=True)==path and sha(path)==row['expectedSha256'],row['path']
    own=json.loads((HERE/'expected-registry-own-keys.json').read_text())
    contracts=json.loads((REPO/'tests/device/contract-versions.json').read_text())['contracts']
    tree=ast.parse((REPO/'tests/device/validate_contract_versions.py').read_text())
    assignment=next(node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='REQUIRED' for t in node.targets))
    required=ast.literal_eval(assignment.value)
    for key,value in own.items():assert contracts.get(key)==value and required.get(key)==value['current'],key
    return rows

def prior_originals(plan):
    path=HERE/'retained-prior-original-pins.json';assert sha(path)==plan['retainedPriorPinsSha256']
    wanted=json.loads(path.read_text());current={name:pin(REPO/name) for name in wanted}
    assert current==wanted,'Prior actual originals or raw failure/success diagnostics changed'
    return current

def broad_sources(plan):
    names=subprocess.check_output(['rg','--files','-0',*plan['broadSourceRoots']],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}
    # Explicitly required even if rg ignore rules change.
    paths.update(REPO/name for name in ('interface/src/main.cpp','interface/CMakeLists.txt','CMakeLists.txt'))
    assert all((REPO/name).is_file() for name in ('interface/src/main.cpp','interface/CMakeLists.txt','CMakeLists.txt'))
    return paths

def sources(plan):
    paths=broad_sources(plan)
    own=json.loads((HERE/'freeze.json').read_text())
    paths.update(HERE/name for name in own['files']);paths.add(HERE/'freeze.json')
    for row in plan['frozenPackets']:
        root=REPO/row['path'];frozen=json.loads((root/'freeze.json').read_text())
        paths.update(root/name for name in frozen['files']);paths.add(root/'freeze.json')
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}

def originals(root):
    return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
