"""Prepare a source-only backup; never import or execute candidate modules."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import tarfile

repo = Path.cwd()
private = repo / '.ios-host-tmp'
output = repo / 'docs/ios-adapter-backups/20261103'
baseline = json.loads((repo / 'docs/ios-adapter-backups/20261029/manifest.json').read_text())
baseline_sources = {row['path']: row for row in baseline['privateSourceDrafts']}
assert not output.exists()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only']).strip()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
source_extensions = {'.py', '.js', '.mjs', '.cpp', '.cc', '.c', '.h', '.hpp', '.qml', '.sh', '.diff', '.patch', '.cmake'}
metadata_names = {'freeze.json', 'source-freeze.json', 'manifest.json', 'source-manifest.json',
    'draft-manifest.json', 'checkpoint.json', 'plan.json', 'test-plan.json', 'run-plan.json',
    'supervisor-plan.json', 'semantic-plan.json', 'review-plan.json', 'PAUSE-CHECKPOINT.json',
    'ACTIVE-DRAFT-STATUS.json', 'root-current-checkpoint-20261027.json', 'snapshot.json',
    'subagent-pause-checkpoints.json'}
excluded_dirs = {'.git', '__pycache__', 'node_modules', 'runs', 'temporary', 'root-run-first',
    'source-code-bindings-first', 'untracked', 'remote-backup-preparation-20261029', 'initial-selection'}
private_key = re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----\s+[A-Za-z0-9+/=]{40}')
hosted_token = re.compile(rb'\b(?:gh[pousr]_[A-Za-z0-9_]{30,}|github_pat_[A-Za-z0-9_]{50,}|AKIA[A-Z0-9]{16})\b')

def read_stable(path):
    first = path.lstat()
    assert stat.S_ISREG(first.st_mode), str(path)
    body = path.read_bytes()
    last = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    assert all(getattr(first, field) == getattr(last, field) for field in fields), str(path)
    assert len(body) < 5 * 1024 * 1024, str(path)
    assert not private_key.search(body) and not hosted_token.search(body), 'Sensitive material: ' + str(path.relative_to(repo))
    return body

paths = []
for directory, names, files in os.walk(private, followlinks=False):
    names[:] = sorted(name for name in names if name not in excluded_dirs
        and not name.startswith(('tmp', 'retained-')) and not (Path(directory) / name).is_symlink())
    for name in sorted(files):
        path = Path(directory) / name
        if path.is_symlink():
            continue
        documentation = path.suffix in {'.txt', '.md'} and name.startswith(('README', 'RESTART', 'ROOT-', 'SOURCE-', 'NEXT-', 'PLAN', 'CHECKPOINT'))
        candidate_json = path.suffix == '.json' and ('candidate' in path.relative_to(private).parts or 'backup-restart-note' in path.parent.name)
        packet_metadata = (len(path.relative_to(private).parts) == 2 and path.suffix in {'.json', '.txt', '.md'} and path.stat().st_size <= 262144 and not re.search(r'(?:source.*(?:map|pins)|census|originals|(?:^|[-_])(?:before|after|report|output|result|stdout|stderr)(?:[-_.]|$))', name, re.I))
        if path.suffix in source_extensions or name in metadata_names or documentation or candidate_json or packet_metadata:
            relative = str(path.relative_to(repo))
            body = read_stable(path)
            previous = baseline_sources.get(relative)
            if previous is None or hashlib.sha256(body).hexdigest() != previous['sha256']:
                paths.append(path)

output.mkdir(parents=True)
archive = output / 'private-source-drafts.tar.gz'
rows = []
with archive.open('xb') as stream, gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w|') as bundle:
        for path in sorted(paths):
            body = read_stable(path)
            relative = str(path.relative_to(repo))
            item = tarfile.TarInfo(relative)
            item.size = len(body)
            item.mode = 0o600
            item.mtime = 0
            bundle.addfile(item, io.BytesIO(body))
            rows.append({'path': relative, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})

assert archive.stat().st_size < 50 * 1024 * 1024
expected = {row['path']: row for row in rows}
with tarfile.open(archive, 'r:gz') as bundle:
    members = bundle.getmembers()
    assert len(members) == len(expected)
    for item in members:
        assert item.isfile() and not item.name.startswith('/') and '..' not in Path(item.name).parts
        assert item.name in expected
        body = bundle.extractfile(item).read()
        assert len(body) == expected[item.name]['bytes']
        assert hashlib.sha256(body).hexdigest() == expected[item.name]['sha256']
for row in rows:
    assert hashlib.sha256(read_stable(repo / row['path'])).hexdigest() == row['sha256']

# The public working-code changes are saved separately in the backup commit.
tracked = subprocess.check_output(['git', 'diff', '--name-only', '-z'], text=True).split('\0')
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z', '--',
    'tests/device', 'interface/src', 'libraries', 'ios', 'cmake', 'scripts/system'], text=True).split('\0')
code = []
for name in sorted(set(tracked + untracked) - {''}):
    body = read_stable(repo / name)
    code.append({'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
assert len(code) == 149
assert all(name.startswith(('tests/device/', 'interface/src/scripting/TestScriptingInterface.', 'libraries/audio-client/')) for name in (row['path'] for row in code))
manifest = {'backupKind': 'paused-unfinished-source-backup', 'baseCommit': head, 'baselineManifest': 'docs/ios-adapter-backups/20261029/manifest.json',
    'archiveMode': 'incremental-new-or-changed-private-source',
    'developmentRemainsPaused': True, 'completeFeatureAreas': 5, 'totalFeatureAreas': 14,
    'publicWorkingCode': code, 'privateSourceDrafts': rows,
    'archive': {'path': str(archive.relative_to(repo)), 'bytes': archive.stat().st_size,
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'excluded': ['Raw test originals and runtime directories', 'Certificates, private keys and account/device configuration',
        'Builds, SDK installations and generated binary artifacts', 'Large runtime source maps and historical census/result logs'],
    'qualification': 'A backup is not integration or feature qualification. Existing frozen manifests may reference excluded local originals.'}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
(output / 'README.md').write_text('# Paused iOS adapter source backup, 2026-11-03\n\nThis recovery commit preserves unfinished work and private source proposals.\nFive of fourteen feature adapters are complete at source level. Native compilation\nand device qualification have not been performed. Development remains paused.\n\nNormal repository paths preserve all public working-code changes. The incremental\n`private-source-drafts.tar.gz` contains private sources and selected source metadata\nthat are new or changed since `../20261029/manifest.json`. Keep both backups:\nunchanged private sources remain in the 2026-10-29 archive. The manifest records\nSHA-256 and size for every incremental entry and every public working-code path.\nEvery archive entry is read back and compared with the unchanged local original.\n\nRaw test originals, runtime source copies, large census/source-map/result logs,\ncredentials, account/device configuration, SDKs and binary build artifacts remain\nlocal. Historical frozen launchers may depend on these excluded local originals;\nthis source backup does not make those launchers independently runnable.\n\nRead `.ios-host-tmp/remote-backup-preparation-20261103/RESTART.txt` and\n`checkpoint.json` inside the incremental archive before resuming. Restore only\ninto a separate reviewed checkout. Never extract over existing work or blindly\nexecute old launchers. The latest Emote current-state five countermodels passed;\nAssets historical snapshot cases02..07 passed and case01 failed. Its frozen\ntest-only measurement correction is unpublished and unexecuted. The Source4\nAvatar readonly profile map exists, but that target has not started. New Audio,\nAssets generation and Lifecycle proposals remain unintegrated and unqualified.\n\nThis commit is a source backup, not feature completion or integration acceptance.\nNo PR, protected integration, build, device test or laboratory run is included.\n')
print(json.dumps({'publicCodeFiles': len(code), 'archivedSourceFiles': len(rows),
    'archivedUncompressedBytes': sum(row['bytes'] for row in rows),
    'archiveBytes': archive.stat().st_size, 'archiveSha256': manifest['archive']['sha256']}))
