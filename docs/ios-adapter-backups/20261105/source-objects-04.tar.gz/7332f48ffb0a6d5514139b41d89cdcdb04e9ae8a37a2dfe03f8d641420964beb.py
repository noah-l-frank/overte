"""Root-executable local composition: actual provider/Source/child, SDK MODELS.

This is the shared End RESOURCE/CREATOR/REPLACEMENT composition. Its explicit
native cutoff does not claim Current7, a full parent End archive, native idle,
Audio custody discharge, or typed readmission completion. Root must join those
remaining owners through their real originals in the next fixture.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path


class OriginalKeeperResourceCompositionModels(unittest.TestCase):
    def run_composition(self,scenario):
        map_path=Path(os.environ['LIFECYCLE_END_COMPOSITION_SOURCE_MAP'])
        raw=map_path.read_bytes();self.assertEqual(os.environ['LIFECYCLE_END_COMPOSITION_SOURCE_MAP_SHA256'],hashlib.sha256(raw).hexdigest())
        mapping=json.loads(raw)
        self.assertEqual({'keeper','registry','child','wrapper','provider','nodeFixture'},set(mapping))
        for row in mapping.values():
            self.assertEqual({'path','sha256'},set(row));self.assertTrue(Path(row['path']).is_absolute())
            self.assertEqual(row['sha256'],hashlib.sha256(Path(row['path']).read_bytes()).hexdigest())
        with tempfile.TemporaryDirectory(prefix='lifecycle-end-composition-')as temporary:
            root=Path(temporary);root.chmod(0o700)
            report=root/'report.json';config=root/'configuration.json'
            value=dict(mapping,scenario=scenario,root=str(root),report=str(report),python=sys.executable,
                pythonPath=os.pathsep.join(str(Path(item).absolute())for item in sys.path if item))
            config.write_text(json.dumps(value)+'\n');config.chmod(0o600)
            # Root's original supervisor owns the process-tree budget. No inner
            # timeout kills a Node parent while abandoning an actual child.
            completed=subprocess.run([os.environ['LIFECYCLE_END_COMPOSITION_NODE'],mapping['nodeFixture']['path'],str(config)],
                stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
            self.assertEqual(0,completed.returncode,completed.stderr.decode(errors='replace')[-8192:])
            result=json.loads(report.read_text());self.assertTrue(result['allFixtureChildrenClosed'])
            self.assertTrue(result['physicalSDKModeled']);self.assertTrue(result['nativeCutoffModeled'])
            self.assertFalse(result['current7Qualified']);self.assertFalse(result['parentEndArchiveQualified'])
            self.assertEqual(mapping['keeper']['sha256'],result['keeperSourceSha256'])
            self.assertEqual(mapping['registry']['sha256'],result['registrySourceSha256'])
            return result

    def test_real_original_source_provider_resources_child_exit_canonical_delete_and_single_replacement_birth(self):
        result=self.run_composition('positive')
        self.assertTrue(result['resourceQualified']);self.assertTrue(result['creatorQualified'])
        self.assertTrue(result['creatorReplayEqual']);self.assertTrue(result['oneBirthReplayEqual'])
        self.assertEqual(1,result['canonicalDeletes']);self.assertEqual(1,result['canonicalCreates'])
        self.assertEqual(1,result['replacementBirths']);self.assertEqual(2,result['births'])
        self.assertTrue(result['canonicalStateAbsent']);self.assertFalse(result['nativeIdleQualified'])
        self.assertFalse(result['readmissionArchiveQualified'])
        proof=result['resourceOriginal'];self.assertGreaterEqual(len(proof['providers']),3)
        self.assertEqual({'reading','stopping'},{row['kind']for row in proof['originalControlTasks']})
        self.assertEqual([-1,-1,-1],proof['originalStreamSocketFds']);self.assertEqual([-1,-1],proof['tunSocketFds'])
        self.assertEqual(2,len(result['childExitEvents']));self.assertEqual(2,len(result['childCloseEvents']))
        self.assertTrue(all(row['code']==0 and row['signal']is None for row in result['childCloseEvents']))

    def test_unknown_extra_live_task_refuses_resource_proof_and_creator_before_delete_or_replacement(self):
        result=self.run_composition('unregistered-task')
        self.assertTrue(result['failurePendingRetained']);self.assertFalse(result['resourceQualified'])
        self.assertFalse(result['creatorQualified']);self.assertEqual(0,result['canonicalDeletes'])
        self.assertEqual(0,result['canonicalCreates']);self.assertEqual(0,result['replacementBirths'])
        self.assertEqual('sdk',result['failureOriginal']['pending']['kind'])
        self.assertTrue(result['failureOriginal']['failures']);self.assertFalse(result['failureOriginal']['qualified'])
        self.assertEqual(1,result['births'])

    def test_failed_actual_replacement_birth_remains_reserved_and_cannot_spawn_again(self):
        result=self.run_composition('replacement-failure')
        self.assertTrue(result['resourceQualified']);self.assertTrue(result['creatorQualified'])
        self.assertTrue(result['failedReplacementRetained']);self.assertEqual(1,result['replacementBirths'])
        self.assertEqual(2,result['births']);self.assertEqual(1,result['canonicalDeletes'])
        self.assertEqual(0,result['canonicalCreates'])

    def test_same_original_source_code_mutation_refuses_before_new_query_then_exact_restoration_allows_end(self):
        result=self.run_composition('source-code')
        self.assertTrue(result['sameSourceCodeMutationRefusedBeforeQuery'])
        self.assertTrue(result['foreignControlRefused']);self.assertTrue(result['resourceQualified'])
        self.assertTrue(result['creatorQualified']);self.assertTrue(result['oneBirthReplayEqual'])
        self.assertEqual(1,result['replacementBirths']);self.assertEqual(1,result['canonicalDeletes'])
