"""Private text/AST composition only. No target imports or public edits."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
BASE=REPO/'.ios-host-tmp/audio-settings-restoration-draft-20261028'
OVERLAY=REPO/'.ios-host-tmp/audio-settings-admission-overlay-20261028'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')


def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(name,value):(HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def pin(path):
    first=path.lstat();raw=path.read_bytes();last=path.lstat()
    assert all(getattr(first,key)==getattr(last,key) for key in FIELDS)
    return dict(sha256=sha(raw),**{key:getattr(last,key) for key in FIELDS})


def patch_blocks(raw):
    blocks=[];current=None;hunk=None
    for line in raw.splitlines(True):
        if line.startswith('--- '):
            current=dict(old=line[4:].strip(),new=None,hunks=[]);blocks.append(current)
        elif line.startswith('+++ '):current['new']=line[4:].strip()
        elif line.startswith('@@ '):
            hunk=[];current['hunks'].append(hunk)
        else:
            assert current is not None and hunk is not None and line[:1] in (' ','+','-'),repr(line)
            hunk.append(line)
    return blocks


plan=json.loads((BASE/'package-plan.json').read_text())
overlay=json.loads((OVERLAY/'review-packet.json').read_text())
freeze=json.loads((OVERLAY/'freeze.json').read_text())
assert all(sha((OVERLAY/name).read_bytes())==digest for name,digest in freeze['files'].items())
assert sha((BASE/'package-plan.json').read_bytes())==overlay['baseManifestSha256']
assert all(sha((REPO/row['privatePath']).read_bytes())==row['sha256'] for row in plan['publicationPaths'])
frozen={str(path.relative_to(REPO)):pin(path) for folder in (BASE,OVERLAY,
    REPO/'.ios-host-tmp/audio-settings-independent-review-20261028',
    REPO/'.ios-host-tmp/audio-settings-admission-independent-review-20261028')
    for path in sorted(folder.rglob('*')) if path.is_file()}
save('frozen-inputs-before.json',frozen)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
stale={row['path']:row for row in plan['publicationPaths']}
blocks=patch_blocks((BASE/'full-private-packet.patch').read_text())
assert len(blocks)==17
current={};composed={};hunks={}
for block in blocks:
    assert block['new'].startswith('b/')
    name=block['new'][2:];path=REPO/name
    assert name in stale
    if block['old']=='/dev/null':assert not path.exists(),name
    else:assert block['old']=='a/'+name and path.is_file(),name
    actual=path.read_bytes() if path.exists() else None
    current[name]=actual
    value='' if actual is None else actual.decode()
    for index,hunk in enumerate(block['hunks']):
        old=''.join(line[1:] for line in hunk if line[:1] in (' ','-'))
        new=''.join(line[1:] for line in hunk if line[:1] in (' ','+'))
        if not old:
            assert not value,(name,index)
            value=new
        else:
            assert value.count(old)==1,(name,index,'context absent or ambiguous')
            value=value.replace(old,new,1)
    composed[name]=value.encode();hunks[name]=len(block['hunks'])
    if actual is None or sha(actual)==stale[name]['baseSha256']:
        assert sha(composed[name])==stale[name]['sha256'],name

for row in overlay['paths']:
    name=row['path'];candidate=(OVERLAY/'payload'/name).read_bytes()
    assert sha(candidate)==row['sha256']
    if row['basePrivatePath'] is None:
        assert name not in composed and not (REPO/name).exists()
        current[name]=None
    else:assert sha(composed[name])==row['baseSha256']
    composed[name]=candidate
assert len(composed)==18

# Only this private guide receives the corrected case count and narrow claim.
guide='tests/device/ios/AUDIO_SETTINGS_PARTIAL.md'
text=composed[guide].decode()
text=text.replace('all twelve authored host cases','all sixteen authored host cases',1)
text=text.replace('Twelve host cases use real private files','Sixteen host cases use real private files',1)
text=text.replace('and readonly verification. All twelve are authored, unrun code; none qualifies native',
    'and readonly verification. Four additional cases cover fresh-token preparation/scroll drift,\n'
    'reconstruction after a lost input return and refusal of an admission reference to\n'
    'an actual post-effect original. All sixteen are authored, unrun code; none qualifies native',1)
anchor='captured guards must exactly match their originals.\n'
assert text.count(anchor)==1
text=text.replace(anchor,anchor+'\nEach operation keeps its original `admittedBefore` reference while separately\n'
    'capturing a fresh `before` cut. Both selected values must equal that admission\n'
    'before navigation or input. After delivery, only the named selected target may\n'
    'change. Decode repeats these typed original/value/order checks. This preserves\n'
    'the admission across the owner\'s runtime writes; it does not independently seal\n'
    'the mutable WAL against coordinated rewriting of consistent original references.\n',1)
composed[guide]=text.encode()

rows=[];full=[];shared=[]
for name,candidate in composed.items():
    old=current[name]
    target=HERE/'payload'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(candidate)
    if old is not None:
        snapshot=HERE/'base'/name;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(old)
    if name.endswith('.py'):ast.parse(candidate.decode())
    diff=''.join(difflib.unified_diff(('' if old is None else old.decode()).splitlines(True),candidate.decode().splitlines(True),
        fromfile='/dev/null' if old is None else 'a/'+name,tofile='b/'+name))
    full.append(diff)
    if old is not None:shared.append(diff)
    rows.append(dict(path=name,publicBaseExists=old is not None,publicBaseSha256=None if old is None else sha(old),
        publicBasePin=None if old is None else pin(REPO/name),candidateSha256=sha(candidate),
        inputOrigin='overlay3' if name in {row['path'] for row in overlay['paths']} else 'frozen17-own-hunks-on-current-public',
        historicalOwnHunkCount=hunks.get(name,0)))
(HERE/'proposal18.diff').write_text(''.join(full))
(HERE/'existing-path-rebase-only.diff').write_text(''.join(shared))
save('publication-paths.json',rows)
save('selected-case-ids.json',overlay['proposedSelectedCaseIDs'])
assert all((REPO/name).read_bytes()==old if old is not None else not (REPO/name).exists() for name,old in current.items())
assert all(pin(REPO/name)==row for name,row in frozen.items())
save('frozen-inputs-after.json',frozen)
save('composition-status.json',dict(status='PRIVATE_TEXT_AST_ONLY_UNRUN',publicHead=head,actualPaths=len(rows),
    existingPublicPaths=sum(row['publicBaseExists'] for row in rows),newPublicPaths=sum(not row['publicBaseExists'] for row in rows),
    selectedCaseCount=len(overlay['proposedSelectedCaseIDs']),frozenInputsUnchanged=True,publicInputsUnchanged=True,
    imports=False,tests=False,publicEdits=False))
print(json.dumps(dict(paths=len(rows),existing=sum(row['publicBaseExists'] for row in rows),head=head)))
