"""Actual constructor/lock/census mechanics on declared EMPTY metadata models.

No Native/SDK/GPU/current result is represented. Production constructors, fresh
guard callbacks, pure scope and complete physical inventory guards execute.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from PIL import Image
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_callback_live import IOSEmoteCallbackLiveFeature
from ios.adapters.emote_callback_scene import IOSEmoteCallbackKeyedRetirement,IOSEmoteCallbackSceneFeature
from ios.adapters.emote_callback_live_records import CallbackLiveRecords
from ios.adapters.emote_keys import IOSEmoteKeys
from ios.adapters.emote_restoration_frames import IOSEmoteRestorationFrames
from ios.adapters import emote_archive_round as rounds,web_closures


class CallbackCurrentConstructorRoundModels(unittest.TestCase):
    def setUp(self):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);self.root=Path(temp.name);self.root.chmod(0o700)
        self.lock=ScriptSourceLock(self.root/'script-feature-sources.lock');self.enterContext(self.lock.held());Image.preinit()
        self.binding=dict(sourceRevision='a'*40,artifactSha256='b'*64,sessionId='constructor-model',generation=0,targetFingerprint='c'*64,processIdentity='42')
        self.run='d'*32;self.guards=[];self.constructors=[]

    def empty_flow(self,kind=IOSEmoteCallbackLiveFeature,*,history=True):
        # EMPTY constructor metadata only. The Frame/Key owners have no
        # original rows, so no Source/native acquisition can be invented here.
        flow=object.__new__(kind);flow.root=self.root;flow.run=self.run;flow.role='primary';flow.selector='constructor-model'
        flow.lock=flow.primary_lock=self.lock;flow.policy=dict(source='world-render-target')
        flow.store=PrivateFeatureState(self.root/'ios-emote-primary-feature.json')
        flow.state=dict(binding=self.binding,primaryBinding=self.binding,phaseInstance='e'*32)
        flow.phase=SimpleNamespace(fixture_url='http://127.0.0.1/feature-fixture/v1/runs/'+self.run+'/')
        flow.runtime=SimpleNamespace(state_path=lambda _selector:self.root/'session.json')
        def guard():self.guards.append(rounds._ACTIVE.get());return True
        frames=object.__new__(IOSEmoteRestorationFrames)
        frames.root=self.root;frames.binding=dict(self.binding);frames.run=self.run;frames.role='primary'
        frames.store=PrivateFeatureState(self.root/'ios-emote-primary-restoration-frames.json')
        keys=object.__new__(IOSEmoteKeys);keys.root=self.root;keys.binding=dict(self.binding);keys.run=self.run;keys.role='primary';keys.lock=self.lock
        keys.store=PrivateFeatureState(self.root/'ios-emote-primary-keys.json');keys.previous=None;keys.guard=guard;keys.historical=False
        def current_keys(parts):
            self.assertIsNone(rounds._ACTIVE.get());return keys
        flow.keys=current_keys
        parts=dict(own=dict(check=guard),sources=SimpleNamespace(store=PrivateFeatureState(self.root/'ios-emote-primary-sources.json')),peers=None,restoration=frames)
        native=flow.native_retirement_owner;rendered=flow.rendered_retirement_owner;keyed=flow.KeyedRetirement
        def native_constructor(parts):self.constructors.append(('native',rounds._ACTIVE.get()));return native(parts)
        def rendered_constructor(parts,*,native=None):self.constructors.append(('rendered',rounds._ACTIVE.get()));return rendered(parts,native=native)
        def keyed_constructor(*args,**kwargs):self.constructors.append(('keyed',rounds._ACTIVE.get()));return keyed(*args,**kwargs)
        # Instance-only observation hooks call original unchanged production
        # constructor functions; parser/class namespace policy is untouched.
        flow.native_retirement_owner=native_constructor;flow.rendered_retirement_owner=rendered_constructor;flow.KeyedRetirement=keyed_constructor
        if history:
            flow._callback_live_historical_rows=CallbackLiveRecords()
            self.assertTrue(flow._callback_live_historical_rows.literal(),repr(flow._callback_live_historical_rows.unsupported_members()))
        return flow,parts,keys

    def test_original_current_constructors_share_one_inventory_and_fresh_guards_stay_outside_with_no_current_memo(self):
        flow,parts,keys=self.empty_flow();owner=flow.retirement_owner(parts)
        self.assertIs(type(owner),IOSEmoteCallbackKeyedRetirement);self.assertFalse(owner.historical)
        scopes=[scope for _name,scope in self.constructors];self.assertEqual(3,len(scopes));self.assertIsNotNone(scopes[0]);self.assertTrue(all(scope is scopes[0] for scope in scopes))
        self.assertIsNone(rounds._ACTIVE.get());self.assertEqual([None,None],self.guards)
        self.assertEqual(dict(records=[],abandoned=[],pending=None),owner.state)
        owner.current();self.assertEqual([None,None,None],self.guards)
        calls=[]
        with rounds.scope(dict(artifactRoot=str(self.root),stateRoot=str(self.root)),lock=self.lock,primary_lock=self.lock):
            def current_only():calls.append(True);return dict(mechanismOrdinal=len(calls))
            first=rounds.derived(owner,dict(index=1,sha256='f'*64),current_only)
            second=rounds.derived(owner,dict(index=1,sha256='f'*64),current_only)
        self.assertEqual(2,len(calls));self.assertNotEqual(first,second)
        self.assertEqual({},flow._callback_live_historical_rows.cache.rows)

    def test_original_shared_inventory_refuses_same_inode_body_change_and_new_orphan_between_constructors(self):
        flow,parts,keys=self.empty_flow();file=self.root/'physical-original-boundary.json';file.write_bytes(b'before');file.chmod(0o600)
        original=flow.native_retirement_owner
        for kind in ('same-inode-body','orphan'):
            with self.subTest(kind=kind):
                def changed(parts):
                    owner=original(parts)
                    if kind=='same-inode-body':file.write_bytes(b'after!')
                    else:
                        orphan=self.root/'unexpected-original-orphan.json';orphan.write_bytes(b'{}');orphan.chmod(0o600)
                    return owner
                flow.native_retirement_owner=changed
                with self.assertRaises(NativeUIError):flow.retirement_owner(parts)
                self.assertIsNone(rounds._ACTIVE.get());self.assertEqual({},flow._callback_live_historical_rows.cache.rows)
                self.assertTrue(all(scope is None for scope in self.guards))

    def test_actual_mutable_parser_policy_change_keeps_literal_constructor_fallback(self):
        flow,parts,keys=self.empty_flow();history=flow._callback_live_historical_rows
        with patch.object(web_closures,'READS',new=frozenset((*web_closures.READS,999))):
            self.assertFalse(history.literal());owner=flow.retirement_owner(parts)
            self.assertIs(type(owner),IOSEmoteCallbackKeyedRetirement)
            self.assertTrue(all(scope is None for _name,scope in self.constructors))
        self.assertTrue(history.literal());self.assertEqual({},history.cache.rows);self.assertIsNone(rounds._ACTIVE.get())

    def test_no_history_legacy_profile_and_supplied_current_components_retain_literal_paths(self):
        flow,parts,keys=self.empty_flow(IOSEmoteCallbackSceneFeature,history=False);owner=flow.retirement_owner(parts)
        self.assertIs(type(owner),IOSEmoteCallbackKeyedRetirement);self.assertFalse(hasattr(flow,'_callback_live_historical_rows'))
        self.assertTrue(all(scope is None for _name,scope in self.constructors));self.constructors.clear();self.guards.clear()
        current,parts,keys=self.empty_flow(history=False);owner=current.retirement_owner(parts)
        self.assertFalse(hasattr(current,'_callback_live_historical_rows'));self.assertTrue(all(scope is None for _name,scope in self.constructors))
        current._callback_live_historical_rows=CallbackLiveRecords();self.constructors.clear();self.guards.clear()
        # Preserve canonical current type gates: the constructor observation
        # hook is removed before the supplied-component type comparison.
        current.KeyedRetirement=IOSEmoteCallbackKeyedRetirement
        result=current.retirement_owner(parts,rendered=owner.rendered_owner,keys=keys)
        self.assertIs(type(result),IOSEmoteCallbackKeyedRetirement);self.assertEqual([],self.constructors)
        self.assertTrue(self.guards);self.assertTrue(all(scope is None for scope in self.guards))
