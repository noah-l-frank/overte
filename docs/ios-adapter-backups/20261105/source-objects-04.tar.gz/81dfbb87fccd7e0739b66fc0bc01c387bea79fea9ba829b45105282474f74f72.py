from pathlib import Path
import ast,json,hashlib,difflib
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';P=T/'lifecycle-original-owner-root-three-stage-preparation-20261028';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=T/'lifecycle-owner-exact26-async-setup-root-preparation-20261028/root-supervise.py'
parent='''"""Root-only single fixed source-model stage; no SDK/native execution."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,time
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[2];OUT=HERE/'root-run-first'
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
 p=OUT/name;fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\\n');f.flush();os.fsync(f.fileno())
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode),str(p)
 value=dict(sha256=sha(p)) if stat.S_ISREG(a.st_mode) else {};value['stat']=[getattr(a,k) for k in FIELDS]
 assert value['stat']==[getattr(p.lstat(),k) for k in FIELDS];return value
def process(pid):
 try:v=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):return None
 return dict(pid=pid,parentPid=int(v[1]),pgid=int(v[2]),sid=int(v[3]),startTicks=int(v[19]))
def remaining(binding):
 rows=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  value=process(int(p.name))
  if value is not None and (value['pgid']==binding['pid'] or value['sid']==binding['pid']):rows.append(value)
 return rows
def sources(stage):
 names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\\0');paths={REPO/n for n in names if n};paths.add(REPO/'CMakeLists.txt')
 for relative,digest in json.loads((HERE/'freeze.json').read_text())['files'].items():
  path=HERE/relative;assert sha(path)==digest,str(path);paths.add(path)
 paths.add(HERE/'freeze.json')
 for row in stage['sourcePaths']:paths.add(REPO/row['path'])
 for packet_name,digest in stage['orderedParentFreezes'].items():
  packet=REPO/'.ios-host-tmp'/packet_name;assert sha(packet/'freeze.json')==digest
  paths.add(packet/'freeze.json')
  for relative,expected in json.loads((packet/'freeze.json').read_text())['files'].items():
   path=packet/relative;assert sha(path)==expected,str(path);paths.add(path)
 for row in json.loads((HERE/'sdk-original-pins.json').read_text()):
  for key in ('path','copy'):
   path=Path(row[key]);assert sha(path)==row['sha256'];paths.add(path)
 return {str(path):pin(path) for path in sorted(paths)}
def census(root):return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
assert Path.cwd()==REPO and sys.dont_write_bytecode
for name,expected in json.loads((HERE/'freeze.json').read_text())['files'].items():assert sha(HERE/name)==expected,name
stage=json.loads((HERE/'source-manifest.json').read_text());expected={row['path']:row['candidateSHA256'] for row in stage['sourcePaths']}
for relative,digest in expected.items():assert sha(REPO/relative)==digest,relative
OUT.mkdir(mode=0o700,exist_ok=False)
before=sources(stage);save('source-before.json',before)
current={str(Path(path).relative_to(REPO)):row['sha256'] for path,row in before.items() if Path(path).is_relative_to(REPO) and '.ios-host-tmp' not in Path(path).relative_to(REPO).parts and 'sha256' in row}
config=dict(repositoryRoot=str(REPO),currentSourcePins=current,reviewedCandidates=expected)
save('root-source-map.json',config);map_pin=pin(OUT/'root-source-map.json')
settings=json.loads((HERE/'supervisor-plan.json').read_text());env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1')
for key,value in settings['environmentFiles'].items():env[key]=str(HERE/value);env[key+'_SHA256']=sha(HERE/value)
map_key=settings['rootMapEnvironment'];env[map_key]=str(OUT/'root-source-map.json');env[map_key+'_SHA256']=sha(OUT/'root-source-map.json')
root=HERE/settings['retainedDirectory'];assert not root.exists()
command=['timeout','--signal=TERM','--kill-after=5s',str(settings['initialSeconds'])+'s',sys.executable,str(HERE/'root-child.py')]
print('SOURCE_PINS',len(before),flush=True);started=time.monotonic()
with (OUT/'first.log').open('x') as log:
 task=subprocess.Popen(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 bound=process(task.pid);assert bound is not None and bound['sid']==bound['pgid']==task.pid
 save('process-binding.json',dict(task=bound,supervisor=process(os.getpid()),command=command));print('ACTUAL_PROCESS',json.dumps(bound),flush=True);code=task.wait()
assert not remaining(bound),'Owned process remains before original census'
after=sources(stage);save('source-after.json',after)
first=census(root) if root.exists() else {};assert not remaining(bound),'Owned process remains before second census'
second=census(root) if root.exists() else {};save('originals-first.json',first);save('originals-second.json',second)
left=remaining(bound);report=dict(exitCode=code,seconds=time.monotonic()-started,sourcePins=len(after),allPinsEqual=before==after,
 rootMapUnchanged=pin(OUT/'root-source-map.json')==map_pin,retainedOriginalsUnchanged=first==second,
 retainedFiles=sum(stat.S_ISREG(row['stat'][2]) for row in first.values()),remainingOwnedProcesses=left,
 nativeCompiled=False,actualAuthenticationQualified=False,wholeFeatureQualified=False)
save('report.json',report);print('ACTUAL_TERMINAL',json.dumps(report),flush=True)
assert before==after and first==second and not left and pin(OUT/'root-source-map.json')==map_pin
raise SystemExit(code)
'''
child='''"""Run exact reviewed stage; record actual owned thread teardown."""
import json,os,runpy,sys,threading
from pathlib import Path
HERE=Path(__file__).resolve().parent;before=set(threading.enumerate());code=1
try:
 runpy.run_path(str(HERE/ENTRY),run_name='__main__');code=0
except SystemExit as result:code=result.code
finally:
 remaining=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in before and t.is_alive()]
 with (HERE/'root-run-first/thread-report.json').open('x') as output:
  json.dump(dict(remainingNewThreads=remaining,exitCode=code),output,indent=2);output.write('\\n');output.flush();os.fsync(output.fileno())
 assert not remaining,'Actual fixture/worker thread remains live'
raise SystemExit(code)
'''
sdk=json.loads((T/'lifecycle-original-owner-final-lifetime-integration-20261028/test-plan.json').read_text())['sdkOriginals']
for dirname,cap,entry,retained in [('01-final35',90,'run-exact35.py','retained-exact35-first'),('02-resource11',90,'run-selected.py','retained-first'),('03-motion7',180,'run-selected.py','retained-first')]:
 stage=P/dirname
 helper=stage/'source_model_bindings.py';s=helper.read_text();s=s.replace('import ast,hashlib,json,marshal,os,stat,uuid','from __future__ import annotations\nimport ast,hashlib,json,marshal,os,stat,uuid');ast.parse(s);helper.write_text(s)
 (stage/'sdk-original-pins.json').write_text(json.dumps(sdk,indent=2)+'\n')
 (stage/'root-supervise.py').write_text(parent);ast.parse(parent)
 c=child.replace('HERE=Path(__file__).resolve().parent;',f'HERE=Path(__file__).resolve().parent;ENTRY={entry!r};');(stage/'root-child.py').write_text(c);ast.parse(c)
 (stage/'parent-clone.diff').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),parent.splitlines(True),fromfile='root-approved-exact26-parent.py',tofile=dirname+'/root-supervise.py')))
 provenance=dict(originalParent=str(old),originalParentSHA256=h(old),newParentSHA256=h(stage/'root-supervise.py'),newChildSHA256=h(stage/'root-child.py'),scope='Same fixed timeout/process/session binding/source-before-after/two-original-census lifecycle; adjusted input manifests and stage selected launcher only; no execution.')
 (stage/'clone-provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
 if dirname=='01-final35':
  # Existing literal35 IDs; add canonical nested namespace checks before imports.
  run=stage/'run-exact35.py';s=run.read_text();marker="    retained=HERE/'retained-exact35-first';retained.mkdir(mode=0o700,exist_ok=False)";addition="""    for name,relative in {'ios.adapters':'tests/device/ios/adapters','ios.self_tests':'tests/device/ios/self_tests'}.items():
        spec=PathFinder._get_spec(name,[str(repo/'tests/device/ios')])
        if spec is None or [str(Path(p).resolve()) for p in spec.submodule_search_locations or ()]!=[str(repo/relative)]:raise RuntimeError('Canonical nested namespace mismatch before target import')
""";assert s.count(marker)==1;s=s.replace(marker,addition+marker);ast.parse(s);run.write_text(s)
  m=json.loads((stage/'manifest.json').read_text());m['modelFiles']['source_model_bindings.py']=h(helper);m['modelFiles']['root_stage_guard.py']=h(stage/'root_stage_guard.py');m['launcherSHA256']=h(run);(stage/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
  files={'LIFECYCLE_FINAL_PLAN':'test-plan.json','LIFECYCLE_FINAL_MANIFEST':'manifest.json','LIFECYCLE_FINAL_PYTHON8':'test_owner_readonly_preflight_models.py','LIFECYCLE_FINAL_PYTHON3':'test_existing_wda_route_models.py','LIFECYCLE_FINAL_NODE9':'test_actual_loaded_owner_routes.mjs'}
  # Original runner names use _SHA256 without an intermediate file env for plans.
  env={k+'_SHA256':h(stage/v) for k,v in files.items()}
  # Parent environmentFiles creates NAME + NAME_SHA256, matching its original interface.
  environmentFiles=files;mapkey='LIFECYCLE_FINAL_ROOT_MAP'
 else:
  plan=json.loads((stage/'run-plan.json').read_text());plan['privateFiles']['source_model_bindings.py']=h(helper);plan['privateFiles']['root_stage_guard.py']=h(stage/'root_stage_guard.py');(stage/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
  environmentFiles={'LIFECYCLE_STAGE_MANIFEST':'source-manifest.json','LIFECYCLE_STAGE_PLAN':'run-plan.json'};mapkey='LIFECYCLE_STAGE_ROOT_MAP'
 settings=dict(initialSeconds=cap,killAfterSeconds=5,rootMapEnvironment=mapkey,environmentFiles=environmentFiles,retainedDirectory=retained,entry=entry,sourceModelsOnly=True,noSDKImport=True,authQualified=False,nativeTouch=False)
 (stage/'supervisor-plan.json').write_text(json.dumps(settings,indent=2)+'\n')
# Root stage3 applies only the registry delta after stage2, preserving unrelated keys.
for dirname,previous in [('02-resource11',None),('03-motion7','02-resource11')]:
 stage=P/dirname;diff=[]
 for rel in ('tests/device/contract-versions.json','tests/device/validate_contract_versions.py'):
  oldpath=R/rel if previous is None else P/previous/'registry-candidate'/rel;newpath=stage/'registry-candidate'/rel
  diff.extend(difflib.unified_diff(oldpath.read_text().splitlines(True),newpath.read_text().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 (stage/'registry-after-previous-stage.diff').write_text(''.join(diff))
print('Parent clones prepared; no launcher/source/SDK/model executed.')
