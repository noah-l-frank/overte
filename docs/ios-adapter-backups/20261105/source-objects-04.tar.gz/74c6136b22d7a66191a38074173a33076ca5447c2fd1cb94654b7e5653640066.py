"""Controller-only genuine allocation custody; no Tablet/native authority.

Source-only component. The complete selected runner is not supplied here.
"""
from pathlib import Path
import os, stat, sys, tempfile, threading, types

class CustodyRefusal(RuntimeError):pass

class FunctionBinding:
    def __init__(self,function):
        if type(function)is not types.FunctionType:raise CustodyRefusal('Actual Python function required')
        self.function=function;self.code=function.__code__;self.namespace=function.__globals__
        self.defaults=function.__defaults__;self.keywords=function.__kwdefaults__;self.closure=function.__closure__
        self.values=tuple(self.defaults or ());self.items=tuple((self.keywords or {}).items())
        self.cells=tuple(cell.cell_contents for cell in self.closure or ())
    def guard(self):
        f=self.function
        if (f.__code__ is not self.code or f.__globals__ is not self.namespace
                or f.__defaults__ is not self.defaults or f.__kwdefaults__ is not self.keywords
                or f.__closure__ is not self.closure):raise CustodyRefusal('Original function binding changed')
        if len(self.defaults or ())!=len(self.values)or any(a is not b for a,b in zip(self.defaults or (),self.values)):
            raise CustodyRefusal('Original defaults changed')
        if tuple(self.keywords or ())!=tuple(k for k,v in self.items)or any(self.keywords[k]is not v for k,v in self.items):
            raise CustodyRefusal('Original keyword defaults changed')
        if any(c.cell_contents is not v for c,v in zip(self.closure or (),self.cells)):
            raise CustodyRefusal('Original closure cell changed')
    def frame(self,frame):
        self.guard()
        if frame.f_code is not self.code or frame.f_globals is not self.namespace:
            raise CustodyRefusal('Foreign constructor frame/code/globals')

class RealTemporaryDirectoryRetention:
    """Retain real TD objects without breaking run_open's bound cleanup lookup."""
    def __init__(self,root,constructors,retain_function):
        self.root=Path(root).resolve(strict=True);self.thread=threading.current_thread()
        if not self.root.is_dir()or self.root.is_symlink():raise CustodyRefusal('Actual owned TD parent required')
        self.original=tempfile.TemporaryDirectory;self.retain=FunctionBinding(retain_function)
        self.constructors=tuple((cls,FunctionBinding(setup))for cls,setup in constructors)
        if len(self.constructors)!=2:raise CustodyRefusal('Exactly the two genuine setup constructors')
        self.rows=[];self.objects=[];self.preservers={};self.installed=False
        owner=self;original=self.original
        class RetainedTemporaryDirectory(original):
            def __init__(directory,*args,**kwargs):
                owner.guard();frame=sys._getframe(1)
                matches=[(cls,binding)for cls,binding in owner.constructors
                    if frame.f_code is binding.code and frame.f_globals is binding.namespace
                    and type(frame.f_locals.get('self'))is cls]
                if len(matches)!=1 or args or kwargs or len(owner.objects)>=2:
                    raise CustodyRefusal('Only an original no-argument setup TD allocation')
                cls,binding=matches[0];binding.frame(frame)
                if cls.__dict__.get('setUp')is not binding.function:raise CustodyRefusal('Actual setup member changed')
                super().__init__(dir=str(owner.root))
                path=Path(directory.name)
                if path.resolve(strict=True)!=path or path.parent!=owner.root:raise CustodyRefusal('TD escaped real own root')
                owner.retain.guard();owner.retain.function(directory,expected_root=path)
                # retain_owned_root actually detached the original finalizer.
                # Keep its real preserve closure, then restore a bound cleanup
                # interface on this same actual TD for run_open's genuine search.
                preserve=directory.cleanup
                if not callable(preserve)or directory._finalizer.alive:raise CustodyRefusal('Real retention did not detach')
                owner.preservers[directory]=FunctionBinding(preserve)
                directory.cleanup=types.MethodType(type(directory).cleanup,directory)
                if directory.cleanup.__self__ is not directory or directory.cleanup.__name__!='cleanup':
                    raise CustodyRefusal('Bound real TD cleanup interface lost')
                info=path.lstat();owner.objects.append(directory)
                owner.rows.append(dict(path=str(path),device=info.st_dev,inode=info.st_ino,
                    setup=binding.code.co_filename,constructor=cls.__module__+'.'+cls.__qualname__))
            def cleanup(directory):
                owner.guard();binding=owner.preservers.get(directory)
                if binding is None:raise CustodyRefusal('Unknown TD cleanup receiver')
                binding.guard();binding.function()
        self.actual_class=RetainedTemporaryDirectory
        self.class_members=tuple((key,value,value.__code__)for key,value in vars(self.actual_class).items()
            if type(value)is types.FunctionType)
    def guard(self):
        if threading.current_thread()is not self.thread:raise CustodyRefusal('TD creation/cleanup from foreign thread')
        if tempfile.TemporaryDirectory is not(self.actual_class if self.installed else self.original):
            raise CustodyRefusal('Actual TemporaryDirectory port changed')
        self.retain.guard()
        for cls,binding in self.constructors:binding.guard()
        for key,value,code in self.class_members:
            if vars(self.actual_class).get(key)is not value or value.__code__ is not code:
                raise CustodyRefusal('Retention class implementation changed')
        for directory,binding in self.preservers.items():
            binding.guard()
            if directory._finalizer.alive:raise CustodyRefusal('Retained TD finalizer revived')
    def install(self):
        self.guard()
        if self.installed:raise CustodyRefusal('Repeated TD port installation')
        tempfile.TemporaryDirectory=self.actual_class;self.installed=True;self.guard()
    def restore(self):
        self.guard()
        for directory,binding in self.preservers.items():binding.function()
        tempfile.TemporaryDirectory=self.original;self.installed=False;self.guard()
        return dict(actualTemporaryDirectories=len(self.objects),realRootsRetained=list(self.rows),
            originalTemporaryDirectoryRestored=True,productOwnerReconstructed=False)

class OwnedArenaConfiguration:
    """A scoped real Arena directory choice, never a replacement Value/mmap."""
    def __init__(self,root,heap_module,paired_constructor):
        self.root=Path(root).resolve(strict=True);self.heap=heap_module;self.arena=heap_module.Arena
        self.original_candidates=self.arena._dir_candidates
        self.candidates=[str(self.root)]
        self.constructor=FunctionBinding(self.arena.__init__)
        self.choose=FunctionBinding(self.arena._choose_dir)
        self.paired=FunctionBinding(paired_constructor)
        self.main=threading.current_thread();self.installed=False;self.entries={};self.arenas=[]
        self.fstat=os.fstat;self.readlink=os.readlink
        self.root_identity=self.signature(self.root.lstat())
    @staticmethod
    def signature(info):return(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid)
    def guard(self):
        if threading.current_thread()is not self.main:raise CustodyRefusal('Arena gate used from foreign thread')
        if self.heap.Arena is not self.arena or self.arena.__init__ is not self.constructor.function:
            raise CustodyRefusal('Actual Arena constructor changed')
        if self.arena._choose_dir is not self.choose.function:raise CustodyRefusal('Actual Arena chooser changed')
        self.constructor.guard();self.choose.guard();self.paired.guard()
        expected=self.candidates if self.installed else self.original_candidates
        if self.arena._dir_candidates is not expected:raise CustodyRefusal('Scoped Arena directory object changed')
        if self.installed and(self.candidates!=[str(self.root)]or self.signature(self.root.lstat())!=self.root_identity):
            raise CustodyRefusal('Real own Arena parent changed')
        if os.fstat is not self.fstat or os.readlink is not self.readlink:raise CustodyRefusal('Actual FD readers changed')
    def install(self):
        self.guard()
        if self.installed:raise CustodyRefusal('Arena scope reused')
        self.arena._dir_candidates=self.candidates;self.installed=True;self.guard()
    def begin(self,frame):
        self.guard();self.constructor.frame(frame)
        owner=frame.f_locals.get('self')
        if type(owner)is not self.arena or frame.f_locals.get('fd')!=-1:raise CustodyRefusal('Only a real fresh parent Arena')
        parent=frame.f_back;found=False
        while parent is not None:
            if parent.f_code is self.paired.code and parent.f_globals is self.paired.namespace:found=True;break
            parent=parent.f_back
        if not found or self.entries or self.arenas:raise CustodyRefusal('Unexpected Arena birth or caller')
        self.entries[owner]=(frame,self.fd_table())
    def returned(self,frame):
        self.guard();self.constructor.frame(frame);owner=frame.f_locals.get('self')
        previous=self.entries.pop(owner,None)
        if previous is None or previous[0]is not frame:raise CustodyRefusal('Unobserved original Arena return')
        info=self.fstat(owner.fd)
        if not stat.S_ISREG(info.st_mode)or owner.buffer.closed or owner.buffer.size()!=owner.size:
            raise CustodyRefusal('Actual live Arena FD/mmap required')
        target=self.readlink('/proc/self/fd/'+str(owner.fd))
        if not target.startswith(str(self.root)+'/')or not target.endswith(' (deleted)'):
            raise CustodyRefusal('Arena did not really create/unlink its own file')
        after=self.fd_table();before=previous[1];added={fd:row for fd,row in after.items()if fd not in before}
        if not added or any((row['device'],row['inode'])!=(info.st_dev,info.st_ino)for row in added.values()):
            raise CustodyRefusal('Unknown FD acquired during real Arena constructor')
        self.arenas.append((owner,owner.buffer,dict(actualFD=owner.fd,device=info.st_dev,inode=info.st_ino,
            size=owner.size,actualDescriptors=added,ordinaryFileAlreadyUnlinked=True)))
    def fd_table(self):
        result={}
        for path in Path('/proc/self/fd').iterdir():
            try:
                fd=int(path.name);info=self.fstat(fd)
                result[str(fd)]=dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,target=self.readlink(path))
            except(FileNotFoundError,ProcessLookupError,OSError):continue
        return result
    def restore(self):
        self.guard()
        if self.entries:raise CustodyRefusal('Unreturned actual Arena constructor')
        self.arena._dir_candidates=self.original_candidates;self.installed=False;self.guard()
        return dict(originalArenaDirectoryObjectRestored=True,actualArenaRows=[row for unused,unused2,row in self.arenas],
            cachedResourcesClaimedClosed=False,retirementBoundary='actual parent process exit',
            noDevShmFileWritePermission=True)
