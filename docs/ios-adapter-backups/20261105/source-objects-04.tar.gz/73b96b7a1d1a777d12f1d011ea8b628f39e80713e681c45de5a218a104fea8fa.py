"""Prospective real host WAL/OFS/file constructors; native+SDK wire is MODEL.

The transport seam calls the declared source over a real own host FD/file.
No native executable, HTTP endpoint, physical target or End is qualified.
"""
from copy import deepcopy
from pathlib import Path
import base64,json,unittest
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.feature_observation import FeatureObservation
from ios.adapters import emote_palette_file_delivery as module
from ios.adapters.emote_palette_file_delivery import PaletteFileDelivery,PaletteFileHistory,delivery,RESPONSE_FILE
from ios.adapters.emote_post_controller_copied_role import Profile9RoleState
from ios.adapters.emote_post_controller_end_join import Profile9FamilyFence,Profile9CreatorOriginalJoin
from ios.self_tests.test_ios_emote_post_controller_end_owned import PostControllerEndOwnedTests,DeclaredFileWire


class DeclaredDeliveryBoundary:
    def __init__(self,case):
        self.fixture=PostControllerEndOwnedTests('test_real_completed_family_copy_preserves_old_original_and_never_grants_end')
        case.addCleanup(self.fixture.doCleanups);self.fixture.setUp();self.domain=self.fixture.domain
        self.wire=DeclaredFileWire(case,self.domain);self.calls=[];self.lost=False;self.query=None;self.allow=True
        self.path=self.domain.root/RESPONSE_FILE;self.time=2.;self.native=100000
        boundary=self
        class OwnFileClient:
            def execute(self,session,operation,args):
                case.assertEqual(boundary.wire.binding['sessionId'],session)
                case.assertEqual('mobile: pullFile',operation)
                case.assertTrue(args['remotePath'].endswith('/'+RESPONSE_FILE))
                return base64.b64encode(boundary.path.read_bytes()).decode()if boundary.path.exists()else''
        target=dict(platform='ios',physical=True,probe=dict(kind='ios-documents'),appId='org.example.overte',
            testBuild=dict(resultsDirectory='results',fixtureOrigin='http://127.0.0.1:1'))
        # Actual FeatureObservation constructor; the lower process/transport is
        # explicitly modeled. It is never a positive physical target claim.
        self.observer=FeatureObservation(OwnFileClient(),self.wire.binding['sessionId'],target,
            lambda:dict(bundleId=target['appId'],pid=31,foreground=True),monotonic=self.monotonic,sleep=self.sleep,epoch_ms=self.epoch)
    def monotonic(self):return self.time
    def epoch(self):return self.time*1000
    def sleep(self,seconds):self.time+=seconds
    def clock(self):
        value=self.native;self.native+=10;self.time+=.001;return value
    def guard(self):
        if not self.allow:raise NativeUIError('Declared live creator guard unavailable')
        return True
    def send(self,origin,query,limit,*,before_send=None,after_send=None):
        before_send();self.query=deepcopy(query);self.calls.append(deepcopy(query))
        if query['operation']=='retire':self.wire.unlink_own_model_file()
        original=self.wire.value(query)
        # No prior palette/raw original is retimed; this is the fresh declared
        # result producer's own clock, not a change to a saved original.
        for key in('clockBefore','clockAfter'):
            original[key]=dict(epochMs=self.native-9,monotonicMs=self.native-9)
        value=dict(iosEmotePaletteFileDeliveryVersion=1,requestId=query['commandId'],runId=query['runId'],responseFile=RESPONSE_FILE,original=original)
        self.path.write_text(json.dumps(value));self.path.chmod(0o600);after_send()
        if self.lost:raise OSError('Declared lost original transport return AFTER real own result file write')
    def owner(self):
        d=self.domain
        return PaletteFileDelivery(self.observer,PrivateFeatureState(d.root/('ios-emote-primary-'+d.run+'-palette-file-delivery.json')),
            d.root,self.wire.binding,d.run,d.lock,self.clock,self.guard,monotonic=self.monotonic,epoch_ms=self.epoch,sleep=self.sleep)
    def history(self):
        owner=self.owner();return PaletteFileHistory(owner.store,owner.root,owner.binding,owner.run,owner.lock)


class PaletteFileDeliveryTests(unittest.TestCase):
    def setUp(self):self.boundary=DeclaredDeliveryBoundary(self)
    def test_real_constructor_journal_retains_actual_original_and_existing_response_duty(self):
        b=self.boundary;owner=b.owner()
        with patch.object(module,'send_original_command',b.send):value=owner.request()
        self.assertEqual(b.query,value['query']);self.assertEqual(1,len(b.calls));self.assertEqual(1,len(owner.state['records']))
        history=PaletteFileHistory(owner.store,owner.root,owner.binding,owner.run,owner.lock)
        self.assertEqual(value,history.original(history.state['records'][0]));self.assertFalse(hasattr(history,'request'))
        self.assertTrue(owner.responsibility()['responseProcessLifetimeRequired']);self.assertFalse(owner.responsibility()['EndAllowed'])
    def test_lost_actual_transport_return_reopens_without_resending_query(self):
        b=self.boundary;b.lost=True;owner=b.owner()
        with patch.object(module,'send_original_command',b.send),self.assertRaises(OSError):owner.request()
        self.assertIsNotNone(owner.state['pending']);saved=owner.store.path.read_bytes()
        b.lost=False;reopened=b.owner()
        with patch.object(module,'send_original_command',side_effect=AssertionError('No query replay')):value=reopened.recover()
        self.assertEqual(1,len(b.calls));self.assertEqual(b.query,value['query']);self.assertNotEqual(saved,owner.store.path.read_bytes())
    def test_actual_retirement_original_does_not_retire_response_file_or_grant_end(self):
        b=self.boundary;owner=b.owner()
        with patch.object(module,'send_original_command',b.send):
            prior=owner.request()['delivery']['original']['source']['ownership'];value=owner.request('retire',owned=prior)
        self.assertEqual('retired',value['delivery']['original']['source']['ownership']['phase'])
        self.assertFalse(b.wire.path.exists());self.assertTrue(b.path.exists());self.assertFalse(owner.responsibility()['EndAllowed'])
        with self.assertRaises(NativeUIError):owner.request()
        self.assertEqual(2,len(b.calls))
    def test_historical_constructor_survives_real_lost_live_guard_without_faking_live_owner(self):
        b=self.boundary;owner=b.owner()
        with patch.object(module,'send_original_command',b.send):value=owner.request()
        b.allow=False
        with self.assertRaises(NativeUIError):owner.bound()
        archived=PaletteFileHistory(owner.store,owner.root,owner.binding,owner.run,owner.lock)
        self.assertEqual(value,archived.original(archived.state['records'][0]));self.assertNotIsInstance(archived,PaletteFileDelivery)
    def test_same_bytes_replacement_of_historical_journal_inode_refuses(self):
        b=self.boundary;owner=b.owner()
        with patch.object(module,'send_original_command',b.send):owner.request()
        archived=PaletteFileHistory(owner.store,owner.root,owner.binding,owner.run,owner.lock);path=owner.store.path;raw=path.read_bytes()
        path.rename(path.with_name(path.name+'.retained'));path.write_bytes(raw);path.chmod(0o600)
        with self.assertRaises(NativeUIError):archived.bound()
    def test_foreign_native_creator_run_filename_and_old_sequence_refuse(self):
        b=self.boundary;owner=b.owner()
        with patch.object(module,'send_original_command',b.send):value=owner.request()
        for key,replacement in(('runId','f'*32),('responseFile','foreign.json')):
            bad=deepcopy(value['delivery']);bad[key]=replacement
            with self.assertRaises(NativeUIError):delivery(bad,value['query'],owner.binding)
        foreign=deepcopy(owner.binding);foreign['processIdentity']='32'
        with self.assertRaises(NativeUIError):delivery(value['delivery'],value['query'],foreign)
        with self.assertRaises(NativeUIError):delivery(value['delivery'],value['query'],owner.binding,value['delivery'])
    def test_unresolved_journal_cannot_create_historical_success_or_new_request(self):
        b=self.boundary;b.lost=True;owner=b.owner()
        with patch.object(module,'send_original_command',b.send),self.assertRaises(OSError):owner.request()
        b.path.unlink()
        with self.assertRaises(NativeUIError):PaletteFileHistory(owner.store,owner.root,owner.binding,owner.run,owner.lock)
        with patch.object(module,'send_original_command',side_effect=AssertionError('Unknown cannot resend')),self.assertRaises(NativeUIError):b.owner().request()
        self.assertEqual(1,len(b.calls))
    def test_legacy_or_empty_roles_cannot_become_profile9_fence_or_creator_end(self):
        b=self.boundary;owner=b.owner()
        with self.assertRaises(NativeUIError):Profile9RoleState({},store=owner.store,run=owner.run,role='primary',locks=dict(primary=b.domain.lock,actor=b.domain.lock))
        with self.assertRaises(NativeUIError):Profile9FamilyFence({}, {})
        with self.assertRaises(NativeUIError):Profile9CreatorOriginalJoin(None,owner,None,{},source={},bundle={})
