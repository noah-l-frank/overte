"""UNRUN controller template. No launch until an exact reviewed map is frozen."""
from pathlib import Path
import hashlib,importlib.util,json,os,signal,stat,subprocess,sys,threading,time,traceback

HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent
EXPECTED_MAP='c6e84f35d42812c68bddab981c045bf4a6cc1a7f3cbc4875c978d5f1643e2a6d'
EXPECTED_HEAD='00fafcc4c097552198456c7e7687f243801d3ed8'
BUDGET=180
GRACE=5

def digest(raw):return hashlib.sha256(raw).hexdigest()
def save(name,body):
    path=HERE/name
    with path.open('x')as stream:stream.write(json.dumps(body,sort_keys=True,indent=2)+'\n')
    path.chmod(0o600)

def metadata(info):
    return dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,uid=info.st_uid,gid=info.st_gid,
        nlink=info.st_nlink,bytes=info.st_size,mtimeNs=info.st_mtime_ns,ctimeNs=info.st_ctime_ns)

def file_pin(path):
    path=Path(path);before=path.lstat()
    assert stat.S_ISREG(before.st_mode)and before.st_nlink==1 and not path.is_symlink()
    descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        actual=os.fstat(descriptor);assert metadata(actual)==metadata(before)
        with os.fdopen(descriptor,'rb',closefd=False)as stream:raw=stream.read()
        assert metadata(os.fstat(descriptor))==metadata(before)and metadata(path.lstat())==metadata(before)and len(raw)==before.st_size
    finally:os.close(descriptor)
    return dict(metadata(before),sha256=digest(raw))

def census(root):
    root=Path(root);rows={}
    def visit(path):
        info=path.lstat()
        if stat.S_ISDIR(info.st_mode):
            assert not path.is_symlink()
            with os.scandir(path)as stream:names=sorted(item.name for item in stream)
            row=dict(metadata(info),namespace=names)
            for name in names:visit(path/name)
            assert metadata(path.lstat())==metadata(info)
        else:row=file_pin(path)
        rows[str(path.relative_to(root))]=row
    visit(root);return rows

def kernel_identity(pid):
    try:raw=Path('/proc')/str(pid)/'stat';text=raw.read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    fields=text[text.rfind(')')+2:].split()
    return dict(pid=int(text[:text.index('(')].strip()),parent=int(fields[1]),group=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))

def process_table():
    rows={}
    for entry in Path('/proc').iterdir():
        if entry.name.isdecimal():
            value=kernel_identity(int(entry.name))
            if value is not None:rows[value['pid']]=value
    return rows

def fd_census():
    rows={}
    for entry in Path('/proc/self/fd').iterdir():
        try:
            target=os.readlink(entry);info=entry.stat()
            rows[entry.name]=dict(target=target,device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return rows

def current_head():
    git=REPO/'.git'
    if git.is_file():git=Path(git.read_text().strip().split('gitdir: ',1)[1]);git=git if git.is_absolute()else REPO/git
    head=(git/'HEAD').read_text().strip()
    if not head.startswith('ref: '):return head
    ref=head[5:];common=git
    if(git/'commondir').is_file():common=(git/(git/'commondir').read_text().strip()).resolve(strict=True)
    for base in (git,common):
        if(base/ref).is_file():return(base/ref).read_text().strip()
    for line in(common/'packed-refs').read_text().splitlines():
        if not line.startswith(('#','^'))and line.split(' ',1)[1]==ref:return line.split(' ',1)[0]
    raise AssertionError('Exact checkout HEAD cannot be resolved')

def supervisor():
    assert sys.dont_write_bytecode and current_head()==EXPECTED_HEAD
    parent_fd_before=fd_census();parent_threads_before=tuple(threading.enumerate())
    assert len(sys.argv)==2,'Root supplies the separately reviewed literal freeze SHA'
    freeze_raw=(HERE/'freeze.json').read_bytes();assert digest(freeze_raw)==sys.argv[1]
    freeze=json.loads(freeze_raw)
    for name,row in freeze['files'].items():assert digest((HERE/name).read_bytes())==row['sha256']
    raw=(HERE/'preimport-map.json').read_bytes();assert digest(raw)==EXPECTED_MAP
    plan=json.loads(raw);assert plan['root']==str(HERE)and plan['reportedRootHead']==EXPECTED_HEAD
    assert len(plan['cases'])==14 and len(set(plan['cases']))==14
    assert plan['historicalLock']is None and plan['historicalCorpus']is None
    paths={Path(row['path'])for row in plan['modules'].values()}|{Path(row['path'])for row in plan['frozenPackets']}
    paths|={HERE/name for name in plan['controllerFiles']}
    paths|={Path(sys.executable).resolve(strict=True),HERE/'preimport-map.json',HERE/'freeze.json'}
    before={str(path):file_pin(path)for path in sorted(paths)}
    for name in plan['controllerFiles']:assert before[str(HERE/name)]['sha256']==freeze['files'][name]['sha256']
    for row in list(plan['modules'].values())+plan['frozenPackets']:assert before[str(Path(row['path']))]['sha256']==row['sha256']
    save('external-all-source-binary-pins-before.json',before)
    global_path=HERE/'global_original_corpus.py'
    global_spec=importlib.util.spec_from_file_location('audio_own14_external_global_census',global_path)
    global_guard=importlib.util.module_from_spec(global_spec);global_spec.loader.exec_module(global_guard)
    global_before=global_guard.guard();save('external-global-originals-before.json',global_before)
    raw_root=HERE/'temporary';assert not raw_root.exists();raw_root.mkdir(mode=0o700)
    baseline=process_table();owned={};born=None;process=None;timed_out=False;forced=False;problems=[];term_at=None
    started=time.monotonic()
    try:
        with(HERE/'original-child-stdin.eof').open('xb')as empty:pass
        with(HERE/'original-child-stdin.eof').open('rb')as incoming,(HERE/'original-child-stdout.log').open('xb')as output,(HERE/'original-child-stderr.log').open('xb')as error:
            process=subprocess.Popen([sys.executable,'-B',str(HERE/'run-exact.py')],cwd=REPO,stdin=incoming,stdout=output,stderr=error,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
        born=kernel_identity(process.pid)
        assert born is not None and born['parent']==os.getpid()and born['group']==born['pid']and born['session']==born['pid']
        owned[born['pid']]=born;save('external-child-birth.json',born)
        while True:
            table=process_table()
            # The target admits no child creation. Any actual descendant or
            # same-session/group birth is retained and makes the result fail.
            changed=True
            while changed:
                changed=False
                for pid,row in table.items():
                    if pid in owned:continue
                    if row['parent']in owned or row['group']==born['group']or row['session']==born['session']:
                        assert pid not in baseline,'Pre-existing process cannot become target authority'
                        owned[pid]=row;problems.append(dict(kind='forbidden-descendant-birth',identity=row));changed=True
            for pid,identity in owned.items():
                fresh=kernel_identity(pid)
                if fresh is not None and fresh!=identity:problems.append(dict(kind='bound-identity-changed',before=identity,after=fresh))
            code=process.poll();elapsed=time.monotonic()-started
            if code is not None:break
            if elapsed>=BUDGET and term_at is None:
                timed_out=True;term_at=time.monotonic()
                assert kernel_identity(born['pid'])==born
                os.kill(born['pid'],signal.SIGTERM)
            if term_at is not None and time.monotonic()-term_at>=GRACE:
                forced=True
                assert kernel_identity(born['pid'])==born
                os.kill(born['pid'],signal.SIGKILL)
                process.wait();break
            time.sleep(0.05)
        process.wait()
    except BaseException:
        problems.append(dict(kind='supervisor-original-exception',traceback=traceback.format_exc()))
    finally:
        # Signals are permitted only for identities actually born under this
        # exact runner. A recycled PID is never a signal target.
        residual=[]
        for pid,identity in owned.items():
            fresh=kernel_identity(pid)
            if fresh is not None:
                residual.append(dict(identity=identity,current=fresh))
                if fresh==identity:os.kill(pid,signal.SIGKILL)
        if process is not None:process.wait()
        if residual:problems.append(dict(kind='post-runner-orphans-required-kill',identities=residual))
        remaining=[dict(bound=value,current=kernel_identity(pid))for pid,value in owned.items()if kernel_identity(pid)is not None]
        if remaining:problems.append(dict(kind='own-processes-remain',identities=remaining))
        save('external-process-drain.json',dict(birth=born,owned=list(owned.values()),postRunnerOrphans=residual,remaining=remaining,timedOut=timed_out,forcedKill=forced))
        # No corpus scan occurs until every bound child is actually absent.
        assert not remaining,'Refuse a quiet-corpus claim while any own process remains'
        global_first=global_guard.guard(new_root=raw_root);save('external-global-originals-first.json',global_first)
        first=census(raw_root);save('external-raw-first.json',first)
        global_second=global_guard.guard(new_root=raw_root);save('external-global-originals-second.json',global_second)
        second=census(raw_root);save('external-raw-second.json',second)
        after={str(path):file_pin(path)for path in sorted(paths)};save('external-all-source-binary-pins-after.json',after)
        assert current_head()==EXPECTED_HEAD
        report=json.loads((HERE/'report.json').read_text())if(HERE/'report.json').is_file()else None
        restore=json.loads((HERE/'write-port-restoration.json').read_text())if(HERE/'write-port-restoration.json').is_file()else None
        parent_fd_after=fd_census();parent_threads_after=tuple(threading.enumerate())
        save('external-parent-fd-thread-drain.json',dict(fdBefore=parent_fd_before,fdAfter=parent_fd_after,fdUnchanged=parent_fd_before==parent_fd_after,threadsUnchanged=parent_threads_before==parent_threads_after,threads=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)for thread in parent_threads_after]))
        passed=global_first==global_second and parent_fd_before==parent_fd_after and parent_threads_before==parent_threads_after and process is not None and process.returncode==0 and not problems and not timed_out and not forced and first==second and before==after
        passed=passed and report is not None and report['status']=='PASS'and report['testsRun']==14 and report['selected']==plan['cases']
        passed=passed and report['originalBuiltinIOUnchanged']and report['originalRegisteredCleanupEstablished']and report['actualFDDrainEstablished']and not report['remainingNewThreads']
        passed=passed and restore is not None and restore['restored']and not restore['controlDescriptors']
        terminal=dict(status='PASS'if passed else'FAIL_OR_REFUSED',childReturnCode=None if process is None else process.returncode,
            elapsedSeconds=time.monotonic()-started,problems=problems,timedOut=timed_out,forcedKill=forced,
            allPinsUnchanged=before==after,twoExternalRawCensusesEqual=first==second,ownProcessesAbsent=not remaining,
            globalOldRoots=len(global_before),oldGlobalOriginalsUnchanged=all(global_first[path]==row for path,row in global_before.items()),twoFullGlobalCensusesEqual=global_first==global_second,rawEntries=len(first),rawRoots=[str(raw_root)],nativeQualified=False,wholeQualified=False)
        save('external-terminal.json',terminal)
    return 0 if passed else 1

if __name__=='__main__':sys.exit(supervisor())
