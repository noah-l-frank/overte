"""Historical loaded frame reuse still checks actual independent originals."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import unittest
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from ios.adapters import chat_archive_round as rounds,chat_qml_cache_loaded
from ios.adapters.chat_draft_owner import IOSChatDraftOwner
from ios.self_tests.chat_loaded_peer_fixture import LoadedPairedFixture

class ChatLoadedHistoricalFrameRoundTests(unittest.TestCase):
    def make(self):
        loaded=LoadedPairedFixture(self);loaded.f.open();return loaded,loaded.f.drafts['primary']
    def archive(self,loaded,draft):
        return IOSChatDraftOwner.archive(draft.f.store,draft.f.root,draft.binding,draft.run,draft.f.lock,
            draft.m.owner.fixture_url,source_bound=True,peer_receipts=loaded.contexts['primary'],
            qml_bound=True,qml_artifact=loaded.artifacts['primary'])
    def test_same_call_historical_frame_reuse_preserves_original_files_queries_and_shared_bounds(self):
        loaded,draft=self.make();files=loaded.f.pair.census();commands=loaded.f.pair.commands()
        queries={role:deepcopy(m.qml_queries) for role,m in loaded.f.models.items()}
        with draft.owner() as live:
            scope=rounds.ArchiveRound(live);token=rounds._ACTIVE.set(scope)
            try:
                archive=self.archive(loaded,draft);ref=archive.state['records'][-1]
                before=scope.frame_hits;first=archive.original(ref);second=archive.original(ref)
                self.assertEqual(first,second);self.assertGreater(scope.frame_hits,before)
                self.assertLessEqual(len(scope.memo)+len(scope.frame_memo),rounds._MAX_ENTRIES)
                self.assertLessEqual(scope.memo_bytes+scope.frame_bytes,rounds._MAX_BYTES)
            finally:
                try:scope.close()
                finally:rounds._ACTIVE.reset(token)
            self.assertFalse(scope.frame_memo);self.assertEqual(0,scope.frame_bytes)
        self.assertEqual(files,loaded.f.pair.census());self.assertEqual(commands,loaded.f.pair.commands())
        self.assertEqual(queries,{role:m.qml_queries for role,m in loaded.f.models.items()})
    def test_actual_loaded_parser_data_change_refuses_an_already_populated_frame_proof(self):
        loaded,draft=self.make();original=deepcopy(chat_qml_cache_loaded.COVERAGE)
        with draft.owner() as live:
            scope=rounds.ArchiveRound(live);token=rounds._ACTIVE.set(scope)
            try:
                archive=self.archive(loaded,draft);ref=archive.state['records'][-1]
                archive.original(ref);before=scope.frame_hits;archive.original(ref);self.assertGreater(scope.frame_hits,before)
                chat_qml_cache_loaded.COVERAGE['importGraphAvailable']=True
                with self.assertRaises(NativeUIError):archive.original(ref)
            finally:
                chat_qml_cache_loaded.COVERAGE.clear();chat_qml_cache_loaded.COVERAGE.update(original)
                try:scope.close()
                finally:rounds._ACTIVE.reset(token)
    def test_same_byte_original_inode_replacement_refuses_an_already_populated_frame_proof(self):
        loaded,draft=self.make()
        with draft.owner() as live:
            ref=live.state['records'][-1];path=live.frames.path(live.frames.expand(ref));raw=path.read_bytes()
            backup=loaded.f.pair.root/'preserved-original-before-same-byte-frame-replacement.json'
            scope=rounds.ArchiveRound(live);token=rounds._ACTIVE.set(scope)
            try:
                archive=self.archive(loaded,draft);archive.original(ref)
                before=scope.frame_hits;archive.original(ref);self.assertGreater(scope.frame_hits,before)
                path.rename(backup);path.write_bytes(raw);path.chmod(0o600)
                with self.assertRaises(NativeUIError):archive.original(ref)
                with self.assertRaises(NativeUIError):scope.close()
                self.assertTrue(scope.closed);self.assertEqual(raw,backup.read_bytes());self.assertEqual(raw,path.read_bytes())
                self.assertNotEqual(backup.stat().st_ino,path.stat().st_ino)
            finally:
                try:
                    if not scope.closed:scope.close()
                finally:rounds._ACTIVE.reset(token)

    def test_frame_proofs_yield_the_unchanged_shared_budget_to_completed_decoder_proofs(self):
        loaded,draft=self.make();files=loaded.f.pair.census();commands=loaded.f.pair.commands()
        # A smaller test-only optimization budget reaches real eviction with
        # a short genuine history. No wire/native/operation limit is changed.
        with patch.object(rounds,'_MAX_ENTRIES',4),draft.owner() as live:
            scope=rounds.ArchiveRound(live);token=rounds._ACTIVE.set(scope)
            try:
                first=self.archive(loaded,draft);second=self.archive(loaded,draft)
                self.assertEqual(first.state,second.state);self.assertFalse(scope.disabled)
                self.assertTrue(scope.memo);self.assertLessEqual(len(scope.memo)+len(scope.frame_memo),4)
                self.assertLessEqual(scope.memo_bytes+scope.frame_bytes,rounds._MAX_BYTES)
            finally:
                try:scope.close()
                finally:rounds._ACTIVE.reset(token)
        self.assertEqual(files,loaded.f.pair.census());self.assertEqual(commands,loaded.f.pair.commands())
