"""Four new real-kernel utility cases; UNRUN, not selected by Moving first1.

A future closed utility bootstrap must start this runner as a new session/group
root, permit exactly four sequential genuine -S Python children/24 pipe ends,
and retain/drain every actual original. No Node, TD, socket, SUT or SDK is used.
"""
import os,subprocess,sys,unittest
import moving_owned_identity as subject
_CHILD="import os,sys;print('ready',flush=True);command=sys.stdin.readline().strip();\nif command=='session':os.setsid();print('session',flush=True);sys.stdin.readline()\n"

class MovingOwnedIdentityTests(unittest.TestCase):
    def setUp(self):
        self.bound=subject.process(os.getpid())
        self.assertEqual(self.bound['pid'],self.bound['pgid']);self.assertEqual(self.bound['pid'],self.bound['sid'])
        self.child=subprocess.Popen([sys.executable,'-S','-B','-c',_CHILD],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        self.addCleanup(self.drain)
        self.assertEqual(self.child.stdout.readline(),'ready\n')
        self.birth=subject.process(self.child.pid)
        self.assertIsNotNone(self.birth);self.assertEqual(self.birth['parentPid'],os.getpid())
        self.assertEqual(self.birth['sid'],self.bound['pid']);self.assertEqual(self.birth['pgid'],self.bound['pid'])
    def drain(self):
        if not self.child.stdin.closed:self.child.stdin.close()
        self.child.wait(timeout=5)
        self.assertEqual(self.child.returncode,0)
        self.child.stdout.close();self.child.stderr.close()
        self.assertTrue(all(stream.closed for stream in(self.child.stdin,self.child.stdout,self.child.stderr)))
        self.assertIsNone(subject.process(self.child.pid))
    def reads(self,function):
        """Observe genuine C readlink calls without replacing any subject port."""
        self.assertIsNone(sys.getprofile());calls=[];original=os.readlink
        def profile(frame,event,arg):
            if event=='c_call'and arg is original:calls.append(True)
        sys.setprofile(profile)
        try:return function(),calls
        finally:sys.setprofile(None)
    def test_actual_owned_identity_executable_and_command(self):
        actual,calls=self.reads(lambda:subject.owned_executable(self.birth,self.bound))
        self.assertEqual(actual['identity'],self.birth)
        self.assertEqual(actual['command'],self.child.args)
        self.assertEqual(actual['executable'],os.path.realpath(sys.executable))
        self.assertTrue(calls)
    def test_actual_foreign_parent_identity_never_reads_executable(self):
        foreign=subject.process(os.getppid());self.assertIsNotNone(foreign)
        calls=[]
        def refused():
            with self.assertRaisesRegex(AssertionError,'Foreign identity before executable read'):subject.owned_executable(foreign,self.bound)
        unused,calls=self.reads(refused);self.assertEqual(calls,[])
    def test_actual_exited_child_yields_no_executable_original(self):
        self.assertIsNone(sys.getprofile());original=os.readlink;calls=[]
        def retire_before_original_executable_call(frame,event,arg):
            if event=='c_call'and arg is original and not calls:
                calls.append(True)
                self.child.stdin.close();self.child.wait(timeout=5)
                self.assertEqual(self.child.returncode,0)
                self.assertIsNone(subject.process(self.child.pid))
        sys.setprofile(retire_before_original_executable_call)
        try:actual=subject.owned_executable(self.birth,self.bound)
        finally:sys.setprofile(None)
        self.assertIsNone(actual);self.assertEqual(calls,[True])
    def test_actual_setsid_change_refuses_old_identity_before_executable(self):
        self.child.stdin.write('session\n');self.child.stdin.flush()
        self.assertEqual(self.child.stdout.readline(),'session\n')
        current=subject.process(self.child.pid)
        self.assertEqual(current['startTicks'],self.birth['startTicks']);self.assertEqual(current['parentPid'],self.birth['parentPid'])
        self.assertEqual(current['sid'],self.child.pid);self.assertEqual(current['pgid'],self.child.pid)
        self.assertNotEqual(current,self.birth)
        def refused():
            with self.assertRaisesRegex(AssertionError,'Discovered owned identity changed before executable read'):subject.owned_executable(self.birth,self.bound)
        unused,calls=self.reads(refused);self.assertEqual(calls,[])
