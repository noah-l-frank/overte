"""One exact original Final group; no complete Final/quiet/end claim."""
from contextlib import ExitStack
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import cProfile,faulthandler,pstats,time
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import unpack
from ios.adapters.avatar_ended_archive import FilesOnlyClient
from ios.adapters.avatar_feature import IOSAvatarFeature
from ios.adapters.avatar_runtime import IOSAvatarRuntime
from ios.adapters.avatar_final import Frozen
from ios.adapters.avatar_held_final import IOSAvatarHeldFinal
from ios.adapters.emote_archive_lock import ArchiveSourceLock
from ios.adapters.emote_original_lease import EmoteOriginalLease
root=Path('.ios-host-tmp/avatar-resumed-full-held-20261026-zxr5av14').resolve()
values={}
for path in root.glob('*/ios-avatar-*-feature.json'):
    raw=PrivateFeatureState(path).read();values[raw['role']]=(path,raw)
paths={value['selectors'][role]:path.with_name('session.json') for role,(path,value) in values.items()}
def forbidden(*args,**kwargs):raise AssertionError('Final file-only profile cannot acquire live SDK/native/HTTP/candidate sources')
base=SimpleNamespace(state_path=lambda target:paths[target],_candidate_guard=forbidden,_binding=forbidden,_target=forbidden,ensure_session=forbidden,invoke=forbidden)
runtime=IOSAvatarRuntime(base);locks={role:ArchiveSourceLock(path.with_name('script-feature-sources.lock')) for role,(path,_raw) in values.items()}
raw=values['primary'][1];client=FilesOnlyClient(raw['fixtureUrl'].split('/runs/')[0],'historical-final-profile-'+'a'*32)
leases=[EmoteOriginalLease(path,[]) for path in {root}|{Path(value['artifactRoot']) for _path,value in values.values()}]
faulthandler.enable();faulthandler.dump_traceback_later(75,repeat=False)
with ExitStack() as stack:
    for lock in locks.values():stack.enter_context(lock.held())
    flow=IOSAvatarFeature.archive(runtime,raw,client,locks)
    store=PrivateFeatureState(flow.store.path.with_name('ios-avatar-primary-final.json'));original=store.read()
    state=unpack(original['payload'])[0];reference=state['rows'][-1]['reference'];need(reference is not None)
    final=object.__new__(IOSAvatarHeldFinal)
    final.store=Frozen(store.path,original);final.root=Path(original['artifactRoot'])
    final.bindings={role:context(binding) for role,binding in original['bindings'].items()}
    final.run,final.role,final.locks,final.authority=original['runId'],original['role'],locks,flow.authority
    final.inputs=deepcopy(original['inputs']);final.historical=True;final.previous=deepcopy(original);final.state=deepcopy(state)
    group=final.record(reference)
    profile=cProfile.Profile();start=time.perf_counter();profile.enable()
    parts=final.group(group)
    profile.disable()
    for lease in leases:lease.guard()
    print('Exact original Final group returned role=primary index='+str(reference['index'])+' elapsed='+format(time.perf_counter()-start,'.6f')+' actualSubjects='+str(sorted(parts))+' originalsUnchanged=true sdkQueries=0 wholeFinalQualified=false',flush=True)
    print('Actual original frame reads='+str(sum(row.callcount for row in profile.getstats() if row.code is OriginalFrameStore.read.__code__)),flush=True)
    pstats.Stats(profile).strip_dirs().sort_stats('cumulative').print_stats(35)
