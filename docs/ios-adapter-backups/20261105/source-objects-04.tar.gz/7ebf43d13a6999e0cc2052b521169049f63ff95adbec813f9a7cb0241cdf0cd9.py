"""Exact two Audio fixture roots plus two original DSP scratch roots; no live SDK or network authority."""
from pathlib import Path
import os,stat,threading
from types import FrameType

class AudioResources:
    def __init__(self,temp,recipe):
        self.temp=Path(temp);self.recipe=recipe;self.classes={};self.analysis=None;self.roots=[];self.main=threading.current_thread()
    def loaded(self,name,module):
        if name=='feature_journeys.evidence':
            fn=vars(module)['audio_observation'];self.analysis=(module,fn,fn.__code__,fn.__globals__,fn.__defaults__,tuple(fn.__defaults__ or()),fn.__kwdefaults__,tuple((fn.__kwdefaults__ or{}).items()),fn.__closure__,tuple(cell.cell_contents for cell in fn.__closure__ or()))
        selected={'ios.self_tests.audio_whole_fixture':('whole','AudioWholeFixture','__init__'),
            'ios.self_tests.test_ios_installed_adapter':('installed','InstalledAdapterTests','setUp')}
        if name not in selected:return
        role,class_name,method=selected[name];cls=vars(module)[class_name];function=cls.__dict__[method]
        assert role not in self.classes
        self.classes[role]=(module,class_name,cls,method,function,function.__code__,function.__globals__,function.__defaults__,function.__closure__)
    def td_role(self,frame,args,kwargs):
        assert type(frame)is FrameType and threading.current_thread()is self.main
        if self.analysis is not None:
            module,fn,code,namespace,defaults,values,keywords,items,closure,cells=self.analysis
            assert module.audio_observation is fn and fn.__code__ is code and fn.__globals__ is namespace and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
            assert len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values))
            assert tuple(keywords or())==tuple(key for key,value in items)and all(keywords[key]is value for key,value in items)
            assert len(closure or())==len(cells)and all(cell.cell_contents is value for cell,value in zip(closure or(),cells))
            if frame.f_code is code and frame.f_globals is namespace:
                assert not args and kwargs=={'prefix':'overte-feature-pcm-'}and type(frame.f_locals['content'])is bytes
                assert sum(row['role']=='pcm-analysis'for row in self.roots)<self.recipe['expectedPCMScratchTDs']
                return 'pcm-analysis'
        assert not args and not kwargs
        found=[]
        for role,row in self.classes.items():
            module,name,cls,method,fn,code,namespace,defaults,closure=row
            assert vars(module)[name]is cls and cls.__dict__[method]is fn
            assert fn.__code__ is code and fn.__globals__ is namespace and fn.__defaults__ is defaults and fn.__closure__ is closure
            if frame.f_code is code and frame.f_globals is namespace and type(frame.f_locals.get('self'))is cls:found.append(role)
        assert len(found)==1 and not any(row['role']==found[0]for row in self.roots)
        return found[0]
    def remember(self,role,path):
        path=Path(path);s=path.lstat();assert path.parent==self.temp and path.resolve(strict=True)==path
        assert stat.S_ISDIR(s.st_mode)and stat.S_IMODE(s.st_mode)==0o700 and s.st_uid==os.geteuid()
        self.roots.append(dict(role=role,path=str(path),device=s.st_dev,inode=s.st_ino))
    def finish(self):
        assert len(self.roots)==self.recipe['expectedTDs'] and sum(row['role']=='pcm-analysis'for row in self.roots)==self.recipe['expectedPCMScratchTDs']
        assert {row['role']for row in self.roots}==({'whole','installed','pcm-analysis'}if self.recipe['expectedPCMScratchTDs']else{'whole','installed'})
        for row in self.roots:
            path=Path(row['path']);s=path.lstat();assert(s.st_dev,s.st_ino)==(row['device'],row['inode'])and path.resolve(strict=True)==path
        return dict(realTemporaryDirectories=len(self.roots),realNodeExecutions=0,realHTTPListeners=0,realUDPSockets=0,realTLS=0,realSDK=0,
            noNewProductionDunderNew=True,declaredLowerProducers=['native','UIKit','SDK','OS','audio capture/output','phase Client','host/model clocks'],actualRoots=self.roots,nativeQualified=False,wholeQualified=False)
