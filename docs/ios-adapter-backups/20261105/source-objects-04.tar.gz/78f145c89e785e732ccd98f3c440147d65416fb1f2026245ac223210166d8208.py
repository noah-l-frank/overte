"""UNRUN read-only retained-original boundary diagnostic; no acceptance authority."""
import cProfile
import hashlib
import importlib.abc
import importlib.machinery
import json
import os
from pathlib import Path
import pstats
import signal
import stat
import sys
import threading
import time
import traceback

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
OUTPUT=Path(sys.argv[1]).resolve(strict=True)
PLAN=json.loads((HERE/'plan.json').read_text())
EXPECTED=json.loads((OUTPUT/'sources-before.json').read_text())
BASE_THREADS=set(threading.enumerate())
started=time.monotonic();marks=[];effects=[];imported={};profile=cProfile.Profile()

def save(name,value):
    path=OUTPUT/name
    with path.open('w') as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())

def mark(name):
    value={'name':name,'elapsedSeconds':time.monotonic()-started}
    marks.append(value);print('BOUNDARY',json.dumps(value),flush=True)

def forbidden(name):
    effects.append(name);raise AssertionError('Forbidden read-only diagnostic effect: '+name)

tmp=REPO/PLAN['originalRoot']
locks={str(tmp/name/'script-feature-sources.lock') for name in
       (PLAN['selection']['main'],PLAN['selection']['photos'],PLAN['selection']['archive'])}
pins=json.loads((HERE/'original-pins.json').read_text())
def audit(event,args):
    if event.startswith(('socket.','subprocess.','os.exec','os.spawn','os.fork')) or event in ('os.system','os.posix_spawn','pty.spawn','ctypes.dlopen'):
        forbidden(event)
    if event in ('os.remove','os.rmdir','os.rename','os.mkdir','os.chmod','os.chown','os.utime','os.link','os.symlink','os.truncate'):
        forbidden(event)
    if event=='open':
        path,mode,flags=args
        if not flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):return
        if not isinstance(path,(str,bytes,os.PathLike)):forbidden('descriptor-write-open')
        actual=Path(os.fsdecode(path)).absolute()
        if actual.parent==OUTPUT:return
        if str(actual) in locks and mode is None and not flags&(os.O_TRUNC|os.O_APPEND|os.O_EXCL):
            row=actual.lstat();pin=pins[str(actual.relative_to(REPO))]
            if row.st_dev==pin['st_dev'] and row.st_ino==pin['st_ino']:return
        forbidden('write-open:'+str(actual))

class SourceGuard(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.',1)[0] in ('pymobiledevice3','pmd_pytcp','pmd_pytcpstack','pytcp'):
            forbidden('SDK-import:'+fullname)
        spec=importlib.machinery.PathFinder.find_spec(fullname,path)
        if spec is None or not spec.origin or spec.origin in ('built-in','frozen'):return None
        origin=Path(spec.origin).resolve()
        if 'overte-ios-remotexpc' in str(origin):forbidden('SDK-import:'+fullname)
        if origin.is_relative_to(REPO):
            key=str(origin.relative_to(REPO));expected=EXPECTED.get(key)
            assert expected is not None and hashlib.sha256(origin.read_bytes()).hexdigest()==expected['sha256'],('Unpinned import',fullname,key)
            imported[fullname]=key
        return None

error=None;interrupted=None;actual_reads=set()
def terminate(signum,frame):
    global interrupted
    profile.disable();interrupted={'signal':signum,'stack':traceback.format_stack(frame)}
    save('signal-cutpoint.json',interrupted)
    raise SystemExit(128+signum)

# Root canonical namespace check BEFORE all production imports.
assert not any(name.split('.',1)[0] in ('ios','adapters','feature_journeys') for name in sys.modules)
ordered=[str(REPO/name) for name in PLAN['apiPYTHONPATH']]
remaining=[]
for value in sys.path:
    path=Path(value or os.getcwd()).resolve()
    if path==REPO or REPO in path.parents:continue
    if str(path) not in remaining:remaining.append(str(path))
sys.path[:]=ordered+remaining
for name,relative in {'ios':'tests/device/ios','adapters':'tests/device/adapters','feature_journeys':'tests/device/feature_journeys'}.items():
    spec=importlib.machinery.PathFinder._get_spec(name,list(sys.path))
    assert spec is not None and list(spec.submodule_search_locations or ())==[str(REPO/relative)],name
mark('canonical-source-roots-checked')
assert not any(name.split('.',1)[0] in ('pymobiledevice3','pmd_pytcp','pmd_pytcpstack','pytcp') for name in sys.modules),'SDK preloaded before passive import gate'
sys.addaudithook(audit)
sys.meta_path.insert(0,SourceGuard())
signal.signal(signal.SIGTERM,terminate)
try:
    # No fixture/native/SDK module is imported. The controller policy is the
    # actual selected-before-first-input original, never a backend-derived DTO.
    from contextlib import ExitStack
    from unittest.mock import patch
    from adapters.native_clock_join import digest
    from adapters.normal_feature_state import PrivateFeatureState
    from adapters.operation_transport_guard import scope
    from ios.adapters.snapshot_capture_clock import Budget
    from ios.adapters.snapshot_photos_end_originals import SnapshotPhotosEndOriginals
    from adapters.original_file_reads import readonly,collect
    mark('actual-passive-imports-complete')
    main_binding=dict(sourceRevision='a'*40,artifactSha256='b'*64,processIdentity='42',sessionId='owned-session',generation=0,targetFingerprint='c'*64)
    def selected(name,bundle,pid,capabilities,admission):
        root=tmp/name;target=dict(platform='ios',physical=True,appId=bundle,serverUrl='http://already-bound.invalid',capabilities=capabilities)
        artifact=root/'selected.ipa'
        binding=dict(sourceRevision='c'*40,artifactSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),processIdentity=str(pid),sessionId='companion-session',generation=1,targetFingerprint=digest(target))
        return dict(root=str(root),binding=binding,artifactPath=str(artifact),sessionPath=str(root/'session.json'),admissionPath=str(root/admission),target=target)
    device='HOST-PHYSICAL-SHARE-DEVICE-MODEL'
    photos=selected(PLAN['selection']['photos'],'org.example.snapshot.photos',84,{'appium:udid':device,'appium:platformVersion':'99.1'},'ios-snapshot-companion-owner.json')
    archive=selected(PLAN['selection']['archive'],'org.example.snapshot.sharearchive',85,{'appium:udid':device},'ios-snapshot-share-code-owner.json')
    controller=PrivateFeatureState(tmp/PLAN['selection']['controllerPolicy']).read()
    assert set(controller)=={'selectionKind','runId','configuration'} and controller['selectionKind']=='snapshot-photos-public-domain-selection' and controller['runId']=='a'*32
    # Literal field selections from reviewed declared fixture sources. None of
    # the expected main/helper identities is recovered from owner headers.
    system_ui=dict(select=dict(using='accessibility id',value='Snapshot Original Receiver'),cancel=dict(using='accessibility id',value='System Share Cancel'))
    factory=SnapshotPhotosEndOriginals(dict(root=str(tmp/PLAN['selection']['main']),binding=main_binding),photos,archive,run='a'*32,
        fixture_url='https://controlled.invalid/feature-fixture/v1/runs/'+'a'*32+'/',primary_bundle='org.example.client',system_ui=system_ui,domain_policy=controller['configuration'],reuse_originals=True)
    def blocked(*args,**kwargs):forbidden('PrivateFeatureState writer')
    with ExitStack() as held:
        held.enter_context(patch.object(PrivateFeatureState,'write',blocked));held.enter_context(patch.object(PrivateFeatureState,'discard',blocked))
        for lock in sorted(factory.locks.values(),key=lambda item:str(item.path)):held.enter_context(lock.held())
        factory.check_locks();mark('three-existing-original-locks-held')
        # This is the literal runtime outer25 gate. No clocks/limits/decoders
        # are replaced. cProfile incurs overhead: timings are diagnostic only.
        budget=Budget(time.monotonic)
        profile.enable()
        try:
            with scope(budget.check),readonly(),collect() as actual_reads:
                budget.check();mark('before-read-journey')
                with factory.read_journey() as journey:
                    mark('journey-yielded');budget.check()
                    result=journey.proof();mark('explicit-result2-returned');budget.check()
                    assert result['snapshotCombinedJourneyResultVersion']==2
                mark('read-area-finished');budget.check()
        finally:profile.disable()
except BaseException as exc:
    profile.disable();error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
    print(error['traceback'],file=sys.stderr,flush=True)
finally:
    profile.disable()
    profile.dump_stats(str(OUTPUT/'passive-boundary.pstats'))
    stats=pstats.Stats(profile).stats if profile.getstats() else {}
    rows=[dict(file=file,line=line,function=name,primitiveCalls=record[0],totalCalls=record[1],selfSeconds=record[2],inclusiveSeconds=record[3])
          for (file,line,name),record in stats.items() if str(REPO) in file]
    save('profile-rows.json',sorted(rows,key=lambda row:row['inclusiveSeconds'],reverse=True))
    new_threads=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon) for thread in threading.enumerate() if thread not in BASE_THREADS and thread.is_alive()]
    save('diagnostic-result.json',dict(error=error,marks=marks,forbiddenEffects=effects,imports=imported,interrupted=interrupted,
        newThreads=new_threads,
        elapsedSeconds=time.monotonic()-started,actualReadPaths=sorted(map(str,actual_reads)),authority=False,wholeQualified=False,
        oldInnerStackKnown=False,timingQualification=False))
if error or effects or new_threads:raise SystemExit(1)
