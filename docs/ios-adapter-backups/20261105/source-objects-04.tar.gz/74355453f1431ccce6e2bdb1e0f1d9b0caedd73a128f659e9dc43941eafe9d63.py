"""Source-only prospect: one explicitly selected5-case suite180+5, failfast; no automatic additional selector."""
from pathlib import Path
import importlib.util
import json
import os
import signal
import subprocess
import sys
import threading
import time
import traceback
from metadata import SOURCE, REPO, head, validate, sha, pin, census, load, fds, proc


def main():
    assert sys.dont_write_bytecode and Path.cwd() == REPO and len(sys.argv) == 7
    assert sys.flags.no_site == 1, "Explicit no-site interpreter startup required"
    group, expected_head, source_sha, plan_sha, plan_path, output = sys.argv[1:]
    assert head() == expected_head
    input_path = Path(plan_path).resolve(strict=True)
    input_before = pin(input_path)
    assert input_before['sha256'] == plan_sha
    plan = validate(Path(plan_path), plan_sha, source_sha, expected_head, group)
    assert pin(input_path) == input_before
    here = Path(output)
    outer = Path(str(here) + '-outer')
    assert here.is_absolute() and here.resolve(strict=False) == here
    assert here.parent == REPO / '.ios-host-tmp' and here.name.startswith('chat-offline-public-origin-'+group+'-')
    assert here != SOURCE and not here.exists() and not outer.exists()
    custody = plan['globalCustody']
    for key in ('helperPath', 'seedPath', 'baselinePath'):
        assert custody[key] in plan['physicalPins']
    assert sha(custody['helperPath']) == 'bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
    helper_path = Path(custody['helperPath'])
    assert Path(custody['seedPath']) == helper_path.with_name('global-original-roots-seed.json')
    assert sha(custody['seedPath']) == custody['seedSha256']
    assert sha(custody['baselinePath']) == custody['baselineSha256']
    spec = importlib.util.spec_from_file_location('chat_offline_global_corpus_controller', helper_path)
    corpus = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(corpus)
    old_global = load(custody['baselinePath'])
    assert set(old_global) == set(load(custody['seedPath'])['roots'])
    assert corpus.current() == old_global
    before = {path: pin(path) for path in plan['physicalPins']}
    assert before == plan['physicalPins']
    parent_fds, parent_threads = fds(), tuple(threading.enumerate())
    outer.mkdir(mode=0o700)
    here.mkdir(mode=0o700)
    def save(name, body):
        path = outer / name
        with path.open('x') as stream:
            json.dump(body, stream, sort_keys=True, indent=2)
            stream.write('\n')
        path.chmod(0o600)
    save('all-pins-before.json', before)
    save('approved-input-before.json', input_before)
    save('global-before.json', old_global)
    baseline = {int(path.name): proc(int(path.name)) for path in Path('/proc').iterdir() if path.name.isdecimal()}
    child = None
    birth = None
    owned = {}
    problems = []
    timed_out = forced = False
    term_at = None
    started = time.monotonic()
    try:
        raw_root=here/'temporary';raw_root.mkdir(mode=0o700)
        with (here / 'child-stdin.eof').open('xb'):
            pass
        with (here / 'child-stdin.eof').open('rb') as incoming, (here / 'child-stdout.log').open('xb') as stdout, (here / 'child-stderr.log').open('xb') as stderr:
            child = subprocess.Popen([sys.executable, '-S', '-B', str(SOURCE / 'run-five.py'), group, expected_head, source_sha,
                plan_sha, str(Path(plan_path).resolve(strict=True)), str(here)], cwd=REPO,
                stdin=incoming, stdout=stdout, stderr=stderr, start_new_session=True,
                env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        birth = proc(child.pid)
        assert birth is not None and birth['parent'] == os.getpid()
        assert birth['group'] == birth['session'] == birth['pid']
        owned[birth['pid']] = birth
        save('child-birth.json', birth)
        while child.poll() is None:
            table = {int(path.name): proc(int(path.name)) for path in Path('/proc').iterdir() if path.name.isdecimal()}
            changed = True
            while changed:
                changed = False
                for pid, row in table.items():
                    if row is None or pid in owned:
                        continue
                    if row['parent'] in owned or row['group'] == birth['group'] or row['session'] == birth['session']:
                        assert pid not in baseline
                        owned[pid] = row
                        if row['parent'] != birth['pid'] or len(owned)>1+plan['maxTotalNodes']:
                            problems.append(dict(kind='unadmitted-child-lineage-or-count', identity=row))
                        changed = True
            for pid, identity in owned.items():
                actual = proc(pid)
                assert actual is None or actual == identity
            elapsed = time.monotonic() - started
            if elapsed >= 180 and term_at is None:
                assert proc(child.pid) == birth
                timed_out = True
                term_at = time.monotonic()
                os.kill(child.pid, signal.SIGTERM)
            if term_at is not None and time.monotonic() - term_at >= 5:
                assert proc(child.pid) == birth
                forced = True
                os.kill(child.pid, signal.SIGKILL)
                break
            time.sleep(0.05)
        child.wait()
    except BaseException:
        problems.append(dict(kind='supervisor-exception', traceback=traceback.format_exc()))
    finally:
        if birth is not None:
            # Catch any last same-session child even if the runner terminated
            # between polling passes. Never exclude an active own writer.
            for path in Path('/proc').iterdir():
                if not path.name.isdecimal():
                    continue
                row=proc(int(path.name))
                if row is not None and row['pid']not in owned and(row['group']==birth['group']or row['session']==birth['session']):
                    assert row['pid']not in baseline
                    owned[row['pid']]=row
                    problems.append(dict(kind='late-own-process',identity=row))
        residual = []
        for pid, identity in owned.items():
            actual = proc(pid)
            if actual is not None:
                residual.append(dict(bound=identity, actual=actual))
                if actual == identity:
                    os.kill(pid, signal.SIGKILL)
        if child is not None:
            child.wait()
        remaining = {pid: proc(pid) for pid in owned if proc(pid) is not None}
        save('process-drain.json', dict(owned=list(owned.values()), residual=residual, remaining=remaining))
        assert not remaining
        if residual:
            problems.append(dict(kind='residual-required-kill', identities=residual))
        # All own processes and stdio handles are closed before these reads.
        input_after = pin(input_path)
        input_unchanged = input_before == input_after and input_after['sha256'] == plan_sha
        save('approved-input-after.json', input_after)
        raw_first,raw_second=census(raw_root),census(raw_root)
        global_first, global_second = corpus.current(), corpus.current()
        expected_global_names=set(old_global)|{str(raw_root)}
        old_bodies_unchanged=(set(global_first)==set(global_second)==expected_global_names
            and all(global_first[name]==global_second[name]==rows for name,rows in old_global.items()))
        after = {path: pin(path) for path in before}
        result = load(here / 'child-result.json') if (here / 'child-result.json').is_file() else None
        restoration = load(here / 'write-port-restoration.json') if (here / 'write-port-restoration.json').is_file() else None
        whole_first, whole_second = census(here), census(here)
        child_nodes=[]if result is None else[row['node']['actualNode']for row in result.get('cases',[])if row.get('controllerGatePassed')]
        actual_node_absence=len(child_nodes)==len(plan['cases']) and all(proc(row['pid'])is None for row in child_nodes)
        passed = child is not None and child.returncode == 0 and not problems and not timed_out and not forced
        passed = passed and raw_first == raw_second and actual_node_absence
        passed = passed and global_first == global_second and old_bodies_unchanged and before == after and head() == expected_head
        passed = passed and whole_first == whole_second
        passed = passed and result is not None and result['status'] == 'PASS' and result['testsRun'] == len(plan['cases']) and result['selected'] == plan['cases'] and result['noSDKImported']
        passed = passed and result['actualFivePublicOriginsEstablished']is True and result['actualAllLoadedOriginsAccounted'] is True and result['allLoadedOriginSnapshots'] >= len(plan['cases'])+2
        passed = passed and input_unchanged and result['actualApprovedInputUnchanged'] is True and result['approvedInputCliSha256'] == plan_sha
        passed = passed and restoration is not None and restoration['restored'] and restoration['actualCportCount'] == 27
        passed = passed and fds() == parent_fds and tuple(threading.enumerate()) == parent_threads
        for name, body in (('raw-first.json', raw_first), ('raw-second.json', raw_second),
                ('global-first.json', global_first), ('global-second.json', global_second),
                ('all-pins-after.json', after), ('whole-output-first.json', whole_first),
                ('whole-output-second.json', whole_second)):
            save(name, body)
        save('terminal.json', dict(status='PASS' if passed else 'FAIL_OR_REFUSED', selected=plan['cases'], selectionGroup=group,
            childReturnCode=None if child is None else child.returncode,
            elapsedOuterSeconds=time.monotonic()-started, timedOut=timed_out, forced=forced,
            problems=problems, twoRawCensusesEqual=raw_first==raw_second,newRawRootIncluded=str(raw_root),actualNodesAbsent=actual_node_absence,
            oldGlobalBodiesUnchanged=old_bodies_unchanged,
            actualApprovedInputUnchanged=input_unchanged,approvedInputCliSha256=plan_sha,
            allPhysicalPinsUnchanged=before == after, twoClosedWholeOutputsEqual=whole_first == whole_second,
            actualParentFDThreadDrain=fds() == parent_fds and tuple(threading.enumerate()) == parent_threads,
            noOwnProcesses=not remaining, nativeQualified=False, currentDomainQualified=False, wholeQualified=False))
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
