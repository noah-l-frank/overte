"""Real selected IPA/InstalledBinding/session/child original composition; SDK DI.

Original C++ native bundle and authenticated RSD remain declared producer models.
No source hash or parent boolean is used as original-child binary authority.
"""
import json
from copy import deepcopy
import installed_query_fixture as installed_fixture


class InstalledChildBundleModels(installed_fixture.InstalledOwnedQueryCandidateModels):
    def query(self):return self.f.adapter._lifecycle_owned_native_query('test-only',self.run,'ios-bundle-observe')
    def test_selected_ipa_original_directory_child_file_and_bound_native_birth_compose_without_child_motion_admission(self):
        value=self.query();self.assertEqual(2,value['originalKeeperInstalledQueryVersion']);self.assertEqual(2,value['queryOriginal']['originalKeeperNativeQueryVersion'])
        original=value['childBundleOriginal'];self.assertEqual(2,original['originalKeeperNativeFileVersion'])
        packet=json.loads(original['rawJson']);self.assertEqual(self.measured_directory_bundle,packet['bundle']);self.assertEqual(value['selectedArtifactBundle'],packet['bundle'])
        self.assertLess(value['installedBefore']['observation']['sequence'],packet['sequence']);self.assertLess(packet['sequence'],value['installedAfter']['observation']['sequence'])
        self.assertEqual(2,len(self.executed));self.assertTrue(all(v['args']['nativeBundleProfileVersion']==1 for v in self.executed))
        self.assertTrue(all(resource.fileno()==-1 for service in self.services for resource in service.sockets));self.assertTrue(all(service._afc_reader_task is None for service in self.services))
        self.assertTrue(all(value[k] is False for k in ('nativeAcquisitionBound','originalChildCandidateBound','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished')));self.assert_no_new_session()
    def test_changed_actual_child_bundle_bytes_refuse_even_when_parent_native_binding_and_selected_ipa_match(self):
        def changed():
            if self.executed[-1]['operation']=='touch-native-query':
                packet=json.loads(self.native_file.read_bytes());packet['bundle']['executableSha256']='f'*64;self.native_file.write_text(json.dumps(packet))
        self.after_query=changed
        with self.assertRaises((ValueError,RuntimeError)):self.query()
        self.assertEqual(2,len(self.executed));self.assertEqual(self.measured_directory_bundle,self.f.native.bundle);self.assert_no_new_session()
    def test_foreign_child_bundle_owner_with_identical_ipa_bytes_refuses_exact_original_native_birth(self):
        def changed():
            if self.executed[-1]['operation']=='touch-native-query':
                packet=json.loads(self.native_file.read_bytes());packet['instance']='f'*32;self.native_file.write_text(json.dumps(packet))
        self.after_query=changed
        with self.assertRaises((ValueError,RuntimeError)):self.query()
        self.assertEqual(2,len(self.executed));self.assert_no_new_session()
    def test_selected_ipa_change_after_original_child_read_refuses_without_replay_or_new_session(self):
        def changed():
            if self.executed[-1]['operation']=='touch-native-original-read':self.f.artifact.write_bytes(self.f.artifact.read_bytes()+b'changed after real child original read')
        self.after_query=changed
        with self.assertRaises((ValueError,RuntimeError)):self.query()
        self.assertEqual(2,len(self.executed));self.assertEqual(1,len(self.wal()['records']));self.assert_no_new_session()
