"""Finite lower normal GLTF prefixes; no phase, installed or Whole admission.

Expected scenario states below are assertions only. Raw scene responses come
from independent endpoint constructors and the actual existing QML/backend
model. The direct consumed seam is an input test seam, not evidence consumers.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_ui import NativeUIError
from feature_journeys.scenarios import SCENARIOS,expand
from feature_journeys.fixtures import context
from ios.adapters.assets_runtime import AssetsNativeInput
from ios.self_tests.assets_checkpoint_scene_fixture import CheckpointSceneEndpoint
from ios.self_tests.assets_whole_observation_fixture import Fixture
from ios.self_tests.assets_picker_fixture import RUN


class AssetsNormalGltfCheckpointPrefixTests(unittest.TestCase):
    def states(self,index,rows):
        for row in rows:
            self.assertEqual(expand(SCENARIOS['assets']['steps'][index-1]['state'],context(RUN)),row['state'])
            self.assertFalse(row['publicObservationReady']);self.assertFalse(row['wholeEndEligible'])
        self.assertEqual('primary',rows[0]['subject']);self.assertEqual('actor',rows[1]['subject'])
        self.assertIsNotNone(rows[1]['peerScene'])
        self.assertNotEqual(rows[0]['primaryScene']['path'],rows[1]['primaryScene']['path'])
    def test_normal_action2_opens_real_staged_gltf_picker_without_upload_or_model_effect(self):
        fixture=Fixture(self);fixture.observed(1)
        fixture.perform_action(2)
        rows=(fixture.driver.observe_current('primary'),fixture.driver.observe_current('actor'))
        self.states(2,rows);parts=fixture.parts
        self.assertEqual('staged',parts['owned_files'].state['phase'])
        self.assertEqual('gltf-bundle/main.gltf',parts['owned_files'].state['resource'])
        self.assertEqual('picker-open',parts['picker'].state['phase'])
        self.assertIsNone(parts['upload'].state)
        self.assertFalse(any(row['slot']=='choose-primary' for row in parts['picker'].state['inputs']))
        self.assertEqual({},fixture.backend.mappings);self.assertEqual({},fixture.boundary.peer.models)
        self.assertEqual(1,len(fixture.a.owner.state['records']))
        self.assertIsNone(fixture.a.owner.state['pending']['after'])
        fixture.consume_input(2)
        self.assertEqual(2,len(fixture.a.owner.state['records']))
    def test_normal_action3_cancel_retires_actual_local_files_and_preserves_live_shared_page(self):
        fixture=Fixture(self);fixture.observed(1);fixture.observed(2)
        rows=fixture.observed(3);self.states(3,rows)
        parts=fixture.parts
        self.assertEqual('retired',parts['owned_files'].state['phase'])
        self.assertEqual('page-borrowed-retired',parts['picker'].state['phase'])
        self.assertEqual({},fixture.backend.mappings);self.assertEqual({},fixture.boundary.peer.models)
        self.assertTrue(rows[0]['state']['open']);self.assertFalse(rows[0]['state']['picker'])
        self.assertFalse(fixture.driver.generations.state['complete'])
    def test_lost_normal_open_return_recovers_saved_slot_without_second_input_delivery(self):
        fixture=Fixture(self);fixture.observed(1)
        original=AssetsNativeInput.assets_input;attempts=[];lost=[]
        def actual(native,identifier,*args,**kwargs):
            if identifier=='assets.upload':attempts.append(identifier)
            result=original(native,identifier,*args,**kwargs)
            if identifier=='assets.upload' and not lost:
                lost.append(dict(command=deepcopy(fixture.boundary.inputs[-1]),receipt=deepcopy(native.last_receipt)))
                raise NativeUIError('Actual normal open callback returned; owning Picker did not receive the return')
            return result
        with patch.object(AssetsNativeInput,'assets_input',actual):
            with self.assertRaises(NativeUIError):fixture.perform_action(2)
            self.assertEqual(1,len(lost));self.assertEqual(1,len(fixture.a.owner.state['records']))
            pending=deepcopy(fixture.a.owner.state['pending']);row=fixture.a.owner.plan()[1]
            fixture.driver.act(dict(contractVersion=16,runId=RUN,verb=row['verb'],inputs=deepcopy(row['inputs']),
                ticket=pending['ticket'],fixtureUrl=fixture.driver.url))
        self.assertEqual(['assets.upload'],attempts)
        picker=fixture.driver.last['parts']['picker']
        slots=[entry for entry in picker.state['inputs'] if entry['slot']=='open-picker']
        self.assertEqual(1,len(slots));self.assertIsNone(slots[0]['receipt']);self.assertIsNotNone(slots[0]['resolvedBy'])
        self.assertEqual(lost[0]['command'],slots[0]['command'])
        self.assertEqual(1,sum(command['commandId']==lost[0]['command']['commandId'] for command in fixture.boundary.inputs))
        self.assertEqual('picker-open',picker.state['phase']);self.assertIsNone(fixture.a.owner.state['pending']['after'])
    def test_checkpoint_constructor_rejects_foreign_held_role_lock_and_old_action_before_query(self):
        fixture=Fixture(self);fixture.observed(1);fixture.perform_action(2)
        fixture.driver.observe_current('primary')
        observer=fixture.driver.observers[(2,'primary')]
        ep=fixture.scene_endpoints[(2,'primary')]
        self.assertIs(type(ep),CheckpointSceneEndpoint)
        self.assertIs(ep.lock,observer.locks['primary']);self.assertIs(ep.world,fixture.boundary)
        with self.assertRaises(NativeUIError):
            CheckpointSceneEndpoint(fixture,observer,observer.selector,'primary',observer.locks['actor'])
        counts=deepcopy(ep.counts);queries=deepcopy(ep.queries)
        fixture.a.activate(3)
        with self.assertRaises(NativeUIError):ep.send('clock',dict(commandId='old-action-refused-before-query'))
        self.assertEqual(counts,ep.counts);self.assertEqual(queries,ep.queries)
    def test_normal_gltf_companion_upload_and_import_reach_independent_actor_originals(self):
        fixture=Fixture(self);last=None
        for index in range(1,9):last=fixture.observed(index)
        self.states(8,last)
        self.assertTrue(last[0]['state']['sceneModel']);self.assertTrue(last[1]['state']['sceneModel'])
        self.assertTrue(last[0]['state']['companions'])
        self.assertEqual(last[0]['state']['companions'],last[1]['state']['companions'])
        self.assertTrue(fixture.boundary.peer.deliveries)
        self.assertEqual(set(last[0]['ownedModels']),set(last[1]['ownedModels']))
        self.assertTrue(last[0]['ownedModels'])
        self.assertEqual(8,len(fixture.a.owner.state['records']));self.assertIsNone(fixture.a.owner.state['pending'])
        self.assertFalse(fixture.driver.generations.state['complete'])


if __name__=='__main__':unittest.main()
