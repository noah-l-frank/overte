"""Moving's own initial native model, selected before any original Source birth.

Only fresh raw host-model packets are decorated. No saved packet, source clock,
validator, native reader or existing shared fixture is changed.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from self_tests.test_native_feature_observation import Boundary as OriginalNativeClockBoundary


class MovingNativeClock(OriginalNativeClockBoundary):
    def __init__(self):
        super().__init__()
        # The Moving journey does not issue an animation override. The shared
        # general diagnostic example's active Sit2 override is not its baseline.
        self.moving_model_override_active = False

    def send(self, command):
        previous_sequence = self.sequence
        super().send(command)
        if self.sequence > previous_sequence:
            # An ignored/unknown send cannot edit its earlier sample. Retained
            # originals are never touched; super just created this fresh dict.
            assert self.sample is not None and self.sample['requestId'] == command['commandId']
            assert type(self.moving_model_override_active) is bool
            self.sample['animation']['overrideActive'] = self.moving_model_override_active
