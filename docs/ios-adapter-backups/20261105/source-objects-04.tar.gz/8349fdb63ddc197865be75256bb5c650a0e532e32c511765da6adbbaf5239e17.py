"""Explicit Actor-only passive capture on an existing, held canonical SDK.

The SDK parent ledger owns exact artifact child births before native Start.
No normal/public feature entrypoint selects this runtime or bypasses existing
Audio cleanup guards. Reopening first decodes original files without a source.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
import os,stat,time
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.phase_fixture import PhaseFixtureReader
from feature_journeys.witness import Client
from ios.adapters.audio_passive_capture_source import FILE,MAX_ORIGINAL,hex32
from ios.adapters.audio_passive_owner import IOSAudioPassiveOwner
from ios.adapters.audio_runtime import IOSAudioRuntime
from ios.adapters.audio_session_owners import owners_absent,register_scope
from ios.adapters.emote_original_lease import EmoteOriginalLease


def identity(root):
    need(root.is_absolute() and root.resolve(strict=True)==root)
    value=root.lstat();need(stat.S_ISDIR(value.st_mode) and value.st_uid==os.geteuid() and stat.S_IMODE(value.st_mode)==0o700)
    return dict(device=value.st_dev,inode=value.st_ino)


def fsync_directory(root):
    fd=os.open(root,os.O_RDONLY|getattr(os,'O_DIRECTORY',0)|getattr(os,'O_NOFOLLOW',0))
    try:os.fsync(fd)
    finally:os.close(fd)


class PassiveSDKLedger:
    """Pure typed historical admission, not permission to query a new SDK."""
    OWNER_TYPE=IOSAudioPassiveOwner
    LEDGER_FILE='ios-audio-passive-ledger.json'
    LEDGER_KEY='iosAudioPassiveSDKLedgerVersion'
    LEDGER_VERSIONS=(1,2)
    CHILD_PREFIX='ios-audio-passive-'

    def __init__(self,runtime,selector,run,lease,root,client,lock):
        need(isinstance(runtime,IOSAudioPassiveRuntime) and hex32(run) and hex32(lease) and isinstance(client,Client) and isinstance(lock,ScriptSourceLock))
        self._family_type=type(self);self._family_fields=tuple((name,getattr(type(self),name))for name in('OWNER_TYPE','LEDGER_FILE','LEDGER_KEY','LEDGER_VERSIONS','CHILD_PREFIX'))
        self.family_guard()
        self.runtime,self.selector,self.run,self.root,self.client,self.lock=runtime,selector,run,Path(root),client,lock
        self.selected_lease=lease;self.version=1;self.pending_cache_transfers=[];self.process_end=None
        self.sdkroot=runtime.state_path(selector).parent
        need(lock.path==self.sdkroot/'script-feature-sources.lock' and self.root!=self.sdkroot)
        lock.assert_held();self.root_identity=identity(self.root);identity(self.sdkroot)
        self.store=PrivateFeatureState(self.sdkroot/self.LEDGER_FILE)
        self.scope=PrivateFeatureState(self.sdkroot/'ios-audio-scope.json');self.previous=self.store.read();self.archives={};self.oldleases=[]
        from ios.adapters.audio_shared_actor_inventory import selected
        self.shared=selected(runtime,selector,run,self.root,client,lock)
        self.admit()

    def family_guard(self):
        need(type(self)is self._family_type and all(getattr(type(self),name)is value and getattr(self,name)is value
            for name,value in self._family_fields))
        return True

    def envelope(self):
        value=dict({self.LEDGER_KEY:self.version},binding=deepcopy(self.binding),runId=self.run,role='actor',
            sdkStateRoot=str(self.sdkroot),artifactRoot=str(self.root),rootIdentity=self.root_identity,
            fixtureUrl=self.client.url+'/runs/'+self.run+'/',leases=deepcopy(self.rows))
        if self.version==2:value['processEnd']=deepcopy(self.process_end)
        return value

    def admit(self):
        self.family_guard()
        self.lock.assert_held();need(identity(self.root)==self.root_identity)
        if self.previous is None:
            # A lost scope-only commit remains explicit duty. No orphan file or
            # directory may be inferred owned merely from its familiar name.
            from ios.adapters.audio_whole_actor_admission import parent_absent
            if self.shared is None:need(parent_absent(self) and not list(self.root.iterdir()))
            else:self.shared.first_parent(self)
            self.binding=None;self.rows=[];return
        value=self.previous;self.version=value.get(self.LEDGER_KEY)
        need(type(self.version) is int and self.version in self.LEDGER_VERSIONS)
        exact(value,{self.LEDGER_KEY,'binding','runId','role','sdkStateRoot',
            'artifactRoot','rootIdentity','fixtureUrl','leases'}|({'processEnd'} if self.version==2 else set()))
        self.binding=deepcopy(context(value['binding']));self.rows=deepcopy(value['leases'])
        self.process_end=deepcopy(value.get('processEnd'))
        need(type(value[self.LEDGER_KEY]) is int and value[self.LEDGER_KEY]==self.version
            and same(value,self.envelope()) and type(self.rows) is list and len(self.rows)<=16)
        expected_scope=dict(iosAudioScopeVersion=1,binding=self.binding,runId=self.run,artifactRoot=str(self.root))
        need(same(self.scope.read(),expected_scope))
        audio={path for path in self.sdkroot.iterdir() if path.name.startswith('ios-audio-')}
        if self.shared is None:need(audio==self.sdk_audio_paths())
        roots=set();ids=set()
        for row in self.rows:
            exact(row,{'leaseId','phase','rootIdentity'}|({'onceCacheCustody'} if 'onceCacheCustody' in row else set()));lease=row['leaseId']
            need('onceCacheCustody' not in row or self.version==2 and row['phase']=='opened')
            need(hex32(lease) and lease not in ids and row['phase'] in ('planned','opened'));ids.add(lease)
            child=self.root/(self.CHILD_PREFIX+lease);roots.add(child)
            if row['phase']=='planned':
                need(lease==self.selected_lease)
                need(row['rootIdentity'] is None and not child.exists());continue
            exact(row['rootIdentity'],{'device','inode'})
            need(integer(row['rootIdentity']['device'],0) and integer(row['rootIdentity']['inode'],1) and identity(child)==row['rootIdentity'])
            store=PrivateFeatureState(child/self.OWNER_TYPE.STORE_NAME)
            if store.read() is None:need(lease==self.selected_lease and not list(child.iterdir()))
            else:
                archive=self.OWNER_TYPE.archive(store,child,self.binding,self.run,lease,self.lock,self.client.url+'/runs/'+self.run+'/')
                if 'onceCacheCustody' in row:
                    need(archive.version==2 and same(row['onceCacheCustody'],archive.episode_retired()['cacheCustody']))
                if lease!=self.selected_lease and self.process_end is None:
                    episode=archive.episode_retired()
                    duty=episode['cacheCustody']
                    if duty is not None and duty['inputs']:
                        if 'onceCacheCustody' not in row:self.pending_cache_transfers.append((row,deepcopy(duty)))
                    else:archive.retired()
                    self.oldleases.append(EmoteOriginalLease(child,[]))
                elif self.process_end is not None:self.oldleases.append(EmoteOriginalLease(child,[]))
                self.archives[lease]=archive
        if self.process_end is not None:
            from ios.adapters import audio_once_end
            audio_once_end.shape(self)
            if self.process_end['phase']!='planned':roots.add(audio_once_end.root(self))
        expected={path for path in roots if path.exists()}
        if self.shared is None:need(set(self.root.iterdir())==expected)
        else:self.shared.membership(self,self.sdk_audio_paths(),expected)

    def sdk_audio_paths(self):
        paths={self.scope.path,self.store.path}
        if self.process_end is not None:
            from ios.adapters.audio_once_end import store
            path=store(self).path
            if path.exists():paths.add(path)
        return paths

    def save(self):
        try:
            if self.shared is not None:self.shared.require_live(writing=True)
            self.family_guard()
            self.lock.assert_held();need(identity(self.root)==self.root_identity and same(self.store.read(),self.previous))
            value=self.envelope();self.store.write(value,self.previous);need(same(self.store.read(),value));self.previous=deepcopy(value)
        except BaseException:
            if self.shared is not None:self.shared.failed=True
            raise

    def transfer_completed(self):
        """Persist exact original residual duties before any next SDK source.

        No cache release or absence is inferred. The same selected SDK/session
        retains these process-bound duties until its actual original process end.
        """
        self.lock.assert_held()
        if self.pending_cache_transfers:
            self.version=2
            for row,duty in self.pending_cache_transfers:
                need('onceCacheCustody' not in row);row['onceCacheCustody']=deepcopy(duty)
            self.save();self.pending_cache_transfers=[]
        return True

    def select(self,lease,binding):
        if self.shared is not None:self.shared.require_live()
        self.family_guard()
        need(hex32(lease));context(binding);self.lock.assert_held();self.transfer_completed()
        if self.binding is None:
            self.binding=deepcopy(binding);register_scope(self.runtime.adapter,self.selector,self.binding,self.run,self.root)
            self.save()
        else:need(same(self.binding,binding))
        for key,archive in self.archives.items():
            if key!=lease:
                episode=archive.episode_retired();duty=episode['cacheCustody']
                if duty is None or not duty['inputs']:archive.retired()
                else:need(any(row['leaseId']==key and same(row.get('onceCacheCustody'),duty) for row in self.rows))
        rows=[row for row in self.rows if row['leaseId']==lease];need(len(rows)<=1)
        if rows:row=rows[0]
        else:
            need(len(self.rows)<16 and all(item['phase']=='opened' for item in self.rows))
            row=dict(leaseId=lease,phase='planned',rootIdentity=None);self.rows.append(row);self.save()
        child=self.root/(self.CHILD_PREFIX+lease)
        if row['phase']=='planned':
            # This exact predeclared path is born before any native capture.
            # A lost mkdir/birth return leaves planned+existing fail-closed.
            need(not child.exists());os.mkdir(child,0o700);fsync_directory(self.root)
            row.update(phase='opened',rootIdentity=identity(child));self.save()
        need(identity(child)==row['rootIdentity'])
        if self.shared is not None:self.shared.parent_opened(self)
        return child

    def guard(self):
        self.family_guard()
        self.lock.assert_held();need(identity(self.root)==self.root_identity and same(self.store.read(),self.previous))
        need(same(self.scope.read(),dict(iosAudioScopeVersion=1,binding=self.binding,runId=self.run,artifactRoot=str(self.root))))
        if self.shared is None:need({path for path in self.sdkroot.iterdir() if path.name.startswith('ios-audio-')}==self.sdk_audio_paths())
        expected={self.root/(self.CHILD_PREFIX+row['leaseId']) for row in self.rows if row['phase']=='opened'}
        if self.process_end is not None:
            from ios.adapters import audio_once_end
            audio_once_end.shape(self)
            if self.process_end['phase']!='planned':expected.add(audio_once_end.root(self))
        if self.shared is None:need(set(self.root.iterdir())==expected)
        else:self.shared.membership(self,self.sdk_audio_paths(),expected,live=True)
        for row in self.rows:
            need(row['phase']=='opened' and identity(self.root/(self.CHILD_PREFIX+row['leaseId']))==row['rootIdentity'])
        for old in self.oldleases:old.guard()
        return True

    def prepare_process_end(self):
        if self.shared is not None:self.shared.individual_end_refused()
        from ios.adapters.audio_once_end import prepare
        return prepare(self)

    def finish_process_end(self,end):
        if self.shared is not None:self.shared.individual_end_refused()
        from ios.adapters.audio_once_end import finish
        return finish(self,end)

    def retired(self):
        if self.shared is not None:self.shared.individual_end_refused()
        from ios.adapters.audio_once_end import archived
        return archived(self)


class IOSAudioPassiveRuntime(IOSAudioRuntime):
    @contextmanager
    def passive_owner(self,selector,run,lease,artifact_root,client,*,epoch_ms=lambda:time.time()*1000,monotonic=time.monotonic,sleep=time.sleep,source_lock=None,capture_seconds=None):
        """Private explicit Actor selection; never creates SDK/mic input."""
        path=self.state_path(selector).with_name('script-feature-sources.lock')
        lock=ScriptSourceLock(path) if source_lock is None else source_lock
        need(isinstance(lock,ScriptSourceLock) and lock.path==path and capture_seconds in (None,10))
        with lock.held():
            ledger=PassiveSDKLedger(self,selector,run,lease,artifact_root,client,lock)
            ledger.transfer_completed();need(ledger.process_end is None)
            if ledger.shared is not None:ledger.shared.require_live()
            if capture_seconds is not None and lease in ledger.archives:
                need(not any(row['leaseId']==lease and 'onceCacheCustody' in row for row in ledger.rows))
                started=ledger.archives[lease].state['start']
                need(started is None or started['seconds']==capture_seconds)
            # Full pure historical decoding precedes the first fresh source.
            # Installed/SDK continuity still executes via existing factories.
            source=self._sources(selector);need(source['check']() is not False)
            child=ledger.select(lease,source['binding']);ledger.guard()
            original=source['check']
            def check():ledger.guard();need(original() is not False);ledger.guard();return True
            observer=source['observer'];remote=observer.remote.rsplit('/',1)[0]+'/'+FILE
            for transport in (observer,getattr(source['clock_source'].send,'__self__',None)):
                need(transport is not None);before=getattr(transport,'before_send',None)
                def final(before=before):
                    check()
                    if before is not None:need(before() is not False)
                    check()
                transport.before_send=final
            owner=IOSAudioPassiveOwner(PrivateFeatureState(child/'ios-audio-passive-owner.json'),child,source['binding'],run,lease,lock,check,
                native=source['clock_source'],transport=dict(send=observer.send,read=lambda:observer.original(remote=remote,limit=MAX_ORIGINAL)),
                phase=PhaseFixtureReader(client,run,'audio',epoch_ms=epoch_ms,monotonic=monotonic),
                epoch_ms=epoch_ms,monotonic=monotonic,sleep=sleep)
            once_remote=observer.remote.rsplit('/',1)[0]+'/feature-ios-audio-once-cue.json'
            owner.once_transport=dict(send=observer.send,read=lambda:observer.original(remote=once_remote,limit=1024*1024))
            owner.once_script_factory=getattr(observer,'script_execution_observer',None)
            with self.existing_input_session(selector):
                yield owner
                check()

    @contextmanager
    def once_input_owner(self,selector,run,ticket,artifact_root,client,*,epoch_ms=lambda:time.time()*1000,
                         monotonic=time.monotonic,sleep=time.sleep,source_lock=None):
        """Explicit ten-second owned capture; default Actor eight stays literal.

        Callers reopening Primary-linked originals must already hold the paired
        Primary source lock in audio_once_primary.primary_lock_scope.
        """
        from ios.adapters.audio_passive_actor import lease_id
        from ios.adapters.audio_once_custody import AudioOnceCustody
        with self.passive_owner(selector,run,lease_id(run,ticket),artifact_root,client,
                epoch_ms=epoch_ms,monotonic=monotonic,sleep=sleep,source_lock=source_lock,capture_seconds=10) as owner:
            need(owner.state['start'] is None or owner.state['start']['seconds']==10)
            if owner.state['birth'] is None:owner.start(10)
            yield AudioOnceCustody(owner,ticket,owner.once_transport)


def stored_actor_ledger(runtime,selector,run,root,client,lock):
    """Select only an existing typed family; no fresh source or child birth.

    File existence selects a decoder, never authority. Both families together
    are unsupported because each parent's complete scope inventory is exclusive.
    """
    lock.assert_held();sdk=runtime.state_path(selector).parent
    microphone=PrivateFeatureState(sdk/'ios-audio-passive-ledger.json').read()
    received=PrivateFeatureState(sdk/'ios-audio-received-mixer-ledger.json').read()
    from ios.adapters.audio_shared_actor_inventory import selected
    shared=selected(runtime,selector,run,root,client,lock)
    if shared is None:need(microphone is None or received is None)
    else:shared.guard()
    if microphone is None and received is None:return None
    if received is not None and not(shared is not None and microphone is not None):
        from ios.adapters.audio_received_mixer_runtime import ReceivedMixerSDKLedger
        value=received;kind=ReceivedMixerSDKLedger
    else:value=microphone;kind=PassiveSDKLedger
    need(type(value)is dict and type(value.get('leases'))is list)
    lease=value['leases'][-1]['leaseId']if value['leases']else'0'*32
    return kind(runtime,selector,run,lease,root,client,lock)
