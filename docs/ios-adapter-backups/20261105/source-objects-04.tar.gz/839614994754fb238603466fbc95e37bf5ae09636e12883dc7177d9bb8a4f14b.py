"""Exact Root prerequisite join: historical functional4 and current loader6 differ.

This pure reader verifies retained bytes; it never reopens a scenario runtime,
SDK, Source, process or input and does not claim a current-helper four-case run.
"""
from pathlib import Path
import ast
import hashlib
import json
from group_selection import SELECTION,SELECTION_SHA,selected,GROUPS

REPO=Path(__file__).resolve().parents[2]
ROOT=REPO/'.ios-host-tmp'
READINESS=ROOT/'root-chat-source1-functional4-and-current-c10c-cache6-readiness-20261104'
READINESS_SHA='839195fe485a5a96845bb93e05e3fb1a6831490f3257d73cd2b2d7a3fba968a0'
READY_JSON_SHA='88c0c72a147bc83c1c17e0d1d6ff90c942dcccd74ea3b8afa49830a1b7d4068d'
FUNCTIONAL=ROOT/'root-chat-offline-c10b-four-functional-fresh-source-pass-counter-runtime-pending-results-20261104'
FUNCTIONAL_SHA='f9769846d73571734393ee76d6a688893f42bbd42da5801ab41b31daafc117ef'
COUNTERS=ROOT/'root-c10c-source-execution-six-cache-mutation-alias-counters-qualified-results-20261104'
COUNTERS_SHA='8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a'
OLD=ROOT/'chat-offline-source1-initial4-controller10b-consistent-source-execution-rows-code-preparation-20261104'
OLD_SHA='297d441f42962ea8866b684a91cbae40f4d1b0121ef9c8e9037c02adae28d2e5'
CURRENT=ROOT/'chat-offline-source1-initial4-controller10c-copied-bootstrap-namespace-row-code-preparation-20261104'
CURRENT_SHA='63f5ffc563996ad7793a600cb6a16c53d8df05a54d65db24321a1a2b5c020fc4'
HELPER_SHA='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
PROPOSAL=ROOT/'chat-offline-send-no-replay-source1-private-20261104'
PROPOSAL_SHA='b1df990cbb9187fe6982cafe0a9e4065283eb541c7f30860162afd624a390f9b'


def load(path):return json.loads(Path(path).read_text())
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def actual(path,expected,files):
    path=Path(path)
    assert path.is_absolute()and path.resolve(strict=True)==path and path.is_file()and not path.is_symlink()
    assert digest(path)==expected
    previous=files.setdefault(str(path),expected)
    assert previous==expected
    return path


def packet(directory,leaf,expected,files):
    directory=Path(directory)
    path=actual(directory/leaf,expected,files)
    rows=load(path)['files']
    entries=((row['path'],row)for row in rows)if type(rows)is list else rows.items()
    for name,row in entries:
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        path=directory/name
        assert path.is_relative_to(directory)
        actual(path,row if type(row)is str else row['sha256'],files)


def references(directory,count,files):
    rows=load(directory/'actual-receipt-references.json')
    assert type(rows)is dict and len(rows)==count
    roots=[Path(name)for name in load(directory/'results.json')['newOriginalRoots']]
    for row in rows.values():
        assert type(row)is dict and set(row)=={'path','sha256'}
        path=Path(row['path'])
        assert any(path.is_relative_to(root)for root in roots)
        actual(path,row['sha256'],files)


def require_real_prerequisites(value):
    assert type(value)is dict and set(value)=={'readiness'}
    assert value['readiness']==dict(path=str(READINESS/'freeze.json'),sha256=READINESS_SHA)
    files={}
    for directory,leaf,expected in((READINESS,'freeze.json',READINESS_SHA),
        (FUNCTIONAL,'freeze.json',FUNCTIONAL_SHA),(COUNTERS,'freeze.json',COUNTERS_SHA),
        (OLD,'source-freeze.json',OLD_SHA),(CURRENT,'source-freeze.json',CURRENT_SHA),
        (PROPOSAL,'freeze.json',PROPOSAL_SHA),(SELECTION,'source-freeze.json',SELECTION_SHA)):
        packet(directory,leaf,expected,files)
    actual(READINESS/'readiness.json',READY_JSON_SHA,files)
    ready=load(READINESS/'readiness.json')
    assert ready['status']=='ROOT_SOURCE1_FUNCTIONAL_INITIAL4_AND_CURRENT_C10C_LOADER_COUNTER6_PREREQUISITES_REVIEWED'
    assert ready['source1ProposalFreeze']==PROPOSAL_SHA
    assert ready['initialFourControllerFreeze']==OLD_SHA and ready['initialFourActualPassed']==4
    assert ready['initialFourAndCurrentCounterAreDifferentExplicitScopes']is True
    assert ready['currentHelperSourceFreeze']==CURRENT_SHA and ready['currentHelperSha256']==HELPER_SHA
    assert ready['currentHelperCounter6Qualified']is True and ready['currentHelperFourRerunClaimed']is False
    assert ready['initialFourResultProof']==dict(path=str(FUNCTIONAL/'freeze.json'),sha256=FUNCTIONAL_SHA)
    assert ready['currentHelperCounterProof']==dict(path=str(COUNTERS/'freeze.json'),sha256=COUNTERS_SHA)
    assert ready['remainingSelectionSource']==dict(path=str(SELECTION/'source-freeze.json'),sha256=SELECTION_SHA)
    selection=load(SELECTION/'selections.json')
    assert ready['initialFourIds']==selection['preservedInitialFour']
    assert ready['allowedNewGroups']=={group:selected(group)for group in GROUPS}
    assert ready['perNewGroup']==dict(TDsPerExecutedCase=3,cases=5,graceSeconds=5,maxLiveNodes=1,maxSequentialNodes=5,seconds=180)
    assert all(ready[name]is True for name in('allActualPrerequisiteResourcesAbsent','allSixFourCaseExecutorsUnchanged',
        'allSource1FrozenMembersUnchanged','requiresNewFiveControllerAndFreshRootMetadata','publicCurrentOriginAll14QualificationPending'))
    assert all(ready[name]is False for name in('completeChatQualified','nativeQualified','wholeQualified'))
    old=(OLD/'closed_import_origins.py').read_text();current=(CURRENT/'closed_import_origins.py').read_text()
    needle="            if name in self.initial_modules:\n                row['hostBootstrap']"
    assert old.count(needle)==1
    assert current==old.replace(needle,"            if name in self.initial_modules:\n                row = dict(row)\n                row['hostBootstrap']",1)
    assert digest(CURRENT/'closed_import_origins.py')==HELPER_SHA
    def methods(text):
        cls=next(node for node in ast.parse(text).body if isinstance(node,ast.ClassDef)and node.name=='ClosedOrigins')
        return {node.name:ast.dump(node,include_attributes=False)for node in cls.body if isinstance(node,ast.FunctionDef)}
    before,after=methods(old),methods(current)
    for name in ready['unchangedClosedOriginsMethods']:assert before[name]==after[name]
    for name in('metadata.py','chat_node_port.py','raw_pipe_tee.py','owned_write_boundary.py','run-four.py','supervise.py'):
        assert (OLD/name).read_bytes()==(CURRENT/name).read_bytes()
    four=load(FUNCTIONAL/'results.json');six=load(COUNTERS/'results.json')
    assert four['status']=='ACTUAL_CHAT_C10B_ORIGINAL4_FUNCTIONAL_AND_ALL_DECLARED_GATES_PASS_FRESH_SOURCE_RECORDS_CACHE_COUNTER_RUNTIME_PENDING'
    assert four['controllerFreeze']==OLD_SHA
    assert four['actualStartedCases']==four['actualBodyPassedCases']==four['actualDeclaredControllerGatesPassedCases']==4
    assert four['actualGenuineTemporaryDirectories']==12 and four['actualNodeBirths']==4
    assert four['remainingInitialSelectedCasesUnrun']==0 and four['otherSource1TenCasesUnrun']is True
    assert four['outerTerminal']['selected']==ready['initialFourIds']
    assert four['outerTerminal']['status']=='PASS'and not four['outerTerminal']['problems']
    assert all(four[name]is True for name in('actualAllNodeEndZeroSubscriptionsStreamCloseAbsence','actualRegisteredStandardCleanupsDrained',
        'all27PortsAndCioRestored','all708OldOriginalBodiesUnchanged','all9463PhysicalPinsUnchanged'))
    assert four['fullInitialFourSourceExecutionQualified']is False and four['cachePoisonAndMutationCounterRuntimeQualified']is False
    assert six['status']=='ACTUAL_C10C_FRESH_SOURCE_CACHE_MUTATION_COMPILER_STDLIB_ALIAS_COUNTER6_AND_ALL_UTILITY_GATES_PASS'
    assert six['subjectSourceFreeze']==CURRENT_SHA and six['subjectHelperSha256']==HELPER_SHA
    assert six['actualStartedCases']==six['actualPassedCases']==six['actualGenuineTemporaryDirectories']==6
    assert six['actualFailedCases']==six['actualUnrunCases']==six['actualCallbackErrors']==0
    assert six['actualIds']==ready['currentHelperCounterIds']
    assert six['NodeExecutions']==six['SDKExecutions']==six['overteNativeQueries']==six['globalScans']==six['oldScenarioOriginalInputs']==0
    assert six['actualOriginSnapshots']==18 and six['actualRuntimeOrigins']==2 and six['actualOriginalStandardCleanupCalls']==6
    assert all(six[name]is True for name in('sourceExecutionCounterQualified','actualCompileExecRebindRefusalQualified',
        'actualGenericStdlibExecutionRowEqualityQualified','actualGenuineFourExpatNamesAndForeignReceiverRefusalQualified',
        'actualSourceMutationRefusalQualified','cachePoisonTimestampAndUncheckedRefusalQualified','all27OsCioDupToolsRestored',
        'all725FrozenSourceBinaryPinsUnchanged','actualInputAndCliShaUnchanged','parentFDThreadAndKernelDrain','twoWholeOwnCensusesEqual'))
    for result in(four,six):
        assert result['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
        assert result['nativeQualified']is False and result['wholeQualified']is False and result['deviceQualified']is False
    assert six['wholeChatQualified']is False and six['realNetwork']is False
    references(FUNCTIONAL,211,files);references(COUNTERS,48,files)
    summary=dict(readinessFreeze=READINESS_SHA,initialFourControllerFreeze=OLD_SHA,currentHelperSourceFreeze=CURRENT_SHA,
        currentHelperSha256=HELPER_SHA,initialFourPassed=4,currentHelperCounter6Qualified=True,currentHelperFourRerunClaimed=False,
        initialFourAndCurrentCounterAreDifferentExplicitScopes=True,publicCurrentOriginAll14QualificationPending=True,
        completeChatQualified=False,nativeQualified=False,wholeQualified=False,deviceQualified=False)
    return dict(physicalFiles=files,summary=summary,newOriginalRoots=four['newOriginalRoots']+six['newOriginalRoots'])
