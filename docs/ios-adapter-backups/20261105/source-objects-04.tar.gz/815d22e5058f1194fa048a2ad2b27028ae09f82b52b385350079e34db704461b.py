from pathlib import Path
import hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,value):
    fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w')as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def pin(p):
    p=Path(p);a=p.lstat();assert stat.S_ISREG(a.st_mode)or stat.S_ISDIR(a.st_mode)
    row={k:getattr(a,k)for k in FIELDS}
    if stat.S_ISREG(a.st_mode):row['sha256']=sha(p)
    assert all(getattr(p.lstat(),k)==v for k,v in row.items()if k!='sha256');return row
def sources():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths={REPO/n for n in names if n}|{REPO/'CMakeLists.txt',REPO/'interface/CMakeLists.txt'}
    plan=json.loads((HERE/'plan.json').read_text());packet=REPO/plan['sourcePacket']
    for base in (packet,*(REPO/name for name in plan.get('extraSourcePackets',[])),HERE):
        frozen=json.loads((base/'freeze.json').read_text())
        for name,digest in frozen['files'].items():assert sha(base/name)==digest;paths.add(base/name)
        paths.add(base/'freeze.json')
    return {str(p):pin(p)for p in sorted(paths)}
def census(root):return {str(p.relative_to(root)):pin(p)for p in (root,*sorted(root.rglob('*')))}
def proc(pid):
    try:f=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except(FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(f[1]),group=int(f[2]),session=int(f[3]),startTicks=int(f[19]))
def processes(session):
    values=[]
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            row=proc(int(p.name))
            if row is not None and(row['group']==session or row['session']==session):values.append(row)
    return values
def fds():
    rows={}
    for p in Path('/proc/self/fd').iterdir():
        try:rows[p.name]=os.readlink(p)
        except(FileNotFoundError,ProcessLookupError):pass
    return rows
