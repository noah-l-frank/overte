"""Root-only closed source frontier; no target/project imports on this path."""
from pathlib import Path
import importlib.machinery,json,os,sys
from metadata_reader import pin,load
from source_execution_admission import qualify,HELPER
from c10d_admission import qualify as current_qualification
from backend_dirfd_admission import require_backend_dirfd_qualification
from diagnostic_qualification import require_diagnostic_qualification
HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent
HISTORICAL_SUBJECT_ROOT=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller10c-copied-bootstrap-namespace-row-code-preparation-20261104'
HISTORICAL_QUALIFICATION=REPO/'.ios-host-tmp/root-c10c-source-execution-six-cache-mutation-alias-counters-qualified-results-20261104'

def project_namespace_admission(declared,ordered_roots):
    """Keep impossible aliases as pinned data; admit only real parent paths.

    Splitting a fullname produced from overte.sikuli/overte.py cannot create
    the nonexistent directories overte/sikuli. No namespace is invented and
    no bare alias or fallback loader is granted for such retained source.
    """
    choices={};failed={}
    for fullname in declared:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in declared:continue
            if name not in choices:
                choices[name]=sorted({str((Path(root)/Path(*parts[:size])).resolve(strict=True))
                    for root in ordered_roots if(Path(root)/Path(*parts[:size])).is_dir()})
            if len(choices[name])!=1:
                failed.setdefault(name,dict(physicalChoices=choices[name],affectedAliases=[]))['affectedAliases'].append(fullname)
    refused={}
    for name,row in failed.items():
        row['affectedAliases']=sorted(set(row['affectedAliases']))
        for fullname in row['affectedAliases']:
            entry=refused.setdefault(fullname,dict(origin=dict(declared[fullname]),unresolvableNamespaces=[]))
            entry['unresolvableNamespaces'].append(name)
    for row in refused.values():row['unresolvableNamespaces'].sort()
    admitted={name:row for name,row in declared.items()if name not in refused}
    namespaces={}
    for fullname in admitted:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in admitted:continue
            assert name not in refused and len(choices[name])==1
            namespaces[name]=choices[name]
    return admitted,namespaces,dict(version=1,declaredAliasCount=len(declared),
        admittedAliasCount=len(admitted),unadmittedAliases=refused,unresolvableNamespaces=failed,
        unadmittedSourcesRetainedAsData=True,unadmittedImportAuthority=False)

def prepare(destination,view,modules,ordered_roots,copy_source):
    physical={}
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        value=pin(path)
        if digest is not None:assert value['sha256']==digest
        physical[str(path)]=value;return value
    # Genuine current source-execution prerequisite is the exact actual14
    # aggregate. Historical C10c files remain retained data below.
    actual=current_qualification(REPO,pin,physical);qualified=actual
    boundary_qualification,boundary_files=require_backend_dirfd_qualification(REPO,pin,copy_source)
    physical.update(boundary_files)
    diagnostic_qualification,diagnostic_files=require_diagnostic_qualification(REPO,pin,copy_source)
    physical.update(diagnostic_files)
    assert boundary_qualification['currentSourceAlgorithm']==actual
    tested_backend=boundary_qualification['actualSourceOrigins']['adapters.asset_backend_files']['sha256']
    assert modules['adapters.asset_backend_files']['sha256']==tested_backend
    for folder,filename,digest in((HISTORICAL_SUBJECT_ROOT,'source-freeze.json','63f5ffc563996ad7793a600cb6a16c53d8df05a54d65db24321a1a2b5c020fc4'),
            (HISTORICAL_QUALIFICATION,'freeze.json','8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a')):
        keep(folder/filename,digest);body=load(folder/filename)
        for name,row in body['files'].items():keep(folder/name,row if type(row)is str else row['sha256'])
    qualify(dict(qualifiedSourceExecution=qualified,physicalPins=physical),pin)
    assert keep(destination/'closed_import_origins.py')['sha256']==HELPER
    assert len(load(destination/'readonly-shared-stdlib-sources.json')['sources'])==7
    # Keep every original runtime source alias, plus exact controller modules.
    modules=dict(modules)
    for name in('metadata','metadata_reader','closed_import_origins','closed_source_metadata','source_execution_admission','scoped_ports','typed_observer','owned_write_boundary','backend_dirfd_ports','backend_dirfd_admission','intent_graph_diagnostic','diagnostic_qualification','c10d_admission'):
        path=destination/(name+'.py');value=keep(path);assert name not in modules
        modules[name]=dict(path=str(path),relativePath=None,sha256=value['sha256'],package=False)
    path=destination/'monitoring_observer.py';value=keep(path)
    assert 'assets_current_original_process_observer'not in modules
    modules['assets_current_original_process_observer']=dict(path=str(path),relativePath=None,sha256=value['sha256'],package=False)
    for row in modules.values():keep(row['path'],row['sha256'])
    for name in('run-one.py','supervise.py','historical-controller24-run-one.py.txt','readonly-shared-stdlib-sources.json','readonly-own-public-source-verification.json','third-party-source-declarations.json'):keep(destination/name)
    # Every declared row was pinned above, including rejected aliases. Only
    # import authority is narrowed; source/origin/raw custody is not removed.
    modules,namespaces,alias_admission=project_namespace_admission(modules,ordered_roots)
    third={};declarations=load(copy_source/'third-party-source-declarations.json');assert len(declarations)==39
    for name,row in declarations.items():
        value=keep(row['path'],row['sha256']);third[name]=dict(path=row['path'],sha256=value['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    std=Path(os.__file__).resolve(strict=True).parent;suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);std_namespaces={}
    for current,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current);dirs[:]=sorted(name for name in dirs if name not in('site-packages','dist-packages','__pycache__')and not(folder/name).is_symlink())
        relative=folder.relative_to(std)
        if relative.parts and all(name.isidentifier()for name in relative.parts)and not(folder/'__init__.py').is_file():std_namespaces['.'.join(relative.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix=='.py'or str(path).endswith(suffixes):keep(path)
    python=Path(sys.executable).resolve(strict=True);executable=keep(python)
    own_metadata=set();declaration=load(destination/'readonly-own-public-source-verification.json');assert len(declaration['paths'])==8
    for path,row in declaration['paths'].items():
        original=Path(path);assert original.is_relative_to(REPO/'tests/device/adapters/appium');keep(original,row['sha256'])
        copied=view/original.relative_to(REPO);keep(copied,row['sha256']);own_metadata.update((str(original),str(copied)))
    # This exact own adapter is a necessary pure definition imported by the
    # genuine NativeInput constructor. It is not the installed appium package.
    for path in(REPO/'tests/device/ios/adapters/appium_adapter.py',view/'tests/device/ios/adapters/appium_adapter.py'):
        keep(path);own_metadata.add(str(path))
    assert modules['ios.adapters.appium_adapter']['path']==str(view/'tests/device/ios/adapters/appium_adapter.py')
    result=dict(modules=modules,namespacePackages=namespaces,projectAliasAdmission=alias_admission,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=std_namespaces,
        stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=executable),physicalPins=physical,ownForbiddenMetadataReadPaths=sorted(own_metadata),
        hostBootstrap='Held initial interpreter/stdlib/controller module receivers; not claimed to have been compiled through the delegated current C10d path',
        qualifiedSourceExecution=qualified,qualificationOutputRoots=actual['requiredOriginalRoots'],historicalC10cIsDataOnly=True,
        backendOwn9Qualification=boundary_qualification,backendOwn9RequiredOriginalRoots=boundary_qualification['requiredOriginalRoots'],
        diagnosticUtilityQualification=diagnostic_qualification,diagnosticRequiredOriginalRoots=diagnostic_qualification['requiredOriginalRoots'])
    return result

def validate():
    closure=load(HERE/'closed-source-inputs.json');assert closure['physicalPins']
    assert {path:pin(path)for path in closure['physicalPins']}==closure['physicalPins']
    assert closure['qualifiedSourceExecution']['helperSha256']==HELPER
    assert pin(HERE/'closed_import_origins.py')['sha256']==HELPER
    qualify(closure,pin)
    context=load(HERE/'root-terminal-context.json')
    assert set(closure['qualificationOutputRoots'])<=set(context['originalRoots'])
    boundary_qualification,boundary_files=require_backend_dirfd_qualification(REPO,pin,HERE)
    assert closure['backendOwn9Qualification']==boundary_qualification
    assert closure['backendOwn9RequiredOriginalRoots']==boundary_qualification['requiredOriginalRoots']
    assert set(boundary_qualification['requiredOriginalRoots'])<=set(context['originalRoots'])
    assert all(closure['physicalPins'].get(path)==row for path,row in boundary_files.items())
    assert closure['modules']['adapters.asset_backend_files']['sha256']==boundary_qualification['actualSourceOrigins']['adapters.asset_backend_files']['sha256']
    assert set(closure['modules'])==set(load(HERE/'absolute-import-origin-map.json')['modules'])
    origin_map=load(HERE/'absolute-import-origin-map.json')
    assert closure['modules']==origin_map['modules']
    admission=closure['projectAliasAdmission']
    assert admission['version']==1 and admission['unadmittedSourcesRetainedAsData']is True
    assert admission['unadmittedImportAuthority']is False
    declared=dict(closure['modules'])
    for fullname,row in admission['unadmittedAliases'].items():
        assert fullname not in declared and row['unresolvableNamespaces']
        origin=row['origin'];path=Path(origin['path'])
        assert path.is_relative_to(HERE/'source')and path.resolve(strict=True)==path
        assert pin(path)==closure['physicalPins'][str(path)]and pin(path)['sha256']==origin['sha256']
        declared[fullname]=origin
    actual,namespaces,replayed=project_namespace_admission(declared,origin_map['orderedRoots'])
    assert actual==closure['modules']and namespaces==closure['namespacePackages']and replayed==admission
    diagnostic_qualification,diagnostic_files=require_diagnostic_qualification(REPO,pin,HERE)
    assert closure['diagnosticUtilityQualification']==load(HERE/'execution-plan.json')['diagnosticUtilityQualification']==diagnostic_qualification
    assert closure['diagnosticRequiredOriginalRoots']==diagnostic_qualification['requiredOriginalRoots']
    assert set(diagnostic_qualification['requiredOriginalRoots'])<=set(context['originalRoots'])
    assert all(closure['physicalPins'].get(path)==row for path,row in diagnostic_files.items())
    return closure
