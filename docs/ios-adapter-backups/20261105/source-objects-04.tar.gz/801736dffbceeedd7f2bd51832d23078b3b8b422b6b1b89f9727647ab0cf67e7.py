"""Source-only genuine utility contexts; no metadata/target admission here.

A future reviewed Root runner supplies the actual closed-loader source rows.
This scope must be the sole installed writer router, not stacked over another
Python OS router. The root is the real retained qualifier TEMP, never a source
or original-input tree. Its added audit hook becomes passive after exit.
"""
from contextlib import contextmanager
from pathlib import Path
from types import MappingProxyType
import builtins,io,os,sys,threading
from owned_write_boundary import OwnedWrites,WriteRefusal
from backend_dirfd_ports import BackendDirFDPorts


class QualificationRuntime:
    def __init__(self,temporary,source_pin,source_rows,backend_module,process_module):
        self.temporary=Path(temporary).resolve(strict=True)
        self.helper=OwnedWrites(self.temporary)
        self.originals=MappingProxyType(dict(self.helper.original))
        self.helper.original=self.originals;self.helper.original_items=tuple(self.originals.items())
        self.boundary=BackendDirFDPorts(self.helper,self.originals,source_pin)
        self.original_io,self.original_builtin=io.open,builtins.open
        self.thread=threading.get_ident();self.active=False;self.used=False;self.ports={};self.audit_refusals=[]
        for module in(backend_module,process_module):
            row=source_rows[module.__name__]
            self.boundary.bind(module,Path(row['path']),row['pin'])

    @contextmanager
    def scope(self):
        if self.used or self.active or threading.get_ident()!=self.thread:raise WriteRefusal('Qualification scope birth/thread')
        self.used=True
        if any(getattr(os,name)is not value for name,value in self.originals.items()):
            raise WriteRefusal('Qualification requires held original OS receivers')
        def audit(event,args):
            relevant=event in('open','os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.utime','os.truncate',
                'os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
            if not self.active or not relevant:return
            self.helper.audit(event,args,sys._getframe(1))
        self.audit_hook=audit;sys.addaudithook(audit)
        for name in self.originals:
            def port(*args,_name=name,**kwargs):
                if _name=='close'and(len(args)!=1 or kwargs or type(args[0])is not int
                        or args[0]not in self.boundary.roots and args[0]not in self.boundary.files):
                    return self.originals['close'](*args,**kwargs)
                caller=sys._getframe(1)
                if self.boundary.metadata_read(_name,args,kwargs,caller):return self.helper.os_open(*args,**kwargs)
                handled,result=self.boundary.dispatch(self.helper,_name,args,kwargs,caller)
                if handled:return result
                if _name=='close':return self.originals['close'](*args,**kwargs)
                return self.helper.os_open(*args,**kwargs)if _name=='open'else self.helper.mutate(_name,*args,**kwargs)
            self.ports[name]=port;setattr(os,name,port)
        self.active=True
        try:yield self
        finally:
            primary=sys.exception();self.drain_errors=[]
            try:
                if any(getattr(os,name)is not port for name,port in self.ports.items()):
                    raise WriteRefusal('Qualification router changed before restoration')
                self.receipt=self.boundary.finish()
            except BaseException as error:self.drain_errors.append(error)
            finally:
                for name,value in self.originals.items():
                    try:setattr(os,name,value)
                    except BaseException as error:self.drain_errors.append(error)
                self.active=False
                try:self.helper.close()
                except BaseException as error:self.drain_errors.append(error)
            if any(getattr(os,name)is not value for name,value in self.originals.items())or io.open is not self.original_io or builtins.open is not self.original_builtin:
                self.drain_errors.append(WriteRefusal('Qualification OS/CIO restoration failed'))
            if self.drain_errors and primary is None:raise self.drain_errors[0]
