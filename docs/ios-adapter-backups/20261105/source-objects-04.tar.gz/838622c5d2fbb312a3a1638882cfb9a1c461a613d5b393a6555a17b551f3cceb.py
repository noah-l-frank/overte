"""Actual source query/WAL/HTTP/file/codecs; native/RSD/AFC are explicit models.

Synthetic directory bytes are independently measured before producer birth.
Nothing here runs native code or grants original-child IPA/motion authority.
"""
from __future__ import annotations
import asyncio,hashlib,json,threading,uuid
from concurrent.futures import Future
from copy import deepcopy
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from unittest.mock import patch
import native_file_fixture as file_fixture


class ChildBundleProfileModels(file_fixture.OriginalNativeFileChannelModels):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        from ios.self_tests import test_ios_bundle_identity as archive_fixture
        from ios.self_tests.test_ios_bundle_observation import Boundary
        from ios.self_tests.retained_host_roots import retain_owned_root
        from ios.adapters.bundle_identity import artifact_bundle,compare
        self.archive=archive_fixture.BundleIdentityTests();self.archive.setUp()
        retain_owned_root(self.archive.temp,expected_root=Path(self.archive.temp.name))
        for callback,args,kwargs in self.archive._cleanups:
            if getattr(callback,'__self__',None) is self.archive.temp:callback=self.archive.temp.cleanup
            self.addCleanup(callback,*args,**kwargs)
        self.archive._cleanups.clear()
        self.artifact_sha=self.archive.archive();self.measured_bundle=self.archive.actual_directory_manifest()
        compare(self.measured_bundle,artifact_bundle(self.archive.path,self.artifact_sha))
        self.native=Boundary();self.native.bundle=deepcopy(self.measured_bundle)
        self.source._native_queries=[];self.loop=asyncio.get_running_loop();self.run='a'*32
        self.received=[];self.http_errors=[];self.after_produce=None
        outer=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*_):pass
            def do_POST(self):
                try:
                    raw=self.rfile.read(int(self.headers['Content-Length']));query=json.loads(raw);future=Future()
                    def produce():
                        try:
                            outer.native.send(query);outer.received.append(deepcopy(query))
                            outer.input.write_text(outer.native.original())
                            if outer.after_produce:outer.after_produce()
                            future.set_result(None)
                        except BaseException as error:future.set_exception(error)
                    outer.loop.call_soon_threadsafe(produce);future.result(timeout=5)
                    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
                except (BrokenPipeError,ConnectionResetError):pass
                except BaseException as error:outer.http_errors.append(error)
        self.server=HTTPServer(('127.0.0.1',0),Handler);self.origin='http://127.0.0.1:'+str(self.server.server_address[1])
        self.server_thread=threading.Thread(target=lambda:self.server.serve_forever(poll_interval=.01),name='child-bundle-source-model-http',daemon=False)
        self.server_thread.start();self.addAsyncCleanup(self.close_server)
    async def close_server(self):
        for task in self.tasks:
            try:await asyncio.shield(task)
            except BaseException:pass
        self.server.shutdown();self.server.server_close();self.server_thread.join(timeout=5)
        self.assertFalse(self.server_thread.is_alive());self.assertEqual([],self.http_errors)
    def query_args(self):return dict(binding=deepcopy(self.binding),runId=self.run,resultsDirectory='owned',origin=self.origin,action='ios-bundle-observe',nativeBundleProfileVersion=1)
    async def issue(self,args=None):
        task=asyncio.create_task(self.ops.execute('touch-native-query',self.query_args() if args is None else args,self.binding['sessionId']));self.tasks.append(task)
        return await task
    def read_args(self,value):return dict(binding=deepcopy(self.binding),runId=self.run,resultsDirectory='owned',query=deepcopy(value['query']),nativeBundleProfileVersion=1)
    async def original(self,value,args=None):
        task=asyncio.create_task(self.ops.execute('touch-native-original-read',self.read_args(value) if args is None else args,self.binding['sessionId']));self.tasks.append(task)
        return await task
    def journal(self):return self.ops.native_query_journals[self.run]

    async def test_actual_owned_http_nonce_fixed_original_file_and_independent_ipa_bytes_join_without_child_candidate_authority(self):
        from ios.adapters.bundle_identity import compare
        value=await self.issue();raw=self.input.read_bytes();result=await self.original(value)
        self.assertEqual(2,value['originalKeeperNativeQueryVersion']);self.assertEqual(2,result['originalKeeperNativeFileVersion'])
        self.assertEqual(raw,result['rawJson'].encode());self.assertEqual(hashlib.sha256(raw).hexdigest(),result['sha256'])
        packet=json.loads(raw);compare(packet['bundle'],self.measured_bundle)
        self.assertEqual(value['query'],self.journal()['previous']['records'][0]['query']);self.assertEqual('http-returned',self.journal()['previous']['records'][0]['phase'])
        self.assertEqual(2,self.journal()['previous']['originalKeeperNativeQueryOwnerVersion'])
        self.assertIn(('open','/Documents/owned/ios-installed-bundle-observation.json','r'),self.services[0].calls)
        self.assertTrue(all(row[4].is_set() for row in self.source._native_reads))
        self.assertTrue(all(result[k] is False for k in ('queryIssuanceOwned','installedCandidateBound','freshNativeAcquisitionEstablished','physicalFileIdentityEstablished','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished')))

    async def test_bundle_action_without_optional_profile_fails_before_http_or_original_service(self):
        args=self.query_args();args.pop('nativeBundleProfileVersion')
        with self.assertRaises((RuntimeError,ValueError)):await self.issue(args)
        value=dict(query=dict(schemaVersion=1,commandId='ios-'+'a'*32,action='ios-bundle-observe'))
        args=self.read_args(value);args.pop('nativeBundleProfileVersion')
        with self.assertRaises((RuntimeError,ValueError)):await self.original(value,args)
        self.assertEqual([],self.received);self.assertEqual([],self.services)

    async def test_unknown_boolean_profile_and_profile_on_legacy_action_refuse_before_effect(self):
        for version in (True,2):
            args=self.query_args();args['nativeBundleProfileVersion']=version
            with self.assertRaises((RuntimeError,ValueError)):await self.issue(args)
        args=self.query_args();args['action']='feature-native-observe'
        with self.assertRaises((RuntimeError,ValueError)):await self.issue(args)
        self.assertEqual([],self.received);self.assertEqual([],self.services)

    async def test_matching_packet_and_nonce_without_actual_live_query_owner_refuse_before_service(self):
        value=dict(query=dict(schemaVersion=1,commandId='ios-'+uuid.uuid4().hex,action='ios-bundle-observe'))
        self.native.send(value['query']);self.input.write_text(self.native.original())
        with self.assertRaises((RuntimeError,ValueError)):await self.original(value)
        self.assertEqual({},self.ops.native_query_journals);self.assertEqual([],self.services)

    async def test_actual_foreign_file_nonce_refuses_after_open_and_closes_original_service(self):
        value=await self.issue();packet=json.loads(self.input.read_bytes());packet['commandId']='ios-'+'f'*32;self.input.write_text(json.dumps(packet))
        with self.assertRaises((RuntimeError,ValueError)):await self.original(value)
        self.assertEqual(1,len(self.received));self.assertTrue(self.source._native_reads[0][4].is_set())
        self.assertTrue(all(resource.fileno()==-1 for resource in self.services[0].sockets))

    async def test_original_rsd_swap_during_vend_refuses_without_reauthentication_and_retains_actual_close(self):
        value=await self.issue();original=self.rsd;self.hook=lambda _:setattr(self,'rsd',type(original)())
        try:
            with self.assertRaises((RuntimeError,ValueError)):await self.original(value)
        finally:self.rsd=original
        self.assertEqual(1,len(self.received));self.assertNotIn(('enter',),self.services[0].calls)
        self.assertTrue(self.source._native_reads[0][4].is_set())

    async def test_pending_bundle_original_stays_literal_pending_without_polling_or_freshness_promotion(self):
        self.native.pending=1
        value=await self.issue();result=await self.original(value);packet=json.loads(result['rawJson'])
        self.assertEqual('pending',packet['status']);self.assertEqual({},packet['bundle']);self.assertEqual(0,packet['preparedEpochMs'])
        self.assertEqual(1,len(self.received));self.assertFalse(result['freshNativeAcquisitionEstablished']);self.assertFalse(result['installedCandidateBound'])

    async def test_lost_actual_intent_save_ack_keeps_pending_and_never_issues_or_adopts_http_nonce(self):
        from adapters.normal_feature_state import PrivateFeatureState
        real=PrivateFeatureState.write
        def lost(store,value,previous):
            real(store,value,previous)
            if store.path.name=='ios-lifecycle-native-query-owner-'+self.run+'.json':raise OSError('Declared return lost after original durable write')
        with patch.object(PrivateFeatureState,'write',new=lost):
            with self.assertRaises(OSError):await self.issue()
        journal=self.journal();self.assertIsNotNone(journal['pending']);self.assertEqual([],self.received)
        with self.assertRaises((RuntimeError,ValueError)):await self.issue()
        self.assertEqual([],self.received);self.assertEqual([],self.services)
