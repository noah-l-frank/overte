/* Supervisor transport/process boundary only; no feature verdict or clock edit. */
import fs from 'node:fs';
import net from 'node:net';
import cp from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import {createHash} from 'node:crypto';
import path from 'node:path';
import assert from 'node:assert/strict';
const root=fs.realpathSync(process.env.AUDIO_MODEL_AUDIT_ROOT);
const plan=JSON.parse(fs.readFileSync(path.join(root,'preimport-map.json')));
const parts=JSON.parse(fs.readFileSync(path.join(root,'original-parent-source-map.json')));
const pins=JSON.parse(fs.readFileSync(path.join(root,'binary-pins.json')));
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
assert.equal(hash(pins.node.path),pins.node.sha256);assert.equal(fs.realpathSync(process.execPath),pins.node.path);
for(const value of Object.values(parts))assert.equal(hash(value.path),value.sha256);
function identity(pid){const raw=fs.readFileSync('/proc/'+pid+'/stat','utf8');const f=raw.slice(raw.lastIndexOf(')')+2).trim().split(/\s+/);return {pid,parent:Number(f[1]),group:Number(f[2]),session:Number(f[3]),startTicks:Number(f[19])};}
const selfIdentity=identity(process.pid);const ownSession=Number(process.env.AUDIO_OWNED_SESSION);assert.equal(selfIdentity.group,ownSession);assert.equal(selfIdentity.session,ownSession);
const receipt={identity:selfIdentity,pid:process.pid,nodeSource:process.argv[1],listeners:[],connects:[],spawns:[],refusals:[],exit:null};
const receiptPath=path.join(root,'guard-node-'+process.pid+'.json');
const save=()=>fs.writeFileSync(receiptPath,JSON.stringify(receipt,null,2)+'\n',{mode:0o600});
function refusal(kind){receipt.refusals.push(kind);save();throw Error('AUDIT_REFUSED_'+kind);}
const listen=net.Server.prototype.listen;
net.Server.prototype.listen=function(...args){
  const first=args[0];const host=typeof first==='object'?first.host:args[1];const port=typeof first==='object'?first.port:first;
  if(host!=='127.0.0.1'||port!==0)return refusal('nonowned-listener');
  this.once('listening',()=>{const value=this.address();assert.equal(value.address,'127.0.0.1');receipt.listeners.push(value);save();});
  return listen.apply(this,args);
};
const connect=net.Socket.prototype.connect;
net.Socket.prototype.connect=function(...args){
  let first=args[0];if(Array.isArray(first))first=first[0];
  const host=typeof first==='object'?first.host:args[1];const port=typeof first==='object'?first.port:first;
  if(host!=='127.0.0.1'||!receipt.listeners.some(row=>row.port===Number(port)))return refusal('nonowned-connect');
  receipt.connects.push({host,port:Number(port)});save();return connect.apply(this,args);
};
const spawn=cp.spawn;
cp.spawn=function(file,args,options){
  if(options?.detached!==undefined&&options.detached!==false)return refusal('detached-process');
  if(fs.realpathSync(file)!==pins.python.path||hash(file)!==pins.python.sha256||args?.length!==3||args[0]!=='-B'||args[1]!==parts.child.path||!path.resolve(args[2]).startsWith(root+path.sep)||receipt.spawns.length>=2)
    return refusal('nonowned-process');
  const config=JSON.parse(fs.readFileSync(args[2]));
  assert.equal(config.child.path,parts.child.path);assert.equal(config.child.sha256,parts.child.sha256);
  assert.equal(config.gateway.path,parts.gateway.path);assert.equal(config.gateway.sha256,parts.gateway.sha256);
  const effective=['-I','-B',path.join(root,'child-bootstrap.py'),args[2]];
  const env={PATH:'/usr/bin',LANG:'C.UTF-8',LC_ALL:'C.UTF-8',PYTHONDONTWRITEBYTECODE:'1',PYTHONNOUSERSITE:'1',
    AUDIO_MODEL_AUDIT_ROOT:root,AUDIO_MODEL_GATEWAY_PID:String(process.pid),AUDIO_OWNED_SESSION:String(ownSession)};
  const child=spawn.call(this,file,effective,{...options,env});
  const childIdentity=identity(child.pid);assert.equal(childIdentity.group,ownSession);assert.equal(childIdentity.session,ownSession);
  const row={identity:childIdentity,pid:child.pid,requested:[file,...args],effective:[file,...effective],exit:null,close:null};receipt.spawns.push(row);save();
  child.once('exit',(code,signal)=>{row.exit={code,signal};save();});
  child.once('close',(code,signal)=>{row.close={code,signal,stdio:child.stdio.map(stream=>stream===null||stream.destroyed)};save();});
  return child;
};
for(const name of ['exec','execFile','fork','spawnSync','execSync','execFileSync'])cp[name]=()=>refusal('extra-subprocess-'+name);
process.dlopen=()=>refusal('native-addon-load');
syncBuiltinESMExports();save();
process.once('exit',code=>{receipt.exit=code;save();});
// The real fixture's existing SIGTERM closeAll handler owns teardown. This is
// only delivery of supervisor SIGINT to that original host cleanup path.
process.on('SIGINT',()=>process.emit('SIGTERM'));
