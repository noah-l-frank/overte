"""Literal current747 cold/warm read only; no current/native fact is minted."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import signal,cProfile,hashlib,json,os,pstats,stat,sys,time,unittest
from pathlib import Path
from PIL import Image
from adapters.native_clock_join import digest
from adapters.original_file_reads import readonly,collect
from adapters.script_feature.history import unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
from ios.adapters.emote_callback_live_records import CallbackLiveRecords
from ios.adapters.emote_retirement import Frozen
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def census(roots):
 values={}
 for root in roots:
  for p in (root,*sorted(root.rglob('*'))):
   a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in F])
   if stat.S_ISREG(a.st_mode):v['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
   assert v['stat']==[getattr(p.lstat(),k) for k in F];values[str(p)]=v
 return values
class Current747ReadOnlyProfile(unittest.TestCase):
 def test_literal_current747_primary_two_records_readonly_profile(self):
  here=Path(__file__).resolve().parent;plan=json.loads((here/'input-plan.json').read_text());root=Path(plan['root']);roots=[Path(p) for p in plan['roots']];header=Path(plan['header'])
  expected=json.loads((here/'input-graph-pins.json').read_text());self.assertEqual(expected,census(roots))
  raw=header.read_bytes();self.assertEqual(plan['headerSha256'],hashlib.sha256(raw).hexdigest());value=json.loads(raw)
  self.assertEqual(str(root),value['artifactRoot']);self.assertEqual(plan['binding'],value['binding']);self.assertEqual(2,value['iosEmoteRootedLiveVersion'])
  actual=unpack(value['payload']);self.assertEqual(1,len(actual));references=actual[0]['records'];self.assertEqual(plan['recordReferences'],references);self.assertIsNone(actual[0]['pending'])
  lock=ScriptSourceLock(value['sourceLock']);primary=lock if value['sourceLock']==value['primaryLock'] else ScriptSourceLock(value['primaryLock'])
  # Recreate only ordinary parser registration already performed by the real
  # graph producer's PNG loads. Literal owner-header/reference metadata is parsed outside timer; no historical row/image decode or cache rows warmed.
  Image.preinit();self.assertEqual(expected,census(roots))
  history=CallbackLiveRecords();self.assertTrue(history.literal(),repr(history.unsupported_members()));self.assertEqual({},history.cache.rows)
  profiler_id=getattr(sys.monitoring,'PROFILER_ID',2);self.assertIsNone(sys.monitoring.get_tool(profiler_id))
  profile=cProfile.Profile();rows=[];members=[];elapsed=[];reopens=[];events=[]
  def event(phase,operation):
   events.append(dict(phase=phase,operation=operation,monotonic=time.monotonic(),cacheRows=len(history.cache.rows),literal=history.literal()))
   (here/'actual-read-progress.json').write_text(json.dumps(events,indent=2)+'\n')
  def interrupted(signum,frame):raise TimeoutError('Bounded 45s historical read diagnostic interrupted; partial original parser profile retained')
  previous=signal.signal(signal.SIGALRM,interrupted);signal.setitimer(signal.ITIMER_REAL,45)
  try:
   with lock.held(),primary.held():
    for phase in ('cold','warm'):
     profile.clear();started=time.monotonic()
     with readonly(),collect() as membership:
      event(phase,'before-production-archive');profile.enable()
      try:
       archive=IOSEmoteCallbackLive.archive(value,store=Frozen(header,value),lock=lock,primary_lock=primary,historical_rows=history)
       event(phase,'after-production-archive');actual_rows=[archive.record(reference) for reference in archive.state['records']];event(phase,'after-selected-records')
      finally:
      profile.disable();profile.dump_stats(str(here/(phase+'-actual-decoders-partial-or-complete.pstats')))
      (here/(phase+'-actual-membership-partial-or-complete.json')).write_text(json.dumps(dict(actualPaths=sorted(str(p) for p in membership),partialUnlessCompleted=True),indent=2)+'\n')
     elapsed.append(time.monotonic()-started);rows.append(actual_rows);members.append(set(membership));self.assertEqual(expected,census(roots))
     self.assertEqual(references,[row['reference'] for row in actual_rows]);self.assertEqual(2,len(actual_rows))
     for row in actual_rows:
      frame=archive.read_frame(row['reference']);self.assertEqual(frame['measurementSha256'],digest(row['measurement']))
      expanded=archive.originals.expand(row['reference']);path=archive.originals.path(expanded);descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
      try:
       fd=os.fstat(descriptor);self.assertEqual(expanded['file']['device'],fd.st_dev);self.assertEqual(expanded['file']['inode'],fd.st_ino);archive.originals.file(path,descriptor,expanded)
      finally:os.close(descriptor)
     profile.dump_stats(str(here/(phase+'-actual-decoders.pstats')));stats=pstats.Stats(profile)
     reopens.append(sum(data[1] for (filename,line,function),data in stats.stats.items() if filename.endswith('/ios/adapters/emote_callback_archive.py') and function=='reopen'))
     calls=[dict(file=f,line=l,function=n,primitiveCalls=v[0],totalCalls=v[1],cumulativeSeconds=v[3]) for (f,l,n),v in sorted(stats.stats.items()) if f.startswith(str(here.parents[2]))]
     with (here/(phase+'-actual-project-calls.json')).open('x') as output:json.dump(calls,output,indent=2);output.write('\n')
   finally:
   signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous);profile.disable();del profile
  self.assertTrue(same(rows[0],rows[1]));self.assertTrue(members[0]);self.assertEqual(members[0],members[1]);self.assertEqual(2,len(history.cache.rows));self.assertTrue(history.literal())
  self.assertGreaterEqual(reopens[0],2);self.assertEqual(0,reopens[1]);self.assertEqual(expected,census(roots))
  report=dict(status='ACTUAL_CURRENT747_LITERAL_ORIGINAL_GRAPH_COLD_WARM_HOST_READ',historicalOnly=True,records=2,cacheRows=2,
   coldSeconds=elapsed[0],warmSeconds=elapsed[1],coldReopenCalls=reopens[0],warmReopenCalls=reopens[1],readMembership=len(members[0]),
   readMembershipEqual=True,actualReadMembership=[str(p) for p in sorted(members[0])],originalFiles=747,allOriginalPinsUnchanged=True,
   currentDevice=plan['currentDevice'],old747RuntimeReplay=False,subprocesses=False,network=False,SDKExecuted=False,inputsOrNativeQueries=False,
   noHistoricalRowsOrImagesDecodedBeforeCold=True,parserRegistrationOnlyBeforeCold=True,nativeCompiled=False,deviceAcceptance=False,wholeFeatureQualified=False)
  with (here/'profile-result.json').open('x') as output:json.dump(report,output,indent=2);output.write('\n')
