"""Actual independent child IPA read and original native-file join; SDK modeled.

The creator Task is a declared original-owner model, never authenticated RSD.
Native directory producer is synthetic; actual signed-format IPA bytes/reader,
thread/FD/WAL and source/runtime guards execute only in Root's future run.
"""
from __future__ import annotations
import ast,asyncio,hashlib,json,marshal,os,threading,uuid,weakref,zipfile
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import test_child_bundle_profile_models as bundle_fixture


class SelectedIPAOriginalModels(bundle_fixture.ChildBundleProfileModels):
    async def asyncSetUp(self):
        await super().asyncSetUp();self.binding['artifactSha256']=self.artifact_sha
        self.creator_stop=asyncio.Event();self.creator_ready=asyncio.Event()
        path=Path(self.mapping['keeper']['path']);tree=ast.parse(path.read_bytes());source=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='OriginalKeeperSource');ctor=next(n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='__init__')
        nodes=[n for n in ctor.body if isinstance(n,ast.Assign) and any(isinstance(v,ast.Attribute) and v.attr=='_creator_task' for v in n.targets)];self.assertEqual(1,len(nodes))
        module=ast.Module(body=deepcopy(nodes),type_ignores=[]);code=compile(ast.fix_missing_locations(module),str(path),'exec')
        metadata=dict(sourceSha256=self.mapping['keeper']['sha256'],selectedAstSha256=hashlib.sha256(ast.dump(module,include_attributes=False).encode()).hexdigest(),compiledCodeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest())
        fd=os.open(Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/('creator-'+uuid.uuid4().hex+'.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as f:json.dump(metadata,f);f.write('\n')
        async def original_creator_model():
            exec(code,dict(self=self.source,weakref=weakref,asyncio=asyncio));self.creator_ready.set();await self.creator_stop.wait()
        self.creator=asyncio.create_task(original_creator_model(),name='modeled-original-selected-ipa-creator');await self.creator_ready.wait();self.addAsyncCleanup(self.close_creator)
    async def close_creator(self):
        for task in self.tasks:
            try:await asyncio.shield(task)
            except BaseException:pass
        await self.source.settle_touches();self.creator_stop.set();await self.creator
    def query_args(self):
        value=super().query_args();value['nativeBundleProfileVersion']=2;value['selectedArtifact']=dict(root=str(self.archive.path.parent),relative=self.archive.path.name);return value
    def read_args(self,value):
        args=super().read_args(value);args['nativeBundleProfileVersion']=2;return args
    def receipt(self,value):return self.journal()['selectedOriginals'][value['query']['commandId']]
    async def event(self,event):
        deadline=asyncio.get_running_loop().time()+3
        while not event.is_set():
            self.assertLess(asyncio.get_running_loop().time(),deadline);await asyncio.sleep(.005)
    def archive_fds(self):
        values=[]
        for p in Path('/proc/self/fd').iterdir():
            try:target=os.readlink(p)
            except FileNotFoundError:continue
            if target==str(self.archive.path):values.append(int(p.name))
        return values

    async def test_actual_child_thread_hash_and_selected_ipa_original_native_file_match_without_motion_authority(self):
        value=await self.issue();receipt=self.receipt(value);result=await self.original(value)
        self.assertEqual(3,value['originalKeeperNativeQueryVersion']);self.assertEqual(3,result['originalKeeperNativeFileVersion'])
        self.assertEqual(self.measured_bundle,receipt[2]);self.assertEqual(self.measured_bundle,json.loads(result['rawJson'])['bundle']);self.assertTrue(receipt[3]['returned'])
        receipt[1]();self.assertFalse(self.creator.done());self.assertTrue(all(task.done() and not thread.is_alive() for task,thread,event,loop in self.source._native_queries))
        self.assertEqual(2,len(self.source._native_queries));self.assertEqual(1,len(self.received));self.assertEqual([],self.archive_fds())
        self.assertFalse(result['installedCandidateBound']);self.assertFalse(result['nativeMotionGuardAvailable']);self.assertFalse(result['nativeTouchSupport'])

    async def test_actual_selected_ipa_digest_mismatch_refuses_before_owned_nonce_or_http(self):
        self.binding['artifactSha256']='f'*64
        with self.assertRaises((ValueError,RuntimeError)):await self.issue()
        self.assertEqual([],self.received);self.assertEqual({},self.ops.native_query_journals);self.assertIsNone(self.ops.native_query_task);self.assertEqual([],self.archive_fds())

    async def test_actual_archive_change_after_complete_reader_refuses_original_metadata_without_native_query(self):
        from ios.adapters import bundle_identity
        original=bundle_identity.artifact_bundle
        def changed(path,digest):
            result=original(path,digest);path.write_bytes(path.read_bytes()+b'actual changed archive after original hash');return result
        with patch.object(bundle_identity,'artifact_bundle',new=changed):
            with self.assertRaises((ValueError,RuntimeError)):await self.issue()
        self.assertEqual([],self.received);self.assertEqual({},self.ops.native_query_journals);self.assertEqual([],self.archive_fds())

    async def test_concurrent_query_cannot_enter_original_owner_while_real_selected_fd_read_is_pending(self):
        entered=threading.Event();release=threading.Event();original=zipfile.ZipFile.__init__
        def hold(archive,*args,**kwargs):
            original(archive,*args,**kwargs)
            if threading.current_thread().name=='original-selected-ipa-read':entered.set();release.wait(5)
        with patch.object(zipfile.ZipFile,'__init__',new=hold):
            task=asyncio.create_task(self.issue());await self.event(entered)
            try:
                self.assertTrue(self.archive_fds());self.assertIsNotNone(self.ops.native_query_task)
                args=super().query_args()
                with self.assertRaises((ValueError,RuntimeError)):await super().issue(args)
                self.assertEqual([],self.received);self.assertEqual({},self.ops.native_query_journals)
            finally:release.set()
            value=await task
        self.assertEqual(1,len(self.received));self.assertEqual(3,value['originalKeeperNativeQueryVersion']);self.assertEqual([],self.archive_fds())

    async def test_cancelled_original_request_and_source_drain_retain_real_selected_fd_until_original_thread_returns(self):
        entered=threading.Event();release=threading.Event();original=zipfile.ZipFile.__init__
        def hold(archive,*args,**kwargs):
            original(archive,*args,**kwargs)
            if threading.current_thread().name=='original-selected-ipa-read':entered.set();release.wait(5)
        with patch.object(zipfile.ZipFile,'__init__',new=hold):
            wrapper=asyncio.create_task(self.issue());await self.event(entered);original_task=self.ops.native_query_task;original_task.cancel();drain=asyncio.create_task(self.source.settle_touches());self.controls.append(drain)
            try:
                await asyncio.sleep(.02);self.assertFalse(original_task.done());self.assertFalse(drain.done());self.assertTrue(self.archive_fds());self.assertFalse(self.creator.done());self.assertEqual([],self.received)
            finally:release.set()
            with self.assertRaises(asyncio.CancelledError):await wrapper
            await drain
        self.assertEqual([],self.archive_fds());self.assertEqual([],self.received);self.assertTrue(all(not thread.is_alive() for _,thread,_,_ in self.source._native_queries))

    async def test_observed_source_creator_reference_change_then_restoration_cannot_revive_selected_original(self):
        value=await self.issue();original=self.source._creator_task;self.source._creator_task=weakref.ref(asyncio.current_task())
        with self.assertRaises((RuntimeError,ValueError)):await self.original(value)
        self.source._creator_task=original
        with self.assertRaises((RuntimeError,ValueError)):await self.original(value)
        self.assertTrue(self.receipt(value)[3]['revoked']);self.assertEqual([],self.services);self.assertEqual(1,len(self.received))

    async def test_validly_typed_foreign_native_bundle_bytes_poison_guard_and_restoration_cannot_adopt_same_nonce(self):
        value=await self.issue();raw=self.input.read_bytes();packet=json.loads(raw);packet['bundle']['executableSha256']='f'*64;self.input.write_text(json.dumps(packet))
        with self.assertRaises((RuntimeError,ValueError)):await self.original(value)
        self.input.write_bytes(raw);count=len(self.services)
        with self.assertRaises((RuntimeError,ValueError)):await self.original(value)
        self.assertEqual(count,len(self.services));self.assertEqual(1,len(self.received));self.assertTrue(self.receipt(value)[3]['revoked'])

    async def test_original_sdk_scope_failure_then_restoration_cannot_revive_original_selected_ipa_guard(self):
        value=await self.issue();original=self.ops.fresh_touch_scope
        async def lost(binding):await original(binding);raise RuntimeError('Declared original SDK foreground scope loss')
        self.ops.fresh_touch_scope=lost
        with self.assertRaises(RuntimeError):await self.original(value)
        self.ops.fresh_touch_scope=original
        with self.assertRaises((RuntimeError,ValueError)):await self.original(value)
        self.assertEqual([],self.services);self.assertTrue(self.receipt(value)[3]['revoked']);self.assertEqual(1,len(self.received))
