"""Root metadata only, once after exact corrected source publication."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
plan=json.loads((HERE/'plan.json').read_text());frozen=json.loads((HERE/'freeze.json').read_text())
for name,expected in frozen['files'].items():assert sha(HERE/name)==expected,name
path=HERE/'actual-source-chain-after-publication.json';assert not path.exists()
actual={name:sha(REPO/name) for name in plan['expectedSourceChain']}
assert actual==plan['expectedSourceChain'],'Publish exact reviewed corrected source before admitting actual98'
assert actual=={name:sha(REPO/name) for name in actual}
assert len(actual)==98
path.write_text(json.dumps(dict(status='ACTUAL_98_AFTER_CORRECTED_SOURCE_PUBLICATION',sourceChain=actual,targetImportsExecuted=False,testsExecuted=False),indent=2,sort_keys=True)+'\n')
print('ACTUAL_98_CHAIN_AFTER_PUBLICATION',sha(path))
