"""Prospective actual Current7/Parent/Phase publication graph; UNRUN.

SDK/Qt/native are explicit producers. Typed originals, real owned loopback
publication, PFS CAS/intent, file leases and actual async cleanup stay intact.
Hostile originals remain in each case's retained private namespace on purpose.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,os
from copy import deepcopy
from adapters.normal_ui import NativeUIError
from adapters import pure_original_validation as pure_validation
from adapters.script_feature.lock import ScriptSourceLock
from adapters.original_file_reads import collect
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import unpack
from ios.adapters.lifecycle_current_archive import LifecycleCurrentArchive
from ios.adapters.lifecycle_publication_read_phase import publication_scope,ParserPolicy
from ios.adapters import lifecycle_current_transport as transport
from lifecycle_whole_fresh_fixture import FreshWholeFixture


class LifecyclePublicationOriginalReadPhaseModels(FreshWholeFixture):
    async def original_observer(self):
        await self.primary_api();await self.actor_api();return self.observer

    def archive(self,owner):
        s=owner.stream
        return LifecycleCurrentArchive(s.store,s.previous,s.root,s.binding,s.run,s.role,s.lock)

    async def test_real_historical_record_index_leases_restore_membership_inside_one_publication_only(self):
        owner=await self.original_observer();before=self.counts()
        def read():
            with owner.lock.held(),publication_scope(owner)as phase:
                self.assertTrue(phase.policy.admitted());archive=self.archive(owner);reference=deepcopy(archive.snapshot_state['records'][-1])
                with collect()as cold:value=archive.record(reference)
                hits=phase.stats['hits']
                with collect()as warm:again=archive.record(reference)
                self.assertEqual(value,again);self.assertEqual(cold,warm);self.assertTrue(cold)
                self.assertGreater(phase.stats['hits'],hits);self.assertTrue(value['historical'])
                foreign=pure_validation._ACTIVE.set({});hits=phase.stats['hits'];literal=phase.stats['literal']
                try:
                    self.assertFalse(phase.memo_allowed());self.assertEqual(value,archive.record(reference))
                    self.assertEqual(hits,phase.stats['hits']);self.assertGreater(phase.stats['literal'],literal)
                finally:pure_validation._ACTIVE.reset(foreign)
                self.assertTrue(phase.memo_allowed())
            self.assertEqual(before,self.counts());self.assertEqual({},phase.cache.rows)
            called=[]
            for active in (False,True):
                phase.active=active
                with self.assertRaises(NativeUIError):
                    phase.read(dict(afterExit=True),lambda:called.append('decode'),lambda:called.append('guard'))
                self.assertEqual([],called);self.assertEqual({},phase.cache.rows)
            phase.active=False
            with owner.lock.held(),publication_scope(owner)as following:
                self.assertEqual({},following.cache.rows) # No memo crosses publication boundaries.
        await asyncio.to_thread(read);self.assertEqual(before,self.counts())

    async def test_same_inode_same_bytes_rewrite_refuses_a_warm_historical_row_without_new_query(self):
        owner=await self.original_observer();before=self.counts()
        def rewrite():
            with owner.lock.held(),publication_scope(owner)as phase:
                self.assertTrue(phase.policy.admitted());archive=self.archive(owner);reference=deepcopy(archive.snapshot_state['records'][-1])
                archive.record(reference);path=archive.files.path(archive.files.expand(reference));inode=path.stat().st_ino;raw=path.read_bytes()
                backup=owner.root/('counter-original-before-'+path.name);backup.write_bytes(raw);backup.chmod(0o600)
                with path.open('r+b')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
                self.assertEqual(inode,path.stat().st_ino);self.assertEqual(raw,path.read_bytes())
                with self.assertRaises(NativeUIError):archive.record(reference)
        await asyncio.to_thread(rewrite);self.assertEqual(before,self.counts())

    async def test_new_unknown_parent_original_refuses_even_when_requested_row_is_already_warm(self):
        owner=await self.original_observer();before=self.counts()
        def orphan():
            with owner.lock.held(),publication_scope(owner)as phase:
                self.assertTrue(phase.policy.admitted());archive=self.archive(owner);reference=deepcopy(archive.snapshot_state['records'][-1])
                value=archive.record(reference);path=owner.root/('lifecycle-current-returned-frame-sources-'+self.run+'-actor-0999-'+'f'*64+'.json')
                path.write_bytes(b'actual unknown parent original');path.chmod(0o600)
                with self.assertRaises(NativeUIError):archive.record(reference)
                self.assertEqual(reference['index'],value['original']['originalBody']['index'])
        await asyncio.to_thread(orphan);self.assertEqual(before,self.counts())

    async def test_same_receiver_code_change_refuses_before_a_warm_original_decoder_can_run(self):
        owner=await self.original_observer();before=self.counts()
        def change():
            with owner.lock.held(),publication_scope(owner)as phase:
                self.assertTrue(phase.policy.admitted());archive=self.archive(owner);reference=deepcopy(archive.snapshot_state['records'][-1])
                saved=archive.record(reference);hits=phase.stats['hits'];function=transport.frame_original;code=function.__code__
                function.__code__=code.replace(co_consts=(*code.co_consts,'explicit-changed-historical-current-parser'))
                try:
                    with self.assertRaises(RuntimeError):archive.record(reference)
                finally:function.__code__=code
                self.assertEqual(hits,phase.stats['hits']);self.assertEqual(saved,archive.record(reference))
        await asyncio.to_thread(change);self.assertEqual(before,self.counts())

    async def test_unsupported_new_namespace_member_selects_literal_replay_without_old_memo_admission(self):
        owner=await self.original_observer();before=self.counts()
        def unsupported():
            with owner.lock.held(),publication_scope(owner)as phase:
                self.assertTrue(phase.policy.admitted());archive=self.archive(owner);reference=deepcopy(archive.snapshot_state['records'][-1])
                saved=archive.record(reference);self.assertFalse(hasattr(transport,'counter_opaque_member'))
                transport.counter_opaque_member=object();hits=phase.stats['hits'];literal=phase.stats['literal']
                try:
                    self.assertFalse(phase.policy.admitted());self.assertEqual(saved,archive.record(reference))
                    initial=ParserPolicy();self.assertFalse(initial.admitted());self.assertIsNone(initial.members)
                    self.assertEqual(hits,phase.stats['hits']);self.assertGreater(phase.stats['literal'],literal)
                finally:del transport.counter_opaque_member
        await asyncio.to_thread(unsupported);self.assertEqual(before,self.counts())

    async def test_actual_loopback_post_return_loss_replays_saved_receipt_without_second_post_or_current_cut(self):
        await self.original_observer();self.activate('baseline',{});actual=self.actor_client.request;posted=[]
        def request(path,body=None,**kwargs):
            value=actual(path,body,**kwargs)
            if path.endswith('/samples'):
                posted.append(deepcopy(body))
                if len(posted)==1:raise OSError('Declared loss AFTER actual loopback witness POST committed')
            return value
        self.actor_client.request=request
        try:
            with self.assertRaises(OSError):await self.actor_api()
            before=self.counts();owner=self.observer
            store=PrivateFeatureState(owner.store.path.with_name('phase-publication-lifecycle-input-'+self.run+'-actor.json'))
            pending=unpack(store.read()['payload'])[0]['pending'];self.assertEqual('issued',pending['phase'])
            self.assertEqual(pending['body']['actorSequence'],await self.actor_api('publish'))
            self.assertEqual(1,len(posted));self.assertEqual(before,self.counts())
            completed=unpack(store.read()['payload'])[0];self.assertIsNone(completed['pending'])
            entries=self.phase_server.journal.snapshot(self.run)['entries']
            self.assertEqual(1,sum(row['actorSequence']==posted[0]['actorSequence']for row in entries))
        finally:self.actor_client.request=actual

    async def test_same_originals_and_copied_sdk_metadata_cannot_borrow_retained_store_lock_owner_memo_admission(self):
        owner=await self.original_observer();before=self.counts()
        def foreign():
            with owner.lock.held(),publication_scope(owner)as phase:
                self.assertTrue(phase.memo_allowed());archive=self.archive(owner);reference=deepcopy(archive.snapshot_state['records'][-1])
                saved=archive.record(reference);hits=phase.stats['hits']
                directory=owner.root/'counter-foreign-sdk-metadata';directory.mkdir(mode=0o700)
                store=PrivateFeatureState(directory/owner.stream.store.path.name);store.write(deepcopy(owner.stream.previous),None)
                lock=ScriptSourceLock(directory/'script-feature-sources.lock')
                with lock.held():
                    outsider=LifecycleCurrentArchive(store,store.read(),owner.root,owner.binding,self.run,'actor',lock)
                    self.assertFalse(phase.admits(outsider.files));self.assertEqual(saved,outsider.record(reference))
                    self.assertEqual(hits,phase.stats['hits']) # Literal default only; no copied SDK cache custody.
                # Original owner nonce mutation also cannot select the warm row.
                original=deepcopy(archive.snapshot);nonce=archive.owner;archive.snapshot['owner']='f'*32
                try:self.assertFalse(phase.admits(archive.files))
                finally:archive.snapshot=original
                archive.owner='f'*32
                try:self.assertFalse(phase.admits(archive.files))
                finally:archive.owner=nonce
        await asyncio.to_thread(foreign);self.assertEqual(before,self.counts())
