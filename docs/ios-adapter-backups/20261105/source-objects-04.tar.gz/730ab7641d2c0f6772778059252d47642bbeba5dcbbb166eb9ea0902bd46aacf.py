"""Source-only isolated Source5 assembly. Never imports/runs a target."""
from pathlib import Path
import ast,hashlib,json,pprint,shutil

REPO=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026')
BASE_BUILDER=REPO/'.ios-host-tmp/prepare-assets-picker3-controller8-20261103.py'
HERE9=REPO/'.ios-host-tmp/assets-picker3-five-static-policy-isolated-controller9-20261103'
SOURCE5=REPO/'.ios-host-tmp/assets-picker3-static-policy-custody-source5-draft-20261103'
PREVIOUS8=REPO/'.ios-host-tmp/assets-picker3-five-profile-isolated-controller8-20261103'
assert not HERE9.exists()

# Reuse the already reviewed stdlib assembly, not its target. Its temporary
# historical registry is immediately replaced below by the exact additive merge.
assembly=BASE_BUILDER.read_text().replace("HERE=REPO/'.ios-host-tmp/assets-picker3-five-profile-isolated-controller8-20261103'", "HERE=REPO/'.ios-host-tmp/assets-picker3-five-static-policy-isolated-controller9-20261103'")
old="assert all(actual_registry['contracts'][key]==row for key,row in current['contracts'].items() if key not in own|seven)"
new="assert all(key in current['contracts'] for key in actual_registry['contracts'] if key not in own|seven)"
assert old in assembly;assembly=assembly.replace(old,new)
exec(compile(assembly,str(BASE_BUILDER),'exec'),globals())
assert HERE==HERE9 and not (HERE/'runs').exists()
shutil.copyfile(BASE_BUILDER,HERE/'reviewed-source8-base-builder.py')
frozen(SOURCE5,'8b72cf9d14fa68e1451c92e2dc8818a7c6bc0e4b9139e2d3831ab3eeb569bbd4')
assert sha(PREVIOUS8/'freeze.json')=='491a5c8bdc1258fa4013584178453c8b3f228477c0724860feed4a2d1cad134b'

source5_rows=[]
for row in load(SOURCE5/'candidate-source-rows.json'):
 name=row['path'];source=SOURCE5/'candidate'/name;assert sha(source)==row['candidateSha256']
 target=SOURCE/name;before=sha(target) if target.exists() else None;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
 origins[name]=dict(source='exact-root-reviewed-source5',sourcePath=relative(source),sha256=sha(target))
 source5_rows.append(dict(path=name,controller8BaseSha256=before,source5Sha256=sha(target)))
save('source5-overlay-rows.json',source5_rows)

# Merge exact current public foreign rows with historical own Assets rows.
current=load(REPO/'tests/device/contract-versions.json');private=load(PREVIOUS8/'source/tests/device/contract-versions.json')
own={key:value for key,value in private['contracts'].items() if current['contracts'].get(key)!=value}
assert all(key.startswith(('ios-assets-','assets-','asset-generation-','feature-post-consumer-')) for key in own)
merged=json.loads(json.dumps(current));merged['contracts'].update(own)
registry=SOURCE/'tests/device/contract-versions.json';registry.write_text(json.dumps(merged,indent=2,sort_keys=True)+'\n')
assert all(merged['contracts'][key]==value for key,value in current['contracts'].items() if key not in own)
snapshots={key:value for key,value in current['contracts'].items() if 'snapshot' in key.lower()}
assert all(merged['contracts'][key]==value for key,value in snapshots.items())
origins['tests/device/contract-versions.json']=dict(source='private-additive-current-public-foreign-and-prior-own-Assets',sourcePath='tests/device/contract-versions.json',sha256=sha(registry))

def required(path):
 tree=ast.parse(path.read_text());node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='REQUIRED' for t in n.targets))
 return node.value,ast.literal_eval(node.value)
public_validator=REPO/'tests/device/validate_contract_versions.py';node,requirements=required(public_validator)
_old,private_required=required(PREVIOUS8/'source/tests/device/validate_contract_versions.py')
for key in own:requirements[key]=private_required[key]
text=public_validator.read_text();lines=text.splitlines(True);first=sum(map(len,lines[:node.lineno-1]))+node.col_offset;last=sum(map(len,lines[:node.end_lineno-1]))+node.end_col_offset
text=text[:first]+pprint.pformat(requirements,sort_dicts=True,width=120)+text[last:]
validator=SOURCE/'tests/device/validate_contract_versions.py';validator.write_text(text);ast.parse(text)
origins['tests/device/validate_contract_versions.py']=dict(source='private-additive-current-public-foreign-and-prior-own-Assets-REQUIRED',sourcePath='tests/device/validate_contract_versions.py',sha256=sha(validator))

# Retain both independent observation branches verbatim, without any filtering.
old_normal=(PREVIOUS8/'source/tests/device/ios/adapters/normal_input.py').read_text();new_normal=(REPO/'tests/device/ios/adapters/normal_input.py').read_text()
first=old_normal.index("    if type(value) is dict and 'assetPermissionsVersion' in value:");last=old_normal.index("    if type(value) is dict and 'navigationInventory' in value:",first);assets_branch=old_normal[first:last]
first=new_normal.index("    if type(value) is dict and 'snapshotReviewInventory' in value:");last=new_normal.index("    if type(value) is dict and 'lifecycleNavigation' in value:",first);snapshot_branch=new_normal[first:last]
assert new_normal.replace(snapshot_branch,'',1)==old_normal.replace(assets_branch,'',1)
marker="    if type(value) is dict and 'navigationInventory' in value:";assert new_normal.count(marker)==1
normal=SOURCE/'tests/device/ios/adapters/normal_input.py';normal.write_text(new_normal.replace(marker,assets_branch+marker));ast.parse(normal.read_text())
origins['tests/device/ios/adapters/normal_input.py']=dict(source='private-additive-current-Snapshot-and-prior-Assets-permission-branches',sourcePath='tests/device/ios/adapters/normal_input.py',sha256=sha(normal))
save('current-public-additive-merge-review.json',dict(rootReportedHead='d824159435cbb4e70576ce13e3a343e9858e6caf',registryCurrentSha256=sha(REPO/'tests/device/contract-versions.json'),registryMergedSha256=sha(registry),allCurrentForeignRowsIdentical=True,currentSnapshotRows=snapshots,normalInputPublicSha256=sha(REPO/'tests/device/ios/adapters/normal_input.py'),normalInputMergedSha256=sha(normal),snapshotBranchVerbatim=True,assetsPermissionsBranchVerbatim=True,allOtherNormalInputBytesEqual=True,conditionalReader='normal_input.observation -> snapshot_review.inventory only if snapshotReviewInventory exists',declaredAssetProducerKeyPresent=False,noReaderOrCacheException=True))

# Preserve all actual Controller8 results, failures, originals and censuses.
eighth={}
for path in sorted((PREVIOUS8/'runs').rglob('*')):
 if path.is_file():eighth[relative(path)]=pin(path)
for pattern in ('*-report.json','*-originals-*.json','*-prior-originals-*.json','*-process-binding.json','*-public-source-*.json','*-first.log'):
 for path in PREVIOUS8.glob(pattern):eighth[relative(path)]=pin(path)
save('preserved-eighth-actual-pins.json',dict(sourceController=relative(PREVIOUS8),files=eighth,allOriginalsRetained=True))

plan=load(HERE/'execution-plan.json');models=load(SOURCE5/'five-unrun-countermodels.json')['methods']
order=('freshness','context','inode','orphan','savedCAS')
plan.update(status='PRIVATE_SOURCE5_FIVE_COUNTER_CONTROLLER9_AWAITING_ROOT_REVIEW_UNRUN',rootReportedHead='d824159435cbb4e70576ce13e3a343e9858e6caf',previousControllerPath=relative(PREVIOUS8),previousControllerRawFreezeSha256=sha(PREVIOUS8/'freeze.json'),source5PacketPath=relative(SOURCE5),source5PacketRawFreezeSha256=sha(SOURCE5/'freeze.json'),source5OverlayPaths=2,publicAdditiveCompositionPaths=3,previousOriginalFiles=183,executionAuthorized=False,targetExecutionAuthorized=False,order=list(order),typedPathCoverageRequired=True,wholeQualified=False)
plan['selection']={name:dict(id='ios.self_tests.test_ios_assets_picker_intent_transitions.AssetsPickerIntentTransitionTests.'+method,expectedPersistentPickerNodeChildren=1,independentInterpreter=True,initialTimeoutSeconds=300,killAfterSeconds=5,unchangedRetryAllowed=False) for name,method in zip(order,models)}
plan['runtimeOverlayPolicy']='Fresh HEAD d824 public bytes plus reviewed historical Assets/fixture chain, exact Source5 two files and exact three additive public Snapshot/Assets normal_input/registry/REQUIRED merges; all foreign rows preserved.'
save('execution-plan.json',plan)
metadata=HERE/'metadata.py';text=metadata.read_text();old="'preserved-seventh-actual-pins.json'):";assert old in text;text=text.replace(old,"'preserved-seventh-actual-pins.json','preserved-eighth-actual-pins.json'):")
marker="    for name,row in load('host-executable-pins.json').items():"
extra="""    source5=REPO/load('execution-plan.json')['source5PacketPath'];assert sha(source5/'freeze.json')==load('execution-plan.json')['source5PacketRawFreezeSha256']
    for row in json.loads((source5/'freeze.json').read_text())['files']:assert sha(source5/row['path'])==row['sha256'],row['path']
"""
assert marker in text;text=text.replace(marker,extra+marker);metadata.write_text(text);ast.parse(text)

# Regenerate all source origins, physical identities and static lookup metadata
# after the exact source/foreign merges. No target is imported to build maps.
save('isolated-source-origins.json',origins)
physical={'files':{},'directories':{}}
for path in [SOURCE,*sorted(SOURCE.rglob('*'))]:
 assert not path.is_symlink();info=path.lstat();physical['directories' if path.is_dir() else 'files'][str(path.relative_to(SOURCE))]={key:getattr(info,key) for key in fields}
save('isolated-source-physical-pins.json',physical)
modules={}
for directory in ordered:
 for path in sorted(directory.rglob('*.py')):
  parts=list(path.relative_to(directory).with_suffix('').parts);package=parts[-1]=='__init__'
  if package:parts.pop()
  if parts:modules.setdefault('.'.join(parts),dict(path=str(path),relativePath=str(path.relative_to(SOURCE)),sha256=sha(path),package=package))
save('absolute-import-origin-map.json',dict(orderedRoots=[str(path) for path in ordered],modules=modules))
fixtures=set(load(HERE/'fixture-pins.json'))|{'tests/device/ios/self_tests/test_ios_assets_picker_intent_transitions.py'}
save('fixture-pins.json',{name:dict(path=str(SOURCE/name),sha256=sha(SOURCE/name)) for name in sorted(fixtures)})
start='ios.self_tests.test_ios_assets_picker_intent_transitions';todo=[start];visited={};edges=[]
while todo:
 name=todo.pop()
 if name in visited or name not in modules:continue
 row=modules[name];visited[name]=row;tree=ast.parse(Path(row['path']).read_text())
 for node in ast.walk(tree):
  deps=[]
  if isinstance(node,ast.Import):deps=[alias.name for alias in node.names]
  elif isinstance(node,ast.ImportFrom) and node.level==0 and node.module:deps=[node.module,*[node.module+'.'+alias.name for alias in node.names]]
  for dependency in deps:
   if dependency in modules:edges.append([name,dependency]);todo.append(dependency)
save('fixture-construction-and-import-review.json',dict(mode='Conservative AST only, includes conditional imports; no module imported',selectedStart=start,moduleCount=len(visited),modules=visited,edges=edges,conditionalSnapshotReaderPreserved=True,actualRuntimePreimport=False,actualFixtureTempfileSitesUnchanged=True))
save('five-model-source-pin.json',dict(path=relative(SOURCE5/'candidate/tests/device/ios/self_tests/test_ios_assets_picker_intent_transitions.py'),sha256=sha(SOURCE5/'candidate/tests/device/ios/self_tests/test_ios_assets_picker_intent_transitions.py'),methods=models,extraction='AST/source metadata only; no target import/evaluation'))
save('model-data-and-consumers.json',dict(source5=relative(SOURCE5),models=load(SOURCE5/'five-unrun-countermodels.json'),status='UNRUN',actualNode=1,actualOwnedLoopbackServers=2,retainedTemporaryRoots=4,nativeSDKDomainQtParserRemainModels=True,typedTransitionCoverageRequired=True))
save('ast-only-review.json',dict(controllerSyntaxOnly=True,source5Candidates=2,publicAdditiveCompositionPaths=3,conservativeASTModules=len(visited),isolatedSourceFiles=len(origins),absoluteModuleNames=len(modules),modelsExecuted=0,noNewRawRoots=True))
save('manifest.json',dict(kind='private-source5-five-counter-isolated-controller9',status='AWAITING_ROOT_REVIEW_UNRUN',rootReportedHead=plan['rootReportedHead'],source5RawFreeze=sha(SOURCE5/'freeze.json'),previousController8RawFreeze=sha(PREVIOUS8/'freeze.json'),publicSourceFiles=len(public),isolatedSourceFiles=len(origins),source5Candidates=2,additivePublicCompositionPaths=3,models=5,modelsExecuted=0,initialTimeoutSeconds=300,killAfterSeconds=5,allSnapshotRowsPreserved=True,noNewRawRoots=True,wholeAssetsQualified=False,nativeCompiled=False,sdkExecuted=False,deviceQualified=False))
assert not any(path.name in ('runs','temporary') for path in HERE.rglob('*'))
print(json.dumps(dict(controller9=str(HERE),publicPins=len(public),isolatedFiles=len(origins),absoluteModules=len(modules),countermodels=5,typedCoverageRequired=True,preservedController8Files=len(eighth),newRawRoots=False)))
