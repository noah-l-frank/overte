"""Real generation originals with genuine NativeInput and current cleanup ports.

QML/Node bodies, ordinary callback receipts, HTTP request/response/AFC originals
are produced by the existing real bridge. SDK selection and native Reply DTOs
remain declared host models. No expected observation or incomplete NativeInput
subtype is promoted into the productive constructor.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
from adapters.native_feature_observation import need
from adapters.normal_ui import NativeUIError
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.assets_cleanup_phase import AssetsCleanupPhase
from ios.adapters.assets_cleanup_runtime import CurrentCleanupAssetsRuntime
from ios.adapters.assets_whole_input import AssetsWholeInput
from ios.adapters.assets_whole_prefix_abort import AssetsWholePrefixAbort
from ios.adapters.assets_write_client import AssetsWriteClient
from ios.self_tests.assets_page_generations_fixture import Fixture as GenerationFixture
from ios.self_tests.assets_whole_normal_transport_fixture import QMLNormalTransport
from ios.self_tests.test_ios_assets_write_control import AssetsWriteControlTests
from ios.self_tests.assets_picker_fixture import RUN


class Fixture(GenerationFixture):
    def __init__(self,test):
        self.normal_transports=[];self.normal_documents={};self.cleanup_source_calls=[];self.genuine_inputs=[]
        super().__init__(test)
        test.enterContext(patch('ios.adapters.normal_input.urlopen',side_effect=self.normal_post))
        self.write=AssetsWriteControlTests();self.write.setUp();test.addCleanup(self.write.doCleanups)
        self.write.h.binding['domainId']=self.boundary.reads.binding['domainId']
        self.write.authority=self.write.make_authority()
        from fixture.assets_write_authority import AssetsWriteControl
        self.write.control=AssetsWriteControl(self.write.authority,self.write.control_store)
        self.write.config['domainId']=self.write.h.binding['domainId']

    def native_channel(self,action,guard):
        transport=QMLNormalTransport(self.boundary,self.input,self.selected.context['roles']['primary'],action,guard,
            channel=len(self.normal_transports)+1,documents=self.normal_documents)
        native=transport.native();self.normal_transports.append(transport);self.genuine_inputs.append(native);return native

    def normal_post(self,request,timeout):
        matches=[transport for transport in self.normal_transports if request.full_url==transport.origin+'/e2e-client-command.json']
        need(len(matches)==1);return matches[0].post(request,timeout)

    def start(self):
        self.prepare();runtime,parts=self.remove_reenter();view,components=self.view(runtime,parts)
        self.consume(runtime=view,parts=components)
        self.activate(10);runtime,components=self.current_view();tree=components['tree']
        if tree.state is None:tree.reserve()
        if tree.state['phase']=='reserved':tree.browse()
        self.live_origin=components['generation_view'].reply_owners[10]
        need(self.live_origin.state['jobs'] and self.live_origin.state['phase']=='open')
        # A real native start crosses its durable owner/query intent, then the
        # existing boundary loses the return while its ReadObject is still held.
        # Cleanup must observe/retire this exact job; no start is replayed.
        self.boundary.reads.defer=True;self.boundary.reads.lost='inventory'
        try:
            try:self.live_origin.read('prefix-issued-inventory')
            except NativeUIError:pass
            else:need(False)
        finally:self.boundary.reads.defer=False
        held=self.live_origin.state['jobs'][-1]
        need(held['phase']=='issued' and held['query']['commandId'] in self.boundary.reads.pending)
        self.held_job=held['query']['commandId']
        info=self.selected.context['roles']['primary']
        client=AssetsWriteClient(PrivateFeatureState(self.a.h.roots['primary']/('ios-assets-write-client-'+RUN+'.json')),
            self.a.h.locks['primary'],info['binding'],RUN,self.write.config,lambda:self.selected.selected_guard())
        self.driver=AssetsWholeInput(runtime.adapter,self.selected,self.a.owner,self.episodes,
            backend_config=self.backend.config,permission_client=client,episode_scopes=tuple(self.scopes),
            monotonic=self.boundary.monotonic,epoch_ms=lambda:self.boundary.clock()+5000)
        self.test.addCleanup(self.driver.release_local_leases)
        fixture=self
        def sources(current,selector,lock):
            # This is the declared SDK-construction boundary. The productive
            # CleanupScope/episode/canonical target guard itself remains real.
            current._assets_episode_guard(selector,lock)
            need(selector==fixture.driver.selector and lock is current.assets_episode.locks['primary'])
            fixture.cleanup_source_calls.append((current.assets_episode.index,selector))
            native=fixture.boundary.reads.native();previous=native.guard
            def guarded():
                current._assets_episode_guard(selector,lock)
                need(fixture.boundary.live and fixture.boundary.host.poll() is None and previous() is not False)
                return True
            native.guard=guarded;guarded()
            return dict(binding=deepcopy(fixture.selected.context['roles']['primary']['binding']),replies=native)
        self.test.enterContext(patch.object(CurrentCleanupAssetsRuntime,'_assets_sources',sources))
        return self

    def cleanup(self):
        self.a.epoch=max(self.a.epoch,self.boundary.clock())+1
        self.a.journal.activate(RUN,'f'*32,'cleanup',{})
        owner=AssetsCleanupPhase(self.selected,self.a.owner,self.episodes,
            PrivateFeatureState(self.a.h.roots['primary']/('ios-assets-cleanup-phase-'+RUN+'.json')),
            self.a.h.locks,monotonic=self.boundary.monotonic)
        coordinator=AssetsWholePrefixAbort(self.driver,owner);coordinator.activate()
        return coordinator

    def cleanup_owner(self,coordinator,origin):
        runtime=CurrentCleanupAssetsRuntime(self.driver.adapter,coordinator.scope,origin.reply_episode,
            monotonic=self.boundary.monotonic,epoch_ms=lambda:self.boundary.clock()+5000)
        return runtime.asset_generation_reply_cleanup(self.driver.selector,origin)
