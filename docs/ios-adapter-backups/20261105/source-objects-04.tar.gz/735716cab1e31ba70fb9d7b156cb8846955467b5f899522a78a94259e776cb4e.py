from pathlib import Path
import ast,hashlib,json,shutil
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';OLD=T/'lifecycle-original-owner-native-file8-post-query-root-preparation-20261028/07-native8-regression';Q=T/'lifecycle-original-owner-native-query10-final-compat-root-preparation-20261028/06-query10';TOP=T/'lifecycle-original-owner-sender9-root-preparation-20261028';S=TOP/'09-sender9';S.mkdir(mode=0o700,parents=True);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ('root-child.py','root-supervise.py','root_stage_guard.py','source_model_bindings.py','run-selected.py','sdk-original-pins.json','prior-retained-original-pins.json'):
 shutil.copyfile(OLD/name,S/name)
names=['test_final_send_guard_runs_after_actual_process_read_without_changing_originals','test_slow_actual_process_verification_cannot_send_after_final_guard_expires','test_refused_invalid_or_failed_send_guard_never_reaches_http_or_afc','test_bound_native_clock_factory_uses_distinct_original_nonces_and_keeps_native_time','test_original_native_feature_packet_uses_closed_http_and_actual_afc_documents','test_native_feature_missing_afc_file_is_polled_without_replaying_http_command','test_original_rows_request_ids_sequences_and_capture_times_are_retained','test_process_loss_after_capture_blocks_acceptance','test_post_transport_does_not_follow_redirects']
module=R/'tests/device/ios/self_tests/test_ios_feature_observation.py';tree=ast.parse(module.read_bytes());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='FeatureObservationTests');methods={n.name:n for n in cls.body if isinstance(n,ast.FunctionDef)};assert set(names)<=set(methods)
stage=json.loads((Q/'source-manifest.json').read_bytes());stage.update(stage=9,name='sender9',status='PRIVATE_UNRUN_LEGACY_SENDER9_NO_SOURCE_MUTATION',caseCount=9,initialTimeoutSeconds=30)
for row in stage['sourcePaths']:
 assert h(R/row['path'])==row['candidateSHA256'],row['path'];row['observedPublicSHA256']=h(R/row['path']);row['changesCurrentPublic']=False
stage['sourceDeltaPaths']=[];stage['exactPublicMutationPlan']='NONE: existing nine legacy sender regression bodies unchanged.';(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
plan=json.loads((Q/'run-plan.json').read_bytes());plan.update(status='PRIVATE_UNRUN_EXACT9_LEGACY_SENDER',caseCount=9,cases=['ios.self_tests.test_ios_feature_observation.FeatureObservationTests.'+name for name in names],initialOuterSeconds=30,expectedRetainedRoots=0,retainInstalledFixture=False,retentionAliasActually='None: selected fixture/helpers allocate no TD.',modelMaps={},mkdtempAliases=[])
plan['privateFiles']={name:h(S/name) for name in ('root_stage_guard.py','source_model_bindings.py','run-selected.py')}
plan['requiredPublicDependencies']=sorted(set(plan['requiredPublicDependencies'])|{'tests/device/ios/self_tests/test_ios_feature_observation.py','tests/device/self_tests/test_native_feature_observation.py','tests/device/ios/adapters/feature_observation.py','tests/device/adapters/operation_transport_guard.py'})
plan['qualification']='Nine unchanged legacy sender bodies/helpers; native boundaries explicit models. Last case actual loopback redirect server uses original shutdown/join/server_close. No TD, compiler, Node, SDK/device/service.';(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
sup=json.loads((Q/'supervisor-plan.json').read_bytes());sup['initialSeconds']=30;(S/'supervisor-plan.json').write_text(json.dumps(sup,indent=2)+'\n')
(S/'ast-selection.json').write_text(json.dumps(dict(module=str(module),moduleSHA256=h(module),exactNames=names,bodyLineNumbers={name:methods[name].lineno for name in names},targetImportsExecuted=False,testsExecuted=False),indent=2)+'\n')
(S/'README.txt').write_text('''Root-only unchanged sender9 / PRIVATE UNRUN, initial30s+kill5.
Exact9 existing ids, no source/public/registry changes. Same mandatory complete
actual source/SDK/launcher map and preimport FD/thread/child baseline, canonical
three roots/namespace lookup, actual process identity, Task/FD/thread/child final
guards and two retained original censuses. Zero TD/files expected, no retention
alias needed. Existing last redirect case owns real loopback socket/server and
worker and executes original shutdown+join+server_close; no replacement/fake
close/FD exception/GC assumption. Remaining native boundaries modeled. No
compiler/Node/SDK import/device execution. Previous32 originals pinned both
parent source censuses. Source body extraction literal command/guard/native
nonces/AFC no replay and process loss covered by unchanged cases. Actual new
query HTTP sender additionally covered by separate Root Query10 PASS.
Root reviews then from repo: PYTHONDONTWRITEBYTECODE=1 python3 <here>/root-supervise.py
''')
(S/'clone-provenance.json').write_text(json.dumps(dict(parentFreezeSHA256=h(OLD/'freeze.json'),caseCount=9,initialOuterSeconds=30,killAfterSeconds=5,sourcePathCount=len(stage['sourcePaths']),sourceMutation=0,expectedActualRoots=0,entryModuleSHA256=h(module),postPublicationCurrentMapRequired=True),indent=2)+'\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_SENDER9_UNRUN',files={str(p.relative_to(S)):h(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n')
(TOP/'freeze.json').write_text(json.dumps(dict(files={str(p.relative_to(TOP)):h(p) for p in sorted(TOP.rglob('*')) if p.is_file()}),indent=2)+'\n')
print(json.dumps(dict(stageFreeze=h(S/'freeze.json'),parentFreeze=h(TOP/'freeze.json'),exact=9,budget='30+5'),indent=2))
