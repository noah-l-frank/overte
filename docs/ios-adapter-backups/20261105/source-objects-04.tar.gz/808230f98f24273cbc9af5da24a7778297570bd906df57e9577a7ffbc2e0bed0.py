"""UNRUN Normal4 metadata assembler; Root quiet window remains mandatory."""
from pathlib import Path
import ast,hashlib,importlib.util,json,subprocess,sys
SOURCE=Path(__file__).resolve().parent
REPO=SOURCE.parent.parent
PREVIOUS=REPO/'.ios-host-tmp/audio-normal-mute-prefix-controller3-final-preparation-20261104'
NORMAL=REPO/'.ios-host-tmp/audio-whole-positive2-snapshot-return1-agent-run-20261103'
CONTROLLER=REPO/'.ios-host-tmp/audio-normal-four-action-controller4-code-preparation-20261104'
TEST=REPO/'.ios-host-tmp/audio-normal-muted-rejection-unmute-prefix4-source2-native-projection-private-20261104'
PASSED=REPO/'.ios-host-tmp/audio-normal-open-first-mute-literal-prefix-source2-actor-projection-private-20261103'
EXTRAS=REPO/'.ios-host-tmp/root-chat-own17-original-extra12-baselines-20261104'
BASE_CONTEXT=REPO/'.ios-host-tmp/root-terminal660-original-root-context-20261104/terminal-context.json'
CONTEXT=REPO/'.ios-host-tmp/root-terminal665-original-root-context-20261104/terminal-context.json'
CHAT_ROOT=REPO/'.ios-host-tmp/chat-source17c-own17-semantic-controller7-final-preparation-20261104'
CHAT_RESULT=REPO/'.ios-host-tmp/root-chat-source17c-own17-precase-code-object-api-error-results-20261104'
PREP=REPO/'.ios-host-tmp/audio-normal-four-action-controller4-final-preparation-20261104'
HEAD='00fafcc4c097552198456c7e7687f243801d3ed8'
CASE='ios.self_tests.test_ios_audio_normal_muted_rejection_prefix.AudioNormalMutedRejectionPrefixTests.test_actual_muted_record_rejection_and_unmute_join_primary_originals_silence_actor_without_once_claim'
PREFIX_MODULE='ios.self_tests.test_ios_audio_normal_mute_prefix'
TEST_MODULE='ios.self_tests.test_ios_audio_normal_muted_rejection_prefix'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def physical(path):
    path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_relative_to(REPO/'.ios-host-tmp');return path

def reference(row):
    assert type(row)is dict and set(row)=={'path','sha256'}
    path=physical(row['path']);assert path.is_file()and sha(path)==row['sha256'];return dict(path=str(path),sha256=row['sha256'])

def packet(root,filename,expected):
    root=physical(root);file=physical(root/filename);assert sha(file)==expected
    value=json.loads(file.read_text());rows=value['files']
    entries=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
    for name,row in entries:
        assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
        path=physical(root/name);assert path.is_file()and sha(path)==(row['sha256']if type(row)is dict else row)
    return dict(path=str(file),sha256=expected)

def terminal_proofs(value):
    extra=value['additionalOriginalRoots'];authority=value['authoritativeAdditionalOriginalRoots']
    assert type(extra)is list and all(type(root)is str for root in extra)and len(extra)==len(set(extra))
    assert type(authority)is dict and set(authority)==set(extra)
    proof=[]
    for root in extra:
        path=physical(root);assert path.is_dir()
        claim=authority[root];assert type(claim)is dict and set(claim)=={'freeze','result'}
        freeze=reference(claim['freeze']);result=reference(claim['result'])
        f=Path(freeze['path']);assert f.name=='freeze.json'and Path(result['path'])==f.parent/'results.json'
        proof.append(packet(f.parent,f.name,freeze['sha256']))
        manifest=json.loads(f.read_text());assert type(manifest['files'])is dict
        assert manifest['files']['results.json']['sha256']==result['sha256']
        proof.append(result)
    return proof

def terminal_common(value):
    assert value['status']=='ROOT_TERMINAL_CONTEXT_NO_TARGET_NO_GLOBAL_SCAN'
    assert type(value['globalScans'])is int and value['globalScans']==0
    assert type(value['targets'])is int and value['targets']==0 and value['noWriterExclusions']is True
    roots=value['roots'];assert type(roots)is list and all(type(root)is str for root in roots)and len(roots)==len(set(roots))
    return set(roots)

def root_context():
    # This exact two-layer contract intentionally rejects an unknown wrapper.
    # A newer Root set requires a newly reviewed metadata contract, never a
    # silent flatten/drop of baseContext or inferred writer exclusion.
    base_ref=reference(dict(path=str(BASE_CONTEXT),sha256='5bbdc7d787d18c7d5d2e5d456b2c9049b3054730ab952b8d8335822a10a42eac'))
    ctx_ref=reference(dict(path=str(CONTEXT),sha256='e45709c6feece4d2e0f4e70622610572baf8efa9ff47c1016bbabd09603a9837'))
    base=json.loads(BASE_CONTEXT.read_text());wrapper=json.loads(CONTEXT.read_text())
    common={'additionalOriginalRoots','authoritativeAdditionalOriginalRoots','globalScans','noWriterExclusions','roots','status','targets'}
    assert set(base)==common|{'base653Baseline','base653ExternalTerminal','base653Freeze','base653InputMap','base653Seed'}
    assert set(wrapper)==common|{'baseContext'}and wrapper['baseContext']==base_ref
    roots660=terminal_common(base);roots665=terminal_common(wrapper)
    assert len(roots660)==660 and len(roots665)==665
    assert len(base['additionalOriginalRoots'])==7 and len(wrapper['additionalOriginalRoots'])==5
    old=reference(base['base653Baseline']);assert old['path']==str(PREVIOUS/'global-original-corpus-baseline.json')and old['sha256']=='1e89fcf8ce75273e569fb83b2c865251bd6f2b35b4377aa30a7c570a0fa08cff'
    rows653=json.loads(Path(old['path']).read_text());assert type(rows653)is dict and len(rows653)==653
    assert set(rows653).isdisjoint(base['additionalOriginalRoots'])and roots660==set(rows653)|set(base['additionalOriginalRoots'])
    assert roots660.isdisjoint(wrapper['additionalOriginalRoots'])and roots665==roots660|set(wrapper['additionalOriginalRoots'])
    required={'base653Freeze':('freeze.json','bd27ef472d35a209f4a157deea16504ec718db0a9ce78f00d0448daa7621ab37'),
        'base653InputMap':('preimport-map.json','7eb647b3e770144f0a88f9e759063a5598fb4fe9ebd1a21345b4f2af07423090'),
        'base653Seed':('global-original-roots-seed.json','c98f202fd51111627336fac857dd1c3c8a540be2c8ae01db2b0a1ff07f8cb468'),
        'base653ExternalTerminal':('external-terminal.json','aaba3054b583be6b3c238d797852d8f7f718a91bb1e9f5c576279bdc42af9c6b')}
    proofs=[base_ref,ctx_ref,old]
    for key,(filename,expected)in required.items():
        row=reference(base[key]);assert row==dict(path=str(PREVIOUS/filename),sha256=expected);proofs.append(row)
    original_terminal=json.loads((PREVIOUS/'external-terminal.json').read_text())
    assert original_terminal['status']=='PASS'and original_terminal['childReturnCode']==0 and original_terminal['globalOldRoots']==653
    assert original_terminal['allPinsUnchanged']and original_terminal['ownProcessesAbsent']and original_terminal['twoExternalRawCensusesEqual']and original_terminal['twoFullGlobalCensusesEqual']and not original_terminal['problems']
    proofs+=terminal_proofs(base)+terminal_proofs(wrapper)
    extra_freeze=packet(EXTRAS,'freeze.json','3e518b2df56a7fa6d3cba8e31a8e39baec0ad47000b5e8b3aaabc47be7d5fe32')
    extra_path=EXTRAS/'expected-additional-originals.json';extra_proof=EXTRAS/'proofs.json'
    extra=json.loads(extra_path.read_text());assert type(extra)is dict and len(extra)==12 and set(extra)==roots665-set(rows653)
    proof=json.loads(extra_proof.read_text())
    assert proof['roots']==12 and proof['globalScans']==0 and proof['targets']==0 and proof['targetImports']==0 and proof['producerRawAndUtilityGroupsCompared']is True
    assert proof['old653RetainedBaseline']==old
    assert proof['status']=='TWICE_READ_TERMINAL_EXTRAS_MATCH_ORIGINAL_PARENT_RAW_OUTPUT_CENSUSES_AND_ALL_FROZEN_RECEIPT_HASHES'
    actual_receipts={json.dumps(claim['freeze'],sort_keys=True)for ctx in(base,wrapper)for claim in ctx['authoritativeAdditionalOriginalRoots'].values()}
    assert {json.dumps(row,sort_keys=True)for row in proof['terminalResultPackets']}==actual_receipts
    expected=dict(rows653);expected.update(extra);assert len(expected)==665
    proofs.extend((extra_freeze,dict(path=str(extra_path),sha256=sha(extra_path)),dict(path=str(extra_proof),sha256=sha(extra_proof))))
    return roots665,expected,proofs,base,wrapper

def chat_terminal_delta():
    # A known terminal PRECASE FAILURE is retained; no suite/cleanup/parentFD
    # qualification may be fabricated from this provenance-only admission.
    result_ref=packet(CHAT_RESULT,'freeze.json','ddfa8f739c9be72bd8c8f028de935614d8d03b67fe431730980896eb94f63d16')
    result_path=CHAT_RESULT/'results.json';value=json.loads(result_path.read_text())
    assert value['publicHead']==HEAD and value['newOriginalRoots']==[str(CHAT_ROOT)]and value['rawProducerRootsCreated']==0
    assert value['allSeventeenCasesUnrun']is True and value['actualStandardCaseCleanupQualified']is False and value['parentFDThreadDrainQualified']is False
    assert value['nativeQualified']is False and value['wholeQualified']is False and value['unchangedRetryAuthorized']is False
    assert value['child']['failure']['type']=='AttributeError'and value['child']['testsRun']is None and value['child']['standardRunReturned']is False
    terminal=value['terminal'];assert terminal['status']=='FAIL_PRECASE_API_ERROR'and terminal['childReturnCode']==1
    assert terminal['ownProcessesAbsent']is True and terminal['timedOut']is False and terminal['forcedKill']is False
    report=value['report'];assert report['globalRoots']==665 and report['exitCode']==1 and report['allGlobalOriginalsUnchanged']is True and report['globalMembershipUnchanged']is True
    assert report['allSourcePinsEqual']is True and report['inputUnchanged']is True and report['outputCensusesEqual']is True and report['remainingOwnedProcesses']==[]
    controller=packet(CHAT_ROOT,'freeze.json',value['controllerFreeze'])
    assert controller['sha256']=='552e4f37a34805416c354fbc46520c3e8c74db72d834a3fda87b69f821424441'
    references_path=CHAT_RESULT/'actual-receipt-references.json';references=json.loads(references_path.read_text())
    required={'child-input-first.json','child-input-second.json','child-result.json','global-first.json','global-second.json','input-before.json','output-first.json','output-second.json','process-binding.json','report.json','source-after.json','source-before.json','term-stack.log','test.log'}
    assert type(references)is dict and set(references)==required
    refs=[result_ref,controller,dict(path=str(result_path),sha256=sha(result_path)),dict(path=str(references_path),sha256=sha(references_path))]
    for name,row in references.items():
        ref=reference(row);assert ref['path']==str(CHAT_ROOT/name);refs.append(ref)
    assert references['global-first.json']['sha256']==references['global-second.json']['sha256']
    assert references['output-first.json']['sha256']==references['output-second.json']['sha256']
    assert references['source-before.json']['sha256']==references['source-after.json']['sha256']
    output=json.loads((CHAT_ROOT/'output-first.json').read_text())
    assert type(output)is dict and set(output)=={'child-input-first.json','child-input-second.json','child-output-first.json','child-output-second.json','child-result.json','process-binding.json','term-stack.log','test.log'}
    manifest=json.loads((CHAT_ROOT/'freeze.json').read_text());initial={row['path']:row for row in manifest['files']}
    assert all(type(name)is str and Path(name).name==name for name in initial)
    names=set(initial)|set(references)|set(output)|{'freeze.json','input-first.json','input-second.json'}
    expected_hashes={name:row['sha256']for name,row in initial.items()}
    for name,row in references.items():
        if name in expected_hashes:assert expected_hashes[name]==row['sha256']
        expected_hashes[name]=row['sha256']
    for name,row in output.items():
        if name in expected_hashes:assert expected_hashes[name]==row['sha256']
        expected_hashes[name]=row['sha256']
    expected_hashes['freeze.json']=controller['sha256']
    for name in('input-first.json','input-second.json'):
        expected_hashes[name]=references['input-before.json']['sha256']
    assert set(expected_hashes)==names
    return refs,names,expected_hashes,output

def verify_chat_body(body,names,hashes,output):
    assert set(body)=={'.'}|names
    for name,expected in hashes.items():assert body[name]['sha256']==expected
    for name,row in output.items():assert body[name]==row


def write(name,value):
    path=PREP/name;assert path.parent==PREP and not path.exists()
    with path.open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    path.chmod(0o600)

def module_name(path,root):
    parts=path.relative_to(root).with_suffix('').parts;return '.'.join(parts[:-1]if parts[-1]=='__init__'else parts)

def main():
    assert sys.dont_write_bytecode and len(sys.argv)==2
    source=packet(SOURCE,'source-freeze.json',sys.argv[1])
    roots665,expected665,proofs,base,wrapper=root_context()
    delta_proofs,delta_names,delta_hashes,delta_output=chat_terminal_delta();proofs+=delta_proofs
    assert str(CHAT_ROOT)not in roots665
    roots=roots665|{str(CHAT_ROOT)};assert len(roots)==666
    previous=packet(PREVIOUS,'freeze.json','bd27ef472d35a209f4a157deea16504ec718db0a9ce78f00d0448daa7621ab37')
    controller=packet(CONTROLLER,'code-preparation-freeze.json','aef2aaa8217f200b39c23f61c070a79e7331b61e173452b388a53bbc66f48372')
    test=packet(TEST,'freeze.json','1ef25cec796925e7a3787acc0be04a63b213095c1d45d518a6bf65464b9a9da2')
    passed=packet(PASSED,'freeze.json','6924845568ac27f52598b48255ccf995c984d10e2401fd20979982a3e360de40')
    normal=packet(NORMAL,'freeze.json','3866f8d3c7382660cdfdc03dfca3df952837d3e5593d070032681d850543bc5f')
    prior_map=PREVIOUS/'preimport-map.json';normal_map=NORMAL/'preimport-map.json'
    assert sha(prior_map)=='7eb647b3e770144f0a88f9e759063a5598fb4fe9ebd1a21345b4f2af07423090'and sha(normal_map)=='2e6281834267ef38fb38d83eb18dba17a8a0a59634d9e04f79c511800e0d1ed8'
    prior=json.loads(prior_map.read_text());original=json.loads(normal_map.read_text())
    old86={k:dict(v)for k,v in original['modules'].items()if Path(v['path']).is_relative_to(REPO/'.ios-host-tmp')}
    private={k:dict(v)for k,v in prior['modules'].items()if Path(v['path']).is_relative_to(REPO/'.ios-host-tmp')}
    assert len(old86)==86 and len(private)==87 and set(private)==set(old86)|{PREFIX_MODULE}
    assert all(private[k]==v for k,v in old86.items())and all(sha(v['path'])==v['sha256']for v in private.values())
    prefix_file=PASSED/'candidate/tests/device/ios/self_tests/test_ios_audio_normal_mute_prefix.py'
    assert private[PREFIX_MODULE]['path']==str(prefix_file)and private[PREFIX_MODULE]['sha256']==sha(prefix_file)
    git=Path((REPO/'.git').read_text().split('gitdir: ',1)[1].strip()).resolve(strict=True)
    common=(git/(git/'commondir').read_text().strip()).resolve(strict=True);head=(git/'HEAD').read_text().strip()
    assert head.startswith('ref: ')and(common/head[5:]).read_text().strip()==HEAD
    modules=dict(private);public=REPO/'tests/device'
    namespaces={k:[p for p in values if Path(p).is_relative_to(REPO/'.ios-host-tmp')]for k,values in prior['namespacePackages'].items()}
    paths=[Path(p)for p in subprocess.check_output(['rg','--files',str(public),'-g','*.py'],text=True).splitlines()]
    for path in sorted(paths):
        assert path.resolve(strict=True)==path and not path.is_symlink();label=module_name(path,public)
        if label and label not in modules:modules[label]=dict(path=str(path),sha256=sha(path),package=path.name=='__init__.py',layer='public-current-00faf')
        parts=path.relative_to(public).with_suffix('').parts
        for index in range(1,len(parts)):
            key='.'.join(parts[:index]);directory=str(public.joinpath(*parts[:index]))
            if directory not in namespaces.setdefault(key,[]):namespaces[key].append(directory)
    case_file=TEST/'candidate/tests/device/ios/self_tests/test_ios_audio_normal_muted_rejection_prefix.py'
    modules[TEST_MODULE]=dict(path=str(case_file),sha256=sha(case_file),package=False,layer='new-normal4-test-only')
    namespaces={k:v for k,v in namespaces.items()if v and k not in modules}
    assert all(modules[k]==v for k,v in private.items())
    assert modules['adapters.native_clock_join']==prior['modules']['adapters.native_clock_join']
    assert 'adapters.native_clock_join_refusal_original'not in modules
    assert not any('importer-custody7'in row['path']or 'audio_original_validation_graph.py'in row['path']or 'native-clock-join-original-operands-diagnostic'in row['path']for row in modules.values())
    for row in prior['frozenPackets']:assert sha(row['path'])==row['sha256']
    assert not PREP.exists();PREP.mkdir(mode=0o700)
    for file in('owned_write_boundary.py','global_original_corpus.py'):
        raw=(CONTROLLER/file).read_bytes();assert raw==(PREVIOUS/file).read_bytes();(PREP/file).write_bytes(raw)
    write('global-original-roots-seed.json',dict(roots=sorted(roots),allOld653AndRoot12Exact=True,knownTerminalPrecaseFailureWholeRoot=str(CHAT_ROOT),noWriterExclusions=True))
    spec=importlib.util.spec_from_file_location('normal4_metadata_original_census',PREP/'global_original_corpus.py')
    census=importlib.util.module_from_spec(spec);spec.loader.exec_module(census)
    first=census.current();second=census.current();assert first==second and set(first)==roots
    assert all(first[root]==body for root,body in expected665.items())
    verify_chat_body(first[str(CHAT_ROOT)],delta_names,delta_hashes,delta_output)
    expected=dict(expected665);expected[str(CHAT_ROOT)]=first[str(CHAT_ROOT)]
    write('global-original-corpus-baseline.json',first)
    write('terminal-context.json',dict(base660=base,wrapper665=wrapper,sourceBaseContext=str(BASE_CONTEXT),sourceWrapperContext=str(CONTEXT)))
    frozen=list(prior['frozenPackets'])+[source,previous,controller,test,passed,normal,dict(path=str(prior_map),sha256=sha(prior_map)),dict(path=str(normal_map),sha256=sha(normal_map)),*proofs]
    dedup={}
    for row in frozen:
        if row['path']in dedup:assert dedup[row['path']]==row
        dedup[row['path']]=row
    files=['run-prefix.py','external-supervisor.py','owned_write_boundary.py','global_original_corpus.py','preimport-map.json','global-original-roots-seed.json','global-original-corpus-baseline.json','terminal-context.json','SOURCE-READBACK.json','EXECUTION-PLAN.md']
    plan=dict(prior,root=str(PREP),repository=str(REPO),reportedRootHead=HEAD,status='PRIVATE_UNRUN_NEW_NORMAL4_REQUIRES_ROOT_REVIEW',cases=[CASE],modules=modules,namespacePackages=namespaces,frozenPackets=list(dedup.values()),controllerFiles=files,writeBoundarySource=dict(path=str(PREP/'owned_write_boundary.py'),sha256=sha(PREP/'owned_write_boundary.py')),historicalCorpus=None,historicalLock=None,needsTemporaryRoot=True,baseNormalMap=str(normal_map),baseNormalMapSha256=sha(normal_map),noSource7ProductAdoption=True,clockDiagnosticNotAdopted=True)
    write('preimport-map.json',plan);map_sha=sha(PREP/'preimport-map.json')
    for template,file in(('run-prefix.template.py','run-prefix.py'),('external-supervisor.template.py','external-supervisor.py')):
        text=(CONTROLLER/template).read_text().replace('SOURCE_MAP_PENDING_ROOT_REVIEW',map_sha);ast.parse(text);(PREP/file).write_text(text)
    write('SOURCE-READBACK.json',dict(old86PhysicallyExact=True,passedSource2ModuleExact=True,privateModules=88,old653AndExtras12Exact=True,knownTerminalPrecaseFailureWholeRoot=str(CHAT_ROOT),all666Retained=True,globalRoots=666,globalEntries=sum(len(v)for v in first.values()),publicPythonPaths=len(paths),modules=len(modules),cases=[CASE],baseContextAndWrapperValidated=True,clockDiagnosticNotAdopted=True,targetExecutions=0,rawRootsCreated=0))
    (PREP/'EXECUTION-PLAN.md').write_bytes((CONTROLLER/'REVIEW.md').read_bytes())
    assert first==census.current()==expected and all(sha(row['path'])==row['sha256']for row in modules.values())
    assert(common/head[5:]).read_text().strip()==HEAD
    rows={p.name:dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(PREP.iterdir())if p.is_file()}
    write('freeze.json',dict(status='UNRUN_NORMAL4_REQUIRES_ROOT_REVIEW_AND_NEW_WINDOW',files=rows,mapSha256=map_sha,publicHead=HEAD,sourceFreeze=source['sha256'],cases=[CASE],wallSeconds=180,killGraceSeconds=5,failfast=True,noSource7ProductAdoption=True,clockDiagnosticNotAdopted=True,globalRoots=666,targetExecutions=0,rawRootsCreated=0))
    print(json.dumps(dict(freeze=sha(PREP/'freeze.json'),map=map_sha,modules=len(modules),globalRoots=666,targetExecutions=0)))
if __name__=='__main__':main()
