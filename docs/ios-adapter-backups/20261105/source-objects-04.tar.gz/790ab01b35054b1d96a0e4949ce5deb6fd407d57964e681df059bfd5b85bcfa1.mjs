/* Source-defined Node child-state model only; no SDK/import/service process. */
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import vm from 'node:vm';
import test from 'node:test';

const filename=process.env.LIFECYCLE_SIGNALED_CLOSE_MODEL_SOURCE;
const expected=process.env.LIFECYCLE_SIGNALED_CLOSE_MODEL_SOURCE_SHA256;
const bytes=readFileSync(filename);
assert.equal(createHash('sha256').update(bytes).digest('hex'),expected);
const source=bytes.toString('utf8');
const start=source.indexOf('export class OriginalUserspaceKeeper {');
const end=source.indexOf('\n\nexport async function startOriginalUserspaceKeeper',start);
assert(start>=0 && end>start);
const actualClass=source.slice(start,end).replace(/^export /,'');
// Exact actual class source is parsed/evaluated, not an equivalent copied
// cleanup algorithm. SDK/helper top-level imports/start function never run.
const OriginalUserspaceKeeper=vm.runInNewContext(`(${actualClass})`,{
  Buffer,MAX_BYTES:16384,
  setTimeout(){throw new Error('An already-exited original must not schedule a second wait');},
  clearTimeout(){},
},{filename:'pinned-actual-userspace-keeper-class'});
class ChildModel extends EventEmitter {
  constructor(){
    super();this.exitCode=null;this.signalCode='SIGTERM';this.kills=[];
    this.stdout=new EventEmitter();this.stderr={resume(){}};
    this.emit('exit',null,'SIGTERM'); // This ORIGINAL event already happened.
  }
  kill(signal){this.kills.push(signal);return false;}
}
test('already signaled original child closes without second exit wait or status reset',async()=>{
  const child=new ChildModel();const owner=new OriginalUserspaceKeeper(child,'model-target');
  owner.failed=true;
  const listeners=child.listenerCount('exit');
  assert.equal(await owner.close(),undefined);
  assert.equal(owner.failed,true);assert.deepEqual(child.kills,[]);
  assert.equal(child.listenerCount('exit'),listeners);
});
