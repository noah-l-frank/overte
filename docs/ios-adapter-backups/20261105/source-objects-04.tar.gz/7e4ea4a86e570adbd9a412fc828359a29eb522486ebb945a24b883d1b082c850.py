"""Normal picker on the actually owned shared page, with separate page duty.

Version2 never calls a live leased page dead. Local file retirement requires
original native/file/work quiet windows while that exact page stays alive;
page duty remains in the independent PageLease until actual final Home close.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import need
from ios.adapters.assets_budget import operation
from ios.adapters.assets_picker import OwnedAssetsPicker,root
from ios.adapters.assets_controls import project
from ios.adapters.assets_files import quiet
from ios.adapters.assets_page_lease import OwnedAssetsPageLease
from ios.adapters.assets_episodes import AssetsEpisodeScope


class PageLeasePicker(OwnedAssetsPicker):
    OWNER_VERSION=2
    def __init__(self,*args,page_lease,episode,**kwargs):
        need(isinstance(page_lease,OwnedAssetsPageLease) and type(episode) is AssetsEpisodeScope and episode.owner is page_lease.episodes)
        self.page_lease,self.episode=page_lease,episode;super().__init__(*args,**kwargs);page_lease.context(episode,self)
    def extra_envelope(self):return dict(pageLease=self.page_lease.link(),episode=self.episode.link())
    def validate_extra(self,value):need(value['pageLease']==self.page_lease.link() and value['episode']==self.episode.link())
    def retirement_phase(self):return 'page-borrowed-retired'
    def cleanup_page(self,current,state):
        page=root(current,'page',identifier=state['page']);original=self.page_lease.identity()
        need(page['alive'] and page['visible'] and all(page[key]==original[key] for key in ('rootId','windowId','modelId','componentSource','ownerRootId')))
        return page
    def cleanup_files(self,files):
        need(files.get('exists') is True and files['complete'] and not files['releasing'] and type(files['retiredPrimary']) is bool
            and files['files'][0]['exists'] is (not files['retiredPrimary']) and all(row['exists'] for row in files['files'][1:]))
    @operation
    def open_page(self):
        self.page_lease.live(self.episode);need(self.state['phase']=='reserved')
        if self.page_lease.state['origin'] is None:
            need(self.episode.index==1);current=super().open_page();self.page_lease.attach(self.episode,self);return current
        # Real normal UI capture on the already owned page, not menu reopen.
        row=self.page_lease.attach(self.episode,self);page=row['page'];need(page['alive'])
        self.state.update(page=page['rootId'],phase='page-open');self.save();return project(self.state['captures'][-1])
    @operation
    def cancel_owned(self):
        self.page_lease.live(self.episode)
        if self.state['phase']=='picker-closed':return self.files.observe()
        if self.state['phase']=='canceling':return self.recover_cancel()
        need(self.state['phase'] in ('picker-open','primary-chosen','unavailable'))
        self.state['phase']='canceling';self.save();self.input('cancel-picker','asset-file.cancel');return self.recover_cancel()
    @operation
    def retire_inputs(self):
        self.page_lease.live(self.episode)
        if self.state['phase']==self.retirement_phase():
            self.page_lease.transferred(self.episode,self);return self.files.state['originals'][-1]['packet']
        need(self.state['phase']=='picker-closed');self._window('cleanupWindow','cleanup')
        packet=self.files.recover_release() if self.files.state['phase']=='releasing' else self.files.release()
        quiet(packet['source']);self.cleanup_page(dict(inventory=packet['source']['ui']),self.state)
        self.state['phase']=self.retirement_phase();self.save();self.page_lease.transferred(self.episode,self);return packet
    @operation
    def close_shared_page(self):
        self.page_lease.live(self.episode);need(self.page_lease.state['phase']=='closing' and self.state['phase']==self.retirement_phase())
        self._prepare_slot('close-assets-page','assets.home');current=self._until_dead('page',self.state['page'])
        # File inputs are already retired; no fresh file query is needed to
        # label the actual native root dead. Parent retains the page source.
        return current
