"""A real closed Finder and original-source execution; no site fallback."""
from pathlib import Path
import importlib.abc,importlib.machinery,importlib.util,sys
from .common import FORBIDDEN,pin
from .closed_import_origins import ClosedOrigins
class ActualSource(importlib.abc.Loader):
 def __init__(self,owner,name,row):
  self.owner,self.name,self.row=owner,name,row
  self.delegate=owner.origins.file_spec(name,row,'project').loader
 def create_module(self,spec):return self.delegate.create_module(spec)
 def exec_module(self,module):
  path=Path(self.row['path']);self.owner.origins.physical(path)
  assert pin(path)['sha256']==self.row['sha256']
  module.__file__=str(path)
  if self.row['package']:module.__path__=[str(path.parent)]
  # The real fresh-byte delegate executes this very module/spec; no receipt
  # is copied from another module or inferred from a source-path hash.
  self.delegate.exec_module(module)
  self.owner.origins.physical(path);self.owner.origins.project_loaded(self.name,module,self.row)
  self.owner.loaded[self.name]=dict(path=str(path),sha256=self.row['sha256'])
  callback=self.owner.after_load.get(self.name)
  if callback is not None:callback(module)
class ClosedFinder(importlib.abc.MetaPathFinder):
 def __init__(self,plan,source,repo,command=None):
  self.plan=plan;self.loaded={};self.after_load={};self.origins=ClosedOrigins(plan,source,repo,pin,command_binding=command)
  self.tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespacePackages'],*plan['thirdPartyModules'],*plan['thirdPartyNamespacePackages'])}
 def find_spec(self,name,path=None,target=None):
  if name.split('.')[0]in FORBIDDEN:raise ImportError('No physical SDK/browser/native package: '+name)
  row=self.plan['modules'].get(name)
  if row is not None:return importlib.util.spec_from_file_location(name,row['path'],loader=ActualSource(self,name,row),submodule_search_locations=[str(Path(row['path']).parent)]if row['package']else None)
  roots=self.plan['namespacePackages'].get(name)
  if roots is not None:
   self.origins.namespaces(name,roots,roots,'project');spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots;return spec
  if name in self.plan['thirdPartyModules']or name in self.plan['thirdPartyNamespacePackages']:return self.origins.remaining_spec(name,path)
  if name.split('.')[0]in self.tops:raise ImportError('Missing exact closed module: '+name)
  return self.origins.remaining_spec(name,path)
 def install(self):
  assert self not in sys.meta_path;sys.meta_path.insert(0,self)
 def snapshot(self,name):return self.origins.snapshot(name)
 def restore(self):
  assert sys.meta_path[0]is self;sys.meta_path.remove(self)
