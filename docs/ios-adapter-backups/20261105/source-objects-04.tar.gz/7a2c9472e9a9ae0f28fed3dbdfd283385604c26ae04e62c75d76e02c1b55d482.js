"use strict";
(function () {
    var companion = Script.require("./companion.js");
    var marker = Entities.addEntity({
        type: "Web", name: "e2e-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa-script",
        userData: "{\"kind\":\"avatar-marker-v1\",\"nonce\":\"2a2e60ec755bf1919d8de76b3aa45571\",\"runId\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"}",
        parentID: MyAvatar.SELF_ID, parentJointIndex: 65535,
        localPosition: {x: 0, y: 1.6, z: -3},
        localRotation: {x: 0, y: 0, z: 0, w: 1},
        dimensions: {x: 1.6, y: 0.4, z: 0.01},
        sourceUrl: "http://127.0.0.1:45805/feature-fixture/v1/runs/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/tickets/81e81f554770475db17b980d97061c06/graphics-marker.v1.html", visible: true, collisionless: true, dpi: 100
    }, "local");
    Script.scriptEnding.connect(function () {
        if (marker) { Entities.deleteEntity(marker); }
    });
}());
