"""Private same-dataset two-copy experiment; no PFS/SDK/product result."""
from pathlib import Path
import copy,hashlib,importlib.util,json,statistics,struct,sys,time
HERE=Path(__file__).resolve().parent;SNAPSHOT=HERE/'pair_snapshot.py'
FILES=(Path(__file__).resolve(),SNAPSHOT)
before={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in FILES}
spec=importlib.util.spec_from_file_location('private_world_pair_bench',SNAPSHOT)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
assert module._same_copy(copy.deepcopy)

def graph(size):
    rows=[]
    for index in range(size):
        rows.append(dict(id=index,requestId=format(index,'032x'),active=index%2==0,
                         clock=dict(epochMs=1790000000000+index,monotonicMs=index/4),
                         labels=['source-'+str(index),'Überte',None],
                         coordinates=[index/10,-0.0,1.0],
                         ownership=dict(generation=0,pid='42',alive=True)))
    return dict(rows=rows,profile='declared-metadata-only',complete=True)


def nodes(value):
    pending=[value];seen={}
    while pending:
        item=pending.pop()
        if type(item) not in (dict,list) or id(item) in seen:continue
        seen[id(item)]=item;pending.extend(item.values() if type(item) is dict else item)
    return seen


def equal_graph(source,target):
    original=nodes(source);forward={};reverse={};pending=[(source,target)]
    while pending:
        left,right=pending.pop();assert type(left) is type(right)
        if type(left) in (dict,list):
            if id(left) in forward:assert forward[id(left)] is right;continue
            assert left is not right and id(right) not in original and id(right) not in reverse
            forward[id(left)]=right;reverse[id(right)]=left
            if type(left) is dict:
                assert list(left)==list(right);pending.extend((left[key],right[key]) for key in left)
            else:assert len(left)==len(right);pending.extend(zip(left,right))
        elif type(left) is float:assert struct.pack('>d',left)==struct.pack('>d',right)
        else:assert left==right


def verified_pair(source,pair):
    assert pair is not None and type(pair) is tuple and len(pair)==2
    cached,outward=pair;equal_graph(source,cached);equal_graph(source,outward)
    assert set(nodes(cached)).isdisjoint(nodes(outward))


def literal_pair(value):
    cached=copy.deepcopy(value)
    return cached,copy.deepcopy(cached)


# Untimed alias/cycle control checks the mutable graph contract, not runtime.
shared=[];control={'first':shared,'second':shared,'distinct':[]};shared.append(control)
verified_pair(control,module.clone_pair(control,copy.deepcopy))
results=[]
for size in (24,512,2048):
    value=graph(size);old=[];new=[]
    for round_number in range(3):
        order=('literal','candidate') if round_number%2==0 else ('candidate','literal')
        for name in order:
            started=time.perf_counter()
            pair=literal_pair(value) if name=='literal' else module.clone_pair(value,copy.deepcopy)
            elapsed=time.perf_counter()-started
            verified_pair(value,pair)
            (old if name=='literal' else new).append(elapsed)
    counts=dict(dumps=0,loads=0);previous_profile=sys.getprofile()
    def actual_codec(frame,event,arg):
        if event=='c_call':
            if arg is module._DUMPS:counts['dumps']+=1
            elif arg is module._LOADS:counts['loads']+=1
    try:
        sys.setprofile(actual_codec);pair=module.clone_pair(value,copy.deepcopy)
    finally:sys.setprofile(previous_profile)
    verified_pair(value,pair);assert counts==dict(dumps=1,loads=2),counts
    results.append(dict(rows=size,literalPairSeconds=old,candidatePairSeconds=new,
        medianLiteralPairSeconds=statistics.median(old),medianCandidatePairSeconds=statistics.median(new),
        candidateOverLiteral=statistics.median(new)/statistics.median(old),actualCodecCalls=counts))
after={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in FILES};assert before==after
report=dict(status='PURE_JSON_PAIR_EXPERIMENT_COMPLETE',sourcePins=before,results=results,
    sameDatasetAsPriorSingleExperiment=True,sourceWiring=False,actualRetainedDatasetTested=False,
    wholeFeatureQualified=False,nativeCompiled=False,devicesTested=False,
    performanceBoundary='Synthetic data only; original base helper snapshot plus pair function, no new Source/helper-epoch wiring. No end-to-end or isolated-system runtime claim.')
(HERE/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,sort_keys=True))
