"""One finite genuine Emote terminal-kernel utility; complete old-original window."""
from pathlib import Path
import argparse,hashlib,json,os,runpy,stat,subprocess,sys,traceback
R=Path.cwd().resolve(strict=True);B=R/'.ios-host-tmp';S=Path(__file__).resolve().parent
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def census(root):
    assert root.resolve(strict=True) == root and root.is_dir() and not root.is_symlink()
    result = {}
    for path in (root, *sorted(root.rglob('*'))):
        before = path.lstat()
        value = {key: getattr(before, key) for key in FIELDS}
        if stat.S_ISREG(before.st_mode):
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            try:
                assert all(getattr(os.fstat(descriptor), key) == value[key] for key in FIELDS)
                digest = hashlib.sha256()
                while chunk := os.read(descriptor, 1024 * 1024):
                    digest.update(chunk)
                assert all(getattr(os.fstat(descriptor), key) == value[key] for key in FIELDS)
                value['sha256'] = digest.hexdigest()
            finally:
                os.close(descriptor)
        elif stat.S_ISLNK(before.st_mode):
            value['target'] = os.readlink(path)
        else:
            assert stat.S_ISDIR(before.st_mode)
        assert all(getattr(path.lstat(), key) == value[key] for key in FIELDS)
        result[str(path.relative_to(root))] = value
    return result
def private(p,exists=True):
    p=Path(p);assert p.is_absolute()and p.resolve(strict=exists)==p and p.is_relative_to(B);return p
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--configuration',type=Path,required=True);parser.add_argument('--configuration-sha',required=True);a=parser.parse_args()
    assert R.name=='overte-ios-feature-adapters-resume-20261026'and sys.flags.no_site and sys.dont_write_bytecode
    cp=private(a.configuration);assert sha(cp)==a.configuration_sha;config=load(cp)
    assert config['status']=='ROOT_REVIEWED_SINGLE_EMOTE_KERNEL_UTILITY_CURRENT974_UNRUN'and config['schemaVersion']==1
    assert config['scriptSha256']==sha(Path(__file__))and config['sourceFreeze']==sha(S/'source-freeze.json')
    profile_path=S/'PROFILES.json';profile_sha=load(S/'source-freeze.json')['files']['PROFILES.json']['sha256']
    assert sha(profile_path)==profile_sha
    profiles=load(profile_path);assert sha(profile_path)==profile_sha
    assert len(profiles)==len(config['groups'])==1
    context=private(config['context']);assert sha(context)==config['contextSha256'];ctx=load(context)
    assert ctx['allTargetsTerminal']is True and ctx['expectedHead']==config['expectedHead']
    baseline=private(ctx['globalCustody']['baseline']['path']);helper=private(ctx['globalCustody']['helper']['path'])
    assert baseline.parent==helper.parent==context.parent and sha(baseline)==ctx['globalCustody']['baseline']['sha256']
    assert sha(helper)==ctx['globalCustody']['helper']['sha256']=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
    expected=load(baseline);assert len(expected)==config['oldRootCount']==974
    plans=[];all_cases=[]
    for profile,row in zip(profiles,config['groups']):
        assert row['group']==profile['group'];p=private(row['input']);h=p.parent
        assert h.parent==B and h.name.startswith(profile['destinationPrefix'])and p==h/'approved-inputs.json'
        assert sha(p)==row['inputSha256'];plan=load(p)
        assert plan['repositoryRoot']==str(R)and plan['controllerRoot']==str(h)and plan['actualPublicHead']==config['expectedHead']
        assert plan['sourceFreeze']==profile['sourceFreeze']and plan['status']==profile['inputStatus']
        src=private(B/profile['sourceDirectory']);assert sha(src/'source-freeze.json')==profile['sourceFreeze']
        for name in (profile['supervisor'],profile['runner']):assert sha(h/name)==sha(src/name)
        assert plan['wallSeconds']==30 and plan['killGraceSeconds']==5 and len(plan['cases'])==profile['cases']
        assert plan['PythonExecutions']==profile['PythonExecutions']and plan['subjectOriginCount']==profile['origins']and plan['expectedTemporaryDirectories']==profile['TDs']
        assert plan['NodeExecutions']==plan['SDKExecutions']==plan['overteNativeQueries']==plan['oldApplicationCorpusInputs']==plan['globalOriginalScans']==plan['oldScenarioOriginalInputs']==0
        assert plan['realNetwork']is plan['nativeQualified']is plan['wholeQualified']is False
        assert plan['subjectHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
        assert set(plan['currentSourceExecution']['requiredOriginalRoots'])<=set(expected)
        for key in profile['nullGates']:assert plan[key]is None
        assert plan['kernelSourceFreeze']=='0af2fd7f0bd338041b68dab71646142b3fcce514ed16b02d1fcc2e092cde2e11'
        assert plan['expectedPipeObjects']==18 and plan['expectedBornPipeEndpoints']==36 and plan['expectedParentStreamWrappers']==18
        assert plan['maximumLiveUtilityChildren']==1 and plan['thirdPartyModules']=={}
        rooms=(h,h.with_name(h.name+'-outer'),h.with_name(h.name+'-censuses'))
        assert not rooms[1].exists()and not rooms[2].exists()
        plans.append((profile,row,plan,rooms));all_cases+=plan['cases']
    assert len(all_cases)==len(set(all_cases))==6
    out=private(config['output'],False);assert out.parent==B and not out.exists();out.mkdir(mode=0o700)
    def put(name,value):
        p=out/name
        with p.open('x')as f:json.dump(value,f,sort_keys=True,separators=(',',':'));f.write('\n')
        p.chmod(0o600)
    current=runpy.run_path(str(helper))['current'];before=current();assert before==expected;put('global-before.json',before)
    put('configuration-reference.json',dict(path=str(cp),sha256=a.configuration_sha))
    completed=[];new_roots=[]
    for profile,row,plan,rooms in plans:
        h,o,c=rooms;group=profile['group']
        attempt=dict(group=group,input=row['input'],inputSha256=row['inputSha256'],prospectiveOriginalRooms=list(map(str,rooms)),ownedAbsenceEstablished=False)
        put('attempt-before-'+group+'.json',attempt)
        try:
            print('ROOT_UTILITY_START '+group+' '+str(len(plan['cases']))+' CASES',flush=True)
            with(out/(group+'-stdout.log')).open('xb')as stdout,(out/(group+'-stderr.log')).open('xb')as stderr:
                result=subprocess.run([sys.executable,'-S','-B',str(h/profile['supervisor']),row['inputSha256']],cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
            terminal=load(o/'terminal.json');drain=load(o/'actual-process-drain.json');qualification=load(c/'qualification.json')
            assert terminal['ownProcessesAbsent']and not drain['remaining']and qualification['ownProcessesAbsent']
            assert qualification['originalRoots']==list(map(str,rooms))and qualification['noCensusExclusions']is True
            for owned in drain['owned']:
                try:raw=Path('/proc',str(owned['pid']),'stat').read_text()
                except(FileNotFoundError,ProcessLookupError):continue
                fields=raw[raw.rfind(')')+2:].split();assert int(fields[19])!=owned['startTicks'],'Original process remains; no quiet close'
        except BaseException:
            put('unqualified-partial-custody.json',dict(status='NO_QUIET_CLOSE_INFERRED',attempt=attempt,completedGroups=completed,
                allAttemptedOriginalRooms=list(map(str,new_roots))+list(map(str,rooms))+[str(out)],originalTraceback=traceback.format_exc(),postGlobalInventoriesQualified=False))
            raise
        completed.append(dict(group=group,input=row['input'],inputSha256=row['inputSha256'],supervisorReturnCode=result.returncode,
            originalTerminal=terminal,originalQualification=qualification,originalRoots=list(map(str,rooms))))
        new_roots+=list(rooms);put('completed-after-'+group+'.json',completed)
        print('ROOT_UTILITY_CLOSED '+group+' '+terminal['status'],flush=True)
        if result.returncode!=0 or terminal['status']!='PASS'or qualification['status']!='PASS':break
    first={str(p):census(p)for p in new_roots};second={str(p):census(p)for p in new_roots};assert first==second
    put('whole-output-first.json',first);put('whole-output-second.json',second)
    after1=current();after2=current();assert after1==after2==expected
    put('global-after-first.json',after1);put('global-after-second.json',after2)
    passed=len(completed)==1 and all(row['supervisorReturnCode']==0 and row['originalTerminal']['status']==row['originalQualification']['status']=='PASS'for row in completed)
    put('terminal.json',dict(status='ROOT_SINGLE_EMOTE_TERMINAL_KERNEL_UTILITY_COMPLETED'if passed else'ROOT_SINGLE_EMOTE_TERMINAL_KERNEL_UTILITY_STOPPED_ON_ORIGINAL_FAILURE',
        groups=completed,unrunGroups=[profile['group']for profile,row,plan,rooms in plans[len(completed):]],oldRootCount=974,
        allOldOriginalBodiesUnchanged=True,globalCensuses=3,wholeOwnOutputsTwiceEqual=True,allExecutedOwnedProcessesAbsent=True,
        newOriginalRoots=list(map(str,new_roots))+[str(out)],featureQualified=False,nativeQualified=False,wholeQualified=False))
    put('freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in sorted(out.iterdir())if p.is_file()}))
    print(json.dumps(dict(status='PASS'if passed else'FAIL',groups=len(completed),freeze=sha(out/'freeze.json'))),flush=True)
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
