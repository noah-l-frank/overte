"""Root metadata-only assembler. No target or product import is performed.

Invocation requires a later explicit quiet Root context and exact external
module manifest. Merely importing this module performs no work.
"""
from pathlib import Path
import argparse,hashlib,importlib.machinery,importlib.util,json,os,shutil,stat,sys

REPO=Path(__file__).resolve().parents[2]
CONTROLLER=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller10b-consistent-source-execution-rows-code-preparation-20261104'
CONTROLLER_SHA='297d441f42962ea8866b684a91cbae40f4d1b0121ef9c8e9037c02adae28d2e5'
PROPOSAL=REPO/'.ios-host-tmp/chat-offline-send-no-replay-source1-private-20261104'
PROPOSAL_SHA='b1df990cbb9187fe6982cafe0a9e4065283eb541c7f30860162afd624a390f9b'
HISTORICAL=REPO/'.ios-host-tmp/lifecycle-moving-primary-first1-root687-source4-controller6-final-preparation-20261104'
HISTORICAL_SHA='d0a91ab61a8e578fadc17c4fd9f9ecf17c81ccc2751fb617e5e29eac80f95516'
GLOBAL_HELPER_SHA='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
C6=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller6-no-site-startup-code-preparation-20261104'
C6_SHA='1a517b07d8c888d79cbfe86116def12a8d65b1f9a24f971bde4afa4b5caa4fea'
ASSEMBLER4=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller6-root-assembler4-no-site-code-only-20261104'
ASSEMBLER4_SHA='2b2d014abc83ed3a1f1bea32dd1f9dde32eb38c20b256c3c8fc0797b7ea62d33'
C6_PREP=REPO/'.ios-host-tmp/chat-offline-initial4-prepared-root693-head7c18-assembler4-20261104'
C6_PREP_SHA='cc48741c1b09b51820fd971857918b1614b5fa3dddbfbca9c64119bb5dd1aecd'
C6_PLAN_SHA='d2f00df902aa0071f3458950525129b73d46e52d527db69d94184c21297c10a6'
C6_FAILURE=REPO/'.ios-host-tmp/root-chat-offline-initial4-first-import-refusal-finalizer-source-read-refusal-results-20261104'
C6_FAILURE_SHA='4a7110f0aef1ed025525065f9997fb0f46c0ad1a1d73161ec959beebf5aaae6a'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def excluded(path):return any(p in('site-packages','dist-packages')for p in path.parts)
def hex40(value):return type(value)is str and len(value)==40 and all(c in'0123456789abcdef'for c in value)


def checked_packet(directory,leaf,expected,pin):
    directory=Path(directory);assert sha(directory/leaf)==expected
    rows={str(directory/leaf):pin(directory/leaf)}
    packet=load(directory/leaf)
    files=packet['files']
    items=((r['path'],r)for r in files)if type(files)is list else files.items()
    for name,row in items:
        path=directory/name
        assert path.resolve(strict=True)==path and path.is_relative_to(directory)
        digest=row if type(row)is str else row['sha256']
        assert sha(path)==digest
        rows[str(path)]=pin(path)
    return rows


def checked_c6_retention(pins, baseline, pin):
    # These are closed historical metadata and actual failures, never current
    # source authority or a successful four-case/Node/cleanup qualification.
    for directory,leaf,digest in (
        (C6,'source-freeze.json',C6_SHA),
        (ASSEMBLER4,'source-freeze.json',ASSEMBLER4_SHA),
        (C6_PREP,'freeze.json',C6_PREP_SHA),
        (C6_FAILURE,'freeze.json',C6_FAILURE_SHA)):
        pins.update(checked_packet(directory,leaf,digest,pin))
    assert sha(C6_PREP/'plan.json')==C6_PLAN_SHA
    previous_plan=load(C6_PREP/'plan.json')
    assert previous_plan['controllerSourceFreeze']==C6_SHA
    assert previous_plan['head']=='7c18ac7c24270419b3f8cc5fdd3bb24ef4ee70f9'
    old_custody=previous_plan['globalCustody']
    old_baseline=Path(old_custody['baselinePath'])
    assert old_baseline==C6_PREP/'global-original-corpus-baseline.json'
    assert sha(old_baseline)==old_custody['baselineSha256']
    historical=load(old_baseline)
    assert len(historical)==693  # Historical fact, never a later count cap.
    assert set(historical)<=set(baseline)and all(baseline[name]==rows for name,rows in historical.items())
    receipt=load(C6_FAILURE/'results.json')
    assert receipt['controllerFreeze']==C6_SHA and receipt['preparationFreeze']==C6_PREP_SHA
    assert receipt['planSha256']==C6_PLAN_SHA and receipt['actualStartedCases']==0 and receipt['actualPassedCases']==0
    assert receipt['actualGenuineTemporaryDirectories']==0 and receipt['terminal']['childReturnCode']==1
    assert receipt['actualOwnedProcessAbsenceEstablished']is True
    assert receipt['all693OldOriginalBodiesUnchanged']is True and receipt['allPhysicalPinsUnchanged']is True
    assert receipt['standardCleanupQualified']is False and receipt['all27PortsRestoredQualified']is False
    assert receipt['actualNodeBirthQualified']is False and receipt['positiveFourNodeAbsenceQualified']is False
    child=REPO/'.ios-host-tmp/chat-offline-own4-root693-head7c18-first-20261104'
    assert receipt['newOriginalRoots']==[str(child),str(child/'temporary'),str(child.with_name(child.name+'-outer'))]
    assert all(name in baseline for name in receipt['newOriginalRoots'])
    references=load(C6_FAILURE/'actual-receipt-references.json')
    for row in references.values():
        path=Path(row['path'])
        assert path.is_absolute()and path.resolve(strict=True)==path and sha(path)==row['sha256']
        assert path.is_relative_to(child)or path.is_relative_to(child.with_name(child.name+'-outer'))
        pins[str(path)]=pin(path)
    declared=load(CONTROLLER/'readonly-own-public-source-verification.json')
    assert set(declared['paths'])==set(receipt['metadataSourcePathFalsePositives'])
    for name,row in declared['paths'].items():
        assert row['sha256']==previous_plan['physicalPins'][name]['sha256']
    return historical



def checked_c7_retention(pins, baseline, pin):
    c7=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller7-absence-own-source-read-independent-drain-code-preparation-20261104'
    as5=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller7-root-assembler5-absence-own-source-read-failure-retention-code-only-20261104'
    prep=REPO/'.ios-host-tmp/chat-offline-initial4-prepared-root697-head7c18-assembler5-20261104'
    failed=REPO/'.ios-host-tmp/root-chat-offline-c7-first-body-pass-origin-accounting-refusal-clean-results-20261104'
    probe=REPO/'.ios-host-tmp/root-chat-fileless-stdlib-xml-probe-source1-20261104'
    for directory,leaf,digest in (
        (c7,'source-freeze.json','8d398997e15de8cb480f47a514026348c37ed12617c9b2b5deb5a17a2906a366'),
        (as5,'source-freeze.json','1871a458deb49296a8421923520555bca4f1f7074dc391ccad6145210919c2f5'),
        (prep,'freeze.json','2292276ddb3aff1922a57353243d8b969d1c1c9b9eb58188db842af4bf5345ad'),
        (failed,'freeze.json','0670b8fb97d686b49d4eae9f6745c4c88b0c909db3af413f27072a30a8027e25'),
        (probe,'freeze.json','c5d96a6606276955270560fbf1ad102ab09dc751c33843f480ed120d0a62d4e5')):
        pins.update(checked_packet(directory,leaf,digest,pin))
    previous=load(prep/'plan.json')
    assert sha(prep/'plan.json')=='7784897601db83c38eea739cec77e2c67b061277acaad4ac56b91f3b5ebdc137'
    assert previous['controllerSourceFreeze']=='8d398997e15de8cb480f47a514026348c37ed12617c9b2b5deb5a17a2906a366'
    historical=load(prep/'global-original-corpus-baseline.json')
    assert len(historical)==697  # Saved historical scope, not a current count cap.
    assert set(historical)<=set(baseline)and all(baseline[name]==rows for name,rows in historical.items())
    receipt=load(failed/'results.json')
    assert receipt['status']=='ACTUAL_CHAT_C7_FIRST_BODY_PASS_AFTER_CASE_FILELESS_MODULE_ORIGIN_REFUSAL_REMAINING3_UNRUN'
    assert receipt['actualStartedCases']==receipt['actualBodyPassedCases']==1
    assert receipt['actualQualifiedCases']==0 and receipt['remainingSelectedCasesUnrun']==3
    assert receipt['actualGenuineTemporaryDirectories']==3 and receipt['actualNodeBirths']==1
    assert receipt['actualNodeEndAndZeroSubscriptions']and receipt['actualNodeAbsent']and receipt['actualNodeStreamsClosed']
    assert receipt['all27PortsAndCioRestored']and not receipt['wholeFourStandardCleanupQualified']and not receipt['wholeQualified']
    assert receipt['all697OldOriginalBodiesUnchanged']and receipt['all8998PhysicalPinsUnchanged']
    assert receipt['terminal']['ownProcessesAbsent']and receipt['terminal']['childReturnCode']==1
    child=REPO/'.ios-host-tmp/chat-offline-own4-root697-head7c18-c7-first-20261104'
    assert receipt['newOriginalRoots']==[str(child),str(child/'temporary'),str(child.with_name(child.name+'-outer'))]
    assert all(name in baseline for name in receipt['newOriginalRoots'])
    for row in load(failed/'actual-receipt-references.json').values():
        path=Path(row['path']);assert path.resolve(strict=True)==path and sha(path)==row['sha256']
        assert path.is_relative_to(child)or path.is_relative_to(child.with_name(child.name+'-outer'))
        pins[str(path)]=pin(path)
    observed=load(probe/'results.json');terminal=load(probe/'terminal.json')
    assert terminal['newOriginalRoots']==[str(probe)]and str(probe)in baseline
    assert terminal['terminal']['ownProcessesAbsent']and terminal['terminal']['childReturnCode']==0
    assert observed['productImports']==observed['nodeExecutions']==observed['targets']==observed['globalCensuses']==0
    assert observed['sourceOfC7UnnamedFailureEstablished']is False
    assert [row['name']for row in observed['newFilelessSpecLessModules']]==['pyexpat.errors','pyexpat.model']
    assert all(row['ownerAttributeIdentity']for row in observed['newFilelessSpecLessModules'])
    parent=Path(observed['actualExtensionParent']);actual=pin(parent)
    assert actual==previous['physicalPins'][str(parent)]and actual['sha256']==observed['actualParentSha256']
    pins[str(parent)]=actual
    return historical



def checked_c8_retention(pins, baseline, pin):
    c8=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller8-genuine-expat-child-origins-code-preparation-20261104'
    as6=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller8-root-assembler6-expat-child-c7-retention-code-only-20261104'
    prep=REPO/'.ios-host-tmp/chat-offline-initial4-prepared-root701-head7c18-assembler6-20261104'
    failed=REPO/'.ios-host-tmp/root-chat-offline-c8-first-body-pass-expat-wrapper-alias-refusal-clean-results-20261104'
    probe=REPO/'.ios-host-tmp/root-chat-fileless-stdlib-expat-wrapper-probe-source2-20261104'
    for directory,leaf,digest in (
        (c8,'source-freeze.json','35f2ea03dc5b25a9c0493ec5215354b353c3f4274df30967c06456458c78f13b'),
        (as6,'source-freeze.json','658ae1bc9209e5101e768fc9dfb2a76aed659d6d0df950b1caf977b7596eb805'),
        (prep,'freeze.json','c8cfc9121275b5c1ad910268de016ab65a9ac42d4af83cee67d05bd534ffd156'),
        (failed,'freeze.json','829e152d5346fd5a37d71cd34fa8a6ea0562906be801554172ca04d798e2e96f'),
        (probe,'freeze.json','009034cca145412004d81e8ac65be747528d420c91815a703fe47c664ed13fb9')):
        pins.update(checked_packet(directory,leaf,digest,pin))
    previous=load(prep/'plan.json')
    assert sha(prep/'plan.json')=='a6b1349cfb2448dc6cf191c3f550b6f29c0121527731dd73e050a5c879638956'
    assert previous['controllerSourceFreeze']=='35f2ea03dc5b25a9c0493ec5215354b353c3f4274df30967c06456458c78f13b'
    historical=load(prep/'global-original-corpus-baseline.json')
    assert len(historical)==701  # Historical scope, never a later Root count cap.
    assert set(historical)<=set(baseline)and all(baseline[name]==rows for name,rows in historical.items())
    receipt=load(failed/'results.json')
    assert receipt['status']=='ACTUAL_CHAT_C8_FIRST_BODY_PASS_AFTER_CASE_EXACT_EXPAT_WRAPPER_ALIAS_REFUSAL_REMAINING3_UNRUN'
    assert receipt['actualStartedCases']==receipt['actualBodyPassedCases']==1
    assert receipt['actualQualifiedCases']==0 and receipt['remainingSelectedCasesUnrun']==3
    assert receipt['actualGenuineTemporaryDirectories']==3 and receipt['actualNodeBirths']==1
    assert receipt['actualNodeEndAndZeroSubscriptions']and receipt['actualNodeAbsent']and receipt['actualNodeStreamsClosed']
    assert receipt['all27PortsAndCioRestored']and not receipt['wholeFourStandardCleanupQualified']and not receipt['wholeQualified']
    assert receipt['all701OldOriginalBodiesUnchanged']and receipt['all9102PhysicalPinsUnchanged']
    assert receipt['actualFailedFilelessModuleName']=='xml.parsers.expat.model'
    assert receipt['terminal']['ownProcessesAbsent']and receipt['terminal']['childReturnCode']==1
    child=REPO/'.ios-host-tmp/chat-offline-own4-root701-head7c18-c8-first-20261104'
    assert receipt['newOriginalRoots']==[str(child),str(child/'temporary'),str(child.with_name(child.name+'-outer'))]
    assert all(name in baseline for name in receipt['newOriginalRoots'])
    for row in load(failed/'actual-receipt-references.json').values():
        path=Path(row['path']);assert path.resolve(strict=True)==path and sha(path)==row['sha256']
        assert path.is_relative_to(child)or path.is_relative_to(child.with_name(child.name+'-outer'))
        pins[str(path)]=pin(path)
    observed=load(probe/'results.json');terminal=load(probe/'terminal.json')
    assert terminal['newOriginalRoots']==[str(probe)]and str(probe)in baseline
    assert terminal['terminal']['ownProcessesAbsent']and terminal['terminal']['childReturnCode']==0
    assert observed['productImports']==observed['nodeExecutions']==observed['targets']==observed['globalCensuses']==0
    assert observed['sourceOfC7UnnamedFailureEstablished']is False
    assert observed['aliasesAreTheSameOriginalChildReceivers']and observed['originalC8FailedNameIsActualWrapperAlias']
    assert [row['name']for row in observed['newFilelessSpecLessModules']]==['pyexpat.errors','pyexpat.model','xml.parsers.expat.errors','xml.parsers.expat.model']
    assert all(row['ownerAttributeIdentity']and row['wrapperAttributeIdentity']for row in observed['newFilelessSpecLessModules'])
    for path_key,sha_key in(('actualExtensionParent','actualParentSha256'),('actualPythonWrapper','actualWrapperSha256')):
        path=Path(observed[path_key]);actual=pin(path)
        assert actual==previous['physicalPins'][str(path)]and actual['sha256']==observed[sha_key]
        pins[str(path)]=actual
    return historical



def checked_c9_retention(pins, baseline, pin):
    c9=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller9-genuine-expat-wrapper-aliases-code-preparation-20261104'
    as7=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller9-root-assembler7-expat-wrapper-c8-retention-code-only-20261104'
    prep=REPO/'.ios-host-tmp/chat-offline-initial4-prepared-root705-head7c18-assembler7-20261104'
    actual=REPO/'.ios-host-tmp/root-chat-offline-c9-four-declared-gates-pass-source-cache-execution-limit-results-20261104'
    for directory,leaf,digest in (
        (c9,'source-freeze.json','5d3c7973df44c8f8026ac10e14d4453965b9a602b50550339bb0cd5a79d916a2'),
        (as7,'source-freeze.json','0eeb08f49c311545868b08aa513c46e4d6e8f6b378b684cd68f538f3dca15f7d'),
        (prep,'freeze.json','c6f118b0c4e4f0dde4630289c4dd2c020267407ae8ea1b67e82e6c3df59ebe6a'),
        (actual,'freeze.json','d76f16861adb509a6ae9d44891a53cdc3e08c3a6566e07e9767d9fcd9b2f8c27')):
        pins.update(checked_packet(directory,leaf,digest,pin))
    previous=load(prep/'plan.json')
    assert sha(prep/'plan.json')=='b828b632d99b1005f733df04dcd7cfa1388274c21d93c72044e019ed07715fb1'
    assert previous['controllerSourceFreeze']=='5d3c7973df44c8f8026ac10e14d4453965b9a602b50550339bb0cd5a79d916a2'
    historical=load(prep/'global-original-corpus-baseline.json')
    assert len(historical)==705  # Saved historical scope, not a later count cap.
    assert set(historical)<=set(baseline)and all(baseline[name]==rows for name,rows in historical.items())
    receipt=load(actual/'results.json');limit=load(actual/'source-execution-limitation.json')
    assert receipt['status']=='ACTUAL_CHAT_C9_ORIGINAL4_PASS_ALL_DECLARED_RESOURCE_ORIGIN_GATES_SOURCE_CACHE_EXECUTION_LIMIT_RECORDED'
    assert receipt['actualStartedCases']==receipt['actualBodyPassedCases']==receipt['actualDeclaredControllerGatesPassedCases']==4
    assert receipt['actualFullSourceExecutionQualifiedCases']==0 and receipt['sourceBytesToActuallyExecutedPythonCodeEstablished']is False
    assert receipt['remainingInitialSelectedCasesUnrun']==0 and receipt['otherSource1TenCasesUnrun']
    assert receipt['actualGenuineTemporaryDirectories']==12 and receipt['actualNodeBirths']==4
    assert receipt['actualAllNodeEndZeroSubscriptionsStreamCloseAbsence']and receipt['all27PortsAndCioRestored']
    assert receipt['actualRegisteredStandardCleanupsDrained']and receipt['independentNestedCallbackExecutionCountRecorded']is False
    assert receipt['actualLoadedOriginSnapshots']==7 and not receipt['wholeQualified']and not receipt['nativeQualified']
    assert receipt['all705OldOriginalBodiesUnchanged']and receipt['all9208PhysicalPinsUnchanged']
    assert receipt['terminal']['ownProcessesAbsent']and receipt['terminal']['childReturnCode']==0
    assert receipt['outerTerminal']['status']=='PASS'and not receipt['terminal']['problems']
    assert limit['sourceBytesToActuallyExecutedPythonCodeEstablished']is False and limit['actualCacheTamperingObserved']is False
    assert limit['pythonNoBytecodeWriteDoesNotDisableCacheReads']
    std=Path(limit['actualStdlibGetCodeSource']);current=pin(std)
    assert current==previous['physicalPins'][str(std)]and current['sha256']==limit['actualStdlibSourceSha256']
    pins[str(std)]=current
    child=REPO/'.ios-host-tmp/chat-offline-own4-root705-head7c18-c9-first-20261104'
    assert receipt['newOriginalRoots']==[str(child),str(child/'temporary'),str(child.with_name(child.name+'-outer'))]
    assert all(name in baseline for name in receipt['newOriginalRoots'])
    for row in load(actual/'actual-receipt-references.json').values():
        path=Path(row['path']);assert path.resolve(strict=True)==path and sha(path)==row['sha256']
        assert path.is_relative_to(child)or path.is_relative_to(child.with_name(child.name+'-outer'))
        pins[str(path)]=pin(path)
    return historical


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head',required=True)
    parser.add_argument('--assembler-source-sha256',required=True)
    parser.add_argument('--root-context',type=Path,required=True)
    parser.add_argument('--root-context-sha256',required=True)
    parser.add_argument('--external-manifest',type=Path,required=True)
    parser.add_argument('--external-manifest-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert sys.dont_write_bytecode and Path.cwd()==REPO and hex40(args.expected_head)
    assert sys.flags.no_site == 1, "Explicit no-site interpreter startup required"
    assembler=Path(__file__).resolve().parent
    assert sha(assembler/'source-freeze.json')==args.assembler_source_sha256
    for name,row in load(assembler/'source-freeze.json')['files'].items():assert sha(assembler/name)==row['sha256']
    # Only independently hashed stdlib-only controller definitions are loaded.
    assert sha(CONTROLLER/'source-freeze.json')==CONTROLLER_SHA
    for name,row in load(CONTROLLER/'source-freeze.json')['files'].items():assert sha(CONTROLLER/name)==row['sha256']
    spec=importlib.util.spec_from_file_location('chat_offline_metadata_assembler',CONTROLLER/'metadata.py')
    M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
    assert M.head()==args.expected_head
    pins=checked_packet(CONTROLLER,'source-freeze.json',CONTROLLER_SHA,M.pin)
    pins.update(checked_packet(assembler,'source-freeze.json',args.assembler_source_sha256,M.pin))
    pins.update(checked_packet(PROPOSAL,'freeze.json',PROPOSAL_SHA,M.pin))
    # Historical metadata remains exact; its old public pin values are DATA,
    # not instructions to relabel old public files as the current runtime.
    pins.update(checked_packet(HISTORICAL,'freeze.json',HISTORICAL_SHA,M.pin))
    for directory,expected in(
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller1-code-preparation-20261104','4eb83643183a1953db3c1f7f2e7b093c1841b9ed5f2acb73883a314f9692aa0c'),
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller2-strict-origins-code-preparation-20261104','a846c7039b33fae0dc427d9cdbbe19e26e72a6a6a0d9f83c0496d1e431c534e3'),
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller3-package-spec-input-pin-code-preparation-20261104','f7e427301cded1b35ba46722f4194781399aca59baa8e2d576a637f4770d14e6'),
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller4-current-head-initial-module-custody-code-preparation-20261104','057ef27ebd51c0507ba1cc1fdd68cda76c5751472e5acb720120b4c410027fe4'),
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller5-exact-readonly-stdlib-source-links-code-preparation-20261104','61c14acd1997272f039fa28c74c39fe9760f7f3ec9e8cf649d13cddd2028a510')):
        pins.update(checked_packet(directory,'source-freeze.json',expected,M.pin))
    for path,expected in((args.root_context,args.root_context_sha256),(args.external_manifest,args.external_manifest_sha256)):
        assert path.is_absolute()and path.resolve(strict=True)==path and sha(path)==expected
        pins[str(path)]=M.pin(path)
    context=load(args.root_context);external=load(args.external_manifest)
    assert context['status']=='ROOT_REVIEWED_QUIET_CURRENT_SOURCE_AND_ORIGINAL_CONTEXT'
    assert context['expectedHead']==args.expected_head and context['allTargetsTerminal']is True
    assert external['status']=='ROOT_REVIEWED_EXACT_EXTERNAL_MODULE_FRONTIER'
    assert set(external)=={'status','modules','namespaces','physicalFiles'}
    custody=context['globalCustody']
    for key in('helper','seed','baseline'):
        row=custody[key];path=Path(row['path'])
        assert path.is_absolute()and path.resolve(strict=True)==path and sha(path)==row['sha256']
        pins[str(path)]=M.pin(path)
    assert custody['helper']['sha256']==GLOBAL_HELPER_SHA
    assert Path(custody['seed']['path'])==Path(custody['helper']['path']).with_name('global-original-roots-seed.json')
    baseline=load(custody['baseline']['path']);seed=load(custody['seed']['path'])
    assert set(baseline)==set(seed['roots'])
    old=load(HISTORICAL/'global-original-corpus-baseline.json')
    assert set(old)<=set(baseline)and all(baseline[name]==rows for name,rows in old.items())
    previous_c6_baseline=checked_c6_retention(pins,baseline,M.pin)
    previous_c7_baseline=checked_c7_retention(pins,baseline,M.pin)
    previous_c8_baseline=checked_c8_retention(pins,baseline,M.pin)
    previous_c9_baseline=checked_c9_retention(pins,baseline,M.pin)
    # Root explicitly supplies every later terminal proof and the full output
    # roots, not an inferred current count or a writer exclusion.
    assert type(context['terminalAdditions'])is list
    for addition in context['terminalAdditions']:
        for name in addition['roots']:assert name in baseline
        packet=Path(addition['packet'])
        pins.update(checked_packet(packet,addition['freezeFile'],addition['freezeSha256'],M.pin))
    for row in context['additionalPhysicalProofs']:
        path=Path(row['path']);assert sha(path)==row['sha256'];pins[str(path)]=M.pin(path)
    output=args.output
    assert output.is_absolute()and output.resolve(strict=False)==output and output.parent==REPO/'.ios-host-tmp'
    assert output.name.startswith('chat-offline-initial4-prepared-')and not output.exists()
    assert output not in(CONTROLLER,PROPOSAL,HISTORICAL)
    # Every project alias is constructed from current public .py files. The
    # exact Source1 five rows are the only possible private module overlays.
    modules={};namespaces={};public_paths=set();ambiguous_aliases={}
    public_roots=[Path(value)for value in load(HISTORICAL/'public-source-namespace.json')['roots']]
    for root in public_roots:
        assert root.is_relative_to(REPO)and not root.is_relative_to(REPO/'.ios-host-tmp')
        for path in(root,*sorted(root.rglob('*'))):
            assert path.resolve(strict=True)==path and not path.is_symlink()
            public_paths.add(str(path))
            if path.is_file():pins[str(path)]=M.pin(path)
    # Ordered aliases are independently declared. A different physical file
    # with the same alias refuses; no silent PathFinder-precedence adoption.
    for root in(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests'):
        for path in sorted(root.rglob('*.py')):
            parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
            if package:parts.pop()
            if not parts:continue
            name='.'.join(parts);row=dict(path=str(path),sha256=sha(path),package=package)
            if name in ambiguous_aliases:
                if row not in ambiguous_aliases[name]:ambiguous_aliases[name].append(row)
            elif name in modules and modules[name]!=row:
                ambiguous_aliases[name]=[modules.pop(name),row]
            else:modules[name]=row
            for depth in range(1,len(parts)):
                prefix='.'.join(parts[:depth]);directory=root.joinpath(*parts[:depth])
                if not(directory/'__init__.py').is_file():
                    values=namespaces.setdefault(prefix,[])
                    if str(directory)not in values:values.append(str(directory))
    # These two actual bare aliases have different public files. Neither
    # receives import authority; both canonical qualified names remain real.
    assert set(ambiguous_aliases)=={'test_appium_adapter','test_voice_roundtrip'}
    assert not set(ambiguous_aliases).intersection(sys.stdlib_module_names)
    for name,choices in ambiguous_aliases.items():
        assert name not in modules and len(choices)==2
        assert modules['self_tests.'+name]in choices
        assert modules['ios.self_tests.'+name]in choices
    for name in modules:namespaces.pop(name,None)
    deps=load(PROPOSAL/'DEPENDENCIES.json')
    for row in deps['publicPhysicalDependencies']:
        assert sha(row['path'])==row['sha256'];pins[row['path']]=M.pin(row['path'])
    assert len(deps['overlays'])==5
    for row in deps['overlays']:
        assert sha(row['path'])==row['sha256']
        modules[row['module']]=dict(path=row['path'],sha256=row['sha256'],package=False)
        pins[row['path']]=M.pin(row['path'])
    # Actual stdlib's entire source/extension frontier is pinned BEFORE imports,
    # including initially loaded frozen-source representations. No site root.
    std=Path(vars(os)['__file__']).resolve(strict=True).parent
    assert std.is_dir()and not excluded(std)
    extensions=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    std_namespaces={}
    for current,dirs,names in os.walk(std,topdown=True,followlinks=False):
        directory=Path(current)
        # Prune excluded installation trees BEFORE descending. No installed
        # SDK/package tree is enumerated as a guessed stdlib allowance.
        dirs[:]=sorted(name for name in dirs if name not in('site-packages','dist-packages','__pycache__')
            and not(directory/name).is_symlink())
        relative=directory.relative_to(std)
        if relative.parts and all(part.isidentifier()for part in relative.parts)and not(directory/'__init__.py').is_file():
            std_namespaces['.'.join(relative.parts)]=[str(directory)]
        for name in sorted(names):
            path=directory/name
            if path.suffix!='.py'and not any(str(path).endswith(suffix)for suffix in extensions):continue
            real=path.resolve(strict=True)
            if excluded(real)or not real.is_relative_to(std):continue
            assert real.is_file();pins[str(real)]=M.pin(real)
    python=Path(sys.executable).resolve(strict=True);pins[str(python)]=M.pin(python)
    for name,module in tuple(sys.modules.items()):
        if module is None:continue
        file=vars(module).get('__file__')
        if file is None:continue
        path=Path(file).resolve(strict=True)
        if path.is_relative_to(std)and not excluded(path):pins[str(path)]=M.pin(path)
        elif path.parent in(Path(__file__).resolve().parent,CONTROLLER):pins[str(path)]=M.pin(path)
        else:assert name in external['modules']and external['modules'][name]['path']==str(path),'Unaccounted metadata bootstrap module: '+name
    for path,row in external['physicalFiles'].items():
        assert Path(path).is_absolute()and Path(path).resolve(strict=True)==Path(path)
        assert M.pin(path)==row;pins[path]=row
    for name,row in external['modules'].items():
        assert set(row)=={'path','sha256','package','loader'}and row['loader']in('source','extension')
        assert name not in modules and row['path']in pins and pins[row['path']]['sha256']==row['sha256']
        assert not Path(row['path']).is_relative_to(REPO)
    node=Path(shutil.which('node')).resolve(strict=True);pins[str(node)]=M.pin(node)
    script=REPO/'tests/device/ios/self_tests/chat_message_script_domain.js';model=script.with_suffix('.py')
    pins[str(script)]=M.pin(script);pins[str(model)]=M.pin(model)
    # No temporary/runs/raw room is born; only a new metadata destination.
    output.mkdir(mode=0o700)
    def save(name,value):
        path=output/name
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
        return path
    for key,name in(('helper','global_original_corpus.py'),('seed','global-original-roots-seed.json'),('baseline','global-original-corpus-baseline.json')):
        original=Path(custody[key]['path']);target=output/name
        with original.open('rb')as incoming,target.open('xb')as outgoing:shutil.copyfileobj(incoming,outgoing)
        target.chmod(0o600);assert sha(target)==custody[key]['sha256'];pins[str(target)]=M.pin(target)
    public=save('public-source-namespace.json',dict(roots=[str(r)for r in public_roots],paths=sorted(public_paths)));pins[str(public)]=M.pin(public)
    aliases=save('absolute-module-origins.json',dict(modules=modules,namespaces=namespaces,thirdPartyModules=external['modules'],thirdPartyNamespacePackages=external['namespaces']));pins[str(aliases)]=M.pin(aliases)
    unadmitted=save('unadmitted-public-aliases.json',dict(status='NO_BARE_ALIAS_AUTHORITY_GRANTED',aliases=ambiguous_aliases))
    pins[str(unadmitted)]=M.pin(unadmitted)
    plan=dict(status='ROOT_REVIEWED_PREPARED_UNRUN',head=args.expected_head,controllerSourceFreeze=CONTROLLER_SHA,
        currentHeadAdmission=dict(exactRootExpectedHead=args.expected_head,historicalControllerHead='06ff22857d8c8298390e00cd5df1c848a1d9c6a5',historicalManifestsPreserved=True),
        unadmittedPublicAliases=dict(path=str(unadmitted),sha256=sha(unadmitted),names=sorted(ambiguous_aliases)),
        proposalFreeze=PROPOSAL_SHA,cases=load(PROPOSAL/'INITIAL-SELECTION.json')['ids'],seconds=180,graceSeconds=5,
        maxNodePerCase=1,maxLiveNodes=1,maxTotalNodes=4,TDsPerExecutedCase=3,loopbacksAllowed=False,
        source15Or17Adopted=False,wholeQualified=False,physicalPins=pins,modules=modules,namespacePackages=namespaces,
        thirdPartyModules=external['modules'],thirdPartyNamespacePackages=external['namespaces'],stdlibNamespacePackages=std_namespaces,
        stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=pins[str(python)]),
        publicNamespace=dict(path=str(public),sha256=sha(public)),
        node=dict(path=str(node),pin=pins[str(node)]),nodeScript=dict(path=str(script),pin=pins[str(script)]),nodeModel=dict(path=str(model),pin=pins[str(model)]),
        globalCustody=dict(helperPath=str(output/'global_original_corpus.py'),seedPath=str(output/'global-original-roots-seed.json'),
            seedSha256=sha(output/'global-original-roots-seed.json'),baselinePath=str(output/'global-original-corpus-baseline.json'),baselineSha256=sha(output/'global-original-corpus-baseline.json')))
    prepared=save('plan.json',plan);plan_sha=sha(prepared)
    M.validate(prepared,plan_sha,CONTROLLER_SHA,args.expected_head)
    assert M.head()==args.expected_head
    for path,row in pins.items():assert M.pin(path)==row
    summary=save('preparation-summary.json',dict(status='UNRUN_REQUIRES_ROOT_FINAL_REVIEW_AND_SEPARATE_TARGET_WINDOW',head=args.expected_head,controllerSourceFreeze=CONTROLLER_SHA,
        planPath=str(prepared),planSha256=plan_sha,physicalPins=len(pins),projectModules=len(modules),projectNamespaces=len(namespaces),
        externalModules=len(external['modules']),oldRootNamespaces=len(baseline),allReviewedHistoricalBaselineBodiesPreserved=True,historicalBaselineRootCount=len(old),completeC6HistoricalBaselineRootCount=len(previous_c6_baseline),
        actualFailedC6RetainedWithoutQualification=True,actualFailedC7RetainedWithoutQualification=True,actualFailedC8RetainedWithoutQualification=True,completeC7HistoricalBaselineRootCount=len(previous_c7_baseline),completeC8HistoricalBaselineRootCount=len(previous_c8_baseline),completeC9HistoricalBaselineRootCount=len(previous_c9_baseline),actualC9DeclaredPassRetainedWithSourceExecutionLimit=True,sourceExecutionCounterQualified=False,rootCountIsNotExecutionCap=True,
        noProductImports=True,noTarget=True,noGlobalCensus=True,noRawRootBorn=True,nativeQualified=False,wholeQualified=False))
    frozen={}
    for path in sorted(output.iterdir()):
        assert path.is_file()and not path.is_symlink();frozen[path.name]=dict(bytes=path.stat().st_size,sha256=sha(path))
    freeze=save('freeze.json',dict(status='FROZEN_PREPARED_UNRUN_REQUIRES_ROOT_REVIEW',files=frozen))
    print(json.dumps(dict(freeze=str(freeze),freezeSha256=sha(freeze),plan=str(prepared),planSha256=plan_sha,controllerSourceFreeze=CONTROLLER_SHA),indent=2))
    return 0


if __name__=='__main__':raise SystemExit(main())
