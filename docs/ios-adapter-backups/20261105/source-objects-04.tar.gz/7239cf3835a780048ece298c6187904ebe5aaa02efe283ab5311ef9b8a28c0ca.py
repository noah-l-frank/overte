"""Bounded Audio11 raw replies in independently named immutable index segments.

The standard OriginalFrameStore1024-frame limit remains literal per segment.
Global references select their deterministic segment; no native source, frame
clock or current observation is cached by this storage facade.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib
from adapters.native_feature_observation import exact,need
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import canonical,same

class AudioWholeJournal:
    MAX_REFS=8192
    def __init__(self,owner,role,guard,save):
        self.owner,self.guard,self.save_owner,self.role=owner,guard,save,role
        self.refs=[];self.pending=None;self.manifests=[];self.codecs={}
    def codec(self,segment):
        need(type(segment) is int and 0<=segment<8)
        if segment not in self.codecs:
            namespace='ios-audio11-current-raw'+('' if segment==0 else '-s'+str(segment))
            self.codecs[segment]=OriginalFrameStore(self.owner.store.path.parent,self.owner.binding,self.owner.run,self.role,self.guard,self.intent,namespace=namespace,schema_prefix='iosAudio11CurrentRaw',kind='inputs',monotonic=self.owner.monotonic)
        return self.codecs[segment]
    @property
    def store(self):return self.codec(self.pending['segment'] if self.pending is not None else min(len(self.refs)//1024,7))
    def local(self,ref):
        need(type(ref['index']) is int and 1<=ref['index']<=self.MAX_REFS)
        segment=(ref['index']-1)//1024;return self.codec(segment),dict(ref,index=(ref['index']-1)%1024+1)
    def manifest(self):return dict(revision=len(self.refs),manifests=deepcopy(self.manifests),pending=deepcopy(self.pending))
    def load(self,value):
        exact(value,{'revision','manifests','pending'});need(type(value['revision']) is int and 0<=value['revision']<=self.MAX_REFS)
        self.manifests=deepcopy(value['manifests']);self.pending=deepcopy(value['pending']);self.refs=[]
        need(type(self.manifests) is list and len(self.manifests)<=8)
        for segment,row in enumerate(self.manifests):
            exact(row,{'segment','entries'});need(type(row['segment']) is int and row['segment']==segment)
            codec=self.codec(segment);local=[]
            for block,manifest in enumerate(row['entries'],1):
                need(manifest['block']==block);local.extend(codec.manifest(manifest))
            need(len(local)==1024 if segment<len(self.manifests)-1 else 0<len(local)<=1024)
            self.refs.extend(dict(ref,index=segment*1024+ref['index']) for ref in local)
        need(len(self.refs)==value['revision'])
        for ref in self.refs:self.read_record(ref)
        if self.pending is not None:
            exact(self.pending,{'queryId','segment','original','manifest'})
            need(self.pending['segment']==len(self.refs)//1024)
            if self.pending['original'] is not None:self.store.original(self.pending['original'])
    def read_record(self,ref):
        codec,local=self.local(ref);value=codec.read(codec.expand(local));exact(value,{'iosAudio11RawReplyVersion','kind','query','raw'})
        need(type(value['iosAudio11RawReplyVersion']) is int and value['iosAudio11RawReplyVersion']==1 and value['kind']=='native' and type(value['raw']) is str and 0<len(value['raw'].encode())<=262144)
        return value
    def intent(self,event,value):
        need(self.pending is not None)
        if event=='original':self.pending['original']=deepcopy(value)
        else:need(event=='manifest');self.pending['manifest']=deepcopy(value)
        self.save_owner();return True
    def capture(self,query,raw):
        need(self.pending is None and type(raw) is str and 0<len(raw.encode())<=262144 and len(self.refs)<self.MAX_REFS)
        segment=len(self.refs)//1024;self.pending=dict(queryId=query['commandId'],segment=segment,original=None,manifest=None);self.save_owner()
        self.store.write(len(self.refs)%1024+1,dict(iosAudio11RawReplyVersion=1,kind='native',query=deepcopy(query),raw=raw))
    def accept_capture(self):
        need(self.pending is not None);wire=self.pending['original'];need(wire is not None and wire['phase'] in ('opened','saved'))
        codec=self.store;local=codec.compact(dict(wire,phase='saved'));segment=self.pending['segment'];ref=dict(local,index=segment*1024+local['index'])
        value=self.read_record(ref);need(value['query']['commandId']==self.pending['queryId'])
        current=self.manifests[segment]['entries'] if segment<len(self.manifests) else []
        target=self.pending['manifest']
        if target is not None and codec.manifest_path(target['reference']).exists():
            rows=codec.manifest(target['reference']);need(rows[-1]==local)
            prior=[] if local['index']%128==1 else codec.manifest(current[-1]);need(rows==prior+[local])
            manifests=deepcopy(current)
            if local['index']%128!=1:manifests.pop()
            manifests.append(target['reference'])
        else:manifests=codec.append(current,local)
        if segment==len(self.manifests):self.manifests.append(dict(segment=segment,entries=manifests))
        else:self.manifests[segment]['entries']=manifests
        self.refs.append(ref);self.pending=None;return value
    def owned_paths(self):
        paths=set()
        for segment,row in enumerate(self.manifests):
            codec=self.codec(segment)
            for manifest in row['entries']:
                rows=codec.manifest(manifest)
                for ref in rows:paths.add(codec.path(codec.expand(ref)))
                for count in range(1,len(rows)+1):
                    body={codec.key('ManifestVersion'):1,'kind':'inputs','binding':self.owner.binding,'runId':self.owner.run,'role':self.role,'block':manifest['block'],'entries':rows[:count]};raw=canonical(body)
                    ref=dict(block=manifest['block'],count=count,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw));codec.manifest(ref);paths.add(codec.manifest_path(ref))
        if self.pending is not None:
            if self.pending['original'] is not None and self.pending['original']['phase']!='planned':paths.add(self.store.path(self.pending['original']))
            if self.pending['manifest'] is not None and self.store.manifest_path(self.pending['manifest']['reference']).exists():paths.add(self.store.manifest_path(self.pending['manifest']['reference']))
        return paths
