"""Lossless diagnostic-only typed journal tree; no clock or journal read."""
import json,struct

VERSION=1

def encode_actual_journal(value):
    active=set()
    def node(item):
        kind=type(item)
        if item is None:return dict(type='none')
        if kind is bool:return dict(type='bool',value=item)
        if kind is int:return dict(type='int',value=item)
        if kind is float:return dict(type='float64',ieee754be=struct.pack('>d',item).hex())
        if kind is str:return dict(type='str',value=item)
        if kind is bytes:return dict(type='bytes',hex=item.hex())
        if kind not in(dict,list,tuple,set,frozenset):raise TypeError('Unsupported exact journal value type: '+kind.__name__)
        identity=id(item)
        if identity in active:raise TypeError('Cyclic actual journal diagnostic')
        active.add(identity)
        try:
            if kind is dict:return dict(type='dict',items=[[node(key),node(value)]for key,value in item.items()])
            values=[node(value)for value in item]
            if kind in(set,frozenset):values.sort(key=lambda value:json.dumps(value,sort_keys=True,separators=(',',':')))
            return dict(type={list:'list',tuple:'tuple',set:'set',frozenset:'frozenset'}[kind],items=values)
        finally:active.remove(identity)
    return dict(publisherActualJournalEncodingVersion=VERSION,root=node(value))


def decode_actual_journal(packet):
    if type(packet)is not dict or set(packet)!={'publisherActualJournalEncodingVersion','root'}or type(packet['publisherActualJournalEncodingVersion'])is not int or packet['publisherActualJournalEncodingVersion']!=VERSION:
        raise ValueError('Unknown actual-journal diagnostic grammar')
    def node(item):
        if type(item)is not dict or type(item.get('type'))is not str:raise ValueError('Invalid journal node')
        kind=item['type']
        if kind=='none':
            if set(item)!={'type'}:raise ValueError('Invalid none node')
            return None
        if kind in('bool','int','str'):
            expected={'bool':bool,'int':int,'str':str}[kind]
            if set(item)!={'type','value'}or type(item['value'])is not expected:raise ValueError('Invalid exact primitive type')
            return item['value']
        if kind=='float64':
            if set(item)!={'type','ieee754be'}or type(item['ieee754be'])is not str:raise ValueError('Invalid float node')
            raw=bytes.fromhex(item['ieee754be'])
            if len(raw)!=8:raise ValueError('Invalid float width')
            return struct.unpack('>d',raw)[0]
        if kind=='bytes':
            if set(item)!={'type','hex'}or type(item['hex'])is not str:raise ValueError('Invalid bytes node')
            return bytes.fromhex(item['hex'])
        if set(item)!={'type','items'}or type(item['items'])is not list:raise ValueError('Invalid journal container')
        if kind=='dict':
            result={}
            for pair in item['items']:
                if type(pair)is not list or len(pair)!=2:raise ValueError('Invalid actual dictionary item')
                key=node(pair[0]);value=node(pair[1])
                if key in result:raise ValueError('Repeated dictionary key')
                result[key]=value
            return result
        values=[node(value)for value in item['items']]
        if kind=='list':return values
        if kind=='tuple':return tuple(values)
        if kind in('set','frozenset'):
            result=set(values)
            if len(result)!=len(values):raise ValueError('Repeated set member')
            return result if kind=='set'else frozenset(result)
        raise ValueError('Unsupported journal node')
    return node(packet['root'])
