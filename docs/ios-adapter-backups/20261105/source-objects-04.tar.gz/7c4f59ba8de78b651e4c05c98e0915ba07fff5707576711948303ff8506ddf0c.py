"""Read every retained Assets episode before the one global local end.

The original SDK roots stay canonical. Each individual upload/picker namespace
has its own typed originals and held source lock. No episode's closure becomes
whole closure, and every server baseline must be restored before any Stop.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import need
from adapters.original_file_reads import collect as read_scope
from adapters.script_feature.history import same
from ios.adapters.assets_end_graph import AssetsOwnership,HELD
from ios.adapters.assets_end_metadata import RecordingAssetsMetadata
from ios.adapters.assets_episodes import AssetsEpisodes,PLAN
from ios.adapters.assets_image_ownership import ImageInventoryContext
from ios.adapters.assets_parsed_owner import OwnedAssetsParsedInput
from ios.adapters.assets_session_owners import inspect_directory
from ios.adapters.emote_original_lease import EmoteOriginalLease


class AllEpisodesAssetsOwnership(AssetsOwnership):
    def __init__(self,chosen,copies,locks,selected,episodes):
        need(type(episodes) is AssetsEpisodes and episodes.selected is selected)
        episodes.guard();need(len(episodes.state['entries'])==len(PLAN)
            and all(row['phase']=='ready' for row in episodes.state['entries']))
        self.episodes=episodes;super().__init__(chosen,copies,locks,selected)
        need(same(episodes.context,self.context))
        for index in range(1,len(PLAN)+1):
            for lock in episodes.scope(index).locks.values():lock.assert_held()

    @property
    def roots(self):
        result=super().roots
        for index in range(1,len(PLAN)+1):
            scope=self.episodes.scope(index)
            for info in scope.descriptor['directories'].values():
                for row in info.values():result.add(Path(row['path']))
        return result

    def _read(self,view):
        self.episodes.guard()
        for lock in self.locks.values():lock.assert_held()
        leases=[EmoteOriginalLease(root,[]) for root in self.roots];reports={}
        previous=getattr(view,'episode',None)
        try:
            for index,(kind,resource) in enumerate(PLAN,1):
                scope=self.episodes.scope(index);scope.guard();view.episode=scope
                need(scope.descriptor['kind']==kind and scope.descriptor['resource']==resource)
                directories={role:Path(scope.descriptor['directories'][role]['stateRoot']['path']) for role in ('primary','actor')}
                for lock in scope.locks.values():lock.assert_held()
                primary=self.context['roles']['primary'];contexts={}
                image=None
                if kind=='upload' and resource in ('gltf-bundle/main.gltf','asset-stand.fbx'):
                    image=ImageInventoryContext(scope.artifact_root(primary['target']),deepcopy(primary['binding']),
                        self.run,scope.descriptor['ticket'],scope.locks['primary'])
                images={} if image is None else {directories['primary']:image}
                rows=inspect_directory(directories['primary'],_contexts=contexts,image_context=image,metadata=view,image_contexts=images)
                need(rows and all(row['runId']==self.run and same(row['binding'],primary['binding']) for row in rows)
                    and all(set(row['responsibilities'])<=HELD for row in rows))
                current=contexts.get((self.run,'primary'));need(current is not None)
                files=current['files'];file_copy=None if files is None else view.store(files.store.path).read()
                need(files is not None and files.storage_version==4 and files.state['phase']=='retired'
                    and files.state['ticket']==scope.descriptor['ticket'] and files.state['resource']==resource
                    and same(file_copy['selectedPair'],self.selected.link()) and same(file_copy['episode'],scope.link()))
                if kind=='picker':
                    # A never-uploaded picker has no server/Model duty, but its
                    # actual file/UI owners must exist and be retired. Empty
                    # metadata is not a cancellation or vanished-file proof.
                    need(current['picker'] is not None and current['picker'].state['phase']=='retired'
                        and current['upload'] is None and current['backend'] is None and current['parsed'] is None
                        and not any(row['responsibilities'] for row in rows))
                    actor=inspect_directory(directories['actor'],metadata=view)
                    need(actor==[])
                else:
                    parsed=current['parsed'];backend=current['backend'];upload=current['upload'];removal=current['removal']
                    need(parsed is not None and parsed.state['phase']=='observed' and backend is not None and backend.state['phase']=='restored'
                        and upload is not None and upload.state['phase']=='retired' and removal is not None
                        and removal.state['phase']=='model-gone' and removal.state['contextClosedBy'] is not None)
                    if resource=='asset-stand.fbx':
                        need(type(parsed) is OwnedAssetsParsedInput and parsed.baking.backend is backend
                            and current['baked_tree'] is not None and current['baked_tree'].state['phase']=='deleted'
                            and current['baked_tree'].state['clientClosedBy'] is not None)
                    else:
                        from ios.adapters.assets_unbaked_input import OwnedAssetsUnbakedInput
                        need(type(parsed) is OwnedAssetsUnbakedInput and parsed.backend is backend
                            and current['tree'] is not None and current['tree'].state['phase']=='deleted'
                            and current['tree'].state['clientClosedBy'] is not None)
                    for subject in ('primary','actor-primary'):
                        path=directories['primary']/('ios-assets-scene-'+self.run+'-'+subject+'.json')
                        source=view.store(path).read();need(source is not None and source['iosAssetsSceneSourcesVersion']==3
                            and same(source['selectedPair'],self.selected.link()) and same(source['episode'],scope.link()))
                    path=directories['actor']/('ios-assets-scene-'+self.run+'-actor.json')
                    source=view.store(path).read();need(source is not None and source['iosAssetsSceneSourcesVersion']==3
                        and same(source['selectedPair'],self.selected.link()) and same(source['episode'],scope.link()))
                    actor=inspect_directory(directories['actor'],primary_directory=directories['primary'],metadata=view,image_contexts=images)
                    expected=self.context['roles']['actor']['binding']
                    need(actor and all(row['runId']==self.run and same(row['binding'],expected) for row in actor)
                        and all(set(row['responsibilities'])<=HELD for row in actor)
                        and any(row['responsibilities']==['peer-resource-retirement'] for row in actor))
                    if resource=='asset-stand.fbx':
                        for suffix in ('image-reader-lifecycle','image-processing','image-storage','image-pool'):
                            path=directories['primary']/('ios-assets-'+suffix+'-'+self.run+'.json')
                            need(str(path) in view.copies and view.copies[str(path)] is not None)
                reports[str(index)]=dict(primary=deepcopy(rows),actor=deepcopy(actor))
                scope.guard()
        finally:
            if previous is None:
                if hasattr(view,'episode'):del view.episode
            else:view.episode=previous
        self.episodes.guard()
        for lease in leases:lease.guard()
        return reports

    @classmethod
    def capture(cls,chosen,locks,selected,episodes,*,owned=()):
        view=RecordingAssetsMetadata(owned=owned,selection=selected);temporary=cls(chosen,{},locks,selected,episodes)
        with read_scope() as reads:
            reports=temporary._read(view);view.guard()
        result=cls(chosen,view.copies,locks,selected,episodes)
        need(same(result.read(owned=owned),reports))
        result.metadata_pins={name:None if pin is None else list(pin) for name,pin in view.pins.items()}
        return result,reads
