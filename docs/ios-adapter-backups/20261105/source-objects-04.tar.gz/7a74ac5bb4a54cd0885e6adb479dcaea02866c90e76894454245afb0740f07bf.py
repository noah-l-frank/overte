"""Private exact selection. UNRUN until Root authorizes publication and execution."""
from contextlib import ExitStack
import hashlib
from importlib.machinery import PathFinder
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
RETAINED=HERE/'retained-first13'
REAL_TEMPORARY_DIRECTORY=tempfile.TemporaryDirectory
OBJECTS=[]
CREATED=[]
CASES=[]


def save(name,value):
    (HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')


def proc(pid):
    fields=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(') ',1)[1].split()
    return dict(pid=pid,ppid=int(fields[1]),pgid=int(fields[2]),sid=int(fields[3]),startTicks=int(fields[19]))


def module_spec_without_import(name):
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:
            assert search is not None,name
    return spec


def verify_source_root_final_map():
    config=json.loads((HERE/'source-root-final-map.json').read_text())
    expected=[str(REPO/path) if path!='.' else str(REPO) for path in config['orderedRoots']]
    assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1'
    assert sys.dont_write_bytecode
    assert Path.cwd()==REPO
    # Check before any target package import; never execute package __init__
    # merely to discover a candidate, and never use a private payload overlay.
    assert not any(name.split('.')[0] in config['packageRoots'] for name in sys.modules)
    remaining=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==REPO or REPO in path.parents:
            continue
        if str(path) not in remaining:
            remaining.append(str(path))
    sys.path[:]=expected+remaining
    actual={}
    for name,relative in config['packageRoots'].items():
        spec=module_spec_without_import(name)
        paths=[str(Path(path).resolve()) for path in spec.submodule_search_locations or ()]
        assert paths==[str(REPO/relative)],(name,paths)
    for name,row in config['modules'].items():
        spec=module_spec_without_import(name)
        path=Path(spec.origin).resolve(strict=True)
        assert path==REPO/row['path'],(name,str(path))
        assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],name
        actual[name]=str(path)
    save('first13-source-root-final-map-actual.json',dict(orderedRoots=expected,modules=actual))


def flatten(value):
    return [case for child in value for case in flatten(child)] if isinstance(value,unittest.TestSuite) else [value.id()]


class Result(unittest.TextTestResult):
    def startTest(self,test):
        super().startTest(test)
        self.first_root=len(CREATED)
        print('START_CASE',test.id(),flush=True)

    def stopTest(self,test):
        CASES.append(dict(id=test.id(),actualOwnedRoots=CREATED[self.first_root:]))
        super().stopTest(test)
        print('END_CASE',test.id(),flush=True)


def main():
    save('first13-runner-process.json',proc(os.getpid()))
    print('ACTUAL_RUNNER',json.dumps(proc(os.getpid())),flush=True)
    verify_source_root_final_map()
    # These imports resolve only from the checked final public checkout.
    from ios.self_tests import test_ios_emote_peer_continuation as selected
    from ios.self_tests import test_ios_emote_marker_scope as marker
    from ios.self_tests import test_ios_installed_code as installed
    from ios.self_tests.retained_host_roots import retain_owned_root

    RETAINED.mkdir(mode=0o700,exist_ok=False)

    def retained_directory(suffix=None,prefix=None,dir=None,*,ignore_cleanup_errors=False,delete=True):
        assert dir is None or Path(dir)==RETAINED
        directory=REAL_TEMPORARY_DIRECTORY(suffix=suffix,prefix=prefix,dir=RETAINED,
            ignore_cleanup_errors=ignore_cleanup_errors,delete=delete)
        root=Path(directory.name)
        info=root.lstat()
        assert root.parent==RETAINED and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
        # The actual helper marks/detaches the actual object's finalizer and
        # preserves instance cleanup checks. paired(retain_originals=True)
        # can call this helper again on the same marked real object.
        assert retain_owned_root(directory,expected_root=root)==root
        OBJECTS.append(directory)
        CREATED.append(str(root))
        save('first13-created-roots.json',CREATED)
        return directory

    aliases=SimpleNamespace(TemporaryDirectory=retained_directory)
    names=json.loads((HERE/'selected-case-ids.json').read_text())
    assert len(names)==len(set(names))==13
    loader=unittest.TestLoader()
    suite=loader.loadTestsFromNames(names)
    assert not loader.errors,loader.errors
    actual=flatten(suite)
    assert actual==names and len(actual)==len(set(actual))==13,actual
    save('first13-selected-case-ids-actual.json',actual)
    result=None
    try:
        with ExitStack() as stack:
            for module in (selected,marker,installed):
                stack.enter_context(patch.object(module,'tempfile',aliases))
            result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
    finally:
        local={}
        for name,module in tuple(sys.modules.items()):
            file=getattr(module,'__file__',None)
            if file is not None:
                path=Path(file).resolve()
                if REPO in path.parents:
                    local[name]=str(path.relative_to(REPO))
        save('first13-imported-local-sources.json',local)
        save('first13-test-report.json',dict(testsRun=None if result is None else result.testsRun,
            successful=False if result is None else result.wasSuccessful(),selectedIds=actual,
            caseResults=CASES,actualOwnedRoots=CREATED,nativeExecuted=False,deviceQualified=False,
            wholeFeatureQualified=False,initialPlaybackRecoveryQualified=False))
    return result is None or not result.wasSuccessful()


if __name__=='__main__':
    raise SystemExit(main())
