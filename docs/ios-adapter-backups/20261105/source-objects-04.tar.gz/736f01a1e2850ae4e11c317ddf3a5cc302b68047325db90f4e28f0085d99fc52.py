"""Metadata/AST-only preparation. Never imports the target project."""
import ast,hashlib,json,shutil
from pathlib import Path
R=Path.cwd()
P=R/'.ios-host-tmp/emote-current747-historical-constructor-round-causal-profile-root-preparation-20261103'
B=R/'.ios-host-tmp/emote-current747-timeout-readonly-profile-corrected-root-preparation-20261103'
assert not (P/'freeze.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,value):p.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
for name in ('actual-proof-current-pins.json','actual-reviewed-publication-delta.json','reviewed_scoped22.py','prior_scoped_prerequisite.py'):
 shutil.copyfile(B/name,P/name)
model='''"""Historical constructor comparison; no current/native transport or facts."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import cProfile,hashlib,json,pstats,signal,stat,sys,time,unittest
from pathlib import Path
from PIL import Image
from adapters.native_clock_join import digest
from adapters.original_file_reads import readonly,collect
from adapters.script_feature.history import unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
from ios.adapters.emote_retirement import Frozen
from ios.adapters import emote_callback_archive as archive
from ios.adapters.emote_archive_round import scope,LITERAL_PACKETS
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def census(roots):
 values={}
 for root in roots:
  for path in (root,*sorted(root.rglob('*'))):
   info=path.lstat();assert stat.S_ISREG(info.st_mode) or stat.S_ISDIR(info.st_mode)
   row=dict(stat=[getattr(info,key) for key in F])
   if stat.S_ISREG(info.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
   assert row['stat']==[getattr(path.lstat(),key) for key in F];values[str(path)]=row
 return values
class HistoricalConstructorProfile(unittest.TestCase):
 def test_actual_saved_snapshot2_constructor_chain_only(self):
  here=Path(__file__).resolve().parent;plan=json.loads((here/'input-plan.json').read_text())
  roots=[Path(p) for p in plan['roots']];root=Path(plan['root']);header=Path(plan['header']);expected=json.loads((here/'input-graph-pins.json').read_text())
  self.assertEqual(expected,census(roots));raw=header.read_bytes();self.assertEqual(plan['headerSha256'],hashlib.sha256(raw).hexdigest());value=json.loads(raw)
  self.assertEqual(2,value['iosEmoteRootedLiveVersion']);self.assertEqual(str(root),value['artifactRoot'])
  state=unpack(value['payload']);self.assertEqual(1,len(state));self.assertEqual(plan['recordReferences'],state[0]['records']);self.assertIsNone(state[0]['pending'])
  lock=ScriptSourceLock(value['sourceLock']);primary=lock if value['sourceLock']==value['primaryLock'] else ScriptSourceLock(value['primaryLock'])
  # Literal stored owner header, selected physical OriginalFrameStore file and
  # copied snapshot metadata are validated before constructor timing. No row,
  # image, Native/Rendered/Keyed historical derivation or memo is warmed.
  Image.preinit();profile=cProfile.Profile();events=[];owner=None;started=None
  self.assertIsNone(sys.monitoring.get_tool(sys.monitoring.PROFILER_ID))
  def save(name,data):
   with (here/name).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\\n')
  def event(operation):
   events.append(dict(operation=operation,monotonic=time.monotonic()))
   (here/'actual-read-progress.json').write_text(json.dumps(events,indent=2)+'\\n')
  def interrupted(signum,frame):
   frames=[]
   while frame is not None and len(frames)<96:
    filename=frame.f_code.co_filename
    if filename.startswith(str(here.parents[2])):frames.append(dict(file=filename,function=frame.f_code.co_qualname,line=frame.f_lineno))
    frame=frame.f_back
   save('actual-interruption-stack.json',dict(kind='ACTUAL_SIGNAL_FRAME_NO_LOCALS',frames=frames))
   raise TimeoutError('Original45s historical-constructor diagnostic interrupted; partial real profile retained')
  previous=signal.signal(signal.SIGALRM,interrupted)
  try:
   with lock.held(),primary.held(),readonly():
    live=IOSEmoteCallbackLive._archive_header(value,store=Frozen(header,value),lock=lock,primary_lock=primary)
    reference=state[0]['records'][-1];frame=live.read_frame(reference);snapshot=frame['snapshot']
    self.assertEqual(plan['snapshotSha256'],digest(snapshot));self.assertEqual(plan['selectedReference'],reference)
    self.assertEqual(plan['snapshotReference'],snapshot['reference']);self.assertEqual(2,snapshot['reference']['index'])
    self.assertEqual(expected,census(roots));event('verified-literal-physical-snapshot2-before-timer')
    signal.setitimer(signal.ITIMER_REAL,45);started=time.monotonic()
    with collect() as membership:
     profile.enable()
     try:
      if plan['mode']=='existing-round':
       with scope(snapshot,lock=lock,primary_lock=primary,key_packet_policy=LITERAL_PACKETS):
        event('entered-existing-immutable-round');owner=archive.reopen(snapshot,lock=lock,primary_lock=primary);event('returned-native-rendered-keyed-constructors')
      else:
       self.assertEqual('literal',plan['mode']);owner=archive.reopen(snapshot,lock=lock,primary_lock=primary);event('returned-native-rendered-keyed-constructors')
     finally:
      profile.disable();signal.setitimer(signal.ITIMER_REAL,0)
      profile.dump_stats(str(here/'actual-constructors-partial-or-complete.pstats'))
      save('actual-membership-partial-or-complete.json',dict(paths=sorted(str(p) for p in membership),completed=owner is not None,partialUnlessReportPASS=True))
    elapsed=time.monotonic()-started;self.assertEqual(expected,census(roots));self.assertIsNotNone(owner)
    native=owner.rendered_owner.native_owner;rendered=owner.rendered_owner
    self.assertTrue(all(part.historical for part in (native,rendered,owner)))
    self.assertTrue(same(native.previous,snapshot['owners']['native']) and same(rendered.previous,snapshot['owners']['rendered']) and same(owner.previous,snapshot['owners']['keyed']))
    self.assertEqual(snapshot['reference'],owner.state['records'][-1]);self.assertTrue(membership)
    stats=pstats.Stats(profile)
    calls=[dict(file=f,line=l,function=n,primitiveCalls=v[0],totalCalls=v[1],ownSeconds=v[2],cumulativeSeconds=v[3]) for (f,l,n),v in sorted(stats.stats.items()) if f.startswith(str(here.parents[2]))]
    save('actual-project-constructor-calls.json',calls)
    save('constructor-profile-result.json',dict(status='ACTUAL_HISTORICAL_SNAPSHOT2_CONSTRUCTOR_CHAIN_ONLY',mode=plan['mode'],seconds=elapsed,
     snapshotSha256=digest(snapshot),snapshotReference=snapshot['reference'],sourceLiveReference=reference,originalFiles=747,allOriginalPinsUnchanged=True,
     historicalStatesSha256=digest(dict(native=native.state,rendered=rendered.state,keyed=owner.state)),readMembership=len(membership),actualReadMembership=sorted(str(p) for p in membership),
     historicalOnly=True,constructorChainOnly=True,actualProductionCurrentConstructorReplacement=False,physicalSnapshotMetadataOutsideTimer=True,ImageRegistrationOnlyBeforeTimer=True,
     noHistoricalDerivationBeforeTimer=True,currentDevice=53,oldDevice36RuntimeReplay=False,SDKExecuted=False,network=False,inputsOrNativeQueries=False,wholeFeatureQualified=False))
  finally:
   signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous);profile.disable();del profile
   self.assertEqual(expected,census(roots))
'''
ast.parse(model)
base_input=json.loads((B/'profile1/input-plan.json').read_text())
physical=next(Path(base_input['root']).glob('emote-rooted-live-frame-inputs-*-primary-0002-*.json'))
raw=json.loads(physical.read_text());snapshot=raw['frame']['snapshot']
# Digest uses exactly canonical JSON, as the production history module.
canonical=json.dumps(snapshot,ensure_ascii=True,sort_keys=True,separators=(',',':'),allow_nan=False).encode('ascii')
assert hashlib.sha256(physical.read_bytes()).hexdigest()==base_input['recordReferences'][-1]['sha256']
stages={}
for name,mode in (('round1','existing-round'),('literal1','literal')):
 T=P/name;shutil.copytree(B/'profile1',T)
 (T/'freeze.json').unlink();(T/'test_current747_readonly_profile.py').unlink()
 (T/'test_historical_constructor_profile.py').write_text(model)
 input_plan=dict(base_input,mode=mode,snapshotSha256=hashlib.sha256(canonical).hexdigest(),snapshotReference=snapshot['reference'],selectedReference=base_input['recordReferences'][-1])
 save(T/'input-plan.json',input_plan)
 plan=json.loads((T/'run-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_CURRENT747_HISTORICAL_CONSTRUCTOR_CAUSAL_PROFILE',cases=['test_historical_constructor_profile.HistoricalConstructorProfile.test_actual_saved_snapshot2_constructor_chain_only'],qualification='Historical Native/Rendered/Keyed constructor comparison only. Neither current transport nor feature qualification. Original600 timeout preserved.')
 plan['privateFiles']={p.name:sha(p) for p in T.glob('*.py')};save(T/'run-plan.json',plan)
 manifest=json.loads((T/'source-manifest.json').read_text());manifest.update(name=name,stage=mode+'-actual-snapshot2-constructor-profile',actualPublicBasis='Exact original Root12 current Window124 source-map and all747 rawpins. Existing component_read scopes are retained. This HISTORICAL constructor profile is not relabelled as actual current source/SDK admission.')
 save(T/'source-manifest.json',manifest)
 for path in T.glob('*.py'):ast.parse(path.read_text())
 save(T/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={p.name:sha(p) for p in sorted(T.iterdir()) if p.is_file()}));stages[name]=sha(T/'freeze.json')
save(P/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',stages=stages,initialSecondsEach=60,killAfterSeconds=5,internalProfileSecondsEach=45,currentOriginalFiles=747,currentDevice=53,oldDevice36RuntimeReplay=False,targetImports=False,testsRun=False,productionSourceChanged=False))
(P/'ROOT-PLAN.txt').write_text('Root-only independently bounded stages round1/root-supervise.py and literal1/root-supervise.py, from resume checkout with PYTHONDONTWRITEBYTECODE=1 python3 -B. Each retains existing60+5; each has45s original read-work alarm retaining actual interrupted frame names/lines (NO LOCALS), partial cProfile and actual membership, then real case/aggregate close/censuses. ZERO new TD/SDK/Node/network/input/native query. Both select actual immutable Primary Live2 physical Snapshot2 from new dev53 747 corpus. No headers/clocks/references rewritten. Existing round uses production emote_archive_round.scope(snapshot,key_packet_policy=LITERAL_PACKETS), unmodified. Counterpart literal archive.reopen(snapshot) outside that round. Constructor outputs/actual reads may be compared only if actual completed reports; an interrupted result remains failure. Neither path emulates actual current admission: historical objects skip per-current-component component_read, while the current constructors already have separate component_read rounds. Frozen new747 pure-Live profile remains unrun and is not needed for this comparison. All600 timeout source/retention/rawpins/old27/235/focused2 proofs remain exact and honest. No target imports/tests/public mutations performed during preparation.\n')
save(P/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(P)):sha(p) for p in sorted(P.rglob('*')) if p.is_file() and p.name!='freeze.json'},stages=stages))
print(json.dumps(dict(masterFreeze=sha(P/'freeze.json'),stages=stages)))
