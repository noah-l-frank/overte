"""One actual normal Primary prefix, never an expected-error success."""
from pathlib import Path
from types import SimpleNamespace,ModuleType
import argparse,importlib,importlib.abc,importlib.machinery,importlib.util,io,json,os,signal,stat,sys,tempfile,threading,traceback,unittest
from prefix_common import REPO,load,sha,save,pin,head,proc,fds,all_pins
from avatar_ports import AvatarPorts
from entry_observer import EntryObserver
from monitoring_observer import OriginalProcessObserver
from closed_import_origins import ClosedOrigins
from own_public_source_reads import OwnPublicSourceReads,SDK_NAMES,forbidden_path
parser=argparse.ArgumentParser();parser.add_argument('--input',required=True);parser.add_argument('--input-sha',required=True);args=parser.parse_args()
INPUT=Path(args.input);assert INPUT.is_absolute()and sha(INPUT)==args.input_sha
input_before=pin(INPUT);plan=load(INPUT);HERE=INPUT.parent
assert HERE.resolve(strict=True)==HERE and HERE.parent==REPO/'.ios-host-tmp'and Path.cwd()==REPO and sys.dont_write_bytecode
assert plan['status']=='PRIVATE_UNRUN_AVATAR_PREFIX_REQUIRES_ROOT_REVIEW'and head()==plan['expectedCurrentHead']
assert sys.flags.no_site==1, 'Explicit no-site startup required'
assert plan['initialTimeoutSeconds']==300 and plan['killAfterSeconds']==5 and plan['expectedRetainedRoots']==6
RUN=HERE/'child';TEMP=RUN/'temporary';assert RUN.is_dir()and TEMP.is_dir()and not any(TEMP.iterdir())
assert os.environ['TMPDIR']==str(TEMP)and tempfile.gettempdir()==str(TEMP)
# Source/controller inputs are outside RUN and already unreachable through the
# canonical writer root. Preserve any input actually inside that write room.
# All source pins, without exclusion, still receive full before/after checks.
PROTECTED=tuple(Path(p)for p in(*plan['sourcePins'],str(INPUT))if Path(p).is_relative_to(RUN))
before=all_pins(plan['sourcePins']);save(RUN/'runner-binding.json',proc(os.getpid()))
original_threads=set(threading.enumerate());original_fds=fds();original_meta=tuple(sys.meta_path)
assert not any(name in sys.modules for name in('adapters','ios','feature_journeys','self_tests','fixture','PIL','defusedxml')),'Target imported before original source admission'
original_tools=tuple((sys.monitoring.get_tool(i),sys.monitoring.get_events(i))for i in range(6));original_profile=sys.getprofile();original_trace=sys.gettrace()
original_do_cleanups=unittest.TestCase.doCleanups;cleanup_code=original_do_cleanups.__code__;cleanup_globals=original_do_cleanups.__globals__
cleanup_events=[];cases=[];errors={};retained=[];directories=[];aliases=[];suite=None;result=None;class_setup_returned=False;class_teardown_returned=False
ports=AvatarPorts(TEMP,RUN,save,globals(),sys._getframe(),expected_node=(),node_pin=plan['executables']['node'],environment_digest=plan['environmentSha256'],openssl_pin=plan['executables']['openssl'])
entry=None;process=None;closed=False
assert plan['originPlan']['physicalPins']==plan['sourcePins']
origins=ClosedOrigins(plan['originPlan'],HERE,REPO,pin)
origin_before=origins.snapshot('before-genuine-avatar-project-imports')
save(RUN/'loaded-origins-before.json',origin_before)
tail_outputs=(RUN/'restoration.json',RUN/'result.json');tail_pins={}
original_io=io.open
def tail_write(path,value):
    assert closed and io.open is original_io and path in tail_outputs and pin(path)==tail_pins[path]
    with original_io(path,'w',encoding='utf-8')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
tail_code=tail_write.__code__;tail_globals=tail_write.__globals__
stdlib=Path(os.__file__).resolve().parent
sdk_bad=SDK_NAMES
forbidden_file_function=forbidden_path
forbidden_file_code=forbidden_path.__code__;forbidden_file_globals=forbidden_path.__globals__
own_source_reader=OwnPublicSourceReads(plan,REPO,ports,origins)
reader_type=OwnPublicSourceReads;reader_match=OwnPublicSourceReads.__dict__['matches']
reader_match_code=reader_match.__code__;reader_match_globals=reader_match.__globals__
def own_public_read(event,values,caller):
    assert type(own_source_reader)is reader_type and reader_type.__dict__['matches']is reader_match
    assert reader_match.__code__ is reader_match_code and reader_match.__globals__ is reader_match_globals
    return reader_match(own_source_reader,event,values,caller)
def forbidden(name,path=None):
    assert forbidden_path is forbidden_file_function and forbidden_path.__code__ is forbidden_file_code
    assert forbidden_path.__globals__ is forbidden_file_globals and forbidden_file_globals['SDK_NAMES']is sdk_bad
    if any(part in sdk_bad for part in name.split('.')):return True
    return path is not None and forbidden_path(path)
def audit(event,values):
    # Classify first: no unconditional __code__/frame reads on every audit
    # event, and no global "active" bypass for nested writes.
    if event=='import':
        if forbidden(values[0],values[1]):raise RuntimeError('Vendor SDK import/source refused')
    elif event=='open'and type(values[0])in(str,bytes):
        if forbidden('',values[0]):
            if not own_public_read(event,values,sys._getframe(1)):
                raise RuntimeError('Vendor SDK file refused')
    elif event in('os.system','os.fork','os.forkpty','os.posix_spawn','os.exec','pty.spawn'):raise RuntimeError('Unselected process port')
    elif event.startswith('ctypes.'):raise RuntimeError('Unselected foreign-function loader')
    routed=(event in('open','subprocess.Popen','os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith(('socket.','fcntl.')))
    if not routed:return
    if not closed:ports.audit(event,values,sys._getframe(1))
    elif event=='open':
        target,mode,flags=values;writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
        if writing:
            frame=sys._getframe(1);path=Path(target)if type(target)in(str,bytes)else None
            if (frame.f_code is not tail_code or frame.f_globals is not tail_globals or tail_write.__code__ is not tail_code
                    or frame.f_locals.get('path')!=path or path not in tail_outputs or mode!='w'
                    or flags!=(os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC)or pin(path)!=tail_pins[path]):raise RuntimeError('Unbound postrestore output write')
    elif event in('os.mkdir','os.remove','os.rmdir','os.rename','os.chmod','os.chown','os.utime','os.truncate','os.link','os.symlink')or event.startswith('fcntl.'):
        raise RuntimeError('Mutation after original port restoration')
sys.addaudithook(audit);ports.install()
entry=EntryObserver(ports).start();process=OriginalProcessObserver(proc).start()
entry.bind(original_do_cleanups,'cleanup')

class AfterActualLoader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name,self.delegate=name,delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module)
        # Existing genuine entry/return bindings, after actual pinned source
        # execution. No Source/constructor/function body is replaced.
        if self.name in plan['modules']:entry.imported(self.name,module)
        if self.name=='ios.self_tests.test_ios_avatar_normal_primary_budget_refusal_prefix':
            entry.bind(module.AvatarNormalPrimaryBudgetRefusalPrefixTests.setUpClass.__func__,'class-setup')
            entry.bind(module.AvatarNormalPrimaryBudgetRefusalPrefixTests.tearDownClass.__func__,'class-teardown')

class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if forbidden(name):raise ImportError('Vendor SDK import refused')
        if name in plan['modules']:
            row=plan['originPlan']['modules'][name]
            spec=origins.file_spec(name,dict(row,loader='source'),'project')
            spec.loader=AfterActualLoader(name,spec.loader);return spec
        if name in plan['originPlan']['thirdPartyModules']:
            return origins.remaining_spec(name,path)
        if name in plan['originPlan']['namespacePackages']:
            roots=plan['originPlan']['namespacePackages'][name]
            origins.namespaces(name,roots,roots,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True)
            spec.submodule_search_locations=roots;return spec
        if name.split('.')[0]in plan['closedTopLevels']:
            raise ImportError('Unlisted closed project/third-party module '+name)
        return origins.remaining_spec(name,path)

finder=Finder();sys.meta_path.insert(0,finder)
real_td=tempfile.TemporaryDirectory
def retained_directory(*values,**keywords):
    # All four actual fixture aliases use the ordinary default temp root.
    # No caller's explicit foreign dir is silently redirected.
    if keywords.get('dir')is not None:raise RuntimeError('Unexpected fixture TD parent')
    directory=real_td(*values,**keywords);root=Path(directory.name)
    assert root.resolve(strict=True)==root and root.parent==TEMP
    from ios.self_tests.retained_host_roots import retain_owned_root
    retain_owned_root(directory,expected_root=root);directories.append(directory);retained.append(str(root))
    return directory

class Result(unittest.TextTestResult):
    def startTest(self,test):
        origins.snapshot('before-genuine-avatar-case-'+test.id())
        cases.append(test);super().startTest(test)
    def addError(self,test,error):errors[test.id()]=error[1];super().addError(test,error)
    def addFailure(self,test,error):errors[test.id()]=error[1];super().addFailure(test,error)

def interrupted(signum,frame):raise KeyboardInterrupt('Original prefix interrupted by outer supervisor')
previous_term=signal.signal(signal.SIGTERM,interrupted)
pending_exception=None;cleanup_errors=[];restore=None
try:
    # Exact closed modules are imported only after source/audit/write/monitor
    # installation. Every target constructor remains the genuine original.
    modules=[importlib.import_module(name)for name in plan['fixtureAliasModules']]
    for module in modules:
        assert module.tempfile is tempfile;aliases.append((module,module.tempfile));module.tempfile=SimpleNamespace(TemporaryDirectory=retained_directory)
    people=importlib.import_module('ios.self_tests.avatar_people_node');app=importlib.import_module('ios.self_tests.avatar_app_node')
    process.bind_owners((people.PeopleNode.__init__.__code__,app.AvatarAppNode.__init__.__code__),(people.PeopleNode.close.__code__,app.AvatarAppNode.close.__code__))
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['caseIds']);assert not loader.errors
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for child in value:yield from flatten(child)
        else:yield value
    prepared=list(flatten(suite));assert [test.id()for test in prepared]==plan['caseIds']and len(prepared)==1
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:
    pending_exception=sys.exc_info();traceback.print_exception(*pending_exception)
finally:
    # Preserve the actual standard TestCase cleanup function and its pending
    # callbacks even when TextTestRunner was interrupted. No cleanup result is
    # inferred from process death or a monitor return alone.
    for test in cases:
        if test._cleanups:
            try:
                assert unittest.TestCase.doCleanups is original_do_cleanups and original_do_cleanups.__code__ is cleanup_code and original_do_cleanups.__globals__ is cleanup_globals
                value=original_do_cleanups(test);cleanup_events.append(dict(testId=test.id(),pendingDrain=True,returned=value,remaining=len(test._cleanups)))
                if value is not True:cleanup_errors.append(dict(testId=test.id(),kind='StandardCleanupReturnedFalse'))
            except BaseException:cleanup_errors.append(dict(testId=test.id(),traceback=traceback.format_exc()))
    # The genuine inherited class teardown releases the retained TLS owner.
    # A monitoring receipt distinguishes a completed standard Suite call from
    # an interrupted setup needing this original final cleanup.
    if class_setup_returned and not class_teardown_returned and cases:
        try:type(cases[0]).tearDownClass()
        except BaseException:cleanup_errors.append(dict(kind='OriginalClassTeardown',traceback=traceback.format_exc()))
    for module,original in reversed(aliases):module.tempfile=original
    signal.signal(signal.SIGTERM,previous_term)
    diagnostics=[]
    if cases:
        from normal_prefix_receipt import after_original_cleanup
        diagnostics=[after_original_cleanup(test,errors.get(test.id()))for test in cases]
    processes=[]
    for row in ports.births:
        owner=row['process'];pid=getattr(owner,'pid',None);current=proc(pid)if type(pid)is int else None
        birth=row['birth'];streams={name:None if getattr(owner,name,None)is None else getattr(owner,name).closed for name in('stdin','stdout','stderr')}
        gone=birth is not None and type(pid)is int and birth['pid']==pid and(current is None or current['startTicks']!=birth['startTicks'])
        processes.append(dict(kind=row['kind'],pid=pid,birth=birth,current=current,constructorReturned=row['constructorReturned'],constructorUnwound=row['constructorUnwound'],returnCode=getattr(owner,'returncode',None),streamsClosed=streams,absent=gone))
    save(RUN/'actual-processes.json',processes)
    remaining=[dict(name=t.name,ident=t.ident)for t in threading.enumerate()if t not in original_threads and t.is_alive()]
    origin_after=None
    try:
        origin_after=origins.snapshot('after-genuine-avatar-original-cleanup')
        save(RUN/'loaded-origins-after-cleanup.json',origin_after)
    except BaseException:
        cleanup_errors.append(dict(kind='ActualLoadedOriginAccounting',traceback=traceback.format_exc()))
    save(RUN/'normal-prefix-budget-original.json',diagnostics)
    save(RUN/'retained-root-births.json',retained)
    entry.stop();process.stop()
    assert tuple((sys.monitoring.get_tool(i),sys.monitoring.get_events(i))for i in range(6))==original_tools
    assert sys.getprofile()is original_profile and sys.gettrace()is original_trace
    assert sys.meta_path==[finder,*original_meta];sys.meta_path[:]=original_meta
    save(RUN/'monitoring-original.json',process.metadata())
    save(RUN/'declared-model-preconsumer-original.json',ports.model_files)
    save(RUN/'exact-own-public-source-read-originals.json',own_source_reader.authorized)
    save(RUN/'actual-localhost-resolver-fallback-attempts.json',ports.ipv6_attempts)
    save(RUN/'actual-original-http-bind-nss-attempts.json',ports.host_nss_reads)
    save(RUN/'actual-rejected-popen-start-unwind-originals.json',entry.rejection_original())
    save(RUN/'actual-connected-endpoints-before-http.json',ports.connected_endpoints)
    original_cleanup_ok=all(row['returned']is True and row['remaining']==0 for row in cleanup_events)
    original_closes_ok=all(any(row['owner']is owner['owner']and row['returned']and row['returnCode']==0 for row in process.closes)for owner in process.owners)
    resources=(not remaining and not cleanup_errors and original_cleanup_ok and original_closes_ok and all(row['absent']and row['returnCode']is not None and all(v is None or v is True for v in row['streamsClosed'].values())for row in processes))
    for path in tail_outputs:
        descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        try:assert stat.S_IMODE(os.fstat(descriptor).st_mode)==0o600
        finally:os.close(descriptor)
        tail_pins[path]=pin(path)
    if resources:restore=ports.restore();closed=True
    # No "active" audit switch: closed is reachable only after actual original
    # alias restoration, then report writes use the originally held C IO port.
    if closed:tail_write(RUN/'restoration.json',restore)
    assert pin(INPUT)==input_before and all_pins(plan['sourcePins'])==before and head()==plan['expectedCurrentHead']
    after_fds=fds();descriptor_drain=after_fds==original_fds
    report=dict(allLoadedOriginsAccounted=origin_after is not None,originSnapshots=origins.snapshot_count,testsRun=None if result is None else result.testsRun,successful=result is not None and result.wasSuccessful(),actualCaseIds=[t.id()for t in cases],genuineObserveErrorNonzero=bool(errors),actualClassSetupReturned=class_setup_returned,actualClassTeardownReturned=class_teardown_returned,actualStandardCleanupCalls=cleanup_events,cleanupErrors=cleanup_errors,resourcesDrained=resources,originalHostClosesCompleted=original_closes_ok,originalFDsEqual=descriptor_drain,remainingThreads=remaining,actualNodeCount=sum(row['kind']=='node'for row in processes),actualTLSCount=sum(row['kind']=='openssl'for row in processes),retainedRoots=retained,expectedRetainedRoots=6,budgetDiagnostics=diagnostics,modelArtifactOnly=True,nativeQualified=False,wholeQualified=False)
    if closed:tail_write(RUN/'result.json',report)
    else:save(RUN/'failed-drain-result.json',report)
    if not resources or not descriptor_drain:raise RuntimeError('Actual original cleanup/FD/thread/process drain incomplete')
    if len(retained)!=6 or report['actualNodeCount']!=3 or report['actualTLSCount']!=1:raise RuntimeError('Actual original selected resource cardinality changed')
if pending_exception is not None:raise pending_exception[1].with_traceback(pending_exception[2])
raise SystemExit(0 if result is not None and result.wasSuccessful()and result.testsRun==1 and not result.skipped else 1)
