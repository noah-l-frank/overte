"""Bind resource continuations to actual completed Native3, metadata only."""
import ast,difflib,hashlib,json,os,stat
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/lifecycle-resource4-native-qualified-gated-four-stages-root-preparation-20261102'
BASE=REPO/'.ios-host-tmp/lifecycle-resource4-released-observer-four-selected-stages-root-preparation-20261102'
QUALIFIED=REPO/'.ios-host-tmp/lifecycle-resource4-native-bookend-first3-root-preparation-20261102/first3'
SOURCE=REPO/'.ios-host-tmp/lifecycle-resource4-native-bookend-overall-deadline-source-proposal-20261102'
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(v)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in FIELDS])
 if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
 assert v['stat']==[getattr(p.lstat(),k) for k in FIELDS];return v
report=json.loads((QUALIFIED/'root-run-first/report.json').read_text());assert report['exitCode']==0 and report['allPinsEqual'] and report['rootMapUnchanged'] and report['retainedOriginalsUnchanged'] and report['remainingOwnedProcesses']==[]
qplan=json.loads((QUALIFIED/'run-plan.json').read_text());cases=qplan['cases'];assert len(cases)==3
thread=json.loads((QUALIFIED/'root-run-first/thread-report.json').read_text());assert thread==dict(exitCode=0,remainingNewThreads=[])
before=json.loads((QUALIFIED/'root-run-first/source-before.json').read_text());after=json.loads((QUALIFIED/'root-run-first/source-after.json').read_text());assert before==after
root=QUALIFIED/'retained-first';first=json.loads((QUALIFIED/'root-run-first/originals-first.json').read_text());second=json.loads((QUALIFIED/'root-run-first/originals-second.json').read_text());assert first==second
actual={str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))};assert actual==first
assert sum('sha256' in row for row in actual.values())==report['retainedFiles']
roots=[]
for index,case in enumerate(cases,1):
 case_root=QUALIFIED/('case-cleanup-'+str(index));receipt=json.loads((case_root/'receipt.json').read_text());assert receipt['case']==case and receipt['actualStandardCaseRunReturned'] and receipt['twoCensusesPassed'];roots.extend(receipt['retainedRoots'])
 a=json.loads((case_root/'terminal-census-1.json').read_text());b=json.loads((case_root/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
assert len(roots)==len(set(roots))==6
# Exact current source/launcher/old-original pins are copied from the actual
# successful AFTER census; do not invent maps or mark the old failed first1PASS.
proof_pins=dict(after)
for path in sorted(QUALIFIED.rglob('*')):
 if path.is_file() and (path.parent.name=='root-run-first' or path.parent.name.startswith('case-cleanup-') or path.name.startswith('actual-source-raise') or path.name.startswith('terminal-census-')):proof_pins[str(path)]=pin(path)
for relative,row in actual.items():proof_pins[str(root/relative)]=row
for path in (QUALIFIED/'freeze.json',QUALIFIED/'run-plan.json',QUALIFIED/'source-manifest.json'):proof_pins[str(path)]=pin(path)
for name,row in proof_pins.items():assert pin(Path(name))==row,name
# No shared result/factory acceptance. Runtime prerequisite rechecks exact
# actual report/cases/thread/final censuses PLUS every original/source pin.
gate='''"""Actual Native3 prerequisite, metadata only; no target imports or effects."""
import hashlib,json,os,stat
from pathlib import Path
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def require(here,repo):
    plan=json.loads((here/'actual-native3-prerequisite.json').read_text());pins=json.loads((here/'actual-native3-pass-pins.json').read_text())
    root=Path(plan['actualStage']);assert root.is_relative_to(repo/'.ios-host-tmp') and root.resolve(strict=True)==root
    report=json.loads((root/'root-run-first/report.json').read_text())
    assert report['exitCode']==0 and report['allPinsEqual'] and report['rootMapUnchanged'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses']
    assert json.loads((root/'root-run-first/thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
    qplan=json.loads((root/'run-plan.json').read_text());assert qplan['cases']==plan['actualCaseIds'] and qplan['caseCount']==3
    assert json.loads((root/'root-run-first/source-before.json').read_text())==json.loads((root/'root-run-first/source-after.json').read_text())
    assert json.loads((root/'root-run-first/originals-first.json').read_text())==json.loads((root/'root-run-first/originals-second.json').read_text())
    for index,case in enumerate(plan['actualCaseIds'],1):
        case_root=root/('case-cleanup-'+str(index));receipt=json.loads((case_root/'receipt.json').read_text())
        assert receipt['case']==case and receipt['actualStandardCaseRunReturned'] and receipt['twoCensusesPassed']
        a=json.loads((case_root/'terminal-census-1.json').read_text());b=json.loads((case_root/'terminal-census-2.json').read_text())
        assert a==b and not a['threads'] and not a['pendingTasks'] and not a['sdkModules'] and a['children']==''
    result=[]
    for name,expected in pins.items():
        path=Path(name);assert path.is_relative_to(repo) and path.resolve(strict=True)==path
        a=path.lstat();actual=dict(stat=[getattr(a,k) for k in FIELDS])
        assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
        if stat.S_ISREG(a.st_mode):actual['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual==expected and actual['stat']==[getattr(path.lstat(),k) for k in FIELDS],name
        result.append(path)
    # Prove currently absent original process identity, never infer stop from
    # a timeout, old marker or the fact that a report file exists.
    process=json.loads((root/'root-run-first/process-binding.json').read_text())['task']
    try:row=Path('/proc',str(process['pid']),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):row=None
    assert row is None or int(row[19])!=process['startTicks'],'Original prerequisite process is still live'
    return result
'''
source_changes={row['path']:row for row in json.loads((SOURCE/'plan.json').read_text())['source']};out=[]
for name in ('first1','foreignPostrelease1','remaining6','normal1'):
 old=BASE/name;stage=HERE/name;stage.mkdir(mode=0o700)
 for relative,digest in json.loads((old/'freeze.json').read_text())['files'].items():
  assert sha(old/relative)==digest;write(stage/relative,(old/relative).read_text())
 write(stage/'actual_prerequisite.py',gate);save(stage/'actual-native3-pass-pins.json',proof_pins)
 save(stage/'actual-native3-prerequisite.json',dict(status='ACTUAL_NATIVE3_PASS_BOUND_NOT_ANTICIPATED',actualStage=str(QUALIFIED),actualCaseIds=cases,actualRetainedFiles=report['retainedFiles'],actualRoots=roots,actualReportSHA256=sha(QUALIFIED/'root-run-first/report.json'),scope='Source clock/worker logic under explicit SDK/native models only; no resource/native/auth/whole acceptance'))
 parent=(stage/'root-supervise.py').read_text();parent=parent.replace(' return {str(path):pin(path) for path in sorted(paths)}'," from actual_prerequisite import require\n paths.update(require(HERE,REPO))\n return {str(path):pin(path) for path in sorted(paths)}")
 assert 'paths.update(require(HERE,REPO))' in parent;(stage/'root-supervise.py').write_text(parent)
 child=(stage/'run-selected.py').read_text();anchor='    initial=baseline() # BEFORE any target module import.\n';assert child.count(anchor)==1
 child=child.replace(anchor,"    from actual_prerequisite import require\n    require(HERE,repo) # Actual prior PASS/censuses/source bytes, never a plan flag.\n"+anchor)
 child=child.replace('        sdk_free()\n        if len(owned)', '        sdk_free()\n        require(HERE,repo)\n        if len(owned)');(stage/'run-selected.py').write_text(child)
 plan_path=stage/'run-plan.json';plan=json.loads(plan_path.read_text());plan['privateFiles'].update({p.name:sha(p) for p in stage.glob('*.py')});plan['status']='PRIVATE_UNRUN_NATIVE3_QUALIFIED_GATED_'+name;plan_path.write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
 manifest_path=stage/'source-manifest.json';manifest=json.loads(manifest_path.read_text())
 for row in manifest['sourcePaths']:
  if row['path'] in source_changes:
   change=source_changes[row['path']];row.update(candidate=str(SOURCE/'candidate'/row['path']),candidateSHA256=change['candidateSHA256'],baseSHA256=change['baseSHA256'])
  row['observedPublicSHA256']=sha(REPO/row['path']);row['changesCurrentPublic']=row['observedPublicSHA256']!=row['candidateSHA256']
 manifest['orderedParentFreezes'][str(SOURCE.relative_to(REPO/'.ios-host-tmp'))]=sha(SOURCE/'freeze.json');manifest['status']=plan['status'];manifest['actualPublicBasis']='Actual Native3 PASS with source77e08b83/fb249bcc and exact original overall deadlines; current full map generated per stage.'
 manifest_path.write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
 prior_path=stage/'prior-retained-original-pins.json';prior=json.loads(prior_path.read_text());prior.update(proof_pins);prior_path.write_text(json.dumps(prior,indent=2,sort_keys=True)+'\n')
 for p in stage.glob('*.py'):ast.parse(p.read_bytes(),filename=str(p))
 (stage/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
 out.append(dict(stage=name,freeze=sha(stage/'freeze.json'),cases=plan['cases'],initialSeconds=plan['initialOuterSeconds'],realRoots=plan['expectedRetainedRoots']))
write(HERE/'gate-parent-delta-only.diff',''.join(difflib.unified_diff((BASE/'first1/root-supervise.py').read_text().splitlines(True),(HERE/'first1/root-supervise.py').read_text().splitlines(True),fromfile='before-gate/root-supervise.py',tofile='actual-native3-gated/root-supervise.py')))
write(HERE/'gate-child-delta-only.diff',''.join(difflib.unified_diff((BASE/'first1/run-selected.py').read_text().splitlines(True),(HERE/'first1/run-selected.py').read_text().splitlines(True),fromfile='before-gate/run-selected.py',tofile='actual-native3-gated/run-selected.py')))
save(HERE/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',actualPrerequisiteStage=str(QUALIFIED),actualPrerequisiteReport=report,actualPassPinCount=len(proof_pins),actualFirst3CaseIds=cases,stages=out,noCapsChanged=True,noTimingGuardsChanged=True,testsRun=False,targetImported=False,sourcePublished=False))
write(HERE/'ROOT-PLAN.txt','Fresh Resource4 first1+foreignPostrelease1+remaining6+normal1 require ACTUAL already completed Native3 PASS48files/6roots, not anticipated success. actual_prerequisite.py verifies actual parent0, unchanged map/source/alloriginalcensuses, exactthreecase IDs, three percase standardRunner-return/twoFD/task/thread/child/originalcensuses, threadreport0 and actual prerequisite process gone; all exact17823after-source+rawfile+proof pins are bound at preparation and rechecked parent/child before/after. New NativeSource77e08b83/fb249bcc; runtime55f243 unchanged. Old Source1c5 failedfirst15 is STILLfailure, preserved with allolder15/16/18 and timeline. No cap changes:first1/foreign1 each30+kill5/2TD,remaining6 original90+kill5/12TD,normal1 original60+kill5/3TD. Original audits/explicitignoreddependencies/percase cleanup remain. Root mustreview gate/deltas, then run first1; any newfailure stops laterstages. No imports/tests/PUB byagent.\n')
save(HERE/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'},stageFreezes={r['stage']:r['freeze'] for r in out}))
print(json.dumps(dict(packet=str(HERE),freeze=sha(HERE/'freeze.json'),stages=out,actualPassPins=len(proof_pins))))
