"""Code-only prepared-plan validation; importing performs no census."""
from pathlib import Path
import hashlib,json,os,stat,sys
from group_selection import selected,SELECTION,SELECTION_SHA
from prerequisites import require_real_prerequisites,require_historical_public_component
from source_execution_readiness import qualification,HELPER_SHA
SOURCE=Path(__file__).resolve().parent
REPO=SOURCE.parent.parent
PROPOSAL=REPO/'.ios-host-tmp/chat-offline-send-no-replay-source1-private-20261104'
PROPOSAL_SHA='b1df990cbb9187fe6982cafe0a9e4065283eb541c7f30860162afd624a390f9b'
HISTORICAL_CONTROLLER_HEAD='06ff22857d8c8298390e00cd5df1c848a1d9c6a5'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def meta(info):
    return dict(device=info.st_dev, inode=info.st_ino, mode=info.st_mode,
        uid=info.st_uid, gid=info.st_gid, nlink=info.st_nlink,
        bytes=info.st_size, mtimeNs=info.st_mtime_ns, ctimeNs=info.st_ctime_ns)


def pin(path):
    path = Path(path)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode)
    shared_expected = None
    if before.st_nlink != 1:
        # Only these exact ROOT-owned, non-group/world-writable stdlib source
        # identities are shared read-only inputs. All ordinary/raw paths keep
        # the original single-link rule; no source is unlinked or rewritten.
        manifest = load(SOURCE / 'readonly-shared-stdlib-sources.json')
        actual_std = Path(os.__file__).resolve(strict=True).parent
        assert manifest['version'] == 1 and manifest['actualStdlibRoot'] == str(actual_std)
        assert path.is_absolute() and path.resolve(strict=True) == path
        assert path.is_relative_to(actual_std) and path.suffix == '.py'
        assert not any(part in ('site-packages', 'dist-packages') for part in path.parts)
        shared_expected = manifest['sources'].get(str(path))
        assert shared_expected is not None and before.st_nlink > 1
        assert before.st_uid == 0 and not before.st_mode & 0o022
        assert meta(before) == {key:value for key,value in shared_expected.items() if key != 'sha256'}
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        assert meta(os.fstat(fd)) == meta(before)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        assert meta(os.fstat(fd)) == meta(before) == meta(path.lstat())
        assert len(raw) == before.st_size
    finally:
        os.close(fd)
    result = dict(meta(before), sha256=hashlib.sha256(raw).hexdigest())
    if shared_expected is not None:
        assert result == shared_expected
    return result


def census(root):
    """Exact existing-tree census. Called only in a later Root window."""
    root = Path(root)
    result = {}
    def visit(path):
        info = path.lstat()
        row = meta(info)
        if stat.S_ISDIR(info.st_mode):
            assert not path.is_symlink()
            with os.scandir(path) as stream:
                names = sorted(entry.name for entry in stream)
            row['namespace'] = names
            for name in names:
                visit(path / name)
        else:
            row = pin(path)
        assert meta(path.lstat()) == meta(info)
        result[str(path.relative_to(root))] = row
    visit(root)
    return result


def load(path):
    return json.loads(Path(path).read_text())


def head():
    git = Path((REPO / '.git').read_text().strip().split('gitdir: ', 1)[1])
    if not git.is_absolute():
        git = REPO / git
    common = (git / (git / 'commondir').read_text().strip()).resolve(strict=True)
    selected = (git / 'HEAD').read_text().strip()
    assert selected.startswith('ref: ')
    ref = selected[5:]
    for base in (git, common):
        if (base / ref).is_file():
            return (base / ref).read_text().strip()
    for line in (common / 'packed-refs').read_text().splitlines():
        if line and not line.startswith(('#', '^')):
            value, name = line.split(' ', 1)
            if name == ref:
                return value
    raise AssertionError('Reviewed checkout HEAD unavailable')


def fds():
    result = {}
    for path in Path('/proc/self/fd').iterdir():
        try:
            info = path.stat()
            result[path.name] = dict(target=os.readlink(path), device=info.st_dev,
                inode=info.st_ino, mode=info.st_mode)
        except (FileNotFoundError, ProcessLookupError):
            pass
    return result


def proc(pid):
    try:
        text = (Path('/proc') / str(pid) / 'stat').read_text()
    except (FileNotFoundError, ProcessLookupError):
        return None
    fields = text[text.rfind(')') + 2:].split()
    return dict(pid=int(text[:text.index('(')].strip()), parent=int(fields[1]),
        group=int(fields[2]), session=int(fields[3]), startTicks=int(fields[19]))



PUBLIC_INTEGRATION=REPO/'.ios-host-tmp/root-chat-offline-source1-exact-public-integration-20261104'
PUBLIC_INTEGRATION_FREEZE='f35e841db95bd84e136d549b0213c62e3554b631407df238644c00afc9e77027'
PUBLIC_INTEGRATION_BODY='c766a349671ccd258a886eab0a967d4806295accac82ec18e297463db7bb2bdc'
def require_public_integration(value,expected_head):
    assert value==dict(path=str(PUBLIC_INTEGRATION/'freeze.json'),sha256=PUBLIC_INTEGRATION_FREEZE)
    physical={}
    def keep(path,digest):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        assert pin(path)['sha256']==digest;physical[str(path)]=digest
    def packet(folder,digest):
        folder=Path(folder);keep(folder/'freeze.json',digest);freeze=load(folder/'freeze.json')
        for name,row in freeze['files'].items():
            assert not Path(name).is_absolute()and '..'not in Path(name).parts
            keep(folder/name,row['sha256'])
        return freeze
    packet(PUBLIC_INTEGRATION,PUBLIC_INTEGRATION_FREEZE)
    keep(PUBLIC_INTEGRATION/'integration.json',PUBLIC_INTEGRATION_BODY);body=load(PUBLIC_INTEGRATION/'integration.json')
    assert body['status']=='ROOT_EXACT_FIVE_SOURCE1_PUBLIC_FILE_INTEGRATION_LOCAL_COMMIT_PRIVATE14_PASS_PUBLIC_EXECUTION_PENDING'
    assert body['head']==expected_head=='9d584bb54268b0ae62c2a9154303bd816df6cda2'
    assert body['parent']=='7c18ac7c24270419b3f8cc5fdd3bb24ef4ee70f9'
    assert body['sourceFreeze']==PROPOSAL_SHA and body['sourcePacket']==str(PROPOSAL)
    for key in('publicCurrentOriginAll14Qualified','nativeQualified','deviceQualified','wholeChatQualified'):assert body[key]is False
    assert body['completeFeatures']==5 and body['featureTotal']==14
    assert body['historical34DependenciesRetained']is body['historicalRuntimeASTUnchangedExceptOneAdditiveFactory']is True
    selection=load(SELECTION/'selections.json');expected_ids=selection['preservedInitialFour']+selection['groups']['additional-five-1']+selection['groups']['additional-five-2']
    assert body['actualPrivateSelections']==expected_ids and body['actualDistinctPrivateCases']==len(set(expected_ids))==14
    deps=load(PROPOSAL/'DEPENDENCIES.json');candidate={row['module']:row for row in deps['overlays']};assert len(candidate)==5
    assert len(body['integratedFiles'])==5 and {row['module']for row in body['integratedFiles']}==set(candidate)
    modules={}
    for row in body['integratedFiles']:
        name=row['module'];original=candidate[name];public=REPO/'tests/device'/Path(name.replace('.','/')).with_suffix('.py')
        assert row==dict(module=name,publicPath=str(public),sha256=original['sha256'],sourcePath=original['path'])
        keep(public,row['sha256']);keep(row['sourcePath'],row['sha256'])
        modules[name]=dict(path=str(public),sha256=row['sha256'],package=False)
    assert len(body['publicCommitFiles'])==8
    for name,digest in body['publicCommitFiles'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts;keep(REPO/name,digest)
    historical=body['historicalRuntime'];assert historical['oldPublicPath']==str(REPO/'tests/device/ios/adapters/chat_draft_runtime.py')
    assert historical['path']==str(PROPOSAL/'base/tests/device/ios/adapters/chat_draft_runtime.py')
    assert historical['sha256']=='c17069cae5f166091ef54f0dbed6c6e91ffbc1ae3cdf439fb07587d570cf3465'
    assert historical['currentPublicSha256']==modules['ios.adapters.chat_draft_runtime']['sha256'];keep(historical['path'],historical['sha256'])
    rows=[]
    assert len(deps['publicPhysicalDependencies'])==34
    for row in deps['publicPhysicalDependencies']:
        actual=historical['path']if row['path']==historical['oldPublicPath']else row['path']
        keep(actual,row['sha256']);rows.append(dict(historicalPath=row['path'],physicalPath=actual,sha256=row['sha256']))
    proofs=body['actualProofs'];assert [row['cases']for row in proofs]==[4,5,5]
    assert [row['freezeSha256']for row in proofs]==['f9769846d73571734393ee76d6a688893f42bbd42da5801ab41b31daafc117ef','a458eef17cfef1b367d52f2e6f56fd7f65af1b4b2c59ad10080db13a8e82243d','5dcacff63cd93f31ffbf6dc701ee098aa35c1239279fb59559a314a91b490f5b']
    for proof in proofs:packet(proof['path'],proof['freezeSha256'])
    refs=load(PUBLIC_INTEGRATION/'actual-receipt-references.json');assert len(refs)==595
    for row in refs.values():keep(row['path'],row['sha256'])
    return dict(physicalFiles=physical,publicModules=modules,historicalDependencies=rows,
        summary=dict(publicHead=body['head'],integrationFreeze=PUBLIC_INTEGRATION_FREEZE,publicFiles=5,historicalDependencies=34,
            oldRuntimePhysicalPath=historical['path'],actualDistinctPrivateCases=14,currentPublicOriginQualified=False,
            plannedPublicGroups=[4,5,5],nativeQualified=False,wholeQualified=False))

def validate(path, expected_plan_sha, expected_source_sha, expected_head, expected_group):
    assert sys.flags.no_site == 1, "Explicit no-site interpreter startup required"
    assert type(expected_head) is str and len(expected_head) == 40 and all(c in '0123456789abcdef' for c in expected_head)
    assert expected_head == head()
    assert sha(path) == expected_plan_sha
    assert sha(SOURCE / 'source-freeze.json') == expected_source_sha
    frozen = load(SOURCE / 'source-freeze.json')
    for name, row in frozen['files'].items():
        assert sha(SOURCE / name) == row['sha256']
    assert sha(PROPOSAL / 'freeze.json') == PROPOSAL_SHA
    proposal = load(PROPOSAL / 'freeze.json')
    for name, row in proposal['files'].items():
        assert sha(PROPOSAL / name) == (row if type(row) is str else row['sha256'])
    selection = selected(expected_group)
    plan = load(path)
    assert plan['status'] == 'ROOT_REVIEWED_PREPARED_UNRUN'
    assert plan['head'] == expected_head and plan['controllerSourceFreeze'] == expected_source_sha
    assert plan['currentHeadAdmission'] == dict(exactRootExpectedHead=expected_head,
        historicalControllerHead=HISTORICAL_CONTROLLER_HEAD, historicalManifestsPreserved=True)
    assert plan['proposalFreeze'] == PROPOSAL_SHA and plan['cases'] == selection
    assert plan['selectionGroup']==expected_group and plan['selectionFreeze']==SELECTION_SHA
    assert str(SELECTION/'source-freeze.json')in plan['physicalPins']
    prerequisite = require_real_prerequisites(plan['actualPrerequisites'])
    assert plan['actualPrerequisiteSummary']==prerequisite['summary']
    for name,digest in prerequisite['physicalFiles'].items():
        assert name in plan['physicalPins'] and plan['physicalPins'][name]['sha256']==digest
    # Old component/function/counter proofs are historical, not this loader's
    # current algorithm or the paired consumer composition qualification.
    current,current_pins=qualification(pin)
    assert plan['qualifiedCurrentSourceExecution']==current
    assert sha(SOURCE/'closed_import_origins.py')==HELPER_SHA
    assert all(plan['physicalPins'].get(name)==row for name,row in current_pins.items())
    historical14=require_historical_public_component()
    assert plan['historicalPublic14Component']==historical14['summary']
    assert all(plan['physicalPins'].get(name,{}).get('sha256')==digest for name,digest in historical14['physicalFiles'].items())
    baseline=load(plan['globalCustody']['baselinePath'])
    assert set(current['requiredOriginalRoots'])<=set(baseline)
    assert set(historical14['newOriginalRoots'])<=set(baseline)
    assert plan['currentPairedConsumerQualified']is False
    assert plan['inheritedPrerequisiteScope']=='HISTORICAL_FUNCTIONAL4_AND_C10C_COUNTER6_NOT_CURRENT_HELPER_AUTHORITY'
    assert len(plan['cases']) == len(set(plan['cases'])) == 1
    assert plan['seconds'] == 300 and plan['graceSeconds'] == 5
    assert plan['maxNodePerCase'] == plan['maxLiveNodes'] == plan['maxTotalNodes'] == 2
    assert plan['TDsPerExecutedCase'] == 4 and plan['loopbacksAllowed'] is False
    assert plan['source15Or17Adopted'] is False and plan['wholeQualified'] is False
    # New input schema: all external origins are explicit, never discovered
    # from the target heap or inferred as a site-package root allowlist.
    assert type(plan['thirdPartyModules']) is dict
    assert type(plan['thirdPartyNamespacePackages']) is dict
    assert type(plan['stdlibNamespacePackages']) is dict
    actual_std = Path(vars(os)['__file__']).resolve(strict=True).parent
    assert plan['stdlibRoots'] == [str(actual_std)]
    assert not any(part in ('site-packages', 'dist-packages') for part in actual_std.parts)
    python = Path(sys.executable).resolve(strict=True)
    assert plan['pythonExecutable']['path'] == str(python)
    pins = plan['physicalPins']
    for name, row in pins.items():
        assert pin(name) == row
    assert str(python) in pins and pins[str(python)] == plan['pythonExecutable']['pin']
    assert not set(plan['modules']).intersection(plan['thirdPartyModules'])
    assert not set(plan['namespacePackages']).intersection(plan['thirdPartyNamespacePackages'])
    for name, row in plan['thirdPartyModules'].items():
        assert type(name) is str and set(row) == {'path', 'sha256', 'package', 'loader'}
        actual = Path(row['path'])
        assert actual.is_absolute() and actual.resolve(strict=True) == actual and not actual.is_relative_to(REPO)
        assert str(actual) in pins and pins[str(actual)]['sha256'] == row['sha256']
        assert type(row['package']) is bool and row['loader'] in ('source', 'extension')
        if row['loader'] == 'source':
            assert actual.suffix == '.py'
    for key in ('thirdPartyNamespacePackages', 'stdlibNamespacePackages'):
        for name, roots in plan[key].items():
            assert type(name) is str and type(roots) is list and roots
            actual = [Path(root).resolve(strict=True) for root in roots]
            assert len(actual) == len(set(actual)) and all(real.is_dir() for real in actual)
            if key == 'stdlibNamespacePackages':
                assert all(real.is_relative_to(actual_std) and not any(part in ('site-packages', 'dist-packages') for part in real.parts) for real in actual)
    previous5 = REPO / '.ios-host-tmp/chat-offline-source1-initial4-controller5-exact-readonly-stdlib-source-links-code-preparation-20261104'
    assert sha(previous5 / 'source-freeze.json') == '61c14acd1997272f039fa28c74c39fe9760f7f3ec9e8cf649d13cddd2028a510'
    assert str(previous5 / 'source-freeze.json') in pins
    for name, row in load(previous5 / 'source-freeze.json')['files'].items():
        assert str(previous5 / name) in pins and sha(previous5 / name) == row['sha256']
    previous4 = REPO / '.ios-host-tmp/chat-offline-source1-initial4-controller4-current-head-initial-module-custody-code-preparation-20261104'
    assert sha(previous4 / 'source-freeze.json') == '057ef27ebd51c0507ba1cc1fdd68cda76c5751472e5acb720120b4c410027fe4'
    assert str(previous4 / 'source-freeze.json') in pins
    for name, row in load(previous4 / 'source-freeze.json')['files'].items():
        assert str(previous4 / name) in pins and sha(previous4 / name) == row['sha256']
    previous3 = REPO / '.ios-host-tmp/chat-offline-source1-initial4-controller3-package-spec-input-pin-code-preparation-20261104'
    assert sha(previous3 / 'source-freeze.json') == 'f7e427301cded1b35ba46722f4194781399aca59baa8e2d576a637f4770d14e6'
    assert str(previous3 / 'source-freeze.json') in pins
    for name, row in load(previous3 / 'source-freeze.json')['files'].items():
        assert str(previous3 / name) in pins and sha(previous3 / name) == row['sha256']
    previous2 = REPO / '.ios-host-tmp/chat-offline-source1-initial4-controller2-strict-origins-code-preparation-20261104'
    assert sha(previous2 / 'source-freeze.json') == 'a846c7039b33fae0dc427d9cdbbe19e26e72a6a6a0d9f83c0496d1e431c534e3'
    assert str(previous2 / 'source-freeze.json') in pins
    for name, row in load(previous2 / 'source-freeze.json')['files'].items():
        assert str(previous2 / name) in pins and sha(previous2 / name) == row['sha256']
    predecessor = REPO / '.ios-host-tmp/chat-offline-source1-initial4-controller1-code-preparation-20261104'
    assert sha(predecessor / 'source-freeze.json') == '4eb83643183a1953db3c1f7f2e7b093c1841b9ed5f2acb73883a314f9692aa0c'
    assert str(predecessor / 'source-freeze.json') in pins
    for name, row in load(predecessor / 'source-freeze.json')['files'].items():
        assert str(predecessor / name) in pins and sha(predecessor / name) == row['sha256']
    for directory, leaf in ((SOURCE, 'source-freeze.json'), (PROPOSAL, 'freeze.json')):
        assert str(directory / leaf) in pins
        for name in load(directory / leaf)['files']:
            assert str(directory / name) in pins
    deps = load(PROPOSAL / 'DEPENDENCIES.json')
    overlays = {row['module']: row for row in deps['overlays']}
    assert len(overlays) == 5
    integration=require_public_integration(plan['publicIntegration'],expected_head)
    assert plan['publicIntegrationSummary']==integration['summary']
    for name,digest in integration['physicalFiles'].items():
        assert name in pins and pins[name]['sha256']==digest
    assert set(integration['publicModules'])==set(overlays)
    for name,row in integration['publicModules'].items():assert plan['modules'][name]==row
    for name,row in plan['modules'].items():
        actual=Path(row['path']);assert str(actual)in pins and sha(actual)==row['sha256']
        assert actual.is_relative_to(REPO)and actual.suffix=='.py'
        if actual.is_relative_to(REPO/'.ios-host-tmp'):
            assert name in PAIRED_MODULES and row==PAIRED_MODULES[name]
    assert plan['pairedSourceFreeze']==PAIRED_SHA and plan['pairedModules']==PAIRED_MODULES
    for name,row in PAIRED_MODULES.items():assert plan['modules'][name]==row and pin(row['path'])==plan['physicalPins'][row['path']]
    assert len(integration['historicalDependencies'])==34
    for row in integration['historicalDependencies']:
        assert row['physicalPath']in pins and sha(row['physicalPath'])==row['sha256']
    for name, roots in plan['namespacePackages'].items():
        assert name not in plan['modules'] and type(roots) is list and roots
        for root in roots:
            root = Path(root)
            assert root.is_relative_to(REPO) and root.is_absolute() and root.resolve(strict=True) == root and root.is_dir()
    public = load(plan['publicNamespace']['path'])
    assert plan['publicNamespace']['path'] in pins
    assert sha(plan['publicNamespace']['path']) == plan['publicNamespace']['sha256']
    expected_paths = set(public['paths'])
    actual_paths = set()
    for root in public['roots']:
        root = Path(root)
        assert root.is_relative_to(REPO) and not root.is_relative_to(REPO / '.ios-host-tmp')
        actual_paths.update(str(p) for p in (root, *root.rglob('*')))
    assert actual_paths == expected_paths
    for relative in ('nodeScript', 'nodeModel'):
        row = plan[relative]
        assert row['path'] in pins and pin(row['path']) == row['pin']
    assert plan['nodeScript']['path'] == str(REPO / 'tests/device/ios/self_tests/chat_message_script_domain.js')
    assert plan['nodeModel']['path'] == str(REPO / 'tests/device/ios/self_tests/chat_message_script_domain.py')
    node = Path(plan['node']['path'])
    assert node.is_absolute() and node.resolve(strict=True) == node
    assert str(node) in pins and pin(node) == plan['node']['pin']
    return plan


PAIRED_SOURCE=REPO/'.ios-host-tmp/chat-paired-offline-history-continuation-source2-exact-budget-boundaries-private-20261104'
PAIRED_SHA='fb15ea54f3dde153b47c6ff2b609180098dee853b9af01101ad9d1f60a2ac65e'
PAIRED_MODULES={name:dict(path=str(PAIRED_SOURCE/(name+'.py')),sha256=sha(PAIRED_SOURCE/(name+'.py')),package=False)for name in(
    'chat_paired_offline_continuation','chat_paired_offline_history_fixture','test_chat_paired_offline_history_continuation')}
# The map is independently checked against the exact frozen source before use.
assert sha(PAIRED_SOURCE/'source-freeze.json')==PAIRED_SHA
assert all(load(PAIRED_SOURCE/'source-freeze.json')['files'][name+'.py']['sha256']==row['sha256']for name,row in PAIRED_MODULES.items())
