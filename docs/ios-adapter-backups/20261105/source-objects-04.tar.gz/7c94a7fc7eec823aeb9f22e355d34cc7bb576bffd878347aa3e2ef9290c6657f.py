"""Exact six-or-two SDK host constructors; no authenticated/device authority."""
from pathlib import Path
from metadata_reader import pin
from host_common import head
from closed_import_origins import ClosedOrigins
from source_execution_readiness import qualification
from project_namespace_admission import project_namespace_admission
from class_cleanup_custody import ClassCleanupCustody
from sdk_method_custody import SdkMethodCustody
from sdk_socket_custody import SdkSocketCustody
from sdk_delegate_admission import select_sdk_delegates
import builtins,ctypes,hashlib,importlib.abc,importlib.util,io,json,os,signal,socket,stat,sys,tempfile,threading,traceback,unittest

HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert sys.flags.no_site==1 and sys.dont_write_bytecode and len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and pin(INPUT)['sha256']==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['status']=='PRIVATE_ORIGINAL_SDK8_GROUP_UNRUN'
assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)and head()==plan['actualPublicHead']
recipe=json.loads((HERE/'fixed-eight-groups.json').read_text())['groups'][plan['groupName']]
assert recipe==plan['resourceRecipe']and recipe['caseIds']==plan['cases']and len(plan['cases'])in(2,6)
assert plan['wallSeconds']==30 and plan['killGraceSeconds']==5
assert plan['authenticatedSourceAdmission']is plan['providerAdmission']is plan['consumerAdmission']is None
assert plan['hostSDKPythonExecutionExpected']is True and plan['SDKInstalled']is False
assert plan['caseChildProcesses']==plan['caseTDs']==plan['deviceActionsRequested']==plan['remoteProtocolActionsRequested']==0
assert project_namespace_admission(plan['declaredProjectAliases'],[str(REPO/'tests/device')])==(plan['modules'],plan['namespaces'],plan['projectAliasAdmission'])
actual_sdk_delegates,actual_sdk_selection=select_sdk_delegates(Path(plan['sdkSourceRoot']),plan['sdkSourceCopies'])
assert actual_sdk_delegates==plan['declaredSDKAliases']and actual_sdk_selection==plan['sdkModuleSelection']
sdk_admitted,sdk_namespaces,sdk_aliases=project_namespace_admission(plan['declaredSDKAliases'],[plan['sdkSourceRoot']])
assert sdk_aliases==plan['sdkAliasAdmission']and sdk_namespaces==plan['thirdPartyNamespacePackages']
for name,row in json.loads((HERE/'third-party-source-declarations.json').read_text()).items():
    sdk_admitted[name]=dict(path=row['path'],sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
assert sdk_admitted==plan['thirdPartyModules']
assert plan['subjectHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
assert pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
current,current_pins=qualification(pin);assert current==plan['currentSourceExecution']
assert all(plan['sourceAndBinaryPins'].get(n)==r for n,r in current_pins.items())
assert all(pin(n)==r for n,r in plan['sourceAndBinaryPins'].items())


def fds():
    rows={}
    for p in Path('/proc/self/fd').iterdir():
        try:s=p.stat();rows[p.name]=dict(target=os.readlink(p),device=s.st_dev,inode=s.st_ino,mode=s.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return rows


def children():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()


def census(root):
    rows={}
    for path in(root,*sorted(root.rglob('*'))):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):row=dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,namespace=sorted(x.name for x in path.iterdir()))
        else:row=pin(path)
        rows[str(path.relative_to(root))]=row
    return rows


original_meta=tuple(sys.meta_path);original_path=tuple(sys.path)
bootstrap={'metadata_reader','host_common','closed_import_origins','source_execution_readiness','project_namespace_admission','class_cleanup_custody','sdk_method_custody','sdk_socket_custody','sdk_delegate_admission'}
assert not any(n=='pymobiledevice3'or n.startswith(('pymobiledevice3.','pmd_pytcp.','pmd_net_addr.'))for n in sys.modules)
origin_plan=plan['originPlan'];origins=ClosedOrigins(origin_plan,HERE,REPO,pin)
origin_before=origins.snapshot('before-real-host-sdk-imports');loaded={}


class AfterProjectLoader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name,self.delegate=name,delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module);actual=vars(module)['__file__']
        assert pin(actual)==plan['sourceAndBinaryPins'][actual];loaded[self.name]=actual


class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name in plan['projectAliasAdmission']['unadmittedAliases']or name in plan['sdkAliasAdmission']['unadmittedAliases']:
            raise ImportError('Physical alias remains unadmitted: '+name)
        row=plan['modules'].get(name)
        if row is not None:
            if name in bootstrap:return None
            spec=origins.file_spec(name,dict(row,loader='source'),'project');spec.loader=AfterProjectLoader(name,spec.loader);return spec
        if name in plan['namespaces']:
            roots=plan['namespaces'][name];origins.namespaces(name,roots,roots,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots;return spec
        spec=origins.remaining_spec(name,path)
        row=plan['thirdPartyModules'].get(name)
        if row is not None and Path(row['path']).is_relative_to(Path(plan['sdkSourceRoot'])):
            sdk_attempts.append(dict(name=name,path=row['path'],sourceSha256=row['sha256'],delegateIssued=True,executionNotYetEstablished=True))
        return spec


finder=Finder();sys.meta_path.insert(0,finder)
# Normal copied distribution metadata is real data. Finder still closes every
# import to pinned project/SDK/third-party/stdlib origins, never path fallback.
sdk_root=Path(plan['sdkSourceRoot']);assert sdk_root==HERE/'sdk-source-view'
sys.path[:]=[str(sdk_root)]+[x for x in sys.path if x and not Path(x).resolve().is_relative_to(REPO)]
RECEIPTS=HERE/'child-receipts';TOYS=HERE/'own-toys'
assert RECEIPTS.is_dir()and TOYS.is_dir()and not any(RECEIPTS.iterdir())and not any(TOYS.iterdir())
from owned_write_boundary import OwnedWrites
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={n:getattr(os,n)for n in ports if hasattr(os,n)};original_io=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
original_profile=sys.getprofile();assert original_profile is None
original_cleanup=unittest.TestCase.doCleanups;original_td=tempfile.TemporaryDirectory
pairs=SdkSocketCustody(recipe)
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):
    path=Path(os.readlink('/proc/self/fd/'+str(fd)));assert path.resolve(strict=True)==path and path.is_relative_to(HERE);protected.append(path)
boundary=OwnedWrites(HERE,protected=protected);closed=False;tail_births={};tail_used=set()


def tail_write(path,value):
    assert closed and path in tail_births and path not in tail_used and pin(path)==tail_births[path]
    assert all(getattr(os,n)is value for n,value in original_ports.items())and original_io==(io.open,builtins.open)and original_dup==(os.dup,os.dup2)
    with original_io[0](path,'w',encoding='utf-8')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    tail_used.add(path)


tail_function,tail_code,tail_globals=tail_write,tail_write.__code__,tail_write.__globals__


def audit(event,args):
    if event.startswith('socket.'):
        if pairs.accept(event,args,sys._getframe(1)):return
        raise RuntimeError('Only exact standard selfpipe/declared local-service socketpair is admitted')
    if event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('No device/native query, process, external compiler or signal action')
    if event=='open':
        target,mode,flags=args
        writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
        if writing and type(target)in(str,bytes)and Path(os.fsdecode(target)).is_relative_to(sdk_root):
            raise RuntimeError('SDK source definition view is immutable input')
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if not relevant:return
    if closed:
        if event=='open':
            target,mode,flags=args;writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
            if not writing:return
            caller=sys._getframe(1);path=Path(target)if type(target)in(str,bytes)else None
            assert path in tail_births and path not in tail_used and mode=='w'and flags==(os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC)
            assert caller.f_code is tail_code and caller.f_globals is tail_globals and caller.f_locals.get('path')==path
            assert tail_function is tail_write and tail_write.__code__ is tail_code and pin(path)==tail_births[path]
            return
        raise RuntimeError('Mutation after actual original port restoration')
    boundary.audit(event,args,sys._getframe(1))


boundary.install();sys.addaudithook(audit)
cleanup_calls=[];case_receipts=[];selected=[];secondary=[];definition=None;class_cleanup=None;result=None;fatal=None
class_restore=None;pair_restore=None;pair_report=None;origin_after=None;source_ok=False;definition_ok=False;sdk_rows={};required_rows={};sdk_completed={};sdk_attempts=[];passed=False
monitor=sys.monitoring;monitor_ports=tuple((n,getattr(monitor,n))for n in('get_tool','get_events','get_local_events','set_events','set_local_events','register_callback','use_tool_id','free_tool_id'))


def monitor_snapshot():
    assert sys.monitoring is monitor and all(getattr(monitor,n)is fn for n,fn in monitor_ports)
    return tuple((monitor.get_tool(i),monitor.get_events(i),monitor.get_local_events(i,socket.socketpair.__code__))for i in range(6))


def save(name,value):
    path=RECEIPTS/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')


def record_secondary(phase):secondary.append(dict(phase=phase,traceback=traceback.format_exc()))


def methods_ok():
    assert definition is not None and(class_cleanup is None or class_cleanup.tables is definition.class_tables)
    return definition.check()


def observed_cleanup(case):
    before=len(case._cleanups);outcome=case._outcome;actual=None if outcome is None else outcome.result
    errors=0 if actual is None else len(actual.errors);failures=0 if actual is None else len(actual.failures);returned=None;raised=None
    try:returned=original_cleanup(case);return returned
    except BaseException as error:raised=type(error).__module__+'.'+type(error).__qualname__;raise
    finally:
        now=None if case._outcome is None else case._outcome.result;same=now is actual
        cleanup_calls.append(dict(id=case.id(),pendingBefore=before,remaining=len(case._cleanups),originalReturned=returned,originalRaised=raised,
            callbackErrorDeltaEstablished=same and actual is not None,newCallbackErrors=[]if not same or actual is None else[x for unused,x in actual.errors[errors:]],newCallbackFailures=[]if not same or actual is None else[x for unused,x in actual.failures[failures:]]))


def no_case_td(*args,**kwargs):raise RuntimeError('These exact SDK controls declare zero TemporaryDirectory births')


class Result(unittest.TextTestResult):
    def startTest(self,test):
        if pairs.case is not None:pairs.finish_case()
        class_cleanup.bind_result(self,test);assert methods_ok();origins.snapshot('before-'+test.id());pairs.bind(test)
        self.before=(fds(),tuple(threading.enumerate()),children(),len(cleanup_calls),monitor_snapshot())
        super().startTest(test)
    def stopTest(self,test):
        try:
            fd,threads,kernel,start,tools=self.before;assert methods_ok();origins.snapshot('after-stop-'+test.id())
            row=dict(id=test.id(),remainingStandardCleanups=len(test._cleanups),originalMethodsUnchanged=True,monitorMasksSlotsUnchanged=monitor_snapshot()==tools,
                standardAsyncRunnerCloseStillPending=True,fdEqualDeferredUntilRealRunnerClose=True,threadsUnchanged=tuple(threading.enumerate())==threads,kernelChildrenUnchanged=children()==kernel,nestedOriginalCleanups=cleanup_calls[start:])
            case_receipts.append(row);save('standard-case-'+str(len(case_receipts))+'.json',row)
        except BaseException:record_secondary('original-stop-observation')
        finally:super().stopTest(test)


original_term=signal.getsignal(signal.SIGTERM)
def interrupted(*unused):raise KeyboardInterrupt('Original fixed30-second SDK host constructor boundary')
signal.signal(signal.SIGTERM,interrupted)
fd_before=fds();thread_before=tuple(threading.enumerate());child_before=children();tool_before=monitor_snapshot()
try:
    # Start native-pair refusal BEFORE actual SDK imports: an unselected raw
    # pair call is refused at the real C-call boundary before endpoint birth.
    pairs.start()
    for name in plan['requiredExecutedModules']:__import__(name)
    unittest.TestCase.doCleanups=observed_cleanup;tempfile.TemporaryDirectory=no_case_td
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(value):
        if type(value)is unittest.TestSuite:
            for child in value:yield from flatten(child)
        else:yield value
    selected=list(flatten(suite));ids=[case.id()for case in selected]
    save('actual-selection.json',dict(ids=ids,loaderErrors=loader.errors));assert not loader.errors and ids==plan['cases']
    definition=SdkMethodCustody(plan,pin)
    class_cleanup=ClassCleanupCustody(definition.class_tables,suite,selected,Result,Result.startTest,save)
    class_cleanup.install();assert methods_ok()
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    cleanup_rows=[]
    for case in selected:
        old=case._outcome;pending=len(case._cleanups);drain=unittest.TestResult();returned=True;raised=None
        try:
            if pending:case._outcome=unittest.case._Outcome(drain);returned=observed_cleanup(case)
        except BaseException:returned=False;raised=traceback.format_exc();record_secondary('pending-original-cleanup')
        finally:case._outcome=old
        cleanup_rows.append(dict(id=case.id(),pendingBeforeOuter=pending,remaining=len(case._cleanups),originalReturned=returned,raised=raised,errors=[x for unused,x in drain.errors],failures=[x for unused,x in drain.failures]))
    try:
        if pairs.case is not None:pairs.finish_case()
    except BaseException:record_secondary('last-original-runner-close')
    try:pair_restore=pairs.stop()
    except BaseException:record_secondary('socket-tool-original-restoration')
    for phase,operation in(('socket-report',pairs.report),('definitions',methods_ok),('origins-after',lambda:origins.snapshot('after-sdk-host-cases-and-cleanups'))):
        try:
            value=operation()
            if phase=='socket-report':pair_report=value
            elif phase=='definitions':definition_ok=value is True
            else:origin_after=value
        except BaseException:record_secondary(phase)
    try:
        actual_sdk_files={str(path.relative_to(sdk_root))for path in sdk_root.rglob('*')if path.is_file()}
        assert actual_sdk_files==set(plan['sdkSourceCopies'])
        assert all(pin(n)==r for n,r in plan['sourceAndBinaryPins'].items())and pin(INPUT)['sha256']==sys.argv[2]and head()==plan['actualPublicHead'];source_ok=True
    except BaseException:record_secondary('actual-source-input-head')
    # The helper records only completed real exec calls. A delegated import
    # attempt alone is NOT execution proof, and a partial import never means
    # zero SDK code execution. Retain these independently from required rows.
    try:
        for name,(module,path,digest,size)in tuple(origins.python_executions.items()):
            if path.is_relative_to(sdk_root):
                sdk_completed[name]=dict(path=str(path),sourceSha256=digest,sourceBytes=size,
                    completedFreshSourceExecRecorded=True,currentReceiverIsHeld=sys.modules.get(name)is module)
    except BaseException:record_secondary('completed-host-sdk-source-execution-observation')
    try:
        for name in plan['requiredExecutedModules']:
            module=sys.modules[name];expected=plan['modules'].get(name,plan['thirdPartyModules'].get(name));actual=vars(module)['__file__']
            assert actual==expected['path']and pin(actual)['sha256']==expected['sha256']
            execution=origins.execution_row(name,module,Path(actual));assert execution['kind']=='fresh-pinned-python-source-bytes'
            required_rows[name]=dict(actualModuleFile=actual,actualSourceExecution=execution,physicalPin=pin(actual))
        assert origin_after is not None
        for name,row in origin_after['modules'].items():
            actual=row.get('origin')
            if type(actual)is str and Path(actual).is_relative_to(sdk_root):sdk_rows[name]=row
        assert sdk_rows and any(name.startswith('pymobiledevice3.')and row.get('actualExecution',{}).get('kind')=='fresh-pinned-python-source-bytes'for name,row in sdk_rows.items())
    except BaseException:record_secondary('actual-host-sdk-execution-origin')
    class_summary=None
    try:
        if class_cleanup is not None:class_summary=class_cleanup.summary()
    except BaseException:record_secondary('actual-class-cleanup-summary')
    try:
        if class_cleanup is not None:class_restore=class_cleanup.restore()
    except BaseException:record_secondary('actual-class-cleanup-original-restoration')
    for owner,name,installed,original in((tempfile,'TemporaryDirectory',no_case_td,original_td),(unittest.TestCase,'doCleanups',observed_cleanup,original_cleanup)):
        try:
            current=getattr(owner,name)
            if current is installed:setattr(owner,name,original)
            else:assert current is original,'Foreign cleanup/TD port is never overwritten'
        except BaseException:record_secondary('original-cleanup-TD-port-restoration')
    try:
        current=signal.getsignal(signal.SIGTERM)
        if current is interrupted:signal.signal(signal.SIGTERM,original_term)
        else:assert current is original_term,'Foreign signal handler is never overwritten'
    except BaseException:record_secondary('original-TERM-restoration')
    fd_ok=fds()==fd_before;thread_ok=tuple(threading.enumerate())==thread_before;child_ok=children()==child_before
    tools_ok=False
    try:tools_ok=monitor_snapshot()==tool_before and sys.getprofile()is original_profile
    except BaseException:record_secondary('all-original-monitor-slots-and-masks')
    cleanup_ok=all(r['remaining']==0 and r['originalReturned']is True and not r['errors']and not r['failures']for r in cleanup_rows)
    cleanup_ok=cleanup_ok and len(cleanup_calls)==len(plan['cases'])and all(r['originalReturned']is True and r['originalRaised']is None and r['remaining']==0 and not r['newCallbackErrors']and not r['newCallbackFailures']for r in cleanup_calls)
    passed=fatal is None and not secondary and result is not None and result.testsRun==len(plan['cases'])and result.wasSuccessful()and not result.skipped
    passed=passed and cleanup_ok and source_ok and definition_ok and len(required_rows)==len(plan['requiredExecutedModules'])and bool(sdk_rows)
    passed=passed and pair_restore is not None and pair_restore['restored']and pair_report is not None and tools_ok and fd_ok and thread_ok and child_ok
    passed=passed and class_summary is not None and class_summary['allActualOriginalCallsAccepted']and class_summary['actualOriginalClassCleanupCalls']==1
    passed=passed and class_restore is not None and class_restore['originalDescriptorRestored']and len(case_receipts)==len(plan['cases'])
    report=dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=None if result is None else result.testsRun,fatal=fatal,secondary=secondary,
        actualCaseReceipts=case_receipts,cleanupEstablished=cleanup_ok,standardCleanups=cleanup_rows,originalCleanupCalls=cleanup_calls,
        actualHostSDKCodeExecuted=True if sdk_completed else None,actualHostSDKExecutionUnknown=not bool(sdk_completed),actualSDKCompletedFreshSourceExecutions=sdk_completed,actualSDKSourceDelegatesIssued=sdk_attempts,actualHostSDKLoadedModules=sdk_rows,actualRequiredExecutedOrigins=required_rows,
        SDKInstalled=False,SDKAuthenticationQualified=False,providerQualified=False,consumerAdmission=None,deviceActionsRequested=0,remoteProtocolActionsRequested=0,
        casePythonChildExecutions=0,NodeExecutions=0,fdUnchanged=fd_ok,threadsUnchanged=thread_ok,kernelChildrenUnchanged=child_ok,pinsUnchanged=source_ok,toolsRestored=tools_ok,nativeQualified=False,wholeQualified=False)
    for name,value in(('actual-origins-before.json',origin_before),('actual-origins-after.json',origin_after),('actual-sdk-host-execution.json',dict(required=required_rows,SDK=sdk_rows,completedFreshSourceExecutions=sdk_completed,sourceDelegatesIssued=sdk_attempts,actualHostSDKCodeExecuted=True if sdk_completed else None)),
        ('actual-socket-custody.json',pair_report),('actual-socket-tool-restoration.json',pair_restore),('actual-class-cleanup.json',class_summary),('actual-class-restoration.json',class_restore),('report.json',report)):
        try:save(name,value)
        except BaseException:passed=False;record_secondary('report-'+name);print(traceback.format_exc(),flush=True)
    tail=RECEIPTS/'actual-port-restoration.json'
    try:
        fd=os.open(tail,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        try:assert stat.S_IMODE(os.fstat(fd).st_mode)==0o600
        finally:os.close(fd)
        tail_births[tail]=pin(tail)
    except BaseException:passed=False;record_secondary('original-tail-birth')
    restored=False;dup_ok=False
    try:boundary.restore()
    except BaseException:passed=False;record_secondary('original-27-port-restore')
    try:
        restored=all(getattr(os,n)is value for n,value in original_ports.items())and original_io==(io.open,builtins.open)
        dup_ok=original_dup==(os.dup,os.dup2);boundary.close();closed=True
    except BaseException:passed=False;record_secondary('actual-control-fd-close')
    sys.meta_path[:]=original_meta;sys.path[:]=original_path
    if closed and tail in tail_births:
        try:tail_write(tail,dict(restored=restored,count=len(original_ports),controlDescriptors=sorted(boundary.control_fds),dupPortsRestored=dup_ok,toolsRestored=tools_ok,builtinsCioRestored=original_io==(io.open,builtins.open),actualC10dHelperSha256=plan['subjectHelperSha256'],secondary=secondary))
        except BaseException:passed=False;print(traceback.format_exc(),flush=True)
raise SystemExit(0 if passed and restored and dup_ok and tools_ok else 1)
