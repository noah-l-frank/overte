"""Derived two-copy sample windows from untouched passive Actor originals.

This proves bounded PCM structure only. A once-owned actual cue and original
Primary capturing/playing causal joins remain mandatory before acoustic use.
Qt dequeue timestamps never supply ADC sample age or physical qualification.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import array,bisect,hashlib,io,math,sys,wave
from adapters.native_feature_observation import need
from feature_journeys.fixtures import challenge
from voice_peer.voice_signal import features,sequence,profile_parameters,SYMBOLS,WINDOW,HOP
from ios.adapters.audio_passive_capture_source import original_frame

VERSION=1
PROFILE='recorded-preview-v1'
MIN_QUIET=.5


def digest(data):return hashlib.sha256(data).hexdigest()


def copies(pcm,rate,expected):
    """Use the original detector's frequency/coverage policy on each channel."""
    _lead,tone,cell,_duration,_prefix=profile_parameters(PROFILE)
    observed=features(pcm,rate);times=[t for t,_label in observed];labels=[label for _t,label in observed]
    candidates=[];span=(SYMBOLS-1)*cell+tone;duration=len(pcm)/rate
    for stamp,_label in observed:
        offset=stamp-WINDOW/2
        if offset+span>duration:break
        coverage=[]
        for index,symbol in enumerate(expected):
            lo=bisect.bisect_left(times,offset+index*cell+WINDOW-1e-6)
            hi=bisect.bisect_right(times,offset+index*cell+tone-WINDOW+1e-6)
            values=labels[lo:hi];coverage.append(sum(value==symbol for value in values)/max(1,len(values)))
        average=sum(coverage)/SYMBOLS
        if min(coverage)>=.65 and average>=.85:
            candidates.append(dict(offset=offset,score=min(coverage)*.5+average*.5,coverage=coverage))
    groups=[]
    for candidate in candidates:
        if not groups or candidate['offset']-groups[-1][-1]['offset']>HOP*1.5:groups.append([])
        groups[-1].append(candidate)
    result=[]
    for group in groups:
        best=max(row['score'] for row in group);peaks=[row for row in group if abs(row['score']-best)<1e-9]
        result.append(peaks[len(peaks)//2])
    return result


def fragments(rows,begin,end,pcm):
    result=[]
    for row in rows:
        low=max(begin,row['offset']);high=min(end,row['offset']+row['bytes'])
        if low>=high:continue
        result.append(dict(originSequence=row['sequence'],generation=row['generation'],routeRevision=row['routeRevision'],
            originalOffset=row['offset'],originalBytes=row['bytes'],readBytes=row['readBytes'],readSha256=row['readSha256'],
            originalSha256=row['sha256'],fragmentOffset=low,fragmentBytes=high-low,fragmentSha256=digest(pcm[low:high])))
    need(sum(row['fragmentBytes'] for row in result)==end-begin);return result


def analyze_native(raw_capture,wav,command,pid,run,ticket):
    native=original_frame(raw_capture,wav,command,pid)
    need(native['runId']==run and native['role']=='actor')
    source=native['source'];rate=source['sampleRate'];channels=source['channels'];frame=channels*2
    with wave.open(io.BytesIO(wav),'rb') as reader:pcm=reader.readframes(reader.getnframes())
    data=array.array('h');data.frombytes(pcm)
    if sys.byteorder!='little':data.byteswap()
    expected=sequence(challenge(run,ticket).hex(),profile=PROFILE);lead,tone,cell,duration,_prefix=profile_parameters(PROFILE)
    span=(SYMBOLS-1)*cell+tone;matches=[]
    for channel in range(channels):
        candidate=copies(data[channel::channels],rate,expected)
        for first in candidate:
            for second in candidate:
                quiet_low=math.ceil((first['offset']+span+WINDOW)*rate)
                quiet_high=math.floor((second['offset']-WINDOW)*rate)
                if quiet_high-quiet_low<math.ceil(MIN_QUIET*rate):continue
                first_begin=round((first['offset']-lead)*rate);second_begin=round((second['offset']-lead)*rate)
                count=round(duration*rate)
                if min(first_begin,second_begin)<0 or max(first_begin,second_begin)+count>len(data)//channels:continue
                quiet=data[quiet_low*channels:quiet_high*channels]
                rms=math.sqrt(sum(sample*sample for sample in quiet)/len(quiet))/32768
                quiet_db=20*math.log10(max(rms,1e-9))
                if quiet_db>=-55:continue
                core_low=round((first['offset']+WINDOW)*rate)*frame
                core_high=round((first['offset']+span-WINDOW)*rate)*frame;core=pcm[core_low:core_high]
                search_low=max(0,round((second['offset']-.1)*rate))*frame
                search_high=min(len(pcm),round((second['offset']+span+.1)*rate)*frame)
                position=pcm.find(core,search_low,search_high)
                duplicate=False
                while position>=0:
                    if position%frame==0:duplicate=True;break
                    position=pcm.find(core,position+1,search_high)
                if duplicate:continue
                # Require each complete derived window to remain unclipped,
                # matching the existing present-signal policy; no channel mix.
                windows=[];valid=True
                for current,begin in ((first,first_begin),(second,second_begin)):
                    samples=data[begin*channels:(begin+count)*channels]
                    clipped=sum(abs(sample)>=32760 for sample in samples)/len(samples)
                    if clipped>=.01:valid=False;break
                    low,high=begin*frame,(begin+count)*frame
                    windows.append(dict(beginFrame=begin,endFrame=begin+count,firstToneFrame=round(current['offset']*rate),
                        symbolCoverage=current['coverage'],pcmSha256=digest(pcm[low:high]),
                        originFragments=fragments(source['rows'],low,high,pcm)))
                if valid:matches.append(dict(matchedChannel=channel,copies=windows,quietBeginFrame=quiet_low,quietEndFrame=quiet_high,quietRmsDbFS=quiet_db))
    need(matches)
    # Stable deterministic projection, never a new original capture. Prefer the
    # first chronological genuine pair; extra matches are retained as a count.
    matches.sort(key=lambda row:(row['copies'][0]['firstToneFrame'],row['copies'][1]['firstToneFrame'],row['matchedChannel']))
    chosen=matches[0]
    return dict(iosAudioTwoCopyWindowVersion=VERSION,runId=run,ticket=ticket,leaseId=native['leaseId'],instance=native['instance'],
        processId=pid,profile=PROFILE,wholeWavSha256=digest(wav),originalCaptureSha256=digest(raw_capture),
        sampleRate=rate,channels=channels,totalFrames=len(pcm)//frame,completePairCandidates=len(matches),**chosen,
        twoCompleteCopies=True,duplicateByteReplayAccepted=False,dequeueClockUsedAsADCAge=False,
        physicalADCQualified=False,acousticQualified=False,peerQualified=False,wholeQualified=False,
        unmetCausalRequirements=['independently-once-owned-actual-unique-cue','original-primary-capturing-to-playing-join'])


def from_actor(actor,ticket):
    """Consume the real typed owner/ledger originals under its existing lock."""
    from ios.adapters.audio_passive_actor import IOSAudioPassiveActor,lease_id
    need(isinstance(actor,IOSAudioPassiveActor))
    with actor.lock.held():
        current=actor.archive(lease_id(actor.run,ticket));need(current is not None and current[1] is not None)
        owner=current[1];birth=actor.birth(owner,ticket);need(owner.state['snapshot'] is not None and owner.state['absence'] is not None)
        owner.retired();snapshot=owner.proof(owner.state['snapshot']);value=owner.snapshot()
        raw=owner.assembled(snapshot['chunks']['capture'],'capture',snapshot['selection'],owner.state['snapshot'])
        derived=analyze_native(raw,value['wav'],owner.state['capture'],owner.pid,actor.run,ticket)
        return derived|dict(birthReference=birth['reference'],snapshotReference=owner.state['snapshot'],absenceReference=owner.state['absence'])
