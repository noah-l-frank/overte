"""Root-only immutable one-case execution, fixed180+5 wall/process boundary."""
import json,os,stat,subprocess,sys,time,traceback
from pathlib import Path
from guard import pin,sources,first_pass,moving_qualified_pass
from global_original_corpus import guard as global_originals
from moving_owned_identity import process
from moving_process_observation import NoPositiveExecutable,observe_owned_executable,require_actual_process_observation_utility
from moving_kernel_qualification import require_actual_utility
PREP=Path(__file__).resolve().parent;HERE=Path(sys.argv[1]).resolve()
plan=json.loads((PREP/'plan.json').read_text());REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and str(REPO)==plan['repositoryRoot']
def target(p):
    p=Path(p);assert p.resolve().is_relative_to(REPO);return p
assert HERE.parent==PREP and HERE.name in ('first1',)and Path.cwd()==REPO and sys.dont_write_bytecode
sources(HERE);first_pass(HERE)
require_actual_utility(plan)
require_actual_process_observation_utility(plan) # New observer remains independently UNRUN/closed.
selection=json.loads((HERE/'case.json').read_text());wall=selection['wallSeconds'];assert wall==180 and selection['killAfterSeconds']==5
out=HERE/'run';target(out).mkdir(mode=0o700,exist_ok=False)
def save(name,value):
    fd=os.open(target(out/name),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def remaining(bound):
    rows=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        row=process(int(path.name))
        if row is not None and(row['sid']==bound['pid']or row['pgid']==bound['pid']):rows.append(row)
    return rows
def census():
    value={}
    for root in(HERE/'retained',HERE/'bindings'):
        if root.exists():value.update({str(p):pin(p)for p in(root,*sorted(root.rglob('*')))})
    return value
before=sources(HERE);save('source-before.json',before)
prior=global_originals();save('global-originals-before.json',prior)
command=['timeout','--signal=TERM','--kill-after=5s',str(wall)+'s',sys.executable,'-B','-S',str(PREP/'run-selected.py')]
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',LIFECYCLE_WHOLE_STAGE=str(HERE))
started=time.monotonic()
with target(out/'test.log').open('x')as log:
    task=subprocess.Popen(command,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    bound=None;binding_established=False;observed={};node_births={};node_problems=[]
    no_positive=[];observation_errors=[];first_observation_error=[];original_failure=None;original_failure_trace=None
    def record_error(stage,error,row=None,events=()):
        if not first_observation_error:first_observation_error.append((error,error.__traceback__))
        observation_errors.append(dict(stage=stage,identity=row,observations=list(events),
            originalExceptionType=type(error).__module__+'.'+type(error).__qualname__,originalTraceback=traceback.format_exc()))
    try:
        bound=process(task.pid);assert bound is not None and bound['sid']==bound['pgid']==task.pid
        binding_established=True
        save('process-binding.json',dict(task=bound,supervisor=process(os.getpid()),command=command))
        while True:
            # A discovery/executable error is explicit nongreen data. It never
            # abandons the genuine existing timeout child or grants signals.
            try:rows=remaining(bound)
            except Exception as error:record_error('own-session-discovery',error);rows=[]
            for row in rows:
                events=[]
                try:
                    key=str(row['pid']);prior_identity=observed.setdefault(key,row)
                    if prior_identity!=row:
                        node_problems.append(dict(kind='own-session-identity-change',before=prior_identity,after=row))
                        continue
                    actual=observe_owned_executable(row,bound,events=events)
                    if type(actual)is NoPositiveExecutable:
                        no_positive.append(actual.record);continue # NEVER a process absence claim.
                    if actual['executable']==plan['nodeExecutable']['path']:
                        assert pin(Path(actual['executable']))==plan['nodeExecutable']['pin']
                        assert actual['command']==['node',plan['movingNodeScript']['path']]
                        birth=actual
                        if key in node_births:assert node_births[key]==birth
                        else:node_births[key]=birth
                except Exception as error:record_error('owned-executable-observation',error,row,events)
            code=task.poll()
            if code is not None:break
            time.sleep(.025)
    except BaseException as error:
        original_failure=error;original_failure_trace=error.__traceback__
        record_error('original-supervisor-failure',error)
    finally:
        # This is the SAME real GNU timeout Popen created above. Its existing
        # 180+5 boundary remains the only signal authority, even after errors.
        # No new kill/terminate/rebind or extended timeout is introduced.
        code=task.wait()
        save('process-observation-receipt.json',dict(noPositiveExecutable=no_positive,errors=observation_errors,
            noPositiveNeverClaimsAbsence=True,actualTimeoutChildWaitReturned=True,actualChildReturnCode=code,
            originalBindingEstablished=binding_established,newSignalAuthority=False))
    save('moving-node-kernel-births.json',dict(nodes=list(node_births.values()),observedOwnSession=list(observed.values()),problems=node_problems,
        noPositiveExecutableObservations=no_positive,observationErrors=observation_errors))
if not binding_established:
    # No invented session baseline or quiet/global post census is permitted.
    if original_failure is not None:raise original_failure.with_traceback(original_failure_trace)
    raise RuntimeError('Original child binding not established; no quiet close')

left=remaining(bound);assert not left,'Owned process remains; originals must not yet be censused'
after=sources(HERE);save('source-after.json',after)
first_pass(HERE) # Recheck every actually qualified sibling corpus after drain.
prior_first=global_originals();save('global-originals-first.json',prior_first)
first_pass(HERE) # Second complete predecessor original census; no writer exception.
prior_second=global_originals();save('global-originals-second.json',prior_second);assert prior==prior_first==prior_second
first=census();save('originals-first.json',first)
assert not remaining(bound);second=census();save('originals-second.json',second)
value=dict(exitCode=code,seconds=time.monotonic()-started,sourcePins=len(before),allPinsEqual=before==after,
    retainedOriginalsUnchanged=first==second,bindingsIncludedInBothOwnCensuses=str(HERE/'bindings')in first and str(HERE/'bindings')in second,globalOriginalsUnchanged=prior==prior_first==prior_second,globalOriginalRoots=len(prior),remainingOwnedProcesses=remaining(bound),
    retainedFiles=sum(stat.S_ISREG(row['stat'][2])for row in second.values()),nodeKernelBirths=len(node_births),nodeIdentityProblems=node_problems,processObservationErrors=observation_errors,noPositiveExecutableObservations=no_positive,supervisorObservationQualified=not observation_errors,noPositiveNeverClaimsAbsence=True,wholeFeatureQualified=False,nativeQualified=False)
save('report.json',value);assert before==after and first==second and not value['remainingOwnedProcesses']
if original_failure is not None:raise original_failure.with_traceback(original_failure_trace)
if first_observation_error:
    error,original_trace=first_observation_error[0];raise error.with_traceback(original_trace)
if code==0:
    assert len(node_births)==1 and not node_problems
    moving_qualified_pass(HERE)
raise SystemExit(code)
