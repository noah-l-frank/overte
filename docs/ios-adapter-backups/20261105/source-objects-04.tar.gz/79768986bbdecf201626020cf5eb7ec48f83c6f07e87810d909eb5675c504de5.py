"""One genuine Chat namespace comparison measurement; no application/native owners."""
from pathlib import Path
_ENTRY_SOURCE_ROOT=Path(__file__).resolve(strict=True).parent
assert not(_ENTRY_SOURCE_ROOT/'__pycache__').exists()and not any(_ENTRY_SOURCE_ROOT.glob('*.pyc')),'Fresh private control root contains bytecode'
from metadata_reader import pin
from closed_import_origins import ClosedOrigins
from host_common import head
from source_execution_readiness import qualification
import ast,builtins,hashlib,importlib.abc,importlib.util,io,json,os,signal,stat,sys,tempfile,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert sys.flags.no_site==1, 'Explicit no-site startup required'
assert len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert plan['status']=='PRIVATE_CHAT_ONE_REAL_NAMESPACE_MEASUREMENT_UNRUN'
group=json.loads((HERE/'SOURCE-RECIPE.json').read_text())
assert plan['cases']==group['cases']and plan['expectedTemporaryDirectories']==group['TDs']
assert plan['TDsPerCase']==group['TDsPerCase']and plan['nestedCleanupCallsPerCase']==group['nestedCleanupCallsPerCase']
assert plan['consumerCompositionQualified']is False and plan['nativeAdmission']is plan['EndAdmission']is plan['runtimeAdmission']is plan['chatAdoptionAdmission']is None
assert plan['NodeExecutions']==plan['SDKExecutions']==plan['overteNativeQueries']==plan['oldApplicationCorpusInputs']==plan['globalOriginalScans']==0
assert plan['realNetwork']is False and plan['classCleanupObservationVersion']==1 and plan['expectedClassCleanupGroups']==1
assert plan['subjectHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
assert Path(plan['subjectActualCopiedPath'])==HERE/'closed_import_origins.py'
assert pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
assert head()==plan['actualPublicHead']
current_q,current_q_pins=qualification(pin)
assert plan['currentSourceExecution']==current_q
assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in current_q_pins.items())
assert len(plan['cases'])==len(set(plan['cases']))==1 and plan['wallSeconds']==60 and plan['killGraceSeconds']==5
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def fds():
    out={}
    for path in Path('/proc/self/fd').iterdir():
        try:v=path.stat();out[path.name]=dict(target=os.readlink(path),device=v.st_dev,inode=v.st_ino,mode=v.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return out
def children():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
def census(root):
    out={}
    for path in(root,*sorted(root.rglob('*'))):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):row=dict(stat=[getattr(info,k)for k in FIELDS],namespace=sorted(p.name for p in path.iterdir()))
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        out[str(path.relative_to(root))]=row
    return out
assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
original_path=tuple(sys.path);original_meta=tuple(sys.meta_path);loaded={};td_callers=[]
bootstrap_names={'metadata_reader','host_common','closed_import_origins','source_execution_readiness'}
for name in(*plan['modules'],*plan['thirdPartyModules']):
    if name in bootstrap_names:
        actual=sys.modules[name]
        assert Path(vars(actual)['__file__'])==Path(plan['modules'][name]['path'])
        assert pin(Path(vars(actual)['__file__']))==plan['sourceAndBinaryPins'][vars(actual)['__file__']]
    else:assert name not in sys.modules
sys.path[:]=[p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespaces'],*plan['thirdPartyModules'])}
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright')
origin_plan=plan['originPlan']
assert origin_plan['physicalPins']==plan['sourceAndBinaryPins']and origin_plan['modules']==plan['modules']
origins=ClosedOrigins(origin_plan,HERE,REPO,pin)
origin_before=origins.snapshot('before-utility-project-imports')
class AfterActualLoader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name,self.delegate=name,delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module)
        path=Path(vars(module)['__file__']);loaded[self.name]=str(path)
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in forbidden:raise ImportError('Product SDK/browser package refused')
        row=plan['modules'].get(name)
        if row is not None:
            spec=origins.file_spec(name,dict(row,loader='source'),'project')
            spec.loader=AfterActualLoader(name,spec.loader);return spec
        if name in origin_plan['namespacePackages']:
            roots=origin_plan['namespacePackages'][name];origins.namespaces(name,roots,roots,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots;return spec
        if name in origin_plan['thirdPartyModules']or name in origin_plan['thirdPartyNamespacePackages']:return origins.remaining_spec(name,path)
        if name.split('.')[0]in tops:raise ImportError('Unmapped project/third-party import: '+name)
        return origins.remaining_spec(name,path)
finder=Finder();sys.meta_path.insert(0,finder)
TOYS=HERE/'own-toys';RECEIPTS=HERE/'child-receipts'
assert TOYS.is_dir()and RECEIPTS.is_dir()and not any(TOYS.iterdir())and not any(RECEIPTS.iterdir())
assert os.environ['TMPDIR']==str(TOYS)and Path(tempfile.gettempdir())==TOYS
from owned_write_boundary import OwnedWrites
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={n:getattr(os,n)for n in ports if hasattr(os,n)};original_io=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
original_profile=sys.getprofile();assert original_profile is None
original_cleanup=unittest.TestCase.doCleanups;original_td=tempfile.TemporaryDirectory;original_time=time.time
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):
    path=Path(os.readlink('/proc/self/fd/'+str(fd)));assert path.resolve(strict=True)==path and path.is_relative_to(HERE);protected.append(path)
boundary=OwnedWrites(HERE,protected=protected)
closed=False;tail_births={};tail_used=set()
def tail_write(path,value):
    assert closed and path in tail_births and path not in tail_used
    assert all(getattr(os,name)is original for name,original in original_ports.items())
    assert original_io==(io.open,builtins.open)and original_dup==(os.dup,os.dup2)
    assert pin(path)==tail_births[path]
    with original_io[0](path,'w',encoding='utf-8')as stream:
        json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    tail_used.add(path)
tail_function=tail_write;tail_code=tail_write.__code__;tail_globals=tail_write.__globals__
def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Product SDK/browser import refused')
    if event.startswith('socket.')or event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('Chat comparison utility admits no subprocess/network/native/signal/other exec')
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if not relevant:return
    if closed:
        if event=='open':
            value,mode,flags=args
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
            if not writing:return
            caller=sys._getframe(1);path=Path(value)if type(value)in(str,bytes)else None
            assert path in tail_births and path not in tail_used
            assert mode=='w'and flags==(os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC)
            assert caller.f_code is tail_code and caller.f_globals is tail_globals and caller.f_locals.get('path')==path
            assert tail_function is tail_write and tail_function.__code__ is tail_code and tail_function.__globals__ is tail_globals
            assert pin(path)==tail_births[path]
            assert all(getattr(os,name)is original for name,original in original_ports.items())and original_io==(io.open,builtins.open)
            return
        raise RuntimeError('Mutation after actual original port restoration')
    boundary.audit(event,args,sys._getframe(1))
boundary.install();sys.addaudithook(audit)
retained=[];cleanup_calls=[]
def denied_directory(*args,**kwargs):
    td_callers.append(dict(positionalCount=len(args),keywordNames=sorted(kwargs)))
    raise RuntimeError('One namespace measurement selects zero TemporaryDirectory constructors')
tempfile.TemporaryDirectory=denied_directory
def observe_original_cleanup(case):
    before=len(case._cleanups);outcome=case._outcome
    success_before=None if outcome is None else outcome.success
    result_before=None if outcome is None else outcome.result
    errors_before=[]if result_before is None else list(result_before.errors)
    failures_before=[]if result_before is None else list(result_before.failures)
    returned=None;raised=None
    try:
        returned=original_cleanup(case)
        return returned
    except BaseException as error:
        raised=type(error).__module__+'.'+type(error).__qualname__
        raise
    finally:
        after_outcome=case._outcome
        after_result=None if after_outcome is None else after_outcome.result
        same_result=after_result is result_before
        new_errors=[]if not same_result or after_result is None else after_result.errors[len(errors_before):]
        new_failures=[]if not same_result or after_result is None else after_result.failures[len(failures_before):]
        cleanup_calls.append(dict(case=type(case).__module__+'.'+type(case).__qualname__,pendingBefore=before,
            remaining=len(case._cleanups),originalReturned=returned,originalRaised=raised,
            outcomeSuccessBefore=success_before,outcomeSuccessAfter=None if after_outcome is None else after_outcome.success,
            actualResultReceiverSame=same_result,
            newCallbackErrors=[dict(id=test.id(),traceback=text)for test,text in new_errors],
            newCallbackFailures=[dict(id=test.id(),traceback=text)for test,text in new_failures],
            callbackErrorDeltaEstablished=same_result and after_result is not None,
            failedReturnRemainsFailed=returned is not True))
unittest.TestCase.doCleanups=observe_original_cleanup

def save(name,body):
    p=RECEIPTS/name
    with p.open('x')as stream:stream.write(json.dumps(body,indent=2,sort_keys=True)+'\n')
    p.chmod(0o600)
fd_before=fds();threads_before=tuple(threading.enumerate());children_before=children()
case_receipts=[];selected=[];result=None;fatal=None;cleanup_rows=[];cleanup_ok=True;passed=False;class_cleanup=None;class_cleanup_restoration=None;class_cleanup_restoration_error=None;closure_restoration_error=None
class Result(unittest.TextTestResult):
    def startTest(self,test):
        class_cleanup.bind_result(self,test)
        assert original_methods_unchanged()
        origins.snapshot('before-standard-case-'+test.id())
        self.before=(fds(),tuple(threading.enumerate()),children(),len(cleanup_calls),monitor_snapshot(),len(retained));super().startTest(test)
    def stopTest(self,test):
        fd,threads,kernel,cleanup_count,monitor_before_case,td_count=self.before
        assert closure_custody.check()
        origins.snapshot('after-standard-case-'+test.id())
        row=dict(id=test.id(),standardStopAfterCleanup=True,originalMethodsUnchanged=original_methods_unchanged(),monitorMasksSlotsUnchanged=monitor_snapshot()==monitor_before_case,remainingStandardCleanups=len(test._cleanups),
            fdUnchanged=fds()==fd,threadsUnchanged=tuple(threading.enumerate())==threads,kernelChildrenUnchanged=children()==kernel,
            actualNestedCleanupCalls=deepcopy_rows(cleanup_calls[cleanup_count:]),newTemporaryDirectories=len(retained)-td_count,profileRestored=sys.getprofile()is original_profile)
        case_receipts.append(row);save('standard-case-'+str(len(case_receipts))+'.json',row);super().stopTest(test)
def deepcopy_rows(rows):return json.loads(json.dumps(rows))
from class_cleanup_custody import ClassCleanupCustody
from definition_custody import DefinitionCustody
from expected_comparison_custody import ExpectedComparisonCustody
custody=None;closure_custody=None;closure_restoration=None;class_tables=[];code_objects=[]
monitor=sys.monitoring
monitor_port_names=('get_tool','get_events','get_local_events','set_local_events','set_events','register_callback','use_tool_id','free_tool_id')
monitor_ports=tuple((name,getattr(monitor,name))for name in monitor_port_names)
def monitor_snapshot():
    assert sys.monitoring is monitor and all(getattr(monitor,name)is port for name,port in monitor_ports)
    return tuple((monitor.get_tool(tool),monitor.get_events(tool),tuple(monitor.get_local_events(tool,code)for code in code_objects))for tool in range(6))
def bind_original_methods():
    global custody,class_tables,code_objects
    inventory=json.loads((HERE/'DEFINITION-INVENTORY.json').read_text())
    for name in sorted(inventory):__import__(name)
    custody=DefinitionCustody(inventory,plan,pin);class_tables=custody.class_tables;code_objects=custody.code_objects
    assert not td_callers
    return custody.check()
def original_methods_unchanged():
    assert custody is not None
    return custody.check()and(closure_custody is None or closure_custody.check())
monitor_suite_before=None
original_term=signal.getsignal(signal.SIGTERM)
def interrupted(*_args):raise KeyboardInterrupt('Fixed60-second comparison utility boundary')
signal.signal(signal.SIGTERM,interrupted)
try:
    # Natural subject import order comes from the actual test module. No
    # unrelated local factory/Pillow/SDK definition is preloaded.
    from comparison_utility_admission import qualification as comparison_qualification
    actual_comparison,actual_comparison_pins=comparison_qualification(pin)
    assert actual_comparison==plan['comparisonUtility']and all(plan['sourceAndBinaryPins'].get(path)==row for path,row in actual_comparison_pins.items())
    for name in plan['explicitFiveImportOrder']:__import__(name)
    import one_namespace_measurement as measurement
    assert measurement.LAUNCH_ADMISSION is None and measurement.CHAT_ADOPTION_ADMISSION is None
    measurement.LAUNCH_ADMISSION=actual_comparison
    module_name='measurement_case'
    actual_module=__import__(module_name,fromlist=['OneSavedNamespaceMeasurement'])
    assert actual_module.CONTEXT is None
    actual_module.CONTEXT=dict(plan=plan,origins=origins,pin=pin,Path=Path)
    loader=unittest.TestLoader();suite=unittest.TestSuite()
    for selector in plan['cases']:
        selected_module,cls,method=selector.rsplit('.',2);assert selected_module==module_name
        suite.addTests(loader.loadTestsFromName(cls+'.'+method,actual_module))
    def flatten(suite):
        if isinstance(suite,unittest.TestSuite):
            for item in suite:yield from flatten(item)
        else:yield suite
    selected=list(flatten(suite));ids=[case.id()for case in selected]
    save('actual-selection.json',dict(ids=ids,loaderErrors=loader.errors));assert not loader.errors and ids==plan['cases']and suite.countTestCases()==1
    bind_original_methods()
    actual_round=sys.modules['ios.adapters.chat_archive_round']
    closure_custody=ExpectedComparisonCustody(actual_round,actual_module.OneSavedNamespaceMeasurement)
    assert closure_custody.check();monitor_suite_before=monitor_snapshot();assert original_methods_unchanged()
    class_cleanup=ClassCleanupCustody(class_tables,suite,selected,Result,Result.startTest,save)
    class_cleanup.install()
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    try:
        for case in selected:
            pending=len(case._cleanups);old=case._outcome;drain=unittest.TestResult();success=True
            try:
                if pending:case._outcome=unittest.case._Outcome(drain);success=observe_original_cleanup(case)
            except BaseException:success=False;print(traceback.format_exc(),flush=True)
            finally:case._outcome=old
            row=dict(id=case.id(),pendingBeforeOuter=pending,remaining=len(case._cleanups),success=success,
                errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],failures=[dict(id=t.id(),traceback=text)for t,text in drain.failures]);cleanup_rows.append(row)
            if not success or case._cleanups or drain.errors or drain.failures:cleanup_ok=False
        class_cleanup_summary=None if class_cleanup is None else class_cleanup.summary()
        save('actual-class-cleanup-calls.json',class_cleanup_summary)
        nested_ok=len(cleanup_calls)==group['expectedNestedCleanupCalls'] and all(row['originalReturned']is True and row['remaining']==0 for row in cleanup_calls)
        first=census(TOYS);second=census(TOYS)
        after={p:pin(p)for p in plan['sourceAndBinaryPins']}
        assert head()==plan['actualPublicHead']and pin(INPUT)['sha256']==sys.argv[2]
        origin_after=origins.snapshot('after-genuine-original-cleanups')
        passed=fatal is None and result is not None and result.testsRun==1 and result.wasSuccessful()and not result.skipped and cleanup_ok and nested_ok
        passed=passed and class_cleanup_summary is not None and class_cleanup_summary['allActualOriginalCallsAccepted']and class_cleanup_summary['expectedSelectedClasses']==plan['expectedClassCleanupGroups']
        passed=passed and len(case_receipts)==1 and all(row['remainingStandardCleanups']==0 and row['fdUnchanged']and row['threadsUnchanged']and row['kernelChildrenUnchanged']and row['monitorMasksSlotsUnchanged']and row['profileRestored']for row in case_receipts)
        passed=passed and monitor_suite_before is not None and monitor_snapshot()==monitor_suite_before and sys.getprofile()is original_profile
        passed=passed and after==plan['sourceAndBinaryPins']and fd_before==fds()and threads_before==tuple(threading.enumerate())and children_before==children()and first==second
        source_origins={}
        for name,expected in plan['subjectOriginModules'].items():
            module=sys.modules.get(name);actual=None if module is None else getattr(module,'__file__',None)
            source_origins[name]=dict(actualModulePresent=module is not None,actualModuleFile=actual,
                actualLoaderExecutedPath=loaded.get(name),expectedPath=expected['path'],expectedSha256=expected['sha256'],
                exactOriginMatched=actual==loaded.get(name)==expected['path'])
        origins_ok=len(source_origins)==plan['subjectOriginCount']==10 and all(row['exactOriginMatched']for row in source_origins.values())
        passed=passed and origins_ok and not retained and not td_callers and original_methods_unchanged()
        passed=passed and [row['newTemporaryDirectories']for row in case_receipts]==group['TDsPerCase']
        passed=passed and [len(row['actualNestedCleanupCalls'])for row in case_receipts]==group['nestedCleanupCallsPerCase']
        save('actual-all-loaded-origins-before.json',origin_before);save('actual-all-loaded-origins-after.json',origin_after)
        save('actual-source-model-origins.json',dict(subjectOrigins=source_origins,
            allSubjectActualRuntimeOriginsEstablished=origins_ok,actualExecutedOrigins=loaded))
        measured=None if 'measurement_case'not in sys.modules else sys.modules['measurement_case'].RESULTS.get('measurement')
        passed=passed and measured is not None and measured['iterationsPerPath']==1 and measured['fixedOrder']=='literal-first,candidate-second'
        save('one-literal-first-candidate-second-measurement.json',measured)
        save('actual-toy-first.json',first);save('actual-toy-second.json',second);save('outer-cleanup.json',dict(success=cleanup_ok,cases=cleanup_rows,nestedActualCalls=cleanup_calls,nestedActualCleanupSucceeded=nested_ok))
        save('report.json',dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=None if result is None else result.testsRun,
            actualCaseReceipts=len(case_receipts),fatal=fatal,cleanupEstablished=cleanup_ok and nested_ok,actualClassCleanupSummary=class_cleanup_summary,
            retainedTemporaryDirectories=retained,temporaryDirectoryAbsenceClaimed=False,fdUnchanged=fd_before==fds(),
            threadsUnchanged=threads_before==tuple(threading.enumerate()),kernelChildrenUnchanged=children_before==children(),
            pinsUnchanged=after==plan['sourceAndBinaryPins'],twoToyCensusesEqual=first==second,allActualLoadedOriginsAccounted=True,originSnapshots=origins.snapshot_count,
            overteNativeQueries=0,actualStdlibInterpreterExtensionsAllowed=True,realNetwork=False,NodeExecutions=0,SDKExecutions=0,PythonExecutions=0,nativeQualified=False,wholeQualified=False,runtimeAdmission=None,EndAdmission=None,chatAdoptionAdmission=None,performanceMeasured=True,rawSinglePairOnly=True,speedOrCPUCauseConclusion=False))
    finally:
        try:
            if closure_custody is not None:
                assert not closure_custody.installed and not closure_custody.bound
                closure_custody.restore()
                closure_restoration=dict(originalCallSetUpRestored=unittest.TestCase._callSetUp is closure_custody.original,actualBoundCases=0,noSetUpObserverInstalled=True)
                save('actual-expected-comparison-closure-restoration.json',closure_restoration)
        except BaseException:closure_restoration_error=traceback.format_exc()
        try:
            if class_cleanup is not None:
                class_cleanup_restoration=class_cleanup.restore()
                save('actual-class-cleanup-restoration.json',class_cleanup_restoration)
        except BaseException:
            # Keep successful actual restoration data even if its receipt IO
            # fails; independent other original restorations are still attempted.
            class_cleanup_restoration_error=traceback.format_exc()
        signal.signal(signal.SIGTERM,original_term)
        tempfile.TemporaryDirectory=original_td;unittest.TestCase.doCleanups=original_cleanup
        monitor_restored=monitor_suite_before is not None and monitor_snapshot()==monitor_suite_before
        tools_restored=tempfile.TemporaryDirectory is original_td and unittest.TestCase.doCleanups is original_cleanup and time.time is original_time and monitor_restored and sys.getprofile()is original_profile and class_cleanup_restoration is not None and class_cleanup_restoration['originalDescriptorRestored']and class_cleanup_restoration_error is None and closure_restoration is not None and closure_restoration['originalCallSetUpRestored']and closure_restoration['actualBoundCases']==0 and closure_restoration_error is None
        tail=RECEIPTS/'actual-port-restoration.json'
        descriptor=os.open(tail,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        try:assert stat.S_IMODE(os.fstat(descriptor).st_mode)==0o600
        finally:os.close(descriptor)
        tail_births[tail]=pin(tail)
        boundary.restore()
        restored=all(getattr(os,n)is v for n,v in original_ports.items())and original_io==(io.open,builtins.open)
        dup_restored=original_dup==(os.dup,os.dup2)
        boundary.close();closed=True
        sys.meta_path[:]=original_meta;sys.path[:]=original_path
        tail_write(RECEIPTS/'actual-port-restoration.json',dict(restored=restored,count=len(original_ports),
            controlDescriptors=sorted(boundary.control_fds),dupPortsRestored=dup_restored,toolsRestored=tools_restored,
            builtinsCioRestored=original_io==(io.open,builtins.open),actualClassCleanupRestoration=class_cleanup_restoration,classCleanupRestorationError=class_cleanup_restoration_error,closureRestorationError=closure_restoration_error,actualC10dHelperSha256=pin(Path(__file__).with_name('closed_import_origins.py'))['sha256']))
raise SystemExit(0 if passed and restored and tools_restored and dup_restored else 1)
