"""Correct private prerequisite SDK admission; metadata/AST, no target imports."""
import ast,difflib,hashlib,json,stat
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/lifecycle-resource4-sdk-separated-actual-native3-gated-root-preparation-20261102';OLD=REPO/'.ios-host-tmp/lifecycle-resource4-native-qualified-foreign-pub-gated-four-stages-root-preparation-20261102'
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(v)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
def pin(p):
 a=p.lstat();v=dict(stat=[getattr(a,k) for k in FIELDS]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
 if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
 assert v['stat']==[getattr(p.lstat(),k) for k in FIELDS];return v
base=OLD/'first1';pins=json.loads((base/'actual-native3-pass-pins.json').read_text());sdk=json.loads((base/'sdk-original-pins.json').read_text());approved={}
for row in sdk:
 for key in ('path','copy'):
  p=Path(row[key]);assert p.resolve(strict=True)==p and sha(p)==row['sha256']
  approved[str(p)]=dict(sha256=row['sha256'],original=row['path'],source='existing-reviewed-sdk-original-pins.json')
# Four historical in-worktree copies are retained by parent freezes although a
# later capture selected another copy path. Bind their exact freeze provenance;
# an arbitrary path or SDK-looking directory never becomes an exception.
manifest=json.loads((base/'source-manifest.json').read_text());frozen_copies={}
for packet,digest in manifest['orderedParentFreezes'].items():
 root=REPO/'.ios-host-tmp'/packet;assert sha(root/'freeze.json')==digest
 values=json.loads((root/'freeze.json').read_text())['files']
 if isinstance(values,list):values={r['path']:r['sha256'] for r in values}
 for name,d in values.items():frozen_copies[str(root/name)]=dict(packet=packet,freezeSHA256=digest,relative=name,sha256=d)
bad=tuple('/'+name+'/' for name in ('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf'))
for name,expected in pins.items():
 if 'sha256' not in expected or not (any(x in name for x in bad) or '/overte-ios-remotexpc/' in name) or name in approved:continue
 p=Path(name);assert p.is_relative_to(REPO) and name in frozen_copies and frozen_copies[name]['sha256']==expected['sha256']
 matching=[row for row in sdk if row['sha256']==expected['sha256'] and Path(row['path']).name==p.name];assert matching,name
 approved[name]=dict(sha256=expected['sha256'],original=matching[0]['path'],source='unchanged-reviewed-parent-freeze-copy',provenance=frozen_copies[name])
external={name for name in pins if not Path(name).is_relative_to(REPO)};assert external=={row['path'] for row in sdk}
assert len(external)==56 and len(approved)==115
for name,item in approved.items():assert name in pins and pins[name]['sha256']==item['sha256']
# Root explicitly reviewed this unrelated test-only publication after Native3.
avatar=REPO/'tests/device/ios/self_tests/test_ios_avatar_explicit_host_monotonic.py';expected_avatar='0025d1a5fb95c60468052bfa62a77a47a42e3822ed83f12edd043fcdaeece363';assert sha(avatar)==expected_avatar
native_plan=json.loads((Path(json.loads((base/'actual-native3-prerequisite.json').read_text())['actualStage'])/'run-plan.json').read_text());assert str(avatar.relative_to(REPO)) not in native_plan['requiredPublicDependencies']
avatar_delta=dict(path=str(avatar),oldActualSourcePin=pins[str(avatar)],currentReviewedForeignPin=pin(avatar),rootReviewedScope='Avatar test-only nonce counter prerequisite, no Native dependency')
pins[str(avatar)]=pin(avatar)
for name,item in pins.items():assert pin(Path(name))==item,name
outs=[]
for name in ('first1','foreignPostrelease1','remaining6','normal1'):
 old=OLD/name;stage=HERE/name;stage.mkdir(mode=0o700)
 for relative,digest in json.loads((old/'freeze.json').read_text())['files'].items():
  assert sha(old/relative)==digest;write(stage/relative,(old/relative).read_text())
 (stage/'actual-native3-pass-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
 save(stage/'approved-sdk-retention-paths.json',dict(scope='Parent full body hashes; child exact current stat plus known digest only. SDK bodies/imports remain forbidden in child; no audit exceptions.',paths=approved,externalOriginalCount=56,inWorktreeCopyCount=59,legacySdkStatTuple='Preserved original8-field historical metadata; current9-field Native3 rawpins are authoritative for this retention guard'))
 path=stage/'actual_prerequisite.py';before=path.read_text();code=before.replace('def require(here,repo):','def require(here,repo,*,parent=False):')
 needle='    result=[]\n    for name,expected in pins.items():\n';assert code.count(needle)==1
 code=code.replace(needle,"    sdk=json.loads((here/'approved-sdk-retention-paths.json').read_text())['paths']\n    originals=json.loads((here/'sdk-original-pins.json').read_text())\n    assert {name for name in pins if not Path(name).is_relative_to(repo)}=={row['path'] for row in originals}\n    result=[]\n    for name,expected in pins.items():\n")
 oldblock="""        path=Path(name);assert path.is_relative_to(repo) and path.resolve(strict=True)==path
        a=path.lstat();actual=dict(stat=[getattr(a,k) for k in FIELDS])
        assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
        if stat.S_ISREG(a.st_mode):actual['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        assert actual==expected and actual['stat']==[getattr(path.lstat(),k) for k in FIELDS],name
        result.append(path)
"""
 newblock="""        path=Path(name);assert path.resolve(strict=True)==path
        assert path.is_relative_to(repo) or name in sdk
        a=path.lstat();actual_stat=[getattr(a,k) for k in FIELDS]
        assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
        assert actual_stat==expected['stat'],name
        if name in sdk:
            assert expected['sha256']==sdk[name]['sha256']
            # Child never opens SDK originals OR SDK source copies. Parent's
            # exact full body hash before/after brackets the child; this is an
            # honest stat-only child check, not a fabricated measured digest.
            if parent:assert hashlib.sha256(path.read_bytes()).hexdigest()==expected['sha256'],name
        elif stat.S_ISREG(a.st_mode):
            assert hashlib.sha256(path.read_bytes()).hexdigest()==expected['sha256'],name
        assert actual_stat==[getattr(path.lstat(),k) for k in FIELDS],name
        result.append(path)
"""
 assert oldblock in code;code=code.replace(oldblock,newblock);path.write_text(code)
 parentpath=stage/'root-supervise.py';parent=parentpath.read_text().replace('paths.update(require(HERE,REPO))','paths.update(require(HERE,REPO,parent=True))');assert 'parent=True' in parent;parentpath.write_text(parent)
 metadata_path=stage/'actual-native3-prerequisite.json';meta=json.loads(metadata_path.read_text());meta['reviewedForeignPublicDeltas'].append(avatar_delta);meta['approvedSdkRetentionPathCount']=len(approved);meta['childSDKCheck']='stat-only; no body/import/source audit exception';metadata_path.write_text(json.dumps(meta,indent=2,sort_keys=True)+'\n')
 priorpath=stage/'prior-retained-original-pins.json';prior=json.loads(priorpath.read_text());prior[str(avatar)]=pin(avatar);priorpath.write_text(json.dumps(prior,indent=2,sort_keys=True)+'\n')
 planpath=stage/'run-plan.json';plan=json.loads(planpath.read_text());plan['privateFiles'].update({p.name:sha(p) for p in stage.glob('*.py')});plan['status']='PRIVATE_UNRUN_SDK_SEPARATED_ACTUAL_NATIVE3_'+name;planpath.write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
 for p in stage.glob('*.py'):ast.parse(p.read_bytes(),filename=str(p))
 (stage/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(stage)):sha(p) for p in sorted(stage.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
 outs.append(dict(name=name,freeze=sha(stage/'freeze.json')))
write(HERE/'sdk-gate-only.diff',''.join(difflib.unified_diff((OLD/'first1/actual_prerequisite.py').read_text().splitlines(True),(HERE/'first1/actual_prerequisite.py').read_text().splitlines(True),fromfile='old-gate/actual_prerequisite.py',tofile='sdk-separated/actual_prerequisite.py')))
write(HERE/'parent-only.diff',''.join(difflib.unified_diff((OLD/'first1/root-supervise.py').read_text().splitlines(True),(HERE/'first1/root-supervise.py').read_text().splitlines(True),fromfile='old-gate/root-supervise.py',tofile='sdk-separated/root-supervise.py')))
save(HERE/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',baseFreeze=sha(OLD/'freeze.json'),stages=outs,sdkExternalOriginals=56,sdkApprovedInWorktreeCopies=59,SDKbodyChildRead=False,SDKimportAuditUnchanged=True,parentFullBodyBeforeAfter=True,reviewedForeignAvatarDelta=avatar_delta,nativeDependenciesExempted=False,testsRun=False,targetImported=False,sourcePublished=False))
write(HERE/'ROOT-PLAN.txt','Corrected ACTUAL Native3 prerequisite gate. Existing sdk-original-pins has56 external originalpaths,55 distinct in-worktree copy paths plus4 old frozen copies retained by actual Native3 source map; source checks bind exact115 SDK original/copy paths by originaldigest and parentfreeze provenance. Parent full body hash before/after unchanged. Child checks exact actual Native3 current9-field stat+known approveddigest only for these paths and never opens SDK originals/copies; no SDK body/import audit exception added. Every other source/original body stays exact, all Native deps unchanged. Existing old8-field SDKstat tuples retained as historicaldata, not remount-normalized runtime proof. Includes Root-reviewed Avatar test-only0025 foreigndelta and prior reviewedEmoteSource3; all original Native3 before/after/case/process/census proof files immutable. No Source1/250/1.5/cap/test/SDK behavior changes. All stages UNRUN; previous7b18 preimportfailure retained.\n')
save(HERE/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'},stageFreezes={r['name']:r['freeze'] for r in outs}))
print(json.dumps(dict(packet=str(HERE),freeze=sha(HERE/'freeze.json'),stages=outs)))
