"""Same original child's literal current bytes over existing operation routes.

This transports actual immutable frame bytes and validates their seven raw
reads. Neither returned JSON nor a compact reference creates a Source/worker.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import base64,hashlib,time,re
from copy import deepcopy
from datetime import datetime
from adapters.native_feature_observation import decode,exact,need,number,validate as native
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import canonical,same
from feature_journeys.contract import identifier,json_document
from ios.adapters import lifecycle_current as current,keyboard_source as keyboard,lifecycle_world as world
from adapters import pending_commit_owner as pending

FLAGS={'nativeAcquisitionBound','installedCandidateBound','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished'}
NAMES=('nativeBefore','beforeUI','pending','ui','keyboard','world','nativeAfter')
FILES=('feature-native-observation.json','ios-normal-ui-request-result.json',pending.FILE,
    'ios-normal-ui-request-result.json',keyboard.FILE,world.FILE,'feature-native-observation.json')
LIMITS=(262144,65536,32768,65536,keyboard.LIMIT,world.LIMIT,262144)


def afc_stat(value,bytes_):
    need(type(value) is dict and all(type(key) is str for key in value))
    for row in value.values():
        need(type(row) is dict and type(row.get('type')) is str)
        if row['type']=='datetime-naive':
            exact(row,{'type','value','fold'});need(type(row['value']) is str and type(row['fold']) is int and row['fold'] in (0,1))
            parsed=datetime.fromisoformat(row['value']);need(parsed.tzinfo is None and parsed.isoformat(timespec='microseconds')==row['value'])
        else:
            exact(row,{'type','value'});kind={'str':str,'int':int,'bool':bool,'NoneType':type(None)}.get(row['type'])
            if row['type']=='float':need(type(row['value']) is str and number(float.fromhex(row['value'])) and float.fromhex(row['value']).hex()==row['value'])
            else:need(kind is not None and type(row['value']) is kind)
    need(value.get('st_ifmt')==dict(type='str',value='S_IFREG') and value.get('st_nlink')==dict(type='int',value=1)
        and value.get('st_size')==dict(type='int',value=bytes_))
    return value


def frame_original(frame,binding,run,role,ticket,owner):
    exact(frame,{'iosLifecycleCurrentAcquisitionFrameVersion','ownerInstance','phase','ticket','current','reads',
        'queryPlan','originalDeadline','sourceContext','originalServiceCloseReturned'}|FLAGS)
    need(type(frame['iosLifecycleCurrentAcquisitionFrameVersion']) is int and frame['iosLifecycleCurrentAcquisitionFrameVersion']==1
        and frame['ownerInstance']==identifier(owner) and frame['ticket']==identifier(ticket)
        and frame['phase'] in ('before-held','holding','released') and frame['originalServiceCloseReturned'] is True
        and all(frame[key] is False for key in FLAGS))
    exact(frame['sourceContext'],{'sessionId','binding','runId','role'})
    need(same(frame['sourceContext'],dict(sessionId=binding['sessionId'],binding=binding,runId=run,role=role)))
    facts=current.original(frame['current'],binding,run);reads=frame['reads'];plan=frame['queryPlan']
    need(type(reads) is list and len(reads)==7 and type(plan) is list and len(plan)==7)
    packets={};ids=[];previous=None
    deadline=frame['originalDeadline'];exact(deadline,{'startedMonotonic','deadlineMonotonic'})
    need(number(deadline['startedMonotonic'],0,1e15) and number(deadline['deadlineMonotonic'],deadline['startedMonotonic'],deadline['startedMonotonic']+1.5)
        and abs(deadline['deadlineMonotonic']-deadline['startedMonotonic']-1.5)<1e-7)
    for row,intent,name,filename,limit in zip(reads,plan,NAMES,FILES,LIMITS):
        exact(row,{'name','query','rawJson','bytes','sha256','fileBefore','fileAfter','hostBefore','hostAfter'})
        exact(intent,{'name','filename','limit','query'})
        need(row['name']==intent['name']==name and intent['filename']==filename and type(intent['limit']) is int
            and intent['limit']==limit and same(row['query'],intent['query']) and type(row['rawJson']) is str
            and type(row['bytes']) is int and row['bytes']==len(row['rawJson'].encode('utf-8'))<=limit
            and row['sha256']==hashlib.sha256(row['rawJson'].encode('utf-8')).hexdigest())
        afc_stat(row['fileBefore'],row['bytes']);afc_stat(row['fileAfter'],row['bytes']);need(same(row['fileBefore'],row['fileAfter']))
        packet=decode(row['rawJson'],limit=limit);query=row['query']
        if name in ('nativeBefore','nativeAfter'):action='feature-native-observe';extra={}
        elif name in ('beforeUI','ui'):action='normal-ui-input';extra=dict(operation='observe')
        elif name=='pending':action='feature-pending-commit-owner';extra=dict(operation='observe',runId=run,eventId='')
        else:action=keyboard.ACTION if name=='keyboard' else world.ACTION;extra=dict(runId=run)
        exact(query,{'schemaVersion','commandId','action'}|set(extra));need(type(query['schemaVersion']) is int and query['schemaVersion']==1
            and query['action']==action and all(query[key]==value for key,value in extra.items()))
        need(type(query['commandId']) is str and re.fullmatch('ios-[0-9a-f]{32}',query['commandId']) is not None);ids.append(query['commandId'])
        for point in (row['hostBefore'],row['hostAfter']):
            exact(point,{'epochMs','monotonic'});need(number(point['epochMs'],1,1e15) and number(point['monotonic'],deadline['startedMonotonic'],deadline['deadlineMonotonic']))
        before,after=row['hostBefore'],row['hostAfter'];need(after['monotonic']>=before['monotonic'] and after['epochMs']>=before['epochMs']
            and abs((after['epochMs']-before['epochMs'])-(after['monotonic']-before['monotonic'])*1000)<=250)
        if previous is not None:need(before['epochMs']>=previous['epochMs'] and before['monotonic']>=previous['monotonic'])
        previous=after
        pid=int(binding['processIdentity']);epoch=frame['current']['clockJoin']['nativeAfter']['capturedEpochMs']
        if name in ('nativeBefore','nativeAfter'):native(packet,query['commandId'],pid,epoch)
        elif name=='keyboard':keyboard.validate(packet,query,pid,epoch)
        elif name=='world':world.validate(packet,query,pid,epoch)
        elif name=='pending':pending.validate(packet,query,pid,epoch)
        if name in ('beforeUI','ui'):
            exact(packet,{'schemaVersion','commandId','observation'});need(type(packet['schemaVersion']) is int and packet['schemaVersion']==1 and packet['commandId']==query['commandId'])
            packets[name]=packet['observation']
        else:packets[name]=packet
    need(len(set(ids))==7)
    joined=frame['current']['clockJoin'];need(same(joined['nativeBefore'],packets['nativeBefore']) and same(joined['nativeAfter'],packets['nativeAfter']))
    need(same(frame['current']['pendingRequest'],reads[2]['query']) and same(frame['current']['originals'],{key:packets[key]for key in current.FIELDS}))
    need(joined['hostBeforeEpochMs']==reads[0]['hostBefore']['epochMs'] and joined['hostBeforeMonotonic']==reads[0]['hostBefore']['monotonic']
        and joined['hostAfterEpochMs']==reads[-1]['hostAfter']['epochMs'] and joined['hostAfterMonotonic']==reads[-1]['hostAfter']['monotonic'])
    return facts


def capture(source,run,role,ticket,root,*,expected_owner=None,monotonic=time.monotonic):
    """Fresh producer call, then literal original reads; no replacement query."""
    need(type(source) is dict and role in ('primary','actor'));identifier(run);identifier(ticket)
    if expected_owner is not None:identifier(expected_owner)
    from ios.adapters.appium_adapter import WebDriver
    from types import MethodType
    binding=deepcopy(source['binding']);client=source['client'];session=source['session'];target=source['target']['testBuild']
    need(type(client) is WebDriver)
    receivers=tuple((name,getattr(client,name),getattr(client,name).__func__.__code__)for name in ('execute','call','_read_reply'))
    origin=client.server_url
    def receiver_guard():
        need(source['client'] is client and source['binding']==binding and source['session']==session and client.server_url==origin)
        for name,bound,code in receivers:
            selected=getattr(client,name);need(type(selected) is MethodType and selected.__self__ is client
                and selected.__func__ is bound.__func__ and bound.__func__.__code__ is code)
    def checked():
        receiver_guard();source['check']();receiver_guard()
    checked();send=receivers[0][1]
    result=send(session,'mobile: overteOriginalKeeperOperation',dict(operation='touch-current-observe',args=dict(
        nativeCurrentObservationVersion=1,binding=binding,runId=run,role=role,ticket=ticket,resultsDirectory=target['resultsDirectory'],origin=target['fixtureOrigin'],expectedOwnerInstance=expected_owner)))
    checked();exact(result,{'iosLifecycleCurrentAcquisitionVersion','ownerInstance','reference','ticket','role'}|FLAGS)
    need(type(result['iosLifecycleCurrentAcquisitionVersion']) is int and result['iosLifecycleCurrentAcquisitionVersion']==1
        and result['ticket']==ticket and result['role']==role and all(result[key] is False for key in FLAGS));identifier(result['ownerInstance'])
    if expected_owner is not None:need(result['ownerInstance']==expected_owner)
    codec=OriginalFrameStore(root,binding,run,role,source['check'],lambda *_:need(False),namespace='lifecycle-current',schema_prefix='iosLifecycleCurrent')
    reference=result['reference'];codec.expand(reference);started=monotonic();parts=[]
    for offset in range(0,reference['bytes'],4096):
        checked();need(number(monotonic(),started,started+5) and monotonic()-started<5)
        chunk=send(session,'mobile: overteOriginalKeeperOperation',dict(operation='touch-current-original-read',args=dict(
            nativeCurrentOriginalReadVersion=1,binding=binding,runId=run,role=role,reference=deepcopy(reference),offset=offset)))
        checked();exact(chunk,{'iosLifecycleCurrentOriginalReadVersion','ownerInstance','reference','offset','contentBase64'}|FLAGS)
        need(type(chunk['iosLifecycleCurrentOriginalReadVersion']) is int and chunk['iosLifecycleCurrentOriginalReadVersion']==1
            and chunk['ownerInstance']==result['ownerInstance'] and same(chunk['reference'],reference)
            and type(chunk['offset']) is int and chunk['offset']==offset and type(chunk['contentBase64']) is str
            and len(chunk['contentBase64'])<=5464 and all(chunk[key] is False for key in FLAGS))
        row=chunk
        raw=base64.b64decode(row['contentBase64'],validate=True);need(len(raw)==min(4096,reference['bytes']-offset));parts.append(raw)
    raw=b''.join(parts);need(len(raw)==reference['bytes'] and hashlib.sha256(raw).hexdigest()==reference['sha256'])
    body=decode(raw.decode('utf-8'),limit=1024*1024);need(canonical(body)==raw)
    exact(body,{'iosLifecycleCurrentFrameVersion','kind','binding','runId','role','index','frame'})
    need(type(body['iosLifecycleCurrentFrameVersion']) is int and body['iosLifecycleCurrentFrameVersion']==1
        and body['kind']=='sources' and same(body['binding'],binding) and body['runId']==run and body['role']==role
        and type(body['index']) is int and body['index']==reference['index'])
    frame_original(body['frame'],binding,run,role,ticket,result['ownerInstance']);checked();need(monotonic()-started<5)
    return dict(iosLifecycleCurrentReturnedOriginalVersion=1,ownerInstance=result['ownerInstance'],binding=binding,runId=run,role=role,
        ticket=ticket,reference=deepcopy(reference),originalBody=body,**{key:False for key in FLAGS})


def returned_original(value,root,binding,run,role,ticket,owner):
    """Literal historical byte correlation, never a replacement current cut."""
    exact(value,{'iosLifecycleCurrentReturnedOriginalVersion','ownerInstance','binding','runId','role',
        'ticket','reference','originalBody'}|FLAGS)
    need(type(value['iosLifecycleCurrentReturnedOriginalVersion']) is int and value['iosLifecycleCurrentReturnedOriginalVersion']==1
        and value['ownerInstance']==owner and same(value['binding'],binding) and value['runId']==run and value['role']==role
        and value['ticket']==ticket and all(value[key] is False for key in FLAGS))
    codec=OriginalFrameStore(root,binding,run,role,lambda:True,lambda *_:need(False),namespace='lifecycle-current',schema_prefix='iosLifecycleCurrent')
    codec.expand(value['reference']);body=value['originalBody'];raw=canonical(body)
    need(len(raw)==value['reference']['bytes'] and hashlib.sha256(raw).hexdigest()==value['reference']['sha256'])
    exact(body,{'iosLifecycleCurrentFrameVersion','kind','binding','runId','role','index','frame'})
    need(type(body['iosLifecycleCurrentFrameVersion']) is int and body['iosLifecycleCurrentFrameVersion']==1
        and body['kind']=='sources' and same(body['binding'],binding) and body['runId']==run and body['role']==role
        and type(body['index']) is int and body['index']==value['reference']['index'])
    return frame_original(body['frame'],binding,run,role,ticket,owner)
