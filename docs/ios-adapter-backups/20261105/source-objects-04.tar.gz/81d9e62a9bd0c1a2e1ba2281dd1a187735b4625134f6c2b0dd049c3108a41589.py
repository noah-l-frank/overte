"""Future Root-only metadata assembler. No global scans, test imports or run."""
from pathlib import Path
import ast,hashlib,json,os,shutil,stat,sys

REPO=Path.cwd().resolve(strict=True);SOURCE=Path(__file__).resolve().parent
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode

def checked(path):
    path=Path(path);assert path.resolve().is_relative_to(REPO);return path

def pin(path):
    path=Path(path);a=path.lstat();assert path.resolve(strict=True)==path and stat.S_ISREG(a.st_mode)
    raw=path.read_bytes();b=path.lstat();fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    row=dict(stat=[getattr(a,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest())
    assert row['stat']==[getattr(b,key)for key in fields];return row

def packet(root,name,expected):
    path=root/name;assert pin(path)['sha256']==expected;body=json.loads(path.read_text())
    for relative,row in body['files'].items():
        expected_sha=row['sha256']if type(row)is dict else row
        assert type(expected_sha)is str and pin(root/relative)['sha256']==expected_sha
    return path

def main():
    assert len(sys.argv)==3,'new exact controller root and separately reviewed bootstrap source-freeze SHA required'
    packet(SOURCE,'source-freeze.json',sys.argv[2])
    destination=checked(Path(sys.argv[1]));assert destination.is_absolute()and not destination.exists()
    moving=REPO/'.ios-host-tmp/lifecycle-moving-primary-first1-original-host-resolver-controller3-code-preparation-20261103'
    counters=REPO/'.ios-host-tmp/lifecycle-moving-prespawn-original-port-own11-source3-early-fd-retirement-private-20261104'
    raw=REPO/'.ios-host-tmp/lifecycle-moving-native-raw-producer-source2-private-20261103'
    writes=REPO/'.ios-host-tmp/audio-own14-canonical-fd-supervisor4-source-private-20261103'
    packets=[packet(moving,'source-freeze.json','5e872a97d32ec5805440bd89618b53d11af3750cbea51f5a03158ee85c6e1a1e'),
        packet(counters,'source-freeze.json','b2bcc67338ef7f6d911c10415a1ba444ae5bd40881d6ad91c1a192f9915d42a1'),
        packet(raw,'freeze.json','bb658d761ec7f6b7f7ec86f4d5d80e0f04633712869290760927fad9ad3af280')]
    helper=writes/'owned_write_boundary.py';assert pin(helper)['sha256']=='156560033c0c292aa72be6cd66af136683de28490341dceacc191398b5167bda'
    modules=dict(moving_host_ports=moving/'moving_host_ports.py',diagnostic_write_guard=moving/'diagnostic_write_guard.py',
        lifecycle_moving_raw_paths=raw/'models/lifecycle_moving_raw_paths.py',lifecycle_moving_raw_world_renderer=raw/'models/lifecycle_moving_raw_world_renderer.py',
        lifecycle_moving_raw_worker=raw/'models/lifecycle_moving_raw_worker.py',moving_prespawn_counter_observer=counters/'moving_prespawn_counter_observer.py',
        test_moving_prespawn_original_ports=counters/'test_moving_prespawn_original_ports.py',owned_write_boundary=helper)
    test=ast.parse(modules['test_moving_prespawn_original_ports'].read_text())
    classes=('MovingOriginalPreSpawnPortTests','MovingOriginalHostResolverTests')
    cases=['test_moving_prespawn_original_ports.'+cls.name+'.'+method.name for name in classes for cls in test.body
        if type(cls)is ast.ClassDef and cls.name==name for method in cls.body if type(method)is ast.FunctionDef and method.name.startswith('test_')]
    assert len(cases)==11 and len(set(cases))==11
    python=Path(sys.executable).resolve(strict=True);node=Path(shutil.which('node')).resolve(strict=True)
    paths=set(modules.values())|set(packets)|{SOURCE/'source-freeze.json',raw/'models/lifecycle_moving_marker_worker.mjs',python,node}
    for frozen in[*packets,SOURCE/'source-freeze.json']:
        body=json.loads(frozen.read_text())
        paths.update(frozen.parent/name for name in body['files'])
    paths|={Path('/usr/lib64/python3.14')/name for name in('subprocess.py','socket.py','socketserver.py','http/server.py','unittest/case.py','unittest/runner.py')}
    before={str(path):pin(path)for path in paths}
    checked(destination).mkdir(mode=0o700)
    for name in('run-own11.py','supervise-own11.py'):
        target=checked(destination/name);assert not target.exists();target.write_bytes((SOURCE/name).read_bytes())
        before[str(target)]=pin(target)
    body=dict(status='FROZEN_UNRUN_REQUIRES_INDEPENDENT_ROOT_REVIEW',repositoryRoot=str(REPO),controllerRoot=str(destination),
        cases=cases,wallSeconds=30,killGraceSeconds=5,modules={name:dict(path=str(path))for name,path in modules.items()},
        sourceAndBinaryPins=before,movingPlan=dict(movingNodeScript=dict(path=str(raw/'models/lifecycle_moving_marker_worker.mjs'),pin=before[str(raw/'models/lifecycle_moving_marker_worker.mjs')]),
            movingWorkerSource=dict(path=str(modules['lifecycle_moving_raw_worker']),pin=before[str(modules['lifecycle_moving_raw_worker'])]),
            nodeExecutable=dict(path=str(node),pin=before[str(node)])),counterSourceFreeze='b2bcc67338ef7f6d911c10415a1ba444ae5bd40881d6ad91c1a192f9915d42a1',
        bootstrapSourceFreeze=sys.argv[2],NodeExecutions=0,globalScans=0,oldCorpusInputs=[])
    target=checked(destination/'approved-inputs.json');target.write_text(json.dumps(body,sort_keys=True,indent=2)+'\n')
    assert before=={path:pin(path)for path in before}
    print(json.dumps(dict(controllerRoot=str(destination),approvedInputsSha256=pin(target)['sha256'],targets=0,globalScans=0)))
if __name__=='__main__':main()
