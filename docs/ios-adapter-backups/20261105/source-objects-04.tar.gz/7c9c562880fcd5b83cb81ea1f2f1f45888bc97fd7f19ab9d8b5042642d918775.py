"""Controller-only canonical/FD/original-caller boundary; no data verdicts."""
import os,stat,sys
from pathlib import Path
class MutationBoundary:
    def __init__(self,repo,stage):
        self.repo,self.stage=repo,stage
        self.roots=tuple(stage/name for name in('retained','bindings','cleanup'))
        self.files={stage/'created-original-roots.json',stage/'selected-result.json'}
        self.lstat,self.fstat,self.frame,self.readlink=os.lstat,os.fstat,sys._getframe,os.readlink
        self.held=None;self.lock_owners={};self.lock_opens=[];self.lock_flocks=[]
        self.parents={}
        for root in self.roots:
            for parent in(root,*root.parents):
                info=self.lstat(parent);assert parent.resolve(strict=True)==parent and stat.S_ISDIR(info.st_mode)
                self.parents[parent]=(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid)
                if parent==repo:break
    def path(self,value):
        # Absolute paths make an os.open dir_fd ineffective at the OS port.
        # No missing dir_fd audit argument is silently interpreted as cwd.
        assert isinstance(value,(str,bytes,os.PathLike)),'Numeric metadata FD refused'
        path=Path(os.fsdecode(value));assert path.is_absolute()and path.resolve()==path
        assert path in self.files or any(path==root or path.is_relative_to(root)for root in self.roots)
        for parent,row in self.parents.items():
            info=self.lstat(parent);assert parent.resolve(strict=True)==parent
            assert(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid)==row
        # Each existing path component remains a real directory/regular leaf.
        for parent in(path.parent,*path.parent.parents):
            if parent.exists():assert stat.S_ISDIR(self.lstat(parent).st_mode)and not parent.is_symlink()
            if parent==self.stage:break
        if path.exists():assert not path.is_symlink()and stat.S_ISREG(self.lstat(path).st_mode)or path in self.roots or path.is_dir()
        return path
    def output_fd(self,descriptor):
        assert type(descriptor)is int
        path=self.path(self.readlink('/proc/self/fd/'+str(descriptor)))
        info=self.fstat(descriptor);at=self.lstat(path)
        assert stat.S_ISREG(info.st_mode)and info.st_nlink==1 and(info.st_dev,info.st_ino)==(at.st_dev,at.st_ino)
    def bind_original_lock(self,module,fcntl):
        cls=module.ScriptSourceLock;wrapper=cls.held;function=wrapper.__wrapped__
        cells=tuple((cell,cell.cell_contents)for cell in wrapper.__closure__or())
        assert wrapper.__code__.co_freevars==('func',)and len(cells)==1 and cells[0][1]is function
        self.held=(module,cls,wrapper,wrapper.__code__,function,function.__code__,function.__globals__,fcntl,fcntl.flock,cells)
    def original_lock(self):
        assert self.held is not None
        module,cls,wrapper,wcode,function,code,namespace,fcntl,flock,cells=self.held
        assert sys.modules.get('adapters.script_feature.lock')is module and module.ScriptSourceLock is cls
        assert cls.held is wrapper and wrapper.__code__ is wcode and wrapper.__wrapped__ is function
        assert function.__code__ is code and function.__globals__ is namespace
        assert sys.modules.get('fcntl')is fcntl and fcntl.flock is flock
        current=wrapper.__closure__or();assert len(current)==len(cells)and all(cell is old and cell.cell_contents is value for cell,(old,value)in zip(current,cells))
        # original held -> outer audit -> boundary.audit -> this method
        frame=self.frame(3);assert frame.f_code is code and frame.f_globals is namespace
        owner=frame.f_locals.get('self');path=frame.f_locals.get('path')
        assert type(owner)is cls and path==owner.path and self.path(path)==path
        previous=self.lock_owners.get(str(path));assert previous is None or previous is owner
        self.lock_owners[str(path)]=owner
        return frame,owner,path
    def audit(self,event,args):
        if event=='open':
            mode,flags=args[1:3]
            writing=type(mode)is str and any(c in mode for c in'wax+')or type(flags)is int and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            if writing:
                if type(args[0])is int:self.output_fd(args[0])
                else:
                    path=self.path(args[0])
                    if path.name=='script-feature-sources.lock':
                        frame,owner,actual=self.original_lock();assert actual==path and owner._owner is None and mode is None
                        assert flags==(os.O_RDWR|os.O_CREAT|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0)|getattr(os,'O_CLOEXEC',0))
                        self.lock_opens.append(dict(path=str(path),receiver=id(owner),line=frame.f_lineno))
        if event=='fcntl.flock':
            frame,owner,path=self.original_lock();fd,operation=args;fcntl=self.held[7]
            assert fd==frame.f_locals.get('descriptor')and operation==(fcntl.LOCK_EX|fcntl.LOCK_NB)
            info=self.fstat(fd);current=self.lstat(path)
            assert stat.S_ISREG(info.st_mode)and info.st_nlink==1 and info.st_size==0 and stat.S_IMODE(info.st_mode)==0o600
            assert(info.st_dev,info.st_ino)==(current.st_dev,current.st_ino)
            assert any(row['path']==str(path)and row['receiver']==id(owner)for row in self.lock_opens)
            self.lock_flocks.append(dict(path=str(path),descriptor=fd,receiver=id(owner),operation=operation))
        if event in('os.chdir','os.fchdir'):raise RuntimeError('Canonical cwd cannot change')
        shapes={'os.mkdir':(1,(2,)),'os.remove':(1,(1,)),'os.rmdir':(1,(1,)),'os.chmod':(1,(2,)),'os.chown':(1,(3,)),'os.rename':(2,(2,3)),'os.truncate':(1,()),'os.utime':(1,(3,))}
        if event in('os.link','os.symlink'):raise RuntimeError('No hardlinks or symlinks are admitted')
        if event in shapes:
            count,slots=shapes[event];assert all(len(args)<=slot or args[slot]in(None,-1)for slot in slots),'Nondefault mutation dir_fd refused'
            for path in args[:count]:self.path(path)
    def finish(self):
        assert all(owner._owner is None for owner in self.lock_owners.values())
        assert {r['path']for r in self.lock_opens}=={r['path']for r in self.lock_flocks}==set(self.lock_owners)
