"""Strict native once-input originals; no playback/acoustic or cleanup verdict.

Claim intent must be durably owned before send by a separately integrated WAL.
This source only decodes the actual native caller, immutable input PCM and
object/callback/resource inventory. SoundCache-held data remain explicit duty
when native injector/wrapper release succeeds. No operation rearms an input.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib
import re
from adapters.native_feature_observation import exact,fresh,integer,need
from adapters.native_script_membership import validate as membership
from adapters.native_script_observation import validate_code
from adapters.script_feature.history import same
from feature_journeys.navigation_scene import resource_root
from ios.adapters.audio_passive_capture_source import hex32
from ios.adapters.audio_once_cue_signal import input_id,input_pcm

VERSION=1
REPLY_VERSION=2
ACTION='feature-ios-audio-once-cue'
FILE='feature-ios-audio-once-cue.json'
OPERATIONS=('claim','observe','retire','release')
FLAGS=('physicalOutputQualified','acousticQualified','peerQualified','wholeQualified')
BOOLEANS=('complete','consumed','managerReturned','returnedNull','injectorBorn','wrapperBorn','finished',
    'injectorDestroyed','wrapperDestroyed','released','injectorLive','playing','wrapperLive',
    'receiverInventoryComplete','processOwnedControlLive','resourceRequested','resourceWrapperBorn','resourceWrapperDestroyed','resourceWrapperLive','resourceReady',
    'resourceCacheObjectLive','resourcePCMStillHeld','retireAttempted','observedInputPCMKnown',
    'observedInputPCMStillHeld','soundCacheAbsenceQualified',*FLAGS)
COUNTERS=('finishedCallbacks','destroyCallbacks','wrapperDestroyCallbacks','resourceReadyCallbacks','resourceDestroyCallbacks')
RECEIVERS=('scriptFinishedReceivers','resourceReadyReceivers')
EPOCHS=('claimedEpochMs','consumedEpochMs','bornEpochMs','finishedEpochMs','destroyedEpochMs')
STICKY=('consumed','managerReturned','returnedNull','injectorBorn','wrapperBorn','finished','injectorDestroyed',
    'wrapperDestroyed','released','resourceRequested','resourceWrapperBorn','resourceWrapperDestroyed',
    'resourceReady','retireAttempted','observedInputPCMKnown')
FIELDS={'iosAudioOnceCueVersion','commandId','operation','instance','runId','ticket','cueId','kind','soundUrl',
    'caller','playCaller','queryCaller','sequence','requestedEpochMs','capturedEpochMs','processId',
    'pcmBytes','pcmFrames','pcmChannels','pcmSha256',*BOOLEANS,*COUNTERS,*RECEIVERS,*EPOCHS}


def command(value,fixture_url):
    need(type(value) is dict);operation=value.get('operation')
    exact(value,{'schemaVersion','commandId','action','operation','instance','runId','ticket','cueId','kind'} |
        ({'soundUrl'} if operation=='claim' else set()))
    need(type(value['schemaVersion']) is int and value['schemaVersion']==VERSION and value['action']==ACTION
        and operation in OPERATIONS and all(hex32(value[key]) for key in ('instance','runId','ticket','cueId'))
        and value['kind'] in ('cue','pattern') and value['cueId']==input_id(value['runId'],value['ticket'],value['kind'])
        and type(value['commandId']) is str and re.fullmatch('ios-[0-9a-f]{32}',value['commandId']))
    resource_root(fixture_url,value['runId'])
    if operation=='claim':
        need(value['commandId']=='ios-'+value['cueId'] and value['soundUrl']==sound_url(fixture_url,value['runId'],value['ticket'],value['kind']))
    return value


def sound_url(fixture_url,run,ticket,kind):
    resource_root(fixture_url,run)
    return fixture_url+'tickets/'+ticket+'/audio-once-'+kind+'/'+input_id(run,ticket,kind)+'.wav'


def caller(value,method,epoch):
    exact(value,{'callerVersion','method','sequence','invokedEpochMs','manager','code'})
    need(type(value['callerVersion']) is int and value['callerVersion']==1 and value['method']==method
        and integer(value['sequence'],1,1000000000) and integer(value['invokedEpochMs'],1,epoch))
    membership(dict(complete=True,revision=1,managers=[value['manager']]),value['invokedEpochMs'])
    validate_code(value['code'],value['invokedEpochMs'])
    need(value['manager']['assigned'] and value['code']['submitted']
        and value['manager']['assignedEpochMs']<=value['code']['submittedEpochMs'])
    return value


def producer(first,second):return same(first['manager'],second['manager']) and same(first['code'],second['code'])


def validate(value,request,pid,fixture_url,*,clock=None,previous=None):
    command(request,fixture_url);exact(value,FIELDS)
    need(type(value['iosAudioOnceCueVersion']) is int and value['iosAudioOnceCueVersion']==REPLY_VERSION
        and integer(pid,1) and type(value['processId']) is int and value['processId']==pid
        and all(value[key]==request[key] for key in ('commandId','operation','instance','runId','ticket','cueId','kind'))
        and integer(value['sequence'],1,1000000000) and integer(value['requestedEpochMs'],1)
        and integer(value['capturedEpochMs'],value['requestedEpochMs'])
        and value['capturedEpochMs']-value['requestedEpochMs']<5000
        and value['soundUrl']==sound_url(fixture_url,request['runId'],request['ticket'],request['kind']))
    need(all(type(value[key]) is bool for key in BOOLEANS) and not any(value[key] for key in (*FLAGS,'soundCacheAbsenceQualified'))
        and all(integer(value[key],0,1000000000) for key in COUNTERS)
        and all(integer(value[key],0,value['capturedEpochMs']) for key in EPOCHS)
        and value['claimedEpochMs']>0 and integer(value['pcmChannels'],0,2)
        and integer(value['pcmBytes'],0,1024*1024) and integer(value['pcmFrames'],0,1024*1024))
    if value['receiverInventoryComplete']:need(all(integer(value[key],0,1000000000) for key in RECEIVERS))
    else:need(all(type(value[key]) is int and value[key]==-1 for key in RECEIVERS))
    need(value['processOwnedControlLive'])
    caller(value['caller'],'featureIOSAudioOnceCue',value['claimedEpochMs'])
    caller(value['queryCaller'],'featureIOSAudioOnceCue',value['capturedEpochMs'])
    if request['operation']=='claim':need(producer(value['caller'],value['queryCaller']))
    if clock is not None:
        need(type(clock) is dict and clock['processId']==pid and clock['instance']==request['instance'])
        fresh(value['capturedEpochMs'],clock['capturedEpochMs'])
    if value['consumed']:
        caller(value['playCaller'],'playSound',value['consumedEpochMs'])
        need(producer(value['caller'],value['playCaller']) and value['playCaller']['sequence']>value['caller']['sequence']
            and value['claimedEpochMs']<=value['consumedEpochMs']
            and value['resourceRequested'] and value['resourceWrapperBorn'] and value['resourceReady'])
    else:
        need(value['playCaller']=={} and value['consumedEpochMs']==0
            and not any(value[key] for key in ('managerReturned','returnedNull','injectorBorn','wrapperBorn','finished',
                'injectorDestroyed','wrapperDestroyed','injectorLive','playing','wrapperLive','observedInputPCMKnown','observedInputPCMStillHeld')))
    need(not value['managerReturned'] or value['consumed'])
    need(not value['returnedNull'] or value['managerReturned'])
    need(not value['injectorBorn'] or value['consumed'] and value['bornEpochMs']>=value['consumedEpochMs'])
    need(not value['wrapperBorn'] or value['injectorBorn'])
    need(not value['injectorLive'] or value['injectorBorn'] and not value['injectorDestroyed'])
    need(not value['wrapperLive'] or value['wrapperBorn'] and not value['wrapperDestroyed'])
    need(not value['playing'] or value['injectorLive'])
    need(not value['resourceWrapperBorn'] or value['resourceRequested'])
    need(not value['resourceReady'] or value['resourceWrapperBorn'])
    need(not value['resourceWrapperLive'] or value['resourceWrapperBorn'] and not value['resourceWrapperDestroyed'])
    need(not value['resourceCacheObjectLive'] or value['resourceWrapperBorn'])
    need(not value['resourcePCMStillHeld'] or value['resourceReady'])
    need(not value['observedInputPCMStillHeld'] or value['injectorBorn'])
    need(not value['receiverInventoryComplete'] or not value['scriptFinishedReceivers'] or value['wrapperLive'])
    need(not value['receiverInventoryComplete'] or not value['resourceReadyReceivers'] or value['resourceWrapperLive'])
    need(not value['resourceWrapperDestroyed'] or value['resourceWrapperBorn'] and value['resourceDestroyCallbacks']>=1)
    need(not value['finished'] or value['injectorBorn'] and value['finishedCallbacks']>=1 and value['finishedEpochMs']>=value['bornEpochMs'])
    need(not value['injectorDestroyed'] or value['injectorBorn'] and value['destroyCallbacks']>=1 and value['destroyedEpochMs']>=value['bornEpochMs'])
    need(not value['wrapperDestroyed'] or value['wrapperBorn'] and value['wrapperDestroyCallbacks']>=1)
    need(all((value[key]>0)==value[flag] for key,flag in (
        ('consumedEpochMs','consumed'),('bornEpochMs','injectorBorn'),('finishedEpochMs','finished'),
        ('destroyedEpochMs','injectorDestroyed'),('finishedCallbacks','finished'),
        ('destroyCallbacks','injectorDestroyed'),('wrapperDestroyCallbacks','wrapperDestroyed'),
        ('resourceDestroyCallbacks','resourceWrapperDestroyed'))))
    if value['observedInputPCMKnown']:
        need(value['injectorBorn'] and value['pcmChannels']==1 and value['pcmFrames']>0
            and value['pcmBytes']==value['pcmFrames']*2 and type(value['pcmSha256']) is str
            and re.fullmatch('[0-9a-f]{64}',value['pcmSha256']))
    else:need(value['pcmSha256']=='' and value['pcmBytes']==value['pcmFrames']==value['pcmChannels']==0)
    if value['complete']:
        need(value['finishedCallbacks']<=1 and value['destroyCallbacks']<=1 and value['wrapperDestroyCallbacks']<=1
            and value['resourceDestroyCallbacks']<=1)
        need(not value['injectorBorn'] or value['observedInputPCMKnown'])
    if value['released']:
        need(value['receiverInventoryComplete'] and value['retireAttempted'] and not any(value[key] for key in ('injectorLive','playing','wrapperLive','resourceWrapperLive'))
            and not any(value[key] for key in RECEIVERS))
        if value['consumed']:
            need(value['managerReturned'] and (value['injectorDestroyed'] if value['injectorBorn'] else value['returnedNull'])
                and (value['returnedNull'] and not value['wrapperBorn'] or value['wrapperBorn'] and value['wrapperDestroyed']))
        need(not value['resourceWrapperBorn'] or value['resourceWrapperDestroyed'])
    if previous is not None:follow(previous,value)
    return value


def follow(previous,current):
    need(all(same(previous[key],current[key]) for key in ('instance','runId','ticket','cueId','kind','soundUrl','processId','caller','claimedEpochMs'))
        and current['sequence']>previous['sequence'] and current['requestedEpochMs']>=previous['capturedEpochMs'])
    need(all(not previous[key] or current[key] for key in STICKY)
        and all(current[key]>=previous[key] for key in COUNTERS)
        and all(not previous[key] or current[key]==previous[key] for key in EPOCHS))
    if not previous['complete']:need(not current['complete'])
    if previous['consumed']:need(same(previous['playCaller'],current['playCaller']))
    if previous['observedInputPCMKnown']:need(all(previous[key]==current[key] for key in ('pcmSha256','pcmBytes','pcmFrames','pcmChannels')))
    if previous['retireAttempted']:need(previous['consumed']==current['consumed'])
    return current


def finished_input(packet,request,pid,fixture_url):
    """Exact independently generated input bytes plus actual native finish.

    An injector finish supplies no physical output, ADC, preview or peer fact.
    """
    validate(packet,request,pid,fixture_url)
    pcm=input_pcm(request['runId'],request['ticket'],request['kind'])
    need(packet['complete'] and packet['consumed'] and packet['managerReturned'] and not packet['returnedNull']
        and packet['injectorBorn'] and packet['wrapperBorn'] and packet['finished'] and packet['finishedCallbacks']==1
        and packet['observedInputPCMKnown'] and packet['pcmBytes']==len(pcm) and packet['pcmFrames']==len(pcm)//2
        and packet['pcmSha256']==hashlib.sha256(pcm).hexdigest())
    return deepcopy(packet)


def retired_objects(packet,request,pid,fixture_url):
    """Object release keeps SoundCache/PCM duties explicit and separate."""
    validate(packet,request,pid,fixture_url);need(packet['complete'] and packet['released'])
    return dict(objectsRetired=True,processOwnedControlLive=packet['processOwnedControlLive'],cacheObjectStillLive=packet['resourceCacheObjectLive'],
        inputPCMStillHeld=packet['observedInputPCMStillHeld'],resourcePCMStillHeld=packet['resourcePCMStillHeld'],
        cacheAbsenceQualified=False,physicalOutputQualified=False,acousticQualified=False,peerQualified=False,wholeQualified=False)
