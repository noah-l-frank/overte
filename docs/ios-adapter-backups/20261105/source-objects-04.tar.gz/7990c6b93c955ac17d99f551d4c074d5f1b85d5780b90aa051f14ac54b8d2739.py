"""Bounded genuine stdlib XML import diagnosis; no product imports or target."""
from pathlib import Path
import hashlib, importlib.machinery, json, os, sys, threading

HERE = Path(__file__).resolve().parent
REPO = HERE.parent.parent
PLAN = REPO / '.ios-host-tmp/chat-offline-initial4-prepared-root701-head7c18-assembler6-20261104/plan.json'
assert sys.flags.no_site == 1 and sys.dont_write_bytecode and Path.cwd() == REPO
assert hashlib.sha256(PLAN.read_bytes()).hexdigest() == 'a6b1349cfb2448dc6cf191c3f550b6f29c0121527731dd73e050a5c879638956'
plan = json.loads(PLAN.read_text())
spec = importlib.machinery.PathFinder.find_spec('pyexpat')
assert type(spec.loader) is importlib.machinery.ExtensionFileLoader
parent_path = Path(spec.origin).resolve(strict=True)
expected = plan['physicalPins'][str(parent_path)]
assert hashlib.sha256(parent_path.read_bytes()).hexdigest() == expected['sha256']
before = set(sys.modules)
threads_before = tuple(threading.enumerate())
import xml.etree.ElementTree  # Actual original interpreter import, no fake module.
import pyexpat
import xml.parsers.expat as wrapper
wrapper_path = Path(wrapper.__file__).resolve(strict=True)
assert hashlib.sha256(wrapper_path.read_bytes()).hexdigest() == plan['physicalPins'][str(wrapper_path)]['sha256']
assert type(wrapper.__spec__.loader) is importlib.machinery.SourceFileLoader
assert wrapper.errors is pyexpat.errors and wrapper.model is pyexpat.model
assert Path(pyexpat.__file__).resolve(strict=True) == parent_path
assert type(pyexpat.__spec__.loader) is importlib.machinery.ExtensionFileLoader
assert hashlib.sha256(parent_path.read_bytes()).hexdigest() == expected['sha256']
rows = []
for name in sorted(set(sys.modules) - before):
    module = sys.modules[name]
    if module is not None and getattr(module, '__file__', None) is None and getattr(module, '__spec__', None) is None:
        suffix = name.rsplit('.', 1)[-1]
        rows.append(dict(name=name, actualModuleType=type(module).__name__,
            ownerAttributeIdentity=getattr(pyexpat, suffix, None) is module,
            wrapperAttributeIdentity=getattr(wrapper, suffix, None) is module,
            actualModuleName=getattr(module, '__name__', None),
            package=getattr(module, '__package__', None)))
assert tuple(threading.enumerate()) == threads_before
body = dict(status='ACTUAL_STDLIB_ONLY_EXPAT_WRAPPER_ORIGINAL_ALIAS_DIAGNOSIS',
    productImports=0, nodeExecutions=0, targets=0, globalCensuses=0,
    sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    actualExtensionParent=str(parent_path), actualParentSha256=expected['sha256'],
    actualPythonWrapper=str(wrapper_path), actualWrapperSha256=plan['physicalPins'][str(wrapper_path)]['sha256'],
    aliasesAreTheSameOriginalChildReceivers=True,
    newFilelessSpecLessModules=rows, sourceOfC7UnnamedFailureEstablished=False, originalC8FailedNameIsActualWrapperAlias=True,
    originalC7FailureRemainsUnqualified=True, threadsUnchanged=True)
fd = os.open(HERE / 'results.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'w') as stream:
    json.dump(body, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(body, sort_keys=True))
