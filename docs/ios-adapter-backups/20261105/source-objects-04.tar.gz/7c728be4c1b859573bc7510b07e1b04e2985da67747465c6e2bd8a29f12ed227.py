"""Pure real configuration/PFS constructors, no flow/SDK/native admission."""
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import os,tempfile,unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.audio_whole_dispatch import configuration

class AudioFamily12DispatchTests(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        self.root=Path(temporary.name);self.root.chmod(0o700)
        audio=dict(actorTarget='actor')
        for name in('artifactRoot','primaryArtifactRoot','actorArtifactRoot','primaryWholeRoot','actorWholeRoot'):
            path=self.root/name;path.mkdir(mode=0o700);audio[name]=str(path)
        self.value=dict(iosFeatureAdapterVersion=12,areas=['audio'],fixtureConfig=str(self.root/'unopened-fixture-config.json'),graphics=None,create=None,emotes=None,
            worldNavigation=None,avatarPeople=None,worldWeb=None,tabletWeb=None,emoteCoordinatorVersion=None,worldWebCoordinatorVersion=None,emoteTargets=None,
            audio=audio,audioCoordinatorVersion=1,audioSharedActorFamilyVersion=2)
        self.store=PrivateFeatureState(self.root/'config.json')
        self.enterContext(patch.dict(os.environ,OVERTE_IOS_FEATURE_ADAPTER_CONFIG=str(self.store.path)))
    def save(self,value):self.store.write(value,self.store.read())
    def test_actual_pfs_config12_reader_and_literal_old11_both_reach_dispatch(self):
        self.save(self.value);self.assertEqual(self.value,configuration())
        old=deepcopy(self.value);old['iosFeatureAdapterVersion']=11;old.pop('audioSharedActorFamilyVersion')
        self.save(old);self.assertEqual(old,configuration())
        self.assertFalse((self.root/'unopened-fixture-config.json').exists())
    def test_exact_family2_and_full_config_shape_still_refuse_other_authority(self):
        self.save(self.value);self.assertEqual(self.value,configuration())
        for version in(True,1,None):
            bad=deepcopy(self.value);bad['audioSharedActorFamilyVersion']=version;self.save(bad)
            with self.assertRaises(NativeUIError):configuration()
        bad=deepcopy(self.value);bad['unexpectedReplyAuthority']=True;self.save(bad)
        with self.assertRaises(NativeUIError):configuration()
