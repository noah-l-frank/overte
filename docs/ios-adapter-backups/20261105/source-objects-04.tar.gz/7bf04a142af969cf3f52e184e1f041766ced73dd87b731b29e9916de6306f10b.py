"""Closed reviewed native codec imports before any Audio admission/acquisition.

No owner, transport, SDK, observation, clock or validator is invoked here.
The namespace objects and all referenced values are fenced afresh by each
SemanticFence. This preparation returns no result or admission authority.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0

MODULES=(
    'adapters.native_account_observation','adapters.native_animation_caller',
    'adapters.native_animation_history','adapters.native_feature_observation',
    'adapters.native_script_loads','adapters.native_script_membership',
    'adapters.native_script_observation','adapters.normal_ui',
    'adapters.pure_original_validation','adapters.recorded_preview_history',
    'feature_journeys.contract','feature_journeys.fixtures',
    'feature_journeys.scenarios','voice_peer.voice_signal')


def prepare():
    # Literal roots; their complete top-level dependency closure is recorded
    # in IMPORT-CLOSURE.json. Do not replace this with a dynamic module loader.
    import adapters.native_account_observation
    import adapters.native_animation_history
    import adapters.recorded_preview_history
    import warnings

