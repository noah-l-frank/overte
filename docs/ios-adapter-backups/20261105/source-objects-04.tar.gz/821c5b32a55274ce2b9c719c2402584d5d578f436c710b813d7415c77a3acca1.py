"""Single fixed90+5 exact26 model run; actual sources and originals retained."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,time
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
ENTRY=HERE.parent/'lifecycle-owner-exact26-async-setup-testprep-20261028'
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml')
PACKETS=('lifecycle-owner-exact26-async-setup-testprep-20261028','lifecycle-owner-exact26-model-testprep-20261028','lifecycle-authenticated-keeper-drain-async-setup-overlay-20261028','lifecycle-authenticated-creator-draft-20261028','lifecycle-authenticated-creator-corrections-20261028','lifecycle-authenticated-creator-model-aba-overlay-20261028','lifecycle-authenticated-keeper-drain-overlay-20261028','lifecycle-authenticated-keeper-drain-test-barrier-overlay-20261028')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    p=HERE/name;fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def pin(p):
    a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode),str(p)
    v=dict(sha256=sha(p)) if stat.S_ISREG(a.st_mode) else {}
    v['stat']=[getattr(a,k) for k in FIELDS];b=p.lstat();assert v['stat']==[getattr(b,k) for k in FIELDS];return v

def sources():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths={REPO/n for n in names if n};paths.add(REPO/'CMakeLists.txt')
    assert REPO/'interface/src/main.cpp' in paths
    for name in PACKETS:
        root=HERE.parent/name;freeze=json.loads((root/'freeze.json').read_text())
        for relative,expected in freeze['files'].items():
            p=root/relative;assert sha(p)==expected,str(p);paths.add(p)
        paths.add(root/'freeze.json')
    for p in (HERE/'root-child.py',HERE/'root-supervise.py',HERE/'freeze.json',HERE/'sdk-source-map.json',HERE/'drain-source-map.json',HERE/'clone-provenance.json'):paths.add(p)
    return {str(p):pin(p) for p in sorted(paths)}
def process(pid):
    try:v=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(v[1]),pgid=int(v[2]),sid=int(v[3]),startTicks=int(v[19]))
def remaining(binding):
    rows=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        v=process(int(p.name))
        if v is not None and (v['pgid']==binding['pid'] or v['sid']==binding['pid']):rows.append(v)
    return rows

def census(root):return {str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))}
assert Path.cwd()==REPO and sys.dont_write_bytecode and not (HERE/'first26-report.json').exists()
for name,expected in json.loads((HERE/'freeze.json').read_text())['files'].items():assert sha(HERE/name)==expected,name
expected=json.loads((ENTRY/'source-expectations.json').read_text())
for name,allowed in expected['publicTargets'].items():assert sha(REPO/name) in allowed,name
save('sdk-source-map.json',expected['sdkModelSources'])
roles={'keeper':'tests/device/ios/pymobiledevice3_wda_xctest.py','lease':'tests/device/ios/adapters/touch_lease.py','fixture':'tests/device/ios/self_tests/test_ios_touch_lease.py','retained':'tests/device/ios/adapters/lifecycle_touch_transport.py'}
save('drain-source-map.json',dict(repositoryRoot=str(REPO),sources={k:dict(path=str(REPO/n),sha256=sha(REPO/n)) for k,n in roles.items()}))
before=sources();save('source-before.json',before)
config=dict(repositoryRoot=str(REPO),scope='all-current-repository-source-and-active-launchers',actualSourceRoots=list(ROOTS),
    files=[dict(path=name,**row) for name,row in before.items()],sdkModelMap=dict(path=str(HERE/'sdk-source-map.json'),sha256=sha(HERE/'sdk-source-map.json')),
    drainModelMap=dict(path=str(HERE/'drain-source-map.json'),sha256=sha(HERE/'drain-source-map.json')))
save('root-source-map.json',config);map_pin=pin(HERE/'root-source-map.json')
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',LIFECYCLE_EXACT26_ROOT_MAP=str(HERE/'root-source-map.json'),LIFECYCLE_EXACT26_ROOT_MAP_SHA256=sha(HERE/'root-source-map.json'))
assert not (ENTRY/'retained-first26').exists() and not (HERE/'first26.log').exists()
print('SOURCE_PINS',len(before),flush=True);started=time.monotonic()
command=['timeout','--signal=TERM','--kill-after=5s','90s',sys.executable,str(HERE/'root-child.py')]
with (HERE/'first26.log').open('x') as log:
    task=subprocess.Popen(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    bound=process(task.pid);assert bound is not None and bound['sid']==bound['pgid']==task.pid
    save('first26-process-binding.json',dict(task=bound,supervisor=process(os.getpid()),command=command))
    print('ACTUAL_PROCESS',json.dumps(bound),flush=True);code=task.wait()
assert not remaining(bound),'Owned process remains before retained-original census'
after=sources();save('source-after.json',after)
root=ENTRY/'retained-first26';first=census(root) if root.exists() else {};second=census(root) if root.exists() else {}
save('originals-first.json',first);save('originals-second.json',second)
left=remaining(bound);report=dict(exitCode=code,seconds=time.monotonic()-started,sourcePins=len(after),allPinsEqual=before==after,
    rootMapUnchanged=pin(HERE/'root-source-map.json')==map_pin,retainedOriginalsUnchanged=first==second,
    retainedFiles=sum(stat.S_ISREG(row['stat'][2]) for row in first.values()),remainingOwnedProcesses=left,
    nativeCompiled=False,sdkImported=False,actualAuthenticationQualified=False,wholeFeatureQualified=False)
save('first26-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report),flush=True)
assert before==after and first==second and not left and pin(HERE/'root-source-map.json')==map_pin
raise SystemExit(code)
