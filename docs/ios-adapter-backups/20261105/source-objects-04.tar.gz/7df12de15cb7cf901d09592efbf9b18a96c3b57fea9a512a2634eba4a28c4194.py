"""Root-only fresh metadata for exactly one unchanged Assets Source2 case.

No subject import, child, model execution or corpus census is performed here.
The current Root must separately guard all prior originals around the utility.
"""
from pathlib import Path
import argparse,ast,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from project_namespace_admission import project_namespace_admission
from source_execution_readiness import qualification
SOURCE=Path(__file__).resolve().parent
SUBJECTS={
 'archive01':('assets-current-checkpoint-owned-originals-source2-complete-save-failure-domain-private-20261105','42748bf52f23de932810d6cea3546c4fe04a6efd5e6e67383901f97bd6f8a625',88,80,588,'source2-'),
 'second01':('assets-second-ordinary-picker-checkpoint-owned-originals-source3-private-20261105','800d75f00c7d9e06341a6d8399d21f10b51a2e935f41b7a00800a3691909d552',90,82,590,'')}
HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
C25=REPO/'.ios-host-tmp/assets-picker3-reserved-phase-controller25-qualified-diagnostic14-source-private-20261104'
EXECUTORS=('run-one.py','supervise-one.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','source_execution_readiness.py',
 'readonly-shared-stdlib-sources.json','class_cleanup_custody.py','definition_custody.py','project_namespace_admission.py','third-party-source-declarations.json',
 'fixed-two-original-profiles.json','runtime_projection.py','SOURCE-OVERLAYS.json','assets_resources.py','fixture_common.py','scoped_ports.py','backend_dirfd_ports.py','monitoring_observer.py','typed_observer.py',
 'c10d_admission.py','backend_utility_readiness.py','definition-inventory.json','required-definition-closure.json',
 'source2-definition-inventory.json','source2-SOURCE-OVERLAYS.json','source2-required-definition-closure.json')
def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','expected-head','destination','group','source-review-freeze','source-review-sha'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--root-reviewed-source23-and-bootstrap5',required=True,action='store_true')
    args=parser.parse_args();assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and all(c in'0123456789abcdef'for c in args.expected_head)and head()==args.expected_head
    groups=json.loads((SOURCE/'fixed-two-original-profiles.json').read_text())['groups'];assert args.group in groups;recipe=groups[args.group]
    name,SUBJECT_SHA,origin_count,overlay_count,definition_count,prefix=SUBJECTS[args.group];SUBJECT=REPO/'.ios-host-tmp'/name
    assert len(recipe['caseIds'])==1 and recipe['wallSeconds']==300 and recipe['killGraceSeconds']==5
    physical={}
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        row=pin(path)
        if digest is not None:assert row['sha256']==digest
        previous=physical.setdefault(str(path),row);assert previous==row
        return row
    def frozen(folder,name,digest):
        keep(folder/name,digest);value=json.loads((folder/name).read_text());assert type(value['files'])is dict
        for leaf,row in value['files'].items():
            assert not Path(leaf).is_absolute()and '..'not in Path(leaf).parts
            keep(folder/leaf,row if type(row)is str else row['sha256'])
        return value
    frozen(SOURCE,'source-freeze.json',args.source_freeze);frozen(SUBJECT,'source-freeze.json',SUBJECT_SHA)
    frozen(REPO/'.ios-host-tmp/root-assets-source3-second01-b7-original-decorator-custody-refusal-negative-results-20261105','freeze.json','23aa2b30ad88666fd474bc55f9d7406f1aaa7d969ac36656f80092384cdcfb0c')
    for path,record in json.loads((SOURCE/'ACTUAL-B7-DECORATOR-NEGATIVE-REFERENCES.json').read_text())['references'].items():
        assert path==record['path'];keep(path,record['sha256'])
    frozen(REPO/'.ios-host-tmp/assets-original-checkpoint-source23-bootstrap7-fresh-owned-definition-source-reader-code-preparation-20261105','source-freeze.json','47a72d7a39f51cb9b8d6d67ee45afd164bedfe66258cb07485ea045d38c06cf2')
    frozen(REPO/'.ios-host-tmp/assets-original-checkpoint-source23-bootstrap6a-qualified-original-negative-retention-code-preparation-20261105','source-freeze.json','7ff5091957ebe7eb21fc66ee88a7543d5b778d5d70008e4d95138a51fc376480')
    frozen(REPO/'.ios-host-tmp/root-assets-source3-second01-b6a-window-current1181-20261105','freeze.json','5691bdadd15b48fa34b56212027c630d86565652c55475a367f51915b9869445')
    negative=json.loads((SOURCE/'ACTUAL-B6A-INVENTORY-REFUSAL-REFERENCES.json').read_text())
    for path,record in negative['references'].items():
        assert path==record['path'];keep(path,record['sha256'])

    frozen(REPO/'.ios-host-tmp/assets-original-checkpoint-source23-bootstrap6-genuine-unittest-importerror-protocol-code-preparation-20261105','source-freeze.json','bbf496e5eaf450999d113d0d8c4dcc53d8f0d0b8337104f6f34f62e5ca7830b3')
    frozen(REPO/'.ios-host-tmp/root-assets-archive01-b5-original-unittest-import-protocol-refusal-negative-results-20261105','freeze.json','ac42f86da46969d9994714be668ad7fdf43f083f02a01a5144d50ce88924d763')
    qualified_negative=json.loads((SOURCE/'ACTUAL-B5-QUALIFIED-NEGATIVE-REFERENCES.json').read_text())
    for path,record in qualified_negative['frozenMembers'].items():
        assert path==record['path'];keep(path,record['sha256'])

    frozen(REPO/'.ios-host-tmp/assets-original-checkpoint-source23-bootstrap5-exact-host-frontier-and-own-metadata-code-preparation-20261105','source-freeze.json','a3ebf6823776e3a039deddccef0c611099026e89393b18e9fd69154737fcfdea')
    raw5=REPO/'.ios-host-tmp/root-assets-checkpoint-archive01-b5-window-current1177-20261105'
    frozen(raw5,'freeze.json','77800f0ee9998da7e2942e1228ee376d45aef52bb769af77a7e404e23ddd7950')
    # Exact raw originals only. No qualified Root status or failed probe name
    # is inferred; the actual full room maps bind these four selected files.
    rawrefs=json.loads((SOURCE/'ACTUAL-B5-RAW-NEGATIVE-REFERENCES.json').read_text())
    for path,row in rawrefs['references'].items():
        assert path==row['path'];keep(path,row['sha256'])

    frozen(REPO/'.ios-host-tmp/assets-second-ordinary-checkpoint-source3-first1-bootstrap1-closed-code-preparation-20261105','source-freeze.json','628163afa4429d7b7d951e3f737514977cc6d19d2d450d2a91c2da3f1ad665b0')
    frozen(REPO/'.ios-host-tmp/assets-independent-source3-first-ordinary2-bootstrap1-full-source-review-20261105','freeze.json','a89744198824e89a936ffca955c899ccb1b10ce6d14b53318ee2476894c9f6f9')
    frozen(REPO/'.ios-host-tmp/assets-checkpoint-owned-source2-ten-bootstrap1-closed-code-preparation-20261105','source-freeze.json','b5c788b8ce8d97f778e17e958c52e35b4a8b9560da2b41d9808c39515daad201')
    frozen(REPO/'.ios-host-tmp/assets-checkpoint-owned-source2-ten-bootstrap2-exact-own-adapter-metadata-read-code-preparation-20261105','source-freeze.json','67a7a5a13018989b5012f5a2b0e2815b94778289cd8964c98d7968a46584f851')
    # Retain the actual failed predecessor and its literal negative receipts.
    # These historical rows grant no runtime or feature admission.
    frozen(REPO/'.ios-host-tmp/root-assets-checkpoint-source2-ten-bootstrap3-actual-metadata-device-inode-code-preparation-20261105','source-freeze.json','40ceb4a0b520283a067d2d48a985977c463f77e1e39f060e2be149ad12e95382')
    negative=REPO/'.ios-host-tmp/root-assets-archive01-b3-original-startup-refusal-negative-results-20261105'
    frozen(negative,'freeze.json','afd77c96270e600dde49324e9b9f5e7ba102a0e6fa73f812bab6083b83b547c1')
    for path,row in json.loads((negative/'actual-receipt-references.json').read_text()).items():
        assert row['path']==path
        keep(path,row['sha256'])
    frozen(REPO/'.ios-host-tmp/assets-checkpoint-source2-ten-bootstrap4-genuine-backend-startup-dependency-code-preparation-20261105','source-freeze.json','1ec0ae6a3b29c8b8c6e170114277a915d1cec0daf3df6c425e37c024e0f35f86')
    frozen(REPO/'.ios-host-tmp/assets-current-checkpoint-owned-originals-source2-complete-save-failure-domain-private-20261105','source-freeze.json','42748bf52f23de932810d6cea3546c4fe04a6efd5e6e67383901f97bd6f8a625')
    negative4=REPO/'.ios-host-tmp/root-assets-archive01-b4-original-module-import-refusal-negative-results-20261105'
    frozen(negative4,'freeze.json','d6591966329ccb2c66aec4db5399284668f15fec12f60aef3a66d1151fc85a08')
    for path,row in json.loads((negative4/'actual-receipt-references.json').read_text()).items():
        assert row['path']==path;keep(path,row['sha256'])
    review=Path(args.source_review_freeze);assert review.is_absolute()and review.is_relative_to(REPO/'.ios-host-tmp')
    frozen(review.parent,review.name,args.source_review_sha)
    composition=json.loads((SUBJECT/'COMPOSED-SOURCE-MANIFEST.json').read_text());assert len(composition['origins'])==origin_count
    for row in composition['origins']:keep(row['path'],row['sha256'])
    current,current_pins=qualification(pin);physical.update(current_pins);keep(SOURCE/'closed_import_origins.py',HELPER)
    from backend_utility_readiness import boundary_qualification
    backend,backend_pins=boundary_qualification(REPO,pin,SOURCE);physical.update(backend_pins)
    # Existing public roots declare canonical names and the genuinely used bare
    # self-test names. All physical sources are pinned before classification.
    device=REPO/'tests/device';roots=(device,device/'self_tests',device/'ios/self_tests');declared={}
    for root in roots:
        for path in sorted(root.rglob('*.py')):
            parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
            if package:parts.pop()
            if parts:
                row=keep(path);declared.setdefault('.'.join(parts),dict(path=str(path),sha256=row['sha256'],package=package))
    overlays=json.loads((SOURCE/(prefix+'SOURCE-OVERLAYS.json')).read_text());assert len(overlays)==overlay_count
    for row in overlays:
        actual=keep(row['path'],row['sha256']);declared[row['module']]=dict(path=row['path'],sha256=actual['sha256'],package=row['package'])
    from definition_custody import inventory
    definitions=json.loads((SOURCE/(prefix+'definition-inventory.json')).read_text());assert len(definitions)==definition_count
    for name,row in definitions.items():
        assert name in declared and declared[name]['path']==row['path']and declared[name]['sha256']==row['sha256']
        keep(row['path'],row['sha256']);assert inventory(row['path'])==row['inventory'],('Actual definition source changed',name)
    required=json.loads((SOURCE/(prefix+'required-definition-closure.json')).read_text());assert set(required)==set(definitions)
    from runtime_projection import project,validate_plan,EXCLUDED
    historical_definitions=definitions
    definitions,entry_projection=project(historical_definitions)
    assert len(definitions)==definition_count-3
    from definition_custody import graphics_operation_schema
    graphics_schema=graphics_operation_schema(definitions) # actual original factory AST before destination birth
    # Actual picker with_name JS and actual public ROOT-derived QML operands.
    node_args=['node',str(device/'ios/self_tests/assets_picker_host.js'),str(REPO/'interface/resources/qml/hifi/dialogs/TabletAssetServer.qml'),
      str(REPO/'interface/resources/qml/dialogs/NativeFileBrowser.qml'),str(REPO/'interface/resources/qml/hifi/tablet/TabletNavigation.qml'),
      str(REPO/'interface/resources/qml/hifi/dialogs/NativeModelTree.qml'),'usage']
    for path in node_args[1:-1]:keep(path)
    node_path=Path('/usr/bin/node');real_node=node_path.resolve(strict=True);node=keep(real_node)
    node_pin=dict(path=str(node_path),realPath=str(real_node),device=node['device'],inode=node['inode'],sha256=node['sha256'])
    third={};external=json.loads((SOURCE/'third-party-source-declarations.json').read_text());assert len(external)==39
    for name,row in external.items():
        assert name=='PIL'or name.startswith('PIL.')or name=='defusedxml'or name.startswith('defusedxml.')
        keep(row['path'],row['sha256']);third[name]=dict(path=row['path'],sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14');stdns={};suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    for stdlib_dir,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(stdlib_dir);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink());relative=folder.relative_to(std)
        if relative.parts and all(n.isidentifier()for n in relative.parts)and not(folder/'__init__.py').is_file():stdns['.'.join(relative.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix=='.py'or str(path).endswith(suffixes):keep(path)
    python=Path(sys.executable).resolve(strict=True);python_pin=keep(python)
    # Explicit actual head admission; historical Source2 headers are not rebound.
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ');gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for path in(REPO/'.git',gd/'HEAD',gd/'commondir',gd/'index'):keep(path)
    keep(next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs'))
    own_reads={str(path)for path in map(Path,physical)if path.is_relative_to(device/'adapters/appium')}
    own_adapter=device/'ios/adapters/appium_adapter.py'
    assert own_adapter.resolve(strict=True)==own_adapter and str(own_adapter)in physical
    assert pin(own_adapter)==physical[str(own_adapter)]
    own_reads.add(str(own_adapter)) # Exact existing own source; metadata-pin frame only.
    # These exact two current repository DATA files are also pinned by the
    # original full public-source walk; they grant no imports or SDK authority.
    for logical in('adapters/android-phone/appium_adapter.py','ios/pymobiledevice3_wda_xctest.py'):
        own=device/logical;assert own.resolve(strict=True)==own and str(own)in physical
        assert pin(own)==physical[str(own)];own_reads.add(str(own))
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'
    assert dest.name.startswith('assets-checkpoint-'+args.group+'-prepared-')and not dest.exists()
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    dest.mkdir(mode=0o700)
    for name in EXECUTORS:
        path=dest/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        row=keep(path)
        if path.suffix=='.py'and name not in('run-one.py','supervise-one.py'):
            assert path.stem not in declared;declared[path.stem]=dict(path=str(path),sha256=row['sha256'],package=False)
    projects,namespaces,alias_data=project_namespace_admission(declared,[str(device)])
    assert(projects,namespaces,alias_data)==project_namespace_admission(declared,[str(device)])
    assert all(name in projects for name in historical_definitions)
    planner_projects=projects;projects={name:row for name,row in projects.items()if name not in EXCLUDED}
    plan=dict(status='PRIVATE_ASSETS_SOURCE23_BOOTSTRAP5_ONE_ORIGINAL_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(dest),actualPublicHead=args.expected_head,
      sourceFreeze=args.source_freeze,subjectSourceFreeze=SUBJECT_SHA,sourceReview=dict(path=str(review),sha256=args.source_review_sha),
      qualifiedSourceExecution=current,subjectHelperSha256=HELPER,backendBoundaryQualification=backend,
      sourceAndBinaryPins=physical,modules=projects,namespaces=namespaces,thirdPartyModules=third,subjectOriginModules=definitions,definitionInventory=definitions,
      graphicsSceneOperationSchema=graphics_schema,
      historicalDefinitionInventory=historical_definitions,namespacePlannerOriginalModules=planner_projects,runtimeEntrypointProjection=entry_projection,
      groupName=args.group,cases=recipe['caseIds'],resourceRecipe=recipe,wallSeconds=300,killGraceSeconds=5,expectedTemporaryDirectories=4,expectedNestedCleanupCalls=7,
      expectedNode=1,expectedHTTP=2,expectedPickerNodeArgv=node_args,nodePin=node_pin,
      SDKExecutions=0,overteNativeQueries=0,oldCorpusInputs=0,globalOriginalScans=0,realNetwork='exact-two-owned-loopback-listeners-only',
      pythonExecutable=dict(path=str(python),pin=python_pin),declaredProjectAliases=declared,projectAliasAdmission=alias_data,
      productionAndTestOverlays=overlays,historicalCompositionOriginals=composition,ownForbiddenMetadataReadPaths=sorted(own_reads),
      trustedHostBootstrap='Initial interpreter/stdlib/control modules are held physical HOSTBOOTSTRAP; only genuine project delegates execute fresh through current C10d.',
      normalAction2Qualified=False,phaseAdmission=None,remaining6Admission=None,nativeCompiled=False,nativeQualified=False,wholeQualified=False)
    plan['originPlan']=dict(modules=projects,namespacePackages=namespaces,projectAliasAdmission=alias_data,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=stdns,
      stdlibRoots=[str(std)],pythonExecutable=plan['pythonExecutable'],physicalPins=physical)
    assert validate_plan(plan)
    output=dest/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,sort_keys=True,indent=2);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),sha256=pin(output)['sha256'],group=args.group,cases=recipe['caseIds'],targetStarts=0,globalCensuses=0)))
if __name__=='__main__':main()
