"""Closed Photos end scope, real Node originals and passive retired replay."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.appium_adapter import WebDriverRequestError
from ios.adapters.process_retirement import filename
from ios.adapters.snapshot_photos_end_graph import SnapshotPhotosEndGraph
from ios.adapters.snapshot_photos_end_owner import SnapshotPhotosEndOwner
from ios.adapters.snapshot_photos_end_position import SnapshotPhotosRetiredSDKPosition
from ios.self_tests.snapshot_photos_end_domain import PhotosEndFlow


class SnapshotPhotosEndContractTests(unittest.TestCase):
    def test_new_process_profile_accepts_only_photos_primary_stage_zero(self):
        self.assertEqual('ios-snapshot-photos-primary-0-process-retirement.json',filename('snapshotphotos','primary',0))
        self.assertEqual('ios-snapshot-share-archive-primary-0-process-retirement.json',filename('snapshotsharearchive','primary',0))
        self.assertEqual('ios-graphics-actor-1-process-retirement.json',filename('graphics','actor',1))
        for role,stage in (('actor',0),('primary',1),('actor',1)):
            with self.subTest(role=role,stage=stage),self.assertRaises(NativeUIError):filename('snapshotphotos',role,stage)
    def test_foreign_retired_sdk_position_cannot_open_any_original_graph(self):
        graph=object.__new__(SnapshotPhotosEndGraph)
        with self.assertRaises(NativeUIError):graph.replay(object())
        with self.assertRaises(NativeUIError):SnapshotPhotosRetiredSDKPosition(object())
    def test_frozen_graph_rejects_untyped_or_live_journey_before_file_access(self):
        with self.assertRaises(NativeUIError):SnapshotPhotosEndGraph(object())


class SnapshotPhotosEndWholeTests(unittest.TestCase):
    def test_first_photos_pid_sdk_end_replays_frozen_same_png_graph_without_live_context(self):
        flow=PhotosEndFlow(self);d=flow.domain;helper=d.photos.helper;host=(flow.host.stat().st_ino,flow.host.read_bytes())
        with flow.owner() as owner:
            literal=deepcopy(owner.graph.previous['originalResult2']);self.assertTrue(literal['photosSDKRetirementRequired'])
            result=owner.finalize();self.assertEqual(84,result['originalPID']);self.assertTrue(result['originalGraphReplayedWithoutSDK'])
            self.assertTrue(result['mainProcessStillOwned']);self.assertTrue(result['sourceMainSDKWitnessRetirementRequired'])
            self.assertEqual(literal,owner.graph.previous['originalResult2']);self.assertEqual(404,owner.state['sdkChecks'][-1]['status'])
            self.assertEqual((1,1),(helper.stop_calls,helper.delete_calls));self.assertIsNone(helper.session.read())
            process,history=owner.process_history();self.assertTrue(history['windows'][-1]['complete']);self.assertGreaterEqual(history['windows'][-1]['elapsedMs'],3000)
        with flow.owner() as repeated:self.assertEqual(result,repeated.finalize())
        self.assertEqual((1,1),(helper.stop_calls,helper.delete_calls));self.assertFalse(helper.sdk_alive)
        with flow.journey() as fresh:
            before=(deepcopy(helper.requests),deepcopy(helper.sdk),deepcopy(d.main.commands))
            with (patch.object(helper,'execute',side_effect=AssertionError('Retired historical SDK command')),
                    patch.object(helper,'call',side_effect=AssertionError('Retired historical SDK read')),
                    patch.object(PrivateFeatureState,'write',side_effect=AssertionError('Retired historical write'))):
                historical=SnapshotPhotosEndOwner.history(fresh,flow.helper());self.assertEqual(result,historical.proof())
                position=SnapshotPhotosRetiredSDKPosition(historical);self.assertEqual(literal,historical.graph.replay(position))
                row=historical.graph.row_store(1).path;held=row.with_name('held-photos-end-pin.json');row.rename(held)
                try:
                    with self.assertRaises(NativeUIError):historical.proof()
                finally:held.rename(row)
            self.assertEqual(before,(helper.requests,helper.sdk,d.main.commands))
        self.assertEqual(host,(flow.host.stat().st_ino,flow.host.read_bytes()));self.assertTrue(d.main_foreground)
        self.assertEqual((1,1,1,1,1),(d.main.upload_count,d.photos.save_count,helper.read_count,helper.delete_count,helper.retire_count))
    def test_lost_delivered_stop_and_sdk_delete_cold_reopen_original_without_second_effect(self):
        flow=PhotosEndFlow(self);helper=flow.domain.photos.helper;helper.lose_stop=True
        with flow.owner() as first:
            with self.assertRaisesRegex(NativeUIError,'lost Photos Stop'):first.finalize()
            self.assertTrue(first.state['stopIssued']);self.assertFalse(first.state['processReady']);stop_record=first.store.read()
        self.assertEqual((1,0),(helper.stop_calls,helper.delete_calls));helper.lose_delete=True
        with flow.owner() as second:
            self.assertIsNot(first,second);self.assertEqual(stop_record,second.previous)
            with self.assertRaises(WebDriverRequestError):second.finalize()
            self.assertTrue(second.state['sdkIssued']);self.assertFalse(second.state['sdkAbsent']);delete_record=second.store.read()
        self.assertEqual((1,1),(helper.stop_calls,helper.delete_calls));self.assertFalse(helper.sdk_alive);self.assertIsNotNone(helper.session.read())
        with flow.owner() as third:
            self.assertIsNot(second,third);self.assertEqual(delete_record,third.previous)
            result=third.finalize();self.assertTrue(result['localSDKPointerRetired']);self.assertTrue(result['originalPhotosSDK404'])
        self.assertEqual((1,1),(helper.stop_calls,helper.delete_calls));self.assertIsNone(helper.session.read())
        self.assertTrue(flow.domain.main_foreground);self.assertTrue(flow.host.exists())


if __name__=='__main__':unittest.main()
