"""Root-only current metadata step before one separately granted profile."""
from profile_metadata import HERE,REPO,frozen,originals,pin,save,sources,prior_originals
value=frozen();before=sources(value);old=originals(value);prior_originals(value);after=sources(value);old_after=originals(value)
assert before==after and old==old_after
save(HERE/'actual-source-map.json',dict(status='ACTUAL_CURRENT_DIAGNOSTIC_SOURCE_MAP',worktree=str(REPO),sourcePins=before,originalReference=pin(REPO/value['originalReference']),originalFiles=789))
print('ACTUAL_SOURCE_PINS',len(before),flush=True)
