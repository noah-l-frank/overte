import ast,hashlib,json,stat,difflib
from pathlib import Path
R=Path.cwd();P=R/'.ios-host-tmp/emote-callback-window-flow-cache-focused-window-corrected-root-preparation-20261103';B=R/'.ios-host-tmp/emote-callback-live-prefix-current235-readonly-profile-corrected-root-preparation-20261103/profile1';G=R/'.ios-host-tmp/emote-callback-live-prefix-fresh-postboot-scoped22-graph-root-preparation-20261103/graph1';S=R/'.ios-host-tmp/emote-callback-window-flow-cache-focused-source-overlay-20261103';PUB=R/'.ios-host-tmp/avatar-lifecycle-emote-window-and-qualified-docs-root-publication-20261103/manifest.json';SC=R/'.ios-host-tmp/emote-callback-live-prefix-scoped22-tail5-root-preparation-20261103';TAIL=SC/'tail5';assert not(P/'freeze.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.open('x').write(s)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in F])
 if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
 assert v['stat']==[getattr(p.lstat(),k) for k in F];return v
publication=json.loads(PUB.read_text());assert len(publication['files'])==12
oldmap=json.loads((B/'root-run-first/root-source-map.json').read_text())['currentSourcePins'];expected=dict(oldmap)
for rel,row in publication['files'].items():assert expected.get(rel)==row['baseSha256'];assert sha(R/rel)==row['candidateSha256'];expected[rel]=row['candidateSha256']
assert len(set(expected)^set(oldmap))==4
save(P/'actual-reviewed-publication-delta.json',dict(manifest=str(PUB),manifestSHA256=sha(PUB),files=publication['files'],oldMapStage=str(B),unchangedHelper='4fea6757d1a6903dce66ecfd5d94e6f13138b9dbbdaa2cce78a105fcf7db7994',historicalMetricsScope='One literal235 archive read interval; owner/reference metadata and parser registration prepared outside timer, empty rowcache; not whole/API latency.',wholeFeatureQualified=False))
prior=json.loads((B/'prior-retained-original-pins.json').read_text());newpins={}
for stage in (B,G,TAIL):
 frozen=set(json.loads((stage/'freeze.json').read_text())['files'])|{'freeze.json'}
 for p in stage.rglob('*'):
  if str(p.relative_to(stage)) not in frozen:newpins[str(p)]=pin(p)
for p in (PUB,SC/'root-scoped22-report.json'):newpins[str(p)]=pin(p)
prior.update(newpins);save(P/'actual-proof-current-pins.json',newpins)
write(P/'reviewed_scoped22.py',(SC/'scoped_prerequisite.py').read_text());write(P/'prior_scoped_prerequisite.py',(SC/'prior_scoped_prerequisite.py').read_text())
gate='''"""Actual27 +current235 profile historical scope, exact reviewed12 PUB delta."""
import hashlib,json,stat
from pathlib import Path
from reviewed_scoped22 import historical
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
SC=Path(%r);TAIL=SC/'tail5';PROFILE=Path(%r)
def checkpins(master):
 pins=json.loads((master/'actual-proof-current-pins.json').read_text())
 for name,expected in pins.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();v=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):v['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert v==expected and v['stat']==[getattr(p.lstat(),k) for k in F]
 return [Path(name) for name in pins]
def exited(out):
 p=json.loads((out/'process-binding.json').read_text())['task']
 try:row=Path('/proc',str(p['pid']),'stat').read_text().rsplit(') ',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):row=None
 assert row is None or int(row[19])!=p['startTicks']
def passed(stage,count):
 out=stage/'root-run-first';r=json.loads((out/'report.json').read_text());assert r['exitCode']==0 and all(r[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not r['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text());assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 cases=json.loads((stage/'run-plan.json').read_text())['cases'];a=json.loads((stage/'selected-result.json').read_text());assert len(cases)==count and a['selectedIds']==cases and a['successful'] and a['testsRun']==count and not any(a[k] for k in ('failureCount','errorCount','skippedCount'))
 for i,case in enumerate(cases,1):
  c=stage/('case-cleanup-'+str(i));r=json.loads((c/'receipt.json').read_text());assert r['case']==case and r['actualStandardCaseRunReturned'] and r['twoCensusesPassed']
  a=json.loads((c/'terminal-census-1.json').read_text());b=json.loads((c/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 a=json.loads((stage/'terminal-census-1.json').read_text());b=json.loads((stage/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 return cases

def require(here,repo,current=None):
 master=here.parent;paths=checkpins(master);actual,oldpaths=historical(SC,repo);paths+=oldpaths
 assert json.loads((SC/'root-scoped22-report.json').read_text())==actual;tail=passed(TAIL,5);scope=json.loads((SC/'scope-plan.json').read_text());assert tail==scope['tail'] and len(set(scope['unchangedPrefix']+tail))==27
 passed(PROFILE,1);metric=json.loads((PROFILE/'profile-result.json').read_text());assert metric['historicalOnly'] and metric['originalFiles']==235 and metric['records']==1 and metric['cacheRows']==1 and metric['coldReopenCalls']>=2 and metric['warmReopenCalls']==0 and metric['readMembership']==215 and metric['readMembershipEqual'] and metric['allOriginalPinsUnchanged'] and not metric['old747RuntimeReplay']
 delta=json.loads((master/'actual-reviewed-publication-delta.json').read_text());manifest=Path(delta['manifest']);assert hashlib.sha256(manifest.read_bytes()).hexdigest()==delta['manifestSHA256'];assert json.loads(manifest.read_text())['files']==delta['files']
 old=json.loads((PROFILE/'root-run-first/root-source-map.json').read_text());expected=dict(old['currentSourcePins']);assert old['repositoryRoot']==str(repo)
 for name,row in delta['files'].items():assert expected.get(name)==row['baseSha256'];expected[name]=row['candidateSha256']
 if current is not None:assert current['currentSourcePins']==expected
 for name,digest in expected.items():
  p=repo/name;assert p.is_relative_to(repo) and p.resolve(strict=True)==p and hashlib.sha256(p.read_bytes()).hexdigest()==digest
 if here.name=='window1':
  first=master/'focused2';passed(first,2)
  frozen=set(json.loads((first/'freeze.json').read_text())['files'])|{'freeze.json'}
  for p in first.rglob('*'):
   if str(p.relative_to(first)) not in frozen:assert p.resolve(strict=True)==p;paths.append(p)
 checkpins(master)
 return paths+[manifest,master/'actual-reviewed-publication-delta.json',master/'actual-proof-current-pins.json',master/'reviewed_scoped22.py',master/'prior_scoped_prerequisite.py']
'''%(str(SC),str(B))
write(P/'component_prerequisite.py',gate)
# Exactly reviewed current Node PROGRAM bodies, including Avatar-compatible
# marker fixture changed in the explicit foreign12 publication.
programs=[]
for rel in ('tests/device/ios/self_tests/emote_script_vm_fixture.py','tests/device/ios/self_tests/emote_marker_domain_fixture.py'):
 p=R/rel;tree=ast.parse(p.read_bytes());program=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROGRAM' for t in n.targets)));programs.append(dict(path=rel,sourceSHA256=sha(p),programSHA256=hashlib.sha256(program.encode()).hexdigest()))
sourceplan=json.loads((S/'plan.json').read_text());stages=[]
for name,cases,seconds,roots,aliases in [('focused2',sourceplan['focusedCases'],15,2,['ios.self_tests.test_ios_emote_callback_window_cache_factory']),('window1',[sourceplan['qualificationCase']],600,4,['ios.self_tests.test_ios_emote_marker_scope','ios.self_tests.test_ios_installed_code'])]:
 T=P/name;T.mkdir()
 for rel,d in json.loads((B/'freeze.json').read_text())['files'].items():
  assert sha(B/rel)==d
  if rel.endswith('.py') or rel=='sdk-original-pins.json':write(T/rel,(B/rel).read_text())
 (T/'actual_smoke_prerequisite.py').write_text('from component_prerequisite import require\n');write(T/'component_prerequisite.py',gate);(T/'reviewed_scoped22.py').write_text((SC/'scoped_prerequisite.py').read_text()) if (T/'reviewed_scoped22.py').exists() else write(T/'reviewed_scoped22.py',(SC/'scoped_prerequisite.py').read_text())
 write(T/'monitoring_observer.py',(G/'monitoring_observer.py').read_text())
 observer=(T/'monitoring_observer.py').read_text().replace('(2,5,4,3,1,0)','(5,3,4)');(T/'monitoring_observer.py').write_text(observer)
 if name=='window1':
  # Start from actual audited fresh graph runner: exact original Node/VM close
  # observation without wrapped source methods or process constructors.
  code=(G/'run-selected.py').read_text().replace("    os.environ['EMOTE_FRESH_GRAPH_PROFILE_OUTPUT']=str(HERE/'profile-result.json')\n",'')
  # The component gate is called under the same established module name.
  (T/'run-selected.py').write_text(code)
 else:
  code=(TAIL/'run-selected.py').read_text() # zero-subprocess, original loopback restriction
  (T/'run-selected.py').write_text(code)
 parent=(T/'root-supervise.py').read_text();anchor=' paths.update(require_smoke(HERE,REPO))\n';assert parent.count(anchor)==1
 parent=parent.replace(anchor,anchor+" for n,d in json.loads((HERE/'master-guard-pins.json').read_text()).items():\n  p=HERE.parent/n;assert sha(p)==d;paths.add(p)\n");(T/'root-supervise.py').write_text(parent)
 plan=json.loads((B/'run-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_CACHE_FACTORY_'+name,cases=cases,caseCount=len(cases),totalCaseCount=len(cases),initialOuterSeconds=seconds,expectedRetainedRoots=roots,retainedTemporaryDirectoryAliases=aliases,modelMaps={},mkdtempAliases=[],retainInstalledFixture=False,nodePrograms=programs)
 plan['requiredPublicDependencies']=sorted(set(plan['requiredPublicDependencies'])|{r['path'] for r in sourceplan['sourceRows']}|{r['path'] for r in programs})
 plan['privateFiles']={f.name:sha(f) for f in T.glob('*.py')};save(T/'run-plan.json',plan);save(T/'prior-retained-original-pins.json',prior)
 manifest=json.loads((B/'source-manifest.json').read_text());manifest.update(name=name,stage='changed-cache-'+name,status=plan['status'],caseCount=len(cases),pythonCaseCount=len(cases),initialTimeoutSeconds=seconds,sourcePathCount=4,sourceDeltaPaths=[r['path'] for r in sourceplan['sourceRows']],sourcePaths=[dict(path=r['path'],candidate=str(S/'candidate'/r['path']),candidateSHA256=r['candidateSHA256'],observedPublicSHA256=sha(R/r['path']),changesCurrentPublic=True) for r in sourceplan['sourceRows']])
 manifest['orderedParentFreezes'][str(S.relative_to(R/'.ios-host-tmp'))]=sha(S/'freeze.json');manifest['actualPublicBasis']='Actual Root12 publication manifest exact current delta from historical27/current235 profile; old full source maps retained, not mislabelled current. FullchangedWindow onlyafteractualfocused2PASS.';save(T/'source-manifest.json',manifest)
 superplan=json.loads((B/'supervisor-plan.json').read_text());superplan['initialSeconds']=seconds;save(T/'supervisor-plan.json',superplan)
 save(T/'master-guard-pins.json',{n:sha(P/n) for n in ('actual-reviewed-publication-delta.json','actual-proof-current-pins.json','component_prerequisite.py','reviewed_scoped22.py','prior_scoped_prerequisite.py')})
 for f in T.glob('*.py'):ast.parse(f.read_text())
 save(T/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={f.name:sha(f) for f in T.iterdir() if f.is_file() and f.name!='freeze.json'}));stages.append(dict(name=name,seconds=seconds,killAfterSeconds=5,roots=roots,cases=cases,freeze=sha(T/'freeze.json')))
write(P/'ROOT-PLAN.txt','Root-only focused2 first15+kill5/2realTD (cachefactory metadata mechanisms/defaultLive1), then actualchanged Window1 original600+kill5/4realTD onlyafterfocused2 actualPASS. FourWindowroots=2artifact+2InstalledCodeTests; both actualproducer aliases retained, originalold600also4. Fullnewinputs required because realconstructioncache bypass fixed; old747 preserved/fobiddenruntime. Actual27 and current235singlearchive-read PASS remain historical scopes; exact current12 publicationdelta checked beforeimports/publicmap with no invented currentoldmap. Helper4fea/Live d6/testf4ed unchanged; actualnewSource4 e14a/7659/a71/c476 selected. Node fullargv+currentactualPROGRAMpins fromreviewed changedmarkerfixture, passive Popen+ActualVM ctor/close monitoring only3/4/5; source/noSDK/loopback/percase+aggregate FD/task/thread/process/originalcensuses remain. No Native/SDK/fulljourney claim fromWindowcomponent.\n')
save(P/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',sourceFreeze=sha(S/'freeze.json'),publicationManifest=str(PUB),publicationSHA256=sha(PUB),stages=stages,historical27Scope=True,historical235ArchiveIntervalOnly=True,old747RuntimeReplayForbidden=True,targetImports=False,testsRun=False))
save(P/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(f.relative_to(P)):sha(f) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='freeze.json'},stageFreezes={s['name']:s['freeze'] for s in stages}))
print(json.dumps(dict(freeze=sha(P/'freeze.json'),stages=stages,rawProofPins=len(newpins),nodePrograms=programs)))
