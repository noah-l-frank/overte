"""Prospective actual Parent11 historical readers; no live End/SDK authority.

The archived decoder's completed reader has no runtime/selector and cannot
create a live readmission owner. Actual original files remain read-only.
"""
from copy import deepcopy
from pathlib import Path
import cProfile,hashlib,json,unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.lock import ScriptSourceLock
from adapters.native_clock_join import digest
from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd

REPO=next(path for path in Path(__file__).resolve().parents if(path/'.ios-host-tmp').is_dir()and(path/'tests/device').is_dir())
RUN=REPO/'.ios-host-tmp/audio-parent-idle4-fresh-pid-receipt-preparation11-20261103'
EXPECTED_FREEZE='5785b856982112908006954e3cd5803f2108990e5cbd5fc97513231ef7c49c1f'

class AudioOriginalEndReadphaseTests(unittest.TestCase):
    def setUp(self):
        self.assertEqual(EXPECTED_FREEZE,hashlib.sha256((RUN/'execution-freeze.json').read_bytes()).hexdigest())
        stores=list((RUN/'temporary').rglob('ios-audio-whole-primary-0-process-retirement.json'));self.assertEqual(1,len(stores))
        self.store=PrivateFeatureState(stores[0]);self.archive=self.store.read();self.root=Path(self.archive['artifactRoot'])
        self.binding=self.archive['binding'];self.run=self.archive['runId']
        locks=list(self.store.path.parent.glob('script-feature-sources.lock'));self.assertEqual(1,len(locks))
        self.lock=ScriptSourceLock(locks[0]);self.lock_context=self.lock.held();self.lock_context.__enter__();self.addCleanup(self.lock_context.__exit__,None,None,None)
        flow=json.loads(self.store.path.with_name('ios-audio11-whole-primary.json').read_text())
        self.proof=deepcopy(flow['state']['oldEnd']['proof']);self.proof['archive']=deepcopy(self.archive)
        self.assertEqual(digest(self.archive),self.proof['archiveSha256'])
        # Check every retained original's actual bytes/inode outside the
        # business decoder, and retain the full before/after observation.
        self.before=self.files();self.addCleanup(self.check_files)
    def files(self):
        rows={}
        for path in self.root.iterdir():
            if path.is_file():
                st=path.lstat();rows[path.name]=(st.st_dev,st.st_ino,st.st_mode,st.st_nlink,st.st_size,st.st_mtime_ns,st.st_ctime_ns,hashlib.sha256(path.read_bytes()).hexdigest())
        for path in (self.store.path,self.lock.path):
            st=path.lstat();rows[str(path)]=(st.st_dev,st.st_ino,st.st_mode,st.st_nlink,st.st_size,st.st_mtime_ns,st.st_ctime_ns,hashlib.sha256(path.read_bytes()).hexdigest())
        return rows
    def check_files(self):self.assertEqual(self.before,self.files())
    def reader(self):
        return IOSOriginalKeeperProcessEnd._completed_reader(store=self.store,root=self.root,binding=self.binding,run=self.run,
            role='primary',stage=0,profile_key='audiowhole',lock=self.lock)
    def archived(self,value,**changes):
        args=dict(store=self.store,root=self.root,binding=self.binding,run=self.run,role='primary',stage=0,profile_key='audiowhole',lock=self.lock);args.update(changes)
        return IOSOriginalKeeperProcessEnd.archived_original(value,**args)
    def profiled(self,call):
        profile=cProfile.Profile();result=profile.runcall(call)
        summary=IOSOriginalKeeperProcessEnd._summary.__code__;read=OriginalFrameStore.read.__code__
        return result,sum(row.callcount for row in profile.getstats()if row.code is summary),sum(row.callcount for row in profile.getstats()if row.code is read)
    def test_actual_retained_end_is_equal_and_each_independent_reader_fully_reads_once_without_verdict_cache(self):
        reader=self.reader();self.assertFalse(hasattr(reader,'runtime'))
        for call in (reader.retirement_original,lambda:self.archived(self.proof),reader.retirement_original):
            result,summaries,reads=self.profiled(call)
            self.assertEqual(self.proof,result);self.assertEqual(1,summaries);self.assertGreaterEqual(reads,17)
    def test_changed_in_memory_completed_owner_state_or_previous_metadata_refuses_without_touching_originals(self):
        reader=self.reader();state=deepcopy(reader.state);previous=deepcopy(reader.previous)
        for key in ('phase','canonicalStateAbsence'):
            reader.state=deepcopy(state)
            reader.state[key]='sdk-closed'if key=='phase'else dict(sessionState=False,installedBinding=True)
            with self.assertRaises(NativeUIError):reader.retirement_original()
        reader.state=deepcopy(state);reader.previous=deepcopy(previous);reader.previous['stage']=1
        with self.assertRaises(NativeUIError):reader.retirement_original()
        reader.previous=previous;reader.state=state
    def test_supplied_summary_mutation_with_same_real_archive_digest_never_admits_an_end(self):
        for key,value in (('resourceRetirementEstablished',False),('creatorRetirementOriginalSha256','0'*64),('nativeFeatureInstance','0'*32)):
            forged=deepcopy(self.proof);forged[key]=value
            with self.assertRaises(NativeUIError):self.archived(forged)
    def test_wrong_actual_archive_context_binding_root_role_or_stage_refuses(self):
        for change in (dict(binding=dict(self.binding,generation=self.binding['generation']+1)),dict(root=self.root.parent),dict(role='actor'),dict(stage=1)):
            with self.assertRaises(NativeUIError):self.archived(self.proof,**change)
