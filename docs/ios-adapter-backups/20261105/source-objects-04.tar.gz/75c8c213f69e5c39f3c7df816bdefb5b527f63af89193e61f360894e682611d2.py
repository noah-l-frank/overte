"""Root-granted one saved-graph diagnostic; no source/native/effect verdict."""
from pathlib import Path
import cProfile,hashlib,json,os,pstats,stat,sys,time,traceback
from contextlib import ExitStack
from importlib.machinery import PathFinder
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
plan=json.loads((HERE/'profile-plan.json').read_text());config=json.loads((HERE/'source-root-map.json').read_text())
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
for name,expected in json.loads((HERE/'freeze.json').read_text())['files'].items():assert sha(HERE/name)==expected,name
review=REPO/plan['retainedReview'];assert sha(review/'freeze.json')==plan['retainedReviewFreezeSha256']
for name,expected in json.loads((review/'freeze.json').read_text())['files'].items():assert sha(review/name)==expected
output=Path(os.environ['OVERTE_WORLD6_READONLY_PROFILE_ROOT']).resolve(strict=True)
assert output.is_relative_to(HERE/'runs') and output!=HERE/'runs'
s=output.lstat();assert stat.S_ISDIR(s.st_mode) and stat.S_IMODE(s.st_mode)==0o700 and s.st_uid==os.geteuid()
assert not (output/'profile-result.json').exists()
roots={key:Path(value).resolve(strict=True) for key,value in plan['originalRoots'].items()}
assert len(set(roots.values()))==2 and set(roots)=={'primary','actor'}
fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
    result={key:getattr(a,key) for key in fields}
    if stat.S_ISREG(a.st_mode):result['sha256']=sha(path)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in fields)
    return result
def originals():
    root=Path(plan['actualRetainedTemporaryRoot'])
    return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
before=originals();save(output/'originals-before.json',before)
assert sum(stat.S_ISREG(row['st_mode']) for row in before.values())==645
# Validate existing original lock files BEFORE any product lock can use O_CREAT.
for root in roots.values():
    assert root.is_absolute() and root.resolve(strict=True)==root
    row=(root/'script-feature-sources.lock').lstat()
    assert stat.S_ISREG(row.st_mode) and row.st_nlink==1 and row.st_size==0 and stat.S_IMODE(row.st_mode)==0o600 and row.st_uid==os.geteuid()

def spec_without_import(name):
    search=sys.path;spec=None;parts=name.split('.')
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search));assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:assert search is not None,name
    return spec
assert not any(name.split('.')[0] in {key.split('.')[0] for key in config['packageRoots']} for name in sys.modules)
remaining=[]
for item in sys.path:
    path=Path(item or os.getcwd()).resolve()
    if path==REPO or REPO in path.parents:continue
    if str(path) not in remaining:remaining.append(str(path))
sys.path[:]=[str(REPO/name) for name in config['orderedRoots']]+remaining
for name,relative in config['packageRoots'].items():
    spec=spec_without_import(name);assert [str(Path(p).resolve()) for p in spec.submodule_search_locations or ()]==[str(REPO/relative)],name
for name,row in config['modules'].items():
    spec=spec_without_import(name);assert spec.origin is not None and Path(spec.origin).resolve()==REPO/row['path'] and sha(REPO/row['path'])==row['sha256'],name
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import readonly,scope as actual_read_scope
from adapters.operation_transport_guard import scope as transport_scope
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.witness import Client
from ios.adapters.world_web_feature import IOSWorldWebFeature
from ios.adapters.world_web_runtime import IOSWorldWebRuntime
from ios.adapters.world_web_archived import rebuild
from ios.adapters.world_web_terminal_live import WorldWebTerminalLive
from ios.adapters.world_web_scope_archive import original_round
from ios.adapters.world_web_api_clock import scope as api_scope,SECONDS
assert SECONDS==plan['innerExistingAPISeconds']==25
forbidden_calls=[]
def forbidden(*_args,**_kwargs):
    forbidden_calls.append(True);raise AssertionError('Saved diagnostic forbids live SDK/native/input/fixture status/transport or sleep')
client=object.__new__(Client)
feature=PrivateFeatureState(Path(plan['primaryFeaturePath'])).read();assert feature is not None
client.url=feature['fixtureUrl'].split('/runs/')[0];client.request=forbidden
paths={'primary':roots['primary']/'session.json',feature['peerTarget']:roots['actor']/'session.json'}
base=SimpleNamespace(_candidate_guard=forbidden,_binding=forbidden,state_path=paths.__getitem__,invoke=forbidden)
runtime=IOSWorldWebRuntime(base)
chosen={key:feature[key] for key in ('artifactRoot','imagePolicy','origins')};chosen['actorTarget']=feature['peerTarget']
flow=IOSWorldWebFeature(runtime,'primary',client,feature['runId'],'primary',chosen,epoch_ms=forbidden,monotonic=time.monotonic,sleep=forbidden)
locks={'primary':flow.lock,'actor':ScriptSourceLock(roots['actor']/'script-feature-sources.lock')}
profiler=cProfile.Profile();stage='preflight';error=None;details={};started=time.monotonic()
try:
    with ExitStack() as stack:
        for lock in sorted(locks.values(),key=lambda value:str(value.path)):stack.enter_context(lock.held())
        stack.enter_context(readonly());stack.enter_context(transport_scope(forbidden))
        stack.enter_context(actual_read_scope(fresh=True));stack.enter_context(api_scope(time.monotonic));stack.enter_context(original_round())
        flow.load();assert flow.previous==feature and flow.state['phase']=='paired'
        profiler.enable();stage='existing-historical-rebuild'
        owner=rebuild(flow)
        details['rebuildCompleted']=True;details['currentRetirementRecords']=len(owner.state['records'])
        stage='existing-terminal-live-constructor-decode'
        journal=WorldWebTerminalLive(owner)
        details['liveDecodeCompleted']=True;details['committedLiveRecords']=len(journal.state['records'])
        stage='completed-existing-pure-subpath'
except BaseException as caught:
    error=dict(type=type(caught).__name__,traceback=''.join(traceback.format_exception(caught)))
finally:
    profiler.disable();profiler.dump_stats(str(output/'actual-readonly-profile.pstats'))
    stats=pstats.Stats(profiler);calls=[]
    for (filename,line,function),(primitive,total,self_seconds,cumulative,callers) in stats.stats.items():
        if str(REPO) in filename:
            calls.append(dict(file=str(Path(filename).relative_to(REPO)),line=line,function=function,
                primitiveCalls=primitive,totalCalls=total,selfSeconds=self_seconds,cumulativeSeconds=cumulative))
    save(output/'profile-calls-cumulative.json',sorted(calls,key=lambda row:row['cumulativeSeconds'],reverse=True))
    first=originals();second=originals();save(output/'originals-after-first.json',first);save(output/'originals-after-second.json',second)
    result=dict(status='READONLY_DIAGNOSTIC_ONLY_NOT_A_TEST_OR_PERFORMANCE_VERDICT',lastStage=stage,details=details,error=error,
        measuredSeconds=time.monotonic()-started,innerExistingAPISeconds=25,profileOverheadCannotQualifyTiming=True,
        all645OriginalsByteStatCensusUnchanged=before==first==second,forbiddenLiveCallbacks=len(forbidden_calls),
        nativeExecuted=False,sdkExecuted=False,inputExecuted=False,wholeQualified=False)
    save(output/'profile-result.json',result);print(json.dumps(result),flush=True)
    assert before==first==second,'Original645 changed';assert not forbidden_calls,'A forbidden live path was attempted'
raise SystemExit(0 if error is None else 1)
