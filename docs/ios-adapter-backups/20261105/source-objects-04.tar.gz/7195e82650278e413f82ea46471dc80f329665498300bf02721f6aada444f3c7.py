"""Actual Source AST, WAL and loopback HTTP; SDK/native/source births are models.

Source-owner model coverage supplies no authentication, native freshness, IPA
binding, native touch or resource retirement qualification.
"""
from __future__ import annotations
import ast,asyncio,hashlib,inspect,json,marshal,os,re,socket,threading,time,unittest,uuid,weakref
from contextlib import asynccontextmanager,suppress
from copy import deepcopy
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from unittest.mock import patch


class OriginalNativeQueryOwnerModels(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        raw=Path(os.environ['LIFECYCLE_NATIVE_QUERY_MAP']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_NATIVE_QUERY_MAP_SHA256']:raise RuntimeError('Actual source map required before target imports')
        self.mapping=json.loads(raw)
        for row in self.mapping.values():
            if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('Actual source changed')
        from ios.self_tests import test_ios_touch_lease as fixture
        from adapters.normal_feature_state import PrivateFeatureState
        self.private_type=PrivateFeatureState;self.f=fixture.TouchLeaseTests();self.f.setUp()
        for callback,args,kwargs in self.f._cleanups:self.addCleanup(callback,*args,**kwargs)
        self.f._cleanups.clear();self.addAsyncCleanup(self.f.asyncTearDown)
        self.binding=dict(self.f.binding,processIdentity='42');self.loop=asyncio.get_running_loop();self.loop_thread=threading.get_ident()
        self.current_threads=[];self.received=[];self.http_errors=[];self.response_gate=threading.Event();self.response_gate.set();self.received_event=threading.Event()
        self.drop_response=False;self.fresh_hook=None;self.tasks=[];self.controls=[]
        path=Path(self.mapping['keeper']['path']);tree=ast.parse(path.read_bytes())
        nodes=[next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name) for name in ('OriginalKeeperSource','OriginalKeeperOperations')]
        module=ast.Module(body=nodes,type_ignores=[]);code=compile(ast.fix_missing_locations(module),str(path),'exec')
        metadata=dict(sourceSha256=self.mapping['keeper']['sha256'],selectedAstSha256=hashlib.sha256(ast.dump(module,include_attributes=False).encode()).hexdigest(),compiledCodeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest())
        out=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT']);info=out.stat();self.assertEqual(0o700,info.st_mode&0o777);self.assertEqual(os.geteuid(),info.st_uid)
        fd=os.open(out/(uuid.uuid4().hex+'.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as stream:json.dump(metadata,stream,sort_keys=True);stream.write('\n')
        ns=dict(asyncio=asyncio,weakref=weakref,inspect=inspect,asynccontextmanager=asynccontextmanager,uuid=uuid,re=re,json=json,time=time,LaunchError=RuntimeError)
        exec(code,ns);self.source_type=ns['OriginalKeeperSource'];self.ops_type=ns['OriginalKeeperOperations'];outer=self
        class RSD:pass
        class Capability:
            # Explicit original SDK socket-factory model, resolved before the
            # injected HID context call; never an authentication/source claim.
            udp_socket=staticmethod(socket.socket)
            def current(_):
                outer.current_threads.append(threading.get_ident());outer.assertIs(asyncio.get_running_loop(),outer.loop)
                return outer.rsd,'fd00::1'
        class Tunnel:
            def original_source(_):return outer.cap
        self.rsd=RSD();self.cap=Capability();self.tunnel=Tunnel()
        self.source=self.source_type.__new__(self.source_type);self.source._tunnel=weakref.ref(self.tunnel);self.source._source=self.cap
        self.source._loop=self.loop;self.source._born=[];self.source._leases=[];self.source._native_reads=[];self.source._native_queries=[];self.source._closing=False
        self.ops=self.make_ops()
        class Handler(BaseHTTPRequestHandler):
            protocol_version='HTTP/1.1'
            def log_message(self,*_args):pass
            def do_POST(self):
                try:
                    length=int(self.headers['Content-Length']);body=self.rfile.read(length);command=json.loads(body)
                    wal=outer.wal().read();outer.received.append(dict(path=self.path,command=command,wal=deepcopy(wal),thread=threading.get_ident()))
                    outer.received_event.set()
                    if not outer.response_gate.wait(5):raise TimeoutError('Declared HTTP response gate was not released')
                    if outer.drop_response:self.close_connection=True;return
                    self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body);self.wfile.flush()
                except (BrokenPipeError,ConnectionResetError):pass
                except BaseException as error:outer.http_errors.append(error);self.close_connection=True
        self.server=HTTPServer(('127.0.0.1',0),Handler);self.origin='http://127.0.0.1:'+str(self.server.server_address[1])
        self.http_thread=threading.Thread(target=lambda:self.server.serve_forever(poll_interval=.01),name='modeled-native-query-http',daemon=False);self.http_thread.start()
        self.addAsyncCleanup(self.cleanup_queries)

    def make_ops(self):
        ops=self.ops_type(self.source,self.f.store.path.parent);ops.session=dict(sessionId=self.binding['sessionId'],archiveBundleId='org.example.overte',wdaBundleId='org.example.wda')
        async def fresh(binding):
            self.assertEqual(self.binding,binding);self.source.current()
            if self.fresh_hook is not None:await self.fresh_hook()
        ops.fresh_touch_scope=fresh;return ops
    def wal(self):return self.private_type(self.f.store.path.parent/('ios-lifecycle-native-query-owner-'+self.f.run_id+'.json'))
    def args(self):return dict(binding=deepcopy(self.binding),runId=self.f.run_id,resultsDirectory='owned',origin=self.origin,action='feature-native-observe')
    def start(self,args=None):
        task=asyncio.create_task(self.ops.execute('touch-native-query',self.args() if args is None else args,self.binding['sessionId']));self.tasks.append(task);return task
    async def wait_received(self):
        deadline=self.loop.time()+2
        while not self.received_event.is_set():
            if self.loop.time()>=deadline:raise AssertionError('Actual HTTP request did not arrive')
            await asyncio.sleep(.005)
    async def cleanup_queries(self):
        self.response_gate.set();self.f.context.enter_gate.set();self.f.context.down_gate.set();self.f.context.drain_gate.set()
        self.source._loop=self.loop;self.ops.source=self.source;self.ops.touch=None;self.ops.touch_resources=None
        for task in self.tasks:
            with suppress(BaseException):await asyncio.wait_for(asyncio.shield(task),7)
        await self.source.settle_touches()
        if self.controls:await asyncio.gather(*self.controls,return_exceptions=True)
        self.server.shutdown();self.server.server_close();self.http_thread.join(timeout=5)
        self.assertFalse(self.http_thread.is_alive());self.assertEqual([],self.http_errors)
        for task,thread,finished,loop in self.source._native_queries:
            self.assertTrue(task.done());self.assertFalse(thread.is_alive());self.assertTrue(finished.is_set());self.assertIs(self.loop,loop)
    async def touch(self):
        with patch('ios.adapters.hid_session.touch_session',side_effect=lambda *_a,**_k:self.f.context):
            lease=self.source.touch_lease(self.f.store,binding=self.binding,run=self.f.run_id,check=lambda:True)
            self.f.owner=lease;self.ops.touch=lease;await lease.begin(100,50,25,10,seconds=3)
        return lease

    async def test_actual_echo_follows_owned_durable_nonce_intent_and_all_sdk_guards_use_original_loop(self):
        result=await self.start();self.assertEqual(1,len(self.received));received=self.received[0]
        self.assertEqual('/e2e-client-command.json',received['path']);self.assertEqual('intent',received['wal']['records'][0]['phase'])
        self.assertEqual(received['command'],received['wal']['records'][0]['query']);self.assertEqual(received['command'],result['query'])
        self.assertEqual('http-returned',self.wal().read()['records'][0]['phase']);self.assertEqual({self.loop_thread},set(self.current_threads));self.assertNotEqual(self.loop_thread,received['thread'])
        self.assertTrue(result['queryIntentOwned']);self.assertTrue(result['httpReturnObserved'])
        self.assertTrue(all(not result[key] for key in ('nativeDeliveryAcknowledged','freshNativeAcquisitionEstablished','installedCandidateBound','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished')))

    async def test_caller_supplied_nonce_is_rejected_before_any_intent_or_http(self):
        args=self.args();args['query']=dict(schemaVersion=1,commandId='ios-'+'a'*32,action=args['action'])
        with self.assertRaises(RuntimeError):await self.start(args)
        self.assertIsNone(self.wal().read());self.assertEqual([],self.received);self.assertEqual([],self.source._native_queries)

    async def test_lost_http_return_retains_original_nonce_and_next_query_never_replays_it(self):
        self.drop_response=True
        with self.assertRaises(Exception):await self.start()
        first=self.wal().read();self.assertEqual('http-uncertain',first['records'][0]['phase']);self.assertEqual(1,len(self.received))
        self.drop_response=False;result=await self.start();last=self.wal().read()
        self.assertEqual(first['records'][0],last['records'][0]);self.assertNotEqual(first['records'][0]['query']['commandId'],result['query']['commandId'])
        self.assertEqual([row['query'] for row in last['records']],[row['command'] for row in self.received])

    async def test_lost_committed_intent_readback_retains_pending_and_never_adopts_or_dispatches(self):
        write=self.private_type.write
        def lost(store,value,previous):
            write(store,value,previous)
            if store.path==self.wal().path:raise OSError('Declared lost write acknowledgement AFTER actual fsync/replace')
        with patch.object(self.private_type,'write',new=lost),self.assertRaises(OSError):await self.start()
        original=self.wal().read();journal=self.ops.native_query_journals[self.f.run_id]
        self.assertEqual(original,journal['pending']);self.assertIsNone(journal['previous']);self.assertEqual('intent',original['records'][0]['phase'])
        with self.assertRaises(RuntimeError):await self.start()
        self.assertEqual(original,self.wal().read());self.assertEqual([],self.received)

    async def test_cold_owner_cannot_adopt_even_exact_unchanged_wal_from_original_query(self):
        await self.start();original=self.wal().read();self.ops=self.make_ops()
        with self.assertRaises(RuntimeError):await self.start()
        self.assertEqual(original,self.wal().read());self.assertEqual(1,len(self.received));self.assertEqual({},self.ops.native_query_journals)

    async def test_real_deadline_expiry_before_send_refuses_without_retiming_or_http(self):
        async def delayed():await asyncio.sleep(1.55)
        self.fresh_hook=delayed
        with self.assertRaises(RuntimeError):await self.start()
        self.assertEqual([],self.received);self.assertIsNone(self.wal().read());self.assertEqual([],self.source._native_queries)

    async def test_closing_and_cancelled_caller_keep_actual_original_http_thread_until_return(self):
        self.response_gate.clear();task=self.start();await self.wait_received();thread=self.source._native_queries[0][1]
        task.cancel();entered=asyncio.Event();source_closed=[]
        async def creator_exit():entered.set();await self.source.settle_touches();source_closed.append(True)
        exiting=asyncio.create_task(creator_exit());self.controls.append(exiting);await entered.wait()
        self.assertTrue(self.source._closing);self.assertTrue(thread.is_alive());self.assertFalse(task.done());self.assertFalse(exiting.done());self.assertEqual([],source_closed)
        self.response_gate.set()
        with self.assertRaises(asyncio.CancelledError):await task
        await exiting;self.assertEqual([True],source_closed);self.assertFalse(thread.is_alive());self.assertEqual('http-uncertain',self.wal().read()['records'][0]['phase'])

    async def test_foreign_original_loop_cannot_start_query_or_create_a_worker(self):
        self.source._loop=object()
        with self.assertRaises(RuntimeError):await self.start()
        self.source._loop=self.loop;self.assertIsNone(self.wal().read());self.assertEqual([],self.received);self.assertEqual([],self.source._native_queries)

    async def test_release_after_real_once_down_refuses_accepted_query_and_preserves_original_once_up(self):
        lease=await self.touch();self.response_gate.clear();task=self.start();await self.wait_received();lease.request_release.set();self.response_gate.set()
        with self.assertRaises(RuntimeError):await task
        await self.source.settle_touches();self.assertEqual([0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        self.assertEqual(1,len(self.received));self.assertEqual('http-uncertain',self.wal().read()['records'][0]['phase'])

    async def test_disk_query_mutation_during_http_refuses_before_any_native_acquisition_authority(self):
        self.response_gate.clear();task=self.start();await self.wait_received();original=self.wal().read();foreign=deepcopy(original)
        foreign['records'][0]['query']['commandId']='ios-'+'f'*32;self.wal().write(foreign,original);self.response_gate.set()
        with self.assertRaises(RuntimeError):await task
        self.assertEqual(foreign,self.wal().read());self.assertEqual(1,len(self.received));self.assertEqual(original,self.ops.native_query_journals[self.f.run_id]['previous'])
