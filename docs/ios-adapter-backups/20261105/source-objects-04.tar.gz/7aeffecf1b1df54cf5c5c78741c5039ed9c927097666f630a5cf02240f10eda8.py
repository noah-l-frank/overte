"""Private complete Profile9 terminal family; old terminal classes unchanged."""
from copy import deepcopy
from adapters.native_feature_observation import need
from adapters.script_feature.history import same
from ios.adapters.emote_callback_terminal import (IOSEmotePostControllerCallbackFeature,
    IOSEmotePostControllerCallbackTerminal,IOSEmoteCallbackResponsibility,
    IOSEmoteCallbackTerminalJournal,IOSEmoteCallbackInventory)
from ios.adapters.emote_rooted_responsibility import IOSEmoteRootedResponsibility
from ios.adapters.emote_post_controller_runtime_sources import callback_inventory
from ios.adapters.emote_post_controller_end_boundary import existing_profile9_actor


class IOSEmotePost9Responsibility(IOSEmoteCallbackResponsibility):
    def validate(self,values,parts,owner,live):
        # The old complete original recovery/scene/publication obligations run
        # unchanged. Only this NEW family uses a fully typed palette inventory
        # instead of invoking Source4's deliberately closed End-only branch.
        IOSEmoteRootedResponsibility.validate(self,values,parts,owner,live)
        retained=callback_inventory(self.flow,parts);retained.bound()
        need(retained.owner is not None and retained.manifest['uncertainRead']is False
            and retained.stable and all(flag is True for flag in retained.stable))
        values[str(retained.owner_path)]=deepcopy(retained.owner.previous)
        self.post_controller_inventory=retained
    def guard(self):
        IOSEmoteRootedResponsibility.guard(self)
        self.post_controller_inventory.bound();return True


class IOSEmotePost9Terminal(IOSEmotePostControllerCallbackTerminal):
    Responsibility=IOSEmotePost9Responsibility
    existing_actor=staticmethod(existing_profile9_actor)
    # Ordinary invoke(finish) is inherited DENY. Only separately named typed
    # source7 completion is wired by the new explicit entrypoint.
