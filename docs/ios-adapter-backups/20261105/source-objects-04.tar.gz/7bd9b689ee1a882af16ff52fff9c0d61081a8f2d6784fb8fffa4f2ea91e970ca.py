"""One fixed-cap Audio45 host run with complete source pins and real originals."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tempfile,time
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
MAP=HERE/'root-actual-source-map.json';MAPPING=json.loads(MAP.read_text())
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    a=path.lstat();value={k:getattr(a,k) for k in FIELDS}
    if stat.S_ISREG(a.st_mode):value['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    else:assert stat.S_ISDIR(a.st_mode)
    b=path.lstat();assert all(getattr(a,k)==getattr(b,k) for k in FIELDS),str(path)
    return value
def save(name,value):(HERE/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def sources():
    paths={REPO/name for name in MAPPING['sources']}
    paths.update(HERE/name for name in ('root-supervise45.py','root-actual-source-map.json','root-publication.json'))
    references=json.loads((HERE/'frozen-packet-input-pins.json').read_text())
    for name,sha in references.items():
        path=REPO/name;assert hashlib.sha256(path.read_bytes()).hexdigest()==sha,name;paths.add(path)
    return {str(p.relative_to(REPO)):pin(p) for p in sorted(paths)}
def originals(roots):
    return {str(root):{str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))} for root in sorted(roots)}
def process(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
assert not (HERE/'root45-report.json').exists() and not (HERE/'root45-first.log').exists(),'Single use only'
runs=HERE/'runs';runs.mkdir(mode=0o700,exist_ok=True)
runroot=Path(tempfile.mkdtemp(prefix='root45-first-',dir=runs));runroot.chmod(0o700)
temporary=runroot/'temporary';temporary.mkdir(mode=0o700)
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='tests/device:tests/device/self_tests:tests/device/ios/self_tests',TMPDIR=str(temporary),AUDIO_ORIGIN_ACTUAL_ROOT_MAP=str(MAP),AUDIO_ORIGIN_ACTUAL_ROOT_MAP_SHA256=hashlib.sha256(MAP.read_bytes()).hexdigest())
before=sources();save('root45-source-before.json',before);started=time.monotonic()
print('SOURCE_LAUNCHER_REFERENCE_PINS',len(before),flush=True)
with (HERE/'root45-first.log').open('x') as log:
    task=subprocess.Popen(['timeout','--signal=TERM','--kill-after=5s','180s',sys.executable,str(HERE/'run-exact45.py')],cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    binding=process(task.pid);assert binding is not None;save('root45-process-binding.json',binding)
    print('ACTUAL_PROCESS',json.dumps(binding,sort_keys=True),flush=True);code=task.wait()
after=sources();save('root45-source-after.json',after);assert before==after,'Source/launcher drift'
roots={temporary}|({HERE/'retained-first45'} if (HERE/'retained-first45').exists() else set())
first=originals(roots);save('root45-originals-first.json',first)
second=originals(roots);save('root45-originals-second.json',second);assert first==second,'Post-stop originals changed'
remaining=[]
for path in Path('/proc').iterdir():
    if not path.name.isdecimal():continue
    item=process(int(path.name))
    if item is not None and item['session']==task.pid:remaining.append(item)
report=dict(exitCode=code,seconds=time.monotonic()-started,runRoot=str(runroot),sourcePins=len(after),allPinsEqual=True,originalFiles=sum(stat.S_ISREG(row['st_mode']) for rows in first.values() for row in rows.values()),postStopOriginalCensusesEqual=True,remainingOwnedProcesses=remaining,nativeCompiled=False,sdkExecuted=False,deviceQualified=False,physicalADCQualified=False,acousticQualified=False,peerQualified=False,wholeFeatureQualified=False)
save('root45-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
assert not remaining
raise SystemExit(code)
