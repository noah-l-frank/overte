"""Complete three-original Actor set through the unchanged publication WAL.

The initial two commitments remain exact; index3 adds restored-source history.
No arbitrary subset, role, callback or synthetic live source is admitted.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from feature_journeys.phase_fixture import PhaseFixtureReader
from feature_journeys.witness import Client
from ios.adapters.lifecycle_received_actor_world import LifecycleReceivedActorWorld
from ios.adapters.lifecycle_actor_publication import LifecycleActorCanonicalPublication,LifecycleActorSamplePublisher


class LifecycleRestoredActorPublication(LifecycleActorCanonicalPublication):
    def __init__(self,owners,client=None,*,historical=False):
        need(type(owners)is tuple and len(owners)==3 and all(type(owner)is LifecycleReceivedActorWorld for owner in owners)
            and tuple(owner.index for owner in owners)==(1,2,3)and type(historical)is bool)
        first,last=owners[0],owners[-1]
        need(all(owner.lock is first.lock and owner.run==first.run and same(owner.binding,first.binding)
            and owner.fixture_url==first.fixture_url and owner.store.path.parent==first.store.path.parent for owner in owners))
        self.owners,self.lock,self.binding,self.run,self.historical=owners,first.lock,deepcopy(first.binding),first.run,historical
        self.store=PrivateFeatureState(first.store.path.with_name('phase-publication-lifecycle-input-'+first.run+'-actor.json'))
        self.client,self.phase,self.publisher=client,None,None
        if historical:need(client is None and all(owner.historical for owner in owners))
        else:
            need(isinstance(client,Client)and not last.historical and last.fixture_url==client.url+'/runs/'+first.run+'/')
            self.phase=PhaseFixtureReader(client,self.run,'lifecycle-input',epoch_ms=last.epoch_ms,monotonic=last.monotonic)
        self.guard()

    def prepare(self):
        need(not self.historical);self.guard()
        if self.publisher is None:
            self.phase.status();last=self.owners[-1]
            self.publisher=LifecycleActorSamplePublisher(self.store,self.binding,self.phase,self.lock,self.guard,self.validate_original,
                epoch_ms=last.epoch_ms,monotonic=last.monotonic)
        return self.publisher
