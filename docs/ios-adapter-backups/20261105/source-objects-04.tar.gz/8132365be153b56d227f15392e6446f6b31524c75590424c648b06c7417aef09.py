"""One capture's immutable original proof; no current-frame/result cache.

The full typed frozen marker is decoded twice before native acquisition.
After image composition, exact saved record/PNG bytes and every earlier
immutable dependency must still match. Every later archive remains cold and
independent. Acquisition/native clocks and final current guards stay outside
this helper and retain their original limits.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_clock_join import digest
from adapters.native_feature_observation import need
from adapters.original_file_reads import collect,scope
from adapters.original_marker_scope import OriginalMarkerScope
from adapters.original_frame_store import OriginalFrameStore
from adapters.owned_vulkan_world_frame import VulkanWorldFrameOwner
from adapters.script_feature.history import same
from ios.adapters.avatar_record_cache import AvatarRecordCache
from ios.adapters.avatar_sample_return_literal import AvatarSampleReturnLiteral
from ios.adapters import avatar_images
from ios.adapters.emote_callback_live_records import _token


class AvatarSampleReturnProof:
    def __init__(self,owner):
        owner.lock.assert_held();need(not owner.historical)
        self.owner,self.lock,self.root=owner,owner.lock,owner.root
        self.binding,self.run,self.role=deepcopy(owner.binding),owner.run,owner.role
        self.value=deepcopy(owner.state['markerOwner']);self.marker=None;self.paths=set();self.signatures=None;self.literal=None
        def decode():
            return owner.Marker.archive(self.value,root=self.root,binding=self.binding,run=self.run,
                role=self.role,lock=self.lock,require_ready=True)
        # The active original scope also checks deterministic earlier index
        # prefixes, including an absent optional prefix. Its namespace is
        # retained separately, so a later name birth cannot gain membership.
        with scope(fresh=True),collect() as first:marker=decode()
        # Declared marker-only test models have no original file membership.
        # They keep the full existing archive path instead of gaining a lease.
        if not first:return
        roots=[OriginalMarkerScope,OriginalFrameStore,VulkanWorldFrameOwner,AvatarRecordCache,owner.Marker,owner.Marker.archive.__func__,owner.Marker.decode,owner.Marker.validate_frame,
            OriginalMarkerScope.bind_image_world,OriginalMarkerScope.ui_absent,
            owner.read_record.__func__,owner.validate_record.__func__,owner.partial.__func__,owner.follow.__func__,
            OriginalFrameStore.read,OriginalFrameStore.manifest,OriginalFrameStore.restore,
            VulkanWorldFrameOwner.archive_original.__func__,VulkanWorldFrameOwner.__init__,VulkanWorldFrameOwner._load,
            VulkanWorldFrameOwner._read,VulkanWorldFrameOwner._file,VulkanWorldFrameOwner.archive,
            avatar_images.compose,avatar_images.image_observation,avatar_images.original_pixels,
            type(self),type(self).check,type(self).namespace,type(self).verify_saved,type(self).dependencies]
        roots.extend(vars(marker.components).values())
        literal=AvatarSampleReturnLiteral(roots)
        if literal.policy is None:return  # Unsupported/declared parsers remain cold.
        namespace=self.namespace(marker);signatures=AvatarRecordCache.signatures(first)
        with scope(fresh=True),collect() as second:confirmed=decode()
        need(first==second and AvatarRecordCache.signatures(second)==signatures
            and same(marker.state,confirmed.state) and same(marker.frames,confirmed.frames)
            and self.namespace(confirmed)==namespace and literal.literal())
        self.marker,self.paths,self.signatures=confirmed,set(second),signatures
        self.literal=literal;self.namespace_names=namespace;self.marker_type=type(confirmed)
        self.marker_graph=digest(dict(state=confirmed.state,frames=confirmed.frames))
        self.marker_components=confirmed.components;self.component_refs=[]
        self.component_policy=_token(vars(self.marker_components),self.component_refs,set())
        self.check()

    @property
    def available(self):return self.marker is not None

    def check(self):
        need(self.available and self.owner.lock is self.lock and self.owner.root==self.root
            and self.owner.run==self.run and self.owner.role==self.role and same(self.owner.binding,self.binding)
            and same(self.owner.state['markerOwner'],self.value))
        self.lock.assert_held()
        need(self.literal.literal() and type(self.marker) is self.marker_type
            and digest(dict(state=self.marker.state,frames=self.marker.frames))==self.marker_graph
            and self.marker.components is self.marker_components
            and _token(vars(self.marker_components),[],set())==self.component_policy
            and self.namespace(self.marker)==self.namespace_names
            and AvatarRecordCache.signatures(self.paths)==self.signatures)

    def namespace(self,marker):
        original=marker.originals
        need(original.root==self.root and original.run==self.run and original.role==self.role
            and original.namespace=='avatar' and original.kind=='inputs')
        prefixes=tuple('avatar-'+kind+'-inputs-'+self.run+'-'+self.role+'-' for kind in ('frame','index'))
        names=tuple(sorted(path.name for path in self.root.iterdir() if path.name.startswith(prefixes)))
        need(len(names)<=2048);return names

    @staticmethod
    def dependencies(paths):
        need(type(paths) is set)
        return {} if not paths else AvatarRecordCache.signatures(paths)

    def verify_saved(self,row,record_digest,raw,dependencies):
        """Exact same composition inputs only; never supply a new observation."""
        self.check();owner=self.owner
        record=owner.read_record(row,historical=True)
        need(record['status']=='observed' and digest(record)==record_digest and record['markerSha256']==digest(self.value))
        # Reopen the exact persisted original row and repeat prior-prefix and
        # immutable marker/world admission. Nothing comes from a new SDK read.
        frame=record['partial']
        owner.follow(frame,phase_before=frame['phaseBefore'],before_index=record['index'])
        self.marker.bind_image_world(frame['worldBefore']);self.marker.bind_image_world(frame['worldAfter'])
        original=VulkanWorldFrameOwner.archive_original(record['owner'],self.root,self.binding,self.run,self.role,0,record['requestId'],self.lock)
        need(type(raw) is bytes and original==raw)
        # Basis images/earlier record inputs were fully decoded for the one
        # composition. Their actual file identities/modes/lengths/timestamps
        # must survive all persistence, so no duplicate PNG interpretation is
        # needed for these identical immutable inputs.
        need(type(dependencies) is dict and self.dependencies(set(dependencies))==dependencies)
        self.check()
