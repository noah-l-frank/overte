"""Prospective stdlib-only original kernel/callback counters. No SDK/Node."""
from pathlib import Path
import importlib.util,json,os,unittest
ROOT=Path(__file__).resolve().parent

def module(name,file):
 spec=importlib.util.spec_from_file_location(name,ROOT/'candidate'/file);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
verifier=module('audio_verifier11','external-verifier.py')
receipts=module('audio_receipts11','parent-boundary-receipts.py')
KEYS=('pid','parent','group','session','startTicks')

class AudioParentVerifierBoundaryTests(unittest.TestCase):
 def actual(self):
  row=verifier.process_identity(os.getpid());return row,{key:row[key]for key in KEYS}
 def test_actual_kernel_identity_retains_exact_pid_parent_group_session_and_startticks(self):
  row,bound=self.actual();self.assertEqual(os.getpid(),row['pid']);self.assertEqual(os.getppid(),row['parent'])
  self.assertEqual(os.getpgrp(),row['group']);self.assertEqual(os.getsid(0),row['session']);self.assertGreater(row['startTicks'],0)
  status,current,source=verifier.observed_owned(bound,{row['pid']:row})
  self.assertEqual('present',status);self.assertEqual('table',source);self.assertEqual(bound,{key:current[key]for key in KEYS})
 def test_stale_table_before_actual_receipt_uses_fresh_real_pid_stat_instead_of_false_unobservable(self):
  _row,bound=self.actual();self.assertTrue(Path('/proc',str(bound['pid'])).exists())
  status,current,source=verifier.observed_owned(bound,{})
  self.assertEqual('present',status);self.assertEqual('fresh-pid-after-receipt',source)
  self.assertEqual(bound,{key:current[key]for key in KEYS})
 def test_wrong_startticks_never_admits_the_current_pid_and_unbound_identities_refuse(self):
  _row,bound=self.actual();wrong=dict(bound,startTicks=bound['startTicks']+1)
  status,current,source=verifier.observed_owned(wrong,{})
  self.assertEqual('reused',status);self.assertIsNone(current);self.assertEqual('fresh-pid-after-receipt',source)
  for invalid in ({'pid':bound['pid']},dict(bound,startTicks=True),dict(bound,session=0)):
   with self.assertRaises(ValueError):verifier.observed_owned(invalid,{})
 def test_actual_failed_original_cleanup_serializes_test_id_and_traceback_without_claiming_success(self):
  class FailureCase(unittest.TestCase):
   def runTest(self):pass
  case=FailureCase();events=[]
  def failure():events.append('failed');raise ValueError('controlled original cleanup failure')
  case.addCleanup(lambda:events.append('continued'));case.addCleanup(failure)
  result=unittest.TestResult();case._outcome=unittest.case._Outcome(result)
  actual=unittest.TestCase.doCleanups;success=actual(case)
  self.assertFalse(success);self.assertEqual([],case._cleanups);self.assertEqual(['failed','continued'],events)
  self.assertEqual(1,len(result.errors));self.assertIs(result.errors[0][0],case)
  rows=receipts.cleanup_errors(result.errors);saved=json.loads(json.dumps(dict(success=success,errors=rows)))
  self.assertFalse(saved['success']);self.assertEqual(case.id(),saved['errors'][0]['testId'])
  self.assertEqual(result.errors[0][1],saved['errors'][0]['traceback']);self.assertIn('controlled original cleanup failure',saved['errors'][0]['traceback'])
  self.assertIs(actual,unittest.TestCase.doCleanups)
