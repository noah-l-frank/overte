#!/usr/bin/env python3
"""Separate exact2 source/argv models; never execute the creator or SDK."""
from __future__ import annotations
import hashlib,json,os,sys,unittest
from pathlib import Path
from root_stage_guard import pinned,baseline,terminal
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
stage=json.loads(pinned(HERE/'source-manifest.json',os.environ['LIFECYCLE_COMPAT_STAGE_SHA256']))
plan=json.loads(pinned(HERE/'default-kernel-case-plan.json',os.environ['LIFECYCLE_COMPAT_CASE_PLAN_SHA256']))
map_path=Path(os.environ['LIFECYCLE_COMPAT_ROOT_MAP']);map_raw=pinned(map_path,os.environ['LIFECYCLE_COMPAT_ROOT_MAP_SHA256']);mapping=json.loads(map_raw)
assert set(mapping)=={'repositoryRoot','currentSourcePins','reviewedCandidates'}
repo=Path(mapping['repositoryRoot']);expected={row['path']:row['candidateSHA256'] for row in stage['sourcePaths']}
assert str(repo)==stage['repositoryRoot'] and mapping['reviewedCandidates']==expected
for rel,digest in mapping['currentSourcePins'].items():
 path=Path(rel);assert not path.is_absolute() and '..' not in path.parts;pinned(repo/path,digest)
for rel,digest in expected.items():pinned(repo/rel,digest)
pinned(HERE/'test_default_kernel_compat_models.py',plan['modelSHA256'])
pinned(HERE/'default-kernel-model-source-map.json',plan['mapSHA256'])
initial=baseline();root=HERE/'compat-retained-first';root.mkdir(mode=0o700,exist_ok=False)
bindings=HERE/'compat-code-bindings-first';bindings.mkdir(mode=0o700,exist_ok=False);os.environ['LIFECYCLE_CODE_BINDINGS_ROOT']=str(bindings)
sys.path.insert(0,str(HERE))
try:
 suite=unittest.TestSuite();loader=unittest.TestLoader()
 for case in plan['ids']:suite.addTests(loader.loadTestsFromName(case))
 assert suite.countTestCases()==2
 result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
finally:
 pinned(map_path,hashlib.sha256(map_raw).hexdigest())
 for rel,digest in mapping['currentSourcePins'].items():pinned(repo/rel,digest)
 terminal(HERE/'root-compat2-first',initial,[])
raise SystemExit(0 if result.wasSuccessful() else 1)
