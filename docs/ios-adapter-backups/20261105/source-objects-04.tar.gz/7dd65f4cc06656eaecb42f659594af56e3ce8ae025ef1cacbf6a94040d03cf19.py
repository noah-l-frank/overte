"""Root-only Moving C11 State Own4 metadata; never imports the utility subject or starts it."""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
SOURCE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/moving-c11-real-process-state-own4-utility-source1-private-20261104'
SUBJECT_SHA='b54758ad7298aad59a3c26ced418e00a054a893a3d89b5d61a0efb949e229e18'
HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
EXECUTORS=('run-four.py','supervise-four.py','metadata_reader.py','host_common.py','closed_import_origins.py',
    'owned_write_boundary.py','shutil_copy_range_port.py','python_children.py','moving_owned_identity.py','moving_process_observation.py','test_moving_process_observation.py','source_execution_readiness.py','readonly-shared-stdlib-sources.json','exact-four-selectors.json')

def frozen(folder,name,sha,physical):
    path=folder/name;assert pin(path)['sha256']==sha;physical[str(path)]=pin(path);value=json.loads(path.read_text())
    for leaf,row in value['files'].items():
        assert not Path(leaf).is_absolute()and '..'not in Path(leaf).parts
        actual=folder/leaf;assert pin(actual)['sha256']==(row if type(row)is str else row['sha256']);physical[str(actual)]=pin(actual)
    return value

def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','expected-head','destination'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and head()==args.expected_head
    physical={};frozen(SOURCE,'source-freeze.json',args.source_freeze,physical);frozen(SUBJECT,'source-freeze.json',SUBJECT_SHA,physical)
    for name in('moving_owned_identity.py','moving_process_observation.py','test_moving_process_observation.py'):assert(SOURCE/name).read_bytes()==(SUBJECT/name).read_bytes()
    frozen(REPO/'.ios-host-tmp/lifecycle-moving-controller11-state-bound-no-positive-executable-source-private-20261104','code-preparation-freeze.json','f77d4cab150d5a0af8e8cbb46dd065991f74236b1e31e326a7ec28b9077ceee6',physical)
    frozen(REPO/'.ios-host-tmp/moving-c9-kernel-sid-own4-bootstrap2-immutable-original-birth-source-private-20261104','source-freeze.json','02ea762444fe2cc5192e4de933924526dad9dc3d6bfe4053fa6e1938c71d5225',physical)
    frozen(REPO/'.ios-host-tmp/moving-c11-process-observation-own4-bootstrap1-code-preparation-20261104','source-freeze.json','06fcd41637a997fd952cd826b269109f0c9a1af5a10f16b0c694146f94eb7cd1',physical)
    frozen(REPO/'.ios-host-tmp/moving-c11-process-observation-own4-bootstrap2-exact-shutil-copy-range-code-preparation-20261104','source-freeze.json','9237839b6b5210841b6ab81a262a4e547d84e4670d747cbc60fff5ffbb66b56e',physical)
    current_qualification,current_physical=qualification(pin);physical.update(current_physical)
    assert pin(SOURCE/'closed_import_origins.py')['sha256']==HELPER
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ');gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(path)]=pin(path)
    ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    refpath=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs');physical[str(refpath)]=pin(refpath)
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14')
    suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);namespaces={}
    for current,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink())
        rel=folder.relative_to(std)
        if rel.parts and all(n.isidentifier()for n in rel.parts)and not(folder/'__init__.py').is_file():namespaces['.'.join(rel.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(suffixes):continue
            assert path.resolve(strict=True)==path and not path.is_symlink();physical[str(path)]=pin(path)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'and dest.name.startswith('moving-c11-state-own4-prepared-')and not dest.exists()
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    dest.mkdir(mode=0o700)
    for name in EXECUTORS:
        path=dest/name;assert path.resolve().is_relative_to(REPO)
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(path)]=pin(path)
    modules={name:dict(path=str(dest/(name+'.py')),sha256=physical[str(dest/(name+'.py'))]['sha256'],package=False,loader='source')for name in('metadata_reader','host_common','source_execution_readiness','closed_import_origins','owned_write_boundary','shutil_copy_range_port','python_children','moving_owned_identity','moving_process_observation','test_moving_process_observation')}
    retained=REPO/'tests/device/ios/self_tests/retained_host_roots.py'
    assert retained.resolve(strict=True)==retained;physical[str(retained)]=pin(retained)
    modules['ios.self_tests.retained_host_roots']=dict(path=str(retained),sha256=physical[str(retained)]['sha256'],package=False,loader='source')
    project_namespaces={'ios':[str(REPO/'tests/device/ios')],'ios.self_tests':[str(REPO/'tests/device/ios/self_tests')]}
    for roots in project_namespaces.values():
        for root in roots:assert Path(root).is_dir()and Path(root).resolve(strict=True)==Path(root)
    cases=json.loads((SOURCE/'exact-four-selectors.json').read_text());assert len(cases)==len(set(cases))==4
    subject_names=('moving_owned_identity','moving_process_observation','test_moving_process_observation','ios.self_tests.retained_host_roots');subjects={name:dict(path=modules[name]['path'],sha256=modules[name]['sha256'])for name in subject_names}
    origin=dict(modules=modules,namespacePackages=project_namespaces,thirdPartyModules={},thirdPartyNamespacePackages={},stdlibNamespacePackages=namespaces,stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='PRIVATE_MOVING_C11_STATE_UTILITY4_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(dest),actualPublicHead=args.expected_head,sourceFreeze=args.source_freeze,utilitySubjectSourceFreeze=SUBJECT_SHA,kernelSubjectSha256='08263283e4c2a687fbbb468cb87c6025b2e424edb70be744fddf6ed0ebdee30f',
        sourceAndBinaryPins=physical,modules=modules,namespaces=project_namespaces,thirdPartyModules={},originPlan=origin,subjectOriginModules=subjects,subjectOriginCount=4,cases=cases,wallSeconds=30,killGraceSeconds=5,
        pythonExecutable=dict(path=str(python),pin=physical[str(python)]),PythonExecutions=5,maximumLiveUtilityChildren=2,expectedTemporaryDirectories=1,expectedTemporaryDirectoriesPerCase=[0,0,0,1],
        subjectSourceFreeze=SUBJECT_SHA,currentSourceExecution=current_qualification,consumerCompositionQualified=False,subjectHelperSha256=HELPER,subjectActualCopiedPath=str(dest/'closed_import_origins.py'),
        NodeExecutions=0,SDKExecutions=0,realNetwork=False,overteNativeQueries=0,oldApplicationCorpusInputs=0,globalOriginalScans=0,oldScenarioOriginalInputs=0,
        trustedHostBootstrap='Actual interpreter/stdlib/initial controller modules are explicitly trusted physical origins; delegated kernel/test modules use actual C10d fresh source bytes. No entire-interpreter cache absence claim.',nativeQualified=False,wholeQualified=False,processObservationUtilityRootProof=None,movingAdmissionQualified=False,originalE458BaseSHA256='156560033c0c292aa72be6cd66af136683de28490341dceacc191398b5167bda',controlledBoundaryVariant='exact-original-shutil-copy-range-offset-dst-only',controlledBoundaryVariantSHA256=physical[str(dest/'owned_write_boundary.py')]['sha256'])
    output=dest/'approved-inputs.json';assert output.resolve().is_relative_to(REPO)
    fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),sha256=pin(output)['sha256'],sourcePins=len(physical),cases=4,targets=0,globalScans=0)))
if __name__=='__main__':main()
