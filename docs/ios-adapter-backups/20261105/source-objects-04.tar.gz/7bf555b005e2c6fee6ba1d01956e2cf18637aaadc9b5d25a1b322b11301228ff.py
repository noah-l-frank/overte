"""Stdlib-only physical-prefix inventory. This is not a Chat semantic decoder."""
from pathlib import Path
import base64
import hashlib
import json
import os
import stat
import zlib

WORK = Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026')
RUN = WORK / '.ios-host-tmp/chat-send-proof-source15-paired-root-preparation-20261103/runs/paired1/first-12ss1l8w'
RAW = RUN / 'temporary'


def read(path):
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        opened = os.fstat(descriptor)
        with os.fdopen(os.dup(descriptor), 'rb') as stream:
            value = stream.read()
        after = os.fstat(descriptor)
    finally:
        os.close(descriptor)
    current = path.lstat()
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    identity = lambda item: tuple(getattr(item, key) for key in fields)
    assert identity(before) == identity(opened) == identity(after) == identity(current)
    return value, dict(zip(fields, identity(current)))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def payload(value):
    # Literal compressed framing only; no product method, parser import or clock guard.
    assert set(value) == {'encoding', 'bytes', 'sha256', 'data'}
    assert value['encoding'] == 'zlib-base64-json' and type(value['bytes']) is int
    assert 2 <= value['bytes'] <= 16 * 1024 * 1024 and len(value['data']) <= 48 * 1024
    packed = base64.b64decode(value['data'], validate=True)
    assert base64.b64encode(packed).decode() == value['data']
    decoder = zlib.decompressobj()
    raw = decoder.decompress(packed, value['bytes'] + 1)
    assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
    assert len(raw) == value['bytes'] and hashlib.sha256(raw).hexdigest() == value['sha256']
    frames = json.loads(raw)
    assert canonical(frames) == raw and type(frames) is list and len(frames) == 1
    return frames[0]


def main():
    inventory = {}
    originals = {}
    for path in sorted(RAW.rglob('*')):
        assert not path.is_symlink()
        if path.is_dir():
            continue
        raw, info = read(path)
        row = dict(path=str(path.relative_to(WORK)), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(), identity=info)
        inventory[str(path.relative_to(RAW))] = row
        originals[(info['st_dev'], info['st_ino'], len(raw), row['sha256'])] = row['path']
    assert len(inventory) == 41
    journals = {}
    for role, relative in (('peer', 'tmp4anb7giw/ios-chat-draft-owner.json'),
                           ('primary', 'tmpm0n175js/ios-chat-draft-owner.json'),
                           ('receive', 'tmp4anb7giw/ios-chat-receive-sources.json')):
        raw, _info = read(RAW / relative)
        envelope = json.loads(raw)
        state = payload(envelope['payload'])
        references = state['records']
        physical = []
        for reference in references:
            assert set(reference) == {'bytes', 'device', 'index', 'inode', 'sha256'}
            key = reference['device'], reference['inode'], reference['bytes'], reference['sha256']
            physical.append(dict(index=reference['index'], path=originals[key]))
        journals[role] = dict(path=str((RAW / relative).relative_to(WORK)),
            version=envelope.get('iosChatDraftOwnerVersion', envelope.get('iosChatReceiveSourcesVersion')),
            records=len(references), references=physical,
            pending=state['pending'], observation=state.get('observation'),
            failures=len(state.get('failures', [])), interrupted=len(state['interrupted']),
            operations=[dict(verb=item['verb'], ticket=item['ticket'], before=item['before']['index'],
                after=None if item['after'] is None else item['after']['index'], intents=len(item['intents']),
                queries=len(item['queries']), hasPeerReceipt=item['peerReceipt'] is not None)
                for item in state.get('operations', [])])
    assert journals['peer']['version'] == 11 and journals['primary']['version'] == 9
    assert journals['peer']['records'] == 9 and journals['primary']['records'] == 8 and journals['receive']['records'] == 4
    assert all(row['pending'] is None and row['observation'] is None for row in journals.values())
    result = dict(kind='stdlib-physical-prefix-only', semanticProductDecode=False, targetExecuted=False,
        rawRoot=str(RAW), originalFiles=len(inventory), journals=journals, inventory=inventory)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
