from pathlib import Path
import ast,difflib,hashlib,json
P=Path(__file__).resolve().parent;R=P.parents[1];T=R/'.ios-host-tmp';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
rel='tests/device/ios/pymobiledevice3_wda_xctest.py';base=R/rel;s=base.read_text();old='self.touch=None;self.closed=False;self.draining=False';new='self.touch=None;self.closed=False;self.draining=False;self.retained_motion_resource=None';assert s.count(old)==1;s=s.replace(old,new)
old="            row['motionResource']=resource # Actual source birth, never an RPC field.";new=old+"\n            row['motionStep']=resource._native_step # Same original born guard, retained for old cleanup.";assert s.count(old)==1;s=s.replace(old,new)
marker='    async def execute(self, operation, args, session):';assert s.count(marker)==1;s=s.replace(marker,(P/'receiver.fragment.py').read_text()+marker)
old="        if operation in ('touch-release','touch-inspect','touch-settle'):\n            # Original claim/session";new="""        if operation in ('touch-release','touch-inspect','touch-settle'):
            if type(args) is dict and 'originalKeeperRetainedTouchProfileVersion' in args:
                return await self.retained_resource_cleanup(operation,args,session)
            # Original claim/session""";assert old in s;s=s.replace(old,new)
old='''                    self.touch_resources=resource # Retain actual duty before any saved ACK can be lost.
                    self.source.prepare_motion(resource,self.instance,receipt,seconds=args['seconds'])''';new='''                    self.touch_resources=resource # Retain actual duty before any saved ACK can be lost.
                    if receipt._selected is not None:
                        if self.retained_motion_resource is not None:raise LaunchError('session-lifetime')
                        # Actual source-local resource and original receipt,
                        # captured BEFORE preparation CAS/worker/Down. A cold
                        # JSON header cannot recreate this original duty.
                        self.retained_motion_resource=(self,resource,original_source,asyncio.get_running_loop(),self.instance,
                            deepcopy(binding),run,receipt,deepcopy(reference))
                    self.source.prepare_motion(resource,self.instance,receipt,seconds=args['seconds'])''';assert old in s;s=s.replace(old,new)
out=P/'candidate/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s);ast.parse(s);rows.append(dict(path=rel,base=str(base),baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out)))
rel='tests/device/ios/appium_wda_host_ops.js';base=R/rel;s=base.read_text();old="""            if (retained && (!originalClaimAccepted || originalKeeperRoutes.get(driver) !== bridge ||
                !args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).length !== 0))
                throw new Error('Original retained touch owner unavailable');""";new="""            if (retained) {
                if (!originalClaimAccepted || originalKeeperRoutes.get(driver) !== bridge ||
                    !args || typeof args !== 'object' || Array.isArray(args))
                    throw new Error('Original retained touch owner unavailable');
                const scoped = Object.hasOwn(args, 'originalKeeperRetainedTouchProfileVersion');
                const keys = ['binding', 'expectedOwnerInstance', 'originalKeeperRetainedTouchProfileVersion', 'referenceJson', 'runId'];
                if (scoped ? args.originalKeeperRetainedTouchProfileVersion !== 1 ||
                    Object.keys(args).sort().join(',') !== keys.join(',') ||
                    args.expectedOwnerInstance !== retainedScope.ownerInstance : Object.keys(args).length !== 0)
                    throw new Error('Original retained touch owner unavailable');
            }""";assert old in s;s=s.replace(old,new)
out=P/'candidate/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s);rows.append(dict(path=rel,base=str(base),baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out)))
rel='tests/device/ios/adapters/appium_adapter.py';base=T/'lifecycle-original-owner-retained-webdriver-exact-operation-overlay-20261029/candidate/repo'/rel;s=base.read_text();s=s.replace('    def retain_original_keeper_cleanup(self,session: str):','    def retain_original_keeper_cleanup(self,session: str,*,original=None):',1)
old="        origin=self.server_url;path=f'/session/{session}/execute/sync'\n        read_reply=self._read_reply;timeout=self.COMMAND_TIMEOUT_SECONDS";new="""        original_args={}
        if original is not None:
            from adapters.normal_feature_state import context
            from feature_journeys.contract import identifier,json_document
            from adapters.script_feature.history import canonical
            if type(original) is not dict or set(original)!={'ownerInstance','binding','runId','referenceJson'}:
                fail('Original keeper retained resource is unavailable')
            identifier(original['ownerInstance']);identifier(original['runId']);context(original['binding'])
            if original['binding']['sessionId']!=session or type(original['referenceJson']) is not str or len(original['referenceJson'])>2048:
                fail('Original keeper retained resource is unavailable')
            reference=json_document(original['referenceJson'])
            if canonical(reference).decode('ascii')!=original['referenceJson']:fail('Original keeper retained resource is unavailable')
            original_args={'originalKeeperRetainedTouchProfileVersion':1,'expectedOwnerInstance':original['ownerInstance'],
                'binding':json.loads(json.dumps(original['binding'])),'runId':original['runId'],'referenceJson':original['referenceJson']}
        origin=self.server_url;path=f'/session/{session}/execute/sync'
        read_reply=self._read_reply;timeout=self.COMMAND_TIMEOUT_SECONDS""";assert old in s;s=s.replace(old,new)
old="'args':[{'operation':operation,'args':{}}]";new="'args':[{'operation':operation,'args':original_args}]";assert s.count(old)==1;s=s.replace(old,new)
out=P/'candidate/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s);ast.parse(s);rows.append(dict(path=rel,base=str(base),baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out)))
(P/'source3-checkpoint.diff').write_text(''.join(''.join(difflib.unified_diff(Path(row['base']).read_text().splitlines(True),Path(row['candidate']).read_text().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path'])) for row in rows))
(P/'checkpoint.json').write_text(json.dumps(dict(status='PRIVATE_ACTIVE_DRAFT_UNRUN_NOT_FROZEN',files=rows,remaining=['actual receiver and Node preeffect countercases','touch3 own registry plan','wire resource-scoped sender into remotelease before Down'],legacyCleanupArgsPreserved=True,sourceCurrentRequiredForCleanup=False,nativeAuthWholeFlags=False),indent=2)+'\n');print(json.dumps(rows,indent=2))
