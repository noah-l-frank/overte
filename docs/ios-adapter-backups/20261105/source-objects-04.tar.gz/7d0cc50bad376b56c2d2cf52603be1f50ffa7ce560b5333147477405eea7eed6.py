"""Six genuine Linux original-state controls, source only and UNRUN.

No modeled PID or kernel query result. Wrappers delegate real exe reads and
only synchronize actual child state changes, or count actual lookup calls.
The stale expected tuple is explicitly a comparator fault, not PID reuse.
"""
from pathlib import Path
import hashlib,os,shutil,subprocess,sys,tempfile,time,unittest
import kernel

CHILD_CODE='import sys;sys.stdout.buffer.write(b"R");sys.stdout.buffer.flush();sys.stdin.buffer.read(1)'


class OriginalOwnedKernelTerminalTests(unittest.TestCase):
    def finish(self,child):
        # Closing this original input makes our finite child return; no signal
        # bypass is needed even when its actual exe path was deleted.
        try:
            if child.stdin is not None and not child.stdin.closed:child.stdin.close()
            child.wait(timeout=5)
        finally:
            for stream in(child.stdout,child.stderr):
                if stream is not None:stream.close()
        self.assertIsNotNone(child.returncode)
        self.assertTrue(kernel.absent(child.pid))
    def child(self,executable=None):
        actual=str(Path(sys.executable).resolve(strict=True))if executable is None else str(executable)
        child=subprocess.Popen([actual,'-S','-B','-c',CHILD_CODE],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            bufsize=0,close_fds=True,shell=False,start_new_session=False)
        self.addCleanup(self.finish,child) # Before ready read/any later failure.
        self.assertEqual(child.stdout.read(1),b'R')
        original=kernel.observe(child.pid,parent=os.getpid(),group=os.getpgrp())
        self.assertEqual(original['kind'],'PRESENT_LIVE');self.assertEqual(original['executable'],actual)
        return child,original
    def zombie(self,child,identity):
        deadline=time.monotonic()+5
        while True:
            sample=kernel._sample(child.pid)
            self.assertIsNotNone(sample);self.assertEqual(sample['identity'],identity)
            if sample['state']=='Z':return sample
            self.assertLess(time.monotonic(),deadline);time.sleep(.005)
    def lookup_counter(self):
        original=kernel._executable;calls=[]
        def observed(pid):calls.append(pid);return original(pid)
        self.addCleanup(setattr,kernel,'_executable',original)
        kernel._executable=observed
        return calls,original
    def test_live_original_child_keeps_complete_sid_and_actual_executable(self):
        child,birth=self.child();identity=birth['after']['identity'];actual=kernel.observe(child.pid,expected=identity)
        self.assertEqual(actual['kind'],'PRESENT_LIVE');self.assertEqual(actual['after']['identity'],identity)
        self.assertIn('session',identity);self.assertIn('rawStat',actual['before']);self.assertIn('rawStat',actual['after'])
        self.assertTrue(actual['executableReadAttempted']);self.assertEqual(actual['executable'],birth['executable'])
        self.assertFalse(kernel.absent(child.pid))
    def test_actual_unreaped_zombie_is_present_without_exe_then_original_wait_establishes_absence(self):
        child,birth=self.child();identity=birth['after']['identity']
        child.stdin.write(b'X');self.zombie(child,identity);calls,unused=self.lookup_counter()
        actual=kernel.observe(child.pid,expected=identity)
        self.assertEqual(actual['kind'],'PRESENT_TERMINAL');self.assertEqual(actual['after']['state'],'Z')
        self.assertFalse(actual['executableReadAttempted']);self.assertIsNone(actual['executable']);self.assertEqual(calls,[])
        self.assertFalse(kernel.absent(child.pid));self.assertIn(child.pid,kernel.descendants(os.getpid()))
        with self.assertRaises(kernel.OwnedTerminal):kernel.process(child.pid,expected=identity)
        self.assertEqual(calls,[]);child.wait(timeout=5);self.assertTrue(kernel.absent(child.pid))
    def test_actual_exit_between_original_stat_and_real_exe_lookup_retains_terminal_state(self):
        child,birth=self.child();identity=birth['after']['identity'];original=kernel._executable;entered=[]
        def exit_then_delegate(pid):
            self.assertEqual(pid,child.pid);entered.append(pid);child.stdin.write(b'X');self.zombie(child,identity)
            return original(pid) # Genuine /proc read after the actual exit.
        self.addCleanup(setattr,kernel,'_executable',original);kernel._executable=exit_then_delegate
        actual=kernel.observe(child.pid,expected=identity)
        self.assertEqual(entered,[child.pid]);self.assertEqual(actual['kind'],'PRESENT_TERMINAL')
        self.assertTrue(actual['executableReadAttempted']);self.assertEqual(actual['after']['state'],'Z')
        self.assertIsNotNone(actual['lookupError']);self.assertFalse(kernel.absent(child.pid))
    def test_stat_only_foreign_discovery_reads_executable_only_for_actual_owned_child(self):
        child,birth=self.child();foreign_parent=kernel._sample(os.getppid());self.assertIsNotNone(foreign_parent)
        calls,unused=self.lookup_counter();found=kernel.descendants(os.getpid())
        self.assertEqual(set(found),{child.pid});self.assertEqual(calls,[child.pid])
        self.assertNotIn(os.getppid(),calls);self.assertEqual(found[child.pid]['observation']['after']['identity'],birth['after']['identity'])
        self.assertFalse(kernel.absent(child.pid))
    def test_changed_expected_lifetime_refuses_before_actual_executable_lookup_without_reuse_claim(self):
        child,birth=self.child();wrong=dict(birth['after']['identity']);wrong['startTicks']+=1
        calls,unused=self.lookup_counter()
        with self.assertRaisesRegex(AssertionError,'changed BEFORE executable read'):kernel.observe(child.pid,expected=wrong)
        self.assertEqual(calls,[]);self.assertFalse(kernel.absent(child.pid))
    def test_live_deleted_owned_interpreter_executable_is_not_terminal_or_absent(self):
        # Actual copied ELF, no compiler or custom copy fallback. Existing
        # shutil decides its original syscall/fallback path. Hash both bytes.
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        root=Path(temporary.name);original=Path(sys.executable).resolve(strict=True);copied=root/'original-python'
        expected=hashlib.sha256(original.read_bytes()).hexdigest();shutil.copyfile(original,copied);copied.chmod(0o700)
        self.assertEqual(hashlib.sha256(copied.read_bytes()).hexdigest(),expected)
        child,birth=self.child(copied);identity=birth['after']['identity'];copied.unlink()
        with self.assertRaises(FileNotFoundError):kernel.observe(child.pid,expected=identity)
        current=kernel._sample(child.pid);self.assertEqual(current['identity'],identity);self.assertNotEqual(current['state'],'Z')
        self.assertFalse(kernel.absent(child.pid))
