"""One exact selected failfast5-case host suite180+5; no runtime map is supplied here."""
from pathlib import Path
import builtins,faulthandler,importlib.abc,importlib.machinery,importlib.util
from types import FrameType
import metadata as original_metadata
import io,json,os,signal,sys,tempfile,threading,traceback,unittest
from metadata import SOURCE,REPO,PROPOSAL,PUBLIC_INTEGRATION,validate,sha,pin,load,census,fds,proc,head
from chat_node_port import ChatNodePort
from closed_import_origins import ClosedOrigins

assert sys.dont_write_bytecode and Path.cwd()==REPO and len(sys.argv)==7
assert sys.flags.no_site == 1, "Explicit no-site interpreter startup required"
group,expected_head,source_sha,plan_sha,plan_path,output=sys.argv[1:]
input_path=Path(plan_path).resolve(strict=True)
input_before=pin(input_path);assert input_before['sha256']==plan_sha
plan=validate(Path(plan_path),plan_sha,source_sha,expected_head,group)
assert pin(input_path)==input_before
HERE=Path(output);TEMP=HERE/'temporary'
assert HERE.is_absolute()and HERE.resolve(strict=True)==HERE and HERE.parent==REPO/'.ios-host-tmp'
assert HERE.name.startswith('chat-offline-public-origin-'+group+'-')and TEMP.is_dir()and not list(TEMP.iterdir())
initial_fds,initial_threads=fds(),tuple(threading.enumerate())
initial_path,initial_meta=list(sys.path),list(sys.meta_path)
real_td=tempfile.TemporaryDirectory;real_cleanup=unittest.TestCase.doCleanups;cleanup_code=real_cleanup.__code__
initial_io=io.open,builtins.open
loaded={};td_callers=[];roots=[];directories=[];refusals=[];case_receipts=[];pending_case=None
result=None;returned=False;fatal=None;selected_cases=[]
method_seals=[]
origins=ClosedOrigins(plan,SOURCE,REPO,pin)
origin_before=origins.snapshot('validated-before-project-imports')
origin_after=None

def sdk_free():
    assert not [name for name in sys.modules if name.split('.')[0]in forbidden]

def seal(cls):
    for name,member in cls.__dict__.items():
        function=member.__func__ if type(member)in(classmethod,staticmethod)else member
        if hasattr(function,'__code__'):
            method_seals.append((cls,name,member,function,function.__code__,function.__globals__))
            wrapped=getattr(function,'__wrapped__',None)
            if wrapped is not None:method_seals.append((function,'__wrapped__',wrapped,wrapped,wrapped.__code__,wrapped.__globals__))

def unchanged_methods():
    for owner,name,member,function,code,namespace in method_seals:
        actual=owner.__dict__[name]if isinstance(owner,type)else getattr(owner,name)
        assert actual is member and function.__code__ is code and function.__globals__ is namespace

def save(name,value):
    path=HERE/name
    with path.open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    path.chmod(0o600)

boundary_path=SOURCE/'owned_write_boundary.py'
assert sha(boundary_path)=='156560033c0c292aa72be6cd66af136683de28490341dceacc191398b5167bda'
spec=importlib.util.spec_from_file_location('chat_offline_e458_controller',boundary_path)
boundary_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(boundary_module)
boundary=boundary_module.OwnedWrites(HERE,protected=[Path(os.readlink('/proc/self/fd/'+str(n))).resolve(strict=True)for n in(1,2)])
original_ports=dict(boundary.original);boundary.install()
node=ChatNodePort(plan,HERE,pin,proc)
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright','PySide6','PyQt6')
project_tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespacePackages'])}
assert not any(name.split('.')[0]in project_tops for name in sys.modules)

# This small exception reads only independently pinned OWN repository source
# bytes for metadata verification. It grants neither a loader nor SDK a read.
metadata_pin=pin;metadata_pin_code=pin.__code__;metadata_pin_globals=pin.__globals__
metadata_open=type(boundary).__dict__['os_open'];metadata_open_code=metadata_open.__code__;metadata_open_globals=metadata_open.__globals__
metadata_read_flags=os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC
own_read_manifest=load(SOURCE/'readonly-own-public-source-verification.json')
assert own_read_manifest['version']==1 and own_read_manifest['publicRoot']==str(REPO/'tests/device/adapters/appium')
assert len(own_read_manifest['paths'])==8
own_read_rows=tuple((name,row['sha256'])for name,row in sorted(own_read_manifest['paths'].items()))
for name,digest in own_read_rows:
    path=Path(name);assert path.parent==REPO/'tests/device/adapters/appium'and path.resolve(strict=True)==path
    assert name in plan['physicalPins']and plan['physicalPins'][name]['sha256']==digest

def own_metadata_pin_read(args,caller):
    value,mode,flags=args
    if mode is not None or flags!=metadata_read_flags or type(value)not in(str,bytes):return False
    path=Path(os.fsdecode(value));name=str(path)
    if not any(name==approved and plan['physicalPins'][name]['sha256']==digest for approved,digest in own_read_rows):return False
    if not path.is_absolute()or path.resolve(strict=True)!=path or type(caller)is not FrameType:return False
    if (sys.modules.get('metadata')is not original_metadata or original_metadata.pin is not metadata_pin or pin is not metadata_pin
            or metadata_pin.__code__ is not metadata_pin_code or metadata_pin.__globals__ is not metadata_pin_globals
            or metadata_pin_globals is not original_metadata.__dict__):return False
    frame=caller
    if caller.f_code is metadata_open_code:
        if (caller.f_globals is not metadata_open_globals or type(boundary).__dict__['os_open']is not metadata_open
                or metadata_open.__code__ is not metadata_open_code or metadata_open.__globals__ is not metadata_open_globals
                or caller.f_locals.get('self')is not boundary or caller.f_locals.get('path')!=path
                or caller.f_locals.get('flags')!=metadata_read_flags or caller.f_locals.get('dir_fd')is not None
                or boundary.original['open']is not original_ports['open']or os.open is not boundary.ports['open']):return False
        frame=caller.f_back
    elif os.open is not original_ports['open']:return False
    return(type(frame)is FrameType and frame.f_code is metadata_pin_code and frame.f_globals is metadata_pin_globals
        and frame.f_locals.get('path')==path)

def refuse(event,detail):
    refusals.append(dict(event=event,detail=detail));raise RuntimeError('CHAT_OFFLINE_CONTROLLER_REFUSED_'+event)

postclose_tail_births={};postclose_writer=None;postclose_writer_code=None;postclose_writer_globals=None

def own_closed_report_open(args,caller):
    value,mode,flags=args
    if not boundary.closed or boundary.installed or postclose_writer is None:return False
    if (type(caller)is not FrameType or caller.f_code is not postclose_writer_code or caller.f_globals is not postclose_writer_globals
            or postclose_writer.__code__ is not postclose_writer_code or postclose_writer.__globals__ is not postclose_writer_globals):return False
    if mode!='w'or flags!=(os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC)or type(value)not in(str,bytes):return False
    path=Path(os.fsdecode(value));row=postclose_tail_births.get(str(path))
    if row is None or path.parent!=HERE or caller.f_locals.get('path')!=path:return False
    if any(getattr(os,name)is not original for name,original in original_ports.items())or(io.open,builtins.open)!=initial_io or boundary.control_fds:return False
    info=path.lstat()
    return(path.resolve(strict=True)==path and(info.st_dev,info.st_ino)==row and info.st_nlink==1
        and info.st_mode&0o777==0o600)

def audit(event,args):
    if event=='open'and own_closed_report_open(args,sys._getframe(1)):return
    if event=='open'and type(args[0])is int and node.pipe_open(args,sys._getframe(1)):return
    if event=='subprocess.Popen':node.spawn(args,sys._getframe(1));return
    if event=='os.kill':node.signal(args,sys._getframe(1));return
    if event.startswith('socket.')or event in('os.system','os.exec','os.fork','os.forkpty','os.posix_spawn',
        'pty.spawn','ctypes.dlopen','os.killpg','os.setsid','os.setpgid','os.putenv','os.unsetenv','os.fchdir')or event.startswith('os.spawn'):
        refuse(event,'Only exact owned model Node/process/stdio, no network/SDK/compiler/device/service')
    if event=='import'and any(args[0]==name or args[0].startswith(name+'.')for name in forbidden):
        refuse(event,'Installed/vendor SDK import')
    if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
        path=os.fsdecode(args[0])
        if '/overte-ios-remotexpc/'in path or any('/'+name+'/'in path for name in forbidden):
            if not own_metadata_pin_read(args,sys._getframe(1)):
                refuse(event,'Installed SDK path')
    if event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate',
        'os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.'):
        boundary.audit(event,args,sys._getframe(1))

sys.addaudithook(audit)
sdk_free()
monitor=sys.monitoring
monitor_ports=tuple((name,getattr(monitor,name))for name in('get_tool','get_events','use_tool_id','register_callback',
    'set_local_events','get_local_events','free_tool_id'))
tool_slots=[(monitor.get_tool(n),monitor.get_events(n))for n in range(6)]
tool=next((n for n in(5,4,3)if monitor.get_tool(n)is None),None)
assert tool is not None and monitor.get_events(tool)==0
monitor.use_tool_id(tool,'chat-offline-genuine-node-constructor-custody')
monitor.register_callback(tool,monitor.events.PY_START,node.constructor_start)
monitor.register_callback(tool,monitor.events.PY_RETURN,node.constructor_return)
constructor_code=node.popen.__init__.__code__
monitor.set_local_events(tool,constructor_code,monitor.events.PY_START|monitor.events.PY_RETURN)

class Loader(importlib.abc.Loader):
    def __init__(self,name,row):self.name,self.row=name,row
    def create_module(self,spec):return None
    def exec_module(self,module):
        path=Path(self.row['path']);assert pin(path)==plan['physicalPins'][str(path)]
        raw=path.read_bytes();module.__file__=str(path)
        if self.row['package']:module.__path__=[str(path.parent)]
        loaded[self.name]=self.row;exec(compile(raw,str(path),'exec'),module.__dict__)
        assert pin(path)==plan['physicalPins'][str(path)]
        origins.project_loaded(self.name,module,self.row)
        names={'ios.self_tests.test_ios_installed_code':'InstalledCodeTests',
            'ios.self_tests.test_ios_chat_receive_runtime':'IOSChatReceiveRuntimeTests',
            'ios.self_tests.test_ios_chat_draft_owner':'ChatDraftOwnerTests'}
        if self.name in names:
            cls=vars(module)[names[self.name]];setup=cls.__dict__['setUp']
            td_callers.append((cls,setup,setup.__code__,setup.__globals__))

class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        row=plan['modules'].get(name)
        if row is not None:return importlib.util.spec_from_loader(name,Loader(name,row),is_package=row['package'])
        roots_=plan['namespacePackages'].get(name)
        if roots_ is not None:
            origins.namespaces(name,roots_,roots_,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots_;return spec
        if name.split('.')[0]in project_tops:raise ImportError('Project import missing exact origin: '+name)
        return origins.remaining_spec(name,path)

sys.meta_path.insert(0,Finder())
trace=(HERE/'term-stack.log').open('x')
def stop(_sig,_frame):
    faulthandler.dump_traceback(file=trace,all_threads=True);trace.flush()
    raise KeyboardInterrupt('Fixed180+5 selected five-case suite boundary')
old_term=signal.signal(signal.SIGTERM,stop)

class Result(unittest.TextTestResult):
    def startTest(self,test):
        global pending_case
        pending_case=test;node.current_case=test.id()
        self.case_fds=fds();self.case_threads=tuple(threading.enumerate())
        super().startTest(test)
    def stopTest(self,test):
        row=dict(id=test.id(),pendingCleanups=len(test._cleanups),roots=[r for r in roots if r['case']==test.id()])
        try:
            assert len(row['roots'])==3 and not test._cleanups
            row['node']=node.finish_case(test.id())
            unchanged_methods();sdk_free()
            origins.snapshot('after-case-'+str(len(case_receipts)+1))
            assert fds()==self.case_fds and tuple(threading.enumerate())==self.case_threads
            assert not any(t not in initial_threads and t.is_alive()for t in threading.enumerate())
            row['controllerGatePassed']=True
        except BaseException:
            row['controllerGatePassed']=False;row['controllerFailure']=traceback.format_exc();self.stop()
        case_receipts.append(row);super().stopTest(test)

try:
    from ios.self_tests.chat_message_script_domain import ScriptMessageModel
    from ios.self_tests.chat_send_receive_fixture import BusScriptModel
    from ios.self_tests.retained_host_roots import retain_owned_root
    node.bind(ScriptMessageModel,BusScriptModel)
    from ios.adapters.chat_draft_owner import IOSChatDraftOwner
    from ios.adapters.chat_receive_sources import IOSChatReceiveSources
    from ios.adapters.chat_send_operation import IOSChatSendOperation
    from ios.adapters.chat_offline_send_operation import IOSChatOfflineSendOperation
    from ios.adapters.chat_draft_runtime import IOSChatDraftRuntime
    from ios.adapters.chat_draft_clock import Budget
    from adapters.normal_feature_state import PrivateFeatureState
    for cls in(IOSChatDraftOwner,IOSChatReceiveSources,IOSChatSendOperation,IOSChatOfflineSendOperation,IOSChatDraftRuntime,Budget,PrivateFeatureState):seal(cls)
    class RetainedDirectory(real_td):
        def __init__(self,*args,**kwargs):
            frame=sys._getframe(1)
            matches=[(cls,setup,code,namespace)for cls,setup,code,namespace in td_callers
                if frame.f_code is code and frame.f_globals is namespace and type(frame.f_locals.get('self'))is cls]
            assert len(matches)==1 and not args and not kwargs and node.current_case in plan['cases']
            cls,setup,code,namespace=matches[0]
            assert cls.__dict__['setUp']is setup and setup.__code__ is code and setup.__globals__ is namespace
            super().__init__(dir=TEMP)
            directory=Path(self.name);assert directory.parent==TEMP and directory.stat().st_mode&0o777==0o700
            retain_owned_root(self,expected_root=directory)
            roots.append(dict(case=node.current_case,path=str(directory),actualSetup=cls.__module__+'.'+cls.__qualname__))
            directories.append(self)
    tempfile.TemporaryDirectory=RetainedDirectory
    module_name='ios.self_tests.test_ios_chat_offline_send'
    module=__import__(module_name,fromlist=['ChatOfflineSendTests'])
    assert len(td_callers)==3
    suite=unittest.TestSuite()
    for selected in plan['cases']:
        prefix,cls,method=selected.rsplit('.',2);assert prefix==module_name and method in module.ChatOfflineSendTests.__dict__
        part=unittest.defaultTestLoader.loadTestsFromName(cls+'.'+method,module)
        assert part.countTestCases()==1
        case=next(iter(part));assert case.id()==selected;selected_cases.append(case);suite.addTest(case)
    assert sys.gettrace()is None and sys.getprofile()is None
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite);returned=True
except BaseException:
    fatal=traceback.format_exc()
finally:
    # Independent actual attempts: one failed source/origin/readback gate must
    # not prevent genuine pending cleanup, monitor or OS-port restoration.
    finalization_checks=[];finalization_failures=[]
    def final_check(name,function,*,require_true=False):
        try:
            value=function()
            if require_true and value is not True:
                finalization_checks.append(dict(name=name,passed=False,returnedFalse=True))
                finalization_failures.append(dict(name=name,kind='ActualCheckNotTrue'))
                return None
            finalization_checks.append(dict(name=name,passed=True))
            return value
        except BaseException:
            failure=dict(name=name,kind='ActualOriginalException',traceback=traceback.format_exc())
            finalization_checks.append(dict(name=name,passed=False));finalization_failures.append(failure)
            return None

    cleanup=[]
    for case in selected_cases:
        old_outcome=case._outcome;drain=unittest.TestResult();ok=True;exception=None
        try:
            assert unittest.TestCase.doCleanups is real_cleanup and real_cleanup.__code__ is cleanup_code
            if case._cleanups:
                case._outcome=unittest.case._Outcome(drain);ok=real_cleanup(case)
        except BaseException:
            ok=False;exception=traceback.format_exc()
        finally:case._outcome=old_outcome
        cleanup.append(dict(id=case.id(),remaining=len(case._cleanups),success=ok,
            errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],originalException=exception))
    original_failed=(fatal is not None or result is None or not result.wasSuccessful()
        or any(not row['controllerGatePassed']for row in case_receipts))
    if original_failed:
        final_check('preserve-original-failure-before-controller-drain',lambda:save(
            'original-failure-before-controller-drain.json',dict(fatal=fatal,cleanup=cleanup,
            cases=case_receipts,errors=[]if result is None else[dict(id=t.id(),traceback=text)for t,text in result.errors],
            failures=[]if result is None else[dict(id=t.id(),traceback=text)for t,text in result.failures])))
        final_check('genuine-failure-only-owned-node-drain',node.abort_all)
    def quiet_owned_nodes():
        assert not [row['birth']for row in node.entries if proc(row['process'].pid)is not None], 'Refuse quiet inventory while an own Node remains'
        return True
    quiet=final_check('actual-owned-nodes-absent-before-quiet-inventory',quiet_owned_nodes,require_true=True)
    def restore_temporaries():tempfile.TemporaryDirectory=real_td
    final_check('restore-original-temporarydirectory',restore_temporaries)
    final_check('restore-original-sigterm',lambda:signal.signal(signal.SIGTERM,old_term))
    final_check('close-original-term-trace',trace.close)
    def restore_monitor():
        monitor.set_local_events(tool,constructor_code,0)
        monitor.register_callback(tool,monitor.events.PY_START,None);monitor.register_callback(tool,monitor.events.PY_RETURN,None)
        assert monitor.get_local_events(tool,constructor_code)==0 and monitor.get_events(tool)==0
        monitor.free_tool_id(tool)
        return (all(getattr(monitor,name)is value for name,value in monitor_ports)
            and tool_slots==[(monitor.get_tool(n),monitor.get_events(n))for n in range(6)])
    monitor_ok=final_check('actual-monitor-restoration',restore_monitor,require_true=True)is True
    def restore_import_ports():sys.path[:]=initial_path;sys.meta_path[:]=initial_meta
    final_check('restore-original-import-ports',restore_import_ports)
    code_ok=final_check('actual-all-physical-pins',lambda:all(pin(path)==row for path,row in plan['physicalPins'].items()),require_true=True)is True
    sdk_ok=final_check('actual-sdk-modules-absent',lambda:not any(name.split('.')[0]in forbidden for name in sys.modules),require_true=True)is True
    final_check('actual-original-product-methods',unchanged_methods)
    origin_after=final_check('actual-loaded-origin-accounting',lambda:origins.snapshot('after-original-cleanup-and-port-drain'))
    input_after=final_check('actual-approved-input-readback',lambda:pin(input_path))
    input_unchanged=(input_after is not None and input_before==input_after and input_after['sha256']==plan_sha)
    final_check('save-approved-input-before',lambda:save('approved-input-before.json',input_before))
    final_check('save-approved-input-after',lambda:save('approved-input-after.json',input_after))
    final_check('save-loaded-origins-before',lambda:save('all-loaded-origins-before.json',origin_before))
    final_check('save-loaded-origins-after',lambda:save('all-loaded-origins-after.json',origin_after))
    raws_first=raws_second=None
    if quiet is True:
        raws_first=final_check('actual-quiet-raw-first',lambda:census(TEMP))
        raws_second=final_check('actual-quiet-raw-second',lambda:census(TEMP))
    else:
        finalization_checks.append(dict(name='quiet-raw-inventories',passed=False,notAttemptedBecauseOwnNodeAbsenceUnproved=True))
        finalization_failures.append(dict(name='quiet-raw-inventories',kind='ActualOwnedNodeAbsenceUnproved'))
    raw_equal=raws_first is not None and raws_second is not None and raws_first==raws_second
    final_check('save-actual-raw-first',lambda:save('raw-first.json',raws_first))
    final_check('save-actual-raw-second',lambda:save('raw-second.json',raws_second))
    descriptor_drain=final_check('actual-original-fd-thread-drain',lambda:fds()==initial_fds and tuple(threading.enumerate())==initial_threads,require_true=True)is True
    head_ok=final_check('actual-current-checkout-head',lambda:head()==expected_head,require_true=True)is True
    profile_ok=final_check('actual-profile-trace-unchanged',lambda:sys.getprofile()is None and sys.gettrace()is None,require_true=True)is True
    public_subjects={row['module']:row for row in load(PUBLIC_INTEGRATION/'integration.json')['integratedFiles']}
    actual_public_origins={name:dict(actualLoadedRow=loaded.get(name),actualModuleFile=getattr(sys.modules.get(name),'__file__',None),
        actualAdmission=origins.admissions.get(name),expectedPublicPath=row['publicPath'],expectedSha256=row['sha256'])for name,row in public_subjects.items()}
    public_origins_ok=all(value['actualLoadedRow']==plan['modules'][name]and value['actualModuleFile']==value['expectedPublicPath']
        and value['actualAdmission']is not None and value['actualAdmission']['origin']==value['expectedPublicPath']
        and plan['modules'][name]['sha256']==value['expectedSha256']for name,value in actual_public_origins.items())
    passed=public_origins_ok and returned and fatal is None and result is not None and result.wasSuccessful()and result.testsRun==len(plan['cases']) and not result.skipped
    passed=passed and len(case_receipts)==len(plan['cases']) and all(row['controllerGatePassed']for row in case_receipts)
    passed=passed and len(roots)==3*len(plan['cases'])and len(node.entries)==len(plan['cases']) and node.completed_cases==plan['cases']
    passed=passed and all(row['success']and not row['remaining']and not row['errors']for row in cleanup)
    passed=passed and not refusals and not node.controller_drains and sdk_ok and code_ok and monitor_ok and raw_equal
    passed=passed and descriptor_drain and head_ok and profile_ok and input_unchanged and origin_after is not None
    # Both own report files are genuinely born0600 through active E458 ports,
    # before restoration. Only the exact held tail function may later reopen
    # these same inodes through the original C IO after actual helper close.
    def report_file_birth(path):
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        try:
            info=os.fstat(fd);assert info.st_mode&0o777==0o600 and info.st_nlink==1
            return(info.st_dev,info.st_ino)
        finally:os.close(fd)
    for name in('controller-finalization-checks.json','child-result.json'):
        path=HERE/name;birth=final_check('actual-report-birth-'+name,lambda path=path:report_file_birth(path))
        if birth is not None:postclose_tail_births[str(path)]=birth
    # Actual port restoration is attempted even after ANY check above fails.
    restoration=HERE/'write-port-restoration.json';restoration_birth=None
    def restoration_file_birth():
        fd=os.open(restoration,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        try:
            info=os.fstat(fd);assert info.st_mode&0o777==0o600
            return(info.st_dev,info.st_ino)
        finally:os.close(fd)
    restoration_birth=final_check('actual-restoration-receipt-file-birth',restoration_file_birth)
    final_check('genuine-original-boundary-restore',boundary.restore)
    restored=final_check('actual-27-os-and-cio-port-restoration',lambda:
        all(getattr(os,name)is value for name,value in original_ports.items())and(io.open,builtins.open)==initial_io
        and not boundary.control_fds,require_true=True)is True
    def write_actual_restoration():
        info=restoration.lstat();assert restoration_birth==(info.st_dev,info.st_ino)
        with boundary.original_io(restoration,'w')as stream:
            json.dump(dict(restored=restored,actualCportCount=len(original_ports),controlDescriptors=sorted(boundary.control_fds)),stream);stream.write('\n')
    if restoration_birth is not None:final_check('write-genuine-postrestore-receipt',write_actual_restoration)
    final_check('genuine-boundary-close',boundary.close)
    def save_after_restore(name,value):
        path=HERE/name;info=path.lstat()
        assert postclose_tail_births[str(path)]==(info.st_dev,info.st_ino)and boundary.closed and not boundary.installed
        assert boundary.original_io is initial_io[0]
        with boundary.original_io(path,'w')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    postclose_writer=save_after_restore;postclose_writer_code=save_after_restore.__code__;postclose_writer_globals=save_after_restore.__globals__
    final_check('save-independent-finalization-checks',lambda:save_after_restore('controller-finalization-checks.json',
        dict(checks=finalization_checks,failures=finalization_failures)))
    passed=passed and restored and boundary.closed and not finalization_failures
    final_check('save-actual-child-result',lambda:save_after_restore('child-result.json',dict(status='PASS'if passed else'FAIL_OR_REFUSED',selected=plan['cases'],selectionGroup=group,
        suiteReturned=returned,testsRun=0 if result is None else result.testsRun,fatal=fatal,refusals=refusals,
        cases=case_receipts,cleanup=cleanup,retainedTemporaryRoots=roots,importedOrigins=loaded,
        actualAllLoadedOriginsAccounted=origin_after is not None,allLoadedOriginSnapshots=origins.snapshot_count,
        actualApprovedInputUnchanged=input_unchanged,approvedInputCliSha256=plan_sha,
        actualFivePublicOriginsEstablished=public_origins_ok,actualPublicSubjectOrigins=actual_public_origins,
        failureOnlyControllerDrains=node.controller_drains,finalizationChecks=finalization_checks,finalizationFailures=finalization_failures,
        allPhysicalPinsUnchanged=code_ok,monitorRestored=monitor_ok,actualFDThreadDrain=descriptor_drain,
        twoOwnRawCensusesEqual=raw_equal,noSDKImported=sdk_ok,nativeQualified=False,currentDomainQualified=False,wholeQualified=False)))
    passed=passed and not finalization_failures
    if finalization_failures:
        print(json.dumps(dict(controllerFinalizationFailed=True,failures=finalization_failures),sort_keys=True),file=sys.stderr,flush=True)
sys.exit(0 if passed and restored else 1)
