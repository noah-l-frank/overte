"""Root-only metadata assembly. Importing this file launches no target."""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,shutil,stat,sys
from closed_import_origins import ClosedOrigins
from own_boundary_proof import qualified_original,source_execution_original
from own_public_source_reads import forbidden_path
from prefix_common import REPO,load,sha,pin,head,FIELDS
from root_context import root_context,later_context
CODE=Path(__file__).resolve().parent
OLD=REPO/'.ios-host-tmp/avatar-completed-login-resume3-changed-normal-root-preparation-20261103'
SOURCE1=REPO/'.ios-host-tmp/avatar-normal-primary-budget-refusal-prefix1-source-controller-code-private-20261104'
SOURCE2=REPO/'.ios-host-tmp/avatar-api-budget-refusal-original-source2-real-port-stack-private-20261104'
OWN22=REPO/'.ios-host-tmp/root-avatar-world-shared-budget-own22-qualified-results-20261104'
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript','domain-server/resources')
def frozen(folder,filename,digest):
    path=folder/filename;assert sha(path)==digest;value=load(path)
    rows=value['files'];items=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
    paths={path}
    for name,row in items:
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        file=folder/name;assert sha(file)==(row['sha256']if type(row)is dict else row);paths.add(file)
    return paths
def project_namespace_admission(declared,ordered_roots):
    """Keep impossible aliases as pinned data; admit only real parent paths.

    Splitting a fullname produced from overte.sikuli/overte.py cannot create
    the nonexistent directories overte/sikuli. No namespace is invented and
    no bare alias or fallback loader is granted for such retained source.
    """
    choices={};failed={}
    for fullname in declared:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in declared:continue
            if name not in choices:
                choices[name]=sorted({str((Path(root)/Path(*parts[:size])).resolve(strict=True))
                    for root in ordered_roots if(Path(root)/Path(*parts[:size])).is_dir()})
            if len(choices[name])!=1:
                failed.setdefault(name,dict(physicalChoices=choices[name],affectedAliases=[]))['affectedAliases'].append(fullname)
    refused={}
    for name,row in failed.items():
        row['affectedAliases']=sorted(set(row['affectedAliases']))
        for fullname in row['affectedAliases']:
            entry=refused.setdefault(fullname,dict(origin=dict(declared[fullname]),unresolvableNamespaces=[]))
            entry['unresolvableNamespaces'].append(name)
    for row in refused.values():row['unresolvableNamespaces'].sort()
    admitted={name:row for name,row in declared.items()if name not in refused}
    namespaces={}
    for fullname in admitted:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in admitted:continue
            assert name not in refused and len(choices[name])==1
            namespaces[name]=choices[name]
    return admitted,namespaces,dict(version=1,declaredAliasCount=len(declared),
        admittedAliasCount=len(admitted),unadmittedAliases=refused,unresolvableNamespaces=failed,
        unadmittedSourcesRetainedAsData=True,unadmittedImportAuthority=False)

def main():
    p=argparse.ArgumentParser();p.add_argument('--source-freeze',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--destination',required=True)
    p.add_argument('--later-terminal-results',required=True);p.add_argument('--later-sha',required=True);p.add_argument('--later-bundle-freeze',required=True)
    p.add_argument('--own-boundary-proof',required=True);p.add_argument('--own-boundary-proof-sha',required=True)
    p.add_argument('--source-execution-proof',required=True);p.add_argument('--source-execution-proof-sha',required=True);a=p.parse_args()
    assert Path.cwd()==REPO and sys.dont_write_bytecode and sys.flags.no_site==1 and len(a.expected_head)==40 and head()==a.expected_head
    physical=frozen(CODE,'source-freeze.json',a.source_freeze)
    physical.update(frozen(REPO/'.ios-host-tmp/avatar-normal-prefix7-c10c-bound-original-http-nss-source-private-20261104','source-freeze.json','146fedc0cd29f7c7481198e3615063aaa1f1a48f0d9f3e6c31d9c6d74a0d6b52'))
    for name,row in load(CODE/'ACTUAL-OWN7-CLOSED-NEGATIVE-REFERENCES.json').items():
        physical[name]=pin(Path(name));assert physical[name]['sha256']==row['sha256']
    physical.update(frozen(REPO/'.ios-host-tmp/avatar-normal-prefix6-c10b-exact-own-source-read-source-wip-private-20261104','source-freeze.json','8ecee9ca3a03c9af3132c626ab7f4ce106408a05ef0ca04ae07ea2b70679ea60'))
    predecessor=REPO/'.ios-host-tmp/avatar-normal-prefix4-held-https-connector-option-custody-source-private-20261104'
    physical.update(frozen(predecessor,'source-freeze.json','981458bc00805b9480b1673bea9bbf0f80f6ba49e9b317e7d6f21a3b4db709d4'))
    reference=load(CODE/'closed-origin-reference.json')
    physical.update(frozen(Path(reference['sourcePacket']),'source-freeze.json',reference['sourceFreezeSha256']))
    assert sha(CODE/'closed_import_origins.py')==reference['memberSha256']
    # This actual proof join is deliberately fail-closed until Root supplies
    # the completed utility receipt and its real parser, not guessed fields.
    own_boundary_actual=qualified_original(a.own_boundary_proof,a.own_boundary_proof_sha)
    source_execution_actual=source_execution_original(a.source_execution_proof,a.source_execution_proof_sha)
    physical.update(frozen(Path(a.source_execution_proof).parent,'freeze.json',a.source_execution_proof_sha))
    for row in source_execution_actual['actualReceiptReferences'].values():
        path=Path(row['path']);assert pin(path)['sha256']==row['sha256'];physical.add(path)

    for folder,filename,digest in((OLD,'freeze.json','224630049852f0fdb8cacd7083380a8b3e2b383135eccc155767400b9835a05a'),
            (SOURCE1,'source-freeze.json','adb89825fba3daa42de5a5281ff666c5603aa1d6a497763c93c4bb06f106ac9c'),
            (SOURCE2,'freeze.json','3c14384dd0eb26ce2c2696c7b6d72d3baf8f0a25bae328b3f554f768930de348'),
            (OWN22,'freeze.json','47ca3ecfe8bf4622c60f4414d1fd9ef02e0fd7ed1e3c1488c301e77e40792665')):
        physical.update(frozen(folder,filename,digest))
    own=load(OWN22/'results.json');assert own['terminal']['status']=='PASS'and own['terminal']['ownProcessesAbsent']
    assert own['actualPassedCases']==22 and own['originalCleanupFinallyReturned']is True and own['all27PortsRestored']is True
    assert own['sharedHelperSource2Freeze']=='3c14384dd0eb26ce2c2696c7b6d72d3baf8f0a25bae328b3f554f768930de348'
    roots,expected,proofs,base,wrapper=root_context()
    roots,expected,extra,later=later_context(Path(a.later_terminal_results),a.later_sha,a.later_bundle_freeze,roots,expected)
    for row in proofs+extra:
        # Root context routines already verify every exact proof/member hash.
        # Their actual path conventions are retained as separate source proof.
        if isinstance(row,dict)and 'path'in row:
            path=Path(row['path']);physical.add(path if path.is_absolute()else REPO/path)
    # Pin every retained proof packet member, not merely its manifest. These
    # are named immutable source/status reads; no old-root census occurs here.
    for row in proofs+extra:
        if isinstance(row,dict)and 'path'in row:
            path=Path(row['path']);path=path if path.is_absolute()else REPO/path
            if path.name=='freeze.json':
                body=load(path);members=body['files'];entries=members.items()if type(members)is dict else((x['path'],x)for x in members)
                for name,member in entries:
                    assert not Path(name).is_absolute()and '..'not in Path(name).parts
                    child=path.parent/name;assert sha(child)==(member['sha256']if type(member)is dict else member);physical.add(child)
    assert set(expected)==roots
    assert set(source_execution_actual['actualResult']['newOriginalRoots'])<=roots
    for root,body in expected.items():
        assert type(body)is dict and '.'in body and Path(root).is_absolute()
        for name,row in body.items():
            assert not Path(name).is_absolute()and '..'not in Path(name).parts and set(FIELDS)<=set(row)
            kind=row['st_mode'];assert set(row)==set(FIELDS)|({'sha256'}if stat.S_ISREG(kind)else{'target'}if stat.S_ISLNK(kind)else set())
    public=set()
    for root in ROOTS:
        for path in(REPO/root).rglob('*'):
            assert not path.is_symlink()
            if path.is_file():public.add(path)
    physical.update(public);physical.update((REPO/'CMakeLists.txt',REPO/'interface/CMakeLists.txt'))
    modules={};namespaces={};alias_choices={}
    for root in(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests'):
        for path in sorted(root.rglob('*.py')):
            parts=path.relative_to(root).with_suffix('').parts;name='.'.join(parts[:-1]if parts[-1]=='__init__'else parts)
            if name:
                row=dict(path=str(path),package=path.name=='__init__.py')
                choices=alias_choices.setdefault(name,[])
                if row not in choices:choices.append(row)
                modules.setdefault(name,row)
            for i in range(1,len(parts)):namespaces.setdefault('.'.join(parts[:i]),str(root.joinpath(*parts[:i])))
    original_map=OLD/'source-root-final-map.json';physical.add(original_map)
    historical_module_rows=load(original_map)['modules']
    ambiguous={name:rows for name,rows in alias_choices.items()if len(rows)>1}
    assert set(ambiguous)=={'test_appium_adapter','test_voice_roundtrip'}
    # The genuine historical NativeInstalledFrontdoor imports the former
    # bare name. Its old explicit physical map selects the exact current
    # public file; no implicit search order chooses ambiguous authority.
    for name,rows in ambiguous.items():
        selected=dict(path=str(REPO/historical_module_rows[name]['path']),package=False)
        assert selected in rows;modules[name]=selected
    for name,row in historical_module_rows.items():
        assert modules[name]['path']==str(REPO/row['path']),'Original module physical path disappeared: '+name
    overlays={
        'adapters.api_budget_refusal_original':SOURCE2/'candidate/tests/device/adapters/api_budget_refusal_original.py',
        'ios.adapters.avatar_api_entry':SOURCE2/'candidate/tests/device/ios/adapters/avatar_api_entry.py',
        'ios.self_tests.test_ios_avatar_normal_primary_budget_refusal_prefix':SOURCE1/'test_ios_avatar_normal_primary_budget_refusal_prefix.py'}
    for name,path in overlays.items():modules[name]=dict(path=str(path),package=False);physical.add(path)
    third=load(CODE/'third-party-source-declarations.json')
    for name,row in third.items():assert sha(row['path'])==row['sha256'];physical.add(Path(row['path']))
    names=('run-prefix.py','supervise-prefix.py','prefix_common.py','avatar_ports.py','entry_observer.py','assets_fixture_ports.py','owned_write_boundary.py','monitoring_observer.py','metadata_reader.py','closed_import_origins.py','readonly-shared-stdlib-sources.json','own_public_source_reads.py')
    dest=Path(a.destination);assert dest.is_absolute()and dest.parent==REPO/'.ios-host-tmp'and dest.parent.resolve(strict=True)==dest.parent and not dest.exists()
    # All source/proof checks precede any new controller/output birth.
    binaries={}
    for name in('node','openssl','timeout'):
        selected=Path(shutil.which(name));resolved=selected.resolve(strict=True);v=pin(resolved)
        binaries[name]=dict(path=str(selected),realPath=str(resolved),device=v['st_dev'],inode=v['st_ino'],sha256=v['sha256']);physical.add(resolved)
    assert Path(binaries['node']['path']).parent==Path(binaries['openssl']['path']).parent
    # Pin the entire actual stdlib source/extension frontier before any
    # target execution. No site/dist traversal or unpinned cached pyc authority.
    std=Path(os.__file__).resolve(strict=True).parent
    extensions=tuple(importlib.machinery.EXTENSION_SUFFIXES);stdlib_namespaces={}
    for current,dirs,files in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current)
        dirs[:]=sorted(name for name in dirs if name not in('site-packages','dist-packages','__pycache__')and not(folder/name).is_symlink())
        relative=folder.relative_to(std)
        if relative.parts and all(part.isidentifier()for part in relative.parts)and not(folder/'__init__.py').is_file():
            stdlib_namespaces['.'.join(relative.parts)]=[str(folder)]
        for name in sorted(files):
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(extensions):continue
            assert path.resolve(strict=True)==path and not path.is_symlink()
            physical.add(path)
    python=Path(sys.executable).resolve(strict=True);physical.add(python)
    before={str(path):pin(path)for path in sorted(physical)}
    metadata_plan=dict(modules={},namespacePackages={},thirdPartyModules={},thirdPartyNamespacePackages={},
        stdlibNamespacePackages=stdlib_namespaces,stdlibRoots=[str(std)],
        pythonExecutable=dict(path=str(python),pin=before[str(python)]),physicalPins=before)
    metadata_origins=ClosedOrigins(metadata_plan,CODE,REPO,pin)
    metadata_before=metadata_origins.snapshot('before-prefix-metadata-destination-birth')
    dest.mkdir(mode=0o700)
    for name in names:
        target=dest/name
        with target.open('xb')as stream:stream.write((CODE/name).read_bytes())
        target.chmod(0o600);before[str(target)]=pin(target)
    with(dest/'normal_prefix_receipt.py').open('xb')as stream:stream.write((SOURCE1/'normal_prefix_receipt.py').read_bytes())
    (dest/'normal_prefix_receipt.py').chmod(0o600);before[str(dest/'normal_prefix_receipt.py')]=pin(dest/'normal_prefix_receipt.py')
    for name in('normal_prefix_receipt','owned_write_boundary','assets_fixture_ports','avatar_ports','entry_observer','monitoring_observer','prefix_common','metadata_reader','closed_import_origins','own_public_source_reads'):
        modules[name]=dict(path=str(dest/(name+'.py')),package=False)
    # Every old/public physical file stays pinned; impossible dotted folder
    # aliases become explicit metadata DATA, never a fake runtime namespace.
    ordered_roots=(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests')
    modules,namespace_rows,alias_admission=project_namespace_admission(modules,ordered_roots)
    namespaces={name:values[0]for name,values in namespace_rows.items()}
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(dest/'child/temporary'),PATH=str(Path(binaries['node']['path']).parent),PYTHONPATH='')
    assert not any(name.startswith('NODE_')for name in env)
    origin_plan=dict(projectAliasAdmission=alias_admission,modules={name:dict(row,sha256=before[row['path']]['sha256'])for name,row in modules.items()},
        namespacePackages={name:[value]for name,value in namespaces.items()},
        thirdPartyModules={name:dict(path=row['path'],sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')for name,row in third.items()},
        thirdPartyNamespacePackages={},stdlibNamespacePackages=stdlib_namespaces,stdlibRoots=[str(std)],
        pythonExecutable=dict(path=str(python),pin=before[str(python)]),physicalPins=before)
    metadata_paths={str(path):before[str(path)]for path in sorted(public)if forbidden_path(path)}
    project_paths={}
    for name,row in modules.items():
        if row['path']in metadata_paths:
            assert Path(row['path']).suffix=='.py'
            project_paths.setdefault(row['path'],[]).append(name)
    readonly_own=dict(version=1,metadataPaths=metadata_paths,
        projectPaths={path:sorted(names)for path,names in project_paths.items()})
    plan=dict(status='PRIVATE_UNRUN_AVATAR_PREFIX_REQUIRES_ROOT_REVIEW',expectedCurrentHead=a.expected_head,qualifiedOwn22HistoricalHead=own['publicHead'],historicalAvatarSourceHead=None,historicalAvatarAuthority=dict(freezeSha256='224630049852f0fdb8cacd7083380a8b3e2b383135eccc155767400b9835a05a',mapSha256=sha(original_map)),source1HistoricalHead=load(SOURCE1/'prospective-selection.json')['currentPublicHead'],sourcePins=before,modules=modules,namespaces=namespaces,thirdPartyModules=third,
        closedTopLevels=sorted({name.split('.')[0]for name in(*modules,*third,*namespaces)}),executables=binaries,environmentSha256=hashlib.sha256(json.dumps(env,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
        caseIds=load(SOURCE1/'prospective-selection.json')['suite']['caseIds'],fixtureAliasModules=load(SOURCE1/'prospective-selection.json')['suite']['fixtureAliasModules'],
        initialTimeoutSeconds=300,killAfterSeconds=5,expectedRetainedRoots=6,expectedNodeProcesses=3,expectedTLSProcesses=1,
        apiBudgetSeconds=25,originalFinishSeconds=30,projectAliasAdmission=alias_admission,readonlyOwnPublicSourceReads=readonly_own,originPlan=origin_plan,ownBoundaryActualJoin=own_boundary_actual,sourceExecutionActualJoin=source_execution_actual,explicitHistoricalBareAliasChoices=ambiguous,globalOriginals=expected,expectedGlobalRootCount=len(roots),rootProofs=proofs+extra,wholeQualified=False,nativeQualified=False,declaredArtifactModelOnly=True)
    with(dest/'approved-inputs.json').open('x')as stream:json.dump(plan,stream,sort_keys=True,indent=2);stream.write('\n')
    (dest/'approved-inputs.json').chmod(0o600)
    metadata_after=metadata_origins.snapshot('after-prefix-metadata-only-writes')
    for name,value in(('metadata-origin-before.json',metadata_before),('metadata-origin-after.json',metadata_after)):
        with(dest/name).open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
        (dest/name).chmod(0o600)
    assert before=={path:pin(path)for path in before}and head()==a.expected_head
    print(json.dumps(dict(status='METADATA_ONLY_UNRUN',input=str(dest/'approved-inputs.json'),inputSha256=sha(dest/'approved-inputs.json'),roots=len(roots),modules=len(modules))))
if __name__=='__main__':main()
