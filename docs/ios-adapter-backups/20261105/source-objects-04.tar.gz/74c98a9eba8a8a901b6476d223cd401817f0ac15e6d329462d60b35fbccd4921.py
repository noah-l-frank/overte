"""Two UNRUN actual-constructor lower-boundary cleanup controls.

The ONE replaced factory-return seam is explicitly modeled: it returns real
CoreDeviceTunnelProxy/UsbmuxLockdownClient/ServiceConnection objects owning real
local sockets, with NO pairing/USB/RSD/authentication success. No provider
record or fake Source is manufactured. The genuine SDK auth read must refuse.
"""
import socket
from types import MethodType
import unittest
from unittest.mock import patch

from pymobiledevice3.exceptions import NotPairedError, PyMobileDevice3Exception
from pymobiledevice3.lockdown import UsbmuxLockdownClient
from pymobiledevice3.remote import userspace_tunnel as userspace
from pymobiledevice3.remote.tunnel_service import CoreDeviceTunnelProxy
from pymobiledevice3.service_connection import ServiceConnection


class OriginalSdkPartialSetupCleanupTests(unittest.IsolatedAsyncioTestCase):
    async def lower_acquired_pair(self):
        services = []
        originals = []
        for _role in ('provider','lockdown'):
            left, right = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
            self.addCleanup(right.close)
            self.addCleanup(left.close)
            service = ServiceConnection(left)
            self.addAsyncCleanup(service.close)
            services.append(service)
            originals.append((left,right))
        provider = CoreDeviceTunnelProxy(services[0],
            'UNAUTHENTICATED-LOCAL-CONSTRUCTOR-CONTROL')
        client = UsbmuxLockdownClient(services[1],
            host_id='UNAUTHENTICATED-HOST-CONSTRUCTOR-CONTROL')
        self.addAsyncCleanup(client.close)
        self.addAsyncCleanup(provider.close)
        return provider, client, services, originals

    async def test_actual_acquired_callbacks_close_before_authentication_refusal_escapes(self):
        provider, client, services, originals = await self.lower_acquired_pair()
        calls = []
        async def modeled_factory_return(*args, **kwargs):
            self.assertEqual((None,False,False), args)
            self.assertEqual({'require_validated_source':True}, kwargs)
            calls.append((provider,client))
            return provider, client
        tunnel = userspace.UserspaceRsdTunnel(autopair=False,
            remotepairing_fallback=False, require_validated_source=True)
        self.addAsyncCleanup(tunnel.aclose)
        with patch.object(userspace, '_create_no_root_tunnel_provider', modeled_factory_return):
            with self.assertRaises(NotPairedError):
                await tunnel.aopen()
        self.assertEqual(1, len(calls))
        self.assertIsNone(tunnel._original_failed_setup_cleanup)
        self.assertIsNone(tunnel._source)
        self.assertIsNone(tunnel.rsd)
        self.assertIsNone(tunnel.tun)
        self.assertIsNone(tunnel._exit_stack)
        self.assertFalse(userspace.tunnel_service.USE_USERSPACE_TUNNEL)
        for service, (left,right) in zip(services, originals):
            self.assertIsNone(service.socket)
            self.assertEqual(-1, left.fileno())
            right.setblocking(False)
            self.assertEqual(b'', right.recv(1))

    async def test_original_auth_error_stays_primary_after_actual_close_then_fault(self):
        provider, client, services, originals = await self.lower_acquired_pair()
        original_close = provider.close
        async def fault_after_actual_close(receiver):
            self.assertIs(receiver, provider)
            await original_close()
            raise OSError('Control fault after genuine original provider close returned')
        provider.close = MethodType(fault_after_actual_close, provider)
        self.addCleanup(setattr, provider, 'close', original_close)
        calls = []
        async def modeled_factory_return(*_args, **_kwargs):
            calls.append((provider,client))
            return provider, client
        tunnel = userspace.UserspaceRsdTunnel(autopair=False,
            remotepairing_fallback=False, require_validated_source=True)
        with patch.object(userspace, '_create_no_root_tunnel_provider', modeled_factory_return):
            with self.assertRaises(NotPairedError) as failed:
                await tunnel.aopen()
            self.assertTrue(any('OSError' in note for note in failed.exception.__notes__))
            pending = tunnel._original_failed_setup_cleanup
            self.assertEqual(2, len(pending))
            self.assertIs(pending[0][0], provider)
            self.assertIs(pending[0][1].__self__, provider)
            self.assertIs(pending[1][0], client)
            self.assertIs(pending[1][1].__self__, client)
            with self.assertRaises(PyMobileDevice3Exception):
                await tunnel.aopen()
            with self.assertRaises(PyMobileDevice3Exception):
                await tunnel.aclose()
        self.assertEqual(1, len(calls))
        self.assertIsNone(tunnel._source)
        self.assertIsNone(tunnel.rsd)
        self.assertIsNone(tunnel.tun)
        self.assertIsNone(tunnel._exit_stack)
        self.assertFalse(userspace.tunnel_service.USE_USERSPACE_TUNNEL)
        # These concrete local sockets did close before the injected fault.
        # The SDK still retains an unresolved callback duty, never close proof.
        for service, (left,right) in zip(services, originals):
            self.assertIsNone(service.socket)
            self.assertEqual(-1, left.fileno())
            right.setblocking(False)
            self.assertEqual(b'', right.recv(1))
