"""Seven real UIKit copy/WAL cases; retain only explicitly owned test roots."""
from pathlib import Path
import hashlib,json,tempfile,types,unittest
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
from ios.self_tests import test_ios_tablet_web_source_owner as fixture
from ios.self_tests import test_ios_tablet_web_uikit_copy_recovery as cases
from ios.self_tests.retained_host_roots import retain_owned_root
plan=json.loads((HERE/'manifest.json').read_text())
for row in plan['paths']:
    assert hashlib.sha256((REPO/row['path']).read_bytes()).hexdigest()==row['candidateSha256'],row['path']
expected=next(row['caseIds'] for row in plan['paths'] if row['caseIds'])[3:5]
assert len(expected)==len(set(expected))==2
real=tempfile.TemporaryDirectory;retained=[]
def temporary(*args,**kwargs):
    value=real(*args,**kwargs);root=retain_owned_root(value,expected_root=Path(value.name))
    retained.append(value);print('retained UIKit copy root',root,flush=True);return value
original_fixture,original_cases=fixture.tempfile,cases.tempfile
fixture.tempfile=cases.tempfile=types.SimpleNamespace(TemporaryDirectory=temporary)
try:
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(expected)
    def ids(value):
        for item in value:
            if isinstance(item,unittest.TestSuite):yield from ids(item)
            else:yield item.id()
    actual=list(ids(suite));assert not loader.errors and actual==expected,loader.errors
    (HERE/'remaining-a-actual-case-ids.json').write_text(json.dumps(actual,indent=2)+'\n')
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
    assert not result.skipped
finally:
    fixture.tempfile,cases.tempfile=original_fixture,original_cases
    assert tempfile.TemporaryDirectory is real
    (HERE/'remaining-a-actual-retained-roots.json').write_text(json.dumps([value.name for value in retained],indent=2)+'\n')
raise SystemExit(not result.wasSuccessful())
