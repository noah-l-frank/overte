"""Future root-granted World6 minimal-terminal exact2; no full19 authority."""
from pathlib import Path
import hashlib,json,os,stat,sys,tempfile,threading,types,unittest

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
PLAN=HERE/'selected-suite-plan.json'
plan=json.loads(PLAN.read_text())
sha=lambda body:hashlib.sha256(body).hexdigest()
packet=REPO/plan['proposal']
assert sha((packet/'freeze.json').read_bytes())==plan['proposalFreezeSha256']
freeze=json.loads((packet/'freeze.json').read_text())
for name,expected in freeze['files'].items():assert sha((packet/name).read_bytes())==expected,name
# No imports or fixtures before exact future source publication/run preflight.
assert sha((REPO/plan['publicPath']).read_bytes())==plan['publicCandidateSha256'],'Recovery test not published at reviewed revision'
runroot=Path(os.environ['OVERTE_WORLD6_RECOVERY_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs') and runroot!=HERE/'runs'
info=runroot.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
temporary=Path(os.environ['TMPDIR']).resolve(strict=True)
assert temporary==runroot/'temporary' and Path(tempfile.gettempdir())==temporary
info=temporary.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
assert not any(temporary.iterdir()) and not (runroot/'selected2-result.json').exists(),'Fresh root required'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    before=path.lstat();assert stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode),str(path)
    value={field:getattr(before,field) for field in FIELDS}
    if stat.S_ISREG(before.st_mode):value['sha256']=sha(path.read_bytes())
    after=path.lstat();assert all(getattr(before,f)==getattr(after,f) for f in FIELDS),str(path)
    return value
for name,row in plan['reviewedFixturePins'].items():
    actual=pin(REPO/name);assert actual['sha256']==row['sha256'] and all(actual[key]==value for key,value in row['stat'].items()),name
source_paths=[REPO/plan['publicPath'],PLAN,Path(__file__),packet/'freeze.json']
source_paths.extend(REPO/name for name in plan['reviewedFixturePins'])
source_before={str(path):pin(path) for path in source_paths}
thread_before=set(threading.enumerate())

sys.path.insert(0,str(REPO/'tests/device'))
from ios.self_tests import test_ios_emote_marker_scope as marker_fixture
from ios.self_tests import world_web_actor_fixture as actor_fixture
from ios.self_tests.retained_host_roots import retain_owned_root

real_temporary_directory=tempfile.TemporaryDirectory
retained=[]
def retained_temporary_directory(*args,**kwargs):
    directory=real_temporary_directory(*args,**kwargs)
    root=Path(directory.name);assert root.is_relative_to(temporary)
    root=retain_owned_root(directory,expected_root=root)
    retained.append(str(root));print('RETAINED_ACTUAL_WORLD6_ROOT',root,flush=True)
    return directory

# Only fixture-local names. Keep real TemporaryDirectory/retain idempotence;
# no product decoder, file/HTTP/session getter, server or process is replaced.
original_aliases=[(module,module.tempfile) for module in (marker_fixture,actor_fixture)]
result=None
try:
    for module,original in original_aliases:
        assert original is tempfile
        module.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_temporary_directory)
    ids=plan['caseIds'];assert len(ids)==len(set(ids))==2
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for item in value:yield from flatten(item)
        else:yield value
    actual_ids=[test.id() for test in flatten(suite)]
    assert not loader.errors and actual_ids==ids and suite.countTestCases()==2,(loader.errors,actual_ids)
    print('ACTUAL_SELECTED_IDS',json.dumps(actual_ids),flush=True)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.testsRun==2 and not result.skipped,'Both selected cases must execute without skip'
finally:
    for module,original in original_aliases:module.tempfile=original
    assert tempfile.TemporaryDirectory is real_temporary_directory
    assert all(module.tempfile is original for module,original in original_aliases)
    assert source_before=={str(path):pin(path) for path in source_paths},'Source/launcher/fixture revision changed'
    def originals():return {str(path.relative_to(temporary)):pin(path) for path in (temporary,*sorted(temporary.rglob('*')))}
    first=originals();second=originals();assert first==second,'Post-test originals changed'
    (runroot/'selected2-originals-first.json').write_text(json.dumps(first,indent=2)+'\n')
    (runroot/'selected2-originals-second.json').write_text(json.dumps(second,indent=2)+'\n')
    remaining=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in thread_before and thread.is_alive()]
    report=dict(testsRun=None if result is None else result.testsRun,selectedCount=2,
        successful=False if result is None else result.wasSuccessful(),skipped=[] if result is None else result.skipped,
        retainedTemporaryDirectoryRoots=retained,fixtureAliasesRestored=True,
        sourceLauncherFixturePinsUnchanged=True,postTestOriginalCensusesEqual=True,
        newRemainingThreads=remaining,nativeCompiled=False,sdkExecuted=False,deviceQualified=False,
        whole19Qualified=False,full19CapClosed=True)
    (runroot/'selected2-result.json').write_text(json.dumps(report,indent=2)+'\n')
    print('ACTUAL_RESULT',json.dumps(report),flush=True)
    assert not remaining,'New fixture/worker/listener threads remain live'
sys.exit(0 if result is not None and result.wasSuccessful() else 1)
