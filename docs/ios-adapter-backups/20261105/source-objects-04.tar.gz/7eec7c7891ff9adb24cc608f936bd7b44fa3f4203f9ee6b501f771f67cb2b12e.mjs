/* Actual source-defined proxy/bridge flow with explicit HTTP producer models.
 * No SDK module imports, WDA session/service or device execution. */
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash, randomUUID} from 'node:crypto';
import nodeUrl from 'node:url';
import vm from 'node:vm';
import test from 'node:test';

const mapBytes=readFileSync(process.env.LIFECYCLE_WDA_SESSION_MODEL_MAP);
assert.equal(createHash('sha256').update(mapBytes).digest('hex'),process.env.LIFECYCLE_WDA_SESSION_MODEL_MAP_SHA256);
const map=JSON.parse(mapBytes);
function pinned(role) {
  const bytes=readFileSync(map[role].path);
  assert.equal(createHash('sha256').update(bytes).digest('hex'),map[role].sha256);
  return bytes.toString('utf8');
}
const source=pinned('proxy');
const begin=source.indexOf('const ORIGINAL_DOWNSTREAM_SESSION_EPOCHS =');
assert(begin>=0);
const body=source.slice(begin);
assert.equal(body.split('exports.JWProxy = JWProxy;').length,2);
// Actual loaded CommonJS class, import preamble excluded. Explicit dependency
// and HTTP producer DI; no SDK require/import/initializer is evaluated.
const code=body.replace('exports.JWProxy = JWProxy;','');
const modelLog={debug(){},info(){},warn(){}};
const namespace={nodeUrl,MJSONWP:'MJSONWP',W3C:'W3C',
  DEFAULT_LOG:modelLog,MAX_LOG_BODY_LENGTH:1024,
  util:{hasValue:value=>value!==null&&value!==undefined,isPlainObject:value=>value!==null&&typeof value==='object',
    truncateString:value=>String(value)},logger:{markSensitive:value=>value},
  errors:{ProxyRequestError:class extends Error{}},};
Object.assign(namespace,{node_url_1:{default:nodeUrl},support_1:{util:namespace.util,logger:namespace.logger},
  constants_1:{MAX_LOG_BODY_LENGTH:1024},errors_1:{errors:namespace.errors}});
const Proxy=vm.runInNewContext(code+';JWProxy',namespace,{filename:'pinned-ACTUAL-LOADED-nested-proxy'});
function modelProxy() {
  // Explicit HTTP producer seam; source logic under test is the ORIGINAL
  // response/epoch/receipt/getter path. It is not real HTTP/auth qualification.
  const proxy=Object.create(Proxy.prototype);
  Object.assign(proxy,{sessionId:'appium-placeholder',_log:modelLog,protocolConverter:{},_activeRequests:[],_downstreamProtocol:null});
  proxy.getUrlForProxy=(url,method)=>method==='POST'&&url.endsWith('/session')
    ? 'http://model-wda/session' : 'http://model-wda/session/'+proxy.sessionId;
  proxy.request=async()=>({status:200,headers:{},data:{value:{sessionId:'wda-original-session'}}});
  return proxy;
}

test('initial Appium placeholder is unavailable until original POST session response',async()=>{
  const proxy=modelProxy();assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
  await proxy.proxy('/session','POST',{});
  const actual=proxy.getOriginalDownstreamSessionSource();assert.equal(actual.sessionId,'wda-original-session');
  assert.equal(Object.isFrozen(actual),true);assert.notEqual(actual.sessionId,'appium-placeholder');
});
test('same SID recreation replaces original receipt; caller field assignment cannot recreate it',async()=>{
  const proxy=modelProxy();await proxy.proxy('/session','POST',{});
  const first=proxy.getOriginalDownstreamSessionSource();await proxy.proxy('/session','POST',{});
  const second=proxy.getOriginalDownstreamSessionSource();assert.notEqual(first,second);assert.equal(first.sessionId,second.sessionId);
  proxy.sessionId='appium-placeholder';assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
});
test('observed SID A foreign A cannot revive old receipt without another original response',async()=>{
  const proxy=modelProxy();await proxy.proxy('/session','POST',{});
  const first=proxy.getOriginalDownstreamSessionSource();proxy.sessionId='foreign-wda-session';
  assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
  proxy.sessionId=first.sessionId;assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
  await proxy.proxy('/session','POST',{});
  assert.notEqual(proxy.getOriginalDownstreamSessionSource(),first);
});
test('cancel entry revokes while original response pending; late response cannot remint',async()=>{
  const proxy=modelProxy();let complete;
  proxy.request=()=>new Promise(resolve=>{complete=resolve;});
  const creating=proxy.proxy('/session','POST',{});proxy.cancelActiveRequests();
  complete({status:200,headers:{},data:{value:{sessionId:'wda-original-session'}}});await creating;
  assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
});
test('delete entry revokes before its original return, without a new session request',async()=>{
  const proxy=modelProxy();await proxy.proxy('/session','POST',{});let complete;
  proxy.request=()=>new Promise(resolve=>{complete=resolve;});
  const deleting=proxy.proxy('/session/wda-original-session','DELETE');
  assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
  complete({status:200,headers:{},data:{value:null}});await deleting;
  assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
});
test('actual bridge borrows original WDA proxy receipt; changed owner refuses new input but permits release',async()=>{
  const helper=pinned('hostops');const first=helper.indexOf('const originalKeeperRoutes =');
  const last=helper.indexOf('\nexport function isStrictHostUtilityMode',first);assert(first>=0&&last>first);
  const bridgeCode=helper.slice(first,last);
  const stringifyAt=helper.indexOf('function stringifyLaunchEnvironment');
  const stringifyEnd=helper.indexOf('\n\nfunction createSimulatorHostOps',stringifyAt);assert(stringifyAt>=0&&stringifyEnd>stringifyAt);
  const launch=vm.runInNewContext(bridgeCode+'\n'+helper.slice(stringifyAt,stringifyEnd)+'\ntryOriginalKeeperLaunch',
    {WebDriverProxy:Proxy,randomUUID,WDA_PORT:8100},{filename:'pinned-actual-wda-host-route'});
  const proxy=modelProxy(),wda={jwproxy:proxy};const driver={sessionId:'original-appium-session',opts:{udid:'model-target',bundleId:'org.example.overte'},wda};
  const operations=[];const instance='a'.repeat(32);
  const remote={async originalKeeperOperation(_target,request){
    operations.push(request);
    return {originalKeeperOperationVersion:1,ownerInstance:instance,result:request.operation==='inspect'
      ? {creatorMode:'userspace-keeper',nativeTouchSupport:false} : {modeled:true}};
  }};
  await launch(driver,remote,{udid:'model-target',bundleId:'org.example.wda',env:{USE_PORT:'8100',WDA_PRODUCT_BUNDLE_IDENTIFIER:'org.example.wda'}});
  const bridge=driver[Symbol.for('overte.originalKeeperRoute.v1')];
  await assert.rejects(bridge.request('touch-begin',{}));assert.equal(operations.some(row=>row.operation==='wda-bind'),false);
  await proxy.proxy('/session','POST',{});
  await bridge.request('touch-begin',{});
  assert.equal(operations.find(row=>row.operation==='wda-bind').args.wdaSessionId,'wda-original-session');
  assert.equal(operations.filter(row=>row.operation==='touch-begin').length,1);
  driver.wda={jwproxy:modelProxy()};await assert.rejects(bridge.request('touch-begin',{}));
  assert.equal(operations.filter(row=>row.operation==='touch-begin').length,1);
  driver.wda=wda;await assert.rejects(bridge.request('touch-begin',{}));
  assert.equal(operations.filter(row=>row.operation==='touch-begin').length,1);
  await bridge.request('touch-release',{});assert.equal(operations.at(-1).operation,'touch-release');
});

// Actual loaded ESM source classes: only module import preamble/export marker
// removed; HTTP/owner callback are explicit models, never a service/auth proof.
function apiClass() {
  const text=pinned('api');const at=text.indexOf('export class TunnelApiClient {');assert(at>=0);
  const body=text.slice(at).replace('export class TunnelApiClient','class TunnelApiClient');
  return vm.runInNewContext(body+';TunnelApiClient',{DEFAULT_TIMEOUT_MS:10000,
    TunnelAvailabilityError:class extends Error{}},{filename:'actual-loaded-registry-client'});
}
function serverClass() {
  const text=pinned('server'),at=text.indexOf('export class TunnelRegistryServer {');
  const end=text.indexOf('export async function startTunnelRegistryServer',at);assert(at>=0&&end>at);
  const helper=text.indexOf('function sendJSON(');assert(helper>end);
  const body=text.slice(at,end).replace('export class TunnelRegistryServer','class TunnelRegistryServer');
  return vm.runInNewContext(body+'\n'+text.slice(helper)+';TunnelRegistryServer',{
    Buffer,http:{STATUS_CODES:{200:'OK',404:'Not Found',413:'Payload Too Large'}},
  },{filename:'actual-loaded-registry-server'});
}
function responseModel() {
  return {code:null,headers:null,body:null,writeHead(code,headers){this.code=code;this.headers=headers;},
    end(body){this.body=JSON.parse(body);}};
}
test('actual loaded client uses exact existing original-owner route and bounded request transport',async()=>{
  const Client=apiClass(),client=new Client('http://model-registry/remotexpc/tunnels');const calls=[];
  const request={schemaVersion:2,operation:'inspect',args:{}};
  client.fetchWithTimeout=async(...args)=>{calls.push(args);return {ok:true,json:async()=>({modelOnly:true})};};
  const result=await client.originalKeeperOperation('model target',request);
  assert.equal(result.modelOnly,true);assert.equal(calls.length,1);
  assert.equal(calls[0][0],'http://model-registry/remotexpc/tunnels/model%20target/original-owner');
  assert.equal(calls[0][1].method,'POST');assert.equal(calls[0][1].body,JSON.stringify(request));
  assert.equal(calls[0][2],35000);
});
test('actual loaded server dispatches one bounded original request on same owner callback',async()=>{
  const Server=serverClass(),server=Object.create(Server.prototype),calls=[];
  server.originalOwnerOperation=async(target,request)=>{calls.push([target,request]);return {modelOnly:true};};
  const bytes=Buffer.from(JSON.stringify({schemaVersion:2,operation:'inspect',args:{}}));
  async function* request(){yield bytes.subarray(0,4);yield bytes.subarray(4);}
  const response=responseModel();await server.originalOwnerRequest(request(),response,'model-target');
  assert.equal(response.code,200);assert.equal(response.body.modelOnly,true);assert.equal(calls.length,1);
  assert.equal(calls[0][0],'model-target');assert.equal(calls[0][1].operation,'inspect');
});
test('actual loaded server unavailable and oversized bodies never dispatch owner operation',async()=>{
  const Server=serverClass(),server=Object.create(Server.prototype);let consumed=false,calls=0;
  async function* request(){consumed=true;yield Buffer.alloc(16385,32);}
  let response=responseModel();await server.originalOwnerRequest(request(),response,'model-target');
  assert.equal(response.code,404);assert.equal(consumed,false);
  server.originalOwnerOperation=async()=>{calls++;return {};};response=responseModel();
  await server.originalOwnerRequest(request(),response,'model-target');
  assert.equal(response.code,413);assert.equal(calls,0);
});
