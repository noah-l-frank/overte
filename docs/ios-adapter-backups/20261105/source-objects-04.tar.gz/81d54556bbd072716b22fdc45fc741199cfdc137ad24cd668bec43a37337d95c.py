"""Prospective genuine owners; SDK/native/peer delivery remain lower models."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib,uuid
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from adapters.script_feature.history import unpack
from ios.adapters import appium_adapter
from ios.adapters.lifecycle_independent_actor_flow import observe_held_with_independent_actor
from ios.adapters.lifecycle_independent_actor_world import LifecycleActorWorldPacket,LifecycleActorWorldPending
from ios.adapters.lifecycle_independent_actor_join import compare_held_originals
from ios.self_tests import test_ios_lifecycle_world_attempt as attempt
from ios.self_tests.test_ios_lifecycle_world_hold import LifecycleWorldHoldTests
from ios.self_tests.lifecycle_independent_actor_domain import LifecycleActorDomain,PRIMARY,TICKET


class LifecycleIndependentActorOriginalTests(LifecycleWorldHoldTests):
    def setUp(self):
        original=attempt.TouchBoundary
        class PrimaryIdentity(original):
            def decorate(receiver,value):
                super().decorate(value)
                value['source']['domain']['selfSha256']=hashlib.sha256(uuid.UUID(PRIMARY).bytes).hexdigest()
        # Select the declared native identity at model birth, before originals.
        with patch.object(attempt,'TouchBoundary',PrimaryIdentity):super().setUp()
        self.peer=LifecycleActorDomain(self,self.b.owner.run)

    def actors(self):return self.peer.owner(1),self.peer.owner(2)

    async def held_pair(self,*,ignored=False):
        primary=self.make();self.peer.ignore_peer=ignored
        with self.peer.lock.held():
            before,after=self.actors();before.acquire(TICKET)
            await primary.act();primary.observe()
            self.peer.peer_event() # Distinct declared peer-delivery event.
            after.acquire(TICKET)
            return primary,before,after

    async def test_genuine_actor_before_after_matches_actual_primary_motion_without_borrowed_pixels(self):
        primary,before,after=await self.held_pair()
        with self.peer.lock.held():
            calls=len(self.peer.queries);value=compare_held_originals(primary,before,after)
            self.assertEqual([0.,0.,-.7],value['actorMeasuredRootDelta']);self.assertEqual(2,calls)
            self.assertEqual(calls,len(self.peer.queries));self.assertFalse(value['actorPixelsEstablished'])
            self.assertFalse(value['pairedTemporalOrderEstablished']);self.assertFalse(value['resourceRetirementEstablished'])
            self.assertNotEqual(primary.binding['targetFingerprint'],before.binding['targetFingerprint'])

    async def test_ignored_independent_peer_event_refuses_even_when_primary_native_move_succeeded(self):
        primary,before,after=await self.held_pair(ignored=True)
        with self.peer.lock.held():
            saved=deepcopy(after.original());calls=len(self.peer.queries)
            with self.assertRaises(NativeUIError):compare_held_originals(primary,before,after)
            self.assertEqual(saved,after.original());self.assertEqual(calls,len(self.peer.queries))

    async def test_retained_actor_originals_refuse_same_bytes_foreign_inode_without_requery(self):
        with self.peer.lock.held():
            owner=self.peer.owner(1);owner.acquire(TICKET);child=owner.child(historical=True)
            path=child.files().path(child.state['storage']);raw=path.read_bytes();path.rename(path.with_name('retained-'+path.name))
            path.write_bytes(raw);path.chmod(0o600);calls=len(self.peer.queries)
            with self.assertRaises(NativeUIError):owner.original()
            self.assertEqual(calls,len(self.peer.queries));self.assertEqual(raw,path.read_bytes())

    async def test_lost_actor_http_return_reopens_only_original_nonce_and_never_resends(self):
        with self.peer.lock.held():
            owner=self.peer.owner(1);self.peer.lost=True
            with self.assertRaises(OSError):owner.acquire(TICKET)
            self.assertEqual(1,len(self.peer.queries));first=deepcopy(self.peer.queries[0])
            reopened=self.peer.owner(1);value=reopened.acquire(TICKET)
            self.assertEqual([first],self.peer.queries);self.assertEqual(first,value['nativeOriginal']['query'])

    async def test_final_parent_cas_failure_latches_same_owner_and_reopens_actual_saved_actor(self):
        with self.peer.lock.held():
            owner=self.peer.owner(1);write=owner.store.write
            def fail(value,previous):
                if unpack(value['payload'])[0]['phase']=='complete':raise OSError('Before actual Actor parent complete CAS')
                return write(value,previous)
            with patch.object(owner.store,'write',fail),self.assertRaises(OSError):owner.acquire(TICKET)
            self.assertTrue(owner.failed);calls=len(self.peer.queries)
            for method in(owner.bound,owner.original):
                with self.assertRaises(NativeUIError):method()
            self.assertEqual('reading',unpack(owner.store.read()['payload'])[0]['phase'])
            reopened=self.peer.owner(1);reopened.acquire(TICKET);self.assertEqual(calls,len(self.peer.queries))

    async def test_changed_phase_after_uncertain_getter_never_relabels_saved_original(self):
        with self.peer.lock.held():
            owner=self.peer.owner(1);self.peer.lost=True
            with self.assertRaises(OSError):owner.acquire(TICKET)
            self.peer.journal.activate(self.peer.run,'e'*32,'cleanup',{})
            calls=len(self.peer.queries)
            with self.assertRaises((NativeUIError,ValueError)):self.peer.owner(1).acquire(TICKET)
            self.assertEqual(calls,len(self.peer.queries));self.assertEqual('reading',unpack(owner.store.read()['payload'])[0]['phase'])

    async def test_foreign_primary_uuid_cannot_select_actor_self_or_unrelated_remote_body(self):
        self.peer.fault=lambda value:value['source']['bodies']['avatars'][0].update(sessionId='00000000-0000-4000-8000-000000000000')
        primary,before,after=await self.held_pair()
        with self.peer.lock.held():
            calls=len(self.peer.queries)
            with self.assertRaises(NativeUIError):compare_held_originals(primary,before,after)
            self.assertEqual(calls,len(self.peer.queries))

    async def test_observed_actor_source_loss_latches_same_owner_without_query_or_aba_revival(self):
        with self.peer.lock.held():
            owner=self.peer.owner(1);self.peer.good=False
            with self.assertRaises(NativeUIError):owner.acquire(TICKET)
            self.assertTrue(owner.failed);self.assertEqual([],self.peer.queries)
            self.peer.good=True
            with self.assertRaises(NativeUIError):owner.acquire(TICKET)
            self.assertEqual([],self.peer.queries);self.assertIsNone(owner.store.read())

    async def test_actual_sdk_factory_holds_two_original_actor_owners_without_session_or_launch(self):
        counts=(self.peer.ctx.sessions,self.peer.ctx.launches)
        with patch.object(appium_adapter,'WebDriver',return_value=self.peer.sdk_client):
            with self.peer.runtime.actor_world_originals('test-only',self.peer.run,(3,4),self.peer.client,
                    epoch_ms=self.peer.clock,monotonic=self.peer.mono)as owners:
                before,after=owners;self.assertIs(before.lock,after.lock)
                self.assertEqual(self.peer.lock.path,before.lock.path)
                a=before.acquire(TICKET);self.peer.peer_event();b=after.acquire(TICKET)
                self.assertEqual(before.binding,after.binding);self.assertEqual('actor',a['role']);self.assertEqual(4,b['index'])
        self.assertEqual(counts,(self.peer.ctx.sessions,self.peer.ctx.launches));self.assertEqual(2,len(self.peer.queries))

    async def test_optional_ordinary_flow_brackets_actual_held_input_with_independent_actor_queries(self):
        primary=self.make();send=self.context.send_touchscreen
        async def reported(state,x,y):
            result=await send(state,x,y)
            if state==0xC2 and len(self.context.calls)==2:self.peer.peer_event()
            return result
        # Declared peer transport event follows the actual lower HID report;
        # it is independent from every World read and copies no Primary DTO.
        self.context.send_touchscreen=reported
        counts=(self.peer.ctx.sessions,self.peer.ctx.launches)
        with patch.object(appium_adapter,'WebDriver',return_value=self.peer.sdk_client):
            value=await observe_held_with_independent_actor(primary,self.peer.runtime,'test-only',self.peer.client)
        self.assertTrue(value['genuineControllerCallOrderEstablished']);self.assertTrue(value['originalPrimaryReleaseStillRequired'])
        self.assertEqual([0xC2,0xC2],self.flags());self.assertEqual(2,len(self.peer.queries))
        self.assertEqual(counts,(self.peer.ctx.sessions,self.peer.ctx.launches))

    async def test_actual_independent_sdk_candidate_replacement_refuses_before_actor_world_delivery(self):
        with self.peer.lock.held():
            owner=self.peer.owner(1);self.peer.ctx.artifact.write_bytes(b'Foreign candidate after real Actor source birth')
            with self.assertRaises((NativeUIError,ValueError,RuntimeError)):owner.acquire(TICKET)
            self.assertTrue(owner.failed);self.assertEqual([],self.peer.queries)
            self.assertIsNone(owner.store.read())

    async def test_new_stale_or_foreign_process_actor_packets_remain_issued_and_cannot_resend(self):
        with self.peer.lock.held():
            for index,fault in enumerate(('pid','body-sequence'),1):
                def hostile(value,fault=fault):
                    if fault=='pid':value['processId']=43
                    else:value['source']['bodies']['sequence']=0
                self.peer.fault=hostile;owner=self.peer.owner(index)
                with self.assertRaises(NativeUIError):owner.acquire(TICKET)
                query=deepcopy(self.peer.queries[-1]);calls=len(self.peer.queries)
                with self.assertRaises(NativeUIError):self.peer.owner(index).acquire(TICKET)
                self.assertEqual(calls,len(self.peer.queries));self.assertEqual(query,self.peer.queries[-1])
                self.assertEqual('reading',unpack(owner.store.read()['payload'])[0]['phase'])

    async def test_other_unresolved_actor_slot_blocks_new_fixed_file_query_without_overwriting_old_raw(self):
        with self.peer.lock.held():
            first=self.peer.owner(1);self.peer.lost=True
            with self.assertRaises(OSError):first.acquire(TICKET)
            old_raw=self.peer.raw;second=self.peer.owner(2)
            with self.assertRaises(LifecycleActorWorldPending):second.acquire(TICKET)
            self.assertEqual(1,len(self.peer.queries));self.assertEqual(old_raw,self.peer.raw)
            self.assertEqual('reading',unpack(first.store.read()['payload'])[0]['phase'])

    async def test_actual_primary_clock_callback_cannot_replace_independent_actor_source(self):
        native=self.b.d.source.source['clock_source']
        with self.peer.lock.held():
            owner=self.peer.owner(1)
            with patch.object(self.peer.native,'send',native.send),self.assertRaises(NativeUIError):owner.acquire(TICKET)
            self.assertTrue(owner.failed);self.assertEqual([],self.peer.queries)
