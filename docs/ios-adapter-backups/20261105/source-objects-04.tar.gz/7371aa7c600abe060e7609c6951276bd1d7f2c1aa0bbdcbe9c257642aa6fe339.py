"""Same-invocation pure decode reuse, with actual owned originals."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch

from adapters.normal_ui import NativeUIError
from adapters.original_file_reads import scope
from adapters.original_frame_store import OriginalFrameStore
from ios.adapters import tablet_web_aggregate_root as aggregate
from ios.adapters import tablet_web_child_rotation as closed
from ios.adapters import tablet_web_rotation_fence as fence
from ios.self_tests import test_ios_tablet_web_aggregate_root as fixture


class TabletParentDecodeHandoffTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):fixture.TabletOwnedAggregateRootTests.setUpClass()

    def setUp(self):
        self.f=fixture.TabletOwnedAggregateRootTests();self.addCleanup(self.f.doCleanups)
        self.f.setUp();self.owner=self.f.open()

    def test_actual_guard_decodes_once_but_rereads_every_original_on_each_invocation(self):
        monitor=sys.monitoring;tool=next(i for i in range(6) if monitor.get_tool(i) is None)
        monitor.use_tool_id(tool,'tablet-parent-pure-decode-test');seen=[]
        def call(code,_offset):seen.append(code)
        monitor.register_callback(tool,monitor.events.PY_START,call)
        monitor.set_local_events(tool,closed.decode.__code__,monitor.events.PY_START)
        try:
            calls=list(self.f.boundary.calls)
            with scope(fresh=True) as first:self.owner._parent_guard()
            self.assertEqual(1,len(seen));self.assertTrue(first)
            with scope(fresh=True) as second:self.owner._parent_guard()
            self.assertEqual(2,len(seen));self.assertEqual(first,second)
            required=set(self.f.canonical_paths)
            self.assertTrue(required<=first);self.assertEqual(calls,self.f.boundary.calls)
            self.assertEqual(self.f.canonical,self.f.pins(self.f.canonical_paths))
        finally:
            monitor.set_local_events(tool,closed.decode.__code__,0)
            monitor.register_callback(tool,monitor.events.PY_START,None);monitor.free_tool_id(tool)

    def test_same_bytes_replaced_canonical_child_inode_refuses_after_successful_guard(self):
        self.owner._parent_guard();path=self.f.source.children['dom'].store.path
        raw=path.read_bytes();before=path.stat();calls=list(self.f.boundary.calls)
        tmp=TemporaryDirectory();self.addCleanup(tmp.cleanup);outside=Path(tmp.name);outside.chmod(0o700)
        retained=outside/'original-child';os.replace(path,retained)
        with path.open('xb') as stream:stream.write(raw)
        path.chmod(0o600)
        self.assertEqual(raw,retained.read_bytes());self.assertEqual(before.st_ino,retained.stat().st_ino)
        self.assertNotEqual(before.st_ino,path.stat().st_ino)
        with self.assertRaises(NativeUIError):self.owner._parent_guard()
        self.assertEqual(calls,self.f.boundary.calls)

    def test_current_memory_mutation_during_actual_copy_read_keeps_literal_late_validation(self):
        original=OriginalFrameStore.read;changed=[];calls=list(self.f.boundary.calls)
        def actual(store,reference):
            result=original(store,reference)
            if store.namespace=='tabletweb-closed-headers' and not changed:
                changed.append(True);self.owner.parent['copyIntent']['phase']='foreign-phase'
            return result
        saved=deepcopy(self.owner.parent)
        try:
            with patch.object(OriginalFrameStore,'read',actual),self.assertRaises(NativeUIError):self.owner._parent_guard()
            self.assertEqual([True],changed);self.assertEqual(calls,self.f.boundary.calls)
            self.assertEqual(self.f.canonical,self.f.pins(self.f.canonical_paths))
        finally:self.owner.parent=saved

    def test_inplace_parser_code_change_during_actual_copy_read_keeps_literal_late_rejection(self):
        original=OriginalFrameStore.read;parser=fence._legacy;code=parser.__code__;defaults=parser.__defaults__
        changed=[];calls=list(self.f.boundary.calls)
        def reject(raw,expected):raise NativeUIError('Actual changed legacy parser')
        def actual(store,reference):
            result=original(store,reference)
            if store.namespace=='tabletweb-closed-headers' and not changed:
                changed.append(True);parser.__code__=reject.__code__
            return result
        try:
            with patch.object(OriginalFrameStore,'read',actual),self.assertRaisesRegex(NativeUIError,'Actual changed legacy parser'):
                self.owner._parent_guard()
            self.assertEqual([True],changed);self.assertEqual(calls,self.f.boundary.calls)
        finally:
            parser.__code__=code;parser.__defaults__=defaults
            self.assertIs(parser.__code__,code);self.assertIs(parser.__defaults__,defaults)

    def test_changed_decode_alias_runs_both_literal_calls_in_the_original_guard(self):
        original=closed.decode;calls=[];native=list(self.f.boundary.calls)
        def actual(value,expected):calls.append(True);return original(value,expected)
        with patch.object(closed,'decode',actual):self.owner._parent_guard()
        self.assertEqual([True,True],calls);self.assertEqual(native,self.f.boundary.calls)
