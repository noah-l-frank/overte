"""Private source proposal only. No project imports/tests/publication."""
import ast,difflib,hashlib,json,os
from pathlib import Path
REPO=Path.cwd();OUT=REPO/'.ios-host-tmp/emote-callback-live-prefix-private-proposal-20261102'
def write(path,data):
 path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 with path.open('x') as stream:stream.write(data)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
profile=REPO/'.ios-host-tmp/emote-complete-live747-supported-readonly-profile-preparation-20261029/runs/profile1/first-o24euytu/actual-project-calls.json'
rows=json.loads(profile.read_text());paths=sorted({r['path'] for r in rows if r['path'].startswith('tests/device/') and '/self_tests/' not in r['path']})
modules=[path[len('tests/device/'):-3].replace('/','.') for path in paths]
helper='''"""Existing AvatarRecordCache shared only by an explicit CallbackLive2 owner.

Historical rows keep their original measurement and clocks. Every hit retains
actual original file signatures/read membership; every outer Live decode keeps
its complete immutable inventory, row order, pending and orphan checks. Current
State/native admission, new acquisitions and resource cleanup never enter it.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from importlib import import_module
from types import FunctionType,ModuleType,BuiltinFunctionType,CodeType
from contextvars import ContextVar
import re
from adapters.native_feature_observation import need
from adapters.script_feature.history import canonical,same
from ios.adapters.avatar_record_cache import AvatarRecordCache

# The actual source modules on the complete retained747 graph decode. Bind
# their full parser/class namespaces, including aliases and policy constants;
# a new/unsupported dependency takes the unchanged literal decoder.
PARSER_MODULES=__MODULES__


class _Unsupported(Exception):pass


def _token(value,refs,active,depth=0):
    if depth>32:raise _Unsupported
    kind=type(value)
    if kind in (str,int,bool,type(None)):return (kind.__name__,value)
    if kind is float:return ('float',value.hex())
    refs.append(value);identity=id(value)
    if identity in active:return ('recursive',identity)
    active=active|{identity}
    def token(item):return _token(item,refs,active,depth+1)
    if kind is FunctionType:
        closure=() if value.__closure__ is None else tuple(token(cell.cell_contents) for cell in value.__closure__)
        return ('function',identity,id(value.__code__),token(value.__defaults__),token(value.__kwdefaults__),closure)
    if kind is CodeType:return ('code',identity)
    if kind is BuiltinFunctionType:return ('builtin',identity)
    if kind is ModuleType:return ('module',identity)
    if kind is ContextVar:return ('contextvar',identity) # No current validator-scope result is cached.
    if kind is re.Pattern:return ('pattern',identity,value.pattern,value.flags)
    if kind in (list,tuple):return (kind.__name__,tuple(token(item) for item in value))
    if kind in (set,frozenset):
        if not all(type(item) is str for item in value):raise _Unsupported
        return (kind.__name__,tuple(sorted(value)))
    if kind is dict:
        if not all(type(key) is str for key in value):raise _Unsupported
        return ('dict',tuple((key,token(value[key])) for key in sorted(value)))
    if kind in (staticmethod,classmethod):return (kind.__name__,token(value.__func__))
    if kind is property:return ('property',token(value.fget),token(value.fset),token(value.fdel))
    if kind is type:
        # External standard-library types are bindings, not project policies.
        if not value.__module__.startswith(('adapters.','ios.adapters.','feature_journeys.')):
            return ('external-type',identity)
        attributes=[]
        for name,item in sorted(vars(value).items()):
            if name.startswith('__') and name not in ('__init__','__enter__','__exit__','__call__'):continue
            attributes.append((name,token(item)))
        return ('class',identity,tuple(id(base) for base in value.__bases__),tuple(attributes))
    raise _Unsupported


class CallbackLiveRecords:
    """Feature-local reuse of byte-proved historical rows, never current facts."""
    def __init__(self):
        self.cache=AvatarRecordCache();self.modules=tuple(import_module(name) for name in PARSER_MODULES)
        self.references=[];self.policy=self.signature(self.references)

    def signature(self,references):
        result=[]
        try:
            for module in self.modules:
                members=[]
                for name,value in sorted(vars(module).items()):
                    if name.startswith('__'):continue
                    # Module aliases and full callable/class policy are part of
                    # admission, even when a decoder imports the same function
                    # under another name. Mutable original rows live on owners,
                    # never in these source-module namespaces.
                    members.append((name,_token(value,references,set())))
                result.append((module.__name__,id(module),tuple(members)))
            return tuple(result)
        except (AttributeError,TypeError,ValueError,RecursionError,_Unsupported):return None

    def literal(self):
        return self.policy is not None and self.signature([])==self.policy

    def read(self,owner,reference,decode):
        from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
        if type(owner) is not IOSEmoteCallbackLive or not self.literal():return decode()
        owner.file_guard()
        need(owner._historical_rows is self and type(self.cache) is AvatarRecordCache)
        context=dict(binding=owner.binding,primaryBinding=owner.primary_binding,runId=owner.run,role=owner.role,
            root=str(owner.root),store=str(owner.store.path),sourceLock=str(owner.lock.path),primaryLock=str(owner.primary_lock.path),
            fixtureUrl=owner.fixture_url,phaseInstance=owner.phase_instance,imagePolicy=owner.policy,
            original=dict(root=str(owner.originals.root),namespace=owner.originals.namespace,
                schema=owner.originals.schema_prefix,kind=owner.originals.kind))
        before=canonical(context);key=dict(emoteCallbackLiveHistoricalRowVersion=1,context=context,reference=reference)
        encoded=canonical(key)
        def checked():
            owner.file_guard();need(self.literal() and canonical(key)==encoded and canonical(context)==before)
            result=decode()
            owner.file_guard();need(self.literal() and canonical(key)==encoded and canonical(context)==before)
            return result
        if encoded not in self.cache.rows and len(self.cache.rows)>=512:return decode()
        result=self.cache.read(key,checked)
        owner.file_guard();need(self.literal() and canonical(key)==encoded and canonical(context)==before)
        return result
'''.replace('__MODULES__',repr(tuple(modules)))
path='tests/device/ios/adapters/emote_callback_live_records.py';write(OUT/'candidate'/path,helper)
path='tests/device/ios/adapters/emote_callback_live.py';before=(REPO/path).read_text();after=before
anchor='from copy import deepcopy\n';after=after.replace(anchor,anchor+'from contextlib import contextmanager\nfrom ios.adapters.emote_callback_live_records import CallbackLiveRecords\n')
anchor='    FORMAT_VERSION=2\n';body='''
    def __init__(self,owner,*,historical_rows=None):
        need(historical_rows is None or type(historical_rows) is CallbackLiveRecords)
        self._historical_rows=historical_rows
        super().__init__(owner)

    @classmethod
    def archive(cls,value,*,store,lock,primary_lock,historical_rows=None):
        need(historical_rows is None or type(historical_rows) is CallbackLiveRecords)
        obj=cls._archive_header(value,store=store,lock=lock,primary_lock=primary_lock)
        obj._historical_rows=historical_rows;obj.state=obj.decode(value);return obj

    @classmethod
    @contextmanager
    def archive_scope(cls,value,*,store,lock,primary_lock,historical_rows=None):
        need(historical_rows is None or type(historical_rows) is CallbackLiveRecords)
        obj=cls._archive_header(value,store=store,lock=lock,primary_lock=primary_lock)
        obj._historical_rows=historical_rows
        with obj.decoding(value) as state:obj.state=state;yield obj

    def record(self,reference):
        history=getattr(self,'_historical_rows',None)
        if history is None:return super().record(reference)
        self.bound()
        with self.read_batch():return history.read(self,reference,lambda:self.read_record(reference))

    @contextmanager
    def decoding(self,value):
        history=getattr(self,'_historical_rows',None)
        if history is None or not history.literal():
            with super().decoding(value) as state:yield state
            return
        # The full inventory/prefix decoder remains the outer owner. Each cold
        # record still derives its actual original graph TWICE via the existing
        # AvatarRecordCache. Warm rows reopen exact physical file signatures
        # and restore actual reads; no copied result is a new/current sample.
        with self.read_batch():yield self.decode_state(value)
'''
assert after.count(anchor)==1;after=after.replace(anchor,anchor+body)
anchor='    PAIRED_FORMAT_VERSION=7\n';body='''
    def live_owner(self,owner):
        history=getattr(self,'_callback_live_historical_rows',None)
        if history is None:
            history=CallbackLiveRecords();self._callback_live_historical_rows=history
        return IOSEmoteCallbackLive(owner,historical_rows=history)
'''
assert after.count(anchor)==1;after=after.replace(anchor,anchor+body)
after=after.replace('live=IOSEmoteCallbackLive(self.retirement_owner(parts))','live=self.live_owner(self.retirement_owner(parts))').replace("measured=IOSEmoteCallbackLive(owner).append(reference)['measurement']","measured=self.live_owner(owner).append(reference)['measurement']")
write(OUT/'base'/path,before);write(OUT/'candidate'/path,after)
patch=[]
for path in sorted((OUT/'candidate').rglob('*.py')):
 relative=str(path.relative_to(OUT/'candidate'));base=OUT/'base'/relative
 old=base.read_text() if base.exists() else '';new=path.read_text();ast.parse(new,filename=relative)
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
write(OUT/'source2.diff',''.join(patch))
write(OUT/'plan.json',json.dumps(dict(status='PRIVATE_SOURCE_UNRUN_PRELIMINARY_POLICY_REVIEW_REQUIRED',profileSource=str(profile),profileSHA256=sha(profile),parserModuleCount=len(modules),baseLiveDefaultUnchanged=True,callbackDefaultNoHistoryLiteral=True,featureLocalOnly=True,firstBoundedReadonly='After Root review/publication: cold then same-holder warm complete Live747 archive, actual original readmembership equal, full before/after rawpins. New TWO-decode stage initial120+kill5, no Window retry.',remaining=['Review supported token coverage; unsupported namespace values deliberately force literal fallback','Meaningful counterexamples and Root-only diagnostic controller not yet authored','Add parser/policy/source identity tests before first Window retry']),indent=2)+'\n')
write(OUT/'freeze.json',json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(packet=str(OUT),freeze=sha(OUT/'freeze.json'),sourceFiles=2,parserModules=len(modules))))
