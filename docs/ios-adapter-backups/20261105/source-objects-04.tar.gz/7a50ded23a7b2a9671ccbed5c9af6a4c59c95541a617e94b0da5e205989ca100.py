"""One supported historical Root4 constructor/history, no live producer/test."""
import cProfile,hashlib,importlib.abc,importlib.machinery,json,os,pstats,signal,stat,sys,threading,time,traceback
from pathlib import Path
from types import CodeType
from profile_metadata import HERE,REPO,frozen,pin,process,save,sources
value=frozen();OUTPUT=Path(os.environ['OVERTE_TABLET_ROOT328_PROFILE_ROOT']).resolve(strict=True)
assert OUTPUT.is_relative_to(HERE/'runs') and OUTPUT!=HERE/'runs' and stat.S_IMODE(OUTPUT.stat().st_mode)==0o700
save(OUTPUT/'runner-process-binding.json',process(os.getpid()))
ready=json.loads((HERE/'actual-source-map.json').read_text());assert ready['status']=='ACTUAL_CURRENT_DIAGNOSTIC_SOURCE_MAP'
expected=sources(value);assert expected==ready['sourcePins']
BASE_THREADS=set(threading.enumerate());effects=[];marks=[];imports={};error=None;interrupted=None;reads=set();owner=None;frames=None
scope=json.loads((HERE/'independent-original-scope.json').read_text());assert hashlib.sha256((HERE/'independent-original-scope.json').read_bytes()).hexdigest()==value['independentScopeSha256']
root=Path(scope['root']);lockpath=root/'script-feature-sources.lock';lockpin=pin(lockpath);started=time.monotonic();profiler=cProfile.Profile();profiling_started=False
def mark(name):
    row=dict(name=name,seconds=time.monotonic()-started);marks.append(row);print('BOUNDARY',json.dumps(row),flush=True)
def forbidden(name):effects.append(name);raise AssertionError('Forbidden historical-only effect: '+name)
def audit(event,args):
    if event.startswith(('socket.','subprocess.','os.exec','os.spawn','os.fork')) or event in ('os.system','os.posix_spawn','pty.spawn','ctypes.dlopen'):forbidden(event)
    if event in ('os.remove','os.rmdir','os.rename','os.mkdir','os.chmod','os.chown','os.utime','os.link','os.symlink','os.truncate'):forbidden(event)
    if event=='open':
        path,mode,flags=args
        if not flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):return
        if not isinstance(path,(str,bytes,os.PathLike)):forbidden('descriptor-write-open')
        actual=Path(os.fsdecode(path)).absolute()
        if actual.parent==OUTPUT:return
        if actual==lockpath and mode is None and not flags&(os.O_TRUNC|os.O_APPEND|os.O_EXCL):
            row=actual.lstat()
            if row.st_dev==lockpin['st_dev'] and row.st_ino==lockpin['st_ino']:return
        forbidden('write-open:'+str(actual))
class SourceGuard(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.',1)[0] in ('pymobiledevice3','pmd_pytcp','pmd_pytcpstack','pytcp','tidevice','pyidevice'):forbidden('SDK-import:'+fullname)
        spec=importlib.machinery.PathFinder.find_spec(fullname,path)
        if spec is None or not spec.origin or spec.origin in ('built-in','frozen'):return None
        origin=Path(spec.origin).resolve()
        if 'overte-ios-remotexpc' in str(origin) or any(part in ('pymobiledevice3','pmd_pytcp','pmd_pytcpstack','pytcp') for part in origin.parts):forbidden('SDK-path:'+fullname)
        if origin.is_relative_to(REPO):
            key=str(origin.relative_to(REPO));wanted=expected.get(key)
            if '/self_tests/' in key:forbidden('fixture-import:'+fullname)
            assert wanted is not None and hashlib.sha256(origin.read_bytes()).hexdigest()==wanted['sha256'],('Unpinned source',fullname,key)
            imports[fullname]=key
        return None
assert not any(n.split('.',1)[0] in ('ios','adapters','feature_journeys','pymobiledevice3') for n in sys.modules)
ordered=[str(REPO/p) for p in ('tests/device','tests/device/self_tests','tests/device/ios/self_tests')];rest=[]
for item in sys.path:
    path=Path(item or os.getcwd()).resolve()
    if path==REPO or REPO in path.parents:continue
    if str(path) not in rest:rest.append(str(path))
sys.path[:]=ordered+rest
for name,relative in {'ios':'tests/device/ios','adapters':'tests/device/adapters','feature_journeys':'tests/device/feature_journeys'}.items():
    spec=importlib.machinery.PathFinder._get_spec(name,list(sys.path));assert spec is not None and list(spec.submodule_search_locations or ())==[str(REPO/relative)]
sys.addaudithook(audit);sys.meta_path.insert(0,SourceGuard())
def terminate(signum,frame):
    global interrupted
    interrupted=dict(signal=signum,stack=traceback.format_stack(frame));save(OUTPUT/'signal-cutpoint.json',interrupted)
    raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,terminate)
try:
    from adapters.normal_feature_state import PrivateFeatureState,context
    from adapters.original_file_reads import readonly,collect
    from adapters.script_feature.lock import ScriptSourceLock
    from ios.adapters.tablet_web_aggregate_root import source_owner,TabletWebAggregateRoot
    from ios.adapters.tablet_web_record_cache import TabletRecordCache,scope as record_scope
    from ios.adapters.tablet_web_api_entry import installed_entry,BUDGETS
    assert BUDGETS['feature.tablet-web.observe']==value['innerOriginalAPISeconds']==60
    assert context(scope['binding'])==scope['binding'] and scope['pid']==42 and scope['binding']['processIdentity']=='42'
    # Original pre-observer controller metadata, not a Root4/child header donor.
    metadata=json.loads((root/'paired-input-metadata.json').read_text())
    assert dict(metadata['scope'],processIdentity='42')==scope['binding']
    selected=json.loads((root/'sample-root-normal-app-input.json').read_text())
    feature=json.loads((root/'tabletweb-feature-'+scope['run']+'-primary.json').read_text())
    assert selected['binding']==scope['binding'] and selected['featureRun']==scope['run']
    assert selected['fixtureUrl']==scope['fixtureURL']==feature['origins']['primary']+'/feature-fixture/v1/runs/'+scope['run']+'/'
    lock=ScriptSourceLock(lockpath)
    def live(*_args,**_kwargs):forbidden('live guard/epoch/native/status callback')
    def replay(_self,_selector,_operation,_arguments):
        global owner,frames
        mark('before-supported-historical-Root4-constructor')
        owner=source_owner(root,scope['binding'],scope['run'],scope['role'],scope['fixtureURL'],scope['pid'],lock,live,
            epoch_ms=live,monotonic=time.monotonic,historical=True)
        assert type(owner) is TabletWebAggregateRoot and owner.historical
        mark('supported-historical-Root4-constructor-returned')
        frames=owner.history();mark('same-scope-history-returned')
        return len(frames)
    # Reuse the original API60 clock/decorator, without claiming InstalledAdapter
    # routing or creating a live API source. No clock limit is manufactured.
    call=installed_entry(replay)
    mark('actual-passive-imports-complete');profiler.enable();profiling_started=True
    with lock.held(),readonly(),collect() as reads,record_scope(TabletRecordCache()):
        result=call(None,'original-retained-root','feature.tablet-web.observe',{})
    mark('original-API60-and-existing-lock-left')
except BaseException as exc:
    error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc());print(error['traceback'],file=sys.stderr,flush=True)
finally:
    profiler.disable();profiler.dump_stats(str(OUTPUT/'raw.pstats'))
    names={}
    for entry in profiler.getstats():
        code=entry.code
        if type(code) is CodeType:names[(code.co_filename,code.co_firstlineno,code.co_name)]=code.co_qualname
    stat_rows=pstats.Stats(profiler).stats if profiler.getstats() else {};rows=[]
    def label(key):
        filename,line,name=key;path=Path(filename)
        if not path.is_absolute() or not path.is_relative_to(REPO/'tests/device'):return None
        return dict(module=str(path.relative_to(REPO)),line=line,qualifiedName=names.get(key,name))
    for key,(primitive,calls,own,cumulative,callers) in stat_rows.items():
        item=label(key)
        if item is None:continue
        source=[]
        for caller,cost in callers.items():
            named=label(caller)
            if named is not None:source.append(dict(**named,cost=list(cost) if type(cost) is tuple else cost))
        source.sort(key=lambda row:row['cost'][3] if type(row['cost']) is list and len(row['cost'])>3 else 0,reverse=True)
        rows.append(dict(**item,primitiveCalls=primitive,calls=calls,selfSeconds=own,cumulativeSeconds=cumulative,callers=source[:8]))
    focused=[row for row in rows if row['qualifiedName'] in ('aggregate_epoch','AvatarRecordCache._read','TabletAggregateChild._bound','TabletWebAggregateRoot._parent_guard')]
    save(OUTPUT/'profile-summary.json',dict(topSelf=sorted(rows,key=lambda row:row['selfSeconds'],reverse=True)[:20],topCumulative=sorted(rows,key=lambda row:row['cumulativeSeconds'],reverse=True)[:20],focusedActualFunctions=focused,profileOverheadQualified=False))
    threads=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in BASE_THREADS and t.is_alive()]
    save(OUTPUT/'diagnostic-result.json',dict(error=error,interrupted=interrupted,marks=marks,forbiddenEffects=effects,newThreads=threads,imports=imports,
        actualOriginalReadPathCount=len(reads),returnedFrameCount=None if frames is None else len(frames),historicalOwnerReturned=owner is not None,
        originalAPI60ClockUsed=True,completeInstalledAPI60Closure=False,profilingEnabled=profiling_started,traceEnabled=False,
        elapsedSeconds=time.monotonic()-started,wholeQualified=False,nativeExecuted=False,sdkExecuted=False,inputExecuted=False,performanceQualified=False))
    assert expected=={name:pin(REPO/name) for name in expected},'Pinned Source/helper changed'
if error or effects or threads:raise SystemExit(1)
