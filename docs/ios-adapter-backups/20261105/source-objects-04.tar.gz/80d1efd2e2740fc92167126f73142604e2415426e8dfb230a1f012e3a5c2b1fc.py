"""One capture's immutable marker qualification, never a current-result cache.

Both complete frozen-marker reads precede native acquisition. Exact pure-reader
policy, marker object/state/components, marker-only filenames and original file
identities remain fixed through the saved-record/PNG handoff. Ordinary archive
methods stay independent; unsupported and empty test graphs take the cold path.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import os
from types import MethodType,SimpleNamespace
from adapters.native_clock_join import digest
from adapters.native_feature_observation import need
from adapters.native_script_files import OwnedScriptFiles
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import collect,scope
from adapters.original_frame_store import OriginalFrameStore
from adapters.original_marker_scope import OriginalMarkerScope,_components
from adapters.owned_vulkan_world_frame import VulkanWorldFrameOwner
from adapters.script_feature.history import canonical,same
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters import avatar_images as images
from ios.adapters.avatar_record_cache import AvatarRecordCache
from ios.adapters.avatar_sample_return_literal import AvatarSampleReturnLiteral
from ios.adapters import emote_callback_live_records as tokens


class AvatarSampleReturnProof:
    @staticmethod
    def reader_roots(owner,components):
        # Full class tokens bind namespaces/bases and every method identity.
        # Only these actually used immutable methods recursively bind globals;
        # live SDK/input methods on the same classes are never traversed.
        roots=[owner.Marker,OriginalMarkerScope,OriginalFrameStore,VulkanWorldFrameOwner,
            PrivateFeatureState,ScriptSourceLock,AvatarRecordCache,type(owner),
            _components,OwnedScriptFiles.__init__,images.compose,images.image_observation,images.original_pixels]
        methods=((owner.Marker,('archive','decode','envelope','validate_frame','ui_absent','bind_image_world')),
            (OriginalMarkerScope,('archive','decode','envelope','validate_frame','ui_absent','bind_image_world')),
            (OriginalFrameStore,('__init__','key','now','bound','original','path','file','read','expand',
                'manifest_reference','manifest_path','manifest','restore')),
            (PrivateFeatureState,('__init__','_parent','read')),(ScriptSourceLock,('assert_held','held')),
            (VulkanWorldFrameOwner,('archive_original','__init__','_load','_read','_file','archive')),
            (type(owner),('identity','read_record','validate_record','partial','follow','archive')),
            (components.Files,('__init__','owned')),(components.Originals,('__init__',)),
            (AvatarRecordCache,('signatures',)))
        for cls,names in methods:
            for name in names:
                value=getattr(cls,name)
                roots.append(value.__func__ if type(value) is MethodType else value)
        roots.extend(vars(components).values());return roots

    @staticmethod
    def method_bindings(owner,names):
        rows=[]
        for name in names:
            method=getattr(owner,name)
            need(type(method) is MethodType and method.__self__ is owner)
            rows.append((name,method.__func__))
        return tuple(rows)

    def __init__(self,owner):
        owner.lock.assert_held();need(not owner.historical)
        self.owner,self.lock,self.root=owner,owner.lock,owner.root
        self.binding,self.run,self.role=deepcopy(owner.binding),owner.run,owner.role
        self.value=deepcopy(owner.state['markerOwner']);self.policy=deepcopy(owner.policy)
        self.marker=None;self.paths=set();self.signatures=None;self.interpretation=None
        # Explicit unsupported/marker-only models retain ordinary archive().
        if type(owner.Marker) is not type or not issubclass(owner.Marker,OriginalMarkerScope) or owner.Marker.PROFILE!='avatar':return
        components=_components('avatar')
        literal=AvatarSampleReturnLiteral(self.reader_roots(owner,components))
        if literal.policy is None:return
        self.interpretation=literal
        before=self.namespace()
        def decode():
            return owner.Marker.archive(self.value,root=self.root,binding=self.binding,run=self.run,
                role=self.role,lock=self.lock,require_ready=True)
        # scope activates the existing deterministic optional earlier-manifest
        # prefix reads; collect observes isolated nested reader memberships too.
        with scope(fresh=True),collect() as first:marker=decode()
        if not first:return
        signatures=AvatarRecordCache.signatures(first)
        need(literal.literal() and self.namespace()==before)
        with scope(fresh=True),collect() as second:confirmed=decode()
        need(first==second and AvatarRecordCache.signatures(second)==signatures
            and same(marker.state,confirmed.state) and same(marker.frames,confirmed.frames)
            and literal.literal() and self.namespace()==before)
        self.marker,self.paths,self.signatures=confirmed,set(second),signatures
        self.marker_object=confirmed
        self.marker_state,self.marker_frames=confirmed.state,confirmed.frames
        self.marker_bytes=canonical(dict(state=confirmed.state,frames=confirmed.frames))
        self.components=confirmed.components;need(type(self.components) is SimpleNamespace)
        self.component_references=[]
        self.component_policy=tuple((name,tokens._token(value,self.component_references,set()))
            for name,value in sorted(vars(self.components).items()))
        self.originals,self.files=confirmed.originals,confirmed.files
        self.marker_header=self.header(confirmed)
        self.namespace_rows=before;self.owner_type,self.marker_type=type(owner),type(confirmed)
        self.marker_methods=self.method_bindings(confirmed,('bind_image_world',))
        self.owner_methods=self.method_bindings(owner,('read_record','validate_record','partial','follow','archive'))
        self.scope=owner.scope
        self.check()

    @property
    def available(self):return self.marker is not None

    def namespace(self):
        # These immutable files alone belong to the frozen Avatar marker.
        # Samples, GPU originals and live metadata may legitimately be born.
        prefixes=tuple('avatar-'+kind+'-inputs-'+self.run+'-'+self.role+'-' for kind in ('frame','index'))
        PrivateFeatureState(self.root/'avatar-return-marker-namespace-boundary')._parent()
        with os.scandir(self.root) as entries:names=sorted(entry.name for entry in entries if entry.name.startswith(prefixes))
        need(len(names)<=2048)
        paths={self.root/name for name in names}
        return {} if not paths else AvatarRecordCache.signatures(paths)

    @staticmethod
    def header(marker):
        return canonical(dict(root=str(marker.root),binding=marker.binding,run=marker.run,role=marker.role,pid=marker.pid,
            fixtureUrl=marker.fixture_url,ticket=marker.ticket,originalRoot=str(marker.originals.root),
            originalBinding=marker.originals.binding,originalRun=marker.originals.run,originalRole=marker.originals.role,
            namespace=marker.originals.namespace,schemaPrefix=marker.originals.schema_prefix,kind=marker.originals.kind))

    def check(self):
        need(self.available and self.owner.lock is self.lock and self.owner.root==self.root
            and type(self.owner) is self.owner_type and self.owner.run==self.run and self.owner.role==self.role
            and same(self.owner.binding,self.binding) and same(self.owner.state['markerOwner'],self.value)
            and same(self.owner.policy,self.policy) and self.owner.scope is self.scope)
        self.lock.assert_held();marker=self.marker
        need(marker is self.marker_object and type(marker) is self.marker_type and marker.lock is self.lock and marker.state is self.marker_state
            and marker.frames is self.marker_frames and marker.components is self.components
            and marker.originals is self.originals and marker.files is self.files
            and type(marker.state) is dict and type(marker.frames) is list
            and canonical(dict(state=marker.state,frames=marker.frames))==self.marker_bytes
            and self.header(marker)==self.marker_header and same(self.scope.state,marker.state)
            and self.method_bindings(marker,('bind_image_world',))==self.marker_methods
            and self.method_bindings(self.owner,('read_record','validate_record','partial','follow','archive'))==self.owner_methods)
        references=[]
        need(tuple((name,tokens._token(value,references,set())) for name,value in sorted(vars(self.components).items()))==self.component_policy
            and self.interpretation.literal() and self.namespace()==self.namespace_rows
            and AvatarRecordCache.signatures(self.paths)==self.signatures)

    @staticmethod
    def dependencies(paths):
        need(type(paths) is set)
        return {} if not paths else AvatarRecordCache.signatures(paths)

    def verify_saved(self,row,record_digest,raw,dependencies):
        """Reopen exact saved bytes, all prior prefixes and original PNG chunks."""
        self.check();owner=self.owner
        record=owner.read_record(row,historical=True)
        need(record['status']=='observed' and digest(record)==record_digest and record['markerSha256']==digest(self.value))
        frame=record['partial']
        owner.follow(frame,phase_before=frame['phaseBefore'],before_index=record['index'])
        self.marker.bind_image_world(frame['worldBefore']);self.marker.bind_image_world(frame['worldAfter'])
        original=VulkanWorldFrameOwner.archive_original(record['owner'],self.root,self.binding,self.run,self.role,0,record['requestId'],self.lock)
        need(type(raw) is bytes and original==raw)
        need(type(dependencies) is dict and self.dependencies(set(dependencies))==dependencies)
        self.check()
