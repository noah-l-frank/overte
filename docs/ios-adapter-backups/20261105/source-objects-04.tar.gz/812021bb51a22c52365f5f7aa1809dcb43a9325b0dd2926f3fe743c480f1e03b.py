"""Actual fresh_touch_scope +host TouchLease over explicit SDK/WDA models.

This models the PID race only. Actual WDA session-route admission remains a
separate required source hook; this is not endpoint/auth/device qualification.
"""
from __future__ import annotations
import ast
import asyncio
import hashlib
import json
import os
from pathlib import Path
import unittest


class PostWdaPIDModels(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        source_map=Path(os.environ['LIFECYCLE_POST_WDA_PID_SOURCE_MAP']);raw=source_map.read_bytes()
        if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_POST_WDA_PID_SOURCE_MAP_SHA256']:
            raise RuntimeError('Exact source map unavailable')
        self.map=json.loads(raw)
        for row in self.map.values():
            if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:
                raise RuntimeError('Actual source changed')
        from ios.self_tests import test_ios_touch_lease as fixture
        from ios.adapters import touch_lease
        self.assertEqual(Path(fixture.__file__).resolve(),Path(self.map['fixture']['path']))
        self.assertEqual(Path(touch_lease.__file__).resolve(),Path(self.map['lease']['path']))
        self.fixture=fixture;self.f=fixture.TouchLeaseTests();self.f.setUp()
        for function,args,kwargs in self.f._cleanups:self.addCleanup(function,*args,**kwargs)
        self.f._cleanups.clear()
        tree=ast.parse(Path(self.map['keeper']['path']).read_text())
        owner=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='OriginalKeeperOperations')
        actual=next(n for n in owner.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='fresh_touch_scope')
        class Model:
            def __init__(_self):
                _self.rsd=object();_self.pid=int(self.f.binding['processIdentity']);_self.restart=False
                _self.session={'sessionId':self.f.binding['sessionId'],'archiveBundleId':'org.example.overte'}
                _self.process_calls=0;_self.wda_calls=0;_self.events=[]
            def scope(_self,session):
                self.assertEqual(session,_self.session['sessionId']);return _self.rsd
            async def process(_self,bundle):
                self.assertEqual(bundle,_self.session['archiveBundleId']);_self.process_calls+=1
                _self.events.append(('actual-modeled-pid-pair',_self.pid));return {'bundlePids':[_self.pid]*2}
        self.model=Model()
        class ModeledWDA:
            def __init__(_self,rsd,*,port,timeout):
                self.assertIs(rsd,self.model.rsd);self.assertEqual(port,8100);self.assertEqual(timeout,2.0)
            async def _request_json(_self,method,path,payload):
                # Explicit protocol model: do not qualify the unbound WDA
                # endpoint. R3 original-session route is separately required.
                self.assertEqual(method,'POST');self.assertEqual(payload,{'bundleId':'org.example.overte'})
                self.model.wda_calls+=1;self.model.events.append(('wda-request',path))
                if self.model.restart:self.model.pid+=1
                await asyncio.sleep(0)
                return {'value':4}
        class ModelError(RuntimeError):pass
        self.namespace={'WdaServiceClient':ModeledWDA,'LaunchError':ModelError}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[actual],type_ignores=[])),'<pinned-actual-fresh-touch-scope>','exec'),self.namespace)
        self.f.check=lambda:self.namespace['fresh_touch_scope'](self.model,self.f.binding)
        self.f.owner=self.f.make()
    async def asyncTearDown(self):await self.f.asyncTearDown()
    async def test_restart_inside_original_wda_await_with_same_rsd_and_session_refuses_before_down(self):
        self.model.restart=True;original_rsd=self.model.rsd;original_session=self.model.session['sessionId']
        with self.assertRaises(RuntimeError):await self.f.begin()
        await self.f.owner.worker
        self.assertIs(self.model.rsd,original_rsd);self.assertEqual(self.model.session['sessionId'],original_session)
        self.assertEqual(2,self.model.process_calls);self.assertEqual(1,self.model.wda_calls)
        self.assertEqual([],self.f.states());self.assertEqual([],self.f.factories)
    async def test_stable_original_pid_before_and_after_wda_allows_existing_once_down_up_model(self):
        await self.f.begin();self.assertEqual(8,self.model.process_calls);self.assertEqual(4,self.model.wda_calls)
        self.assertEqual([0xC2],self.f.states());await self.f.owner.release()
        self.assertEqual([0xC2,0x02],self.f.states());self.assertEqual(1,len(self.f.factories))
