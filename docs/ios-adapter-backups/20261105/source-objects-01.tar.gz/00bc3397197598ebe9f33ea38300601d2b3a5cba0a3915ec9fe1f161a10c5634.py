"""Actual supported policy graph profiling only; NO Publisher POST/qualification."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,json,os,time
from pathlib import Path
from ios.adapters import emote_callback_live_records as tokens
from test_lifecycle_publication_original_read_phase_models import LifecyclePublicationOriginalReadPhaseModels
from lifecycle_policy_comparison_scaffold import Comparisons


class LifecyclePolicyMemberCostProfileModels(LifecyclePublicationOriginalReadPhaseModels):
    async def test_passive_policy_member_tag_cost_and_scaffold_equivalence_without_publisher_post(self):
        await self.primary_api();await self.actor_api(publish=False)
        owner=self.observer;before=self.counts();journal=self.phase_server.journal.snapshot(self.run)
        prefix='phase-publication-lifecycle-input-'+self.run+'-actor'
        self.assertEqual([],journal['entries']);self.assertEqual([],list(owner.store.path.parent.glob(prefix+'*.json')))
        repo=Path.cwd().resolve(strict=True);self.assertEqual('overte-ios-feature-adapters-resume-20261026',repo.name)
        output=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT'])/'passive-policy-member-cost-profile.json'
        report=dict(lifecyclePolicyMemberCostProfileVersion=1,diagnosticOnly=True,freshPublishQualified=False,
            actualPublisherPOSTs=0,productOrTokenizerChanged=False,comparisonScaffoldAppliedToSUT=False,
            classifierBindingAssumption='Scaffold only assumes unchanged stdlib classifiers; not production equivalence claim',
            scans=[],initialSupported=False,policyAdmitted=False,completed=False)
        def save():
            self.assertTrue(output.resolve().is_relative_to(repo));output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');output.chmod(0o600)
        def profile():
            policy=owner._publication_parser_policy;report['initialSupported']=policy.members is not None
            report['policyAdmitted']=policy.admitted();save()
            self.assertTrue(report['initialSupported']);self.assertTrue(report['policyAdmitted'])
            compiler=Comparisons();started=time.perf_counter();prepared=[];held=[]
            for name,module,members in policy.members:
                for member,expected in members:prepared.append((name,module,member,expected,compiler.compile(expected)))
            report['comparisonInstructionPreparationSeconds']=time.perf_counter()-started
            report['immutableInstructionCount']=len(compiler.instructions);save()
            for scan in range(2):
                row=dict(scan=scan+1,members=[],tags={},literalSeconds=0.,comparisonSeconds=0.,allOutcomesEqual=True,allReferenceOrdersEqual=True)
                report['scans'].append(row);save()
                for index,(name,module,member,expected,check)in enumerate(prepared,1):
                    value=vars(module)[member];refs=[];started=time.perf_counter()
                    actual=tokens._token(value,refs,set());literal_seconds=time.perf_counter()-started
                    other=[];started=time.perf_counter();equal=check(value,other,set());comparison_seconds=time.perf_counter()-started
                    expected_equal=actual==expected;refs_equal=[id(v)for v in refs]==[id(v)for v in other]
                    held.extend(refs);held.extend(other)
                    item=dict(module=name,member=member,tag=actual[0],type=[type(value).__module__,type(value).__qualname__],
                        identity=id(value),literalSeconds=literal_seconds,comparisonSeconds=comparison_seconds,
                        outcomeEqual=(equal==expected_equal),referenceOrderEqual=refs_equal)
                    row['members'].append(item);row['literalSeconds']+=literal_seconds;row['comparisonSeconds']+=comparison_seconds
                    row['allOutcomesEqual']=row['allOutcomesEqual']and item['outcomeEqual'];row['allReferenceOrdersEqual']=row['allReferenceOrdersEqual']and refs_equal
                    tag=row['tags'].setdefault(item['tag'],dict(members=0,literalSeconds=0.,comparisonSeconds=0.));tag['members']+=1;tag['literalSeconds']+=literal_seconds;tag['comparisonSeconds']+=comparison_seconds
                    if index%128==0:save()
                    self.assertEqual(expected_equal,equal,(name,member));self.assertTrue(refs_equal,(name,member));self.assertTrue(expected_equal,(name,member))
                row['topLiteralMembers']=sorted(row['members'],key=lambda v:v['literalSeconds'],reverse=True)[:40]
                row['topComparisonMembers']=sorted(row['members'],key=lambda v:v['comparisonSeconds'],reverse=True)[:40]
                row['uniqueTopLevelIdentities']=len({v['identity']for v in row['members']});save()
            report['heldActualReferences']=len(held);report['policyAdmittedAfter']=policy.admitted();save()
        save();await asyncio.to_thread(profile)
        self.assertEqual(before,self.counts());self.assertEqual(journal['entries'],self.phase_server.journal.snapshot(self.run)['entries'])
        self.assertEqual([],list(owner.store.path.parent.glob(prefix+'*.json')))
        report.update(completed=True,noPublisherWALOrPOST=True,countsUnchanged=True);save()
