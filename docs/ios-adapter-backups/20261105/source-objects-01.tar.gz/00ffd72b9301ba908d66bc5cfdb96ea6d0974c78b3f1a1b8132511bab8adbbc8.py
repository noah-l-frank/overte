"""Actual state-bound executable observation; no process absence authority.

The qualified five-field kernel module stays byte-identical. A real matching
owned zombie can supply no positive executable, never a quiet/absent verdict.
"""
from pathlib import Path
from copy import deepcopy
import traceback
import moving_owned_identity as kernel

_LIVE_STATES=frozenset(('R','S','D','T','t','I','W','K','P'))

class NoPositiveExecutable:
    __slots__=('record',)
    def __init__(self,record):
        assert record['positiveExecutableEstablished']is False and record['processAbsenceEstablished']is False
        self.record=deepcopy(record)

def stat_original(pid):
    assert type(pid)is int and pid>0
    try:
        with Path('/proc',str(pid),'stat').open('r')as stream:raw=stream.read(65537)
    except(FileNotFoundError,ProcessLookupError):return None
    assert len(raw)<=65536 and int(raw[:raw.index('(')].strip())==pid
    fields=raw.rsplit(') ',1)[1].split();state=fields[0]
    identity=dict(pid=pid,parentPid=int(fields[1]),pgid=int(fields[2]),sid=int(fields[3]),startTicks=int(fields[19]))
    kernel._identity(identity)
    assert len(state)==1 and state in _LIVE_STATES|{'Z'},'Unknown proc state remains an error'
    return dict(identity=identity,state=state,rawStat=raw)

def observe_owned_executable(expected,bound,*,events):
    assert type(events)is list
    record=dict(expected=deepcopy(expected),bound=deepcopy(bound),before=None,after=None,
        outcome='started',positiveExecutableEstablished=False,processAbsenceEstablished=False,originalError=None,originalKernelError=None)
    events.append(record)
    def no_positive(reason):
        record['outcome']='NoPositiveExecutable';record['reason']=reason
        return NoPositiveExecutable(record)
    try:
        kernel._identity(expected);kernel._identity(bound)
        assert bound['pid']==bound['pgid']==bound['sid']
        assert expected['sid']==bound['pid']or expected['pgid']==bound['pid'],'Foreign identity before any executable read'
        before=stat_original(expected['pid']);record['before']=before
        if before is None:
            record['after']=stat_original(expected['pid'])
            assert record['after']is None,'PID reappeared after missing pre-stat'
            return no_positive('no-stat-before-or-after-no-absence-authority')
        assert before['identity']==expected,'Identity changed before original kernel call'
        try:actual=kernel.owned_executable(expected,bound)
        except(FileNotFoundError,ProcessLookupError)as original:
            record['originalError']=dict(type=type(original).__module__+'.'+type(original).__qualname__,errno=original.errno,
                filename=original.filename,traceback=traceback.format_exc())
            record['originalKernelError']=deepcopy(record['originalError'])
            after=stat_original(expected['pid']);record['after']=after
            if after is None:return no_positive('original-executable-unavailable-then-no-stat-no-absence-authority')
            assert after['identity']==expected,'Identity changed across original executable failure'
            if after['state']=='Z':return no_positive('actual-same-owned-identity-stat-Z-no-executable')
            raise # Live unavailable executable is the SAME original error.
        after=stat_original(expected['pid']);record['after']=after
        if after is None:return no_positive('post-stat-gone-no-absence-authority')
        assert after['identity']==expected,'Identity changed after original kernel observation'
        if after['state']=='Z':return no_positive('actual-owned-stat-Z-after-kernel-no-current-positive')
        assert actual is not None,'Original kernel had no executable but current identity is live; unknown remains error'
        assert actual['identity']==expected
        record['outcome']='PositiveExecutable';record['positiveExecutableEstablished']=True
        return actual
    except BaseException as original:
        record['outcome']='ObservationError'
        record['originalError']=dict(type=type(original).__module__+'.'+type(original).__qualname__,
            errno=getattr(original,'errno',None),filename=getattr(original,'filename',None),traceback=traceback.format_exc())
        raise

def require_actual_process_observation_utility(plan):
    # No future Root qualification schema is guessed or treated as existing.
    assert plan.get('processObservationUtilityRootProof')is None
    raise RuntimeError('C11 state-bound process observation is UNRUN; a real separately reviewed Root utility proof is required')
