from pathlib import Path
import ast,difflib,hashlib,json,textwrap
P=Path(__file__).resolve().parent;R=P.parents[1];H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
rel='tests/device/ios/adapters/lifecycle_world_hold_runtime.py';base=R/rel;s=base.read_text();s=s.replace('No canonical RPC supplies a retained HID context yet. A caller must already\nown that actual factory; absent transport cannot be reconstructed or installed.','Default profile retains an explicitly owned HID factory. Optional child profile\nroutes its original worker through existing operations and typed source births.\nProduction admission stays closed; JSON cannot supply a HID/SDK owner.',1);tree=ast.parse(s);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='IOSLifecycleWorldHoldRuntime');method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_selected_motion_original_result');lines=s.splitlines(True);block=''.join(lines[method.lineno-1:method.end_lineno]);start=block.index('        import re\n');end=block.index('        transfer_current()\n');pure=textwrap.dedent(block[start:end]);pure=pure.replace("binding=source['binding']\n",'').replace("result['ownerInstance']",'owner');pure='def selected_motion_frame_original(frame,binding,run,owner,selected_query):\n'+textwrap.indent(pure,'    ')+'    return frame\n\n\n'
wrapper='''    def _selected_motion_original_result(self,source,run,selected_query,result,reference,frame,transfer_current):
        selected_motion_frame_original(frame,source['binding'],run,result['ownerInstance'],selected_query)
        transfer_current()
        return dict(originalKeeperNativeAcquisitionVersion=3,ownerInstance=result['ownerInstance'],binding=deepcopy(source['binding']),runId=run,
            reference=deepcopy(reference),originalFrame=deepcopy(frame),nativeAcquisitionBound=False,installedCandidateBound=False,
            nativeMotionGuardAvailable=False,nativeTouchSupport=False,resourceRetirementEstablished=False)
''';s=s.replace(block,wrapper,1);marker='class IOSLifecycleWorldHoldRuntime:';s=s.replace(marker,pure+(P/'child-frame.fragment.py').read_text()+(P/'retained-client.fragment.py').read_text()+'\n\n'+(P/'connection.fragment.py').read_text()+'\n\n'+marker,1)
s=s.replace('    def child(self,selector,editors,attempt,session_factory):','    def child(self,selector,editors,attempt,session_factory,*,original_child=False):',1)
old="        need(type(editors) is LifecycleEditors and type(attempt) is LifecycleWorldAttempt and callable(session_factory))";new="""        need(type(original_child) is bool and type(editors) is LifecycleEditors and type(attempt) is LifecycleWorldAttempt
            and (original_child and session_factory is None or not original_child and callable(session_factory)))""";assert old in s;s=s.replace(old,new)
old="        owner=LifecycleWorldHold(PrivateFeatureState(root/'ios-lifecycle-world-hold.json'),attempt,session_factory)";new="""        connection=_OriginalKeeperWorldConnection(self,selector,source,editors.run) if original_child else None
        owner=LifecycleWorldHold(PrivateFeatureState(root/'ios-lifecycle-world-hold.json'),attempt,session_factory,original_child=connection)""";assert old in s;s=s.replace(old,new)
out=P/'candidate/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s);ast.parse(s);rows.append(dict(path=rel,baseSHA256=H(base),candidateSHA256=H(out)))
rel='tests/device/ios/adapters/lifecycle_world_hold.py';base=R/rel;s=base.read_text();s=s.replace('    def __init__(self,store,attempt,session_factory):','    def __init__(self,store,attempt,session_factory,*,original_child=None):',1)
old='        need(isinstance(store,PrivateFeatureState) and type(attempt) is LifecycleWorldAttempt and callable(session_factory))';new="""        from ios.adapters.lifecycle_world_hold_runtime import _OriginalKeeperWorldConnection
        need(isinstance(store,PrivateFeatureState) and type(attempt) is LifecycleWorldAttempt
            and (original_child is None and callable(session_factory)
                or type(original_child) is _OriginalKeeperWorldConnection and session_factory is None))
        self.version=1 if original_child is None else 2
        self.original_child=self._original_child=original_child""";assert old in s;s=s.replace(old,new)
old="        self.history.check();need(self.sources.source['check']() is not False and same(self.store.read(),self.previous));return True";new="""        self.history.check();need(self.sources.source['check']() is not False and same(self.store.read(),self.previous))
        if self.version==2:need(self.original_child is self._original_child and self.original_child.current() is not False)
        return True""";assert old in s;s=s.replace(old,new)
old="            self.storage if live else lambda *_:need(False),namespace='ios-lifecycle-world-hold-proof',schema_prefix='iosLifecycleWorldHoldProof')";new="""            self.storage if live else lambda *_:need(False),
            namespace='ios-lifecycle-child-hold-proof' if self.version==2 else 'ios-lifecycle-world-hold-proof',
            schema_prefix='iosLifecycleWorldHoldChildProof' if self.version==2 else 'iosLifecycleWorldHoldProof')""";assert old in s;s=s.replace(old,new)
old="        exact(frame,{'originals','clockJoin'})";new="""        exact(frame,{'originals','clockJoin'}|({'originalChild'} if self.version==2 else set()))
        if self.version==2:
            from ios.adapters.lifecycle_world_hold_runtime import original_child_world_frame
            child=original_child_world_frame(frame['originalChild'],self.binding,self.run,before=before)
            need(frame['originals']==child['originals'] and frame['clockJoin']==child['clockJoin'])""";assert s.count(old)==1;s=s.replace(old,new)
old="    def packet(self,index):return self.source_frame(self.frame(index),before=index==1)";new="""    def packet(self,index):
        frame=self.frame(index);packet=self.source_frame(frame,before=index==1)
        if self.version==2 and index>1:
            child=frame['originalChild'];first=self.frame(1)['originalChild']
            need(child['ownerInstance']==first['ownerInstance'] and child['originalFrame']['ordinal']==index-1)
            previous=child['originalFrame']['previousReference']
            need(previous is None if index==2 else previous==self.frame(index-1)['originalChild']['reference'])
        return packet""";assert old in s;s=s.replace(old,new)
s=s.replace('dict(iosLifecycleWorldHoldVersion=VERSION,binding=', 'dict(iosLifecycleWorldHoldVersion=self.version,binding=',1)
s=s.replace("value['iosLifecycleWorldHoldVersion']==VERSION", "value['iosLifecycleWorldHoldVersion']==self.version",1)
old='    def capture(self,before=False):\n        need(len(self.state[\'frames\'])<32)';new="    def capture(self,before=False):\n        if self.version==2:return self._capture_original_child(before)\n        need(len(self.state['frames'])<32)";assert old in s;s=s.replace(old,new)
marker='    def prepared(self):';s=s.replace(marker,(P/'owner-child-methods.fragment.py').read_text()+marker,1)
old='    def lease_owner(self):\n        if self.lease is None:';new="""    def lease_owner(self):
        if self.version==2:
            need(self.original_child is self._original_child)
            if self.lease is not None:
                need(self.lease is self.original_child.lease);return self.lease
            if self.original_child.lease is None:
                self.prepared();self.original_child.bind_preparation(self.frame(1),self.state['seconds'])
            self.lease=self.original_child.lease;return self.lease
        if self.lease is None:""";assert old in s;s=s.replace(old,new)
old="            if not self.state['frames']:self.capture(True)";new="""            if not self.state['frames']:
                captured=self.capture(True)
                if inspect.isawaitable(captured):await captured""";assert old in s;s=s.replace(old,new)
old="        need(0<=self.epoch_ms()-join['hostBeforeEpochMs']<1500 and 0<=self.monotonic()-join['hostBeforeMonotonic']<1.5)\n        fresh(frame['originals']['world']['clockAfter']['epochMs'],self.reader.clock_ms())";new="""        if self.version==1:
            need(0<=self.epoch_ms()-join['hostBeforeEpochMs']<1500 and 0<=self.monotonic()-join['hostBeforeMonotonic']<1.5)
            fresh(frame['originals']['world']['clockAfter']['epochMs'],self.reader.clock_ms())
        # Child profile performs actual new beforeDown+beforeMove cuts in its
        # original worker. The stored preparation is historical intent only.""";assert s.count(old)==1;s=s.replace(old,new)
old="    def observe(self):\n        self.bound();need(self.state['phase'] in ('issued','held'))";new="    def observe(self):\n        if self.version==2:return self._observe_original_child()\n        self.bound();need(self.state['phase'] in ('issued','held'))";assert old in s;s=s.replace(old,new)
old="        lease=self.lease_owner();status=await lease.release()";new="""        lease=self.lease_owner()
        if self.version==2 and not lease._issued:
            await lease.settle()
            need(False) # Original pre-Down cleanup returned; no native release proof exists.
        status=await lease.release()""";assert old in s;s=s.replace(old,new)
old="            self.state['released']=self.capture();self.state['phase']='released';self.save()";new="""            captured=self.capture()
            if inspect.isawaitable(captured):captured=await captured
            self.state['released']=captured;self.state['phase']='released';self.save()""";assert old in s;s=s.replace(old,new)
old="    def sample_quiet(self):\n        self.bound();need(self.state['released'] is not None)";new="    def sample_quiet(self):\n        if self.version==2:return self._quiet_original_child()\n        self.bound();need(self.state['released'] is not None)";assert old in s;s=s.replace(old,new)
out=P/'candidate/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s);ast.parse(s);rows.append(dict(path=rel,baseSHA256=H(base),candidateSHA256=H(out)))
(P/'source2-checkpoint.diff').write_text(''.join(''.join(difflib.unified_diff((R/row['path']).read_text().splitlines(True),(P/'candidate/repo'/row['path']).read_text().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path'])) for row in rows))
(P/'checkpoint.json').write_text(json.dumps(dict(status='PRIVATE_ACTIVE_SOURCE_DRAFT_UNRUN_NOT_FROZEN',files=rows,remaining=['actual normal firstattempt/editorprefix source-DI fixture with physical selectedIPA BEFORE prefix/Sourcebirth','new Begin2 packet separate review/qualification; cannot use legacyBegin1','sameSource actualclient+NativeClock+Scene continuity before first retained capture','own1 Holdversion2 schema and oldv1/newmeaningfulmodels','preparation savedACK-loss mustremain non-adoptable; scoped abort gives no releasedproof'],gateFalse=True,targetImports=False,testsRun=False),indent=2)+'\n');print(json.dumps(rows,indent=2))
