from pathlib import Path
import cProfile,pstats,time,json,os,io
from unittest.mock import patch
from contextlib import ExitStack
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope
from adapters.original_frame_store import OriginalFrameStore
from adapters.native_clock_join import digest
from adapters.script_feature.history import unpack
from ios.adapters.avatar_postlogout_reads import IOSAvatarPostLogoutReads
from ios.adapters.emote_archive_lock import ArchiveSourceLock
from ios.adapters.emote_original_lease import EmoteOriginalLease
root=Path('.ios-host-tmp/avatar-final-ready-boundary-jtcencez').resolve()
final=next(root.glob('*/ios-avatar-primary-final.json'));raw=PrivateFeatureState(final).read()
config=raw['inputs']['primary'];path=Path(config['paths']['post']);store=PrivateFeatureState(path);original=store.read()
lock=ArchiveSourceLock(path.with_name('script-feature-sources.lock'));lease=EmoteOriginalLease(root,[])
with lock.held():
    expected=None
    owner=None
    actual_open=os.open;actual_io_open=io.open;comparison=[]
    for label in ('cold-archive','warm-parse'):
        profile=cProfile.Profile();start=time.perf_counter();opened=[]
        def os_open(path,*args,**kwargs):
            opened.append(['os',os.fspath(path),str(args)]);return actual_open(path,*args,**kwargs)
        def io_open(path,*args,**kwargs):
            opened.append(['io',os.fspath(path) if not isinstance(path,int) else '<fd>',str(args)]);return actual_io_open(path,*args,**kwargs)
        with patch.object(os,'open',os_open),patch.object(io,'open',io_open),scope(fresh=True) as reads:
            profile.enable()
            if owner is None:
                owner=IOSAvatarPostLogoutReads.archive(original,store=store,root=Path(config['root']),binding=raw['bindings']['primary'],run=raw['runId'],role=raw['role'],subject='primary',lock=lock,child_run=config['childRunId'],fixture_url=config['fixtureUrl'],ticket=config['ticket'],baseline=config['baseline']['state'],logout_before=config['logoutBefore'])
                value=owner.state
            else:value=owner.parse(original)
            profile.disable()
        elapsed=time.perf_counter()-start;lease.guard()
        comparison.append(dict(mode=label,opened=opened,membership=sorted(map(str,reads)),state=digest(value)))
        sha=digest(value)
        if expected is None:expected=sha
        else:assert sha==expected
        print('PostLogout actual original '+label+' seconds='+format(elapsed,'.6f')+' retainedRows='+str(len(value['rows']))+' pending='+str(value['pending'] is not None)+' members='+str(len(reads))+' actualFrameReads='+str(sum(x.callcount for x in profile.getstats() if x.code is OriginalFrameStore.read.__code__))+' originalInventoryUnchanged=True nativeSDK=0',flush=True)
        pstats.Stats(profile).strip_dirs().sort_stats('cumulative').print_stats(22).print_callers('deepcopy')
    baseline=Path(__file__).with_name('open-baseline.json')
    if baseline.exists():
        assert json.loads(baseline.read_text())==comparison
        print('Cold/warm exact actual file-open trace/membership/output parity=True',flush=True)
    else:baseline.write_text(json.dumps(comparison))
