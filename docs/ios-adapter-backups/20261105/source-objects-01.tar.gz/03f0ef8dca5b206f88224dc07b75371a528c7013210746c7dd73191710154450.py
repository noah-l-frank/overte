"""Current passive Asset API rights independent of any live QML page.

No cached UI flag, settings ACK, action request or historical permission sample
can supply these facts. The optional source is literal absent on older packets;
a complete new source is required for whole checkpoint/cleanup use.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import exact,integer,need
from ios.adapters.assets_controls import identity


def validate(value,*,pid,epoch=None,previous=None):
    exact(value,{'iosAssetsPermissionSourceVersion','instance','sequence','processId','capturedEpochMs',
        'available','complete','binding','permissions'})
    need(type(value['iosAssetsPermissionSourceVersion']) is int and value['iosAssetsPermissionSourceVersion']==1
        and integer(value['sequence'],1) and type(value['processId']) is int and value['processId']==pid
        and integer(value['capturedEpochMs'],1) and type(value['available']) is type(value['complete']) is bool)
    identity(value['instance'])
    if epoch is not None:need(abs(value['capturedEpochMs']-epoch)<=1500)
    if value['complete']:
        need(value['available']);binding=value['binding'];exact(binding,{'apiId','clientNodeId','domainId'})
        for name in binding:identity(binding[name])
        exact(value['permissions'],{'canWriteAssets','canRez','canRezTmp'})
        need(all(type(right) is bool for right in value['permissions'].values()))
    else:need(value['binding'] is None and value['permissions'] is None)
    if previous is not None:
        validate(previous,pid=pid)
        need(value['instance']==previous['instance'] and value['sequence']>previous['sequence']
            and value['capturedEpochMs']>=previous['capturedEpochMs'])
        if previous['complete'] and value['complete']:need(value['binding']==previous['binding'])
    return value


def current(packet,*,pid,domain_id=None):
    need(type(packet.get('assetPermissionsVersion')) is int and packet['assetPermissionsVersion']==1)
    value=validate(packet.get('assetPermissions'),pid=pid,epoch=packet['sampleEpochMs']);need(value['available'] and value['complete'])
    if domain_id is not None:need(value['binding']['domainId']==domain_id)
    usage=packet.get('assetUsageInventory')
    if usage is not None and usage['available'] and usage['complete']:
        for page in usage['pages']:
            need(all(page[key]==value['binding'][key] for key in ('apiId','clientNodeId','domainId'))
                and page['permissions']==value['permissions'])
    return deepcopy(value)
