"""Original existing lock receiver only; never create or mutate old inputs."""
from pathlib import Path
import os,stat,sys,threading
class OriginalLockCustody:
    def __init__(self,path,expected,pin):
        self.path=Path(path);self.expected=expected;self.pin=pin;self.owner=None;self.rows=[];self.active=None
        self.open=os.open;self.fstat=os.fstat;self.pid=os.getpid;self.ident=threading.get_ident;self.frame=sys._getframe
    def bind_class(self,module,fcntl):
        self.module=module;self.kind=module.ScriptSourceLock;self.wrapper=self.kind.held;self.function=self.wrapper.__wrapped__
        self.code=self.function.__code__;self.namespace=self.function.__globals__;self.flock=fcntl.flock;self.fcntl=fcntl
        self.methods=tuple((name,getattr(self.kind,name),getattr(self.kind,name).__code__)for name in('__init__','_check','assert_held','held'))
    def bind(self,owner):
        assert self.owner is None and type(owner)is self.kind and owner.path==self.path and owner._owner is None
        assert self.pin(self.path)==self.expected;self.owner=owner
    def check(self):
        assert self.module.ScriptSourceLock is self.kind and self.kind.held is self.wrapper and self.wrapper.__wrapped__ is self.function
        assert self.function.__code__ is self.code and self.function.__globals__ is self.namespace and self.fcntl.flock is self.flock
        for name,function,code in self.methods:assert getattr(self.kind,name)is function and function.__code__ is code
        assert self.pin(self.path)==self.expected
    def held_frame(self,frame):
        self.check();assert frame.f_code is self.code and frame.f_globals is self.namespace
        assert frame.f_locals.get('self')is self.owner and frame.f_locals.get('path')==self.path
        assert self.owner.path==self.path
    def os_open(self,path,flags,mode=0o777,*,dir_fd=None):
        if type(path)not in(str,bytes,type(self.path))or Path(os.fsdecode(path))!=self.path:
            return self.boundary.os_open(path,flags,mode,dir_fd=dir_fd)
        self.held_frame(self.frame(1));assert dir_fd is None and self.owner._owner is None
        expected=os.O_RDWR|os.O_CREAT|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0)
        assert flags==expected and mode==0o600 and self.active is None
        frame=self.frame();self.active=(frame,flags)
        try:descriptor=self.open(path,flags,mode)
        finally:self.active=None
        info=self.fstat(descriptor);assert stat.S_ISREG(info.st_mode)and info.st_size==0 and info.st_nlink==1 and stat.S_IMODE(info.st_mode)==0o600
        assert(info.st_dev,info.st_ino)==(self.expected['stat'][0],self.expected['stat'][1]);self.check()
        self.rows.append(dict(descriptor=descriptor,device=info.st_dev,inode=info.st_ino,flocks=[]));return descriptor
    def event(self,event,args,caller):
        if event=='open':
            path,mode,flags=args
            if type(path)not in(str,bytes,type(self.path))or Path(os.fsdecode(path))!=self.path:return False
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            if not writing:return False
            self.check();assert self.active is not None and caller is self.active[0]
            self.held_frame(caller.f_back);assert mode is None and flags==self.active[1]|getattr(os,'O_CLOEXEC',0)
            return True
        if event=='fcntl.flock':
            descriptor,operation=args;self.held_frame(caller)
            assert caller.f_locals['descriptor']==descriptor and operation==self.fcntl.LOCK_EX|self.fcntl.LOCK_NB
            row=next(r for r in self.rows if r['descriptor']==descriptor);info=self.fstat(descriptor)
            assert(info.st_dev,info.st_ino)==(row['device'],row['inode']);row['flocks'].append(operation);return True
        return False
    def install(self,boundary):
        self.boundary=boundary;boundary.ports['open']=self.os_open;os.open=boundary.ports['open']
        # Exact declared controller wrapper composes with the unchanged E458
        # helper; original syscall map and own dir_fd invocation remain literal.
        boundary.port_implementations=[]
        for port in boundary.ports.values():
            function=getattr(port,'__func__',port)
            boundary.port_implementations.append((port,function,function.__code__,tuple(cell.cell_contents for cell in function.__closure__ or())))
        boundary._seal_function(self.os_open.__func__);boundary._check()
    def finish(self):
        self.check();assert self.owner is not None and self.owner._owner is None and len(self.rows)==1 and self.rows[0]['flocks']
        for row in self.rows:
            try:info=self.fstat(row['descriptor'])
            except OSError as error:assert error.errno==9
            else:assert(info.st_dev,info.st_ino)!=(row['device'],row['inode']),'Original lock descriptor remains live'
        return dict(existingOriginalInodePreserved=True,originalHeldCodeAndReceivers=True,ownerReleased=True,actualOpenAndFlockRows=self.rows)
