"""Exactly one frozen RawMarkerWorker Node child and its real CPython pipes.

Controller custody only. No product method, native observation or process exit
is synthesized. Other subprocess and inherited-descriptor ports remain refused.
"""
from pathlib import Path
import hashlib,os,shutil,stat,subprocess,sys


class MovingNodePort:
    def __init__(self,plan,write_boundary):
        self.plan,self.boundary=plan,write_boundary
        self.script=Path(plan['movingNodeScript']['path'])
        self.node=Path(plan['nodeExecutable']['path'])
        self.command=['node',str(self.script)]
        self.popen=subprocess.Popen;self.environment_path=os.environ.get('PATH')
        self.popen_methods=tuple((name,getattr(self.popen,name),getattr(self.popen,name).__code__)
            for name in('__init__','_execute_child'))
        self.readers=(os.fstat,os.readlink,sys._getframe,shutil.which)
        self.pending=None;self.spawned=False;self.worker=None;self.start=None;self.owner=None
        self.pipe_opens=[];self.bound_pid=None
        self.script_pin=self.pin(self.script);self.node_pin=self.pin(self.node)
        assert self.script_pin==plan['movingNodeScript']['pin']and self.node_pin==plan['nodeExecutable']['pin']
        assert Path(shutil.which('node')).resolve(strict=True)==self.node

    @staticmethod
    def pin(path):
        before=path.lstat();assert stat.S_ISREG(before.st_mode)and path.resolve(strict=True)==path
        raw=path.read_bytes();after=path.lstat()
        fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        value=dict(stat=[getattr(before,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest())
        assert value['stat']==[getattr(after,key)for key in fields];return value

    def bind(self,worker_class):
        assert self.worker is None and worker_class.__module__=='lifecycle_moving_raw_worker'
        self.worker=worker_class;self.start=worker_class.start
        self.start_code=self.start.__code__;self.start_globals=self.start.__globals__
        assert self.start_globals['subprocess']is subprocess
        assert Path(self.start_code.co_filename).resolve(strict=True)==Path(self.plan['movingWorkerSource']['path'])
        assert self.pin(Path(self.start_code.co_filename))==self.plan['movingWorkerSource']['pin']

    def check(self):
        assert subprocess.Popen is self.popen and os.environ.get('PATH')==self.environment_path
        assert self.readers==(os.fstat,os.readlink,sys._getframe,shutil.which)
        for name,function,code in self.popen_methods:assert getattr(self.popen,name)is function and function.__code__ is code
        assert self.worker is not None and self.worker.start is self.start and self.start.__code__ is self.start_code
        assert self.start.__globals__ is self.start_globals and self.start_globals['subprocess']is subprocess
        assert self.pin(self.script)==self.script_pin and self.pin(self.node)==self.node_pin
        assert Path(shutil.which('node')).resolve(strict=True)==self.node

    def frames(self,frame):
        self.check();outer=None;constructor=None;execute=None
        while frame is not None:
            if frame.f_code is self.start_code and frame.f_globals is self.start_globals:outer=frame
            for name,function,code in self.popen_methods:
                if frame.f_code is code and frame.f_globals is function.__globals__:
                    if name=='__init__':constructor=frame
                    else:execute=frame
            frame=frame.f_back
        assert outer is not None and constructor is not None
        worker=outer.f_locals['self'];child=constructor.f_locals['self']
        assert type(worker)is self.worker and type(child)is self.popen and worker.process is None
        assert constructor.f_locals['args']==self.command
        assert constructor.f_locals['stdin']==subprocess.PIPE and constructor.f_locals['stdout']==subprocess.PIPE and constructor.f_locals['stderr']==subprocess.PIPE
        assert constructor.f_locals['text']is True and constructor.f_locals['shell']is False
        assert constructor.f_locals['cwd']is None and constructor.f_locals['env']is None and constructor.f_locals['executable']is None
        assert constructor.f_locals['start_new_session']is False and constructor.f_locals['pass_fds']==()
        assert constructor.f_locals['process_group']==-1 and constructor.f_locals['preexec_fn']is None
        assert constructor.f_locals['close_fds']is True
        if self.pending is None:self.pending=child;self.owner=worker
        assert self.pending is child and self.owner is worker and not self.spawned
        return constructor,execute

    def pipe_open(self,args,frame):
        if type(args[0])is not int:return False
        descriptor,mode,flags=args
        if type(mode)is not str or not any(letter in mode for letter in'wax+'):return False
        info=os.fstat(descriptor)
        if not stat.S_ISFIFO(info.st_mode):return False
        constructor,unused=self.frames(frame)
        assert mode in('w','wb')and descriptor==constructor.f_locals['p2cwrite']
        target=os.readlink('/proc/self/fd/'+str(descriptor))
        assert stat.S_ISFIFO(info.st_mode)and target=='pipe:['+str(info.st_ino)+']'
        assert not self.pipe_opens
        self.pipe_opens.append(dict(descriptor=descriptor,device=info.st_dev,inode=info.st_ino,mode=info.st_mode))
        return True

    def spawn(self,args,frame):
        constructor,execute=self.frames(frame);assert execute is not None
        executable,command,cwd,env=args
        assert executable=='node'and command==self.command and cwd is None and env is None
        assert execute.f_locals['self']is self.pending and len(self.pipe_opens)==1
        self.spawned=True

    def finish(self):
        self.check();assert self.spawned and self.pending is not None and self.owner.process is self.pending
        process=self.pending;self.bound_pid=process.pid
        assert process.poll()==0 and not Path('/proc',str(process.pid)).exists()
        assert all(stream is not None and stream.closed for stream in(process.stdin,process.stdout,process.stderr))
        assert self.owner.reader is not None and not self.owner.reader.is_alive()and not self.owner.running
        browser=self.owner.browser
        assert browser.thread is not None and not browser.thread.is_alive()
        return dict(actualNodePid=process.pid,actualNodeReturnCode=process.returncode,pipeOpens=self.pipe_opens,
            actualPipeStreamsClosed=True,actualReaderExited=True,actualBrowserExited=True,
            exactCommand=self.command,nodeScript=self.plan['movingNodeScript'],nodeExecutable=self.plan['nodeExecutable'])


class OwnedLoopbacks:
    def __init__(self):self.servers=[]
    def audit(self,event,args):
        if event=='socket.bind':
            owner,address=args
            assert type(address)is tuple and address[0]in('127.0.0.1','::1')and address[1]==0
            self.servers.append(owner)
        elif event=='socket.connect':
            unused,address=args
            assert type(address)is tuple and address[0]in('127.0.0.1','::1','localhost')
            assert any(owner.fileno()>=0 and owner.getsockname()[1]==address[1]for owner in self.servers)
        elif event in('socket.sendto','socket.sendmsg'):raise RuntimeError('No datagram transport admitted')
    def finish(self):
        assert self.servers and all(owner.fileno()==-1 for owner in self.servers)
        return dict(ownedServerSockets=len(self.servers),allOwnedServerSocketsClosed=True)
