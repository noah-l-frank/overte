"""Actual original component codecs/transport methods, raw native data MODELS.

No SDK/Parent/Current7/physical/native qualification is produced. The test
constructs actual NativeInput/NativeFeatureObservation/Audio readers and drives
actual HTTP-receipt/AFC methods over declared in-process lower producers.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import base64,json,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from adapters.native_clock_join import NativeClockAcquisition
from adapters.native_feature_observation import NativeFeatureObservation
from adapters.normal_ui import NativeUIError
from ios.adapters import normal_input
from ios.adapters.audio_settings_source import IOSAudioSettings
from ios.adapters.audio_session_source import IOSAudioSession
from ios.adapters.audio_outer_original_acquisition import AudioOuterOriginalAcquisition
from audio_original_current_producer import RawAudioCurrentProducer

class AudioOuterOriginalAcquisitionTests(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        self.root=Path(temporary.name);self.root.chmod(0o700);self.model=RawAudioCurrentProducer(self.root/'raw')
        self.guard_calls=0;self.inner_clock_calls=0;self.reads=[];self.fault=None
        def guard():self.guard_calls+=1;return self.fault!='lost-source'
        self.guard=guard
        def clock_send(q):self.model.produce(q)
        self.clock=NativeFeatureObservation(clock_send,lambda:self.model.file('/Documents/owned-results/feature-native-observation.json').read_text(),
            lambda:time.time()*1000,guard,42,ios=True)
        def forbidden_inner_clock():self.inner_clock_calls+=1;raise AssertionError('Joined originals must use real outer NativeAfter, never an inner clock substitute')
        outer=self
        class Client:
            def execute(self,session,operation,values):
                outer.assertEqual('model',session);outer.assertEqual('mobile: pullFile',operation)
                path=outer.model.file(values['remotePath']);outer.reads.append(path.name);return base64.b64encode(path.read_bytes()).decode()
        target=dict(appId=self.model.bundle_id,nativeUiObservation=dict(kind='uikit-documents',version=1),testBuild=dict(fixtureOrigin='https://controlled.invalid',resultsDirectory='owned-results'))
        self.ui=normal_input.NativeInput(Client(),'model',target,lambda:dict(bundleId=self.model.bundle_id,pid=42,foreground=True),native_epoch_ms=forbidden_inner_clock)
        def post(request,timeout):
            query=json.loads(request.data);outer.model.produce(query)
            class Response:
                status=200
                def __enter__(self):return self
                def __exit__(self,*_args):return False
                def read(self,limit):return json.dumps(query).encode()[:limit]
            return Response()
        self.enterContext(patch.object(normal_input,'urlopen',post))
        def reader(kind,cls):
            filename='feature-ios-audio-'+kind+'.json'
            def send(q):
                self.model.produce(q)
                if self.fault=='late'and kind=='session':time.sleep(1.55)
            def original():
                path=self.model.file('/Documents/owned-results/'+filename);self.reads.append(path.name);return path.read_text()
            return cls(send,original,forbidden_inner_clock,guard,42)
        self.readers=dict(clock=self.clock,settings=reader('settings',IOSAudioSettings),session=reader('session',IOSAudioSession))
        self.source=dict(native=self.ui,clock_source=self.clock,client=self.ui.client,session='model',target=target,
            binding=dict(sourceRevision='a'*40,artifactSha256='b'*64,processIdentity='42',sessionId='model',generation=1,targetFingerprint='c'*64),check=guard)
    def acquire(self,*,change=None):
        round_=AudioOuterOriginalAcquisition(self.source,self.readers,'d'*32,monotonic=time.monotonic)
        acquisition=NativeClockAcquisition(self.clock);acquisition.begin(time.time()*1000);round_.bind_before(acquisition.started['nativeBefore'])
        native=self.clock.read(self.clock.sequence,require_recorded_history=True);ui=round_.ui_original()
        settings=round_.reader_original('settings');session=round_.reader_original('session')
        if change is not None:change()
        raw=dict(native=native,ui=ui,settings=settings,session=session,settingsClock=dict(capturedEpochMs=settings['clockAfter']['epochMs']),sessionClock=dict(capturedEpochMs=session['clockAfter']['epochMs']))
        join=acquisition.finish(raw,[('native','capturedEpochMs'),('ui','sampleEpochMs'),('settingsClock','capturedEpochMs'),('sessionClock','capturedEpochMs')])
        self.assertEqual(ui,round_.accept(join['nativeAfter']));return raw,join
    def test_three_actual_native_reads_and_one_unchanged_original_response_per_component_under_real_outer_bracket(self):
        before=len(self.model.queries);raw,join=self.acquire();queries=self.model.queries[before:]
        self.assertEqual(3,sum(q['action']=='feature-native-observe'for q in queries));self.assertEqual(0,self.inner_clock_calls)
        self.assertEqual(1,sum(q['action']=='normal-ui-input'for q in queries))
        for kind in ('settings','session'):
            self.assertEqual(1,sum(q['action']=='feature-ios-audio-'+kind for q in queries))
            packet=json.loads(self.model.file('/Documents/owned-results/feature-ios-audio-'+kind+'.json').read_text())
            self.assertEqual(packet,raw[kind]);self.assertEqual(packet,self.readers[kind].last)
            self.assertEqual(join['nativeAfter']['capturedEpochMs'],self.readers[kind].acquisition['nativeAfterEpochMs'])
        self.assertEqual(len(self.reads),3);self.assertGreater(self.guard_calls,6)
        first={q['commandId']for q in queries};self.acquire()
        self.assertTrue(first.isdisjoint({q['commandId']for q in self.model.queries[len(queries):]}))
    def test_real_late_delivery_refuses_without_retiming_or_accepting_current_reader_state(self):
        self.fault='late'
        with self.assertRaises(NativeUIError):self.acquire()
        self.assertIsNone(self.readers['settings'].last);self.assertIsNone(self.readers['session'].last)
        self.assertEqual(0,self.inner_clock_calls)
    def test_actual_final_source_loss_and_same_object_parser_code_mutation_refuse_before_commit(self):
        with self.assertRaises(NativeUIError):self.acquire(change=lambda:setattr(self,'fault','lost-source'))
        self.assertIsNone(self.readers['settings'].last)
        self.fault=None;function=self.readers['settings']._validate;original=function.__code__
        def changed(*_args,**_kwargs):return None
        try:
            with self.assertRaises(NativeUIError):self.acquire(change=lambda:setattr(function,'__code__',changed.__code__))
        finally:function.__code__=original
        self.assertIsNone(self.readers['settings'].last);self.assertIsNone(self.readers['session'].last)
