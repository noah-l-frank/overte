"""One exact45 host run; no native execution or complete Chat admission."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tempfile,time
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
PRIVATE=REPO/'.ios-host-tmp'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics','libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
def save(name,value):
    (HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def pin(path):
    first=path.lstat();result={k:getattr(first,k) for k in FIELDS}
    if stat.S_ISREG(first.st_mode):result['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    else:assert stat.S_ISDIR(first.st_mode)
    last=path.lstat();assert all(getattr(first,k)==getattr(last,k) for k in FIELDS),str(path)
    return result
def census():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    files={REPO/name for name in names if name}
    files.update(HERE/name for name in ('root-supervise45.py','selected-suite.py','selected-suite-plan.json','sourcepins.json','integration.diff','root-actual-publication.json','root-reviewed-qt-reference-capture.json'))
    files.update(path for path in (HERE/'reviewed-qt-reference').rglob('*') if path.is_file())
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(files)}
def original_census(roots):
    return {str(root):{str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))} for root in sorted(roots)}
def process(pid):
    try:
        fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
    except FileNotFoundError:return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
temporary=Path(tempfile.mkdtemp(prefix='root-selected45-tmp-',dir=HERE));temporary.chmod(0o700)
old_patch_roots=set(PRIVATE.glob('qt-qml-patch-test-*'))
before=census();save('root45-source-before.json',before)
environment=os.environ.copy()
environment.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.:tests/device:tests/device/self_tests:tests/device/ios/self_tests',TMPDIR=str(temporary),OVERTE_QT_SOURCE_REFERENCE_ROOT=str(HERE/'reviewed-qt-reference'))
print('SOURCE_LAUNCHER_REFERENCE_PINS',len(before),flush=True)
started=time.monotonic()
with (HERE/'root45-first.log').open('w') as log:
    task=subprocess.Popen(['timeout','--signal=TERM','--kill-after=5s','90s',sys.executable,str(HERE/'selected-suite.py')],cwd=REPO,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    binding=process(task.pid);assert binding is not None
    save('root45-process-binding.json',binding)
    print('ACTUAL_PROCESS',json.dumps(binding,sort_keys=True),flush=True)
    code=task.wait()
after=census();save('root45-source-after.json',after)
assert before==after,'Source/launcher/reference bytes/stat/membership changed'
roots={temporary}|(set(PRIVATE.glob('qt-qml-patch-test-*'))-old_patch_roots)
first=original_census(roots);save('root45-originals-first.json',first)
second=original_census(roots);save('root45-originals-second.json',second)
assert first==second,'Originals changed after test completion'
remaining=[]
for path in Path('/proc').iterdir():
    if not path.name.isdecimal():continue
    item=process(int(path.name))
    if item is not None and item['processGroup']==task.pid:remaining.append(item)
report=dict(exitCode=code,seconds=time.monotonic()-started,sourceLauncherReferencePins=len(after),allSourcePinsEqual=True,originalRootCount=len(roots),originalFiles=sum(stat.S_ISREG(row['st_mode']) for rows in first.values() for row in rows.values()),originalPostTestCensusesEqual=True,remainingOwnedProcesses=remaining,nativeCompiled=False,deviceQualified=False,wholeFeatureQualified=False)
save('root45-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
assert not remaining,'Owned process group remains live'
raise SystemExit(code)
