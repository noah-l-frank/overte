"""Ordinary address return selected only from the actual owned native baseline.

The normal address input WAL retains uncertain sends. Its acknowledgment is
separate from fresh World position/orientation/input restoration evidence.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import math
from adapters.native_clock_join import NativeClockAcquisition,validate_join
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUI
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same
from ios.adapters import lifecycle_current as current,lifecycle_world as world,navigation_state
from ios.adapters.navigation_address_inputs import NavigationAddressInputs
from ios.adapters.normal_navigation import configuration


class LifecycleRestoration:
    def __init__(self,store,editors,*,epoch_ms,monotonic,current_stream=None):
        self.store,self.editors,self.source=store,editors,editors.sources.source
        self.binding,self.run,self.lock=deepcopy(editors.binding),editors.run,editors.lock
        from ios.adapters.lifecycle_current_stream import LifecycleCurrentStream
        need(current_stream is None or type(current_stream) is LifecycleCurrentStream and current_stream.source is self.source
            and current_stream.binding==self.binding and current_stream.run==self.run and current_stream.role=='primary'and current_stream.lock is self.lock)
        self.current_stream=current_stream
        need(isinstance(store,PrivateFeatureState) and store.path==editors.store.path.with_name('ios-lifecycle-restoration.json'))
        self.epoch_ms,self.monotonic=epoch_ms,monotonic;self.previous=store.read()
        self.state=dict(baseline=None,after=None,storage={}) if self.previous is None else deepcopy(self.previous['state'])
        if self.previous is not None:
            exact(self.previous,{'iosLifecycleRestorationVersion','binding','runId','state'})
            need(type(self.previous['iosLifecycleRestorationVersion']) is int and self.previous['iosLifecycleRestorationVersion']==1
                and self.previous['binding']==self.binding and self.previous['runId']==self.run);exact(self.state,{'baseline','after','storage'})
        self.files=OriginalFrameStore(store.path.parent,self.binding,self.run,'primary',self.check,self.intent,
            namespace='lifecycle-restoration',schema_prefix='iosLifecycleRestoration',kind='inputs')
        self.reader=self.source['observer'].lifecycle_world(self.source['clock_source'])
        self.navigation=self.source['observer'].navigation_state(self.source['clock_source'])
        self.check()
        need(type(self.state['storage']) is dict and set(self.state['storage'])<= {'1','2'}
            and (self.state['after'] is None or self.state['baseline'] is not None))
        for key,value in self.state['storage'].items():self.files.original(value);need(value['index']==int(key))
        for name,index in (('baseline',1),('after',2)):
            reference=self.state[name]
            if reference is not None:
                need(reference['index']==index and str(index)in self.state['storage']
                    and same(reference,self.files.compact(self.state['storage'][str(index)])))
                self.original(reference)

    def check(self):
        self.lock.assert_held();need(self.source is self.editors.sources.source and self.source['binding']==self.binding
            and self.source['check']() is not False and same(self.store.read(),self.previous));return True

    def save(self):
        self.check();value=dict(iosLifecycleRestorationVersion=1,binding=self.binding,runId=self.run,state=deepcopy(self.state))
        self.store.write(value,self.previous);self.previous=deepcopy(value)

    def intent(self,kind,value):
        self.check();need(kind=='original');self.files.original(value);key=str(value['index']);need(key in ('1','2'))
        old=self.state['storage'].get(key)
        if old is None:need(value['phase']=='planned')
        else:
            need(all(same(old[k],value[k]) for k in old if k not in ('phase','file'))
                and (old['phase'],value['phase']) in (('planned','opened'),('opened','saved'))
                and (old['file'] is None or old['file']==value['file']))
        self.state['storage'][key]=deepcopy(value);self.save()

    def baseline(self,actual):
        self.check();current.original(actual,self.binding,self.run)
        need(self.current_stream is not None and self.current_stream.state['records']);reference=self.current_stream.state['records'][-1]
        retained=self.current_stream.record(reference);need(same(retained['current'],actual))
        if self.state['baseline'] is not None:
            need(same(self.original(self.state['baseline'])['world'],actual));return self.selected()
        clock=NativeClockAcquisition(self.source['clock_source'],epoch_ms=self.epoch_ms,monotonic=self.monotonic)
        clock.begin(self.epoch_ms());raw=self.navigation.read(self.run);joined=clock.finish(dict(navigation=raw),[])
        first=actual['originals']['world'];need(first['clockAfter']['epochMs']<=raw['clockBefore']['epochMs']
            and raw['clockAfter']['epochMs']-first['clockBefore']['epochMs']<1500)
        need(math.dist(first['source']['avatar']['feetPosition'],raw['source']['avatar']['feetPosition'])<=.025)
        frame=dict(world=deepcopy(actual),navigation=raw,clockJoin=joined,currentReference=deepcopy(reference),ownerInstance=self.current_stream.state['owner'])
        ref=self.files.write(1,frame);self.state['baseline']=ref;self.save();return self.selected()

    def original(self,reference):
        self.check();value=self.files.read(self.files.expand(reference))
        if reference['index']==2:
            exact(value,{'current','addressOwner','currentReference'});current.original(value['current'],self.binding,self.run)
            need(self.current_stream is not None and same(self.current_stream.record(value['currentReference'])['current'],value['current']))
            # Decode the literal actual ordinary-address WAL, without creating
            # a live navigation/Input owner or issuing a replacement Go.
            decoder=object.__new__(NavigationAddressInputs);decoder.binding,decoder.run=self.binding,self.run
            decoded=decoder.decode(value['addressOwner']);rows=[row for row in decoded['rows']if row['key']=='return']
            need(len(rows)==1 and rows[0]['phase']=='acknowledged' and rows[0]['url']==self.selected())
            first=self.original(self.state['baseline'])['world']['originals']['world'];last=value['current']['originals']['world']
            measured=world.measure(first,last)
            need(measured['heldInputs']==[] and measured['worldDisplacement']<=.025 and not last['source']['touch']['active']
                and abs(sum(a*b for a,b in zip(first['source']['avatar']['orientation'],last['source']['avatar']['orientation'])))>=.9999)
            return value
        need(reference['index']==1);exact(value,{'world','navigation','clockJoin','currentReference','ownerInstance'})
        need(self.current_stream is not None and value['ownerInstance']==self.current_stream.state['owner']
            and same(self.current_stream.record(value['currentReference'])['current'],value['world']))
        current.original(value['world'],self.binding,self.run);packet=value['navigation'];join=validate_join(value['clockJoin'],dict(navigation=packet))
        navigation_state.validate(packet,dict(schemaVersion=1,commandId=packet['requestId'],action=navigation_state.ACTION,runId=self.run),
            int(self.binding['processIdentity']),join['nativeAfter']['capturedEpochMs'])
        need(join['nativeBefore']['capturedEpochMs']<=packet['clockBefore']['epochMs']<=packet['clockAfter']['epochMs']<=join['nativeAfter']['capturedEpochMs'])
        return value

    def selected(self):
        self.check();need(self.state['baseline'] is not None);value=self.original(self.state['baseline']);url=value['navigation']['source']['sceneUrl']
        need(type(url) is str and 1<=len(url)<=2048 and not any(ord(c)<32 for c in url));return url

    def restore(self,*,ticket):
        from feature_journeys.contract import identifier
        self.check();identifier(ticket);need(self.current_stream is not None)
        # A new actual original-owner cut is REQUIRED before Go. A new Source
        # with only the old JSON binding cannot borrow the baseline address.
        opening=self.current_stream.current(ticket);first_cut=opening['current'];first_facts=current.original(first_cut,self.binding,self.run)
        need(not first_facts['world']['source']['touch']['active'] and first_facts['editor']['field'] is None
            and not first_facts['editor']['keyboard']['keyboard'])
        url=self.selected();source=self.source
        owner=NavigationAddressInputs(PrivateFeatureState(self.store.path.with_name('ios-navigation-address-'+self.binding['processIdentity']+'-inputs.json')),
            self.binding,self.run,self.lock,self.check,NativeUI(source['client'],source['session'],self.check),source['native'],
            epoch_ms=self.epoch_ms,monotonic=self.monotonic)
        profile=configuration(source['target']);need(profile is not None)
        owner.goto('return',url,profile,{url},original_return=self)
        # New actual current sources, never the Go acknowledgment or requested
        # address. An unsettled return refuses and leaves all responsibility.
        observed=self.current_stream.current(ticket);value=observed['current'];current_reference=deepcopy(self.current_stream.state['records'][-1])
        first=self.original(self.state['baseline'])['world']['originals']['world'];last=value['originals']['world'];facts=world.measure(first,last)
        need(facts['heldInputs']==[] and facts['worldDisplacement']<=.025 and not last['source']['touch']['active'])
        a,b=first['source']['avatar']['orientation'],last['source']['avatar']['orientation']
        need(abs(sum(x*y for x,y in zip(a,b)))>=.9999)
        if self.state['after'] is None:
            # The restored evidence uses its own complete Current original;
            # no fabricated second navigation clock join is published.
            self.state['after']=self.files.write(2,dict(current=value,addressOwner=deepcopy(owner.previous),currentReference=current_reference))
            self.save()
        return dict(performed=True)
