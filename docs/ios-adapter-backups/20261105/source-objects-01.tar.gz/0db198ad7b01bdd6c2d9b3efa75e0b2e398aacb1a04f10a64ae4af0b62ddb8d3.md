# Root-only future admission, unchanged interface

No command has been run. Use the actual current Root-reviewed quiet context/external manifest and exact expected checkout; preserve all prior failure rooms and bodies.

```text
PYTHONDONTWRITEBYTECODE=1 <reviewed-python> -B -S <B3>/prepare.py \
  --expected-head <actual-current-head> \
  --group paired-first1 \
  --assembler-source-sha256 <B3-source-freeze-sha256> \
  --root-context <current-root-context.json> \
  --root-context-sha256 <exact-sha256> \
  --external-manifest <exact-reviewed-external-manifest.json> \
  --external-manifest-sha256 <exact-sha256> \
  --public-integration-freeze <actual-retained-f35e-freeze.json> \
  --public-integration-sha256 f35e841db95bd84e136d549b0213c62e3554b631407df238644c00afc9e77027 \
  --output <new-absolute-chat-paired-offline-paired-first1-prepared-name>
```

The unchanged literal public integration reader currently requires its actual 9d584bb54268b0ae62c2a9154303bd816df6cda2 source. Do not silently admit another HEAD or relabel this historical integration. Any future public change needs separate explicit source admission.

After full Root generated readback and a separate explicit target window, the unchanged supervisor accepts the exact group, HEAD, source freeze, plan SHA, plan path and new private output root. It runs only one positive at 300+5. It never chains the remaining five. Errors/timeouts/cleanup failures retain originals and stay failing.
