"""No-site controller metadata and actual kernel identities only."""
from pathlib import Path
import os,sys,threading
from metadata_reader import pin,load,sha,census
SOURCE=Path(__file__).resolve().parent
REPO=SOURCE.parent.parent
def proc(pid):
    try:raw=Path('/proc',str(pid),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    v=raw[raw.rfind(')')+2:].split()
    return dict(pid=int(raw[:raw.index('(')].strip()),parentPid=int(v[1]),processGroup=int(v[2]),session=int(v[3]),startTicks=int(v[19]))
def fds():
    out={}
    for p in Path('/proc/self/fd').iterdir():
        try:s=p.stat();out[p.name]=dict(path=os.readlink(p),device=s.st_dev,inode=s.st_ino,mode=s.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return out
def table():
    return {int(p.name):row for p in Path('/proc').iterdir()if p.name.isdecimal()and(row:=proc(int(p.name)))is not None}
def head():
    raw=(REPO/'.git').read_text();assert raw.startswith('gitdir: ')
    gd=Path(raw[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for root in(gd,common):
        p=root/ref[5:]
        if p.is_file():return p.read_text().strip()
    raise AssertionError('Actual current own checkout HEAD unavailable')
def admitted(path,digest):
    assert sys.dont_write_bytecode and sys.flags.no_site==1 and Path.cwd()==REPO
    path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path and path.name=='approved-inputs.json'and path.parent.parent==REPO/'.ios-host-tmp'
    before=pin(path);assert before['sha256']==digest
    plan=load(path);assert plan['status']=='PRIVATE_OWN_BOUNDARY4_UNRUN_REQUIRES_ROOT_REVIEW'and plan['expectedHead']==head()
    assert plan['seconds']==30 and plan['graceSeconds']==5 and len(plan['cases'])==4
    assert plan['NodeExecutions']==0 and plan['maximumOpenSSLExecutions']==2 and plan['maximumFixtureListeners']==1
    assert plan['oldOriginalInputs']==plan['globalCensuses']==0
    for name,row in plan['physicalPins'].items():assert pin(name)==row
    assert pin(path)==before;return plan,before
