"""Read original closed utility receipts; no target or product imports."""
from pathlib import Path
import hashlib,json,os,stat,runpy
R=Path.cwd().resolve();B=R/'.ios-host-tmp'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(d,n,x):
 p=d/n
 with p.open('x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
 p.chmod(0o600)
def pin(p):
 p=Path(p);a=p.lstat();assert stat.S_ISREG(a.st_mode)
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  assert os.fstat(fd)==a
  with os.fdopen(fd,'rb',closefd=False)as f:raw=f.read()
  assert os.fstat(fd)==a==p.lstat()
 finally:os.close(fd)
 return dict(device=a.st_dev,inode=a.st_ino,mode=a.st_mode,uid=a.st_uid,gid=a.st_gid,nlink=a.st_nlink,bytes=a.st_size,mtimeNs=a.st_mtime_ns,ctimeNs=a.st_ctime_ns,sha256=hashlib.sha256(raw).hexdigest())
collector=B/'root-four-utility-serial-window-current918-b1-20261104'
assert sha(collector/'freeze.json')=='25fa0d0334f80e8b67566cdd4c9cead31fca21b68267308ad95063c7281a1744'
for n,v in load(collector/'freeze.json')['files'].items():assert sha(collector/n)==v['sha256']
t=load(collector/'terminal.json');assert len(t['groups'])==2 and t['unrunGroups']==['audio-terminal6-b2','world-timing8-b1']
assert t['allExecutedOwnedProcessesAbsent']and t['allOldOriginalBodiesUnchanged']and t['wholeOwnOutputsTwiceEqual']and len(t['newOriginalRoots'])==7
assert load(collector/'global-before.json')==load(collector/'global-after-first.json')==load(collector/'global-after-second.json')
assert len(load(collector/'global-before.json'))==918
assert load(collector/'whole-output-first.json')==load(collector/'whole-output-second.json')
tool=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py'
assert sha(tool)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be'
census=runpy.run_path(str(tool))['census']
whole=load(collector/'whole-output-first.json')
for name,v in whole.items():assert census(Path(name))==v
refs={}
for root in map(Path,t['newOriginalRoots']):
 for p in sorted(root.rglob('*')):
  if p.is_file()and not p.is_symlink():refs[str(p)]=dict(path=str(p),sha256=sha(p))
rows=[]
for ix,row in enumerate(t['groups']):
 h=Path(row['input']).parent;o=h.with_name(h.name+'-outer');c=h.with_name(h.name+'-censuses')
 assert sha(h/'approved-inputs.json')==row['inputSha256'];plan=load(h/'approved-inputs.json');report=load(h/'child-receipts/report.json');ports=load(h/'child-receipts/actual-port-restoration.json')
 assert plan['wallSeconds']==30 and plan['killGraceSeconds']==5
 assert load(o/'source-binary-before.json')==load(o/'source-binary-after.json')==plan['sourceAndBinaryPins']
 for name,v in plan['sourceAndBinaryPins'].items():assert pin(name)==v
 assert load(o/'approved-input-before.json')==load(o/'approved-input-after.json')
 assert load(o/'actual-child-output-first.json')==load(o/'actual-child-output-second.json')
 assert load(o/'actual-child-subtrees-first.json')==load(o/'actual-child-subtrees-second.json')
 assert load(c/'whole-first.json')==load(c/'whole-second.json')
 assert load(o/'actual-parent-drain.json')==dict(fdsEqual=True,threadsEqual=True)
 drain=load(o/'actual-process-drain.json');assert not drain['remaining']and not drain['forced']
 for owned in drain['owned']:
  try:raw=Path('/proc',str(owned['pid']),'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  assert int(raw[raw.rfind(')')+2:].split()[19])!=owned['startTicks']
 for k in ('fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','twoToyCensusesEqual','allActualLoadedOriginsAccounted'):assert report[k]is True
 for k in ('restored','builtinsCioRestored','dupPortsRestored','toolsRestored'):assert ports[k]is True
 assert ports['actualC10dHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
 assert report['fatal']is None and report['nativeQualified']is report['wholeQualified']is False
 cases=[load(h/('child-receipts/standard-case-'+str(j)+'.json'))for j in range(1,report['actualCaseReceipts']+1)]
 assert [x['id']for x in cases]==plan['cases'][:len(cases)]
 for case in cases:
  for k in ('fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','originalMethodsUnchanged','standardStopAfterCleanup'):assert case[k]is True
  assert case['remainingStandardCleanups']==0
  for call in case['actualNestedCleanupCalls']:assert call['remaining']==0 and not call['newCallbackErrors']and not call['newCallbackFailures']and call['originalRaised']is None
 if ix==0:
  assert row['supervisorReturnCode']==0 and row['originalTerminal']['status']==row['originalQualification']['status']=='PASS'
  assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==4 and report['cleanupEstablished']
  children=load(h/'child-receipts/actual-utility-children.json');obs=load(h/'child-receipts/actual-observation-cases.json')
  assert len(children)==5 and len(obs)==4
  for child in children:
   assert child['actualKernelAbsent']and child['allThreeParentStreamsClosed']
   assert len(child['pipes'])==6 and all(not x['sameOriginalStillLive']for x in child['pipes'])
  observations=[x['observation'][0]for x in obs]
  assert [x['outcome']for x in observations]==['NoPositiveExecutable','NoPositiveExecutable','ObservationError','ObservationError']
  assert all(x['processAbsenceEstablished']is False and x['positiveExecutableEstablished']is False for x in observations)
  assert observations[0]['before']['state']==observations[0]['after']['state']=='Z'
  copy=ports['originalShutilCopyOutcome'];assert copy['qualified']and copy['actualFifthConstructorCopiedELFPinEstablished']and copy['actualOriginalCopyFileRangeFullCopy']and not copy['actualOriginalFirstEXDEVStdlibFallback']and copy['originalErrorRecords']==[]
  assert copy['copiedELFConstructorPin']==children[4]['actualExecutablePin']
  assert ports['strictShutilCopyRange']['returnedBytes']==copy['copiedELFConstructorPin']['bytes']==11544
  detail=dict(status='PASS_FOUR_ORIGINAL_STATE_UTILITY_CASES_ONLY',originalReport=report,originalPortRestoration=ports,actualFiveChildren=children,actualObservations=obs,processObservationUtilityQualified=True,movingAdmissionQualified=False)
 else:
  assert row['supervisorReturnCode']==1 and row['originalTerminal']['status']==row['originalQualification']['status']=='FAIL_OR_REFUSED'
  assert report['testsRun']==report['actualCaseReceipts']==10 and report['cleanupEstablished']is False
  assert all(call['outcomeSuccessAfter']for case in cases[:9]for call in case['actualNestedCleanupCalls'])
  assert cases[9]['actualNestedCleanupCalls'][0]['failedReturnRemainsFailed']and not cases[9]['actualNestedCleanupCalls'][0]['outcomeSuccessAfter']
  cleanup=load(h/'child-receipts/actual-class-cleanup-restoration.json');summary=cleanup['summary']
  assert cleanup['originalDescriptorRestored']and cleanup['originalFunctionCodeGlobalsUnchanged']
  assert summary['actualOriginalClassCleanupCalls']==2 and summary['expectedSelectedClasses']==3 and not summary['problems']
  assert all(x['acceptedExpectedMetadataUpdate']and x['addedKeys']==['tearDown_exceptions']and x['onlyGenuineEmptyTearDownExceptionsDelta']for x in summary['actualCalls'])
  detail=dict(status='ORIGINAL_NINE_PASS_TENTH_ASSERTION_FAILED',originalReport=report,originalPortRestoration=ports,originalFailedCase=cases[9],actualExecutedClassCleanupsAccepted=2,thirdClassUnrun=True,originalFailureResetPointUnrecorded=True,diagnosticAdmission=None,assetsPhaseQualified=False)
 rows.append(dict(group=row['group'],actualInputSha256=row['inputSha256'],actualSourceFreeze=plan['sourceFreeze'],originalTerminal=row['originalTerminal'],originalQualification=row['originalQualification'],**detail))
for value in refs.values():assert sha(value['path'])==value['sha256']
out=B/'root-c11-pass4-assets-fail10-original-results-20261104';out.mkdir(mode=0o700)
put(out,'results.json',dict(status='ROOT_C11_UTILITY4_PASS_ASSETS_ORIGINAL_CASE10_FAILURE_RETAINED',groups=rows,terminal=dict(childReturnCode=1,ownProcessesAbsent=True,problems=[],timedOut=False,forcedKill=False),newOriginalRoots=t['newOriginalRoots'],originalCollectorFreeze=sha(collector/'freeze.json'),unrunGroups=t['unrunGroups'],all918PreviousOriginalBodiesUnchanged=True,globalCensuses=3,wholeNewOutputsTwiceEqual=True,featureQualified=False,nativeQualified=False,wholeQualified=False))
put(out,'actual-receipt-references.json',refs)
put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}))
print(json.dumps(dict(freeze=sha(out/'freeze.json'),receiptReferences=len(refs),groups=2)))
