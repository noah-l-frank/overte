"""Public installed route over one real loopback SDK and original UIKit models.

This declares candidate/target/OS/native producer seams. It supplies no page,
closure, touch, PNG, process/SDK retirement or worker-success observation.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
import os
import tempfile
import time
from types import SimpleNamespace
from unittest.mock import patch
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters import appium_adapter
from ios.adapters.installed_adapter import create_physical_adapter
from ios.adapters.tablet_web_feature import IOSTabletWebFeature
from ios.adapters.tablet_web_runtime import IOSTabletWebRuntime
from ios.adapters.tablet_web_api_entry import scope as actual_api_scope
from ios.self_tests.tablet_web_lifecycle_fixture import ExistingLifecycleAdapter
from ios.self_tests.tablet_web_paired_fixture import SELECTOR,ADAPTER
from ios.self_tests.tablet_web_terminal_fixture import TerminalPairedTabletFixture,production_actor


def actual_public_actor(inputs,clock,pipe):
    # Spawned process: keep the actual run() and same shared SDK. This test
    # scope adds real work60 around each original worker operation while its
    # declared native/host-boundary observation clocks stay untouched.
    actual=IOSTabletWebFeature.operation
    @contextmanager
    def bounded(feature):
        with actual_api_scope(time.monotonic),actual(feature):yield
    with patch.object(IOSTabletWebFeature,'operation',bounded):production_actor(inputs,clock,pipe)


class PublicTabletVertical:
    def __init__(self,test):
        self.fixture=TerminalPairedTabletFixture(test);self.b=self.fixture.boundary
        self.calls=[];self.factories=[]
        # Metadata outside ALL product roots and the immutable candidate tree.
        from ios.self_tests.retained_host_roots import retain_owned_root
        temporary=tempfile.TemporaryDirectory(prefix='tablet-public-context-');self.root=Path(temporary.name)
        retain_owned_root(temporary,expected_root=self.root);test.addCleanup(temporary.cleanup)
        artifacts=self.root/'candidate';artifacts.mkdir(mode=0o700);(artifacts/'declared-host-model').write_bytes(b'No compiled/native artifact qualification')
        target=self.b.target
        target.update(artifactMode='personal-team-preinstalled',_artifactMode='personal-team-preinstalled',
            normalScripts=dict(contractVersion=1,profile='ios-native-qt-scripts-v1'))
        # The existing fixture binding is an explicitly modeled selector, not
        # a hash derived from this target DTO or the declared artifact bytes.
        # Keep those old typed originals intact; do not re-label their binding.
        self.fixture.metadata['target']=deepcopy(target)
        store=PrivateFeatureState(self.b.root/'paired-input-metadata.json');store.write(self.fixture.metadata,store.read())
        model=ExistingLifecycleAdapter(self.b.root,self.fixture.metadata);outer=self
        class Base:
            IOS_PROBE_SCRIPT_PATH=appium_adapter.AppiumAdapter.IOS_PROBE_SCRIPT_PATH
            IOS_LAUNCH_STABILITY_SECONDS=appium_adapter.AppiumAdapter.IOS_LAUNCH_STABILITY_SECONDS
            def __init__(_self,platform):_self.platform=platform;_self.adapter_id='declared-tablet-host'
            @staticmethod
            def advertised_capabilities(_target):return ['app.stop','app.launch','app.process','lifecycle.background']
            def target(_self,selector):return model._target(selector)
            def state_path(_self,selector):return model.state_path(selector)
            def read_session(_self,selector):return model.read_session(selector)
            def save_session(_self,selector,value):return model.save_session(selector,value)
            def ensure_session(_self,selector):
                state=_self.read_session(selector);need(state is not None)
                return appium_adapter.WebDriver(target['serverUrl']),state['sessionId'],state
            def query_app_state(_self,*args):return appium_adapter.AppiumAdapter.query_app_state(_self,*args)
            def launch_ios_test_build(_self,*args,**kwargs):return appium_adapter.AppiumAdapter.launch_ios_test_build(_self,*args,**kwargs)
            def invoke(_self,*args,**kwargs):return appium_adapter.AppiumAdapter.invoke(_self,*args,**kwargs)
            def cleanup(_self,_selector):raise AssertionError('Typed complete Tablet archive must precede SDK fallback')
        candidate=dict(physicalHandoffVersion=1,bundleIdentity=deepcopy(self.fixture.metadata['bundle']),
            artifactIdentity={key:self.b.binding[key] for key in ('sourceRevision','artifactSha256')})
        self.adapter=create_physical_adapter(SimpleNamespace(artifact_root=str(artifacts)),Base,lambda _args:deepcopy(candidate))
        # Only candidate/target-origin producer seams are modeled. Actual
        # InstalledCodeBinding/FeatureObservation and all transport guards run.
        def source_scope(selector,session,state,selected):
            self.adapter._candidate_guard();return model._scope(selector,session,state,selected)
        self.adapter._scope=source_scope
        self.adapter._binding_store=model._binding_store
        def retired(selector,scope):
            self.adapter._candidate_guard(complete=True);return model._retired_candidate_scope(selector,scope)
        self.adapter._retired_candidate_scope=retired
        config=self.root/'feature-configuration.json';access=self.root/'fixture-reader.json'
        PrivateFeatureState(access).write(dict(fixtureAdapterAccessVersion=1,fixtureUrl=self.fixture.fixture_url,adapterToken=ADAPTER),None)
        value=dict(iosFeatureAdapterVersion=9,areas=['tablet-web'],fixtureConfig=str(access),graphics=None,create=None,emotes=None,
            worldNavigation=None,avatarPeople=None,worldWeb=None,tabletWeb=deepcopy(self.fixture.settings),
            emoteCoordinatorVersion=None,worldWebCoordinatorVersion=None,tabletWebCoordinatorVersion=1)
        PrivateFeatureState(config).write(value,None)
        test.enterContext(patch.dict(os.environ,OVERTE_IOS_FEATURE_ADAPTER_CONFIG=str(config)))
        actual_factory=IOSTabletWebRuntime._tablet_web_feature
        def factory(runtime,selector,run,*,role,client,settings):
            need(runtime.adapter is self.adapter and selector==SELECTOR and role=='primary')
            flow=actual_factory(runtime,selector,run,role=role,client=client,settings=settings)
            flow.monotonic,flow.epoch_ms,flow.sleep=self.b.mono,self.b.host,self.fixture.primary.sleep
            self.factories.append((selector,run,role));return flow
        test.enterContext(patch.object(IOSTabletWebRuntime,'_tablet_web_feature',factory))
    def invoke(self,operation,value):
        self.calls.append((operation,deepcopy(value)))
        result=self.adapter.invoke(SELECTOR,operation,value);need(self.adapter._operation is None);return result
