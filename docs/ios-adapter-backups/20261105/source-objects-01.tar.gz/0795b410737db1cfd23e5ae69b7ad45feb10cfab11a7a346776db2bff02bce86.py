"""Existing Source10 genuine constructors, with the additive paired factory.

Only SDK/native/render/HTTP producers remain inherited declared lower models.
Source counting delegates to the real existing fixture source constructors.
"""
from ios.adapters.snapshot_actor_pixel_runtime import IOSSnapshotActorPixelRuntime
from ios.self_tests.snapshot_actor_temporal_png_domain import TemporalActorPNGDomain
from ios.self_tests.snapshot_actor_pixel_domain import RUN,TICKET


class PairedPNGScopeDomain(TemporalActorPNGDomain):
    def __init__(self,case,*,same_target=False):
        super().__init__(case)
        self.source_calls=[]
        if same_target:
            # Contradictory lower selected-source binding BEFORE any role
            # owner/query/PFS original is born, never an edited live owner.
            self.actor.binding=dict(self.actor.binding,targetFingerprint=self.primary.ctx.binding['targetFingerprint'])
        domain=self;base=type(self.primary.runtime)
        class Primary(IOSSnapshotActorPixelRuntime,base):
            def _sources(self,selector):
                domain.source_calls.append(('primary',selector))
                return super()._sources(selector)
        self.primary.runtime=Primary(self.primary.runtime.adapter)
        base_actor=type(self.actor_runtime)
        class Actor(base_actor):
            def _sources(self,selector):
                domain.source_calls.append(('actor',selector))
                return super()._sources(selector)
        self.actor_runtime=Actor(self.actor_runtime.adapter)

    def paired(self,*,pixel_originals=True,actor_client=None):
        return self.primary.runtime.paired_pixel_originals('primary',self.actor_runtime,'actor',RUN,self.client(),
            self.actor_client if actor_client is None else actor_client,pixel_originals=pixel_originals,
            epoch_ms=self.primary.capture.epoch,monotonic=self.primary.capture.mono,sleep=self.primary.capture.sleep)
