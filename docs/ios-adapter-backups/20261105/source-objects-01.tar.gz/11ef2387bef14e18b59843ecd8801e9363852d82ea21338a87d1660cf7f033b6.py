"""PRIVATE alternative: immutable-only memo within ONE parser_identity call.

Mutable containers and opaque dictionary keys always run original data(); no
benefit is claimed for the measured mutable constants. No data() signature or
body changes. Create/discard this object inside parser_identity, never reuse.
"""
from types import FunctionType
from adapters.normal_ui import NativeUIError
from ios.adapters import snapshot_photos_end_round as original


class ConstantDescriptors:
    def __init__(self,namespace):
        self.namespace=namespace;self.fn=vars(namespace).get('data')
        if type(self.fn) is not FunctionType:raise NativeUIError('Parser data identity changed')
        self.pin=(self.fn.__code__,self.fn.__defaults__,self.fn.__kwdefaults__,self.fn.__closure__)
        self.entries={};self.stability={}
    def guard(self):
        fn=vars(self.namespace).get('data')
        if fn is not self.fn or any(current is not expected for current,expected in zip(
            (fn.__code__,fn.__defaults__,fn.__kwdefaults__,fn.__closure__),self.pin)):
            raise NativeUIError('Parser data identity changed')
    def immutable(self,value,depth=0):
        # Match the original primitive-before-depth-limit ordering. At depth6
        # original data returns identity; it never invokes a leaf callback.
        if type(value) in (str,int,float,bool,bytes,type(None)):return True
        if depth>=6:return True
        if type(value) not in (tuple,frozenset):return False
        key=(id(value),depth);found=self.stability.get(key)
        if found is not None:
            if found[0] is not value:raise NativeUIError('Descriptor identity changed')
            return found[1]
        valid=all(self.immutable(item,depth+1) for item in value)
        self.stability[key]=(value,valid);return valid
    def __call__(self,value):
        self.guard()
        if not self.immutable(value):
            # Keep every original str(key) side effect in original order.
            result=self.fn(value);self.guard();return result
        key=id(value);found=self.entries.get(key)
        if found is None:
            result=self.fn(value);self.guard();self.entries[key]=(value,result);return result
        if found[0] is not value:raise NativeUIError('Descriptor identity changed')
        self.guard();return found[1]


def parser_identity():
    """Review-only exact old return grammar; all _ORIGINAL verdicts fresh.

    A public integration must pin this new reader/helper class code in the
    existing parser_headers guard too. This is not an applied decoder.
    """
    original.need(original.IOSSnapshotPhotosOwner.capture is original._CAPTURE
        and original.IOSSnapshotCaptureOwner.archive.__func__ is original._ARCHIVE
        and original.SnapshotPhotosArchive.guard is original._GUARD)
    memo={};current={};constant=ConstantDescriptors(original)
    for name,(module,expected) in original._ORIGINAL.items():
        original.need(original.sys.modules.get(name) is module);signature=original.methods(vars(module),memo)
        original.need(signature==expected);current[name]=(module,signature)
    result=[]
    for name,module in sorted(original.modules().items()):
        previous=current.get(name)
        signature=previous[1] if previous is not None and previous[0] is module else original.methods(vars(module),memo)
        constants=tuple((key,constant(value)) for key,value in sorted(vars(module).items())
            if key.isupper() and key not in ('_ORIGINAL','_BASELINES','_DEPENDENCIES'))
        result.append((name,id(module),signature,constants))
    return tuple(result)
