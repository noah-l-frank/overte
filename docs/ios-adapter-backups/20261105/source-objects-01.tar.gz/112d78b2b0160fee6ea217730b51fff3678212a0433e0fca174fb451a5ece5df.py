from pathlib import Path
import ast,hashlib,json,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-canonical4-sync-host-root-preparation-20261029/66-canonical-child4';FIX=T/'lifecycle-original-owner-normal-child-first-bind-native-clock-overlay-20261029';P=T/'lifecycle-original-owner-canonical4-first-bind-clock-root-preparation-20261029';S=P/'67-canonical-child4';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();report=json.loads((B/'root-run-first/report.json').read_text());summary=json.loads((B/'actual-source-raise-summary-first.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==10 and report['allPinsEqual'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses'];assert summary['ownedToolFreed'] and not summary['dropped'] and not summary['writeFailures']
for n,d in json.loads((FIX/'freeze.json').read_text())['files'].items():assert H(FIX/n)==d
P.mkdir(mode=0o700);S.mkdir(mode=0o700)
for n,d in json.loads((B/'freeze.json').read_text())['files'].items():
 assert H(B/n)==d;dest=S/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/n,dest)
shutil.copyfile(FIX/'candidate/normal_child_fixture.py',S/'normal_child_fixture.py');shutil.copyfile(FIX/'test-only1.diff',S/'test-only-first-bind-native-clock.diff')
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((B/'prior-retained-original-pins.json').read_text());assert sum('sha256' in v for v in prior.values())==3316;root=B/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==10
for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
for n in ['report.json','thread-report.json','process-binding.json']:p=B/'root-run-first'/n;prior[str(p)]=pin(p)
for n in ['actual-source-raise-events-first.jsonl','actual-source-raise-summary-first.json']:p=B/n;prior[str(p)]=pin(p)
assert sum('sha256' in v for v in prior.values())==3331;(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n')
plan=json.loads((S/'run-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_CANONICAL4_FIRST_BIND_CLOCK_FIX');plan['privateFiles']['normal_child_fixture.py']=H(S/'normal_child_fixture.py');(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n');stage=json.loads((S/'source-manifest.json').read_text());changes=[]
for row in stage['sourcePaths']:
 rel=row['path'];actual=H(R/rel)
 if actual!=row['candidateSHA256']:
  dest=S/'actual-current-dependency/repo'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,dest);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(dest),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
stage.update(stage=67,name=S.name,status='PRIVATE_UNRUN_CANONICAL4_FIRST_BIND_CLOCK_FIX',sourceDeltaPaths=[],exactPublicMutationPlan='NONE. CanonicalSource2 alreadypublic59f5/791b andown3 remaincurrent; changeonly private model nativeclock at initialbind.');stage['orderedParentFreezes'][FIX.name]=H(FIX/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
(S/'clone-provenance-first-bind-clock.json').write_text(json.dumps(dict(parent66Freeze=H(B/'freeze.json'),actual66FailedSetupReportSHA256=H(B/'root-run-first/report.json'),overlayFreeze=H(FIX/'freeze.json'),source2AndModel4AssertionsUnchanged=True,firstBindNewNativeClockProducer=True,initialSeconds=90,killAfterSeconds=5,realRoots=12,actualOldOriginalFiles=3285,actualReports=36,actualDiagnosticFiles=10,totalPriorPinnedFiles=3331,otherDependencyChanges=changes,executed=False),indent=2)+'\n');(S/'README-first-bind-clock.txt').write_text('Root67 same4/90+kill5/12realTD/sameRAISEobserver, Source2/old18 assertions unchanged. OnlyprospectiveindependentNativeClock producer selectedbeforeFIRST Installed.bind, matching alreadyprospectiveBundle epoch; oldconstant20000 waswrongbeforeKeyboardhookbirth. NO oldOriginalsretimed/validatorloosened/Sourcechanged.10actual66failedsetupfiles+3reports+2diag appended=3331priorfiles (3285originals+36reports+10diag). Sourcepublic59f5/791b+own3 unchanged. Old64/65UNRUN66ERRORretained. Noagentimports/tests/PUB.\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(stage=str(S),parentFreeze=H(P/'freeze.json'),stageFreeze=H(S/'freeze.json'),fixtureSHA256=H(S/'normal_child_fixture.py'),changes=changes,priorFiles=3331),indent=2))
