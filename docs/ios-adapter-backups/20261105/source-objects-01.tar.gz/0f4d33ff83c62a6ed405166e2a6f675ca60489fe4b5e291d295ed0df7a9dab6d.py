"""Actual main-thread lock + independent worker admission; native/SDK MODELS."""
import threading
from unittest.mock import patch
from normal_child_fixture import NormalChildFixture

class TerminalCanonicalReadScopeModels(NormalChildFixture):
    async def test_changed_selected_ipa_before_worker_canonical_read_refuses_original_without_borrowing_main_thread_lock(self):
        await self.owner.act(seconds=12);await self.owner.observe()
        connection=self.owner._original_child;original=self.runtime._native_passive_world_reference
        main=threading.get_ident();seen=[];artifact=self.normal.d.f.f.f.artifact
        before=artifact.read_bytes();self.owner.history.lock.assert_held()
        def acquire_on_original_thread(selector,source,run,phase,result,value):
            seen.append((threading.get_ident(),source is None))
            self.assertIsNone(source);self.assertNotEqual(main,threading.get_ident())
            # Actual newly selected physical host IPA is changed AFTER the
            # main-thread admission, BEFORE worker's canonical _sources call.
            # Source/native originals and original child IPA remain untouched.
            artifact.write_bytes(before+b'declared-foreign-IPA')
            return original(selector,source,run,phase,result,value)
        with patch.object(self.runtime,'_native_passive_world_reference',new=acquire_on_original_thread):
            with self.assertRaises((RuntimeError,ValueError)):await self.owner.release()
        self.assertEqual(1,len(seen));self.assertEqual(True,seen[0][1]);self.assertNotEqual(main,seen[0][0])
        self.owner.history.lock.assert_held() # Original lock still owned on THIS thread.
        self.assertEqual(30,len(self.commands));self.assertEqual(6,len(self.collection()['cuts']))
        self.assertIsNone(self.owner.state['released']);self.assertEqual(2,len(self.owner.state['frames']))
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        self.assertEqual(before+b'declared-foreign-IPA',artifact.read_bytes())
        self.assertEqual(before,self.archive.path.read_bytes())
