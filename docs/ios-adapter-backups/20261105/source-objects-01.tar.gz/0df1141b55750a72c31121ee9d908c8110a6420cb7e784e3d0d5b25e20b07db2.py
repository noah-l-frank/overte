"""One bounded historical read; keep independent source and original pins."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,time

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
CHILD=HERE/'runner.py'
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking',
       'libraries/qml','libraries/graphics','libraries/image','libraries/shared',
       'libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system',
       'interface/resources/qml')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
BASE=REPO/'.ios-host-tmp/avatar-genuine-actor-terminal-two-refs-launch03-20261027'
PINS=BASE/'timeout-poststop-originals-census.json'

def save(name,value):
    (HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')

def pin(path):
    first=path.lstat()
    row={key:getattr(first,key) for key in FIELDS}
    if stat.S_ISREG(first.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    else:assert stat.S_ISDIR(first.st_mode)
    last=path.lstat()
    assert all(getattr(first,key)==getattr(last,key) for key in FIELDS),str(path)
    return row

def sources():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}
    paths.update((Path(__file__).resolve(),CHILD,HERE/'plan.json'))
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}

original_roots=[Path(name) for name in json.loads(PINS.read_bytes())['retainedRoots']]
assert len(original_roots)==5 and all(path.is_relative_to(BASE) for path in original_roots)

def originals():
    return {str(path):pin(path) for root in original_roots for path in (root,*sorted(root.rglob('*')))}

before=sources();original_before=originals()
save('supervisor-sources-before.json',before);save('supervisor-originals-before.json',original_before)
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()
task_env=os.environ.copy()
task_env.update(TMPDIR=str(REPO/'.ios-host-tmp'),PYTHONDONTWRITEBYTECODE='1',
                PYTHONPATH='.:tests/device:tests/device/self_tests:tests/device/ios/self_tests',
                AVATAR_SEGMENT_SOURCE_REVISION=revision)
print('SOURCE_PINS',len(before),'ORIGINAL_NODES',len(original_before),'HEAD',revision,flush=True)
started=time.monotonic()
with (HERE/'actual-first.log').open('w') as stream:
    task=subprocess.Popen(['timeout','--signal=TERM','--kill-after=5s','180s',sys.executable,str(CHILD)],
                          cwd=REPO,env=task_env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    proc=Path('/proc')/str(task.pid)
    body=(proc/'stat').read_text();parts=body[body.rfind(')')+2:].split()
    binding=dict(timeoutPid=task.pid,startTicks=int(parts[19]),processGroup=int(parts[2]),
                 session=int(parts[3]),sourceRevision=revision,outerSeconds=180,killAfterSeconds=5)
    save('supervisor-actual-process.json',binding);print('ACTUAL_TIMEOUT',json.dumps(binding),flush=True)
    code=task.wait()
after=sources();original_after=originals()
save('supervisor-sources-after.json',after);save('supervisor-originals-after.json',original_after)
changed_sources=sorted(key for key in set(before)|set(after) if before.get(key)!=after.get(key))
changed_originals=sorted(key for key in set(original_before)|set(original_after) if original_before.get(key)!=original_after.get(key))
report=dict(exitCode=code,elapsedSeconds=time.monotonic()-started,sourcePins=len(after),
            originalNodes=len(original_after),changedSources=changed_sources,changedOriginals=changed_originals,
            wholeFeatureQualified=False,livePublisherQualified=False)
save('supervisor-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
raise SystemExit(code if not changed_sources and not changed_originals else 98)
