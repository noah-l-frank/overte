"""Profile9 historical copied role2; genuine original grammar, no live facade.

The old Feature8 decoder is preserved. This distinct constructor duplicates
its original checks with exact9/PROFILE9 admission. It cannot grant legacy
copied ownership, Stop, SDK deletion or overall End.
"""
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import context
from adapters.script_feature.history import pack,unpack,same
from feature_journeys.contract import arguments,identifier
from ios.adapters.emote_callback_terminal import PROFILE9
from ios.adapters.emote_target_pair import original as target_pair,selected
from ios.adapters.graphics_configuration import settings
from ios.adapters.peer_admission import validate as admitted

class Profile9RoleState:
    """Parsed Feature9 payload only; never masquerades as a live Feature."""
    def __init__(self,value,*,store,run,role,locks):
        exact(value,{'iosEmoteFeatureVersion','runId','role','artifactRoot','fixtureUrl','imagePolicy','payload','targetPair','callbackProfile'})
        need(type(value['iosEmoteFeatureVersion']) is int and value['iosEmoteFeatureVersion']==9
            and same(value['callbackProfile'],PROFILE9) and value['runId']==run and value['role']==role)
        self.run,self.role,self.store=identifier(run),role,store
        self.lock,self.primary_lock=locks[role],locks['primary']
        self.lock.assert_held();self.primary_lock.assert_held()
        pair=target_pair(value['targetPair']);self.configured_pair=selected(pair)
        need(all(str(locks[key].path.parent)==pair[key+'StateRoot'] for key in ('primary','actor')))
        policy=settings(dict(artifactRoot=value['artifactRoot'],imagePolicy=value['imagePolicy']))
        self.root,self.policy=Path(policy['artifactRoot']),policy['imagePolicy']
        need(str(self.root)==pair[role+'ArtifactRoot'])
        self.fixture_url=value['fixtureUrl'];suffix='/runs/'+run+'/'
        need(type(self.fixture_url) is str and self.fixture_url.endswith(suffix))
        self.server_url=self.fixture_url[:-len(suffix)]
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0]
        need(value['payload']==pack([state]))
        exact(state,{'phase','binding','primaryBinding','actorAdmission','phaseInstance','initialTicket','lastCall','inputBarrier','cleanup','retirement'})
        need(state['phase']=='cleaned');context(state['binding']);context(state['primaryBinding'])
        identifier(state['phaseInstance']);identifier(state['initialTicket'])
        if role=='primary':
            actor=admitted(state['actorAdmission'],state['binding'])
            need(same(state['binding'],state['primaryBinding']) and same(actor,pair['actorBinding']))
        else:need(state['actorAdmission'] is None and same(state['binding'],pair['actorBinding']))
        need(same(state['primaryBinding'],pair['primaryBinding']))
        if state['lastCall'] is not None:
            call=arguments('feature.emotes.act',state['lastCall'])
            need(call['runId']==run and call['fixtureUrl']==self.fixture_url)
        if state['inputBarrier'] is not None:
            exact(state['inputBarrier'],{'index','sha256'});need(integer(state['inputBarrier']['index'],1))
        need(type(state['cleanup']) is list and 1<=len(state['cleanup'])<=128
            and type(state['retirement']) is dict)
        self.state,self.previous=deepcopy(state),deepcopy(value)
        need(same(store.read(),value))

    def bound(self):
        self.lock.assert_held();self.primary_lock.assert_held()
        need(same(self.store.read(),self.previous))
        return True
