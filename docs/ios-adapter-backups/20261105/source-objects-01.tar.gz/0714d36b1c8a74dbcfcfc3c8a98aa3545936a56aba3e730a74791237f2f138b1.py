"""One explicit NEW five-case group metadata assembler; no target/product import.

Invocation requires a later explicit quiet Root context and exact external
module manifest. Merely importing this module performs no work.
"""
from pathlib import Path
import argparse,builtins,hashlib,importlib.machinery,importlib.util,json,os,shutil,stat,sys

REPO=Path(__file__).resolve().parents[2]
CONTROLLER=Path(__file__).resolve().parent
CONTROLLER_SHA=None
PROPOSAL=REPO/'.ios-host-tmp/chat-offline-send-no-replay-source1-private-20261104'
PROPOSAL_SHA='b1df990cbb9187fe6982cafe0a9e4065283eb541c7f30860162afd624a390f9b'
HISTORICAL=REPO/'.ios-host-tmp/lifecycle-moving-primary-first1-root687-source4-controller6-final-preparation-20261104'
HISTORICAL_SHA='d0a91ab61a8e578fadc17c4fd9f9ecf17c81ccc2751fb617e5e29eac80f95516'
GLOBAL_HELPER_SHA='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
C6=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller6-no-site-startup-code-preparation-20261104'
C6_SHA='1a517b07d8c888d79cbfe86116def12a8d65b1f9a24f971bde4afa4b5caa4fea'
ASSEMBLER4=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller6-root-assembler4-no-site-code-only-20261104'
ASSEMBLER4_SHA='2b2d014abc83ed3a1f1bea32dd1f9dde32eb38c20b256c3c8fc0797b7ea62d33'
C6_PREP=REPO/'.ios-host-tmp/chat-offline-initial4-prepared-root693-head7c18-assembler4-20261104'
C6_PREP_SHA='cc48741c1b09b51820fd971857918b1614b5fa3dddbfbca9c64119bb5dd1aecd'
C6_PLAN_SHA='d2f00df902aa0071f3458950525129b73d46e52d527db69d94184c21297c10a6'
C6_FAILURE=REPO/'.ios-host-tmp/root-chat-offline-initial4-first-import-refusal-finalizer-source-read-refusal-results-20261104'
C6_FAILURE_SHA='4a7110f0aef1ed025525065f9997fb0f46c0ad1a1d73161ec959beebf5aaae6a'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def excluded(path):return any(p in('site-packages','dist-packages')for p in path.parts)
def hex40(value):return type(value)is str and len(value)==40 and all(c in'0123456789abcdef'for c in value)


def checked_packet(directory,leaf,expected,pin):
    directory=Path(directory);assert sha(directory/leaf)==expected
    rows={str(directory/leaf):pin(directory/leaf)}
    packet=load(directory/leaf)
    files=packet['files']
    items=((r['path'],r)for r in files)if type(files)is list else files.items()
    for name,row in items:
        path=directory/name
        assert path.resolve(strict=True)==path and path.is_relative_to(directory)
        digest=row if type(row)is str else row['sha256']
        assert sha(path)==digest
        rows[str(path)]=pin(path)
    return rows


def checked_c6_retention(pins, baseline, pin):
    # These are closed historical metadata and actual failures, never current
    # source authority or a successful four-case/Node/cleanup qualification.
    for directory,leaf,digest in (
        (C6,'source-freeze.json',C6_SHA),
        (ASSEMBLER4,'source-freeze.json',ASSEMBLER4_SHA),
        (C6_PREP,'freeze.json',C6_PREP_SHA),
        (C6_FAILURE,'freeze.json',C6_FAILURE_SHA)):
        pins.update(checked_packet(directory,leaf,digest,pin))
    assert sha(C6_PREP/'plan.json')==C6_PLAN_SHA
    previous_plan=load(C6_PREP/'plan.json')
    assert previous_plan['controllerSourceFreeze']==C6_SHA
    assert previous_plan['head']=='7c18ac7c24270419b3f8cc5fdd3bb24ef4ee70f9'
    old_custody=previous_plan['globalCustody']
    old_baseline=Path(old_custody['baselinePath'])
    assert old_baseline==C6_PREP/'global-original-corpus-baseline.json'
    assert sha(old_baseline)==old_custody['baselineSha256']
    historical=load(old_baseline)
    assert len(historical)==693  # Historical fact, never a later count cap.
    assert set(historical)<=set(baseline)and all(baseline[name]==rows for name,rows in historical.items())
    receipt=load(C6_FAILURE/'results.json')
    assert receipt['controllerFreeze']==C6_SHA and receipt['preparationFreeze']==C6_PREP_SHA
    assert receipt['planSha256']==C6_PLAN_SHA and receipt['actualStartedCases']==0 and receipt['actualPassedCases']==0
    assert receipt['actualGenuineTemporaryDirectories']==0 and receipt['terminal']['childReturnCode']==1
    assert receipt['actualOwnedProcessAbsenceEstablished']is True
    assert receipt['all693OldOriginalBodiesUnchanged']is True and receipt['allPhysicalPinsUnchanged']is True
    assert receipt['standardCleanupQualified']is False and receipt['all27PortsRestoredQualified']is False
    assert receipt['actualNodeBirthQualified']is False and receipt['positiveFourNodeAbsenceQualified']is False
    child=REPO/'.ios-host-tmp/chat-offline-own4-root693-head7c18-first-20261104'
    assert receipt['newOriginalRoots']==[str(child),str(child/'temporary'),str(child.with_name(child.name+'-outer'))]
    assert all(name in baseline for name in receipt['newOriginalRoots'])
    references=load(C6_FAILURE/'actual-receipt-references.json')
    for row in references.values():
        path=Path(row['path'])
        assert path.is_absolute()and path.resolve(strict=True)==path and sha(path)==row['sha256']
        assert path.is_relative_to(child)or path.is_relative_to(child.with_name(child.name+'-outer'))
        pins[str(path)]=pin(path)
    declared=load(CONTROLLER/'readonly-own-public-source-verification.json')
    assert set(declared['paths'])==set(receipt['metadataSourcePathFalsePositives'])
    for name,row in declared['paths'].items():
        assert row['sha256']==previous_plan['physicalPins'][name]['sha256']
    return historical



def checked_c7_retention(pins, baseline, pin):
    c7=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller7-absence-own-source-read-independent-drain-code-preparation-20261104'
    as5=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller7-root-assembler5-absence-own-source-read-failure-retention-code-only-20261104'
    prep=REPO/'.ios-host-tmp/chat-offline-initial4-prepared-root697-head7c18-assembler5-20261104'
    failed=REPO/'.ios-host-tmp/root-chat-offline-c7-first-body-pass-origin-accounting-refusal-clean-results-20261104'
    probe=REPO/'.ios-host-tmp/root-chat-fileless-stdlib-xml-probe-source1-20261104'
    for directory,leaf,digest in (
        (c7,'source-freeze.json','8d398997e15de8cb480f47a514026348c37ed12617c9b2b5deb5a17a2906a366'),
        (as5,'source-freeze.json','1871a458deb49296a8421923520555bca4f1f7074dc391ccad6145210919c2f5'),
        (prep,'freeze.json','2292276ddb3aff1922a57353243d8b969d1c1c9b9eb58188db842af4bf5345ad'),
        (failed,'freeze.json','0670b8fb97d686b49d4eae9f6745c4c88b0c909db3af413f27072a30a8027e25'),
        (probe,'freeze.json','c5d96a6606276955270560fbf1ad102ab09dc751c33843f480ed120d0a62d4e5')):
        pins.update(checked_packet(directory,leaf,digest,pin))
    previous=load(prep/'plan.json')
    assert sha(prep/'plan.json')=='7784897601db83c38eea739cec77e2c67b061277acaad4ac56b91f3b5ebdc137'
    assert previous['controllerSourceFreeze']=='8d398997e15de8cb480f47a514026348c37ed12617c9b2b5deb5a17a2906a366'
    historical=load(prep/'global-original-corpus-baseline.json')
    assert len(historical)==697  # Saved historical scope, not a current count cap.
    assert set(historical)<=set(baseline)and all(baseline[name]==rows for name,rows in historical.items())
    receipt=load(failed/'results.json')
    assert receipt['status']=='ACTUAL_CHAT_C7_FIRST_BODY_PASS_AFTER_CASE_FILELESS_MODULE_ORIGIN_REFUSAL_REMAINING3_UNRUN'
    assert receipt['actualStartedCases']==receipt['actualBodyPassedCases']==1
    assert receipt['actualQualifiedCases']==0 and receipt['remainingSelectedCasesUnrun']==3
    assert receipt['actualGenuineTemporaryDirectories']==3 and receipt['actualNodeBirths']==1
    assert receipt['actualNodeEndAndZeroSubscriptions']and receipt['actualNodeAbsent']and receipt['actualNodeStreamsClosed']
    assert receipt['all27PortsAndCioRestored']and not receipt['wholeFourStandardCleanupQualified']and not receipt['wholeQualified']
    assert receipt['all697OldOriginalBodiesUnchanged']and receipt['all8998PhysicalPinsUnchanged']
    assert receipt['terminal']['ownProcessesAbsent']and receipt['terminal']['childReturnCode']==1
    child=REPO/'.ios-host-tmp/chat-offline-own4-root697-head7c18-c7-first-20261104'
    assert receipt['newOriginalRoots']==[str(child),str(child/'temporary'),str(child.with_name(child.name+'-outer'))]
    assert all(name in baseline for name in receipt['newOriginalRoots'])
    for row in load(failed/'actual-receipt-references.json').values():
        path=Path(row['path']);assert path.resolve(strict=True)==path and sha(path)==row['sha256']
        assert path.is_relative_to(child)or path.is_relative_to(child.with_name(child.name+'-outer'))
        pins[str(path)]=pin(path)
    observed=load(probe/'results.json');terminal=load(probe/'terminal.json')
    assert terminal['newOriginalRoots']==[str(probe)]and str(probe)in baseline
    assert terminal['terminal']['ownProcessesAbsent']and terminal['terminal']['childReturnCode']==0
    assert observed['productImports']==observed['nodeExecutions']==observed['targets']==observed['globalCensuses']==0
    assert observed['sourceOfC7UnnamedFailureEstablished']is False
    assert [row['name']for row in observed['newFilelessSpecLessModules']]==['pyexpat.errors','pyexpat.model']
    assert all(row['ownerAttributeIdentity']for row in observed['newFilelessSpecLessModules'])
    parent=Path(observed['actualExtensionParent']);actual=pin(parent)
    assert actual==previous['physicalPins'][str(parent)]and actual['sha256']==observed['actualParentSha256']
    pins[str(parent)]=actual
    return historical



def checked_c8_retention(pins, baseline, pin):
    c8=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller8-genuine-expat-child-origins-code-preparation-20261104'
    as6=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller8-root-assembler6-expat-child-c7-retention-code-only-20261104'
    prep=REPO/'.ios-host-tmp/chat-offline-initial4-prepared-root701-head7c18-assembler6-20261104'
    failed=REPO/'.ios-host-tmp/root-chat-offline-c8-first-body-pass-expat-wrapper-alias-refusal-clean-results-20261104'
    probe=REPO/'.ios-host-tmp/root-chat-fileless-stdlib-expat-wrapper-probe-source2-20261104'
    for directory,leaf,digest in (
        (c8,'source-freeze.json','35f2ea03dc5b25a9c0493ec5215354b353c3f4274df30967c06456458c78f13b'),
        (as6,'source-freeze.json','658ae1bc9209e5101e768fc9dfb2a76aed659d6d0df950b1caf977b7596eb805'),
        (prep,'freeze.json','c8cfc9121275b5c1ad910268de016ab65a9ac42d4af83cee67d05bd534ffd156'),
        (failed,'freeze.json','829e152d5346fd5a37d71cd34fa8a6ea0562906be801554172ca04d798e2e96f'),
        (probe,'freeze.json','009034cca145412004d81e8ac65be747528d420c91815a703fe47c664ed13fb9')):
        pins.update(checked_packet(directory,leaf,digest,pin))
    previous=load(prep/'plan.json')
    assert sha(prep/'plan.json')=='a6b1349cfb2448dc6cf191c3f550b6f29c0121527731dd73e050a5c879638956'
    assert previous['controllerSourceFreeze']=='35f2ea03dc5b25a9c0493ec5215354b353c3f4274df30967c06456458c78f13b'
    historical=load(prep/'global-original-corpus-baseline.json')
    assert len(historical)==701  # Historical scope, never a later Root count cap.
    assert set(historical)<=set(baseline)and all(baseline[name]==rows for name,rows in historical.items())
    receipt=load(failed/'results.json')
    assert receipt['status']=='ACTUAL_CHAT_C8_FIRST_BODY_PASS_AFTER_CASE_EXACT_EXPAT_WRAPPER_ALIAS_REFUSAL_REMAINING3_UNRUN'
    assert receipt['actualStartedCases']==receipt['actualBodyPassedCases']==1
    assert receipt['actualQualifiedCases']==0 and receipt['remainingSelectedCasesUnrun']==3
    assert receipt['actualGenuineTemporaryDirectories']==3 and receipt['actualNodeBirths']==1
    assert receipt['actualNodeEndAndZeroSubscriptions']and receipt['actualNodeAbsent']and receipt['actualNodeStreamsClosed']
    assert receipt['all27PortsAndCioRestored']and not receipt['wholeFourStandardCleanupQualified']and not receipt['wholeQualified']
    assert receipt['all701OldOriginalBodiesUnchanged']and receipt['all9102PhysicalPinsUnchanged']
    assert receipt['actualFailedFilelessModuleName']=='xml.parsers.expat.model'
    assert receipt['terminal']['ownProcessesAbsent']and receipt['terminal']['childReturnCode']==1
    child=REPO/'.ios-host-tmp/chat-offline-own4-root701-head7c18-c8-first-20261104'
    assert receipt['newOriginalRoots']==[str(child),str(child/'temporary'),str(child.with_name(child.name+'-outer'))]
    assert all(name in baseline for name in receipt['newOriginalRoots'])
    for row in load(failed/'actual-receipt-references.json').values():
        path=Path(row['path']);assert path.resolve(strict=True)==path and sha(path)==row['sha256']
        assert path.is_relative_to(child)or path.is_relative_to(child.with_name(child.name+'-outer'))
        pins[str(path)]=pin(path)
    observed=load(probe/'results.json');terminal=load(probe/'terminal.json')
    assert terminal['newOriginalRoots']==[str(probe)]and str(probe)in baseline
    assert terminal['terminal']['ownProcessesAbsent']and terminal['terminal']['childReturnCode']==0
    assert observed['productImports']==observed['nodeExecutions']==observed['targets']==observed['globalCensuses']==0
    assert observed['sourceOfC7UnnamedFailureEstablished']is False
    assert observed['aliasesAreTheSameOriginalChildReceivers']and observed['originalC8FailedNameIsActualWrapperAlias']
    assert [row['name']for row in observed['newFilelessSpecLessModules']]==['pyexpat.errors','pyexpat.model','xml.parsers.expat.errors','xml.parsers.expat.model']
    assert all(row['ownerAttributeIdentity']and row['wrapperAttributeIdentity']for row in observed['newFilelessSpecLessModules'])
    for path_key,sha_key in(('actualExtensionParent','actualParentSha256'),('actualPythonWrapper','actualWrapperSha256')):
        path=Path(observed[path_key]);actual=pin(path)
        assert actual==previous['physicalPins'][str(path)]and actual['sha256']==observed[sha_key]
        pins[str(path)]=actual
    return historical



def checked_c9_retention(pins, baseline, pin):
    c9=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller9-genuine-expat-wrapper-aliases-code-preparation-20261104'
    as7=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller9-root-assembler7-expat-wrapper-c8-retention-code-only-20261104'
    prep=REPO/'.ios-host-tmp/chat-offline-initial4-prepared-root705-head7c18-assembler7-20261104'
    actual=REPO/'.ios-host-tmp/root-chat-offline-c9-four-declared-gates-pass-source-cache-execution-limit-results-20261104'
    for directory,leaf,digest in (
        (c9,'source-freeze.json','5d3c7973df44c8f8026ac10e14d4453965b9a602b50550339bb0cd5a79d916a2'),
        (as7,'source-freeze.json','0eeb08f49c311545868b08aa513c46e4d6e8f6b378b684cd68f538f3dca15f7d'),
        (prep,'freeze.json','c6f118b0c4e4f0dde4630289c4dd2c020267407ae8ea1b67e82e6c3df59ebe6a'),
        (actual,'freeze.json','d76f16861adb509a6ae9d44891a53cdc3e08c3a6566e07e9767d9fcd9b2f8c27')):
        pins.update(checked_packet(directory,leaf,digest,pin))
    previous=load(prep/'plan.json')
    assert sha(prep/'plan.json')=='b828b632d99b1005f733df04dcd7cfa1388274c21d93c72044e019ed07715fb1'
    assert previous['controllerSourceFreeze']=='5d3c7973df44c8f8026ac10e14d4453965b9a602b50550339bb0cd5a79d916a2'
    historical=load(prep/'global-original-corpus-baseline.json')
    assert len(historical)==705  # Saved historical scope, not a later count cap.
    assert set(historical)<=set(baseline)and all(baseline[name]==rows for name,rows in historical.items())
    receipt=load(actual/'results.json');limit=load(actual/'source-execution-limitation.json')
    assert receipt['status']=='ACTUAL_CHAT_C9_ORIGINAL4_PASS_ALL_DECLARED_RESOURCE_ORIGIN_GATES_SOURCE_CACHE_EXECUTION_LIMIT_RECORDED'
    assert receipt['actualStartedCases']==receipt['actualBodyPassedCases']==receipt['actualDeclaredControllerGatesPassedCases']==4
    assert receipt['actualFullSourceExecutionQualifiedCases']==0 and receipt['sourceBytesToActuallyExecutedPythonCodeEstablished']is False
    assert receipt['remainingInitialSelectedCasesUnrun']==0 and receipt['otherSource1TenCasesUnrun']
    assert receipt['actualGenuineTemporaryDirectories']==12 and receipt['actualNodeBirths']==4
    assert receipt['actualAllNodeEndZeroSubscriptionsStreamCloseAbsence']and receipt['all27PortsAndCioRestored']
    assert receipt['actualRegisteredStandardCleanupsDrained']and receipt['independentNestedCallbackExecutionCountRecorded']is False
    assert receipt['actualLoadedOriginSnapshots']==7 and not receipt['wholeQualified']and not receipt['nativeQualified']
    assert receipt['all705OldOriginalBodiesUnchanged']and receipt['all9208PhysicalPinsUnchanged']
    assert receipt['terminal']['ownProcessesAbsent']and receipt['terminal']['childReturnCode']==0
    assert receipt['outerTerminal']['status']=='PASS'and not receipt['terminal']['problems']
    assert limit['sourceBytesToActuallyExecutedPythonCodeEstablished']is False and limit['actualCacheTamperingObserved']is False
    assert limit['pythonNoBytecodeWriteDoesNotDisableCacheReads']
    std=Path(limit['actualStdlibGetCodeSource']);current=pin(std)
    assert current==previous['physicalPins'][str(std)]and current['sha256']==limit['actualStdlibSourceSha256']
    pins[str(std)]=current
    child=REPO/'.ios-host-tmp/chat-offline-own4-root705-head7c18-c9-first-20261104'
    assert receipt['newOriginalRoots']==[str(child),str(child/'temporary'),str(child.with_name(child.name+'-outer'))]
    assert all(name in baseline for name in receipt['newOriginalRoots'])
    for row in load(actual/'actual-receipt-references.json').values():
        path=Path(row['path']);assert path.resolve(strict=True)==path and sha(path)==row['sha256']
        assert path.is_relative_to(child)or path.is_relative_to(child.with_name(child.name+'-outer'))
        pins[str(path)]=pin(path)
    return historical


# Only these genuine controller definition modules need local sibling imports.
# Their actual approved fresh source bytes execute through held Python compile/
# exec; SourceFileLoader supplies real metadata but never consults a .pyc here.
_COMPILE=builtins.compile
_EXEC=builtins.exec
_ABSENT=object()


class ControllerDefinitions:
    def __init__(self):
        self.saved={};self.created={}

    def __enter__(self):
        assert builtins.compile is _COMPILE and builtins.exec is _EXEC
        frozen=load(CONTROLLER/'source-freeze.json')['files']
        try:
            for name in('host_common','source_execution_readiness','group_selection','prerequisites','metadata'):
                path=CONTROLLER/(name+'.py')
                assert path.resolve(strict=True)==path and not path.is_symlink()
                before=path.lstat()
                assert stat.S_ISREG(before.st_mode)and before.st_nlink==1
                def identity(info):
                    return(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns)
                fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
                try:
                    assert identity(os.fstat(fd))==identity(before)
                    chunks=[]
                    while True:
                        chunk=os.read(fd,65536)
                        if not chunk:break
                        chunks.append(chunk)
                    raw=b''.join(chunks)
                    assert identity(os.fstat(fd))==identity(before)==identity(path.lstat())
                    assert len(raw)==before.st_size and hashlib.sha256(raw).hexdigest()==frozen[path.name]['sha256']
                finally:os.close(fd)
                assert builtins.compile is _COMPILE and builtins.exec is _EXEC
                spec=importlib.util.spec_from_file_location(name,path)
                assert type(spec.loader)is importlib.machinery.SourceFileLoader
                module=importlib.util.module_from_spec(spec)
                self.saved[name]=sys.modules.get(name,_ABSENT)
                sys.modules[name]=module;self.created[name]=module
                _EXEC(_COMPILE(raw,str(path),'exec',dont_inherit=True,optimize=-1),vars(module))
                assert sys.modules[name]is module and module.__spec__ is spec and module.__file__==str(path)
                assert identity(path.lstat())==identity(before)and sha(path)==frozen[path.name]['sha256']
            return self.created['metadata']
        except BaseException:
            self.__exit__(None,None,None)
            raise

    def __exit__(self,kind,value,traceback):
        changed=[]
        for name,module in self.created.items():
            if sys.modules.get(name)is not module:changed.append(name)
        for name,previous in self.saved.items():
            if previous is _ABSENT:sys.modules.pop(name,None)
            else:sys.modules[name]=previous
        assert not changed,'Controller metadata alias changed: '+repr(changed)
        assert builtins.compile is _COMPILE and builtins.exec is _EXEC
        return False


def checked_five_prerequisites(M,pins):
    contract=dict(readiness=dict(path=str(M.require_real_prerequisites.__globals__['READINESS']/'freeze.json'),
        sha256='839195fe485a5a96845bb93e05e3fb1a6831490f3257d73cd2b2d7a3fba968a0'))
    joined=M.require_real_prerequisites(contract)
    for name,digest in joined['physicalFiles'].items():
        assert sha(name)==digest;pins[name]=M.pin(name)
    # Keep the original WIP controller and source-only assembler physically,
    # without changing their prospective/blocked status or historical pins.
    for directory,expected in(
        (REPO/'.ios-host-tmp/chat-offline-source1-additional5-controller2-real-joint-readiness-code-preparation-20261104','7f70549910a5e47f8260ca6e79a2b09323c2cd6e4e46acb30b6b589f99a0f2bd'),
        (REPO/'.ios-host-tmp/chat-offline-source1-additional5-controller2-root-assembler2-real-readiness-code-only-20261104','2dc2fc2d89726073741abd3decfed8b92117d29d191523518683ec8bc42b8492'),
        (REPO/'.ios-host-tmp/chat-offline-source1-additional5-controller1-c10c-fixed-groups-code-preparation-20261104','a5fee374a3dca14c3e4b0505aaf7af0bf77025ac6a4374eb53152c472e7a5304'),
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller10b-root-assembler8-fresh-source-c9-pass-limit-retention-code-only-20261104','21c98c13954bae5d2c370d228851332b1234a7c1906b7d7187197b81daa1a3a2')):
        pins.update(checked_packet(directory,'source-freeze.json',expected,M.pin))
    for directory,expected in(
        (REPO/'.ios-host-tmp/chat-offline-source1-additional5-controller3-aligned-prerequisite-plan-code-preparation-20261104','ec29274db0877a234460ed4a971524a901e684519e697d49e948e84252d50f67'),
        (REPO/'.ios-host-tmp/chat-offline-source1-additional5-controller3-root-assembler3-aligned-plan-code-only-20261104','cddcd8828b44b814ed7cdb82430785ce74154aeb4305c64d370d1dd8dde0d1b5'),
        (REPO/'.ios-host-tmp/chat-offline-source1-public-origin-four-five-five-controller1-code-preparation-20261104','7c22680664b48e704e5e7082ff0d24b562a9401e973215696fd8a3ded28c8a52')):
        pins.update(checked_packet(directory,'source-freeze.json',expected,M.pin))
    return contract,joined


def project_namespace_admission(declared,ordered_roots):
    """Keep impossible aliases as pinned data; admit only real parent paths.

    Splitting a fullname produced from overte.sikuli/overte.py cannot create
    the nonexistent directories overte/sikuli. No namespace is invented and
    no bare alias or fallback loader is granted for such retained source.
    """
    choices={};failed={}
    for fullname in declared:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in declared:continue
            if name not in choices:
                choices[name]=sorted({str((Path(root)/Path(*parts[:size])).resolve(strict=True))
                    for root in ordered_roots if(Path(root)/Path(*parts[:size])).is_dir()})
            if len(choices[name])!=1:
                failed.setdefault(name,dict(physicalChoices=choices[name],affectedAliases=[]))['affectedAliases'].append(fullname)
    refused={}
    for name,row in failed.items():
        row['affectedAliases']=sorted(set(row['affectedAliases']))
        for fullname in row['affectedAliases']:
            entry=refused.setdefault(fullname,dict(origin=dict(declared[fullname]),unresolvableNamespaces=[]))
            entry['unresolvableNamespaces'].append(name)
    for row in refused.values():row['unresolvableNamespaces'].sort()
    admitted={name:row for name,row in declared.items()if name not in refused}
    namespaces={}
    for fullname in admitted:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in admitted:continue
            assert name not in refused and len(choices[name])==1
            namespaces[name]=choices[name]
    return admitted,namespaces,dict(version=1,declaredAliasCount=len(declared),
        admittedAliasCount=len(admitted),unadmittedAliases=refused,unresolvableNamespaces=failed,
        unadmittedSourcesRetainedAsData=True,unadmittedImportAuthority=False)


def main():
    global CONTROLLER_SHA
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head',required=True)
    parser.add_argument('--group',required=True,choices=('paired-first1',))
    parser.add_argument('--assembler-source-sha256',required=True)
    parser.add_argument('--root-context',type=Path,required=True)
    parser.add_argument('--root-context-sha256',required=True)
    parser.add_argument('--external-manifest',type=Path,required=True)
    parser.add_argument('--external-manifest-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--public-integration-freeze',type=Path,required=True)
    parser.add_argument('--public-integration-sha256',required=True)
    args=parser.parse_args()
    assert sys.dont_write_bytecode and Path.cwd()==REPO and hex40(args.expected_head)
    assert sys.flags.no_site == 1, "Explicit no-site interpreter startup required"
    assembler=Path(__file__).resolve().parent
    assert sha(assembler/'source-freeze.json')==args.assembler_source_sha256
    for name,row in load(assembler/'source-freeze.json')['files'].items():assert sha(assembler/name)==row['sha256']
    # Only independently hashed stdlib-only controller definitions are loaded.
    CONTROLLER_SHA=args.assembler_source_sha256
    assert sha(CONTROLLER/'source-freeze.json')==CONTROLLER_SHA
    for name,row in load(CONTROLLER/'source-freeze.json')['files'].items():assert sha(CONTROLLER/name)==row['sha256']
    with ControllerDefinitions()as M:
        M.require_chat_host_cost_qualification()
        assert M.head()==args.expected_head
        pins=checked_packet(CONTROLLER,'source-freeze.json',CONTROLLER_SHA,M.pin)
        pins.update(checked_packet(REPO/'.ios-host-tmp/chat-paired-offline-history-first1-bootstrap6-preserved-qualification-stdlib-loop-code-preparation-20261104','source-freeze.json','a274495921c140b49ca6d825f55bd6886d7af94fce3ba137b84b070083fe7376',M.pin))
        pins.update(checked_packet(REPO/'.ios-host-tmp/root-world-host-timing-source11-global-unwind-local-start-return-private-20261104','source-freeze.json','771e52a551a0a9e0ef90d5f5f3157a2e06ccc1720ddba7855ebc7b8d0452ba66',M.pin))
        # Preserve exact unrun B4 and its historical/current prerequisite separation.
        pins.update(checked_packet(REPO/'.ios-host-tmp/chat-paired-offline-history-first1-bootstrap4-qualified-c10d-original-readiness-code-preparation-20261104','source-freeze.json','105c28ecea0578acfbab57da3703839794f7473dd75ddbbf385989f0ce78debe',M.pin))
        # Immutable B3 remains the pre-C10d source, never relabeled.
        previous3=REPO/'.ios-host-tmp/chat-paired-offline-history-first1-bootstrap3-real-namespace-data-only-code-preparation-20261104'
        pins.update(checked_packet(previous3,'source-freeze.json','448de76e65aebab64e878301247dde22cb7e7557af8a7a64273b93d0523ccbdf',M.pin))
        snapshot5=REPO/'.ios-host-tmp/snapshot-scene-source1-ordered-source3-own4-bootstrap5-qualified-c10d-original-readiness-private-20261104'
        pins.update(checked_packet(snapshot5,'source-freeze.json','9ccd59d94fe0403306e733ed7e66771b15e00a9c1d25ff16f2966920917dbb21',M.pin))
        for name in('host_common.py','source_execution_readiness.py'):
            assert (CONTROLLER/name).read_bytes()==(snapshot5/name).read_bytes()
        # Retain both actual immutable producer packets as source provenance.
        previous=REPO/'.ios-host-tmp/chat-paired-offline-history-first1-bootstrap2-exact-active-origin-code-preparation-20261104'
        pins.update(checked_packet(previous,'source-freeze.json','8aa32e2ff14c3fabadb715ca23d649417dd3b7f921c9e849d35797e7635316bf',M.pin))
        namespace_source=REPO/'.ios-host-tmp/assets-picker3-reserved-phase-controller18-real-namespace-alias-admission-source-private-20261104'
        pins.update(checked_packet(namespace_source,'source-freeze.json','632fd9563b63356e559b69680766306dd2a74a8c77a8105614ecc686667a5b43',M.pin))
        pins.update(checked_packet(assembler,'source-freeze.json',args.assembler_source_sha256,M.pin))
        actual_prerequisites,joined=checked_five_prerequisites(M,pins)
        current,current_pins=M.qualification(M.pin);pins.update(current_pins)
        assert sha(CONTROLLER/'closed_import_origins.py')==M.HELPER_SHA
        historical14=M.require_historical_public_component()
        for name,digest in historical14['physicalFiles'].items():
            assert sha(name)==digest;pins[name]=M.pin(name)
        selection=M.selected(args.group)
        public_contract=dict(path=str(args.public_integration_freeze),sha256=args.public_integration_sha256)
        public_join=M.require_public_integration(public_contract,args.expected_head)
        for name,digest in public_join['physicalFiles'].items():
            assert sha(name)==digest;pins[name]=M.pin(name)
        assert len(selection)==1
        pins.update(checked_packet(PROPOSAL,'freeze.json',PROPOSAL_SHA,M.pin))
        # Historical metadata remains exact; its old public pin values are DATA,
        # not instructions to relabel old public files as the current runtime.
        pins.update(checked_packet(HISTORICAL,'freeze.json',HISTORICAL_SHA,M.pin))
        for directory,expected in(
            (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller1-code-preparation-20261104','4eb83643183a1953db3c1f7f2e7b093c1841b9ed5f2acb73883a314f9692aa0c'),
            (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller2-strict-origins-code-preparation-20261104','a846c7039b33fae0dc427d9cdbbe19e26e72a6a6a0d9f83c0496d1e431c534e3'),
            (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller3-package-spec-input-pin-code-preparation-20261104','f7e427301cded1b35ba46722f4194781399aca59baa8e2d576a637f4770d14e6'),
            (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller4-current-head-initial-module-custody-code-preparation-20261104','057ef27ebd51c0507ba1cc1fdd68cda76c5751472e5acb720120b4c410027fe4'),
            (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller5-exact-readonly-stdlib-source-links-code-preparation-20261104','61c14acd1997272f039fa28c74c39fe9760f7f3ec9e8cf649d13cddd2028a510')):
            pins.update(checked_packet(directory,'source-freeze.json',expected,M.pin))
        for path,expected in((args.root_context,args.root_context_sha256),(args.external_manifest,args.external_manifest_sha256)):
            assert path.is_absolute()and path.resolve(strict=True)==path and sha(path)==expected
            pins[str(path)]=M.pin(path)
        context=load(args.root_context);external=load(args.external_manifest)
        assert context['status']=='ROOT_REVIEWED_QUIET_CURRENT_SOURCE_AND_ORIGINAL_CONTEXT'
        assert context['expectedHead']==args.expected_head and context['allTargetsTerminal']is True
        assert external['status']=='ROOT_REVIEWED_EXACT_EXTERNAL_MODULE_FRONTIER'
        assert set(external)=={'status','modules','namespaces','physicalFiles'}
        custody=context['globalCustody']
        for key in('helper','seed','baseline'):
            row=custody[key];path=Path(row['path'])
            assert path.is_absolute()and path.resolve(strict=True)==path and sha(path)==row['sha256']
            pins[str(path)]=M.pin(path)
        assert custody['helper']['sha256']==GLOBAL_HELPER_SHA
        assert Path(custody['seed']['path'])==Path(custody['helper']['path']).with_name('global-original-roots-seed.json')
        baseline=load(custody['baseline']['path']);seed=load(custody['seed']['path'])
        assert set(baseline)==set(seed['roots'])
        assert all(name in baseline for name in joined['newOriginalRoots'])
        assert set(current['requiredOriginalRoots'])<=set(baseline)
        assert set(historical14['newOriginalRoots'])<=set(baseline)
        old=load(HISTORICAL/'global-original-corpus-baseline.json')
        assert set(old)<=set(baseline)and all(baseline[name]==rows for name,rows in old.items())
        previous_c6_baseline=checked_c6_retention(pins,baseline,M.pin)
        previous_c7_baseline=checked_c7_retention(pins,baseline,M.pin)
        previous_c8_baseline=checked_c8_retention(pins,baseline,M.pin)
        previous_c9_baseline=checked_c9_retention(pins,baseline,M.pin)
        # Root explicitly supplies every later terminal proof and the full output
        # roots, not an inferred current count or a writer exclusion.
        assert type(context['terminalAdditions'])is list
        for addition in context['terminalAdditions']:
            for name in addition['roots']:assert name in baseline
            packet=Path(addition['packet'])
            pins.update(checked_packet(packet,addition['freezeFile'],addition['freezeSha256'],M.pin))
        for row in context['additionalPhysicalProofs']:
            path=Path(row['path']);assert sha(path)==row['sha256'];pins[str(path)]=M.pin(path)
        output=args.output
        assert output.is_absolute()and output.resolve(strict=False)==output and output.parent==REPO/'.ios-host-tmp'
        assert output.name.startswith('chat-paired-offline-'+args.group+'-prepared-')and not output.exists()
        assert output not in(CONTROLLER,PROPOSAL,HISTORICAL)
        # Every project alias is constructed from current public .py files. The
        # exact Source1 five rows are the only possible private module overlays.
        modules={};namespaces={};public_paths=set();ambiguous_aliases={}
        public_roots=[Path(value)for value in load(HISTORICAL/'public-source-namespace.json')['roots']]
        for root in public_roots:
            assert root.is_relative_to(REPO)and not root.is_relative_to(REPO/'.ios-host-tmp')
            for path in(root,*sorted(root.rglob('*'))):
                assert path.resolve(strict=True)==path and not path.is_symlink()
                public_paths.add(str(path))
                if path.is_file():pins[str(path)]=M.pin(path)
        # Ordered aliases are independently declared. A different physical file
        # with the same alias refuses; no silent PathFinder-precedence adoption.
        ordered_roots=(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests')
        for root in ordered_roots:
            for path in sorted(root.rglob('*.py')):
                parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
                if package:parts.pop()
                if not parts:continue
                name='.'.join(parts);row=dict(path=str(path),sha256=sha(path),package=package)
                if name in ambiguous_aliases:
                    if row not in ambiguous_aliases[name]:ambiguous_aliases[name].append(row)
                elif name in modules and modules[name]!=row:
                    ambiguous_aliases[name]=[modules.pop(name),row]
                else:modules[name]=row
        # These two actual bare aliases have different public files. Neither
        # receives import authority; both canonical qualified names remain real.
        assert set(ambiguous_aliases)=={'test_appium_adapter','test_voice_roundtrip'}
        assert not set(ambiguous_aliases).intersection(sys.stdlib_module_names)
        for name,choices in ambiguous_aliases.items():
            assert name not in modules and len(choices)==2
            assert modules['self_tests.'+name]in choices
            assert modules['ios.self_tests.'+name]in choices
        deps=load(PROPOSAL/'DEPENDENCIES.json')
        # All34 immutable historical rows remain literal; current public
        # runtime c170->bb1d is bound to its actual retained Source1/base file.
        assert len(deps['publicPhysicalDependencies'])==34 and len(public_join['historicalDependencies'])==34
        for row in public_join['historicalDependencies']:
            assert sha(row['physicalPath'])==row['sha256'];pins[row['physicalPath']]=M.pin(row['physicalPath'])
        assert len(deps['overlays'])==5
        for row in deps['overlays']:
            assert sha(row['path'])==row['sha256'];pins[row['path']]=M.pin(row['path'])
            # The real public namespace was collected independently above.
            # No private candidate may override it after integration.
            assert modules[row['module']]==public_join['publicModules'][row['module']]
        assert all(not Path(row['path']).is_relative_to(REPO/'.ios-host-tmp')for row in modules.values())
        pins.update(checked_packet(M.PAIRED_SOURCE,'source-freeze.json',M.PAIRED_SHA,M.pin))
        for name,row in M.PAIRED_MODULES.items():
            assert name not in modules;modules[name]=row;pins[row['path']]=M.pin(row['path'])
        for name in('host_function_timing','chat_host_cost_diagnostic'):
            path=CONTROLLER/(name+'.py');assert name not in modules
            pins[str(path)]=M.pin(path);modules[name]=dict(path=str(path),sha256=sha(path),package=False)
        # Actual stdlib's entire source/extension frontier is pinned BEFORE imports,
        # including initially loaded frozen-source representations. No site root.
        std=Path(vars(os)['__file__']).resolve(strict=True).parent
        assert std.is_dir()and not excluded(std)
        extensions=tuple(importlib.machinery.EXTENSION_SUFFIXES)
        std_namespaces={}
        for paired_stdlib_directory,dirs,names in os.walk(std,topdown=True,followlinks=False):
            directory=Path(paired_stdlib_directory)
            # Prune excluded installation trees BEFORE descending. No installed
            # SDK/package tree is enumerated as a guessed stdlib allowance.
            dirs[:]=sorted(name for name in dirs if name not in('site-packages','dist-packages','__pycache__')
                and not(directory/name).is_symlink())
            relative=directory.relative_to(std)
            if relative.parts and all(part.isidentifier()for part in relative.parts)and not(directory/'__init__.py').is_file():
                std_namespaces['.'.join(relative.parts)]=[str(directory)]
            for name in sorted(names):
                path=directory/name
                if path.suffix!='.py'and not any(str(path).endswith(suffix)for suffix in extensions):continue
                real=path.resolve(strict=True)
                if excluded(real)or not real.is_relative_to(std):continue
                assert real.is_file();pins[str(real)]=M.pin(real)
        python=Path(sys.executable).resolve(strict=True);pins[str(python)]=M.pin(python)
        for name,module in tuple(sys.modules.items()):
            if module is None:continue
            file=vars(module).get('__file__')
            if file is None:continue
            path=Path(file).resolve(strict=True)
            if path.is_relative_to(std)and not excluded(path):pins[str(path)]=M.pin(path)
            elif path.parent in(Path(__file__).resolve().parent,CONTROLLER):pins[str(path)]=M.pin(path)
            else:assert name in external['modules']and external['modules'][name]['path']==str(path),'Unaccounted metadata bootstrap module: '+name
        for path,row in external['physicalFiles'].items():
            assert Path(path).is_absolute()and Path(path).resolve(strict=True)==Path(path)
            assert M.pin(path)==row;pins[path]=row
        for name,row in external['modules'].items():
            assert set(row)=={'path','sha256','package','loader'}and row['loader']in('source','extension')
            assert name not in modules and row['path']in pins and pins[row['path']]['sha256']==row['sha256']
            assert not Path(row['path']).is_relative_to(REPO)
        node=Path(shutil.which('node')).resolve(strict=True);pins[str(node)]=M.pin(node)
        script=REPO/'tests/device/ios/self_tests/chat_message_script_domain.js';model=script.with_suffix('.py')
        pins[str(script)]=M.pin(script);pins[str(model)]=M.pin(model)
        # All public, private, controller, stdlib and external source pins now
        # exist. Classify aliases only from actual resolved parent directories.
        modules,namespaces,alias_admission=project_namespace_admission(modules,ordered_roots)
        assert all(modules[name]==row for name,row in public_join['publicModules'].items())
        assert all(modules[name]==row for name,row in M.PAIRED_MODULES.items())
        declared=dict(modules)
        for name,row in alias_admission['unadmittedAliases'].items():
            assert name not in declared;declared[name]=row['origin']
        replayed,replayed_namespaces,replayed_admission=project_namespace_admission(declared,ordered_roots)
        assert replayed==modules and replayed_namespaces==namespaces and replayed_admission==alias_admission
        # No temporary/runs/raw room is born; only a new metadata destination.
        output.mkdir(mode=0o700)
        def save(name,value):
            path=output/name
            fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,'w')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
            return path
        for key,name in(('helper','global_original_corpus.py'),('seed','global-original-roots-seed.json'),('baseline','global-original-corpus-baseline.json')):
            original=Path(custody[key]['path']);target=output/name
            with original.open('rb')as incoming,target.open('xb')as outgoing:shutil.copyfileobj(incoming,outgoing)
            target.chmod(0o600);assert sha(target)==custody[key]['sha256'];pins[str(target)]=M.pin(target)
        public=save('public-source-namespace.json',dict(roots=[str(r)for r in public_roots],paths=sorted(public_paths)));pins[str(public)]=M.pin(public)
        aliases=save('absolute-module-origins.json',dict(modules=modules,namespaces=namespaces,projectAliasAdmission=alias_admission,thirdPartyModules=external['modules'],thirdPartyNamespacePackages=external['namespaces']));pins[str(aliases)]=M.pin(aliases)
        unadmitted=save('unadmitted-public-aliases.json',dict(status='NO_UNADMITTED_ALIAS_AUTHORITY_GRANTED',aliases=ambiguous_aliases,projectAliasAdmission=alias_admission))
        pins[str(unadmitted)]=M.pin(unadmitted)
        plan=dict(status='ROOT_REVIEWED_PREPARED_UNRUN',hostCostDiagnosticOnly=True,hostCostAlgorithmQualification=None,hostCostEngineSha256='2ad2223660ddc2948066523d491feeca458c9d9fb1be277c08f862825a0dccb0',head=args.expected_head,controllerSourceFreeze=CONTROLLER_SHA,
            currentHeadAdmission=dict(exactRootExpectedHead=args.expected_head,historicalControllerHead='06ff22857d8c8298390e00cd5df1c848a1d9c6a5',historicalManifestsPreserved=True),
            projectAliasAdmission=alias_admission,
            unadmittedPublicAliases=dict(path=str(unadmitted),sha256=sha(unadmitted),names=sorted(ambiguous_aliases)),
            proposalFreeze=PROPOSAL_SHA,cases=selection,selectionGroup=args.group,selectionFreeze=M.SELECTION_SHA,
            actualPrerequisites=actual_prerequisites,actualPrerequisiteSummary=joined['summary'],publicIntegration=public_contract,publicIntegrationSummary=public_join['summary'],seconds=300,graceSeconds=5,pairedSourceFreeze=M.PAIRED_SHA,pairedModules=M.PAIRED_MODULES,
            qualifiedCurrentSourceExecution=current,historicalPublic14Component=historical14['summary'],currentPairedConsumerQualified=False,
            inheritedPrerequisiteScope='HISTORICAL_FUNCTIONAL4_AND_C10C_COUNTER6_NOT_CURRENT_HELPER_AUTHORITY',
            maxNodePerCase=2,maxLiveNodes=2,maxTotalNodes=2,TDsPerExecutedCase=4,loopbacksAllowed=False,
            source15Or17Adopted=False,wholeQualified=False,physicalPins=pins,modules=modules,namespacePackages=namespaces,
            thirdPartyModules=external['modules'],thirdPartyNamespacePackages=external['namespaces'],stdlibNamespacePackages=std_namespaces,
            stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=pins[str(python)]),
            publicNamespace=dict(path=str(public),sha256=sha(public)),
            node=dict(path=str(node),pin=pins[str(node)]),nodeScript=dict(path=str(script),pin=pins[str(script)]),nodeModel=dict(path=str(model),pin=pins[str(model)]),
            globalCustody=dict(helperPath=str(output/'global_original_corpus.py'),seedPath=str(output/'global-original-roots-seed.json'),
                seedSha256=sha(output/'global-original-roots-seed.json'),baselinePath=str(output/'global-original-corpus-baseline.json'),baselineSha256=sha(output/'global-original-corpus-baseline.json')))
        prepared=save('plan.json',plan);plan_sha=sha(prepared)
        M.validate(prepared,plan_sha,CONTROLLER_SHA,args.expected_head,args.group)
        assert M.head()==args.expected_head
        for path,row in pins.items():assert M.pin(path)==row
        summary=save('preparation-summary.json',dict(status='UNRUN_REQUIRES_ROOT_FINAL_REVIEW_AND_SEPARATE_TARGET_WINDOW',head=args.expected_head,controllerSourceFreeze=CONTROLLER_SHA,
            planPath=str(prepared),planSha256=plan_sha,physicalPins=len(pins),projectModules=len(modules),projectNamespaces=len(namespaces),
            externalModules=len(external['modules']),oldRootNamespaces=len(baseline),allReviewedHistoricalBaselineBodiesPreserved=True,historicalBaselineRootCount=len(old),completeC6HistoricalBaselineRootCount=len(previous_c6_baseline),
            actualFailedC6RetainedWithoutQualification=True,actualFailedC7RetainedWithoutQualification=True,actualFailedC8RetainedWithoutQualification=True,completeC7HistoricalBaselineRootCount=len(previous_c7_baseline),completeC8HistoricalBaselineRootCount=len(previous_c8_baseline),completeC9HistoricalBaselineRootCount=len(previous_c9_baseline),actualC9DeclaredPassRetainedWithSourceExecutionLimit=True,sourceExecutionCounterQualified=True,currentHelperFourRerunClaimed=False,actualPrerequisiteSummary=joined['summary'],selectionGroup=args.group,cases=selection,rootCountIsNotExecutionCap=True,
            noProductImports=True,noTarget=True,noGlobalCensus=True,noRawRootBorn=True,nativeQualified=False,wholeQualified=False))
        frozen={}
        for path in sorted(output.iterdir()):
            assert path.is_file()and not path.is_symlink();frozen[path.name]=dict(bytes=path.stat().st_size,sha256=sha(path))
        freeze=save('freeze.json',dict(status='FROZEN_PREPARED_UNRUN_REQUIRES_ROOT_REVIEW',files=frozen))
        print(json.dumps(dict(freeze=str(freeze),freezeSha256=sha(freeze),plan=str(prepared),planSha256=plan_sha,controllerSourceFreeze=CONTROLLER_SHA),indent=2))
        return 0


if __name__=='__main__':raise SystemExit(main())
