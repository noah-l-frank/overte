"""Declared SDK/candidate data boundaries; actual Runtime/Installed/End codecs.

No RuntimeModel, typed End proof or retirement verdict is synthesized. The real
WebDriver, installed binding journal, IOSScriptRuntime, parent End and immutable
file stores run against the local original-keeper gateway. The artifact/native
bundle are MODELS; this can never qualify an installed binary or physical SDK.
Only Root may execute the prospective fixture.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib,json
from pathlib import Path
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.appium_adapter import WebDriver
from ios.adapters.feature_observation import FeatureObservation
from ios.adapters.installed_code import InstalledCodeBinding
from ios.adapters.normal_scripts import PROFILE
from ios.adapters.original_keeper_readmission import creation_capabilities
from ios.adapters.script_runtime import IOSScriptRuntime


class DeclaredCanonicalSDK:
    """The original host consumer owns all actual state/CAS/native-byte reads."""
    def __init__(self,root,origin,session):
        self.root=Path(root);self.root.mkdir(mode=0o700);self._session_recreation_forbidden=False
        self.artifact=self.root/'declared-model-artifact.bytes';self.artifact.write_bytes(b'Explicit model bytes, never an installable binary.');self.artifact.chmod(0o600)
        self.artifact_sha256=hashlib.sha256(self.artifact.read_bytes()).hexdigest();self.artifact_identity=self.artifact.stat()
        self.bundle=dict(bundleContractVersion=1,bundleId='org.overte.model',executableSha256='a'*64,bundleSha256='b'*64,nodeCount=3,fileCount=2,totalBytes=1000)
        self.selected=dict(platform='ios',physical=True,appId=self.bundle['bundleId'],serverUrl=origin,
            artifactMode='personal-team-preinstalled',_artifactMode='personal-team-preinstalled',probe=dict(kind='ios-documents'),
            nativeUiObservation=dict(kind='uikit-documents',version=1),normalScripts=dict(contractVersion=1,profile=PROFILE),
            testBuild=dict(resultsDirectory='owned-results',fixtureOrigin=origin,scenePath='/scene.json'),capabilities={})
        self.creations=0;self.generations=1
        self.save_session('model',dict(sessionId=session,generation=1,targetFingerprint=self.fingerprint()))
    def state_path(self,selector):need(selector=='model');return self.root/'session.json'
    def fingerprint(self):return hashlib.sha256(json.dumps(self.selected,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    def _candidate_guard(self,*,complete=False):
        need(type(complete)is bool);info=self.artifact.stat()
        need((info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns)==
            (self.artifact_identity.st_dev,self.artifact_identity.st_ino,self.artifact_identity.st_size,self.artifact_identity.st_mtime_ns,self.artifact_identity.st_ctime_ns))
        need(hashlib.sha256(self.artifact.read_bytes()).hexdigest()==self.artifact_sha256)
    def _target(self,selector):need(selector=='model');self._candidate_guard();return deepcopy(self.selected)
    def target(self,selector):return self._target(selector)
    def read_session(self,selector):return PrivateFeatureState(self.state_path(selector)).read()
    def save_session(self,selector,state):
        store=PrivateFeatureState(self.state_path(selector));store.write(state,store.read())
    def _binding_store(self,selector):return PrivateFeatureState(self.state_path(selector).with_name('installed-code-binding.json'))
    def _scope(self,selector,session,state,target):
        self._candidate_guard();need(target==self.selected and self.read_session(selector)==state and state['sessionId']==session
            and state['targetFingerprint']==self.fingerprint())
        return dict(sourceRevision='a'*40,artifactSha256=self.artifact_sha256,sessionId=session,generation=state['generation'],targetFingerprint=self.fingerprint())
    def _retired_candidate_scope(self,selector,scope):
        self._candidate_guard(complete=True);target=self._target(selector)
        need(scope['sourceRevision']=='a'*40 and scope['artifactSha256']==self.artifact_sha256 and scope['targetFingerprint']==self.fingerprint())
        return target
    def _avatar_retired_binding_record(self,selector,scope,value):
        self._retired_candidate_scope(selector,scope)
        class Frozen:
            def read(_self):return value
        def forbidden():need(False)
        # The same actual installed historical decoder, with no live access.
        return InstalledCodeBinding(Frozen(),scope,self.bundle,forbidden,forbidden,forbidden).record()
    def _binding(self,selector,client,session,state,target):
        scope=self._scope(selector,session,state,target)
        def process():
            need(self._scope(selector,session,state,target)==scope)
            return client.execute(session,'mobile: overteProcessInfo',dict(bundleId=target['appId']))
        def source():
            need(self._scope(selector,session,state,target)==scope)
            return client.execute(session,'mobile: overteProcessSourceInfo',dict(bundleId=target['appId']))
        observer=FeatureObservation(client,session,target,process)
        return InstalledCodeBinding(self._binding_store(selector),scope,self.bundle,process,source,lambda:observer.installed_bundle().read())
    def ensure_session(self,selector):
        target=self._target(selector);state=self.read_session(selector);client=WebDriver(target['serverUrl'])
        if state is None:
            need(not self._session_recreation_forbidden)
            capabilities=creation_capabilities(self,target)
            result=client.call('POST','/session',dict(capabilities=dict(alwaysMatch=capabilities,firstMatch=[{}])))
            need(type(result)is dict and type(result['sessionId'])is str)
            self.generations+=1;self.creations+=1
            state=dict(sessionId=result['sessionId'],generation=self.generations,targetFingerprint=self.fingerprint())
            self.save_session(selector,state)
        return client,state['sessionId'],state
    def describe(self,selector):
        client,session,state=self.ensure_session(selector);target=self._target(selector)
        gate=self._binding(selector,client,session,state,target);record=gate.record()
        if record is None:
            # This fixture's first SDK/native launch is a declared lower
            # boundary model. The complete actual gate journal is retained.
            gate.begin();gate.bind()
        else:gate.verify()
        current=client.execute(session,'mobile: overteProcessInfo',dict(bundleId=target['appId']))
        state=dict(state,processIdentity=str(current['pid']),iosE2ELaunchCompleted=True);self.save_session(selector,state)
        return dict(executionIdentity=gate._claim(),physicalSDKModeled=True)
    def runtime(self):return IOSScriptRuntime(self)
