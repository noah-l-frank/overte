VALUE = 'actual-foreign'
def wrong_factory(): return None
class ForeignParser: pass
