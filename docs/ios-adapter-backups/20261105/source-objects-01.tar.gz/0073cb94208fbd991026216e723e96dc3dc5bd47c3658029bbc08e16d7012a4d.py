"""UNRUN stdlib-only fixed180+5 exact process-group supervisor."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
HERE=Path(__file__).resolve().parent
pins=json.loads((HERE/'controller-pins.json').read_text())
for name,row in pins.items():assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==row['sha256']
assert not(HERE/'supervisor-start.json').exists()
def save(name,value):(HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def census(group):
 values=[]
 for path in Path('/proc').iterdir():
  if not path.name.isdigit():continue
  try:
   raw=(path/'stat').read_text();fields=raw[raw.rfind(')')+2:].split()
   if int(fields[2])==group:values.append(dict(pid=int(path.name),parent=int(fields[1]),group=int(fields[2]),startTicks=int(fields[19]),state=fields[0]))
  except(FileNotFoundError,ProcessLookupError,PermissionError):pass
 return values
binary=json.loads((HERE/'binary-pins.json').read_text())['python'];assert hashlib.sha256(Path(binary['path']).read_bytes()).hexdigest()==binary['sha256']
stream=(HERE/'execution.log').open('wb');started=time.monotonic()
env=dict(PATH='/usr/bin',LANG='C.UTF-8',LC_ALL='C.UTF-8',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
process=subprocess.Popen([binary['path'],'-I','-B',str(HERE/'run-parent-boundary1.py')],cwd=HERE,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
save('supervisor-start.json',dict(pid=process.pid,group=process.pid,initial=census(process.pid),budgetSeconds=180,killGraceSeconds=5))
timeout=False
try:
 process.wait(timeout=max(0,started+180-time.monotonic()))
except subprocess.TimeoutExpired:
 timeout=True;save('before-fixed-timeout-census.json',census(process.pid));os.killpg(process.pid,signal.SIGINT)
 try:process.wait(timeout=max(0,started+185-time.monotonic()))
 except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
finally:
 stream.close();remaining=census(process.pid)
 if remaining:
  # Exact owned group only. Such a failure cannot be promoted to host PASS.
  save('before-orphan-cleanup-census.json',remaining)
  try:os.killpg(process.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  deadline=min(time.monotonic()+5,started+185)
  while time.monotonic()<deadline and census(process.pid):time.sleep(.05)
  if census(process.pid):
   try:os.killpg(process.pid,signal.SIGKILL)
   except ProcessLookupError:pass
  remaining=census(process.pid)
 save('supervisor-terminal.json',dict(exitCode=process.returncode,fixed180Timeout=timeout,elapsedSeconds=time.monotonic()-started,
  remainingOwnedProcesses=remaining,hadPostRunnerOrphans=(HERE/'before-orphan-cleanup-census.json').exists(),businessEndClaim=False))
sys.exit(124 if timeout else process.returncode)
