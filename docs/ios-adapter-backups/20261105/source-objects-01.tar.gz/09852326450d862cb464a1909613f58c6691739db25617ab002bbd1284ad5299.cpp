//
//  ScriptManager.cpp
//  libraries/script-engine/src
//
//  Created by Brad Hefta-Gaub on 12/14/13.
//  Copyright 2013 High Fidelity, Inc.
//  Copyright 2022-2023 Overte e.V.
//
//  Distributed under the Apache License, Version 2.0.
//  See the accompanying file LICENSE or http://www.apache.org/licenses/LICENSE-2.0.html
//  SPDX-License-Identifier: Apache-2.0
//

#include "ScriptManager.h"
#if defined(OVERTE_E2E_FEATURE_TESTS)
#include "ScriptLoadObservation.h"
namespace {
overte::e2e::ScriptLoadObservation& featureScriptLoads() {
    static overte::e2e::ScriptLoadObservation history;
    return history;
}
}
QVariantMap ScriptManager::featureLoadHistory() { return featureScriptLoads().snapshot(); }
#endif
#include <Finally.h>
#include "../../../security/redaction/SafeDiagnostics.h"

#include <chrono>
#include <memory>
#include <thread>
#ifdef Q_OS_ANDROID
#include <sys/system_properties.h>
#endif

#include <QtCore/QCoreApplication>
#include <QtCore/QEventLoop>
#include <QtCore/QFileInfo>
#include <QtCore/QTimer>
#include <QtCore/QThread>
#include <QtCore/QRegularExpression>

#include <QtCore/QFuture>
#include <QtConcurrent/QtConcurrentRun>

#include <shared/LocalFileAccessGate.h>
#include <shared/AbstractLoggerInterface.h>
#include <DebugDraw.h>
#include <MessagesClient.h>
#include <OctreeConstants.h>
#include <PathUtils.h>
#include <PortableHighResolutionClock.h>
#include <ResourceCache.h>
#include <ResourceManager.h>
#include <ResourceScriptingInterface.h>
#include <UserActivityLoggerScriptingInterface.h>
#include <NodeList.h>

#include "AssetScriptingInterface.h"
#include "BatchLoader.h"
#include "EventTypes.h"
#include "MenuItemProperties.h"
#include "ScriptCache.h"
#include "ScriptContext.h"
#include "XMLHttpRequestClass.h"
#include "WebSocketClass.h"
#include "ScriptEngine.h"
#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(Q_OS_IOS)
#include "v8/ScriptEngineV8.h"
#endif
#include "ScriptEngineCast.h"
#include "ScriptEngineLogging.h"
#include "ScriptEngines.h"
#include "StackTestScriptingInterface.h"
#include "ScriptValue.h"
#include "ScriptProgram.h"
#include "ScriptValueIterator.h"
#include "ScriptValueUtils.h"
#include "ScriptManagerScriptingInterface.h"

#include <Profile.h>

#include "MIDIEvent.h"

#include "SettingHandle.h"
#include <AddressManager.h>
#include <NetworkingConstants.h>
#include <ThreadHelpers.h>
#include <iostream>

const QString ScriptManager::_SETTINGS_ENABLE_EXTENDED_EXCEPTIONS {
    "com.highfidelity.experimental.enableExtendedJSExceptions"
};

const QString ScriptManager::SCRIPT_EXCEPTION_FORMAT{ "[%0] %1 in %2:%3" };
const QString ScriptManager::SCRIPT_BACKTRACE_SEP{ "\n    " };

static const int MAX_MODULE_ID_LENGTH { 4096 };
static const int MAX_DEBUG_VALUE_LENGTH { 80 };

static const ScriptValue::PropertyFlags READONLY_PROP_FLAGS{ ScriptValue::ReadOnly | ScriptValue::Undeletable };
static const ScriptValue::PropertyFlags READONLY_HIDDEN_PROP_FLAGS{ READONLY_PROP_FLAGS | ScriptValue::SkipInEnumeration };

static const bool HIFI_AUTOREFRESH_FILE_SCRIPTS { true };

int scriptManagerPointerMetaID = qRegisterMetaType<ScriptManagerPointer>();

Q_DECLARE_METATYPE(ExternalResource::Bucket);

Q_DECLARE_METATYPE(ScriptValue);

// --- Static script initialization registry

static ScriptManager::StaticInitializerNode* rootInitializer = nullptr;
static ScriptManager::StaticTypesInitializerNode* rootTypesInitializer = nullptr;


using ScriptableResourceRawPtr = ScriptableResource*;
ScriptValue externalResourceBucketToScriptValue(ScriptEngine* engine, ExternalResource::Bucket const& in);
bool externalResourceBucketFromScriptValue(const ScriptValue& object, ExternalResource::Bucket& out);
static ScriptValue scriptableResourceToScriptValue(ScriptEngine* engine,
                                                    const ScriptableResourceRawPtr& resource);
static bool scriptableResourceFromScriptValue(const ScriptValue& value, ScriptableResourceRawPtr& resource);
STATIC_SCRIPT_TYPES_INITIALIZER((+[](ScriptManager* manager){
    auto scriptEngine = manager->engine().get();

    registerEventTypes(scriptEngine);
    scriptRegisterMetaType<ExternalResource::Bucket, externalResourceBucketToScriptValue, externalResourceBucketFromScriptValue>(scriptEngine);

    scriptRegisterMetaType<ScriptableResourceRawPtr, scriptableResourceToScriptValue, scriptableResourceFromScriptValue>(scriptEngine);
}));

void ScriptManager::registerNewStaticInitializer(StaticInitializerNode* dest) {
    // this function is assumed to be called on LoadLibrary, where we are explicitly operating in single-threaded mode
    // Therefore there is no mutex or threadsafety here and the structure is assumed not to change after loading
    dest->prev = rootInitializer;
    rootInitializer = dest;
}
static void runStaticInitializers(ScriptManager* manager) {
    ScriptManager::StaticInitializerNode* here = rootInitializer;
    while (here != nullptr) {
        (*here->init)(manager);
        here = here->prev;
    }
}
void ScriptManager::registerNewStaticTypesInitializer(StaticTypesInitializerNode* dest) {
    // this function is assumed to be called on LoadLibrary, where we are explicitly operating in single-threaded mode
    // Therefore there is no mutex or threadsafety here and the structure is assumed not to change after loading
    dest->prev = rootTypesInitializer;
    rootTypesInitializer = dest;
}
static void runStaticTypesInitializers(ScriptManager* manager) {
    ScriptManager::StaticTypesInitializerNode* here = rootTypesInitializer;
    while (here != nullptr) {
        (*here->init)(manager);
        here = here->prev;
    }
}

// ---

static ScriptValue debugPrint(ScriptContext* context, ScriptEngine* engine) {
    // assemble the message by concatenating our arguments
    QString message = "";
    for (int i = 0; i < context->argumentCount(); i++) {
        if (i > 0) {
            message += " ";
        }
        message += context->argument(i).repr();
    }

    // was this generated by a script engine? If we don't recognize it then send the message and exit
    ScriptManager* scriptManager = engine->manager();
    if (!scriptManager) {
        qCDebug(scriptengine_script) << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
        return ScriptValue();
    }

    // This message was sent by one of our script engines, let's try to see if we can find the source.
    // Note that the first entry in the backtrace should be "print" and is somewhat useless to us
    AbstractLoggerInterface* loggerInterface = AbstractLoggerInterface::get();
    if (loggerInterface && loggerInterface->showSourceDebugging()) {
        ScriptContext* userContext = context;
        ScriptContextPointer parentContext; // using this variable to maintain parent variable lifespan
        while (userContext && userContext->functionContext()->functionType() == ScriptFunctionContext::NativeFunction) {
            parentContext = userContext->parentContext();
            userContext = parentContext.get();
        }
        QString location;
        if (userContext) {
            auto contextInfo = userContext->functionContext();
            QString fileName = contextInfo->fileName();
            int lineNumber = contextInfo->lineNumber();
            QString functionName = contextInfo->functionName();

            location = functionName;
            if (!fileName.isEmpty()) {
                if (location.isEmpty()) {
                    location = fileName;
                } else {
                    location = QString("%1 at %2").arg(location).arg(fileName);
                }
            }
            if (lineNumber != -1) {
                location = QString("%1:%2").arg(location).arg(lineNumber);
            }
        }
        if (location.isEmpty()) {
            location = scriptManager->getFilename();
        }

        // give the script engine a chance to notify the system about this message
        scriptManager->print(message);

        // send the message to debug log
        qCDebug(scriptengine_script) << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
    } else {
        scriptManager->print(message);
        // Public logs exclude script identity and contents; the internal print route is unchanged.
        qCDebug(scriptengine_script) << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
    }

    return ScriptValue();
}

// FIXME Come up with a way to properly encode entity IDs in filename
// The purpose of the following two function is to embed entity ids into entity script filenames
// so that they show up in stacktraces
//
// Extract the url portion of a url that has been encoded with encodeEntityIdIntoEntityUrl(...)
QString extractUrlFromEntityUrl(const QString& url) {
    auto parts = url.split(' ', Qt::SkipEmptyParts);
    if (parts.length() > 0) {
        return parts[0];
    } else {
        return "";
    }
}

// Encode an entity id into an entity url
// Example: http://www.example.com/some/path.js [EntityID:{9fdd355f-d226-4887-9484-44432d29520e}]
QString encodeEntityIdIntoEntityUrl(const QString& url, const QString& entityID) {
    return url + " [EntityID:" + entityID + "]";
}

QString ScriptManager::logException(const ScriptValue& exception) {
    auto message = formatException(exception, _enableExtendedJSExceptions.get());
    auto context = _engine->currentContext();
    if (context) {
        scriptErrorMessage(message, context->currentFileName(), context->currentLineNumber());
    } else {
        scriptErrorMessage(message, "", -1);
    }
    return message;
}

std::shared_ptr<ScriptException> ScriptManager::getUncaughtException() const {
    return _engine->uncaughtException();
}

void ScriptManager::registerConsoleScriptingInterface(ScriptEngine::ScriptEngineScopeGuard* scopeGuard, ScriptEngine* scriptEngine) {
    scriptEngine->registerGlobalObject(scopeGuard, "console", _consoleScriptingInterface.get());
    scriptEngine->registerFunction(scopeGuard, "console", "info", ConsoleScriptingInterface::info, scriptEngine->currentContext()->argumentCount());
    scriptEngine->registerFunction(scopeGuard, "console", "log", ConsoleScriptingInterface::log, scriptEngine->currentContext()->argumentCount());
    scriptEngine->registerFunction(scopeGuard, "console", "debug", ConsoleScriptingInterface::debug, scriptEngine->currentContext()->argumentCount());
    scriptEngine->registerFunction(scopeGuard, "console", "warn", ConsoleScriptingInterface::warn, scriptEngine->currentContext()->argumentCount());
    scriptEngine->registerFunction(scopeGuard, "console", "error", ConsoleScriptingInterface::error, scriptEngine->currentContext()->argumentCount());
    scriptEngine->registerFunction(scopeGuard, "console", "exception", ConsoleScriptingInterface::exception, scriptEngine->currentContext()->argumentCount());
    scriptEngine->registerFunction(scopeGuard, "console", "assert", ConsoleScriptingInterface::assertion, scriptEngine->currentContext()->argumentCount());
    scriptEngine->registerFunction(scopeGuard, "console", "group", ConsoleScriptingInterface::group, 1);
    scriptEngine->registerFunction(scopeGuard, "console", "groupCollapsed", ConsoleScriptingInterface::groupCollapsed, 1);
    scriptEngine->registerFunction(scopeGuard, "console", "groupEnd", ConsoleScriptingInterface::groupEnd, 0);
}

ScriptManagerPointer scriptManagerFactory(ScriptManager::Context context,
                                                 const QString& scriptContents,
                                                 const QString& fileNameString) {
    ScriptManagerPointer manager = newScriptManager(context, scriptContents, fileNameString);
    auto scriptEngines = DependencyManager::get<ScriptEngines>();
    scriptEngines->addScriptEngine(manager);
    manager->setScriptEngines(scriptEngines);
    return manager;
}

ScriptManagerPointer newScriptManager(ScriptManager::Context context,
                                      const QString& scriptContents,
                                      const QString& fileNameString) {
    ScriptManagerPointer manager(new ScriptManager(context, scriptContents, fileNameString),
                                 [](ScriptManager* obj) { obj->deleteLater(); });
    return manager;
}

int ScriptManager::processLevelMaxRetries { ScriptRequest::MAX_RETRIES };

ScriptManager::ScriptManager(Context context, const QString& scriptContents, const QString& fileNameString) :
    QObject(),
    _context(context),
    _engine(newScriptEngine(this)),
    _scriptContents(scriptContents),
    _timerFunctionMap(),
    _fileNameString(fileNameString),
    _quatLibrary(new Quat()),
    _vec3Library(new Vec3()),
    _mat4Library(new Mat4()),
    _uuidLibrary(new ScriptUUID()),
    _consoleScriptingInterface(new ConsoleScriptingInterface()),
    _assetScriptingInterface(new AssetScriptingInterface(this))
{

    switch (_context) {
        case Context::CLIENT_SCRIPT:
            _type = Type::CLIENT;
            break;
        case Context::ENTITY_CLIENT_SCRIPT:
            _type = Type::ENTITY_CLIENT;
            break;
        case Context::ENTITY_SERVER_SCRIPT:
            _type = Type::ENTITY_SERVER;
            break;
        case Context::AGENT_SCRIPT:
            _type = Type::AGENT;
            break;
        case Context::NETWORKLESS_TEST_SCRIPT:
            _type = Type::NETWORKLESS_TEST;
            break;
    }

    qRegisterMetaType<ScriptValue>();
    qRegisterMetaType<std::function<void()>>();

    _scriptingInterface = std::make_shared<ScriptManagerScriptingInterface>(this);

    if (isEntityServerScript()) {
        qCDebug(scriptengine) << "isEntityServerScript() -- limiting maxRetries to 1";
        processLevelMaxRetries = 1;
    }


#if 0
    // V8TODO: Is this actually needed? Exceptions will already be logged on the
    // script engine side.

    // this is where all unhandled exceptions end up getting logged
    connect(this, &ScriptManager::unhandledException, this, [this](const ScriptValue& err) {
        qCCritical(scriptengine) << "Caught exception";

        auto output = err.engine() == _engine ? err : _engine->makeError(err);
        if (!output.property("detail").isValid()) {
            output.setProperty("detail", "UnhandledException");
        }

        // Unhandled exception kills the running script
        if (_abortOnUncaughtException) {
            stop(false);
            logException(output);
        }
    });
#endif

    // Forward exceptions from the scripting engine
    connect(_engine.get(), &ScriptEngine::exception, this, &ScriptManager::unhandledException);

    if (_type == Type::ENTITY_CLIENT || _type == Type::ENTITY_SERVER) {
        QObject::connect(this, &ScriptManager::update, this, [this]() {
            processEntityScriptContents();
        });
    }

    //Gather entity script messages for transmission when running server side.
    if (_type == Type::ENTITY_SERVER) {
        ;
    }

    if (!_areMetaTypesInitialized) {
        initMetaTypes();
    }
}

QString ScriptManager::getTypeAsString() const {
    auto value = QVariant::fromValue(_type).toString();
    return value.isEmpty() ? "unknown" : value.toLower();
}

QString ScriptManager::getContext() const {
    switch (_context) {
        case CLIENT_SCRIPT:
            return "client";
        case ENTITY_CLIENT_SCRIPT:
            return "entity_client";
        case ENTITY_SERVER_SCRIPT:
            return "entity_server";
        case AGENT_SCRIPT:
            return "agent";
        case NETWORKLESS_TEST_SCRIPT:
            return "networkless_test";
        default:
            return "unknown";
    }
    return "unknown";
}

bool ScriptManager::isDebugMode() const {
#if defined(DEBUG)
    return true;
#else
    return false;
#endif
}

ScriptManager::~ScriptManager() {
    auto scopeGuard = engine()->getScopeGuard();
    qDebug() << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
    if (_type == ScriptManager::Type::ENTITY_CLIENT) {
        printf("ScriptManager::~ScriptManager");
    }
    // We need to make sure that these get deleted before the script engine.
    _scriptingInterface.reset();
    _quatLibrary.reset();
    _vec3Library.reset();
    _mat4Library.reset();
    _uuidLibrary.reset();
    _consoleScriptingInterface.reset();
    _assetScriptingInterface.reset();
    _returnValue = ScriptValue();
    _isDeleted = true;
}

void ScriptManager::disconnectNonEssentialSignals() {
    disconnect();
    QThread* workerThread;
    // Keep destruction-to-quit wiring even before run starts or after it ends.
    // The worker event loop can still be alive while _isRunning is false.
    if (_isThreaded && (workerThread = thread())) {
        connect(this, &QObject::destroyed, workerThread, &QThread::quit, Qt::DirectConnection);
        connect(workerThread, &QThread::finished, workerThread, &QObject::deleteLater);
    }
}

void ScriptManager::runInThread() {
    if (_hasRunStarted.load()) { return; }
    Q_ASSERT_X(!_isThreaded, "ScriptManager::runInThread()", "runInThread should not be called more than once");

    if (_isThreaded) {
        return;
    }

    _isThreaded = true;

    // The thread interface cannot live on itself, and we want to move this into the thread, so
    // the thread cannot have this as a parent.
    QThread* workerThread = new QThread();
    QString name = QString("js:") + getFilename().replace("about:","");
    workerThread->setObjectName(name);
    _engine->setThread(workerThread);
    moveToThread(workerThread);
    _assetScriptingInterface->moveToThread(workerThread);

    // NOTE: If you connect any essential signals for proper shutdown or cleanup of
    // the script engine, make sure to add code to "reconnect" them to the
    // disconnectNonEssentialSignals() method
    connect(workerThread, &QThread::started, this, [this, name] {
        setThreadName(name.toStdString());
        run();
    });
    // QThread::quit is thread-safe. Do not queue it to the creator thread,
    // which may be waiting for this worker to finish after manager deletion.
    connect(this, &QObject::destroyed, workerThread, &QThread::quit, Qt::DirectConnection);
    connect(workerThread, &QThread::finished, workerThread, &QObject::deleteLater);

#if defined(OVERTE_E2E_FEATURE_TESTS)
    if (_featureWorkEnabled) {
        _featureTerminalThread=overte::e2e::ScriptTerminalObservation::process().bind(featureLoadMembership());
        const auto terminalThread=_featureTerminalThread;
        // No receiver/context/manager capture: receiver destruction is the
        // ordinary cause of worker quit, and must not remove this receipt.
        QObject::connect(workerThread,&QThread::finished,workerThread,[terminalThread] {
            overte::e2e::ScriptTerminalObservation::process().threadFinished(terminalThread);
        },Qt::DirectConnection);
    }
#endif
    workerThread->start();
}

void ScriptManager::executeOnScriptThread(std::function<void()> function, const Qt::ConnectionType& type ) {
    if (QThread::currentThread() != thread()) {
        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->executeOnScriptThread(function, type);
        });
        return;
    }

    function();
}

void ScriptManager::waitTillDoneRunning(bool shutdown) {
    // Engine should be stopped already, but be defensive
    stop();

    auto workerThread = thread();

    if (workerThread == QThread::currentThread()) {
        qCWarning(scriptengine) << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
        return;
    }

    if (_isThreaded && workerThread) {
        // We should never be waiting (blocking) on our own thread
        assert(workerThread != QThread::currentThread());

#if 0
        // 26 Feb 2021 - Disabled this OSX-specific code because it causes OSX to crash on shutdown; without this code, OSX
        // doesn't crash on shutdown. Qt 5.12.3 and Qt 5.15.2.
        //
        // On mac, don't call QCoreApplication::processEvents() here. This is to prevent
        // [NSApplication terminate:] from prematurely destroying the static destructors
        // while we are waiting for the scripts to shutdown. We will pump the message
        // queue later in the Application destructor.
        if (workerThread->isRunning()) {
            workerThread->quit();

            if (_engine->isEvaluating()) {
                qCWarning(scriptengine) << "Script Engine has been running too long, aborting:" << getFilename();
                _engine->abortEvaluation();
            } else {
                auto context = _engine->currentContext();
                if (context) {
                    qCWarning(scriptengine) << "Script Engine has been running too long, throwing:" << getFilename();
                    context->throwError("Timed out during shutdown");
                }
            }

            // Wait for the scripting thread to stop running, as
            // flooding it with aborts/exceptions will persist it longer
            static const auto MAX_SCRIPT_QUITTING_TIME = 0.5 * MSECS_PER_SECOND;
            if (!workerThread->wait(MAX_SCRIPT_QUITTING_TIME)) {
                workerThread->terminate();
            }
        }
#else
        //auto startedWaiting = usecTimestampNow();
        while (!_isDoneRunning) {
            // If the final evaluation takes too long, then tell the script engine to stop running
            //auto elapsedUsecs = usecTimestampNow() - startedWaiting;
            // TODO: This part was very unsafe and was causing crashes all the time.
            //  I disabled it for now until we find a safer solution.
            //  With it disabled now we get clean shutdowns and restarts.
            // V8TODO: temporarily increased script timeout. Maybe use different timeouts for release and unoptimized debug?
            /*static const auto MAX_SCRIPT_EVALUATION_TIME = 10 * USECS_PER_SECOND;
            if (elapsedUsecs > MAX_SCRIPT_EVALUATION_TIME) {
                workerThread->quit();

                if (_engine->isEvaluating()) {
                    qCWarning(scriptengine) << "Script Engine has been running too long (evaluation), aborting:" << getFilename();
                    _engine->abortEvaluation();
                } else {
                    auto context = _engine->currentContext();
                    if (context) {
                        qCWarning(scriptengine) << "Script Engine has been running too long (event loop), throwing:" << getFilename();
                        context->throwError("Timed out during shutdown");
                    }
                }

                // Wait for the scripting thread to stop running, as
                // flooding it with aborts/exceptions will persist it longer
                static const auto MAX_SCRIPT_QUITTING_TIME = 50 * MSECS_PER_SECOND;
                if (!workerThread->wait(MAX_SCRIPT_QUITTING_TIME)) {
                    Q_ASSERT(false);
                    workerThread->terminate();
                }
            }*/

            if (shutdown) {
                // NOTE: This will be called on the main application thread (among other threads) from stopAllScripts.
                //       The thread will need to continue to process events, because
                //       the scripts will likely need to marshall messages across to the main thread, e.g.
                //       if they access Settings or Menu in any of their shutdown code. So:
                // Process events for this thread, allowing invokeMethod calls to pass between threads.
                QCoreApplication::processEvents();
                // Events may use script engine so guard is necessary.
                auto scopeGuard = _engine->getScopeGuard();
                _engine->processEvents();
            }

            // Avoid a pure busy wait
            QThread::msleep(1);
        }
#endif

        scriptInfoMessage("Script Engine has stopped:" + getFilename(), "", -1);
    }
}

void ScriptManager::removeFromScriptEngines() {
    // Retirement may finish after the application's registry has been released.
    // Retain it across removal when available; an expired registry needs no edit.
    const auto scriptEngines = _scriptEngines.toStrongRef();
    if (scriptEngines) {
        scriptEngines->removeScriptEngine(shared_from_this());
    }
}

QString ScriptManager::getFilename() const {
    QStringList fileNameParts = _fileNameString.split("/");
    QString lastPart;
    if (!fileNameParts.isEmpty()) {
        lastPart = fileNameParts.last();
    }
    return lastPart;
}

QString ScriptManager::getAbsoluteFilename() const {
    return _fileNameString;
}

bool ScriptManager::hasValidScriptSuffix(const QString& scriptFileName) {
    QFileInfo fileInfo(scriptFileName);
    QString scriptSuffixToLower = fileInfo.completeSuffix().toLower();
    return scriptSuffixToLower.contains(QString("js"), Qt::CaseInsensitive);
}

void ScriptManager::loadURL(const QUrl& scriptURL, bool reload) {
    if (_isRunning) {
        return;
    }

    const auto loadRequest = _scriptLoadContext.next();
    if (!loadRequest.current()) {
        return;
    }
    QUrl url = expandScriptUrl(scriptURL);
    if (!loadRequest.current()) {
        return;
    }
    _fileNameString = url.toString();
#if defined(OVERTE_E2E_FEATURE_TESTS)
    _e2eRequiredModules.assignedLoadURL(url,loadRequest.featureGeneration());
#endif
    _isReloading = reload;

    // Check that script has a supported file extension
    if (!hasValidScriptSuffix(_fileNameString)) {
        scriptErrorMessage("File extension of file: " + _fileNameString + " is not a currently supported script type", _fileNameString, -1);
        if (!loadRequest.current()) {
            return;
        }
        emit errorLoadingScript(_fileNameString);
        return;
    }

    const auto maxRetries = 0; // for consistency with previous scriptCache->getScript() behavior
    std::weak_ptr<ScriptManager> weakRef(shared_from_this());
    auto scriptCache = DependencyManager::get<ScriptCache>();
    scriptCache->getScriptContents(url.toString(), [this, weakRef, loadRequest](const QString& url, const QString& scriptContents, bool isURL, bool success, const QString&status) {
        // Cache requests do not own the manager. Retain it only while delivering
        // a live completion, including reentrant error/loaded signal receivers.
        auto strongRef = weakRef.lock();
        if (!strongRef || !loadRequest.current()) {
            return;
        }
        // Consume this response before invoking any reentrant receiver. A new
        // load supersedes the completion ticket as well as all older requests.
        const auto completion = _scriptLoadContext.next();
        if (!completion.current()) {
            return;
        }
#if defined(OVERTE_E2E_FEATURE_TESTS)
        // Only the original live callback supplies its URL, result and ticket.
        // This is fetch completion, not proof of script initialization or effects.
        featureScriptLoads().record(_e2eRequiredModules.snapshot().value("instance").toString(),
            url, loadRequest.featureGeneration(), isURL, success, status);
#endif
        qCDebug(scriptengine) << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
        if (!completion.current()) {
            return;
        }
        if (!success) {
            scriptErrorMessage("ERROR Loading file (" + status + "):" + url, url, -1);
            if (!completion.current()) {
                return;
            }
            emit errorLoadingScript(_fileNameString);
            if (!completion.current()) {
                return;
            }

            // emitting scriptLoaded will keep Interface from discarding
            // scripts that might only be temporarily unavailable
            emit scriptLoaded(url);

            return;
        }

        _scriptContents = scriptContents;

        emit scriptLoaded(url);
    }, reload, maxRetries);
}

void ScriptManager::scriptErrorMessage(const QString& message, const QString& fileName, int lineNumber) {
    qCCritical(scriptengine) << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
    emit errorMessage(message, getFilename());
    if (!currentEntityIdentifier.isInvalidID()) {
        emit errorEntityMessage(message, fileName, lineNumber, currentEntityIdentifier, isEntityServerScript());
    } else {
        if (isEntityServerScript()) {
            emit errorEntityMessage(message, fileName, lineNumber, EntityItemID(), isEntityServerScript());
        }
    }
}

void ScriptManager::scriptWarningMessage(const QString& message, const QString& fileName, int lineNumber) {
    qCWarning(scriptengine) << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
    emit warningMessage(message, getFilename());
    if (!currentEntityIdentifier.isInvalidID()) {
        emit warningEntityMessage(message, fileName, lineNumber, currentEntityIdentifier, isEntityServerScript());
    } else {
        if (isEntityServerScript()) {
            emit warningEntityMessage(message, fileName, lineNumber, EntityItemID(), isEntityServerScript());
        }
    }
}

void ScriptManager::scriptInfoMessage(const QString& message, const QString& fileName, int lineNumber) {
    qCInfo(scriptengine) << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
    emit infoMessage(message, getFilename());
    if (!currentEntityIdentifier.isInvalidID()) {
        emit infoEntityMessage(message, fileName, lineNumber, currentEntityIdentifier, isEntityServerScript());
    } else {
        if (isEntityServerScript()) {
            emit infoEntityMessage(message, fileName, lineNumber, EntityItemID(), isEntityServerScript());
        }
    }
}

void ScriptManager::scriptPrintedMessage(const QString& message, const QString& fileName, int lineNumber) {
    qCDebug(scriptengine) << overte::security::diagnosticEvent(overte::security::DiagnosticEvent::Redacted);
    emit printedMessage(message, getFilename());
    if (!currentEntityIdentifier.isInvalidID()) {
        emit printedEntityMessage(message, fileName, lineNumber, currentEntityIdentifier, isEntityServerScript());
    } else {
        if (isEntityServerScript()) {
            // TODO: Some callbacks like for example websockets one right now
            // don't set currentEntityIdentifier and there doesn't seem to be easy way to add it currently
            emit printedEntityMessage(message, fileName, lineNumber, EntityItemID(), isEntityServerScript());
        }
    }
}

void ScriptManager::clearDebugLogWindow() {
    emit clearDebugWindow();
}

// Templated qScriptRegisterMetaType fails to compile with raw pointers
using ScriptableResourceRawPtr = ScriptableResource*;

static ScriptValue scriptableResourceToScriptValue(ScriptEngine* engine,
                                                    const ScriptableResourceRawPtr& resource) {
    if (!resource) {
        return ScriptValue();  // probably shutting down
    }

    // The first script to encounter this resource will track its memory.
    // In this way, it will be more likely to GC.
    // This fails in the case that the resource is used across many scripts, but
    // in that case it would be too difficult to tell which one should track the memory, and
    // this serves the common case (use in a single script).
    auto data = resource->getResource();
    auto manager = engine->manager();
    if (data && manager && !resource->isInScript()) {
        resource->setInScript(true);
        QObject::connect(data.data(), &Resource::updateSize, manager, &ScriptManager::updateMemoryCost);
    }

    auto object = engine->newQObject(const_cast<ScriptableResourceRawPtr>(resource), ScriptEngine::ScriptOwnership);
    return object;
}

static bool scriptableResourceFromScriptValue(const ScriptValue& value, ScriptableResourceRawPtr& resource) {
    resource = static_cast<ScriptableResourceRawPtr>(value.toQObject());
    return true;
}

/*@jsdoc
 * The <code>Resource</code> API provides values that define the possible loading states of a resource.
 *
 * @namespace Resource
 *
 * @hifi-interface
 * @hifi-client-entity
 * @hifi-avatar
 * @hifi-server-entity
 * @hifi-assignment-client
 *
 * @property {Resource.State} State - The possible loading states of a resource. <em>Read-only.</em>
 */
static ScriptValue createScriptableResourcePrototype(ScriptManagerPointer manager) {
    auto engine = manager->engine();
    auto prototype = engine->newObject();

    auto state = engine->newObject();
    auto metaEnum = QMetaEnum::fromType<ScriptableResource::State>();
    for (int i = 0; i < metaEnum.keyCount(); ++i) {
        state.setProperty(metaEnum.key(i), metaEnum.value(i));
    }

    prototype.setProperty("State", state);

    return prototype;
}

ScriptValue externalResourceBucketToScriptValue(ScriptEngine* engine, ExternalResource::Bucket const& in) {
    return engine->newValue((int)in);
}

bool externalResourceBucketFromScriptValue(const ScriptValue& object, ExternalResource::Bucket& out) {
    out = static_cast<ExternalResource::Bucket>(object.toInt32());
    return true;
}

void ScriptManager::resetModuleCache(bool deleteScriptCache) {
    if (QThread::currentThread() != thread()) {
        executeOnScriptThread([=, this]() { resetModuleCache(deleteScriptCache); });
        return;
    }
    auto jsRequire = _engine->globalObject().property("Script").property("require");
    auto cache = jsRequire.property("cache");
    auto cacheMeta = jsRequire.data();

    if (deleteScriptCache) {
        auto it = cache.newIterator();
        while (it->hasNext()) {
            it->next();
            if (it->flags() & ScriptValue::SkipInEnumeration) {
                continue;
            }
            qCDebug(scriptengine) << "resetModuleCache(true) -- staging " << it->name() << " for cache reset at next require";
            cacheMeta.setProperty(it->name(), true);
        }
    }
    cache = _engine->newObject();
    if (!cacheMeta.isObject()) {
        cacheMeta = _engine->newObject();
        cacheMeta.setProperty("id", "Script.require.cacheMeta");
        cacheMeta.setProperty("type", "cacheMeta");
        jsRequire.setData(cacheMeta);
    }
    cache.setProperty("__created__", (double)QDateTime::currentMSecsSinceEpoch(), ScriptValue::SkipInEnumeration);
#if DEBUG_JS_MODULES
    cache.setProperty("__meta__", cacheMeta, READONLY_HIDDEN_PROP_FLAGS);
#endif
    jsRequire.setProperty("cache", cache, READONLY_PROP_FLAGS);
}

void ScriptManager::initMetaTypes() {
    if (_areMetaTypesInitialized) {
        return;
    }
    _areMetaTypesInitialized = true;
    runStaticTypesInitializers(this);
}

void ScriptManager::init() {
    auto scopeGuard = engine()->getScopeGuard();
    auto* sgp = scopeGuard.get();
    if (_isInitialized) {
        return; // only initialize once
    }

    // Native registration must finish before permanently aborting V8: an
    // aborted engine returns empty properties, including Script.require.
    // Keep stop requests immediate without waiting for this worker's Locker.
    _isInitializing.store(true);
    Finally finishInitialization([this] {
        _isInitializing.store(false);
        if (isStopping()) { _engine->abortEvaluation(); }
    });
    if (isStopping() || isStopped()) { return; }

    _isInitialized = true;

    if (_context != NETWORKLESS_TEST_SCRIPT) {
        // This initializes a bunch of systems that want network access. We
        // want to avoid it in test script mode.
        runStaticInitializers(this);
    }

    auto scriptEngine = _engine.get();

    if (_context != NETWORKLESS_TEST_SCRIPT) {
        // For test scripts we want to minimize the amount of functionality available, for the least
        // amount of dependencies and faster test system startup.

        ScriptValue xmlHttpRequestConstructorValue = scriptEngine->newFunction(XMLHttpRequestClass::constructor);
        scriptEngine->globalObject().setProperty("XMLHttpRequest", xmlHttpRequestConstructorValue);

        ScriptValue webSocketConstructorValue = scriptEngine->newFunction(WebSocketClass::constructor);
        scriptEngine->globalObject().setProperty("WebSocket", webSocketConstructorValue);
    }

    /*@jsdoc
     * Prints a message to the program log and emits {@link Script.printedMessage}.
     * The message logged is the message values separated by spaces.
     * <p>Alternatively, you can use {@link Script.print} or one of the {@link console} API methods.</p>
     * @function print
     * @param {...*} [message] - The message values to print.
     */
    scriptEngine->globalObject().setProperty("print", scriptEngine->newFunction(debugPrint));

    // NOTE: You do not want to end up creating new instances of singletons here. They will be on the ScriptManager thread
    // and are likely to be unusable if we "reset" the ScriptManager by creating a new one (on a whole new thread).

    scriptEngine->registerGlobalObject(sgp, "Script", _scriptingInterface.get());

    {
        // set up Script.require.resolve and Script.require.cache
        auto Script = scriptEngine->globalObject().property("Script");
        auto require = Script.property("require");
        auto resolve = Script.property("_requireResolve");
        require.setProperty("resolve", resolve, READONLY_PROP_FLAGS);

        scriptEngine->globalObject().setProperty("require", require, READONLY_PROP_FLAGS);
        resetModuleCache();
    }

    scriptEngine->registerEnum(sgp, "Script.ExternalPaths", QMetaEnum::fromType<ExternalResource::Bucket>());

    scriptEngine->registerGlobalObject(sgp, "Quat", _quatLibrary.get());
    scriptEngine->registerGlobalObject(sgp, "Vec3", _vec3Library.get());
    scriptEngine->registerGlobalObject(sgp, "Mat4", _mat4Library.get());
    scriptEngine->registerGlobalObject(sgp, "Uuid", _uuidLibrary.get());

#if defined(Q_OS_IOS) || defined(OVERTE_IOS)
    {
        const auto global = scriptEngine->globalObject();
        const auto scriptApi = global.property("Script");
        const auto quatApi = global.property("Quat");
        qInfo().nospace()
            << "OVERTE_IOS_SCRIPT_API_GATE context=" << getContext()
            << " script_require=" << scriptApi.property("require").isFunction()
            << " script_load=" << scriptApi.property("load").isFunction()
            << " script_include=" << scriptApi.property("include").isFunction()
            << " script_set_interval=" << scriptApi.property("setInterval").isFunction()
            << " quat_from_vec3_degrees=" << quatApi.property("fromVec3Degrees").isFunction();
    }
#endif

    if (_context != NETWORKLESS_TEST_SCRIPT) {
        // This requires networking, we want to avoid the need for it in test scripts
        scriptEngine->registerGlobalObject(sgp, "Messages", DependencyManager::get<MessagesClient>().data());
    }

    registerConsoleScriptingInterface(sgp, scriptEngine);

    // constants
    scriptEngine->globalObject().setProperty("TREE_SCALE", scriptEngine->newValue(TREE_SCALE));

    if (_context != NETWORKLESS_TEST_SCRIPT) {
        // Scriptable cache access
        auto resourcePrototype = createScriptableResourcePrototype(shared_from_this());
        scriptEngine->globalObject().setProperty("Resource", resourcePrototype);
        scriptEngine->setDefaultPrototype(qMetaTypeId<ScriptableResource*>(), resourcePrototype);

        scriptEngine->registerGlobalObject(sgp, "Assets", _assetScriptingInterface.get());
        scriptEngine->registerGlobalObject(sgp, "Resources", DependencyManager::get<ResourceScriptingInterface>().data());

        scriptEngine->registerGlobalObject(sgp, "DebugDraw", &DebugDraw::getInstance());

        scriptEngine->registerGlobalObject(sgp, "UserActivityLogger", DependencyManager::get<UserActivityLoggerScriptingInterface>().data());
    }

#if DEV_BUILD || PR_BUILD
    scriptEngine->registerGlobalObject(sgp, "StackTest", new StackTestScriptingInterface(this));
#endif

    qCDebug(scriptengine) << "Engine initialized";
}

// registers a global object by name
void ScriptManager::registerValue(const QString& valueName, ScriptValue value) {
    _engine->globalObject().setProperty(valueName, value);
}

// Unregister the handlers for this eventName and entityID.
void ScriptManager::removeEventHandler(const EntityItemID& entityID, const QString& eventName, const ScriptValue& handler) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::removeEventHandler() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "] "
            "entityID:" << entityID << " eventName:" << eventName;
#endif
        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->removeEventHandler(entityID, eventName, handler);
        });
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::removeEventHandler() called on thread [" << QThread::currentThread() << "] entityID:" << entityID << " eventName : " << eventName;
#endif

    if (!_registeredHandlers.contains(entityID)) {
        return;
    }
    RegisteredEventHandlers& handlersOnEntity = _registeredHandlers[entityID];
    CallbackList& handlersForEvent = handlersOnEntity[eventName];
    // ScriptValue does not have operator==(), so we can't use QList::removeOne and friends. So iterate.
    for (int i = 0; i < handlersForEvent.count(); ++i) {
        if (handlersForEvent[i].function.equals(handler)) {
            handlersForEvent.removeAt(i);
            return; // Design choice: since comparison is relatively expensive, just remove the first matching handler.
        }
    }
}

// Unregister all event handlers for the specified entityID (i.e. the entity is being removed)
void ScriptManager::removeAllEventHandlers(const EntityItemID& entityID) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::removeAllEventHandlers() called on wrong thread [" << QThread::currentThread() << ", correct thread is " << thread() << " ], ignoring "
            "entityID:" << entityID;
#endif
        return;
    }

    if (_registeredHandlers.contains(entityID)) {
        _registeredHandlers.remove(entityID);
    }
}

// Register the handler.
void ScriptManager::addEventHandler(const EntityItemID& entityID, const QString& eventName, const ScriptValue& handler) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::addEventHandler() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "] "
        "entityID:" << entityID << " eventName:" << eventName;
#endif

        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->addEventHandler(entityID, eventName, handler);
        });
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::addEventHandler() called on thread [" << QThread::currentThread() << "] entityID:" << entityID << " eventName : " << eventName;
#endif

    if (_registeredHandlers.count() == 0) {
        // First time any per-entity handler has been added in this script...
        emit attachDefaultEventHandlers();
    }
    if (!_registeredHandlers.contains(entityID)) {
        _registeredHandlers[entityID] = RegisteredEventHandlers();
    }
    CallbackList& handlersForEvent = _registeredHandlers[entityID][eventName];
    CallbackData handlerData = { handler, currentEntityIdentifier, currentSandboxURL, _currentEntityScriptConsentRequest };
    handlersForEvent << handlerData; // Note that the same handler can be added many times. See removeEntityEventHandler().
}

bool ScriptManager::isStopped() const {
    if (_context == NETWORKLESS_TEST_SCRIPT) {
        return false;
    }

    QSharedPointer<ScriptEngines> scriptEngines(_scriptEngines);
    return !scriptEngines || scriptEngines->isStopped();
}

void ScriptManager::run() {
    // The engine abort latch is permanent; neither repeated nor reentrant run
    // may initialize or publish a second terminal lifecycle for this manager.
    if (_hasRunStarted.exchange(true)) { return; }
    const auto runOwner = shared_from_this();
    auto scopeGuard = _engine->getScopeGuard();
    const bool previousLocalAccess = hifi::scripting::isLocalAccessSafeThread();
    Finally finishRun([this, previousLocalAccess] {
        stop(false);
        scriptInfoMessage("Script Engine stopping:" + getFilename(), getFilename(), -1);

        stopAllTimers(); // make sure all our timers are stopped if the script is ending
        if (_isInitialized) { emit scriptEnding(); }

        emit releaseEntityPacketSenderMessages(true);

        emit finished(_fileNameString, shared_from_this());

        // Restore the caller's thread-local state, including a cancelled start.
        hifi::scripting::setLocalAccessSafeThread(previousLocalAccess);
        _isRunning = false;
        emit runningStateChanged();
        emit doneRunning();
        _engine->disconnectSignalProxies();
        // Process all remaining events
        {
            QEventLoop loop;
            loop.processEvents();
        }
        _isDoneRunning = true;
#if defined(OVERTE_E2E_FEATURE_TESTS)
        if (_featureWorkEnabled && _featureWorkValid.load()) {
            // Owner thread, after scriptEnding returned, proxy disconnect and
            // final queued-event processing. Worker exit is a separate event.
            overte::e2e::ScriptTerminalObservation::process().shutdownDrained(
                _featureTerminalThread,featureLoadMembership(),featureSourceIdentity(),
                _featureSignalCallbacks,_featureTimerCallbacks,_engine->isEvaluating(),_timerFunctionMap.size());
        }
#endif
    });
    if (isStopping() || isStopped()) { return; }
    if (QThread::currentThread() != qApp->thread() && _context == Context::CLIENT_SCRIPT) {
        // Flag that we're allowed to access local HTML files on UI created from C++ calls on this thread
        // (because we're a client script)
        hifi::scripting::setLocalAccessSafeThread(true);
    }

    if (QThread::currentThread() != _assetScriptingInterface->thread()) {
        _assetScriptingInterface->moveToThread(QThread::currentThread());
    }

    auto filenameParts = _fileNameString.split("/");
    auto name = filenameParts.size() > 0 ? filenameParts[filenameParts.size() - 1] : "unknown";
    PROFILE_SET_THREAD_NAME("Script: " + name);

    scriptInfoMessage("Script Engine starting:" + getFilename(), getFilename(), -1);

    if (!_isInitialized) {
        init();
    }

    if (isStopping() || isStopped()) { return; }

    _isRunning = true;
    emit runningStateChanged();
    if (isStopping() || isStopped()) { return; }

    {
        PROFILE_RANGE(script, _fileNameString);
#if defined(OVERTE_E2E_FEATURE_TESTS)
        _e2eRequiredModules.submitted(_scriptContents);
#if defined(Q_OS_IOS)
        _featureCreateSources.submitted(_fileNameString,_scriptContents);
        _featureSnapshotSources.submitted(_fileNameString,_scriptContents);
        try { _featureSnapshotHttpSources.submitted(_fileNameString,_scriptContents); }
        catch (...) { _featureSnapshotHttpSources.snapshotUnavailable(); }
        try { _featureSnapshotCombinedSources.submitted(_fileNameString,_scriptContents); }
        catch (...) { _featureSnapshotCombinedSources.snapshotUnavailable(); }
        try { _featureChatSources.submitted(_fileNameString,_scriptContents); }
        catch (...) { _featureChatSources.unavailable(); }
        _featureAvatarScript->submitted(_fileNameString,_scriptContents);
#endif
#endif
        _returnValue = _engine->evaluate(_scriptContents, _fileNameString);

        if (_engine->hasUncaughtException() && _abortOnUncaughtException) {

            qCWarning(scriptengine) << "Engine has uncaught exception, stopping";
            stop();
            // V8TODO: Is clearing needed here?
            //_engine->clearExceptions();
        }
    }
#ifdef _WIN32
    // VS13 does not sleep_until unless it uses the system_clock, see:
    // https://www.reddit.com/r/cpp_questions/comments/3o71ic/sleep_until_not_working_with_a_time_pointsteady/
    using clock = std::chrono::system_clock;
#else
    using clock = std::chrono::high_resolution_clock;
#endif

    clock::time_point startTime = clock::now();
    int thisFrame = 0;

    _lastUpdate = usecTimestampNow();

    std::chrono::microseconds totalUpdates(0);
#ifdef Q_OS_ANDROID
    qint64 lastPhoneMemoryReport { 0 };
#endif

    qCDebug(scriptengine) << "Waiting for finish";

    // TODO: Integrate this with signals/slots instead of reimplementing throttling for ScriptManager
    while (!_isFinished) {
        //qCDebug(scriptengine) << "In script event loop";

        auto beforeSleep = clock::now();

        // Throttle to SCRIPT_FPS
        // We'd like to try to keep the script at a solid SCRIPT_FPS update rate. And so we will
        // calculate a sleepUntil to be the time from our start time until the original target
        // sleepUntil for this frame. This approach will allow us to "catch up" in the event
        // that some of our script udpates/frames take a little bit longer than the target average
        // to execute.
        // NOTE: if we go to variable SCRIPT_FPS, then we will need to reconsider this approach
        const std::chrono::microseconds TARGET_SCRIPT_FRAME_DURATION(USECS_PER_SECOND / SCRIPT_FPS + 1);
        clock::time_point targetSleepUntil(startTime + (thisFrame++ * TARGET_SCRIPT_FRAME_DURATION));

        // However, if our sleepUntil is not at least our average update and timer execution time
        // into the future it means our script is taking too long in its updates, and we want to
        // punish the script a little bit. So we will force the sleepUntil to be at least our
        // averageUpdate + averageTimerPerFrame time into the future.
        auto averageUpdate = totalUpdates / thisFrame;
        auto averageTimerPerFrame = _totalTimerExecution / thisFrame;
        auto averageTimerAndUpdate = averageUpdate + averageTimerPerFrame;
        auto sleepUntil = std::max(targetSleepUntil, beforeSleep + averageTimerAndUpdate);

        // We don't want to actually sleep for too long, because it causes our scripts to hang
        // on shutdown and stop... so we want to loop and sleep until we've spent our time in
        // purgatory, constantly checking to see if our script was asked to end
        bool processedEvents = false;
        if (!_isFinished) {
            PROFILE_RANGE(script, "processEvents-sleep");
            std::chrono::milliseconds sleepFor =
                std::chrono::duration_cast<std::chrono::milliseconds>(sleepUntil - clock::now());
            if (sleepFor > std::chrono::milliseconds(0)) {
                QEventLoop loop;
                QTimer timer;
                timer.setSingleShot(true);
                connect(&timer, &QTimer::timeout, &loop, &QEventLoop::quit);
                timer.start(sleepFor.count());
                loop.exec();
            } else {
                QCoreApplication::processEvents();
            }
            _engine->processEvents();
            processedEvents = true;
            _engine->perManagerLoopIterationCleanup();
        }

        PROFILE_RANGE(script, "ScriptMainLoop");

//#define SCRIPT_DELAY_DEBUG
#ifdef SCRIPT_DELAY_DEBUG
        {
            auto actuallySleptUntil = clock::now();
            uint64_t seconds = std::chrono::duration_cast<std::chrono::seconds>(actuallySleptUntil - startTime).count();
            if (seconds > 0) { // avoid division by zero and time travel
                uint64_t fps = thisFrame / seconds;
                // Overreporting artificially reduces the reported rate
                const int REPORT_BELOW_FPS = 30;
                if (thisFrame % SCRIPT_FPS == 0 && fps < REPORT_BELOW_FPS) {
                    qCDebug(scriptengine) <<
                        "Script:" << name <<
                        "Frame:" << thisFrame <<
                        "Slept (us):" << std::chrono::duration_cast<std::chrono::microseconds>(actuallySleptUntil - beforeSleep).count() <<
                        "Avg Updates (us):" << averageUpdate.count() <<
                        "averageTimerPerFrame (us):" << averageTimerPerFrame.count() <<
                        "FPS:" << fps;
                }
            }
        }
#endif
        if (_isFinished) {
            break;
        }

        // Only call this if we didn't processEvents as part of waiting for next frame
        if (!processedEvents) {
            PROFILE_RANGE(script, "processEvents");
            QCoreApplication::processEvents();
            _engine->processEvents();
        }

        if (_isFinished) {
            break;
        }

        if (!_isFinished) {
            emit releaseEntityPacketSenderMessages(false);
        }

        qint64 now = usecTimestampNow();

#ifdef Q_OS_ANDROID
        if (now - lastPhoneMemoryReport >= 5 * USECS_PER_SECOND) {
            lastPhoneMemoryReport = now;
            char testModeValue[PROP_VALUE_MAX] {};
            const bool phoneTestMode = __system_property_get("debug.overte.test_mode", testModeValue) > 0 &&
                (qstrcmp(testModeValue, "1") == 0 || qstricmp(testModeValue, "on") == 0 ||
                    qstricmp(testModeValue, "true") == 0);
            if (phoneTestMode) {
                const auto statistics = _engine->getMemoryUsageStatistics();
                const auto encodedURL = QUrl::toPercentEncoding(_fileNameString, "", " ,\n\r\t");
                qCWarning(scriptengine).noquote()
                    << QStringLiteral("PHONE_PERF record=script_heap epoch_ms=")
                        + QString::number(QDateTime::currentMSecsSinceEpoch())
                        + QStringLiteral(" script=") + QString::fromLatin1(encodedURL)
                        + QStringLiteral(" total_heap_bytes=") + QString::number(statistics.totalHeapSize)
                        + QStringLiteral(" used_heap_bytes=") + QString::number(statistics.usedHeapSize)
                        + QStringLiteral(" available_bytes=") + QString::number(statistics.totalAvailableSize)
                        + QStringLiteral(" used_global_handles_bytes=") + QString::number(statistics.usedGlobalHandlesSize);
            }
        }
#endif

        // we check for 'now' in the past in case people set their clock back
        if (_emitScriptUpdates() && _lastUpdate < now) {
            float deltaTime = (float) (now - _lastUpdate) / (float) USECS_PER_SECOND;
            if (!_isFinished) {
                auto preUpdate = clock::now();
                {
                    PROFILE_RANGE(script, "ScriptUpdate");
                    emit update(deltaTime);
                }
                auto postUpdate = clock::now();
                auto elapsed = (postUpdate - preUpdate);
                totalUpdates += std::chrono::duration_cast<std::chrono::microseconds>(elapsed);
            }
        }
        _lastUpdate = now;

        // only clear exceptions if we are not in the middle of evaluating
        if (!_engine->isEvaluating() && _engine->hasUncaughtException()) {
            qCWarning(scriptengine) << __FUNCTION__ << "---------- UNCAUGHT EXCEPTION --------";
            qCWarning(scriptengine) << "runInThread" << _engine->uncaughtException();
            emit unhandledException(_engine->uncaughtException());
            _engine->clearExceptions();
        }
    }
}

#if defined(OVERTE_E2E_FEATURE_TESTS)
thread_local QVariantMap ScriptManager::_featureNativeCallContext;

QVariantMap ScriptManager::featureNativeCallContext() { return _featureNativeCallContext; }

ScriptManager::FeatureNativeCallScope::FeatureNativeCallScope(const QVariantMap& original) :
    _previous(_featureNativeCallContext) {
    _featureNativeCallContext=original;
}

ScriptManager::FeatureNativeCallScope::FeatureNativeCallScope(ScriptManager* manager, const QByteArray& method, const QVariantMap& emitStack) :
    _previous(_featureNativeCallContext) {
    _featureNativeCallContext.clear();
    if (!manager || !manager->_featureWorkEnabled || QThread::currentThread()!=manager->thread()
            || (method!="overrideAnimation" && method!="restoreAnimation"
#if defined(Q_OS_IOS)
                && method!="emitScriptEvent" && method!="featureIOSCreateEvent" && method!="featureIOSWorldWebEvent" && method!="featureIOSSnapshotEvent"
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
                && method!="shareSnapshot"
#if defined(OVERTE_E2E_VOICE_TESTS)
                && method!="playSound" && method!="featureIOSAudioOnceCue"
#endif
#endif
                && method!="addButton" && method!="addEntity" && method!="deleteEntity"
#endif
                )
            || manager->_featureNativeCallSequence>=1000000000) { return; }
    const auto membership=manager->featureLoadMembership();const auto code=manager->featureSourceIdentity();
    if (membership.isEmpty() || code.isEmpty() || !membership.value("assigned").toBool()
            || !code.value("submitted").toBool()) { return; }
    _featureNativeCallContext={{"callerVersion",1},{"method",QString::fromLatin1(method)},
        {"sequence",static_cast<qulonglong>(++manager->_featureNativeCallSequence)},
        {"invokedEpochMs",QDateTime::currentMSecsSinceEpoch()},{"manager",membership},{"code",code}};
#if defined(Q_OS_IOS)
    if (method=="emitScriptEvent") { _featureNativeCallContext.insert("emitStack",emitStack.isEmpty()?QVariant():QVariant(emitStack)); }
    if (method=="featureIOSCreateEvent") { _featureNativeCallContext.insert("codeSources",manager->featureCreateSources()); }
    if (method=="featureIOSSnapshotEvent") {
        _featureNativeCallContext.insert("codeSources",manager->featureSnapshotSources());
        try {
            _featureNativeCallContext.insert("snapshotCombinedSources",manager->featureSnapshotCombinedSources());
            _featureNativeCallContext.insert("snapshotCombinedStack",manager->featureAvatarV8Stack());
        } catch (...) { manager->_featureSnapshotCombinedSources.snapshotUnavailable(); }
    }
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
    if (method=="shareSnapshot") {
        try {
            _featureNativeCallContext.insert("snapshotCombinedSources",manager->featureSnapshotCombinedSources());
            _featureNativeCallContext.insert("snapshotCombinedStack",manager->featureAvatarV8Stack());
        } catch (...) {manager->_featureSnapshotCombinedSources.snapshotUnavailable();}
    }
#endif
    if (method=="addEntity" || method=="deleteEntity") {
        _featureNativeCallContext.insert("callerChain",manager->featureAvatarTimerCallers());
        const auto original=manager->featureAvatarScriptObservation();
        _featureNativeCallContext.insert("avatarCode",QVariantMap{{"avatarScriptVersion",original.value("avatarScriptVersion")},
            {"instance",original.value("instance")},{"complete",original.value("complete")},{"code",original.value("code")}});
        const auto avatarCallers=overte::e2e::AvatarV8Callers::resolve(manager->featureAvatarV8Stack(),original.value("code").toList());
        _featureNativeCallContext.insert("avatarCallers",QVariantMap{{"avatarEntityCallersVersion",1},
            {"complete",avatarCallers.complete},{"callerStack",avatarCallers.stack},{"callerModules",avatarCallers.modules}});
    }
#endif
}

ScriptManager::FeatureNativeCallScope::~FeatureNativeCallScope() { _featureNativeCallContext=_previous; }

void ScriptManager::featureCallbackBoundary(bool timer, bool entering) {
    if (QThread::currentThread()!=thread()) { _featureWorkValid=false;return; }
    auto& count=timer ? _featureTimerCallbacks : _featureSignalCallbacks;
    if ((entering && count>=1000000000) || (!entering && count==0)) { _featureWorkValid=false;return; }
    if (entering) { ++count; } else { --count; }
}

QVariantMap ScriptManager::featureWorkObservation(const QString& requestId) {
    if (!_featureWorkEnabled || !_featureWorkValid || !thread() || !thread()->isRunning()
            || !isRunning() || isStopping() || isFinished() || _isDoneRunning) { return {}; }
    std::lock_guard<std::mutex> lock(_featureWorkMutex);
    if (requestId==_featureWorkRequest) {
        return _featureWorkPending ? QVariantMap{{"pending",true}} : _featureWorkResult;
    }
    if (_featureWorkPending || _featureWorkSequence>=1000000000) { return {}; }
    _featureWorkRequest=requestId;_featureWorkResult.clear();_featureWorkPending=true;
    const auto sequence=++_featureWorkSequence;
    const auto requested=QDateTime::currentMSecsSinceEpoch();
    // This normal-priority owner-thread barrier follows already posted Qt
    // input deliveries. It never blocks the GUI or forwards a product input.
    const bool posted=QMetaObject::invokeMethod(this,[this,requestId,sequence,requested] {
        QVariantMap result;
        if (QThread::currentThread()==thread() && _featureWorkValid && isRunning()
                && !isStopping() && !isFinished() && !_isDoneRunning && _timerFunctionMap.size()<=256) {
            const auto membership=featureLoadMembership();const auto code=featureSourceIdentity();
            QVariantList timers;
            bool complete=!membership.isEmpty() && !code.isEmpty() && _engine;
            for (const auto& entry:_timerFunctionMap) {
                const auto& timer=entry.second.first;
                if (!timer || timer->thread()!=QThread::currentThread() || entry.first<=0) { complete=false;break; }
                timers.append(QVariantMap{{"handle",entry.first},{"active",timer->isActive()},
                    {"singleShot",timer->isSingleShot()},{"intervalMs",timer->interval()},{"remainingMs",timer->remainingTime()}});
            }
            if (complete) {
                const auto captured=QDateTime::currentMSecsSinceEpoch();
                if (captured>=requested) {
                    result={{"manager",membership},{"code",code},{"work",QVariantMap{
                        {"scriptWorkVersion",1},{"requestId",requestId},{"sequence",static_cast<qulonglong>(sequence)},
                        {"requestedEpochMs",requested},{"capturedEpochMs",captured},
                        {"signalCallbacks",static_cast<qulonglong>(_featureSignalCallbacks)},
                        {"timerCallbacks",static_cast<qulonglong>(_featureTimerCallbacks)},
                        {"evaluating",_engine->isEvaluating()},{"timers",timers}}}};
                }
            }
        }
        std::lock_guard<std::mutex> completed(_featureWorkMutex);
        if (_featureWorkRequest==requestId && _featureWorkPending) {
            _featureWorkResult=result;_featureWorkPending=false;
        }
    },Qt::QueuedConnection);
    if (!posted) { _featureWorkPending=false;_featureWorkValid=false;return {}; }
    return {{"pending",true}};
}

#endif

// NOTE: This is private because it must be called on the same thread that created the timers, which is why
// we want to only call it in our own run "shutdown" processing.
void ScriptManager::stopAllTimers() {
    _timerFunctionMap.clear();
    _timerHandleCounter = 1;
}

void ScriptManager::stopAllTimersForEntityScript(const EntityItemID& entityID) {
    std::erase_if(_timerFunctionMap, [entityID](auto& i) { return i.second.second.definingEntityIdentifier == entityID; });
    // the timer map is potentially shared across multiple entity scripts,
    // so don't clear it or reset the handle counter
}

void ScriptManager::stop(bool marshal) {
    _isStopping = true; // this can be done on any thread
    _scriptLoadContext.setActive(false);

    // Interrupt JavaScript before queuing manager-thread work: that thread may
    // be occupied by an unbounded evaluation. Retain the engine during the call.
    auto engine = _engine;
    if (engine && !_isInitializing.load()) {
        engine->abortEvaluation();
    }

    if (marshal) {
        // Lambda is necessary there to keep shared_ptr counter above zero if this gets called from different thread
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->stop(false);
        });
        return;
    }

    if (!_isFinished) {
        _isFinished = true;
        emit runningStateChanged();
    }
}

void ScriptManager::updateMemoryCost(const qint64& deltaSize) {
    _engine->updateMemoryCost(deltaSize);
}

void ScriptManager::timerFired(int handle) {
    if (isStopped()) {
        scriptWarningMessage("Script.timerFired() while shutting down is ignored... parent script:" + getFilename(), getFilename(), -1);
        return; // bail early
    }

    // Timer events shouldn't be processed after the script engine has shut down.
    if (_isDoneRunning) {
        return;
    }

//#define SCRIPT_TIMER_PERFORMANCE_STATISTICS
#ifdef SCRIPT_TIMER_PERFORMANCE_STATISTICS
    _timerCallCounter++;
    if (_timerCallCounter % 100 == 0) {
        qCDebug(scriptengine) << "Script engine: " << _engine->manager()->getFilename()
                 << "timer call count: " << _timerCallCounter << " total time: " << _totalTimeInTimerEvents_s;
    }
    QElapsedTimer callTimer;
    callTimer.start();
#endif

    if (!_timerFunctionMap.contains(handle)) {
        qCWarning(scriptengine) << "timerFired -- not in _timerFunctionMap" << handle;
        return;
    }

    auto& functionPair = _timerFunctionMap[handle];
    auto& timer = functionPair.first;
    auto data = functionPair.second;
#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(Q_OS_IOS)
    const auto avatarTimer=_featureAvatarScript->fired(handle,timer.get());
    const auto avatarUiTimer=_featureAvatarUiWork->fired(handle,timer.get());
    Finally avatarUiDispatchReturned([&] { _featureAvatarUiWork->dispatchReturned(avatarUiTimer); });
    const auto snapshotTimer=_featureSnapshotTimerWork->fired(handle,timer.get());
    const auto combinedSnapshotTimer=featureSnapshotCombinedTimerFired(handle,timer.get());
    Finally snapshotDispatchReturned([&] {_featureSnapshotTimerWork->dispatchReturned(snapshotTimer);featureSnapshotCombinedTimerReturned(combinedSnapshotTimer);});
#endif

    if (!timer->isActive()) {
        // this timer is done, we can kill it
        _timerFunctionMap.erase(handle);
    }

    // call the associated JS function, if it exists
    if (data.function.isValid()) {
#if defined(OVERTE_E2E_FEATURE_TESTS)
        FeatureCallbackScope featureCallback(this,true);
#endif
        PROFILE_RANGE(script, __FUNCTION__);
        auto preTimer = p_high_resolution_clock::now();
#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(Q_OS_IOS)
        _featureAvatarScript->callback(avatarTimer,true);
        Finally avatarCallbackLeft([&] { _featureAvatarScript->callback(avatarTimer,false); });
        _featureAvatarUiWork->callback(avatarUiTimer,true);
        Finally avatarUiCallbackLeft([&] { _featureAvatarUiWork->callback(avatarUiTimer,false); });
        _featureSnapshotTimerWork->callback(snapshotTimer,true);
        featureSnapshotCombinedTimerCallback(combinedSnapshotTimer,true);
        Finally snapshotCallbackLeft([&] {_featureSnapshotTimerWork->callback(snapshotTimer,false);featureSnapshotCombinedTimerCallback(combinedSnapshotTimer,false);});
#endif
        callWithEnvironment(data.definingEntityIdentifier, data.definingSandboxURL, data.function, data.function, ScriptValueList(), data.consentRequest);
        auto postTimer = p_high_resolution_clock::now();
        auto elapsed = (postTimer - preTimer);
        _totalTimerExecution += std::chrono::duration_cast<std::chrono::microseconds>(elapsed);
    } else {
        qCWarning(scriptengine) << "timerFired -- invalid function" << data.function.toVariant().toString();
    }

#ifdef SCRIPT_TIMER_PERFORMANCE_STATISTICS
    _totalTimeInTimerEvents_s += callTimer.elapsed() / 1000.0;
#endif
}

#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(Q_OS_IOS)
QString ScriptManager::featureSnapshotCombinedTimerFired(int handle,const QTimer* timer) noexcept {
    try { return _featureSnapshotCombinedTimerWork->fired(handle,timer); }
    catch (...) { _featureSnapshotCombinedTimerWork->snapshotUnavailable();return {}; }
}
void ScriptManager::featureSnapshotCombinedTimerCallback(const QString& id,bool enter) noexcept {
    try { _featureSnapshotCombinedTimerWork->callback(id,enter); }
    catch (...) { _featureSnapshotCombinedTimerWork->snapshotUnavailable(); }
}
void ScriptManager::featureSnapshotCombinedTimerReturned(const QString& id) noexcept {
    try { _featureSnapshotCombinedTimerWork->dispatchReturned(id); }
    catch (...) { _featureSnapshotCombinedTimerWork->snapshotUnavailable(); }
}
QVariantMap ScriptManager::featureAvatarV8Stack() const {
    if (!overte::e2e::IOSV8ScriptStack::enabled() || !_engine || QThread::currentThread()!=thread()) { return {}; }
    const auto engine=qobject_cast<ScriptEngineV8*>(_engine.get());
    if (!engine || QThread::currentThread()!=engine->thread()) { return {}; }
    return engine->featureV8Stack();
}

QStringList ScriptManager::featureAvatarTimerCallers() const {
    if (!QCoreApplication::arguments().contains("--testScript") || !_engine || QThread::currentThread()!=thread()) { return {}; }
    QStringList result;auto context=_engine->currentContext();ScriptContextPointer owner;int depth {0};
    while (context && ++depth<=128) {
        const auto function=context->functionContext();
        if (function && function->functionType()==ScriptFunctionContext::ScriptFunction) {
            const auto source=function->fileName();if (source.size()>4096 || result.size()>=32) { _featureAvatarScript->unavailable();_featureAvatarUiWork->unavailable();_featureSnapshotTimerWork->unavailable();return {}; }result.append(source);
        }
        owner=context->parentContext();context=owner.get();
    }
    if (depth>128) { _featureAvatarScript->unavailable();_featureAvatarUiWork->unavailable();_featureSnapshotTimerWork->unavailable();return {}; }
    return result;
}
#endif

int ScriptManager::setupTimerWithInterval(const ScriptValue& function, int intervalMS, bool isSingleShot) {
    int handle = _timerHandleCounter++;

    // create the timer, add it to the map, and start it
    CallbackData timerData = { function, currentEntityIdentifier, currentSandboxURL, _currentEntityScriptConsentRequest };
    auto& newTimer =
        _timerFunctionMap.emplace(handle, std::make_pair(std::make_unique<QTimer>(), timerData)).first->second.first;
    newTimer->setSingleShot(isSingleShot);

    // The default timer type is not very accurate below about 200ms http://doc.qt.io/qt-5/qt.html#TimerType-enum
    static const int MIN_TIMEOUT_FOR_COARSE_TIMER = 200;
    if (intervalMS < MIN_TIMEOUT_FOR_COARSE_TIMER) {
        newTimer->setTimerType(Qt::PreciseTimer);
    }

    connect(newTimer.get(), &QTimer::timeout, [this, handle]() { timerFired(handle); });

    if (intervalMS < 0) {
        int lineNumber = -1;
        QString fileName = getFilename();
        auto context = _engine->currentContext();
        if (context) {
            lineNumber = context->currentLineNumber();
            fileName = context->currentFileName();
        }

        scriptWarningMessage("Script.setInterval() was passed negative value " + QString::number(intervalMS) + ". Ignored, timer not started. Parent script:" + getFilename(), fileName, lineNumber);
    } else {
        newTimer->start(intervalMS);
    }

#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(Q_OS_IOS)
    const auto avatarCallers=overte::e2e::AvatarV8Callers::resolve(featureAvatarV8Stack(),
        _featureAvatarScript->snapshot().value("code").toList());
    const auto avatarTimer=_featureAvatarScript->created(handle,avatarCallers,newTimer.get());
    if (!avatarTimer.isEmpty()) {
        const auto observer=_featureAvatarScript;
        QObject::connect(newTimer.get(),&QObject::destroyed,[observer,avatarTimer] { observer->destroyed(avatarTimer); });
    }
    const auto avatarUiTimer=_featureAvatarUiWork->created(handle,avatarCallers,newTimer.get());
    if (!avatarUiTimer.isEmpty()) {
        const auto observer=_featureAvatarUiWork;
        QObject::connect(newTimer.get(),&QObject::destroyed,[observer,avatarUiTimer] { observer->destroyed(avatarUiTimer); });
    }
    const auto snapshotTimer=_featureSnapshotTimerWork->created(handle,featureAvatarTimerCallers(),newTimer.get());
    if (!snapshotTimer.isEmpty()) {
        const auto observer=_featureSnapshotTimerWork;
        QObject::connect(newTimer.get(),&QObject::destroyed,[observer,snapshotTimer] {observer->destroyed(snapshotTimer);});
    }
    try {
        if (overte::e2e::PlacesHttpObservation::installed(featureLoadMembership().value("url").toString(),"/defaultScripts.js")) {
            const auto sources=_featureSnapshotCombinedSources.snapshot();
            if (sources.value("complete").userType()!=QMetaType::Bool || !sources.value("complete").toBool()) {_featureSnapshotCombinedTimerWork->snapshotUnavailable();}
            else {
                const auto combinedCallers=overte::e2e::AvatarV8Callers::resolve(featureAvatarV8Stack(),sources.value("evaluations").toList());
                const auto combinedTimer=_featureSnapshotCombinedTimerWork->created(handle,combinedCallers,newTimer.get());
                if (!combinedTimer.isEmpty()) {
                    const auto observer=_featureSnapshotCombinedTimerWork;
                    QObject::connect(newTimer.get(),&QObject::destroyed,[observer,combinedTimer] {
                        try { observer->destroyed(combinedTimer); } catch (...) { observer->snapshotUnavailable(); }
                    });
                }
            }
        }
    } catch (...) { _featureSnapshotCombinedTimerWork->snapshotUnavailable(); }
#endif
    return handle;
}

int ScriptManager::setInterval(const ScriptValue& function, int intervalMS) {
    if (isStopped()) {
        int lineNumber = -1;
        QString fileName = getFilename();
        auto context = _engine->currentContext();
        if (context) {
            lineNumber = context->currentLineNumber();
            fileName = context->currentFileName();
        }
        scriptWarningMessage("Script.setInterval() while shutting down is ignored... parent script:" + getFilename(), fileName, lineNumber);
        return 0; // bail early
    }

    return setupTimerWithInterval(function, intervalMS, false);
}

int ScriptManager::setTimeout(const ScriptValue& function, int timeoutMS) {
    if (isStopped()) {
        int lineNumber = -1;
        QString fileName = getFilename();
        auto context = _engine->currentContext();
        if (context) {
            lineNumber = context->currentLineNumber();
            fileName = context->currentFileName();
        }
        scriptWarningMessage("Script.setTimeout() while shutting down is ignored... parent script:" + getFilename(), fileName, lineNumber);
        return 0; // bail early
    }

    return setupTimerWithInterval(function, timeoutMS, true);
}

void ScriptManager::stopTimer(int handle) {
    if (_timerFunctionMap.contains(handle)) {
        _timerFunctionMap.erase(handle);
    } else {
        qCDebug(scriptengine) << "stopTimer -- not in _timerFunctionMap" << handle;
    }
}

QUrl ScriptManager::resolvePath(const QString& include) const {
    //qCDebug(scriptengine) << "ScriptManager::resolvePath: getCurrentScriptURLs: " << _engine->getCurrentScriptURLs();
    QUrl url(include);
    // first lets check to see if it's already a full URL -- or a Windows path like "c:/"
    if (include.startsWith("/") || url.scheme().length() == 1) {
        url = QUrl::fromLocalFile(include);
    }
    if (!url.isRelative()) {
        return expandScriptUrl(url);
    }

    // we apparently weren't a fully qualified url, so, let's assume we're relative
    // to the first absolute URL in the JS scope chain
    QUrl parentURL;
    auto context = _engine->currentContext();
    ScriptContextPointer parentContext;  // using this variable to maintain parent variable lifespan
    do {
        auto contextInfo = context->functionContext();
        parentURL = QUrl(contextInfo->fileName());
        //qCDebug(scriptengine) << "ScriptManager::resolvePath: URL get: " << parentURL << " backtrace: " << context->backtrace() << " " << _engine->getCurrentScriptURLs();
        parentContext = context->parentContext();
        context = parentContext.get();
    } while (parentURL.isRelative() && context);

    if (parentURL.isRelative()) {
        // fallback to the "include" parent (if defined, this will already be absolute)
        parentURL = QUrl(_parentURL);
    }

    if (parentURL.isRelative()) {
        // fallback to the original script engine URL
        parentURL = QUrl(_fileNameString);

        // if still relative and path-like, then this is probably a local file...
        if (parentURL.isRelative() && url.path().contains("/")) {
            parentURL = QUrl::fromLocalFile(_fileNameString);
        }
    }

    // at this point we should have a legitimate fully qualified URL for our parent
    url = expandScriptUrl(parentURL.resolved(url));
    return url;
}

QUrl ScriptManager::resourcesPath() const {
    return QUrl(PathUtils::resourcesUrl());
}

void ScriptManager::print(const QString& message) {
    emit scriptPrintedMessage(message, getFilename(), engine()->currentContext()->currentLineNumber());
}


void ScriptManager::beginProfileRange(const QString& label) const {
    PROFILE_SYNC_BEGIN(script, label.toStdString().c_str(), label.toStdString().c_str());
}

void ScriptManager::endProfileRange(const QString& label) const {
    PROFILE_SYNC_END(script, label.toStdString().c_str(), label.toStdString().c_str());
}

// Script.require.resolve -- like resolvePath, but performs more validation and throws exceptions on invalid module identifiers (for consistency with Node.js)
QString ScriptManager::_requireResolve(const QString& moduleId, const QString& relativeTo) {
    if (!_engine->IS_THREADSAFE_INVOCATION(__FUNCTION__)) {
        return QString();
    }
    QUrl defaultScriptsLoc = PathUtils::defaultScriptsLocation();
    QUrl url(moduleId);

    auto displayId = moduleId;
    if (displayId.length() > MAX_DEBUG_VALUE_LENGTH) {
        displayId = displayId.mid(0, MAX_DEBUG_VALUE_LENGTH) + "...";
    }
    auto message = QString("Cannot find module '%1' (%2)").arg(displayId);

    auto throwResolveError = [&](const QString& error, const QString &details = QString()) -> QString {
        _engine->raiseException(error, "require.resolve: " + details);
        return QString();
    };

    // de-fuzz the input a little by restricting to rational sizes
    auto idLength = url.toString().length();
    if (idLength < 1 || idLength > MAX_MODULE_ID_LENGTH) {
        auto details = QString("rejecting invalid module id size (%1 chars [1,%2])")
            .arg(idLength).arg(MAX_MODULE_ID_LENGTH);
        return throwResolveError(details, "RangeError");
    }

    // this regex matches: absolute, dotted or path-like URLs
    // (ie: the kind of stuff ScriptManager::resolvePath already handles)
    QRegularExpression qualified ("^\\w+:|^/|^[.]{1,2}(/|$)");

    // this is for module.require (which is a bound version of require that's always relative to the module path)
    if (!relativeTo.isEmpty()) {
        url = QUrl(relativeTo).resolved(moduleId);
        url = resolvePath(url.toString());
    } else if (qualified.match(moduleId).hasMatch()) {
        url = resolvePath(moduleId);
    } else {
        // check if the moduleId refers to a "system" module
        QString systemPath = defaultScriptsLoc.path();
        QString systemModulePath = QString("%1/modules/%2.js").arg(systemPath).arg(moduleId);
        url = defaultScriptsLoc;
        url.setPath(systemModulePath);
        if (!QFileInfo(url.toLocalFile()).isFile()) {
            if (!moduleId.contains("./")) {
                // the user might be trying to refer to a relative file without anchoring it
                // let's do them a favor and test for that case -- offering specific advice if detected
                auto unanchoredUrl = resolvePath("./" + moduleId);
                if (QFileInfo(unanchoredUrl.toLocalFile()).isFile()) {
                    auto msg = QString("relative module ids must be anchored; use './%1' instead")
                        .arg(moduleId);
                    return throwResolveError(message.arg(msg));
                }
            }
            return throwResolveError(message.arg("system module not found"));
        }
    }

    if (url.isRelative()) {
        return throwResolveError(message.arg("could not resolve module id"));
    }

    // if it looks like a local file, verify that it's an allowed path and really a file
    if (url.isLocalFile()) {
        QFileInfo file(url.toLocalFile());
        QUrl canonical = url;
        if (file.exists()) {
            canonical.setPath(file.canonicalFilePath());
        }

        bool disallowOutsideFiles = !PathUtils::defaultScriptsLocation().isParentOf(canonical) && !currentSandboxURL.isLocalFile();
        if (disallowOutsideFiles && !PathUtils::isDescendantOf(canonical, currentSandboxURL)) {
            return throwResolveError(message.arg(
                QString("path '%1' outside of origin script '%2' '%3'")
                    .arg(PathUtils::stripFilename(url))
                    .arg(PathUtils::stripFilename(currentSandboxURL))
                    .arg(canonical.toString())
            ));
        }
        if (!file.exists()) {
            return throwResolveError(message.arg("path does not exist: " + url.toLocalFile()));
        }
        if (!file.isFile()) {
            return throwResolveError(message.arg("path is not a file: " + url.toLocalFile()));
        }
    }

    return url.toString();
}

// retrieves the current parent module from the JS scope chain
ScriptValue ScriptManager::currentModule() {
    if (!_engine->IS_THREADSAFE_INVOCATION(__FUNCTION__)) {
        return _engine->nullValue();
    }
    auto jsRequire = _engine->globalObject().property("Script").property("require");
    auto cache = jsRequire.property("cache");
    ScriptValue candidate;
    ScriptContextPointer parentContext;  // using this variable to maintain parent variable lifespan
    for (auto context = _engine->currentContext(); context && !candidate.isObject();
         parentContext = context->parentContext(), context = parentContext.get()) {
        auto contextInfo = context->functionContext();
        candidate = cache.property(contextInfo->fileName());
    }
    if (!candidate.isObject()) {
        return ScriptValue();
    }
    return candidate;
}

// replaces or adds "module" to "parent.children[]" array
// (for consistency with Node.js and userscript cache invalidation without "cache busters")
bool ScriptManager::registerModuleWithParent(const ScriptValue& module, const ScriptValue& parent) {
    auto children = parent.property("children");
    if (children.isArray()) {
        auto key = module.property("id");
        auto length = children.property("length").toInt32();
        for (int i = 0; i < length; i++) {
            if (children.property(i).property("id").strictlyEquals(key)) {
                qCDebug(scriptengine_module) << key.toString() << " updating parent.children[" << i << "] = module";
                children.setProperty(i, module);
                return true;
            }
        }
        qCDebug(scriptengine_module) << key.toString() << " appending parent.children[" << length << "] = module";
        children.setProperty(length, module);
        return true;
    } else if (parent.isValid()) {
        qCDebug(scriptengine_module) << "registerModuleWithParent -- unrecognized parent" << parent.toVariant().toString();
    }
    return false;
}

// creates a new JS "module" Object with default metadata properties
ScriptValue ScriptManager::newModule(const QString& modulePath, const ScriptValue& parent) {
    auto closure = _engine->newObject();
    auto exports = _engine->newObject();
    auto module = _engine->newObject();
    //qCDebug(scriptengine_module) << "newModule" << parent.property("filename").toString();

    closure.setProperty("module", module, READONLY_PROP_FLAGS);

    // note: this becomes the "exports" free variable, so should not be set read only
    closure.setProperty("exports", exports);

    // make the closure available to module instantiation
    module.setProperty("__closure__", closure, READONLY_HIDDEN_PROP_FLAGS);

    // for consistency with Node.js Module
    module.setProperty("id", modulePath, READONLY_PROP_FLAGS);
    module.setProperty("filename", modulePath, READONLY_PROP_FLAGS);
    module.setProperty("exports", exports); // not readonly
    module.setProperty("loaded", false, READONLY_PROP_FLAGS);
    module.setProperty("parent", parent, READONLY_PROP_FLAGS);
    module.setProperty("children", _engine->newArray(), READONLY_PROP_FLAGS);

    // module.require is a bound version of require that always resolves relative to that module's path
    auto boundRequire = _engine->evaluate("(function(id) { return Script.require(Script.require.resolve(id, this.filename)); })", "(boundRequire)");
    module.setProperty("require", boundRequire, READONLY_PROP_FLAGS);
    //qCDebug(scriptengine) << "Module object contents" << _engine->scriptValueDebugListMembers(module);
    return module;
}

// synchronously fetch a module's source code using BatchLoader
QVariantMap ScriptManager::fetchModuleSource(const QString& modulePath, const bool forceDownload) {
    using UrlMap = QMap<QUrl, QString>;
    auto scriptCache = DependencyManager::get<ScriptCache>();
    // BatchLoader::finished may be delivered after the nested event loop exits
    // during script shutdown. Keep the response alive until that queued
    // callback has been destroyed instead of capturing a stack map by
    // reference (which caused the Android 0xcdcd... use-after-free crash).
    auto req = std::make_shared<QVariantMap>();
    qCDebug(scriptengine_module) << "require.fetchModuleSource: " << QUrl(modulePath).fileName() << QThread::currentThread();

    auto onload = [=, this](const UrlMap& data, const UrlMap& _status) {
        auto url = modulePath;
        auto status = _status[url];
        auto contents = data[url];
        if (isStopping()) {
            (*req)["status"] = "Stopped";
            (*req)["success"] = false;
        } else {
            (*req)["url"] = url;
            (*req)["status"] = status;
            (*req)["success"] = ScriptCache::isSuccessStatus(status);
            (*req)["contents"] = contents;
        }
    };

    if (forceDownload) {
        qCDebug(scriptengine_module) << "require.requestScript -- clearing cache for" << modulePath;
        scriptCache->deleteScript(modulePath);
    }
    BatchLoader* loader = new BatchLoader(QList<QUrl>({ modulePath }));
    connect(loader, &BatchLoader::finished, this, onload);
    connect(this, &QObject::destroyed, loader, &QObject::deleteLater);
    // fail faster? (since require() blocks the engine thread while resolving dependencies)
    const int MAX_RETRIES = 1;

    loader->start(MAX_RETRIES);

    if (!loader->isFinished()) {
        // This lambda can get called AFTER this local scope has completed.
        // This is why we pass smart ptrs to the lambda instead of references to local variables.
        auto monitor = std::make_shared<QTimer>();
        auto loop = std::make_shared<QEventLoop>();
        QObject::connect(loader, &BatchLoader::finished, this, [monitor, loop] {
            monitor->stop();
            loop->quit();
        });

        // this helps detect the case where stop() is invoked during the download
        //  but not seen in time to abort processing in onload()...
        connect(monitor.get(), &QTimer::timeout, this, [this, loop] {
            if (isStopping()) {
                loop->exit(-1);
            }
        });
        monitor->start(500);
        loop->exec();
    }
    loader->deleteLater();
    return *req;
}

// evaluate a pending module object using the fetched source code
ScriptValue ScriptManager::instantiateModule(const ScriptValue& module, const QString& sourceCode) {
    ScriptValue result;
    auto modulePath = module.property("filename").toString();
    auto closure = module.property("__closure__");

    qCDebug(scriptengine_module) << QString("require.instantiateModule: %1 / %2 bytes")
        .arg(QUrl(modulePath).fileName()).arg(sourceCode.length());

    if (module.property("content-type").toString() == "application/json") {
        qCDebug(scriptengine_module) << "... parsing as JSON";
        closure.setProperty("__json", sourceCode);
        result = _engine->evaluateInClosure(closure, _engine->newProgram( "module.exports = JSON.parse(__json)", modulePath ));
    } else {
        // scoped vars for consistency with Node.js
        closure.setProperty("require", module.property("require"));
        closure.setProperty("__filename", modulePath, READONLY_HIDDEN_PROP_FLAGS);
        closure.setProperty("__dirname", QString(modulePath).replace(
            QRegularExpression(QStringLiteral("/[^/]*$")), QString()), READONLY_HIDDEN_PROP_FLAGS);
        //_engine->scriptValueDebugDetails(module);
#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(Q_OS_IOS)
        _featureCreateSources.submitted(modulePath,sourceCode);
        _featureSnapshotSources.submitted(modulePath,sourceCode);
        try { _featureSnapshotHttpSources.submitted(modulePath,sourceCode); }
        catch (...) { _featureSnapshotHttpSources.snapshotUnavailable(); }
        try { _featureSnapshotCombinedSources.submitted(modulePath,sourceCode); }
        catch (...) { _featureSnapshotCombinedSources.snapshotUnavailable(); }
        try { _featureChatSources.submitted(modulePath,sourceCode); }
        catch (...) { _featureChatSources.unavailable(); }
        _featureAvatarScript->submitted(modulePath,sourceCode);
#endif
        result = _engine->evaluateInClosure(closure, _engine->newProgram( sourceCode, modulePath ));
    }

    return result;
}

// CommonJS/Node.js like require/module support
ScriptValue ScriptManager::require(const QString& moduleId) {
    qCDebug(scriptengine_module) << "ScriptManager::require(" << moduleId.left(MAX_DEBUG_VALUE_LENGTH) << ")";
    if (!_engine->IS_THREADSAFE_INVOCATION(__FUNCTION__)) {
        return _engine->nullValue();
    }

    auto jsRequire = _engine->globalObject().property("Script").property("require");
    auto cacheMeta = jsRequire.data();
    auto cache = jsRequire.property("cache");
    auto parent = currentModule();

    auto throwModuleError = [&](const QString& modulePath, const ScriptValue& error) {
#if defined(OVERTE_E2E_FEATURE_TESTS)
        _e2eRequiredModules.record(modulePath, false, false);
#endif
        cache.setProperty(modulePath, _engine->nullValue());
        if (!error.isNull()) {
#ifdef DEBUG_JS_MODULES
            qCWarning(scriptengine_module) << "throwing module error:" << error.toString() << modulePath << error.property("stack").toString();
#endif
            _engine->raiseException(error, "module error");
        }
        return _engine->nullValue();
    };

    // start by resolving the moduleId into a fully-qualified path/URL
    QString modulePath = _requireResolve(moduleId);
    if (modulePath.isNull() || _engine->hasUncaughtException()) {
        // the resolver already threw an exception -- bail early
        return _engine->nullValue();
    }

    // check the resolved path against the cache
    auto module = cache.property(modulePath);

    // modules get cached in `Script.require.cache` and (similar to Node.js) users can access it
    // to inspect particular entries and invalidate them by deleting the key:
    //   `delete Script.require.cache[Script.require.resolve(moduleId)];`

    // Check to see if we should invalidate the cache based on a user setting.
    Setting::Handle<bool> getCachebustSetting {"cachebustScriptRequire", false };

    // cacheMeta is just used right now to tell deleted keys apart from undefined ones
    bool invalidateCache = getCachebustSetting.get() || (module.isUndefined() && cacheMeta.property(moduleId).isValid());

    // reset the cacheMeta record so invalidation won't apply next time, even if the module fails to load
    cacheMeta.setProperty(modulePath, ScriptValue());

    auto exports = module.property("exports");
    if (!invalidateCache && exports.isObject()) {
#if defined(OVERTE_E2E_FEATURE_TESTS)
        _e2eRequiredModules.record(modulePath, module.property("loaded").toBool(), true);
#endif
        // we have found a cached module -- just need to possibly register it with current parent
        qCDebug(scriptengine_module) << QString("require - using cached module for '%1' (loaded: %2)")
            .arg(moduleId).arg(module.property("loaded").toString());
        registerModuleWithParent(module, parent);
        return exports;
    }

    // bootstrap / register new empty module
    module = newModule(modulePath, parent);
    registerModuleWithParent(module, parent);

    // add it to the cache (this is done early so any cyclic dependencies pick up)
    cache.setProperty(modulePath, module);

    // download the module source
    auto req = fetchModuleSource(modulePath, invalidateCache);

    if (!req.contains("success") || !req["success"].toBool()) {
        auto error = QString("error retrieving script (%1)").arg(req["status"].toString());
        return throwModuleError(modulePath, _engine->newValue(error));
    }

#if DEBUG_JS_MODULES
    qCDebug(scriptengine_module) << "require.loaded: " <<
        QUrl(req["url"].toString()).fileName() << req["status"].toString();
#endif

    auto sourceCode = req["contents"].toString();

    if (QUrl(modulePath).fileName().endsWith(".json", Qt::CaseInsensitive)) {
        module.setProperty("content-type", "application/json");
    } else {
        module.setProperty("content-type", "application/javascript");
    }

    // evaluate the module
    auto result = instantiateModule(module, sourceCode);

    if (result.isError() && !result.strictlyEquals(module.property("exports"))) {
        qCWarning(scriptengine_module) << "-- result.isError --" << result.toString();
        return throwModuleError(modulePath, result);
    }

    // mark as fully-loaded
    module.setProperty("loaded", true, READONLY_PROP_FLAGS);
#if defined(OVERTE_E2E_FEATURE_TESTS)
    _e2eRequiredModules.record(modulePath, true, false);
#endif

    // set up a new reference point for detecting cache key deletion
    cacheMeta.setProperty(modulePath, module);

    //qCDebug(scriptengine_module) << "//ScriptManager::require(" << moduleId << ")";

    //qCDebug(scriptengine_module) << "Exports: " << _engine->scriptValueDebugDetails(module.property("exports"));
    return module.property("exports");
}

// If a callback is specified, the included files will be loaded asynchronously and the callback will be called
// when all of the files have finished loading.
// If no callback is specified, the included files will be loaded synchronously and will block execution until
// all of the files have finished loading.
void ScriptManager::include(const QStringList& includeFiles, const ScriptValue& callback) {
    if (!_engine->IS_THREADSAFE_INVOCATION(__FUNCTION__)) {
        return;
    }
    if (isStopped()) {
        int lineNumber = -1;
        QString fileName = getFilename();
        auto context = _engine->currentContext();
        if (context) {
            lineNumber = context->currentLineNumber();
            fileName = context->currentFileName();
        }
        scriptWarningMessage("Script.include() while shutting down is ignored... includeFiles:"
                + includeFiles.join(",") + "parent script:" + getFilename(), fileName, lineNumber);
        return; // bail early
    }
    QList<QUrl> urls;

    for (QString includeFile : includeFiles) {
        QString file = DependencyManager::get<ResourceManager>()->normalizeURL(includeFile);
        QUrl thisURL;
        bool isStandardLibrary = false;
        if (file.startsWith("/~/")) {
            thisURL = expandScriptUrl(QUrl::fromLocalFile(expandScriptPath(file)));
            QUrl defaultScriptsLoc = PathUtils::defaultScriptsLocation();
            if (!defaultScriptsLoc.isParentOf(thisURL)) {
                int lineNumber = -1;
                QString fileName = getFilename();
                auto context = _engine->currentContext();
                if (context) {
                    lineNumber = context->currentLineNumber();
                    fileName = context->currentFileName();
                }
                //V8TODO this probably needs to be done per context, otherwise file cannot be included again in a module
                scriptWarningMessage("Script.include() -- skipping" + file + "-- outside of standard libraries", fileName, lineNumber);
                continue;
            }
            isStandardLibrary = true;
        } else {
            thisURL = resolvePath(file);
        }

        bool disallowOutsideFiles = thisURL.isLocalFile() && !isStandardLibrary && !currentSandboxURL.isLocalFile();
        if (disallowOutsideFiles && !PathUtils::isDescendantOf(thisURL, currentSandboxURL)) {
            int lineNumber = -1;
            QString fileName = currentSandboxURL.toString();
            auto context = _engine->currentContext();
            if (context) {
                lineNumber = context->currentLineNumber();
                fileName = context->currentFileName();
            }
            scriptWarningMessage("Script.include() ignoring file path" + thisURL.toString()
                                + "outside of original entity script" + currentSandboxURL.toString(), fileName, lineNumber);
        } else {
            // We could also check here for CORS, but we don't yet.
            // It turns out that QUrl.resolve will not change hosts and copy authority, so we don't need to check that here.
            urls.append(thisURL);
        }
    }

    // If there are no URLs left to download, don't bother attempting to download anything and return early
    if (urls.size() == 0) {
        return;
    }

    BatchLoader* loader = new BatchLoader(urls);
    EntityItemID capturedEntityIdentifier = currentEntityIdentifier;
    QUrl capturedSandboxURL = currentSandboxURL;
    const auto capturedConsent = _currentEntityScriptConsentRequest;

    auto evaluateScripts = [=, this](const QMap<QUrl, QString>& data, const QMap<QUrl, QString>& status) {
        if (!entityScriptInvocationAllowed(capturedEntityIdentifier, capturedConsent)) {
            loader->deleteLater();
            return;
        }
        auto parentURL = _parentURL;
        for (QUrl url : urls) {
            if (!entityScriptInvocationAllowed(capturedEntityIdentifier, capturedConsent)) { break; }
            QString contents = data[url];
            if (contents.isNull()) {
                int lineNumber = -1;
                QString fileName = url.toString();
                auto context = _engine->currentContext();
                if (context) {
                    lineNumber = context->currentLineNumber();
                    fileName = context->currentFileName();
                }
                scriptErrorMessage("Error loading file (" + status[url] +"): " + url.toString(), fileName, lineNumber);
            } else {
                std::lock_guard<std::recursive_mutex> lock(_lock);
                if (!_includedURLs.contains(url)) {
                    _includedURLs << url;
                    // Set the parent url so that path resolution will be relative
                    // to this script's url during its initial evaluation
                    _parentURL = url.toString();
                    auto operation = [&]() {
#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(Q_OS_IOS)
                        _featureCreateSources.submitted(url.toString(),contents);
                        _featureSnapshotSources.submitted(url.toString(),contents);
                        try { _featureSnapshotHttpSources.submitted(url.toString(),contents); }
                        catch (...) { _featureSnapshotHttpSources.snapshotUnavailable(); }
                        try { _featureSnapshotCombinedSources.submitted(url.toString(),contents); }
                        catch (...) { _featureSnapshotCombinedSources.snapshotUnavailable(); }
                        try { _featureChatSources.submitted(url.toString(),contents); }
                        catch (...) { _featureChatSources.unavailable(); }
                        _featureAvatarScript->submitted(url.toString(),contents);
#endif
                        _engine->evaluate(contents, url.toString());
                    };

                    doWithEnvironment(capturedEntityIdentifier, capturedSandboxURL, operation, capturedConsent);
                    if(_engine->hasUncaughtException()) {
                        auto ex = _engine->uncaughtException();
                        ex->additionalInfo += "; evaluateInClosure";
                        emit unhandledException(ex);
                        _engine->clearExceptions();
                    }
                } else {
                    int lineNumber = -1;
                    QString fileName = url.toString();
                    auto context = _engine->currentContext();
                    if (context) {
                        lineNumber = context->currentLineNumber();
                        fileName = context->currentFileName();
                    }
                    scriptPrintedMessage("Script.include() skipping evaluation of previously included url:" + url.toString(), fileName, lineNumber);
                }
            }
        }
        _parentURL = parentURL;

        if (callback.isFunction()) {
            callWithEnvironment(capturedEntityIdentifier, capturedSandboxURL, callback, ScriptValue(), ScriptValueList(), capturedConsent);
        }

        loader->deleteLater();
    };

    connect(loader, &BatchLoader::finished, this, evaluateScripts);

    // If we are destroyed before the loader completes, make sure to clean it up
    connect(this, &QObject::destroyed, loader, &QObject::deleteLater);

    loader->start(processLevelMaxRetries);

    if (!callback.isFunction() && !loader->isFinished()) {
        QEventLoop loop;
        QObject::connect(loader, &BatchLoader::finished, &loop, &QEventLoop::quit);
        loop.exec();
    }
}

void ScriptManager::include(const QString& includeFile, const ScriptValue& callback) {
    if (isStopped()) {
        int lineNumber = -1;
        QString fileName = currentSandboxURL.toString();
        auto context = _engine->currentContext();
        if (context) {
            lineNumber = context->currentLineNumber();
            fileName = context->currentFileName();
        }
        scriptWarningMessage("Script.include() while shutting down is ignored...  includeFile:"
                    + includeFile + "parent script:" + getFilename(), fileName, lineNumber);
        return; // bail early
    }

    QStringList urls;
    urls.append(includeFile);
    include(urls, callback);
}

// NOTE: The load() command is similar to the include() command except that it loads the script
// as a stand-alone script. To accomplish this, the ScriptManager class just emits a signal which
// the Application or other context will connect to in order to know to actually load the script
void ScriptManager::load(const QString& loadFile) {
    if (!_engine->IS_THREADSAFE_INVOCATION(__FUNCTION__)) {
        return;
    }
    int lineNumber = -1;
    QString fileName = getFilename();
    auto context = _engine->currentContext();
    if (context) {
        lineNumber = context->currentLineNumber();
        fileName = context->currentFileName();
    }
    if (isStopped()) {
        scriptWarningMessage("Script.load() while shutting down is ignored... loadFile:"
                + loadFile + "parent script:" + getFilename(), fileName, lineNumber);
        return; // bail early
    }
    if (!currentEntityIdentifier.isInvalidID()) {
        scriptWarningMessage("Script.load() from entity script is ignored...  loadFile:"
                + loadFile + "parent script:" + getFilename() + "entity: " + currentEntityIdentifier.toString(), fileName, lineNumber);
        return; // bail early
    }

    QUrl url = resolvePath(loadFile);
    if (_isReloading) {
        auto scriptCache = DependencyManager::get<ScriptCache>();
        scriptCache->deleteScript(url.toString());
        emit reloadScript(url.toString(), false);
    } else {
        emit loadScript(url.toString(), false);
    }
}

// Look up the handler associated with eventName and entityID. If found, evalute the argGenerator thunk and call the handler with those args
void ScriptManager::forwardHandlerCall(const EntityItemID& entityID, const QString& eventName, const ScriptValueList& eventHandlerArgs) {
    if (QThread::currentThread() != thread()) {
        qCDebug(scriptengine) << "*** ERROR *** ScriptManager::forwardHandlerCall() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "]";
        assert(false);
        return ;
    }
    if (!_registeredHandlers.contains(entityID)) {
        return;
    }
    const RegisteredEventHandlers& handlersOnEntity = _registeredHandlers[entityID];
    if (!handlersOnEntity.contains(eventName)) {
        return;
    }
    CallbackList handlersForEvent = handlersOnEntity[eventName];
    if (!handlersForEvent.isEmpty()) {
        for (int i = 0; i < handlersForEvent.count(); ++i) {
            // handlersForEvent[i] can contain many handlers that may have each been added by different interface or entity scripts,
            // and the entity scripts may be for entities other than the one this is a handler for.
            // Fortunately, the definingEntityIdentifier captured the entity script id (if any) when the handler was added.
            CallbackData& handler = handlersForEvent[i];
            callWithEnvironment(handler.definingEntityIdentifier, handler.definingSandboxURL, handler.function, ScriptValue(), eventHandlerArgs, handler.consentRequest);
        }
    }
}

int ScriptManager::getNumRunningEntityScripts() const {
    QReadLocker locker { &_entityScriptsLock };
    int sum = 0;
    for (const auto& entityScripts : _entityScripts) {
        for (const auto& script : entityScripts) {
            if (script.status == EntityScriptStatus::RUNNING) {
                ++sum;
            }
        }
    }
    return sum;
}

void ScriptManager::setEntityScriptDetails(const EntityItemID& entityID, const QString& scriptURL, const EntityScriptDetails& details) {
    {
        QWriteLocker locker { &_entityScriptsLock };
        _entityScripts[entityID][scriptURL] = details;
    }
    emit entityScriptDetailsUpdated();
}

void ScriptManager::updateEntityScriptStatus(const EntityItemID& entityID, const QString& scriptURL, const EntityScriptStatus &status, const QString& errorInfo) {
    {
        QWriteLocker locker { &_entityScriptsLock };
        EntityScriptDetails& details = _entityScripts[entityID][scriptURL];
        details.status = status;
        details.errorInfo = errorInfo;
    }
    emit entityScriptDetailsUpdated();
}

QVariant ScriptManager::cloneEntityScriptDetails(const EntityItemID& entityID, const QString& scriptURL) {
    static const QVariant NULL_VARIANT = QVariant::fromValue(nullptr);
    QVariantMap map;
    if (entityID.isNull()) {
        // TODO: find better way to report JS Error across thread/process boundaries
        map["isError"] = true;
        map["errorInfo"] = "Error: getEntityScriptDetails -- invalid entityID";
    } else {
#ifdef DEBUG_ENTITY_STATES
        qCDebug(scriptengine) << "cloneEntityScriptDetails" << entityID << QThread::currentThread();
#endif
        EntityScriptDetails scriptDetails;
        if (getEntityScriptDetails(entityID, scriptURL, scriptDetails)) {
#ifdef DEBUG_ENTITY_STATES
            qCDebug(scriptengine) << "gotEntityScriptDetails" << scriptDetails.status << QThread::currentThread();
#endif
            map["isRunning"] = isEntityScriptRunning(entityID, scriptURL);
            map["status"] = EntityScriptStatus_::valueToKey(scriptDetails.status).toLower();
            map["errorInfo"] = scriptDetails.errorInfo;
            map["entityID"] = entityID.toString();
#ifdef DEBUG_ENTITY_STATES
            {
                auto debug = QVariantMap();
                debug["script"] = scriptDetails.scriptText;
                debug["scriptObject"] = scriptDetails.scriptObject.toVariant();
                debug["lastModified"] = (qlonglong)scriptDetails.lastModified;
                debug["sandboxURL"] = scriptDetails.definingSandboxURL;
                map["debug"] = debug;
            }
#endif
        } else {
#ifdef DEBUG_ENTITY_STATES
            qCDebug(scriptengine) << "!gotEntityScriptDetails" <<  QThread::currentThread();
#endif
            map["isError"] = true;
            map["errorInfo"] = "Entity script details unavailable";
            map["entityID"] = entityID.toString();
        }
    }
    return map;
}

QFuture<QVariant> ScriptManager::getLocalEntityScriptDetails(const EntityItemID& entityID, const QString& scriptURL) {
    return QtConcurrent::run([this, entityID, scriptURL] {
        return cloneEntityScriptDetails(entityID, scriptURL);
    });
}

bool ScriptManager::getEntityScriptDetails(const EntityItemID& entityID, const QString& scriptURL, EntityScriptDetails &details) const {
    QReadLocker locker { &_entityScriptsLock };
    auto it = _entityScripts.constFind(entityID);
    if (it == _entityScripts.constEnd()) {
        return false;
    }
    auto it2 = it.value().constFind(scriptURL);
    if (it2 == it.value().constEnd()) {
        return false;
    }
    details = it2.value();
    return true;
}

bool ScriptManager::hasEntityScriptDetails(const EntityItemID& entityID, const QString& scriptURL) const {
    QReadLocker locker { &_entityScriptsLock };
    auto it = _entityScripts.constFind(entityID);
    if (it == _entityScripts.constEnd()) {
        return false;
    }
    return it.value().contains(scriptURL);
}

bool ScriptManager::isCurrentEntityScriptLoad(const EntityItemID& entityID, const QString& script,
                                             const std::shared_ptr<EntityScriptLoadRequest>& request) const {
    return request && !isStopping() && !_isFinished &&
        _entityScriptLoads.value(entityID).value(script) == request;
}

void ScriptManager::cancelEntityScriptLoad(const EntityItemID& entityID, const QString& script) {
    auto loads = _entityScriptLoads.find(entityID);
    if (loads != _entityScriptLoads.end()) {
        loads->remove(script);
        if (loads->isEmpty()) { _entityScriptLoads.erase(loads); }
    }
    auto queued = _contentAvailableQueue.find(entityID);
    if (queued != _contentAvailableQueue.end()) {
        queued->remove(script);
        if (queued->isEmpty()) { _contentAvailableQueue.erase(queued); }
    }
}

void ScriptManager::processEntityScriptContents() {
    EntityScriptContentAvailableMap pending;
    std::swap(_contentAvailableQueue, pending);
    for (const auto& scripts : pending) {
        for (const auto& args : scripts) {
            if (!isCurrentEntityScriptLoad(args.entityID, args.requestedScript, args.request)) {
                continue;
            }
            // Consume before entering code which can reenter unload/load/update.
            cancelEntityScriptLoad(args.entityID, args.requestedScript);
            entityScriptContentAvailable(args.entityID, args.scriptOrURL, args.contents,
                                         args.isURL, args.success, args.status);
        }
    }
}

bool ScriptManager::bindEntityScriptConsent(std::shared_ptr<EntityScriptConsentScope> scope,
                                           EntityScriptConsentPrompt prompt) {
    if (_context != ENTITY_CLIENT_SCRIPT || QThread::currentThread() != thread() ||
        _hasRunStarted.load() || _entityScriptConsentScope || !scope || !scope->active() || scope->origin().isEmpty() || !prompt) {
        return false;
    }
    _entityScriptConsentScope = std::move(scope);
    _entityScriptConsentPrompt = std::move(prompt);
    const auto weakManager = weak_from_this();
    _entityScriptConsentScope->onInvalidated([weakManager] {
        if (const auto manager = weakManager.lock()) { manager->stop(); }
    });
    return true;
}

bool ScriptManager::rejectEntityScriptWithoutConsent(const EntityItemID& entityID, const QString& scriptURL,
                                                     bool requestConsent, bool forceRedownload) {
    switch (_context) {
        case ENTITY_SERVER_SCRIPT:
        case AGENT_SCRIPT:
        case NETWORKLESS_TEST_SCRIPT:
            return false;
        default:
            break;
    }
    // qrc resources are immutable files embedded in the signed application package. They are
    // client code, rather than code supplied by a world, and are required by bundled serverless
    // interactions such as the tutorial portal. Keep the same scoped callback token and identity
    // checks used by reviewed scripts, while exempting only this non-network, non-file scheme.
    const QUrl sourceURL(scriptURL);
    if (_context == ENTITY_CLIENT_SCRIPT &&
        sourceURL.scheme().compare(QStringLiteral("qrc"), Qt::CaseInsensitive) == 0) {
        if (isStopping() || _isFinished) { return true; }
        auto existing = _entityScriptConsentRequests.value(entityID).value(scriptURL);
        if (existing) { return !existing->allowed(); }
        // Late callbacks cannot manufacture a new authorization, even for
        // bundled resources. Only a current load request can create one.
        if (!requestConsent) { return true; }
        if (!_entityScriptConsentScope) {
            _entityScriptConsentScope = std::make_shared<EntityScriptConsentScope>(QStringLiteral("qrc:///"));
            const auto weakManager = weak_from_this();
            _entityScriptConsentScope->onInvalidated([weakManager] {
                if (const auto manager = weakManager.lock()) { manager->stop(); }
            });
        }
        auto bundled = std::make_shared<EntityScriptConsentRequest>(
            _entityScriptConsentScope, scriptURL, forceRedownload);
        if (!bundled->resolve(true)) { return true; }
        _entityScriptConsentRequests[entityID][scriptURL] = bundled;
        return false;
    }
    if (_context != ENTITY_CLIENT_SCRIPT || !_entityScriptConsentScope ||
        !_entityScriptConsentScope->active() || !_entityScriptConsentPrompt || isStopping() || _isFinished) {
        updateEntityScriptStatus(entityID, scriptURL, EntityScriptStatus::ERROR_LOADING_SCRIPT,
                                 QStringLiteral("ENTITY_SCRIPT_CONSENT_UNAVAILABLE"));
        return true;
    }
    auto existing = _entityScriptConsentRequests.value(entityID).value(scriptURL);
    if (existing) {
        if (existing->allowed()) { return false; }
        existing->_forceRedownload = existing->_forceRedownload || forceRedownload;
        updateEntityScriptStatus(entityID, scriptURL, EntityScriptStatus::ERROR_LOADING_SCRIPT,
            existing->decision() == EntityScriptConsentRequest::Decision::Declined ?
                QStringLiteral("ENTITY_SCRIPT_CONSENT_DECLINED") : QStringLiteral("ENTITY_SCRIPT_CONSENT_REQUIRED"));
        return true;
    }
    // A late/cache callback cannot manufacture a new consent prompt.
    if (!requestConsent) { return true; }
    int pending = 0;
    for (const auto& scripts : _entityScriptConsentRequests) {
        for (const auto& request : scripts) {
            if (request->decision() == EntityScriptConsentRequest::Decision::Pending) { ++pending; }
        }
    }
    if (pending >= 64) {
        updateEntityScriptStatus(entityID, scriptURL, EntityScriptStatus::ERROR_LOADING_SCRIPT,
                                 QStringLiteral("ENTITY_SCRIPT_CONSENT_QUEUE_FULL"));
        return true;
    }
    const auto request = std::make_shared<EntityScriptConsentRequest>(_entityScriptConsentScope, scriptURL, forceRedownload);
    _entityScriptConsentRequests[entityID][scriptURL] = request;
    updateEntityScriptStatus(entityID, scriptURL, EntityScriptStatus::ERROR_LOADING_SCRIPT,
                             QStringLiteral("ENTITY_SCRIPT_CONSENT_REQUIRED"));
    if (isStopping() || !request->active() ||
        _entityScriptConsentRequests.value(entityID).value(scriptURL) != request) { return true; }
    const auto weakManager = weak_from_this();
    _entityScriptConsentPrompt(entityID, request, [weakManager, entityID, scriptURL, request](bool allow) {
        if (auto manager = weakManager.lock()) {
            QMetaObject::invokeMethod(manager.get(), [weakManager, entityID, scriptURL, request, allow] {
                const auto manager = weakManager.lock();
                if (!manager || manager->isStopping() || manager->_isFinished ||
                    manager->_entityScriptConsentRequests.value(entityID).value(scriptURL) != request ||
                    !request->resolve(allow)) { return; }
                if (allow) {
                    manager->loadEntityScript(entityID, scriptURL, request->_forceRedownload);
                } else {
                    manager->updateEntityScriptStatus(entityID, scriptURL, EntityScriptStatus::ERROR_LOADING_SCRIPT,
                                                     QStringLiteral("ENTITY_SCRIPT_CONSENT_DECLINED"));
                }
            }, Qt::QueuedConnection);
        }
    });
    return true;
}

void ScriptManager::loadEntityScript(const EntityItemID& entityID, const QString& entityScript, bool forceRedownload) {
    if (QThread::currentThread() != thread()) {
        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->loadEntityScript(entityID, entityScript, forceRedownload);
        });
        return;
    }
    if (rejectEntityScriptWithoutConsent(entityID, entityScript, true, forceRedownload)) {
        return;
    }
    PROFILE_RANGE(script, __FUNCTION__);

    QSharedPointer<ScriptEngines> scriptEngines(_scriptEngines);
    if (isStopping() || !scriptEngines || scriptEngines->isStopped()) {
        qCDebug(scriptengine) << "Entity script loader unavailable";
        return;
    }

    cancelEntityScriptLoad(entityID, entityScript);
    const auto request = std::make_shared<EntityScriptLoadRequest>();
    _entityScriptLoads[entityID][entityScript] = request;

    if (!hasEntityScriptDetails(entityID, entityScript)) {
        // make sure EntityScriptDetails has an entry for this UUID right away
        // (which allows bailing from the loading/provisioning process early if the Entity gets deleted mid-flight)
        updateEntityScriptStatus(entityID, entityScript, EntityScriptStatus::PENDING, "...pending...");
    }

#ifdef DEBUG_ENTITY_STATES
    {
        EntityScriptDetails details;
        bool hasEntityScript = getEntityScriptDetails(entityID, entityScript, details);
        qCDebug(scriptengine) << "loadEntityScript.LOADING: " << entityID.toString()
            << "(previous: " << (hasEntityScript ? details.status : EntityScriptStatus::PENDING) << ")";
    }
#endif

    if (!isCurrentEntityScriptLoad(entityID, entityScript, request)) { return; }

    EntityScriptDetails newDetails;
    newDetails.scriptText = entityScript;
    newDetails.status = EntityScriptStatus::LOADING;
    newDetails.definingSandboxURL = currentSandboxURL;
    setEntityScriptDetails(entityID, entityScript, newDetails);
    if (!isCurrentEntityScriptLoad(entityID, entityScript, request)) { return; }

    auto scriptCache = DependencyManager::get<ScriptCache>();
    // note: see EntityTreeRenderer.cpp for shared pointer lifecycle management
    std::weak_ptr<ScriptManager> weakRef(shared_from_this());
    scriptCache->getScriptContents(entityScript,
        [this, weakRef, entityScript, entityID, request](const QString& url, const QString& contents, bool isURL, bool success, const QString& status) {
            std::shared_ptr<ScriptManager> strongRef = weakRef.lock();
            if (!strongRef) {
                qCWarning(scriptengine) << "loadEntityScript.contentAvailable -- ScriptManager was deleted during getScriptContents!!";
                return;
            }
            if (isStopping()) {
#ifdef DEBUG_ENTITY_STATES
                qCDebug(scriptengine) << "loadEntityScript.contentAvailable -- stopping";
#endif
                return;
            }
            executeOnScriptThread([=, this]{
#ifdef DEBUG_ENTITY_STATES
                qCDebug(scriptengine) << "loadEntityScript.contentAvailable" << status << entityID.toString();
#endif
                if (isCurrentEntityScriptLoad(entityID, entityScript, request) && !request->queued) {
                    request->queued = true;
                    _contentAvailableQueue[entityID][entityScript] = {
                        entityID, _context == ENTITY_CLIENT_SCRIPT ? entityScript : url, contents, isURL, success, status, entityScript, request
                    };
                } else {
#ifdef DEBUG_ENTITY_STATES
                    qCDebug(scriptengine) << "loadEntityScript.contentAvailable -- aborting";
#endif
                }
            });
    }, forceRedownload, ScriptRequest::MAX_RETRIES, _context == ENTITY_CLIENT_SCRIPT, _entityScriptConsentScope);
}

// The JSDoc is for the callEntityScriptMethod() call in this method.
// since all of these operations can be asynch we will always do the actual work in the response handler
// for the download
void ScriptManager::entityScriptContentAvailable(const EntityItemID& entityID, const QString& scriptOrURL, const QString& contents, bool isURL, bool success , const QString& status) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "Entity script callback queued to its owner thread";
#endif

        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->entityScriptContentAvailable(entityID, scriptOrURL, contents, isURL, success, status);
        });
        return;
    }

    if (rejectEntityScriptWithoutConsent(entityID, scriptOrURL)) {
        return;
    }

    const auto consent = _entityScriptConsentRequests.value(entityID).value(scriptOrURL);
    const auto consentCurrent = [&] {
        return _context != ENTITY_CLIENT_SCRIPT ||
            (consent && consent->allowed() && !isStopping() && !_isFinished &&
             _entityScriptConsentRequests.value(entityID).value(scriptOrURL) == consent);
    };
    auto scriptCache = DependencyManager::get<ScriptCache>();
    bool isFileUrl = isURL && scriptOrURL.startsWith("file://");
    auto fileName = isURL ? scriptOrURL : "about:EmbeddedEntityScript";

    QString entityScript;
    {
        QWriteLocker locker { &_entityScriptsLock };
        entityScript = _entityScripts[entityID][scriptOrURL].scriptText;
    }

    EntityScriptDetails newDetails;
    newDetails.scriptText = scriptOrURL;

    // If an error happens below, we want to update newDetails with the new status info
    // and also abort any pending Entity loads that are waiting on the exact same script URL.
    auto setError = [&](const QString &errorInfo, const EntityScriptStatus& status) {
        newDetails.errorInfo = errorInfo;
        newDetails.status = status;
        setEntityScriptDetails(entityID, scriptOrURL, newDetails);
    };

    // NETWORK / FILESYSTEM ERRORS
    if (!success) {
        setError("Failed to load script (" + status + ")", EntityScriptStatus::ERROR_LOADING_SCRIPT);
        return;
    }

    // SYNTAX ERRORS
    //auto syntaxError = _engine->lintScript(contents, fileName);
    auto program = _engine->newProgram( contents, fileName );
    if (!program) {
        setError("Bad program (isNull)", EntityScriptStatus::ERROR_RUNNING_SCRIPT);
        std::shared_ptr<ScriptException> ex = std::make_shared<ScriptEngineException>("Program is Null", "Bad program in entityScriptContentAvailable");
        emit unhandledException(ex);

        return; // done processing script
    }

    auto syntaxCheck = program->checkSyntax();
    if (!syntaxCheck || syntaxCheck->state() != ScriptSyntaxCheckResult::Valid) {
        auto message = syntaxCheck ? syntaxCheck->errorMessage() : QStringLiteral("Syntax check unavailable");
        //syntaxError.property("formatted").toString();
        //if (message.isEmpty()) {
        //    message = syntaxError.toString();
        //}
        setError(QString("Bad syntax (%1)").arg(message), EntityScriptStatus::ERROR_RUNNING_SCRIPT);
        //syntaxError.setProperty("detail", entityID.toString());
        //V8TODO
        //emit unhandledException(syntaxError);

        return;
    }

    if (isURL) {
        setParentURL(scriptOrURL);
    }

    // SANITY/PERFORMANCE CHECK USING SANDBOX
    // V8TODO: can be skipped for now should we implement it before merging V8 branch?

    /*const int SANDBOX_TIMEOUT = 0.25 * MSECS_PER_SECOND;
    ScriptEnginePointer sandbox = newScriptEngine();
    sandbox->setProcessEventsInterval(SANDBOX_TIMEOUT);
    ScriptValue testConstructor, exception;
    if (atoi(getenv("UNSAFE_ENTITY_SCRIPTS") ? getenv("UNSAFE_ENTITY_SCRIPTS") : "0"))
    {
        QTimer timeout;
        timeout.setSingleShot(true);
        timeout.start(SANDBOX_TIMEOUT);
        connect(&timeout, &QTimer::timeout, [=, &sandbox]{
                qCDebug(scriptengine) << "ScriptManager::entityScriptContentAvailable timeout";

                // Guard against infinite loops and non-performant code
                sandbox->raiseException(
                    sandbox->makeError(sandbox->newValue(QString("Timed out (entity constructors are limited to %1ms)").arg(SANDBOX_TIMEOUT)))
                );
        });

        testConstructor = sandbox->evaluate(program);

        if (sandbox->hasUncaughtException()) {
            exception = sandbox->cloneUncaughtException(QString("(preflight %1)").arg(entityID.toString()));
            sandbox->clearExceptions();
        } else if (testConstructor.isError()) {
            exception = testConstructor;
        }
    } else {
        // ENTITY SCRIPT ALLOWLIST STARTS HERE
        auto nodeList = DependencyManager::get<NodeList>();
        bool passList = false;  // assume unsafe
        QString allowlistPrefix = "[ALLOWLIST ENTITY SCRIPTS]";
        QList<QString> safeURLPrefixes = { "file:///", "atp:", "cache:" };
        safeURLPrefixes += qEnvironmentVariable("EXTRA_ALLOWLIST").trimmed().split(
            QRegularExpression(QStringLiteral("\\s*,\\s*")), Qt::SkipEmptyParts);

        // Entity Script Allowlist toggle check.
        Setting::Handle<bool> allowlistEnabled {"private/allowlistEnabled", false };

        if (!allowlistEnabled.get()) {
            passList = true;
        }

        // Pull SAFEURLS from the Interface.JSON settings.
        QVariant raw = Setting::Handle<QVariant>("private/settingsSafeURLS").get();
        QStringList settingsSafeURLS = raw.toString().trimmed().split(
            QRegularExpression(QStringLiteral("\\s*[,\r\n]+\\s*")), Qt::SkipEmptyParts);
        safeURLPrefixes += settingsSafeURLS;
        // END Pull SAFEURLS from the Interface.JSON settings.

        // Get current domain allowlist bypass, in case an entire domain is allowlisted.
        QString currentDomain = DependencyManager::get<AddressManager>()->getDomainURL().host();

        QString domainSafeIP = nodeList->getDomainHandler().getHostname();
        QString domainSafeURL = URL_SCHEME_OVERTE + "://" + currentDomain;
        for (const auto& str : safeURLPrefixes) {
            if (domainSafeURL.startsWith(str) || domainSafeIP.startsWith(str)) {
                qCDebug(scriptengine) << allowlistPrefix << "Allowlist Bypassed, entire domain is allowlisted. Current Domain Host: "
                    << nodeList->getDomainHandler().getHostname()
                    << "Current Domain: " << currentDomain;
                passList = true;
            }
        }
        // END bypass allowlist based on current domain.

        // Start processing scripts through the allowlist.
        if (ScriptManager::getContext() == "entity_server") { // If running on the server, do not engage allowlist.
            passList = true;
        } else if (!passList) { // If waved through, do not engage allowlist.
            for (const auto& str : safeURLPrefixes) {
                qCDebug(scriptengine) << allowlistPrefix << "Script URL: " << scriptOrURL << "TESTING AGAINST" << str << "RESULTS IN"
                    << scriptOrURL.startsWith(str);
                if (!str.isEmpty() && scriptOrURL.startsWith(str)) {
                    passList = true;
                    qCDebug(scriptengine) << allowlistPrefix << "Script approved.";
                    break; // Bail early since we found a match.
                }
            }
        }
        // END processing of scripts through the allowlist.

        if (!passList) { // If the entity failed to pass for any reason, it's blocked and an error is thrown.
            qCDebug(scriptengine) << allowlistPrefix << "(disabled entity script)" << entityID.toString() << scriptOrURL;
            exception = _engine->makeError(_engine->newValue("UNSAFE_ENTITY_SCRIPTS == 0"));
        } else {
            QTimer timeout;
            timeout.setSingleShot(true);
            timeout.start(SANDBOX_TIMEOUT);
            connect(&timeout, &QTimer::timeout, [=, &sandbox] {
                qCDebug(scriptengine) << "ScriptManager::entityScriptContentAvailable timeout";

                // Guard against infinite loops and non-performant code
                sandbox->raiseException(
                    sandbox->makeError(sandbox->newValue(QString("Timed out (entity constructors are limited to %1ms)").arg(SANDBOX_TIMEOUT))));
            });

            testConstructor = sandbox->evaluate(program);

            if (sandbox->hasUncaughtException()) {
                exception = sandbox->cloneUncaughtException(QString("(preflight %1)").arg(entityID.toString()));
                sandbox->clearExceptions();
            } else if (testConstructor.isError()) {
                exception = testConstructor;
            }
        }
      // ENTITY SCRIPT ALLOWLIST ENDS HERE, uncomment below for original full disabling.

      // qCDebug(scriptengine) << "(disabled entity script)" << entityID.toString() << scriptOrURL;
      // exception = makeError("UNSAFE_ENTITY_SCRIPTS == 0");
    }

    if (exception.isError()) {
      // create a local copy using makeError to decouple from the sandbox engine
      exception = _engine->makeError(exception);
      setError(formatException(exception, _enableExtendedJSExceptions.get()), EntityScriptStatus::ERROR_RUNNING_SCRIPT);
      emit unhandledException(exception);
      return;
    }

    // CONSTRUCTOR VIABILITY
    if (!testConstructor.isFunction()) {
        QString testConstructorType = QString(testConstructor.toVariant().typeName());
        if (testConstructorType == "") {
            testConstructorType = "empty";
        }
        QString testConstructorValue = testConstructor.toString();
        if (testConstructorValue.size() > MAX_DEBUG_VALUE_LENGTH) {
            testConstructorValue = testConstructorValue.mid(0, MAX_DEBUG_VALUE_LENGTH) + "...";
        }
        auto message = QString("failed to load entity script -- expected a function, got %1, %2")
            .arg(testConstructorType).arg(testConstructorValue);

        auto err = _engine->makeError(_engine->newValue(message));
        err.setProperty("fileName", scriptOrURL);
        err.setProperty("detail", "(constructor " + entityID.toString() + ")");

        setError("Could not find constructor (" + testConstructorType + ")", EntityScriptStatus::ERROR_RUNNING_SCRIPT);
        emit unhandledException(err);
        return; // done processing script
    }*/

    // ENTITY SCRIPT ALLOWLIST STARTS HERE
    auto nodeList = DependencyManager::get<NodeList>();
    bool passList = false;  // assume unsafe
    QString allowlistPrefix = "[ALLOWLIST ENTITY SCRIPTS]";
    QList<QString> safeURLPrefixes = { "file:///", "atp:", "cache:" };
    safeURLPrefixes += qEnvironmentVariable("EXTRA_ALLOWLIST").trimmed().split(
        QRegularExpression(QStringLiteral("\\s*,\\s*")), Qt::SkipEmptyParts);

    // Entity Script Allowlist toggle check.
    Setting::Handle<bool> allowlistEnabled {"private/allowlistEnabled", false };

    if (!allowlistEnabled.get()) {
        passList = true;
    }

    // Pull SAFEURLS from the Interface.JSON settings.
    QVariant raw = Setting::Handle<QVariant>("private/settingsSafeURLS").get();
    QStringList settingsSafeURLS = raw.toString().trimmed().split(
        QRegularExpression(QStringLiteral("\\s*[,\r\n]+\\s*")), Qt::SkipEmptyParts);
    safeURLPrefixes += settingsSafeURLS;
    // END Pull SAFEURLS from the Interface.JSON settings.

    // Get current domain allowlist bypass, in case an entire domain is allowlisted.
    QString currentDomain = DependencyManager::get<AddressManager>()->getDomainURL().host();

    QString domainSafeIP = nodeList->getDomainHandler().getHostname();
    QString domainSafeURL = URL_SCHEME_OVERTE + "://" + currentDomain;
    for (const auto& str : safeURLPrefixes) {
        if (domainSafeURL.startsWith(str) || domainSafeIP.startsWith(str)) {
            qCDebug(scriptengine) << allowlistPrefix << "Allowlist Bypassed, entire domain is allowlisted. Current Domain Host: "
                                  << nodeList->getDomainHandler().getHostname()
                                  << "Current Domain: " << currentDomain;
            passList = true;
        }
    }
    // END bypass allowlist based on current domain.

    // Start processing scripts through the allowlist.
    if (ScriptManager::getContext() == "entity_server") { // If running on the server, do not engage allowlist.
        passList = true;
    } else if (!passList) { // If waved through, do not engage allowlist.
        for (const auto& str : safeURLPrefixes) {
            qCDebug(scriptengine) << allowlistPrefix << "Script URL: " << scriptOrURL << "TESTING AGAINST" << str << "RESULTS IN"
                                  << scriptOrURL.startsWith(str);
            if (!str.isEmpty() && scriptOrURL.startsWith(str)) {
                passList = true;
                qCDebug(scriptengine) << allowlistPrefix << "Script approved.";
                break; // Bail early since we found a match.
            }
        }
    }
    // END processing of scripts through the allowlist.

    ScriptValue exception;
    if (!passList) { // If the entity failed to pass for any reason, it's blocked and an error is thrown.
        qCDebug(scriptengine) << allowlistPrefix << "(disabled entity script)" << entityID.toString() << scriptOrURL;
        exception = _engine->makeError(_engine->newValue("UNSAFE_ENTITY_SCRIPTS == 0"));
    }

    if (exception.isError()) {
        setError(formatException(exception, _enableExtendedJSExceptions.get()), EntityScriptStatus::ERROR_RUNNING_SCRIPT);
        auto scriptRuntimeException = std::make_shared<ScriptRuntimeException>();
        ScriptValue message = exception.property("stack"); //This contains more details along with the error message
        scriptRuntimeException->errorMessage = message.toString();
        scriptRuntimeException->thrownValue = exception;
        emit unhandledException(scriptRuntimeException);
        return;
    }
    // ENTITY SCRIPT ALLOWLIST ENDS HERE, uncomment below for original full disabling.

    // qCDebug(scriptengine) << "(disabled entity script)" << entityID.toString() << scriptOrURL;
    // exception = makeError("UNSAFE_ENTITY_SCRIPTS == 0");

    // (this feeds into refreshFileScript)
    int64_t lastModified = 0;
    if (isFileUrl) {
        QString file = QUrl(scriptOrURL).toLocalFile();
        lastModified = (quint64)QFileInfo(file).lastModified().toMSecsSinceEpoch();
    }

    // THE ACTUAL EVALUATION AND CONSTRUCTION
    ScriptValue entityScriptConstructor, entityScriptObject;
    QUrl sandboxURL = currentSandboxURL.isEmpty() ? scriptOrURL : currentSandboxURL;
    auto initialization = [&]{
        if (!consentCurrent()) { return; }
        entityScriptConstructor = _engine->evaluate(contents, fileName);
        if (!consentCurrent()) { return; }
        if (!entityScriptConstructor.isFunction()) {
            setError(QStringLiteral("Entity script must evaluate to a constructor"), EntityScriptStatus::ERROR_RUNNING_SCRIPT);
            return;
        }
        entityScriptObject = entityScriptConstructor.construct();

        if (_engine->hasUncaughtException()) {
            // V8TODO: Why were we copying the uncaught exception here? Does anything
            // actually make use of that?
            //  entityScriptObject = _engine->cloneUncaughtException("(construct " + entityID.toString() + ")");
            entityScriptObject = _engine->nullValue();
            _engine->clearExceptions();
        }
    };

    doWithEnvironment(entityID, sandboxURL, initialization, consent);
    if (!consentCurrent()) { return; }

    if (!entityScriptObject.isObject() || entityScriptObject.isError()) {
       // auto exception = entityScriptObject;
       // setError(formatException(exception, _enableExtendedJSExceptions.get()), EntityScriptStatus::ERROR_RUNNING_SCRIPT);
       // emit unhandledException(exception);
       // V8TODO: Is this needed? Wouldn't the ScriptManager have already emitted the exception?
        return;
    }

    // ... AND WE HAVE LIFTOFF
    newDetails.status = EntityScriptStatus::RUNNING;
    newDetails.scriptObject = entityScriptObject;
    newDetails.consentRequest = consent;
    newDetails.lastModified = lastModified;
    newDetails.definingSandboxURL = sandboxURL;
    setEntityScriptDetails(entityID, scriptOrURL, newDetails);

    if (isURL) {
        setParentURL("");
    }

    // if we got this far, then call the preload method
#if defined(Q_OS_ANDROID)
    const quint64 preloadStartedAt = usecTimestampNow();
#endif
    callEntityScriptMethodForScript(entityID, scriptOrURL, "preload");
#if defined(Q_OS_ANDROID)
    const quint64 preloadElapsed = usecTimestampNow() - preloadStartedAt;
    if (preloadElapsed >= 250 * USECS_PER_MSEC) {
        qCWarning(scriptengine) << "PICO_ENTITY_PRELOAD_SLOW"
            << "elapsedMs" << preloadElapsed / USECS_PER_MSEC
            << "entity" << entityID
            << "script" << scriptOrURL;
    }
#endif

    emit entityScriptPreloadFinished(entityID);
}

/*@jsdoc
 * Triggered when the script terminates for a user.
 * <p>Note: Can only be connected to via <code>this.unload = function () { ... }</code> in the entity script.</p>
 * <p class="availableIn"><strong>Supported Script Types:</strong> Client Entity Scripts &bull; Server Entity Scripts</p>
 * @function Entities.unload
 * @param {Uuid} entityID - The ID of the entity that the script is running in.
 * @returns {Signal}
 */
// The JSDoc is for the callEntityScriptMethod() call in this method.
void ScriptManager::unloadEntityScript(const EntityItemID& entityID, const QString& scriptURL, bool shouldRemoveFromMap) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::unloadEntityScript() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "]  "
            "entityID:" << entityID;
#endif

        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->unloadEntityScript(entityID, scriptURL, shouldRemoveFromMap);
        });
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::unloadEntityScript() called on correct thread [" << thread() << "]  "
        "entityID:" << entityID;
#endif

    // Queued cleanup can arrive after run() has released its engine scope.
    // Copying EntityScriptDetails also copies ScriptValues and enters V8.
    // Acquire the engine before the details lock and retain it through cleanup.
    auto scopeGuard = _engine->getScopeGuard();

    auto consent = _entityScriptConsentRequests.find(entityID);
    if (consent != _entityScriptConsentRequests.end()) {
        if (auto request = consent->value(scriptURL)) { request->invalidate(); }
        consent->remove(scriptURL);
        if (consent->isEmpty()) { _entityScriptConsentRequests.erase(consent); }
    }
    cancelEntityScriptLoad(entityID, scriptURL);

    EntityScriptDetails oldDetails;
    if (getEntityScriptDetails(entityID, scriptURL, oldDetails)) {
        const auto& scriptText = oldDetails.scriptText;

        if (isEntityScriptRunning(entityID, scriptURL)) {
            callEntityScriptMethodForScript(entityID, scriptURL, "unload");
        }
#ifdef DEBUG_ENTITY_STATES
        else {
            qCDebug(scriptengine) << "unload called while !running" << entityID << oldDetails.status;
        }
#endif
        if (shouldRemoveFromMap) {
            // this was a deleted entity, we've been asked to remove it from the map
            {
                QWriteLocker locker { &_entityScriptsLock };
                auto& entityScripts = _entityScripts[entityID];
                entityScripts.remove(scriptText);
                if (entityScripts.size() == 0) {
                    _entityScripts.remove(entityID);
                }
            }
            emit entityScriptDetailsUpdated();
        } else if (oldDetails.status != EntityScriptStatus::UNLOADED) {
            EntityScriptDetails newDetails;
            newDetails.status = EntityScriptStatus::UNLOADED;
            newDetails.lastModified = QDateTime::currentMSecsSinceEpoch();
            // keep scriptText populated for the current need to "debouce" duplicate calls to unloadEntityScript
            newDetails.scriptText = scriptText;
            setEntityScriptDetails(entityID, scriptURL, newDetails);
        }

        stopAllTimersForEntityScript(entityID);
    }
}

void ScriptManager::unloadAllEntityScriptsForEntity(const EntityItemID& entityID, bool shouldRemoveFromMap) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::unloadAllEntityScriptsForEntity() called on wrong thread ["
                              << QThread::currentThread() << "], invoking on correct thread [" << thread()
                              << "]  "
                                 "entityID:"
                              << entityID;
#endif

        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()] {
            manager->unloadAllEntityScriptsForEntity(entityID, shouldRemoveFromMap);
        });
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::unloadAllEntityScriptsForEntity() called on correct thread [" << thread()
                          << "]  "
                             "entityID:"
                          << entityID;
#endif

    // Queued cleanup can arrive after run() has released its engine scope.
    // Copying EntityScriptDetails also copies ScriptValues and enters V8.
    // Acquire the engine before the details lock and retain it through cleanup.
    auto scopeGuard = _engine->getScopeGuard();

    for (const auto& request : _entityScriptConsentRequests.value(entityID)) { request->invalidate(); }
    _entityScriptConsentRequests.remove(entityID);
    _entityScriptLoads.remove(entityID);
    _contentAvailableQueue.remove(entityID);

    std::vector<EntityScriptDetails> scriptDetails;
    {
        QWriteLocker locker { &_entityScriptsLock };
        for (const auto& detail : _entityScripts[entityID]) {
            scriptDetails.push_back(detail);
        }
    }
    for (const auto& oldDetails : scriptDetails) {
        const auto& scriptText = oldDetails.scriptText;

        if (isEntityScriptRunning(entityID, scriptText)) {
            callEntityScriptMethodForScript(entityID, scriptText, "unload");
        }
#ifdef DEBUG_ENTITY_STATES
        else {
            qCDebug(scriptengine) << "unload called while !running" << entityID << oldDetails.status;
        }
#endif
        if (shouldRemoveFromMap) {
            // this was a deleted entity, we've been asked to remove it from the map
            {
                QWriteLocker locker{ &_entityScriptsLock };
                _entityScripts.remove(entityID);
            }
            emit entityScriptDetailsUpdated();
        } else if (oldDetails.status != EntityScriptStatus::UNLOADED) {
            EntityScriptDetails newDetails;
            newDetails.status = EntityScriptStatus::UNLOADED;
            newDetails.lastModified = QDateTime::currentMSecsSinceEpoch();
            // keep scriptText populated for the current need to "debouce" duplicate calls to unloadEntityScript
            newDetails.scriptText = scriptText;
            setEntityScriptDetails(entityID, scriptText, newDetails);
        }

        stopAllTimersForEntityScript(entityID);
    }
}

QList<EntityItemID> ScriptManager::getListOfEntityScriptIDs() {
    QReadLocker locker{ &_entityScriptsLock };
    return _entityScripts.keys();
}

void ScriptManager::unloadAllEntityScripts(bool blockingCall) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::unloadAllEntityScripts() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "]";
#endif
        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()] {
            manager->unloadAllEntityScripts(blockingCall);
        }, blockingCall ? Qt::BlockingQueuedConnection : Qt::QueuedConnection);
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::unloadAllEntityScripts() called on correct thread [" << thread() << "]";
#endif

    // Queued cleanup can arrive after run() has released its engine scope.
    // Copying EntityScriptDetails also copies ScriptValues and enters V8.
    // Acquire the engine before the details lock and retain it through cleanup.
    auto scopeGuard = _engine->getScopeGuard();

    for (const auto& scripts : _entityScriptConsentRequests) {
        for (const auto& request : scripts) { request->invalidate(); }
    }
    _entityScriptConsentRequests.clear();
    _entityScriptLoads.clear();
    _contentAvailableQueue.clear();

    std::vector<std::pair<EntityItemID, EntityScriptDetails>> scripts;
    {
        QReadLocker locker{ &_entityScriptsLock };
        for (const auto& entityID : _entityScripts.keys()) {
            for (const auto& scriptDetails : _entityScripts[entityID]) {
                scripts.push_back(std::make_pair(entityID, scriptDetails));
            }
        }
    }
    foreach (const auto& idAndScript, scripts) {
        unloadEntityScript(idAndScript.first, idAndScript.second.scriptText, true);
    }
    {
        QWriteLocker locker{ &_entityScriptsLock };
        _entityScripts.clear();
    }
    emit entityScriptDetailsUpdated();

#ifdef DEBUG_ENGINE_STATE
    _debugDump(
        "---- CURRENT STATE OF ENGINE: --------------------------",
        globalObject(),
        "--------------------------------------------------------"
    );
#endif // DEBUG_ENGINE_STATE
}

void ScriptManager::refreshFileScript(const EntityItemID& entityID, const QString& scriptURL) {
    if (!HIFI_AUTOREFRESH_FILE_SCRIPTS || !hasEntityScriptDetails(entityID, scriptURL)) {
        return;
    }

    if (_refreshRecurseGuard) {
        return;
    }
    _refreshRecurseGuard = true;

    EntityScriptDetails details;
    {
        QWriteLocker locker { &_entityScriptsLock };
        details = _entityScripts[entityID][scriptURL];
    }
    // Check to see if a file based script needs to be reloaded (easier debugging)
    if (details.lastModified > 0) {
        QString filePath = QUrl(details.scriptText).toLocalFile();
        auto lastModified = QFileInfo(filePath).lastModified().toMSecsSinceEpoch();
        if (lastModified > details.lastModified) {
            scriptInfoMessage("Reloading modified script " + details.scriptText, filePath, -1);
            unloadEntityScript(entityID, details.scriptText, true);
            loadEntityScript(entityID, details.scriptText, true);
        }
    }
    _refreshRecurseGuard = false;
}

// Execute operation in the appropriate context for (the possibly empty) entityID.
// Even if entityID is supplied as currentEntityIdentifier, this still documents the source
// of the code being executed (e.g., if we ever sandbox different entity scripts, or provide different
// global values for different entity scripts).
std::function<void(std::function<void()>)> ScriptManager::captureScriptEnvironment() {
    const auto weakManager = weak_from_this();
    const auto entity = currentEntityIdentifier;
    const auto sandbox = currentSandboxURL;
    const auto consent = _currentEntityScriptConsentRequest;
    return [weakManager, entity, sandbox, consent](std::function<void()> operation) {
        if (const auto manager = weakManager.lock()) {
            manager->doWithEnvironment(entity, sandbox, std::move(operation), consent);
        }
    };
}

bool ScriptManager::entityScriptInvocationAllowed(const EntityItemID& entityID,
    const std::shared_ptr<EntityScriptConsentRequest>& consent) const {
    return _context != ENTITY_CLIENT_SCRIPT ||
        (consent && consent->allowed() && consent->belongsTo(_entityScriptConsentScope) &&
         !isStopping() && !_isFinished &&
         _entityScriptConsentRequests.value(entityID).value(consent->source()) == consent);
}

void ScriptManager::doWithEnvironment(const EntityItemID& entityID, const QUrl& sandboxURL, std::function<void()> operation, const std::shared_ptr<EntityScriptConsentRequest>& consent) {
    if (!entityScriptInvocationAllowed(entityID, consent)) { return; }
    const auto oldConsent = _currentEntityScriptConsentRequest;
    _currentEntityScriptConsentRequest = consent;
    EntityItemID oldIdentifier = currentEntityIdentifier;
    QUrl oldSandboxURL = currentSandboxURL;
    currentEntityIdentifier = entityID;
    currentSandboxURL = sandboxURL;

#if DEBUG_CURRENT_ENTITY
    ScriptValue oldData = this->globalObject().property("debugEntityID");
    this->globalObject().setProperty("debugEntityID", entityID.toScriptValue(this)); // Make the entityID available to javascript as a global.
    operation();
    this->globalObject().setProperty("debugEntityID", oldData);
#else
    operation();
#endif
    currentEntityIdentifier = oldIdentifier;
    currentSandboxURL = oldSandboxURL;
    _currentEntityScriptConsentRequest = oldConsent;
}

void ScriptManager::callWithEnvironment(const EntityItemID& entityID, const QUrl& sandboxURL, const ScriptValue& function, const ScriptValue& thisObject, const ScriptValueList& args, const std::shared_ptr<EntityScriptConsentRequest>& consent) {
    auto operation = [&]() {
        function.call(thisObject, args);
    };
    doWithEnvironment(entityID, sandboxURL, operation, consent);
}

void ScriptManager::callEntityScriptMethod(const EntityItemID& entityID, const QString& methodName, const QStringList& params, const QUuid& remoteCallerID) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::callEntityScriptMethod() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "]  "
            "entityID:" << entityID << "methodName:" << methodName;
#endif
        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->callEntityScriptMethod(entityID, methodName, params, remoteCallerID);
        });
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::callEntityScriptMethod() called on correct thread [" << thread() << "]  "
        "entityID:" << entityID << "methodName:" << methodName;
#endif

    std::vector<EntityScriptDetails> scriptDetails;
    {
        QWriteLocker locker { &_entityScriptsLock };
        for (const auto& detail : _entityScripts[entityID]) {
            scriptDetails.push_back(detail);
        }
    }
    for (const auto& details : scriptDetails) {
        if (HIFI_AUTOREFRESH_FILE_SCRIPTS && methodName != "unload") {
            refreshFileScript(entityID, details.scriptText);
        }
        if (entityScriptInvocationAllowed(entityID, details.consentRequest) &&
            isEntityScriptRunning(entityID, details.scriptText)) {
            ScriptValue entityScript = details.scriptObject;  // previously loaded

            // If this is a remote call, we need to check to see if the function is remotely callable
            // we do this by checking for the existance of the 'remotelyCallable' property on the
            // entityScript. And we confirm that the method name is included. If this fails, the
            // function will not be called.
            bool callAllowed = false;
            if (remoteCallerID == QUuid()) {
                callAllowed = true;
            } else {
                if (entityScript.property("remotelyCallable").isArray()) {
                    auto callables = entityScript.property("remotelyCallable");
                    auto callableCount = callables.property("length").toInteger();
                    for (int i = 0; i < callableCount; i++) {
                        auto callable = callables.property(i).toString();
                        if (callable == methodName) {
                            callAllowed = true;
                            break;
                        }
                    }
                }
                if (!callAllowed) {
                    qCDebug(scriptengine) << "Method [" << methodName << "] not remotely callable.";
                }
            }

            if (callAllowed && entityScript.property(methodName).isFunction()) {
                auto scriptEngine = engine().get();

                ScriptValueList args;
                args << EntityItemIDtoScriptValue(scriptEngine, entityID);
                args << scriptValueFromSequence(scriptEngine, params);

                ScriptValue oldData = scriptEngine->globalObject().property("Script").property("remoteCallerID");
                scriptEngine->globalObject()
                    .property("Script")
                    .setProperty("remoteCallerID",
                                 remoteCallerID.toString());  // Make the remoteCallerID available to javascript as a global.
                callWithEnvironment(entityID, details.definingSandboxURL, entityScript.property(methodName), entityScript,
                                    args, details.consentRequest);
                scriptEngine->globalObject().property("Script").setProperty("remoteCallerID", oldData);
            }
        }
    }
}

void ScriptManager::callEntityScriptMethodForScript(const EntityItemID& entityID,
                                                    const QString& scriptURL,
                                                    const QString& methodName,
                                                    const QStringList& params,
                                                    const QUuid& remoteCallerID) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::callEntityScriptMethodForScript() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "]  "
            "entityID:" << entityID << "script:" << scriptURL << "methodName:" << methodName;
#endif
        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->callEntityScriptMethodForScript(entityID, scriptURL, methodName, params, remoteCallerID);
        });
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::callEntityScriptMethodForScript() called on correct thread [" << thread() << "]  "
        "entityID:" << entityID << "methodName:" << methodName;
#endif

    EntityScriptDetails details;
    {
        QWriteLocker locker { &_entityScriptsLock };
        details = _entityScripts[entityID][scriptURL];
    }
    if (HIFI_AUTOREFRESH_FILE_SCRIPTS && methodName != "unload") {
        refreshFileScript(entityID, scriptURL);
    }
    if (entityScriptInvocationAllowed(entityID, details.consentRequest) &&
        isEntityScriptRunning(entityID, scriptURL)) {
        ScriptValue entityScript = details.scriptObject;  // previously loaded

        // If this is a remote call, we need to check to see if the function is remotely callable
        // we do this by checking for the existance of the 'remotelyCallable' property on the
        // entityScript. And we confirm that the method name is included. If this fails, the
        // function will not be called.
        bool callAllowed = false;
        if (remoteCallerID == QUuid()) {
            callAllowed = true;
        } else {
            if (entityScript.property("remotelyCallable").isArray()) {
                auto callables = entityScript.property("remotelyCallable");
                auto callableCount = callables.property("length").toInteger();
                for (int i = 0; i < callableCount; i++) {
                    auto callable = callables.property(i).toString();
                    if (callable == methodName) {
                        callAllowed = true;
                        break;
                    }
                }
            }
            if (!callAllowed) {
                qCDebug(scriptengine) << "Method [" << methodName << "] not remotely callable.";
            }
        }

        if (callAllowed && entityScript.property(methodName).isFunction()) {
            auto scriptEngine = engine().get();

            ScriptValueList args;
            args << EntityItemIDtoScriptValue(scriptEngine, entityID);
            args << scriptValueFromSequence(scriptEngine, params);

            ScriptValue oldData = scriptEngine->globalObject().property("Script").property("remoteCallerID");
            scriptEngine->globalObject()
                .property("Script")
                .setProperty("remoteCallerID",
                                remoteCallerID.toString());  // Make the remoteCallerID available to javascript as a global.
            callWithEnvironment(entityID, details.definingSandboxURL, entityScript.property(methodName), entityScript,
                                args, details.consentRequest);
            scriptEngine->globalObject().property("Script").setProperty("remoteCallerID", oldData);
        }
    }
}

void ScriptManager::callEntityScriptMethodForScript(const EntityItemID& entityID,
                                                    const QString& scriptURL,
                                                    const QString& methodName,
                                                    const QString& param) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::callEntityScriptMethodForScript() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "]  "
            "entityID:" << entityID << "script:" << scriptURL << "methodName:" << methodName;
#endif
        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->callEntityScriptMethodForScript(entityID, scriptURL, methodName, param);
        });
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::callEntityScriptMethodForScript() called on correct thread [" << thread() << "]  "
        "entityID:" << entityID << "methodName:" << methodName;
#endif

    EntityScriptDetails details;
    {
        QWriteLocker locker { &_entityScriptsLock };
        details = _entityScripts[entityID][scriptURL];
    }
    if (HIFI_AUTOREFRESH_FILE_SCRIPTS && methodName != "unload") {
        refreshFileScript(entityID, scriptURL);
    }
    if (entityScriptInvocationAllowed(entityID, details.consentRequest) &&
        isEntityScriptRunning(entityID, scriptURL)) {
        ScriptValue entityScript = details.scriptObject;  // previously loaded

        if (entityScript.property(methodName).isFunction()) {
            auto scriptEngine = engine().get();

            ScriptValueList args;
            args << EntityItemIDtoScriptValue(scriptEngine, entityID);
            args << scriptValueFromValue(scriptEngine, param);
            callWithEnvironment(entityID, details.definingSandboxURL, entityScript.property(methodName), entityScript,
                                args, details.consentRequest);
        }
    }
}

void ScriptManager::callEntityScriptMethod(const EntityItemID& entityID, const QString& methodName, const PointerEvent& event) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::callEntityScriptMethod() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "]  "
            "entityID:" << entityID << "methodName:" << methodName << "event: mouseEvent";
#endif

        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->callEntityScriptMethod(entityID, methodName, event);
        });
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::callEntityScriptMethod() called on correct thread [" << thread() << "]  "
        "entityID:" << entityID << "methodName:" << methodName << "event: pointerEvent";
#endif

    std::vector<EntityScriptDetails> scriptDetails;
    {
        QWriteLocker locker{ &_entityScriptsLock };
        for (const auto& detail : _entityScripts[entityID]) {
            scriptDetails.push_back(detail);
        }
    }
    for (const auto& details : scriptDetails) {
        if (HIFI_AUTOREFRESH_FILE_SCRIPTS) {
            refreshFileScript(entityID, details.scriptText);
        }
        if (entityScriptInvocationAllowed(entityID, details.consentRequest) &&
            isEntityScriptRunning(entityID, details.scriptText)) {
            ScriptValue entityScript = details.scriptObject;  // previously loaded
            if (entityScript.property(methodName).isFunction()) {
                auto scriptEngine = engine().get();

                ScriptValueList args;
                args << EntityItemIDtoScriptValue(scriptEngine, entityID);
                args << event.toScriptValue(scriptEngine);
                callWithEnvironment(entityID, details.definingSandboxURL, entityScript.property(methodName), entityScript, args, details.consentRequest);
            }
        }
    }
}

void ScriptManager::callEntityScriptMethod(const EntityItemID& entityID, const QString& methodName, const EntityItemID& otherID, const Collision& collision) {
    if (QThread::currentThread() != thread()) {
#ifdef THREAD_DEBUGGING
        qCDebug(scriptengine) << "*** WARNING *** ScriptManager::callEntityScriptMethod() called on wrong thread [" << QThread::currentThread() << "], invoking on correct thread [" << thread() << "]  "
            "entityID:" << entityID << "methodName:" << methodName << "otherID:" << otherID << "collision: collision";
#endif

        // Lambda is necessary there to keep shared_ptr counter above zero
        QMetaObject::invokeMethod(this, [=, manager = shared_from_this()]{
            manager->callEntityScriptMethod(entityID, methodName, otherID, collision);
        });
        return;
    }
#ifdef THREAD_DEBUGGING
    qCDebug(scriptengine) << "ScriptManager::callEntityScriptMethod() called on correct thread [" << thread() << "]  "
        "entityID:" << entityID << "methodName:" << methodName << "otherID:" << otherID << "collision: collision";
#endif

    std::vector<EntityScriptDetails> scriptDetails;
    {
        QWriteLocker locker{ &_entityScriptsLock };
        for (const auto& detail : _entityScripts[entityID]) {
            scriptDetails.push_back(detail);
        }
    }
    for (const auto& details : scriptDetails) {
        if (HIFI_AUTOREFRESH_FILE_SCRIPTS) {
            refreshFileScript(entityID, details.scriptText);
        }
        if (entityScriptInvocationAllowed(entityID, details.consentRequest) &&
            isEntityScriptRunning(entityID, details.scriptText)) {
            ScriptValue entityScript = details.scriptObject;  // previously loaded
            if (entityScript.property(methodName).isFunction()) {
                auto scriptEngine = engine().get();

                ScriptValueList args;
                args << EntityItemIDtoScriptValue(scriptEngine, entityID);
                args << EntityItemIDtoScriptValue(scriptEngine, otherID);
                args << collisionToScriptValue(scriptEngine, collision);
                callWithEnvironment(entityID, details.definingSandboxURL, entityScript.property(methodName), entityScript,
                                    args, details.consentRequest);
            }
        }
    }
}

QString ScriptManager::getExternalPath(ExternalResource::Bucket bucket, const QString& path) {
    return ExternalResource::getInstance()->getUrl(bucket, path);
}

QString ScriptManager::formatException(const ScriptValue& exception, bool includeExtendedDetails) {
    if (!_engine->IS_THREADSAFE_INVOCATION(__FUNCTION__)) {
        return QString();
    }
    QString note{ "UncaughtException" };
    QString result;

    if (!exception.isObject()) {
        return result;
    }
    const auto message = exception.toString();
    const auto fileName = exception.property("fileName").toString();
    const auto lineNumber = exception.property("lineNumber").toString();
    const auto stacktrace = exception.property("stack").toString();

    if (includeExtendedDetails) {
        // Display additional exception / troubleshooting hints that can be added via the custom Error .detail property
        // Example difference:
        //   [UncaughtExceptions] Error: Can't find variable: foobar in atp:/myentity.js\n...
        //   [UncaughtException (construct {1eb5d3fa-23b1-411c-af83-163af7220e3f})] Error: Can't find variable: foobar in atp:/myentity.js\n...
        if (exception.property("detail").isValid()) {
            note += " " + exception.property("detail").toString();
        }
    }

    result = QString(SCRIPT_EXCEPTION_FORMAT).arg(note, message, fileName, lineNumber);
    if (!stacktrace.isEmpty()) {
        result += QString("\n[Backtrace]%1%2").arg(SCRIPT_BACKTRACE_SEP).arg(stacktrace);
    }
    return result;
}

ScriptValue ScriptManager::evaluate(const QString& program, const QString& fileName) {
    return _engine->evaluate(program, fileName);
}

void ScriptManager::requestGarbageCollection() {
    _engine->requestCollectGarbage();
}

void ScriptManager::logBacktrace(const QString &title) {
    _engine->logBacktrace(title);
}
