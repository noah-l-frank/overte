"""Original stdlib metadata ports only; no SUT import on import."""
from pathlib import Path
import hashlib,io,json,os,stat,subprocess,sys,threading
REPO=Path(__file__).resolve().parent.parent.parent
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
_ORIGINAL_SAVE_PORTS=(os.open,os.fdopen,os.fsync)
def load(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    path=Path(path);fd=_ORIGINAL_SAVE_PORTS[0](path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_CLOEXEC,0o600)
    with _ORIGINAL_SAVE_PORTS[1](fd,'w')as stream:
        json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n');stream.flush();_ORIGINAL_SAVE_PORTS[2](stream.fileno())
def pin(path):
    path=Path(path);s=path.lstat();assert stat.S_ISREG(s.st_mode)and path.resolve(strict=True)==path and s.st_nlink==1
    row={k:getattr(s,k)for k in FIELDS};row['sha256']=sha(path)
    assert all(getattr(path.lstat(),k)==row[k]for k in FIELDS);return row
def head():
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ')
    gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for base in(gd,common):
        path=base/ref[5:]
        if path.is_file():return path.read_text().strip()
    for line in(common/'packed-refs').read_text().splitlines():
        if line and not line.startswith(('#','^')):
            value,name=line.split(' ',1)
            if name==ref[5:]:return value
    raise AssertionError('Actual current checkout HEAD unavailable')
def proc(pid):
    try:raw=Path('/proc',str(pid),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    values=raw[raw.rfind(')')+2:].split()
    return dict(pid=int(raw[:raw.index('(')].strip()),parentPid=int(values[1]),processGroup=int(values[2]),session=int(values[3]),startTicks=int(values[19]))
def fds():
    rows={}
    for p in Path('/proc/self/fd').iterdir():
        try:s=p.stat();rows[p.name]=dict(path=os.readlink(p),device=s.st_dev,inode=s.st_ino,mode=s.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return rows
def census(root):
    root=Path(root);out={}
    def visit(path):
        s=path.lstat();row={k:getattr(s,k)for k in FIELDS}
        if stat.S_ISDIR(s.st_mode):
            names=sorted(x.name for x in path.iterdir())
            for name in names:visit(path/name)
            assert sorted(x.name for x in path.iterdir())==names
        elif stat.S_ISREG(s.st_mode):row=pin(path)
        elif stat.S_ISLNK(s.st_mode):row['target']=os.readlink(path)
        else:raise AssertionError('Unsupported original file kind')
        assert all(getattr(path.lstat(),k)==row[k]for k in FIELDS);out[str(path.relative_to(root))]=row
    visit(root);return out
def all_pins(rows):
    actual={path:pin(path)for path in rows};assert actual==rows,'Source/controller/binary pin drift';return actual
def global_census(expected):
    actual={root:census(root)for root in expected};assert actual==expected,'Retained old original drift';return actual

