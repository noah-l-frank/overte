"""Stdlib-only custody for the isolated five-case Root controller."""
from pathlib import Path
import hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent
SOURCE=HERE/'source'
PUBLIC_ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript','domain-server/resources')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(name):return json.loads((HERE/name).read_text())
_ORIGINAL_SAVE_PORTS=(os.open,os.write,os.fsync,os.close)
def save(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    original_open,original_write,original_sync,original_close=_ORIGINAL_SAVE_PORTS
    descriptor=original_open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_CLOEXEC',0),0o600)
    try:
        pending=memoryview(raw)
        while pending:
            count=original_write(descriptor,pending);assert count>0;pending=pending[count:]
        original_sync(descriptor)
    finally:original_close(descriptor)
def pin(path):
    first=path.lstat();value={key:getattr(first,key) for key in FIELDS}
    if stat.S_ISREG(first.st_mode):value['sha256']=sha(path)
    elif stat.S_ISLNK(first.st_mode):value['target']=str(path.readlink())
    else:assert stat.S_ISDIR(first.st_mode),str(path)
    second=path.lstat();assert all(getattr(first,k)==getattr(second,k) for k in FIELDS),str(path)
    return value

def proc(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,state=fields[0],parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
def processes(session):
    values=[]
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            row=proc(int(path.name))
            if row is not None and (row['session']==session or row['processGroup']==session):values.append(row)
    return values

def fds(pid):
    result={};root=Path('/proc',str(pid),'fd')
    try:paths=list(root.iterdir())
    except FileNotFoundError:return result
    for path in paths:
        try:target=os.readlink(path)
        except (FileNotFoundError,PermissionError):continue
        result[path.name]=target
    return result

def census(root):
    assert root.is_dir() and root.resolve()==root
    return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
def prior_roots():
    context=load('root-terminal-context.json')
    assert context['allTargetWindowsTerminal']is True and context['originalRoots']
    roots={Path(path)for path in context['originalRoots']}
    assert len(roots)==len(context['originalRoots'])
    assert all(path.is_absolute()and path.is_relative_to(REPO/'.ios-host-tmp')for path in roots)
    # Any later Root-owned run corpora join the same guards, never an exclusion.
    for directory in (REPO/'.ios-host-tmp').iterdir():
        if directory.is_dir() and not directory.is_symlink() and directory!=HERE:
            for name in ('runs','temporary'):
                path=directory/name
                if path.is_dir() and not path.is_symlink():roots.add(path)
    if (HERE/'runs').exists():
        for directory in (HERE/'runs').iterdir():
            if directory.is_dir():
                for path in directory.iterdir():
                    if path.is_dir():roots.add(path)
    return sorted(roots)
def prior_census(roots):return {str(path):census(path) for path in roots}
def public_guard():
    expected=load('public-dependency-baselines.json')
    raw=subprocess.check_output([load('host-executable-pins.json')['rg']['realPath'],'--files','-0',*PUBLIC_ROOTS],cwd=REPO)
    actual=set(filter(None,raw.decode().split('\0')))|{'CMakeLists.txt','interface/CMakeLists.txt'}
    assert actual==set(expected),'Public source membership changed'
    result={name:pin(REPO/name) for name in sorted(actual)}
    for name,row in result.items():
        old=expected[name]
        assert row['sha256']==old['sha256'] and row['st_dev']==old['device'] and row['st_ino']==old['inode'] and row['st_size']==old['bytes'],name
    return result

def validate():
    frozen=load('freeze.json')
    for row in frozen['files']:
        path=HERE/row['path'];assert path.is_file() and not path.is_symlink() and sha(path)==row['sha256'],row['path']
    source=load('isolated-source-origins.json');paths=[SOURCE,*sorted(SOURCE.rglob('*'))];assert not any(p.is_symlink() for p in paths),'Isolated source symlink refused'
    physical=load('isolated-source-physical-pins.json');actual={str(p.relative_to(SOURCE)) for p in paths if not p.is_dir()};actual_dirs={str(p.relative_to(SOURCE)) for p in paths if p.is_dir()}
    assert actual_dirs==set(physical['directories']),'Isolated source directory membership drift'
    for name,row in {**physical['files'],**physical['directories']}.items():
        info=(SOURCE/name).lstat();assert all(getattr(info,key)==value for key,value in row.items()),name
    assert actual==set(source),'Isolated source membership drift'
    for name,row in source.items():assert sha(SOURCE/name)==row['sha256'],name
    parent=REPO/load('execution-plan.json')['parentPlanPath'];assert sha(parent/'freeze.json')==load('execution-plan.json')['parentPlanRawFreezeSha256']
    packet=REPO/load('execution-plan.json')['packetPath'];assert sha(packet/'freeze.json')==load('execution-plan.json')['packetRawFreezeSha256']
    for row in json.loads((packet/'freeze.json').read_text())['files']:assert sha(packet/row['path'])==row['sha256'],row['path']
    fix=REPO/load('execution-plan.json')['mechanicalFixtureFixPath'];assert sha(fix/'freeze.json')==load('execution-plan.json')['mechanicalFixtureFixRawFreezeSha256']
    for row in json.loads((fix/'freeze.json').read_text())['files']:assert sha(fix/row['path'])==row['sha256'],row['path']
    bridge=REPO/load('execution-plan.json')['nativeConstructorFixturePath'];assert sha(bridge/'freeze.json')==load('execution-plan.json')['nativeConstructorFixtureRawFreezeSha256']
    for row in json.loads((bridge/'freeze.json').read_text())['files']:assert sha(bridge/row['path'])==row['sha256'],row['path']
    for failure_name in ('preserved-first-failure-pins.json','preserved-second-failure-pins.json','preserved-third-failure-pins.json','preserved-fourth-failure-pins.json','preserved-fifth-partial-pins.json','preserved-sixth-actual-pins.json','preserved-seventh-actual-pins.json','preserved-eighth-actual-pins.json','preserved-ninth-actual-pins.json'):
        failure=load(failure_name)
        for name,row in failure['files'].items():
            path=REPO/name;info=path.stat();assert sha(path)==row['sha256'] and (info.st_dev,info.st_ino,info.st_size)==(row['device'],row['inode'],row['bytes']),name
    edit_fix=REPO/load('execution-plan.json')['normalEditEnvelopeFixPath'];assert sha(edit_fix/'freeze.json')==load('execution-plan.json')['normalEditEnvelopeFixRawFreezeSha256']
    for row in json.loads((edit_fix/'freeze.json').read_text())['files']:assert sha(edit_fix/row['path'])==row['sha256'],row['path']
    live_fix=REPO/load('execution-plan.json')['currentPermissionsFixPath'];assert sha(live_fix/'freeze.json')==load('execution-plan.json')['currentPermissionsFixRawFreezeSha256']
    for row in json.loads((live_fix/'freeze.json').read_text())['files']:assert sha(live_fix/row['path'])==row['sha256'],row['path']
    scene_fix=REPO/load('execution-plan.json')['sceneGuardFixPath'];assert sha(scene_fix/'freeze.json')==load('execution-plan.json')['sceneGuardFixRawFreezeSha256']
    for row in json.loads((scene_fix/'freeze.json').read_text())['files']:assert sha(scene_fix/row['path'])==row['sha256'],row['path']
    picker=REPO/load('execution-plan.json')['picker3PacketPath'];assert sha(picker/'freeze.json')==load('execution-plan.json')['picker3PacketRawFreezeSha256']
    for row in json.loads((picker/'freeze.json').read_text())['files']:assert sha(picker/row['path'])==row['sha256'],row['path']
    previous=REPO/load('execution-plan.json')['previousControllerPath'];assert sha(previous/'freeze.json')==load('execution-plan.json')['previousControllerRawFreezeSha256']
    for row in load('parent-chain-source-pins.json'):
        path=REPO/row['sourcePath'];info=path.stat();assert sha(path)==row['sha256'] and (info.st_dev,info.st_ino,info.st_size)==(row['device'],row['inode'],row['bytes']),row['path']
    profile=REPO/load('execution-plan.json')['profileAdmissionPacketPath'];assert sha(profile/'freeze.json')==load('execution-plan.json')['profileAdmissionPacketRawFreezeSha256']
    for row in json.loads((profile/'freeze.json').read_text())['files']:assert sha(profile/row['path'])==row['sha256'],row['path']
    source5=REPO/load('execution-plan.json')['source5PacketPath'];assert sha(source5/'freeze.json')==load('execution-plan.json')['source5PacketRawFreezeSha256']
    for row in json.loads((source5/'freeze.json').read_text())['files']:assert sha(source5/row['path'])==row['sha256'],row['path']
    source6=REPO/load('execution-plan.json')['source6PacketPath'];assert sha(source6/'freeze.json')==load('execution-plan.json')['source6PacketRawFreezeSha256']
    for row in json.loads((source6/'freeze.json').read_text())['files']:assert sha(source6/row['path'])==row['sha256'],row['path']
    for name,row in load('host-executable-pins.json').items():
        path=Path(row['path']);actual=path.resolve(strict=True);info=actual.stat()
        assert str(actual)==row['realPath'] and sha(actual)==row['sha256'] and (info.st_dev,info.st_ino)==(row['device'],row['inode']),name
    plan=load('execution-plan.json')
    assert plan['reservedFixtureFreeze']=='abb2f1dadf4b9be26e376b5248d9557d23a4952546b9c28c82b58819fe2ad995'
    assert plan['source6PacketRawFreezeSha256']=='be61ffdd00e27583cb50812f916542d324fdc3f1572cbbfd54a5dc47ae81114e'
    fixture=REPO/plan['reservedFixturePacketPath'];assert sha(fixture/'freeze.json')==plan['reservedFixtureFreeze']
    members=json.loads((fixture/'freeze.json').read_text())['files']
    items=members.items()if type(members)is dict else((row['path'],row)for row in members)
    for name,row in items:
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        assert sha(fixture/name)==(row['sha256']if type(row)is dict else row),name
    expected=json.loads((fixture/'seven-unrun-models.json').read_text())
    ids=[expected['module']+'.'+expected['className']+'.'+method for method in expected['methods']]
    assert len(ids)==7 and plan['order']==['phase']and set(plan['selection'])=={'phase'}
    assert plan['selection']['phase']['id']==ids[0],'Only the new real reserved phase counter selected'
    failed=REPO/plan['failedController10ReceiptPath'];assert sha(failed/'freeze.json')=='ea6d19fcdf76f674e5e7587e9228c1c1e9dfcc2cdbcc81f23729b978beab92cd'
    assert sha(HERE/'owned_write_boundary.py')=='156560033c0c292aa72be6cd66af136683de28490341dceacc191398b5167bda'
    context=load('root-terminal-context.json')
    for packet in context['completedRootProofs']:
        root=REPO/packet['path'];assert sha(root/'freeze.json')==packet['freezeSha256']
    assert set(load('explicit-root-original-baselines.json'))==set(context['originalRoots'])
    return plan


def current_head():
    raw=(REPO/'.git').read_text();assert raw.startswith('gitdir: ')
    gd=Path(raw[8:].strip());gd=gd if gd.is_absolute()else REPO/gd
    gd=gd.resolve(strict=True);common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    selected=(gd/'HEAD').read_text().strip();assert selected.startswith('ref: ')
    ref=selected[5:]
    for base in(gd,common):
        if(base/ref).is_file():return(base/ref).read_text().strip()
    for line in(common/'packed-refs').read_text().splitlines():
        if line and not line.startswith(('#','^')):
            value,name=line.split(' ',1)
            if name==ref:return value
    raise AssertionError('Actual own checkout HEAD unavailable')


_historical_validate=validate

def validate():
    plan=load('execution-plan.json')
    assert plan['actualExpectedHead']==current_head()
    assert plan['historicalController10Head']=='d824159435cbb4e70576ce13e3a343e9858e6caf'
    value=_historical_validate()
    for path,row in load('historical-private-origin-pins.json').items():
        path=Path(path);assert path.resolve(strict=True)==path and not path.is_symlink()and pin(path)==row
    for row in load('controller-source-custody.json'):
        file=Path(row['path']);assert sha(file)==row['sha256']
        members=json.loads(file.read_text())['files']
        entries=members.items()if type(members)is dict else((item['path'],item)for item in members)
        for name,item in entries:
            assert not Path(name).is_absolute()and '..'not in Path(name).parts
            assert sha(file.parent/name)==(item['sha256']if type(item)is dict else item)
    for path,row in load('root-context-source-pins.json').items():
        path=Path(path);assert path.resolve(strict=True)==path and not path.is_symlink()and pin(path)==row
    prerequisite=load('qualified-own3-prerequisite.json')
    path=REPO/prerequisite['packet'];assert sha(path/'freeze.json')=='8c079bab025acad40ec33c9519b13b3e0972bf5f54406fc55c8f8f8c8bf27b06'
    manifest=json.loads((path/'freeze.json').read_text())
    for name,row in manifest['files'].items():assert sha(path/name)==row['sha256']
    actual=json.loads((path/'results.json').read_text())
    assert actual['portsSourceFreeze']=='ea3f310a79432af3e0561d3639737399dd4e387050c34411e457ba5f6748200d'
    assert actual['actualTests']==3 and actual['portNegativeCountersQualified']is True
    assert actual['child']['cleanupEstablished']and actual['child']['fdUnchanged']and actual['child']['threadsUnchanged']and actual['child']['kernelChildrenUnchanged']
    assert actual['ports']['restored']and actual['ports']['count']==27 and actual['ports']['dupPortsRestored']and not actual['ports']['controlDescriptors']
    terminal=actual['terminal'];assert terminal['status']=='PASS'and terminal['childReturnCode']==0 and terminal['ownProcessesAbsent']
    assert not terminal['timedOut']and not terminal['forcedKill']and not terminal['orphansRequiredKill']and not terminal['problems']
    assert actual['normalAction2Qualified']is False and actual['wholeQualified']is False
    return value


_c14_validate=validate
def validate():
    from backend_dirfd_admission import require_backend_dirfd_qualification
    from metadata_reader import pin as strict_source_pin
    boundary_qualification,boundary_files=require_backend_dirfd_qualification(REPO,strict_source_pin,HERE)
    # Original C12/C14 file/raw/source/Own3/corpus checks remain literal.
    plan=_c14_validate()
    from closed_source_metadata import validate as closed_validate
    closure=closed_validate()
    assert plan['backendOwn9Qualification']==closure['backendOwn9Qualification']==boundary_qualification
    assert plan['diagnosticOnly']is plan['diagnosticAlwaysNonzero']is True
    assert plan['diagnosticPhaseAdmission']is None and plan['diagnosticCompositionQualified']is False
    assert plan['diagnosticUtilityQualification']==closure['diagnosticUtilityQualification']
    assert all(closure['physicalPins'].get(path)==row for path,row in boundary_files.items())
    return plan
