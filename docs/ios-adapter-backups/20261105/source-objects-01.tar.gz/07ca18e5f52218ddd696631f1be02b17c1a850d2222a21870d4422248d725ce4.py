from pathlib import Path
from types import SimpleNamespace
import json,sys,signal,time,traceback,importlib.abc,importlib.util
REPO=Path.cwd();HERE=Path(__file__).resolve().parent
controller=REPO/'.ios-host-tmp/chat-send-proof-source15-paired-root-preparation-20261103'
sys.path.insert(0,str(controller));import run_metadata as meta
plan=meta.validate_frozen();meta.publication();before=meta.sources(plan);own=meta.pin(Path(__file__).resolve())
corpus=Path(json.loads((controller/'paired1-report.json').read_text())['runRoot'])/'temporary';originals=meta.originals(corpus)
assert originals==json.loads((controller/'paired1-originals-second.json').read_text())
meta.save(HERE/'source-before.json',before)
def audit(event,args):
    if event=='import':assert not any(part in ('pymobiledevice3','tidevice','pyidevice','zeroconf') for part in args[0].split('.'))
    elif event=='subprocess.Popen':assert list(args[1])==['rg','--files','-0',*plan['broadSourceRoots']] and Path(args[2]).resolve()==REPO
    elif event in ('socket.connect','socket.bind'):raise AssertionError('Historical diagnostic cannot use a service')
    elif event=='open' and isinstance(args[0],(str,bytes)):
        p=Path(args[0]).absolute();flags=args[2]
        if p.is_relative_to(corpus) and isinstance(flags,int):
            assert not flags & (512|1024),'No original truncate/append'
            if flags & 64:assert p.exists() and p.name=='script-feature-sources.lock' and p.stat().st_size==0,'Only open an existing original lock inode'
sys.addaudithook(audit)
sys.path[:0]=[str(REPO/'tests/device'),str(REPO/'tests/device/self_tests'),str(REPO/'tests/device/ios/self_tests')]
overlays=plan['privateSourceOverlays']
class Overlay(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        for row in overlays:
            if fullname==row['module']:
                source=REPO/row['path'];assert meta.sha(source)==row['sha256']
                return importlib.util.spec_from_file_location(fullname,source)
sys.meta_path.insert(0,Overlay())
from ios.adapters import chat_draft_runtime,chat_archive_round as a
from ios.adapters import chat_peer_receipts,chat_send_receive
from ios.adapters.chat_receive_sources import IOSChatReceiveSources
from ios.adapters.chat_draft_owner import IOSChatDraftOwner
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.script_runtime import IOSScriptRuntime
from feature_journeys.phase_fixture import Client
for label in a._QML_AUTHORITIES:__import__(label,fromlist=['__name__'])
assert a.original_methods()
paths={};headers={}
for path in corpus.rglob('ios-chat-draft-owner.json'):
    value=json.loads(path.read_text());role={9:'primary',11:'peer'}[value['iosChatDraftOwnerVersion']]
    assert role not in paths;paths[role]=path;headers[role]=value
assert set(paths)=={'primary','peer'}
receive_paths=list(corpus.rglob('ios-chat-receive-sources.json'));assert len(receive_paths)==1
receive_path=receive_paths[0];saved=json.loads(receive_path.read_text())
locks={role:ScriptSourceLock(paths[role].with_name('script-feature-sources.lock')) for role in paths}
possible=list(corpus.rglob('*.ipa'));assert len(possible)==1;artifact=possible[0]
artifacts={role:(artifact,headers[role]['binding']['artifactSha256']) for role in paths}
runtime=object.__new__(chat_draft_runtime.IOSChatDraftRuntime);runtime.adapter=SimpleNamespace(state_path=lambda selector:paths[selector].with_name('session.json'))
client=object.__new__(Client);client.url=headers['primary']['fixtureUrl'].split('/runs/')[0]
import statistics
candidate=HERE/'comparison.py';candidate_pin=meta.pin(candidate);namespace=dict(vars(a));exec(compile(candidate.read_text(),str(candidate),'exec'),namespace)
match=namespace['matching_signature'];current=namespace['matching_original_methods']
# Every actual module/member baseline and the complete current graph agree.
assert current() and a.original_methods()
classes={};module_outcomes=[]
for name,(values,expected) in [*a._BASELINES.items(),*a._DEPENDENCIES.items()]:
    left=a.module_signature(values)==expected;right=match(values,expected,class_cache=classes)
    assert left==right and left,name
    module_outcomes.append(name)
# Local counterexamples exercise every old row kind, current code, inherited
# methods and class aliases. No production parser/data/function is replaced.
class Parent:
    def method(self):return 1
class Child(Parent):pass
def sample():return 1
v=dict(sample=sample,Parent=Parent,Child=Child,Alias=Child,CONST=(1,True,None),a=a,ctx=a._ACTIVE)
expected=a.module_signature(v)
def equal():
    left=a.module_signature(v)==expected;right=match(v,expected,class_cache={});assert left==right;return right
assert equal();outcomes=[]
old=sample.__code__;sample.__code__=(lambda:2).__code__;assert not equal();outcomes.append('same-function-code');sample.__code__=old
Parent.added=lambda self:3;assert not equal();outcomes.append('inherited-method-added');del Parent.added
v['Alias']=Parent;assert not equal();outcomes.append('class-alias');v['Alias']=Child
v['CONST']=(2,True,None);assert not equal();outcomes.append('constant');v['CONST']=(1,True,None)
v['a']=sys;assert not equal();outcomes.append('module-identity');v['a']=a
v['ctx']=a.ContextVar('different');assert not equal();outcomes.append('contextvar-identity');v['ctx']=a._ACTIVE
v['NEW']=3;assert not equal();outcomes.append('new-constant');del v['NEW'];assert equal()
old_times=[];new_times=[]
for _ in range(9):
    start=time.perf_counter();assert a.original_methods();old_times.append(time.perf_counter()-start)
    start=time.perf_counter();assert current();new_times.append(time.perf_counter()-start)
after=meta.sources(plan);assert after==before and originals==meta.originals(corpus) and candidate_pin==meta.pin(candidate)
meta.save(HERE/'report.json',dict(status='PURE_ACTUAL_PARSER_GRAPH_COMPARISON_BENCH_PASS',actualModules=len(module_outcomes),counterexamples=outcomes,literalMedianSeconds=statistics.median(old_times),candidateMedianSeconds=statistics.median(new_times),perAliasCurrentFunctionsAndDataRead=True,classCacheSamePerInvocationAsSource7=True,noProductionReplacement=True,allSourcePinsUnchanged=True,allOriginalsUnchanged=True,noServicesOrSDKOrNode=True,wholeChatQualified=False))
print((HERE/'report.json').read_text())
