"""Named source/AST/hash readback only. No project imports or builder."""
from pathlib import Path
import hashlib,json,ast,difflib,collections
R=Path.cwd();S=R/'.ios-host-tmp/audio-normal14-route-media-current-actor-union-staging2-private-20261104';O=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();F=load(S/'source-freeze.json');assert sha(S/'source-freeze.json')=='e0372e3f4068eefaca0ed354411ea8dacb782b6e3afc0c5836518ddf1a1f45e2'
refs={};bad=[]
def check(p,row):
 p=Path(p);raw=p.read_bytes();digest=row if type(row)is str else row['sha256'];h=hashlib.sha256(raw).hexdigest()
 if h!=digest or type(row)is dict and 'bytes'in row and len(raw)!=row['bytes']:bad.append(str(p))
 refs[str(p)]=dict(bytes=len(raw),sha256=h)
for n,row in F['files'].items():check(S/n,row)
source_refs=load(S/'SOURCE-REFERENCES.json')
for n,row in source_refs.items():check(n,row)
manifest=load(S/'STAGING-MANIFEST.json');candidates=manifest['candidates'];assert len(candidates)==116
layers=collections.Counter();patches=0
for row in candidates:
 n=row['path'];p=S/'candidate'/n;check(p,row);layers[row['layer']]+=1
 original=row.get('sourcePath')
 if original is not None:
  if row['layer'].startswith('exact-'):check(original,row);assert Path(original).read_bytes()==p.read_bytes()
  else:check(original,dict(sha256=row['addonSha256']))
 old=S/'base-current'/n;oldlines=old.read_text().splitlines(True)if old.exists()else[]
 patch=''.join(difflib.unified_diff(oldlines,p.read_text().splitlines(True),fromfile='current/'+n if old.exists()else'/dev/null',tofile='staging2/'+n))
 target=S/'diffs/current-to-staging2'/(n+'.patch');assert target.read_text()==patch,n;patches+=1
prec=load(S/'SOURCE-PRECEDENCE.json');selected={}
for row in prec['effectiveLayers']:
 if row.get('sourcePath'):check(row['sourcePath'],row)
 selected[row['path']]=row
for row in candidates:
 if row['layer'].startswith('exact-'):assert selected[row['path']]['sha256']==row['sha256']
actor=load(S/'CURRENT-ACTOR32-PRESERVATION.json');assert len(actor)==32
for row in actor:
 n=row['path'];assert sha(R/n)==row['actualCurrentSha256']==sha(S/'base-current'/n)
 candidate=S/'candidate'/n;assert row['effectiveStagedSha256']==sha(candidate if candidate.exists()else R/n)
 assert row['preserved']is True
fallback=[r['path']for r in actor if r['unchangedFallback']];assert len(fallback)==27
old=Path(prec['packets']['staging107']['directory']);oldrows=load(old/'STAGING-MANIFEST.json')['rows']
def inventory(p):
 tree=ast.parse(p.read_text(),filename=str(p));out={};counts=collections.Counter()
 def walk(node,parents=()):
  for ch in ast.iter_child_nodes(node):
   if isinstance(ch,(ast.FunctionDef,ast.AsyncFunctionDef)):
    q='.'.join((*parents,ch.name));counts[q]+=1;out[q+'#'+str(counts[q])]=hashlib.sha256(ast.dump(ch,include_attributes=False).encode()).hexdigest();walk(ch,(*parents,ch.name))
   elif isinstance(ch,ast.ClassDef):walk(ch,(*parents,ch.name))
   else:walk(ch,parents)
 walk(tree);return tree,out
changed=[];added=[];oldcount=0;unchanged=0;ast_rows={};test_bodies=0
for row in oldrows:
 n=row['path']
 if not n.endswith('.py'):continue
 _t,originals=inventory(old/'candidate'/n);_u,current=inventory(S/'candidate'/n);oldcount+=len(originals)
 for k,d in originals.items():
  assert k in current,(n,k)
  if current[k]!=d:changed.append(dict(path=n,definition=k,originalAST=d,proposedAST=current[k]))
  else:unchanged+=1
 for k,d in current.items():
  if k not in originals:added.append(dict(path=n,definition=k,ASTSha256=d))
for row in candidates:
 n=row['path']
 if n.endswith('.py'):
  t,inv=inventory(S/'candidate'/n);ast_rows[n]=hashlib.sha256(ast.dump(t,include_attributes=False).encode()).hexdigest()
  if '/self_tests/'in n:test_bodies+=sum(isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))and x.name.startswith('test_')for x in ast.walk(t))
assert oldcount==1203 and unchanged==1201 and len(changed)==2 and len(added)==3,(oldcount,unchanged,changed,added)
expected=load(S/'AST-PRESERVATION.json');assert changed==expected['explicitReviewedRouteMethodEditsOnly']
assert sorted(added,key=lambda x:(x['path'],x['definition']))==sorted(expected['additiveOldPathDefinitions'],key=lambda x:(x['path'],x['definition']))
for row in load(S/'PROSPECTIVE-TEST-SOURCES.json')['methods']:
 _t,inv=inventory(S/'candidate'/row['path']);assert inv[row['class']+'.'+row['method']+'#1']==row['ASTSha256']
assert test_bodies==73
v=dict(subjectFreeze=sha(S/'source-freeze.json'),membersVerified=len(F['files']),declaredReferencesVerified=len(source_refs),allNamedPinsMatch=not bad,failures=bad,candidatesVerified=len(candidates),layerCounts=dict(layers),fullCurrentPatchesExact=patches,ActorCurrent32Preserved=True,ActorFallback27Exact=fallback,parsedPythonCandidates=len(ast_rows),pythonASTs=ast_rows,oldFunctions=oldcount,unchangedFunctions=unchanged,changedFunctions=changed,additiveFunctions=added,all73ProspectiveBodiesMatched=True,execution=False,builders=False,maps=False,censuses=False,targets=False,Git=False,publicWrites=False)
(O/'STATIC-READBACK.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');refs[str(S/'source-freeze.json')]=dict(bytes=(S/'source-freeze.json').stat().st_size,sha256=sha(S/'source-freeze.json'))
(O/'NAMED-SOURCE-REFERENCES.json').write_text(json.dumps(refs,sort_keys=True,indent=2)+'\n')
print(json.dumps({k:v[k]for k in ['membersVerified','declaredReferencesVerified','allNamedPinsMatch','failures','candidatesVerified','layerCounts','fullCurrentPatchesExact','parsedPythonCandidates','oldFunctions','unchangedFunctions','changedFunctions','additiveFunctions','all73ProspectiveBodiesMatched']}))
