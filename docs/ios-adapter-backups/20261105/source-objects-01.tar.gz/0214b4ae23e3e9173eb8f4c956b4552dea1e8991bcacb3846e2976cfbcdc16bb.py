"""Exact one-model runner over frozen private sources; Root execution only."""
from pathlib import Path
import faulthandler,hashlib,importlib,importlib.abc,importlib.machinery,importlib.util,json,os,signal,stat,sys,tempfile,threading,time,traceback,types,unittest
from metadata import HERE,REPO,SOURCE,load,save,validate,proc,processes,fds,census,sha
from metadata_reader import pin as source_pin
from closed_import_origins import ClosedOrigins
assert sys.flags.no_site==1,'Exact -S controlled bootstrap required'
assert len(sys.argv)==2
validation_started=time.monotonic();plan=validate();pre_validation_seconds=time.monotonic()-validation_started;kind=sys.argv[1];assert kind in plan['selection'];selected=plan['selection'][kind]
from scoped_ports import FixturePorts
from typed_observer import TypedIntentObserver,NodeConstructorObserver
from owned_write_boundary import OwnedWrites
assert Path.cwd()==SOURCE and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
runroot=Path(os.environ['OVERTE_ASSETS_ISOLATED_RUN_ROOT']).resolve(strict=True)
assert runroot.parent==HERE/'runs'/kind and runroot.name.startswith('first-')
temporary=runroot/'temporary';assert Path(os.environ['TMPDIR'])==temporary and Path(tempfile.gettempdir())==temporary
for directory in (runroot,temporary):
    value=directory.lstat();assert stat.S_ISDIR(value.st_mode) and value.st_uid==os.geteuid() and stat.S_IMODE(value.st_mode)==0o700
assert not any(temporary.iterdir())
started=time.monotonic();self_binding=proc(os.getpid());assert self_binding is not None
launch=json.loads((runroot/'supervisor-launch-binding.json').read_text());parent=proc(launch['task']['pid'])
assert launch['selectedId']==selected['id'] and parent is not None and parent['startTicks']==launch['task']['startTicks']
assert self_binding['parentPid']==parent['pid'] and self_binding['session']==parent['pid'] and self_binding['processGroup']==parent['pid'],'Only the exact fixed-cap supervisor may launch this child'
save(runroot/'runner-process-binding.json',self_binding)
stack=(runroot/'signal-original-stacks.log').open('x');faulthandler.enable(file=stack)
def terminate(signum,frame):
    # Capture the real pre-cleanup stack; no locals/configuration are retained.
    faulthandler.dump_traceback(file=stack,all_threads=True);stack.flush()
    save(runroot/'signal-precleanup-census.json',dict(processes=processes(self_binding['session']),fds=fds(os.getpid()),threads=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate()]))
    signal.signal(signum,signal.SIG_DFL);os.kill(os.getpid(),signum)
signal.signal(signal.SIGTERM,terminate)
threads_before=set(threading.enumerate());fds_before=fds(os.getpid());base_processes={(p['pid'],p['startTicks']) for p in processes(self_binding['session'])}
def owned():return [p for p in processes(self_binding['session']) if (p['pid'],p['startTicks']) not in base_processes]
def new_threads():return [dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
node_pin=load('host-executable-pins.json')['node']
node_environment_digest=hashlib.sha256(json.dumps(dict(os.environ),sort_keys=True,separators=(',',':')).encode()).hexdigest()
source_map=load('absolute-import-origin-map.json');origins=source_map['modules'];roots=source_map['orderedRoots']
# Runtime source/alias custody is qualified C10c, not an unrestricted
# PathFinder fallback. All source pins exist before any project import.
closure=load('closed-source-inputs.json');source_pins=closure['physicalPins']
assert {path:source_pin(path)for path in source_pins}==source_pins
assert closure['modules']==origins
source_custody=ClosedOrigins(closure,HERE,REPO,source_pin)
source_origins_before=source_custody.snapshot('assets-reserved-before-runtime-imports')
stdlib=Path(os.__file__).resolve(strict=True).parent
sys.path[:]=roots+[x for x in sys.path if x and not Path(x).resolve().is_relative_to(REPO)
    and Path(x).resolve().is_relative_to(stdlib)and'site-packages'not in x and'dist-packages'not in x]
namespace_paths={name:rows[0]for name,rows in closure['namespacePackages'].items()}
assert all(len(rows)==1 for rows in closure['namespacePackages'].values())
project_tops={name.split('.',1)[0]for name in(*origins,*namespace_paths,*closure['thirdPartyModules'])}
actual_imports={};temp_aliases=[];retained=[];retained_objects=[];retention_helper=None
real_td,real_mkdtemp=tempfile.TemporaryDirectory,tempfile.mkdtemp
site_rows=load('static-tempfile-alias-sites.json');temp_sites={x['module']:x for x in site_rows};temp_site_paths={x['path'] for x in site_rows}

def roots_guard():
    for row in retained:
        path=Path(row['root']);info=path.lstat()
        assert path.resolve()==path and path.is_relative_to(temporary) and (info.st_dev,info.st_ino)==(row['device'],row['inode'])
        assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
def record_root(path,producer):
    path=Path(path);info=path.lstat()
    assert path.resolve()==path and path.is_relative_to(temporary) and stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
    retained.append(dict(root=str(path),producer=producer,device=info.st_dev,inode=info.st_ino))
    save(runroot/('retained-root-'+format(len(retained),'06d')+'.json'),retained[-1]);return path
def retained_directory(*args,**kwargs):
    directory=real_td(*args,**kwargs)
    assert retention_helper is not None
    retention_helper(directory,expected_root=Path(directory.name));retained_objects.append(directory)
    record_root(directory.name,'actualTemporaryDirectory');return directory
def retained_mkdtemp(*args,**kwargs):return str(record_root(real_mkdtemp(*args,**kwargs),'actualMkdtemp'))
def install_fixture_aliases(module):
    name=module.__name__
    if name=='ios.self_tests.retained_host_roots':return
    path=Path(module.__file__).resolve()
    fixture=path.is_relative_to(SOURCE/'tests/device/ios/self_tests') or path.is_relative_to(SOURCE/'tests/device/self_tests')
    if not fixture:return
    for key,value in tuple(vars(module).items()):
        replacement=None
        if value is tempfile:
            assert str(path.relative_to(SOURCE)) in temp_site_paths,(name,key,'Unreviewed actual fixture tempfile alias')
            replacement=types.SimpleNamespace(**vars(tempfile));replacement.TemporaryDirectory=retained_directory;replacement.mkdtemp=retained_mkdtemp
        elif value is real_td:
            assert str(path.relative_to(SOURCE)) in temp_site_paths,(name,key,'Unreviewed actual direct TemporaryDirectory alias');replacement=retained_directory
        elif value is real_mkdtemp:
            assert str(path.relative_to(SOURCE)) in temp_site_paths,(name,key,'Unreviewed actual direct mkdtemp alias');replacement=retained_mkdtemp
        if replacement is not None:
            temp_aliases.append((module,key,value));setattr(module,key,replacement)
class CheckedLoader(importlib.abc.Loader):
    def __init__(self,delegate,fullname,path):self.delegate,self.fullname,self.path=delegate,fullname,path
    def __getattr__(self,name):return getattr(self.delegate,name)
    def create_module(self,spec):return self.delegate.create_module(spec) if hasattr(self.delegate,'create_module') else None
    def exec_module(self,module):
        row=origins[self.fullname];assert source_pin(self.path)==source_pins[str(self.path)]
        self.delegate.exec_module(module)
        assert Path(module.__file__).resolve()==self.path and source_pin(self.path)==source_pins[str(self.path)]
        actual_imports[self.fullname]=dict(path=str(self.path),sha256=row['sha256']);install_fixture_aliases(module)
class CheckedFinder(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname in origins:
            row=origins[fullname];source=Path(row['path'])
            assert source.resolve(strict=True)==source and source_pin(source)==source_pins[str(source)]
            assert source.is_relative_to(SOURCE)or fullname=='assets_current_original_process_observer'and source==HERE/'monitoring_observer.py'
            spec=source_custody.file_spec(fullname,dict(row,loader='source'),'project')
            spec.loader=CheckedLoader(spec.loader,fullname,source);return spec
        if fullname in namespace_paths:
            values=closure['namespacePackages'][fullname];source_custody.namespaces(fullname,values,values,'project')
            spec=importlib.machinery.ModuleSpec(fullname,loader=None,is_package=True)
            spec.submodule_search_locations=values;return spec
        if fullname in closure['thirdPartyModules']:return source_custody.remaining_spec(fullname,path)
        if fullname.split('.',1)[0]in project_tops:raise RuntimeError('Unmapped isolated project import before loader')
        return source_custody.remaining_spec(fullname,path)
# Audit SDK source/module access and process/socket boundaries BEFORE imports.
forbidden=('pymobiledevice3','tidevice','pyidevice','zeroconf','overte-ios-remotexpc','appium','selenium','playwright','PySide6','PyQt6')
fixture_ports=None;port_restoration=None;typed_observer=None
refusals=[];execution_audit=[];binds=[];server_records=[];allowed_ports=set();setup_observation_seconds=[];metadata_hash_reads=[]
source_hash_paths={str(SOURCE/name) for name in load('isolated-source-origins.json')}
hash_code,hash_guard_code=sha.__code__,validate.__code__
def own_frozen_hash_comparison(path):
    if not isinstance(path,(str,bytes,os.PathLike)) or os.fsdecode(path) not in source_hash_paths:return False
    frame=sys._getframe(1);hash_seen=False;guard_seen=False
    for _ in range(16):
        if frame is None:break
        if frame.f_code is hash_code and str(frame.f_locals.get('path'))==os.fsdecode(path):hash_seen=True
        if frame.f_code is hash_guard_code:guard_seen=True
        frame=frame.f_back
    if hash_seen and guard_seen:
        metadata_hash_reads.append(dict(path=os.fsdecode(path),operation='exact-own-frozen-source-sha256-comparison'));return True
    return False
def forbidden_path(path):
    if not isinstance(path,(str,bytes,os.PathLike)):return False
    return any(any(part==bad or part.startswith(bad+'_') for bad in forbidden) for part in Path(os.fsdecode(path)).parts)
metadata_pin_function=source_pin;metadata_pin_code=source_pin.__code__;metadata_pin_globals=source_pin.__globals__
readonly_function=OwnedWrites.os_open;readonly_code=readonly_function.__code__;readonly_globals=readonly_function.__globals__
reader_function=ClosedOrigins.execute_python_source;reader_code=reader_function.__code__;reader_globals=reader_function.__globals__
owned_metadata_paths=set(closure['ownForbiddenMetadataReadPaths'])
own_definition=SOURCE/'tests/device/ios/adapters/appium_adapter.py'
def exact_own_source_read(path):
    if type(path)not in(str,bytes)and not isinstance(path,os.PathLike):return False
    actual=Path(os.fsdecode(path));frame=sys._getframe(1)
    # Exact immediate caller only, never search for a convenient ancestor.
    if (frame.f_code is not audit_code or frame.f_globals is not audit_globals
            or audit_function is not audit or audit_function.__code__ is not audit_code):return False
    caller=frame.f_back
    if caller is None:return False
    pin_caller=caller
    if caller.f_code is readonly_code and caller.f_globals is readonly_globals:
        if fixture_ports is None or not fixture_ports.installed:return False
        fixture_ports.check();helper=caller.f_locals.get('self');port=fixture_ports.ports['open'];middle=caller.f_back
        if (OwnedWrites.os_open is not readonly_function or readonly_function.__code__ is not readonly_code
                or not any(helper is row for row in fixture_ports.helpers.values())or caller.f_locals.get('path')!=actual
                or caller.f_locals.get('dir_fd')is not None or middle is None or middle.f_code is not port.__code__
                or middle.f_globals is not port.__globals__ or middle.f_locals.get('self')is not fixture_ports or middle.f_locals.get('_name')!='open'
                or middle.f_locals.get('args')!=(actual,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
                or middle.f_locals.get('kwargs')!={}):return False
        pin_caller=middle.f_back
    if str(actual)in owned_metadata_paths and actual.is_absolute()and actual.resolve(strict=True)==actual:
        if (pin_caller is not None and pin_caller.f_code is metadata_pin_code and pin_caller.f_globals is metadata_pin_globals and source_pin is metadata_pin_function
                and source_pin.__code__ is metadata_pin_code and pin_caller.f_locals.get('path')==actual):return True
    if actual==own_definition and caller.f_code is reader_code and caller.f_globals is reader_globals:
        delegate=caller.f_locals.get('delegate')
        return (ClosedOrigins.execute_python_source is reader_function and reader_function.__code__ is reader_code
            and caller.f_locals.get('self')is source_custody and getattr(delegate,'guard',None)is source_custody
            and getattr(delegate,'name',None)=='ios.adapters.appium_adapter'and getattr(delegate,'kind',None)=='project'
            and Path(delegate.row['path'])==own_definition and source_custody.plan['physicalPins'].get(str(actual))==source_pins[str(actual)])
    return False
def own_definition_module(name,module):
    return (name=='ios.adapters.appium_adapter'and type(module)is types.ModuleType and sys.modules.get(name)is module
        and vars(module).get('__file__')==str(own_definition)and origins[name]['path']==str(own_definition))
def sdk_modules():
    return [name for name,module in tuple(sys.modules.items()) if any(part in forbidden for part in name.split('.'))
        or forbidden_path(getattr(module,'__file__',None))and not own_definition_module(name,module)]
assert not sdk_modules()
assert not any(name.split('.')[0] in ('ios','adapters','feature_journeys','fixture','self_tests') for name in sys.modules),'Target loaded before isolated preflight'
def audit(event,args):
    # Mirror the unchanged FixturePorts predicate BEFORE capturing a frame.
    # Ignored import/introspection/shutdown events have no write authority here.
    if fixture_ports is not None and (event in('open','os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.utime','os.truncate',
            'os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')):
        fixture_ports.audit(event,args,sys._getframe(1))
    if event=='import':
        name=args[0]
        if name.split('.',1)[0]in project_tops and name not in origins and name not in namespace_paths and name not in closure['thirdPartyModules']:
            raise RuntimeError('Unknown project import before side effects')
        if any(part in forbidden for part in name.split('.')) or forbidden_path(args[1]):refusals.append(dict(event=event,module=name));raise RuntimeError('SDK import refused')
    elif event=='open' and forbidden_path(args[0]):
        if not own_frozen_hash_comparison(args[0])and not(args[1]is None and args[2]==os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC and exact_own_source_read(args[0])):
            refusals.append(dict(event='SDK-source-open'));raise RuntimeError('SDK source read refused')
    elif event=='subprocess.Popen':
        executable,arguments,cwd,environment=args
        assert type(arguments) in (tuple,list) and list(arguments)==plan['expectedPickerNodeArgv'],'Only the exact one original QML Node argv is admitted'
        assert os.fsdecode(executable)=='node'and cwd is None and environment is None
        fixture_ports.node_environment_guard()
        assert (Path(os.environ['PATH'])/'node').resolve(strict=True)==Path(node_pin['realPath'])
        execution_audit.append(dict(kind='actual-assets-picker-usage-node',argv=list(arguments)))
    elif event=='socket.bind':
        sock,address=args
        assert type(address) is tuple and address==('127.0.0.1',0) and len(binds)<2,'Only two owned loopback fixture listeners admitted'
        binds.append(sock)
    elif event=='socket.connect':
        sock,address=args
        assert type(address) is tuple and address[0]=='127.0.0.1' and address[1] in allowed_ports,'Connection outside the two actual fixture ports refused'
    elif event=='socket.getaddrinfo':
        assert args[0] in ('127.0.0.1','localhost') and args[1] in allowed_ports,'DNS outside actual owned loopback fixtures refused'
    elif event in ('socket.gethostbyname','socket.gethostbyaddr'):
        assert args[0] in ('127.0.0.1','localhost'),'External DNS refused'
    elif event=='socket.sendto':raise RuntimeError('Unselected datagram send refused')
    elif event in ('os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','ctypes.dlopen')or event.startswith('os.spawn'):raise RuntimeError('Unselected native/SDK execution refused')
audit_function=audit;audit_code=audit.__code__;audit_globals=audit.__globals__
sys.addaudithook(audit)
# Exact private original observer; no global profile fallback.
finder=CheckedFinder();sys.meta_path.insert(0,finder)
monitor=importlib.import_module('assets_current_original_process_observer');observer=monitor.OriginalProcessObserver(proc).start()
fixture_ports=FixturePorts(temporary,runroot,save,globals(),sys._getframe(),plan['expectedPickerNodeArgv'],node_pin,node_environment_digest)
fixture_ports.bind_callbacks((terminate,record_root))
fixture_ports.install()
node_observer=NodeConstructorObserver(fixture_ports).start()
from ios.self_tests.retained_host_roots import retain_owned_root
retention_helper=retain_owned_root
selected_module=selected['id'].rsplit('.',2)[0]
module=importlib.import_module(selected_module)
case_class=getattr(module,selected['id'].rsplit('.',2)[1])
fixture_class=importlib.import_module('ios.self_tests.assets_whole_observation_fixture').Fixture
original_fixture_init=fixture_class.__init__
def measured_fixture_init(fixture,test):
    original_fixture_init(fixture,test);observation_started=time.monotonic()
    assert len(observer.processes)==1
    actual_node=observer.processes[0]['process'];actual_image=Path('/proc',str(actual_node.pid),'exe').resolve(strict=True)
    assert str(actual_image)==node_pin['realPath']and sha(actual_image)==node_pin['sha256']
    actual_info=actual_image.stat();assert (actual_info.st_dev,actual_info.st_ino)==(node_pin['device'],node_pin['inode'])
    # Read the same original servers after their genuine fixture constructor,
    # regardless of whether the selected TestCase uses setUp or its test body.
    for label,source in (('settings',fixture.write.h),('control',fixture.write)):
        server,thread=source.server,source.thread;address=server.socket.getsockname();fd=server.socket.fileno()
        assert address[0]=='127.0.0.1' and type(address[1]) is int and address[1]>0 and server.socket in binds and thread.is_alive()
        fixture_ports.add_server(server,thread,source.path)
        allowed_ports.add(address[1]);server_records.append(dict(label=label,server=server,thread=thread,birth=dict(host=address[0],port=address[1],fd=fd,socketInode=os.readlink('/proc/self/fd/'+str(fd)),threadName=thread.name,threadIdent=thread.ident,threadNativeId=thread.native_id,ownerPid=os.getpid())))
    assert len(binds)==len(server_records)==len(allowed_ports)==2
    save(runroot/'actual-loopback-server-births.json',[row['birth']|{'label':row['label']} for row in server_records]);setup_observation_seconds.append(time.monotonic()-observation_started)
fixture_class.__init__=measured_fixture_init
case_receipt=None;result=None
class ImmediateResult(unittest.TextTestResult):
    def record_exception(self,test,error,event):
        body=''.join(traceback.format_exception(*error));path=runroot/('original-exception-'+str(len(list(runroot.glob('original-exception-*.json')))+1)+'.json')
        save(path,dict(testId=test.id(),event=event,traceback=body));self.stream.write(body);self.stream.flush()
    def addError(self,test,error):super().addError(test,error);self.record_exception(test,error,'ERROR')
    def addFailure(self,test,error):super().addFailure(test,error);self.record_exception(test,error,'FAILURE')
    def addSubTest(self,test,subtest,error):
        super().addSubTest(test,subtest,error)
        if error is not None:self.record_exception(subtest,error,'SUBTEST_FAILURE')
    def stopTest(self,test):
        global case_receipt
        rows=[]
        for value in server_records:
            rows.append(dict(label=value['label'],birth=value['birth'],threadAlive=value['thread'].is_alive(),socketClosed=value['server'].socket.fileno()==-1))
        case_receipt=dict(testId=test.id(),originalCleanupsReturned=True,servers=rows,remainingNewThreads=new_threads(),remainingOwnedChildren=owned(),fdBaselineUnchanged=fds(os.getpid())==fds_before)
        save(runroot/'case-stop-receipt.json',case_receipt);super().stopTest(test)
from ios.adapters.assets_picker_originals import IntentTransitions,IntentCodePolicy,OriginalPageLeasePicker
fixture_ports.bind_callbacks((measured_fixture_init,ImmediateResult.record_exception,ImmediateResult.stopTest))
typed_observer=TypedIntentObserver(IntentTransitions,IntentCodePolicy,OriginalPageLeasePicker,temporary).start()
try:
    loader=unittest.TestLoader();_module_name,class_name,method_name=selected['id'].rsplit('.',2)
    assert _module_name==selected_module and module.__name__==selected_module
    suite=loader.loadTestsFromName(class_name+'.'+method_name,module)
    assert not loader.errors and suite.countTestCases()==1
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for item in value:yield from flatten(item)
        else:yield value
    actual=[x.id() for x in flatten(suite)];assert actual==[selected['id']]
    save(runroot/'selected-ids-actual.json',actual)
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=ImmediateResult).run(suite)
finally:
    fixture_class.__init__=original_fixture_init
    for target,key,value in reversed(temp_aliases):setattr(target,key,value)
    assert tempfile.TemporaryDirectory is real_td and tempfile.mkdtemp is real_mkdtemp
    assert all(getattr(target,key) is value for target,key,value in temp_aliases)
    process_rows=[]
    for item in observer.processes:
        child=item['process'];streams={k:None if getattr(child,k) is None else getattr(child,k).closed for k in ('stdin','stdout','stderr')}
        process_rows.append(dict(pid=item['pid'],birth=item['birth'],current=proc(item['pid']),commandKind=item['commandKind'],constructorOutcome=item['constructorOutcome'],returnCode=child.poll(),streams=streams))
    typed_observer.stop();typed_receipt=typed_observer.report()
    node_observer.stop()
    port_restoration=fixture_ports.restore()
    known_popen={id(row['process'])for row in observer.processes}
    actual_pipe_owners=node_observer.entries==1 and node_observer.tool is None and len(fixture_ports.node_entries)==1 and len(fixture_ports.pipe_opens)==1 and all(id(owner)in known_popen for owner,_fd,_dev,_ino in fixture_ports.pipe_opens)
    observer.stop();monitoring=observer.metadata()
    source_origins_after=source_custody.snapshot('assets-reserved-after-standard-cleanups');sys.meta_path.remove(finder)
    roots_guard();remaining_first=owned();threads_first=new_threads();fd_first=fds(os.getpid());first=census(temporary)
    second=census(temporary);remaining_second=owned();threads_second=new_threads();fd_second=fds(os.getpid());roots_guard()
    guard_failure=None
    try:validate()
    except Exception as error:
        guard_failure=type(error).__name__;save(runroot/'post-source-guard-failure.json',dict(exceptionType=guard_failure,traceback=traceback.format_exc()))
    save(runroot/'actual-imported-source-origins.json',actual_imports)
    save(runroot/'actual-all-loaded-origins-before.json',source_origins_before);save(runroot/'actual-all-loaded-origins-after.json',source_origins_after)
    save(runroot/'actual-fixture-tempfile-aliases.json',[dict(module=m.__name__,binding=k) for m,k,_ in temp_aliases])
    save(runroot/'actual-observed-original-processes.json',dict(processes=process_rows,monitoring=monitoring,executionAudit=execution_audit))
    save(runroot/'selected-originals-first.json',first);save(runroot/'selected-originals-second.json',second)
    clean_processes=len(process_rows)==1 and all(row['commandKind']=='node' and row['constructorOutcome']=='return' and row['returnCode'] is not None and (row['current'] is None or row['birth'] is not None and row['current']['startTicks']!=row['birth']['startTicks']) and all(x is None or x for x in row['streams'].values()) for row in process_rows)
    clean_servers=case_receipt is not None and len(case_receipt['servers'])==2 and all(not row['threadAlive'] and row['socketClosed'] for row in case_receipt['servers'])
    actual_source_closed=all(source_pin(path)==row for path,row in source_pins.items())and bool(source_origins_after)
    clean=actual_source_closed and guard_failure is None and typed_receipt['actualTypedPathReached'] and typed_receipt['ownToolFreed'] and port_restoration['originalPortsRestored'] and actual_pipe_owners and len(retained)==4 and result is not None and result.testsRun==1 and not result.skipped and result.wasSuccessful() and clean_processes and clean_servers and not refusals and not sdk_modules() and not remaining_first and not remaining_second and not threads_first and not threads_second and fd_first==fd_second==fds_before and first==second and case_receipt['fdBaselineUnchanged']
    save(runroot/'selected-result.json',dict(selectedId=selected['id'],testsRun=None if result is None else result.testsRun,successful=clean,testAssertionsSuccessful=result is not None and result.wasSuccessful(),seconds=time.monotonic()-started,preImportPrivateValidationSeconds=pre_validation_seconds,setupObservationSeconds=setup_observation_seconds,monitoringCallbackOverheadSeparatelyMeasured=False,monitoringOverheadIncludedInFixedCap=True,reservedFixtureScope=True,normalAction2Qualified=False,typedPathCoverage=typed_receipt,originalWritePorts=port_restoration,actualPipeOwnersObserved=actual_pipe_owners,originalCensusesEqual=first==second,remainingOwnedBeforeCensuses=remaining_first,remainingOwnedAfterCensuses=remaining_second,remainingNewThreadsBeforeCensuses=threads_first,remainingNewThreadsAfterCensuses=threads_second,fdBaselineUnchanged=fd_first==fd_second==fds_before,fdBefore=fds_before,fdAfter=fd_second,originalProcessCustodyClean=clean_processes,actualLoopbackClean=clean_servers,originalProcessMonitoring=monitoring,retainedOriginalRoots=retained,sourceOriginsVerified=actual_source_closed,closedSourceExecutionHelperSha256=sha(HERE/'closed_import_origins.py'),initialHostBootstrapScopeExplicit=True,fixtureAliasesRestored=True,sdkAttempts=refusals,metadataOnlyOwnFrozenSourceHashReads=metadata_hash_reads,postSourceGuardFailure=guard_failure,wholeAssetsQualified=False,publicObservationReady=False,nativeCompiled=False,sdkExecuted=False,deviceQualified=False))
    print('ACTUAL_SINGLE_CASE_RESULT',kind,'PASS' if clean else 'FAIL',flush=True)
raise SystemExit(0 if clean else 1)
