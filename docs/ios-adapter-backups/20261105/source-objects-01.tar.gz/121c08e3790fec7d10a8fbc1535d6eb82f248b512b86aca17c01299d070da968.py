"""One connected original Audio14 + evidence/restoration handoff; declared lower native/SDK/audio producers."""
from pathlib import Path
from metadata_reader import pin
from closed_import_origins import ClosedOrigins
from host_common import head
from audio_admission import require
from audio_resources import AudioResources
from locks import Locks
import builtins,hashlib,importlib.abc,importlib.util,io,json,os,signal,stat,sys,tempfile,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert sys.flags.no_site==1, 'Explicit no-site startup required'
assert len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert plan['status']=='PRIVATE_AUDIO_ORIGINAL_HANDOFF_FIRST1_UNRUN'
assert plan['cases']==json.loads((HERE/'exact-one-selector.json').read_text())
assert plan['NodeExecutions']==plan['SDKExecutions']==plan['overteNativeQueries']==plan['oldCorpusInputs']==0 and plan['globalOriginalScans']==3
assert plan['realNetwork']is False
require(plan['rootAdmission'],pin)
assert plan['subjectHelperSha256']=='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
assert Path(plan['subjectActualCopiedPath'])==HERE/'closed_import_origins.py'
assert pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
assert head()==plan['actualPublicHead']
assert len(plan['cases'])==len(set(plan['cases']))==1 and plan['wallSeconds']==180 and plan['killGraceSeconds']==5
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def fds():
    out={}
    for path in Path('/proc/self/fd').iterdir():
        try:v=path.stat();out[path.name]=dict(target=os.readlink(path),device=v.st_dev,inode=v.st_ino,mode=v.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return out
def children():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
def census(root):
    out={}
    for path in(root,*sorted(root.rglob('*'))):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):row=dict(stat=[getattr(info,k)for k in FIELDS],namespace=sorted(p.name for p in path.iterdir()))
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        out[str(path.relative_to(root))]=row
    return out
assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
original_path=tuple(sys.path);original_meta=tuple(sys.meta_path);loaded={};td_callers=[]
resources=AudioResources(HERE/'temporary');locks=Locks(HERE/'temporary')
bootstrap_names={'metadata_reader','host_common','closed_import_origins','audio_admission','kernel_admission','audio_resources','locks'}
for name in(*plan['modules'],*plan['thirdPartyModules']):
    if name in bootstrap_names:
        actual=sys.modules[name]
        assert Path(vars(actual)['__file__'])==Path(plan['modules'][name]['path'])
        assert pin(Path(vars(actual)['__file__']))==plan['sourceAndBinaryPins'][vars(actual)['__file__']]
    else:assert name not in sys.modules
sys.path[:]=[p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespaces'],*plan['thirdPartyModules'])}
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright')
origin_plan=plan['originPlan']
assert origin_plan['physicalPins']==plan['sourceAndBinaryPins']and origin_plan['modules']==plan['modules']
origins=ClosedOrigins(origin_plan,HERE,REPO,pin)
origin_before=origins.snapshot('before-utility-project-imports')
class AfterActualLoader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name,self.delegate=name,delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module)
        path=Path(vars(module)['__file__']);loaded[self.name]=str(path)
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
        resources.loaded(self.name,module);locks.loaded(self.name,module)
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in forbidden:raise ImportError('Product SDK/browser package refused')
        row=plan['modules'].get(name)
        if row is not None:
            spec=origins.file_spec(name,dict(row,loader='source'),'project')
            spec.loader=AfterActualLoader(name,spec.loader);return spec
        if name in origin_plan['namespacePackages']:
            roots=origin_plan['namespacePackages'][name];origins.namespaces(name,roots,roots,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots;return spec
        if name in origin_plan['thirdPartyModules']or name in origin_plan['thirdPartyNamespacePackages']:return origins.remaining_spec(name,path)
        if name.split('.')[0]in tops:raise ImportError('Unmapped project/third-party import: '+name)
        return origins.remaining_spec(name,path)
finder=Finder();sys.meta_path.insert(0,finder)
TOYS=HERE/'temporary';RECEIPTS=HERE/'child-receipts'
assert TOYS.is_dir()and RECEIPTS.is_dir()and not any(TOYS.iterdir())and not any(RECEIPTS.iterdir())
assert os.environ['TMPDIR']==str(TOYS)and Path(tempfile.gettempdir())==TOYS
from owned_write_boundary import OwnedWrites
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={n:getattr(os,n)for n in ports if hasattr(os,n)};original_io=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
original_cleanup=unittest.TestCase.doCleanups;original_td=tempfile.TemporaryDirectory;original_time=time.time
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):
    path=Path(os.readlink('/proc/self/fd/'+str(fd)));assert path.resolve(strict=True)==path and path.is_relative_to(HERE);protected.append(path)
boundary=OwnedWrites(HERE,protected=protected)
closed=False;tail_births={};tail_used=set()
def tail_write(path,value):
    assert closed and path in tail_births and path not in tail_used
    assert all(getattr(os,name)is original for name,original in original_ports.items())
    assert original_io==(io.open,builtins.open)and original_dup==(os.dup,os.dup2)
    assert pin(path)==tail_births[path]
    with original_io[0](path,'w',encoding='utf-8')as stream:
        json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    tail_used.add(path)
tail_function=tail_write;tail_code=tail_write.__code__;tail_globals=tail_write.__globals__
def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Product SDK/browser import refused')
    if event.startswith('socket.')and event!='socket.gethostname':raise RuntimeError('No real Audio socket, HTTP, UDP or DNS source')
    if event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('No real Audio process/SDK/Node/native/signal port')
    if event=='fcntl.flock':return locks.check(args,sys._getframe(1))
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if not relevant:return
    if closed:
        if event=='open':
            value,mode,flags=args
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
            if not writing:return
            caller=sys._getframe(1);path=Path(value)if type(value)in(str,bytes)else None
            assert path in tail_births and path not in tail_used
            assert mode=='w'and flags==(os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC)
            assert caller.f_code is tail_code and caller.f_globals is tail_globals and caller.f_locals.get('path')==path
            assert tail_function is tail_write and tail_function.__code__ is tail_code and tail_function.__globals__ is tail_globals
            assert pin(path)==tail_births[path]
            assert all(getattr(os,name)is original for name,original in original_ports.items())and original_io==(io.open,builtins.open)
            return
        raise RuntimeError('Mutation after actual original port restoration')
    boundary.audit(event,args,sys._getframe(1))
boundary.install();sys.addaudithook(audit)
retained=[];retained_objects=[];cleanup_calls=[]
from ios.self_tests.retained_host_roots import retain_owned_root
retain_original=retain_owned_root;retain_code=retain_original.__code__;retain_globals=retain_original.__globals__
class RetainedTemporaryDirectory(original_td):
    def __init__(self,*args,**kwargs):
        frame=sys._getframe(1);role=resources.td_role(frame,args,kwargs)
        assert retain_original.__code__ is retain_code and retain_original.__globals__ is retain_globals
        super().__init__(dir=TOYS,**kwargs)
        root=Path(self.name);assert root.parent==TOYS and root.resolve(strict=True)==root
        retain_original(self,expected_root=root);resources.remember(role,root);retained_objects.append(self);retained.append(str(root))
def observe_original_cleanup(case):
    before=len(case._cleanups);outcome=case._outcome
    success_before=None if outcome is None else outcome.success
    result_before=None if outcome is None else outcome.result
    errors_before=[]if result_before is None else list(result_before.errors)
    failures_before=[]if result_before is None else list(result_before.failures)
    returned=None;raised=None
    try:
        returned=original_cleanup(case)
        return returned
    except BaseException as error:
        raised=type(error).__module__+'.'+type(error).__qualname__
        raise
    finally:
        after_outcome=case._outcome
        after_result=None if after_outcome is None else after_outcome.result
        same_result=after_result is result_before
        new_errors=[]if not same_result or after_result is None else after_result.errors[len(errors_before):]
        new_failures=[]if not same_result or after_result is None else after_result.failures[len(failures_before):]
        cleanup_calls.append(dict(case=type(case).__module__+'.'+type(case).__qualname__,pendingBefore=before,
            remaining=len(case._cleanups),originalReturned=returned,originalRaised=raised,
            outcomeSuccessBefore=success_before,outcomeSuccessAfter=None if after_outcome is None else after_outcome.success,
            actualResultReceiverSame=same_result,
            newCallbackErrors=[dict(id=test.id(),traceback=text)for test,text in new_errors],
            newCallbackFailures=[dict(id=test.id(),traceback=text)for test,text in new_failures],
            callbackErrorDeltaEstablished=same_result and after_result is not None,
            failedReturnRemainsFailed=returned is not True))
unittest.TestCase.doCleanups=observe_original_cleanup;tempfile.TemporaryDirectory=RetainedTemporaryDirectory

def save(name,body):
    p=RECEIPTS/name
    with p.open('x')as stream:stream.write(json.dumps(body,indent=2,sort_keys=True)+'\n')
    p.chmod(0o600)
fd_before=fds();threads_before=tuple(threading.enumerate());children_before=children()
case_receipts=[];selected=[];result=None;fatal=None;cleanup_rows=[];cleanup_ok=True
class Result(unittest.TextTestResult):
    def startTest(self,test):
        assert original_methods_unchanged()and tools_unchanged()
        origins.snapshot('before-standard-case-'+test.id())
        self.before=(fds(),tuple(threading.enumerate()),children(),len(cleanup_calls),len(retained));super().startTest(test)
    def stopTest(self,test):
        fd,threads,kernel,cleanup_count,roots=self.before
        origins.snapshot('after-standard-case-'+test.id())
        row=dict(id=test.id(),standardStopAfterCleanup=True,originalMethodsUnchanged=original_methods_unchanged(),monitorSlotsUnchanged=tools_unchanged(),remainingStandardCleanups=len(test._cleanups),
            fdUnchanged=fds()==fd,threadsUnchanged=tuple(threading.enumerate())==threads,kernelChildrenUnchanged=children()==kernel,
            actualNestedCleanupCalls=deepcopy_rows(cleanup_calls[cleanup_count:]),newTemporaryDirectories=len(retained)-roots)
        case_receipts.append(row);save('standard-case-'+str(len(case_receipts))+'.json',row);super().stopTest(test)
def deepcopy_rows(rows):return json.loads(json.dumps(rows))
method_seals=[]
def bind_original_methods():
    declarations=(
        ('closed_import_origins','ClosedOrigins',()),('closed_import_origins','PinnedDelegate',()),
        ('audio_resources','AudioResources',()),('locks','Locks',()),
        ('ios.adapters.audio_original_evidence_handoff','IOSAudioOriginalEvidenceHandoff',()),
        ('ios.adapters.audio_whole_feature','IOSAudioWholeFeature',()),
        ('ios.self_tests.audio_whole_fixture','AudioWholeFixture',()),
        ('ios.self_tests.test_ios_audio_whole','AudioWholeTests',()),
        ('ios.self_tests.audio_once_journey_fixture','OnceJourneyFixture',()),
        ('ios.self_tests.test_ios_installed_adapter','InstalledAdapterTests',()),
        ('ios.self_tests.test_ios_script_runtime','IOSScriptRuntimeTests',()),
        ('ios.self_tests.test_ios_audio_original_evidence_handoff','AudioOriginalEvidenceHandoffTests',()))
    for module_name,class_name,names in declarations:
        module=sys.modules[module_name];cls=vars(module)[class_name]
        path=Path(vars(module)['__file__']);assert str(path)in plan['sourceAndBinaryPins']and pin(path)==plan['sourceAndBinaryPins'][str(path)]
        # Pin the full actual class-method table, including static control/
        # selector helpers transitively called by the explicit recipe methods.
        for name,member in cls.__dict__.items():
            function=member.__func__ if type(member)in(classmethod,staticmethod)else member
            if not hasattr(function,'__code__'):continue
            chain=[];seen=set()
            while function is not None:
                assert id(function)not in seen;seen.add(id(function))
                code=function.__code__;namespace=function.__globals__;owner_name=namespace['__name__'];owner=sys.modules[owner_name]
                assert namespace is vars(owner)
                physical=Path(code.co_filename)
                if not physical.is_absolute():
                    actual_spec=vars(owner)['__spec__']
                    assert actual_spec.origin=='frozen'and actual_spec.loader is importlib.machinery.FrozenImporter and code.co_filename=='<frozen '+owner_name+'>'
                    physical=Path(vars(owner)['__file__'])
                assert str(physical)in plan['sourceAndBinaryPins']and pin(physical)==plan['sourceAndBinaryPins'][str(physical)]
                next_function=getattr(function,'__wrapped__',None);defaults=function.__defaults__;keywords=function.__kwdefaults__;closure=function.__closure__
                chain.append((function,code,namespace,owner_name,owner,next_function,defaults,tuple(defaults or()),keywords,tuple((keywords or{}).items()),closure,tuple(cell.cell_contents for cell in closure or())))
                function=next_function
            method_seals.append((module,module_name,cls,class_name,name,member,chain))
def original_methods_unchanged():
    for module,module_name,cls,class_name,name,member,chain in method_seals:
        assert sys.modules.get(module_name)is module and vars(module)[class_name]is cls and cls.__dict__[name]is member
        for function,code,namespace,owner_name,owner,next_function,defaults,values,keywords,items,closure,cells in chain:
            assert function.__code__ is code and function.__globals__ is namespace and sys.modules.get(owner_name)is owner and namespace is vars(owner)
            assert getattr(function,'__wrapped__',None)is next_function and function.__defaults__ is defaults and function.__kwdefaults__ is keywords and function.__closure__ is closure
            assert len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values))
            assert tuple(keywords or())==tuple(key for key,value in items)and all(keywords[key]is value for key,value in items)
            assert len(closure or())==len(cells)and all(cell.cell_contents is value for cell,value in zip(closure or(),cells))
    return True
monitor=sys.monitoring
monitor_ports=tuple((name,getattr(monitor,name))for name in('get_tool','get_events','get_local_events','set_local_events','register_callback','use_tool_id','free_tool_id'))
monitor_before=tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6))
def tools_unchanged():
    return (all(getattr(monitor,name)is port for name,port in monitor_ports)
        and monitor_before==tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6)))

original_term=signal.getsignal(signal.SIGTERM)
def interrupted(*_args):raise KeyboardInterrupt('Fixed180-second original Audio FIRST1 boundary')
signal.signal(signal.SIGTERM,interrupted)
try:
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(suite):
        if isinstance(suite,unittest.TestSuite):
            for item in suite:yield from flatten(item)
        else:yield suite
    selected=list(flatten(suite));ids=[case.id()for case in selected]
    save('actual-selection.json',dict(ids=ids,loaderErrors=loader.errors));assert not loader.errors and ids==plan['cases']and suite.countTestCases()==1
    bind_original_methods();assert original_methods_unchanged()and tools_unchanged()
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    try:
        for case in selected:
            pending=len(case._cleanups);old=case._outcome;drain=unittest.TestResult();success=True
            try:
                if pending:case._outcome=unittest.case._Outcome(drain);success=observe_original_cleanup(case)
            except BaseException:success=False;print(traceback.format_exc(),flush=True)
            finally:case._outcome=old
            row=dict(id=case.id(),pendingBeforeOuter=pending,remaining=len(case._cleanups),success=success,
                errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],failures=[dict(id=t.id(),traceback=text)for t,text in drain.failures]);cleanup_rows.append(row)
            if not success or case._cleanups or drain.errors or drain.failures:cleanup_ok=False
        for row in retained:
            root=Path(row);info=root.lstat();assert root.parent==TOYS and root.resolve(strict=True)==root
        nested_ok=all(row['originalReturned']is True and row['remaining']==0 for row in cleanup_calls)
        first=census(TOYS);second=census(TOYS)
        after={p:pin(p)for p in plan['sourceAndBinaryPins']}
        assert head()==plan['actualPublicHead']and pin(INPUT)['sha256']==sys.argv[2]
        origin_after=origins.snapshot('after-genuine-original-cleanups')
        passed=fatal is None and result is not None and result.testsRun==1 and result.wasSuccessful()and not result.skipped and cleanup_ok and nested_ok
        passed=passed and len(retained)==4 and len(case_receipts)==1 and len(cleanup_calls)==3 and all(row['remainingStandardCleanups']==0 and row['fdUnchanged']and row['threadsUnchanged']and row['kernelChildrenUnchanged']and row['newTemporaryDirectories']==4 and row['originalMethodsUnchanged']and row['monitorSlotsUnchanged']for row in case_receipts)
        passed=passed and after==plan['sourceAndBinaryPins']and fd_before==fds()and threads_before==tuple(threading.enumerate())and children_before==children()and first==second
        source_origins={}
        for name,expected in plan['subjectOriginModules'].items():
            module=sys.modules.get(name);actual=None if module is None else getattr(module,'__file__',None)
            source_origins[name]=dict(actualModulePresent=module is not None,actualModuleFile=actual,
                actualLoaderExecutedPath=loaded.get(name),expectedPath=expected['path'],expectedSha256=expected['sha256'],
                exactOriginMatched=actual==loaded.get(name)==expected['path'])
        origins_ok=len(source_origins)==plan['subjectOriginCount']==10 and all(row['exactOriginMatched']for row in source_origins.values())
        passed=passed and origins_ok and not td_callers and original_methods_unchanged()and tools_unchanged()
        save('actual-all-loaded-origins-before.json',origin_before);save('actual-all-loaded-origins-after.json',origin_after)
        save('actual-source-model-origins.json',dict(subjectOrigins=source_origins,
            allTenActualRuntimeOriginsEstablished=origins_ok,actualExecutedOrigins=loaded))
        save('actual-audio-resources.json',resources.finish());save('actual-audio-locks.json',locks.finish());save('actual-toy-first.json',first);save('actual-toy-second.json',second);save('outer-cleanup.json',dict(success=cleanup_ok,cases=cleanup_rows,nestedActualCalls=cleanup_calls,nestedActualCleanupSucceeded=nested_ok))
        save('report.json',dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=None if result is None else result.testsRun,
            actualCaseReceipts=len(case_receipts),fatal=fatal,cleanupEstablished=cleanup_ok and nested_ok,
            retainedTemporaryDirectories=retained,temporaryDirectoryAbsenceClaimed=False,fdUnchanged=fd_before==fds(),
            threadsUnchanged=threads_before==tuple(threading.enumerate()),kernelChildrenUnchanged=children_before==children(),
            pinsUnchanged=after==plan['sourceAndBinaryPins'],twoToyCensusesEqual=first==second,allActualLoadedOriginsAccounted=True,originSnapshots=origins.snapshot_count,
            overteNativeQueries=0,actualStdlibInterpreterExtensionsAllowed=True,realNetwork=False,NodeExecutions=0,SDKExecutions=0,PythonExecutions=0,nativeQualified=False,wholeQualified=False))
    finally:
        signal.signal(signal.SIGTERM,original_term)
        tempfile.TemporaryDirectory=original_td;unittest.TestCase.doCleanups=original_cleanup
        monitor_restored=tools_unchanged()
        tools_restored=tempfile.TemporaryDirectory is original_td and unittest.TestCase.doCleanups is original_cleanup and time.time is original_time and monitor_restored
        tail=RECEIPTS/'actual-port-restoration.json'
        descriptor=os.open(tail,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        try:assert stat.S_IMODE(os.fstat(descriptor).st_mode)==0o600
        finally:os.close(descriptor)
        tail_births[tail]=pin(tail)
        boundary.restore()
        restored=all(getattr(os,n)is v for n,v in original_ports.items())and original_io==(io.open,builtins.open)
        dup_restored=original_dup==(os.dup,os.dup2)
        boundary.close();closed=True
        sys.meta_path[:]=original_meta;sys.path[:]=original_path
        tail_write(RECEIPTS/'actual-port-restoration.json',dict(restored=restored,count=len(original_ports),
            controlDescriptors=sorted(boundary.control_fds),dupPortsRestored=dup_restored,toolsRestored=tools_restored,
            builtinsCioRestored=original_io==(io.open,builtins.open),actualC10cHelperSha256=pin(Path(__file__).with_name('closed_import_origins.py'))['sha256']))
raise SystemExit(0 if passed and restored and tools_restored and dup_restored else 1)
