"""Prospective actual owned AFC model receivers/descriptors, no End DTO."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,tempfile,unittest
from pathlib import Path
from audio_original_current_producer import RawAudioCurrentProducer

class AudioRawAFCCustodyTests(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        root=Path(temporary.name);root.chmod(0o700);self.model=RawAudioCurrentProducer(root/'raw')
        self.model.produce(dict(action='feature-native-observe',commandId='ios-'+'a'*32))
    def test_actual_reader_finishes_and_exact_original_close_clears_only_its_own_file_socket_and_slots(self):
        async def scenario():
            model=self.model;kind=model.service_type();one,two=kind(object()),kind(object())
            try:
                for service in (one,two):
                    await service.send_command(model.bundle_id,'VendContainer');self.assertIs(service,await service.__aenter__())
                first=await one.fopen('/Documents/owned-results/feature-native-observation.json','r')
                other=await two.fopen('/Documents/owned-results/feature-native-observation.json','r')
                fd=model.handles[other].fileno();receiver=one._afc_reader_task
                self.assertFalse(receiver.done());self.assertIsNotNone(one._service)
                await one.aclose();self.assertTrue(receiver.done());self.assertIsNone(one._afc_reader_task);self.assertIsNone(one._service)
                self.assertEqual({},one._afc_pending);self.assertEqual([-1,-1],[s.fileno()for s in one.sockets])
                self.assertNotIn(first,model.handles);self.assertEqual(fd,model.handles[other].fileno());self.assertFalse(two.closed)
                await one.aclose();await two.aclose();self.assertEqual({},model.handles)
            finally:
                await one.aclose();await two.aclose()
        asyncio.run(scenario())
    def test_reader_is_not_born_before_actual_vend_and_failed_entry_can_close_its_exact_owned_socketpair(self):
        async def scenario():
            service=self.model.service_type()(object())
            self.assertIsNone(service._afc_reader_task)
            try:
                with self.assertRaises(AssertionError):await service.__aenter__()
                self.assertIsNone(service._afc_reader_task)
            finally:await service.aclose()
            self.assertIsNone(service._service);self.assertEqual([-1,-1],[s.fileno()for s in service.sockets])
        asyncio.run(scenario())
