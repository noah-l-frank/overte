"""Two fresh fixed-cap original SDK host groups inside one old-corpus window.

No helper, original case, recipe, timeout or supervisor is changed. Stop on
the first original failure; independently retain absence and all output rooms.
"""
from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys,traceback

R=Path.cwd().resolve(strict=True);B=R/'.ios-host-tmp';S=Path(__file__).resolve().parent
SOURCE=B/'avatar-lifecycle-sdk-eight-genuine-constructor-bootstrap3-real-filefinder-sdk-delegate-precedence-code-preparation-20261105'
SOURCE_SHA='593189fbc7247fd19a19835af85677d97a177730f08174d2ca12f34baca897f7'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def identity(pid):
    try:raw=Path('/proc',str(pid),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    f=raw[raw.rfind(')')+2:].split()
    return dict(pid=int(pid),parent=int(f[1]),group=int(f[2]),session=int(f[3]),startTicks=int(f[19]))
def main():
    assert sys.flags.no_site and sys.dont_write_bytecode and len(sys.argv)==4
    assert sha(S/'source-freeze.json')==sys.argv[1]
    cp=Path(sys.argv[2]);assert cp.parent.parent==B and sha(cp)==sys.argv[3];cfg=load(cp)
    assert cfg['status']=='ROOT_REVIEWED_SDK8_TWO_FRESH_FIXED_GROUPS_UNRUN'
    assert cfg['scriptSha256']==sha(Path(__file__))and cfg['sourceFreeze']==sys.argv[1]
    assert sha(SOURCE/'source-freeze.json')==SOURCE_SHA
    for n,row in load(SOURCE/'source-freeze.json')['files'].items():assert sha(SOURCE/n)==row['sha256']
    context=Path(cfg['context']);assert sha(context)==cfg['contextSha256'];ctx=load(context)
    assert ctx['allTargetsTerminal']is True and ctx['expectedHead']==cfg['expectedHead']
    for row in ctx['globalCustody'].values():assert sha(row['path'])==row['sha256']
    expected=load(ctx['globalCustody']['baseline']['path']);assert len(expected)==cfg['oldRootCount']
    helper=Path(ctx['globalCustody']['helper']['path']);assert sha(helper)=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
    advance=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py'
    assert sha(advance)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be'
    census=runpy.run_path(str(advance))['census'];current=runpy.run_path(str(helper))['current']
    recipes=load(SOURCE/'fixed-eight-groups.json')['groups'];groups=cfg['groups']
    assert len(groups)==2 and [r['group']for r in groups]==sorted(recipes)
    plans=[]
    for row in groups:
        ip=Path(row['input']);h=ip.parent;recipe=recipes[row['group']]
        assert h.parent==B and h.name.startswith('sdk-original-'+row['group']+'-prepared-')and ip.name=='approved-inputs.json'
        assert sha(ip)==row['inputSha256'];p=load(ip)
        assert p['controllerRoot']==str(h)and p['repositoryRoot']==str(R)and p['actualPublicHead']==cfg['expectedHead']
        assert p['status']=='PRIVATE_ORIGINAL_SDK8_GROUP_UNRUN'and p['sourceFreeze']==SOURCE_SHA
        assert p['groupName']==row['group']and p['cases']==recipe['caseIds']and p['resourceRecipe']==recipe
        assert p['wallSeconds']==30 and p['killGraceSeconds']==5 and len(p['cases'])in(2,6)
        assert p['subjectHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
        assert p['authenticatedSourceAdmission']is p['providerAdmission']is p['consumerAdmission']is None
        assert p['hostSDKPythonExecutionExpected']is True and p['SDKInstalled']is False
        assert p['deviceActionsRequested']==p['remoteProtocolActionsRequested']==p['caseChildProcesses']==p['caseTDs']==p['oldApplicationCorpusInputs']==p['globalOriginalScans']==0
        for f in h.glob('*.py'):
            origin=SOURCE/f.name if(SOURCE/f.name).exists()else Path(next(z['originalSource']for z in p['testModules'].values()if z['path']==str(f)))
            assert sha(f)==sha(origin)
        assert set(p['currentSourceExecution']['requiredOriginalRoots'])<=set(expected)
        assert not any(z.exists()for z in(h/'own-toys',h.with_name(h.name+'-outer'),h.with_name(h.name+'-censuses')))
        plans.append((row,h))
    assert len({str(h)for row,h in plans})==2
    out=Path(cfg['output']);assert out.parent==B and not out.exists();out.mkdir(mode=0o700)
    def put(n,v):
        with(out/n).open('x')as stream:json.dump(v,stream,sort_keys=True,separators=(',',':'));stream.write('\n')
        (out/n).chmod(0o600)
    before=current();assert before==expected;put('global-before.json',before)
    put('configuration-reference.json',dict(path=str(cp),sha256=sys.argv[3]))
    completed=[];rooms=[]
    for row,h in plans:
        group=row['group'];o=h.with_name(h.name+'-outer');c=h.with_name(h.name+'-censuses')
        put('attempt-'+group+'.json',row);print('ROOT_SDK8_HOST_START '+group,flush=True)
        with(out/(group+'-stdout.log')).open('xb')as stdout,(out/(group+'-stderr.log')).open('xb')as stderr:
            result=subprocess.run([sys.executable,'-S','-B',str(h/'supervise-one.py'),row['inputSha256']],cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
        put('actual-return-'+group+'.json',dict(supervisorReturnCode=result.returncode))
        try:
            drain=load(o/'actual-process-drain.json')
            originals=drain['owned']+drain['firstDiscoveries'];assert originals
            for original in originals:
                actual=identity(original['pid']);assert actual is None or actual['startTicks']!=original['startTicks']
            owned_groups={r['group']for r in originals};same=[]
            for proc in Path('/proc').iterdir():
                if proc.name.isdecimal():
                    actual=identity(int(proc.name))
                    if actual is not None and(actual['group']in owned_groups or actual['session']in owned_groups):same.append(actual)
            assert same==[]
            put('actual-root-absence-'+group+'.json',dict(recordedOriginals=originals,remainingSameGroupOrSession=same,observationGrantsNoSignalAuthority=True,originalDrain=drain))
        except BaseException:
            put('unqualified-partial-'+group+'.json',dict(originalTraceback=traceback.format_exc(),supervisorReturnCode=result.returncode,quietClosureInferred=False));raise
        terminal=load(o/'terminal.json')if(o/'terminal.json').exists()else None
        qualification=load(c/'qualification.json')if(c/'qualification.json').exists()else None
        actual_rooms=[p for p in(h,h/'own-toys',o,c)if p.exists()]
        assert all(p.is_dir()and not p.is_symlink()for p in actual_rooms);rooms+=actual_rooms
        passed=result.returncode==0 and terminal is not None and qualification is not None and terminal['status']==qualification['status']=='PASS'
        if passed:
            assert terminal['ownProcessesAbsent']is qualification['ownProcessesAbsent']is True
            assert qualification['originalRoots']==list(map(str,[h,o,c]))and qualification['noCensusExclusions']is True
        completed.append(dict(group=group,input=row['input'],inputSha256=row['inputSha256'],supervisorReturnCode=result.returncode,originalTerminal=terminal,originalQualification=qualification,rootObservedAbsence=True,passed=passed,originalRooms=list(map(str,actual_rooms))))
        put('completed-'+group+'.json',completed[-1]);print('ROOT_SDK8_HOST_CLOSED '+group+' '+('PASS'if passed else'FAIL'),flush=True)
        if not passed:break
    first={str(p):census(p)for p in rooms};second={str(p):census(p)for p in rooms};assert first==second
    put('whole-first.json',first);put('whole-second.json',second)
    after1=current();after2=current();assert after1==after2==expected
    put('global-after-first.json',after1);put('global-after-second.json',after2)
    passed=len(completed)==2 and all(r['passed']for r in completed)
    put('terminal.json',dict(status='ROOT_SDK8_EIGHT_ORIGINAL_HOST_CONSTRUCTORS_PASS'if passed else'ROOT_SDK8_STOPPED_ON_ORIGINAL_FAILURE',completedGroups=completed,unrunGroups=[r['group']for r,h in plans[len(completed):]],oldRootCount=len(expected),allOldOriginalBodiesUnchanged=True,allRecordedOriginalProcessesAndGroupsAbsent=True,wholeOwnRoomsTwiceEqual=True,newOriginalRoots=list(map(str,rooms+[out])),nativeQualified=False,featureQualified=False,wholeQualified=False))
    put('freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}))
    print(json.dumps(dict(status='PASS'if passed else'FAIL',freeze=sha(out/'freeze.json'),groups=len(completed))),flush=True)
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
