"""Actual source review+C10c proof; kernel admission remains intentionally shut."""
from pathlib import Path
import json
from kernel_admission import require as require_kernel
C10C='63f5ffc563996ad7793a600cb6a16c53d8df05a54d65db24321a1a2b5c020fc4'
HELPER='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
QUALIFIED='8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a'
AUDIO='d7d36f194177cb5c854e14efb28b78d5fb77a89cc4f02638ab9802843bca7c63'
REVIEW='d4c52e1b735b7bad3aadc45fdc103e19a66cc54f71d30b4a870833c5a7a247f0'

def read_ref(row,pin):
    assert type(row)is dict and set(row)=={'path','sha256'}
    path=Path(row['path']);assert path.is_absolute()and path.resolve(strict=True)==path
    assert pin(path)['sha256']==row['sha256'];return json.loads(path.read_text())
def packet(row,pin):
    value=read_ref(row,pin);root=Path(row['path']).parent
    for name,entry in value['files'].items():
        assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
        assert pin(root/name)['sha256']==(entry if type(entry)is str else entry['sha256'])
    return value

def require(value,pin):
    require_kernel(value['kernelOwn5Proof'],pin)
    assert value['status']=='ROOT_REVIEWED_AUDIO_ORIGINAL_HANDOFF_FIRST1_PENDING_ACTUAL_KERNEL_PROOF'
    assert value['audioSourceFreeze']==AUDIO
    row=value['audioSemanticReviewFreeze'];assert row['sha256']==REVIEW;review=packet(row,pin)
    body=read_ref(dict(path=str(Path(row['path']).parent/'STATIC-READBACK.json'),sha256=review['files']['STATIC-READBACK.json']['sha256']),pin)
    assert body['originalWholeFeatureMethodsASTIdentical']==28 and body['retainedPrivateOrigins']==86 and body['declaredDependencies']==113
    assert body['onlyAdditiveMethod']=='original_evidence_handoff'and body['status']=='SOURCE_ONLY_NO_IMPORTS_NO_TARGETS_NO_MAPS_NO_CENSUSES'
    ref=value['c10cQualifiedRootFreeze'];assert ref['sha256']==QUALIFIED
    root=packet(ref,pin);name='results.json';path=Path(ref['path']).parent/name
    actual=read_ref(dict(path=str(path),sha256=root['files'][name]['sha256']),pin)
    assert actual['status']=='ACTUAL_C10C_FRESH_SOURCE_CACHE_MUTATION_COMPILER_STDLIB_ALIAS_COUNTER6_AND_ALL_UTILITY_GATES_PASS'
    assert actual['subjectSourceFreeze']==C10C and actual['subjectHelperSha256']==HELPER
    assert actual['actualPassedCases']==actual['actualStartedCases']==6 and actual['actualFailedCases']==actual['actualUnrunCases']==0
    for key in('sourceExecutionCounterQualified','cachePoisonTimestampAndUncheckedRefusalQualified','actualSourceMutationRefusalQualified',
        'actualCompileExecRebindRefusalQualified','actualGenericStdlibExecutionRowEqualityQualified','actualGenuineFourExpatNamesAndForeignReceiverRefusalQualified',
        'all27OsCioDupToolsRestored','all725FrozenSourceBinaryPinsUnchanged','actualInputAndCliShaUnchanged','parentFDThreadAndKernelDrain','twoWholeOwnCensusesEqual'):
        assert actual[key]is True
    assert actual['actualOriginalStandardCleanupCalls']==actual['actualGenuineTemporaryDirectories']==6
    assert actual['actualCallbackErrors']==actual['NodeExecutions']==actual['SDKExecutions']==actual['overteNativeQueries']==0
    assert actual['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
    assert actual['realNetwork']is False and actual['qualificationScope'].startswith('Actual runtime delegated Python source bytes')
    return True
