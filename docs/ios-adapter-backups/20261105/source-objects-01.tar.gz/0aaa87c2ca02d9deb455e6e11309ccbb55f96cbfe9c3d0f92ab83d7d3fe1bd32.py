"""Two exact readonly historical paths; original single-path port unchanged."""
from pathlib import Path
from types import FrameType
import os
import sys
from original_lock_port import OriginalLockPort

class OriginalTwoLocks:
    def __init__(self, root, operands, original_open):
        self.ports = [OriginalLockPort(root / operands[key],
            operands['pins'][operands[key]], original_open)
            for key in ('actorLock', 'primaryLock')]
        assert self.ports[0].path != self.ports[1].path
    def attach(self, boundary):
        # One router keeps sys._getframe(1) the actual held() caller.
        # Chaining two wrappers would insert a controller frame between the
        # second port and held(); never relax the original frame check.
        original_boundary_open = boundary.ports['open']
        original_open = boundary.original['open']
        manager = self
        assert all(port.original_open is original_open for port in self.ports)
        def open_port(path, flags, mode=0o777, *, dir_fd=None):
            writing = flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)
            candidates = [port for port in manager.ports if writing
                and isinstance(path, (str, bytes, os.PathLike))
                and Path(os.fsdecode(path)) == port.path]
            assert len(candidates) <= 1
            if candidates:
                port = candidates[0]
                boundary._check()
                assert original_open is boundary.original['open'] and port.original_open is original_open
                assert dir_fd is None and mode == 0o600
                assert flags == (os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK)
                frame = sys._getframe(1)
                owner = port.held(frame)
                assert owner._owner is None and port.opening is None
                port.opening = (frame, owner)
                try:
                    descriptor = original_open(path, flags, mode)
                    port.check_inode(port.fstat(descriptor))
                    port.check_inode(port.lstat(port.path))
                    port.opens.append(dict(descriptor=descriptor, receiver=id(owner)))
                    return descriptor
                finally:
                    port.opening = None
            return original_boundary_open(path, flags, mode, dir_fd=dir_fd)
        boundary.ports['open'] = open_port
        boundary.port_implementations.append((open_port, open_port, open_port.__code__,
            tuple(cell.cell_contents for cell in open_port.__closure__ or ())))
        boundary._seal_function(open_port)
        for port in self.ports:
            port.open_port = open_port
        os.open = open_port
        boundary._check()
    def bind(self, module, fcntl):
        for port in self.ports:
            port.bind(module, fcntl)
    def audit(self, event, args, caller):
        if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
            selected = [port for port in self.ports
                if Path(os.fsdecode(args[0])) == port.path]
        elif event == 'fcntl.flock':
            assert type(caller) is FrameType
            owner = caller.f_locals.get('self')
            selected = [port for port in self.ports
                if port.ports is not None and type(owner) is port.ports[1]
                and owner.path == port.path]
        else:
            return False
        assert len(selected) <= 1
        return bool(selected) and selected[0].audit(event, args, caller)
    @property
    def opens(self):
        return [dict(path=str(port.path), **row) for port in self.ports for row in port.opens]
    @property
    def flocks(self):
        return [dict(path=str(port.path), **row) for port in self.ports for row in port.flocks]
    def released(self):
        results = [port.released() for port in self.ports]
        return len(results) == 2 and all(results)
