"""Actual C10d6+8 prerequisite; no feature/Actor or FullPrefix authority."""
from c10d_qualification import SUBJECT_SHA as SUBJECT,HELPER_SHA as HELPER,ROOT_SHA as QUALIFIED,require_current

def qualify(plan,pin):
    proof=plan['qualifiedSourceExecution']
    assert proof['subjectSourceFreeze']==SUBJECT and proof['helperSha256']==HELPER
    current,physical=require_current(proof['rootFreeze']['path'],proof['rootFreeze']['sha256'],pin)
    assert current['subjectSourceFreeze']==SUBJECT and current['helperSha256']==HELPER
    assert current['consumerCompositionsQualified']is False and current['wholeQualified']is False
    return current,physical
