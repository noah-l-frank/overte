"""Literal actual diagnostic14 proof; never Assets/World phase qualification.

Only explicitly named saved files are read. No corpus walk, process query,
clock, live SUT import, observer startup or successful phase verdict exists here.
"""
from pathlib import Path
import json

ROOT_NAME='root-c24-pass14-world-fail1-original-qualified-results-20261104'
ROOT_SHA='61d95b4674f37f3f8cf1afadc4682598b64c41be8143820416419811cac770f6'
RESULT_SHA='218e1e2cf6deb644597874e8e4a23258941e6a3c57ccae9dbf559115f55f6f36'
REFS_SHA='e0ef3cbbb964efe006b4fd78c6958a8b9e45a1ad17920295468374446715bf9f'
SUBJECT_NAME='assets-c24-policy-value-bounded-diagnostic-source4-genuine-held-callback-counter-private-20261104'
SUBJECT_SHA='3241ab6ed8592c3dc4930b2fa26d801ec0f7242317b4182fffbc7acd8aad4c5a'
BOOTSTRAP_NAME='c24-diagnostic-source4-closed-utility14-bootstrap3-held-callback-counter-code-preparation-20261104'
BOOTSTRAP_SHA='8c9d18dbba780150332b035d37cb5d94192c7dbb245f8def3a18f75f358acb99'
HELPER_SHA='56ea39998c071b7162a53a7c0d7253dcc7799ffde3034a1d56c660dfb658eeac'
RUNNER_SHA='6ae12a819226d93b6b0f74fc4e83c26a210768103b8396912f0cfe0f09a8b24a'
SOURCE_HELPER_SHA='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
CLASS_SHA='d0dfe3d94f47bf5bf1e491dc59c232623483931f7b051df4a5e52d097cf49046'


def require_diagnostic_qualification(repo,pin,consumer):
    repo=Path(repo);consumer=Path(consumer)
    assert consumer==Path(__file__).resolve(strict=True).parent
    assert consumer.parent==repo/'.ios-host-tmp'and repo.resolve(strict=True)==repo
    physical={}
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        value=pin(path)
        if digest is not None:assert value['sha256']==digest
        previous=physical.setdefault(str(path),value);assert previous==value
        return path
    def load(path,digest=None):
        path=keep(path,digest);value=json.loads(path.read_text());assert pin(path)==physical[str(path)]
        return value
    def packet(folder,leaf,digest):
        value=load(folder/leaf,digest)
        rows=value['files'];entries=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
        for name,row in entries:
            assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
            keep(folder/name,row if type(row)is str else row['sha256'])
        return value
    root=repo/'.ios-host-tmp'/ROOT_NAME
    frozen=packet(root,'freeze.json',ROOT_SHA)
    assert frozen['files']=={'actual-receipt-references.json':{'sha256':REFS_SHA},'results.json':{'sha256':RESULT_SHA}}
    body=load(root/'results.json',RESULT_SHA)
    # This genuine Root result has no schemaVersion field. Do not invent one.
    assert 'schemaVersion'not in body
    assert body['status']=='ROOT_C24_DIAGNOSTIC14_PASS_WORLD_ORIGINAL_FIRST_CASE_ERROR_RETAINED'
    assert body['all929OldOriginalBodiesUnchanged']is body['wholeNewOutputsTwiceEqual']is True
    assert body['globalCensuses']==3
    assert body['terminal']==dict(childReturnCode=1,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
    assert body['featureQualified']is body['nativeQualified']is body['wholeQualified']is False
    references=load(root/'actual-receipt-references.json',REFS_SHA);assert len(references)==120
    for path,row in references.items():
        assert set(row)=={'path','sha256'}and path==row['path'];keep(path,row['sha256'])
    assert len(body['groups'])==2
    actual,negative=body['groups']
    assert actual['group']=='assets-diagnostic14-b3'and actual['status']=='PASS_FOURTEEN_REAL_DIAGNOSTIC_CASES_ONLY'
    assert actual['diagnosticUtilityQualified']is True
    assert actual['assetsPhaseQualified']is False and actual['diagnosticAdmission']is None
    assert actual['sourceFreeze']==BOOTSTRAP_SHA
    assert negative['group']=='world-timing8-b2'and negative['status']=='ORIGINAL_FIRST_CASE_LOCAL_EVENT_VALUEERROR'
    assert negative['worldTimingUtilityQualified']is False and negative['worldConsumerAdmission']is None
    assert negative['originalMonitorSlotRestorationFalsePreserved']is True
    assert negative['originalReport']['status']=='FAIL_OR_ERROR'and negative['originalReport']['testsRun']==1
    assert negative['originalTerminal']['status']=='FAIL_OR_REFUSED'and negative['originalTerminal']['childReturnCode']==1
    assert negative['originalPortRestoration']['toolsRestored']is False
    assert negative['originalQualification']['status']=='FAIL_OR_REFUSED'and negative['originalQualification']['priorTerminalPassed']is False
    subject=repo/'.ios-host-tmp'/SUBJECT_NAME
    packet(subject,'source-freeze.json',SUBJECT_SHA)
    packet(repo/'.ios-host-tmp'/BOOTSTRAP_NAME,'source-freeze.json',BOOTSTRAP_SHA)
    keep(subject/'intent_graph_diagnostic.py',HELPER_SHA);keep(subject/'candidate-run-one.py',RUNNER_SHA)
    keep(consumer/'intent_graph_diagnostic.py',HELPER_SHA);keep(consumer/'run-one.py',RUNNER_SHA)
    selectors=load(subject/'prospective-fourteen-utility-selectors.json')
    assert type(selectors)is list and len(selectors)==len(set(selectors))==14
    room=Path(actual['input']).parent
    assert room==repo/'.ios-host-tmp/c24-diagnostic-utility14-prepared-root929-headcb793-b3-20261104'
    approved=load(actual['input'],actual['inputSha256'])
    assert approved['sourceFreeze']==BOOTSTRAP_SHA
    assert approved['subjectSourceFreeze']==approved['utilitySubjectSourceFreeze']==SUBJECT_SHA
    assert approved['status']=='PRIVATE_C24_DIAGNOSTIC_SOURCE4_UTILITY14_UNRUN'
    assert approved['cases']==selectors and approved['wallSeconds']==30 and approved['killGraceSeconds']==5
    assert len(approved['sourceAndBinaryPins'])==900 and approved['expectedClassCleanupGroups']==3
    assert approved['subjectHelperSha256']==SOURCE_HELPER_SHA
    assert approved['expectedTemporaryDirectories']==0 and approved['maximumLiveUtilityChildren']==0
    assert approved['diagnosticAdmission']is approved['utilityQualification']is None
    selection=load(room/'child-receipts/actual-selection.json')
    assert selection==dict(ids=selectors,loaderErrors=[])
    report=load(room/'child-receipts/report.json');assert report==actual['originalReport']
    assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==14 and report['fatal']is None
    assert report['retainedTemporaryDirectories']==[]
    for name in('cleanupEstablished','fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','twoToyCensusesEqual','allActualLoadedOriginsAccounted'):
        assert report[name]is True
    assert report['NodeExecutions']==report['PythonExecutions']==report['SDKExecutions']==report['overteNativeQueries']==0 and report['realNetwork']is False
    cleanups=load(room/'child-receipts/outer-cleanup.json')
    assert cleanups['success']is cleanups['nestedActualCleanupSucceeded']is True
    assert len(cleanups['cases'])==len(cleanups['nestedActualCalls'])==14
    assert [row['id']for row in cleanups['cases']]==selectors
    for row in cleanups['nestedActualCalls']:
        assert row['originalReturned']is True and row['originalRaised']is None and row['remaining']==0
        assert row['newCallbackErrors']==row['newCallbackFailures']==[]
    origins=load(room/'child-receipts/actual-source-model-origins.json')
    assert origins['allThreeActualRuntimeOriginsEstablished']is True
    expected={'intent_graph_diagnostic':HELPER_SHA,'test_intent_graph_diagnostic':'8b0b4dc26445d6523d7fd97db948a21c342ffebc9ca0eaa466d5201b584af338','class_cleanup_custody':CLASS_SHA}
    assert set(origins['subjectOrigins'])==set(approved['subjectOriginModules'])==set(expected)
    for name,digest in expected.items():
        row=origins['subjectOrigins'][name];path=room/(name+'.py');keep(path,digest)
        assert row['actualModulePresent']is row['exactOriginMatched']is True
        assert row['actualModuleFile']==row['actualLoaderExecutedPath']==row['expectedPath']==origins['actualExecutedOrigins'][name]==str(path)
        assert row['expectedSha256']==approved['subjectOriginModules'][name]['sha256']==digest
        assert approved['subjectOriginModules'][name]['path']==str(path)
    for index,selector in enumerate(selectors,1):
        row=load(room/('child-receipts/standard-case-'+str(index)+'.json'))
        assert row['id']==selector and row['standardStopAfterCleanup']is row['originalMethodsUnchanged']is row['monitorMasksSlotsUnchanged']is row['profileRestored']is True
        assert row['remainingStandardCleanups']==0 and row['fdUnchanged']is row['threadsUnchanged']is row['kernelChildrenUnchanged']is True
    restore=load(room/'child-receipts/actual-port-restoration.json');assert restore==actual['originalPortRestoration']
    assert restore['restored']is restore['dupPortsRestored']is restore['toolsRestored']is restore['builtinsCioRestored']is True
    assert restore['count']==27 and restore['controlDescriptors']==[]and restore['classCleanupRestorationError']is None
    assert restore['actualC10dHelperSha256']==SOURCE_HELPER_SHA
    class_final=load(room/'child-receipts/actual-class-cleanup-restoration.json');assert class_final==actual['originalClassCleanupFinal']
    assert class_final['originalDescriptorRestored']is class_final['originalFunctionCodeGlobalsUnchanged']is True
    summary=class_final['summary'];assert summary['allActualOriginalCallsAccepted']is summary['allSelectedClassesObservedExactlyOnce']is True
    assert summary['expectedSelectedClasses']==summary['actualOriginalClassCleanupCalls']==3 and summary['problems']==[]
    terminal=load(Path(str(room)+'-outer')/'terminal.json');assert terminal==actual['originalTerminal']
    assert terminal['status']=='PASS'and terminal['childReturnCode']==0 and terminal['timedOut']is terminal['forcedKill']is False
    assert terminal['problems']==terminal['orphansRequiredKill']==terminal['fullOwnCensusExclusions']==[]
    for name in('ownProcessesAbsent','twoFullOwnOutputCensusesEqual','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','allSourceBinaryPinsEqual','actualStdlibParentFDThreadDrain','allThreeActualRuntimeOriginsEstablished','actualFourteenCaseReceiptsEstablished','actualClassCleanupCustodyEstablished','zeroCaseChildBirthsEstablished'):
        assert terminal[name]is True
    census_room=Path(str(room)+'-censuses');qualified=load(census_room/'qualification.json');assert qualified==actual['originalQualification']
    assert qualified['status']=='PASS'and qualified['actualUtilityCases']==14
    assert qualified['priorTerminalPassed']is qualified['twoCompleteHEREAndOuterCensusesEqual']is qualified['noCensusExclusions']is qualified['ownProcessesAbsent']is True
    assert qualified['diagnosticAdmission']is None and qualified['assetsPhaseQualified']is qualified['wholeQualified']is False
    rooms=body['newOriginalRoots'];assert len(rooms)==len(set(rooms))==7
    assert rooms[:3]==qualified['originalRoots']==[str(room),str(room)+'-outer',str(census_room)]
    collector=Path(rooms[-1]);assert body['originalCollectorFreeze']=='7cc7674d4463f111852bbfafdace4b81febe7c9b58197e0a6abc9036fc3cb692'
    packet(collector,'freeze.json',body['originalCollectorFreeze'])
    closed=load(collector/'terminal.json')
    assert closed['status']=='ROOT_TWO_CORRECTED_UTILITIES_STOPPED_ON_ORIGINAL_FAILURE'
    assert closed['allExecutedOwnedProcessesAbsent']is closed['allOldOriginalBodiesUnchanged']is closed['wholeOwnOutputsTwiceEqual']is True
    assert closed['globalCensuses']==3 and closed['oldRootCount']==929 and closed['newOriginalRoots']==rooms
    assert closed['groups'][0]['supervisorReturnCode']==0 and closed['groups'][1]['supervisorReturnCode']==1
    assert closed['groups'][0]['originalQualification']==qualified and closed['groups'][1]['originalQualification']==negative['originalQualification']
    for files in ((collector/'global-before.json',collector/'global-after-first.json',collector/'global-after-second.json'),(collector/'whole-output-first.json',collector/'whole-output-second.json'),(census_room/'whole-first.json',census_room/'whole-second.json')):
        assert len({physical[str(path)]['sha256']for path in files})==1
    timeout=repo/'.ios-host-tmp/root-assets-c24-original-five-minute-timeout-negative-results-20261104'
    packet(timeout,'freeze.json','444279530625b676c70121f0fc99c1bf63f7aa9e4dc646e25ecc2c1690ad4b85')
    return dict(rootFreeze=dict(path=str(root/'freeze.json'),sha256=ROOT_SHA),resultSha256=RESULT_SHA,
        source4Freeze=SUBJECT_SHA,bootstrapFreeze=BOOTSTRAP_SHA,diagnosticHelperSha256=HELPER_SHA,
        diagnosticRunnerSha256=RUNNER_SHA,actualCaseIds=selectors,actualReferences=120,
        diagnosticUtilityQualified=True,requiredOriginalRoots=rooms,mixedRootExitCode=1,
        worldCompanionStatus=negative['status'],worldTimingUtilityQualified=False,
        assetsPhaseQualified=False,diagnosticCompositionQualified=False,nativeQualified=False,wholeQualified=False),physical
