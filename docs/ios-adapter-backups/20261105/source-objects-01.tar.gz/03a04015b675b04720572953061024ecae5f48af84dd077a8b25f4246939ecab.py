"""Exact Source10+11 overlays over actual held Actor public32 definitions.

Historical public39/Actor34 proof remains historical. This utility has no
consumer/native/whole PASS until Root executes its exact new composition.
"""
from pathlib import Path
import ast,hashlib,json
from host_common import REPO,head
from historical_public_readiness import readiness as previous_readiness,packet
SOURCE=Path(__file__).resolve().parent
S10=REPO/'.ios-host-tmp/snapshot-actor-before-capture-after-png-temporal-join-source10-private-20261104'
S11=REPO/'.ios-host-tmp/snapshot-paired-png-original-scope-source11-private-20261104'
ROOT_REVIEW=REPO/'.ios-host-tmp/root-snapshot-temporal10-paired11-source-review-20261104'
PEER11=REPO/'.ios-host-tmp/lifecycle-independent-snapshot-paired-png-source11-full-source-review-20261104'


def readiness(pin,copy_manifest,copy_manifest_sha):
    old,physical=previous_readiness(pin,copy_manifest,copy_manifest_sha)
    packet(REPO/'.ios-host-tmp/snapshot-actor25-public73-compatibility-bootstrap1-dirty-parent-source-private-20261104','source-freeze.json','a38cb566c2947f917f2aafa0aa553961000df87b632663fd10e93c69368f370f',pin,physical)
    packet(ROOT_REVIEW,'freeze.json','9c96637f53bc95b08e8a86ceed9f3b0d5f4e8cee5e540e6662c11e759ee67c27',pin,physical)
    packet(PEER11,'freeze.json','d6203d621ebb4e12c4a3263eccbbd3d8ba317e06642b27c115521c7f06038237',pin,physical)
    packet(REPO/'.ios-host-tmp/avatar-independent-snapshot-source10-temporal-png-full-source-review-20261104',
        'freeze.json','d42cc8520bdb03e269d187f9e5e0e5e7895212559e8439c8c8e8f7457a789ad8',pin,physical)
    overlays={}
    for folder,digest in ((S10,'ce0aad33395181606a63812ed968952f9b9a2b6cfca567b52ac377946e6397ae'),
                          (S11,'ed971e6ee5c4d9d3a9d8d9248561501899be20863918e798ff65a505199f0e64')):
        frozen=packet(folder,'source-freeze.json',digest,pin,physical)
        for leaf,row in frozen['files'].items():
            if not leaf.startswith('candidate/')or not leaf.endswith('.py'):continue
            relative=Path(leaf).relative_to('candidate/tests/device')
            name='.'.join(relative.with_suffix('').parts);path=folder/leaf
            assert path.resolve(strict=True)==path and name not in overlays
            actual=pin(path);assert actual['sha256']==(row if type(row)is str else row['sha256'])
            physical[str(path)]=actual;overlays[name]=dict(path=str(path),sha256=actual['sha256'])
    assert len(overlays)==6
    declarations_path=SOURCE/'SUBJECT-DECLARATIONS.json';physical[str(declarations_path)]=pin(declarations_path)
    declared=json.loads(declarations_path.read_text())['subjects']
    public=dict(old['publicSubjectOrigins']);pure=dict(old['privatePureTestOrigins']);origins=dict(old['subjectOrigins'])
    for name,row in overlays.items():
        if name in origins:
            assert name=='ios.adapters.snapshot_actor_pixel_runtime'and name in public
            # Its original public baseline still has to match the actual held
            # Actor copy. The private addition is separately identified.
            baseline=S11/'base/tests/device/ios/adapters/snapshot_actor_pixel_runtime.py'
            actual=pin(baseline);assert actual['sha256']==public[name]['sha256'];physical[str(baseline)]=actual
            del public[name]
        origins[name]=row
    assert len(origins)==51 and len(public)==44 and len(pure)==1
    assert set(origins)==set(public)|set(pure)|set(overlays)==set(declared)
    for name,row in declared.items():
        assert dict(path=row['path'],sha256=row['sha256'])==origins[name]
        if name in overlays:assert row['category']=='explicit-private-subject-overlay'
        elif name in public:assert row['category']=='current-public-definition'
        else:assert row['category']=='explicit-private-pure-test-only'
    recipe_path=SOURCE/'SOURCE-RECIPE.json';physical[str(recipe_path)]=pin(recipe_path)
    recipe=json.loads(recipe_path.read_text());assert recipe['groupCount']==4 and recipe['caseCount']==12
    actual_ids=[case for name in recipe['groupOrder']for case in recipe['groups'][name]['cases']]
    source_ids=[]
    for folder in (S10,S11):
        source_recipe=json.loads((folder/'RESOURCE-RECIPE.json').read_text());source_ids.extend(source_recipe['cases'])
        for group in source_recipe['groups']:
            expected=recipe['groups'][group['name']]
            assert expected['cases']==group['cases']and expected['caseCount']==len(group['cases'])
            assert expected['expectedTemporaryDirectories']==group['TDs']and group['wallSeconds']==180 and group['graceSeconds']==5
            assert expected['expectedTemporaryDirectoriesPerCase']=={case:source_recipe['caseTDs'][case]for case in group['cases']}
    assert actual_ids==source_ids and len(actual_ids)==len(set(actual_ids))==12
    assert len(recipe['originalBodyRecords'])==12
    for row in recipe['originalBodyRecords']:
        name,cls_name,method=row['id'].rsplit('.',2);path=Path(origins[name]['path'])
        assert row['expectedActualPath']==row['originalSourcePath']==str(path)
        tree=ast.parse(path.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef)and n.name==cls_name)
        fn=next(n for n in cls.body if isinstance(n,ast.FunctionDef)and n.name==method)
        assert hashlib.sha256(ast.dump(fn,include_attributes=False).encode()).hexdigest()==row['expectedBodyASTSha256']
    return dict(old,subjectOrigins=origins,publicSubjectOrigins=public,privatePureTestOrigins=pure,
        privateOverlayOrigins=overlays,expectedParentHead=head(),copyHistoricalParentHead=old['expectedParentHead'],
        allImplementationDefiningOriginsPublic=False,source10Freeze='ce0aad33395181606a63812ed968952f9b9a2b6cfca567b52ac377946e6397ae',
        source11Freeze='ed971e6ee5c4d9d3a9d8d9248561501899be20863918e798ff65a505199f0e64',
        combinedSourceReview='9c96637f53bc95b08e8a86ceed9f3b0d5f4e8cee5e540e6662c11e759ee67c27',
        independentSource11Peer='d6203d621ebb4e12c4a3263eccbbd3d8ba317e06642b27c115521c7f06038237',
        currentConsumerCompositionQualified=False,legacyPageCaptureDifferentTicketCompositionQualified=False,
        liveCombinedPhotosDestinationQualified=False,temporalHostCompositionQualified=False,
        nativeAdmission=None,nativeQualified=False,wholeQualified=False),physical
