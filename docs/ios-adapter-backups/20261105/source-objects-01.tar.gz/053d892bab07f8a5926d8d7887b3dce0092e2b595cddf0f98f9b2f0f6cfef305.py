"""Six UNRUN no-device genuine SDK-constructor controls.

Only actual constructors are used. No validate_pairing/aopen/usbmux discovery,
remote handshake, fake Source/provider/frame/spec/PID or desired receipt exists.
Local ServiceConnection controls use an actual AF_UNIX socketpair without a
protocol server. Such sockets cannot establish authenticated SDK custody.
"""
import socket
import unittest

from pymobiledevice3.exceptions import NotPairedError, PyMobileDevice3Exception
from pymobiledevice3.lockdown import UsbmuxLockdownClient
from pymobiledevice3.remote.userspace_tunnel import UserspaceRsdTunnel
from pymobiledevice3.service_connection import ServiceConnection
from ios.pymobiledevice3_wda_xctest import OriginalKeeperSource


class OriginalSdkConstructorControls(unittest.IsolatedAsyncioTestCase):
    def test_default_actual_constructor_keeps_original_source_opt_in_closed(self):
        tunnel = UserspaceRsdTunnel()
        self.assertFalse(tunnel._require_validated_source)
        self.assertTrue(tunnel.autopair)
        self.assertTrue(tunnel.remotepairing_fallback)
        self.assertIsNone(tunnel._source)
        self.assertIsNone(tunnel.rsd)
        with self.assertRaises(PyMobileDevice3Exception):
            tunnel.original_source()

    def test_strict_actual_constructor_refuses_autopair_or_fallback(self):
        for autopair, fallback in ((True,False),(False,True),(True,True)):
            with self.subTest(autopair=autopair, fallback=fallback):
                with self.assertRaises(ValueError):
                    UserspaceRsdTunnel(autopair=autopair,
                        remotepairing_fallback=fallback, require_validated_source=True)

    async def test_unopened_genuine_tunnel_cannot_mint_original_keeper_borrow(self):
        tunnel = UserspaceRsdTunnel(autopair=False,
            remotepairing_fallback=False, require_validated_source=True)
        self.addAsyncCleanup(tunnel.aclose)
        with self.assertRaises(PyMobileDevice3Exception):
            OriginalKeeperSource(tunnel)
        self.assertIsNone(tunnel._source)
        self.assertIsNone(tunnel._exit_stack)
        self.assertIsNone(tunnel._transport_watcher)

    async def test_unopened_genuine_tunnel_close_is_idempotent_and_not_a_source(self):
        tunnel = UserspaceRsdTunnel(autopair=False,
            remotepairing_fallback=False, require_validated_source=True)
        self.addAsyncCleanup(tunnel.aclose)
        await tunnel.aclose()
        await tunnel.aclose()
        self.assertIsNone(tunnel.rsd)
        self.assertIsNone(tunnel.tun)
        self.assertIsNone(tunnel._source)
        with self.assertRaises(PyMobileDevice3Exception):
            tunnel.original_source()

    async def local_unpaired_client(self):
        left, right = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM)
        self.addCleanup(right.close)
        self.addCleanup(left.close)
        service = ServiceConnection(left)
        self.addAsyncCleanup(service.close)
        # This declared label is not a pair record or an authenticated identity.
        client = UsbmuxLockdownClient(service,
            host_id='UNAUTHENTICATED-HOST-CONSTRUCTOR-CONTROL')
        self.addAsyncCleanup(client.close)
        return client, service, left, right

    async def test_actual_local_service_and_lockdown_constructor_have_no_auth_source(self):
        client, service, left, right = await self.local_unpaired_client()
        self.assertIs(client.service, service)
        self.assertIs(service.socket, left)
        self.assertIsNone(service.writer)
        self.assertIsNone(service.reader)
        self.assertIsNone(client.session_id)
        self.assertFalse(client.paired)
        with self.assertRaises(NotPairedError):
            client.validated_session_source()
        right.setblocking(False)
        with self.assertRaises(BlockingIOError):
            right.recv(1)

    async def test_actual_unpaired_close_closes_its_original_local_socket(self):
        client, service, left, right = await self.local_unpaired_client()
        with self.assertRaises(NotPairedError):
            client.validated_session_source()
        await client.close()
        self.assertIsNone(client._validated_session_source)
        self.assertIsNone(service.socket)
        self.assertEqual(-1, left.fileno())
        right.setblocking(False)
        self.assertEqual(b'', right.recv(1))
        with self.assertRaises(NotPairedError):
            client.validated_session_source()
