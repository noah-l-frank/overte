"""Three exact unselected device programs are data, not host import authority.

All source rows remain pinned. Every other original class/function table is
unchanged; a surprise use of these programs refuses before any source loader.
"""
from pathlib import Path
import ast
EXCLUDED=('module_support','modules.feature_journey','overte_session')
EXPECTED={'module_support': {'path': '/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/tests/device/module_support.py', 'sha256': 'edefb4c2ce8da00cca32ff6b3ccd7bd8309b5db94a290a5876d3044ffb35a406'}, 'modules.feature_journey': {'path': '/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/assets-whole29-current-observation-source-draft-20261103/candidate/tests/device/modules/feature_journey.py', 'sha256': '51ba79ad0a79edd24557a362b51b7f74f5484624c1f0a6dd06e3a48e1fa7752d'}, 'overte_session': {'path': '/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/tests/device/overte_session.py', 'sha256': 'f1a6798e4e7294265e3d9585f2d043b9741bc0eecc0437bc873a6523dcd7cdaf'}}

def project(declared):
    """Metadata-only original source inspection; never called after SUT import."""
    assert set(EXCLUDED)<=set(declared)
    for name,row in EXPECTED.items():
        assert declared[name]['path']==row['path']and declared[name]['sha256']==row['sha256']
    incoming={name:[]for name in EXCLUDED};literal_mentions=[]
    for name,row in declared.items():
        tree=ast.parse(Path(row['path']).read_text());targets=[]
        for node in ast.walk(tree):
            names=[]
            if isinstance(node,ast.ImportFrom)and node.module:
                names=[node.module]+[node.module+'.'+alias.name for alias in node.names if alias.name!='*']
            elif isinstance(node,ast.Import):names=[alias.name for alias in node.names]
            elif isinstance(node,ast.Call)and isinstance(node.func,(ast.Name,ast.Attribute)):
                port=node.func.id if isinstance(node.func,ast.Name)else node.func.attr
                if port in('import_module','__import__')and node.args and isinstance(node.args[0],ast.Constant)and type(node.args[0].value)is str:names=[node.args[0].value]
            for target in names:
                if target in incoming:incoming[target].append(dict(caller=name,line=node.lineno))
            if name not in EXCLUDED and isinstance(node,ast.Constant)and type(node.value)is str and node.value in EXCLUDED:
                literal_mentions.append(dict(caller=name,line=node.lineno,value=node.value))
    assert incoming['modules.feature_journey']==[]
    assert all(row['caller']in EXCLUDED for rows in incoming.values()for row in rows)
    assert not literal_mentions
    data={name:declared[name]for name in EXCLUDED};runtime={name:row for name,row in declared.items()if name not in EXCLUDED}
    return runtime,dict(version=1,kind='EXACT_DEVICE_ENTRYPOINT_DATA_ONLY_NO_RUNTIME_AUTHORITY',excluded=data,
        literalIncomingImports=incoming,otherLiteralEntrypointMentions=literal_mentions,unknownDynamicImportsAreRefused=True,
        allPhysicalDeclarationRowsRetained=True,originalDefinitionCount=len(declared),runtimeDefinitionCount=len(runtime))


def validate_plan(plan):
    """Pure fixed expected-layout replay, not a current namespace verdict."""
    allrows=plan['historicalDefinitionInventory'];runtime=plan['definitionInventory'];projection=plan['runtimeEntrypointProjection']
    assert projection['version']==1 and projection['kind']=='EXACT_DEVICE_ENTRYPOINT_DATA_ONLY_NO_RUNTIME_AUTHORITY'
    assert set(projection['excluded'])==set(EXCLUDED)
    assert projection['excluded']=={name:allrows[name]for name in EXCLUDED}
    assert runtime=={name:row for name,row in allrows.items()if name not in EXCLUDED}
    for name,row in EXPECTED.items():assert allrows[name]['path']==row['path']and allrows[name]['sha256']==row['sha256']
    assert projection['originalDefinitionCount']==len(allrows)and projection['runtimeDefinitionCount']==len(runtime)
    assert projection['literalIncomingImports']['modules.feature_journey']==[]and not projection['otherLiteralEntrypointMentions']
    assert all(row['caller']in EXCLUDED for rows in projection['literalIncomingImports'].values()for row in rows)
    assert projection['allPhysicalDeclarationRowsRetained']is projection['unknownDynamicImportsAreRefused']is True
    assert set(plan['subjectOriginModules'])==set(runtime)
    assert plan['modules']=={name:row for name,row in plan['namespacePlannerOriginalModules'].items()if name not in EXCLUDED}
    assert plan['originPlan']['modules']==plan['modules']
    assert len(allrows)==(588 if plan['groupName']=='archive01'else 590)
    assert len(runtime)==(585 if plan['groupName']=='archive01'else 587)
    return True
