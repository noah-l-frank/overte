"""Existing independent worker's explicit Profile9 route and pure End watch."""
from adapters.native_feature_observation import need,exact
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same,unpack
from ios.adapters.emote_runtime import IOSEmoteRuntime
from ios.adapters.emote_callback_terminal import IOSEmotePostControllerCallbackFeature
from ios.adapters.emote_post9_caller import target_flags
from feature_journeys import terminal
from feature_journeys.retirement_receipts import binding_from_context


def factory(runtime,config):
    need(isinstance(runtime,IOSEmoteRuntime)and config['iosEmoteObserverVersion']==4
        and type(config['postControllerFamilyVersion'])is int and config['postControllerFamilyVersion']==1)
    pair=config['targetPair'];need(pair['primaryTarget']==config['primaryTarget']and pair['actorTarget']==config['target'])
    for selector in(config['primaryTarget'],config['target']):target_flags(runtime.adapter.target(selector))
    return runtime._emote_post_controller_feature


def step(flow,config):
    need(type(flow)is IOSEmotePostControllerCallbackFeature and flow.role=='actor')
    factory(flow.runtime,config);seal=None
    with flow.held(30):
        flow.load()
        primary=IOSEmotePostControllerCallbackFeature(flow.runtime,config['primaryTarget'],flow.client,flow.run,'primary',
            config['primaryArtifactRoot'],config['primaryImagePolicy'],actor_selector=flow.selector,
            epoch_ms=flow.epoch_ms,monotonic=flow.monotonic,sleep=flow.sleep,target_pair=flow.configured_pair)
        primary.lock=primary.primary_lock=flow.primary_lock
        raw=PrivateFeatureState(primary.store.path.with_name('ios-emote-primary-'+flow.run+'-post9-end.json')).read()
        if raw is not None:
            exact(raw,{'iosEmotePost9EndArchiveVersion','runId','archiveSha256','seal','payload'})
            need(type(raw['iosEmotePost9EndArchiveVersion'])is int and raw['iosEmotePost9EndArchiveVersion']==2 and raw['runId']==flow.run)
            rows=unpack(raw['payload']);need(len(rows)==1 and rows[0]['phase']in('prepared','retiring','complete'))
            terminal.sealed(raw['seal']);need(raw['seal']['description']['runId']==flow.run)
            if rows[0]['phase']=='complete':seal=raw['seal']
            else:return 'sealed'
        else:
            control=PrivateFeatureState(primary.store.path.with_name('ios-emote-primary-'+flow.run+'-terminal.json')).read()
            if control is not None:
                exact(control,{'iosEmoteTerminalJournalVersion','runId','artifactRoot','bindings','locks','payload'})
                need(type(control['iosEmoteTerminalJournalVersion'])is int and control['iosEmoteTerminalJournalVersion']==2
                    and control['runId']==flow.run and control['artifactRoot']==str(primary.root)
                    and same(control['locks'],dict(primary=str(flow.primary_lock.path),actor=str(flow.lock.path)))
                    and flow.state is not None and same(control['bindings'],dict(primary=flow.state['primaryBinding'],actor=flow.state['binding'])))
                rows=unpack(control['payload']);need(len(rows)==1);state=rows[0]
                terminal.description(state['description'],area='emotes',run=flow.run)
                need(all(same(state['description']['roles'][role]['binding'],binding_from_context(binding))for role,binding in
                    (('primary',flow.state['primaryBinding']),('actor',flow.state['binding']))))
                if state['phase']in('sealing','sealed'):terminal.sealed(state['seal'],state['description']);return 'sealed'
                need(state['phase']=='inspected')
            if not flow.phase.status()['active']:return 'inactive'
    # Release BOTH locks before the actual canonical reconstruction. No End
    # graph is opened recursively inside a live Actor lease; no new query is
    # made on sealed/retired paths. The raw header above never grants complete.
    if seal is not None:
        from ios.adapters.emote_post9_canonical_end import completed
        actual=completed(primary,seal);need(actual['stage']=='finish');return 'complete'
    flow.publish();return 'published'
