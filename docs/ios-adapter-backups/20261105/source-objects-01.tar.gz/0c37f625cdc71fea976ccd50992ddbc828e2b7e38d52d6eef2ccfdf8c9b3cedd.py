"""Approved sequential common checks with all2238retained original files pinned."""
from pathlib import Path
import hashlib,json,stat,subprocess,sys
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics','libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def save(name,value):(HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def pin(path):
    before=path.lstat();row={key:getattr(before,key) for key in FIELDS}
    if stat.S_ISREG(before.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    else:assert stat.S_ISDIR(before.st_mode)
    after=path.lstat();assert all(getattr(before,key)==getattr(after,key) for key in FIELDS);return row

def sources():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}|{Path(__file__).resolve(),HERE/'actual-publication.json',HERE/'doc-publication.json'}
    evidence=json.loads((HERE/'restore-fixed14-source-after.json').read_text())
    paths.update(REPO/name for name in evidence)
    paths.update(HERE/name for name in ('restore-fixed14-source-after.json','restore-fixed14-test-report.json','restore-fixed14-supervisor-report.json','restore-fixed14-raw.log','restore-fixed14-new-originals-second.json','restore-fixed14-old-originals-after.json'))
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}
expected=json.loads((HERE/'restore-fixed14-old-originals-after.json').read_text())
expected.update(json.loads((HERE/'restore-fixed14-new-originals-second.json').read_text()))
assert len(expected)==66
assert sum(stat.S_ISREG(row['st_mode']) for rows in expected.values() for row in rows.values())==2238
def originals():
    return {root:{str(path.relative_to(Path(root))):pin(path) for path in (Path(root),*sorted(Path(root).rglob('*')))} for root in sorted(expected)}

before=sources();original_before=originals();assert expected==original_before,'Earlier original census no longer matches'
save('common-source-before.json',before);save('common-originals-before.json',original_before)
commands=[
 [sys.executable,'tests/run-project-tests.py','--profile','quick','--suite','documentation','--suite','documentation-contracts','--suite','ios-input-selection','--suite','policy-consistency','--suite','project-coverage','--timeout','240'],
 [sys.executable,'tests/device/validate_contract_versions.py'],[sys.executable,'tests/check-documentation.py','--all'],
 ['git','diff','--check'],['git','diff','--cached','--check']]
code=0
try:
    for argv in commands:
        print('CHECK',json.dumps(argv),flush=True);result=subprocess.run(argv,cwd=REPO)
        if result.returncode:code=result.returncode;break
finally:
    after=sources();original_after=originals();save('common-source-after.json',after);save('common-originals-after.json',original_after)
    assert before==after,'Source/launcher byte/stat/membership changed';assert original_before==original_after,'Owned original changed'
    print('SOURCE_LAUNCHER_PINS_UNCHANGED',len(after),'ORIGINAL_FILES',sum(stat.S_ISREG(row['st_mode']) for rows in original_after.values() for row in rows.values()),flush=True)
raise SystemExit(code)
