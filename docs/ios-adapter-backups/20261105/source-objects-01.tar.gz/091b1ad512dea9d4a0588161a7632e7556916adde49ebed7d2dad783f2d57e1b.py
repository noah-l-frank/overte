"""Run exact reviewed stage; record actual owned thread teardown."""
import json,os,runpy,sys,threading
from pathlib import Path
HERE=Path(__file__).resolve().parent;ENTRY='run-compat2.py';before=set(threading.enumerate());code=1
try:
 runpy.run_path(str(HERE/ENTRY),run_name='__main__');code=0
except SystemExit as result:code=result.code
finally:
 remaining=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in before and t.is_alive()]
 with (HERE/'root-compat2-first/thread-report.json').open('x') as output:
  json.dump(dict(remainingNewThreads=remaining,exitCode=code),output,indent=2);output.write('\n');output.flush();os.fsync(output.fileno())
 assert not remaining,'Actual fixture/worker thread remains live'
raise SystemExit(code)
