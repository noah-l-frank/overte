"""Explicit host lower palette/file producer, NEVER native/device evidence.

Uses actual original VM/Rig values, real own fixed-file FD/atomic replacement/
unlink and real receiver bytes. It accepts no desired animation/result/End.
"""
from copy import deepcopy
from pathlib import Path
import hashlib,json,os,tempfile,uuid
from adapters.native_feature_observation import need
from ios.adapters.emote_palette_file_original import FILE,METADATA
from ios.adapters.emote_palette_file_delivery import RESPONSE_FILE
from ios.self_tests.test_ios_emote_palette_original import PaletteProducer


def metadata(info):
    return dict(zip(METADATA,map(str,(info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns))))


class HostPaletteFile:
    def __init__(self,test,fixture):
        self.fixture=fixture;self.root=fixture.normal.target.root;self.path=self.root/FILE
        self.producer=PaletteProducer();self.owner=uuid.uuid4().hex;self.reader=uuid.uuid4().hex
        self.sequence=self.generation=0;self.fd=-1;self.palette=None;self.raw=None;self.before=None
        self.issued=self.retired=self.unknown=False;self.responses={};self.native_inputs=[]
        test.addCleanup(self.close)
        self.directory=os.open(self.root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
        self.parent=os.fstat(self.directory);self.root_current()
    def close(self):
        if self.fd>=0:os.close(self.fd);self.fd=-1
        if getattr(self,'directory',-1)>=0:os.close(self.directory);self.directory=-1
    def root_current(self):
        before=os.fstat(self.directory);path=self.root.lstat()
        def identity(row):return(row.st_dev,row.st_ino,row.st_mode,row.st_uid,row.st_gid)
        need(identity(before)==identity(path)==identity(self.parent)and before.st_uid==os.geteuid()
            and before.st_mode&0o777==0o700 and self.root.resolve(strict=True)==self.root)
    def publish(self,query,native,computed):
        self.root_current();need(not self.issued and not self.unknown)
        value=self.producer.compute(native,computed)
        # Fresh declared producer at this actual query, BEFORE any raw write.
        # Existing originals are never changed. Compute every current joint
        # from actual VM poses; this remains a lower CPU model, not a renderer.
        pose=value['source']['observation']['postControllerPose'];poses=[]
        for index,item in enumerate(native['animation']['joints']):
            row=list(item)
            if index==0:row[4]+=.05
            poses.append([1.,1.,1.,*row])
        pose['relativePoses']=deepcopy(poses);pose['absolutePoses']=deepcopy(poses)
        value.update(requestId=query['commandId'],runId=query['runId'])
        raw=json.dumps(value,allow_nan=False).encode();need(0<len(raw)<=250000)
        if self.fd>=0:need(self.current())
        else:need(not self.path.exists())
        fd,name=tempfile.mkstemp(prefix='emote-post9-native-palette-',dir=self.root)
        try:
            os.fchmod(fd,0o600);used=0
            while used<len(raw):used+=os.write(fd,raw[used:])
            os.fsync(fd);os.replace(name,self.path)
        finally:
            os.close(fd)
            if Path(name).exists():Path(name).unlink()
        if self.fd>=0:os.close(self.fd)
        self.fd=os.open(self.path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
        self.before=os.fstat(self.fd);self.raw,self.palette=raw,deepcopy(value);self.generation+=1
        need(self.current());self.native_inputs.append(deepcopy(native));return value
    def current(self):
        self.root_current();before=os.fstat(self.fd);path=os.stat(FILE,dir_fd=self.directory,follow_symlinks=False)
        need(before.st_nlink==1 and before.st_mode&0o777==0o600)
        return metadata(before)==metadata(path)==metadata(self.before)and os.pread(self.fd,len(self.raw)+1,0)==self.raw
    def command(self,query):
        self.root_current();need(self.palette is not None and query['runId']==self.palette['runId']);self.sequence+=1
        domain=self.fixture.normal.target.domain;before=dict(epochMs=domain.epoch(),monotonicMs=round(domain.time*1000))
        if query['operation']=='retire':
            need(not self.issued and query['ownerInstance']==self.owner and query['generation']==self.generation
                and query['paletteRequestId']==self.palette['requestId'])
            self.issued=True;need(self.current())
            os.unlink(FILE,dir_fd=self.directory);os.fsync(self.directory)
            actual=os.fstat(self.fd);need(actual.st_nlink==0)
            try:os.stat(FILE,dir_fd=self.directory,follow_symlinks=False)
            except FileNotFoundError:pass
            else:need(False)
            need(os.pread(self.fd,len(self.raw)+1,0)==self.raw);self.retired=True
        elif not self.retired:need(self.current())
        native=dict(iosEmotePaletteFileOwnedOriginalVersion=1,instance=self.owner,processId=31,generation=self.generation,
            phase='retired'if self.retired else'owned',retirementIssued=self.issued,pendingPublication=False,
            file=dict(name=FILE,metadata=metadata(self.before),sha256=hashlib.sha256(self.raw).hexdigest(),bytes=len(self.raw),palette=deepcopy(self.palette)),
            afterRetirement=metadata(os.fstat(self.fd))if self.retired else{},processDeathProved=False,sdkAbsentProved=False)
        original=dict(iosEmotePaletteFileVersion=1,requestId=query['commandId'],runId=query['runId'],instance=self.reader,sequence=self.sequence,
            processId=31,clockDomain='native-main-emote-palette-file',clockBefore=before,
            clockAfter=dict(epochMs=domain.epoch(),monotonicMs=round(domain.time*1000)),source=dict(complete=True,ownership=native))
        result=dict(iosEmotePaletteFileDeliveryVersion=1,requestId=query['commandId'],runId=query['runId'],responseFile=RESPONSE_FILE,original=original)
        self.write_response('primary',result);return result
    def write_response(self,role,value):
        path=self.fixture.roles[role].target.root/RESPONSE_FILE
        path.write_text(json.dumps(value,allow_nan=False));path.chmod(0o600);self.responses[role]=path
    def response(self,role):return self.responses[role].read_text()
