"""Actor editor generations derived only from its own original Current7 cuts.

Primary metadata supplies the actual retained original owner before acquisition.
It never supplies the Actor's current fields, source rows, aliases or world pose.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from ios.adapters.graphics_history import follow_native
from ios.adapters import lifecycle_current as current,lifecycle_fields as fields,lifecycle_world as world,keyboard_source as keyboard
from ios.adapters.lifecycle_current_stream import LifecycleCurrentStream
from ios.adapters.lifecycle_current_archive import LifecycleCurrentArchive

EDITORS=('create','chat','scripts','scripts')


def derive(archive,references):
    """Literal replay suitable for a future witness callback: no SDK reads."""
    need(type(archive)is LifecycleCurrentArchive and archive.role=='actor'and type(references)is list
        and len(references)<=len(archive.snapshot['state']['records'])<=64)
    aliases=[];values=[]
    for index,reference in enumerate(references,1):
        need(reference['index']==index and same(reference,archive.snapshot['state']['records'][index-1]))
        retained=archive.record(reference);value=retained['current'];facts=retained['facts'];field=facts['editor']['field']
        if not values:
            need(field is None and not facts['editor']['keyboard']['keyboard']and not facts['editor']['holder']['resources']['pendingRuns'])
            world.measure(value['originals']['world'],value['originals']['world']);need(not value['originals']['world']['source']['touch']['active'])
        else:
            previous=values[-1];a,b=previous['originals'],value['originals']
            follow_native(previous['clockJoin']['nativeAfter'],value['clockJoin']['nativeBefore'])
            need(a['ui']['instance']==b['beforeUI']['instance']and a['ui']['lastSequence']<=b['beforeUI']['lastSequence']
                and a['ui']['elapsedMs']<=b['beforeUI']['elapsedMs'])
            fields.validate(b['beforeUI']['lifecycleFieldInventory'],pid=int(archive.binding['processIdentity']),previous=a['ui']['lifecycleFieldInventory'])
            packet=b['keyboard'];keyboard.validate(packet,dict(schemaVersion=1,commandId=packet['requestId'],action=keyboard.ACTION,runId=archive.run),
                int(archive.binding['processIdentity']),previous=a['keyboard'])
            world.validate(b['world'],dict(schemaVersion=1,commandId=b['world']['requestId'],action=world.ACTION,runId=archive.run),
                int(archive.binding['processIdentity']),previous=a['world'])
            need(a['pending']['instance']==b['pending']['instance']and a['pending']['sequence']<b['pending']['sequence']
                and a['pending']['lastIntentSequence']<=b['pending']['lastIntentSequence']
                and a['pending']['capturedEpochMs']<=b['pending']['capturedEpochMs']
                and a['pending']['resources']['archivedEvents']<=b['pending']['resources']['archivedEvents'])
            if a['pending']['commit']:
                old,new=a['pending']['commit'],b['pending']['commit'];need(new and all(same(old[key],new[key])for key in ('captureCommandId','fieldToken')))
                left,right=old['observation'],new['observation']
                need(all(same(left[key],right[key])for key in ('instance','eventId','processId','createdEpochMs','source'))
                    and left['sequence']<right['sequence']and left['elapsedMs']<=right['elapsedMs']
                    and same(left['events'],right['events'][:len(left['events'])]))
            if field is not None:
                known=[alias for alias in aliases if same(alias['identity'],field['identity'])]
                if known:need(len(known)==1 and known[0]['generation']==len(aliases))
                else:
                    generation=len(aliases)+1;need(generation<=4)
                    alias=fields.alias_transition(a['ui']['lifecycleFieldInventory'],b['ui']['lifecycleFieldInventory'],EDITORS[generation-1],generation)
                    need(same(alias['identity'],field['identity'])and field['focused']==(generation!=4)
                        and facts['editor']['keyboard']['keyboard']==(generation!=4))
                    if generation==4:
                        holder=facts['editor']['holder'];need(same(holder['held'],aliases[2]['identity'])and holder['commit']and holder['commit']['observation']['pending'])
                    aliases.append(dict(alias,reference=deepcopy(reference)))
        values.append(value)
    return aliases,values


class LifecycleActorHistory:
    def __init__(self,store,stream,primary):
        need(isinstance(store,PrivateFeatureState)and type(stream)is type(primary)is LifecycleCurrentStream
            and stream.role=='actor'and primary.role=='primary'and stream.run==primary.run and stream.binding==primary.binding
            and stream.lock.path==primary.lock.path and primary.state['records']and primary.state['owner']is not None)
        primary.bound();stream.bound();need(stream.state['owner']==primary.state['owner']
            and store.path==stream.store.path.with_name('ios-lifecycle-actor-current-history-'+stream.run+'.json'))
        self.store,self.stream,self.primary=store,stream,primary;self.previous=store.read()
        self.state=dict(records=[],aliases=[])if self.previous is None else deepcopy(self.previous['state'])
        if self.previous is not None:need(same(self.previous,self.envelope()))
        self.replay()

    def envelope(self):
        s=self.stream;return dict(iosLifecycleActorHistoryVersion=1,binding=s.binding,runId=s.run,ownerInstance=s.state['owner'],
            artifactRoot=str(s.root),state=deepcopy(self.state))

    def bound(self):
        self.stream.bound();self.primary.bound();need(self.stream.state['owner']==self.primary.state['owner']and same(self.store.read(),self.previous));return True

    def archive(self):
        s=self.stream;return LifecycleCurrentArchive(s.store,s.previous,s.root,s.binding,s.run,'actor',s.lock)

    def replay(self):
        self.bound();exact(self.state,{'records','aliases'});need(type(self.state['records'])is list and type(self.state['aliases'])is list)
        aliases,values=derive(self.archive(),self.state['records']);need(same(aliases,self.state['aliases']));return values

    def append(self,reference):
        self.replay();need(reference['index']==len(self.state['records'])+1
            and same(reference,self.stream.state['records'][reference['index']-1]))
        proposed=self.state['records']+[deepcopy(reference)];aliases,_=derive(self.archive(),proposed)
        self.state=dict(records=proposed,aliases=aliases);self.bound();value=self.envelope();self.store.write(value,self.previous);self.previous=deepcopy(value)
        return len(proposed)

    def recover_saved(self):
        """Adopt known original stream rows as history; publish no new sample."""
        self.replay()
        for reference in self.stream.state['records'][len(self.state['records']):]:self.append(reference)
        return self.replay()
