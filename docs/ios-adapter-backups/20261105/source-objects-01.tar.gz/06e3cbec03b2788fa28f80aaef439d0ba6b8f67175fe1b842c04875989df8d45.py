import cProfile
import hashlib
import json
from pathlib import Path
import pstats
import time
from ios.self_tests.test_ios_emote_rooted_fence_original import RootedFenceOriginalTests

case=RootedFenceOriginalTests()
def pins():
    result={}
    for path in case.scope.root.iterdir():
        if path.is_file():
            info=path.stat();result[str(path)]=(info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns,hashlib.sha256(path.read_bytes()).hexdigest())
    return result
try:
    case.setUp();before=pins();actions=list(case.f.domain.io.actions);seq=dict(case.f.domain.sequences)
    profiler=cProfile.Profile();started=time.monotonic();profiler.enable()
    result=case.decoded()
    profiler.disable();duration=time.monotonic()-started
    assert before==pins();assert actions==case.f.domain.io.actions;assert seq==case.f.domain.sequences
    assert result['scope'].held_originals()==case.scope.held_originals()
    profile_path=Path(__file__).with_suffix('.pstats');profiler.dump_stats(str(profile_path))
    print(json.dumps(dict(seconds=duration,originals=len(before),unchanged=True,inputs=0,nativeQueries=0)))
    stats=pstats.Stats(profiler)
    for key,value in sorted(stats.stats.items()):
        filename,line,method=key
        if filename.endswith(('emote_keys.py','emote_archive_round.py','original_frame_store.py')) and method in ('_original','_packet','original','packet','key_original','read','guard'):
            print(json.dumps(dict(file=Path(filename).name,line=line,method=method,primitive=value[0],calls=value[1],own=value[2],cumulative=value[3])))
    stats.sort_stats('cumulative').print_stats(10)
    from ios.adapters.emote_archive_round import scope as archive_round
    from ios.self_tests.retained_host_roots import retain_owned_root
    retained=retain_owned_root(case.f.f.f.f.temp,expected_root=case.scope.root)
    payload=dict(root=str(retained),binding=case.scope.binding,run=case.scope.run,role=case.scope.role,
        lock=str(case.scope.lock.path),value=case.value,copies=case.copies)
    Path(__file__).with_suffix('.case.json').write_text(json.dumps(payload))
    profile=cProfile.Profile();started=time.monotonic();profile.enable()
    with archive_round(dict(artifactRoot=str(case.scope.root),stateRoot=str(case.scope.lock.path.parent)),lock=case.scope.lock,primary_lock=case.scope.lock):
        result2=case.decoded()
    profile.disable();elapsed=time.monotonic()-started
    assert before==pins();assert actions==case.f.domain.io.actions;assert seq==case.f.domain.sequences
    assert result['metadata']==result2['metadata']
    assert result['scope'].snapshot()==result2['scope'].snapshot()
    assert result['keys'].previous==result2['keys'].previous
    profile.dump_stats(str(Path(__file__).with_suffix('.round.pstats')))
    print(json.dumps(dict(roundSeconds=elapsed,originals=len(before),unchanged=True,inputs=0,nativeQueries=0)))
    stats=pstats.Stats(profile)
    for key,value in sorted(stats.stats.items()):
        filename,line,method=key
        if filename.endswith(('emote_keys.py','emote_archive_round.py','original_frame_store.py')) and method in ('_original','_packet','original','packet','key_original','read','guard'):
            print(json.dumps(dict(file=Path(filename).name,line=line,method=method,primitive=value[0],calls=value[1],own=value[2],cumulative=value[3])))
    stats.sort_stats('cumulative').print_stats(12)
finally:case.doCleanups()
