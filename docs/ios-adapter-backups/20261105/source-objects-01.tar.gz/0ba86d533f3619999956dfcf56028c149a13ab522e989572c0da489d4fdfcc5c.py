"""Metadata-only clock2 then Fresh16 own3 controller; no target execution."""
from pathlib import Path
import ast,hashlib,json,os,stat
R=Path.cwd();D=Path(__file__).resolve().parent;O=R/'.ios-host-tmp/lifecycle-whole-fresh16-navigation-clock-three-pinned-overlay-root-preparation-20261103';S=R/'.ios-host-tmp/lifecycle-restoration-navigation-clock-originals-source-proposal-20261103';H=R/'.ios-host-tmp/lifecycle-clock-originals-two-then-fresh16-three-pinned-overlay-root-preparation-20261103'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(O/'freeze.json')=='53e818ee944f8591893299e20e37a19a85acd5247ef94fd67196a1bf1059c896'
assert sha(S/'freeze.json')=='a012075feaabe7f1b6978c3c4f2cf27e392a510440b227fe308330decd9736d4'
assert not H.exists();H.mkdir(mode=0o700)
for relative,digest in json.loads((O/'freeze.json').read_text())['files'].items():
    assert sha(O/relative)==digest
    if relative in ('immutable-source-pins.json','AST-ONLY.json'):continue
    p=H/relative;p.parent.mkdir(parents=True,exist_ok=True,mode=0o700);p.write_bytes((O/relative).read_bytes());p.chmod(0o600)
f=H/'models/test_lifecycle_restoration_clock_original_models.py';f.write_bytes((S/'models'/f.name).read_bytes());f.chmod(0o600)
clock_cases=[('clockEndpoints1','test_actual_nested_navigation_endpoints_join_and_replay_without_new_query'),('clockCorrupt1','test_changed_clock_copies_and_same_helper_code_refuse_without_requery_or_original_change')]
for name,method in clock_cases:
    p=H/name;p.mkdir(mode=0o700);value=json.loads((H/'first1/case.json').read_text());value['case']='test_lifecycle_restoration_clock_original_models.LifecycleRestorationClockOriginalModels.'+method
    (p/'case.json').write_text(json.dumps(value,indent=2)+'\n')
def rebase(v):
    if type(v)is dict:return {k:rebase(x)for k,x in v.items()}
    if type(v)is list:return [rebase(x)for x in v]
    return v.replace(str(O),str(H))if type(v)is str else v
for path in (H/'plan.json',H/'maps.json',*sorted((H/'maps').glob('*.json'))):path.write_text(json.dumps(rebase(json.loads(path.read_text())),indent=2,sort_keys=True)+'\n')
maps=json.loads((H/'maps.json').read_text())
for row in maps.values():row['sha256']=sha(Path(row['path']))
(H/'maps.json').write_text(json.dumps(maps,indent=2,sort_keys=True)+'\n')
order=['clockEndpoints1','clockCorrupt1','first1','typeLoss1','originalUp1'];plan=json.loads((H/'plan.json').read_text());plan['cases']=[json.loads((H/name/'case.json').read_text())['case']for name in order];plan['caseCount']=5;plan['stageOrder']=order;plan['sourceFreezeSha256']=sha(S/'freeze.json');(H/'plan.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
p=H/'root-supervise.py';t=p.read_text();old="HERE.name in ('first1','typeLoss1','originalUp1')";assert t.count(old)==1;p.write_text(t.replace(old,"HERE.name in ('clockEndpoints1','clockCorrupt1','first1','typeLoss1','originalUp1')"))
p=H/'guard.py';t=p.read_text();start=t.index('def first_pass(here):');t=t[:start]+"""def qualified_pass(stage):
    report=json.loads((stage/'run/report.json').read_text());selected=json.loads((stage/'selected-result.json').read_text())
    assert report['exitCode']==0 and report['allPinsEqual']and report['retainedOriginalsUnchanged']and not report['remainingOwnedProcesses']
    expected=json.loads((stage/'case.json').read_text())['case']
    assert selected['selectedIds']==[expected]and selected['successful']and selected['testsRun']==1 and not any(selected[k]for k in ('failureCount','errorCount','skippedCount'))
    receipt=json.loads((stage/'cleanup/receipt.json').read_text());assert receipt['case']==expected and receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']and len(receipt['retainedRoots'])==3
    before=json.loads((stage/'run/source-before.json').read_text());after=json.loads((stage/'run/source-after.json').read_text());assert before==after==json.loads((stage.parent/'immutable-source-pins.json').read_text())
    first=json.loads((stage/'run/originals-first.json').read_text());second=json.loads((stage/'run/originals-second.json').read_text());assert first==second
    root=stage/'retained';actual={str(p):pin(p)for p in(root,*sorted(root.rglob('*')))};assert second==actual
    a=json.loads((stage/'cleanup/terminal-census-1.json').read_text());b=json.loads((stage/'cleanup/terminal-census-2.json').read_text());assert a==b
    assert not any(a[k]for k in('threads','pendingTasks','sdkModules'))and a['children']==''

def first_pass(here):
    order=('clockEndpoints1','clockCorrupt1','first1','typeLoss1','originalUp1');assert here.name in order
    for name in order[:order.index(here.name)]:qualified_pass(here.parent/name)
""";p.write_text(t)
(H/'ROOT-PLAN.txt').write_text("""ROOT AUTHORIZED EXACT CLOCK2 FIRST, THEN FRESH16 OWN3 ONLY UPON PASS

Sourcea012075feaabe7f1b6978c3c4f2cf27e392a510440b227fe308330decd9736d4.
Execute each stage exactly once via python3 -B root-supervise.py <stage> from
this Resume worktree, in this exact order:
clockEndpoints1, clockCorrupt1, first1, typeLoss1, originalUp1.
Every earlier stage must have actual qualified PASS before the next can launch.
A failure/timeout stops the selection; no retry/cap increase. Product semantics
require Root review before another successor. Unchanged180s+TERM/kill-after5s.

clockEndpoints1 and clockCorrupt1 select exactly the new OWN methods in
models/test_lifecycle_restoration_clock_original_models.py. They inherit the real
FreshWholeFixture, actual Current7/Parent/Navigation/Restoration and source maps.
Qt/native/RSD/SDK remain explicitly raw models. No target import/execution during
this preparation. No source/native/parent guard replacement. Product delta is
only the reviewed Navigation clock carrier in Sourcea012. All prior preparation
and actual failures remain immutable/pinned. Controller53e8 stays UNRUN unchanged.

Sources(), actual standard AsyncRunner/teardown/cleanup/Runner.close, unchanged
root_stage_guard.py and all before/after source/raw/FD/task/thread/child/SDK
censuses remain mandatory. Each exact own case owns three genuine retained TDs.
Each child forbids all SDK imports/reads and subprocess/Node; socket bind/connect
are strictly owned loopback. Parent owns PGID/SID/startticks and requires empty
owned process group/session before two immutable original censuses. Prior-stage
admission additionally rechecks the actual retained tree against its full saved
inode/hash/stat census, exact result/receipt and source-map pins. All raw files,
PFS/WAL/sidecar originals are kept on error or timeout.

The final three stages preserve their exact previous methods/expected states.
This tests state/input/independent Actor evidence only: Primary artifacts are
explicitly empty. Moving PNG, common WholeEngine, End/native/device qualification
remain OPEN; no broader qualification or completion claim follows these cases.
""")
(H/'selection-provenance.json').write_text(json.dumps(dict(parentController=str(O),parentFreeze=sha(O/'freeze.json'),sourceFreeze=sha(S/'freeze.json'),selectedStages=order,addedOwnCases=[json.loads((H/name/'case.json').read_text())['case']for name,_ in clock_cases],rootSupervisorDelta='Allow only two literal additional stage names; command/budget/process boundary unchanged',runnerUnchanged=sha(H/'run-selected.py')==sha(O/'run-selected.py'),terminalGuardUnchanged=sha(H/'root_stage_guard.py')==sha(O/'root_stage_guard.py'),failfast=True),indent=2)+'\n')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
    a=p.lstat();assert not p.is_symlink()and p.resolve(strict=True)==p;v=dict(stat=[getattr(a,k)for k in FIELDS])
    if p.is_file():v['sha256']=sha(p)
    assert v['stat']==[getattr(p.lstat(),k)for k in FIELDS];return v
old=json.loads((O/'immutable-source-pins.json').read_text());pins={name:pin(Path(name))for name in old};assert old==pins
for p in (O/'freeze.json',O/'immutable-source-pins.json',Path(__file__).resolve()):pins[str(p)]=pin(p)
for p in sorted(H.rglob('*')):
    if p.is_file():pins[str(p)]=pin(p)
(H/'immutable-source-pins.json').write_text(json.dumps(pins,indent=2,sort_keys=True)+'\n')
rows=[]
for p in sorted(H.rglob('*.py')):rows.append(dict(path=str(p.relative_to(H)),sha256=sha(p),astSha256=hashlib.sha256(ast.dump(ast.parse(p.read_bytes()),include_attributes=False).encode()).hexdigest()))
(H/'AST-ONLY.json').write_text(json.dumps(dict(status='NO_TARGET_IMPORT_OR_EXECUTION',files=rows),indent=2)+'\n')
files={str(p.relative_to(H)):sha(p)for p in sorted(H.rglob('*'))if p.is_file()}
(H/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_FROZEN_UNRUN_EXACT_SELECTION_AUTHORIZED',sourceFreeze=sha(S/'freeze.json'),parentControllerFreeze=sha(O/'freeze.json'),files=files),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(controller=str(H),freeze=sha(H/'freeze.json'),pins=len(pins),pythonFiles=len(rows),source=sha(S/'freeze.json'),executed=False)))
