"""Actual30+5 supervisor; real lineage, two complete outputs, no old corpus."""
from pathlib import Path
import argparse,json,os,signal,subprocess,sys,threading,time,traceback
from utility_common import SOURCE,REPO,admitted,pin,load,sha,head,proc,table,fds,census
p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--input-sha',required=True);p.add_argument('--output',required=True);a=p.parse_args()
plan,input_before=admitted(a.input,a.input_sha);HERE=Path(a.output);OUTER=Path(a.output+'-outer')
assert HERE.is_absolute()and HERE.resolve(strict=False)==HERE and HERE.parent==REPO/'.ios-host-tmp'and HERE.name.startswith('avatar-boundary-own4-output-')and not HERE.exists()and not OUTER.exists()
source_before={path:pin(path)for path in plan['physicalPins']};fds_before=fds();threads_before=tuple(threading.enumerate());initial=table()
HERE.mkdir(mode=0o700);OUTER.mkdir(mode=0o700)
def save(name,value):
    path=OUTER/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as out:json.dump(value,out,sort_keys=True,indent=2);out.write('\n');out.flush();os.fsync(out.fileno())
save('source-before.json',source_before);save('input-before.json',input_before)
task=None;birth=None;owned={};problems=[];timed_out=False;forced=False;term_at=None;start=time.monotonic()
def discover():
    rows=table();changed=True
    while changed:
        changed=False
        for pid,row in rows.items():
            if pid in owned:continue
            linked=row['parentPid']in owned or birth is not None and(row['processGroup']==birth['processGroup']or row['session']==birth['session'])
            partial=row['parentPid']==os.getpid()and row!=initial.get(pid)
            if linked or partial:
                assert pid not in initial;owned[pid]=row;changed=True
                if birth is not None and pid!=birth['pid']and(row['parentPid']!=birth['pid']or row['processGroup']!=birth['processGroup']or row['session']!=birth['session']):
                    problems.append(dict(kind='unadmitted-descendant-or-detachment',identity=row))
    return rows
try:
    with(HERE/'stdin.eof').open('xb'):pass
    with(HERE/'stdin.eof').open('rb')as incoming,(HERE/'stdout.log').open('xb')as stdout,(HERE/'stderr.log').open('xb')as stderr:
        task=subprocess.Popen([sys.executable,'-S','-B',str(SOURCE/'run-own4.py'),'--input',a.input,'--input-sha',a.input_sha,'--output',str(HERE)],stdin=incoming,stdout=stdout,stderr=stderr,cwd=REPO,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},start_new_session=True)
    birth=proc(task.pid);assert birth is not None and birth['parentPid']==os.getpid()and birth['processGroup']==birth['session']==birth['pid'];owned[task.pid]=birth;save('actual-runner-birth.json',birth)
    while True:
        discover()
        for pid,row in owned.items():
            now=proc(pid)
            if now is not None and now!=row:problems.append(dict(kind='actual-identity-changed',before=row,after=now))
        if task.poll()is not None:break
        if time.monotonic()-start>=30 and term_at is None:
            assert proc(task.pid)==birth;timed_out=True;term_at=time.monotonic();os.kill(task.pid,signal.SIGTERM)
        if term_at is not None and time.monotonic()-term_at>=5:
            assert proc(task.pid)==birth;forced=True;os.kill(task.pid,signal.SIGKILL);break
        time.sleep(.025)
    task.wait()
except BaseException:problems.append(dict(kind='actual-supervisor-exception',traceback=traceback.format_exc()))
finally:
    discover();residual=[]
    for pid,row in owned.items():
        now=proc(pid)
        if now is not None:
            residual.append(dict(bound=row,current=now))
            if now==row:os.kill(pid,signal.SIGKILL)
    if task is not None:task.wait()
    remaining=[dict(bound=row,current=proc(pid))for pid,row in owned.items()if proc(pid)is not None]
    save('actual-kernel-drain.json',dict(owned=list(owned.values()),postRunnerResidual=residual,remaining=remaining))
    assert not remaining,'No post-stop inventories while a bound process remains'
    first=census(HERE);save('whole-output-first.json',first);second=census(HERE);save('whole-output-second.json',second)
    after={path:pin(path)for path in source_before};save('source-after.json',after);input_after=pin(a.input);save('input-after.json',input_after)
    child=load(HERE/'result.json')if(HERE/'result.json').is_file()else None;data=load(HERE/'actual-case-data.json')if(HERE/'actual-case-data.json').is_file()else None
    if data is not None:
        # Join short-lived original children missed by polling to the actual
        # retained child-side birth receipts, without assuming PID absence.
        births=[row['birth']for case in data['cases']for row in case['actualProcesses']]
        for row in births:
            if row is None:
                problems.append(dict(kind='unproven-partial-constructor-no-birth-authority'));continue
            assert row['parentPid']==birth['pid']and row['processGroup']==birth['processGroup']and row['session']==birth['session']
            current=proc(row['pid']);assert current is None or current['startTicks']!=row['startTicks']
        assert len(births)<=2
    final_fds=fds();final_threads=tuple(threading.enumerate())
    passed=(task is not None and task.returncode==0 and not timed_out and not forced and not problems and not residual and not remaining
        and source_before==after and input_before==input_after and first==second and fds_before==final_fds and threads_before==final_threads and head()==plan['expectedHead']
        and child is not None and child['status']=='PASS'and child['testsRun']==4 and child['selected']==plan['cases']and not child['finalizationFailures']
        and child['actualFDsEqual']and child['actualThreadsEqual']and child['actualToolsEqual']and child['actualPortsEqual']and child['originalCleanupEstablished']
        and not child['remainingKernelChildren']and not child['prohibitedNativeOrNodeEntries']and child['NodeExecutions']==child['SDKExecutions']==0 and child['actualTLSBirths']==2 and child['actualFixtureListeners']==1 and len(child['retainedTDs'])==6)
    save('parent-drain.json',dict(actualFDsEqual=fds_before==final_fds,actualThreadsEqual=threads_before==final_threads))
    save('terminal.json',dict(status='PASS'if passed else'FAIL_OR_REFUSED',childReturnCode=None if task is None else task.returncode,seconds=time.monotonic()-start,timedOut=timed_out,forced=forced,problems=problems,postRunnerResidual=residual,remainingOwned=remaining,
        allSourcePinsEqual=source_before==after,actualInputPinAndCliShaEqual=input_before==input_after,twoFullOwnOutputCensusesEqual=first==second,actualParentFDThreadDrain=fds_before==final_fds and threads_before==final_threads,
        maximumDeclaredTLSBirths=2,NodeExecutions=0,oldOriginalInputs=0,globalCensuses=0,nativeQualified=False,wholeQualified=False))
raise SystemExit(0 if passed else 1)
