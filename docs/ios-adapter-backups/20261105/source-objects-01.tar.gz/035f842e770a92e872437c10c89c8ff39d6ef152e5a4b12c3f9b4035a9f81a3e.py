"""Retain actual startup refusal and unavailable lineage without promotion."""
from pathlib import Path
import hashlib,json
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,v):
 with(d/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
C=B/'root-assets-source3-second01-b7-window-current1185-20261105'
assert sha(C/'freeze.json')=='c4eb53b8dd209a1c8f43058dfe14c0a6c3c82b98cc2637afadb4fc5ba278a160'
for n,r in load(C/'freeze.json')['files'].items():assert sha(C/n)==r['sha256']
t=load(C/'terminal.json');assert t['status']=='ROOT_ASSETS_SOURCE3_SECOND01_ORIGINAL_FAILURE_OR_PARTIAL_CLOSED_WITHOUT_LINEAGE_PROMOTION'
assert t['allOldOriginalBodiesUnchanged']is t['allRecordedOriginalPIDsAndGroupsAbsent']is t['wholeAllActualOwnRoomsTwiceEqual']is True and t['oldRootCount']==1185
assert t['originalSupervisorReturnCode']==1 and t['originalSupervisorTerminal']is t['originalQualification']is None
h=Path(t['newOriginalRoots'][0]);o=h.with_name(h.name+'-outer');assert len(t['newOriginalRoots'])==4 and t['newOriginalRoots'][1]==str(h/'temporary')
assert sha(h/'approved-inputs.json')=='fd0c213370acf5de9abd57b115efef2a0ddee4ce530ac7957fa092e970725f0b'
drain=load(o/'actual-drain.json');assert drain==t['originalDrain'] and drain['remaining']==[] and drain['completeOriginalNodeLineage']is False and drain['reportedOriginalNodes']==[]
assert drain['timedOut']is drain['forced']is False
partial=load(o/'unqualified-partial.json');assert type(partial['originalReport'])is dict and partial['problems']==[] and partial['noWholeOutputOrGlobalClosureClaim']is True
assert not(o/'terminal.json').exists()
report=load(h/'actual-report.json');assert report==partial['originalReport']and report['testsRun']is None and report['cases']==[]and report['actualResources']is None and report['actualOriginalNodes']==[]and report['retainedTemporaryDirectories']==[]
assert report['definitionsUnchanged']is report['completeOriginalNodeLineage']is False and report['pinsAndInputUnchanged']is True
assert report['expectedEagerDefinitionCount']==report['actualEagerDefinitionCount']==587 and len(report['actualEagerDefinitionModules'])==587 and report['retainedPhysicalDefinitionCount']==590
assert [r['phase']for r in report['secondary']]==['resource-recipe']
original_log=h/'child-logs/stdout.log';text=original_log.read_text();assert 'DefinitionCustody'in text and 'in decorated'in text and 'assert key in closure and closure[key].cell_contents is following'in text and 'AssertionError'in text
ctx=load(B/'root-ios-current1185-after-assets-second01-b6a-inventory-read-negative-context-20261105/root-context.json');old=load(ctx['globalCustody']['baseline']['path']);assert len(old)==1185 and load(C/'global-before.json')==old
post=load(C/'global-after-first.json');assert post==load(C/'global-after-second.json') and set(post)==set(old)|{str(h/'temporary')}and all(post[n]==v for n,v in old.items())
whole=load(C/'whole-first.json');assert whole==load(C/'whole-second.json')and whole[str(h/'temporary')]==post[str(h/'temporary')]
absence=load(C/'actual-root-kernel-absence.json');assert absence['actualSameGroupOrSession']==[]and absence['originalCreatorLineageQualified']is False
for row in absence['actualRecordedOriginals']:
 try:raw=Path('/proc',str(row['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(raw[raw.rfind(')')+2:].split()[19])!=row['startTicks']
terminal=dict(childReturnCode=t['originalSupervisorReturnCode'],returnCodeScope='Actual completed Assets supervisor; original runner return was not saved and remains None',originalRunnerReturnCode=None,ownProcessesAbsent=True,problems=partial['problems'],timedOut=drain['timedOut'],forcedKill=drain['forced'],custodyProjectionOnly=True)
refs={str(f):dict(path=str(f),sha256=sha(f))for root in map(Path,t['newOriginalRoots'])for f in sorted(root.rglob('*'))if f.is_file()and not f.is_symlink()}
OUT=B/'root-assets-source3-second01-b7-original-decorator-custody-refusal-negative-results-20261105';OUT.mkdir(mode=0o700)
put(OUT,'results.json',dict(status='ROOT_RETAINED_ASSETS_SOURCE3_SECOND01_B7_ORIGINAL_PRECASE_DECORATOR_CLOSURE_REFUSAL',terminal=terminal,newOriginalRoots=t['newOriginalRoots'],originalSupervisorTerminal=None,originalRunnerReport=report,originalRunnerReturnCode=None,originalQualification=None,originalCreatorLineageQualified=False,actualObservedOriginalNodeReceipts=drain['reportedOriginalNodes'],all1185OldOriginalBodiesUnchanged=True,ownTemporaryExplicitlyIncluded=True,rootIndependentlyObservedOriginalProcessAbsence=True,originalFailure=dict(path=str(original_log),sha256=sha(original_log),message="Genuine DefinitionCustody decorator closure assertion refused before original case; actual failed module/member/closure keys not recorded"),actualEagerDefinitionImports=587,retainedPhysicalDefinitions=590,originalSourcePinGuardPassed=True,originalDefinitionGuardPassed=False,originalFailedDecoratorModule=None,originalFailedDecoratorMember=None,originalFailedClosureKeys=None,phaseAdmission=None,normalAction2Qualified=False,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(OUT,'actual-receipt-references.json',refs);put(OUT,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in OUT.iterdir()}));print(json.dumps(dict(freeze=sha(OUT/'freeze.json'),results=sha(OUT/'results.json'),references=len(refs))))
