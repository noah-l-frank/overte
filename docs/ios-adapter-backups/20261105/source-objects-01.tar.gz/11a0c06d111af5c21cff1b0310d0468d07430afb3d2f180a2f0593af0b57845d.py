"""One fixed60+kill5 Root-owned passive attribution run, never a feature test."""
from pathlib import Path
import json,os,stat,subprocess,sys,tempfile,time
from profile_metadata import HERE,REPO,frozen,group,originals,pin,process,save,sources,prior_originals
value=frozen();approved=json.loads((HERE/'actual-source-map.json').read_text());ready_pin=pin(HERE/'actual-source-map.json')
assert approved['status']=='ACTUAL_CURRENT_DIAGNOSTIC_SOURCE_MAP'
assert not (HERE/'root-profile-report.json').exists() and not (HERE/'root-profile-first.log').exists(),'No unchanged repeat'
before=sources(value);assert before==approved['sourcePins'];old=originals(value);prior_before=prior_originals(value)
save(HERE/'root-profile-source-before.json',before);save(HERE/'root-profile-originals-before.json',old)
runs=HERE/'runs';runs.mkdir(mode=0o700,exist_ok=True)
output=Path(tempfile.mkdtemp(prefix='first-',dir=runs));output.chmod(0o700)
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='tests/device:tests/device/self_tests:tests/device/ios/self_tests',OVERTE_TABLET_ROOT328_PROFILE_ROOT=str(output))
command=['timeout','--signal=TERM','--kill-after='+str(value['killAfterSeconds'])+'s',str(value['outerInitialSeconds'])+'s',sys.executable,str(HERE/'profile-saved-once.py')]
print('SOURCE_LAUNCHER_PINS',len(before),flush=True);started=time.monotonic()
with (HERE/'root-profile-first.log').open('x') as log:
    task=subprocess.Popen(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    binding=process(task.pid);assert binding is not None and binding['session']==task.pid and binding['processGroup']==task.pid
    save(HERE/'root-profile-process-binding.json',dict(supervisor=process(os.getpid()),task=binding,command=command))
    print('ACTUAL_PROCESS',json.dumps(binding,sort_keys=True),flush=True);code=task.wait()
after=sources(value);save(HERE/'root-profile-source-after.json',after)
def owned():
    found=group(task.pid,task.pid);runnerpath=output/'runner-process-binding.json'
    if runnerpath.exists():
        runner=json.loads(runnerpath.read_text());current=process(runner['pid'])
        if current is not None and current['startTicks']==runner['startTicks'] and current not in found:found.append(current)
    return found
remaining_before=owned();prior_after=prior_originals(value);first=originals(value);save(HERE/'root-profile-originals-first.json',first)
second=originals(value);save(HERE/'root-profile-originals-second.json',second);remaining_after=owned()
result=dict(exitCode=code,seconds=time.monotonic()-started,outputRoot=str(output),sourcePins=len(after),allPinsEqual=before==after,
    readyMapUnchanged=pin(HERE/'actual-source-map.json')==ready_pin,all1113OriginalsUnchanged=old==first==second,
    ownedProcessesBeforeCensuses=remaining_before,remainingOwnedProcesses=remaining_after,postStopCensusesQualified=not remaining_before and not remaining_after,
    priorOriginalsUnchanged=prior_before==prior_after,diagnosticOnly=True,performanceQualified=False,completeInstalledAPI60Closure=False,nativeExecuted=False,sdkExecuted=False,inputExecuted=False,wholeQualified=False)
save(HERE/'root-profile-report.json',result);print('ACTUAL_TERMINAL',json.dumps(result,sort_keys=True),flush=True)
assert before==after and pin(HERE/'actual-source-map.json')==ready_pin and old==first==second and prior_before==prior_after and not remaining_before and not remaining_after
raise SystemExit(code)
