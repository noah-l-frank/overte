"""Test-gated original Python keeper Stop/OS/SDK retirement producers.

Only actual source-local owners, SDK objects, Tasks, sockets and original close
receivers supply custody. A JSON header or provider exit alone retires nothing.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,gc,inspect,threading,time,uuid,os
from copy import deepcopy
from contextlib import suppress
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need,number
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import identifier
from ios.adapters.lifecycle_checkpoint_index import LifecycleCheckpointIndex

PROFILE='ios-original-keeper-process-end-v1'
FAMILIES={'lifecycle':('primary','actor'),'audioonce':('actor',),'audiowhole':('primary',),'avatar':('primary','actor'),'audioreceived':('actor',)}


def point():return dict(epochMs=time.time()*1000,monotonicMs=time.monotonic()*1000)


class ProviderCustody:
    def __init__(self,end):
        from pymobiledevice3.dtx_service_provider import DtxServiceProvider,ORIGINAL_KEEPER_RESOURCE_OBSERVER
        self.end,self.kind=end,DtxServiceProvider;self.rows=[];self.context=ORIGINAL_KEEPER_RESOURCE_OBSERVER
        self.functions=tuple((DtxServiceProvider,name,getattr(DtxServiceProvider,name),getattr(DtxServiceProvider,name).__code__)
            for name in ('__init__','connect','close','__aenter__','__aexit__'))
        # Existing WDA providers were genuinely born before this optional end
        # protocol. Retain their ACTUAL current objects/DTX, not a new factory.
        for value in gc.get_objects():
            if isinstance(value,DtxServiceProvider)and getattr(value,'_dtx',None)is not None:
                need(value.lockdown is end.rsd)
                need(value._original_resource_observer in (None,self));value._original_resource_observer=self
                self.born(value);self.opened(value)

    def guard(self):
        self.end.identity()
        for cls,name,function,code in self.functions:need(getattr(cls,name)is function and function.__code__ is code)

    def row(self,provider):
        rows=[row for row in self.rows if row['provider']is provider];need(len(rows)==1);return rows[0]

    def born(self,provider):
        self.guard();need(isinstance(provider,self.kind)and provider.lockdown is self.end.rsd and provider._owns_dtx is True)
        if not any(row['provider']is provider for row in self.rows):
            self.rows.append(dict(id=uuid.uuid4().hex,provider=provider,dtx=None,reader=None,writer=None,socket=None,innerCloseReturned=False))

    def before(self,provider):
        self.guard();row=self.row(provider);need(provider._original_resource_observer is self)
        if row['dtx']is not None:need(provider._dtx in (row['dtx'],None))

    def opened(self,provider):
        self.before(provider);row=self.row(provider);dtx=provider._dtx;need(dtx is not None and dtx._reader_task is not None)
        if row['dtx']is None:
            need(dtx._reader_task.get_loop()is self.end.loop and not dtx._reader_task.done()and not dtx._writer.is_closing())
            row.update(dtx=dtx,reader=dtx._reader_task,writer=dtx._writer,socket=dtx._writer.get_extra_info('socket'))
        else:need(row['dtx']is dtx)

    def dtx_returned(self,provider,dtx):
        self.before(provider);row=self.row(provider);need(row['dtx']is dtx);row['innerCloseReturned']=True

    async def closed(self):
        self.guard();await asyncio.sleep(0);result=[]
        for row in self.rows:
            provider,dtx,reader,writer=row['provider'],row['dtx'],row['reader'],row['writer']
            need(dtx is not None and reader is not None and writer is not None and row['innerCloseReturned']
                and provider._dtx is None and dtx._closed and dtx._disconnected.is_set()and reader.done()
                and not dtx._channels and not dtx._services and not dtx._pending_replies
                and all(future.done()for future in dtx._pending_outgoing_replies)and writer.is_closing())
            await writer.wait_closed();sock=row['socket'];need(sock is not None and sock.fileno()==-1)
            result.append(dict(id=row['id'],providerSlotCleared=True,originalDtxCloseAwaitReturned=True,
                originalReaderTaskDone=True,originalWriterWaitClosedReturned=True,originalSocketFd=-1,
                channels=0,services=0,pendingReplies=0,pendingOutgoingReplies=0))
        need(result);return result


class OriginalKeeperProcessEndSource:
    def __init__(self,owner,args,session,owner_type,source_type):
        exact(args,{'originalProcessEndVersion','binding','runId','roles','profileKey','resultsDirectory','origin','operationId','stage'})
        need(type(args['originalProcessEndVersion'])is int and args['originalProcessEndVersion']==1
            and type(owner)is owner_type and type(owner.source)is source_type and args['profileKey']in FAMILIES
            and type(args['stage'])is int and args['stage']in ((0,1)if args['profileKey']=='audiowhole'else (0,))
            and type(args['roles'])is list and args['roles']and len(set(args['roles']))==len(args['roles'])
            and set(args['roles'])<=set(FAMILIES[args['profileKey']]))
        self.owner,self.source,self.loop=owner,owner.source,asyncio.get_running_loop();self.owner_type,self.source_type=owner_type,source_type
        self.stage=args['stage'];self.binding,self.run=deepcopy(context(args['binding'])),identifier(args['runId']);need(self.binding['sessionId']==session)
        self.claim=owner.session;need(self.claim is not None and self.claim['sessionId']==session and self.loop is self.source._loop)
        self.instance,self.session,self.args=owner.instance,session,deepcopy(args);self.rsd=owner.scope(session)
        self.original_time=time;self.epoch_function=time.time;self.monotonic_function=time.monotonic;self.point_function=point;self.point_code=point.__code__
        self.operation_id=identifier(args['operationId']);self.main_thread=threading.current_thread();self.original_threads=tuple(threading.enumerate())
        self.wda=owner.wda;need(isinstance(self.wda,asyncio.Task)and self.wda.get_loop()is self.loop)
        self.creator=self.source._creator_task();need(isinstance(self.creator,asyncio.Task)and self.creator.get_loop()is self.loop)
        self.graph=tuple(ref()for ref in self.source._source._refs);need(all(value is not None for value in self.graph))
        self.tunnel=self.source._tunnel();need(self.tunnel is not None)
        objects=(*self.graph[1:-1],self.rsd.service,self.source._source._authentication,self.tunnel)
        self.sdk_receivers=[]
        for obj in objects:
            for name in ('close','aclose','__aexit__'):
                method=getattr(obj,name,None)
                if method is not None and hasattr(method,'__func__'):
                    self.sdk_receivers.append((obj,name,method.__func__,method.__func__.__code__))
        self.lock=ScriptSourceLock(owner.state_root/'script-feature-sources.lock')
        self.store=PrivateFeatureState(owner.state_root/('ios-original-process-end-'+self.run+'-'+str(self.stage)+'.json'))
        self.previous=None;self.state=dict(phase='planned',records=[],pending=None,cutoff=None,stop=None,
            windows={role:[]for role in args['roles']},sdk=None,creatorIntent=None)
        with self.lock.held():need(self.store.read()is None)
        self.files=OriginalFrameStore(owner.state_root,self.binding,self.run,'primary',self.bound,self.intent,
            namespace=('original-keeper-end'if self.stage==0 else 'original-keeper-end-next'),schema_prefix='iosOriginalKeeperEnd',kind='sources')
        self.index=LifecycleCheckpointIndex(self.files,self.save)
        self.receivers=tuple((obj,name,getattr(obj,name),getattr(obj,name).__func__.__code__)
            for obj,names in ((owner,('process','fresh_touch_scope')),(self.source,('current','settle_touches','original_control_tasks')))for name in names)
        self.end_type=type(self);self.methods=tuple((name,function,function.__code__)for name,function in self.end_type.__dict__.items()if inspect.isfunction(function))
        self.providers=ProviderCustody(self)
        self.context_token=self.providers.context.set(self.providers)

    def identity(self):
        self.index.guard();need(time is self.original_time and time.time is self.epoch_function and time.monotonic is self.monotonic_function
            and point is self.point_function and point.__code__ is self.point_code)
        need(type(self.owner)is self.owner_type and type(self.source)is self.source_type and self.owner.source is self.source
            and self.owner.instance==self.instance and self.owner.session is self.claim and self.claim['sessionId']==self.session
            and asyncio.get_running_loop()is self.loop and self.loop is self.source._loop and self.owner.wda is self.wda)
        need(type(self)is self.end_type and self.end_type is OriginalKeeperProcessEndSource)
        for name,function,code in self.methods:need(getattr(self.end_type,name)is function and function.__code__ is code)
        for obj,name,bound,code in self.receivers:
            current=getattr(obj,name);need(current.__self__ is obj and current.__func__ is bound.__func__ and bound.__func__.__code__ is code)
        for obj,name,function,code in self.sdk_receivers:
            need(getattr(obj,name).__func__ is function and function.__code__ is code)

    def bound(self):
        self.identity();self.lock.assert_held();need(same(self.store.read(),self.previous))
        expected={self.files.path(self.files.expand(ref))for ref in self.state['records']}
        pending=self.state['pending']
        if pending is not None and pending['file']is not None and pending['file']['phase']!='planned':expected.add(self.files.path(pending['file']))
        need(set(self.owner.state_root.glob(self.files.namespace+'-frame-sources-'+self.run+'-primary-*.json'))==expected);return True

    def save(self):
        self.bound();state={key:deepcopy(value)for key,value in self.state.items()if key not in ('records','windows')}
        state['windows']={role:[ref['index']for ref in references]for role,references in self.state['windows'].items()}
        value=dict(iosOriginalKeeperEndOwnerVersion=2,binding=self.binding,runId=self.run,ownerInstance=self.instance,
            profileKey=self.args['profileKey'],roles=self.args['roles'],checkpointIndex=self.index.snapshot(),state=state)
        self.store.write(value,self.previous);self.previous=deepcopy(value)

    def intent(self,kind,value):
        need(self.state['pending']is not None)
        if kind=='manifest':
            need(self.state['pending']['file']is not None and self.state['pending']['file']['phase']=='saved');self.index.intent(value);return
        need(kind=='original');self.files.original(value);pending=self.state['pending'];old=pending['file']
        need(value['index']==pending['index'])
        if old is None:need(value['phase']=='planned')
        else:need(all(same(old[k],value[k])for k in old if k not in ('phase','file'))and (old['phase'],value['phase'])in (('planned','opened'),('opened','saved')))
        pending['file']=deepcopy(value);self.save()

    def plan(self,kind,role=None):
        self.identity();self.providers.guard();need(self.state['pending']is None)
        self.providers.context.set(self.providers)
        for obj,name,bound,code in self.receivers:need(getattr(obj,name).__func__ is bound.__func__ and bound.__func__.__code__ is code)
        with self.lock.held():
            self.state['pending']=dict(index=len(self.state['records'])+1,kind=kind,role=role,operationId=identifier(self.operation_id),file=None);self.save()

    def retain(self,value):
        self.identity();pending=self.state['pending'];need(pending is not None)
        with self.lock.held():
            reference=self.files.write(pending['index'],dict(kind=pending['kind'],role=pending['role'],operationId=pending['operationId'],original=value))
            self.index.append(reference);self.state['records'].append(reference)
            kind,role=pending['kind'],pending['role']
            if kind=='os':self.state['windows'][role].append(reference)
            else:self.state[{'cutoff':'cutoff','stop':'stop','sdk':'sdk'}[kind]]=reference
            self.state['phase']={'cutoff':'armed','stop':'stopped','os':'observing','sdk':'sdk-closed'}[kind]
            self.state['pending']=None;self.save();return reference

    def result(self,reference):
        return dict(iosOriginalKeeperEndReferenceVersion=1,ownerInstance=self.instance,binding=self.binding,runId=self.run,
            reference=deepcopy(reference),profile=PROFILE)

    async def arm(self):
        self.plan('cutoff')
        from ios.adapters.lifecycle_current_collector import OriginalLifecycleCurrent
        current=self.owner._lifecycle_current.get('primary')
        args=dict(nativeCurrentObservationVersion=1,binding=self.binding,runId=self.run,role='primary',ticket=uuid.uuid4().hex,
            resultsDirectory=self.args['resultsDirectory'],origin=self.args['origin'],expectedOwnerInstance=self.instance)
        if current is None:
            current=OriginalLifecycleCurrent(self.owner,args,self.session,self.owner_type,self.source_type,lambda:time.time()*1000)
            self.owner._lifecycle_current['primary']=current
        need(type(current)is OriginalLifecycleCurrent and current.binding==self.binding and current.run==self.run)
        returned=await current.acquire(args,self.session)
        with current.lock.held():frame=current.files.read(current.files.expand(returned['reference']))
        self.cutoff=deepcopy(frame);native=frame['current']['clockJoin']['nativeAfter']
        reference=self.retain(dict(iosOriginalKeeperCutoffVersion=1,source=PROFILE,binding=self.binding,runId=self.run,
            ownerInstance=self.instance,nativeFeatureInstance=native['instance'],reference=deepcopy(returned['reference']),original=frame))
        return self.result(reference)

    async def sample(self,role):
        need(role in self.state['windows']and self.state['phase']in ('stopped','observing'))
        need(len(self.state['windows'][role])<128)
        self.plan('os',role);before=point();pid=int(self.binding['processIdentity'])
        # Both native numeric PID checks AND independent bundle lookups come
        # from the SAME original RSD, through a newly awaited DVT provider.
        value=await self.owner.process(self.claim['archiveBundleId'],pid);after=point()
        need(after['epochMs']-before['epochMs']<1500 and after['monotonicMs']-before['monotonicMs']<1500)
        reference=self.retain(dict(iosOriginalKeeperOSVersion=1,binding=self.binding,runId=self.run,role=role,ownerInstance=self.instance,
            nativeFeatureInstance=self.cutoff['current']['clockJoin']['nativeAfter']['instance'],processId=pid,
            source='pmd-original-rsd-dvt',clockDomain='python-original-keeper-host',before=before,after=after,process=value))
        return self.result(reference)

    async def stop(self):
        need(self.state['phase']=='armed');self.plan('stop');pid=int(self.binding['processIdentity']);before=point()
        anchor=await self.owner.process(self.claim['archiveBundleId'],pid)
        need(anchor['bundlePids']==[pid,pid]and anchor['pidChecks']==[True,True])
        from pymobiledevice3.services.dvt.instruments.dvt_provider import DvtProvider
        from pymobiledevice3.services.dvt.instruments.process_control import ProcessControl
        # No caller PID, bundle or second creator. The exact current bundle
        # PID was independently measured above and equals the native cutoff.
        provider=DvtProvider(self.rsd)
        async with provider:
            async with ProcessControl(provider)as control:
                need(await control.process_identifier_for_bundle_identifier(self.claim['archiveBundleId'])==pid)
                clock=self.cutoff['current']['clockJoin'];now=point()
                need(0<=now['epochMs']-clock['hostBeforeEpochMs']<1500
                    and 0<=now['monotonicMs']/1000-clock['hostBeforeMonotonic']<1.5)
                await control.kill(pid)
        reference=self.retain(dict(iosOriginalKeeperStopVersion=1,binding=self.binding,runId=self.run,ownerInstance=self.instance,
            processId=pid,nativeFeatureInstance=self.cutoff['current']['clockJoin']['nativeAfter']['instance'],before=before,after=point(),anchor=anchor,killAwaitReturned=True))
        return self.result(reference)

    def quiet(self,role):
        with self.lock.held():rows=[self.files.read(self.files.expand(ref))['original']for ref in self.state['windows'][role]]
        suffix=[]
        for row in rows:
            absent=row['process']['bundlePids']==[0,0]and row['process']['pidChecks']==[False,False]
            contiguous=not suffix or all(0<=row['before'][key]-suffix[-1]['after'][key]<1500 for key in ('epochMs','monotonicMs'))
            if not absent:suffix=[]
            elif contiguous:suffix.append(row)
            else:suffix=[row]
        need(3<=len(suffix)<=128)
        now=point();need(all(0<=now[key]-suffix[-1]['after'][key]<1500 for key in ('epochMs','monotonicMs')))
        a,b=suffix[0]['after'],suffix[-1]['before'];need(3000<=min(b['epochMs']-a['epochMs'],b['monotonicMs']-a['monotonicMs'])<30000)

    def status(self,operation_id):
        self.identity();identifier(operation_id)
        with self.lock.held():
            self.bound();records=[]
            for reference in self.state['records']:
                row=self.files.read(self.files.expand(reference))
                if row['operationId']==operation_id:records.append(dict(operationId=row['operationId'],kind=row['kind'],role=row['role'],reference=deepcopy(reference)))
            need(len(records)<=1)
            return dict(iosOriginalKeeperEndStatusVersion=1,profile=PROFILE,ownerInstance=self.instance,binding=self.binding,
                runId=self.run,records=records,pending=deepcopy(self.state['pending']),phase=self.state['phase'])

    async def close_sdk(self):
        if self.state['phase']=='sdk-closed':return self.result(self.state['sdk'])
        for role in self.state['windows']:self.quiet(role)
        self.plan('sdk');source=self.source;owner=self.owner
        await source.settle_touches()
        if owner.wda is not None:
            owner.wda_stop.set();await asyncio.shield(owner.wda);need(owner.wda.done()and not owner.wda.cancelled()and owner.wda.exception()is None)
        # The WDA runner belongs to this same original creator and is stopped
        # before its RSD/authentication graph is actually closed.
        await owner.process(self.claim['wdaBundleId'],terminate=True)
        owner.draining=True;current=asyncio.current_task()
        for task in tuple(owner.operations):
            if task is not current:await asyncio.shield(task)
        raw=source._source;refs=tuple(ref()for ref in raw._refs);need(all(left is right for left,right in zip(refs,self.graph)))
        loop,provider,lockdown,client,tun,dial,rsd,stack=refs;need(loop is self.loop and rsd is self.rsd)
        tunnel=source._tunnel();need(tunnel is not None and raw._owner()is tunnel and tunnel._source is raw)
        writer=rsd.service._writer;auth_writer=raw._authentication._writer();proxy_writer=provider._service.writer
        watcher=tunnel._transport_watcher;server=dial._server;relay_tasks=tuple(dial._relay_tasks)
        need(server is not None and server.is_serving());listener_sockets=tuple(server.sockets);need(listener_sockets)
        original_sockets=tuple(value.get_extra_info('socket')for value in (writer,auth_writer,proxy_writer));need(all(sock is not None for sock in original_sockets))
        tun._original_retirement_watch=dict(stackStopReturned=False,stackStopFailed=False)
        # Keep actual original SDK task identities before teardown; later SDK
        # tasks not in this set must also be gone from the loop census.
        def sdk_task(task):
            coro=task.get_coro();code=getattr(coro,'cr_code',None)or getattr(coro,'gi_code',None)
            return code is not None and any(name in code.co_filename for name in ('/pymobiledevice3/','/pmd_pytcp/'))
        tasks=tuple(task for task in asyncio.all_tasks(self.loop)if task is not current and sdk_task(task))
        close=tunnel.aclose;function,code=close.__func__,close.__func__.__code__
        await close();need(close.__func__ is function and function.__code__ is code)
        if watcher is not None:
            with suppress(asyncio.CancelledError):await watcher
        for original in (writer,auth_writer,proxy_writer):
            need(original is not None and original.is_closing());await original.wait_closed()
        await server.wait_closed();need(not server.is_serving()and all(sock.fileno()==-1 for sock in listener_sockets))
        provider_rows=await self.providers.closed();await asyncio.sleep(0)
        controls=source.original_control_tasks();control_tasks=tuple(row['task']for row in controls)
        need(all(task in (current,self.creator,*control_tasks)for task in asyncio.all_tasks(self.loop)if not task.done()))
        executor=getattr(self.loop,'_default_executor',None)
        if executor is not None:await self.loop.shutdown_default_executor()
        executor_threads=()if executor is None else tuple(executor._threads)
        need(all(not thread.is_alive()for thread in executor_threads)and threading.enumerate()==[self.main_thread])
        need(tun._original_retirement_watch==dict(stackStopReturned=True,stackStopFailed=False)
            and tun._closed and tun._peer.fileno()==tun._pend.fileno()==-1 and all(sock.fileno()==-1 for sock in original_sockets)
            and dial._closing and dial._server is None and not dial._relay_tasks and not dial._inflight_dials
            and rsd.service._writer is None and rsd.service._reader is None and lockdown._validated_session_source is None
            and tunnel._source is None and tunnel._exit_stack is None and tunnel.rsd is None and tunnel.tun is None
            and (watcher is None or watcher.done())and all(task.done()for task in (*tasks,*relay_tasks))
            and not any(sdk_task(task)for task in asyncio.all_tasks(self.loop)if task is not current and not task.done()))
        services=[]
        for service,close,task,loop,closed,lock in (*source._native_reads,*source._lifecycle_current_reads):
            need(loop is self.loop and task.done()and closed.is_set()and close.__self__ is service
                and service._service is None and service._afc_reader_task is None and not service._afc_pending)
            services.append(dict(originalCloseReturned=True,originalTaskDone=True,serviceSlotCleared=True,readerSlotCleared=True,pending=0))
        threads=[]
        for row in (*source._native_queries,*source._lifecycle_current_queries):
            task,thread,finished,loop=row;need(loop is self.loop and finished.is_set()and not thread.is_alive());threads.append(dict(finished=True,alive=False))
        reference=self.retain(dict(iosOriginalKeeperSDKCloseVersion=1,binding=self.binding,runId=self.run,ownerInstance=self.instance,
            source=PROFILE,nativeFeatureInstance=self.cutoff['current']['clockJoin']['nativeAfter']['instance'],
            providers=provider_rows,originalWdaTaskReturned=True,originalWatcherDone=watcher is None or watcher.done(),
            originalRelayTasksDone=all(task.done()for task in relay_tasks),originalSDKTasksDone=all(task.done()for task in tasks),
            originalHTTPThreads=threads,originalAFCServices=services,originalExecutorThreadsDone=all(not thread.is_alive()for thread in executor_threads),
            originalThreadCensusOnlyControl=True,originalRemainingTaskCensusOnlyControlAndEnd=True,
            originalControlTasks=[dict(kind=row['name'],id=row['id'],originalCreatorRegistered=True,originalReceiverCodeBound=True,
                originalLoopBound=True,done=row['task'].done())for row in controls],rsdWriterWaitClosedReturned=True,authenticationWriterWaitClosedReturned=True,
            proxyWriterWaitClosedReturned=True,relayListenerClosed=not server.is_serving(),originalRelayListenerWaitClosedReturned=True,
            originalListenerSocketFds=[sock.fileno()for sock in listener_sockets],
            stackStopReturned=True,originalStreamSocketFds=[sock.fileno()for sock in original_sockets],tunSocketFds=[tun._peer.fileno(),tun._pend.fileno()],sourceSlotCleared=True,
            resourceRetirementEstablished=True,canonicalSessionDeleted=False))
        return self.result(reference)

    def creator_intent(self,args):
        self.identity();exact(args,{'binding','runId','stage','sdkReference'})
        need(args['binding']==self.binding and args['runId']==self.run and type(args['stage'])is int and args['stage']==self.stage
            and args['sdkReference']==self.state['sdk']and self.state['phase']=='sdk-closed'and self.state['pending']is None)
        with self.lock.held():
            self.bound();sdk=self.files.read(self.files.expand(self.state['sdk']))['original']
            need(sdk['resourceRetirementEstablished']is True and sdk['canonicalSessionDeleted']is False)
            value=dict(iosOriginalKeeperCreatorExitIntentVersion=1,profile=PROFILE,binding=self.binding,runId=self.run,stage=self.stage,
                ownerInstance=self.instance,profileKey=self.args['profileKey'],keeperProcessId=os.getpid(),sdkReference=deepcopy(self.state['sdk']),
                nativeFeatureInstance=sdk['nativeFeatureInstance'],providerResourcesSha256=digest(sdk))
            if self.state['creatorIntent']is None:self.state['creatorIntent']=deepcopy(value);self.save()
            else:need(same(self.state['creatorIntent'],value))
            return deepcopy(value)

    def read(self,reference,offset):
        self.identity();need(reference in self.state['records']and type(offset)is int and offset>=0)
        import base64
        from adapters.script_feature.history import canonical
        with self.lock.held():
            value=self.files.read(self.files.expand(reference));body=dict(iosOriginalKeeperEndFrameVersion=1,kind='sources',binding=self.binding,
                runId=self.run,role='primary',index=reference['index'],frame=value);raw=canonical(body)
        need(len(raw)==reference['bytes']and offset<len(raw));return dict(reference=reference,offset=offset,contentBase64=base64.b64encode(raw[offset:offset+4096]).decode())
