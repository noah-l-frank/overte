"""Prospective first-action ownership controls, not Assets/End qualification.

Original QML/Node/file/HTTP and typed source owners remain genuine fixture
constructors. Qt/SDK/native/render/domain propagation are explicit models.
No body has been run; no new clock, resource or outer-cap allowance is granted.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import unittest
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from adapters.script_feature.history import same,unpack
from ios.adapters.assets_checkpoint_owned_originals import AssetsCheckpointOriginalOwnership,AssetsCheckpointOwnedArchive
from ios.self_tests.assets_checkpoint_owned_fixture import Fixture,CheckpointEndpoint


class AssetsCheckpointOwnedOriginalTests(unittest.TestCase):
    def setUp(self):
        self.f=Fixture(self);self.f.ordinary_input(1)

    def acquire(self,role='primary'):
        self.f.driver.observe_current(role)
        observer=self.f.driver.observers[(1,role)]
        return observer,AssetsCheckpointOriginalOwnership(observer)

    def source_calls(self):
        return dict(inputs=deepcopy(self.f.boundary.inputs),
            replies=deepcopy(self.f.boundary.reads.requests),peerReplies=deepcopy(self.f.peer_reads.requests),
            endpoints={str(key):deepcopy(endpoint.queries)for key,endpoint in self.f.scene_endpoints.items()})

    def test_existing_current_originals_are_durably_owned_without_new_acquisition_or_end(self):
        observer,ownership=self.acquire();before=self.source_calls();archive=AssetsCheckpointOwnedArchive(ownership)
        value=archive.freeze();self.assertEqual(before,self.source_calls())
        self.assertEqual(value,archive.original());self.assertEqual(before,self.source_calls())
        self.assertNotIn('state',value);self.assertNotIn('currentCohort',value)
        self.assertFalse(value['publicObservationReady']);self.assertFalse(value['metadataRetirementAllowed'])
        self.assertEqual(str(observer.ui.store.path),value['cohortOriginalReferences']['ui']['path'])
        self.assertTrue(set(value['componentNamespacePaths'])<=set(value['actualReadPaths']))
        self.assertTrue(all(type(endpoint)is CheckpointEndpoint for endpoint in self.f.scene_endpoints.values()))
        self.assertFalse(archive.retirement_manifest()['performed'])
        with self.assertRaises(NativeUIError):archive.retire()
        self.assertEqual(0,len(self.f.a.owner.state['records']))

    def test_actor_original_ownership_keeps_separate_actual_node_and_peer_sources(self):
        _left,left=self.acquire();_right,right=self.acquire('actor');before=self.source_calls()
        a=AssetsCheckpointOwnedArchive(left).freeze();b=AssetsCheckpointOwnedArchive(right).freeze()
        self.assertEqual(before,self.source_calls());self.assertEqual('primary',a['role']);self.assertEqual('actor',b['role'])
        self.assertIsNone(a['cohortOriginalReferences']['peerScene']);self.assertIsNotNone(b['cohortOriginalReferences']['peerScene'])
        self.assertNotEqual(a['cohortOriginalReferences']['ui']['path'],b['cohortOriginalReferences']['ui']['path'])
        self.assertNotEqual(a['sourceBinding']['processIdentity'],b['sourceBinding']['processIdentity'])
        self.assertFalse(b['externalConsumersComplete'])

    def test_lost_real_complete_ofs_return_reopens_saved_inode_without_query_or_replay(self):
        _observer,ownership=self.acquire();archive=AssetsCheckpointOwnedArchive(ownership);original=archive.originals.write;calls=[]
        def lost(index,value):
            reference=original(index,value);calls.append(deepcopy(reference));raise OSError('Lost complete OFS return')
        before=self.source_calls()
        with patch.object(archive.originals,'write',lost):
            with self.assertRaises(OSError):archive.freeze()
        pending=deepcopy(archive.state['pending']);self.assertEqual('saved',pending['phase'])
        path=archive.originals.path(pending);inode=path.stat().st_ino;raw=path.read_bytes()
        reopened=AssetsCheckpointOwnedArchive(ownership);value=reopened.freeze()
        self.assertEqual(1,len(calls));self.assertEqual(raw,path.read_bytes());self.assertEqual(inode,path.stat().st_ino)
        self.assertEqual(before,self.source_calls());self.assertEqual(value,reopened.original())

    def test_actual_final_parent_cas_failure_latches_same_owner_and_real_saved_recovery(self):
        _observer,ownership=self.acquire();archive=AssetsCheckpointOwnedArchive(ownership);write=archive.store.write;attempts=[]
        def fail(value,previous):
            if unpack(value['payload'])[0]['phase']=='copied':attempts.append(True);raise OSError('Before actual complete CAS')
            return write(value,previous)
        before=self.source_calls()
        with patch.object(archive.store,'write',fail):
            with self.assertRaises(OSError):archive.freeze()
        self.assertEqual([True],attempts);self.assertTrue(archive.failed)
        durable=unpack(archive.store.read()['payload'])[0];self.assertEqual('copying',durable['phase'])
        self.assertEqual('saved',durable['pending']['phase']);path=archive.originals.path(durable['pending'])
        raw=path.read_bytes();inode=path.stat().st_ino
        with self.assertRaises(NativeUIError):archive.original()
        reopened=AssetsCheckpointOwnedArchive(ownership);reopened.freeze()
        self.assertEqual(raw,path.read_bytes());self.assertEqual(inode,path.stat().st_ino);self.assertEqual(before,self.source_calls())

    def test_actual_opened_empty_owned_original_is_retained_and_never_completed_from_ram(self):
        _observer,ownership=self.acquire();archive=AssetsCheckpointOwnedArchive(ownership);intent=archive.intent
        def stop(event,wire):
            value=intent(event,wire)
            if wire['phase']=='opened':raise OSError('After real opened intent before body write')
            return value
        before=self.source_calls()
        with patch.object(archive.originals,'intent',stop):
            with self.assertRaises(OSError):archive.freeze()
        pending=deepcopy(archive.state['pending']);self.assertEqual('opened',pending['phase'])
        path=archive.originals.path(pending);info=path.stat();self.assertEqual(0,info.st_size)
        reopened=AssetsCheckpointOwnedArchive(ownership)
        with self.assertRaises((NativeUIError,ValueError)):reopened.freeze()
        self.assertEqual((info.st_dev,info.st_ino,0),(path.stat().st_dev,path.stat().st_ino,path.stat().st_size))
        self.assertEqual(before,self.source_calls());self.assertIsNotNone(reopened.state['pending'])

    def test_lost_real_planned_intent_return_reopens_without_adopting_or_overwriting_a_file(self):
        _observer,ownership=self.acquire();archive=AssetsCheckpointOwnedArchive(ownership);intent=archive.intent
        def stop(event,wire):
            value=intent(event,wire)
            if wire['phase']=='planned':raise OSError('After durable plan before original O_EXCL')
            return value
        before=self.source_calls()
        with patch.object(archive.originals,'intent',stop):
            with self.assertRaises(OSError):archive.freeze()
        pending=deepcopy(archive.state['pending']);self.assertEqual('planned',pending['phase'])
        path=archive.originals.path(pending);self.assertFalse(path.exists())
        reopened=AssetsCheckpointOwnedArchive(ownership);reopened.freeze()
        self.assertTrue(path.is_file());self.assertEqual(before,self.source_calls())

    def test_same_bytes_replacement_source_inode_cannot_reanchor_existing_owned_archive(self):
        observer,ownership=self.acquire();archive=AssetsCheckpointOwnedArchive(ownership);archive.freeze()
        ref=observer.ui.originals.expand(observer.ui.state['frames'][-1]);path=observer.ui.originals.path(ref)
        raw=path.read_bytes();before=self.source_calls();path.rename(path.with_name('retained-before-replacement-'+path.name))
        path.write_bytes(raw);path.chmod(0o600)
        with self.assertRaises(NativeUIError):archive.original()
        self.assertEqual(raw,path.read_bytes());self.assertEqual(before,self.source_calls())

    def test_unknown_owned_namespace_file_refuses_and_preserves_its_actual_inode(self):
        _observer,ownership=self.acquire();archive=AssetsCheckpointOwnedArchive(ownership)
        path=archive.root/(archive.originals.namespace+'-frame-inputs-'+archive.run+'-'+archive.role+'-0002-'+('f'*64)+'.json')
        path.touch(mode=0o600,exist_ok=False);info=path.stat();before=self.source_calls()
        with self.assertRaises(NativeUIError):archive.freeze()
        self.assertEqual((info.st_dev,info.st_ino,0),(path.stat().st_dev,path.stat().st_ino,path.stat().st_size))
        self.assertEqual(before,self.source_calls())

    def test_foreign_cohort_reference_cannot_become_an_owned_current_fact(self):
        observer,_ownership=self.acquire();before=self.source_calls()
        observer.last['ui']['path']=str(Path(self.f.selected.context['roles']['actor']['stateRoot'])/'foreign-ui.json')
        with self.assertRaises(NativeUIError):AssetsCheckpointOriginalOwnership(observer)
        self.assertEqual(before,self.source_calls());self.assertEqual(0,len(self.f.a.owner.state['records']))


    def test_real_source_header_read_error_before_complete_cas_latches_and_reopens_saved_original(self):
        observer,ownership=self.acquire();archive=AssetsCheckpointOwnedArchive(ownership)
        # The actual owner performs its real header read. Fault only this
        # genuine PFS read port at the final proposed complete save boundary.
        read=observer.ui.store.read;faults=[]
        class OriginalHeaderReadError(OSError):pass
        def failing_read():
            if archive.state is not None and archive.state['phase']=='copied'and not faults:
                faults.append(True);raise OriginalHeaderReadError('Original checkpoint header read before complete CAS')
            return read()
        before=self.source_calls()
        with patch.object(observer.ui.store,'read',failing_read):
            with self.assertRaises(OriginalHeaderReadError):archive.freeze()
        self.assertEqual([True],faults);self.assertTrue(archive.failed)
        durable=unpack(archive.store.read()['payload'])[0]
        self.assertEqual('copying',durable['phase']);self.assertEqual('saved',durable['pending']['phase'])
        self.assertIsNone(durable['record']);path=archive.originals.path(durable['pending'])
        info=path.stat();raw=path.read_bytes()
        for rejected in(archive.bound,archive.original,archive.freeze):
            with self.assertRaises(NativeUIError):rejected()
        self.assertEqual(before,self.source_calls())
        reopened=AssetsCheckpointOwnedArchive(ownership);value=reopened.freeze()
        self.assertEqual('copied',unpack(reopened.store.read()['payload'])[0]['phase'])
        self.assertEqual((info.st_dev,info.st_ino),(path.stat().st_dev,path.stat().st_ino))
        self.assertEqual(raw,path.read_bytes());self.assertEqual(value,reopened.original())
        self.assertEqual(before,self.source_calls());self.assertFalse(value['wholeEndEligible'])


if __name__=='__main__':unittest.main()
