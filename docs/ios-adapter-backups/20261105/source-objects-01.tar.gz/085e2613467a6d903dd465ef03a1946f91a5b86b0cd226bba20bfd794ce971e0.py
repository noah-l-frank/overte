"""Own original HTTP streams and original ScriptSourceLock for Publisher2.

No native/product/clock verdict is supplied. Actual server resolver metadata
uses the unchanged original Source3 OwnedLoopbacks fence.
"""
from pathlib import Path
import http.client,http.server,os,socket,socketserver,stat,sys,threading
from controller_original_host_ports import OwnedLoopbacks


class PublisherHostCustody:
    def __init__(self):
        self.loopbacks=OwnedLoopbacks();self.created=[];self.clients=[];self.accepted=[];self.listeners=[]
        self.functions=tuple((owner,key,getattr(owner,key),getattr(owner,key).__code__,getattr(owner,key).__globals__)
            for owner,key in((socketserver.TCPServer,'__init__'),(socket,'create_connection'),
                (http.client.HTTPConnection,'connect'),(socket.socket,'accept'),(socketserver.TCPServer,'get_request')))
        self.peer_reader=socket.socket.getpeername
        self.lock=None;self.lock_owners=[];self.lock_rows=[];self.lock_inodes={}

    def fresh(self):
        for owner,key,function,code,namespace in self.functions:
            assert getattr(owner,key)is function and function.__code__ is code and function.__globals__ is namespace
        assert socket.socket.getpeername is self.peer_reader
        self.loopbacks.check()

    def find(self,caller,index):
        unused,unused2,function,code,namespace=self.functions[index]
        while caller is not None:
            if caller.f_code is code and caller.f_globals is namespace:return caller
            caller=caller.f_back
        return None

    def endpoint(self,owner,peer=False):
        return self.loopbacks.endpoint(owner.family,self.peer_reader(owner)if peer else self.loopbacks.socket_class.getsockname(owner))

    def socket(self,event,args,caller):
        self.fresh()
        if event=='socket.__new__':
            owner,family,kind,protocol=args
            assert family in(socket.AF_INET,socket.AF_INET6)and kind==socket.SOCK_STREAM and protocol in(0,socket.IPPROTO_TCP)
            self.created.append(owner)
            server=self.find(caller,0);client=self.find(caller,1);accept=self.find(caller,3)
            if server is not None:
                obj=server.f_locals['self'];address=server.f_locals['server_address']
                assert http.server.HTTPServer in type(obj).__mro__ and self.loopbacks.endpoint(family,address)[1]==0
                self.listeners.append((owner,obj));return
            if client is not None:
                request=self.find(caller,2);assert request is not None
                target=client.f_locals['address'];destination=self.loopbacks.endpoint(family,target)
                assert(family,destination)in self.loopbacks.current_servers()
                connection=request.f_locals['self'];assert http.client.HTTPConnection in type(connection).__mro__
                assert connection._tunnel_host is None and connection.host==destination[0]and connection.port==destination[1]
                self.clients.append(dict(owner=owner,family=family,destination=destination));return
            assert accept is not None
            listener=accept.f_locals['self'];assert any(listener is known for known,unused in self.listeners)
            server_frame=self.find(caller,4);assert server_frame is not None and server_frame.f_locals['self'].socket is listener
            descriptor=accept.f_locals['fd'];info=os.fstat(descriptor);assert stat.S_ISSOCK(info.st_mode)
            peer=self.loopbacks.endpoint(family,accept.f_locals['addr']);destination=self.endpoint(listener)
            matches=[]
            for row in self.clients:
                client_socket=row['owner']
                if client_socket.fileno()<0 or row['family']!=family:continue
                try:
                    if self.endpoint(client_socket)==peer and self.endpoint(client_socket,True)==destination:matches.append(row)
                except OSError:continue
            assert len(matches)==1,'Accepted connection must be the actual still-owned original client'
            self.accepted.append(dict(owner=owner,descriptor=descriptor,device=info.st_dev,inode=info.st_ino,peer=peer,destination=destination));return
        if event=='socket.bind':
            assert any(args[0]is known for known,unused in self.listeners)
        elif event=='socket.connect':
            assert any(args[0]is row['owner']for row in self.clients)
        self.loopbacks.audit(event,args,caller)

    def bind_lock(self,module,fcntl):
        cls=module.ScriptSourceLock;wrapper=cls.held;function=wrapper.__wrapped__
        self.lock=(module,cls,wrapper,wrapper.__code__,function,function.__code__,function.__globals__,
            tuple((cell,cell.cell_contents)for cell in wrapper.__closure__ or ()),fcntl,fcntl.flock)

    def original_lock_frame(self,caller):
        module,cls,wrapper,code,function,fcode,namespace,cells,fcntl,flock=self.lock
        assert sys.modules.get('adapters.script_feature.lock')is module and module.ScriptSourceLock is cls
        assert cls.held is wrapper and wrapper.__code__ is code and wrapper.__wrapped__ is function
        assert function.__code__ is fcode and function.__globals__ is namespace and fcntl.flock is flock
        assert len(wrapper.__closure__ or ())==len(cells)and all(a is cell and a.cell_contents is value for a,(cell,value)in zip(wrapper.__closure__ or (),cells))
        while caller is not None:
            if caller.f_code is fcode and caller.f_globals is namespace:break
            caller=caller.f_back
        assert caller is not None;owner=caller.f_locals['self'];path=caller.f_locals['path']
        assert type(owner)is cls and path==owner.path
        if not any(owner is known for known in self.lock_owners):self.lock_owners.append(owner)
        return caller,owner,path

    def flock(self,args,caller):
        frame,owner,path=self.original_lock_frame(caller);descriptor,operation=args;fcntl=self.lock[8]
        assert descriptor==frame.f_locals['descriptor']and operation==fcntl.LOCK_EX|fcntl.LOCK_NB
        info=os.fstat(descriptor);current=path.lstat()
        assert stat.S_ISREG(info.st_mode)and info.st_nlink==1 and info.st_size==0 and stat.S_IMODE(info.st_mode)==0o600
        assert(info.st_dev,info.st_ino)==(current.st_dev,current.st_ino)
        key=str(path);before=self.lock_inodes.setdefault(key,(info.st_dev,info.st_ino));assert before==(info.st_dev,info.st_ino)
        self.lock_rows.append(dict(path=key,descriptor=descriptor,device=info.st_dev,inode=info.st_ino,receiver=id(owner)))

    def finish(self):
        self.fresh();assert self.listeners and self.clients and self.accepted
        assert all(owner.fileno()==-1 for owner in self.created)
        assert all(owner._owner is None for owner in self.lock_owners)
        for row in self.lock_rows:
            info=Path(row['path']).lstat();assert(info.st_dev,info.st_ino)==(row['device'],row['inode'])
            try:live=os.fstat(row['descriptor'])
            except OSError as error:assert error.errno==9
            else:assert(live.st_dev,live.st_ino)!=(row['device'],row['inode'])
        return dict(socketObjects=len(self.created),listeners=len(self.listeners),clientAttempts=len(self.clients),acceptedOwnStreams=len(self.accepted),
            allActualSocketsClosed=True,originalLockRows=self.lock_rows,allOriginalLockOwnersReleased=True,
            resolver=self.loopbacks.finish(),NativeFacts=False)
