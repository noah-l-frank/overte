"""Source-only stdlib MP variant utility package; no Tablet owner or authority."""
