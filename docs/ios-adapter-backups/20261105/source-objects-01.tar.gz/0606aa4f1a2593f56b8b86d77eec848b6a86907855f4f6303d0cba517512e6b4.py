import ast,hashlib,json,shutil,difflib
from pathlib import Path
R=Path.cwd();D=R/'.ios-host-tmp/emote-callback-live-prefix-external-parser-policy-source-complete-20261102';P=R/'.ios-host-tmp/emote-callback-live-prefix-external-parser-policy-class-closure-20261102'
assert not (P/'freeze.json').exists()
for n in ('base','candidate'):shutil.copytree(D/n,P/n)
rel='tests/device/ios/adapters/emote_callback_live_records.py';q=P/'candidate'/rel;s=q.read_text()
s=s.replace("(ImageMode,'ModeDescriptor'),(ImageMode,'sys'),","(ImageMode,'ModeDescriptor'),(ImageMode,'sys'),(sys,'byteorder'),")
s=s.replace('PngImagePlugin.ChunkStream,ImageStat.Stat)','PngImagePlugin.ChunkStream,ImageStat.Stat,json.JSONDecoder,json.JSONEncoder,functools.cached_property)')
s=s.replace("    return (_token(cls,references,set()),_token(cls.__new__,references,set()),", """    references.append(cls.__bases__)
    # Exact namespace membership catches new call/attribute overrides too;
    # existing generated method code and field descriptor identity are retained.
    methods=tuple((name,_token(value,references,set())) for name,value in sorted(vars(cls).items())
        if type(value) in (FunctionType,staticmethod,classmethod,property))
    return (tuple(sorted(vars(cls))),tuple(id(base) for base in cls.__bases__),methods,_token(cls,references,set()),_token(cls.__new__,references,set()),""")
s=s.replace("            if name.startswith('__') and name not in ('__init__','__new__','__enter__','__exit__','__getattr__'):continue\n            members.append((name,token(value)))", """            # All names participate, including newly added Python call/lookup
            # overrides. Only inherent instance dictionary/weakref descriptors
            # use exact retained identity, never arbitrary descriptor admission.
            if name in ('__dict__','__weakref__'):
                references.append(value);members.append((name,('inherent-descriptor',id(value),type(value).__module__,type(value).__qualname__)))
            else:members.append((name,token(value)))""")
q.write_text(s)
for f in P.rglob('*.py'):ast.parse(f.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((D/'plan.json').read_text());rows=[];diff=[]
for f in sorted((P/'candidate').rglob('*.py')):
 r=f.relative_to(P/'candidate');rows.append(dict(path=str(r),baseSHA256=sha(P/'base'/r),candidateSHA256=sha(f)));diff.extend(difflib.unified_diff((P/'base'/r).read_text().splitlines(True),f.read_text().splitlines(True),fromfile='a/'+str(r),tofile='b/'+str(r)))
old.update(previousDraftFreeze=sha(D/'freeze.json'),sourceRows=rows)
(P/'source.diff').write_text(''.join(diff));shutil.copyfile(D/'actual-old-profile-external-functions.json',P/'actual-old-profile-external-functions.json')
(P/'plan.json').write_text(json.dumps(old,indent=2)+'\n')
files={str(f.relative_to(P)):sha(f) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='freeze.json'}
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_ROOT_SOURCE_REVIEW_REQUIRED',files=files),indent=2)+'\n')
print(json.dumps(dict(freeze=sha(P/'freeze.json'),rows=rows)))
