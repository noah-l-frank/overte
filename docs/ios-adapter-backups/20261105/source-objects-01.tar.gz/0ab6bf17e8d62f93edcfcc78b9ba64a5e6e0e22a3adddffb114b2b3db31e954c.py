"""Genuine Callback8 ordinary prefix to current inactive checkpoint.

Real JS/W3C/UDP/HTTP/PNG and original owner/terminal readers are used. Native,
SDK/Qt/GPU and the existing paired Runtime assembly remain declared models.
No new fake/neutral owner is constructed and Finish remains CLOSED.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import ast,inspect,textwrap,unittest
from adapters.normal_ui import NativeUIError
from feature_journeys.witness import Client
from ios.adapters.emote_runtime import IOSEmoteRuntime
from ios.adapters.emote_terminal import IOSEmoteTerminal
from ios.adapters.emote_rooted_inventory import IOSEmoteRootedInventory
from ios.adapters.emote_callback_inactive import capture as capture_inactive
from ios.adapters.emote_rooted_fence import inactive,inactive_prefixes
from ios.adapters.emote_observer import EmoteObservationPending
from ios.self_tests.emote_callback_terminal_fixture import paired


class CallbackInactiveCheckpointTests(unittest.TestCase):
    def counts(self,f):
        return dict(primary=len(f.target.domain.history),actor=len(f.actor.target.domain.history),
            inputs=deepcopy(f.target.domain.io.actions),actorInputs=deepcopy(f.actor.target.domain.io.actions),
            gpu={role:[deepcopy(q) for slot in target.callback_context.worlds.values() for q in slot.commands]
                for role,target in (('primary',f.target),('actor',f.actor.target))})

    def refused_at(self,f,seal,function,fragment):
        # A deadline or unrelated construction error cannot pass a negative
        # counter. Bind the real originating need() call in its actual source.
        lines,start=inspect.getsourcelines(function);source=textwrap.dedent(''.join(lines))
        candidates=[node for node in ast.walk(ast.parse(source))
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='need'
            and fragment in ''.join(ast.get_source_segment(source,node).split())]
        self.assertEqual(1,len(candidates));node=candidates[0]
        positions=set(range(start+node.lineno-1,start+node.end_lineno))
        try:self.checkpoint(f,seal)
        except NativeUIError as error:
            chain=[error];seen=set();matched=False
            while chain and len(seen)<16:
                current=chain.pop()
                if id(current) in seen:continue
                seen.add(id(current));tb=current.__traceback__
                while tb is not None:
                    if tb.tb_frame.f_code is function.__code__ and tb.tb_lineno in positions:matched=True
                    tb=tb.tb_next
                if current.__cause__ is not None:chain.append(current.__cause__)
                if current.__context__ is not None:chain.append(current.__context__)
            self.assertTrue(matched,'Expected exact original refusal site was not reached')
        else:self.fail('Expected original NativeUIError was not raised')

    def sealed_prefix(self):
        # The unchanged existing paired fixture creates actual Feature8/owner
        # constructors. Its older lower Runtime/native producer assembly is
        # explicit modeling, not a newly fabricated owner or installed SDK.
        f=paired(self);p,a=f.flow,f.actor.flow;reader=Client(f.target.client.url,'r'*64)
        call=dict(contractVersion=16,runId=p.run,afterSequence=0)
        p.observe(call);a.observe(call)
        p.act(f.call('play',name='Crying'))
        # Original modeled delivery progression from the existing normal
        # Callback8 test; no stored/native/capture clock is rebased here.
        f.target.native.sleep(.25)
        self.assertTrue(a.observe(call)['state']['override'])
        p.act(f.call('cancel'));self.assertFalse(a.observe(call)['state']['override'])
        f.call('cleanup');cleanup=dict(contractVersion=16,runId=p.run)
        def waiting(seconds):
            if p.lock._owner is None and p.primary_lock._owner is None:
                self.assertIsNone(a.lock._owner);a.cleanup(cleanup)
            f.target.domain.sleep(seconds)
        p.sleep=waiting
        self.assertEqual(dict(performed=True),p.cleanup(cleanup))
        samples=[]
        for index in range(3):
            primary=p.observe(call);actor=a.observe(call);witness=reader.request('/runs/'+p.run)
            entries=[row for row in witness['entries'] if row['actorSequence']==actor['sequence']]
            self.assertEqual(1,len(entries));samples.append(dict(primary=primary,actor=entries[0]))
            if index<2:f.target.domain.sleep(1.6)
        inspected=p.terminal(dict(contractVersion=16,runId=p.run,stage='inspect'))
        sealed=p.terminal(dict(contractVersion=16,runId=p.run,stage='seal',
            description=inspected['description'],samples=samples))
        return f,reader,sealed['seal']

    def checkpoint(self,f,seal):
        # The new genuine Runtime entry uses its existing typed terminal
        # factory and controller. No source/result/capture method is patched.
        return IOSEmoteRuntime._emote_callback_inactive_checkpoint(f.runtime,f.flow,seal,f.actor.flow)

    def test_actual_normal_play_cancel_cleanup_three_pair_seal_and_http_retirement_join_current_inactive_original(self):
        f,reader,seal=self.sealed_prefix();p,a=f.flow,f.actor.flow
        reader.request('/runs/'+p.run,method='DELETE')
        before=self.counts(f);actual=self.checkpoint(f,seal)
        self.assertEqual(before,self.counts(f))
        self.assertEqual(1,actual['iosEmoteCallbackInactiveCheckpointVersion'])
        self.assertEqual(seal,actual['seal']);self.assertEqual(seal,actual['terminalProof']['seal'])
        self.assertEqual(2,actual['terminalProof']['original']['iosEmoteTerminalWindowVersion'])
        self.assertEqual({'primary','actor'},set(actual['rolePhasePrefixes']))
        self.assertEqual(p.configured_pair,actual['configuredTargetPair'])
        self.assertFalse(actual['phaseOriginal']['active'])
        inactive(actual['phaseOriginal'],run=p.run,instance=actual['phaseInstance'],
            ticket=seal['description']['ticket'],after=actual['completionFloorEpochMs'])
        inactive_prefixes(actual['phaseOriginal'],actual['rolePhasePrefixes'],run=p.run)
        self.assertIsNone(p.lock._owner);self.assertIsNone(a.lock._owner)
        # An inactive checkpoint is not silently accepted as copied-State,
        # fresh native Stop authority, process death or SDK retirement.
        with self.assertRaises(EmoteObservationPending):
            p.terminal(dict(contractVersion=16,runId=p.run,stage='finish',seal=seal))
        self.assertEqual(before,self.counts(f))

    def test_actual_still_active_cleanup_phase_refuses_without_native_acquisition_or_input_replay(self):
        f,reader,seal=self.sealed_prefix();before=self.counts(f)
        self.refused_at(f,seal,IOSEmoteTerminal.window,"status['active']isFalse")
        self.assertEqual(before,self.counts(f))
        self.assertTrue(f.flow.phase.status()['active'])
        self.assertIsNone(f.flow.lock._owner);self.assertIsNone(f.actor.flow.lock._owner)

    def test_foreign_seal_cannot_borrow_actual_inactive_callback_originals(self):
        f,reader,seal=self.sealed_prefix();reader.request('/runs/'+f.flow.run,method='DELETE')
        hostile=deepcopy(seal);hostile['description']['ticket']='f'*32 if seal['description']['ticket']!='f'*32 else'e'*32
        before=self.counts(f)
        self.refused_at(f,hostile,capture_inactive,"same(journal.state['seal'],seal)")
        self.assertEqual(before,self.counts(f))
        self.assertIsNone(f.flow.lock._owner);self.assertIsNone(f.actor.flow.lock._owner)

    def test_new_unknown_current_carrier_after_real_seal_blocks_inactive_checkpoint_without_adoption(self):
        f,reader,seal=self.sealed_prefix();reader.request('/runs/'+f.flow.run,method='DELETE')
        orphan=f.flow.root/'emote-inactive-unowned-obligation.json'
        orphan.write_bytes(b'{}');orphan.chmod(0o600);identity=orphan.stat();before=self.counts(f)
        self.refused_at(f,seal,IOSEmoteRootedInventory.__init__,'found<=reads|owned')
        self.assertEqual(before,self.counts(f));self.assertEqual(b'{}',orphan.read_bytes())
        self.assertEqual((identity.st_dev,identity.st_ino),(orphan.stat().st_dev,orphan.stat().st_ino))
        self.assertIsNone(f.flow.lock._owner);self.assertIsNone(f.actor.flow.lock._owner)


if __name__=='__main__':unittest.main()
