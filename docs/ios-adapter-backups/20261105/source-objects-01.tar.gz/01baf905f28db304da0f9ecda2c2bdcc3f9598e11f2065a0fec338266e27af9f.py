"""Authorized single stdlib-only interrupt/registered cleanup counter."""
from pathlib import Path
import hashlib,json,os,sys,unittest
ROOT=Path(__file__).resolve().parent
ORIGINAL=unittest.TestCase.doCleanups
REFUSALS=[]
def audit(event,args):
    if event.startswith('socket.')or event.startswith('subprocess.')or event in ('os.system','os.exec','os.fork','os.forkpty','os.posix_spawn','ctypes.dlopen'):
        REFUSALS.append(event);raise RuntimeError('Forbidden action in stdlib-only cleanup counter')
    if event=='import'and args[0].split('.')[0]in ('ios','adapters','feature_journeys','pymobiledevice3','appium'):
        REFUSALS.append(event);raise ImportError('Target import forbidden in stdlib-only counter')
    if event=='open':
        path,mode,flags=args
        if isinstance(path,(str,bytes,os.PathLike))and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):
            if not Path(os.fsdecode(path)).absolute().is_relative_to(ROOT):raise RuntimeError('Write outside private counter root')
sys.addaudithook(audit)

class RegisteredCleanupFinallyCase(unittest.TestCase):
    cleanup_receipt=None
    def run(self,result=None):
        try:return super().run(result)
        finally:
            pending=len(self._cleanups);previous=self._outcome;cleanups=unittest.TestResult()
            try:
                if pending:
                    self._outcome=unittest.case._Outcome(cleanups)
                    success=unittest.TestCase.doCleanups(self)
                else:success=True
            finally:self._outcome=previous
            self.cleanup_receipt=dict(pendingBeforeOuterFinally=pending,remaining=len(self._cleanups),success=success,
                errors=cleanups.errors,failures=cleanups.failures,originalFunctionUnchanged=unittest.TestCase.doCleanups is ORIGINAL)

class StdlibCleanupCounter(unittest.TestCase):
    def test_real_keyboard_interrupt_keeps_original_lifo_cleanup_chain_exactly_once(self):
        calls=[]
        class Interrupted(RegisteredCleanupFinallyCase):
            def setUp(inner):
                inner.addCleanup(lambda:calls.append('first'))
                def last():
                    calls.append('last');inner.addCleanup(lambda:calls.append('nested-original'))
                inner.addCleanup(last)
            def test_interrupt(inner):raise KeyboardInterrupt('Actual stdlib-only diagnostic interruption')
        case=Interrupted('test_interrupt');result=unittest.TestResult()
        with self.assertRaises(KeyboardInterrupt):case.run(result)
        self.assertEqual(['last','nested-original','first'],calls)
        self.assertEqual(1,result.testsRun);self.assertEqual([],result.errors);self.assertEqual([],result.failures)
        self.assertEqual(2,case.cleanup_receipt['pendingBeforeOuterFinally']);self.assertEqual(0,case.cleanup_receipt['remaining'])
        self.assertTrue(case.cleanup_receipt['success']);self.assertTrue(case.cleanup_receipt['originalFunctionUnchanged'])
        self.assertTrue(unittest.TestCase.doCleanups(case));self.assertEqual(['last','nested-original','first'],calls)
        self.assertIs(unittest.TestCase.doCleanups,ORIGINAL)
        self.interrupt_receipt=case.cleanup_receipt

if __name__=='__main__':
    case=StdlibCleanupCounter('test_real_keyboard_interrupt_keeps_original_lifo_cleanup_chain_exactly_once')
    result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([case]))
    value=dict(status='PASS'if result.wasSuccessful()and not REFUSALS else'FAIL_OR_ERROR',testsRun=result.testsRun,
        errors=len(result.errors),failures=len(result.failures),auditRefusals=REFUSALS,
        originalCleanupFunctionUnchanged=unittest.TestCase.doCleanups is ORIGINAL,
        originalInterruptCleanup=case.interrupt_receipt if hasattr(case,'interrupt_receipt')else None,
        targetImports=0,targetTests=0,nodeExecutions=0,SDKExecutions=0,normalQualified=False,wholeQualified=False)
    (ROOT/'stdlib-counter-report.json').write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
    print(json.dumps(value),flush=True)
    sys.exit(0 if value['status']=='PASS'else 1)
