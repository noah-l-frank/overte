"""Once cue/pattern custody inside the actual SDK-owned passive child WAL.

No new SDK filename/directory or parallel ownership ledger is introduced.
OriginalFrameStore already persists bytes/inode/manifest and the owning parent
CAS before send. A saved claim intent is never resent, including a lost reply.
Primary input order uses actual paired SDK originals and common host order;
source/ADC/acoustic/peer/native/device/whole qualification stays separate.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import json
import uuid
from adapters.native_clock_join import NativeClockAcquisition,digest,validate_join
from adapters.native_feature_observation import decode,exact,integer,need,number
from adapters.native_script_observation import NativeScriptObservation,validate as script_packet
from adapters.normal_ui import NativeUIError
from adapters.script_feature.history import same
from feature_journeys.phase_fixture import validate as phase_packet
from ios.adapters.audio_api_clock import operation
from ios.adapters import audio_once_cue_source as source
from ios.adapters import audio_once_primary as primary

PROFILE='once-input-causal-capture10-v1'
KINDS=('cue','pattern')
PROOFS=('once-intent','once-reply','once-primary-authorized','once-primary-returned','once-window','once-probe-intent','once-probe')


def initial(ticket):
    return dict(profile=PROFILE,ticket=ticket,inputs={kind:dict(claim=None,last=None,retire=None,release=None) for kind in KINDS},
        primaryAuthorized=None,primaryReturned=None)


def shape(owner):
    value=owner.state['once'];exact(value,{'profile','ticket','inputs','primaryAuthorized','primaryReturned'})
    need(value['profile']==PROFILE and source.input_id(owner.run,value['ticket'],'cue')
        and owner.state['birth'] is not None and owner.state['start'] is not None and owner.state['start']['seconds']==10)
    exact(value['inputs'],set(KINDS))
    limit=owner.state['streams']['proofs']['revision']
    for slot in value['inputs'].values():
        exact(slot,{'claim','last','retire','release'})
        need(all(v is None or integer(v,1,limit) for v in slot.values()))
    need(all(value[key] is None or integer(value[key],1,limit) for key in ('primaryAuthorized','primaryReturned')))


def link(state,value,index):
    kind=value['kind']
    if kind=='once-intent':
        query=value['command'];slot=state['inputs'][query['kind']]
        if query['operation'] in ('claim','retire','release'):
            key=query['operation'];need(slot[key] is None);slot[key]=index
    elif kind=='once-reply':state['inputs'][value['inputKind']]['last']=index
    elif kind=='once-primary-authorized':need(state['primaryAuthorized'] is None);state['primaryAuthorized']=index
    elif kind=='once-primary-returned':need(state['primaryReturned'] is None);state['primaryReturned']=index
    elif kind in ('once-window','once-probe-intent','once-probe'):pass
    else:need(False)


def native_join(owner,value):
    join=validate_join(value['clockJoin'],dict(reply=value['packet']))
    need(join['nativeBefore']['processId']==join['nativeAfter']['processId']==owner.pid
        and join['nativeBefore']['instance']==join['nativeAfter']['instance']==owner.state['instance'])
    for native in (join['nativeBefore'],join['nativeAfter']):
        need(native['requestId'] in owner._query_index and owner._query_index[native['requestId']][0]=='native')
    for packet in (value['phaseBefore'],value['phaseAfter']):
        phase_packet(packet,run=owner.run,area='audio',request=packet['requestId'],epoch=packet['capturedEpochMs'])
    phase_packet(value['phaseAfter'],run=owner.run,area='audio',request=value['phaseAfter']['requestId'],
        epoch=value['phaseAfter']['capturedEpochMs'],previous=value['phaseBefore'])
    need(same(value['phaseBefore']['activations'],value['phaseAfter']['activations']))
    return join


def validate_entry(owner,value,ordinal):
    need(value['kind'] in PROOFS);kind=value['kind'];ticket=owner.state['once']['ticket']
    if kind=='once-probe-intent':
        exact(value,{'kind','command'});query=value['command'];need(query['commandId'] not in owner._query_index)
        exact(query,{'schemaVersion','commandId','action'})
        need(type(query['schemaVersion']) is int and query['schemaVersion']==1 and query['action']=='feature-script-observe'
            and type(query['commandId']) is str and query['commandId'].startswith('ios-') and source.hex32(query['commandId'][4:]))
    elif kind=='once-probe':
        exact(value,{'kind','intent','packet','clockJoin'});need(integer(value['intent'],1,ordinal-1))
        intent=owner.proof(value['intent']);need(intent['kind']=='once-probe-intent')
        join=validate_join(value['clockJoin'],dict(script=value['packet']))
        for native in (join['nativeBefore'],join['nativeAfter']):
            need(native['processId']==owner.pid and native['instance']==owner.state['instance']
                and native['requestId'] in owner._query_index and owner._query_index[native['requestId']][0]=='native')
        script_packet(value['packet'],intent['command']['commandId'],owner.pid,join['nativeAfter']['capturedEpochMs'])
        need(value['packet']['source'].get('sourceIdentityVersion')==1 and value['packet']['source'].get('membershipSourceVersion')==1
            and value['packet']['source']['membership']['complete'])
    elif kind=='once-intent':
        exact(value,{'kind','command','actorBefore','primaryInput','probe','issuedHost'});primary.host(value['issuedHost'])
        query=source.command(value['command'],owner.fixture_url);need(query['commandId'] not in owner._query_index)
        need(query['runId']==owner.run and query['ticket']==ticket and query['instance']==owner.state['instance'])
        slot=owner.state['once']['inputs'][query['kind']]
        if query['operation']=='claim':
            need(slot['claim'] in (None,ordinal) and integer(value['actorBefore'],1,ordinal-1)
                and integer(value['probe'],1,ordinal-1) and owner.proof(value['probe'])['kind']=='once-probe')
            actor=owner.proof(value['actorBefore']);need(actor['kind']=='reply')
            state=actor['packet']['source']['state']
            need(state['owned'] and state['active'] and not state['complete'] and not state['invalid']
                and state['targetBytes']//(state['sampleRate']*state['channels']*2)==10)
            for packet in (actor['phaseBefore'],actor['phaseAfter']):
                need(packet['active'] and packet['activations'][-1]['ticket']==ticket
                    and packet['activations'][-1]['stimulus']['verb']=='record-start')
            need(value['issuedHost']['epochMs']>=actor['clockJoin']['hostAfterEpochMs']
                and value['issuedHost']['monotonic']>=actor['clockJoin']['hostAfterMonotonic'])
            if query['kind']=='cue':need(value['primaryInput'] is None)
            else:
                need(integer(value['primaryInput'],1,ordinal-1));returned=owner.proof(value['primaryInput'])
                need(returned['kind']=='once-primary-returned')
                need(value['issuedHost']['epochMs']>=returned['value']['returnedHost']['epochMs']
                    and value['issuedHost']['monotonic']>=returned['value']['returnedHost']['monotonic'])
        else:
            need(slot['claim'] is not None and slot['claim']<ordinal and value['actorBefore'] is value['primaryInput'] is value['probe'] is None)
            if query['operation'] in ('retire','release'):need(slot[query['operation']] in (None,ordinal))
    elif kind=='once-reply':
        exact(value,{'kind','inputKind','intent','packet','clockJoin','phaseBefore','phaseAfter'})
        need(value['inputKind'] in KINDS and integer(value['intent'],1,ordinal-1))
        intent=owner.proof(value['intent']);need(intent['kind']=='once-intent' and intent['command']['kind']==value['inputKind'])
        join=native_join(owner,value);source.validate(value['packet'],intent['command'],owner.pid,owner.fixture_url,clock=join['nativeAfter'])
        claim_index=owner.state['once']['inputs'][value['inputKind']]['claim'];need(claim_index is not None and claim_index<ordinal)
        claim=owner.proof(claim_index);probe=owner.proof(claim['probe']);selected_caller(value['packet']['caller'],probe['packet'])
        if intent['command']['operation']=='claim':
            for phase in (value['phaseBefore'],value['phaseAfter']):
                need(phase['active'] and phase['activations'][-1]['ticket']==ticket
                    and phase['activations'][-1]['stimulus']['verb']=='record-start')
    elif kind=='once-primary-authorized':
        exact(value,{'kind','value'});parent,_before=primary.before(owner,value['value'])
        need(integer(value['value']['cueReply'],1,ordinal-1))
        cue=owner.proof(value['value']['cueReply']);need(cue['kind']=='once-reply' and cue['inputKind']=='cue')
        intent=owner.proof(cue['intent']);source.finished_input(cue['packet'],intent['command'],owner.pid,owner.fixture_url)
        need(value['value']['issuedHost']['epochMs']>=cue['clockJoin']['hostAfterEpochMs']
            and value['value']['issuedHost']['monotonic']>=cue['clockJoin']['hostAfterMonotonic'])
    elif kind=='once-window':
        from ios.adapters.audio_once_window import validate_original
        exact(value,{'kind','value'});validate_original(owner,value['value'],ordinal)
    else:
        exact(value,{'kind','value'});need(integer(value['value'].get('authorization'),1,ordinal-1))
        authorized=owner.proof(value['value']['authorization']);need(authorized['kind']=='once-primary-authorized')
        primary.returned(owner,value['value'],authorized['value'])


def admit(owner,frames):
    shape(owner);expected=initial(owner.state['once']['ticket']);commands=set();replies=set();previous={}
    for index,value in enumerate(frames,1):
        if value['kind'] not in PROOFS:continue
        if value['kind'] in ('once-intent','once-probe-intent'):
            query=value['command'];need(query['commandId'] not in commands);commands.add(query['commandId'])
            if value['kind']=='once-probe-intent':continue
            if query['operation']!='claim':need(expected['inputs'][query['kind']]['claim'] is not None)
            if query['operation']=='claim' and query['kind']=='pattern':need(value['primaryInput']==expected['primaryReturned'] is not None)
        elif value['kind']=='once-reply':
            need(value['intent'] not in replies);replies.add(value['intent']);kind=value['inputKind']
            if kind in previous:source.follow(previous[kind],value['packet'])
            previous[kind]=value['packet']
        elif value['kind']=='once-primary-authorized':need(value['value']['cueReply']==expected['inputs']['cue']['last'])
        elif value['kind']=='once-primary-returned':need(value['value']['authorization']==expected['primaryAuthorized'])
        link(expected,value,index)
    need(same(expected,owner.state['once']));owner._once_command_ids=commands


def cache_custody(owner):
    owner.passive_retired();duties=[]
    for kind,slot in owner.state['once']['inputs'].items():
        if slot['claim'] is None:continue
        need(slot['last'] is not None);reply=owner.proof(slot['last']);intent=owner.proof(reply['intent'])
        duty=source.retired_objects(reply['packet'],intent['command'],owner.pid,owner.fixture_url)
        if any(duty[key] for key in ('cacheObjectStillLive','inputPCMStillHeld','resourcePCMStillHeld','processOwnedControlLive')):
            duties.append(dict(inputKind=kind,cueId=reply['packet']['cueId'],replyReference=slot['last'],
                replySha256=digest(reply),nativePCMSha256=reply['packet']['pcmSha256'],
                **{key:duty[key] for key in ('cacheObjectStillLive','inputPCMStillHeld','resourcePCMStillHeld','processOwnedControlLive')}))
    return dict(iosAudioOnceCacheCustodyVersion=1,binding=deepcopy(owner.binding),runId=owner.run,leaseId=owner.lease,
        nativeInstance=owner.state['instance'],inputs=duties,discharge='original-process-end-only',
        cacheAbsenceQualified=False,nativeQualified=False,wholeQualified=False)


def selected_caller(caller,packet):
    """Actual independent original Script membership/code, never request echo."""
    source_value=packet['source'];manager=caller['manager']
    members=[row for row in source_value['membership']['managers'] if row['instance']==manager['instance']]
    engines=[row for row in source_value['engines'] if row['required']['instance']==manager['instance']]
    need(len(members)==len(engines)==1 and same(members[0],manager))
    engine=engines[0]
    need(engine['running'] and not engine['stopping'] and not engine['finished']
        and engine['url']==manager['url'] and same(engine['code'],caller['code'])
        and caller['invokedEpochMs']>=packet['capturedEpochMs'])
    return caller


def require_retired(owner):need(not cache_custody(owner)['inputs'])


class AudioOnceCustody:
    def __init__(self,owner,ticket,transport):
        from ios.adapters.audio_passive_owner import IOSAudioPassiveOwner
        need(type(owner) is IOSAudioPassiveOwner and not owner.historical and owner.state['birth'] is not None
            and owner.state['start']['seconds']==10 and type(transport) is dict and set(transport)=={'send','read'}
            and all(callable(fn) for fn in transport.values()) and callable(getattr(owner,'once_script_factory',None)))
        owner.bound();self.owner,self.ticket,self.transport=owner,ticket,transport
        self.monotonic,self.epoch_ms,self.sleep=owner.monotonic,owner.epoch_ms,owner.sleep
        if owner.version==1:
            need(owner.state['pending'] is None);owner.version=2;owner.state['once']=initial(ticket);owner.save()
        need(owner.version==2 and owner.state['once']['ticket']==ticket);shape(owner)

    @operation
    def probe_original(self):
        owner=self.owner;owner.bound();reader=owner.once_script_factory()
        need(type(reader) is NativeScriptObservation and reader.ios and reader.pid==owner.pid)
        # Same actual owned Native clock, with every clock query durably logged
        # by the existing parent. No alternate clock or result is substituted.
        reader.clock_ms=lambda:owner.native.read(owner.native.sequence)['capturedEpochMs']
        sent=[];actual_send=reader.send
        def send(query):
            reference=owner.journals['proofs'].append(dict(kind='once-probe-intent',command=deepcopy(query)))
            sent.append(reference['index']);return actual_send(query)
        reader.send=send
        acquisition=NativeClockAcquisition(owner.native,monotonic=self.monotonic,epoch_ms=self.epoch_ms);acquisition.begin(self.epoch_ms())
        packet=reader.read(0,require_code_identity=True,require_membership=True)
        need(len(sent)==1);join=acquisition.finish(dict(script=packet),[('script','capturedEpochMs')])
        reference=owner.journals['proofs'].append(dict(kind='once-probe',intent=sent[0],packet=packet,clockJoin=join))
        return reference['index']

    def now(self):return dict(epochMs=self.epoch_ms(),monotonic=self.monotonic())
    def slot(self,kind):need(kind in KINDS);return self.owner.state['once']['inputs'][kind]

    @operation
    def control(self,kind,verb,*,actor_before=None,primary_input=None,probe=None):
        owner=self.owner;owner.bound();owner.recover_storage();slot=self.slot(kind)
        need(verb in source.OPERATIONS)
        if verb in ('claim','retire','release') and slot[verb] is not None:
            # A saved intent can only be resolved by a new observation. A lost
            # native send/return is never permission to repeat the once input.
            verb='observe';actor_before=primary_input=probe=None
        if verb!='claim':need(slot['claim'] is not None)
        previous=owner.phase_chain(owner.journals['proofs'].restore());before=owner.phase.status()
        if previous is not None:
            phase_packet(before,run=owner.run,area='audio',request=before['requestId'],epoch=before['capturedEpochMs'],previous=previous)
        acquisition=NativeClockAcquisition(owner.native,monotonic=self.monotonic,epoch_ms=self.epoch_ms);acquisition.begin(self.epoch_ms())
        cue=source.input_id(owner.run,self.ticket,kind)
        query=dict(schemaVersion=1,commandId='ios-'+(cue if verb=='claim' else uuid.uuid4().hex),action=source.ACTION,
            operation=verb,instance=owner.state['instance'],runId=owner.run,ticket=self.ticket,cueId=cue,kind=kind)
        if verb=='claim':query['soundUrl']=source.sound_url(owner.fixture_url,owner.run,self.ticket,kind)
        source.command(query,owner.fixture_url)
        intent=dict(kind='once-intent',command=query,actorBefore=actor_before,primaryInput=primary_input,probe=probe,issuedHost=self.now())
        reference=owner.journals['proofs'].append(intent)
        # append returns only after original bytes/inode/manifest and the owner
        # effect pointer are durably saved. The actual external input follows.
        owner.bound();self.transport['send'](deepcopy(query));started=previous_time=self.monotonic();packet=None
        for attempt in range(101):
            owner.bound();raw=self.transport['read']()
            try:value=decode(raw) if raw else None
            except json.JSONDecodeError:value=None
            if type(value) is dict and value.get('commandId')==query['commandId']:packet=value;break
            now=self.monotonic();need(number(now,previous_time,started+5));previous_time=now
            if now-started>=5 or attempt==100:break
            self.sleep(min(.05,5-(now-started)))
        if packet is None:raise NativeUIError('Once-input original reply is unavailable; persisted intent remains owned')
        join=acquisition.finish(dict(reply=packet),[('reply','capturedEpochMs')]);after=owner.phase.status(before)
        value=dict(kind='once-reply',inputKind=kind,intent=reference['index'],packet=packet,clockJoin=join,phaseBefore=before,phaseAfter=after)
        result=owner.journals['proofs'].append(value);owner.admit();return result['index'],value

    @operation
    def start_input(self,kind):
        slot=self.slot(kind)
        if slot['claim'] is not None:return self.control(kind,'observe')
        primary_input=self.owner.state['once']['primaryReturned'] if kind=='pattern' else None
        need(kind=='cue' or primary_input is not None)
        actor_before,_value=self.owner.control('observe');probe=self.probe_original()
        return self.control(kind,'claim',actor_before=actor_before,primary_input=primary_input,probe=probe)

    def finished(self,kind):
        self.owner.file_guard();slot=self.slot(kind);need(slot['last'] is not None)
        reply=self.owner.proof(slot['last']);intent=self.owner.proof(reply['intent'])
        return slot['last'],source.finished_input(reply['packet'],intent['command'],self.owner.pid,self.owner.fixture_url)

    @operation
    def authorize_primary(self,recorded):
        owner=self.owner;owner.bound();recorded.lock.assert_held()
        need(owner.state['once']['primaryAuthorized'] is None and owner.state['once']['primaryReturned'] is None)
        cue,_packet=self.finished('cue')
        need(not any(row['ticket']==self.ticket for row in recorded.state['operations']) and recorded.state['pending'] is None)
        reference=recorded.capture(self.ticket,'record-start')
        value=dict(primary=primary.header(owner,recorded),original=deepcopy(reference),issuedHost=self.now(),cueReply=cue)
        result=owner.journals['proofs'].append(dict(kind='once-primary-authorized',value=value));return result['index']

    @operation
    def primary_returned(self,recorded,result):
        owner=self.owner;owner.bound();recorded.lock.assert_held();index=owner.state['once']['primaryAuthorized']
        need(index is not None and owner.state['once']['primaryReturned'] is None and type(result) is dict
            and result.get('performed') is True and type(result.get('original')) is dict)
        authorized=owner.proof(index);actual=primary.header(owner,recorded);saved=authorized['value']['primary']
        need(all(same(actual[key],saved[key]) for key in ('binding','runId','fixtureUrl','sdkRoot','artifactRoot',
            'sdkRootIdentity','artifactRootIdentity','lockPath')))
        rows=[row for row in recorded.state['operations'] if row['ticket']==self.ticket];need(len(rows)==1)
        value=dict(authorization=index,original=deepcopy(rows[0]['after']),returnedObservation=deepcopy(result['original']),
            operationSha256=digest(rows[0]),returnedHost=self.now())
        ref=owner.journals['proofs'].append(dict(kind='once-primary-returned',value=value));return ref['index']

    @operation
    def start_recording(self,runtime,selector,recorded,call,*,pcm_profile=None):
        """Actual normal Primary API; lost return requires original recovery.

        Caller owns both original SDK locks in stable order. No function/result
        replacement is used; the ordinary owner/authorization WAL owns input.
        """
        from ios.adapters.audio_runtime import IOSAudioRuntime
        need(isinstance(runtime,IOSAudioRuntime) and recorded.lock is primary.held_lock(recorded.lock.path)
            and call['ticket']==self.ticket and call['verb']=='record-start')
        if self.owner.state['once']['primaryAuthorized'] is None:self.authorize_primary(recorded)
        result=runtime.normal_act(selector,recorded,call,pcm_profile=pcm_profile)
        if self.owner.state['once']['primaryReturned'] is None:self.primary_returned(recorded,result)
        return result
