"""Bind the genuine B4 first-body refusal; do not promote missing child receipts."""
from pathlib import Path
import hashlib,json
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,v):
 with(d/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
C=B/'root-tablet-mp3-b4-whole-output-window-current1161-20261105'
assert sha(C/'freeze.json')=='c75bdce7c7d86e70d3bba969ca613bc331ee570d9c4baddbeea0f8095d7643f7'
for n,r in load(C/'freeze.json')['files'].items():assert sha(C/n)==r['sha256']
t=load(C/'terminal.json');assert t['allExecutedOwnedProcessesAbsent']is t['allOldOriginalBodiesUnchanged']is t['wholeOwnOutputsTwiceEqual']is True
assert t['oldRootCount']==1161 and len(t['groups'])==1 and len(t['newOriginalRoots'])==4
row=t['groups'][0];h=Path(row['input']).parent;o=h.with_name(h.name+'-outer');c=h.with_name(h.name+'-censuses')
assert sha(h/'approved-inputs.json')=='1e53e96a567f44bf32c90a0272e79fb6d6472a6a61cf7d0a443726947245ba7c'
raw=load(o/'terminal.json');assert raw==row['originalTerminal']and raw['status']=='FAIL_OR_REFUSED'and raw['childReturnCode']==1
assert raw['ownProcessesAbsent']is True and raw['timedOut']is raw['forcedKill']is False and raw['problems']==[] and raw['actualBoundChildren']==0
for k in('actualStdlibParentFDThreadDrain','allActualSubjectOriginsEstablished','allSourceBinaryPinsEqual','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','twoFullOwnOutputCensusesEqual'):assert raw[k]is True
q=load(c/'qualification.json');assert q==row['originalQualification']and q['originalRoots']==list(map(str,[h,o,c]))and q['noCensusExclusions']is True
report=load(h/'child-receipts/report.json');restore=load(h/'child-receipts/actual-port-restoration.json')
assert report['status']=='FAIL_OR_REFUSED'and report['testsRun']==report['actualCaseReceipts']==1 and report['actualChildReceipts']==[] and report['allExtraFDsActualArenaOwned']is False
assert restore['allCasePortsRestored']is restore['localToolsRestored']is restore['unittestCleanupRestored']is True and restore['passed']is False
assert len(restore['unavailableOriginalReceipts'])==2 and restore['finalizationErrors']==[] and restore['originalFilePhase']['original27PortsRestored']is True
stderr=h/'child-logs/stderr.log';text=stderr.read_text();assert 'os.ftruncate(self.fd, size)'in text and 'frame is port'in text and 'Unreturned actual Arena constructor'in text
assert report['originalStandardCleanupEstablished']is False
ctx=load(B/'root-ios-current1161-after-tablet-b3-mp-negative-context-20261105/root-context.json');old=load(ctx['globalCustody']['baseline']['path']);assert len(old)==1161 and load(C/'global-before.json')==load(C/'global-after-first.json')==load(C/'global-after-second.json')==old
assert load(C/'whole-output-first.json')==load(C/'whole-output-second.json')
drain=load(o/'actual-process-drain.json');assert drain['remaining']==[]
groups={r['group']for r in drain['owned']};seen=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdecimal():continue
 try:stat=(proc/'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 f=stat[stat.rfind(')')+2:].split()
 if int(f[2])in groups or int(f[3])in groups:seen.append(dict(pid=int(proc.name),group=int(f[2]),session=int(f[3])))
assert seen==[]
refs={str(f):dict(path=str(f),sha256=sha(f))for root in map(Path,t['newOriginalRoots'])for f in sorted(root.rglob('*'))if f.is_file()and not f.is_symlink()}
OUT=B/'root-tablet-b4-mp-original-first-body-arena-truncate-negative-results-20261105';OUT.mkdir(mode=0o700)
put(OUT,'results.json',dict(status='ROOT_RETAINED_TABLET_B4_FIRST_BODY_ORIGINAL_ARENA_TRUNCATE_AUDIT_CONJUNCTION_FAILURE',terminal=dict(childReturnCode=raw['childReturnCode'],ownProcessesAbsent=raw['ownProcessesAbsent'],problems=raw['problems'],timedOut=raw['timedOut'],forcedKill=raw['forcedKill'],custodyProjectionOnly=True),newOriginalRoots=t['newOriginalRoots'],originalSupervisorTerminal=raw,actualFirstBodyEntered=True,actualTestsRun=1,remainingTwoMPBodiesUnrun=True,actualMPChildrenBorn=0,actualChildReceipts=[],originalStandardCleanupEstablished=False,actualTwentySevenPortsAndMonitoringRestored=True,unavailableOriginalReceipts=restore['unavailableOriginalReceipts'],actualUnqualifiedExtraFDs=report['actualCachedProcessLifetimeFDs'],actualRetirementReceipts=report['retirements'],originalArenaConfigurationRestorationQualified=False,allExtraFDsActualArenaOwned=False,rootActualOwnedGroupsAbsent=seen,all1161OldOriginalBodiesUnchanged=True,originalFailure=dict(path=str(stderr),sha256=sha(stderr)),MPVariantQualification=None,consumerAdmission=None,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(OUT,'actual-receipt-references.json',refs);put(OUT,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in OUT.iterdir()}));print(json.dumps(dict(freeze=sha(OUT/'freeze.json'),results=sha(OUT/'results.json'),references=len(refs))))
