"""Three actual Tablet fixture HTTP listeners and their genuine socket ports.

No server/socket/response is supplied by this controller. Every admitted
listener is born in the unchanged paired fixture/SDK constructor itself.
"""
from pathlib import Path
import _socket,http.server,os,socket,socketserver,stat,sys,threading,types
from tablet_constructor_custody import FunctionBinding,CustodyRefusal

class ThreeOriginalHTTPServers:
    def __init__(self,*,original_loopbacks_class,paired_class,sdk_class,fixture_server_class,make_server,pipe_function):
        self.original=original_loopbacks_class();self.main=threading.current_thread()
        self.paired_class=paired_class;self.paired=FunctionBinding(paired_class.__init__)
        self.sdk_class=sdk_class;self.sdk=FunctionBinding(sdk_class.__init__)
        self.fixture_class=fixture_server_class;self.make=FunctionBinding(make_server)
        self.tcp=FunctionBinding(socketserver.TCPServer.__init__);self.tcp_bind=FunctionBinding(socketserver.TCPServer.server_bind)
        self.http_bind=FunctionBinding(http.server.HTTPServer.server_bind)
        self.socket_class=socket.socket;self.c_socket_class=_socket.socket
        self.c_members=tuple((key,vars(self.c_socket_class)[key])for key in('fileno','getsockname','getpeername','getsockopt','family','type'))
        self.socket_init=FunctionBinding(socket.socket.__init__);self.accept=FunctionBinding(socket.socket.accept)
        self.create=FunctionBinding(socket.create_connection);self.pair=FunctionBinding(socket.socketpair)
        self.pipe=FunctionBinding(pipe_function);self.http_request=FunctionBinding(socketserver.ThreadingMixIn.process_request_thread)
        self.original_make=make_server;self.rows=[];self.accepted=[];self.socketpairs=[]
        self.active_pair=None;self.closed=False
        self.methods=tuple((key,value,FunctionBinding(value))for key,value in vars(type(self)).items()if type(value)is types.FunctionType)
    def check(self):
        if self.closed:raise CustodyRefusal('HTTP socket boundary lifetime ended')
        for key,value,binding in self.methods:
            if vars(type(self)).get(key)is not value:raise CustodyRefusal('HTTP gate method replaced')
            binding.guard()
        for binding in(self.paired,self.sdk,self.make,self.tcp,self.tcp_bind,self.http_bind,self.socket_init,
                self.accept,self.create,self.pair,self.pipe,self.http_request):binding.guard()
        if self.paired_class.__init__ is not self.paired.function or self.sdk_class.__init__ is not self.sdk.function:
            raise CustodyRefusal('Original actual fixture constructors changed')
        if socket.socket is not self.socket_class or _socket.socket is not self.c_socket_class:
            raise CustodyRefusal('Actual original C/Python socket classes changed')
        if any(vars(self.c_socket_class).get(key)is not value for key,value in self.c_members):
            raise CustodyRefusal('Actual C socket receiver changed')
        if socket.socket.__init__ is not self.socket_init.function or socket.socket.accept is not self.accept.function:
            raise CustodyRefusal('Original Python socket constructor/accept changed')
        if socket.create_connection is not self.create.function or socket.socketpair is not self.pair.function:
            raise CustodyRefusal('Original socket creator installation changed')
        if socketserver.ThreadingMixIn.process_request_thread is not self.http_request.function:
            raise CustodyRefusal('Original request-thread receiver changed')
        self.original.check()
    def ancestors(self,frame,binding):
        found=[]
        while frame is not None:
            if frame.f_code is binding.code and frame.f_globals is binding.namespace:binding.frame(frame);found.append(frame)
            frame=frame.f_back
        return found
    def one(self,frame,binding):
        rows=self.ancestors(frame,binding)
        if len(rows)!=1:raise CustodyRefusal('Exact genuine source frame required')
        return rows[0]
    def signature(self,owner):
        self.check()
        if type(owner)is not self.socket_class:raise CustodyRefusal('No proxy/subtype socket authority')
        c=dict(self.c_members);fd=c['fileno'](owner);info=os.fstat(fd)
        family=c['family'].__get__(owner);kind=c['type'].__get__(owner)
        if family!=socket.AF_INET or kind&0xf!=socket.SOCK_STREAM or c['getsockopt'](owner,socket.SOL_SOCKET,socket.SO_TYPE)!=socket.SOCK_STREAM:
            raise CustodyRefusal('Actual numeric IPv4 stream socket required')
        if not stat.S_ISSOCK(info.st_mode):raise CustodyRefusal('Actual socket FD/inode required')
        return(fd,info.st_dev,info.st_ino,info.st_mode)
    def actual_server(self,frame):
        ctor=self.one(frame,self.tcp);server=ctor.f_locals.get('self')
        pair=self.one(ctor,self.paired);fixture=pair.f_locals.get('self')
        if type(fixture)is not self.paired_class:raise CustodyRefusal('Foreign paired fixture receiver')
        if self.ancestors(ctor,self.sdk):
            own=self.one(ctor,self.sdk);bridge=own.f_locals.get('self');handler=own.f_locals.get('Handler')
            if type(bridge)is not self.sdk_class or type(server)is not http.server.ThreadingHTTPServer:
                raise CustodyRefusal('Actual SDKBridge HTTP server required')
            if ctor.f_locals.get('RequestHandlerClass')is not handler or not isinstance(handler,type):
                raise CustodyRefusal('Actual lexical SDK handler class required')
            route=vars(handler).get('route')
            if type(route)is types.FunctionType:
                # Its code is in the genuine lexical Handler class code object,
                # not directly in SDKBridge.__init__. Flatten code constants.
                todo=[self.sdk.code];codes=[]
                while todo:
                    code=todo.pop();codes.append(code);todo.extend(x for x in code.co_consts if isinstance(x,types.CodeType))
                if type(route)is not types.FunctionType or route.__code__ not in codes:
                    raise CustodyRefusal('Foreign same-name SDK handler body')
            if type(route)is not types.FunctionType:raise CustodyRefusal('Actual SDK route function required')
            if route.__globals__ is not self.sdk.namespace or not any(cell.cell_contents is bridge for cell in route.__closure__ or ()):
                raise CustodyRefusal('Actual SDK handler lexical receiver required')
            if any(vars(handler).get(name)is not route for name in('do_GET','do_POST','do_DELETE')):
                raise CustodyRefusal('Actual original SDK handler dispatch changed')
            kind='sdk'
        else:
            make=self.one(ctor,self.make)
            if type(server)is not self.fixture_class or ctor.f_locals.get('RequestHandlerClass')is not self.make.namespace.get('Handler'):
                raise CustodyRefusal('Actual feature fixture server/handler required')
            if make.f_locals.get('tls_context')is not None or make.f_locals.get('account_provider')is not None:
                raise CustodyRefusal('No unrelated trusted account/TLS infrastructure')
            peer=make.f_locals.get('browser_peer_of');kind='feature'if peer is None else'foreign'
            if peer is not None:
                first=next((row['server']for row in self.rows if row['kind']=='feature'),None)
                if peer is not first or fixture.fixture is not first:raise CustodyRefusal('Foreign listener lacks genuine first server owner')
        return server,fixture,kind
    def socket_birth(self,args,frame):
        self.check();owner,family,kind,protocol=args
        # A genuine AF_UNIX Pipe creates only a connected socketpair. It is a
        # separate IPC capacity and does not become an HTTP/network listener.
        if family==socket.AF_UNIX:
            pair=self.one(frame,self.pair);self.one(pair,self.pipe)
            if kind&0xf!=socket.SOCK_STREAM or protocol!=0 or type(owner)not in(self.socket_class,self.c_socket_class):
                raise CustodyRefusal('Only original local stream Pipe socketpair')
            return
        if family!=socket.AF_INET or kind&0xf!=socket.SOCK_STREAM or protocol not in(0,socket.IPPROTO_TCP):
            raise CustodyRefusal('Unexpected socket family/type/protocol')
        init=self.one(frame,self.socket_init)
        if init.f_locals.get('self')is not owner:raise CustodyRefusal('Socket constructor borrowed another receiver')
        if self.ancestors(init,self.tcp):
            server,fixture,kind=self.actual_server(init)
            if init.f_locals.get('fileno')is not None or len(self.rows)>=3:
                raise CustodyRefusal('Only original three fresh HTTP listener sockets')
            return
        if self.ancestors(init,self.accept):
            accept=self.one(init,self.accept);listener=accept.f_locals.get('self')
            if not any(row['socket']is listener for row in self.rows)or init.f_locals.get('fileno')!=accept.f_locals.get('fd'):
                raise CustodyRefusal('Accepted socket lacks real own listening parent/returned FD')
            self.signature(listener);return
        create=self.one(init,self.create)
        if init.f_locals.get('fileno')is not None or create.f_locals.get('source_address')is not None:
            raise CustodyRefusal('Only original new client sockets with no foreign bind')
        address=create.f_locals.get('address')
        if (socket.AF_INET,address)not in self.original.current_servers():
            raise CustodyRefusal('Client socket lacks actual own numeric origin')
    def audit(self,event,args,frame):
        if not event.startswith('socket.'):return
        self.check()
        if event=='socket.__new__':self.socket_birth(args,frame);return
        if event=='socket.bind':
            owner,address=args;server,fixture,kind=self.actual_server(frame)
            bind=self.one(frame,self.tcp_bind)
            if bind.f_locals.get('self')is not server or server.socket is not owner or address!=('127.0.0.1',0):
                raise CustodyRefusal('Actual original numeric HTTP bind receiver/address required')
            if kind!=('sdk','feature','foreign')[len(self.rows)]:raise CustodyRefusal('Unexpected actual HTTP birth order')
            identity=self.signature(owner)
            self.rows.append(dict(server=server,fixture=fixture,kind=kind,socket=owner,identity=identity))
            self.original.audit(event,args,frame);return
        if event=='socket.connect':
            owner,address=args;create=self.one(frame,self.create)
            if create.f_locals.get('sock')is not owner or create.f_locals.get('sa')!=address:
                raise CustodyRefusal('Actual original create_connection C receiver required')
            self.signature(owner);self.original.audit(event,args,frame);return
        if event in('socket.getaddrinfo','socket.gethostbyaddr'):
            self.original.audit(event,args,frame);return
        raise CustodyRefusal('Undeclared socket/datagram/resolver/IPC operation')
    def socketpair_returned(self,frame,result):
        self.check();self.pair.frame(frame);self.one(frame,self.pipe)
        if type(result)is not tuple or len(result)!=2 or self.socketpairs:
            raise CustodyRefusal('Exactly one original parent Pipe socketpair')
        rows=[];c=dict(self.c_members)
        for owner in result:
            if type(owner)is not self.socket_class or c['family'].__get__(owner)!=socket.AF_UNIX or c['type'].__get__(owner)&0xf!=socket.SOCK_STREAM:
                raise CustodyRefusal('Actual AF_UNIX stream pair required')
            fd=c['fileno'](owner);info=os.fstat(fd)
            if not stat.S_ISSOCK(info.st_mode):raise CustodyRefusal('Actual original pair descriptors required')
            rows.append(dict(descriptor=fd,identity=dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode),
                actualFamily='AF_UNIX',actualType='SOCK_STREAM'))
        self.socketpairs.append((tuple(result),rows));return rows
    def writer_server(self,frame):
        self.check();request=self.one(frame,self.http_request);server=request.f_locals.get('self')
        row=next((row for row in self.rows if row['server']is server),None)
        if row is None or self.signature(row['socket'])!=row['identity']:
            raise CustodyRefusal('HTTP writer lacks original held server socket/inode')
        if type(server).process_request_thread is not self.http_request.function:
            raise CustodyRefusal('HTTP request thread method replaced')
        return row
    def finish(self):
        self.check()
        if len(self.rows)!=3 or [r['kind']for r in self.rows]!=['sdk','feature','foreign']:
            raise CustodyRefusal('Three genuine HTTP listener births not observed')
        result=self.original.finish();self.closed=True
        result.update(actualOriginalHTTPBirths=3,genuineConstructorKinds=['sdk','feature','foreign'],
            actualAFUNIXPipePairs=len(self.socketpairs),standardThreadsClaimedDrained=False,
            noExternalNSSorDNSClaim=False,scope='controlled host fixtures only')
        return result
