"""Bounded selected host checks; retained originals, source pins and process binding."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tempfile,time
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
PRIVATE=REPO/'.ios-host-tmp'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
ROOTS=('tests/device','interface/src/main.cpp','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics','libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
def save(name,value):
    (HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def pin(path):
    first=path.lstat();result={key:getattr(first,key) for key in FIELDS}
    if stat.S_ISREG(first.st_mode):result['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    else:assert stat.S_ISDIR(first.st_mode),str(path)
    last=path.lstat();assert all(getattr(first,key)==getattr(last,key) for key in FIELDS),str(path)
    return result
def census():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    files={REPO/name for name in names if name}
    files.add(Path(__file__).resolve())
    files.update(HERE/name for name in ('proposal.diff','manifest.json','selected-seven.py','retained-runner-plan.json','root-publication.json','remaining-a-suite.py','root-fixture-cache-rejection.json'))
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(files)}
def original_census(roots):
    return {str(root):{str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))} for root in sorted(roots)}
def process(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
    except FileNotFoundError:return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
def main():
    mode='remaining-a'
    argv=[sys.executable,str(HERE/'remaining-a-suite.py')];seconds=300
    prefix='root-'+mode+'-first'
    assert not (HERE/(prefix+'-report.json')).exists(),'No unchanged reruns'
    temporary=Path(tempfile.mkdtemp(prefix=prefix+'-tmp-',dir=HERE));temporary.chmod(0o700)
    before=census();save(prefix+'-source-before.json',before)
    environment=os.environ.copy();environment.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.:tests/device:tests/device/self_tests:tests/device/ios/self_tests',TMPDIR=str(temporary))
    print('SOURCE_LAUNCHER_REFERENCE_PINS',len(before),flush=True)
    started=time.monotonic()
    with (HERE/(prefix+'.log')).open('w') as log:
        task=subprocess.Popen(['timeout','--signal=TERM','--kill-after=5s',str(seconds)+'s',*argv],cwd=REPO,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        binding=process(task.pid);assert binding is not None
        save(prefix+'-process-binding.json',binding);print('ACTUAL_PROCESS',json.dumps(binding,sort_keys=True),flush=True)
        code=task.wait()
    after=census();save(prefix+'-source-after.json',after)
    assert before==after,'Source/launcher/reference bytes/stat/membership changed'
    roots={temporary}
    first=original_census(roots);save(prefix+'-originals-first.json',first)
    second=original_census(roots);save(prefix+'-originals-second.json',second)
    assert first==second,'Originals changed after completion'
    remaining=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        item=process(int(path.name))
        if item is not None and item['session']==task.pid:remaining.append(item)
    report=dict(exitCode=code,seconds=time.monotonic()-started,outerSeconds=seconds,killAfterSeconds=5,sourceLauncherReferencePins=len(after),allSourcePinsEqual=True,originalRootCount=len(roots),originalFiles=sum(stat.S_ISREG(row['st_mode']) for rows in first.values() for row in rows.values()),originalPostTestCensusesEqual=True,remainingOwnedProcesses=remaining,nativeCompiled=False,deviceQualified=False,wholeFeatureQualified=False)
    save(prefix+'-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
    assert not remaining,'Owned session remains live'
    raise SystemExit(code)
if __name__=='__main__':main()
