"""Genuine second-input/ownership constructors; all prospective host cases.

Qt/SDK/native/domain boundaries are the existing explicit fixture models.
Direct consume_input1 below is only that fixture's original host-WAL seam;
no marker/image/peer external consumer completion or Whole result is implied.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import unittest
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
from adapters.script_feature.history import unpack
from ios.adapters.assets_checkpoint_owned_originals import AssetsCheckpointOriginalOwnership,AssetsCheckpointOwnedArchive
from ios.adapters.assets_second_checkpoint_owned_originals import (
    AssetsSecondCheckpointOriginalOwnership,AssetsSecondCheckpointOwnedArchive,AssetsSecondCheckpointRetainedArchive)
from ios.adapters.assets_whole_observation import AssetsWholeObservation
from ios.adapters import assets_whole_input
from ios.self_tests.assets_checkpoint_owned_fixture import Fixture,CheckpointEndpoint


class AssetsSecondCheckpointOwnedOriginalTests(unittest.TestCase):
    def setUp(self):
        self.f=Fixture(self);self.f.ordinary_input(1);self.f.driver.observe_current('primary')
        first=self.f.driver.observers[(1,'primary')]
        self.first_archive=AssetsCheckpointOwnedArchive(AssetsCheckpointOriginalOwnership(first))
        self.first_original=self.first_archive.freeze()
        self.first_files={path:(path.stat().st_dev,path.stat().st_ino,path.read_bytes())for path in self.first_archive.paths()}
        # Existing genuine fixture consumer; never counted as external effects.
        self.f.consume_input(1)

    def calls(self):
        return dict(inputs=deepcopy(self.f.boundary.inputs),replies=deepcopy(self.f.boundary.reads.requests),
            peerReplies=deepcopy(self.f.peer_reads.requests),
            scene={str(key):deepcopy(endpoint.queries)for key,endpoint in self.f.scene_endpoints.items()})

    def second(self,role='primary'):
        self.f.ordinary_input(2);self.f.driver.observe_current(role)
        observer=self.f.driver.observers[(2,role)]
        return observer,AssetsSecondCheckpointOriginalOwnership(observer)

    def first_unchanged(self):
        for path,(device,inode,raw)in self.first_files.items():
            self.assertEqual((device,inode),(path.stat().st_dev,path.stat().st_ino));self.assertEqual(raw,path.read_bytes())

    def test_second_ordinary_picker_open_owns_new_files_and_current_originals_without_more_input(self):
        observer,owner=self.second();before=self.calls();archive=AssetsSecondCheckpointOwnedArchive(owner);value=archive.freeze()
        self.assertEqual(before,self.calls());self.assertEqual(value,archive.original());self.first_unchanged()
        self.assertEqual(2,value['actionIndex']);self.assertEqual('picker',value['episodeOriginal']['kind'])
        self.assertEqual('gltf-bundle/main.gltf',value['episodeOriginal']['resource'])
        self.assertEqual(1,value['firstCompletedActionOriginal']['index']);self.assertEqual(2,value['currentSecondActionPending']['index'])
        self.assertEqual('primary',value['fileOriginalCreatorRole']);self.assertTrue(value['fileSourceOriginalReferences']['refs'])
        self.assertTrue(set(value['componentNamespacePaths'])<=set(value['actualReadPaths']))
        self.assertEqual(str(observer.files.store.path),value['cohortOriginalReferences']['files']['path'])
        self.assertFalse(value['wholeEndEligible']);self.assertFalse(value['actionCompletionEstablished'])
        self.assertEqual(1,len(self.f.a.owner.state['records']));self.assertIsNotNone(self.f.a.owner.state['pending'])
        with self.assertRaises(NativeUIError):archive.retire()

    def test_actor_second_checkpoint_has_real_distinct_node_peer_and_primary_file_creator(self):
        observer,owner=self.second('actor');before=self.calls();value=AssetsSecondCheckpointOwnedArchive(owner).freeze()
        self.assertEqual(before,self.calls());self.first_unchanged();self.assertEqual('actor',value['role'])
        self.assertIsNotNone(value['cohortOriginalReferences']['node']);self.assertIsNotNone(value['cohortOriginalReferences']['peerScene'])
        self.assertEqual('43',value['sourceBinding']['processIdentity']);self.assertEqual('primary',value['fileOriginalCreatorRole'])
        self.assertIsNot(observer.primary_scene['scene'],observer.peer_scene['scene'])
        self.assertTrue(all(type(endpoint)is CheckpointEndpoint for endpoint in self.f.scene_endpoints.values()))
        self.assertFalse(value['externalConsumersComplete'])

    def test_real_complete_ofs_lost_return_reopens_same_second_original_without_reacquisition(self):
        _o,owner=self.second();archive=AssetsSecondCheckpointOwnedArchive(owner);write=archive.originals.write;attempts=[]
        def lost(index,value):
            result=write(index,value);attempts.append(result);raise OSError('Actual second checkpoint OFS return lost')
        before=self.calls()
        with patch.object(archive.originals,'write',lost),self.assertRaises(OSError):archive.freeze()
        self.assertEqual(1,len(attempts));pending=unpack(archive.store.read()['payload'])[0]['pending']
        self.assertEqual('saved',pending['phase']);path=archive.originals.path(pending);identity=(path.stat().st_dev,path.stat().st_ino,path.read_bytes())
        reopened=AssetsSecondCheckpointOwnedArchive(owner);value=reopened.freeze()
        self.assertEqual(identity,(path.stat().st_dev,path.stat().st_ino,path.read_bytes()));self.assertEqual(before,self.calls())
        self.assertEqual(value,reopened.original());self.first_unchanged()

    def test_actual_second_parent_complete_cas_failure_latches_then_reopens_saved_original(self):
        _o,owner=self.second();archive=AssetsSecondCheckpointOwnedArchive(owner);write=archive.store.write;failures=[]
        def failed(value,previous):
            if unpack(value['payload'])[0]['phase']=='copied':failures.append(True);raise OSError('Actual second complete CAS before write')
            return write(value,previous)
        before=self.calls()
        with patch.object(archive.store,'write',failed),self.assertRaises(OSError):archive.freeze()
        self.assertEqual([True],failures);self.assertTrue(archive.failed)
        durable=unpack(archive.store.read()['payload'])[0];self.assertEqual('copying',durable['phase']);self.assertEqual('saved',durable['pending']['phase'])
        for method in(archive.bound,archive.freeze,archive.original):
            with self.assertRaises(NativeUIError):method()
        reopened=AssetsSecondCheckpointOwnedArchive(owner);value=reopened.freeze();self.assertEqual(before,self.calls())
        self.assertEqual(value,reopened.original());self.first_unchanged()

    def test_saved_complete_cas_return_lost_recovers_only_actual_durable_parent(self):
        _o,owner=self.second();archive=AssetsSecondCheckpointOwnedArchive(owner);write=archive.store.write;failures=[]
        def lost(value,previous):
            result=write(value,previous)
            if unpack(value['payload'])[0]['phase']=='copied'and not failures:failures.append(True);raise OSError('After actual complete CAS')
            return result
        before=self.calls()
        with patch.object(archive.store,'write',lost),self.assertRaises(OSError):archive.freeze()
        self.assertTrue(archive.failed);self.assertEqual('copied',unpack(archive.store.read()['payload'])[0]['phase'])
        retained=AssetsSecondCheckpointRetainedArchive(archive);self.assertFalse(retained.original()['currentCheckpointEstablished'])
        reopened=AssetsSecondCheckpointOwnedArchive(owner);self.assertEqual(reopened.original(),reopened.freeze())
        self.assertEqual(before,self.calls());self.first_unchanged()

    def test_changed_native_file_source_inode_refuses_without_new_sources(self):
        observer,owner=self.second();archive=AssetsSecondCheckpointOwnedArchive(owner);archive.freeze();before=self.calls()
        ref=observer.files.sources.refs[-1];store=observer.files.sources.store;path=store.path(store.expand(ref))
        raw=path.read_bytes();path.rename(path.with_name('retained-before-replace-'+path.name));path.write_bytes(raw);path.chmod(0o600)
        with self.assertRaises(NativeUIError):archive.original()
        self.assertEqual(before,self.calls());self.assertEqual(raw,path.read_bytes());self.first_unchanged()

    def test_cancellation_keeps_typed_retained_copy_but_never_revives_old_current_owner(self):
        _o,owner=self.second();archive=AssetsSecondCheckpointOwnedArchive(owner);value=archive.freeze()
        self.f.consume_input(2);self.f.ordinary_input(3);before=self.calls()
        for method in(archive.bound,archive.freeze,archive.original):
            with self.assertRaises(NativeUIError):method()
        retained=AssetsSecondCheckpointRetainedArchive(archive);saved=retained.original()
        self.assertEqual(value,saved['retainedOriginal']);self.assertFalse(saved['currentCheckpointEstablished'])
        manifest=retained.manifest();self.assertFalse(manifest['metadataRetirementAllowed']);self.assertFalse(manifest['performed'])
        self.assertEqual(before,self.calls());self.first_unchanged()

    def test_lost_actual_second_input_return_cannot_fabricate_checkpoint_or_repeat_input(self):
        original=assets_whole_input.open_only;attempts=[]
        def lost(picker):
            result=original(picker);attempts.append(deepcopy(picker.state));raise OSError('Original picker-open return lost')
        with patch.object(assets_whole_input,'open_only',lost),self.assertRaises(OSError):self.f.ordinary_input(2)
        self.assertEqual(1,len(attempts));self.assertEqual('picker-open',attempts[0]['phase'])
        self.assertTrue(attempts[0]['inputs']);self.assertIsNone(self.f.driver.last)
        before=self.calls()
        with self.assertRaises(NativeUIError):AssetsWholeObservation(self.f.driver,'primary')
        self.assertEqual(before,self.calls());self.assertEqual(2,self.f.a.owner.state['pending']['index'])
        self.assertIsNone(self.f.a.owner.state['pending']['after']);self.first_unchanged()


    def test_unknown_file_source_namespace_member_is_not_adopted_or_deleted(self):
        observer,owner=self.second();archive=AssetsSecondCheckpointOwnedArchive(owner)
        path=observer.files.store.path.parent/(observer.files.sources.NAMESPACE+'-frame-actual-unreferenced.json')
        path.write_bytes(b'actual unreferenced own bytes');path.chmod(0o600);info=path.stat();before=self.calls()
        with self.assertRaises(NativeUIError):archive.freeze()
        self.assertEqual((info.st_dev,info.st_ino),(path.stat().st_dev,path.stat().st_ino))
        self.assertEqual(b'actual unreferenced own bytes',path.read_bytes());self.assertEqual(before,self.calls())
        self.first_unchanged()

    def test_real_opened_incomplete_second_copy_stays_owed_in_readonly_retained_inventory(self):
        _o,owner=self.second();archive=AssetsSecondCheckpointOwnedArchive(owner);intent=archive.intent
        def stopped(event,wire):
            value=intent(event,wire)
            if wire['phase']=='opened':raise OSError('After real second opened intent before frame body')
            return value
        before=self.calls()
        with patch.object(archive.originals,'intent',stopped),self.assertRaises(OSError):archive.freeze()
        pending=unpack(archive.store.read()['payload'])[0]['pending'];self.assertEqual('opened',pending['phase'])
        path=archive.originals.path(pending);info=path.stat();self.assertEqual(0,info.st_size)
        view=AssetsSecondCheckpointRetainedArchive(archive);manifest=view.manifest()
        self.assertTrue(manifest['openedOrIncompleteIsOwed']);self.assertFalse(manifest['actualCopiedOriginalValidated'])
        self.assertEqual(pending,manifest['pending'])
        with self.assertRaises(NativeUIError):view.original()
        reopened=AssetsSecondCheckpointOwnedArchive(owner)
        with self.assertRaises((NativeUIError,ValueError)):reopened.freeze()
        self.assertEqual((info.st_dev,info.st_ino,0),(path.stat().st_dev,path.stat().st_ino,path.stat().st_size))
        self.assertEqual(before,self.calls());self.first_unchanged()

    def test_actual_file_header_guard_read_failure_latches_complete_save_without_inmemory_success(self):
        observer,owner=self.second();archive=AssetsSecondCheckpointOwnedArchive(owner);read=observer.files.store.read;faults=[]
        class ActualFileHeaderReadFailure(OSError):pass
        def failed():
            if archive.state is not None and archive.state['phase']=='copied'and not faults:
                faults.append(True);raise ActualFileHeaderReadFailure('Actual file source header read in complete save')
            return read()
        before=self.calls()
        with patch.object(observer.files.store,'read',failed),self.assertRaises(ActualFileHeaderReadFailure):archive.freeze()
        self.assertEqual([True],faults);self.assertTrue(archive.failed)
        durable=unpack(archive.store.read()['payload'])[0];self.assertEqual('copying',durable['phase']);self.assertEqual('saved',durable['pending']['phase'])
        for method in(archive.bound,archive.freeze,archive.original):
            with self.assertRaises(NativeUIError):method()
        reopened=AssetsSecondCheckpointOwnedArchive(owner);self.assertEqual(reopened.freeze(),reopened.original())
        self.assertEqual(before,self.calls());self.first_unchanged()

    def test_foreign_staged_file_token_cannot_replace_actual_current_cohort(self):
        observer,_owner=self.second();before=self.calls();original=observer.last['files']['token']
        observer.last['files']['token']=('0'if original[0]!='0'else'1')+original[1:]
        with self.assertRaises(NativeUIError):AssetsSecondCheckpointOriginalOwnership(observer)
        self.assertEqual(before,self.calls());self.first_unchanged()


if __name__=='__main__':unittest.main()
