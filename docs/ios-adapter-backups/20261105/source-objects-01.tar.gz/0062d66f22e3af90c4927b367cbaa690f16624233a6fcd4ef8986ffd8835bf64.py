"""Root-only exact single-case supervisor; never a suite discovery runner."""
from pathlib import Path
import json,os,signal,subprocess,sys,tempfile,time,traceback
from metadata import HERE,SOURCE,load,save,validate,public_guard,prior_roots,prior_census,census,proc,processes,sha
assert len(sys.argv)==2
plan=validate();kind=sys.argv[1];assert kind in plan['selection'];selection=plan['selection'][kind]
assert os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
assert Path.cwd()==HERE
report=HERE/(kind+'-report.json');logpath=HERE/(kind+'-first.log')
assert not report.exists() and not logpath.exists(),'No unchanged repeat'
assert all(json.loads(p.read_text())['qualified'] for p in HERE.glob('currentObservationCase*-report.json')),'A previous case failed; source/controller successor required'
# No selected case may overlap another run of this immutable controller.
lock=HERE/'controller-active.lock';descriptor=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
lock_binding=proc(os.getpid());os.write(descriptor,json.dumps(lock_binding).encode());os.close(descriptor)
try:
    before=public_guard();save(HERE/(kind+'-public-source-before.json'),before)
    roots=prior_roots();old_before=prior_census(roots);old_again=prior_census(roots)
    assert old_before==old_again,'A historical/foreign corpus is still changing; wait for its owner'
    save(HERE/(kind+'-prior-originals-before.json'),old_before)
    runs=HERE/'runs'/kind;runs.mkdir(mode=0o700,parents=True,exist_ok=True)
    assert not any(runs.iterdir()),'An attempted case is never silently repeated'
    runroot=Path(tempfile.mkdtemp(prefix='first-',dir=runs));runroot.chmod(0o700)
    temporary=runroot/'temporary';temporary.mkdir(mode=0o700)
    env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='',TMPDIR=str(temporary),OVERTE_ASSETS_ISOLATED_RUN_ROOT=str(runroot))
    executables=load('host-executable-pins.json')
    command=[executables['timeout']['realPath'],'--signal=TERM','--kill-after=5s','300s',executables['python']['realPath'],'-B',str(HERE/'run-one.py'),kind]
    started=time.monotonic()
    with logpath.open('x') as stream:
        task=subprocess.Popen(command,cwd=SOURCE,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        binding=proc(task.pid);assert binding is not None and binding['session']==task.pid and binding['processGroup']==task.pid
        save(HERE/(kind+'-process-binding.json'),dict(supervisor=proc(os.getpid()),task=binding,command=command))
        save(runroot/'supervisor-launch-binding.json',dict(supervisor=proc(os.getpid()),task=binding,command=command,selectedId=selection['id']))
        print('ACTUAL_OWNED_CASE_STARTED',kind,task.pid,flush=True)
        try:code=task.wait()
        except BaseException:
            current=proc(task.pid)
            if current is not None:
                assert current['startTicks']==binding['startTicks'] and current['session']==task.pid
                os.killpg(task.pid,signal.SIGTERM)
                try:task.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    current=proc(task.pid);assert current is not None and current['startTicks']==binding['startTicks']
                    os.killpg(task.pid,signal.SIGKILL);task.wait()
            raise
    remaining_before=processes(task.pid)
    # Stop is established before any purported qualified originals census.
    first=census(temporary);prior_first=prior_census(roots)
    second=census(temporary);prior_second=prior_census(roots);remaining_after=processes(task.pid)
    for suffix,value in [('originals-first',first),('originals-second',second),('prior-originals-first',prior_first),('prior-originals-second',prior_second)]:save(HERE/(kind+'-'+suffix+'.json'),value)
    after=None;source_error=None
    try:
        after=public_guard();save(HERE/(kind+'-public-source-after.json'),after);validate()
    except Exception as error:
        source_error=type(error).__name__;save(HERE/(kind+'-post-source-guard-failure.json'),dict(exceptionType=source_error,traceback=traceback.format_exc()))
    result_path=runroot/'selected-result.json';child=json.loads(result_path.read_text()) if result_path.is_file() else None
    clean=code==0 and child is not None and child['successful'] and child['testsRun']==1 and child['selectedId']==selection['id'] and not remaining_before and not remaining_after and first==second and old_before==prior_first==prior_second and before==after and source_error is None
    value=dict(kind=kind,exitCode=code,seconds=time.monotonic()-started,initialTimeoutSeconds=300,killAfterSeconds=5,runRoot=str(runroot),selectedId=selection['id'],qualified=clean,sourceGuardUnchanged=before==after,postStopOriginalCensusesEqual=first==second,priorOriginalCorporaUnchanged=old_before==prior_first==prior_second,ownedProcessesBeforeCensuses=remaining_before,ownedProcessesAfterCensuses=remaining_after,childResultPresent=child is not None,originalFiles=sum('sha256' in row for row in first.values()),priorOriginalFiles=sum('sha256' in row for corpus in old_before.values() for row in corpus.values()),sourceGuardFailure=source_error,postStopCensusesQualified=not remaining_before and not remaining_after,wholeAssetsQualified=False,nativeCompiled=False,sdkExecuted=False,deviceQualified=False)
    save(report,value);print('ACTUAL_SINGLE_CASE_TERMINAL',json.dumps(value,sort_keys=True),flush=True)
    raise SystemExit(0 if clean else code if code else 1)
finally:
    stored=json.loads(lock.read_text());current=proc(os.getpid());assert stored['pid']==current['pid'] and stored['startTicks']==current['startTicks'],'Controller lock ownership changed'
    lock.unlink()
