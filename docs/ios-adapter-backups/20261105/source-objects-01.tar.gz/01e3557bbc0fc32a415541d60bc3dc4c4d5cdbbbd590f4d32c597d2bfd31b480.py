"""Private same-selection diagnostics; keep only this worktree's new temp roots."""
from pathlib import Path
import tempfile
import unittest

keep_root=Path.cwd()/'.ios-host-tmp'
actual_directory=tempfile.TemporaryDirectory
retained=[]
class RetainedSnapshotDirectory(actual_directory):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._snapshot_keep=Path(self.name).resolve().is_relative_to(keep_root.resolve())
        if self._snapshot_keep:
            self._finalizer.detach();retained.append(self.name)
    def cleanup(self):
        if not getattr(self,'_snapshot_keep',False):return super().cleanup()

tempfile.TemporaryDirectory=RetainedSnapshotDirectory
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in ['test_ios_snapshot_prepared_quiet.SnapshotPreparedQuietTests.test_four_reserves_have_no_fact_and_each_actual_dispatch_has_its_new_clock_floor', 'test_ios_snapshot_prepared_quiet.SnapshotPreparedQuietTests.test_mutated_prepared_child_header_blocks_before_any_source_request', 'test_ios_snapshot_prepared_quiet.SnapshotPreparedQuietTests.test_partial_reserved_group_cold_reopens_same_nonces_before_any_request', 'test_ios_snapshot_prepared_quiet.SnapshotPreparedQuietTests.test_saved_original_stays_historical_after_cold_reopen_and_never_reissues', 'test_ios_snapshot_prepared_quiet.SnapshotPreparedQuietTests.test_separate_profile_cannot_prepare_a_combined_group'])
result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
for path in retained:print('Retained original temporary root:',path,flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
