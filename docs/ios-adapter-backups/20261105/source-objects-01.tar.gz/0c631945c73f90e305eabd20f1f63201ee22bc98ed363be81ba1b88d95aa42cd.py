"""Root-only metadata refresh AFTER exact source publication; launches no tests."""
from run_metadata import HERE,REPO,load_plan,validate_frozen,publication,sources,save,sha
import json,subprocess
plan=validate_frozen();rows=publication()
path=HERE/'publication-ready-source-map.json'
assert not path.exists(),'No silent refresh or replacement of an approved source map'
actual=sources(plan)
observed=json.loads((HERE/'observed-before-publication.json').read_text())
changed=[name for name in sorted(set(observed)|set(actual))
    if name in observed and name in actual and observed[name].get('sha256')!=actual[name].get('sha256')]
value=dict(status='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA',
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    publication=rows,sourcePins=actual,changedSourceSHAsSincePreparation=changed,
    mainCpp=actual['interface/src/main.cpp'],
    tsi={name:actual[name] for name in plan['explicitTSIPins']},
    rootedOrphanGuardUnchanged=True,testsExecuted=False,targetImportsExecuted=False)
save(path,value)
print(json.dumps(dict(sourceMap=str(path),sourceMapSha256=sha(path),pins=len(actual),changedSourceSHAs=changed,head=value['head']),sort_keys=True))
