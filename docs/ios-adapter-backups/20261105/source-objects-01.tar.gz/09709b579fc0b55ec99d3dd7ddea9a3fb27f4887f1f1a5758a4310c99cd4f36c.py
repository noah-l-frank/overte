"""Typed historical GPU metadata after actual Callback end retirement.

The default/current decoder remains unchanged. Only the one physical metadata
membership check is interpreted through the actual durable per-path end view;
all original Sample3/Drain4/GPU/transcript decoders remain literal.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import need
from adapters.native_vulkan_world_frame import absent
from adapters.normal_feature_state import PrivateFeatureState
from adapters.owned_vulkan_world_frame import VulkanWorldFrameOwner
from adapters.script_feature.history import same,unpack
from ios.adapters.emote_retirement import Frozen
from ios.adapters.emote_archive_round import scope as original_round
from ios.adapters.emote_callback_retirement import IOSEmoteCallbackRetirementObserver
from ios.adapters import emote_callback_archive as archive
from ios.adapters import emote_callback_drain_originals as drains

from ios.adapters.emote_callback_current_state import CallbackCurrentState,graph,selected_parents
from ios.adapters.emote_callback_retirement_view import CallbackRetirementView
from ios.adapters.emote_callback_metadata_archives import CallbackSampleArchive,CallbackObserverArchive,CallbackPhaseArchive


class CallbackRetiredState(CallbackCurrentState):
    def __init__(self,snapshot,copies,*,lock,primary_lock,retirement):
        need(type(retirement) is CallbackRetirementView and retirement.locks[snapshot['role']] is lock
            and retirement.locks['primary'] is primary_lock)
        retirement.guard();self.retirement=retirement
        super().__init__(snapshot,copies,lock=lock,primary_lock=primary_lock)

    def _read(self):
        with original_round(self.snapshot,lock=self.lock,primary_lock=self.primary_lock):
            keyed,raw,sources,peers=graph(self.snapshot,lock=self.lock,primary_lock=self.primary_lock)
            self.used=set();native=keyed.rendered_owner.native_owner;root,role,run=keyed.root,keyed.role,keyed.run
            for name,path in self.snapshot['paths'].items():need(same(self.store(path).read(),self.snapshot['owners'][name]))
            for name,field in (('sources','sources'),('peers','peers'),('files','fileReceipts'),('entities','entities'),('pointers','pointers')):
                if native.paths[name] is not None:need(same(self.store(native.paths[name]).read(),raw[field]))
            scope_store=self.store(self.lock.path.with_name('ios-emote-'+role+'-marker.json'))
            need(same(scope_store.read(),raw['scope']))
            scope=drains.projection(raw['sampleOwners'],root=root,binding=keyed.binding,run=run,role=role,lock=self.lock,policy=keyed.policy)
            need(same(scope.envelope(scope.state),raw['scope']))
            samples_store=self.store(self.lock.path.with_name('ios-emote-'+role+'-samples.json'))
            # These are distinct original DTOs. Do not compare Projection4 to
            # Samples3 or turn the historical sample's pending owner released.
            need(same(samples_store.read(),raw['sampleOwners']['samples']))
            samples=CallbackSampleArchive(samples_store.read(),store=samples_store,root=root,binding=keyed.binding,run=run,role=role,lock=self.lock,policy=keyed.policy)
            phase=CallbackPhaseArchive(keyed.fixture_url,sources.frames[-1]['phaseAfter'],run=run,instance=keyed.phase_instance)
            observer_store=self.store(self.lock.path.with_name('ios-emote-'+role+'-observer.json'))
            observer=CallbackObserverArchive(observer_store.read(),store=observer_store,root=root,binding=keyed.binding,run=run,role=role,lock=self.lock,
                policy=keyed.policy,sources=sources,peers=peers,samples=samples,phase=phase)
            need(same(observer.original(observer.state['records'][-1]),raw['observation']))
            drains.history(observer)
            parents=selected_parents(keyed,raw,scope,samples);current={}
            expected={self.lock.path.with_name('graphics-world-frame-'+role+'-0-'+request[4:]+'.json') for request in parents}
            self.retirement.gpu_membership(expected,set(self.lock.path.parent.glob('graphics-world-frame-'+role+'-0-*.json')))
            for request,original in parents.items():
                path=self.lock.path.with_name('graphics-world-frame-'+role+'-0-'+request[4:]+'.json')
                store=self.store(path);value=store.read();current[path]=value
                if original is None:need(value is None);continue
                need(value is not None and original['phase']=='released' and absent(original['absence']))
                owner=VulkanWorldFrameOwner(store,root,keyed.binding,run,role,0,request,
                    lambda *_:need(False),lambda:True,source_lock=self.lock)
                owner.verify_owned_artifact();need(same(owner.state,value))
                fixed=('vulkanWorldOwnerVersion','binding','runId','role','stage','requestId','root','name','ticket','file','frame')
                need(all(same(value[key],original[key]) for key in fixed))
                before,after=unpack(original['transcript']),unpack(value['transcript'])
                need(same(after[:len(before)],before))
                for row in after[len(before):]:need(row['command']['operation']=='inspect' and row['receipt'] is not None)
                need(same(store.read(),value))
            need(self.used==set(self.copies))
            return dict(keyed=keyed,sources=sources,peers=peers,scope=scope,samples=samples,observer=observer,currentGpu=current)

