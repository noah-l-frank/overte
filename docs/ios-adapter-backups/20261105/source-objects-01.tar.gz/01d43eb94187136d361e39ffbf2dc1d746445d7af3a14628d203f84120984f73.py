from pathlib import Path
import cProfile,importlib,json,pstats,sys,time
REPO=Path.cwd();HERE=Path(__file__).resolve().parent
controller=REPO/'.ios-host-tmp/chat-current-pass-source7-guard3-root-preparation-20261103'
sys.path.insert(0,str(controller));import run_metadata as meta
plan=meta.validate_frozen();meta.publication();before=meta.sources(plan);own=meta.pin(Path(__file__).resolve())
meta.save(HERE/'source-before.json',before)
def audit(event,args):
    if event=='import':assert not any(part in ('pymobiledevice3','tidevice','pyidevice','zeroconf') for part in args[0].split('.'))
    elif event=='subprocess.Popen':assert list(args[1])==['rg','--files','-0',*plan['broadSourceRoots']] and Path(args[2]).resolve()==REPO
    elif event in ('socket.connect','socket.bind'):raise AssertionError('Pure parser timing must not use a service')
sys.addaudithook(audit)
sys.path[:0]=[str(REPO/'tests/device'),str(REPO/'tests/device/self_tests'),str(REPO/'tests/device/ios/self_tests')]
from ios.adapters import chat_draft_runtime,chat_archive_round as a
from ios.adapters import chat_receive_sources,chat_peer_receipts,chat_send_receive
for name in a._QML_AUTHORITIES:importlib.import_module(name)
assert a.original_methods()
rows={};samples=10
for label,method in [('generic',a.original_methods),('qml',a.qml_authority)]:
    start=time.monotonic_ns();values=[method() for _ in range(samples)];duration=time.monotonic_ns()-start
    assert all(v==values[0] for v in values)
    rows[label]=dict(meanMicroseconds=duration/samples/1000,modules=len(values[0]) if type(values[0]) is tuple else None)
p=cProfile.Profile();p.runcall(a.qml_authority);p.dump_stats(str(HERE/'qml-profile.pstats'))
stats=pstats.Stats(p);hot=[]
for (file,line,name),(primitive,calls,own_seconds,total_seconds,callers) in sorted(stats.stats.items(),key=lambda v:v[1][3],reverse=True)[:18]:
    hot.append(dict(file=file,line=line,name=name,calls=calls,ownSeconds=own_seconds,totalSeconds=total_seconds))
after=meta.sources(plan);assert before==after and own==meta.pin(Path(__file__).resolve()) and a.original_methods()
meta.save(HERE/'source-after.json',after)
report=dict(status='PURE_QML_CURRENT_PARSER_COST_ONLY',samples=samples,rows=rows,hot=hot,allSourcePinsUnchanged=True,sourcePins=len(before),noFramesOrTransportOrSDKOrNode=True,wholeChatQualified=False)
meta.save(HERE/'report.json',report);print(json.dumps(report))
