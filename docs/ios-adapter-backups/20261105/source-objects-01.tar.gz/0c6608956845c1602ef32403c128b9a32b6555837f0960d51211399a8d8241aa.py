"""One synchronous Chat decoder's completed historical proof DAG.

Original decoders remain the authority. Nothing is reused across the outer
call, mutation/query boundaries, a changed original file or a changed parser.
Only the existing exact bounded sender factory has a reusable dependency graph.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextvars import ContextVar
from contextlib import contextmanager
from copy import deepcopy
import inspect
import hashlib
from pathlib import Path
import stat
import sys
from types import FunctionType,ModuleType
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as read_scope,record
from adapters.script_feature.history import canonical,same

_ACTIVE=ContextVar('ios_chat_archive_decode_round',default=None)
_LAST_COUNTS=ContextVar('ios_chat_archive_decode_counts',default=(0,0))
_LAST_FRAME_COUNTS=ContextVar('ios_chat_archive_frame_decode_counts',default=(0,0))
_LAST_CONSTRUCTION=ContextVar('ios_chat_original_construction_counts',default=None)
_BASELINES={}
_DEPENDENCIES={}
_MODULES=tuple('ios.adapters.'+name for name in ('chat_draft_owner','chat_receive_sources','chat_peer_receipts','chat_send_receive','chat_draft_runtime'))
_FIELDS=('previous','state','binding','primary_binding','run','root','fixture_url','version','frontier','frontier_ticket',
    'source_bound','peer_actor','historical','subgraph_only','bound_record')
_MUTATORS=frozenset(('write','discard','save','query_intent','input_intent','storage_intent','capture','act','cleanup',
    'restore_history','resolve','recover','recover_observation','remember','remember_clock'))
_MAX_ENTRIES=32
_MAX_BYTES=2*1024*1024
_MAX_ENTRY_BYTES=256*1024


def function(value):
    target=getattr(value,'__func__',value)
    return target,getattr(target,'__code__',None),id(getattr(value,'__self__',None))


def _literal_module_signature(namespace,*,class_cache=None):
    class_cache={} if class_cache is None else class_cache
    values=[]
    for name,value in sorted(namespace.items()):
        if isinstance(value,FunctionType):values.append((name,function(value)))
        elif isinstance(value,type):
            # Imported aliases refer to the same actual class. Compute its
            # complete current MRO/method signature once per guard pass; this
            # dictionary never survives original_methods()/qml_authority().
            entry=class_cache.get(id(value))
            if entry is None:
                methods=[]
                for parent in value.__mro__:
                    for key,item in sorted(vars(parent).items()):
                        if key in _MUTATORS:continue
                        if isinstance(item,(staticmethod,classmethod)):item=item.__func__
                        if isinstance(item,FunctionType):methods.append((parent,key,function(item)))
                entry=(value,tuple(methods));class_cache[id(value)]=entry
            need(entry[0] is value)
            values.append((name,value,entry[1]))
        elif isinstance(value,ContextVar):values.append((name,id(value)))
        elif isinstance(value,ModuleType):values.append((name,id(value)))
        elif name.isupper() and isinstance(value,(str,int,float,bool,tuple,frozenset,type(None))):values.append((name,value))
    return tuple(values)

class _ModuleClassifierSeal(tuple):
    """Strong one-installation custody, not parser/native verdict reuse."""
    __slots__=()
    def __new__(cls,function):
        # Private installation data, deliberately an EXACT tuple, not a tuple
        # subtype whose slot-wrapper calls may allocate argument tuples.
        cells=function.__closure__;code=function.__code__;names=code.co_freevars
        own=None;held=[];index=0
        while index<code.co_nfreevars:
            cell=cells[index]
            if names[index]=='seal':
                need(own is None);own=cell
            else:held.append((cell,cell.cell_contents))
            index+=1
        need(own is not None)
        return (function,code,cells,own,().__class__(held),code.co_nfreevars-1)
    def check(self,function):
        expected,code,cells,own,held,count=self
        if function is not expected or function.__code__ is not code or function.__closure__ is not cells:return False
        if own.cell_contents is not self:return False
        index=0
        while index<count:
            cell,value=held[index]
            if cell.cell_contents is not value:return False
            index+=1
        return True



_LAST_MODULE_DISPATCH=ContextVar('ios_chat_current_module_dispatch',default=None)


def _make_module_signature():
    literal=_literal_module_signature;literal_code=literal.__code__
    module_namespace=literal.__globals__;builtin_namespace=literal.__builtins__
    actual_type=builtin_namespace['type'];actual_tuple=builtin_namespace['tuple'];actual_dict=builtin_namespace['dict'];actual_str=builtin_namespace['str']
    expected=tuple((name,builtin_namespace[name])for name in(
        'type','str','int','float','bool','tuple','frozenset','dict','list','set','bytes','bytearray',
        'isinstance','getattr','id','sorted'))+(('FunctionType',(lambda:None).__class__),
        ('ModuleType',actual_type(sys)),('ContextVar',actual_type(_ACTIVE)))
    expected_count=expected.__len__()
    def aliases_unchanged():
        # Kept as independently sealed installation data and original counter
        # subject. The classifier never CALLS this Python verifier.
        if literal.__code__ is not literal_code:raise ValueError('Literal module classifier installation changed')
        index=0
        while index<expected_count:
            name,original=expected[index]
            current=module_namespace[name]if name in module_namespace else builtin_namespace[name]
            if current is not original:return False
            index+=1
        return True
    seal_class=_ModuleClassifierSeal;seal_check=seal_class.check;seal_check_code=seal_check.__code__
    seal_new=seal_class.__new__;seal_new_code=seal_new.__code__
    seal_namespace=seal_class.__dict__;seal_names=actual_tuple(seal_namespace);seal_members=actual_tuple(seal_namespace.items())
    checker_code=aliases_unchanged.__code__;checker_closure=aliases_unchanged.__closure__
    checker_cells=actual_tuple((cell,cell.cell_contents)for cell in checker_closure)
    scalar_types=(actual_str,builtin_namespace['int'],builtin_namespace['float'],builtin_namespace['bool'],actual_tuple,builtin_namespace['frozenset'])
    ignored_types=(actual_dict,builtin_namespace['list'],builtin_namespace['set'],builtin_namespace['bytes'],builtin_namespace['bytearray'])
    # Bind actual immutable C receivers at Birth. Mutable module getattr is
    # never used while deciding observer state, even after attribute removal.
    builtin_function_type=().__class__.__new__.__class__;module_type=ModuleType;actual_len=builtin_namespace['len'];monitor=getattr(sys,'monitoring',None)
    need(actual_type(actual_len)is builtin_function_type and actual_type(actual_len.__self__)is module_type
        and actual_len.__self__.__dict__ is builtin_namespace and actual_len.__name__=='len'and actual_len.__qualname__=='len')
    get_profile=sys.getprofile;get_trace=sys.gettrace
    monitor_get_tool=None if monitor is None else monitor.get_tool
    monitor_get_events=None if monitor is None else monitor.get_events
    monitor_get_local=None if monitor is None else monitor.get_local_events
    observer_supported=actual_type(sys)is module_type and monitor is not None and actual_type(monitor)is module_type
    cold_ports=((sys,'getprofile',get_profile),(sys,'gettrace',get_trace),(monitor,'get_tool',monitor_get_tool),
        (monitor,'get_events',monitor_get_events),(monitor,'get_local_events',monitor_get_local))
    for receiver,name,port in cold_ports:
        if actual_type(port)is not builtin_function_type:observer_supported=False;continue
        # Actual built-in function name/qualname/self fields are read-only C
        # receiver identity, not writable __module__ metadata or live getattr.
        if port.__self__ is not receiver or port.__name__!=name or port.__qualname__!=name:observer_supported=False

    state=None;seal=None
    def module_signature(namespace,*,class_cache=None):
        # Exact tuple C descriptors bypass subclass iteration/overrides. No
        # Python seal/checker call occurs anywhere in this projection.
        if ().__class__.__class__(seal)is not ().__class__:raise ValueError('Unknown classifier seal format')
        sealed_object=seal;expected_function=seal[0];expected_code=seal[1]
        expected_cells=seal[2];own_cell=seal[3];held_cells=seal[4];held_count=seal[5]
        if (seal is not sealed_object or module_signature is not expected_function
                or module_signature.__code__ is not expected_code or module_signature.__closure__ is not expected_cells
                or own_cell.cell_contents is not sealed_object):raise ValueError('Module classifier custody changed')
        guard_index=0
        while guard_index<held_count:
            guard_cell,guard_value=held_cells[guard_index]
            if guard_cell.cell_contents is not guard_value:raise ValueError('Module classifier closure changed')
            guard_index+=1
        (literal,literal_code,actual_type,actual_tuple,actual_dict,actual_str,actual_sorted,actual_isupper,
            scalar_types,ignored_types,seal_check,seal_check_code,seal_new,seal_new_code,seal_namespace,seal_names,
            seal_members,checker_code,checker_closure,checker_cells,diagnostics,expected_aliases,module_namespace,
            builtin_namespace,actual_dict_get,missing,get_profile,get_trace,monitor_get_tool,monitor_get_events,
            monitor_get_local,observer_supported,unwind_mask,observer_codes,actual_len)=state
        # All tracked key/tuple preparation precedes control inspection.
        guard_names=actual_tuple(seal_namespace);guard_module_keys=actual_tuple(module_namespace);guard_builtin_keys=actual_tuple(builtin_namespace)
        guard_index=0
        while guard_index<actual_len(guard_module_keys):
            if actual_type(guard_module_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier global key')
            guard_index+=1
        guard_index=0
        while guard_index<actual_len(guard_builtin_keys):
            if actual_type(guard_builtin_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier builtin key')
            guard_index+=1
        if (literal.__code__ is not literal_code or aliases_unchanged.__code__ is not checker_code
                or aliases_unchanged.__closure__ is not checker_closure or seal_class.check is not seal_check
                or seal_check.__code__ is not seal_check_code or seal_class.__new__ is not seal_new
                or seal_new.__code__ is not seal_new_code or actual_len(guard_names)!=actual_len(seal_names)):
            raise ValueError('Classifier checker installation changed')
        guard_index=0
        while guard_index<actual_len(seal_members):
            guard_name,guard_member=seal_members[guard_index]
            if guard_names[guard_index]is not guard_name or seal_namespace[guard_name]is not guard_member:
                raise ValueError('Classifier seal namespace changed')
            guard_index+=1
        guard_index=0
        while guard_index<actual_len(checker_cells):
            guard_cell,guard_value=checker_cells[guard_index]
            if guard_cell.cell_contents is not guard_value:raise ValueError('Classifier checker closure changed')
            guard_index+=1
        if (seal is not sealed_object or module_signature is not expected_function
                or module_signature.__code__ is not expected_code or module_signature.__closure__ is not expected_cells
                or own_cell.cell_contents is not sealed_object):raise ValueError('Module classifier custody changed')
        guard_index=0
        while guard_index<held_count:
            guard_cell,guard_value=held_cells[guard_index]
            if guard_cell.cell_contents is not guard_value:raise ValueError('Module classifier closure changed')
            guard_index+=1
        # Exact-str keys and actual dict.get avoid Module __getattr__, custom
        # dict methods/hash/equality, Python checker calls and tracked iterators.
        alias_ok=True;guard_index=0
        while guard_index<actual_len(expected_aliases):
            guard_name,guard_value=expected_aliases[guard_index]
            guard_current=actual_dict_get(module_namespace,guard_name,missing)
            if guard_current is missing:guard_current=actual_dict_get(builtin_namespace,guard_name,missing)
            if guard_current is not guard_value:alias_ok=False
            guard_index+=1
        if not alias_ok:
            result=literal(namespace,class_cache=class_cache)
            diagnostics.set({'mode':'literal-alias-change','fastEntries':0,'literalEntries':None})
            # All tracked key/tuple preparation precedes control inspection.
            guard_names=actual_tuple(seal_namespace);guard_module_keys=actual_tuple(module_namespace);guard_builtin_keys=actual_tuple(builtin_namespace)
            guard_index=0
            while guard_index<actual_len(guard_module_keys):
                if actual_type(guard_module_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier global key')
                guard_index+=1
            guard_index=0
            while guard_index<actual_len(guard_builtin_keys):
                if actual_type(guard_builtin_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier builtin key')
                guard_index+=1
            if (literal.__code__ is not literal_code or aliases_unchanged.__code__ is not checker_code
                    or aliases_unchanged.__closure__ is not checker_closure or seal_class.check is not seal_check
                    or seal_check.__code__ is not seal_check_code or seal_class.__new__ is not seal_new
                    or seal_new.__code__ is not seal_new_code or actual_len(guard_names)!=actual_len(seal_names)):
                raise ValueError('Classifier checker installation changed')
            guard_index=0
            while guard_index<actual_len(seal_members):
                guard_name,guard_member=seal_members[guard_index]
                if guard_names[guard_index]is not guard_name or seal_namespace[guard_name]is not guard_member:
                    raise ValueError('Classifier seal namespace changed')
                guard_index+=1
            guard_index=0
            while guard_index<actual_len(checker_cells):
                guard_cell,guard_value=checker_cells[guard_index]
                if guard_cell.cell_contents is not guard_value:raise ValueError('Classifier checker closure changed')
                guard_index+=1
            if (seal is not sealed_object or module_signature is not expected_function
                    or module_signature.__code__ is not expected_code or module_signature.__closure__ is not expected_cells
                    or own_cell.cell_contents is not sealed_object):raise ValueError('Module classifier custody changed')
            guard_index=0
            while guard_index<held_count:
                guard_cell,guard_value=held_cells[guard_index]
                if guard_cell.cell_contents is not guard_value:raise ValueError('Module classifier closure changed')
                guard_index+=1
            # Exact-str keys and actual dict.get avoid Module __getattr__, custom
            # dict methods/hash/equality, Python checker calls and tracked iterators.
            alias_ok=True;guard_index=0
            while guard_index<actual_len(expected_aliases):
                guard_name,guard_value=expected_aliases[guard_index]
                guard_current=actual_dict_get(module_namespace,guard_name,missing)
                if guard_current is missing:guard_current=actual_dict_get(builtin_namespace,guard_name,missing)
                if guard_current is not guard_value:alias_ok=False
                guard_index+=1
            return result
        literal_keys=actual_type(namespace)is not actual_dict
        if not literal_keys:
            incoming_keys=actual_tuple(namespace);key_index=0
            while key_index<actual_len(incoming_keys):
                if actual_type(incoming_keys[key_index])is not actual_str:literal_keys=True;break
                key_index+=1
        if literal_keys or class_cache is not None and actual_type(class_cache)is not actual_dict:
            result=literal(namespace,class_cache=class_cache)
            diagnostics.set({'mode':'literal-key-or-mapping','fastEntries':0,'literalEntries':None})
            # All tracked key/tuple preparation precedes control inspection.
            guard_names=actual_tuple(seal_namespace);guard_module_keys=actual_tuple(module_namespace);guard_builtin_keys=actual_tuple(builtin_namespace)
            guard_index=0
            while guard_index<actual_len(guard_module_keys):
                if actual_type(guard_module_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier global key')
                guard_index+=1
            guard_index=0
            while guard_index<actual_len(guard_builtin_keys):
                if actual_type(guard_builtin_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier builtin key')
                guard_index+=1
            if (literal.__code__ is not literal_code or aliases_unchanged.__code__ is not checker_code
                    or aliases_unchanged.__closure__ is not checker_closure or seal_class.check is not seal_check
                    or seal_check.__code__ is not seal_check_code or seal_class.__new__ is not seal_new
                    or seal_new.__code__ is not seal_new_code or actual_len(guard_names)!=actual_len(seal_names)):
                raise ValueError('Classifier checker installation changed')
            guard_index=0
            while guard_index<actual_len(seal_members):
                guard_name,guard_member=seal_members[guard_index]
                if guard_names[guard_index]is not guard_name or seal_namespace[guard_name]is not guard_member:
                    raise ValueError('Classifier seal namespace changed')
                guard_index+=1
            guard_index=0
            while guard_index<actual_len(checker_cells):
                guard_cell,guard_value=checker_cells[guard_index]
                if guard_cell.cell_contents is not guard_value:raise ValueError('Classifier checker closure changed')
                guard_index+=1
            if (seal is not sealed_object or module_signature is not expected_function
                    or module_signature.__code__ is not expected_code or module_signature.__closure__ is not expected_cells
                    or own_cell.cell_contents is not sealed_object):raise ValueError('Module classifier custody changed')
            guard_index=0
            while guard_index<held_count:
                guard_cell,guard_value=held_cells[guard_index]
                if guard_cell.cell_contents is not guard_value:raise ValueError('Module classifier closure changed')
                guard_index+=1
            # Exact-str keys and actual dict.get avoid Module __getattr__, custom
            # dict methods/hash/equality, Python checker calls and tracked iterators.
            alias_ok=True;guard_index=0
            while guard_index<actual_len(expected_aliases):
                guard_name,guard_value=expected_aliases[guard_index]
                guard_current=actual_dict_get(module_namespace,guard_name,missing)
                if guard_current is missing:guard_current=actual_dict_get(builtin_namespace,guard_name,missing)
                if guard_current is not guard_value:alias_ok=False
                guard_index+=1
            return result
        quiet=observer_supported and get_profile()is None and get_trace()is None
        if quiet:
            tool=0
            while tool<6:
                if monitor_get_tool(tool)is not None:
                    if monitor_get_events(tool)&~unwind_mask:quiet=False
                    observer_index=0
                    while observer_index<actual_len(observer_codes):
                        if monitor_get_local(tool,observer_codes[observer_index]):quiet=False
                        observer_index+=1
                tool+=1
        if not quiet:
            result=literal(namespace,class_cache=class_cache)
            diagnostics.set({'mode':'literal-observer','fastEntries':0,'literalEntries':None})
            # All tracked key/tuple preparation precedes control inspection.
            guard_names=actual_tuple(seal_namespace);guard_module_keys=actual_tuple(module_namespace);guard_builtin_keys=actual_tuple(builtin_namespace)
            guard_index=0
            while guard_index<actual_len(guard_module_keys):
                if actual_type(guard_module_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier global key')
                guard_index+=1
            guard_index=0
            while guard_index<actual_len(guard_builtin_keys):
                if actual_type(guard_builtin_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier builtin key')
                guard_index+=1
            if (literal.__code__ is not literal_code or aliases_unchanged.__code__ is not checker_code
                    or aliases_unchanged.__closure__ is not checker_closure or seal_class.check is not seal_check
                    or seal_check.__code__ is not seal_check_code or seal_class.__new__ is not seal_new
                    or seal_new.__code__ is not seal_new_code or actual_len(guard_names)!=actual_len(seal_names)):
                raise ValueError('Classifier checker installation changed')
            guard_index=0
            while guard_index<actual_len(seal_members):
                guard_name,guard_member=seal_members[guard_index]
                if guard_names[guard_index]is not guard_name or seal_namespace[guard_name]is not guard_member:
                    raise ValueError('Classifier seal namespace changed')
                guard_index+=1
            guard_index=0
            while guard_index<actual_len(checker_cells):
                guard_cell,guard_value=checker_cells[guard_index]
                if guard_cell.cell_contents is not guard_value:raise ValueError('Classifier checker closure changed')
                guard_index+=1
            if (seal is not sealed_object or module_signature is not expected_function
                    or module_signature.__code__ is not expected_code or module_signature.__closure__ is not expected_cells
                    or own_cell.cell_contents is not sealed_object):raise ValueError('Module classifier custody changed')
            guard_index=0
            while guard_index<held_count:
                guard_cell,guard_value=held_cells[guard_index]
                if guard_cell.cell_contents is not guard_value:raise ValueError('Module classifier closure changed')
                guard_index+=1
            # Exact-str keys and actual dict.get avoid Module __getattr__, custom
            # dict methods/hash/equality, Python checker calls and tracked iterators.
            alias_ok=True;guard_index=0
            while guard_index<actual_len(expected_aliases):
                guard_name,guard_value=expected_aliases[guard_index]
                guard_current=actual_dict_get(module_namespace,guard_name,missing)
                if guard_current is missing:guard_current=actual_dict_get(builtin_namespace,guard_name,missing)
                if guard_current is not guard_value:alias_ok=False
                guard_index+=1
            return result
        entries=actual_sorted(namespace.items());count=entries.__len__();outputs=[None]*count
        class_cache={}if class_cache is None else class_cache
        index=0;used=0;fast=0;slow=0;span_ready=False;literal_tail=False
        # All tracked key/tuple preparation precedes control inspection.
        guard_names=actual_tuple(seal_namespace);guard_module_keys=actual_tuple(module_namespace);guard_builtin_keys=actual_tuple(builtin_namespace)
        guard_index=0
        while guard_index<actual_len(guard_module_keys):
            if actual_type(guard_module_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier global key')
            guard_index+=1
        guard_index=0
        while guard_index<actual_len(guard_builtin_keys):
            if actual_type(guard_builtin_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier builtin key')
            guard_index+=1
        if (literal.__code__ is not literal_code or aliases_unchanged.__code__ is not checker_code
                or aliases_unchanged.__closure__ is not checker_closure or seal_class.check is not seal_check
                or seal_check.__code__ is not seal_check_code or seal_class.__new__ is not seal_new
                or seal_new.__code__ is not seal_new_code or actual_len(guard_names)!=actual_len(seal_names)):
            raise ValueError('Classifier checker installation changed')
        guard_index=0
        while guard_index<actual_len(seal_members):
            guard_name,guard_member=seal_members[guard_index]
            if guard_names[guard_index]is not guard_name or seal_namespace[guard_name]is not guard_member:
                raise ValueError('Classifier seal namespace changed')
            guard_index+=1
        guard_index=0
        while guard_index<actual_len(checker_cells):
            guard_cell,guard_value=checker_cells[guard_index]
            if guard_cell.cell_contents is not guard_value:raise ValueError('Classifier checker closure changed')
            guard_index+=1
        if (seal is not sealed_object or module_signature is not expected_function
                or module_signature.__code__ is not expected_code or module_signature.__closure__ is not expected_cells
                or own_cell.cell_contents is not sealed_object):raise ValueError('Module classifier custody changed')
        guard_index=0
        while guard_index<held_count:
            guard_cell,guard_value=held_cells[guard_index]
            if guard_cell.cell_contents is not guard_value:raise ValueError('Module classifier closure changed')
            guard_index+=1
        # Exact-str keys and actual dict.get avoid Module __getattr__, custom
        # dict methods/hash/equality, Python checker calls and tracked iterators.
        alias_ok=True;guard_index=0
        while guard_index<actual_len(expected_aliases):
            guard_name,guard_value=expected_aliases[guard_index]
            guard_current=actual_dict_get(module_namespace,guard_name,missing)
            if guard_current is missing:guard_current=actual_dict_get(builtin_namespace,guard_name,missing)
            if guard_current is not guard_value:alias_ok=False
            guard_index+=1
        if not alias_ok:raise ValueError('Classifier alias changed during allocation')
        while index<count:
            pair=entries[index];name,value=pair;kind=actual_type(value)
            simple=(value is None or kind is scalar_types[0]or kind is scalar_types[1]or kind is scalar_types[2]
                or kind is scalar_types[3]or kind is scalar_types[4]or kind is scalar_types[5])
            ignored=(kind is ignored_types[0]or kind is ignored_types[1]or kind is ignored_types[2]
                or kind is ignored_types[3]or kind is ignored_types[4])
            if (simple or ignored)and not literal_tail:
                if not span_ready:
                    quiet=observer_supported and get_profile()is None and get_trace()is None
                    if quiet:
                        tool=0
                        while tool<6:
                            if monitor_get_tool(tool)is not None:
                                if monitor_get_events(tool)&~unwind_mask:quiet=False
                                observer_index=0
                                while observer_index<actual_len(observer_codes):
                                    if monitor_get_local(tool,observer_codes[observer_index]):quiet=False
                                    observer_index+=1
                            tool+=1
                    if not quiet:literal_tail=True
                    else:span_ready=True
                if not literal_tail:
                    if simple and actual_isupper(name):outputs[used]=pair;used+=1
                    fast+=1;index+=1;continue
            span_ready=False;row=None;slow+=1
            if isinstance(value,FunctionType):row=(name,function(value))
            elif isinstance(value,type):
                entry=class_cache.get(id(value))
                if entry is None:
                    methods=[]
                    for parent in value.__mro__:
                        for key,item in sorted(vars(parent).items()):
                            if key in _MUTATORS:continue
                            if isinstance(item,(staticmethod,classmethod)):item=item.__func__
                            if isinstance(item,FunctionType):methods.append((parent,key,function(item)))
                    entry=(value,tuple(methods));class_cache[id(value)]=entry
                need(entry[0]is value);row=(name,value,entry[1])
            elif isinstance(value,ContextVar):row=(name,id(value))
            elif isinstance(value,ModuleType):row=(name,id(value))
            elif name.isupper()and isinstance(value,(str,int,float,bool,tuple,frozenset,type(None))):row=(name,value)
            if row is not None:outputs[used]=row;used+=1
            # All tracked key/tuple preparation precedes control inspection.
            guard_names=actual_tuple(seal_namespace);guard_module_keys=actual_tuple(module_namespace);guard_builtin_keys=actual_tuple(builtin_namespace)
            guard_index=0
            while guard_index<actual_len(guard_module_keys):
                if actual_type(guard_module_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier global key')
                guard_index+=1
            guard_index=0
            while guard_index<actual_len(guard_builtin_keys):
                if actual_type(guard_builtin_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier builtin key')
                guard_index+=1
            if (literal.__code__ is not literal_code or aliases_unchanged.__code__ is not checker_code
                    or aliases_unchanged.__closure__ is not checker_closure or seal_class.check is not seal_check
                    or seal_check.__code__ is not seal_check_code or seal_class.__new__ is not seal_new
                    or seal_new.__code__ is not seal_new_code or actual_len(guard_names)!=actual_len(seal_names)):
                raise ValueError('Classifier checker installation changed')
            guard_index=0
            while guard_index<actual_len(seal_members):
                guard_name,guard_member=seal_members[guard_index]
                if guard_names[guard_index]is not guard_name or seal_namespace[guard_name]is not guard_member:
                    raise ValueError('Classifier seal namespace changed')
                guard_index+=1
            guard_index=0
            while guard_index<actual_len(checker_cells):
                guard_cell,guard_value=checker_cells[guard_index]
                if guard_cell.cell_contents is not guard_value:raise ValueError('Classifier checker closure changed')
                guard_index+=1
            if (seal is not sealed_object or module_signature is not expected_function
                    or module_signature.__code__ is not expected_code or module_signature.__closure__ is not expected_cells
                    or own_cell.cell_contents is not sealed_object):raise ValueError('Module classifier custody changed')
            guard_index=0
            while guard_index<held_count:
                guard_cell,guard_value=held_cells[guard_index]
                if guard_cell.cell_contents is not guard_value:raise ValueError('Module classifier closure changed')
                guard_index+=1
            # Exact-str keys and actual dict.get avoid Module __getattr__, custom
            # dict methods/hash/equality, Python checker calls and tracked iterators.
            alias_ok=True;guard_index=0
            while guard_index<actual_len(expected_aliases):
                guard_name,guard_value=expected_aliases[guard_index]
                guard_current=actual_dict_get(module_namespace,guard_name,missing)
                if guard_current is missing:guard_current=actual_dict_get(builtin_namespace,guard_name,missing)
                if guard_current is not guard_value:alias_ok=False
                guard_index+=1
            if not alias_ok:raise ValueError('Classifier alias changed during literal callback')
            index+=1
        result=actual_tuple(outputs[:used])
        diagnostics.set({'mode':'fresh-per-entry','fastEntries':fast,'literalEntries':slow})
        # All tracked key/tuple preparation precedes control inspection.
        guard_names=actual_tuple(seal_namespace);guard_module_keys=actual_tuple(module_namespace);guard_builtin_keys=actual_tuple(builtin_namespace)
        guard_index=0
        while guard_index<actual_len(guard_module_keys):
            if actual_type(guard_module_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier global key')
            guard_index+=1
        guard_index=0
        while guard_index<actual_len(guard_builtin_keys):
            if actual_type(guard_builtin_keys[guard_index])is not actual_str:raise ValueError('Nonliteral classifier builtin key')
            guard_index+=1
        if (literal.__code__ is not literal_code or aliases_unchanged.__code__ is not checker_code
                or aliases_unchanged.__closure__ is not checker_closure or seal_class.check is not seal_check
                or seal_check.__code__ is not seal_check_code or seal_class.__new__ is not seal_new
                or seal_new.__code__ is not seal_new_code or actual_len(guard_names)!=actual_len(seal_names)):
            raise ValueError('Classifier checker installation changed')
        guard_index=0
        while guard_index<actual_len(seal_members):
            guard_name,guard_member=seal_members[guard_index]
            if guard_names[guard_index]is not guard_name or seal_namespace[guard_name]is not guard_member:
                raise ValueError('Classifier seal namespace changed')
            guard_index+=1
        guard_index=0
        while guard_index<actual_len(checker_cells):
            guard_cell,guard_value=checker_cells[guard_index]
            if guard_cell.cell_contents is not guard_value:raise ValueError('Classifier checker closure changed')
            guard_index+=1
        if (seal is not sealed_object or module_signature is not expected_function
                or module_signature.__code__ is not expected_code or module_signature.__closure__ is not expected_cells
                or own_cell.cell_contents is not sealed_object):raise ValueError('Module classifier custody changed')
        guard_index=0
        while guard_index<held_count:
            guard_cell,guard_value=held_cells[guard_index]
            if guard_cell.cell_contents is not guard_value:raise ValueError('Module classifier closure changed')
            guard_index+=1
        # Exact-str keys and actual dict.get avoid Module __getattr__, custom
        # dict methods/hash/equality, Python checker calls and tracked iterators.
        alias_ok=True;guard_index=0
        while guard_index<actual_len(expected_aliases):
            guard_name,guard_value=expected_aliases[guard_index]
            guard_current=actual_dict_get(module_namespace,guard_name,missing)
            if guard_current is missing:guard_current=actual_dict_get(builtin_namespace,guard_name,missing)
            if guard_current is not guard_value:alias_ok=False
            guard_index+=1
        if not alias_ok:raise ValueError('Classifier alias changed before projection return')
        return result
    state=(literal,literal_code,actual_type,actual_tuple,actual_dict,actual_str,builtin_namespace['sorted'],actual_str.isupper,
        scalar_types,ignored_types,seal_check,seal_check_code,seal_new,seal_new_code,seal_namespace,seal_names,
        seal_members,checker_code,checker_closure,checker_cells,_LAST_MODULE_DISPATCH,expected,module_namespace,
        builtin_namespace,actual_dict.get,object(),get_profile,get_trace,monitor_get_tool,monitor_get_events,
        monitor_get_local,observer_supported,0 if monitor is None else monitor.events.PY_UNWIND,
        (module_signature.__code__,checker_code,seal_check_code,literal_code,function.__code__),actual_len)
    seal=seal_class(module_signature)
    return module_signature


module_signature=_make_module_signature()


def register(name,namespace):
    need(name in _MODULES and name not in _BASELINES)
    _BASELINES[name]=(namespace,module_signature(namespace))
    # The imported parser's globals are part of its authority too. Pin their
    # original helper functions/constants, including validators called through
    # an imported module, rather than only the outer function's __code__.
    pending=[namespace];seen=set()
    while pending:
        current=pending.pop()
        for value in tuple(current.values()):
            module=value if isinstance(value,ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            label=getattr(module,'__name__','')
            if not label.startswith(('adapters.','ios.adapters.','feature_journeys.')) or label in seen or label==__name__:continue
            seen.add(label)
            if label in _MODULES:continue
            if label not in _DEPENDENCIES:_DEPENDENCIES[label]=(vars(module),module_signature(vars(module)))
            pending.append(vars(module))


_QML_AUTHORITIES=('ios.adapters.chat_qml_owner_binding','ios.adapters.chat_qml_cache_loaded',
    'ios.adapters.chat_qml_sources','ios.adapters.qt_image_bytes','ios.adapters.bundle_identity',
    'ios.adapters.installed_code','ios.adapters.chat_script_sources')


def qml_constant(value,depth=0):
    # New loaded profiles add independently selected source-data files and
    # mutable constant grammars to the original Python parser authority.
    need(depth<=16)
    if value is None or type(value) in (str,int,float,bool):return value
    if type(value) in (bytes,bytearray):
        need(len(value)<=65536);return (type(value).__name__,bytes(value).hex())
    if isinstance(value,Path):
        need(value.is_absolute() and value.resolve(strict=True)==value)
        before=node(value);need(stat.S_ISREG(before[2]) and before[6]<=65536)
        raw=value.read_bytes();need(node(value)==before and len(raw)==before[6])
        return ('source-data-file',str(value),before,hashlib.sha256(raw).hexdigest())
    if type(value) in (tuple,list):
        need(len(value)<=1024);return (type(value).__name__,tuple(qml_constant(item,depth+1) for item in value))
    if type(value) in (set,frozenset):
        need(len(value)<=1024);return (type(value).__name__,tuple(sorted((qml_constant(item,depth+1) for item in value),key=repr)))
    if type(value) is dict:
        need(len(value)<=1024 and all(type(key) is str for key in value))
        return ('dict',tuple((key,qml_constant(value[key],depth+1)) for key in sorted(value)))
    need(False)


def qml_authority():
    # Extend authority only for a loaded-profile round. Literal profiles6/7
    # retain their original imported dependency frontier and memory key.
    pending=[]
    for name in _QML_AUTHORITIES:
        module=sys.modules.get(name);need(type(module) is ModuleType);pending.append(module)
    signatures={};seen=set();classes={}
    while pending:
        module=pending.pop();name=getattr(module,'__name__','')
        if name in seen or name==__name__:continue
        seen.add(name)
        if not name.startswith(('adapters.','ios.adapters.','feature_journeys.')):continue
        namespace=vars(module);rows=[]
        for key,value in sorted(namespace.items()):
            new_authority=name not in _DEPENDENCIES and name not in _MODULES
            if (name in _QML_AUTHORITIES or new_authority) and key.isupper() and isinstance(value,(Path,dict,list,set,bytes,bytearray)):
                rows.append((key,qml_constant(value)))
            target=value if isinstance(value,ModuleType) else sys.modules.get(getattr(value,'__module__',''))
            if type(target) is ModuleType:pending.append(target)
        # Existing immutable/function/class guards remain authoritative. The
        # new round adds only previously unreachable QML authority plus data
        # constants ignored by the old generic frontier.
        methods=None if name in _DEPENDENCIES or name in _MODULES else module_signature(namespace,class_cache=classes)
        signatures[name]=(id(module),methods,tuple(rows))
    return tuple((name,signatures[name]) for name in sorted(signatures))


def original_methods():
    classes={}
    return (all(name in _BASELINES and module_signature(_BASELINES[name][0],class_cache=classes)==_BASELINES[name][1] for name in _MODULES)
        and all(module_signature(namespace,class_cache=classes)==expected for namespace,expected in _DEPENDENCIES.values()))


def factory(context):
    from ios.adapters.chat_draft_runtime import IOSChatDraftRuntime
    from ios.adapters.chat_peer_receipts import IOSChatPeerReceipts
    from ios.adapters.chat_receive_sources import IOSChatReceiveSources
    need(type(context) is IOSChatPeerReceipts and context.bounded_sender and context.version==2 and unshadowed(context))
    wrapped=context.sender_owner;inner=getattr(wrapped,'__wrapped__',None)
    need(isinstance(inner,FunctionType) and inner.__code__ in IOSChatDraftRuntime._chat_receipt_contexts.__code__.co_consts)
    closure=inspect.getclosurevars(inner).nonlocals
    base={'contexts','fixture_url','receive','run','self'}
    need(set(closure) in (base,base|{'qml_artifacts'})
        and closure['receive'] is context.receive and type(closure['receive']) is IOSChatReceiveSources)
    artifacts=closure.get('qml_artifacts')
    if 'qml_artifacts' in closure:
        need(type(artifacts) is dict and set(artifacts)=={'primary','peer'})
        from ios.adapters.chat_qml_owner_binding import selected_artifact
        artifacts=tuple((role,selected_artifact(artifacts[role],context.receive.primary_binding if role=='primary' else context.receive.binding))
            for role in ('primary','peer'))
    contexts=closure['contexts'];need(type(contexts) is dict and set(contexts)=={'primary','peer'}
        and contexts[context.recipient_role] is context and all(type(item) is IOSChatPeerReceipts for item in contexts.values()))
    role,selector=inner.__defaults__;runtime=closure['self'];source=context.receive
    need(role==context.sender_role and closure['run']==source.run)
    path=runtime.state_path(selector).with_name('ios-chat-draft-owner.json')
    lock=source.primary_lock if role=='primary' else source.lock
    need(path==lock.path.with_name('ios-chat-draft-owner.json'))
    signature=(id(context),id(wrapped),function(inner),inner.__defaults__,closure['fixture_url'],closure['run'],
        id(source),id(runtime),id(runtime.adapter),function(runtime.state_path),function(runtime.adapter.state_path),
        tuple((role,id(contexts[role])) for role in ('primary','peer')),str(path))
    if artifacts is None:return signature
    return signature+('loaded-qml-artifacts-v1',tuple((role,str(path),digest,node(path),node(path.parent)) for role,(path,digest) in artifacts))


def memory(owner):
    value={key:getattr(owner,key) for key in _FIELDS if hasattr(owner,key)}
    value['root']=str(value['root']);value['storePath']=str(owner.store.path);value['lockPath']=str(owner.lock.path)
    if getattr(owner,'qml_bound',False):
        path,digest=owner.qml_artifact;value['qml_bound']=True;value['qmlArtifact']=(str(path),digest,node(path),node(path.parent))
    if hasattr(owner,'primary_lock'):value['primaryLockPath']=str(owner.primary_lock.path)
    frames=owner.frames
    value['frames']={key:str(getattr(frames,key)) if key=='root' else getattr(frames,key)
        for key in ('root','binding','run','role','namespace','schema_prefix','kind')}
    callbacks=tuple(function(getattr(owner,key)) for key in ('bound','guard','monotonic') if hasattr(owner,key))
    callbacks+=tuple(function(getattr(frames,key)) for key in ('guard','intent','monotonic'))
    if not hasattr(owner,'peer_receipts'):
        callbacks+=((None,None,None) if owner.historical else function(owner.parts['check']),)
    context=getattr(owner,'peer_receipts',None)
    return canonical(value),callbacks,None if context is None else factory(context)


def node(path):
    row=path.lstat()
    need(stat.S_ISREG(row.st_mode) or stat.S_ISDIR(row.st_mode))
    return (row.st_dev,row.st_ino,row.st_mode,row.st_uid,row.st_gid,row.st_nlink,row.st_size,row.st_mtime_ns,row.st_ctime_ns)


def inventory(roots):
    result=[]
    for root in roots:
        PrivateFeatureState(root/'chat-round-boundary')._parent();entries=list(root.iterdir());need(len(entries)<=4096)
        result.append((str(root),node(root),tuple(sorted((path.name,node(path)) for path in entries))))
    return tuple(result)


def eligible(owner):
    from ios.adapters.chat_draft_owner import IOSChatDraftOwner
    from ios.adapters.chat_receive_sources import IOSChatReceiveSources
    from adapters.original_frame_store import OriginalFrameStore
    from adapters.script_feature.lock import ScriptSourceLock
    if type(owner) not in (IOSChatDraftOwner,IOSChatReceiveSources):return False
    context=getattr(owner,'peer_receipts',None)
    if context is None and not (_ACTIVE.get() is not None and type(owner) is IOSChatReceiveSources):return False
    if context is not None and not (owner.source_bound and owner.version in (6,7,9,11) and owner.previous is not None):return False
    if not original_methods():return False
    if (type(owner.store) is not PrivateFeatureState or type(owner.frames) is not OriginalFrameStore
            or type(owner.lock) is not ScriptSourceLock or not all(unshadowed(item) for item in (owner,owner.store,owner.frames,owner.lock))):return False
    if context is None:return _ACTIVE.get() is not None and type(owner) is IOSChatReceiveSources
    try:
        need(unshadowed(context))
        factory(context)
        if owner.historical:
            need(owner.guard.__closure__ is None
                and owner.guard.__code__ in IOSChatDraftOwner.archive.__func__.__code__.co_consts)
        return owner.source_bound and owner.version in (6,7,9,11) and owner.previous is not None
    except (AttributeError,KeyError,TypeError,ValueError,RuntimeError):return False


def unshadowed(value):
    return all(name not in vars(value) for parent in type(value).__mro__ for name,item in vars(parent).items()
        if isinstance(item,(FunctionType,staticmethod,classmethod)))


def proof_key(owner,snapshot,value):
    # Fresh archive wrappers have fresh bound-method/lambda identities. Their
    # exact literal code is checked independently; normalize only their own
    # receiver identity when naming the same original historical subgraph.
    body,callbacks,context=snapshot;normalized=[]
    for target,code,receiver in callbacks:
        if owner.historical and target is getattr(owner,'guard',None) and code is not None:target=code
        normalized.append((target,code,None if receiver==id(owner) else receiver))
    return str(owner.store.path),body,tuple(normalized),context,canonical(value)


class ArchiveRound:
    def __init__(self,owner):
        self.source=owner.peer_receipts.receive
        source=self.source
        from adapters.original_frame_store import OriginalFrameStore
        from adapters.script_feature.lock import ScriptSourceLock
        need(type(source.store) is PrivateFeatureState and type(source.frames) is OriginalFrameStore
            and type(source.lock) is ScriptSourceLock and type(source.primary_lock) is ScriptSourceLock
            and all(unshadowed(item) for item in (source,source.store,source.frames,source.lock,source.primary_lock)))
        self.receipts=tuple(inspect.getclosurevars(owner.peer_receipts.sender_owner.__wrapped__).nonlocals['contexts'].values())
        self.contexts=tuple(factory(item) for item in self.receipts)
        self.source_memory=memory(source);self.active={};self.pending=set();self.memo={};self.memo_bytes=0
        self.closed=False;self.hits=0;self.disabled=False;self.frame_memo={};self.frame_bytes=0;self.frame_hits=0
        self.roots=tuple(sorted({Path(source.bound_record[role+'ArtifactRoot']['path']) for role in ('primary','peer')}
            |{source.store.path.parent,owner.store.path.parent,source.primary_lock.path.parent,source.lock.path.parent},key=str))
        if getattr(owner,'qml_bound',False):
            # Original selected IPA bytes are an explicit dependency. Their
            # real parent/file metadata participates in every actual lease
            # check; the first literal proof still reads and hashes the IPA.
            artifacts=inspect.getclosurevars(owner.peer_receipts.sender_owner.__wrapped__).nonlocals['qml_artifacts']
            self.roots=tuple(sorted(set(self.roots)|{path.parent for path,_digest in artifacts.values()},key=str))
        self.files=inventory(self.roots)
        self.qml_authority=qml_authority() if getattr(owner,'qml_bound',False) else None

    def check(self):
        need(not self.closed and original_methods() and memory(self.source)==self.source_memory
            and tuple(factory(item) for item in self.receipts)==self.contexts)
        if self.qml_authority is not None:need(qml_authority()==self.qml_authority)
        for owner,expected in tuple(self.active.items()):
            need(memory(owner)==expected and all(unshadowed(item) for item in (owner,owner.store,owner.frames,owner.lock)))
        need(all(unshadowed(item) for item in (self.source,self.source.store,self.source.frames,self.source.lock,self.source.primary_lock)))
        need(inventory(self.roots)==self.files)
        # Invoke the actual callbacks; a previous True verdict is never proof.
        self.source.bound()
        for owner in tuple(self.active):owner.bound()
        need(memory(self.source)==self.source_memory and inventory(self.roots)==self.files and original_methods())
        for owner,expected in tuple(self.active.items()):need(memory(owner)==expected)

    def run(self,owner,value,literal):
        snapshot=memory(owner);need(owner not in self.active)
        key=proof_key(owner,snapshot,value);need(key not in self.pending)
        self.active[owner]=snapshot;self.pending.add(key)
        started=owner.frames.now()
        try:
            self.check();owner.frames.bound(started)
            if not self.disabled and owner.historical and key in self.memo:
                result,dependencies=self.memo[key]
                for path in dependencies:record(path)
                self.hits+=1;self.check();owner.frames.bound(started)
                return deepcopy(result)
            with read_scope(fresh=True) as dependencies:result=literal()
            if any(path.parent not in self.roots for path in dependencies):self.disable()
            for path in dependencies:
                record(path)
            self.check()
            if not self.disabled and owner.historical:
                size=(len(snapshot[0])+len(key[-1])+len(canonical(result))
                    +sum(len(str(path).encode('utf-8')) for path in dependencies))
                # These are optimization storage bounds, never wire/read caps.
                # A fully validated literal result survives; its memo does not.
                self.make_frame_room(size)
                if len(self.memo)+len(self.frame_memo)>=_MAX_ENTRIES or size>_MAX_ENTRY_BYTES or self.memo_bytes+self.frame_bytes+size>_MAX_BYTES:self.disable()
                else:self.memo[key]=(deepcopy(result),frozenset(dependencies));self.memo_bytes+=size
            return result
        finally:
            self.pending.remove(key);del self.active[owner]

    def make_frame_room(self,size):
        # State-DAG proofs retain their original admission policy. Optional
        # completed frame proofs cannot consume the last space they need.
        while self.frame_memo and (len(self.memo)+len(self.frame_memo)>=_MAX_ENTRIES
                or self.memo_bytes+self.frame_bytes+size>_MAX_BYTES):
            oldest=next(iter(self.frame_memo));entry=self.frame_memo.pop(oldest);self.frame_bytes-=entry[2]

    def frame(self,owner,value,previous,dependencies,literal,*,original_reference=None):
        from ios.adapters.chat_draft_owner import IOSChatDraftOwner
        need(type(owner) is IOSChatDraftOwner and owner.qml_bound
            and (owner.historical or type(original_reference) is dict and original_reference in owner.state['records'])
            and owner.version in (9,11) and owner.peer_receipts in self.receipts
            and all(unshadowed(item) for item in (owner,owner.store,owner.frames,owner.lock)))
        snapshot=memory(owner);owned=owner not in self.active
        if owned:self.active[owner]=snapshot
        else:need(self.active[owner]==snapshot)
        key=('historical-loaded-frame-v1',)+proof_key(owner,snapshot,
            dict(value=value,previous=previous,dependencies=dependencies,originalReference=original_reference))
        need(key not in self.pending);self.pending.add(key);started=owner.frames.now()
        try:
            self.check();owner.frames.bound(started)
            if not self.disabled and key in self.frame_memo:
                result,files,size=self.frame_memo.pop(key);self.frame_memo[key]=(result,files,size)
                for path in files:record(path)
                self.frame_hits+=1;self.check();owner.frames.bound(started)
                return deepcopy(result)
            with read_scope(fresh=True) as files:result=literal()
            if any(path.parent not in self.roots for path in files):self.disable()
            for path in files:record(path)
            # The original byte read keeps its own5-second bound. Complete
            # historical typed dependency validation was not a byte read and
            # must not acquire the prototype's extra whole-frame5-second cap.
            # Existing decoder/operation/native acquisition limits are intact.
            self.check()
            size=len(snapshot[0])+len(key[-1])+len(canonical(result))+sum(len(str(path).encode('utf-8')) for path in files)
            if not self.disabled and size<=_MAX_ENTRY_BYTES:
                # Both proof kinds share the original32-entry/2-MiB limits.
                # Evict only completed frame proofs; never enlarge a limit or
                # retain a current/native result. Every miss reruns literally.
                while self.frame_memo and (len(self.memo)+len(self.frame_memo)>=_MAX_ENTRIES
                        or self.memo_bytes+self.frame_bytes+size>_MAX_BYTES):
                    oldest=next(iter(self.frame_memo));entry=self.frame_memo.pop(oldest);self.frame_bytes-=entry[2]
                if len(self.memo)+len(self.frame_memo)<_MAX_ENTRIES and self.memo_bytes+self.frame_bytes+size<=_MAX_BYTES:
                    self.frame_memo[key]=(deepcopy(result),frozenset(files),size);self.frame_bytes+=size
            return result
        finally:
            self.pending.remove(key)
            if owned:del self.active[owner]

    def disable(self):
        self.disabled=True;self.memo.clear();self.memo_bytes=0;self.frame_memo.clear();self.frame_bytes=0

    def close(self):
        try:self.check();need(not self.active and not self.pending)
        finally:
            # Counts contain no input, original, decoded tree or reusable proof.
            _LAST_FRAME_COUNTS.set((self.frame_hits,len(self.frame_memo)))
            _LAST_COUNTS.set((self.hits,len(self.memo)));self.closed=True;self.memo.clear();self.memo_bytes=0;self.frame_memo.clear();self.frame_bytes=0


@contextmanager
def construction(owner):
    _LAST_CONSTRUCTION.set(None) # Numeric diagnostics only, never a reusable proof.
    # The saved decoder and its immediately following original-reader floor
    # restoration are ONE synchronous read-only construction. There is no
    # native query/input/write here; every real current callback still runs.
    # Closing the decoder's scope early used to force a fresh recursive graph
    # merely to reopen the already validated final record for those floors.
    if (_ACTIVE.get() is not None or not owner.qml_bound or owner.version not in (9,11)
            or not eligible(owner)):
        yield;return
    try:current=ArchiveRound(owner)
    except (AttributeError,KeyError,TypeError,ValueError,RuntimeError):
        yield;return
    token=_ACTIVE.set(current)
    try:yield
    finally:
        try:
            current.close()
            _LAST_CONSTRUCTION.set(dict(scopeClosed=True,disabled=current.disabled,
                frameHits=current.frame_hits,profile=owner.version))
        finally:_ACTIVE.reset(token)


def decode(owner,value,literal):
    current=_ACTIVE.get()
    if not eligible(owner):
        if current is not None:current.disable()
        return literal()
    if current is not None:return current.run(owner,value,literal)
    try:current=ArchiveRound(owner)
    except (AttributeError,KeyError,TypeError,ValueError,RuntimeError):return literal()
    token=_ACTIVE.set(current)
    try:return current.run(owner,value,literal)
    finally:
        try:current.close()
        finally:_ACTIVE.reset(token)


def completed_record(owner,reference,value,previous,literal):
    current=_ACTIVE.get()
    # Live readers can revisit immutable ACCEPTED historical records. Actual
    # frame files are still read before this function. Fresh/current captures
    # have no accepted reference and cannot enter this path.
    if (current is None or owner.historical or not owner.qml_bound
            or owner.version not in (9,11) or reference not in owner.state['records']):return literal()
    return current.frame(owner,value,previous,True,literal,original_reference=reference)


def historical_frame(owner,value,previous,dependencies,literal):
    current=_ACTIVE.get()
    # Literal profiles and live/native owners keep their exact literal path.
    # A saved frame is reusable only in the already protected synchronous
    # loaded-profile historical graph, never as a current observation.
    if (current is None or not owner.historical or not owner.qml_bound
            or owner.version not in (9,11)):return literal()
    return current.frame(owner,value,previous,dependencies,literal)


def set_state(owner,state):
    current=_ACTIVE.get()
    if current is not None and owner in current.active:
        need(memory(owner)==current.active[owner]);owner.state=state;current.active[owner]=memory(owner)
    else:owner.state=state


def mutation():
    # A pure decoder cannot retain or consume a proof after beginning a write,
    # query, UI input or live capture. Refuse before that boundary has effects.
    need(_ACTIVE.get() is None)
