"""PRIVATE source composition only: no imports of targets, tests or compilers."""
from pathlib import Path
import ast,hashlib,json,difflib

ROOT=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026')
P=ROOT/'.ios-host-tmp/lifecycle-original-owner-native-motion-worker-scope-proposal-20261028'
BASE=ROOT/'.ios-host-tmp/lifecycle-original-owner-native-current-predown-proposal-20261028'
PATHS=['tests/device/ios/pymobiledevice3_wda_xctest.py','tests/device/ios/adapters/lifecycle_touch_resource_owner.py','tests/device/ios/adapters/lifecycle_world_hold.py']
originals={p:(BASE/'candidate/repo'/p if i<2 else ROOT/p).read_text() for i,p in enumerate(PATHS)}
texts=dict(originals)
def change(p,old,new):
    assert texts[p].count(old)==1,(p,old[:150],texts[p].count(old))
    texts[p]=texts[p].replace(old,new)
keeper,resource,hold=PATHS
guard=(P/'native_worker_guard.phase_boundaries.py').read_text()
guard=guard.replace("self._contact=None", "self._contact=None\n        from ios.adapters.touch import validate_actions\n        path=resource.state['path'];window=path['window']\n        actions=validate_actions(dict(actions=[dict(type='pointer',id='original-motion-worker',parameters=dict(pointerType='touch'),actions=[\n            dict(type='pointerMove',duration=0,origin='viewport',x=path['start'][0],y=path['start'][1]),\n            dict(type='pointerDown',button=0),dict(type='pointerMove',duration=0,origin='viewport',x=path['end'][0],y=path['end'][1]),\n            dict(type='pointerUp',button=0)])]),window['width'],window['height'])\n        self._hid_start,self._hid_end=actions[0][1],actions[2][1]")
guard=guard.replace("lease.previous['position']==path['start']", "tuple(lease.previous['position'])==tuple(self._hid_start)")
guard=guard.replace("lease.previous['deadlineMonotonic']-lease.previous['startedMonotonic']==self._resource().state['seconds']", "lease.previous['deadlineMonotonic']==lease.previous['startedMonotonic']+self._resource().state['seconds']")
change(resource,'class LifecycleTouchResourceOwner:',guard+'class LifecycleTouchResourceOwner:')
change(resource,'self._motion_failed=False;self._motion_original=None','self._motion_failed=False;self._motion_original=None;self._native_step=None')
change(resource,'self._target=None;self._failed=False;self._selected=selected;self._selected_id=selected_id','self._target=None;self._failed=False;self._selected=selected;self._selected_id=selected_id;self._worker_guard=None;self._worker_phase=None')
change(resource,'                and not source._leases and not source._born and owner.touch is None\n','')
change(resource,"            target=None if self._target is None else self._target()", "            if self._worker_guard is None:need(not source._leases and not source._born and owner.touch is None)\n            else:\n                need(type(self._worker_guard) is _NativeMotionWorkerGuard and self._worker_guard._original() is not None\n                    and self._worker_guard._original()._selected is self._selected)\n                self._worker_guard._scope_without_ref()\n            target=None if self._target is None else self._target()")
change(resource,"        if self.version==4:\n            raise TouchTransportUnavailable('Original selected-IPA preparation exists; fresh current Down/movement guard is not connected')", "        if self.version==4:\n            if type(self._native_step) is not _NativeMotionWorkerGuard:\n                raise TouchTransportUnavailable('Original selected-IPA preparation exists; fresh current Down/movement guard is not connected')\n            return self._make_native_motion_lease(store,rsd,local_address,check=check,options=options,\n                admit_begin=admit_begin,on_worker_birth=on_worker_birth,worker_lock=worker_lock)")
change(resource,'    def intent(self,kind,reference):', '''    def _make_native_motion_lease(self,store,rsd,local_address,*,check,options,admit_begin,on_worker_birth,worker_lock):
        # Private source-born seam only. The normal RPC cannot install the
        # actual weak owner/lease bridge; restored DTO/WAL cannot recreate it.
        from ios.adapters.lifecycle_world_hold import _MotionContext
        step=self._native_step;step.scope()
        need(isinstance(store,PrivateFeatureState) and store.path!=self.store.path and store.read() is None
            and store.path.parent==self.store.path.parent and store.path.name=='ios-lifecycle-touch-lease-'+self.run+'.json'
            and rsd is self._motion_rsd() and local_address==self._motion_address and self._factory is None
            and callable(check) and worker_lock is True and callable(admit_begin) and callable(on_worker_birth))
        options={} if options is None else dict(options)
        need(set(options)<={'display_factory','hid_factory','socket_factory'} and all(callable(value) for value in options.values()))
        @asynccontextmanager
        async def selected_factory():
            # The SAME original worker owns this lock, SDK context and HID.
            with self.lock.held():
                step.scope();lease=self._lease()
                need(lease is not None and lease.worker is asyncio.current_task() and lease._session_factory is self._factory)
                self._source=resources.TouchResourceObservation(rsd);self._retained=RetainedTouchWorker(lease)
                self._loop=asyncio.get_running_loop()
                actual=lambda:touch_session(rsd,local_address,observation=self._source,**options)
                async with _MotionContext(actual,step._hid_start,step._hid_end,step.movement,
                        before_down=lambda:step.checkpoint('before-down')) as hid:yield hid
        self._factory=selected_factory
        lease=TouchLease(store,selected_factory,binding=self.binding,run=self.run,check=check,
            admit_begin=admit_begin,on_worker_birth=on_worker_birth)
        self._lease=weakref.ref(lease);step.bind_lease(lease,selected_factory);return lease

    def intent(self,kind,reference):''')
# Preserve default _MotionContext input order; optional synchronous checkpoint
# is only used by the private original-child bridge.
change(hold,'    def __init__(self,factory,start,end,check):','    def __init__(self,factory,start,end,check,*,before_down=None):')
change(hold,'        self.actual=None;self.hid=None;self.sent=False;self._actual_exit=None','        need(before_down is None or callable(before_down));self.before_down=before_down\n        self.actual=None;self.hid=None;self.sent=False;self._actual_exit=None')
change(hold,'                    need(not self.sent);self.sent=True\n                    await hid.send_touchscreen(state,*start)', '''                    need(not self.sent);self.sent=True
                    if self.before_down is not None:
                        result=self.before_down();need(not inspect.isawaitable(result) and result is not False)
                    await hid.send_touchscreen(state,*start)''')
# Original source registers actual worker responsibility FIRST; only then bind
# optional worker identity, never a task id supplied by RPC.
change(keeper,"        row['owner'] = RetainedTouchWorker(lease)\n        return row", "        row['owner'] = RetainedTouchWorker(lease)\n        resource=getattr(lease,'_original_motion_resource',None)\n        if resource is not None:\n            from ios.adapters.lifecycle_touch_resource_owner import LifecycleTouchResourceOwner,_NativeMotionWorkerGuard\n            if type(resource) is not LifecycleTouchResourceOwner or type(resource._native_step) is not _NativeMotionWorkerGuard:\n                raise LaunchError('session-lifetime')\n            resource._native_step.born(lease,task)\n        return row")
# Source generic _birth accesses immutable local association set before begin.
change(resource,'        self._lease=weakref.ref(lease);step.bind_lease(lease,selected_factory);return lease','        self._lease=weakref.ref(lease);lease._original_motion_resource=self\n        step.bind_lease(lease,selected_factory);return lease')
# Selected ArtifactLease original source closure must permit only the exact
# already-captured local worker transition; no blanket acceptance of born state.
change(keeper,"                        or owner.touch is not None or actual._born or actual._leases\n",'')
change(keeper,"                if state['returned']:result['lease'].guard()", "                worker_guard=state.get('motionGuard')\n                if worker_guard is None:\n                    if owner.touch is not None or actual._born or actual._leases:raise LaunchError('session-lifetime')\n                else:\n                    from ios.adapters.lifecycle_touch_resource_owner import _NativeMotionWorkerGuard\n                    bridge=worker_guard()\n                    if type(bridge) is not _NativeMotionWorkerGuard or bridge._source() is not actual or bridge._owner() is not owner:\n                        raise LaunchError('session-lifetime')\n                    bridge._scope_without_ref()\n                if state['returned']:result['lease'].guard()")
# New local entrypoint does not change any execute/RPC path or canonical gate.
change(keeper,'    async def native_before_down(self,resource):', '''    def motion_worker_lease(self,resource):
        """Private local source integration; no RPC/configuration capability."""
        from adapters.normal_feature_state import PrivateFeatureState
        from ios.adapters.lifecycle_touch_resource_owner import LifecycleTouchResourceOwner,_NativeMotionWorkerGuard
        if (type(resource) is not LifecycleTouchResourceOwner or resource is not self.touch_resources
                or self.touch is not None or self.source._born or self.source._leases):raise LaunchError('session-lifetime')
        with resource.lock.held():
            step=_NativeMotionWorkerGuard(resource,self.source,self)
            try:
                lease=self.source.touch_lease(PrivateFeatureState(resource.store.path.with_name('ios-lifecycle-touch-lease-'+resource.run+'.json')),
                    binding=resource.binding,run=resource.run,check=step.continuity,resource_owner=resource)
                self.touch=lease;step.scope();return lease
            except BaseException:
                step.fail();raise

    async def native_motion_step(self,resource,step,phase):
        """OWN native original interval at each actual Down/Move boundary."""
        from ios.adapters.lifecycle_touch_resource_owner import LifecycleTouchResourceOwner,_NativeMotionWorkerGuard,_NativeMotionReference
        from ios.adapters import lifecycle_world as world,native_geometry
        if (type(resource) is not LifecycleTouchResourceOwner or type(step) is not _NativeMotionWorkerGuard
                or resource._native_step is not step or phase not in ('before-down','after-down')
                or asyncio.current_task() is not step._worker()):raise LaunchError('session-lifetime')
        step.scope();lease=step._lease()
        if ((phase=='before-down' and (lease.down_issued or lease.previous['phase']!='down-issued'))
                or (phase=='after-down' and (not lease.down_issued or lease.up_issued))):raise LaunchError('session-lifetime')
        loop=asyncio.get_running_loop();started=loop.time();epoch=time.time()*1000;deadline=min(started+1.5,lease._deadline())
        original=resource._motion_original
        try:
            anchor=original.anchor(self.source,resource,self.instance);step.scope()
            owner=self.native_query_journals[resource.run]
            args=dict(binding=deepcopy(resource.binding),runId=resource.run,resultsDirectory=owner['directory'],origin=owner['origin'],selectedQueryId=resource.state['selectedQueryId'])
            if len(self.source._native_current_tasks)>=8 or any(not t.done() for t in self.source._native_current_tasks):raise LaunchError('session-lifetime')
            async def acquire():
                try:return await self.native_acquire(args,resource.binding['sessionId'],_motion_window=True,_current_resource=resource)
                finally:self.native_current_cuts.pop(asyncio.current_task(),None)
            task=asyncio.create_task(acquire(),name='original-native-motion-'+phase)
            self.native_current_cuts[task]=(resource,started,epoch,deadline,step,phase)
            self.source._native_current_tasks.append(task);self.operations.add(task);task.add_done_callback(self.operations.discard)
            done,_=await asyncio.wait({task},timeout=max(0.,deadline-loop.time()))
            if task not in done:raise LaunchError('session-lifetime')
            receipt=task.result()
            if type(receipt) is not _NativeMotionReference:raise LaunchError('session-lifetime')
            current=receipt.original(self.source,resource,self.instance);step.scope()
            old,new=anchor['originals']['world'],current['originals']['world']
            if world.context(old)!=world.context(new) or anchor['originals']['window']!=current['originals']['window']:raise LaunchError('session-lifetime')
            geometry=[]
            for frame in (anchor,current):
                raw=frame['originals']['geometry'];doc,view=native_geometry.validate(raw,raw['commandId'],native_epoch_ms=frame['clockJoin']['nativeAfter']['capturedEpochMs'])
                geometry.append((doc['nativeUi'],doc['window'],view))
            if geometry[0]!=geometry[1]:raise LaunchError('session-lifetime')
            a,b=world.touch.pad(old['source']['pad']),world.touch.pad(new['source']['pad'])
            if (a is None or b is None or not b['active'] or not b['enabled'] or b['hidden'] or not b['fixed']
                    or any(a[k]!=b[k] for k in ('objectId','viewport','fixed','center','radius'))):raise LaunchError('session-lifetime')
            facts=world.measure(old,new)
            if facts['heldInputs'] or facts['worldDisplacement']>.025 or any(new['source']['drive']['raw']):raise LaunchError('session-lifetime')
            if phase=='before-down':
                if b['moveValid'] or new['source']['touch']['active']:raise LaunchError('session-lifetime')
            else:
                contact=world.contact_attempt(old,new)
                if (new['source']['touch']['active']!=[contact['contactId']] or contact['ended'] is not None
                        or contact['route']!='world' or contact['lastRoute']!='world' or not b['moveValid']
                        or contact['nativeId']!=b['moveNativeId'] or b['moveOrigin']!=a['center']
                        or contact['position']!=b['movePoint']
                        or any(abs(x-y)>1 for x,y in zip(contact['position'],a['center']))):raise LaunchError('session-lifetime')
                events=[e for e in new['source']['touch']['events'] if any(p['id']==contact['contactId'] for p in e['points'])]
                if not events or any(e['route']!='world' for e in events):raise LaunchError('session-lifetime')
                step._contact=contact['contactId']
            if loop.time()>=deadline:raise LaunchError('session-lifetime')
            return receipt
        except BaseException:
            step.fail();raise

    async def native_before_down(self,resource):''')
# Exact current-capture token extends old4tuple only for actual local bridge.
change(keeper,"        current_cut=None\n        if _current_resource is not None:","        current_cut=None;worker_step=None\n        if _current_resource is not None:")
change(keeper,"            _current_resource.file_guard()\n        journal=self._native_acquisition_owner", "            _current_resource.file_guard()\n            if len(current_cut)==6:\n                from ios.adapters.lifecycle_touch_resource_owner import _NativeMotionWorkerGuard\n                worker_step=current_cut[4]\n                if type(worker_step) is not _NativeMotionWorkerGuard or _current_resource._native_step is not worker_step:raise LaunchError('session-lifetime')\n                worker_step.scope()\n            elif len(current_cut)!=4:raise LaunchError('session-lifetime')\n        journal=self._native_acquisition_owner")
change(keeper,"            if (touch is not None or (resource is not None and resource is not _current_resource) or journal['source']._leases or journal['source']._born\n", "            if (((worker_step is None and (touch is not None or journal['source']._leases or journal['source']._born))\n                    or (resource is not None and resource is not _current_resource))\n")
change(keeper,'        if current_cut is not None:started,epoch,deadline=current_cut[1:]','        if current_cut is not None:started,epoch,deadline=current_cut[1:4]')
change(keeper,"                _current_resource.file_guard()\n            if selected is not None:", "                _current_resource.file_guard()\n                if worker_step is not None:worker_step.scope()\n            if selected is not None:")
change(keeper,'                if current_cut is not None:receipt._target=weakref.ref(_current_resource)', '                if current_cut is not None:receipt._target=weakref.ref(_current_resource)\n                if worker_step is not None:receipt._worker_guard=worker_step;receipt._worker_phase=current_cut[5]')
# Write only this new private candidate tree. No public target mutations.
rows=[];diff=[]
for p in PATHS:
    candidate=P/'candidate/repo'/p;candidate.parent.mkdir(parents=True,exist_ok=True);candidate.write_text(texts[p]);ast.parse(candidate.read_bytes())
    base=BASE/'candidate/repo'/p if p!=hold else ROOT/p
    rows.append(dict(path=p,base=str(base),baseSHA256=hashlib.sha256(originals[p].encode()).hexdigest(),candidate=str(candidate),candidateSHA256=hashlib.sha256(candidate.read_bytes()).hexdigest()))
    diff.extend(difflib.unified_diff(originals[p].splitlines(True),texts[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(P/'source3.diff').write_text(''.join(diff))
(P/'checkpoint-phase-source.json').write_text(json.dumps(dict(status='PRIVATE_CHECKPOINT_AST_ONLY_UNRUN_NOT_FINAL',files=rows,dependencyFreeze='8d26a06a14343d85eae796b8312ba4393fe7eda8dc22f302ab8ce3e1acd96330',canonicalGate=False,nativeTouchSupport=False,nativeMotionGuardAvailable=False,rpcDownUnchanged=True,unchangedMaximumSeconds=12,continuousNativeFreshnessClaim=False),indent=2)+'\n')
print(json.dumps(dict(paths=len(rows),diffSha256=hashlib.sha256((P/'source3.diff').read_bytes()).hexdigest(),files=rows),indent=2))
