"""Restoration lower Actor producer with identity selected before birth; real owned packet/files/lock constructors.

No native/SDK/domain transport is executed. Motion arrives through an explicit
lower peer event between queries; the query receives no desired avatar/pose.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import base64,hashlib,json,uuid,time
from copy import deepcopy
from unittest.mock import patch
from adapters.native_feature_observation import need
from adapters.script_feature.lock import ScriptSourceLock
from adapters.normal_feature_state import PrivateFeatureState
from feature_journeys.phase_fixture import PhaseFixtureReader
from feature_journeys.witness import Client,Journal
from ios.adapters import avatar_world,feature_observation,appium_adapter
from ios.adapters.normal_scripts import PROFILE
from ios.adapters.lifecycle_received_actor_world import IOSLifecycleReceivedActorRuntime
from ios.adapters.lifecycle_received_actor_world import LifecycleReceivedActorWorld
from ios.adapters import lifecycle_received_world
from ios.self_tests.test_ios_installed_adapter import InstalledAdapterTests
from ios.self_tests.test_ios_avatar_world import packet as base_world

PRIMARY='00000000-0000-4000-8000-000000000001'
ACTOR='00000000-0000-4000-8000-000000000002'
TICKET='d'*32


class LifecycleRestorationActorDomain:
    def __init__(self,case,run,*,primary_session,domain_id):
        need(str(uuid.UUID(primary_session))==primary_session and str(uuid.UUID(domain_id))==domain_id)
        self.primary_session,self.domain_id=primary_session,domain_id
        self.run=run;primary_post=feature_observation.post_request
        self.ctx=InstalledAdapterTests();self.ctx.setUp();case.addCleanup(self.ctx.doCleanups)
        self.ctx.target.update(serverUrl='http://controlled.invalid:4724',normalScripts=dict(contractVersion=1,profile=PROFILE),
            nativeUiObservation=dict(kind='uikit-documents',version=1))
        self.ctx.target['testBuild']['fixtureOrigin']='http://controlled.invalid:49122'
        self.ctx.adapter._state['targetFingerprint']=self.ctx.adapter.fingerprint()
        self.ctx.adapter.describe('test-only')
        self.clock=lambda:int(time.time()*1000);self.mono=time.monotonic
        self.lock=ScriptSourceLock(self.ctx.adapter.state_path('test-only').with_name('script-feature-sources.lock'))
        self.position=[0.,0.,0.];self.velocity=[0.,0.,0.];self.sequence=0;self.queries=[];self.raw=None
        self.receive_sequence=0;self.records=[];self.ignore_packet=False;self.actor_lifetime="7"*32;self.primary_lifetime="8"*32
        self.posts=[];self.drop_post=False;self.lose_post=False
        self.birth_position=deepcopy(self.position);self.restore_events=0;self.ignore_restore=False
        self.receive_event()
        self.lost=False;self.ignore_peer=False;self.good=True;self.fault=None
        self.journal=Journal(clock=self.clock,lifecycle_actor_originals=True)
        # Existing coordinator allocator is modeled before any source original.
        with patch('feature_journeys.witness.secrets.token_hex',return_value=run):need(self.journal.register('lifecycle-input')==run)
        self.journal.activate(run,TICKET,'baseline',{})
        domain=self
        class PhaseTransport(Client):
            def request(self,path,value=None,method=None,*,phase_nonce=None,**_kwargs):
                if path=='/runs/'+run+'/phase':
                    need(value is None and phase_nonce is not None);return domain.journal.phase(run,phase_nonce)
                if path=='/runs/'+run:
                    need(value is None);return domain.journal.snapshot(run)
                need(path=='/runs/'+run+'/samples'and self.token=='a'*64 and type(value)is dict)
                domain.posts.append(deepcopy(value))
                if not domain.drop_post:domain.journal.publish(run,value)
                if domain.lose_post:
                    domain.lose_post=False;raise OSError('Canonical Journal accepted original; return lost')
                return {}
        self.client=PhaseTransport('https://controlled.invalid/feature-fixture/v1','a'*64,monotonic=self.mono,sleep=self.ctx.clock.sleep)
        self.phase=PhaseFixtureReader(self.client,run,'lifecycle-input',epoch_ms=self.clock,monotonic=self.mono)
        prior=feature_observation.post_request
        def post(request,timeout):
            if not request.full_url.startswith('http://controlled.invalid:49122/'):
                return primary_post(request,timeout)
            query=json.loads(request.data)
            if query.get('action')!=lifecycle_received_world.ACTION:return prior(request,timeout)
            need(timeout==5);lifecycle_received_world.command(query);self.sequence+=1;self.queries.append(deepcopy(query))
            value=base_world(42);value.update(requestId=query['commandId'],runId=run,sequence=self.sequence)
            for marker in(value['source']['markers'][0],value['source']['scriptOriginal']['source']['effects']['entities'][0]):
                data=json.loads(marker['userData']);data['runId']=run;marker['userData']=json.dumps(data)
            value['source']['domain']['selfSha256']=hashlib.sha256(uuid.UUID(ACTOR).bytes).hexdigest()
            value['source']['domain']['avatarMixerSha256']='c'*64
            value['source']['domain']['domainId']=self.domain_id
            value['source']['bodies']=dict(avatarBodyCollectionVersion=1,instance='c'*32,sequence=self.sequence,capturedEpochMs=20000,complete=True,
                avatars=[dict(sessionId=self.primary_session,self=False,replicated=False,position=deepcopy(self.position),orientation=[0,0,0,1],velocity=deepcopy(self.velocity)),
                    dict(sessionId=ACTOR,self=True,replicated=False,position=[2,0,4],orientation=[0,0,0,1],velocity=[0,0,0])])
            world=value
            value=dict(iosLifecycleReceivedWorldVersion=1,requestId=query['commandId'],runId=run,instance='6'*32,
                sequence=self.sequence,processId=42,clockDomain='native-main-lifecycle-received-world',
                clockBefore=deepcopy(world['clockBefore']),clockAfter=deepcopy(world['clockAfter']),
                source=dict(world=world,bodyLifetimes={hashlib.sha256(uuid.UUID(self.primary_session).bytes).hexdigest():self.primary_lifetime,
                    hashlib.sha256(uuid.UUID(ACTOR).bytes).hexdigest():self.actor_lifetime},
                    receivedRoots=dict(avatarReceivedRootVersion=1,instance='5'*32,processId=42,
                        selfSha256=world['source']['domain']['selfSha256'],complete=True,receiveSequence=self.receive_sequence,
                        droppedRecords=max(0,self.receive_sequence-32),records=deepcopy(self.records[-32:]))))
            if self.fault is not None:self.fault(value)
            self.raw=json.dumps(value,indent=1)+'\n'
            encoded=json.dumps(query).encode()
            class Response:
                status=200
                def __enter__(receiver):return receiver
                def __exit__(receiver,*_args):return False
                def read(receiver,limit):return encoded[:limit]
            if self.lost:raise OSError('Actual lower Actor getter returned; HTTP return lost')
            return Response()
        lower=patch.object(feature_observation,'post_request',post);lower.start();case.addCleanup(lower.stop)
        original_client=self.ctx.adapter.client
        class ActorSDKClient:
            def call(receiver,method,path,*args):
                need(method=='GET'and path=='/session/test-only'and not args);return {}
            def execute(receiver,session,operation,values):
                if operation=='mobile: pullFile'and values['remotePath'].endswith('/'+lifecycle_received_world.FILE):
                    need(session=='test-only'and self.raw is not None)
                    return base64.b64encode(self.raw.encode()).decode('ascii')
                return original_client.execute(session,operation,values)
        self.sdk_client=ActorSDKClient();self.runtime=IOSLifecycleReceivedActorRuntime(self.ctx.adapter)
        # The actual canonical installed candidate/SDK Source constructor runs.
        # Only its pre-existing lower WebDriver transport is modeled.
        with patch.object(appium_adapter,'WebDriver',return_value=self.sdk_client):
            self.source=self.runtime._sources('test-only')
        self.binding=self.source['binding'];self.feature=self.source['observer'];self.native=self.source['clock_source']
    def peer_event(self):
        # Declared model's independent receiver event, not a reader callback or
        # copied Primary observation/request. Ignoring this event stays visible.
        if not self.ignore_peer:
            self.position[2]-=.7;self.velocity=[0,0,-.5]
            if not self.ignore_packet:self.receive_event()
    def restore_peer_event(self):
        # A separate declared receiver event after the original ordinary Go
        # returns. No URL, requested pose or Primary packet is received here.
        self.restore_events+=1
        if not self.ignore_restore:
            self.position=deepcopy(self.birth_position);self.velocity=[0.,0.,0.]
            if not self.ignore_packet:self.receive_event()
    def receive_event(self):
        # Declared wire-model producer event, independent of every read/input
        # request. These are not native socket/packet-parser runtime results.
        raw=json.dumps(dict(position=self.position,orientation=[0,0,0,1],source=self.primary_session),sort_keys=True).encode()
        self.receive_sequence+=1
        self.records.append(dict(avatarInstance=self.primary_lifetime,replicated=False,carriesPosition=True,carriesOrientation=True,
            wirePosition=deepcopy(self.position),wireOrientation=[0,0,0,1],receiveSequence=self.receive_sequence,
            capturedEpochMs=20000,avatarSha256=hashlib.sha256(uuid.UUID(self.primary_session).bytes).hexdigest(),
            mixerSha256='c'*64,recordSha256=hashlib.sha256(raw).hexdigest(),recordBytes=len(raw)))
    def guard(self):
        need(self.good and self.source['check']()is not False);return True
    def owner(self,index,*,historical=False):
        path=self.ctx.root/('ios-lifecycle-received-actor-world-'+format(index,'04d')+'.json')
        args=(PrivateFeatureState(path),self.lock,self.binding,self.run,index,self.phase.fixture_url)
        if historical:return LifecycleReceivedActorWorld(*args,historical=True)
        return LifecycleReceivedActorWorld(*args,phase=self.phase,feature=self.feature,native=self.native,
            guard=self.guard,epoch_ms=self.clock,monotonic=self.mono)
