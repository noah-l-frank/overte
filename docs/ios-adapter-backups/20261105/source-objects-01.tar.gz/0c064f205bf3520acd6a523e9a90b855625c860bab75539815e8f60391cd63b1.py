"""One no-build pure metadata cache probe; no timing or qualification claim."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import hashlib,importlib.util,json,os,socket,sys
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
PROTOTYPE=ROOT/'.ios-host-tmp/photos-checked-tree-descriptor-proposal.py'
from adapters.normal_feature_state import PrivateFeatureState
from feature_journeys.scenarios import SCENARIOS
from ios.adapters import snapshot_photos_end_round as literal
before={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest() for path in (PROTOTYPE,Path(literal.__file__),ROOT/'tests/device/feature_journeys/scenarios.py',Path(__file__))}
spec=importlib.util.spec_from_file_location('private_checked_tree_cache_probe_target',PROTOTYPE)
proposal=importlib.util.module_from_spec(spec);spec.loader.exec_module(proposal)
counts=[]
def counted(value):counts.append(id(value));return literal.data(value)
seen_nodes=0
primitive=(str,int,float,bool,bytes,type(None))
def unsupported(value,path=(),depth=0,seen=None):
 global seen_nodes
 seen_nodes+=1
 kind=type(value)
 if kind in primitive or depth>=6:return None
 if kind not in (dict,list,tuple):
  known={set:'set',frozenset:'frozenset'}
  return dict(path=list(path),reason='unsupported-type',type=known.get(kind,'non-builtin-container-or-opaque'),typeIdentity=id(kind),depth=depth)
 seen=set() if seen is None else seen
 if id(value) in seen:return dict(path=list(path),reason='cycle',depth=depth)
 if kind is dict and any(type(key) is not str for key in value):return dict(path=list(path),reason='non-exact-string-key',depth=depth)
 seen.add(id(value))
 try:
  rows=value.items() if kind is dict else enumerate(value)
  for key,item in rows:
   found=unsupported(item,(*path,key),depth+1,seen)
   if found is not None:return found
 finally:seen.remove(id(value))
 return None

def forbidden(*args,**kwargs):raise AssertionError('Pure metadata probe attempted an external effect')
with patch.object(PrivateFeatureState,'read',forbidden),patch.object(PrivateFeatureState,'write',forbidden),patch.object(PrivateFeatureState,'discard',forbidden),patch.object(socket,'socket',forbidden):
 reader=proposal.tree_reader(SimpleNamespace(data=counted))
 first=reader(SCENARIOS);first_count=len(counts);second=reader(SCENARIOS);second_count=len(counts)
 failure=unsupported(SCENARIOS)
after={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in before};assert before==after
report=dict(scope='PURE_ACTUAL_SCENARIOS_METADATA_ONLY',firstDataCallCount=first_count,totalDataCallCount=second_count,secondAvoidedLiteralData=second_count==first_count,descriptorsEqual=first==second,firstUnsupported=failure,strictBuiltinNodesVisited=seen_nodes,sourceAndLauncherPins=before,noPFSReads=True,noSDK=True,noNetwork=True,noPerformanceClaim=True)
(OUT/'report.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps(report,sort_keys=True))
