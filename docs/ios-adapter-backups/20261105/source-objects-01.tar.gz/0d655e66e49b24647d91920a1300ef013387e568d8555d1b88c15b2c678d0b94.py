"""Genuine lower checkpoint endpoint constructor before any Parsed owner exists.

This is a modeled raw native/Domain producer, not a live Assets owner or a
native process observation. Each query reads its own held world and fresh action
and lock custody; no requested scenario value or primary result is accepted.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import json,uuid
from adapters.native_feature_observation import need
from adapters.script_feature.history import same
from ios.adapters.assets_action_phase import AssetsActionScope
from ios.self_tests.assets_scene_facts_fixture import instantiate_native
from ios.self_tests.test_ios_create_peer import domain_pair


class CheckpointSceneEndpoint:
    def __init__(self,fixture,observer,selector,role,lock):
        need(role in ('primary','actor-primary','actor') and observer.driver is fixture.driver)
        action=observer.action
        need(type(action) is AssetsActionScope and action.owner is fixture.a.owner)
        subject='actor' if role=='actor' else 'primary'
        selected=fixture.selected;info=selected.context['roles'][subject]
        need(selector==info['target'])
        episode=observer.episode
        expected=action.owner.locks[subject] if episode is None else episode.locks[subject]
        need(lock is expected)
        root=Path(info['stateRoot']) if episode is None else Path(episode.descriptor['directories'][subject]['stateRoot']['path'])
        need(root.is_dir() and not root.is_symlink() and lock.path==root/'script-feature-sources.lock')
        self.fixture,self.boundary,self.role=fixture,fixture.boundary,role
        self.action,self.selection,self.episode,self.subject=action,selected,episode,subject
        self.selector,self.root,self.lock=selector,root,lock
        self.binding=deepcopy(info['binding']);self.pid=int(self.binding['processIdentity'])
        self.world=fixture.boundary.peer if role=='actor' else fixture.boundary
        self.raw={};self.counts=dict(clock=0,state=0,domain=0,origin=0);self.queries=[]
        self.instance=uuid.uuid4().hex;self.domain_instance=uuid.uuid4().hex
        self.monotonic=self.boundary.monotonic;self.epoch_ms=self.boundary.clock
        self.guard()
    def guard(self):
        self.action.guard();self.selection.selected_guard();self.lock.assert_held()
        info=self.selection.context['roles'][self.subject]
        expected=self.action.owner.locks[self.subject] if self.episode is None else self.episode.locks[self.subject]
        root=Path(info['stateRoot']) if self.episode is None else Path(self.episode.descriptor['directories'][self.subject]['stateRoot']['path'])
        if self.episode is not None:self.episode.guard()
        need(self.selection is self.action.owner.selected and self.lock is expected
            and self.selector==info['target'] and same(self.binding,info['binding'])
            and self.pid==int(info['binding']['processIdentity']) and self.root==root
            and self.lock.path==root/'script-feature-sources.lock' and root.is_dir() and not root.is_symlink()
            and self.world is (self.boundary.peer if self.role=='actor' else self.boundary)
            and self.boundary is self.fixture.boundary and self.boundary.live)
        return True
    def send(self,kind,query):
        self.guard();need(kind in self.counts)
        self.queries.append((kind,deepcopy(query)));self.counts[kind]+=1;self.boundary.tick()
        if kind=='clock':packet=instantiate_native(self.world.clock(),self.pid,self.instance,self.counts[kind])
        elif kind=='state':packet=self.world.state(query['commandId']);packet['processId']=self.pid
        elif kind=='origin':packet=self.world.origin(query);packet['processId']=self.pid
        else:
            state=self.world.state();state['processId']=self.pid
            packet=domain_pair(state,state)[0];packet.update(instance=self.domain_instance,sequence=self.counts[kind])
        packet['requestId']=query['commandId'];raw=json.dumps(packet)
        self.guard();self.raw[kind]=raw
