"""Fresh Picker3 storage: full immutable UI/input/value originals, compact WAL.

Existing Picker1/2 decoders and WALs remain literal. No record is migrated,
trimmed, hashed in place of retaining bytes or adopted from an unknown inode.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import hashlib,os,re
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.operation_transport_guard import check as transport_check
from adapters.script_feature.history import MAX_RAW,canonical,pack,unpack,same
from ios.adapters.assets_budget import operation
from ios.adapters.assets_controls import project
from ios.adapters.assets_model_sources import AssetsModelSources
from ios.adapters.assets_page_picker import PageLeasePicker

VERSION=3
VALUES=('workBeforeSelect','negativeWindow','cleanupWindow')
FIELDS={'phase','page','picker','captures','inputs',*VALUES}
PROFILES={'capture':('assets-picker-capture','iosAssetsPickerCapture','sources',96),
          'input':('assets-picker-input','iosAssetsPickerInput','inputs',64),
          'value':('assets-picker-value','iosAssetsPickerValue','sources',131)}


def digest(value):return hashlib.sha256(canonical(value)).hexdigest()


class OriginalPageLeasePicker(PageLeasePicker):
    OWNER_VERSION=VERSION
    def __init__(self,*args,**kwargs):
        self.storage=None;self.stores=None;self._writing=None;self._wire=None;self.historical=False
        super().__init__(*args,**kwargs);self._init_storage()
        if self.previous is None:self.storage=self.empty_storage()
        else:self._wire=deepcopy(unpack(self.previous['payload'])[0]);self.storage=deepcopy(self._wire['originals'])
    @staticmethod
    def empty_storage():return dict(captures=[],inputs=[],inputHistory=[],values={key:None for key in VALUES},valueHistory=[],pending=None)
    def _init_storage(self):
        if getattr(self,'stores',None) is not None:return
        self.stores={}
        for kind,(namespace,schema,mode,_limit) in PROFILES.items():
            self.stores[kind]=OriginalFrameStore(self.store.path.parent,self.binding,self.files.run,self.files.role,
                self.metadata_guard,lambda transition,ref,kind=kind:self.intent_original(kind,transition,ref),
                namespace=namespace,schema_prefix=schema,kind=mode,monotonic=self.monotonic)
    def metadata_guard(self):
        self.lock.assert_held();self.files.envelope_guard();PrivateFeatureState(self.store.path)._parent()
        need(same(self.store.read(),self.previous));return True
    def ready(self):
        self._init_storage();self.metadata_guard();transport_check()
        need(not getattr(self,'historical',False) and self.storage is not None and self.storage['pending'] is None)
        if self.previous is not None:
            current=unpack(self.previous['payload']);need(len(current)==1 and same(self.storage,current[0]['originals']))
        self._shape(self.storage);self.membership(self.storage);need(self.files.native.guard() is not False);return True
    def context(self):
        return dict(pickerHeader=str(self.store.path),fileOwnerToken=self.files.state['token'],
            ticket=self.files.state['ticket'],resource=self.files.state['resource'],extra=self.extra_envelope())
    def envelope(self,wire):
        return dict(iosAssetsPickerOwnerVersion=VERSION,**self.extra_envelope(),runId=self.files.run,binding=self.binding,
            fileOwnerToken=self.files.state['token'],payload=pack([wire]))
    def _persist(self,wire):
        self.metadata_guard();transport_check();need(not getattr(self,'historical',False) and self.files.native.guard() is not False)
        value=self.envelope(wire);self._decode(value,membership=wire['originals'])
        self.store.write(value,self.previous);need(same(self.store.read(),value));self.previous=deepcopy(value);self._wire=deepcopy(wire)
    def intent_original(self,kind,transition,ref):
        need(transition=='original' and self._writing==kind and self.storage['pending'] is not None)
        pending=self.storage['pending'];need(pending['kind']==kind);store=self.stores[kind];store.original(ref)
        prior=pending['original']
        if prior is None:need(ref['phase']=='planned')
        else:
            need(ref['index']==prior['index'] and ref['sha256']==prior['sha256'] and ref['bytes']==prior['bytes'])
            need((prior['phase'],ref['phase']) in (('planned','opened'),('opened','saved')))
            if prior['phase']=='opened':need(same(ref['file'],prior['file']))
        pending['original']=deepcopy(ref);wire=deepcopy(self._wire);wire['originals']=deepcopy(self.storage);self._persist(wire);return True
    def _read(self,kind,ref):
        body=self.stores[kind].read(self.stores[kind].expand(ref));exact(body,{'pickerOriginalVersion','context','kind','key','previous','data'})
        need(type(body['pickerOriginalVersion']) is int and body['pickerOriginalVersion']==1 and body['kind']==kind
            and same(body['context'],self.context()));return body
    def membership(self,storage):
        known=set();root=self.store.path.parent;prefixes=[]
        groups={'capture':storage['captures'],'input':storage['inputHistory'],'value':storage['valueHistory']}
        for kind,refs in groups.items():
            store=self.stores[kind];prefixes.append(store.namespace+'-frame-'+store.kind+'-')
            for ref in refs:known.add(store.path(store.expand(ref)))
        pending=storage['pending']
        if pending is not None and pending['original'] is not None:
            store=self.stores[pending['kind']];ref=pending['original'];store.original(ref);path=store.path(ref)
            if ref['phase']=='planned':need(not os.path.lexists(path))
            else:known.add(path);AssetsModelSources.prefix(SimpleNamespace(originals=store),ref)
        entries=list(root.iterdir());need(len(entries)<=4096)
        actual={p for p in entries if p.name.startswith(tuple(prefixes))}
        need(actual==known);return known
    def _shape(self,s):
        exact(s,{'captures','inputs','inputHistory','values','valueHistory','pending'})
        for kind,key in (('capture','captures'),('input','inputHistory'),('value','valueHistory')):
            need(type(s[key]) is list and len(s[key])<=PROFILES[kind][3])
            for index,ref in enumerate(s[key],1):need(self.stores[kind].expand(ref)['index']==index)
        need(type(s['inputs']) is list and len(s['inputs'])<=16);exact(s['values'],set(VALUES))
        if s['pending'] is not None:
            p=s['pending'];exact(p,{'kind','key','bodySha256','original','target'})
            need(p['kind'] in PROFILES and type(p['bodySha256']) is str and re.fullmatch('[0-9a-f]{64}',p['bodySha256']))
            exact(p['target'],{'phase','page','picker'})
            need(p['target']['phase'] in ('reserved','page-open','picker-open','primary-chosen','checking-unavailable','unavailable',
                'canceling','picker-closed','closing-page','page-closed','retired',self.retirement_phase()))
            from ios.adapters.assets_controls import identity
            for field in ('page','picker'):
                if p['target'][field] is not None:identity(p['target'][field])
            group={'capture':'captures','input':'inputHistory','value':'valueHistory'}[p['kind']]
            need(len(s[group])<PROFILES[p['kind']][3])
            if p['kind']=='capture':need(type(p['key']) is int and p['key']==len(s['captures'])+1)
            elif p['kind']=='input':need(type(p['key']) is str and re.fullmatch('[a-z][a-z-]{0,39}',p['key']))
            else:need(p['key'] in VALUES)
            if p['original'] is not None:
                self.stores[p['kind']].original(p['original']);need(p['original']['index']==len(s[group])+1)
        return s
    def _input_transition(self,old,new):
        exact(new,{'slot','id','action','text','reference','command','receipt','resolvedBy'})
        if old is None:need(new['command'] is None and new['receipt'] is None and new['resolvedBy'] is None);return
        need(same({k:v for k,v in old.items() if k not in ('command','receipt','resolvedBy')},
            {k:v for k,v in new.items() if k not in ('command','receipt','resolvedBy')}))
        changes=0
        for key in ('command','receipt','resolvedBy'):
            if old[key] is not None:need(same(old[key],new[key]))
            elif new[key] is not None:changes+=1
        need(changes==1)
    def _value_transition(self,key,old,new):
        need(key in VALUES and new is not None)
        if key!='workBeforeSelect':
            exact(new,{'kind','requests','hostBrackets'});need(new['kind']==('unavailable' if key=='negativeWindow' else 'cleanup'))
        if old is None:return
        need(key!='workBeforeSelect');exact(old,{'kind','requests','hostBrackets'})
        need(new['kind']==old['kind'] and len(new['requests'])==len(old['requests'])+1
            and same(new['requests'][:-1],old['requests']) and same(new['hostBrackets'][:-1],old['hostBrackets']))
    def _hydrate(self,wire):
        exact(wire,{'phase','page','picker','originals'});s=self._shape(wire['originals']);captures=[]
        for index,ref in enumerate(s['captures'],1):
            body=self._read('capture',ref);need(body['key']==index and body['previous'] is None)
            data=body['data'];exact(data,{'packet','receipt'});receipt=data['receipt'];exact(receipt,{'schemaVersion','commandId','observation'})
            need(type(receipt['schemaVersion']) is int and receipt['schemaVersion']==1 and type(receipt['commandId']) is str
                and re.fullmatch('ios-[0-9a-f]{32}',receipt['commandId']) and same(receipt['observation'],data['packet']))
            captures.append(deepcopy(data['packet']))
        inputs={};latest={};counts={}
        for ref in s['inputHistory']:
            body=self._read('input',ref);key=body['key'];entry=body['data'];need(type(key) is str and entry.get('slot')==key)
            need(same(body['previous'],latest.get(key)));self._input_transition(inputs.get(key),entry)
            counts[key]=counts.get(key,0)+1;need(counts[key]<=4);inputs[key]=deepcopy(entry);latest[key]=ref
        need(same(s['inputs'],list(latest.values())))
        values={key:None for key in VALUES};value_refs={};value_counts={}
        for ref in s['valueHistory']:
            body=self._read('value',ref);key=body['key'];need(key in VALUES and same(body['previous'],value_refs.get(key)))
            self._value_transition(key,values[key],body['data']);values[key]=deepcopy(body['data']);value_refs[key]=ref
            value_counts[key]=value_counts.get(key,0)+1;need(value_counts[key]<=(1 if key=='workBeforeSelect' else 65))
        need(all(same(s['values'][key],value_refs.get(key)) for key in VALUES))
        state=dict(phase=wire['phase'],page=wire['page'],picker=wire['picker'],captures=captures,inputs=list(inputs.values()),**values)
        need(len(canonical([state]))<=MAX_RAW);return self.validate_state(state)
    def _decode(self,value,*,membership):
        self._init_storage();exact(value,{'iosAssetsPickerOwnerVersion','runId','binding','fileOwnerToken','payload'}|set(self.extra_envelope()))
        self.validate_extra(value);need(type(value['iosAssetsPickerOwnerVersion']) is int and value['iosAssetsPickerOwnerVersion']==VERSION
            and value['runId']==self.files.run and same(value['binding'],self.binding) and value['fileOwnerToken']==self.files.state['token'])
        rows=unpack(value['payload']);need(len(rows)==1);state=self._hydrate(rows[0]);self._shape(membership);self.membership(membership);return state
    def decode(self,value):
        self._init_storage()
        current=unpack((self.previous if self.previous is not None else value)['payload']);need(len(current)==1)
        return self._decode(value,membership=current[0]['originals'])
    def _record(self,kind,key,data,previous):
        need(self.storage['pending'] is None and self._writing is None)
        group={'capture':'captures','input':'inputHistory','value':'valueHistory'}[kind];index=len(self.storage[group])+1
        need(index<=PROFILES[kind][3]);body=dict(pickerOriginalVersion=1,context=self.context(),kind=kind,key=key,previous=deepcopy(previous),data=deepcopy(data))
        self.storage['pending']=dict(kind=kind,key=key,bodySha256=digest(body),original=None,
            target={key:deepcopy(self.state[key]) for key in ('phase','page','picker')})
        wire=deepcopy(self._wire);wire['originals']=deepcopy(self.storage);self._persist(wire);self._writing=kind
        try:ref=self.stores[kind].write(index,body)
        finally:self._writing=None
        need(self.storage['pending']['original']['phase']=='saved');self._accept_pending(ref,body)
    def _accept_pending(self,ref,body):
        p=self.storage['pending'];need(p is not None and p['original'] is not None and p['original']['phase']=='saved'
            and same(self.stores[p['kind']].compact(p['original']),ref) and digest(body)==p['bodySha256']
            and body['kind']==p['kind'] and body['key']==p['key'] and same(body['context'],self.context()))
        kind,key=p['kind'],p['key'];s=self.storage
        if kind=='capture':need(key==len(s['captures'])+1);s['captures'].append(ref)
        elif kind=='input':
            refs=s['inputHistory'];old=[self._read('input',r) for r in s['inputs']];keys=[r['key'] for r in old]
            self._input_transition(None if key not in keys else old[keys.index(key)]['data'],body['data'])
            need(same(body['previous'],None if key not in keys else s['inputs'][keys.index(key)]))
            refs.append(ref)
            if key in keys:s['inputs'][keys.index(key)]=ref
            else:need(len(s['inputs'])<16);s['inputs'].append(ref)
        else:
            previous=None if s['values'][key] is None else self._read('value',s['values'][key])['data']
            self._value_transition(key,previous,body['data']);s['valueHistory'].append(ref);s['values'][key]=ref
        target=p['target'];s['pending']=None;wire=dict(**deepcopy(target),originals=deepcopy(s));self._persist(wire)
    def save(self):
        self._init_storage();self.ready();self.validate_state(self.state);need(len(canonical([self.state]))<=MAX_RAW)
        if self._wire is None:
            need(not self.state['captures'] and not self.state['inputs'] and all(self.state[k] is None for k in VALUES))
            self._wire=dict(**{k:deepcopy(self.state[k]) for k in ('phase','page','picker')},originals=deepcopy(self.storage));self._persist(self._wire);return
        need(len(self.storage['captures'])<=len(self.state['captures'])<=len(self.storage['captures'])+1)
        if len(self.state['captures'])>len(self.storage['captures']):
            self._record('capture',len(self.state['captures']),dict(packet=deepcopy(self.state['captures'][-1]),receipt=deepcopy(self.native.last_receipt)),None)
        for index,entry in enumerate(self.state['inputs']):
            old_ref=self.storage['inputs'][index] if index<len(self.storage['inputs']) else None
            old=None if old_ref is None else self._read('input',old_ref)['data']
            if not same(old,entry):self._record('input',entry['slot'],entry,old_ref)
        need(len(self.storage['inputs'])==len(self.state['inputs']))
        for key in VALUES:
            ref=self.storage['values'][key];old=None if ref is None else self._read('value',ref)['data']
            if not same(old,self.state[key]):self._record('value',key,self.state[key],ref)
        wire=dict(**{k:deepcopy(self.state[k]) for k in ('phase','page','picker')},originals=deepcopy(self.storage));self._persist(wire)
    @operation
    def recover_storage_saved(self):
        self._init_storage();self.metadata_guard();transport_check();need(not getattr(self,'historical',False) and self.files.native.guard() is not False)
        p=self.storage['pending'];need(p is not None and p['original'] is not None and p['original']['phase']=='saved')
        ref=self.stores[p['kind']].compact(p['original']);body=self._read(p['kind'],ref);self._accept_pending(ref,body)
        self.state=self.decode(self.previous);return dict(recorded=True,nativeQueryRepeated=False,nativeInputRepeated=False,currentFactProduced=False)

    @operation
    def capture(self):self.ready();return super().capture()
    @operation
    def input(self,*args,**kwargs):self.ready();return super().input(*args,**kwargs)
    @operation
    def resolve_pending(self):self.ready();return super().resolve_pending()
    @operation
    def open_page(self):self.ready();return super().open_page()
    @operation
    def open_picker(self):self.ready();return super().open_picker()
    @operation
    def choose_primary(self):self.ready();return super().choose_primary()
    @operation
    def prepare(self):self.ready();return super().prepare()
    @operation
    def select_after_primary(self):self.ready();return super().select_after_primary()
    @operation
    def retire_and_select(self):self.ready();return super().retire_and_select()
    @operation
    def observe_unavailable(self):self.ready();return super().observe_unavailable()
    @operation
    def cancel(self):self.ready();return super().cancel()
    @operation
    def recover_cancel(self):self.ready();return super().recover_cancel()
    @operation
    def close_page(self):self.ready();return super().close_page()
    @operation
    def recover_close(self):self.ready();return super().recover_close()
    @operation
    def cancel_owned(self):self.ready();return super().cancel_owned()
    @operation
    def retire_inputs(self):self.ready();return super().retire_inputs()
    @operation
    def close_shared_page(self):self.ready();return super().close_shared_page()
    def _window(self,*args,**kwargs):self.ready();return super()._window(*args,**kwargs)
    @operation
    def release(self):self.ready();return super().release()
    @operation
    def recover_release(self):self.ready();return super().recover_release()


def picker_type(value):
    if value is None:return OriginalPageLeasePicker
    need(type(value) is dict and type(value.get('iosAssetsPickerOwnerVersion')) is int)
    version=value['iosAssetsPickerOwnerVersion'];need(version in (2,VERSION))
    return PageLeasePicker if version==2 else OriginalPageLeasePicker


def admit_page_picker(picker):
    """Admit only the two explicit shared-page storage profiles.

    This is a storage/type binding check. The caller still performs its same
    page/action/lock/native checks before an actual operation. No subclass or
    missing/mismatched stored profile gains authority through this function.
    """
    actual=type(picker)
    need(actual in (PageLeasePicker,OriginalPageLeasePicker))
    expected=2 if actual is PageLeasePicker else VERSION
    need(type(picker.OWNER_VERSION) is int and picker.OWNER_VERSION==expected)
    stored=picker.store.read();need(same(stored,picker.previous))
    if stored is None:need(picker.state is None)
    else:
        need(type(stored) is dict and type(stored.get('iosAssetsPickerOwnerVersion')) is int
            and stored['iosAssetsPickerOwnerVersion']==expected and picker.state is not None)
    return True


def page_picker_owner(native,files,store,binding,**kwargs):
    # This is an explicit fresh-birth storage selection. Existing2 is read and
    # written by its SAME literal class; no new original or version is emitted.
    return picker_type(store.read())(native,files,store,binding,**kwargs)
