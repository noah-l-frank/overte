"""Actual staged Script/PNG owners; native physics/GPU/SDK are raw MODELS.

The existing marker test supplies neutral journal/lock scaffolding, NOT a real
IOSLifecycleMarkerScope constructor or a physical renderer. This composes the
actual normal marker Script, original Vulkan HTTP/AFC decoder and file owner,
native clock join, independent renderer/body packets and Lifecycle image join.
No saved packet/PNG is retimed, repainted or made current by a later call.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import base64,hashlib,json,uuid
from copy import deepcopy
from io import BytesIO
from PIL import Image,ImageDraw
from adapters.native_clock_join import NativeClockAcquisition
from adapters.native_vulkan_world_frame import absent
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.owned_vulkan_world_frame import VulkanWorldFrameOwner
from feature_journeys.fixtures import marker_bytes
from ios.adapters import feature_observation,lifecycle_image_join
from ios.self_tests.test_ios_avatar_renderers import packet as renderer_packet
from ios.self_tests.test_ios_vulkan_world_frame import SDK
from self_tests.test_native_completed_frame import view as numeric_view
from lifecycle_parent_marker_fixture import LifecycleParentDomain

EXTENT=[1600,1000]
POLICY=dict(source='world-render-target',marker=[706,480,864,520],subject=[750,560,850,790])


class MovingDomain(LifecycleParentDomain):
    def __init__(self,scope):
        super().__init__(scope);self.sequences['renderers']=0
        self.world_template['source']['view'].update(fieldOfViewDegrees=60.,aspectRatio=1.6,perspective=True)
        self.motion_start=None;self.speed=[.2,0.,-.1];self.renderer_fault=None
        self.gpu_sequence=0;self.gpu_frames=0

    def moving_pose(self):
        elapsed=0. if self.motion_start is None else self.time-self.motion_start
        return [a+b*elapsed for a,b in zip([0.,0.,4.],self.speed)]

    def select_physics_snapshot(self):
        self.pose['position']=self.moving_pose()
        self.pose['velocity']=[0.,0.,0.]if self.motion_start is None else deepcopy(self.speed)
        p=self.pose['position']
        self.world_template['source']['avatar']['bounds']=dict(corner=[p[0]-.5,p[1],p[2]-.5],dimensions=[1.,1.8,1.])

    def renderers(self):
        # Physics publishes a stable native frame; the getter and subsequent
        # World getter may observe that SAME frame without inventing new pose.
        sequence=self.tick('renderers');packet=renderer_packet();epoch=self.epoch()
        packet.update(requestId='ios-'+uuid.uuid4().hex,runId=self.scope.run,sequence=sequence,processId=self.scope.pid)
        packet['clockBefore']=dict(epochMs=epoch,monotonicMs=round(self.time*1000));packet['clockAfter']=deepcopy(packet['clockBefore'])
        for row in packet['source']['avatars']:
            row['bounds']=deepcopy(self.world_template['source']['avatar']['bounds'])
            if row['self']:
                row['rigPose'].update(capturedEpochMs=epoch,evaluationSequence=100+sequence)
                if self.renderer_fault=='unknown-bounds':row.update(boundsReady=False,bounds=None)
            else:
                row['bounds']['corner'][0]+=100
                row['externalPose'].update(capturedEpochMs=epoch,evaluationSequence=100+sequence)
        return packet


class MovingGPU(SDK):
    """Fresh raw producer selected BEFORE the first original GPU request.

    Its pixels and numeric view are model outputs. The unmodified actual
    FeatureObservation/Vulkan decoder and VulkanWorldFrameOwner consume them.
    """
    def __init__(self,domain,ticket,*,no_fence=False,stale_ticket=None):
        super().__init__();self.domain=domain;self.pid=domain.scope.pid
        self.offset=20000;self.clock=domain.time;self.no_fence=no_fence
        self.sequence=domain.gpu_sequence;domain.gpu_frames+=1;self.frame_index=domain.gpu_frames
        self.source_extent=[800,500];self.target_extent=deepcopy(EXTENT)
        self.card_ticket=ticket if stale_ticket is None else stale_ticket;self.frame_id=uuid.uuid4().hex
        self.produced_view=None;self.change=self.recorded_geometry
        image=Image.new('RGBA',tuple(EXTENT),(75,85,95,255));draw=ImageDraw.Draw(image)
        # Independently declared model raster for the actual model mesh frame.
        for y in range(530,830,8):
            for x in range(700,900,8):
                color=(25,50,180,255)if(x//8+y//8)%2 else(225,165,35,255)
                draw.rectangle((x,y,x+7,y+7),fill=color)
        card=Image.open(BytesIO(marker_bytes(domain.scope.run,self.card_ticket))).convert('RGBA')
        image.paste(card.resize((198,50),Image.Resampling.NEAREST),(701,475))
        self.raw_pixels=image.tobytes();output=BytesIO();image.save(output,format='PNG');self.png=output.getvalue()

    def epoch(self):return self.domain.epoch()if hasattr(self,'domain')else super().epoch()

    def sleep(self,seconds):self.domain.sleep(seconds);self.clock=self.domain.time

    def recorded_geometry(self,value):
        if 'completedFrameVersion'not in value or value.get('pending')is True:return
        if self.produced_view is None:
            actual=numeric_view();position=self.domain.moving_pose()
            actual.update(position=[position[0],position[1]+1.6,position[2]+4.],rotation=deepcopy(self.domain.pose['orientation']))
            self.produced_view=actual
        value['source']['renderTrace'].update(frameId=self.frame_id,recordedView=deepcopy(self.produced_view))

    def send(self,value):
        self.clock=self.domain.time;super().send(value);self.domain.time=self.clock;self.domain.gpu_sequence=self.sequence

    def original(self):
        self.clock=self.domain.time;super().original();self.domain.time=self.clock;self.domain.gpu_sequence=self.sequence
        # These are fields of this NEW modeled reply before first transport
        # exposure, never a converted/relabelled historical GPU original.
        if self.value is not None:
            self.value['processId']=self.pid
            if 'vulkanWorldFrameVersion'in self.value:
                self.value['source']['image'].update(width=EXTENT[0],height=EXTENT[1])
        return json.dumps(self.value)if self.value is not None else''

    def execute(self,session,operation,values):
        assert session==self.domain.scope.binding['sessionId']and operation=='mobile: pullFile'
        assert values=={'remotePath':'@org.example.client:documents/owned-results/feature-vulkan-world-frame.json'}
        self.paths.append(deepcopy(values));return base64.b64encode(self.original().encode()).decode()

    def observer(self):
        return feature_observation.FeatureObservation(self,self.domain.scope.binding['sessionId'],self.target,self.process,
            epoch_ms=self.epoch,monotonic=lambda:self.clock,sleep=self.sleep)


class MovingOriginalComposition:
    def __init__(self,scope,domain):
        self.scope,self.domain=scope,domain;self.pending={};self.previous=None;self.frames=[]
        self.store=PrivateFeatureState(scope.root/'lifecycle-moving-model-originals.json')
        self.files=OriginalFrameStore(scope.root,scope.binding,scope.run,'primary',scope.bound,self.intent,
            namespace='lifecycle-moving-model',schema_prefix='iosLifecycleMovingModel',kind='sources')
        self.gpu=None;self.owner=None

    def intent(self,kind,value):
        assert kind=='original';old=self.pending.get(str(value['index']))
        assert value['phase']==('planned'if old is None else{'planned':'opened','opened':'saved'}[old['phase']])
        self.pending[str(value['index'])]=deepcopy(value)
        body=dict(modelOriginalStorageVersion=1,binding=self.scope.binding,runId=self.scope.run,storage=self.pending)
        self.store.write(body,self.previous);self.previous=deepcopy(body)

    def acquire(self,ticket,*,no_fence=False,stale_ticket=None):
        from unittest.mock import patch
        if self.owner is not None:
            assert self.owner.state['phase']=='released'and absent(self.owner.state['absence'])
        s,d=self.scope,self.domain;d.select_physics_snapshot()
        clock=NativeClockAcquisition(s.native,epoch_ms=s.epoch_ms,monotonic=s.monotonic)
        clock.begin(s.epoch_ms());before=d.world(s.run);left=d.renderers()
        gpu=MovingGPU(d,ticket,no_fence=no_fence,stale_ticket=stale_ticket);self.gpu=gpu;request='ios-'+uuid.uuid4().hex
        def factory(intent,receipt):return gpu.observer().vulkan_world_frame(intent,receipt)
        store=PrivateFeatureState(s.root/('graphics-world-frame-primary-0-'+request[4:]+'.json'))
        owner=VulkanWorldFrameOwner(store,s.root,s.binding,s.run,'primary',0,request,factory,s.bound,source_lock=s.lock,
            monotonic=s.monotonic,sleep=s.sleep);self.owner=owner
        with patch.object(feature_observation,'post_request',side_effect=gpu.post):
            capture,raw=owner.capture(ticket);retirement=owner.release()
        assert absent(retirement)
        d.select_physics_snapshot();right=d.renderers();after=d.world(s.run)
        originals=dict(worldBefore=before,renderersBefore=left,capture=capture,retirement=retirement,renderersAfter=right,worldAfter=after)
        frame=dict(originals,clockJoin=clock.finish(originals,[('capture','capturedEpochMs'),('retirement','capturedEpochMs')]))
        marker=s.bind_image_world(before);saved=dict(frame=frame,owner=deepcopy(owner.state),requestId=request,policy=POLICY,
            marker=marker,ticket=ticket)
        reference=self.files.write(len(self.frames)+1,saved);self.frames.append(reference)
        return frame,raw,deepcopy(POLICY),marker,reference

    def compose(self,original):
        frame,raw,policy,marker,_reference=original
        return lifecycle_image_join.compose(self.scope.run,self.files.read(self.files.expand(original[-1]))['ticket'],self.scope.binding,
            frame,raw,policy,marker_nonce=marker['nonce'],marker_url=marker['url'])
