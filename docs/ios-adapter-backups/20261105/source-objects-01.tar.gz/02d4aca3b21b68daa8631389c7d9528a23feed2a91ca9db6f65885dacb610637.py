"""Canonical private path boundary for explicitly owned Moving host producers."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path


def guarded_path(path):
    repo=Path.cwd().resolve(strict=True)
    assert repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file()
    path=Path(path);assert path.resolve().is_relative_to(repo);return path
