"""Independent stdlib-only readback; original failed aggregate remains immutable."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,json,os,re,stat,tempfile,time

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
plan=json.loads((HERE/'readback-plan.json').read_text())
assert plan['status']=='UNRUN_INDEPENDENT_STDLIB_READBACK_PROPOSAL'
runs=HERE/'runs';assert not runs.exists(),'No unchanged readback repeat'
runs.mkdir(mode=0o700)
out=Path(tempfile.mkdtemp(prefix='first-',dir=runs));out.chmod(0o700)
forbidden=[]
def audit(event,args):
    if event=='import':
        name=args[0]
        if any(part in ('pymobiledevice3','tidevice','pyidevice','zeroconf') for part in name.split('.')):
            forbidden.append(event);raise RuntimeError('SDK import prohibited')
    if event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn','socket.connect','socket.bind'):
        forbidden.append(event);raise RuntimeError('Pure original readback cannot execute or connect')
    if event=='open':
        path,mode,flags=args
        writing=(isinstance(flags,int) and flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)) or isinstance(mode,str) and any(c in mode for c in 'wax+')
        if writing and (not isinstance(path,(str,bytes,os.PathLike)) or not Path(os.fsdecode(path)).resolve().is_relative_to(out)):
            forbidden.append(event);raise RuntimeError('Readback writes only its independent output')
    if event in ('os.remove','os.rmdir','os.rename','os.chmod','os.mkdir'):
        paths=[x for x in args[:2] if isinstance(x,(str,bytes,os.PathLike))]
        if any(not Path(os.fsdecode(p)).resolve().is_relative_to(out) for p in paths):
            forbidden.append(event);raise RuntimeError('Original mutation prohibited')
sys.addaudithook(audit)

def signature(info):return {k:getattr(info,k) for k in FIELDS}
def pin(path):
    path=Path(path);a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
    result=signature(a)
    if stat.S_ISREG(a.st_mode):
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
        with os.fdopen(fd,'rb') as stream:
            assert signature(os.fstat(stream.fileno()))==result;raw=stream.read();assert signature(os.fstat(stream.fileno()))==result
        assert len(raw)==a.st_size;result['sha256']=hashlib.sha256(raw).hexdigest()
    assert signature(path.lstat())==signature(a);return result

def load(path):
    path=Path(path);before=pin(path);value=json.loads(path.read_text());assert pin(path)==before;return value

def census(root):
    root=Path(root);before=signature(root.lstat());value={str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))}
    assert signature(root.lstat())==before;return value

def proc(pid):
    try:a=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(a[1]),processGroup=int(a[2]),session=int(a[3]),startTicks=int(a[19]))

def save(name,value):
    path=out/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as stream:stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n');stream.flush();os.fsync(stream.fileno())

started=time.monotonic();before_pins={name:pin(REPO/name) for name in plan['inputSha256']}
assert all(before_pins[name]['sha256']==sha for name,sha in plan['inputSha256'].items())
producer=REPO/plan['producer'];run=REPO/plan['runRoot'];temporary=run/'temporary'
parent=load(producer/'ui7-report.json');selected=load(run/'selected-result.json');suite=load(producer/'suite-plan.json')['suites']['ui7']
assert parent['kind']=='ui7' and parent['exitCode']==1 and selected['successful'] is False
assert parent['originalFiles']==970 and parent['allPinsEqual'] and parent['publicationReadyMapUnchanged']
assert parent['postStopOriginalCensusesEqual'] and parent['priorOriginalCensusesUnchanged'] and parent['postStopCensusesQualified']
assert not parent['ownedProcessesBeforeCensuses'] and not parent['remainingOwnedProcesses']
assert selected['kind']=='ui7' and selected['testsRun']==7 and selected['selectedIds']==plan['expectedCases']==suite['caseIds']==load(run/'selected-ids-actual.json')
assert not selected['caseAuditFailures'] and selected['sourceLauncherPinsUnchanged'] and selected['originalCensusesEqual']
assert selected['fixtureAliasesRestored'] and selected['nodeProducerAliasRestored'] and selected['synchronousNodeProducerRestored']
assert selected['actualSDKNameAndSourceImportAuditInstalled']
for key in ('sdkImportAttempts','sdkModulesBefore','sdkModulesAfter','remainingOwnedChildrenBeforeCensuses','remainingOwnedChildrenAfterCensuses','remainingNewThreadsBeforeCensuses','remainingNewThreads'):assert selected[key]==[]
log=(producer/'ui7-first.log').read_text()
passed=re.findall(r'^test_[^\n]* \(([^\n]+)\) \.\.\. ok$',log,re.MULTILINE)
assert passed==plan['expectedCases'] and re.search(r'^Ran 7 tests in [0-9.]+s$',log,re.MULTILINE) and '\nOK\n' in log
assert log.rstrip().endswith('AssertionError') and 'line 289, in <module>' in log
source=(producer/'run-selected.py').read_text();assert "len(nodes)==selected['expectedNodeChildrenNotProof']" in source
assert suite['expectedNodeChildrenNotProof']==1 and len(selected['originalNodeCloseObservations'])==7
assert len(selected['synchronousOriginalNodeRuns'])==7 and selected['synchronousOriginalNodeRuns']==load(run/'actual-synchronous-node-observations.json')
receipts=[load(run/('case-stop-receipt-'+format(i,'06d')+'.json')) for i in range(1,8)]
assert receipts==selected['caseStopReceipts'] and [r['testId'] for r in receipts]==plan['expectedCases']
for row in receipts:
    assert row['originalCleanupsReturned'] and row['cleanAtCaseBoundary'] and row['remainingNewThreads']==row['remainingOwnedChildren']==[]
    assert len(row['nodeCloseObservations'])==1 and len(row['synchronousNodeOriginalRuns'])==1
    node=row['nodeCloseObservations'][0];assert node['exitCode']==-15 and node['stdinClosed'] and node['stdoutClosed'] and node['stderrClosed']
    sync=row['synchronousNodeOriginalRuns'][0];assert sync['entered'] and sync['returned'] and sync['exitCode']==0
assert [node for row in receipts for node in row['nodeCloseObservations']]==selected['originalNodeCloseObservations']
observed=load(run/'actual-all-original-processes.json');assert observed['processes']==selected['actualObservedSubprocesses']
kinds=[row['kind'] for row in observed['executions']]
assert kinds.count('assets-picker-node')==7 and kinds.count('original-marker-node')==7 and kinds.count('exact-metadata-rg')==1 and len(kinds)==15
assert len(observed['processes'])==15 and observed['observer']==selected['originalProcessMonitoring']
monitor=observed['observer'];assert monitor['starts']==monitor['normalReturns']==15 and monitor['selectedUnwinds']==0 and monitor['privateToolFreed'] and monitor['globalProfileInstalled'] is False
for row in observed['processes']:
    assert row['constructorOutcome']=='return' and row['birth'] is not None and row['current'] is None and row['returnCode'] in (-15,0)
    assert all(value is None or value is True for value in row['originalStreamsClosed'].values())
old_bindings=[parent['taskBinding'],parent['runnerBinding'],*[row['birth'] for row in observed['processes']]]
def absent():
    actual=[]
    for birth in old_bindings:
        current=proc(birth['pid']);assert current is None or current['startTicks']!=birth['startTicks'];actual.append(dict(birth=birth,current=current))
    groups=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        row=proc(int(path.name))
        if row is not None and (row['session']==parent['taskBinding']['session'] or row['processGroup']==parent['taskBinding']['processGroup']):groups.append(row)
    assert not groups;return actual
processes_before=absent()
first=load(producer/'ui7-originals-first.json');assert first==load(producer/'ui7-originals-second.json')==load(run/'selected-originals-first.json')==load(run/'selected-originals-second.json')
assert sum('sha256' in row for row in first.values())==970 and census(temporary)==first
prior=load(producer/'ui7-prior-originals-before.json');assert prior==load(producer/'ui7-prior-originals-first.json')==load(producer/'ui7-prior-originals-second.json')
fullplan=load(producer/'suite-plan.json');extra={row['label']:row for row in fullplan.get('additionalRootOriginalCorpora',[])}
for root,expected in prior.items():
    if root.startswith('flat:'):
        actual={name:pin(REPO/name) for name in expected}
    elif root.startswith('root25769:'):
        row=extra[root.split(':',1)[1]];actual=census(row['root'])
        if row['schema']=='stat-list':actual={name:dict(stat=[pinrow[k] for k in row['statFields']],**({'sha256':pinrow['sha256']} if 'sha256' in pinrow else {})) for name,pinrow in actual.items()}
        else:assert row['schema']=='named-stat-fields'
    else:assert Path(root).is_absolute();actual=census(root)
    assert actual==expected,root
source_before=load(producer/'ui7-source-before.json');assert source_before==load(producer/'ui7-source-after.json')
ready=load(producer/'ui7-publication-ready-source-map.json');assert ready['sourcePins']==source_before and len(source_before)==parent['sourceLauncherReferencePins']
for name,expected in source_before.items():assert pin(REPO/name)==expected,name
imports=load(run/'actual-imported-local-sources.json');assert all(name in source_before for name in imports.values())
preimport=load(run/'preimport-source-map-actual.json');config=load(producer/'source-root-final-map.json')
assert preimport['orderedRoots']==[str(REPO/name) for name in config['orderedRoots']]
assert preimport['modules']=={name:str(REPO/row['path']) for name,row in config['modules'].items()}
identities=load(run/'created-original-root-identities.json');assert load(run/'created-original-roots.json')==[row['root'] for row in identities]
assert identities==selected['originalProducerRoots'] and len({row['root'] for row in identities})==len(identities)
for row in identities:
    path=Path(row['root']);a=path.lstat();assert path.resolve()==path and path.is_relative_to(temporary) and row['producer']=='genuineTemporaryDirectory'
    assert (a.st_dev,a.st_ino)==(row['device'],row['inode']) and stat.S_ISDIR(a.st_mode) and stat.S_IMODE(a.st_mode)==0o700
assert census(temporary)==first
processes_after=absent();after_pins={name:pin(REPO/name) for name in plan['inputSha256']};assert before_pins==after_pins and not forbidden
result=dict(status='ACTUAL_UI7_CASES_QUALIFIED_WITH_PRESERVED_AGGREGATE_COUNT_FAILURE',
    actualUnitCasesQualified=7,perCasePickerNodes=1,totalPickerNodes=7,totalSynchronousMarkerRuns=7,totalMetadataRg=1,
    sourcePins=len(source_before),originalFiles=970,actualProducerRoots=len(identities),allCaseReceiptsAndUnitLogPassed=True,
    originalParentExitCode=1,originalSelectedSuccessful=False,originalAggregateControllerPassed=False,
    aggregateFailure='The immutable controller incorrectly compared aggregate Picker Node count7 to per-case expected1.',
    inputPinsUnchanged=True,sourcePinsUnchanged=True,allOriginalCensusesUnchanged=True,priorCorpora=len(prior),
    ownedProcessesAbsentAroundCensuses=True,noSdkNativeQueriesInputsRecoveryOrTestsExecuted=True,
    nativeCompiled=False,deviceQualified=False,wholeAssetsQualified=False,fullFeatureCountChanged=False,seconds=time.monotonic()-started)
save('processes-before-original-censuses.json',processes_before);save('processes-after-original-censuses.json',processes_after)
save('qualified-supplement.json',result)
print(json.dumps(dict(report=str(out/'qualified-supplement.json'),**result),sort_keys=True),flush=True)
