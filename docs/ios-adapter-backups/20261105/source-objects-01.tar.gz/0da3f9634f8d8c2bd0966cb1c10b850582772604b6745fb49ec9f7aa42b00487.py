"""UNRUN proposal: one real saved namespace, same collector, two comparators.

Every public entry refuses while the actual-utility admission is absent. Root
must create a later reviewed immutable consumer joining its REAL proof schema.
No observer, SUT import, file read, native clock or expected-state producer here.
"""
import sys
from time import perf_counter_ns,process_time_ns
from types import ModuleType

LAUNCH_ADMISSION=None
CHAT_ADOPTION_ADMISSION=None
MODULE_NAME='ios.adapters.chat_peer_receipts'
SAVED_SHA='4eb386b970a7dea6e9f76612028d5a153a20826a3a7c92ec3c2cc3a2c28b52c0'
SAVED_BYTES=8980


def measure_one_registered_namespace(current,approved_origin,saved_binding):
    if LAUNCH_ADMISSION is None:raise RuntimeError('Closed: actual comparison Utility14 proof and Root admission are absent')
    # These declarations are NOT self-authenticating source authority. The
    # future Root loader must independently pin/join actual fresh execution.
    if type(current)is not ModuleType:raise ValueError('Actual current round module required')
    actual=sys.modules.get(MODULE_NAME)
    if type(actual)is not ModuleType:raise ValueError('Actual already-loaded saved-name module required')
    namespace=vars(actual)
    if (saved_binding.get('kind')!='fresh-pinned-python-source-bytes' or saved_binding.get('cachedBytecodeConsulted')is not False
            or saved_binding.get('sourceSha256')!=SAVED_SHA or saved_binding.get('sourceBytes')!=SAVED_BYTES):raise ValueError('Wrong literal saved binding')
    if approved_origin.get('sha256')!=SAVED_SHA or approved_origin.get('bytes')!=SAVED_BYTES or vars(actual).get('__file__')!=approved_origin.get('path'):
        raise ValueError('Actual fresh source differs from the fixed saved binding; require a new explicit source proposal')
    if sys.getprofile()is not None or sys.gettrace()is not None:raise ValueError('Measurement must be unprofiled/untraced')
    if not current.original_methods():raise ValueError('Fresh original method authority refused before measurement')
    record=current._BASELINES.get(MODULE_NAME)
    if record is None or record[0]is not namespace:raise ValueError('Genuine original registration required; no injected baseline')
    expected=record[1];plan=current._BASELINE_COMPARISONS.get(MODULE_NAME)
    if plan is None or plan[0]is not expected:raise ValueError('Genuine compiled expected plan missing')
    collector=current.module_signature;compare=current._compare_expected;function=current.function
    controls=(collector.__code__,collector.__globals__,compare.__code__,compare.__globals__,function.__code__,function.__globals__)
    literal_classes={};candidate_classes={};proven={}
    wall0=perf_counter_ns();cpu0=process_time_ns()
    literal_signature=collector(namespace,class_cache=literal_classes)
    literal_equal=literal_signature==expected
    cpu1=process_time_ns();wall1=perf_counter_ns()
    wall2=perf_counter_ns();cpu2=process_time_ns()
    candidate_signature=collector(namespace,class_cache=candidate_classes)
    candidate_equal=compare(candidate_signature,expected,plan,proven)
    cpu3=process_time_ns();wall3=perf_counter_ns()
    # Validation is outside both timed spans. No equality, getter, callback,
    # collection or current verdict is replaced with its earlier result.
    if not literal_equal or not candidate_equal or candidate_signature!=literal_signature:raise ValueError('Fresh original projections/comparison differ')
    if (current.module_signature is not collector or current._compare_expected is not compare or current.function is not function
            or collector.__code__ is not controls[0] or collector.__globals__ is not controls[1]
            or compare.__code__ is not controls[2] or compare.__globals__ is not controls[3]
            or function.__code__ is not controls[4] or function.__globals__ is not controls[5]):raise ValueError('Actual collector/comparator controls changed')
    if sys.modules.get(MODULE_NAME)is not actual or vars(actual)is not namespace or current._BASELINES.get(MODULE_NAME)is not record:
        raise ValueError('Actual namespace/registration receiver changed')
    if not current.original_methods():raise ValueError('Fresh original method authority refused after measurement')
    if sys.getprofile()is not None or sys.gettrace()is not None:raise ValueError('Profile/trace not restored')
    return dict(module=MODULE_NAME,old=dict(wallNanoseconds=wall1-wall0,cpuNanoseconds=cpu1-cpu0),
        candidate=dict(wallNanoseconds=wall3-wall2,cpuNanoseconds=cpu3-cpu2),
        rawClockReadOrder='wall0,cpu0,work,cpu1,wall1',fixedOrder='literal-first,candidate-second',iterationsPerPath=1,
        actualProjectionRows=len(candidate_signature),actualLocalProvenClasses=len(proven),
        sameActualCollectorObject=True,registeredExpectedTupleUntouched=True,projectionEqual=True,
        expectedCompilationIncluded=False,wholeGuardCostsIncluded=False,timingOverheadSubtracted=False,
        historicalHeapReconstructed=False,applicationOriginalsDecoded=False,chatAdoptionAdmission=None,
        speedOrCPUCauseConclusion=False,nativeQualified=False,wholeQualified=False)
