"""Actual source-retirement originals, default flow and fresh historical reads.

Host Node/files/unlinks and normal owner paths execute. Native/UIKit/SDK/OS
remain declared models. No whole End/old25 timing conclusion follows.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import cProfile
from contextlib import ExitStack
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.original_file_reads import collect,scope as read_scope
from ios.adapters.snapshot_share_source_retirement_owner import SnapshotShareSourceRetirementOwner,ShareSourceInspectAction
from ios.self_tests import test_ios_snapshot_share_source_retirement as existing


class SnapshotRetirementHistoricalWorkTests(unittest.TestCase):
    def setUp(self):
        self.fixture=existing.SnapshotShareSourceRetirementTests();self.addCleanup(self.fixture.doCleanups)
        self.domain=self.fixture.prepared()
        with self.domain.owner() as share:
            self.expected=share.source_retirement_owner().cleanup()

    def held(self):
        stack=ExitStack();stack.enter_context(self.domain.main.ctx.lock.held());stack.enter_context(self.domain.archive.source_lock.held())
        return stack

    def effects(self):
        d=self.domain
        return deepcopy((d.main.commands,d.primary_ui.requests,d.archive.ui.requests,d.archive.requests,d.archive.sdk,
            d.archive.source_unlinks,d.archive.source_retire_calls,d.archive.node.call('stats')))

    def originals(self):
        roots=(self.domain.main.ctx.root,self.domain.archive.root)
        return {str(path):(path.stat().st_dev,path.stat().st_ino,path.stat().st_size,path.stat().st_mtime_ns,
            path.stat().st_ctime_ns,hashlib.sha256(path.read_bytes()).hexdigest())
            for root in roots for path in sorted(root.rglob('*')) if path.is_file()}

    @staticmethod
    def calls(profile,function):
        return sum(row.callcount for row in profile.getstats() if row.code is function.__code__)

    def external(self):
        directory=tempfile.TemporaryDirectory(prefix='share-retirement-original-witness-');self.addCleanup(directory.cleanup)
        return Path(directory.name)

    def test_historical_load_and_proof_read_each_qualified_original_once_keep_default_and_return_original_values(self):
        effects=self.effects();before=self.originals()
        with self.held():
            profile=cProfile.Profile();profile.enable()
            try:reader=self.fixture.history(self.domain)
            finally:profile.disable()
            # Three load rows plus three proof rows. Count ACTUAL unchanged
            # function executions, without replacing a decoder/guard method.
            self.assertEqual(6,self.calls(profile,SnapshotShareSourceRetirementOwner.observed))
            profile=cProfile.Profile()
            with collect() as reads,read_scope(fresh=True) as membership:
                profile.enable()
                try:result=reader.proof()
                finally:profile.disable()
            self.assertEqual(3,self.calls(profile,SnapshotShareSourceRetirementOwner.observed))
            self.assertEqual(self.expected,result);self.assertTrue(reads);self.assertEqual(reads,membership)
            for row in reader.state['after']:
                if row['qualified'] is True:
                    action=reader.action(row,True)
                    self.assertIn(action.files.path(action.files.expand(action.state['proof'])),reads)
                    # Public qualified() still returns precisely its original
                    # absence packet, without introducing a tuple API.
                    self.assertEqual(reader.observed(row)[0],reader.qualified(row))
            result['fileQuiet']['requestIds'].clear();self.assertEqual(self.expected,reader.proof())
        self.assertEqual(effects,self.effects());self.assertEqual(before,self.originals())
        # The LIVE default retains its original qualified()+observed() calls.
        with self.domain.owner() as share:
            owner=share.source_retirement_owner();self.assertFalse(owner.historical);profile=cProfile.Profile();profile.enable()
            try:self.assertEqual(self.expected,owner.proof())
            finally:profile.disable()
            self.assertEqual(6,self.calls(profile,SnapshotShareSourceRetirementOwner.observed))

    def test_same_bytes_new_original_inode_is_rejected_without_another_unlink_or_query(self):
        with self.held():
            reader=self.fixture.history(self.domain);self.assertEqual(self.expected,reader.proof())
            row=next(row for row in reader.state['after'] if row['qualified'] is True);action=reader.action(row,True)
            path=action.files.path(action.files.expand(action.state['proof']));raw=path.read_bytes();old_inode=path.stat().st_ino
            # Retain the actual original inode OUTSIDE the archive namespace;
            # membership cannot conceal the intended original-inode failure.
            original=self.external()/'inspection-original.json';path.rename(original);path.write_bytes(raw);path.chmod(0o600)
            self.assertNotEqual(old_inode,path.stat().st_ino);self.assertEqual(old_inode,original.stat().st_ino)
            effects=self.effects()
            with self.assertRaises(NativeUIError):reader.proof()
            self.assertEqual(effects,self.effects());self.assertEqual(raw,original.read_bytes())

    def test_byte_change_after_real_qualification_is_checked_by_the_same_retained_observation(self):
        with self.held():
            from ios.adapters.snapshot_photos_end_read_area import _ACTIVE
            self.assertIsNone(_ACTIVE.get(),'This default historical countercase must not be masked by an epoch guard')
            reader=self.fixture.history(self.domain);row=next(row for row in reader.state['after'] if row['qualified'] is True)
            action=reader.action(row,True);path=action.files.path(action.files.expand(action.state['proof']))
            raw=path.read_bytes();witness=self.external()/'inspection-before-corruption.json';witness.write_bytes(raw);witness.chmod(0o600)
            inode=path.stat().st_ino;qualified=ShareSourceInspectAction.qualified;changed=[];effects=self.effects()
            def actual(owner):
                result=qualified(owner)
                if owner.index==row['index'] and not changed:
                    # Only the actual original file is changed AFTER the
                    # real qualified guard has succeeded. No verdict stub.
                    path.write_bytes(raw[:-1]+(b' ' if raw[-1:]!=b' ' else b'\n'));changed.append(True)
                return result
            with patch.object(ShareSourceInspectAction,'qualified',actual),self.assertRaises(NativeUIError):reader.proof()
            self.assertEqual([True],changed);self.assertEqual(inode,path.stat().st_ino)
            self.assertEqual(raw,witness.read_bytes());self.assertEqual(effects,self.effects())

    def test_fresh_historical_load_rejects_new_unknown_owned_namespace_member(self):
        with self.held():
            reader=self.fixture.history(self.domain);self.assertEqual(self.expected,reader.proof())
            path=self.domain.archive.root/'share-source-retirement-unclaimed.json'
            PrivateFeatureState(path).write(dict(unknownResponsibility=True),None);before=self.originals();effects=self.effects()
            with read_scope(fresh=True),self.assertRaises(NativeUIError):self.fixture.history(self.domain)
            self.assertEqual(before,self.originals());self.assertEqual(effects,self.effects())


if __name__=='__main__':unittest.main()
