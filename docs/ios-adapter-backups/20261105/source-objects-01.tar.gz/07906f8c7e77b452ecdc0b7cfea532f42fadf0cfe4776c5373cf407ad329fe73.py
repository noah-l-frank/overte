"""Immutable source/history prerequisites, no target imports or SDK admission."""
import hashlib,json,os,stat
from pathlib import Path
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path):
    path=Path(path);a=path.lstat();assert not path.is_symlink()and path.resolve(strict=True)==path
    assert stat.S_ISREG(a.st_mode)or stat.S_ISDIR(a.st_mode)
    value=dict(stat=[getattr(a,k)for k in FIELDS])
    if stat.S_ISREG(a.st_mode):value['sha256']=sha(path)
    assert value['stat']==[getattr(path.lstat(),k)for k in FIELDS];return value

def sources(here):
    preparation=here.parent;expected=json.loads((preparation/'immutable-source-pins.json').read_text())
    current={name:pin(name)for name in expected};assert current==expected,'Reviewed source/dependency/retained-original pin changed'
    freeze=json.loads((preparation/'freeze.json').read_text())
    for relative,digest in freeze['files'].items():assert sha(preparation/relative)==digest,relative
    history=json.loads((preparation/'historical-proof-scope.json').read_text())
    for row in history['stages']:
        stage=Path(row['path']);out=stage/'root-run-first';report=json.loads((out/'report.json').read_text())
        assert report['exitCode']==0 and report['retainedFiles']==row['retainedFiles']and not report['remainingOwnedProcesses']
        assert all(report[k]for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged'))
        assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
        assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text())
        thread=json.loads((out/'thread-report.json').read_text());assert thread==dict(exitCode=0,remainingNewThreads=[])
        selected=json.loads((stage/'selected-result.json').read_text())
        assert selected['successful']and selected['testsRun']==len(row['cases'])and selected['selectedIds']==row['cases']
        assert not any(selected[k]for k in ('failureCount','errorCount','skippedCount'))
        for index,case in enumerate(row['cases'],1):
            cleanup=stage/('case-cleanup-'+str(index));receipt=json.loads((cleanup/'receipt.json').read_text())
            assert receipt['case']==case and receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']
            a=json.loads((cleanup/'terminal-census-1.json').read_text());b=json.loads((cleanup/'terminal-census-2.json').read_text())
            assert a==b and not any(a[key]for key in ('threads','pendingTasks','sdkModules'))and a['children']==''
    for row in history.get('failedStages',[]):
        stage=Path(row['path']);report_path=stage/'run/report.json';assert sha(report_path)==row['reportSha256']
        report=json.loads(report_path.read_text());assert report['exitCode']==row['exitCode']==1 and report['retainedFiles']==row['retainedFiles']
        assert report['allPinsEqual']and report['retainedOriginalsUnchanged']and not report['remainingOwnedProcesses']
        assert json.loads((stage/'run/source-before.json').read_text())==json.loads((stage/'run/source-after.json').read_text())
        assert json.loads((stage/'run/originals-first.json').read_text())==json.loads((stage/'run/originals-second.json').read_text())
        receipt=json.loads((stage/'cleanup/receipt.json').read_text());assert receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']and len(receipt['retainedRoots'])==row['retainedRootCount']
        a=json.loads((stage/'cleanup/terminal-census-1.json').read_text());b=json.loads((stage/'cleanup/terminal-census-2.json').read_text())
        assert a==b and not any(a[k]for k in ('threads','pendingTasks','sdkModules'))and a['children']==''
        selected_path=stage/'selected-result.json';assert selected_path.exists()==row['selectedResultExists']
        if selected_path.exists():
            selected=json.loads(selected_path.read_text());assert selected['successful']is False and selected['testsRun']==1 and selected['failureCount']+selected['errorCount']>0 and selected['skippedCount']==0
    for row in history.get('passiveDiagnostics',[]):
        stage=Path(row['path']);assert sha(stage/'run/report.json')==row['reportSha256']and sha(Path(row['artifactPath']))==row['artifactSha256']
        report=json.loads((stage/'run/report.json').read_text());assert report['exitCode']==0 and report['allPinsEqual']and report['retainedOriginalsUnchanged']and not report['remainingOwnedProcesses']
        assert json.loads((stage/'run/source-before.json').read_text())==json.loads((stage/'run/source-after.json').read_text())
        assert json.loads((stage/'run/originals-first.json').read_text())==json.loads((stage/'run/originals-second.json').read_text())
        data=json.loads(Path(row['artifactPath']).read_text());assert data['diagnosticOnly']and data['freshPublishQualified']is False and data['completed']and data['noPublisherWALOrPOST']and data['actualPublisherPOSTs']==0
        receipt=json.loads((stage/'cleanup/receipt.json').read_text());assert receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']and len(receipt['retainedRoots'])==3
        a=json.loads((stage/'cleanup/terminal-census-1.json').read_text());b=json.loads((stage/'cleanup/terminal-census-2.json').read_text());assert a==b and not any(a[k]for k in('threads','pendingTasks','sdkModules'))and a['children']==''
    return current

def qualified_pass(stage):
    report=json.loads((stage/'run/report.json').read_text());selected=json.loads((stage/'selected-result.json').read_text())
    assert report['exitCode']==0 and report['allPinsEqual']and report['retainedOriginalsUnchanged']and not report['remainingOwnedProcesses']
    expected=json.loads((stage/'case.json').read_text())['case']
    assert selected['selectedIds']==[expected]and selected['successful']and selected['testsRun']==1 and not any(selected[k]for k in ('failureCount','errorCount','skippedCount'))
    receipt=json.loads((stage/'cleanup/receipt.json').read_text());assert receipt['case']==expected and receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']and len(receipt['retainedRoots'])==json.loads((stage/'case.json').read_text()).get('expectedTemporaryDirectories',3)
    before=json.loads((stage/'run/source-before.json').read_text());after=json.loads((stage/'run/source-after.json').read_text());assert before==after==json.loads((stage.parent/'immutable-source-pins.json').read_text())
    first=json.loads((stage/'run/originals-first.json').read_text());second=json.loads((stage/'run/originals-second.json').read_text());assert first==second
    root=stage/'retained';actual={str(p):pin(p)for p in(root,*sorted(root.rglob('*')))};assert second==actual
    a=json.loads((stage/'cleanup/terminal-census-1.json').read_text());b=json.loads((stage/'cleanup/terminal-census-2.json').read_text());assert a==b
    assert not any(a[k]for k in('threads','pendingTasks','sdkModules'))and a['children']==''

def first_pass(here):
    history=json.loads((here.parent/'historical-clock-prerequisites.json').read_text())
    for row in history['stages']:
        stage=Path(row['path']);assert sha(stage/'run/report.json')==row['reportSha256']and sha(stage.parent/'freeze.json')==row['controllerFreeze']
        assert json.loads((stage.parent/'plan.json').read_text())['sourceFreezeSha256']==row['sourceFreeze']
        qualified_pass(stage)
    own=json.loads((here.parent/'historical-qualified-instruction-prerequisites.json').read_text())
    for row in own['stages']:
        stage=Path(row['path']);assert sha(stage/'run/report.json')==row['reportSha256']and sha(stage.parent/'freeze.json')==row['controllerFreeze']
        assert json.loads((stage.parent/'plan.json').read_text())['sourceFreezeSha256']==row['sourceFreeze']
        qualified_pass(stage)
    warm=json.loads((here.parent/'historical-qualified-warm-prerequisites.json').read_text())
    for row in warm['stages']:
        stage=Path(row['path']);assert sha(stage/'run/report.json')==row['reportSha256']and sha(stage.parent/'freeze.json')==row['controllerFreeze']
        assert json.loads((stage.parent/'plan.json').read_text())['sourceFreezeSha256']==row['sourceFreeze']
        qualified_pass(stage)
        report=json.loads((stage/'run/report.json').read_text());assert report['globalOriginalsUnchanged']
        before=json.loads((stage/'run/global-originals-before.json').read_text())
        first=json.loads((stage/'run/global-originals-first.json').read_text());second=json.loads((stage/'run/global-originals-second.json').read_text())
        assert before==first==second
    order=('first1', 'sameInode1', 'parentOrphan1', 'code1', 'unsupported1', 'foreignStore1', 'lostPost1');assert here.name in order
    for name in order[:order.index(here.name)]:qualified_pass(here.parent/name)
