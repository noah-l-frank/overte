"""Finalize once, only in Root's explicit quiet window; no target imports.

Before that window this file is code only. Root supplies final terminal-context
including the actual completed Audio utility root and its frozen result packet.
"""
from pathlib import Path
import ast,json,os,shutil,subprocess,sys
from metadata import HERE,REPO,RAW,ARTIFACT,ARTIFACT_SHA,sha,pin,save,census,public_paths,global_roots,global_census

EXPECTED_HEAD='00fafcc4c097552198456c7e7687f243801d3ed8'
SOURCE15=REPO/'.ios-host-tmp/chat-send-proof-read-round-source15-draft-20261103'
SOURCE16D=REPO/'.ios-host-tmp/chat-current-module-type-dispatch-source16d-draft-20261103'
CHAT2=REPO/'.ios-host-tmp/chat-source15-retained-phase-readonly-controller2-20261103'
PUBLISHER5=REPO/'.ios-host-tmp/lifecycle-publisher-refusal-controller5-source4-utility-roots-final-preparation-20261103'
PUBLISHER_RESULT=REPO/'.ios-host-tmp/root-lifecycle-publisher-refusal-qualified-actual-operands-20261103'
SNAPSHOT_RESULT=REPO/'.ios-host-tmp/root-snapshot-history-commit-and-terminal-roots-20261103'
AUDIO_UTILITY=REPO/'.ios-host-tmp/root-audio-controller4-boundary-own4-qualified-results-20261103'
packet_pins={}
PREVIOUS_OWN10=REPO/'.ios-host-tmp/chat-current-module-dispatch-own10-suite-controller3-code-only-20261103'
PREVIOUS_REFUSAL=REPO/'.ios-host-tmp/root-chat-own10-controller3-precase-import-refusal-20261103'
KNOWN_PACKETS={
    PREVIOUS_OWN10:'ac918ebeefea8e23c8c7a0a3b645227584738d706c3ee04af17fb1a51434a263',
    PREVIOUS_REFUSAL:'d26fca535f53bbf20f93c38caf4d255f056f8bad505d48eae212a846d048b8e2',
    AUDIO_UTILITY:'21cc72cd1b67998b8bc1e81b09a4ceba118f95aeda95fc881ec6863b569b533b',
    SOURCE15:'f63f29623d4e4bc46daf0939fc1f8971d10c5e26a6a742faede244052190d685',
    SOURCE16D:'8d060ed7d82da95696a7a245b8ee7aaa302a8b4b35af395d52093231e317ae27',
    CHAT2:'ffe5550362f1bb6db14ff6327a54168f0103856a3fa67ae5448a3b6a8d53ef93',
    PUBLISHER5:'a58a0d916c40163e9d9ee126a04807da7658a230d8809c64991d89cb8845b570',
    PUBLISHER_RESULT:'ab010c9d0bbdfd58e8e0f29f89c5e8c689ff65f15b09b3245b1663105236c6cf',
    SNAPSHOT_RESULT:'dfabc87bacbbc13d38cc6a8fc0b7b47071bf7eae35c686aaafed307cd2c5898f',
    REPO/'.ios-host-tmp/root-snapshot-resume-commit-and-terminal-roots-20261103':'6b26d9970f4ce73e0a0980050aa36156909eb34dfe0e88a3035738492b2f1f85',
    REPO/'.ios-host-tmp/chat-current-module-type-dispatch-source16c-draft-20261103':'071818d0500f39232d60b79250421b3f1939cf3b9a0d66f5fcab8803de6c1312',
    REPO/'.ios-host-tmp/chat-current-module-type-dispatch-source16b-draft-20261103':'e38b6eddcac88950ee5c4482f02161a387871486ccbf911cdfafd68ed0bae6fd',
    REPO/'.ios-host-tmp/chat-current-module-type-dispatch-source16-draft-20261103':'e1684198420c7c43986f358ac35a19cb8fc908649f351554c408d9c192e2ec78',
}

def document(path):return json.loads(Path(path).read_text())

def packet_paths(directory,digest):
    assert directory.resolve(strict=True)==directory and directory.is_relative_to(REPO/'.ios-host-tmp')
    assert sha(directory/'freeze.json')==digest
    rows=document(directory/'freeze.json')['files']
    if type(rows)is list:rows={row['path']:row for row in rows}
    paths={directory/'freeze.json'}
    packet_pins[str(directory/'freeze.json')]=pin(directory/'freeze.json')
    for name,row in rows.items():
        path=directory/name
        assert not Path(name).is_absolute()and'..'not in Path(name).parts
        assert path.resolve(strict=True)==path and path.is_file()and not path.is_symlink()
        expected=row['sha256']if type(row)is dict else row
        assert sha(path)==expected,path
        paths.add(path);packet_pins[str(path)]=pin(path)
        assert packet_pins[str(path)]['sha256']==expected
    return paths

assert Path.cwd()==REPO and sys.dont_write_bytecode
assert sys.argv[1:]==['--root-confirmed-quiet']
assert not(HERE/'freeze.json').exists(),'New immutable successor required after any finalization'
code_freeze=document(HERE/'controller-code-freeze.json')
for name,row in code_freeze['files'].items():assert sha(HERE/name)==row['sha256'],'Reviewed controller code/metadata changed'
terminal=document(HERE/'terminal-context.json')
assert terminal['publicHead']==EXPECTED_HEAD and terminal['allTargetWindowsTerminal']is True
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==EXPECTED_HEAD
# Audio is deliberately not inferred from a sender WAL, an active directory or
# a guessed temp name. Root must approve this completed proof and exact roots.
assert terminal['audioAllWindowsTerminal']is True
assert terminal['audioFinalOriginalRoots']or terminal['audioFinalNoNewRawRoots']is True
audio_packet=REPO/terminal['audioFinalResultPacket']
known=dict(KNOWN_PACKETS);known[audio_packet]=terminal['audioFinalResultFreeze']
paths=set()
for directory,digest in known.items():paths.update(packet_paths(directory,digest))
for row in terminal['audioFinalOriginalRoots']:
    assert Path(row).is_absolute()and Path(row).is_relative_to(REPO/'.ios-host-tmp')
# Every metadata fact used below is pinned as an independent source artifact.
for name in('global-original-corpus-baseline.json','global-original-roots-seed.json'):
    paths.add(PUBLISHER5/name)
old_baseline=document(PUBLISHER5/'global-original-corpus-baseline.json')
assert len(old_baseline)==638,'Exact completed Publisher5 old-corpus set required'
chat_baseline=document(CHAT2/'global-originals-baseline.json')
assert set(chat_baseline)<=set(old_baseline),'Do not lose any Chat630 root'
for name,value in chat_baseline.items():assert old_baseline[name]==value,'Old corpus baseline disagrees'
refusal=document(PREVIOUS_REFUSAL/'results.json')
assert refusal['controllerFreeze']==known[PREVIOUS_OWN10]and refusal['allTenCasesUnrun']is True
assert refusal['publicHead']==EXPECTED_HEAD and refusal['actualStandardCaseCleanupQualified']is False
for row in document(PREVIOUS_REFUSAL/'actual-receipt-references.json').values():
    path=Path(row['path']);assert path.parent==PREVIOUS_OWN10 and sha(path)==row['sha256'];paths.add(path)
old_report=document(PREVIOUS_OWN10/'report.json');old_child=document(PREVIOUS_OWN10/'child-result.json')
assert old_report['exitCode']==1 and old_report['qualifiedCounter']is False
assert old_report['allGlobalOriginalsUnchanged']and old_report['allSourcePinsEqual']and old_report['outputCensusesEqual']
assert old_report['globalRoots']==645 and old_report['remainingOwnedProcesses']==[]
assert old_child['testsRun']is None and old_child['cleanup']==[]
assert old_child['refusals']==['Project import absent from exact origin map']
assert old_child['failure']['type']=='RuntimeError'and 'loadTestsFromName(selected)'in old_child['failure']['traceback']
assert old_child['inputUnchanged']and old_child['inputCensusesEqual']and old_child['sealedOutputCensusesEqual']
previous_physical=document(HERE/'closed-controller3-physical-pins.json')
for name,row in previous_physical.items():assert pin(PREVIOUS_OWN10/name)==row,'Closed Controller3 artifact changed'
paths.update(PREVIOUS_OWN10/name for name in previous_physical if name!='.')
seed=set(old_baseline)
seed.add(str(PREVIOUS_OWN10))
seed.update(document(PREVIOUS_OWN10/'global-originals-baseline.json'))

# The entire first1 room includes diagnostics, producer originals and bindings;
# the four narrower original namespaces remain explicit roots too.
publication=document(PUBLISHER_RESULT/'results.json')
assert publication['controllerFreeze']==known[PUBLISHER5]
assert publication['report']['globalOriginalRoots']==638 and publication['report']['globalOriginalsUnchanged']is True
first1=REPO/publication['sharedFinalOldCorpusRoot']
assert first1==PUBLISHER5/'first1'
assert len(publication['newOriginalRoots'])==4
seed.add(str(first1));seed.update(publication['newOriginalRoots'])
# Both utility original roots are mandatory, not just dynamic /runs discovery.
for label in('lifecycle-publisher-controller3-lock-utility-observer-counter-preparation-20261103',
        'lifecycle-publisher-controller4-lock-utility-counter2-preparation-20261103'):
    seed.add(str(REPO/'.ios-host-tmp'/label/'utility-stage'))
snapshot=document(SNAPSHOT_RESULT/'state.json');assert snapshot['publicHead']==EXPECTED_HEAD
seed.update(row['path']for row in snapshot['originalRoots'])
previous19=REPO/snapshot['previous19RootsPacket']
seed.update(document(previous19/'additional-original-roots.json'))
utility=document(AUDIO_UTILITY/'results.json')
assert utility['rawRoot']==str(REPO/'.ios-host-tmp/audio-controller4-boundary-own4-source-preparation2-full-ports-20261103/temporary')
seed.add(utility['rawRoot'])
seed.update(terminal['audioFinalOriginalRoots']);seed.add(str(RAW))
# Actual final scans begin only here, after all terminal proofs and quiet gate.
executables={name:Path(value).resolve(strict=True)for name,value in(
    ('python',sys.executable),('timeout',shutil.which('timeout')),('rg',shutil.which('rg')))}
save(HERE/'host-executable-pins.json',{name:dict(path=str(path),pin=pin(path))for name,path in executables.items()})
save(HERE/'global-root-seed.json',sorted(seed));roots=global_roots();assert len(roots)==646,'Exact completed645 plus whole Controller3 room required'
baseline=global_census(roots)
assert roots==global_roots()and baseline==global_census(roots),'Global originals must be completely quiet'
for name,value in old_baseline.items():assert baseline[name]==value,'Existing originals changed'
assert baseline[str(PREVIOUS_OWN10)]==previous_physical,'Whole closed Controller3 original census changed'
save(HERE/'global-originals-baseline.json',baseline)
raw=census(RAW);assert raw==document(CHAT2/'input-originals-baseline.json')
assert sum('sha256'in value for value in raw.values())==41 and sha(ARTIFACT)==ARTIFACT_SHA
save(HERE/'input-originals-baseline.json',raw)
# Preserve the original six Source15 source files physically, even when the
# actual module loader uses the new Source16d round file.
old_map=document(CHAT2/'approved-source-map.json')
for name,value in old_map.items():
    path=Path(name)
    if path.is_relative_to(REPO/'.ios-host-tmp'):
        assert pin(path)==value,'Retained private source/fixture physical identity changed'
        paths.add(path)
overlays=[]
for row in document(CHAT2/'plan.json')['overlays']:
    assert sha(REPO/row['path'])==row['sha256'];paths.add(REPO/row['path'])
    if row['module']=='chat_retained_readonly_phase_probe':continue
    if row['module']=='ios.adapters.chat_archive_round':continue
    overlays.append(dict(row))
for row in document(SOURCE16D/'candidate-source-rows.json'):
    path=SOURCE16D/row['path'];assert sha(path)==row['sha256']
    relative=path.relative_to(SOURCE16D/'candidate/tests/device').with_suffix('')
    overlays.append(dict(module='.'.join(relative.parts),path=str(path.relative_to(REPO)),sha256=row['sha256']))
for row in document(SOURCE16D/'exact-source15-and-actual-references.json'):
    path=REPO/row['path'];assert sha(path)==row['sha256'];paths.add(path)
public=public_paths();save(HERE/'public-membership.json',sorted(map(str,public)));paths.update(public)
origins={};namespaces=set()
for path in sorted(public):
    if path.suffix!='.py'or not path.is_relative_to(REPO/'tests/device'):continue
    parts=list(path.relative_to(REPO/'tests/device').with_suffix('').parts)
    if parts[-1]=='__init__':parts.pop()
    if not parts:continue
    label='.'.join(parts);assert label not in origins;origins[label]=str(path)
    for index in range(1,len(parts)):namespaces.add('.'.join(parts[:index]))
for row in overlays:
    origins[row['module']]=str(REPO/row['path']);paths.add(REPO/row['path'])
    parts=row['module'].split('.')
    for index in range(1,len(parts)):namespaces.add('.'.join(parts[:index]))
origins.update(metadata=str(HERE/'metadata.py'),__main__=str(HERE/'run-one.py'))
namespaces={name:str(REPO/'tests/device'/name.replace('.','/'))for name in namespaces if name not in origins}
save(HERE/'absolute-module-origins.json',dict(modules=origins,namespaces=namespaces))
selectors=document(SOURCE16D/'prospective-ten-selectors.json');assert len(selectors)==len(set(selectors))==10
save(HERE/'plan.json',dict(publicHead=EXPECTED_HEAD,allowedSelectors=selectors,suiteFailfast=True,
    source16dFreeze=known[SOURCE16D],expectedTestsRun=10,initialTimeoutSeconds=60,killAfterSeconds=5,
    overlays=overlays,packets=[dict(path=str(p.relative_to(REPO)),freezeSha256=d)for p,d in known.items()],
    globalRoots=len(roots),noTD=True,noNetwork=True,noSDK=True,noNode=True,noLocks=True,
    namespaceMicroprobeSelected=False,wholeChatQualified=False))
# Existing actual receipts and the four real producer namespaces are immutable
# old originals; source-plan metadata must also remain frozen during the suite.
paths.update(p for p in CHAT2.iterdir()if p.is_file())
paths.update(p for p in HERE.iterdir()if p.is_file())
paths.add(CHAT2/'global-originals-baseline.json');paths.add(PUBLISHER5/'global-original-corpus-baseline.json')
for name,value in packet_pins.items():assert pin(Path(name))==value,'Frozen packet changed during finalization'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==EXPECTED_HEAD
save(HERE/'approved-source-map.json',{str(p):pin(p)for p in sorted(paths)})
for p in HERE.glob('*.py'):ast.parse(p.read_text(),filename=str(p))
files=[]
for p in sorted(HERE.iterdir()):
    assert p.is_file()and not p.is_symlink()
    files.append(dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)))
save(HERE/'freeze.json',dict(status='frozen-unrun-root-review-required',files=files))
print(json.dumps(dict(freeze=sha(HERE/'freeze.json'),globalRoots=len(roots),sourcePins=len(paths),
    expectedTests=10,budgetSeconds=60,drainSeconds=5,targetExecuted=False)))
