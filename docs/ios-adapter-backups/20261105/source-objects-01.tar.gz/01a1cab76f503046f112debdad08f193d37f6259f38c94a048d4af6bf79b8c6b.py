"""Outer true kernel boundary for one exact finite Snapshot Scene group, fixed180+5."""
from pathlib import Path
from metadata_reader import pin
from host_common import head
from source_execution_readiness import qualification
from public_subject_readiness import readiness as subject_readiness,packet
from kernel_algorithm_readiness import algorithm as kernel_algorithm
from lifetime_composition_readiness import qualification as lifetime_qualification
from owned_node_observations import observe_binary,signal_candidate
import hashlib,json,os,signal,stat,subprocess,sys,threading,time,traceback
REPO=Path.cwd().resolve(strict=True);HERE=Path(__file__).resolve().parent
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert sys.flags.no_site==1, 'Explicit no-site startup required'
assert len(sys.argv)==2
INPUT=HERE/'approved-inputs.json';assert hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[1]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert head()==plan['actualPublicHead']
current_readiness,current_readiness_pins=qualification(pin)
assert current_readiness==plan['qualifiedSourceExecution']and current_readiness['currentHelperAlgorithmQualified']is True
assert current_readiness['consumerCompositionQualified']is False
actual_kernel,kernel_pins=kernel_algorithm(REPO,HERE,pin,packet)
assert actual_kernel==plan['ownedKernelAlgorithmProof']and actual_kernel['SnapshotConsumerCompositionQualified']is False
actual_lifetime,lifetime_pins=lifetime_qualification(REPO,HERE,pin,packet)
assert actual_lifetime==plan['ownedParentLifetimeUtilityProof']and actual_lifetime['actualFourParentLifetimeControlsQualified']is True
assert actual_lifetime['SnapshotConsumerCompositionQualified']is plan['snapshotConsumerCompositionQualified']is False
assert plan['newParentLifetimeCompositionQualified']is True
assert plan['ownedParentLifetimeRequiredOriginalRooms']==actual_lifetime['requiredOriginalRoots']
assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in lifetime_pins.items())
assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in kernel_pins.items())
assert plan['helperQualificationRequiredOriginalRooms']==current_readiness['requiredOriginalRoots']and len(current_readiness['requiredOriginalRoots'])==6
assert plan['externalRootGuardMustIncludeAllHelperOriginalRooms']is True
assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in current_readiness_pins.items())
assert plan['status']=='SOURCE12_CAPTURE_PHASE_PNG_PHOTOS_GROUP_UNRUN'
recipe=json.loads((HERE/'SOURCE-RECIPE.json').read_text());group=recipe['groups'][plan['group']]
assert plan['cases']==group['cases']and plan['caseCount']==group['caseCount']
assert plan['expectedTemporaryDirectories']==group['expectedTemporaryDirectories']and plan['expectedTemporaryDirectoriesPerCase']==group['expectedTemporaryDirectoriesPerCase']
actual_subjects,subject_pins=subject_readiness(pin,plan['publicCopyManifest']['path'],plan['publicCopyManifest']['sha256'])
assert actual_subjects==plan['declaredSubjectSourceBytes']
assert recipe['source9RootReview']==plan['source9RootReview']==actual_subjects['source9RootReview']
assert plan['nativeAdmission']is None
assert plan['publicCopyManifest']==actual_subjects['publicCopyManifest']
assert head()==plan['actualPublicHead']==actual_subjects['expectedParentHead']
assert plan['allSnapshotImplementationDefiningOriginsPublic']is actual_subjects['allImplementationDefiningOriginsPublic']is False
assert plan['publicSubjectOriginCount']==len(actual_subjects['publicSubjectOrigins'])==79
assert plan['privatePureOriginCount']==len(actual_subjects['privatePureTestOrigins'])==1
assert plan['subjectOriginCount']==len(actual_subjects['subjectOrigins'])==85
assert plan['privateOverlayOriginsExplicit']==actual_subjects['privateOverlayOrigins']and len(actual_subjects['privateOverlayOrigins'])==5
assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in subject_pins.items())
assert set(actual_subjects['requiredOriginalRoots'])|set(actual_kernel['requiredOriginalRoots'])|set(actual_lifetime['requiredOriginalRoots'])<=set(plan['externalRootOriginalRoots'])
assert plan['canonicalTransportIsModel']is True and plan['realAuthenticationOrIndependentProcessQualified']is plan['actorRenderedPixelsQualified']is False
assert plan['wallSeconds']==180 and plan['killGraceSeconds']==5 and len(plan['cases'])==plan['caseCount']and plan['caseCount']==1

def checked(path):
    path=Path(path);assert path.resolve().is_relative_to(REPO);return path

def meta(info):return[info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns]
def census(root):
    result={}
    def visit(path):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):
            names=sorted(item.name for item in path.iterdir());row=dict(stat=meta(info),namespace=names)
            for name in names:visit(path/name)
            assert meta(path.lstat())==meta(info)
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        result[str(path.relative_to(root))]=row
    visit(root);return result

def identity(pid):
    try:text=Path('/proc',str(pid),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    values=text[text.rfind(')')+2:].split()
    return dict(pid=int(text[:text.index('(')].strip()),parent=int(values[1]),group=int(values[2]),session=int(values[3]),startTicks=int(values[19]))
def table():
    result={}
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            row=identity(int(path.name))
            if row is not None:result[row['pid']]=row
    return result

def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:info=path.stat();result[path.name]=dict(target=os.readlink(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result

parent_fds=fds();parent_threads=tuple(threading.enumerate())
COLLECTOR=checked(HERE.with_name(HERE.name+'-outer'));assert not COLLECTOR.exists();checked(COLLECTOR).mkdir(mode=0o700)
def save(name,body):
    path=checked(COLLECTOR/name);assert path.parent==COLLECTOR
    with path.open('x')as stream:stream.write(json.dumps(body,sort_keys=True,indent=2)+'\n')
    path.chmod(0o600)

input_before=pin(INPUT);assert input_before['sha256']==sys.argv[1]
save('approved-input-before.json',input_before)
before={name:pin(name)for name in plan['sourceAndBinaryPins']};assert before==plan['sourceAndBinaryPins']
save('source-binary-before.json',before)
initial_names=sorted(path.name for path in HERE.iterdir())
for name in('own-toys','child-receipts','child-logs'):
    path=checked(HERE/name);assert not path.exists();path.mkdir(mode=0o700)
expected_names=sorted(initial_names+['own-toys','child-receipts','child-logs'])
LOGS=HERE/'child-logs';stdin=checked(LOGS/'stdin.eof');stdin.write_bytes(b'')
process=None;born=None;owned={};discovered={};birth_receipts={};node_observations={};signal_observations={};problems=[];timed_out=False;forced=False;term_at=None;baseline=table();started=time.monotonic()
def admit_node_receipts(final=False):
    if born is None:return
    expected=plan['resourceRecipe']['NodeExecutions']
    for index in range(1,expected+1):
        path=HERE/('child-receipts/actual-node-birth-'+str(index)+'.json')
        if not path.exists():
            if final:raise AssertionError('Missing genuine Node constructor receipt')
            continue
        actual_pin=pin(path)
        try:value=json.loads(path.read_text())
        except json.JSONDecodeError:
            if final:raise
            continue
        assert pin(path)==actual_pin and set(value)=={'schemaVersion','birth','creator','command','case','actualOriginalConstructorReturnObserved'}
        assert value['schemaVersion']==1 and value['actualOriginalConstructorReturnObserved']is True
        assert value['case']==plan['cases'][0]and value['creator']==('ArchiveEndNodeSource.__init__'if index%2 else'OriginalUploadScript.dispatch')
        row=value['birth'];assert type(row)is dict and set(row)=={'pid','parent','group','session','startTicks'}and all(type(x)is int for x in row.values())
        assert row['parent']==born['pid']and row['group']==row['session']==born['pid']and row['pid']not in baseline
        command=value['command'];assert type(command)is list and all(type(x)is str for x in command)
        if index%2:assert len(command)==4 and command[:2]==['node','-e']and command[-1]==str(REPO/'tests/device/ios/process_plugin/process_observer.cjs')
        else:assert command==['node',str(REPO/'tests/device/ios/self_tests/snapshot_upload_preflight.js'),str(REPO)]
        if index in birth_receipts:assert birth_receipts[index]==dict(pin=actual_pin,value=value)
        else:
            assert row['pid']not in owned and all(old['value']['birth']['pid']!=row['pid']for old in birth_receipts.values())
            # Creator-return receipt is produced by the exact fresh-source
            # Node callback. Discovery alone never enters this authority map.
            birth_receipts[index]=dict(pin=actual_pin,value=value);owned[row['pid']]=dict(row)
        observation=node_observations.setdefault(index,{})
        observe_binary(row,plan['nodeBinary'],pin,observation)
    if final:assert len(birth_receipts)==expected

try:
    with stdin.open('rb')as incoming,(LOGS/'stdout.log').open('xb')as output,(LOGS/'stderr.log').open('xb')as error:
        process=subprocess.Popen([sys.executable,'-S','-B',str(HERE/'run-group.py'),str(INPUT),sys.argv[1]],cwd=REPO,
            stdin=incoming,stdout=output,stderr=error,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(HERE/'own-toys')})
    born=identity(process.pid);assert born is not None and born['parent']==os.getpid()and born['group']==born['session']==born['pid']
    owned[born['pid']]=born;save('actual-runner-birth.json',born)
    while True:
        admit_node_receipts()
        actual=table();selected={born['pid']};changed=True
        while changed:
            changed=False
            for pid,row in actual.items():
                if pid in selected:continue
                if row['parent']in selected or row['group']==born['group']or row['session']==born['session']:
                    assert pid not in baseline;selected.add(pid);discovered.setdefault(pid,dict(row));changed=True
        if len(selected)>1+plan['resourceRecipe']['maxLiveNodes']:problems.append(dict(kind='too-many-live-children',identities=[actual[pid]for pid in selected]))
        for pid,row in owned.items():
            fresh=identity(pid)
            if fresh is not None and fresh!=row:problems.append(dict(kind='kernel-identity-changed',before=row,after=fresh))
        code=process.poll();elapsed=time.monotonic()-started
        if code is not None:break
        if elapsed>=180 and term_at is None:
            timed_out=True;term_at=time.monotonic()
            if signal_candidate(born,plan['originPlan']['pythonExecutable'],pin,signal_observations.setdefault(born['pid'],{})):os.kill(born['pid'],signal.SIGTERM)
        if term_at is not None and time.monotonic()-term_at>=5:
            forced=True
            if signal_candidate(born,plan['originPlan']['pythonExecutable'],pin,signal_observations.setdefault(born['pid'],{})):os.kill(born['pid'],signal.SIGKILL)
            process.wait();break
        time.sleep(.025)
    process.wait()
except BaseException:problems.append(dict(kind='original-parent-exception',traceback=traceback.format_exc()))
finally:
    try:admit_node_receipts(final=True)
    except BaseException:problems.append(dict(kind='original-node-receipt-refusal',traceback=traceback.format_exc()))
    orphans=[]
    for pid,binding in owned.items():
        actual=identity(pid)
        if actual is not None:
            orphans.append(dict(bound=binding,current=actual))
            if actual==binding:
                binary=plan['originPlan']['pythonExecutable']if pid==born['pid']else plan['nodeBinary']
                try:
                    if signal_candidate(binding,binary,pin,signal_observations.setdefault(pid,{})):os.kill(pid,signal.SIGKILL)
                except BaseException:problems.append(dict(kind='original-bound-rescue-refusal',pid=pid,traceback=traceback.format_exc()))
    if process is not None:process.wait()
    remaining=[dict(bound=owned.get(pid),firstDiscovery=discovered.get(pid),current=identity(pid))for pid in set(owned)|set(discovered)if identity(pid)is not None]
    unadmitted=set(discovered)-set(owned)
    if unadmitted:problems.append(dict(kind='unadmitted-observed-child',identities=[discovered[pid]for pid in unadmitted]))
    save('actual-process-drain.json',dict(owned=list(owned.values()),firstDiscoveries=list(discovered.values()),creatorReceipts=birth_receipts,nodeLifetimeObservations=node_observations,signalObservations=signal_observations,terminalIsPresentNotAbsence=True,originalBirthBindingsNeverReplaced=True,discoveryGrantsNoSignalAuthority=True,orphansRequiredKill=orphans,remaining=remaining,timedOut=timed_out,forced=forced))
    assert not remaining,'No quiet original census while a bound process remains'
    # Entire controller root, including approved-inputs and every metadata,
    # code, output and directory row. These reports are in sibling COLLECTOR.
    first=census(HERE);second=census(HERE)
    save('actual-child-output-first.json',first);save('actual-child-output-second.json',second)
    def child_subtrees(full):
        result={}
        for name in('own-toys','child-receipts','child-logs'):
            assert name in full
            prefix=name+'/'
            result[name]={'.'if key==name else key[len(prefix):]:row for key,row in full.items()if key==name or key.startswith(prefix)}
        return result
    first_children=child_subtrees(first);second_children=child_subtrees(second)
    save('actual-child-subtrees-first.json',first_children);save('actual-child-subtrees-second.json',second_children)
    input_after=pin(INPUT);save('approved-input-after.json',input_after)
    assert head()==plan['actualPublicHead']
    input_unchanged=input_before==input_after and input_before['sha256']==input_after['sha256']==sys.argv[1]
    assert all(name in first and name in second for name in('approved-inputs.json','run-group.py','supervise-group.py'))
    after={name:pin(name)for name in plan['sourceAndBinaryPins']};save('source-binary-after.json',after)
    resource_path=HERE/'child-receipts/actual-combined-resource-originals.json'
    resource=json.loads(resource_path.read_text())if resource_path.is_file()else None
    resource_ok=resource is not None and resource['directoryDescriptorsDrained']is True and resource['rawPipeBytesClaimed']is False and len(resource['actualNodes'])==plan['resourceRecipe']['NodeExecutions']
    if resource_ok:
        resource_ok=all(row['identity']==birth_receipts[i+1]['value']['birth']and row['creator']==birth_receipts[i+1]['value']['creator']and row['exitCode']==0 and row['allOriginalStreamsClosed']is True for i,row in enumerate(resource['actualNodes']))
    report_path=HERE/'child-receipts/report.json';restore_path=HERE/'child-receipts/actual-port-restoration.json'
    report=json.loads(report_path.read_text())if report_path.is_file()else None
    restore=json.loads(restore_path.read_text())if restore_path.is_file()else None
    selection_path=HERE/'child-receipts/actual-selection.json'
    selection=json.loads(selection_path.read_text())if selection_path.is_file()else None
    origins_path=HERE/'child-receipts/actual-source-model-origins.json'
    origins=json.loads(origins_path.read_text())if origins_path.is_file()else None
    origins_ok=origins is not None and origins['allDeclaredActualRuntimeOriginsEstablished']is True
    if origins_ok:
        rows=origins['subjectOrigins'];origins_ok=set(rows)==set(plan['subjectOriginModules'])and len(rows)==plan['subjectOriginCount']
        for name,expected in plan['subjectOriginModules'].items():
            row=rows.get(name,{})
            origins_ok=origins_ok and row.get('actualModulePresent')is True and row.get('exactOriginMatched')is True
            origins_ok=origins_ok and row.get('actualModuleFile')==row.get('actualLoaderExecutedPath')==expected['path']
            origins_ok=origins_ok and origins['actualExecutedOrigins'].get(name)==expected['path']
            origins_ok=origins_ok and row.get('expectedSha256')==expected['sha256']==pin(expected['path'])['sha256']
    parent_fd_after=fds();parent_thread_after=tuple(threading.enumerate())
    save('actual-parent-drain.json',dict(fdsEqual=parent_fds==parent_fd_after,threadsEqual=parent_threads==parent_thread_after))
    passed=resource_ok and len(birth_receipts)==plan['resourceRecipe']['NodeExecutions']and process is not None and process.returncode==0 and not problems and not orphans and not remaining and not timed_out and not forced
    passed=passed and first==second and first_children==second_children and input_unchanged and before==after and parent_fds==parent_fd_after and parent_threads==parent_thread_after
    passed=passed and sorted(path.name for path in HERE.iterdir())==expected_names
    passed=passed and report is not None and report['status']=='PASS'and report['testsRun']==plan['caseCount']and report['actualCaseReceipts']==plan['caseCount']and report['group']==plan['group']
    passed=passed and selection is not None and selection['ids']==plan['cases']and not selection['loaderErrors']
    passed=passed and origins_ok and report['allActualLoadedOriginsAccounted']is True
    passed=passed and restore is not None and restore['restored']and restore['count']==27 and not restore['controlDescriptors']and restore['dupPortsRestored']and restore['toolsRestored']and restore['builtinsCioRestored']and restore['actualC10dHelperSha256']==plan['subjectHelperSha256']
    passed=passed and restore['actualNodeMonitorRestoration']['actualOwnedConstructorToolRestored']and not restore['actualNodeMonitorRestoration']['originalConstructorUnwinds']and restore['actualResourceFailure']is None and not restore['actualResourceRescueErrors']
    terminal=dict(status='PASS'if passed else'FAIL_OR_REFUSED',childReturnCode=None if process is None else process.returncode,
        elapsedSeconds=time.monotonic()-started,problems=problems,timedOut=timed_out,forcedKill=forced,
        ownProcessesAbsent=not remaining,orphansRequiredKill=orphans,twoFullOwnOutputCensusesEqual=first==second,
        fullOwnCensusRoot=str(HERE),fullOwnCensusExclusions=[],approvedInputsExactPinAndCliShaUnchanged=input_unchanged,
        originalChildSubtreesCensusesEqual=first_children==second_children,
        allSourceBinaryPinsEqual=before==after,actualStdlibParentFDThreadDrain=parent_fds==parent_fd_after and parent_threads==parent_thread_after,
        allDeclaredActualRuntimeOriginsEstablished=origins_ok,
        newParentLifetimeCompositionQualified=True,ownedParentLifetimeUtilityProof=actual_lifetime,snapshotConsumerCompositionQualified=False,ownedKernelAlgorithmProof=actual_kernel,group=plan['group'],caseCount=plan['caseCount'],NodeExecutions=len(birth_receipts),actualCombinedResourceOriginalsEstablished=resource_ok,snapshotQualified=False,nativeQualified=False,globalScans=0)
    save('terminal.json',terminal)
# Complete HERE and outer after terminal/absence. Reports are written only in
# a third sibling; Root must close that final receipt room independently.
CENSUSES=checked(HERE.with_name(HERE.name+'-censuses'));assert not CENSUSES.exists();CENSUSES.mkdir(mode=0o700)
def actual_bound_processes_left():
    return [dict(original=owned.get(pid),firstDiscovery=discovered.get(pid),current=identity(pid))for pid in set(owned)|set(discovered)if identity(pid)is not None]
assert not actual_bound_processes_left()
whole_first=dict(HERE=census(HERE),outer=census(COLLECTOR))
whole_second=dict(HERE=census(HERE),outer=census(COLLECTOR))
for name,value in(('whole-first.json',whole_first),('whole-second.json',whole_second)):
    path=CENSUSES/name
    with path.open('x')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    path.chmod(0o600)
qualified=passed and whole_first==whole_second and not actual_bound_processes_left()
with(CENSUSES/'qualification.json').open('x')as stream:
    json.dump(dict(status='PASS'if qualified else'FAIL_OR_REFUSED',group=plan['group'],actualUtilityCases=plan['caseCount'],
        priorTerminalPassed=passed,twoCompleteHEREAndOuterCensusesEqual=whole_first==whole_second,
        noCensusExclusions=True,ownProcessesAbsent=not actual_bound_processes_left(),
        originalRoots=[str(HERE),str(COLLECTOR),str(CENSUSES)],capturePhasePNGPhotosConsumerAdmission=None,
        legacyCombinedDifferentTicketQualified=False,nativeQualified=False,wholeQualified=False),stream,indent=2,sort_keys=True);stream.write('\n')
(CENSUSES/'qualification.json').chmod(0o600)
raise SystemExit(0 if qualified else 1)
