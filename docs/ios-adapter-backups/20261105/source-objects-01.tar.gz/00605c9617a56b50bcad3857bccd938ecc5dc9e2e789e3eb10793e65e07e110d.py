from pathlib import Path
import ast,json,hashlib,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';PACK=T/'lifecycle-original-owner-native-shared-lock-proposal-20261028';LAST=T/'lifecycle-original-owner-motion-selected-join8-root-preparation-20261028';BASE=LAST/'20-motion-selected-join8';NODE=LAST/'21-default-motion14';ACQ=T/'lifecycle-original-owner-motion-owned-root-preparation-20261028/12-default-acquisition8';P=T/'lifecycle-original-owner-native-sharedlock3-root-preparation-20261028';P.mkdir(mode=0o700);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((PACK/'manifest.json').read_text());assert H(PACK/'freeze.json')=='c9b0f39520d2088b9c1de50c771bedfc74998a8abd96e76be7fc3021ff38cb62';assert H(R/m['path'])==m['baseSHA256']
for rel,digest in json.loads((PACK/'freeze.json').read_text())['files'].items():assert H(PACK/rel)==digest
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((BASE/'prior-retained-original-pins.json').read_text())
for stage,count in [(BASE,92),(NODE,47)]:
 report=json.loads((stage/'root-run-first/report.json').read_text());assert report['exitCode']==0 and report['retainedFiles']==count and not report['remainingOwnedProcesses'];root=stage/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==count
 for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
assert sum('sha256' in v for v in prior.values())==1016
for number,name,old in [(22,'22-native-sharedlock3',False),(23,'23-default-native-acquisition8',True)]:
 S=P/name;S.mkdir(mode=0o700)
 for n in ['root-child.py','root-supervise.py','root_stage_guard.py','source_model_bindings.py','supervisor-plan.json','run-selected.py','sdk-original-pins.json']:shutil.copyfile(BASE/n,S/n)
 stage=json.loads((BASE/'source-manifest.json').read_text());rows={r['path']:r for r in stage['sourcePaths']};changes=[]
 for rel,row in rows.items():
  if rel==m['path']:
   row.update(candidate=m['candidate'],candidateSHA256=m['candidateSHA256'],observedPublicSHA256=H(R/rel),changesCurrentPublic=True);continue
  current=H(R/rel)
  if row['candidateSHA256']!=current:
   out=S/'actual-current-snapshots/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out);changes.append(dict(path=rel,old=row['candidateSHA256'],current=current));row.update(candidate=str(out),candidateSHA256=current,observedPublicSHA256=current,changesCurrentPublic=False)
 stage.update(stage=number,name=name,status='PRIVATE_UNRUN_SHAREDLOCK3_AND_DEFAULT8',caseCount=8 if old else 3,pythonCaseCount=8 if old else 3,nodeCaseCount=0,sourcePaths=list(rows.values()),sourcePathCount=len(rows),sourceDeltaPaths=[m['path']],exactPublicMutationPlan='Root ONLY Source1 sharedlock keeper exact reviewed candidate; no registry/version/cap/gate changes. Shared actual snapshots preserve all foreign current bytes. Regression8 after same source no furtherPUB.')
 stage['orderedParentFreezes'][PACK.name]=H(PACK/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n')
 plan=json.loads((BASE/'run-plan.json').read_text())
 if old:
  names=['test_native_acquisition_models.py','native_file_fixture.py']
  for n in names:shutil.copyfile(ACQ/n,S/n)
  assert H(S/'test_native_acquisition_models.py')=='d5296ffd701ed4ecedc3d57f2bcfbb687a1f4f3b3090131f6d4f617b05306d09';plan['cases']=json.loads((ACQ/'run-plan.json').read_text())['cases'];plan['retainedTemporaryDirectoryAliases']=['ios.self_tests.test_ios_touch_lease'];plan['retainInstalledFixture']=False
 else:
  names=['test_native_shared_lock_models.py','test_motion_selected_join_models.py','motion_reference_fixture.py','native_acquisition_fixture.py','native_file_fixture.py']
  for n in names:shutil.copyfile(PACK/n,S/n)
  plan['cases']=json.loads((PACK/'test-plan.json').read_text())['cases']
 plan.update(status='PRIVATE_UNRUN_UNCHANGED_DEFAULT8' if old else 'PRIVATE_UNRUN_SHAREDLOCK3',caseCount=8 if old else 3,totalCaseCount=8 if old else 3,expectedRetainedRoots=8 if old else 6,initialOuterSeconds=60,killAfterSeconds=5)
 plan['privateFiles']={n:H(S/n) for n in ['root_stage_guard.py','source_model_bindings.py','run-selected.py',*names]};plan['requiredPublicDependencies']=sorted(set(plan['requiredPublicDependencies'])|set(rows));(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 (S/'source1.diff').write_bytes((PACK/'source1.diff').read_bytes());(S/'clone-provenance.json').write_text(json.dumps(dict(parentStageFreezeSHA256=H(BASE/'freeze.json'),sourcePacketFreezeSHA256=H(PACK/'freeze.json'),onlySourceDelta=m['path'],actualPublicBaseEqualsReviewedBase=True,actualPriorFiles=1016,sourcePathCount=len(rows),currentSnapshotAdjustments=changes,caseCount=plan['caseCount'],expectedRoots=plan['expectedRetainedRoots'],initialSeconds=60,killAfterSeconds=5,registryVersionCapGateChanges=False,executed=False),indent=2)+'\n')
 (S/'README.txt').write_text('''Root ONLY / PRIVATE UNRUN. Exact sharedlock3 and separate unchanged default8,
60+kill5 both;6/8 genuine TD expectation. Source1 keeper ONLY, reviewed base
verified equal actual current public join source. No family/version/cap/gate
change; actual shared/foreign expected snapshots retained or freshly pinned.
All1016 earlier actual files/nodes immutable, includes join92/default47 +old877.
Strict Root fullcurrent Source+launcher+SDK map BEFORE imports, canonical3roots,
actual FD/task/thread/child baselines/terminal and two original censuses unchanged.
Real TD aliases/existing retain helper; actual callbacks/async teardown and
creator/WDA/window/AFC/server/thread close+await+join preserved. Shared actor
model uses ACTUAL Resource selected_factory AST scope +real socketpair/reader;
source/native/RSD/SDK producer models remain explicit. No native/device/auth/
Down/movement/SDKEnd/canonical qualification. No fake close/GC/FD exclusions.
Root from repo PYTHONDONTWRITEBYTECODE=1 python3 <stage>/root-supervise.py
''')
 for p in S.rglob('*.py'):ast.parse(p.read_bytes(),filename=str(p))
 (S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n');print(name,H(S/'freeze.json'),'snapshots',changes)
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_BOTH_STAGES',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print('parent',H(P/'freeze.json'))
