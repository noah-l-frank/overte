"""UNRUN actual first four normal Audio actions; declared lower host producers.

The original Source2 two-action test executes unchanged once as the prefix.
This is neither Normal14, native PCM lifetime, installed dispatch nor End proof.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from feature_journeys.evidence import audio_observation
from feature_journeys.scenarios import SCENARIOS
from feature_journeys.witness import WITNESS_KEYS,projection
from ios.adapters.audio_authorization_sources import AudioAuthorizationSources
from ios.adapters.audio_authorized_start import AudioAuthorizedStarts
from ios.adapters.audio_page_inputs import AudioPageInputs
from ios.self_tests import test_ios_audio_normal_mute_prefix as passed_prefix
from ios.self_tests.audio_whole_fixture import AudioWholeFixture,RUN


class AudioNormalMutedRejectionPrefixTests(unittest.TestCase):
    def setUp(self):self.f=AudioWholeFixture(self)

    def actor_original(self,ticket):
        f=self.f;calls=f.source_calls
        with f.actor.held():
            f.actor.load();self.assertTrue(f.actor.state['publication']['returned'])
            current=f.actor.current(historical=True);reference=current.state['records'][-1]
            original=f.actor.publication_original(dict(currentReference=reference,sequence=f.actor.state['sequence'],bindingStage='initial'))
            self.assertEqual(ticket,original['ticket'])
        self.assertEqual(calls,f.source_calls)
        entries=f.journal.snapshot(RUN)['entries'];self.assertEqual(ticket,entries[-1]['ticket'])
        self.assertEqual(set(WITNESS_KEYS['audio']),set(entries[-1]['facts']))
        self.assertEqual(projection('audio',original['public']['state']),entries[-1]['facts'])
        return original

    def test_actual_muted_record_rejection_and_unmute_join_primary_originals_silence_actor_without_once_claim(self):
        # No second Prepare/Open/Mute. Execute the entire actually qualified
        # Source2 test body on this same original fixture/case exactly once.
        passed_prefix.AudioNormalMutePrefixTests.test_actual_prepare_open_first_mute_original_inputs_silence_and_actor_publication(self)
        f=self.f;steps=deepcopy(SCENARIOS['audio']['steps'][:4])
        self.assertEqual(['open','mute','record-start','mute'],[s['verb']for s in steps])
        self.assertEqual({},steps[2]['inputs']);self.assertEqual(dict(enabled=False),steps[3]['inputs'])
        self.assertEqual(0,f.m.actions.count('audio.record'));self.assertEqual([],f.once.boundary.once.inputs)
        ticket=format(3,'032x');rejected=f.step('record-start',ticket,{})
        actual=rejected['state'];self.assertTrue(actual['open']);self.assertTrue(actual['muted'])
        self.assertFalse(actual['recording']);self.assertFalse(actual['preview'])
        self.assertEqual('error',actual['phase']);self.assertEqual(['error'],actual['history']);self.assertEqual('microphone-muted',actual['error'])
        for key in('recordedFrames','playedFrames','bufferedFrames'):self.assertEqual(0,actual[key])
        self.assertEqual(1,f.m.actions.count('audio.record'));self.assertEqual([],f.once.boundary.once.inputs)
        calls=f.source_calls
        with f.primary.held():
            f.primary.load();rows=f.primary.state['actions']
            self.assertEqual(['open','mute','record-start'],[r['call']['verb']for r in rows])
            self.assertTrue(all(r['returned']and r['completed']for r in rows));self.assertIsNone(f.primary.state['pending'])
            parent=f.primary.primary_parent();operations=[r for r in parent.state['operations']if r['ticket']==ticket and r['verb']=='record-start']
            self.assertEqual(1,len(operations));operation=operations[0]
            before=parent.original(operation['before']);after=parent.original(operation['after'])
            self.assertEqual({},parent.phase_original(before['phaseBefore'],ticket,'record-start'))
            measured=parent.effect(operation,after);self.assertEqual(projection('audio',actual),measured)
            self.assertEqual('audio',AudioPageInputs.route(before['originals']['ui']));self.assertEqual('audio',AudioPageInputs.route(after['originals']['ui']))
            self.assertTrue(before['originals']['native']['audio']['muted']);self.assertTrue(after['originals']['native']['audio']['muted'])
            inputs=[r for r in operation['inputs']if r['verb']=='record-start'];self.assertEqual(1,len(inputs));self.assertEqual('audio.record',inputs[0]['identifier'])
            # Existing typed historical admission joins genuine OS grants,
            # actual parent input row and completed after-start original. There
            # is no invented raw native 'input returned' archive/field.
            grants=AudioAuthorizationSources.archive(PrivateFeatureState(parent.store.path.with_name('ios-audio-authorization-owner.json')),parent)
            starts=AudioAuthorizedStarts.archive(PrivateFeatureState(parent.store.path.with_name('ios-audio-authorized-starts.json')),parent,grants)
            entries=[e for e in starts.state['entries']if e['ticket']==ticket];self.assertEqual(1,len(entries));entry=entries[0]
            self.assertEqual('complete',entry['phase']);self.assertEqual(operation['after'],entry['startedBy'])
            self.assertEqual(inputs[0],entry['input']['row']);self.assertIsNotNone(entry['after'])
            self.assertEqual(projection('audio',actual),starts.effect(entry))
            artifacts=[a for a in f.primary.state['artifacts']if a['ticket']==ticket]
            self.assertEqual(['audio'],[a['kind']for a in artifacts]);self.assertTrue(f.primary.validate_artifact_source(artifacts[0]))
            wav=f.primary.evidence.read(artifacts[0]);self.assertEqual(artifacts[0]['captureEpochMs'],rejected['artifacts'][0]['capturedEpochMs'])
        self.assertEqual(calls,f.source_calls)
        self.assertTrue(audio_observation(wav,RUN,ticket,silence=True)['passed'])
        actor=self.actor_original(ticket)['public']['state']
        self.assertTrue(actor['open']);self.assertTrue(actor['muted']);self.assertEqual('microphone-muted',actor['error'])
        self.assertEqual('error',actor['phase']);self.assertEqual(['error'],actor['history'])
        for key in('recordedFrames','playedFrames','bufferedFrames'):self.assertEqual(0,actor[key])
        ticket=format(4,'032x');unmuted=f.step('mute',ticket,dict(enabled=False))
        self.assertTrue(unmuted['state']['open']);self.assertFalse(unmuted['state']['muted'])
        self.assertFalse(unmuted['state']['recording']);self.assertFalse(unmuted['state']['preview'])
        self.assertEqual(1,f.m.actions.count('audio.record'));self.assertEqual([],f.once.boundary.once.inputs)
        calls=f.source_calls
        with f.primary.held():
            f.primary.load();rows=f.primary.state['actions']
            self.assertEqual(['open','mute','record-start','mute'],[r['call']['verb']for r in rows])
            self.assertEqual([format(i,'032x')for i in(1,2,3,4)],[r['call']['ticket']for r in rows])
            self.assertTrue(all(r['returned']and r['completed']for r in rows));self.assertIsNone(f.primary.state['pending'])
            parent=f.primary.primary_parent();operations=[r for r in parent.state['operations']if r['ticket']==ticket and r['verb']=='mute']
            self.assertEqual(1,len(operations));operation=operations[0]
            before=parent.original(operation['before']);after=parent.original(operation['after'])
            self.assertEqual(dict(enabled=False),parent.phase_original(before['phaseBefore'],ticket,'mute'))
            self.assertEqual(projection('audio',unmuted['state']),parent.effect(operation,after))
            self.assertEqual('audio',AudioPageInputs.route(before['originals']['ui']));self.assertEqual('audio',AudioPageInputs.route(after['originals']['ui']))
            self.assertTrue(before['originals']['native']['audio']['muted']);self.assertFalse(after['originals']['native']['audio']['muted'])
            inputs=[r for r in operation['inputs']if r['verb']=='mute'];self.assertEqual(1,len(inputs));self.assertEqual('audio.mute',inputs[0]['identifier'])
        self.assertEqual(calls,f.source_calls)
        actor=self.actor_original(ticket)['public']['state'];self.assertTrue(actor['open']);self.assertFalse(actor['muted'])
        self.assertEqual(unmuted['state']['phase'],actor['phase']);self.assertEqual(unmuted['state']['history'],actor['history'])
        self.assertEqual(unmuted['state']['error'],actor['error'])
        self.assertEqual([],f.once.boundary.once.inputs)
