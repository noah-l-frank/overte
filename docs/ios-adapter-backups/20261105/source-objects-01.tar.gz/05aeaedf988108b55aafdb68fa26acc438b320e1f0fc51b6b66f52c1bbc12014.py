"""Seven actually qualified source/foreign/HTTP counters, read-only custody."""
from pathlib import Path
import hashlib,json

def checked(preparation):
    from guard import pin,sha
    spec=json.loads((Path(preparation)/'prerequisites.json').read_text())
    assert [row['kind']for row in spec['proofs']]==['ast4','foreign1','publisher2']
    physical=set()
    for row in spec['proofs']:
        folder=Path(row['path']);freeze=folder/'freeze.json';assert sha(freeze)==row['freezeSha256'];physical.add(freeze)
        for name,original in json.loads(freeze.read_text())['files'].items():
            digest=original if type(original)is str else original['sha256']
            path=folder/name;assert sha(path)==digest;physical.add(path)
        if row['kind']=='ast4':
            result=json.loads((folder/'report.json').read_text())
            assert result['status']=='PASS'and result['testsRun']==4 and result['errors']==result['failures']==0
            assert all(result[name]for name in('actualStandardTestRunReturned','allActualSourcePinsUnchanged','fdUnchanged','threadsUnchanged','noChildBorn','subjectModulesAbsent'))
            assert result['rawRootsCreated']==0 and result['runtimeDiagnosticQualified']is False
            for path,old in json.loads((folder/'source-pins.json').read_text()).items():assert pin(path)==old;physical.add(Path(path))
        else:
            result=json.loads((folder/'results.json').read_text());terminal=result['terminal']
            assert terminal['status']=='PASS'and terminal['childReturnCode']==0 and terminal['ownProcessesAbsent']and not terminal['timedOut']and not terminal['forcedKill']
            assert result['ports']['restored']and result['ports']['count']==27
            assert result['actualTests']==(1 if row['kind']=='foreign1'else 2)
            assert result['foreignCounterQualified'if row['kind']=='foreign1'else'publisher2Qualified']is True
            assert result['nativeQualified']is False and result['wholeQualified']is False
            refs=folder/'actual-receipt-references.json'
            for original in json.loads(refs.read_text()).values():
                path=Path(original['path']);assert sha(path)==original['sha256'];physical.add(path)
    return physical
