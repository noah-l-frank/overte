"""Explicit independent logical Actor port; no Primary input authority."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import need
from feature_journeys.contract import VERSION as CONTRACT_VERSION
from feature_journeys.witness import Client
from ios.adapters.lifecycle_feature import IOSLifecycleFeature
from ios.adapters.lifecycle_editors_runtime import IOSLifecycleEditorsRuntime


class IOSLifecycleActor:
    def __init__(self,runtime,selector,client,run,settings,**clocks):
        # AdapterFixtureClient is deliberately excluded: the Primary adapter
        # has GET-only authority and cannot impersonate an Actor publisher.
        need(type(client)is Client and type(runtime)is IOSLifecycleEditorsRuntime)
        self.flow=IOSLifecycleFeature(runtime,selector,client,run,'actor',settings,**clocks)

    def observe_active(self,after_sequence):
        return self.flow.observe(dict(contractVersion=CONTRACT_VERSION,runId=self.flow.run,afterSequence=after_sequence))

    def cleanup(self):
        return self.flow.cleanup(dict(contractVersion=CONTRACT_VERSION,runId=self.flow.run))
