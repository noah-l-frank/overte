"""Root-only immutable one-case execution, fixed180+5 wall/process boundary."""
import json,os,stat,subprocess,sys,time
from pathlib import Path
from guard import pin,sources,first_pass,moving_qualified_pass
from global_original_corpus import guard as global_originals
from moving_owned_identity import process,owned_executable
from moving_kernel_qualification import require_actual_utility
PREP=Path(__file__).resolve().parent;HERE=Path(sys.argv[1]).resolve()
plan=json.loads((PREP/'plan.json').read_text());REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and str(REPO)==plan['repositoryRoot']
def target(p):
    p=Path(p);assert p.resolve().is_relative_to(REPO);return p
assert HERE.parent==PREP and HERE.name in ('first1',)and Path.cwd()==REPO and sys.dont_write_bytecode
sources(HERE);first_pass(HERE)
require_actual_utility(plan)
selection=json.loads((HERE/'case.json').read_text());wall=selection['wallSeconds'];assert wall==180 and selection['killAfterSeconds']==5
out=HERE/'run';target(out).mkdir(mode=0o700,exist_ok=False)
def save(name,value):
    fd=os.open(target(out/name),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def remaining(bound):
    rows=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        row=process(int(path.name))
        if row is not None and(row['sid']==bound['pid']or row['pgid']==bound['pid']):rows.append(row)
    return rows
def census():
    value={}
    for root in(HERE/'retained',HERE/'bindings'):
        if root.exists():value.update({str(p):pin(p)for p in(root,*sorted(root.rglob('*')))})
    return value
before=sources(HERE);save('source-before.json',before)
prior=global_originals();save('global-originals-before.json',prior)
command=['timeout','--signal=TERM','--kill-after=5s',str(wall)+'s',sys.executable,'-B','-S',str(PREP/'run-selected.py')]
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',LIFECYCLE_WHOLE_STAGE=str(HERE))
started=time.monotonic()
with target(out/'test.log').open('x')as log:
    task=subprocess.Popen(command,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    bound=process(task.pid);assert bound is not None and bound['sid']==bound['pgid']==task.pid
    save('process-binding.json',dict(task=bound,supervisor=process(os.getpid()),command=command))
    observed={};node_births={};node_problems=[]
    while True:
        for row in remaining(bound):
            key=str(row['pid']);prior_identity=observed.setdefault(key,row)
            if prior_identity!=row:
                node_problems.append(dict(kind='own-session-identity-change',before=prior_identity,after=row))
                continue # Never read exe for an identity already known to differ.
            actual=owned_executable(row,bound)
            if actual is None:continue # No positive executable/command evidence.
            if actual['executable']==plan['nodeExecutable']['path']:
                assert pin(Path(actual['executable']))==plan['nodeExecutable']['pin']
                assert actual['command']==['node',plan['movingNodeScript']['path']]
                birth=actual
                if key in node_births:assert node_births[key]==birth
                else:node_births[key]=birth
        code=task.poll()
        if code is not None:break
        time.sleep(.025)
    task.wait()
    save('moving-node-kernel-births.json',dict(nodes=list(node_births.values()),observedOwnSession=list(observed.values()),problems=node_problems))
left=remaining(bound);assert not left,'Owned process remains; originals must not yet be censused'
after=sources(HERE);save('source-after.json',after)
first_pass(HERE) # Recheck every actually qualified sibling corpus after drain.
prior_first=global_originals();save('global-originals-first.json',prior_first)
first_pass(HERE) # Second complete predecessor original census; no writer exception.
prior_second=global_originals();save('global-originals-second.json',prior_second);assert prior==prior_first==prior_second
first=census();save('originals-first.json',first)
assert not remaining(bound);second=census();save('originals-second.json',second)
value=dict(exitCode=code,seconds=time.monotonic()-started,sourcePins=len(before),allPinsEqual=before==after,
    retainedOriginalsUnchanged=first==second,bindingsIncludedInBothOwnCensuses=str(HERE/'bindings')in first and str(HERE/'bindings')in second,globalOriginalsUnchanged=prior==prior_first==prior_second,globalOriginalRoots=len(prior),remainingOwnedProcesses=remaining(bound),
    retainedFiles=sum(stat.S_ISREG(row['stat'][2])for row in second.values()),nodeKernelBirths=len(node_births),nodeIdentityProblems=node_problems,wholeFeatureQualified=False,nativeQualified=False)
save('report.json',value);assert before==after and first==second and not value['remainingOwnedProcesses']
if code==0:
    assert len(node_births)==1 and not node_problems
    moving_qualified_pass(HERE)
raise SystemExit(code)
