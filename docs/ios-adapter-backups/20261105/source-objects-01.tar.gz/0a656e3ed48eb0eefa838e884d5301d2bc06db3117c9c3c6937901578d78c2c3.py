"""Typed per-path historical absence from an actual Callback end journal.

This view authorizes interpretation of retained metadata only. It cannot Stop,
DELETE, query a process, retire metadata, or claim a current GPU/native fact.
The end owner separately fully decodes both process and SDK graphs before any
retirement. Every lookup freshly checks the original durable deletion index.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import pack,unpack,same
from ios.adapters.emote_post9_copied_archive import IOSEmotePost9CopiedArchive
from ios.adapters.emote_retirement import Frozen
from ios.adapters.process_retirement import IOSProcessRetirement,filename
from ios.adapters.installed_code import source as process_source


class Post9RetirementView:
    def __init__(self,archive,seal):
        need(type(archive) is IOSEmotePost9CopiedArchive and archive.state is not None and archive.state['phase']=='validated')
        self.archive,self.seal=archive,deepcopy(seal);self.copies,self.checkpoint=archive.retained()
        archive.validate_context(self.copies);need(same(self.checkpoint['seal'],seal))
        self.run=archive.run;self.locks=dict(primary=archive.lock,actor=archive.actor_lock)
        self.store=PrivateFeatureState(archive.store.path.with_name('ios-emote-primary-'+self.run+'-post9-end.json'))
        self.fixed=None;self.last_retired=0;self.originals={};self.expected=deepcopy(self.copies)
        state=self.state()
        for role,lock in self.locks.items():
            feature=self.copies[str(lock.path.with_name('ios-emote-'+role+'-feature.json'))]
            binding=feature['targetPair'][role+'Binding'];root=Path(feature['artifactRoot'])
            for kind,tail,version in (('processes','process','iosEmotePost9ProcessEndVersion'),('sessions','sdk','iosEmotePost9SDKEndVersion')):
                path=lock.path.with_name('ios-emote-'+role+'-'+self.run+'-post9-'+tail+'-end.json');raw=PrivateFeatureState(path).read()
                need(type(raw) is dict and digest(raw)==state[kind][role] and type(raw.get(version)) is int and raw[version]==(3 if kind=='processes'else 2)
                    and raw.get('runId')==self.run and raw.get('role')==role and same(raw.get('binding'),binding)
                    and raw.get('artifactRoot')==str(root))
                rows=unpack(raw['payload']);need(len(rows)==1);value=rows[0]
                need(value['phase']=='complete' and value['pending'] is None);self.originals[path]=deepcopy(raw)
                if kind=='processes':
                    need(raw['archiveSha256']==digest(archive.previous) and raw['sealSha256']==digest(seal))
                    source=process_source(value['source']);bundle=value['bundleId']
                    os=PrivateFeatureState(path.with_name(filename('emote',role,0)));packet=os.read();need(packet is not None and digest(packet)==value['processSha256'])
                    decoded=IOSProcessRetirement.archive(packet,path=os.path,binding=binding,source=source,bundle=bundle,run=self.run,role=role,stage=0,profile='emote')
                    need(decoded['pending'] is None and decoded['windows'] and decoded['windows'][-1]['complete'])
                    def guard():
                        for owned in self.locks.values():owned.assert_held()
                        return True
                    frames=OriginalFrameStore(root,binding,self.run,role,guard,lambda *_:need(False),namespace='emote-post9-process',schema_prefix='emotePost9Process')
                    fence=frames.read(frames.expand(value['fence']));need(type(fence.get('iosEmotePost9FenceVersion')) is int
                        and fence['iosEmotePost9FenceVersion']==2 and fence['archiveSha256']==digest(archive.previous)
                        and fence['sealSha256']==digest(seal) and fence['runId']==self.run and fence['role']==role and same(fence['binding'],binding))
                    for key,tail_ in (('scope','marker'),('keys','keys'),('pointers','pointers')):
                        target=str(lock.path.with_name('ios-emote-'+role+'-'+tail_+'.json'))
                        need(target in self.expected);self.expected[target]=deepcopy(fence[key])
                    # Reopen the response originals as a historical typed read;
                    # no live SDK/native query or synthetic AFC inode exists.
                    from ios.adapters.emote_post9_response_retirement import retained
                    response=value['response']
                    response_frames=OriginalFrameStore(root,binding,self.run,role,guard,lambda *_:need(False),
                        namespace='emote-post9-response',schema_prefix='emotePost9Response')
                    read=response_frames.read(response_frames.expand(response['read']))
                    retained(response_frames,response,fence,binding=binding,run=self.run,source=source,bundle=bundle,
                        directory=read['afcOriginal']['resultsDirectory'])
                    process_raw=raw
                else:
                    need(raw['processSha256']==digest(process_raw) and value['observed404'] is True)
                    os=PrivateFeatureState(path.with_name(filename('emote',role,1)));packet=os.read();need(packet is not None and digest(packet)==value['osSha256'])
                    decoded=IOSProcessRetirement.archive(packet,path=os.path,binding=binding,source=source,bundle=bundle,run=self.run,role=role,stage=1,profile='emote')
                    need(decoded['pending'] is None and decoded['windows'] and decoded['windows'][-1]['complete'])
        self.guard()
    def state(self):
        for lock in self.locks.values():lock.assert_held()
        need(same(self.archive.store.read(),self.archive.previous))
        raw=self.store.read();exact(raw,{'iosEmotePost9EndArchiveVersion','runId','archiveSha256','seal','payload'})
        need(type(raw['iosEmotePost9EndArchiveVersion']) is int and raw['iosEmotePost9EndArchiveVersion']==2
            and raw['runId']==self.run and raw['archiveSha256']==digest(self.archive.previous) and same(raw['seal'],self.seal))
        rows=unpack(raw['payload']);need(len(rows)==1);state=rows[0];exact(state,{'phase','processes','sessions','retired','pending'})
        need(raw['payload']==pack([state]))
        need(state['phase'] in ('prepared','retiring','complete') and integer(state['retired'],self.last_retired,len(self.archive.state['paths'])))
        for key in ('processes','sessions'):
            exact(state[key],{'primary','actor'})
            need(all(type(sha) is str and len(sha)==64 and all(ch in '0123456789abcdef' for ch in sha) for sha in state[key].values()))
        if state['pending'] is not None:need(state['phase']=='retiring' and type(state['pending']) is int
            and state['pending']==state['retired'] and state['pending']<len(self.archive.state['paths']))
        if state['phase']=='prepared':need(state['retired']==0 and state['pending'] is None)
        if state['phase']=='complete':need(state['retired']==len(self.archive.state['paths']) and state['pending'] is None)
        fixed=dict(processes=state['processes'],sessions=state['sessions'])
        if self.fixed is None:self.fixed=deepcopy(fixed)
        else:need(same(fixed,self.fixed))
        self.last_retired=state['retired'];return state
    def guard(self):
        self.state();need(all(same(PrivateFeatureState(path).read(),value) for path,value in self.originals.items()));return True
    def store_for(self,path,value):
        path=Path(path);state=self.state();key=str(path)
        need(key in self.expected and same(value,self.expected[key]))
        paths=self.archive.state['paths'];need(key in paths);index=paths.index(key);current=PrivateFeatureState(path).read()
        if index<state['retired']:need(current is None)
        elif index==state['pending']:need(current is None or same(current,value))
        else:need(same(current,value))
        self.guard();return Frozen(path,value)
    def gpu_membership(self,expected,actual):
        need(type(expected) is set and type(actual) is set and actual<=expected)
        for path in expected:
            key=str(path);need(key in self.copies);self.store_for(path,self.copies[key])
        self.guard();return True
