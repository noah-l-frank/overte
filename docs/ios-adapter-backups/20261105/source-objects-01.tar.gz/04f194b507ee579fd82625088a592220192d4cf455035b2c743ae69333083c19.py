"""Root runs once AFTER exact public publication; no target imports/tests."""
from run_metadata import HERE,REPO,validate_frozen,publication,sources,save,sha
import json,subprocess
plan=validate_frozen();rows=publication();path=HERE/'publication-ready-source-map.json'
assert not path.exists(),'No silent replacement of an approved source map'
actual=sources(plan);assert actual==sources(plan),'Full Source changed during metadata snapshot'
config=json.loads((HERE/'source-root-final-map.json').read_text())
modulePins={name:dict(path=row['path'],sha256=actual[row['path']]['sha256']) for name,row in config['modules'].items()}
value=dict(status='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),publication=rows,sourcePins=actual,modulePins=modulePins,mainCpp=actual['interface/src/main.cpp'],testsExecuted=False,targetImportsExecuted=False)
save(path,value)
print(json.dumps(dict(sourceMap=str(path),sourceMapSha256=sha(path),pins=len(actual),modules=len(modulePins),head=value['head']),sort_keys=True))
