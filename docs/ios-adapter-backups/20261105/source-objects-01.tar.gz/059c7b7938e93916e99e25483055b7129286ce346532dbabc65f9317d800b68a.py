"""PRIVATE test-only overlay and fresh Root preparation. No target imports/run."""
from pathlib import Path
import ast,difflib,hashlib,json,shutil,stat
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp'
O=T/'lifecycle-original-owner-native-current-predown-proposal-20261028'
B=T/'lifecycle-original-owner-native-current9-root-preparation-20261028/26-native-current9'
J=B.parent/'27-join8-current-regression'
P=T/'lifecycle-original-owner-native-current-drain-model-overlay-20261028';P.mkdir(mode=0o700)
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
name='test_native_current_predown_models.py';old=(O/name).read_text()
start=old.index("            drain=asyncio.create_task(self.source.settle_touches())")
end=old.index('\n\n    async def test_cancelled_actor',start)
new='''            with resource.lock.held():
                # The actual original SDK operation still requires the SAME
                # serialization scope while its lost return settles. Closing
                # admission/revocation remains strict and cannot grant current.
                drain=asyncio.create_task(self.source.settle_touches());self.controls_motion.append(drain)
                await asyncio.sleep(.02);self.assertFalse(drain.done());self.assertFalse(self.creator.done())
                self.window_gate.set()
                try:await task
                except (RuntimeError,ValueError):pass
                with self.assertRaises((RuntimeError,ValueError)) as failure:await drain
                self.assertIs(failure.exception,task.exception())
                self.assertTrue(task.done());self.assertFalse(task.cancelled());self.assertTrue(drain.done())
                self.assertTrue(self.window_closed.is_set());self.assertTrue(all(fd.fileno()==-1 for fd in self.window_sockets))
                self.assertTrue(resource._motion_failed);self.assertTrue(self.selected[3]['revoked']);self.assertEqual([],self.f.states())
        finally:self.window_gate.set()'''
text=old[:start]+new+old[end:];ast.parse(text);(P/name).write_text(text)
(P/'test-only.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
explanation='''TEST-ONLY, UNRUN. First actual Current9 failed5 after4PASS because the test
expected successful Source.settle_touches even though the retained current SDK
Task correctly fails its current-source guard after caller timeout and closing.
The original test also left the actual Resource serialization scope before
that original SDK return. The corrected case keeps the actual same lock through
settle and explicitly requires propagated original Task error identity, actual
done/notcancelled, real WDA socketpair closed, selected receipt revoked, zero
input. Source2/SDK/identity/deadlines/gates unchanged. The original failed69files
and separate Join8PASS92files remain pinned with1101prior=1262actualfiles.
No target import, SDK/test/native execution or public mutation by agent.
'''
(P/'README.txt').write_text(explanation)
(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE_TEST_ONLY_UNRUN',basePacketFreezeSHA256=H(O/'freeze.json'),baseModelSHA256=H(O/name),candidateModelSHA256=H(P/name),sourceChanges=False,caseChanged='NativeCurrentBeforeDownModels.test_unknown_original_window_return_keeps_actual_task_and_fd_under_source_drain'),indent=2)+'\n')
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_TEST_ONLY_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n')
Q=T/'lifecycle-original-owner-native-current9-drain-corrected-root-preparation-20261028';Q.mkdir(mode=0o700);S=Q/'28-native-current9';S.mkdir(mode=0o700)
for n in ['root-child.py','root-supervise.py','root_stage_guard.py','source_model_bindings.py','supervisor-plan.json','run-selected.py','sdk-original-pins.json','native_file_fixture.py','native_acquisition_fixture.py','motion_reference_fixture.py','test_motion_selected_join_models.py','source2.diff']:shutil.copyfile(B/n,S/n)
shutil.copyfile(P/name,S/name)
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((B/'prior-retained-original-pins.json').read_text())
for stage,count,code in [(B,69,1),(J,92,0)]:
 report=json.loads((stage/'root-run-first/report.json').read_text());assert report['retainedFiles']==count and report['exitCode']==code and not report['remainingOwnedProcesses'] and report['allPinsEqual'] and report['retainedOriginalsUnchanged']
 root=stage/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==count
 for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
assert sum('sha256' in row for row in prior.values())==1262
(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n')
stage=json.loads((B/'source-manifest.json').read_text());changes=[]
for row in stage['sourcePaths']:
 actual=H(R/row['path'])
 if actual!=row['candidateSHA256']:
  # Snapshot actual current dependencies, never weaken or repurpose old maps.
  assert row['path'] not in stage['sourceDeltaPaths'],row['path']
  out=S/'actual-current-dependency/repo'/row['path'];out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/row['path'],out)
  changes.append(dict(path=row['path'],old=row['candidateSHA256'],current=actual));row.update(candidate=str(out),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
stage.update(stage=28,name='28-native-current9',status='PRIVATE_UNRUN_TEST_ONLY_DRAIN_CORRECTED',exactPublicMutationPlan='No source mutation. Current Source2 already public; Root runs same9 with only reviewed test correction.')
stage['orderedParentFreezes'][P.name]=H(P/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
plan=json.loads((B/'run-plan.json').read_text());plan['privateFiles'][name]=H(S/name);plan.update(status='PRIVATE_UNRUN_DRAIN_ERROR_IDENTITY_CORRECTED_CURRENT9',initialOuterSeconds=60,killAfterSeconds=5,expectedRetainedRoots=18);(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(S/'test-only.diff').write_bytes((P/'test-only.diff').read_bytes());(S/'README.txt').write_text(explanation+'Fresh Root28: same9 explicit IDs/60+kill5/18 real TD. All parent launcher/terminal guards literal. Full actual source/SDK/source-function+code maps before imports; actual shared dependency snapshots explicit. No source/registry edits.\n')
(S/'clone-provenance.json').write_text(json.dumps(dict(parentFreezeSHA256=H(B/'freeze.json'),testOverlayFreezeSHA256=H(P/'freeze.json'),sourceModelModuleSHA256=H(S/name),priorActualFiles=1262,actualDependencyChanges=changes,executed=False,publicEdits=False,initialSeconds=60,killAfterSeconds=5),indent=2)+'\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n')
(Q/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(Q)):H(p) for p in sorted(Q.rglob('*')) if p.is_file()}),indent=2)+'\n')
print(json.dumps(dict(testOverlay=str(P),testOverlayFreeze=H(P/'freeze.json'),model=H(P/name),rootStage=str(S),stageFreeze=H(S/'freeze.json'),parentFreeze=H(Q/'freeze.json'),priorActualFiles=1262,actualDependencyChanges=changes),indent=2))
