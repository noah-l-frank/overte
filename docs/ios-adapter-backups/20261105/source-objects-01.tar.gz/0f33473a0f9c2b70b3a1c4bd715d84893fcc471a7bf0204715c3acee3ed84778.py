from pathlib import Path
import ast,hashlib,json,shutil
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-retained-webdriver5-root-preparation-20261029/53-retained-webdriver5';QUAL=T/'lifecycle-original-owner-selected-motion-reader4-error-type-root-preparation-20261029/52-selected-motion-reader4';PACK=T/'lifecycle-original-owner-resource-scoped-cleanup-proposal-20261029';P=T/'lifecycle-original-owner-resource-scoped-cleanup15-root-preparation-20261029';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert not (B/'root-run-first').exists()
for rel,d in json.loads((PACK/'freeze.json').read_text())['files'].items():assert H(PACK/rel)==d
P.mkdir(mode=0o700);S=P/'54-resource-scoped-cleanup15';S.mkdir(mode=0o700)
for rel,d in json.loads((B/'freeze.json').read_text())['files'].items():
 assert H(B/rel)==d;out=S/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/rel,out)
for name in ['test_resource_scoped_cleanup_models.py','test_retained_webdriver_cleanup_models.py','test_resource_scoped_cleanup_routes.mjs','test_native_passive_carrier_models.py','test_native_passive_scope_models.py','test_native_motion_existing_rpc_models.py','test_native_motion_worker_scope_models.py','test_motion_selected_join_models.py','motion_reference_fixture.py','native_acquisition_fixture.py','native_file_fixture.py']:shutil.copyfile(PACK/name,S/name)
manifest=json.loads((PACK/'manifest.json').read_text());stage=json.loads((S/'source-manifest.json').read_text());own={row['path']:row for row in manifest['files']+manifest['ownRegistry']};found=set();changes=[]
for row in stage['sourcePaths']:
 rel=row['path'];actual=H(R/rel)
 if rel in own:row.update(candidate=own[rel]['candidate'],candidateSHA256=own[rel]['candidateSHA256'],observedPublicSHA256=actual,changesCurrentPublic=actual!=own[rel]['candidateSHA256']);found.add(rel);continue
 if actual!=row['candidateSHA256']:
  out=S/'actual-current-dependency/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(out),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
for rel in set(own)-found:
 row=own[rel];stage['sourcePaths'].append(dict(path=rel,candidate=row['candidate'],candidateSHA256=row['candidateSHA256'],observedPublicSHA256=H(R/rel),changesCurrentPublic=True))
stage.update(stage=54,name=S.name,status='PRIVATE_UNRUN_SCOPED_CLEANUP_PY12_NODE3',caseCount=15,pythonCaseCount=12,nodeCaseCount=3,initialTimeoutSeconds=90,sourceDeltaPaths=[row['path'] for row in manifest['files']],exactPublicMutationPlan='Root ONLY reviewedSource3+own2 Touch3/RetainedProfile1; preserve every foreign key/source. Original53 remainsUNRUN.')
stage['orderedParentFreezes'][PACK.name]=H(PACK/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
plan=json.loads((S/'run-plan.json').read_text());native_plan=json.loads((QUAL/'run-plan.json').read_text());spec=json.loads((PACK/'test-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_SCOPED_CLEANUP15',cases=spec['pythonCases'],caseCount=12,totalCaseCount=15,expectedRetainedRoots=12,initialOuterSeconds=90,nodeEntry='test_resource_scoped_cleanup_routes.mjs',nodeCaseCount=3,nodeInnerSeconds=15)
for key in ('mkdtempAliases','retainedTemporaryDirectoryAliases','retainInstalledFixture'):plan[key]=native_plan[key]
plan['modelMaps']['LIFECYCLE_SCOPED_CLEANUP_NODE_MAP']={'hostops':'tests/device/ios/appium_wda_host_ops.js'}
for name in list(plan['privateFiles']):
 if (S/name).is_file():plan['privateFiles'][name]=H(S/name)
for name in ['test_resource_scoped_cleanup_models.py','test_retained_webdriver_cleanup_models.py','test_resource_scoped_cleanup_routes.mjs']:plan['privateFiles'][name]=H(S/name)
contracts=json.loads(Path(own['tests/device/contract-versions.json']['candidate']).read_text())['contracts']
for name in ['ios-original-keeper-touch','original-keeper-retained-touch-profile']:plan['registryRequirements'][name]=contracts[name]
plan['requiredPublicDependencies']=list(dict.fromkeys(plan['requiredPublicDependencies']+list(own)))
entry=S/'run-selected.py';text=entry.read_text();old='        return 0 if result.wasSuccessful() else 1';new="""        if not result.wasSuccessful():return 1
        if plan.get('nodeEntry'):
            import subprocess
            command=['timeout','--signal=TERM','--kill-after=5s',str(plan['nodeInnerSeconds'])+'s','node','--test','--test-concurrency=1',str(HERE/plan['nodeEntry'])]
            child=subprocess.Popen(command,cwd=repo)
            status=child.wait()
            if status!=0:return status
        return 0""";assert old in text;text=text.replace(old,new);entry.write_text(text)
plan['privateFiles']['run-selected.py']=H(entry);(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n');settings=json.loads((S/'supervisor-plan.json').read_text());settings['initialSeconds']=90;(S/'supervisor-plan.json').write_text(json.dumps(settings,indent=2)+'\n');shutil.copyfile(PACK/'source3.diff',S/'source3-scoped-cleanup.diff');shutil.copyfile(PACK/'registry-own2.diff',S/'registry-own2.diff')
(S/'clone-provenance-scoped15.json').write_text(json.dumps(dict(parent53UnrunPreserved=True,parent53Freeze=H(B/'freeze.json'),packetFreeze=H(PACK/'freeze.json'),pythonCases=12,nodeCases=3,totalCases=15,initialSeconds=90,killAfterSeconds=5,nodeInnerSeconds=15,genuineRoots=12,retainedActualOriginalFiles=3086,additionalActualReports=9,totalPriorPinnedFiles=3095,actualDependencyChanges=changes,executed=False),indent=2)+'\n');(S/'README-scoped15.txt').write_text('Root54 actualReceiver6+realHTTPtransport6+actualNodebridge3=15, outer90+kill5/Node15/12realTD. Source3+own2 requireRoot PUB; actualcurrent map required before imports. Qualified52 fixture alias/realTD retention restored (53noTD settings not reused for native6). Node onlybuiltinVM/test/fs/crypto with pinned actualhostops block; noSDK imports. All real workerUp/creator/WDA/AFC/HTTPthread/server/socket cleanup unchanged and before both FD/task/thread/child/originalcensuses.3086actual oldoriginals plus9realreports=3095pins. SourceCurrent NOT cleanup prerequisite; foreignOwner/Resource check BEFORE effects.53 oldUNRUN, allfreezes/timeoutoriginals preserved. No agent imports/tests/PUB.\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(stage=str(S),stageFreeze=H(S/'freeze.json'),parentFreeze=H(P/'freeze.json'),changes=changes,entry=H(entry)),indent=2))
