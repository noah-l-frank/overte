"""A single actual audit router, with explicit filesystem/MP/closed phases.

No active=False audit bypass: after restoration the closed phase permits
reads only. Terminal output uses an already bound original own descriptor.
"""
from contextvars import ContextVar
from pathlib import Path
import os,sys,threading
from owned_write_boundary import OwnedWrites
from tablet_constructor_custody import FunctionBinding,CustodyRefusal
_CURRENT=ContextVar('tablet_mp_utility_actual_io_phase',default=None)
_ROOT=None
_CLASSES=None
_HOOK=False
RELEVANT=('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')
def install_router(root,port_class):
    global _ROOT,_CLASSES,_HOOK
    assert not _HOOK and _ROOT is None
    _ROOT=Path(root).resolve(strict=True);_CLASSES=(FilePhase,port_class)
    sys.addaudithook(route);_HOOK=True

def select(scope):
    assert _HOOK
    if scope is not None:
        assert type(scope)in _CLASSES and scope.root==_ROOT
        scope.check()
    _CURRENT.set(scope)

def route(event,args):
    process=event in('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.system','os.exec','os.kill','os.killpg','os.setsid','os.setpgid','ctypes.dlopen')or event.startswith('os.spawn')
    relevant=event in RELEVANT or event.startswith('fcntl.')or event.startswith('socket.')or process or event=='mmap.__new__'
    if not relevant:return  # BEFORE genuine frame/code reads; no recursion port.
    caller=sys._getframe(1);scope=_CURRENT.get()
    if scope is None:
        if event=='open':
            unused,mode,flags=args
            if not(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))and not(type(mode)is str and any(c in mode for c in 'wax+')):return
        raise CustodyRefusal('Closed utility phase has no mutation/process/socket capacity')
    assert type(scope)in _CLASSES and scope.root==_ROOT
    scope.audit_actual(event,args,caller)

class FilePhase:
    def __init__(self,root,protected):
        self.root=Path(root).resolve(strict=True);self.helper=OwnedWrites(root,protected)
        self.thread=threading.get_ident();self.original=dict(self.helper.original);self.active=False;self.closed=False
        self.methods=[(key,value,FunctionBinding(value))for key,value in vars(type(self)).items()if hasattr(value,'__code__')]
    def check(self):
        assert not self.closed and threading.get_ident()==self.thread
        for key,value,binding in self.methods:assert vars(type(self))[key]is value;binding.guard()
        self.helper._check()
    def resume(self):
        self.check();assert not self.active
        self.helper.install();self.active=True;select(self)
    def pause(self):
        self.check();assert self.active and _CURRENT.get()is self
        self.helper.restore();self.active=False
        # Read-only construction may proceed; all mutation aliases have been
        # restored, and this still-bound audit phase refuses unbound writes.
    def audit_actual(self,event,args,caller):
        self.check()
        assert _CURRENT.get()is self
        if event.startswith('socket.')or event=='mmap.__new__'or event in('subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.system','os.exec','os.kill','os.killpg','os.setsid','os.setpgid','ctypes.dlopen')or event.startswith('os.spawn'):
            raise CustodyRefusal('Filesystem phase cannot borrow MP/process/socket/native capacities')
        self.helper.audit(event,args,caller)
    def close(self):
        self.check();assert self.active
        self.helper.restore();self.active=False;self.helper.close();self.closed=True;select(None)
        assert all(getattr(os,key)is value for key,value in self.original.items())
        return dict(original27PortsRestored=len(self.original)==27,controlFDs=sorted(self.helper.control_fds),closedAuditPhase=True)
