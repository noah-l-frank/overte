"""PRIVATE guard-only cases, UNRUN; no actual typed graph authority."""
import importlib.util
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
from adapters.normal_ui import NativeUIError
path=Path(__file__).with_name('photos-closed-entry-proposal.py')
spec=importlib.util.spec_from_file_location('private_closed_entry',path)
proposal=importlib.util.module_from_spec(spec);sys.modules[spec.name]=proposal;spec.loader.exec_module(proposal)

class ClosedEntryGuardProposalTests(unittest.TestCase):
    def setUp(self):
        self.pins=proposal.capture_pins();self.owner=object.__new__(proposal.Owner);self.area=object.__new__(proposal.area_module.ReadArea)
        self.area.parser_module=self.pins[6]
        self.token=proposal.area_module._ACTIVE.set(self.area);self.addCleanup(lambda:proposal.area_module._ACTIVE.reset(self.token));self.callbacks=[]
    def bomb(self,*_args,**_kwargs):self.callbacks.append('called');raise AssertionError('Untrusted callback executed')
    def rejected(self):
        with self.assertRaises(NativeUIError):proposal.closed_entry(self.area,self.owner,self.pins)
        self.assertEqual([],self.callbacks)
    def test_original_closed_chain_returns_actual_function_without_calling_it(self):
        self.assertIs(proposal.Owner.original,proposal.closed_entry(self.area,self.owner,self.pins));self.assertEqual([],self.callbacks)
    def test_class_and_instance_original_or_trampolines_rejected_before_callbacks(self):
        for cls,names in ((proposal.Owner,('original','_original_uncached')),(proposal.area_module.ReadArea,('inventory_original','inventory_key','check','describe','parser_headers'))):
            instance=self.owner if cls is proposal.Owner else self.area
            for name in names:
                with self.subTest(cls=cls.__name__,name=name):
                    with patch.object(cls,name,self.bomb):self.rejected()
                    with patch.object(instance,name,self.bomb,create=True):self.rejected()
        for namespace,rows in ((self.pins[2],self.pins[5]),(self.pins[6],self.pins[7])):
            for name,*_pins in rows:
                with self.subTest(namespace=namespace.__name__,name=name):
                    with patch.object(namespace,name,self.bomb):self.rejected()
    def test_code_defaults_and_attribute_dispatch_changes_rejected(self):
        fn=proposal.Owner.original;code=fn.__code__
        try:fn.__code__=self.bomb.__func__.__code__;self.rejected()
        finally:fn.__code__=code
        try:fn.__defaults__=(None,);self.rejected()
        finally:fn.__defaults__=None
        try:fn.__kwdefaults__={'changed':True};self.rejected()
        finally:fn.__kwdefaults__=None
        with patch.object(proposal.Owner,'__getattribute__',self.bomb):self.rejected()
    def test_wrong_area_owner_context_or_pins_rejected(self):
        for area,owner,pins in ((object(),self.owner,self.pins),(self.area,object(),self.pins),(self.area,self.owner,object())):
            with self.assertRaises(NativeUIError):proposal.closed_entry(area,owner,pins)
        token=proposal.area_module._ACTIVE.set(object())
        try:self.rejected()
        finally:proposal.area_module._ACTIVE.reset(token)
