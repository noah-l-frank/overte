from pathlib import Path
import ast,hashlib,json
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');O=R/'.ios-host-tmp/audio-pcm-input-origin-profile-root-preparation2-20261028';P=R/'.ios-host-tmp/audio-normal-close-evidence-proposal-20261028';H=R/'.ios-host-tmp/audio-normal-close-evidence-root-preparation-20261028';H.mkdir(mode=0o700,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,s):(H/n).write_text(s)
def dump(n,v):write(n,json.dumps(v,indent=2,sort_keys=True)+'\n')
def virtual(rel):
 p=P/'candidate'/rel
 return p if p.is_file() else R/rel
def ids(rel,classes):
 t=ast.parse(virtual(rel).read_bytes(),filename=rel);module=rel.removeprefix('tests/device/').removesuffix('.py').replace('/','.')
 return [module+'.'+c.name+'.'+m.name for c in t.body if isinstance(c,ast.ClassDef) and c.name in classes for m in c.body if isinstance(m,ast.FunctionDef) and m.name.startswith('test_')]
legacy=ids('tests/device/ios/self_tests/test_ios_audio_pcm_lease.py',{'AudioPCMLeaseTests'});strict=ids('tests/device/ios/self_tests/test_ios_audio_pcm_input_origin_profile.py',{'RequiredInputOriginLeaseTests','RequiredInputOriginFactoryTests'})
new=ids('tests/device/ios/self_tests/test_ios_audio_normal_close_evidence.py',{'AudioNormalCloseEvidenceTests'});normalclose=[i for i in new if '.test_full_fourteen_' in i];small=[i for i in new if i not in normalclose]
legacyNormal=ids('tests/device/ios/self_tests/test_ios_audio_normal_journey.py',{'AudioNormalJourneyTests'});strictNormal=ids('tests/device/ios/self_tests/test_ios_audio_pcm_input_origin_profile.py',{'RequiredInputOriginNormalJourneyTests'})
assert (len(legacy),len(strict),len(small),len(normalclose),len(legacyNormal),len(strictNormal))==(17,8,7,1,1,1)
old=json.loads((O/'suite-plan.json').read_text());assert strict+legacy==old['suites']['components25']['caseIds'];assert legacyNormal==old['suites']['legacy1']['caseIds'] and strictNormal==old['suites']['strict1']['caseIds']
def suite(caseids,seconds,roots):return dict(caseIds=caseids,count=len(caseids),initialTimeoutSeconds=seconds,killAfterSeconds=5,expectedRetainedRootsNotProof=roots)
suites=dict(newSmall7=suite(small,180,7),normalClose1=suite(normalclose,600,1),components25=suite(strict+legacy,120,24),legacy1=suite(legacyNormal,600,1),strict1=suite(strictNormal,600,1))
allids=[i for s in suites.values() for i in s['caseIds']];assert len(allids)==len(set(allids))==35
m=json.loads((P/'manifest.json').read_text());rows=[dict(path=x['path'],expectedSha256=x['candidateSha256']) for x in m['publicPaths'] if (P/'candidate'/x['path']).is_file()];assert len(rows)==13
dump('expected-publication.json',rows)
config=json.loads((O/'source-root-final-map.json').read_text());roots=config['orderedRoots'];mods={};queue=[i.rsplit('.',2)[0] for i in allids]+['ios.self_tests.retained_host_roots','ios.self_tests.test_ios_audio_recorded_owner','ios.self_tests.test_ios_installed_adapter']
def modulefile(name):
 for root in roots:
  for tail in [name.replace('.','/')+'.py',name.replace('.','/')+'/__init__.py']:
   rel=(Path(root)/tail).as_posix()
   if virtual(rel).is_file():return rel
 return None
while queue:
 name=queue.pop()
 if name in mods:continue
 rel=modulefile(name)
 if not rel:continue
 mods[name]=dict(path=rel);t=ast.parse(virtual(rel).read_bytes())
 for n in ast.walk(t):
  if isinstance(n,ast.Import):queue.extend(x.name for x in n.names)
  elif isinstance(n,ast.ImportFrom):
   base=n.module or ''
   if n.level:
    parent=name.split('.')[:-1] if not rel.endswith('/__init__.py') else name.split('.')
    base='.'.join(parent[:len(parent)-n.level+1]+([base] if base else []))
   if base:queue.append(base);queue.extend(base+'.'+x.name for x in n.names if x.name!='*')
config['modules']=dict(sorted(mods.items()));config['resolver']='Python3.14 PathFinder._get_spec with explicit parent search locations, no target import; all module paths only until per-kind post-publication map';dump('source-root-final-map.json',config)
metadata=(O/'run_metadata.py').read_text().replace('import hashlib,json,os,stat,subprocess','import ast,hashlib,json,os,stat,subprocess')
metadata=metadata.replace("    paths.update(REPO/row['path'] for row in plan['timingEvidence'])\n",'')
start=metadata.index('def registry_original():')
metadata=metadata[:start]+'''def registry_original():
    raw=(REPO/'tests/device/contract-versions.json').read_bytes();value=json.loads(raw)
    required=load_plan()['registryRequired']
    assert all(value['contracts'].get(key)==row for key,row in required.items()),'Own PCM3 contract changed'
    validator=REPO/'tests/device/validate_contract_versions.py';tree=ast.parse(validator.read_text())
    assignments=[node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='REQUIRED' for target in node.targets)]
    assert len(assignments)==1 and ast.literal_eval(assignments[0].value)['ios-audio-pcm-lease']==3,'Own PCM required version changed'
    return dict(sha256=hashlib.sha256(raw).hexdigest(),required=required,validator=pin(validator))
'''
write('run_metadata.py',metadata)
# Only audited launcher templates; no historical logs/maps/originals copied.
kindtuple="('newSmall7','normalClose1','components25','legacy1','strict1')"
for n in ['run-selected.py','root-supervise.py']:
 s=(O/n).read_text().replace("('components25','strict1','legacy1')",kindtuple).replace('OVERTE_AUDIO_PCM_PROFILE_RUN_ROOT','OVERTE_AUDIO_NORMAL_CLOSE_RUN_ROOT').replace('PCM_PROFILE_ROOT','NORMAL_CLOSE_ROOT')
 s=s.replace('Audio PCM profile selections','Audio normal Close selections').replace('Root current registry/Photo7/Audio2 changed','Root current registry/foreign Photo/World or own PCM3 changed')
 if n=='run-selected.py':
  a=s.index('    first=census();second=census();');s=s[:a]+'''    remaining_before=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
'''+s[a:]
  s=s.replace('originalCensusesEqual=True,remainingNewThreads=remaining','originalCensusesEqual=True,remainingNewThreadsBeforeCensuses=remaining_before,remainingNewThreads=remaining')
  s=s.replace("assert not remaining,'New fixture/worker/listener thread remains live'","assert not remaining_before and not remaining,'New fixture/worker/listener thread remains live around censuses'")
 write(n,s)
write('prepare-actual-map.py',(O/'prepare-actual-map.py').read_text().replace('exact5+own2','exact13+own2'))
plan=dict(status='PRIVATE_FIVE_SEPARATE_EXACT7_1_25_1_1_UNRUN',suites=suites,broadSourceRoots=['tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml'],explicitExtraSourcePins=['CMakeLists.txt','tests/device/contract-versions.json','tests/device/validate_contract_versions.py'],explicitMainPin='interface/src/main.cpp',sourceRootMapSha256=sha(H/'source-root-final-map.json'),expectedPublicationCount=13,expectedPublicationSha256=sha(H/'expected-publication.json'),registryRequired={'ios-audio-pcm-lease':{'current':3,'reads':[1,2,3]}},frozenPackets=[dict(path=str(P.relative_to(R)),freezeSha256=sha(P/'freeze.json'))],unchangedGuard=dict(path='tests/device/ios/adapters/audio_api_clock.py',sha256=json.loads((P/'dependency-pins.json').read_text())['tests/device/ios/adapters/audio_api_clock.py']),timingEvidence=[],sourceGate='Actual complete broad source membership/9stat+SHA and own/foreign registry/validator byte pins are captured by Root per-kind AFTER exact13 candidates+own2 registry hunk publication; no actual source hashes or old ready maps are supplied by this preparation.',retention=dict(aliases=['ios.self_tests.test_ios_audio_recorded_owner.tempfile','ios.self_tests.test_ios_installed_adapter.tempfile'],mechanism='Existing real TemporaryDirectory + retain_owned_root before fixture cleanup binding; local aliases restored, no global mutation. Existing fixture root0700 retained inside fresh scope. Native-model file directory is a child, not another TemporaryDirectory.'),entrypointAudit='All35 exact methods and helpers were read. components25=AST exact8 existing strict components+17 existing PCM methods; imported TestCases excluded from explicit ID loading. newSmall7=seven new cheap methods, normalClose1=the new actual14 composition only, legacy1 and strict1 are their existing original normal14 methods separately. Selected Model/AudioBackgroundDomain/normal Journey/Source codecs do not launch Node/compiler/configure/build/native/device or listeners. Actual private files/CAS/owner locks/original decoders run only after Root grant. Installed fixture HTTP boundary is mocked; nominal serverUrl is not contacted. No setUpClass or discovery.',budgetBeforeFirst='Root fixed BEFORE first executions:7 at180+5;1 normalClose at600+5;25 regression components at120+5;legacy normal1 and strict normal1 each600+5. Existing API25/native1.5/file5 and original clocks remain unchanged.',coldReopenScope='Lost-return Close retry constructs a fresh mode3 lease from the durable release-issued journal through actual runtime callback/factory; source observers are fresh per factory. Parent/runtime/process remain the fixture instance. No fresh complete parent/runtime/process cold-restart test is claimed; no extra test added.',registryApplication='Root applies only own ios-audio-pcm-lease 2->3 hunks in JSON and REQUIRED. Test publication accepts no whole registry candidate; foreign Photo/World keys are unconstrained before post-PUB map and then whole-byte/stat frozen throughout each run. Root must verify publication own-key diff/readback separately.',wholeQualified=False,physicalADCQualified=False,testsRun=False,targetImports=False,resolverExecuted=False,publicEdits=False)
dump('suite-plan.json',plan)
for p in H.iterdir():
 if p.suffix=='.py':ast.parse(p.read_bytes(),filename=str(p))
 if p.suffix=='.json':json.loads(p.read_bytes())
print(json.dumps(dict(preparation=str(H),uniqueCases=len(allids),suites={k:v['count'] for k,v in suites.items()},modulePaths=len(mods),actualMapsPresent=False)))
