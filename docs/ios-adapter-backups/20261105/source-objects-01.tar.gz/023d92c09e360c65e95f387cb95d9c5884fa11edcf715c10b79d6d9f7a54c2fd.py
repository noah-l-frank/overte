"""Five prospective genuine-source counters, NOT added to World first1.

A separate future closed utility must supply its actual approved plan/origin
reader; these bodies never construct fake modules/specs/frames or source proof.
"""
import json,sys,unittest
from host_function_timing import HostFunctionTimings
_CONTEXT=None

def configure(context):
    global _CONTEXT
    assert _CONTEXT is None and set(context)=={'plan','origins','pin'}
    assert context['origins'].plan is context['plan']
    _CONTEXT=context

def _leaf():return sum(range(100))
def _outer():return _leaf()+_leaf()
def _raises(error):raise error
def _generator():yield 1
def _alternate():return 7

class HostFunctionTimingTests(unittest.TestCase):
    def recorder(self,names):
        assert _CONTEXT is not None
        actual=sys.modules[__name__];context=_CONTEXT
        recorder=HostFunctionTimings(((__name__,None,tuple(names)),))
        recorder.bind_module(actual,context['plan']['modules'][__name__],context['origins'].python_executions[__name__],context['pin'])
        return recorder
    def test_real_nested_selected_calls_have_inclusive_and_selected_exclusive_counts(self):
        recorder=self.recorder(('_leaf','_outer'));recorder.install()
        try:self.assertEqual(sum(range(100))*2,_outer());row=recorder.snapshot()
        finally:restored=recorder.restore()
        self.assertTrue(restored['actualSeparateToolRestored']);self.assertTrue(row['timingComplete'])
        rows={r['label'].rsplit('.',1)[-1]:r for r in row['aggregate']}
        self.assertEqual((2,1),(rows['_leaf']['calls'],rows['_outer']['calls']))
        self.assertEqual(rows['_outer']['inclusiveWallNs'],rows['_outer']['exclusiveAmongSelectedWallNs']+rows['_leaf']['inclusiveWallNs'])
        self.assertEqual(rows['_outer']['inclusiveThreadCpuNs'],rows['_outer']['exclusiveAmongSelectedThreadCpuNs']+rows['_leaf']['inclusiveThreadCpuNs'])
        json.dumps(row)
    def test_genuine_unwind_keeps_original_exception_and_leaves_no_live_frame(self):
        recorder=self.recorder(('_raises',));recorder.install();error=LookupError('actual original toy error')
        try:
            with self.assertRaises(LookupError)as actual:_raises(error)
            self.assertIs(actual.exception,error);row=recorder.snapshot()
        finally:recorder.restore();error.__traceback__=None
        self.assertEqual(1,row['aggregate'][0]['unwinds']);self.assertEqual(0,row['unfinishedSelectedCalls'])
        self.assertFalse(any(type(value).__name__=='frame'for value in recorder.stack));json.dumps(row)
    def test_genuine_generator_is_explicitly_excluded_without_resume_or_yield_claim(self):
        recorder=self.recorder(('_generator',));recorder.install()
        try:self.assertEqual([1],list(_generator()));row=recorder.snapshot()
        finally:recorder.restore()
        self.assertEqual(0,row['boundFunctions']);self.assertEqual(1,len(row['excludedFunctions']));self.assertEqual([],row['aggregate'])
        self.assertEqual('generator-or-coroutine-excluded',row['excludedFunctions'][0]['reason'])
    def test_changed_actual_function_code_only_invalidates_diagnostic_and_original_body_result_survives(self):
        recorder=self.recorder(('_leaf',));recorder.install();old=_leaf.__code__
        try:
            _leaf.__code__=_alternate.__code__
            self.assertEqual(7,_leaf());row=recorder.snapshot()
        finally:_leaf.__code__=old;restored=recorder.restore()
        self.assertFalse(row['timingComplete']);self.assertGreater(row['faultCount'],0);self.assertTrue(restored['actualSeparateToolRestored'])
    def test_wrong_existing_source_origin_refuses_before_own_tool_birth(self):
        recorder=HostFunctionTimings(((__name__,None,('_leaf',)),));context=_CONTEXT
        with self.assertRaises(AssertionError):
            recorder.bind_module(sys.modules[__name__],context['plan']['modules']['host_function_timing'],context['origins'].python_executions[__name__],context['pin'])
        self.assertIsNone(recorder.tool)

    def test_genuine_acquisition_c_return_failure_never_claims_unacquired_or_restored(self):
        from host_function_timing import TOOL_NAME
        recorder=self.recorder(('_leaf',));api=sys.monitoring;prior_profile=sys.getprofile();actual=[]
        use=api.use_tool_id;install=type(recorder).install
        error=RuntimeError('Original World timing acquisition C-return lost')
        def profile(frame,event,port):
            if event=='c_return'and port is use and frame.f_code is install.__code__ and frame.f_globals is install.__globals__ and frame.f_locals.get('self')is recorder and not actual:
                actual.append(frame.f_locals['tool']);raise error
        try:
            sys.setprofile(profile)
            with self.assertRaises(RuntimeError)as raised:recorder.install()
            sys.setprofile(prior_profile);self.assertIs(raised.exception,error);self.assertEqual(1,len(actual))
            tool=actual[0];self.assertIs(api.get_tool(tool),TOOL_NAME);self.assertIsNone(recorder.tool)
            restored=recorder.restore();row=recorder.snapshot()
            self.assertTrue(restored['acquisitionOutcomeUnknown']);self.assertIsNone(restored['actualToolAcquired'])
            self.assertFalse(restored['actualSeparateToolRestored']or restored['actualToolFreed']or row['timingComplete'])
            with self.assertRaises(AssertionError):recorder.tool_bound()
        finally:
            sys.setprofile(prior_profile)
            if recorder.tool is not None:recorder.restore()
            if actual:
                # This counter observed the actual original acquisition return;
                # that observation is never assigned to the recorder's ledger.
                self.assertIs(api.get_tool(actual[0]),TOOL_NAME);api.free_tool_id(actual[0])
        self.assertFalse(recorder.restore()['actualSeparateToolRestored'])
        with self.assertRaises(AssertionError):recorder.install()

    def test_genuine_callback_c_return_failure_keeps_previous_callback_unknown(self):
        from host_function_timing import TOOL_NAME
        recorder=self.recorder(('_leaf',));api=sys.monitoring;prior_profile=sys.getprofile();actual=[]
        tool=next(n for n in(3,2,1,0,4,5)if api.get_tool(n)is None and api.get_events(n)==0)
        seed='actual-world-counter-prior-'+str(id(recorder));events=(api.events.PY_START,api.events.PY_RETURN,api.events.PY_UNWIND)
        old_callbacks={};old_local={code:api.get_local_events(tool,code)for code in recorder.bindings};old_global=api.get_events(tool)
        def previous_callback(*_args):return None
        api.use_tool_id(tool,seed)
        try:
            for event in events:old_callbacks[event]=api.register_callback(tool,event,previous_callback)
        finally:api.free_tool_id(tool)
        register=api.register_callback;install=type(recorder).install;error=RuntimeError('Original World callback C-return lost')
        def profile(frame,event,port):
            if event=='c_return'and port is register and frame.f_code is install.__code__ and frame.f_globals is install.__globals__ and frame.f_locals.get('self')is recorder and frame.f_locals.get('event')==api.events.PY_RETURN and not actual:
                actual.append(frame.f_locals['tool']);raise error
        try:
            sys.setprofile(profile)
            with self.assertRaises(RuntimeError)as raised:recorder.install()
            sys.setprofile(prior_profile);self.assertIs(raised.exception,error);self.assertEqual([tool],actual)
            self.assertIs(api.get_tool(tool),TOOL_NAME)
            restored=recorder.restore();row=recorder.snapshot()
            self.assertTrue(restored['callbackMutationOutcomeUnknown']);self.assertEqual([api.events.PY_RETURN],restored['unknownCallbackEvents'])
            self.assertFalse(restored['actualSeparateToolRestored']or row['timingComplete']);self.assertTrue(restored['actualToolFreed'])
            self.assertIsNone(api.get_tool(tool));api.use_tool_id(tool,seed)
            changed=api.register_callback(tool,api.events.PY_RETURN,previous_callback)
            self.assertIs(changed,recorder.callback_objects[api.events.PY_RETURN])
        finally:
            sys.setprofile(prior_profile)
            if recorder.tool is not None:recorder.restore()
            if api.get_tool(tool)is None:api.use_tool_id(tool,seed)
            self.assertIs(api.get_tool(tool),seed);api.set_events(tool,old_global)
            for code,mask in old_local.items():api.set_local_events(tool,code,mask)
            for event,callback in old_callbacks.items():api.register_callback(tool,event,callback)
            api.free_tool_id(tool)
        self.assertFalse(recorder.restore()['actualSeparateToolRestored'])

    def test_original_free_error_is_not_forgotten_after_later_successful_release(self):
        recorder=self.recorder(('_leaf',));recorder.install();api=sys.monitoring;prior_profile=sys.getprofile();actual=[]
        free=api.free_tool_id;restore=type(recorder).restore;error=RuntimeError('Original World diagnostic free refused')
        release_codes=[code for code in restore.__code__.co_consts if type(code)is type(restore.__code__)and code.co_name=='release_acquired']
        self.assertEqual(1,len(release_codes));release_code=release_codes[0]
        def profile(frame,event,port):
            # restore's real release_acquired closure calls the original C port.
            if event=='c_call'and port is free and frame.f_code is release_code and frame.f_globals is restore.__globals__ and frame.f_locals.get('self')is recorder and not actual:
                actual.append(True);raise error
        try:
            sys.setprofile(profile);first=recorder.restore();sys.setprofile(prior_profile)
            self.assertEqual([True],actual);self.assertFalse(first['actualSeparateToolRestored'])
            self.assertGreaterEqual(first['restorationFailureCount'],1);self.assertIsNotNone(recorder.tool)
            second=recorder.restore();self.assertIsNone(recorder.tool)
            self.assertTrue(second['actualToolFreed']);self.assertFalse(second['actualSeparateToolRestored'])
            self.assertGreaterEqual(second['restorationFailureCount'],first['restorationFailureCount'])
            self.assertFalse(recorder.snapshot()['timingComplete'])
        finally:
            sys.setprofile(prior_profile)
            if recorder.tool is not None:recorder.restore()
