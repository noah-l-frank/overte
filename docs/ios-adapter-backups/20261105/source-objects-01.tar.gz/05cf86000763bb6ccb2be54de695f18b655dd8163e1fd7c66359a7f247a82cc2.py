"""Real transport/postguard work bounds; no effect or end-success facts."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import unittest
from adapters.normal_ui import NativeUIError
from adapters.operation_transport_guard import check as before_transport
from ios.adapters.tablet_web_api_entry import installed_entry,scope


class TabletPublicAPIBudgetTests(unittest.TestCase):
    def test_prospective_v9_keeps_readable_old_tablet_configs_closed_without_transport(self):
        import os
        from copy import deepcopy
        from unittest.mock import patch
        from feature_journeys.witness import Client
        from ios.adapters import feature_configuration as config
        from ios.self_tests.test_ios_whole_configuration import WholeConfigurationTests
        fixture=WholeConfigurationTests();fixture.setUp();self.addCleanup(fixture.doCleanups)
        value=dict(fixture.empty,iosFeatureAdapterVersion=9,areas=['tablet-web'],tabletWeb=fixture.settings['tablet-web'],
            emoteCoordinatorVersion=None,worldWebCoordinatorVersion=None,tabletWebCoordinatorVersion=1)
        with patch.object(Client,'request',side_effect=AssertionError('Config cannot acquire native/fixture facts')),\
             patch.dict(os.environ,OVERTE_IOS_FEATURE_ADAPTER_CONFIG=str(fixture.store.path)):
            for version in (5,6,7,8,9):
                selected=deepcopy(value);selected['iosFeatureAdapterVersion']=version
                if version<9:selected.pop('tabletWebCoordinatorVersion')
                if version<7:selected.pop('worldWebCoordinatorVersion')
                if version<6:selected.pop('emoteCoordinatorVersion')
                fixture.store.write(selected,fixture.store.read());before=fixture.store.path.read_bytes();inode=fixture.store.path.stat().st_ino
                self.assertEqual(selected,config.configuration())
                if version<9:
                    with self.assertRaises(NativeUIError):config.capabilities(fixture.target)
                else:self.assertEqual({'feature.tablet-web.'+kind for kind in ('act','observe','cleanup','terminal')},set(config.capabilities(fixture.target)))
                self.assertEqual(before,fixture.store.path.read_bytes());self.assertEqual(inode,fixture.store.path.stat().st_ino)
            for coordinator in (True,0,2,None):
                fixture.store.write(dict(value,tabletWebCoordinatorVersion=coordinator),fixture.store.read())
                with self.assertRaises(NativeUIError):config.capabilities(fixture.target)

    def test_late_final_original_work_cannot_return_a_result_after_the_same_entry_deadline(self):
        clock=[0.];sent=[]
        def operation(_adapter,_selector,_operation,_values):
            before_transport();sent.append('original-passive-operation')
            clock[0]=59.;before_transport()
            # Original final verifier runs in the SAME API after the operation.
            clock[0]=60.;return dict(declaredMetadataOnly=True)
        with self.assertRaises(NativeUIError):installed_entry(operation,monotonic=lambda:clock[0])(object(),'owned','feature.tablet-web.terminal',{})
        self.assertEqual(['original-passive-operation'],sent)
    def test_nested_work_never_renews_deadline_and_failed_guard_blocks_later_transport(self):
        clock=[0.];attempted=[]
        with self.assertRaises(NativeUIError):
            with scope(lambda:clock[0]):
                clock[0]=59.
                with self.assertRaises(NativeUIError):
                    with scope(lambda:0.):clock[0]=60.;before_transport()
                clock[0]=59.
                with self.assertRaises(NativeUIError):before_transport();attempted.append('forbidden-send')
        self.assertEqual([],attempted)
