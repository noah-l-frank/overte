"""One-shot literal-policy costs on actual immutable historical164 originals."""
from contextlib import ExitStack
import json
from pathlib import Path
import time
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import readonly,scope
from adapters.original_frame_store import OriginalFrameStore
from adapters.original_marker_scope import OriginalMarkerScope
from adapters.owned_vulkan_world_frame import VulkanWorldFrameOwner
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.avatar_samples import IOSAvatarSamples
from ios.adapters.avatar_held_samples import history as sample_history
from ios.adapters.avatar_marker_history import archive as marker_archive
from ios.adapters.avatar_record_cache import AvatarRecordCache
from ios.adapters import avatar_images
from ios.adapters.avatar_sample_return_literal import AvatarSampleReturnLiteral
from ios.adapters.avatar_sample_return import AvatarSampleReturnProof
from selected_code_timing import SelectedCodeTiming
from run_metadata import HERE,REPO,originals,save


class LiteralPolicyHistorical164Tests(unittest.TestCase):
    def test_actual_typed_marker_policy_costs_and_same_function_code_change_source4_are_readonly(self):
        plan=json.loads((HERE/'suite-plan.json').read_text());failure=plan['requiredHistoricalFailure']
        root=Path(failure['runRoot'])/'temporary';expected=json.loads((REPO/failure['secondCensus']).read_text())
        before=originals(root);self.assertEqual(expected,before)
        actor=root/'tmplo0577b1';lock=ScriptSourceLock(actor/'script-feature-sources.lock')
        self.assertIn(str(lock.path.relative_to(root)),before)
        import os
        output=Path(os.environ['OVERTE_AVATAR_ROLE_SOURCE_RUN'])
        result=dict(diagnosticOnly=True,nativeQualified=False,normalQualified=False,wholeQualified=False)
        timer=SelectedCodeTiming(dict(constructor=AvatarSampleReturnLiteral.__init__.__code__,
            signature=AvatarSampleReturnLiteral.signature.__code__,literal=AvatarSampleReturnLiteral.literal.__code__)).start()
        try:
            with lock.held(),readonly():
                samplepath=actor/'ios-avatar-actor-samples.json';sample=PrivateFeatureState(samplepath).read()
                archived=sample_history(sample,store=PrivateFeatureState(samplepath),root=actor,binding=sample['binding'],
                    run=sample['runId'],role='actor',policy=sample['imagePolicy'],lock=lock)
                # Real PNG archive above initializes the actual existing PNG
                # dispatcher before the closed interpretation policy is born.
                with scope(fresh=True):
                    marker=marker_archive(archived.state['markerOwner'],root=actor,binding=sample['binding'],
                        run=sample['runId'],role='actor',lock=lock,require_ready=True)
                # This is the exact proposed handoff pure-reader root builder;
                # the retained owner remains historical and no proof/capture is
                # instantiated. A diagnostic never pretends to be current.
                roots=AvatarSampleReturnProof.reader_roots(archived,marker.components)
                started=time.monotonic_ns();literal=AvatarSampleReturnLiteral(roots);cold=time.monotonic_ns()-started
                result.update(policySupported=literal.policy is not None,unsupportedLocation=literal.unsupported,unsupportedDetails=getattr(literal,'unsupportedDetails',None),coldNanoseconds=cold,
                    policyReferences=len(literal.references),rootCount=len(roots),completeHandoffGuardBenchmarked=False,source4ExactPureReaderRoots=True)
                warm=[]
                if literal.policy is not None:
                    for _ in range(3):
                        started=time.monotonic_ns();valid=literal.literal();warm.append(time.monotonic_ns()-started);self.assertTrue(valid)
                    function=avatar_images.compose;code=function.__code__
                    def changed(*_args,**_kwargs):return None
                    try:
                        function.__code__=changed.__code__
                        self.assertFalse(literal.literal());result['sameFunctionCodeMutationRefused']=True
                    finally:function.__code__=code
                    self.assertTrue(literal.literal());result['exactOriginalCodeRestored']=True
                else:
                    result.update(sameFunctionCodeMutationRefused=False,exactOriginalCodeRestored=True)
                result['warmNanoseconds']=warm
        finally:
            timer.stop();result['selectedCodeTimings']=timer.metadata()
            after=originals(root);result['originalCensusesEqual']=before==after==expected;result['originalFiles']=164
            save(output/'literal-policy-profile.json',result)
            save(output/'literal-policy-originals-before.json',before);save(output/'literal-policy-originals-after.json',after)
            self.assertEqual(expected,after)
