"""One capture's immutable original proof; no current-frame/result cache.

The full typed frozen marker is decoded twice before native acquisition.
After image composition, exact saved record/PNG bytes and every earlier
immutable dependency must still match. Every later archive remains cold and
independent. Acquisition/native clocks and final current guards stay outside
this helper and retain their original limits.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_clock_join import digest
from adapters.native_feature_observation import need
from adapters.original_file_reads import collect
from adapters.owned_vulkan_world_frame import VulkanWorldFrameOwner
from adapters.script_feature.history import same
from ios.adapters.avatar_record_cache import AvatarRecordCache


class AvatarSampleReturnProof:
    def __init__(self,owner):
        owner.lock.assert_held();need(not owner.historical)
        self.owner,self.lock,self.root=owner,owner.lock,owner.root
        self.binding,self.run,self.role=deepcopy(owner.binding),owner.run,owner.role
        self.value=deepcopy(owner.state['markerOwner']);self.marker=None;self.paths=set();self.signatures=None
        def decode():
            return owner.Marker.archive(self.value,root=self.root,binding=self.binding,run=self.run,
                role=self.role,lock=self.lock,require_ready=True)
        with collect() as first:marker=decode()
        # Declared marker-only test models have no original file membership.
        # They keep the full existing archive path instead of gaining a lease.
        if not first:return
        signatures=AvatarRecordCache.signatures(first)
        with collect() as second:confirmed=decode()
        need(first==second and AvatarRecordCache.signatures(second)==signatures
            and same(marker.state,confirmed.state) and same(marker.frames,confirmed.frames))
        self.marker,self.paths,self.signatures=confirmed,set(second),signatures
        self.check()

    @property
    def available(self):return self.marker is not None

    def check(self):
        need(self.available and self.owner.lock is self.lock and self.owner.root==self.root
            and self.owner.run==self.run and self.owner.role==self.role and same(self.owner.binding,self.binding)
            and same(self.owner.state['markerOwner'],self.value))
        self.lock.assert_held();need(AvatarRecordCache.signatures(self.paths)==self.signatures)

    @staticmethod
    def dependencies(paths):
        need(type(paths) is set)
        return {} if not paths else AvatarRecordCache.signatures(paths)

    def verify_saved(self,row,record_digest,raw,dependencies):
        """Exact same composition inputs only; never supply a new observation."""
        self.check();owner=self.owner
        record=owner.read_record(row,historical=True)
        need(record['status']=='observed' and digest(record)==record_digest and record['markerSha256']==digest(self.value))
        # Reopen the exact persisted original row and repeat prior-prefix and
        # immutable marker/world admission. Nothing comes from a new SDK read.
        frame=record['partial']
        owner.follow(frame,phase_before=frame['phaseBefore'],before_index=record['index'])
        self.marker.bind_image_world(frame['worldBefore']);self.marker.bind_image_world(frame['worldAfter'])
        original=VulkanWorldFrameOwner.archive_original(record['owner'],self.root,self.binding,self.run,self.role,0,record['requestId'],self.lock)
        need(type(raw) is bytes and original==raw)
        # Basis images/earlier record inputs were fully decoded for the one
        # composition. Their actual file identities/modes/lengths/timestamps
        # must survive all persistence, so no duplicate PNG interpretation is
        # needed for these identical immutable inputs.
        need(type(dependencies) is dict and self.dependencies(set(dependencies))==dependencies)
        self.check()
