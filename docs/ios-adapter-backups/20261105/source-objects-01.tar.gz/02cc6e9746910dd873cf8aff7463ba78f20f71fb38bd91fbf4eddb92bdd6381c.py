"""Original owned numeric stream listeners only; no Moving/Node code.

The host-reader seal and OwnedLoopbacks class are exact frozen AST/bytes slices
of reviewed controller3 5e872a97. They supply no product or native facts.
"""
from pathlib import Path
import hashlib,http.server,ipaddress,marshal,os,socket,socketserver,stat,sys

def _original_host_reader_seal():
    # Captured before target imports, independently of any inspected frame.
    fqdn=socket.getfqdn;reverse=socket.gethostbyaddr;bind=http.server.HTTPServer.server_bind
    tcp_bind=socketserver.TCPServer.server_bind;http_class=http.server.HTTPServer
    held=(fqdn,fqdn.__code__,fqdn.__globals__,reverse,bind,bind.__code__,bind.__globals__,
        tcp_bind,tcp_bind.__code__,tcp_bind.__globals__,http_class)
    def fresh():
        assert socket.getfqdn is fqdn and fqdn.__code__ is held[1]and fqdn.__globals__ is held[2]
        assert socket.gethostbyaddr is reverse
        assert http.server.HTTPServer is http_class and http_class.server_bind is bind
        assert bind.__code__ is held[5]and bind.__globals__ is held[6]
        assert socketserver.TCPServer.server_bind is tcp_bind and tcp_bind.__code__ is held[8]and tcp_bind.__globals__ is held[9]
        assert fqdn.__globals__['gethostbyaddr']is reverse and bind.__globals__['socket']is socket
        return held
    return held,fresh


_ORIGINAL_HOST_READERS,_HOST_READERS_FRESH=_original_host_reader_seal()


class OwnedLoopbacks:
    def __init__(self):
        self.servers=[]
        self.socket_class=socket.socket
        self.receivers=tuple((name,getattr(socket.socket,name))for name in('getsockname','getsockopt','fileno'))
        self.readers=(os.fstat,ipaddress.ip_address)
        self.host_readers=_ORIGINAL_HOST_READERS;self.host_readers_fresh=_HOST_READERS_FRESH
        assert self.host_readers_fresh()is self.host_readers
        self.host_reader_codes=tuple(dict(receiver=name,codeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest())
            for name,code in(('socket.getfqdn',self.host_readers[1]),('HTTPServer.server_bind',self.host_readers[5]),
                ('TCPServer.server_bind',self.host_readers[8])))
        self.resolver_reads=[]

    def check(self):
        assert socket.socket is self.socket_class and self.readers==(os.fstat,ipaddress.ip_address)
        assert self.host_readers_fresh is _HOST_READERS_FRESH and self.host_readers is _ORIGINAL_HOST_READERS
        assert self.host_readers_fresh()is self.host_readers
        assert all(getattr(self.socket_class,name)is function for name,function in self.receivers)

    def endpoint(self,family,address):
        assert type(address)is tuple
        if family==socket.AF_INET:
            assert len(address)==2 and address[0]=='127.0.0.1'
            host,port=address;tail=()
        else:
            assert family==socket.AF_INET6 and len(address)in(2,4)and address[0]=='::1'
            host,port=address[:2];tail=(0,0)if len(address)==2 else address[2:]
            assert len(tail)==2 and all(type(value)is int and value>=0 for value in tail)
        assert type(port)is int and 0<=port<=65535
        parsed=ipaddress.ip_address(host)
        assert parsed.is_loopback and parsed.version==(4 if family==socket.AF_INET else 6)
        return(host,port,*tail)

    def signature(self,owner):
        self.check();assert type(owner)is self.socket_class
        family=owner.family;assert family in(socket.AF_INET,socket.AF_INET6)
        assert self.socket_class.getsockopt(owner,socket.SOL_SOCKET,socket.SO_TYPE)==socket.SOCK_STREAM
        descriptor=self.socket_class.fileno(owner);assert descriptor>=0
        info=os.fstat(descriptor);assert stat.S_ISSOCK(info.st_mode)
        return(family,descriptor,info.st_dev,info.st_ino,info.st_mode)

    def current_servers(self):
        self.check();found=[]
        for owner,signature,requested in self.servers:
            if self.socket_class.fileno(owner)<0:continue
            assert self.signature(owner)==signature
            actual=self.endpoint(signature[0],self.socket_class.getsockname(owner))
            assert actual[0]==requested[0]and actual[2:]==requested[2:]and actual[1]>0
            found.append((signature[0],actual))
        return found

    def original_host_reverse(self,args,frame):
        self.check();held=self.host_readers
        assert type(args)is tuple and len(args)==1 and type(args[0])is str and args[0]in('127.0.0.1','::1')
        assert frame is not None and frame.f_code is held[1]and frame.f_globals is held[2]
        assert frame.f_locals.get('name')==args[0]
        parent=frame.f_back
        assert parent is not None and parent.f_code is held[5]and parent.f_globals is held[6]
        server=parent.f_locals['self']
        assert held[10]in type(server).__mro__ and type(server).server_bind is held[4]
        owner=server.socket;signature=self.signature(owner)
        own=next((row for row in self.servers if row[0]is owner),None);assert own is not None and own[1]==signature
        actual=self.endpoint(signature[0],self.socket_class.getsockname(owner))
        assert(signature[0],actual)in self.current_servers()
        assert self.endpoint(signature[0],server.server_address)==actual
        assert parent.f_locals['host']==args[0]==actual[0]and parent.f_locals['port']==actual[1]
        self.resolver_reads.append(dict(profile='scoped-original-host-resolver-read-v1',numericHost=args[0],
            family=int(signature[0]),actualBoundEndpoint=list(actual),socketDevice=signature[2],socketInode=signature[3],
            receiver='original-socket.getfqdn-to-original-HTTPServer.server_bind',nativeFact=False,
            noExternalNSSorDNSClaim=False))

    def audit(self,event,args,frame=None):
        if event=='socket.bind':
            owner,address=args;signature=self.signature(owner)
            endpoint=self.endpoint(signature[0],address);assert endpoint[1]==0
            assert not any(owner is old for old,unused,unused2 in self.servers)
            self.servers.append((owner,signature,endpoint))
        elif event=='socket.connect':
            owner,address=args;signature=self.signature(owner)
            endpoint=self.endpoint(signature[0],address)
            assert(signature[0],endpoint)in self.current_servers()
        elif event=='socket.getaddrinfo':
            # The actual urllib connection asks with numeric host/port; no DNS,
            # localhost alias, foreign family/scope or external resolver is admitted.
            host,port,family,kind,protocol=args
            assert type(host)is str and host in('127.0.0.1','::1')and type(port)is int
            assert family in(0,socket.AF_UNSPEC,socket.AF_INET,socket.AF_INET6)
            assert kind==socket.SOCK_STREAM and protocol in(0,socket.IPPROTO_TCP)
            expected_family=socket.AF_INET if host=='127.0.0.1'else socket.AF_INET6
            assert family in(0,socket.AF_UNSPEC,expected_family)
            assert any(actual_family==expected_family and actual[0]==host and actual[1]==port
                and actual[2:]==(()if expected_family==socket.AF_INET else(0,0))
                for actual_family,actual in self.current_servers())
        elif event=='socket.gethostbyaddr':self.original_host_reverse(args,frame)
        elif event in('socket.sendto','socket.sendmsg','socket.gethostbyname','socket.getnameinfo'):
            raise RuntimeError('No datagram or external/name resolution transport admitted')

    def finish(self):
        self.check();assert self.servers and all(self.socket_class.fileno(owner)==-1 for owner,unused,unused2 in self.servers)
        return dict(ownedServerSockets=len(self.servers),allOwnedServerSocketsClosed=True,
            scopedOriginalHostResolverRead=list(self.resolver_reads),originalHostReaderCodes=self.host_reader_codes,
            noExternalNSSorDNSClaim=False,
            originalBindEndpoints=[dict(family=int(signature[0]),address=list(endpoint))for owner,signature,endpoint in self.servers])

