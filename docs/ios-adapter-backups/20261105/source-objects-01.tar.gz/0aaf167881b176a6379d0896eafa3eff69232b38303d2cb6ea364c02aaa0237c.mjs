/* Actual source-defined proxy/bridge flow with explicit HTTP producer models.
 * No SDK module imports, WDA session/service or device execution. */
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash, randomUUID} from 'node:crypto';
import {stripTypeScriptTypes} from 'node:module';
import nodeUrl from 'node:url';
import vm from 'node:vm';
import test from 'node:test';

const mapBytes=readFileSync(process.env.LIFECYCLE_WDA_SESSION_MODEL_MAP);
assert.equal(createHash('sha256').update(mapBytes).digest('hex'),process.env.LIFECYCLE_WDA_SESSION_MODEL_MAP_SHA256);
const map=JSON.parse(mapBytes);
function pinned(role) {
  const bytes=readFileSync(map[role].path);
  assert.equal(createHash('sha256').update(bytes).digest('hex'),map[role].sha256);
  return bytes.toString('utf8');
}
const source=pinned('proxy');
const begin=source.indexOf('type OriginalDownstreamSessionSource =');
assert(begin>=0);
const body=source.slice(begin).replace('export class JWProxy','class JWProxy');
// Builtin type erasure only. No dependency import/initializer/HTTP client runs.
const code=stripTypeScriptTypes(body,{mode:'strip'});
const modelLog={debug(){},info(){},warn(){}};
const namespace={nodeUrl,MJSONWP:'MJSONWP',W3C:'W3C',
  DEFAULT_LOG:modelLog,MAX_LOG_BODY_LENGTH:1024,
  util:{hasValue:value=>value!==null&&value!==undefined,isPlainObject:value=>value!==null&&typeof value==='object',
    truncateString:value=>String(value)},logger:{markSensitive:value=>value},
  errors:{ProxyRequestError:class extends Error{}},};
const Proxy=vm.runInNewContext(code+';JWProxy',namespace,{filename:'pinned-actual-nested-proxy'});
function modelProxy() {
  // Explicit HTTP producer seam; source logic under test is the ORIGINAL
  // response/epoch/receipt/getter path. It is not real HTTP/auth qualification.
  const proxy=Object.create(Proxy.prototype);
  Object.assign(proxy,{sessionId:'appium-placeholder',_log:modelLog,protocolConverter:{},_activeRequests:[],_downstreamProtocol:null});
  proxy.getUrlForProxy=(url,method)=>method==='POST'&&url.endsWith('/session')
    ? 'http://model-wda/session' : 'http://model-wda/session/'+proxy.sessionId;
  proxy.request=async()=>({status:200,headers:{},data:{value:{sessionId:'wda-original-session'}}});
  return proxy;
}

test('initial Appium placeholder is unavailable until original POST session response',async()=>{
  const proxy=modelProxy();assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
  await proxy.proxy('/session','POST',{});
  const actual=proxy.getOriginalDownstreamSessionSource();assert.equal(actual.sessionId,'wda-original-session');
  assert.equal(Object.isFrozen(actual),true);assert.notEqual(actual.sessionId,'appium-placeholder');
});
test('same SID recreation replaces original receipt; caller field assignment cannot recreate it',async()=>{
  const proxy=modelProxy();await proxy.proxy('/session','POST',{});
  const first=proxy.getOriginalDownstreamSessionSource();await proxy.proxy('/session','POST',{});
  const second=proxy.getOriginalDownstreamSessionSource();assert.notEqual(first,second);assert.equal(first.sessionId,second.sessionId);
  proxy.sessionId='appium-placeholder';assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
});
test('observed SID A foreign A cannot revive old receipt without another original response',async()=>{
  const proxy=modelProxy();await proxy.proxy('/session','POST',{});
  const first=proxy.getOriginalDownstreamSessionSource();proxy.sessionId='foreign-wda-session';
  assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
  proxy.sessionId=first.sessionId;assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
  await proxy.proxy('/session','POST',{});
  assert.notEqual(proxy.getOriginalDownstreamSessionSource(),first);
});
test('cancel entry revokes while original response pending; late response cannot remint',async()=>{
  const proxy=modelProxy();let complete;
  proxy.request=()=>new Promise(resolve=>{complete=resolve;});
  const creating=proxy.proxy('/session','POST',{});proxy.cancelActiveRequests();
  complete({status:200,headers:{},data:{value:{sessionId:'wda-original-session'}}});await creating;
  assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
});
test('delete entry revokes before its original return, without a new session request',async()=>{
  const proxy=modelProxy();await proxy.proxy('/session','POST',{});let complete;
  proxy.request=()=>new Promise(resolve=>{complete=resolve;});
  const deleting=proxy.proxy('/session/wda-original-session','DELETE');
  assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
  complete({status:200,headers:{},data:{value:null}});await deleting;
  assert.equal(proxy.getOriginalDownstreamSessionSource(),null);
});
test('actual bridge borrows original WDA proxy receipt; changed owner refuses new input but permits release',async()=>{
  const helper=pinned('hostops');const first=helper.indexOf('const originalKeeperRoutes =');
  const last=helper.indexOf('\nexport function isStrictHostUtilityMode',first);assert(first>=0&&last>first);
  const bridgeCode=helper.slice(first,last);
  const stringifyAt=helper.indexOf('function stringifyLaunchEnvironment');
  const stringifyEnd=helper.indexOf('\n\nfunction createSimulatorHostOps',stringifyAt);assert(stringifyAt>=0&&stringifyEnd>stringifyAt);
  const launch=vm.runInNewContext(bridgeCode+'\n'+helper.slice(stringifyAt,stringifyEnd)+'\ntryOriginalKeeperLaunch',
    {WebDriverProxy:Proxy,randomUUID,WDA_PORT:8100},{filename:'pinned-actual-wda-host-route'});
  const proxy=modelProxy(),wda={jwproxy:proxy};const driver={sessionId:'original-appium-session',opts:{udid:'model-target',bundleId:'org.example.overte'},wda};
  const operations=[];const instance='a'.repeat(32);
  const remote={async originalKeeperOperation(_target,request){
    operations.push(request);
    return {originalKeeperOperationVersion:1,ownerInstance:instance,result:request.operation==='inspect'
      ? {creatorMode:'userspace-keeper',nativeTouchSupport:false} : {modeled:true}};
  }};
  await launch(driver,remote,{udid:'model-target',bundleId:'org.example.wda',env:{USE_PORT:'8100',WDA_PRODUCT_BUNDLE_IDENTIFIER:'org.example.wda'}});
  const bridge=driver[Symbol.for('overte.originalKeeperRoute.v1')];
  await assert.rejects(bridge.request('touch-begin',{}));assert.equal(operations.some(row=>row.operation==='wda-bind'),false);
  await proxy.proxy('/session','POST',{});
  await bridge.request('touch-begin',{});
  assert.equal(operations.find(row=>row.operation==='wda-bind').args.wdaSessionId,'wda-original-session');
  assert.equal(operations.filter(row=>row.operation==='touch-begin').length,1);
  driver.wda={jwproxy:modelProxy()};await assert.rejects(bridge.request('touch-begin',{}));
  assert.equal(operations.filter(row=>row.operation==='touch-begin').length,1);
  driver.wda=wda;await assert.rejects(bridge.request('touch-begin',{}));
  assert.equal(operations.filter(row=>row.operation==='touch-begin').length,1);
  await bridge.request('touch-release',{});assert.equal(operations.at(-1).operation,'touch-release');
});
