"""Original parent/roots/uncertainty controls, no completed provider fixture.

All SDK/native/GPU events retain the preselected original TerminalDomain model
scope. These prospective cases may qualify host logic only if actually run.
"""
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import unittest

from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.avatar_keeper_terminal import AvatarKeeperTerminal, KeeperOriginalView
from ios.adapters.avatar_terminal import AvatarTerminal
from ios.adapters.original_keeper_process_end import filename as keeper_filename
from ios.self_tests.test_ios_avatar_keeper_handoff import AvatarKeeperHandoffTests as HandoffCase


class AvatarKeeperTerminal2Tests(unittest.TestCase):
    retain_originals = True
    domain_type = HandoffCase.domain_type
    domain = HandoffCase.domain
    issued_original_pin = HandoffCase.issued_original_pin
    recovered_public_preparation = HandoffCase.recovered_public_preparation
    preparation_unchanged = HandoffCase.preparation_unchanged
    recovered_scene = HandoffCase.recovered_scene
    continue_final = HandoffCase.continue_final
    ready = HandoffCase.ready

    @classmethod
    def setUpClass(cls):
        HandoffCase.setUpClass()

    @classmethod
    def tearDownClass(cls):
        HandoffCase.tearDownClass()

    def owner(self, d):
        p = d.owners['primary']
        p.load()
        return AvatarKeeperTerminal(AvatarTerminal(p))

    def test_both_actual_root_births_and_reopening_keep_every_end_duty_open(self):
        d = self.ready()
        with d.owners['primary'].held(paired=True):
            owner = self.owner(d)
            owner.prepare()
            before = deepcopy(owner.previous)
            self.assertEqual('ending', owner.state['phase'])
            self.assertTrue(all(row['phase'] == 'opened' and row['proof'] is None
                for row in owner.state['roles'].values()))
            self.assertTrue(all(Path(row['root']).is_dir() for row in owner.state['roles'].values()))
            reopened = self.owner(d)
            reopened.prepare()
            self.assertEqual(before, reopened.previous)
            with self.assertRaises(NativeUIError):
                reopened.original()
        self.assertFalse(any(n.lifecycle_inputs for n in d.natives.values()))
        self.assertFalse(any(method == 'DELETE' for _role,method in d.sdk_requests))

    def test_actual_unknown_original_file_is_not_part_of_an_empty_keeper_root(self):
        d = self.ready()
        with d.owners['primary'].held(paired=True):
            owner = self.owner(d)
            owner.prepare()
            root = Path(owner.state['roles']['primary']['root'])
            foreign = PrivateFeatureState(root/'foreign-original.json')
            foreign.write(dict(unparsedOriginal=True), None)
            with self.assertRaises(NativeUIError):
                owner.inventory()
            self.assertTrue(foreign.path.exists())
            self.assertIsNone(owner.state['end'])
        self.assertFalse(any(n.lifecycle_inputs for n in d.natives.values()))

    def test_replaced_actual_directory_cannot_inherit_saved_root_identity(self):
        d = self.ready()
        with d.owners['primary'].held(paired=True):
            owner = self.owner(d)
            owner.prepare()
            root = Path(owner.state['roles']['actor']['root'])
            moved = root.with_name(root.name+'-original-retained')
            root.rename(moved)
            root.mkdir(mode=0o700)
            with self.assertRaises(NativeUIError):
                owner.inventory()
            self.assertTrue(moved.exists())
            self.assertIsNone(owner.state['end'])
        self.assertFalse(any(n.lifecycle_inputs for n in d.natives.values()))

    def test_real_keeper_constructor_saved_cas_lost_return_never_mints_parent_end(self):
        d = self.ready()
        with d.owners['primary'].held(paired=True):
            owner = self.owner(d)
            owner.prepare()
            path = owner.flow.runtime.state_path(owner.flow.selectors['primary']).with_name(
                keeper_filename('avatar', 'primary', 0))
            original = PrivateFeatureState.write
            saved = []
            def lost(store, value, previous):
                result = original(store, value, previous)
                if store.path == path and not saved:
                    saved.append(deepcopy(value))
                    raise OSError('Actual original Keeper constructor saved; return lost')
                return result
            with patch.object(PrivateFeatureState, 'write', lost), self.assertRaises(OSError):
                owner.finish()
            self.assertEqual(1, len(saved))
            self.assertEqual(saved[0], PrivateFeatureState(path).read())
            view = KeeperOriginalView(owner.flow, 'primary', owner.state['roles']['primary']['root'])
            self.assertEqual('prepared', view.state['phase'])
            self.assertIsNone(view.state['cutoff'])
            self.assertIsNone(view.state['stop'])
            self.assertIsNone(owner.state['end'])
        self.assertFalse(any(n.lifecycle_inputs for n in d.natives.values()))


if __name__ == '__main__':
    unittest.main()
