"""Prospective original moving PNG/renderer/GPU composition, NOT Whole14.

Real Script Node VM, real PNG transport/file/hash/archive and strict image
validators; SDK, Qt, physics and GPU execution remain independent raw models.
Marker constructor, whole engine, restoration/cleanup and End remain open.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import hashlib
from copy import deepcopy
from unittest.mock import patch
from adapters.native_vulkan_world_frame import absent
from adapters.normal_ui import NativeUIError
from adapters.owned_vulkan_world_frame import VulkanWorldFrameOwner
from feature_journeys.evidence import MarkerNotReady
from ios.adapters import feature_observation
from test_lifecycle_parent_marker_models import LifecycleParentMarkerModels
from lifecycle_moving_vulkan_fixture import MovingDomain,MovingOriginalComposition


class LifecycleMovingVulkanOriginalModels(LifecycleParentMarkerModels):
    def setUp(self):
        super().setUp();self.domain=MovingDomain(self.scope)
        self.scope.prepare();self.domain.paint();self.scope.admit_rendered()
        self.domain.motion_start=self.domain.time;self.domain.select_physics_snapshot()
        self.images=MovingOriginalComposition(self.scope,self.domain)

    def test_actual_original_png_owner_and_moving_native_renderer_body_brackets_join_without_rewriting_history(self):
        first=self.images.acquire(self.scope.ticket);value,subject=self.images.compose(first)
        saved=deepcopy(first[0]);reference=first[-1];original=self.images.files.read(self.images.files.expand(reference))
        self.assertEqual((128,96),subject.size);self.assertEqual(hashlib.sha256(first[1]).hexdigest(),value['image']['sha256'])
        self.assertNotEqual(value['nativeBodyBefore']['position'],value['nativeBodyAfter']['position'])
        self.assertTrue(absent(first[0]['retirement']));self.assertGreater(len(self.images.gpu.paths),2)
        self.assertEqual(first[1],VulkanWorldFrameOwner.archive_original(original['owner'],self.scope.root,self.scope.binding,
            self.scope.run,'primary',0,original['requestId'],self.scope.lock))
        stamp=first[0]['capture']['capturedEpochMs'];second=self.images.acquire('b'*32);current,_=self.images.compose(second)
        self.assertEqual(saved,first[0]);self.assertEqual(stamp,first[0]['capture']['capturedEpochMs'])
        self.assertNotEqual(value['frameId'],current['frameId']);self.assertNotEqual(first[0]['capture']['requestId'],second[0]['capture']['requestId'])
        self.assertEqual(original,self.images.files.read(self.images.files.expand(reference)))

    def test_stationary_native_marker_cannot_follow_actual_moving_avatar_even_with_valid_fresh_png_and_fence(self):
        self.domain.parent_fault='stationary-marker';current=self.images.acquire(self.scope.ticket);saved=deepcopy(current[0])
        self.assertTrue(absent(current[0]['retirement']))
        with self.assertRaises(NativeUIError):self.images.compose(current)
        self.assertEqual(saved,current[0]);self.assertEqual(1,len(self.images.frames))
        self.assertTrue((self.scope.root/self.images.owner.name).is_file())

    def test_current_original_wrong_ticket_pixels_remain_stale_after_real_capture_and_retirement(self):
        current=self.images.acquire('b'*32,stale_ticket=self.scope.ticket);saved=deepcopy(current[0]);raw=current[1]
        with self.assertRaises(MarkerNotReady):self.images.compose(current)
        self.assertTrue(absent(current[0]['retirement']));self.assertEqual(raw,(self.scope.root/self.images.owner.name).read_bytes())
        self.assertEqual(saved,current[0]);self.assertEqual(hashlib.sha256(raw).hexdigest(),current[0]['capture']['source']['image']['sha256'])

    def test_unknown_current_renderer_bounds_cannot_borrow_marker_or_body_boxes_as_subject(self):
        self.domain.renderer_fault='unknown-bounds';current=self.images.acquire(self.scope.ticket);saved=deepcopy(current[0])
        self.assertTrue(absent(current[0]['retirement']))
        with self.assertRaises(NativeUIError):self.images.compose(current)
        self.assertEqual(saved,current[0]);self.assertIsNone(current[0]['renderersAfter']['source']['avatars'][0]['bounds'])

    def test_real_original_unfinished_gpu_slot_retains_duty_and_cannot_be_shadowed_by_a_new_capture(self):
        with self.assertRaises(NativeUIError):self.images.acquire(self.scope.ticket,no_fence=True)
        gpu,owner=self.images.gpu,self.images.owner
        self.assertEqual(1,sum(row['operation']=='read'for row in gpu.commands))
        with patch.object(feature_observation,'post_request',side_effect=gpu.post),self.assertRaises(NativeUIError):owner.release()
        self.assertIsNone(owner.state['absence']);self.assertTrue(gpu.gpu_pending)
        before=deepcopy(gpu.commands)
        with self.assertRaises(AssertionError):self.images.acquire('b'*32)
        self.assertEqual(before,gpu.commands);self.assertEqual([],self.images.frames)
        self.assertTrue(owner.store.path.is_file());self.assertTrue((self.scope.root/owner.name).is_file())
