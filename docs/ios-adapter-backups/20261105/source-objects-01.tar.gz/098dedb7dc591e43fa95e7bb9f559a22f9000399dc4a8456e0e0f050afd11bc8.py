"""Prospective lower-model dirfd counters; Root-only closed utility runner.

The runner must supply RUNTIME_FACTORY as a held actual controller function
before case birth; it creates QualificationRuntime from actual closed origins.
No case assigns backend owner fields or constructs an owner with __new__.
"""
from contextlib import contextmanager
from pathlib import Path
import os,sys,threading,unittest
from adapters import asset_backend_files as files
import test_asset_backend_files as producers
from owned_write_boundary import WriteRefusal

RUNTIME_FACTORY=None


class BackendDirFDBoundaryTests(unittest.TestCase):
    @contextmanager
    def actual(self,*,before=None):
        if RUNTIME_FACTORY is None:raise RuntimeError('Root closed utility admission not supplied')
        runtime=RUNTIME_FACTORY()
        # before is a declared test setup callback, before router installation.
        # It may create only its own genuine test artifacts under runtime TEMP.
        if before is not None:before(runtime)
        with runtime.scope():
            host=producers.BackendFilesTests()
            try:
                host.setUp()
                yield host,runtime
            finally:
                primary=sys.exception();original_return=host.doCleanups()
                runtime.original_standard_cleanup_return=original_return
                if not original_return and primary is None:raise AssertionError('Genuine backend fixture cleanup failed')
        self.assertFalse(runtime.drain_errors)
        self.assertIs(runtime.original_standard_cleanup_return,True)
        self.assertTrue(runtime.receipt['backendDescriptorsDrained'])

    def test_real_constructor_two_queries_atomic_link_replace_and_reopen(self):
        with self.actual()as(host,runtime):
            host.test_two_actual_queries_reopen_originals_and_never_retime_historical_results()
            kinds=[event[0]for event in runtime.boundary.events]
            for name in('root','read','scan','write','link','unlink','replace'):self.assertIn(name,kinds)
            self.assertEqual(2,len(host.published))

    def test_foreign_directory_fd_is_not_adopted_by_real_reader(self):
        with self.actual()as(host,runtime):
            foreign=runtime.originals['open'](runtime.temporary,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            try:
                with self.assertRaises(WriteRefusal):host.transport._read(foreign,files.ADMISSION,8192)
            finally:runtime.originals['close'](foreign)

    def test_real_root_fd_from_wrong_caller_and_control_fd_refuse(self):
        with self.actual()as(host,runtime):
            with self.assertRaises(WriteRefusal):os.open(files.ADMISSION,runtime.boundary.read_flags,dir_fd=host.transport.fd)
            with self.assertRaises(WriteRefusal):os.fchmod(host.transport.fd,0o700)
            with self.assertRaises(WriteRefusal):os.unlink('not-a-publication',dir_fd=host.transport.fd)
            from adapters.normal_ui import NativeUIError
            with self.assertRaises(NativeUIError):host.transport._read(host.transport.fd,'../outside',8192)
            with runtime.helper.parent(host.journal/'absent')as(control,leaf):
                with self.assertRaises(WriteRefusal):host.transport._read(control,files.ADMISSION,8192)

    def test_real_reader_rejects_symlink_leaf_and_single_link_violation(self):
        # Genuine product _read and the bridge both insist on regular nlink1.
        # Faults use actual syscalls authorized through unchanged E458 invoke.
        with self.actual()as(host,runtime):
            root=host.transport.fd;target=host.b.export/files.ADMISSION
            link=host.b.export/'hardlink-admission'
            runtime.helper.invoke('os.link',(str(target),str(link),-1,-1),runtime.originals['link'],target,link,follow_symlinks=False)
            try:
                with self.assertRaises(WriteRefusal):host.transport._read(root,files.ADMISSION,8192)
            finally:runtime.helper.mutate('unlink',link)
            symlink=host.b.export/'symlink-admission'
            runtime.helper.invoke('os.symlink',(files.ADMISSION,str(symlink),-1),runtime.originals['symlink'],files.ADMISSION,symlink)
            try:
                with self.assertRaises(WriteRefusal):host.transport._read(root,symlink.name,8192)
            finally:runtime.helper.invoke('os.remove',(str(symlink),-1),runtime.originals['unlink'],symlink)

    def test_protected_leaf_append_and_original_cap_stay_closed(self):
        with self.actual()as(host,runtime):
            protected=host.journal/'blocked.json';runtime.helper.protected.add(protected)
            try:
                with self.assertRaises(WriteRefusal):host.transport._write(host.transport.journal_fd,protected.name,b'new')
                self.assertFalse(protected.exists())
            finally:runtime.helper.protected.remove(protected)
            from adapters.normal_ui import NativeUIError
            with self.assertRaises(NativeUIError):host.transport._write(host.transport.journal_fd,'oversize.json',b'x'*65537)
            self.assertFalse((host.journal/'oversize.json').exists())

    def test_other_thread_cannot_use_genuine_backend_descriptor(self):
        with self.actual()as(host,runtime):
            outcomes=[]
            def other():
                try:host.transport._read(host.transport.fd,files.ADMISSION,8192)
                except BaseException as error:outcomes.append(type(error))
            thread=threading.Thread(target=other);thread.start();thread.join(5)
            self.assertFalse(thread.is_alive());self.assertEqual([WriteRefusal],outcomes)

    def test_exclusive_append_never_replaces_existing_original(self):
        with self.actual()as(host,runtime):
            name='counter-original.json';root=host.transport.journal_fd
            host.transport._write(root,name,b'first');path=host.journal/name;before=path.stat();raw=path.read_bytes()
            with self.assertRaises(FileExistsError):host.transport._write(root,name,b'second')
            after=path.stat();self.assertEqual(raw,path.read_bytes());self.assertEqual((before.st_dev,before.st_ino),(after.st_dev,after.st_ino))
            # This counter's extra journal file is not product journal history.
            runtime.helper.mutate('unlink',path)

    def test_reused_closed_root_fd_is_refused_without_adoption(self):
        with self.actual()as(host,runtime):
            # Exact kernel FD reuse fault: save a real duplicate, replace the
            # tracked number with a different actual directory, then restore
            # its original open-file description before genuine cleanup.
            root=host.transport.fd;held=os.dup(root)
            foreign=runtime.originals['open'](host.journal,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            try:
                os.dup2(foreign,root)
                from adapters.normal_ui import NativeUIError
                with self.assertRaises(NativeUIError):host.transport._read(root,files.ADMISSION,8192)
                with self.assertRaises(WriteRefusal):os.open(files.ADMISSION,runtime.boundary.read_flags,dir_fd=root)
            finally:
                os.dup2(held,root);runtime.originals['close'](held);runtime.originals['close'](foreign)

    def test_postpublication_lost_return_recovers_existing_original(self):
        # The original counter changes _append on the instance, not the sealed
        # producer class. Unknown delivery is never sent a second time.
        with self.actual()as(host,runtime):
            host.test_lost_postpublication_ack_recovers_original_without_resending_or_new_query()
            self.assertEqual(1,len(host.published))
