from pathlib import Path
import ast,difflib,hashlib,json,shutil,textwrap
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-world-hold-child-profile-draft-20261029';P=T/'lifecycle-original-owner-world-hold-child-profile-review-packet-20261029';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P.mkdir(mode=0o700)
for f in B.rglob('*'):
 if f.is_file():dest=P/f.relative_to(B);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,dest)
rows=json.loads((B/'checkpoint.json').read_text())['files']
for row in rows:
 rel=row['path'];base=P/'bases/repo'/rel;out=P/'candidate/repo'/rel
 assert H(base)==row['baseSHA256'] and H(out)==row['candidateSHA256'];row.update(base=str(base),candidate=str(out))
(P/'source2.diff').write_text(''.join(''.join(difflib.unified_diff(Path(row['base']).read_text().splitlines(True),Path(row['candidate']).read_text().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path'])) for row in rows))
newtree=ast.parse((P/'test_normal_child_world_hold_models.py').read_bytes());newids=['test_normal_child_world_hold_models.'+c.name+'.'+n.name for c in newtree.body if isinstance(c,ast.ClassDef) and c.name=='NormalChildWorldHoldModels' for n in c.body if isinstance(n,ast.AsyncFunctionDef) and n.name.startswith('test_')];assert len(newids)==3
plan=json.loads((P/'prospective-test-selection.json').read_text());plan.update(status='PRIVATE_FROZEN_UNRUN_REVIEW_PENDING',newNormalCases=newids,expectedNewRealTemporaryDirectories=9,initialNewOuterSeconds=90,killAfterSeconds=5,retainInstalledFixture=False,retainedTemporaryDirectoryAliases=['ios.self_tests.test_ios_touch_lease','ios.self_tests.test_ios_bundle_identity','ios.self_tests.test_ios_installed_adapter'])
plan['remainingReview']=['Source/fixture complete review before any Rootrun','No claim of actual SDK/native/auth or full feature from explicit producer models'];(P/'test-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
manifest=dict(status='PRIVATE_FROZEN_SOURCE2_MODELS3_LEGACY18_UNRUN_REVIEW_PENDING',files=rows,orderedDependencies=[dict(path=str(T/'lifecycle-original-owner-resource-scoped-forward-prepare-import-composition-20261029'),freezeSHA256=H(T/'lifecycle-original-owner-resource-scoped-forward-prepare-import-composition-20261029/freeze.json'))],requiredPriorRegistry={'ios-original-keeper-touch':4,'original-keeper-motion-profile':2,'original-keeper-retained-touch-profile':1},sourceCompleteQualification=False,nativeSDKAuthAndWholeQualified=False,canonicalProductionGate=False,testsRun=False,targetImports=False)
regrows=[];diff=[]
for rel in ['tests/device/contract-versions.json','tests/device/validate_contract_versions.py']:
 base=P/'registry-bases/repo'/rel;out=P/'own-registry/repo'/rel
 for path in (base,out):path.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(R/rel,base);s=base.read_text()
 if rel.endswith('.json'):
  old='    "ios-lifecycle-world-hold": {"current": 1, "reads": [1]},'
  new='    "ios-lifecycle-world-hold": {"current": 2, "reads": [1, 2]},\n    "ios-lifecycle-world-hold-child-proof-frame": {"current": 1, "reads": [1]},\n    "ios-lifecycle-world-hold-child-proof-original": {"current": 1, "reads": [1]},'
 else:
  old='    "ios-lifecycle-world-hold": 1,'
  new='    "ios-lifecycle-world-hold": 2,\n    "ios-lifecycle-world-hold-child-proof-frame": 1,\n    "ios-lifecycle-world-hold-child-proof-original": 1,'
 assert s.count(old)==1;s=s.replace(old,new,1);out.write_text(s);diff.extend(difflib.unified_diff(base.read_text().splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 regrows.append(dict(path=rel,base=str(base),baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out),ownHunksOnly=True))
manifest['ownRegistry']=regrows;(P/'registry-own3.diff').write_text(''.join(diff));(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(P/'README.txt').write_text('Private frozen Source2+3normal models, NOT production/native/SDK/auth/whole qualification. Existing Runtime.child(selector,editors,attempt,None,original_child=True) and actual LifecycleWorldHold2 now route originalselected3 preparation/begin2/inspect3/release3/settle3 through SAME original client/session and exact source-born child Resource/worker. Default1 keeps explicitlocalfactory and existing proof codecs. Production_child/admit unchanged closed. PhysicalIPA selected prospectively before normalinstalled/firsteditor/w3cintercepted attempt; shared model Scene/Touch/native/bundle producers retained, no historical retiming. Actual WebDriver/HTTP/parser/originalrequestTask/receiver/worker/WAL/file/chunk paths execute onlyunderRootrun. Nodebridge qualified separately, never claimed by Pythonmodelserver.3new: full normalfirst→childheld/released/fourquiet chain; Source/RSDloss→oldUponce/noReleasedproof; actualcompletedPrepare returnloss→onlyoriginal unborn scopedsettle/noReplay/noReleasedproof. New3/90+5/9realTD and separate18legacy/90+5/18realTD prospective.30 Sourcequeries/3nativeacqframes/7hostproofs ceilings unchanged. ScopedUp/settle reached before currentPrefix/foreground checks. All genuine Worker/SDK-model context/HTTPthread/server/creator/tasks retained through actualclose, no cancelasrelease. New childproof namespace30chars/typedprefix31chars uses existing strict32 bounds and OriginalFrameStore, distinct from literalv1Proofbody. Own3registry hunk plan only; shared currentbytes must be resnapshotted byRoot after prospective PUB. Full source/fixture review and Rootexecution required. No targetimports/tests/PUB byauthor.\n')
for p in P.rglob('*.py'):ast.parse(textwrap.dedent(p.read_text()) if p.name.endswith('.fragment.py') else p.read_bytes())
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_REVIEW_PENDING',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(path=str(P),freeze=H(P/'freeze.json'),sourceDiff=H(P/'source2.diff'),sourceRows=rows,modelSHA256=H(P/'test_normal_child_world_hold_models.py'),fixtureSHA256=H(P/'normal_child_fixture.py'),newCases=newids),indent=2))
