"""Seven real pre-spawn port counters and four genuine stdlib resolver counters.

UNRUN. No fake process/PID/exit is installed. The positive process-boundary test
ALWAYS stops at the actual audit event before fork/exec; it proves no child exit.
"""
from pathlib import Path
from types import SimpleNamespace
import hashlib,http.server,json,os,socket,stat,subprocess,sys,threading,unittest
from moving_prespawn_counter_observer import(metadata,fds,children,OriginalPreSpawnObserver,PreSpawnStop)

# A future outer controller must independently verify this manifest/hash and
# every exact source origin BEFORE importing this module or the lower fixtures.
REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()
INPUT=Path(os.environ['MOVING_PRESPAWN_APPROVED_INPUTS'])
assert INPUT.resolve(strict=True).is_relative_to(REPO)
assert hashlib.sha256(INPUT.read_bytes()).hexdigest()==os.environ['MOVING_PRESPAWN_APPROVED_INPUTS_SHA256']
APPROVED=json.loads(INPUT.read_text());assert APPROVED['repositoryRoot']==str(REPO)
for path,expected in APPROVED['sourceAndBinaryPins'].items():assert metadata(path)==expected
from moving_host_ports import MovingNodePort,OwnedLoopbacks
from diagnostic_write_guard import MutationBoundary
from lifecycle_moving_raw_worker import RawMarkerWorker
assert not [name for name in sys.modules if name.split('.')[0]in('ios','adapters','feature_journeys','pymobiledevice3','appium')]
_ORIGINAL_CLEANUPS=unittest.TestCase.doCleanups


def toy_census(root):
    result={}
    def visit(path):
        before=path.lstat();fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        row=dict(stat=[getattr(before,key)for key in fields])
        if stat.S_ISREG(before.st_mode):
            assert before.st_nlink==1 and not path.is_symlink();row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        else:
            assert stat.S_ISDIR(before.st_mode)and not path.is_symlink()
            row['namespace']=sorted(child.name for child in path.iterdir())
            for name in row['namespace']:visit(path/name)
        assert row['stat']==[getattr(path.lstat(),key)for key in fields];result[str(path.relative_to(root))]=row
    visit(root);return result


class MovingOriginalPortCounterBase(unittest.TestCase):
    def setUp(self):
        self.fd_before=fds();self.threads_before=tuple(threading.enumerate());self.children_before=children()
        self.pin_before={path:metadata(path)for path in APPROVED['sourceAndBinaryPins']}
        assert self.pin_before==APPROVED['sourceAndBinaryPins']
        output=Path(os.environ['MOVING_PRESPAWN_OUTPUT_ROOT']);assert output.resolve(strict=True)==output and output.is_relative_to(REPO)
        self.case_root=output/self.id().rsplit('.',1)[1];assert not self.case_root.exists();self.case_root.mkdir(mode=0o700)
        self.toy=self.case_root/'toy';self.toy.mkdir(mode=0o700)
        self.stage=self.toy/'stage';self.stage.mkdir(mode=0o700)
        for name in('retained','bindings','cleanup'):(self.stage/name).mkdir(mode=0o700)
        self.main=self.stage/'retained/main.js';self.main.write_text('"use strict";\n')
        self.main.with_name('companion.js').write_text('module.exports={};\n')
        self.boundary=MutationBoundary(REPO,self.stage)
        self.port=MovingNodePort(APPROVED['movingPlan'],self.boundary);self.port.bind(RawMarkerWorker)
        # A declared lower owner only: no World constructor, Source, browser,
        # HTTP request or Native success state exists in this unit fixture.
        self.worker=RawMarkerWorker(SimpleNamespace(),self.unexpected_http)
        self.observers=[];self.owned_fds=[];self.sockets=[]
        self.addCleanup(self.record_terminal)
        self.addCleanup(self.rescue_owned)

    def unexpected_http(self,*args):raise AssertionError('Pre-spawn counter reached browser/HTTP')

    def observer(self,*,loopbacks=None):
        value=OriginalPreSpawnObserver(self.port,self.boundary,loopbacks)
        self.observers.append(value);return value

    def own_fd(self,descriptor):
        info=os.fstat(descriptor);self.owned_fds.append((descriptor,info.st_dev,info.st_ino));return descriptor

    def rescue_owned(self):
        for observer in self.observers:
            if observer is not None:
                # enter/leave is always finally-balanced by each counter.
                observer.rescue_close()
        for owner in self.sockets:owner.close()
        for descriptor,device,inode in self.owned_fds:
            try:info=os.fstat(descriptor)
            except OSError:continue
            if(info.st_dev,info.st_ino)==(device,inode):os.close(descriptor)

    def record_terminal(self):
        self.assertIs(unittest.TestCase.doCleanups,_ORIGINAL_CLEANUPS)
        pin_after={path:metadata(path)for path in APPROVED['sourceAndBinaryPins']}
        self.assertEqual(self.pin_before,pin_after)
        self.assertEqual(self.fd_before,fds());self.assertEqual(self.threads_before,tuple(threading.enumerate()))
        self.assertEqual(self.children_before,children())
        self.assertIsNone(self.worker.process);self.assertIsNone(self.worker.reader)
        self.assertIsNone(self.worker.browser.thread)
        first=toy_census(self.toy);second=toy_census(self.toy);self.assertEqual(first,second)
        report=dict(case=self.id(),sourceAndBinaryPinsUnchanged=True,actualFDsRestored=True,
            actualThreadsRestored=True,actualKernelChildrenRestored=True,twoOwnToyCensusesEqual=True,
            descriptors=[row for owner in self.observers for row in owner.descriptors],
            acceptedPreSpawnAuditEvents=sum(owner.accepted for owner in self.observers),
            auditCommands=[row for owner in self.observers for row in owner.actual_audit_events],
            NodeExecutions=0,childProcessBirths=0,SourceInstances=0,nativeQualified=False,movingQualified=False)
        (self.case_root/'own-toy-first.json').write_text(json.dumps(first,sort_keys=True,indent=2)+'\n')
        (self.case_root/'own-toy-second.json').write_text(json.dumps(second,sort_keys=True,indent=2)+'\n')
        (self.case_root/'standard-cleanup-receipt.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')


class MovingOriginalPreSpawnPortTests(MovingOriginalPortCounterBase):
    def test_actual_original_start_and_popen_pipe_admit_then_stop_before_any_node_birth(self):
        observer=self.observer();observer.enter()
        try:
            with self.assertRaises(PreSpawnStop):self.worker.start(self.main)
        finally:observer.leave()
        self.assertEqual(1,observer.accepted);self.assertEqual(1,len(self.port.pipe_opens))
        self.assertEqual(6,len(observer.descriptors));observer.assert_original_exception_drain()
        self.assertIs(self.port.pending,observer.actual_constructor)
        self.assertIsNone(self.worker.process);self.assertFalse(getattr(self.port.pending,'_child_created',False))
        self.assertFalse(hasattr(self.port.pending,'pid'))
        # finish MUST refuse: audit-admitted is not a created/retired child.
        with self.assertRaises(AssertionError):self.port.finish()

    def test_same_literal_popen_outside_actual_start_frame_refuses_and_real_pipes_close(self):
        observer=self.observer();observer.enter()
        try:
            with self.assertRaises(AssertionError):
                subprocess.Popen(self.port.command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        finally:observer.leave()
        self.assertEqual(0,observer.accepted);self.assertFalse(self.port.spawned)
        self.assertEqual(6,len(observer.descriptors));observer.assert_original_exception_drain()

    def test_actual_unbound_writable_pipe_fd_refuses_without_constructor_or_spawn(self):
        read_end,write_end=os.pipe();self.own_fd(read_end);self.own_fd(write_end)
        observer=self.observer();observer.enter()
        try:
            with self.assertRaises(AssertionError):os.fdopen(write_end,'wb')
        finally:observer.leave()
        self.assertEqual(0,observer.accepted);self.assertEqual([],self.port.pipe_opens)
        self.assertFalse(self.port.spawned)

    def test_same_popen_constructor_object_with_changed_code_refuses_before_port_authority(self):
        function=subprocess.Popen.__init__;code=function.__code__
        try:
            function.__code__=code.replace(co_filename=code.co_filename+'-counter-mutation')
            with self.assertRaises(AssertionError):self.port.check()
        finally:function.__code__=code
        self.port.check();self.assertFalse(self.port.spawned)

    def test_same_bytes_new_script_inode_pointer_refuses_without_touching_frozen_source(self):
        source=self.port.script;copy=self.toy/'same-body-new-inode.mjs';copy.write_bytes(source.read_bytes())
        self.assertEqual(source.read_bytes(),copy.read_bytes());self.assertNotEqual(source.stat().st_ino,copy.stat().st_ino)
        try:
            self.port.script=copy
            with self.assertRaises(AssertionError):self.port.check()
        finally:self.port.script=source
        self.port.check();self.assertFalse(self.port.spawned)

    def test_second_actual_attempt_after_audit_admission_refuses_before_second_spawn(self):
        first=self.observer();first.enter()
        try:
            with self.assertRaises(PreSpawnStop):self.worker.start(self.main)
        finally:first.leave()
        first.assert_original_exception_drain();self.assertEqual(1,first.accepted)
        second=self.observer();second.enter()
        try:
            with self.assertRaises(AssertionError):self.worker.start(self.main)
        finally:second.leave()
        second.assert_original_exception_drain();self.assertEqual(0,second.accepted)
        self.assertEqual(6,len(second.descriptors));self.assertEqual(1,len(self.port.pipe_opens))

    def test_regular_fd_delegates_to_actual_canonical_boundary_and_foreign_stage_fd_refuses(self):
        owned=self.stage/'retained/owned.txt';foreign=self.toy/'outside-stage-witness.txt'
        owned.write_bytes(b'');foreign.write_bytes(b'')
        owned_fd=self.own_fd(os.open(owned,os.O_RDWR|os.O_NOFOLLOW));foreign_fd=self.own_fd(os.open(foreign,os.O_RDWR|os.O_NOFOLLOW))
        observer=self.observer();observer.enter()
        try:
            with os.fdopen(owned_fd,'wb',closefd=False)as stream:stream.write(b'actual own bytes')
            with self.assertRaises(AssertionError):os.fdopen(foreign_fd,'wb',closefd=False)
        finally:observer.leave()
        self.assertEqual(b'actual own bytes',owned.read_bytes());self.assertEqual(b'',foreign.read_bytes())
        self.assertEqual([],self.port.pipe_opens);self.assertFalse(self.port.spawned)


class MovingOriginalHostResolverTests(MovingOriginalPortCounterBase):
    def server(self):
        # Genuine stdlib constructor without activation: bind/getfqdn is real,
        # no listening socket, service loop, accept, reader thread or payload.
        server=http.server.HTTPServer(('127.0.0.1',0),http.server.BaseHTTPRequestHandler,bind_and_activate=False)
        self.sockets.append(server.socket);self.addCleanup(server.server_close);return server

    def test_genuine_http_server_bind_retains_scoped_original_numeric_host_lookup(self):
        server=self.server();loopbacks=OwnedLoopbacks();observer=self.observer(loopbacks=loopbacks);observer.enter()
        try:server.server_bind()
        finally:observer.leave()
        actual=server.socket.getsockname();self.assertEqual(('127.0.0.1',actual[1]),server.server_address)
        self.assertIs(type(server.server_name),str);self.assertEqual(1,len(loopbacks.resolver_reads))
        row=loopbacks.resolver_reads[0];self.assertEqual(list(actual),row['actualBoundEndpoint'])
        self.assertFalse(row['nativeFact']);self.assertFalse(row['noExternalNSSorDNSClaim'])
        server.server_close();receipt=loopbacks.finish()
        self.assertEqual(loopbacks.resolver_reads,receipt['scopedOriginalHostResolverRead'])

    def test_original_reverse_or_getfqdn_outside_http_bind_frame_refuses(self):
        loopbacks=OwnedLoopbacks();observer=self.observer(loopbacks=loopbacks);observer.enter()
        try:
            with self.assertRaises(AssertionError):socket.gethostbyaddr('127.0.0.1')
            with self.assertRaises(AssertionError):socket.getfqdn('127.0.0.1')
        finally:observer.leave()
        self.assertEqual([],loopbacks.resolver_reads)

    def test_foreign_host_and_removed_own_socket_membership_refuse_before_lookup(self):
        server=self.server();loopbacks=OwnedLoopbacks();observer=self.observer(loopbacks=loopbacks)
        def forget_before_reverse(event,args):
            if event=='socket.gethostbyaddr':loopbacks.servers.clear()
        observer.enter()
        try:
            with self.assertRaises(AssertionError):socket.getfqdn('203.0.113.19')
            observer.before_socket_event=forget_before_reverse
            with self.assertRaises(AssertionError):server.server_bind()
        finally:observer.leave()
        self.assertEqual([],loopbacks.resolver_reads);self.assertEqual([],loopbacks.servers)
        self.assertGreater(server.socket.getsockname()[1],0)

    def test_original_reverse_c_port_alias_rebinding_refuses_and_restores_exact_object(self):
        loopbacks=OwnedLoopbacks();original=socket.gethostbyaddr
        def forbidden_substitute(*args):raise AssertionError('No substituted resolver may execute')
        try:
            socket.gethostbyaddr=forbidden_substitute
            with self.assertRaises(AssertionError):loopbacks.check()
        finally:socket.gethostbyaddr=original
        loopbacks.check();self.assertEqual([],loopbacks.resolver_reads)
