"""Authorized exact one diagnostic prefix private Audio host counters; every external action denied."""
from pathlib import Path
import hashlib,importlib.abc,importlib.util,json,os,stat,sys,tempfile,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent;REPO=HERE.parent.parent
PLAN=HERE/'preimport-map.json';EXPECTED='bd3f6c625372bf33ef5d41a821a4a8cb785723256f7c83ae66a0a8dcd860733e'
assert hashlib.sha256(PLAN.read_bytes()).hexdigest()==EXPECTED
plan=json.loads(PLAN.read_text());assert plan['root']==str(HERE) and plan['repository']==str(REPO)
assert sys.dont_write_bytecode and len(plan['cases'])==1 and len(set(plan['cases']))==1
TEMP=HERE/'temporary';assert TEMP.is_dir() and not list(TEMP.iterdir());tempfile.tempdir=str(TEMP)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,value):
 path=HERE/name;path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');path.chmod(0o600)
for row in plan['frozenPackets']:assert digest(row['path'])==row['sha256']
for row in plan['modules'].values():assert digest(row['path'])==row['sha256']
save('preimport-verification.json',dict(status='EXACT_MAP_SHA_CHECKED_BEFORE_ANY_TARGET_IMPORT',mappedModules=len(plan['modules']),frozenPackets=plan['frozenPackets'],python=sys.version,executable=sys.executable,sourceMapSha256=EXPECTED))
loaded={};public_reads={};refusals=[];retained=[];depth=False
initial_modules=dict(sys.modules);initial_meta=list(sys.meta_path);initial_path=list(sys.path);initial_threads=set(threading.enumerate())
project_tops={name.split('.')[0]for name in plan['modules']}
assert not any(name.split('.')[0]in project_tops for name in sys.modules)

def pin_read(path):
 global depth
 if depth:return
 depth=True
 try:
  path=Path(path).absolute()
  if path.is_relative_to(REPO) and not path.is_relative_to(REPO/'.ios-host-tmp') and path.is_file():
   info=path.lstat();row=dict(sha256=digest(path),device=info.st_dev,inode=info.st_ino,bytes=info.st_size,mtimeNs=info.st_mtime_ns)
   if str(path)in public_reads:assert public_reads[str(path)]==row,'Public dependency changed during this exact run'
   else:public_reads[str(path)]=row
 finally:depth=False

def refuse(event,detail):
 row=dict(event=event,detail=detail);refusals.append(row);raise RuntimeError('AUDIT_REFUSED_'+event)

def audit(event,args):
 if event=='import':
  name=args[0]
  if any(name==prefix or name.startswith(prefix+'.')for prefix in ('pymobiledevice3','tidevice','pyidevice','zeroconf','appium','playwright','selenium','ios.pymobiledevice3_wda_xctest')):refuse(event,name)
 elif event.startswith('socket.'):
  if event not in ('socket.gethostname',):refuse(event,'All sockets, device/network transports and services are forbidden')
 elif event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn') or event.startswith('os.spawn'):
  refuse(event,'All subprocess/compiler/Node/build/device actions are forbidden')
 elif event=='ctypes.dlopen':refuse(event,'Dynamic native SDK loads are forbidden')
 elif event=='open' and not depth:
  path,mode,flags=args
  if isinstance(path,(str,bytes,os.PathLike)):
   path=Path(os.fsdecode(path)).absolute();writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)) or isinstance(mode,str) and any(c in mode for c in 'wax+')
   if writing and not path.is_relative_to(HERE):refuse(event,'Write outside the exact private run root')
   if not writing:pin_read(path)
 elif event in ('os.remove','os.rmdir','os.mkdir','os.rename','os.chmod','os.link','os.symlink'):
  candidates=args[:2]if event in ('os.rename','os.link','os.symlink')else args[:1]
  for item in candidates:
   if isinstance(item,(str,bytes,os.PathLike)):
    path=Path(os.fsdecode(item)).absolute()
    if not path.is_relative_to(HERE):refuse(event,'Filesystem mutation outside the exact private run root')
sys.addaudithook(audit)

class Loader(importlib.abc.Loader):
 def __init__(self,name,row):self.name,self.row=name,row
 def create_module(self,spec):return None
 def exec_module(self,module):
  path=Path(self.row['path']);raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==self.row['sha256']
  module.__file__=str(path)
  if self.row['package']:module.__path__=[str(path.parent)]
  loaded[self.name]=self.row
  exec(compile(raw,str(path),'exec'),module.__dict__)
  assert digest(path)==self.row['sha256']
class Finder(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  row=plan['modules'].get(fullname)
  if row is not None:return importlib.util.spec_from_loader(fullname,Loader(fullname,row),is_package=row['package'])
  roots=plan['namespacePackages'].get(fullname)
  if roots is not None:
   spec=importlib.machinery.ModuleSpec(fullname,None,is_package=True);spec.submodule_search_locations=roots;return spec
  if fullname.split('.')[0]in project_tops:raise ImportError('Unmapped project import refused: '+fullname)
  return None
finder=Finder();sys.meta_path.insert(0,finder)
real_td=tempfile.TemporaryDirectory
class RetainedDirectory(real_td):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);assert Path(self.name).is_relative_to(TEMP);self._finalizer.detach();retained.append(self.name);save('retained-temporary-roots.json',retained)
 def cleanup(self):
  self._finalizer.detach() # All roots/originals/failures remain in this exact run.
tempfile.TemporaryDirectory=RetainedDirectory
case_receipts=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  self.started=time.monotonic();print('PREFIX60_CASE_START',test.id(),flush=True);super().startTest(test)
 def stopTest(self,test):
  rows=[dict(name=t.name,ident=t.ident,daemon=t.daemon)for t in threading.enumerate()if t not in initial_threads and t.is_alive()]
  receipt=dict(id=test.id(),elapsedSeconds=time.monotonic()-self.started,newThreads=rows,auditRefusals=len(refusals))
  case_receipts.append(receipt);save('case-stop-receipts.json',case_receipts);print('PREFIX60_CASE_STOP',json.dumps(receipt),flush=True);super().stopTest(test)
  # The case outer finally drains any original registered callbacks after
  # unittest.stopTest on interrupt; final remaining-thread census below is authoritative.
 def addError(self,test,error):
  super().addError(test,error);self.preserve(test,error,'ERROR')
 def addFailure(self,test,error):
  super().addFailure(test,error);self.preserve(test,error,'FAIL')
 def preserve(self,test,error,kind):
  raw=''.join(traceback.format_exception(*error));print('PREFIX60_'+kind,test.id(),raw,flush=True)
  with (HERE/'original-exceptions.log').open('a')as stream:stream.write(kind+' '+test.id()+'\n'+raw);stream.flush();os.fsync(stream.fileno())
class AudioWholePrefixCase(unittest.TestCase):
 def run(self,result=None):
  original_cleanup=unittest.TestCase.doCleanups
  try:return super().run(result)
  finally:
   # Python3.14 TestCase.run skips doCleanups on KeyboardInterrupt. Execute
   # only callbacks still registered, using the ACTUAL unmodified stdlib
   # cleanup implementation and order. No feature abort/End result is added.
   pending=len(self._cleanups);prior=self._outcome;cleanup_result=unittest.TestResult();success=True
   cause=sys.exc_info()[1]
   try:
    if pending:
     self._outcome=unittest.case._Outcome(cleanup_result)
     success=unittest.TestCase.doCleanups(self)
   finally:
    self._outcome=prior
    save('original-cleanup-chain.json',dict(ran=True,pendingBeforeOuterFinally=pending,remaining=len(self._cleanups),success=success,
     errors=cleanup_result.errors,failures=cleanup_result.failures,originalFunctionUnchanged=unittest.TestCase.doCleanups is original_cleanup))
   if not success or self._cleanups or cleanup_result.errors or cleanup_result.failures:
    if cause is not None:cause.add_note('Original registered cleanup chain did not establish successful complete drain; see original-cleanup-chain.json')
    else:raise RuntimeError('Original registered cleanup chain did not establish successful complete drain')
 def test_original_preparation_open_and_first_mute(self):
  import cProfile
  from copy import deepcopy
  from feature_journeys.scenarios import SCENARIOS
  from ios.self_tests.audio_whole_fixture import AudioWholeFixture
  profiler=cProfile.Profile();events=[];started=time.monotonic();complete=False
  def step(label,call):
   events.append(dict(label=label,event='begin',elapsedSeconds=time.monotonic()-started));save('prefix-events.json',events)
   result=call()
   events.append(dict(label=label,event='returned',elapsedSeconds=time.monotonic()-started));save('prefix-events.json',events);return result
  profiler.enable()
  try:
   fixture=step('actual-fixture-birth',lambda:AudioWholeFixture(self))
   step('primary.prepare',fixture.primary.prepare)
   step('actor.prepare',fixture.actor.prepare)
   baseline=step('primary.baseline.observe',fixture.observe)
   self.assertEqual('idle',baseline['state']['phase'])
   step('actor.baseline.publish',fixture.actor.publish)
   prefix=SCENARIOS['audio']['steps'][:2]
   self.assertEqual(['open','mute'],[row['verb']for row in prefix])
   for index,row in enumerate(prefix,1):
    step('ordinary-'+row['verb'],lambda index=index,row=row:fixture.step(row['verb'],format(index,'032x'),deepcopy(row['inputs'])))
   complete=True
  finally:
   profiler.disable();rows=[]
   for entry in profiler.getstats():
    code=entry.code
    where=dict(filename=code.co_filename,line=code.co_firstlineno,name=code.co_name)if hasattr(code,'co_filename')else dict(filename='<builtin>',line=0,name=str(code))
    rows.append(dict(**where,callCount=entry.callcount,recursiveCallCount=entry.reccallcount,selfSeconds=entry.inlinetime,totalSeconds=entry.totaltime))
   save('builtin-cprofile-original.json',dict(profiler='stdlib-cProfile',diagnosticOnly=True,prefixReturned=complete,elapsedSeconds=time.monotonic()-started,rows=sorted(rows,key=lambda row:row['totalSeconds'],reverse=True)))
   save('prefix-terminal.json',dict(status='PREFIX_RETURNED_UNDER_PROFILE'if complete else'PREFIX_INTERRUPTED_OR_FAILED',normalQualified=False,nativeQualified=False,wholeQualified=False))
result=None;fatal=None;actual_ids=[];started=time.monotonic()
try:
 loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
 def flatten(value):
  if isinstance(value,unittest.TestSuite):
   for child in value:yield from flatten(child)
  else:yield value
 actual_ids=[case.id()for case in flatten(suite)];save('actual-selected-ids.json',dict(ids=actual_ids,loaderErrors=loader.errors))
 assert not loader.errors and actual_ids==plan['cases'] and suite.countTestCases()==1,'Exact overlay/selection unresolved; no broadened execution'
 result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(suite)
except BaseException:
 fatal=traceback.format_exc();(HERE/'original-fatal.log').write_text(fatal);print(fatal,flush=True)
finally:
 restored=[]
 for name,module in list(sys.modules.items()):
  if name in loaded and getattr(module,'TemporaryDirectory',None)is RetainedDirectory:module.TemporaryDirectory=real_td;restored.append(name+'.TemporaryDirectory')
 tempfile.TemporaryDirectory=real_td;sys.meta_path[:]=initial_meta;sys.path[:]=initial_path
 assert tempfile.TemporaryDirectory is real_td
 after={};unchanged=True
 for path,before in public_reads.items():
  info=Path(path).lstat();row=dict(sha256=digest(path),device=info.st_dev,inode=info.st_ino,bytes=info.st_size,mtimeNs=info.st_mtime_ns);after[path]=row
  if row!=before:unchanged=False
 for row in loaded.values():assert digest(row['path'])==row['sha256']
 for row in plan['frozenPackets']:assert digest(row['path'])==row['sha256']
 remaining=[dict(name=t.name,ident=t.ident)for t in threading.enumerate()if t not in initial_threads and t.is_alive()]
 save('loaded-project-modules.json',loaded);save('actual-public-dependencies-before.json',public_reads);save('actual-public-dependencies-after.json',after)
 report=dict(status='REFUSED_OR_FATAL'if fatal else'PASS'if result is not None and result.wasSuccessful()and unchanged and not refusals and not remaining else'FAIL_OR_ERROR',testsRun=0 if result is None else result.testsRun,failures=0 if result is None else len(result.failures),errors=0 if result is None else len(result.errors),skips=0 if result is None else len(result.skipped),fatal=fatal is not None,elapsedSeconds=time.monotonic()-started,selected=actual_ids,actualPublicDependencies=len(public_reads),allPublicDependenciesUnchanged=unchanged,loadedProjectModules=len(loaded),auditRefusals=refusals,temporaryRootsRetained=retained,restoredAliases=restored,metaPathRestored=sys.meta_path==initial_meta,sysPathRestored=sys.path==initial_path,tempfileAliasRestored=tempfile.TemporaryDirectory is real_td,remainingNewThreads=remaining,nodeExecutions=0,SDKExecutions=0,builds=0,deviceActions=0,hostOnly=True,diagnosticOnly=True,nativeQualified=False,wholeQualified=False)
 save('report.json',report);print('PREFIX60_TERMINAL',json.dumps(report),flush=True)
