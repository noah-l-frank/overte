"""Prospective real Current7 owners/preflight boundaries; AST-only, UNRUN.

Actual retained Source/Current/HTTP/AFC/PFS/lock paths remain. SDK/native/OS are
explicit inherited models. No Publisher freshness or whole completion claim.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,os
from copy import deepcopy
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.original_file_reads import collect
from ios.adapters import lifecycle_current_transport as transport
from test_lifecycle_publication_original_read_phase_models import LifecyclePublicationOriginalReadPhaseModels


class LifecycleRetainedCurrentOwnerModels(LifecyclePublicationOriginalReadPhaseModels):
    async def primary_stream(self):
        await self.primary_api();return self.primary_history.stream

    async def test_same_actual_archive_history_owner_and_complete_read_membership_without_new_cut(self):
        stream=await self.primary_stream();before=self.counts()
        def read():
            with stream.lock.held():
                first=stream.archive();self.assertIs(first,stream.archive())
                self.assertIs(first,self.primary_history.archive())
                reference=deepcopy(stream.state['records'][-1])
                with collect()as left:a=first.record(reference)
                with collect()as right:b=stream.archive().record(reference)
                self.assertTrue(left);self.assertEqual(left,right);self.assertEqual(a,b)
                self.assertIs(first,stream.held_archive(deepcopy(stream.previous)))
                self.assertIsNone(stream.held_archive(dict(stream.previous,owner='f'*32)))
        await asyncio.to_thread(read);self.assertEqual(before,self.counts())

    async def test_same_inode_same_bytes_rewrite_refuses_retained_archive_before_new_query(self):
        stream=await self.primary_stream();before=self.counts()
        def rewrite():
            with stream.lock.held():
                archive=stream.archive();path=stream.store.path;raw=path.read_bytes();inode=path.stat().st_ino
                backup=stream.root/'retained-current-before-exact-rewrite.json';backup.write_bytes(raw);backup.chmod(0o600)
                with path.open('r+b')as file:file.write(raw);file.flush();os.fsync(file.fileno())
                self.assertEqual(inode,path.stat().st_ino);self.assertEqual(raw,path.read_bytes())
                with self.assertRaises(NativeUIError):stream.archive()
                self.assertIs(archive,stream._current_archive)
        await asyncio.to_thread(rewrite);self.assertEqual(before,self.counts())

    async def test_equal_body_foreign_pfs_inode_refuses_retained_owner_without_cold_replacement(self):
        stream=await self.primary_stream();before=self.counts()
        def replace():
            with stream.lock.held():
                archive=stream.archive();old=stream.store.path.stat().st_ino
                # A real foreign CAS writes equal JSON into a different inode.
                stream.store.write(deepcopy(stream.previous),deepcopy(stream.previous))
                self.assertNotEqual(old,stream.store.path.stat().st_ino)
                with self.assertRaises(NativeUIError):stream.archive()
                self.assertIs(archive,stream._current_archive)
        await asyncio.to_thread(replace);self.assertEqual(before,self.counts())

    async def test_same_original_parser_code_mutation_refuses_then_original_owner_resumes(self):
        stream=await self.primary_stream();before=self.counts()
        def change():
            with stream.lock.held():
                archive=stream.archive();function=transport.frame_original;code=function.__code__
                function.__code__=code.replace(co_consts=(*code.co_consts,'retained-owner-code-counter'))
                try:
                    with self.assertRaises(RuntimeError):stream.archive()
                finally:function.__code__=code
                self.assertIs(archive,stream.archive())
        await asyncio.to_thread(change);self.assertEqual(before,self.counts())

    async def test_lost_real_planned_cas_return_discards_archive_before_any_new_current_query(self):
        stream=await self.primary_stream();before=self.counts()
        def lose():
            with stream.lock.held():
                archive=stream.archive();ticket=self.active_ticket;original=stream.store.write;writes=[]
                def write(value,previous):
                    original(value,previous);writes.append(deepcopy(value));raise OSError('Declared loss AFTER actual planned Current WAL CAS')
                with patch.object(stream.store,'write',new=write):
                    with self.assertRaises(OSError):stream.current(ticket)
                self.assertEqual(1,len(writes));self.assertIsNone(stream._current_archive)
                self.assertEqual('planned',stream.store.read()['pending']['phase'])
                with self.assertRaises(NativeUIError):archive.bound()
                with self.assertRaises(NativeUIError):stream.current(ticket)
        await asyncio.to_thread(lose);self.assertEqual(before,self.counts())

    async def test_passive_default_has_no_publisher_and_explicit_prepare_keeps_actual_owner(self):
        await self.primary_api();await self.actor_api(publish=False);owner=self.observer;before=self.counts()
        def prepare():
            with owner.lock.held():
                path=owner.store.path.with_name('phase-publication-lifecycle-input-'+self.run+'-actor.json')
                self.assertIsNone(PrivateFeatureState(path).read());self.assertIsNone(owner._publisher)
                publisher=owner.prepare_publication();self.assertIs(publisher,owner.prepare_publication())
                self.assertEqual([],publisher.state['records']);self.assertIsNone(publisher.state['pending'])
                self.assertIs(publisher.phase,owner.phase);self.assertIs(publisher.lock,owner.lock)
                self.assertIs(publisher.validate_original.__self__,owner)
                self.assertEqual([],self.phase_server.journal.snapshot(self.run)['entries'])
        await asyncio.to_thread(prepare);self.assertEqual(before,self.counts())
