"""Real Current7/parent/Restoration/address WAL; Qt/native/device remain MODELS.

The model selects the explicit normal-navigation target before installed SDK
birth, uses the original Source's actual seven-query endpoint for every cut,
and ordinary W3C/NativeInput Go To. No archived packet is retimed or relabeled.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,base64,hashlib,inspect,json,os,time,uuid
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
from urllib.parse import urlsplit
from adapters.ios import binding as binding_factory
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters import feature_observation,normal_input,normal_navigation,navigation_state
from ios.adapters.lifecycle_current_archive import LifecycleCurrentArchive
from ios.adapters.lifecycle_current_stream import LifecycleCurrentStream
from ios.adapters.lifecycle_restoration import LifecycleRestoration
from ios.adapters.lifecycle_originals import IOSLifecycleSources
from ios.adapters.lifecycle_editors import LifecycleEditors
from ios.adapters.lifecycle_editor_history import LifecycleEditorHistory
from ios.adapters.lifecycle_navigation_owner import LifecycleNavigationOwner
from ios.adapters.lifecycle_input_owner import LifecycleInputOwner
from ios.adapters.navigation_address_inputs import NavigationAddressInputs
from ios.adapters.script_runtime import IOSScriptRuntime
from ios.self_tests.test_ios_navigation_address_inputs import RetainedBoundary
from ios.self_tests import test_ios_lifecycle_world_attempt as attempt_fixture,test_ios_lifecycle_editors as editor_fixture
from test_original_lifecycle_current_parent_models import OriginalLifecycleCurrentParentModels

AUTHORITY='lifecycle-restoration-model.invalid'
ORIGIN='hifi://'+AUTHORITY
BASELINE=ORIGIN+'/0,0,0/0,0,0,1'
PROFILE=dict(contractVersion=1,profile=normal_navigation.PROFILE,sceneUrl='http://controlled.test:18080/owned/scene.json')


class LifecycleRestorationConnectedModels(OriginalLifecycleCurrentParentModels):
    async def asyncSetUp(self):
        create=binding_factory.create_adapter;old_touch=attempt_fixture.TouchBoundary;old_editor=attempt_fixture.EditorDomain
        editor_class=editor_fixture.LifecycleEditors
        def configured(args,base):
            # The explicit SDK model's target is selected BEFORE Base's first
            # canonical state/fingerprint exists. No admitted binding is edited.
            producer=inspect.getclosurevars(base.__init__).nonlocals['test']
            producer.target['normalNavigation']=deepcopy(PROFILE)
            producer.target['nativeUiObservation']=dict(kind='uikit-documents',version=1)
            return create(args,base)
        class RestorationTouch(old_touch):
            def __init__(self,*a,**kw):
                super().__init__(*a,**kw);self.model_orientation=[0.,0.,0.,1.]
            def decorate(self,value):
                super().decorate(value);value['source']['domain']['addressSha256']=hashlib.sha256(ORIGIN.encode()).hexdigest()
                value['source']['avatar']['orientation']=deepcopy(self.model_orientation)
        class WholeEditorDomain(old_editor):
            def apply(self,control,command):
                if control=='tablet.close':
                    self.effect_count+=1;self.route='closed';return
                return super().apply(control,command)
        def whole_editors(*args,**kwargs):return editor_class(*args,**dict(kwargs,whole=True))
        with patch.object(binding_factory,'create_adapter',side_effect=configured),patch.object(attempt_fixture,'TouchBoundary',RestorationTouch),\
                patch.object(attempt_fixture,'EditorDomain',WholeEditorDomain),patch.object(editor_fixture,'LifecycleEditors',side_effect=whole_editors):
            await super().asyncSetUp()
        # Actual owned close input and its complete immutable editor history;
        # never normalize tabletShown or a saved source packet in the model.
        self.normal.d.flow.close_tablet();self.assertEqual('closed',self.normal.d.route)

        outer=self
        class Address(RetainedBoundary):
            def native_epoch(self):return outer.normal.native.stamp()['epochMs']
            def host_epoch(self):return outer.modeled_epoch()
            def observed(self):
                value=super().observed();value['elapsedMs']=outer.normal.native.tick;return value
            def post(self,request,timeout):
                response=super().post(request,timeout)
                outer.normal.native.b.sequence=self.sequence_native
                return response
            def arrive(self,url):
                # Ordinary actual Go input is the ONLY modeled cause of this
                # physics change. Parse its literal native pose, not an expected
                # baseline position copied from a restoration assertion.
                parts=urlsplit(url);coordinates,rotation=parts.path.strip('/').split('/')
                self.current=url;point=[float(v)for v in coordinates.split(',')]
                outer.normal.boundary.position=point
                outer.normal.boundary.model_orientation=[float(v)for v in rotation.split(',')]
        self.address=Address();self.address.sequence_native=self.normal.native.b.sequence
        self.address.native_boundary.instance=self.normal.native.b.instance
        self.address.current=BASELINE;self.address.history=[BASELINE];self.address.cursor=0
        self.navigation_sequence=0;self.navigation_queries=[];self.navigation_fault=None;self.after_fault=None
        previous_call=self.normal.client.call
        def call(method,path,body=None):
            selected=path.endswith('/elements')and type(body)is dict and body.get('value')in self.address.MAPPING
            selected=selected or '/element/n' in path
            return self.address.call(method,path,body)if selected else previous_call(method,path,body)
        self.normal.client.call=call
        previous_post=feature_observation.post_request.side_effect
        def post(request,timeout):
            query=json.loads(request.data)
            if query.get('action')!=navigation_state.ACTION:return previous_post(request,timeout)
            self.navigation_queries.append(deepcopy(query));self.navigation_sequence+=1
            before=self.normal.native.stamp();position=deepcopy(self.normal.boundary.position)
            orientation=deepcopy(self.normal.boundary.model_orientation)
            scene_clock=self.normal.native.stamp()
            scene=dict(sceneLoadVersion=1,commandId=query['commandId'],runId=self.run,instance='7'*32,
                sequence=self.navigation_sequence,processId=42,capturedEpochMs=scene_clock['epochMs'],
                currentGeneration=0,pendingLeases=0,complete=True,requests=[])
            after=self.normal.native.stamp();url=self.address.current
            if self.navigation_fault=='foreign-authority':url=url.replace(AUTHORITY,'foreign-model.invalid')
            packet=dict(iosNavigationStateVersion=1,requestId=query['commandId'],runId=self.run,instance='6'*32,
                sequence=self.navigation_sequence,processId=42,clockDomain='native-main-navigation',clockBefore=before,clockAfter=after,
                source=dict(foreground=True,sceneUrl=url,domain=dict(handlerConnected=True,serverless=False,protocol='hifi'),
                    avatar=dict(feetPosition=position,orientation=orientation,velocity=[0.,0.,0.],inAir=False,flying=False,modelScale=1.),
                    view=dict(position=[position[0],position[1]+1.6,position[2]],rotation=orientation,mode='first person',
                        fieldOfViewDegrees=60,aspectRatio=1.5,perspective=True),markers=[],absentMarkerIds=list(navigation_state.MARKER_IDS),sceneLoads=scene))
            self.normal.raw[navigation_state.FILE]=json.dumps(packet);raw=json.dumps(query).encode()
            class Response:
                status=200
                def __enter__(self):return self
                def __exit__(self,*_):return False
                def read(self,limit):return raw[:limit]
            return Response()
        self.enterContext(patch.object(feature_observation,'post_request',side_effect=post))
        # This is the ordinary NativeInput SDK producer selected before its
        # first capture. It shares the actual process/UI instance and sequence
        # with Current7, while native lifecycle fields stay independently read.
        self.enterContext(patch.object(normal_input,'urlopen',self.address.post))
        self.restoration=None;self.restoration_stream=None

    def counts(self):
        return dict(currentQueries=len(self.current_queries),navigationQueries=len(self.navigation_queries),
            ordinaryInputs=len(self.address.inputs),nativeInputs=len(self.address.native_boundary.requests),
            sourceFrames=len(self.ops._lifecycle_current.get('primary').frames)if 'primary'in self.ops._lifecycle_current else 0)

    def new_editors(self,source,lock,root):
        native_boundary=self.address.native_boundary;native_boundary.target=source['target']
        def execute(session,operation,arguments):
            self.assertEqual(source['session'],session);self.assertEqual('mobile: pullFile',operation)
            expected='@'+source['target']['appId']+':documents/'+source['target']['testBuild']['resultsDirectory']+'/ios-normal-ui-request-result.json'
            self.assertEqual(expected,arguments['remotePath'])
            return base64.b64encode(json.dumps(native_boundary.receipt).encode()).decode()
        native_boundary.execute=execute
        source['native']=normal_input.NativeInput(native_boundary,source['session'],source['target'],native_boundary.process,
            native_epoch_ms=self.address.native_epoch,monotonic=time.monotonic,sleep=time.sleep)
        originals=IOSLifecycleSources(source,self.run,epoch_ms=self.modeled_epoch,monotonic=time.monotonic)
        owners=[];readers=[]
        for owner_type,reader_name in ((LifecycleNavigationOwner,'lifecycle_navigation_inputs'),(LifecycleInputOwner,'lifecycle_inputs')):
            owners.append(owner_type(PrivateFeatureState(root/owner_type.store_name('primary')),lock,self.binding,self.run,'primary',source['native'],source['check']))
            readers.append(getattr(source['observer'],reader_name)(clock_source=source['clock_source']))
        history=LifecycleEditorHistory(PrivateFeatureState(root/'lifecycle-editor-owner.json'),self.binding,self.run,lock,source['check'])
        return LifecycleEditors(PrivateFeatureState(root/'ios-lifecycle-editors-owner.json'),history,originals,
            owners[0],readers[0],owners[1],readers[1],epoch_ms=self.modeled_epoch,whole=True)

    async def restoration_api(self,operation='baseline'):
        def enter():
            runtime=IOSScriptRuntime(self.runtime.adapter);root=runtime.state_path('test-only').parent
            lock=ScriptSourceLock(root/'script-feature-sources.lock')
            with lock.held():
                stream_store=PrivateFeatureState(root/('ios-lifecycle-current-stream-primary-'+self.run+'.json'))
                if operation=='archive':
                    snapshot=stream_store.read();stream=LifecycleCurrentArchive(stream_store,snapshot,self.current_root,self.binding,self.run,'primary',lock)
                    scope=LifecycleRestoration.archived(PrivateFeatureState(root/'ios-lifecycle-restoration.json'),stream,self.binding,self.run,lock)
                    return deepcopy(scope.original(scope.state['after']))
                source=runtime._sources('test-only');editors=self.new_editors(source,lock,root)
                stream=LifecycleCurrentStream(stream_store,self.current_root,source,self.run,'primary',lock)
                scope=LifecycleRestoration(PrivateFeatureState(root/'ios-lifecycle-restoration.json'),editors,
                    epoch_ms=self.modeled_epoch,monotonic=time.monotonic,current_stream=stream)
                self.restoration,self.restoration_stream=scope,stream
                if operation=='reopen':return deepcopy(scope.state)
                if operation=='baseline':return scope.baseline(stream.current('b'*32)['current'])
                if operation=='restore':return scope.restore(ticket='b'*32)
                if operation=='code-fault':
                    function=NavigationAddressInputs.goto;code=function.__code__
                    function.__code__=code.replace(co_consts=(*code.co_consts,'explicit-foreign-address-code'))
                    try:
                        with self.assertRaisesRegex(RuntimeError,'receiver/code changed'):scope.restore(ticket='b'*32)
                    finally:function.__code__=code
                    return deepcopy(scope.state)
                raise AssertionError('Unknown Restoration model operation')
        return await asyncio.to_thread(enter)

    async def test_real_before_go_and_after_current_cuts_bind_ordinary_address_wal_and_pure_archived_replay(self):
        self.assertEqual(BASELINE,await self.restoration_api());baseline=deepcopy(self.restoration.state['baseline'])
        self.normal.boundary.position=[.7,0.,-.4];before=self.counts()
        self.assertEqual(dict(performed=True),await self.restoration_api('restore'));after=self.counts()
        self.assertEqual(14,after['currentQueries']-before['currentQueries']);self.assertEqual(1,self.address.inputs.count('PhoneAddressGoButton'))
        self.assertEqual([0.,0.,0.],self.normal.boundary.position);self.assertEqual(baseline,self.restoration.state['baseline'])
        commands=len(self.normal.d.f.f.f.commands)
        proof=await self.restoration_api('archive');saved=self.counts();self.assertEqual(proof,await self.restoration_api('archive'));self.assertEqual(saved,self.counts())
        self.assertEqual(commands,len(self.normal.d.f.f.f.commands))
        self.assertEqual(dict(performed=True),await self.restoration_api('restore'));self.assertEqual(saved,self.counts())
        self.assertEqual({'current','addressOwner','currentReference'},set(proof))
        self.assertGreater(proof['currentReference']['index'],baseline['index'])

    async def test_saved_baseline_and_after_original_return_loss_adopts_same_inode_without_query_or_go(self):
        original=OriginalFrameStore.write;lost=[]
        def drop(store,index,frame):
            value=original(store,index,frame)
            if store.namespace=='lifecycle-restoration'and index not in lost:
                lost.append(index);raise OSError('Declared loss AFTER saved Restoration original')
            return value
        with patch.object(OriginalFrameStore,'write',new=drop),self.assertRaises(OSError):await self.restoration_api()
        before=self.counts();saved=deepcopy(self.restoration.state['storage']['1']);path=self.restoration.files.path(saved);original_bytes=(path.stat().st_ino,path.read_bytes())
        reopened=await self.restoration_api('reopen');self.assertIsNotNone(reopened['baseline']);self.assertEqual(before,self.counts());self.assertEqual(original_bytes,(path.stat().st_ino,path.read_bytes()))
        self.normal.boundary.position=[.7,0.,-.4]
        with patch.object(OriginalFrameStore,'write',new=drop),self.assertRaises(OSError):await self.restoration_api('restore')
        before=self.counts();saved=deepcopy(self.restoration.state['storage']['2']);path=self.restoration.files.path(saved);original_bytes=(path.stat().st_ino,path.read_bytes())
        reopened=await self.restoration_api('reopen');self.assertIsNotNone(reopened['after']);self.assertEqual(before,self.counts());self.assertEqual(original_bytes,(path.stat().st_ino,path.read_bytes()))
        self.assertEqual(dict(performed=True),await self.restoration_api('restore'));self.assertEqual(before,self.counts());self.assertEqual([1,2],lost)

    async def test_opened_partial_original_and_unknown_namespace_file_refuse_before_new_current_or_go(self):
        actual=OriginalFrameStore.write
        def partial(store,index,frame):
            if store.namespace!='lifecycle-restoration':return actual(store,index,frame)
            callback=store.intent
            def opened(kind,value):
                result=callback(kind,value)
                if kind=='original'and value['phase']=='opened':raise OSError('Declared interruption with actual opened empty file')
                return result
            store.intent=opened
            try:return actual(store,index,frame)
            finally:store.intent=callback
        with patch.object(OriginalFrameStore,'write',new=partial),self.assertRaises(OSError):await self.restoration_api()
        before=self.counts();pending=deepcopy(self.restoration.state['storage']['1']);path=self.restoration.files.path(pending)
        saved=(path.stat().st_ino,path.read_bytes());self.assertEqual(b'',saved[1])
        with self.assertRaises(NativeUIError):await self.restoration_api('reopen')
        self.assertEqual(before,self.counts());self.assertEqual(saved,(path.stat().st_ino,path.read_bytes()))
        orphan=path.with_name(path.name.replace('-0001-','-0002-'));orphan.write_bytes(b'actual unowned file');orphan.chmod(0o600)
        with self.assertRaises(NativeUIError):await self.restoration_api('restore')
        self.assertEqual(before,self.counts());self.assertEqual(b'actual unowned file',orphan.read_bytes())

    async def test_same_address_receiver_code_mutation_refuses_before_current_or_ordinary_input(self):
        await self.restoration_api();before=self.counts();saved=self.restoration.store.path.read_bytes()
        state=await self.restoration_api('code-fault');self.assertIsNone(state['after']);self.assertEqual(before,self.counts());self.assertEqual(saved,self.restoration.store.path.read_bytes())

    async def test_fresh_foreign_navigation_authority_with_same_actual_pose_cannot_become_baseline(self):
        self.navigation_fault='foreign-authority'
        with self.assertRaises(NativeUIError):await self.restoration_api()
        self.assertEqual(1,len(self.navigation_queries));self.assertIsNone(self.restoration.state['baseline']);self.assertEqual([],self.address.inputs)

    async def test_acknowledged_but_ignored_go_cannot_reuse_before_cut_as_restored_after(self):
        await self.restoration_api();self.normal.boundary.position=[.7,0.,-.4];self.address.mutation='goto-ignored';before=self.counts()
        with self.assertRaises(NativeUIError):await self.restoration_api('restore')
        self.assertEqual(14,self.counts()['currentQueries']-before['currentQueries']);self.assertEqual(1,self.address.inputs.count('PhoneAddressGoButton'))
        self.assertIsNone(self.restoration.state['after']);self.assertEqual([.7,0.,-.4],self.normal.boundary.position)
        self.address.mutation='';before=self.counts()
        with self.assertRaises(NativeUIError):await self.restoration_api('restore')
        self.assertEqual(14,self.counts()['currentQueries']-before['currentQueries']);self.assertEqual(1,self.address.inputs.count('PhoneAddressGoButton'))
        self.assertIsNone(self.restoration.state['after'])

    async def test_foreign_original_owner_before_go_refuses_with_retained_baseline_and_no_requery(self):
        await self.restoration_api();before=self.counts();owner=self.ops.instance
        self.ops.instance='f'*32 if owner!='f'*32 else'e'*32
        try:
            with self.assertRaises((NativeUIError,RuntimeError)):await self.restoration_api('restore')
        finally:self.ops.instance=owner
        self.assertEqual(before,self.counts());self.assertIsNone(self.restoration.state['after']);self.assertEqual([],self.address.inputs)

    async def test_genuine_before_go_current_cannot_supply_after_even_when_all_its_bytes_and_membership_are_valid(self):
        await self.restoration_api();self.normal.boundary.position=[.7,0.,-.4]
        actual=OriginalFrameStore.write;substituted=[]
        def old_current(store,index,frame):
            if store.namespace=='lifecycle-restoration'and index==2:
                stream=self.restoration_stream;reference=deepcopy(stream.state['records'][-2])
                original=stream.record(reference)['current'];value=deepcopy(frame)
                # This is a newly written hostile PARENT carrier containing the
                # exact genuine pre-Go Current7 and acknowledged address WAL.
                # No native row, timestamp, membership or inode is altered.
                value.update(current=deepcopy(original),currentReference=reference)
                substituted.append(reference);return actual(store,index,value)
            return actual(store,index,frame)
        with patch.object(OriginalFrameStore,'write',new=old_current),self.assertRaises(NativeUIError):await self.restoration_api('restore')
        self.assertEqual(1,len(substituted));self.assertEqual(1,self.address.inputs.count('PhoneAddressGoButton'))
        self.assertIsNotNone(self.restoration.state['after']);before=self.counts()
        with self.assertRaises(NativeUIError):await self.restoration_api('reopen')
        self.assertEqual(before,self.counts());self.assertEqual(1,self.address.inputs.count('PhoneAddressGoButton'))
