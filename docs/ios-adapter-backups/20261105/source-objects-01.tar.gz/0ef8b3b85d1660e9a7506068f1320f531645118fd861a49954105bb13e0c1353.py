"""Retain one actual original fixture error; no changed source or rerun."""
from pathlib import Path
import json,hashlib
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(o,n,v):
 with(o/n).open('x')as s:json.dump(v,s,sort_keys=True,indent=2);s.write('\n')
C=B/'root-audio10-bootstrap5-ten-window-current1214-20261105'
assert sha(C/'freeze.json')=='10202c71cca4bc6a550eb1a3d94cdf74e6f8560782c4b317cc85f03404a021ab'
for n,r in load(C/'freeze.json')['files'].items():assert sha(C/n)==r['sha256']
t=load(C/'terminal.json');assert t['status']=='ROOT_AUDIO10_STOPPED_ON_ORIGINAL_FAILURE'and t['oldRootCount']==1214
assert t['allOldOriginalBodiesUnchanged']is t['allRecordedOriginalProcessesAndGroupsAbsent']is t['wholeOwnRoomsTwiceEqual']is True
assert len(t['completedGroups'])==1 and t['unrunGroups']==['audioReply'+format(n,'02d')for n in range(2,11)]
g=t['completedGroups'][0];assert g['group']=='audioReply01'and g['supervisorReturnCode']==1 and g['passed']is False and g['rootObservedAbsence']is True
h=Path(g['input']).parent;o=h.with_name(h.name+'-outer');c=h.with_name(h.name+'-censuses')
assert sha(h/'approved-inputs.json')==g['inputSha256']=='b7fc5387616f871d57da5d4eb83cbd5cee860d37ec9c9e79aeab1c33ece12dc6'
terminal=load(o/'terminal.json');q=load(c/'qualification.json');assert terminal==g['originalTerminal']and q==g['originalQualification']
assert terminal['status']==q['status']=='FAIL_OR_REFUSED'and terminal['childReturnCode']==1 and terminal['ownProcessesAbsent']is q['ownProcessesAbsent']is True
assert terminal['problems']==terminal['orphansRequiredKill']==[]and terminal['timedOut']is True and terminal['forcedKill']is False
for key in('allActualRuntimeOriginsEstablished','allSourceBinaryPinsEqual','zeroCaseChildBirthsEstablished','actualStdlibParentFDThreadDrain'):assert terminal[key]is True
report=load(h/'child-receipts/report.json');assert report['testsRun']is None and report['actualCaseReceipts']==1 and report['status']=='FAIL_OR_ERROR'and type(report['fatal'])is str and 'KeyboardInterrupt'in report['fatal']and report['secondary']==[]and report['cleanupEstablished']is True
assert terminal['actualOneCaseReceiptEstablished']is terminal['actualClassCleanupCustodyEstablished']is False
for key in('fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','allActualLoadedOriginsAccounted','allActualRuntimeOriginsEstablished'):assert report[key]is True
for key in('SDKExecutions','NodeExecutions','PythonExecutions','overteNativeQueries'):assert report[key]==0
restore=load(h/'child-receipts/actual-port-restoration.json');assert restore['count']==27 and restore['controlDescriptors']==restore['secondary']==[]
for key in('builtinsCioRestored','dupPortsRestored','restored','toolsRestored'):assert restore[key]is True
raw=h/'child-logs/stdout.log';text=raw.read_text();assert 'KeyboardInterrupt: Original fixed30-second Audio utility boundary'in text and 'FamilyOriginals'in text and 'self.assembled'in text and 'json/encoder.py'in text
absence=load(C/'actual-root-absence-audioReply01.json');assert absence['remainingSameGroupOrSession']==[]and absence['originalDrain']['remaining']==[]
for row in absence['recordedOriginals']:
 try:proc=Path('/proc',str(row['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(proc[proc.rfind(')')+2:].split()[19])!=row['startTicks']
ctx=load(B/'root-ios-current1214-after-tablet-first4-b7-local-unwind-negative-context-20261105/root-context.json');old=load(ctx['globalCustody']['baseline']['path'])
assert len(old)==1214 and load(C/'global-before.json')==load(C/'global-after-first.json')==load(C/'global-after-second.json')==old
assert load(C/'whole-first.json')==load(C/'whole-second.json')
roots=t['newOriginalRoots'];assert len(roots)==5 and str(h/'own-toys')in roots
refs={str(p):dict(path=str(p),sha256=sha(p))for root in map(Path,roots)for p in sorted(root.rglob('*'))if p.is_file()and not p.is_symlink()}
out=B/'root-audio10-b5-first-original-thirty-second-family-archive-timeout-negative-results-20261105';out.mkdir(mode=0o700)
put(out,'results.json',dict(status='ROOT_RETAINED_AUDIO10_B5_FIRST_ORIGINAL_THIRTY_SECOND_FAMILY_ARCHIVE_TIMEOUT',terminal=terminal,newOriginalRoots=roots,originalRootTerminal=t,originalReport=report,originalRestoration=restore,originalQualification=q,actualOriginalCasesExecuted=1,actualOriginalCasesPassed=0,originalCaseFailure=dict(path=str(raw),sha256=sha(raw),message='Actual original30-second boundary interrupted received.start during shared membership and retired microphone archive/proof traversal; stack location is not CPU attribution'),remainingNineOriginalCasesUnrun=True,cleanupEstablished=True,originalSuiteClassCleanupNotEstablished=True,originalStandardCaseReceiptNotEstablished=True,performanceCauseEstablished=False,finalDefinitionCheckDirectReceiptAvailable=False,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(out,'actual-receipt-references.json',refs);put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}));print(json.dumps(dict(freeze=sha(out/'freeze.json'),results=sha(out/'results.json'),references=len(refs))))
