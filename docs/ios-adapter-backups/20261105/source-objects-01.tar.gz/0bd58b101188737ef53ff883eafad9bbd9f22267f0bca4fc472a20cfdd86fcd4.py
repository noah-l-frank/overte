"""Closed reviewed native codec imports before any Audio admission/acquisition.

No owner, transport, SDK, observation, clock or validator is invoked here.
The namespace objects and all referenced values are fenced afresh by each
SemanticFence. This preparation returns no result or admission authority.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import builtins
import importlib
import types
from adapters.native_feature_observation import need

INSTALLATION_IMPORTERS=(builtins.__import__,importlib.import_module)
INSTALLATION_IMPORT_MODULE_CODE=importlib.import_module.__code__
need(type(INSTALLATION_IMPORTERS[0])is types.BuiltinFunctionType
    and INSTALLATION_IMPORTERS[0].__self__ is builtins
    and INSTALLATION_IMPORTERS[0].__name__=='__import__')

MODULES=(
    'adapters.native_account_observation','adapters.native_animation_caller',
    'adapters.native_animation_history','adapters.native_feature_observation',
    'adapters.native_script_loads','adapters.native_script_membership',
    'adapters.native_script_observation','adapters.normal_ui',
    'adapters.pure_original_validation','adapters.recorded_preview_history',
    'feature_journeys.contract','feature_journeys.fixtures',
    'feature_journeys.scenarios','voice_peer.voice_signal')


def function_builtins(function,*,literal_import=False):
    """Actual frame lookup namespace, not the module named builtins by alias."""
    namespace=function.__builtins__;binding=function.__globals__.get('__builtins__')
    need(type(namespace)is dict and (binding is namespace or
        type(binding)is types.ModuleType and vars(binding)is namespace))
    need(importlib.import_module is INSTALLATION_IMPORTERS[1]
        and importlib.import_module.__code__ is INSTALLATION_IMPORT_MODULE_CODE)
    if literal_import:need(namespace.get('__import__')is INSTALLATION_IMPORTERS[0])
    return namespace,binding


def prepare():
    # Literal roots; their complete top-level dependency closure is recorded
    # in IMPORT-CLOSURE.json. Do not replace this with a dynamic module loader.
    function_builtins(prepare,literal_import=True)
    import adapters.native_account_observation
    import adapters.native_animation_history
    import adapters.recorded_preview_history
    import warnings

