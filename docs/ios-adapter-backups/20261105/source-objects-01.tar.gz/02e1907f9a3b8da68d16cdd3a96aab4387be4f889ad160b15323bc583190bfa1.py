"""Literal C25 original IO/FD/process helpers; no corpus discovery."""
from pathlib import Path
import hashlib,json,os,stat
FIELDS=('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
_ORIGINAL_SAVE_PORTS=(os.open,os.write,os.fsync,os.close)

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path,value):
    raw=(json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
    original_open,original_write,original_sync,original_close=_ORIGINAL_SAVE_PORTS
    descriptor=original_open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_CLOEXEC',0),0o600)
    try:
        pending=memoryview(raw)
        while pending:
            count=original_write(descriptor,pending);assert count>0;pending=pending[count:]
        original_sync(descriptor)
    finally:original_close(descriptor)

def pin(path):
    first=path.lstat();value={key:getattr(first,key) for key in FIELDS}
    if stat.S_ISREG(first.st_mode):value['sha256']=sha(path)
    elif stat.S_ISLNK(first.st_mode):value['target']=str(path.readlink())
    else:assert stat.S_ISDIR(first.st_mode),str(path)
    second=path.lstat();assert all(getattr(first,k)==getattr(second,k) for k in FIELDS),str(path)
    return value

def proc(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,state=fields[0],parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))

def processes(session):
    values=[]
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            row=proc(int(path.name))
            if row is not None and (row['session']==session or row['processGroup']==session):values.append(row)
    return values

def fds(pid):
    result={};root=Path('/proc',str(pid),'fd')
    try:paths=list(root.iterdir())
    except FileNotFoundError:return result
    for path in paths:
        try:target=os.readlink(path)
        except (FileNotFoundError,PermissionError):continue
        result[path.name]=target
    return result

def census(root):
    assert root.is_dir() and root.resolve()==root
    return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
