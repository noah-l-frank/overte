"""Compare complete closed ASCII contexts; every other input stays literal.

No cache, retained verdict, input admission or context validation is added.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.script_feature.history import same

_FIELDS=frozenset(('sourceRevision','artifactSha256','processIdentity','sessionId','generation','targetFingerprint'))
_TEXT=('sourceRevision','artifactSha256','processIdentity','sessionId','targetFingerprint')
_MAX_GENERATION=2**53-1


def closed(value):
    return (type(value) is dict and len(value)==6
        and all(type(key) is str for key in value) and value.keys()==_FIELDS
        and all(type(value[key]) is str and value[key].isascii() for key in _TEXT)
        and type(value['generation']) is int and 0<=value['generation']<=_MAX_GENERATION)


def same_context(left,right):
    if closed(left) and closed(right):return left==right
    # Canonical JSON equates astral text with its equivalent surrogate pair;
    # Python equality alone does not preserve that Unicode behavior.
    return same(left,right)
