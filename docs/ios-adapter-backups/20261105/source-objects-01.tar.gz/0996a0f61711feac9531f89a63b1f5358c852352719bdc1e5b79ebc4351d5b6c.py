"""Existing Combined Photos flow with independent lower PNG producers.

Native/Qt/SDK/OS/render/auth are explicit models. Existing normal input,
Node callbacks, upload/Photos/share/cleanup owners and real files are unchanged.
No returned PNG/result/phase packet is edited into a wanted observation.
"""
from contextlib import contextmanager,ExitStack
from copy import deepcopy
from io import BytesIO
import base64,hashlib,json,uuid
from types import SimpleNamespace
from unittest.mock import patch
from PIL import Image
from adapters.native_feature_observation import NativeFeatureObservation,need
from adapters.normal_feature_state import PrivateFeatureState
from feature_journeys.witness import Client,Journal
from ios.adapters import feature_observation,snapshot_provenance,snapshot_actor_pixels
from ios.adapters.feature_observation import FeatureObservation
from ios.adapters.snapshot_actor_pixel_runtime import IOSSnapshotActorPixelRuntime
from ios.adapters.snapshot_capture_phase_temporal_png_join import retained_capture_phase_temporal_pixel_join
from ios.adapters.snapshot_capture_clock import operation
from ios.adapters.snapshot_temporal_png_photos_join import SnapshotTemporalPNGPhotosJoin
from ios.adapters.snapshot_page_return_owner import SnapshotPageReturnOwner
from ios.adapters.snapshot_upload_owner import IOSSnapshotUploadOwner
from ios.adapters.snapshot_upload_backend_owner import IOSSnapshotUploadBackendOwner
from ios.adapters.snapshot_photos_archive import SnapshotPhotosArchive
from ios.adapters.snapshot_combined_journey import SnapshotCombinedJourney
from ios.adapters.snapshot_combined_photos_journey import SnapshotCombinedPhotosJourney
from ios.self_tests import snapshot_page_return_domain
from ios.self_tests.snapshot_page_return_domain import PageJourneyDomain
from ios.self_tests.snapshot_combined_upload_return_domain import CombinedUploadJourneyDomain
from ios.self_tests.snapshot_combined_photos_return_domain import CombinedPhotosReturnFlow
from ios.self_tests.snapshot_scene_domain import SceneActorDomain,model_scene,model_camera
from ios.self_tests.snapshot_actor_pixel_domain import DeclaredActorFrame,DeclaredActorReadback
from ios.self_tests.snapshot_pending_domain import RUN,REAL_TIME,REAL_MONOTONIC


class CapturePNGJourneyDomain(CombinedUploadJourneyDomain):
    def __init__(self,case):
        super().__init__(case)
        self.provenance_rows={};self.provenance_queries=[];self.provenance_sequence=0;self.frame_sequence=0
        self.provenance_instance=uuid.uuid4().hex;self.recorded={};self.scene_inputs=model_scene();self.camera=model_camera()
        # Independent fixed lower Primary raster, before any normal input.
        with Image.new('RGBA',(128,128))as image:
            for y in range(128):
                for x in range(128):image.putpixel((x,y),((x*2)%256,(y*2)%256,((x//16+y//16)%2)*200+20,255))
            encoded=BytesIO();image.save(encoded,format='PNG');self.f.bytes=encoded.getvalue()
        begin,finish=self.native.begin,self.native.finish
        def original_begin(request='snap_1700000000000_1'):
            cap,identity=begin(request);self.frame_sequence+=1
            self.recorded[identity]=dict(snapshotFrameProvenanceVersion=2,frameInstance=uuid.uuid4().hex,frameIndex=self.frame_sequence,
                processId=int(self.ctx.binding['processIdentity']),pipeline='forward-primary-mono',recordedEpochMs=self.epoch(),
                transformSlot=0,viewport=[0,0,128,128],worldFromCamera=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],
                camera=deepcopy(self.camera),backend='opengl',scene=deepcopy(self.scene_inputs))
            return cap,identity
        def original_finish(cap,identity):
            # Read this producer's actual file callback, never Actor pixels.
            raw=self.f.f.h.path.read_bytes()
            with Image.open(BytesIO(raw))as image:
                image.load();extent=list(image.size);rgba=image.convert('RGBA').tobytes()
            need(extent==[128,128]);row=deepcopy(self.recorded[identity])
            row.update(callbackEpochMs=self.epoch(),readback=dict(sourceExtent=extent,rectBottomLeft=[0,0,*extent],imageExtent=extent,
                pixelFormat='rgba8-top-left',pixelSha256=hashlib.sha256(rgba).hexdigest(),readEpochMs=self.epoch()))
            native=self.native.captures[identity][1]
            self.provenance_rows[identity]=dict(captureInstance=identity,requestId=native['requestId'],frame=row)
            return finish(cap,identity)
        self.native.begin,self.native.finish=original_begin,original_finish
    def client(self):
        # A new phase response is sampled at this actual model query event.
        # Advance only the lower producer's current clock before its original
        # request creates a new packet. Never edit an earlier phase response,
        # activation ledger, Actor frame, native packet or saved publication.
        client=super().client();request=client.request
        def sample_phase(path,value=None,method=None,*,phase_nonce=None,**kwargs):
            need(path=='/runs/'+RUN+'/phase'and value is None and method in(None,'GET'))
            self.advance()
            return request(path,value,method,phase_nonce=phase_nonce,**kwargs)
        client.request=sample_phase
        return client
    def post(self,request,timeout):
        query=json.loads(request.data)
        if query.get('action')!=snapshot_provenance.ACTION:return super().post(request,timeout)
        need(timeout==5);snapshot_provenance.command(query);self.provenance_queries.append(deepcopy(query));self.provenance_sequence+=1
        value=dict(iosSnapshotProvenanceVersion=1,requestId=query['commandId'],runId=query['runId'],instance=self.provenance_instance,
            sequence=self.provenance_sequence,processId=int(self.ctx.binding['processIdentity']),clockDomain='native-main-snapshot-provenance',
            clockBefore=self.clock(),clockAfter=self.clock(),source=dict(complete=True,captures=[deepcopy(self.provenance_rows[k])for k in sorted(self.provenance_rows)]))
        self.raws[snapshot_provenance.FILE]=json.dumps(value,indent=1)+'\n';self.ctx.files.echo=json.dumps(query).encode();return self.ctx.files


class IndependentPhotosActor:
    def __init__(self,case,page):
        self.page=page;self.actor=SceneActorDomain(case,page);a=self.actor;main=page.capture
        a.ctx.feature=FeatureObservation(a.ctx.files,a.binding['sessionId'],a.ctx.files.target,a.ctx.files.process,
            epoch_ms=a.clock,monotonic=a.monotonic,sleep=main.sleep)
        # A separate fixed Actor raster, not copied from the Primary file.
        rgba=bytes(c for y in range(128)for x in range(128)for c in((x*2)%256,(y*2)%256,((x//16+y//16)%2)*200+20,255))
        self.renderer=DeclaredActorReadback(DeclaredActorFrame(a.frame,rgba));self.render_events=[];self.raw=None;self.queries=[];self.sequence=0
        self.journal=Journal(clock=main.epoch,snapshot_actor_pixels=True)
        with patch('feature_journeys.witness.secrets.token_hex',return_value=RUN):need(self.journal.register('snapshots')==RUN)
        domain=self
        class Transport(Client):
            def request(self,path,value=None,method=None,*,phase_nonce=None,**kwargs):
                if path=='/runs/'+RUN+'/phase':return main.client().request(path,value,method,phase_nonce=phase_nonce,**kwargs)
                if path=='/runs/'+RUN:need(value is None);return domain.journal.snapshot(RUN)
                need(path=='/runs/'+RUN+'/samples'and self.token=='a'*64 and type(value)is dict);domain.journal.publish(RUN,value);return {}
        self.client=Transport('https://controlled.invalid/feature-fixture/v1','a'*64,monotonic=REAL_MONOTONIC,sleep=main.sleep)
        execute=a.ctx.files.execute
        def pull(session,operation,values):
            if values['remotePath'].endswith('/'+snapshot_actor_pixels.FILE):
                need(operation=='mobile: pullFile'and self.raw is not None);return base64.b64encode(self.raw.encode()).decode()
            return execute(session,operation,values)
        a.ctx.files.execute=pull;prior=feature_observation.post_request
        def post(request,timeout):
            query=json.loads(request.data)
            if query.get('action')!=snapshot_actor_pixels.ACTION:return prior(request,timeout)
            need(timeout==5);snapshot_actor_pixels.command(query);self.sequence+=1;self.queries.append(deepcopy(query))
            clock=dict(epochMs=a.clock(),monotonicMs=a.clock()-1700000000000+1000)
            body=dict(iosSnapshotActorPixelsVersion=1,requestId=query['commandId'],runId=query['runId'],instance='e'*32,sequence=self.sequence,
                processId=42,clockDomain='native-main-snapshot-actor-pixels',clockBefore=dict(clock),clockAfter=dict(clock),source=self.renderer.original())
            self.raw=json.dumps(body,indent=1)+'\n';a.ctx.files.echo=json.dumps(query).encode();return a.ctx.files
        actual=patch.object(feature_observation,'post_request',post);actual.start();case.addCleanup(actual.stop)
        class ActorRuntime(IOSSnapshotActorPixelRuntime):
            def _sources(self,_selector):
                native=NativeFeatureObservation(a.ctx.native.send,a.ctx.native.original,a.clock,a.ctx.native.guard,42,ios=True,monotonic=a.monotonic,sleep=main.sleep)
                return dict(binding=deepcopy(a.binding),check=lambda:a.ctx.good,observer=a.ctx.feature,clock_source=native)
        self.runtime=ActorRuntime(SimpleNamespace(state_path=lambda _selector:a.ctx.root/'session.json',_candidate_guard=lambda:True,_binding=lambda:None))
    def render(self):
        a=self.actor;held=self.renderer.current;frame=deepcopy(held.inputs)
        frame.update(frameInstance=uuid.uuid4().hex,frameIndex=frame['frameIndex']+1,recordedEpochMs=a.clock(),consumedEpochMs=a.clock())
        self.renderer.current=DeclaredActorFrame(frame,held.rgba);self.renderer.consume(a.clock());self.render_events.append(frame['frameInstance'])
    def pixels(self):
        return self.runtime.actor_pixel_publications('actor',RUN,self.client,epoch_ms=lambda:int(REAL_TIME()*1000),monotonic=REAL_MONOTONIC)


class CapturePNGPhotosPage(PageJourneyDomain):
    combined=True
    def __init__(self,case,*,emit_after=True,before_after_prepare=False):
        with patch.object(snapshot_page_return_domain,'SnapshotJourneyFilesDomain',CapturePNGJourneyDomain):super().__init__(case)
        self.pixel=IndependentPhotosActor(case,self);self.emit_after=emit_after;self.before_after_prepare=before_after_prepare;self.monotonic=REAL_MONOTONIC
    def prepare_png(self):
        # Preserve the genuine old page-a and Pending-cancel-f path exactly.
        with self.owner()as page:opened=page.open('a'*32)
        main=self.capture;main.advance();main.activations.append(dict(sequence=2,ticket='f'*32,activatedEpochMs=main.epoch(),stimulus=dict(verb='capture-cancel',inputs=dict(mode='animated',format='png'))))
        with main.owner()as pending_owner:pending=pending_owner.cancel('f'*32)
        main.advance();main.activations.append(dict(sequence=3,ticket='c'*32,activatedEpochMs=main.epoch(),stimulus=dict(verb='capture',inputs=dict(mode='still',format='png'))))
        self.pixel.journal.activate(RUN,'c'*32,'capture',dict(mode='still',format='png'))
        with main.capture_owner()as capture:
            with self.pixel.pixels()as actor:
                captured,phase=self.capture_png(capture,actor)
        return dict(page=opened,pending=pending,capture=captured,phase=phase)

    @operation
    def capture_png(self,capture,actor):
        # One existing shared25-second budget across the full prefix, including
        # prepare. Splitting prepare out of capture never resets its deadline.
        if self.before_after_prepare:capture.prepare('c'*32)
        self.pixel.render();actor.observe_original(1,'c'*32)
        if not self.before_after_prepare:capture.prepare('c'*32)
        captured=capture.capture('c'*32)
        capture.provenance();rows=[row for row in capture.state['slots']if row['kind']=='provenance'];need(len(rows)==1)
        self.provenance_index=rows[0]['index'];self.actors=actor.actors
        if self.emit_after:
            # Independent lower render EVENT after provenance; no getter update.
            self.pixel.render();actor.observe_original(2,'c'*32)
        return captured,deepcopy(capture.state['phaseOriginal'])


class CapturePNGPhotosReturnFlow(CombinedPhotosReturnFlow):
    emit_after=True
    before_after_prepare=False
    def prepare_main(self,case):
        self.page=CapturePNGPhotosPage(case,emit_after=self.emit_after,before_after_prepare=self.before_after_prepare)
        prepared=self.page.prepare_png();main=self.page.capture
        main.runtime._sources=self.page.runtime._sources
        with main.capture_owner()as capture:self.name_restoration=capture.restore_name_before_destination()
        self.prepared_phase=prepared['phase']
        return main,deepcopy(main.activations),prepared['phase']['createdEpochMs']
    @contextmanager
    def original_join(self,returned):
        photo=self.photos;actors=self.page.actors
        locks=(returned.lock,returned.end.share.archive_lock,photo.helper_lock,actors.lock)
        need(len({lock.path for lock in locks})==4)
        with ExitStack()as held:
            for lock in sorted(locks,key=lambda lock:str(lock.path)):held.enter_context(lock.held())
            archived=SnapshotPageReturnOwner.history(returned.page,returned.files,returned.end,combined=True)
            native=IOSSnapshotUploadOwner.history(PrivateFeatureState(archived.root/'snapshot-upload-owner.json'),archived.lock,archived.binding,archived.run,archived.fixture_url,combined=True,frontend_http=True,frontend_caller=True)
            backend=IOSSnapshotUploadBackendOwner.history(native,domain_policy=self.main.domain_policy)
            photos=SnapshotPhotosArchive.history(PrivateFeatureState(archived.root/'photos-save-owner.json'),archived.lock,photo.helper_lock,archived.binding,photo.helper_binding,archived.run,archived.fixture_url,photo.helper.ipa,photo.admission_store,archived.end.share.primary.target['appId'])
            destination=SnapshotCombinedPhotosJourney(SnapshotCombinedJourney(archived,backend),photos)
            temporal=retained_capture_phase_temporal_pixel_join(archived.files.capture,actors,self.page.provenance_index,1,2)
            yield SnapshotTemporalPNGPhotosJoin(destination,temporal)
