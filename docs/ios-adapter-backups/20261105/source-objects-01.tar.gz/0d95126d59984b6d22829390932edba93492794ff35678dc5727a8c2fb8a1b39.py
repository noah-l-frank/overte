"""Optional held-input path with an independent Actor before and after.

The existing caller owns Primary and its ordinary Up/uncertain cleanup. This
operation creates no factory/tunnel/SDK, changes no cap and cannot restore a
lost worker. A failure keeps all earlier originals and never repeats input.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import inspect
from adapters.native_feature_observation import need
from ios.adapters.lifecycle_world_hold import LifecycleWorldHold
from ios.adapters.snapshot_capture_clock import Budget
from ios.adapters.lifecycle_received_actor_world import IOSLifecycleReceivedActorRuntime
from ios.adapters.lifecycle_actor_publication import LifecycleActorCanonicalPublication
from ios.adapters.lifecycle_received_actor_join import compare_received_held_originals


async def observe_held_with_canonical_received_actor(primary,runtime,selector,client,*,indices=(1,2)):
    need(type(primary)is LifecycleWorldHold and type(runtime)is IOSLifecycleReceivedActorRuntime)
    budget=Budget(primary.monotonic);budget.check()
    primary.bound();need(primary.state['phase']=='new'and primary.lease is None)
    # The budget object is checked across awaits, without installing its
    # ContextVar into the born worker: ordinary Up is not a stale API guard.
    # The actual existing Primary lock remains caller-owned throughout. The
    # Actor factory acquires its own different original SDK/source lock.
    with runtime.actor_world_originals(selector,primary.run,indices,client,
            epoch_ms=primary.epoch_ms,monotonic=primary.monotonic)as actors:
        budget.check();before,after=actors
        need(before.lock.path!=primary.history.lock.path
            and before.binding['targetFingerprint']!=primary.binding['targetFingerprint'])
        publication=LifecycleActorCanonicalPublication(actors,client)
        ticket=before.phase.read()['ticket'];budget.check();before.acquire(ticket);budget.check()
        publication.publish(before.index);budget.check()
        # Once invoked, any uncertain ordinary Down/move remains owned by the
        # existing Primary owner; this function has no second input path.
        await primary.act();budget.check()
        measured=primary.observe()
        if inspect.isawaitable(measured):measured=await measured
        budget.check();need(primary.state['held']is not None)
        after.acquire(ticket);budget.check()
        publication.publish(after.index);budget.check()
        proof=compare_received_held_originals(primary,before,after);budget.check()
        proof['genuineControllerCallOrderEstablished']=True
        proof['hostOrder']='Actor-before-return / original-Primary-act+held-observe-return / Actor-after-return'
        proof['originalPrimaryReleaseStillRequired']=True
        return proof
