"""Code-only prepared-plan validation; importing performs no census."""
from pathlib import Path
import hashlib,json,os,stat
SOURCE=Path(__file__).resolve().parent
REPO=SOURCE.parent.parent
PROPOSAL=REPO/'.ios-host-tmp/chat-offline-send-no-replay-source1-private-20261104'
PROPOSAL_SHA='b1df990cbb9187fe6982cafe0a9e4065283eb541c7f30860162afd624a390f9b'
REVIEWED_HEAD='06ff22857d8c8298390e00cd5df1c848a1d9c6a5'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def meta(info):
    return dict(device=info.st_dev, inode=info.st_ino, mode=info.st_mode,
        uid=info.st_uid, gid=info.st_gid, nlink=info.st_nlink,
        bytes=info.st_size, mtimeNs=info.st_mtime_ns, ctimeNs=info.st_ctime_ns)


def pin(path):
    path = Path(path)
    before = path.lstat()
    assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        assert meta(os.fstat(fd)) == meta(before)
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            raw = stream.read()
        assert meta(os.fstat(fd)) == meta(before) == meta(path.lstat())
        assert len(raw) == before.st_size
    finally:
        os.close(fd)
    return dict(meta(before), sha256=hashlib.sha256(raw).hexdigest())


def census(root):
    """Exact existing-tree census. Called only in a later Root window."""
    root = Path(root)
    result = {}
    def visit(path):
        info = path.lstat()
        row = meta(info)
        if stat.S_ISDIR(info.st_mode):
            assert not path.is_symlink()
            with os.scandir(path) as stream:
                names = sorted(entry.name for entry in stream)
            row['namespace'] = names
            for name in names:
                visit(path / name)
        else:
            row = pin(path)
        assert meta(path.lstat()) == meta(info)
        result[str(path.relative_to(root))] = row
    visit(root)
    return result


def load(path):
    return json.loads(Path(path).read_text())


def head():
    git = Path((REPO / '.git').read_text().strip().split('gitdir: ', 1)[1])
    if not git.is_absolute():
        git = REPO / git
    common = (git / (git / 'commondir').read_text().strip()).resolve(strict=True)
    selected = (git / 'HEAD').read_text().strip()
    assert selected.startswith('ref: ')
    ref = selected[5:]
    for base in (git, common):
        if (base / ref).is_file():
            return (base / ref).read_text().strip()
    for line in (common / 'packed-refs').read_text().splitlines():
        if line and not line.startswith(('#', '^')):
            value, name = line.split(' ', 1)
            if name == ref:
                return value
    raise AssertionError('Reviewed checkout HEAD unavailable')


def fds():
    result = {}
    for path in Path('/proc/self/fd').iterdir():
        try:
            info = path.stat()
            result[path.name] = dict(target=os.readlink(path), device=info.st_dev,
                inode=info.st_ino, mode=info.st_mode)
        except (FileNotFoundError, ProcessLookupError):
            pass
    return result


def proc(pid):
    try:
        text = (Path('/proc') / str(pid) / 'stat').read_text()
    except (FileNotFoundError, ProcessLookupError):
        return None
    fields = text[text.rfind(')') + 2:].split()
    return dict(pid=int(text[:text.index('(')].strip()), parent=int(fields[1]),
        group=int(fields[2]), session=int(fields[3]), startTicks=int(fields[19]))


def validate(path, expected_plan_sha, expected_source_sha, expected_head):
    assert expected_head == REVIEWED_HEAD == head()
    assert sha(path) == expected_plan_sha
    assert sha(SOURCE / 'source-freeze.json') == expected_source_sha
    frozen = load(SOURCE / 'source-freeze.json')
    for name, row in frozen['files'].items():
        assert sha(SOURCE / name) == row['sha256']
    assert sha(PROPOSAL / 'freeze.json') == PROPOSAL_SHA
    proposal = load(PROPOSAL / 'freeze.json')
    for name, row in proposal['files'].items():
        assert sha(PROPOSAL / name) == (row if type(row) is str else row['sha256'])
    selection = load(PROPOSAL / 'INITIAL-SELECTION.json')
    plan = load(path)
    assert plan['status'] == 'ROOT_REVIEWED_PREPARED_UNRUN'
    assert plan['head'] == expected_head and plan['controllerSourceFreeze'] == expected_source_sha
    assert plan['proposalFreeze'] == PROPOSAL_SHA and plan['cases'] == selection['ids']
    assert len(plan['cases']) == len(set(plan['cases'])) == 4
    assert plan['seconds'] == selection['outerWallSeconds'] == 180 and plan['graceSeconds'] == 5
    assert plan['maxNodePerCase'] == 1 and plan['maxLiveNodes'] == 1 and plan['maxTotalNodes'] == 4
    assert plan['TDsPerExecutedCase'] == 3 and plan['loopbacksAllowed'] is False
    assert plan['source15Or17Adopted'] is False and plan['wholeQualified'] is False
    pins = plan['physicalPins']
    for name, row in pins.items():
        assert pin(name) == row
    for directory, leaf in ((SOURCE, 'source-freeze.json'), (PROPOSAL, 'freeze.json')):
        assert str(directory / leaf) in pins
        for name in load(directory / leaf)['files']:
            assert str(directory / name) in pins
    deps = load(PROPOSAL / 'DEPENDENCIES.json')
    overlays = {row['module']: row for row in deps['overlays']}
    assert len(overlays) == 5
    for name, row in overlays.items():
        assert plan['modules'][name] == dict(path=row['path'], sha256=row['sha256'], package=False)
    for name, row in plan['modules'].items():
        actual = Path(row['path'])
        assert str(actual) in pins and sha(actual) == row['sha256']
        assert actual.is_relative_to(REPO) and actual.suffix == '.py'
        if actual.is_relative_to(REPO / '.ios-host-tmp'):
            assert name in overlays and row['path'] == overlays[name]['path']
    for row in deps['publicPhysicalDependencies']:
        assert row['path'] in pins and sha(row['path']) == row['sha256']
    for name, roots in plan['namespacePackages'].items():
        assert name not in plan['modules'] and type(roots) is list and roots
        for root in roots:
            root = Path(root)
            assert root.is_relative_to(REPO) and root.is_absolute() and root.resolve(strict=True) == root and root.is_dir()
    public = load(plan['publicNamespace']['path'])
    assert plan['publicNamespace']['path'] in pins
    assert sha(plan['publicNamespace']['path']) == plan['publicNamespace']['sha256']
    expected_paths = set(public['paths'])
    actual_paths = set()
    for root in public['roots']:
        root = Path(root)
        assert root.is_relative_to(REPO) and not root.is_relative_to(REPO / '.ios-host-tmp')
        actual_paths.update(str(p) for p in (root, *root.rglob('*')))
    assert actual_paths == expected_paths
    for relative in ('nodeScript', 'nodeModel'):
        row = plan[relative]
        assert row['path'] in pins and pin(row['path']) == row['pin']
    assert plan['nodeScript']['path'] == str(REPO / 'tests/device/ios/self_tests/chat_message_script_domain.js')
    assert plan['nodeModel']['path'] == str(REPO / 'tests/device/ios/self_tests/chat_message_script_domain.py')
    node = Path(plan['node']['path'])
    assert node.is_absolute() and node.resolve(strict=True) == node
    assert str(node) in pins and pin(node) == plan['node']['pin']
    return plan

