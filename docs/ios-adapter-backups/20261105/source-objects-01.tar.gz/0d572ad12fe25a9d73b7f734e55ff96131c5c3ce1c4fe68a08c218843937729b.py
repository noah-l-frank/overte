"""Read retained02 using its independent control-sidecar; no new delivery."""
from contextlib import ExitStack,contextmanager
from copy import deepcopy
import cProfile,hashlib,json,os,pstats,signal,sys,time,traceback
from pathlib import Path
from unittest.mock import patch
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import collect
from ios.adapters.snapshot_photos_end_originals import SnapshotPhotosEndOriginals
from ios.self_tests.snapshot_photos_end_domain import selected_public_policy,selection_pin

ROOT=Path.cwd();PRIVATE=ROOT/'.ios-host-tmp';OUT=PRIVATE/'snapshot-retained02-forensic-cost04';OUT.mkdir(mode=0o700,exist_ok=True)
MAIN=PRIVATE/'tmpuie9i6w6';PHOTOS=PRIVATE/'snapshot-companion-0tx6e3ru';ARCHIVE=PRIVATE/'snapshot-companion-uusdz4h9'
SELECT=PRIVATE/'snapshot-photos-selection-yufig1gt/selected-domain-policy.json'
LABEL='FORENSIC_RETAINED02_COSTS_NO_END_OR_TIMING_QUALIFICATION'
def save(name,value):(OUT/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
raw=SELECT.read_bytes();selected=PrivateFeatureState(SELECT).read()
ticket=dict(path=str(SELECT),stat=selection_pin(SELECT),sha256=hashlib.sha256(raw).hexdigest(),valueSha256=digest(selected))
need_sha='178c0e360b4e34ebba79fecf43b61dc8326e0af6ca63d7e7cadd9587ca3e6f9a'
if ticket['sha256']!=need_sha:raise AssertionError('Selected original control artifact changed')
policy=selected_public_policy(ticket)
save('control-ticket-before.json',dict(label=LABEL,ticket=ticket,
    provenance='PolicyFixture.public control artifact born before first Page.prepare_png in actual typedCache02; no Backend or End header is an expected input',
    limitation='Current ticket stat/hash selected separately for this retained read, not a recovered live object or a claim of Photos SDK retirement'))
binding=dict(sourceRevision='a'*40,artifactSha256='b'*64,processIdentity='42',sessionId='owned-session',generation=0,targetFingerprint='c'*64)
DEVICE='HOST-PHYSICAL-SHARE-DEVICE-MODEL'
def helper(root,bundle,pid,caps,name):
 target=dict(platform='ios',physical=True,appId=bundle,serverUrl='http://already-bound.invalid',capabilities=caps);artifact=root/'selected.ipa'
 scope=dict(sourceRevision='c'*40,artifactSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),processIdentity=str(pid),sessionId='companion-session',generation=1,targetFingerprint=digest(target))
 return dict(root=str(root),binding=scope,target=target,artifactPath=str(artifact),sessionPath=str(root/'session.json'),admissionPath=str(root/name))
factory=SnapshotPhotosEndOriginals(dict(root=str(MAIN),binding=binding),
 helper(PHOTOS,'org.example.snapshot.photos',84,{'appium:udid':DEVICE,'appium:platformVersion':'99.1'},'ios-snapshot-companion-owner.json'),
 helper(ARCHIVE,'org.example.snapshot.sharearchive',85,{'appium:udid':DEVICE},'ios-snapshot-share-code-owner.json'),run='a'*32,
 fixture_url='https://controlled.invalid/feature-fixture/v1/runs/'+'a'*32+'/',primary_bundle='org.example.client',
 system_ui=dict(select=dict(using='accessibility id',value='Snapshot Original Receiver'),cancel=dict(using='accessibility id',value='System Share Cancel')),
 domain_policy=policy,reuse_originals=True)
def parser_manifest(rows):
 result={}
 for name,module_id,signatures,constants in rows:
  members={}
  for item in signatures:
   key=item[0];members[key]=dict(sha256=hashlib.sha256(repr(item[1:]).encode()).hexdigest())
   if len(item)==3:
    members[key]['methods']=[dict(owner=parent.__module__+'.'+parent.__qualname__,name=attribute,
       sha256=hashlib.sha256(repr(signature).encode()).hexdigest()) for parent,attribute,signature in item[2]]
  result[name]=dict(identitySha256=hashlib.sha256(repr(module_id).encode()).hexdigest(),members=members,
   constants={key:hashlib.sha256(repr(signature).encode()).hexdigest() for key,signature in constants})
 return result
areas=[];original_area=factory.read_area
@contextmanager
def observed_area():
 with original_area() as area:
  areas.append(area);save('parser-before-names-hashes.json',parser_manifest(area.parsers));yield area
# Private instance-only telemetry delegates to the exact original area method;
# no decoder/guard method, input, deadline or class identity is replaced.
factory.read_area=observed_area
effects=[];locks={str(root/'script-feature-sources.lock') for root in (MAIN,PHOTOS,ARCHIVE)}
lock_pins={path:(Path(path).stat().st_dev,Path(path).stat().st_ino) for path in locks}
def forbidden(label):effects.append(label);raise AssertionError('Forbidden retained-read effect: '+label)
def audit(event,args):
 if event.startswith(('socket.','subprocess.','os.exec','os.spawn','os.fork')) or event in ('os.system','os.posix_spawn','pty.spawn','ctypes.dlopen'):forbidden(event)
 if event in ('os.remove','os.rmdir','os.rename','os.mkdir','os.chmod','os.chown','os.utime','os.link','os.symlink','os.truncate'):forbidden(event)
 if event=='open':
  path,mode,flags=args;write=flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)
  if write:
   if isinstance(path,int):forbidden('descriptor-write-open')
   path=str(Path(os.fsdecode(path)).absolute())
   if Path(path).parent==OUT:return
   if path in locks and mode is None and not flags&(os.O_TRUNC|os.O_APPEND|os.O_EXCL):
    row=Path(path).lstat()
    if (row.st_dev,row.st_ino)==lock_pins[path]:return
   forbidden('open-write:'+path)
started=time.monotonic();error=None;result_sha=None;reads=set();cutpoint=None;yielded=False;entry_members=None
def terminate(number,frame):
 global cutpoint
 stack=[]
 while frame is not None:stack.append(dict(file=frame.f_code.co_filename,line=frame.f_lineno,function=frame.f_code.co_qualname));frame=frame.f_back
 cutpoint=dict(signal=number,stack=stack);save('sigterm-cutpoint.json',cutpoint);raise SystemExit(128+number)
sys.addaudithook(audit);signal.signal(signal.SIGTERM,terminate)
profiler=cProfile.Profile()
# Explicit at enable(): constructor options alone are overwritten by enable().
# This is forensic overhead, never an uninstrumented execution-time claim.
profiler.enable(subcalls=False,builtins=False)
try:
 with collect() as actual:
  with ExitStack() as stack:
   stack.enter_context(patch.object(PrivateFeatureState,'write',side_effect=lambda *_a,**_k:forbidden('PFS.write')))
   stack.enter_context(patch.object(PrivateFeatureState,'discard',side_effect=lambda *_a,**_k:forbidden('PFS.discard')))
   for name in ('write','pwrite','writev','ftruncate','fchmod','fchown'):
    if hasattr(os,name):stack.enter_context(patch.object(os,name,side_effect=lambda *_a,_name=name,**_k:forbidden('os.'+_name)))
   with factory.read_journey() as journey:
    yielded=True
    print(LABEL,'HISTORICAL_JOURNEY_ENTERED',round(time.monotonic()-started,6),flush=True)
    value=journey.proof();result_sha=digest(value)
    entry_members=[dict(kind=row['kind'],pathCount=len(row['paths']),allActuallyRead=set(row['paths'])<=set(actual)) for row in areas[-1].cache.values()]
    if value['snapshotCombinedJourneyResultVersion']!=2 or value['photosSDKRetirementRequired'] is not True:raise AssertionError('Literal Result2 obligation changed')
  reads=set(actual)
except BaseException as exc:error=dict(type=type(exc).__name__,message=str(exc));traceback.print_exc()
finally:
 profiler.disable()
 profiler.dump_stats(str(OUT/'read-costs.pstats'))
 profile_rows=[]
 for (filename,line,name),(primitive,calls,self_seconds,cumulative,callers) in pstats.Stats(profiler).stats.items():
  profile_rows.append(dict(file=filename,line=line,function=name,primitiveCalls=primitive,calls=calls,
    selfSeconds=self_seconds,cumulativeSeconds=cumulative,callerMapCount=len(callers)))
 save('function-costs.json',dict(label=LABEL,instrumented=True,subcalls=False,builtins=False,
   overlappingCumulativeNotAdditive=True,functions=sorted(profile_rows,key=lambda row:row['cumulativeSeconds'],reverse=True)))
 if 'actual' in globals():reads=set(actual)
 area_report=None
 if areas:
  area=areas[-1]
  from ios.adapters.snapshot_photos_end_round import parser_identity
  current_parsers=parser_identity();save('parser-after-names-hashes.json',parser_manifest(current_parsers))
  area_report=dict(elapsedSeconds=time.monotonic()-area.started,counts=dict(area.counts),scopeSame=area.describe()==area.descriptor,
   parserHeadsSame=area.parser_headers()==area.parser_functions,parserInventorySame=current_parsers==area.parsers,
   originalCensus='Independent supervisor compares complete original byte/stat inventory after termination, without extending this expired area')
 unchanged_policy=selected_public_policy(ticket)==policy
 report=dict(label=LABEL,endpointAcceptance=False,wholeAcceptance=False,elapsedSeconds=time.monotonic()-started,error=error,effects=effects,
  cutpoint=cutpoint,historicalJourneyYielded=yielded,entryMembership=entry_members,area=area_report,actualReadPaths=sorted(map(str,reads)),diagnosticResult2Sha256=result_sha,selectedPolicyUnchanged=unchanged_policy)
 save('report.json',report);print(LABEL,json.dumps(report,sort_keys=True),flush=True)
raise SystemExit(1 if error or effects else 0)
