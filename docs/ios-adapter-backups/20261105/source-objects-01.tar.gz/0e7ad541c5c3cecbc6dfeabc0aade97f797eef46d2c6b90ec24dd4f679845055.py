"""Metadata-only explicit terminal custody and immutable assembler inputs.

No project, SDK, vendor, native, or model imports. Called only by a separately
reviewed quiet-window finalizer; importing this module performs no inventory.
"""
import hashlib,json,os,shutil,stat,sys
from pathlib import Path
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def pin(path):
    path=Path(path);a=path.lstat();assert not path.is_symlink()and path.resolve(strict=True)==path
    assert stat.S_ISREG(a.st_mode)or stat.S_ISDIR(a.st_mode)
    result=dict(stat=[getattr(a,k)for k in FIELDS])
    if stat.S_ISREG(a.st_mode):result['sha256']=sha(path)
    assert result['stat']==[getattr(path.lstat(),k)for k in FIELDS];return result

def frozen(folder,digest,physical,filename='freeze.json'):
    folder=Path(folder);f=folder/filename;assert sha(f)==digest;physical.add(f)
    value=json.loads(f.read_text());rows=value['files']
    items=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
    for name,row in items:
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        path=folder/name;expected=row if type(row)is str else row['sha256']
        assert sha(path)==expected;physical.add(path)
    return value

def referenced(row,physical):
    assert type(row)is dict and type(row['path'])is str and type(row['sha256'])is str
    path=Path(row['path']);assert sha(path)==row['sha256'];physical.add(path);return path

def root_result(spec,physical):
    folder=Path(spec['path']);frozen(folder,spec['freezeSha256'],physical)
    path=folder/'results.json';body=json.loads(path.read_text());physical.add(path)
    refs=folder/'actual-receipt-references.json';physical.add(refs)
    for row in json.loads(refs.read_text()).values():referenced(row,physical)
    return body

def context_inputs(source,repo,args,physical):
    cfg=json.loads((source/'assembler-inputs.json').read_text())
    cpath=referenced(cfg['terminalContext'],physical);context=json.loads(cpath.read_text())
    assert context['status']=='ROOT_TERMINAL_CONTEXT_NO_TARGET_NO_GLOBAL_SCAN'
    assert context['globalScans']==context['targets']==0 and context['noWriterExclusions']is True
    baseline_path=referenced(context['base653Baseline'],physical)
    old=json.loads(baseline_path.read_text());assert len(old)==653 and set(old)<=set(context['roots'])
    for key in ('base653Seed','base653InputMap','base653ExternalTerminal','base653Freeze'):referenced(context[key],physical)
    names=set(context['roots']);assert len(names)==660
    assert set(context['additionalOriginalRoots'])==set(context['authoritativeAdditionalOriginalRoots'])
    assert names==set(old)|set(context['additionalOriginalRoots'])
    for name,authority in context['authoritativeAdditionalOriginalRoots'].items():
        f=referenced(authority['freeze'],physical);frozen(f.parent,authority['freeze']['sha256'],physical)
        result_path=referenced(authority['result'],physical)
        refs=f.parent/'actual-receipt-references.json'
        assert refs.exists();physical.add(refs)
        for row in json.loads(refs.read_text()).values():referenced(row,physical)
        result=json.loads(result_path.read_text())
        admitted=result.get('newOriginalRoots',[])
        if not admitted and 'controllerRoot'in result:admitted=[result['controllerRoot'],result['controllerRoot']+'-outer']
        assert name in admitted,'Terminal context authority does not name the original root'
    for spec in cfg['qualifiedAdditions']:
        body=root_result(spec,physical)
        assert body[spec['qualifiedField']]is True and body['actualTests']==spec['actualTests']
        assert body['newOriginalRoots']==spec['newOriginalRoots']
        terminal=body['terminal'];assert terminal['status']=='PASS'and terminal['childReturnCode']==0
        assert terminal['ownProcessesAbsent']and not terminal['timedOut']and not terminal['forcedKill']
        assert body['ports']['restored']is True
        names.update(body['newOriginalRoots'])
    assert len(names)==cfg['rootCountAtAuthoring']==665
    correction=cfg['setupCorrection'];frozen(correction['path'],correction['freezeSha256'],physical)
    own=root_result(cfg['own11'],physical)
    assert own['status']=='ACTUAL_ELEVEN_COUNTERS_PASS_WITH_DISTINCT_ORIGINAL_AND_CONTROLLER_CLEANUP'
    assert len(own['actualCaseReceipts'])==11 and own['NodeExecutions']==0
    assert own['parentDrain']==dict(fdsEqual=True,threadsEqual=True)
    assert not own['kernelDrain']['remaining']and not own['kernelDrain']['timedOut']and not own['kernelDrain']['forced']
    assert own['ports']['count']==27 and own['ports']['restored']
    if args.later_terminal_results is not None:
        path=Path(args.later_terminal_results).resolve(strict=True);physical.add(path)
        later=json.loads(path.read_text());assert later['noWriterExclusions']is True
        for spec in later['results']:
            body=root_result(spec,physical)
            assert body['newOriginalRoots']==spec['newOriginalRoots']
            assert body['status']==spec['status']and type(spec['terminalJustification'])is str and spec['terminalJustification'].strip()
            # A failed test may still have a genuinely drained immutable raw
            # root. Its exact Root result stays a failure; never promote it.
            terminal=body['terminal'];assert terminal['ownProcessesAbsent']is True
            names.update(body['newOriginalRoots'])
    for name in names:
        p=Path(name);assert p.is_absolute()and p.resolve(strict=True)==p and p.is_relative_to(repo)and p.is_dir()
    return old,names

def admit_context(source,repo,args):
    physical=set();old,names=context_inputs(source,repo,args,physical);return old,names,physical

def assemble(source,repo,args):
    assert sys.dont_write_bytecode and repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file()
    cfg=json.loads((source/'assembler-inputs.json').read_text());assert args.expected_head==cfg['publicHead']
    assert args.quiet_receipt.strip()
    physical=set();frozen(source,sha(source/'source-freeze.json'),physical,'source-freeze.json')
    moving=Path(cfg['movingCode']['path']);frozen(moving,cfg['movingCode']['freezeSha256'],physical,'source-freeze.json')
    referenced(cfg['historicalAssembler'],physical)
    context_inputs(source,repo,args,physical) # All prerequisite originals BEFORE any destination birth.
    # Canonical Root-approved destination; no symlink parents, no existing tree.
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve().is_relative_to(repo)
    assert dest.parent.resolve(strict=True)==dest.parent and not dest.exists()and not dest.is_symlink()
    assert dest.parent==repo/'.ios-host-tmp'
    def target(path):
        path=Path(path);assert path.resolve().is_relative_to(repo);return path
    def put(name,data):
        p=target(dest/name);assert p.parent==dest and not p.exists()
        with target(p).open('xb')as stream:stream.write(data)
        target(p).chmod(0o600)
    target(dest).mkdir(mode=0o700)
    code_names=('guard.py','root_stage_guard.py','diagnostic_write_guard.py','global_original_corpus.py','moving_host_ports.py','run-selected.py','root-supervise.py','first-case.json')
    for name in code_names:put(name,(moving/name).read_bytes())
    stage=target(dest/'first1');target(stage).mkdir(mode=0o700)
    case=target(stage/'case.json');assert not case.exists()
    with target(case).open('xb')as stream:stream.write((moving/'first-case.json').read_bytes())
    target(case).chmod(0o600)
    plan=json.loads((moving/'plan-draft.json').read_text());base=Path(plan['controllerBase']['path'])
    frozen(base,plan['controllerBase']['freezeSha256'],physical)
    for name in ('map-inputs.json','historical-proof-scope.json','historical-clock-prerequisites.json','historical-qualified-instruction-prerequisites.json','historical-qualified-warm-prerequisites.json','historical-qualified-retained-owner-prerequisites.json'):
        put(name,(base/name).read_bytes())
    for row in plan['overlays']:
        logical=Path(row['logical']);assert logical.parts[:2]==('tests','device')and logical.suffix=='.py'
        parts=logical.relative_to('tests/device').with_suffix('').parts
        row['module']='.'.join(parts[:-1]if parts[-1]=='__init__'else parts)
        assert sha(row['path'])==row['sha256']
    node=Path(args.node_executable);assert node.is_absolute()and node.resolve(strict=True)==node
    assert shutil.which('node')is not None and Path(shutil.which('node')).resolve(strict=True)==node
    assert stat.S_ISREG(node.stat().st_mode)and os.access(node,os.X_OK)
    plan['nodeExecutable']=dict(path=str(node),pin=pin(node))
    for key in ('movingNodeScript','movingWorkerSource'):
        plan[key]['pin']=pin(Path(plan[key]['path']))
    plan.update(status='PRIVATE_DRAFT_UNRUN_REQUIRES_FINAL_PINS_AND_ROOT_REVIEW',publicHead=args.expected_head,codeOnlySourcePacket=str(moving),codeOnlySourceFreeze=cfg['movingCode']['freezeSha256'],terminalContext=cfg['terminalContext'],qualifiedTerminalAdditions=cfg['qualifiedAdditions'],rootCountAtAuthoring=665,rootCountIsNotExecutionCap=True)
    put('plan-draft.json',(json.dumps(plan,indent=2,sort_keys=True)+'\n').encode())
    put('moving-prerequisites.json',(json.dumps(dict(own11=cfg['own11'],foreign=cfg['qualifiedAdditions'][0],publisher=cfg['qualifiedAdditions'][1],setupCorrection=cfg['setupCorrection'],scope='HOST_ONLY_NO_NATIVE_OR_WHOLE_QUALIFICATION'),indent=2,sort_keys=True)+'\n').encode())
    # Full inherited source-freeze and exact executor bytes remain separate.
    code_files={name:sha(dest/name)for name in code_names}
    put('code-preparation-freeze.json',(json.dumps(dict(files=code_files,sourceMovingFreeze=cfg['movingCode']['freezeSha256']),indent=2,sort_keys=True)+'\n').encode())
    return dest
