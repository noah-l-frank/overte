from pathlib import Path
import hashlib,json,sys,unittest
root=Path.cwd();runner=Path(__file__).resolve();out=runner.parent
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'tests/device').rglob('*.py')};before[str(runner)]=hashlib.sha256(runner.read_bytes()).hexdigest()
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
suite=unittest.defaultTestLoader.loadTestsFromName('test_ios_avatar_scene_manifest_reader.AvatarSceneManifestReaderTests')
assert suite.countTestCases()==6
result=unittest.TextTestRunner(verbosity=2).run(suite)
loaded={str(runner)}
for module in list(sys.modules.values()):
 name=getattr(module,'__file__',None)
 if name:
  p=Path(name).resolve()
  if p.suffix=='.py' and p.is_relative_to(root/'tests/device'):loaded.add(str(p))
after={name:hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in loaded}
(out/'loaded-source-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert all(name in before and before[name]==sha for name,sha in after.items())
print('Actual imported repository source hashes unchanged:',len(after)-1,'and own launcher unchanged',flush=True)
sys.exit(not result.wasSuccessful())
