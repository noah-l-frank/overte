"""Actor stage admission from actual Primary End/readmission/restoration originals.

A copied replacement header never grants live admission. The independent Actor
replays the exact Primary owners and retained old/new original stores before
publishing from its separate replacement current stream. All old frames stay.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same

TRANSITIONAL=('cleaning','replacing','ending','ended','aborting','aborted')
ADOPTABLE=('cleaned','terminal-ready')


def primary(flow):
    from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
    f=flow;need(f.role=='actor');f.guard()
    peer=IOSAudioWholeFeature(f.adapter,f.primary_selector,f.run,'primary',f.client,f.config,
        epoch_ms=f.epoch_ms,monotonic=f.monotonic,sleep=f.sleep,
        runtimes=(f.actor_runtime,f.primary_runtime),source_locks=f.locks)
    peer.load();need(peer.state is not None and same(peer.state['bindings'],f.state['bindings']))
    return peer


def validate(flow):
    """Pure archived join; uses the actual Primary typed retired scope."""
    from ios.adapters.audio_whole_terminal import AudioWholeTerminal
    f=flow;peer=primary(f)
    need(f.state['replacement'] is not None and same(f.state['replacement'],peer.state['replacement'])
        and same(f.state['oldEnd'],peer.state['oldEnd']))
    return AudioWholeTerminal(peer).validate_replacement_restoration()


def synchronize(flow):
    from ios.adapters.audio_whole_feature import AudioWholePending,NAME
    from ios.adapters.audio_whole_terminal import AudioWholeTerminal
    f=flow;need(f.role=='actor'and f.state is not None);f.guard()
    store=PrivateFeatureState(f.adapter.state_path(f.primary_selector).with_name(NAME.format('primary')))
    header=store.read();need(type(header)is dict and header.get('runId')==f.run and header.get('role')=='primary'
        and header.get('settings')==f.config and type(header.get('state'))is dict)
    hint=header['state'];phase=hint.get('phase')
    if phase not in TRANSITIONAL+ADOPTABLE and hint.get('replacement')is None:
        # This hint authorizes no stage or custody change. The ordinary
        # independent initial Source guards remain responsible for live reads.
        need(f.state['replacement']is None);return False
    peer=primary(f)
    if peer.state['phase']in TRANSITIONAL:
        # A real Stop/readmission/final End may have removed the old canonical
        # Source. Never recreate it, read dead SDKs, or publish old facts anew.
        raise AudioWholePending('Actual Primary replacement or End remains in progress')
    need(peer.state['phase']in ADOPTABLE and peer.state['replacement']is not None)
    terminal=AudioWholeTerminal(peer);proof=terminal.validate_replacement_restoration()
    need(len(peer.state['replacementRestoration']['verified'])==2
        and proof['newBinding']==peer.state['replacement']['newBinding'])
    if f.state['replacement']is None:
        need(f.state['oldEnd']is None)
        f.state['oldEnd']=deepcopy(peer.state['oldEnd']);f.state['replacement']=deepcopy(peer.state['replacement']);f.state['cleanupTicket']=peer.state['cleanupTicket'];f.save()
    else:need(same(f.state['oldEnd'],peer.state['oldEnd'])and same(f.state['replacement'],peer.state['replacement'])
        and f.state['cleanupTicket']==peer.state['cleanupTicket'])
    # Recheck all actual Parent/scope/readmission originals after the Actor CAS.
    # Fresh attach() still binds the real new installed Source independently.
    validate(f);return True
