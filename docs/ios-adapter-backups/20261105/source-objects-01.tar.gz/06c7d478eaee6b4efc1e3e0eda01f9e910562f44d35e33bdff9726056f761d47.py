"""Retain the actual first-dispatch fixture TypeError with full original closure."""
from pathlib import Path
import json,hashlib
B=Path.cwd()/'.ios-host-tmp'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(o,n,v):
 with(o/n).open('x')as s:json.dump(v,s,sort_keys=True,indent=2);s.write('\n')
C=B/'root-assets-source6-second01-b11-window-current1228-20261105'
assert sha(C/'freeze.json')=='f67732237db7997821d7931b42071984c2cfeae8a765d3b58042d7c5abc76c3c'
for n,r in load(C/'freeze.json')['files'].items():assert sha(C/n)==r['sha256']
t=load(C/'terminal.json');assert t['status']=='ROOT_ASSETS_SOURCE3_SECOND01_ORIGINAL_FAILURE_OR_PARTIAL_CLOSED_WITHOUT_LINEAGE_PROMOTION'and t['oldRootCount']==1228
for k in('allOldOriginalBodiesUnchanged','allRecordedOriginalPIDsAndGroupsAbsent','wholeAllActualOwnRoomsTwiceEqual','ownTemporaryExplicitlyIncluded'):assert t[k]is True
assert t['originalSupervisorReturnCode']==1
h=Path(t['newOriginalRoots'][0]);o=h.with_name(h.name+'-outer');c=h.with_name(h.name+'-censuses')
assert sha(h/'approved-inputs.json')=='f93135fe28c845dadb3985311b968c7cafa4cedd5b159d3c7faedb3233f249d8'
terminal=t['originalSupervisorTerminal'];q=t['originalQualification']
assert terminal is not None and q is not None and terminal['status']==q['status']=='FAIL_OR_REFUSED'and terminal['childReturnCode']==1
assert terminal['ownProcessesAbsent']is terminal['inputAndSourcePinsUnchanged']is terminal['parentFDThreadUnchanged']is terminal['completeOriginalNodeLineage']is True
assert terminal['problems']==[]and terminal['forcedKill']is terminal['timedOut']is False
report=load(h/'actual-report.json');assert report==terminal['originalReport']and report['testsRun']==len(report['cases'])==1 and report['fatal']is None and report['secondary']==[]
assert report['actualEagerDefinitionCount']==report['expectedEagerDefinitionCount']==587 and report['retainedPhysicalDefinitionCount']==590
for k in('pinsAndInputUnchanged','definitionsUnchanged','completeOriginalNodeLineage','fdsUnchanged','threadsUnchanged','kernelChildrenUnchanged','originalPortsRestored','actualCIOUnchanged','monitorSlotsRestored','allActualLoadedOriginsAccounted','allObservedPIDsAbsent','twoToyCensusesEqual'):assert report[k]is True
assert report['actualOSPortCount']==27
resources=report['actualResources'];assert len(resources['actualTemporaryDirectories'])==4 and resources['realNodeConstructors']==1 and resources['originalListenersClosed']is resources['ownReturnToolReleased']is True and resources['SDKExecuted']is False
assert len(report['actualOriginalNodes'])==1 and report['actualOriginalNodes'][0]['current']is None
raw=h/'child-logs/stderr.log';text=raw.read_text();assert 'in setUp'in text and 'self.f.ordinary_input(1)'in text and 'assets_page_birth.py'in text and "pending is None and 'open-assets' in slots"in text and 'NativeUIError: Native feature observation is unavailable or invalid'in text and 'FAILED (errors=1)'in text
assert q['originalRooms']==list(map(str,[h,o,c]))and q['exclusions']==[]and q['twoEntireHEREAndOuterEqual']is True
absence=load(C/'actual-root-kernel-absence.json');assert absence['actualSameGroupOrSession']==[]and absence['originalCreatorLineageQualified']is True
for row in absence['actualRecordedOriginals']:
 try:proc=Path('/proc',str(row['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(proc[proc.rfind(')')+2:].split()[19])!=row['startTicks']
ctx=load(B/'root-ios-current1228-after-tablet-first4-b8-arena-truncate-negative-context-20261105/root-context.json');old=load(ctx['globalCustody']['baseline']['path']);assert len(old)==1228 and load(C/'global-before.json')==old
post=load(C/'global-after-first.json');assert post==load(C/'global-after-second.json')and set(post)==set(old)|{str(h/'temporary')}and all(post[k]==v for k,v in old.items())
assert load(C/'whole-first.json')==load(C/'whole-second.json')
roots=t['newOriginalRoots'];assert len(roots)==5 and str(h/'temporary')in roots
refs={str(p):dict(path=str(p),sha256=sha(p))for root in map(Path,roots)for p in sorted(root.rglob('*'))if p.is_file()and not p.is_symlink()}
out=B/'root-assets-second01-b11-original-post-open-observation-state-error-negative-results-20261105';out.mkdir(mode=0o700)
put(out,'results.json',dict(status='ROOT_RETAINED_ASSETS_SECOND01_B11_ORIGINAL_POST_OPEN_OBSERVATION_STATE_ERROR',terminal=terminal,newOriginalRoots=roots,originalRootTerminal=t,originalReport=report,originalQualification=q,actualOriginalCasesExecuted=1,actualOriginalCasesPassed=0,actualEagerImports=587,actualPhysicalDefinitions=590,actualTemporaryDirectories=4,actualNodeConstructors=1,actualOriginalNodeCreatorLineage=True,firstOrdinaryDispatcherFailure=dict(path=str(raw),sha256=sha(raw),message="Actual first ordinary action opens original page then current_permissions starts genuine fresh pending observation; PageBirth opened decoder refuses that required intermediate state; no query/input replay or guard waiver"),normalAction2Qualified=False,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(out,'actual-receipt-references.json',refs);put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}));print(json.dumps(dict(freeze=sha(out/'freeze.json'),results=sha(out/'results.json'),references=len(refs))))
