"""Bounded index of immutable original checkpoints, with durable append intent.

The existing OriginalFrameStore owns every byte/hash/inode and128-entry block.
The enclosing WAL retains at most four block references and one append intent;
high-entropy checkpoint originals never have to fit into that64KiB WAL.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib
from adapters.native_feature_observation import exact,integer,need
from adapters.original_frame_store import OriginalFrameStore,BLOCK
from adapters.script_feature.history import canonical,same
from adapters.normal_feature_state import PrivateFeatureState

LIMIT=512


class LifecycleCheckpointIndex:
    def __init__(self,files,save,value=None):
        need(type(files)is OriginalFrameStore and callable(save)and BLOCK==128)
        self.files,self.save=files,save
        classes=((LifecycleCheckpointIndex,('__init__','count','shape','snapshot','references','intent','append','recover_saved_append','inventory')),
            (OriginalFrameStore,('append','manifest','manifest_reference','manifest_path','expand','original')))
        receivers=tuple((cls,name,getattr(cls,name),getattr(cls,name).__code__)for cls,names in classes for name in names)
        def unchanged():
            for cls,name,function,code in receivers:
                need(getattr(cls,name)is function and function.__code__ is code)
            return True
        self.guard=unchanged
        self.blocks,self.pending=[],None
        if value is not None:
            exact(value,{'lifecycleCheckpointIndexVersion','limit','count','blocks','pending'})
            need(type(value['lifecycleCheckpointIndexVersion'])is int and value['lifecycleCheckpointIndexVersion']==1
                and type(value['limit'])is int and value['limit']==LIMIT)
            self.blocks,self.pending=deepcopy(value['blocks']),deepcopy(value['pending'])
            need(type(value['count'])is int and value['count']==self.count())
        self.shape()

    def count(self):return sum(row['count']for row in self.blocks)

    def shape(self):
        self.guard();need(type(self.blocks)is list and len(self.blocks)<=LIMIT//BLOCK)
        for ordinal,row in enumerate(self.blocks,1):
            self.files.manifest_reference(row);need(row['block']==ordinal and (ordinal==len(self.blocks)or row['count']==BLOCK))
        need(integer(self.count(),0,LIMIT))
        if self.pending is not None:
            exact(self.pending,{self.files.key('ManifestVersion'),'reference','phase'})
            need(type(self.pending[self.files.key('ManifestVersion')])is int and self.pending[self.files.key('ManifestVersion')]==1
                and self.pending['phase']in ('planned','saved')and self.count()<LIMIT)
            reference=self.pending['reference'];self.files.manifest_reference(reference)
            need(reference['block']==self.count()//BLOCK+1 and reference['count']==self.count()%BLOCK+1)

    def snapshot(self):
        self.shape();return dict(lifecycleCheckpointIndexVersion=1,limit=LIMIT,count=self.count(),blocks=deepcopy(self.blocks),pending=deepcopy(self.pending))

    def references(self):
        self.shape();result=[]
        for block in self.blocks:result.extend(self.files.manifest(block))
        need(len(result)==self.count())
        for ordinal,reference in enumerate(result,1):self.files.expand(reference);need(reference['index']==ordinal)
        return result

    def intent(self,value):
        previous=self.pending;self.pending=deepcopy(value);self.shape()
        if previous is None:need(value['phase']=='planned')
        else:need(previous['phase']=='planned'and value['phase']=='saved'and same(previous['reference'],value['reference']))
        self.save()

    def append(self,reference):
        self.shape();need(self.pending is None and self.count()<LIMIT and reference['index']==self.count()+1)
        proposed=self.files.append(self.blocks,reference)
        need(self.pending is not None and self.pending['phase']=='saved'and same(self.pending['reference'],proposed[-1]))
        # The owner commits these blocks and its new checkpoint membership in
        # ONE following WAL write. A lost append retains the old published
        # prefix plus its known planned/saved index file; no requery is allowed.
        self.blocks,self.pending=proposed,None

    def recover_saved_append(self,reference):
        """Only a known complete index/body can finish an interrupted append."""
        self.shape();need(reference['index']==self.count()+1)
        if self.pending is None:self.append(reference);return
        saved=self.pending['reference'];entries=self.files.manifest(saved)
        prior=[]if self.count()%BLOCK==0 else self.files.manifest(self.blocks[-1])
        need(same(entries,prior+[reference]))
        blocks=deepcopy(self.blocks)
        if self.count()%BLOCK:blocks.pop()
        blocks.append(deepcopy(saved));self.blocks,self.pending=blocks,None

    def inventory(self):
        """All retained prefix index snapshots, plus one known append duty."""
        expected=set()
        for reference in self.blocks:
            entries=self.files.manifest(reference)
            for count in range(1,len(entries)+1):
                body=dict({self.files.key('ManifestVersion'):1},kind=self.files.kind,binding=self.files.binding,
                    runId=self.files.run,role=self.files.role,block=reference['block'],entries=entries[:count])
                raw=canonical(body);prior=dict(block=reference['block'],count=count,sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
                path=self.files.manifest_path(prior);need(path.is_file());expected.add(path)
                need(same(PrivateFeatureState(path).read(),body))
        if self.pending is not None:
            path=self.files.manifest_path(self.pending['reference'])
            if path.exists():
                self.files.manifest(self.pending['reference']);expected.add(path)
            else:need(self.pending['phase']=='planned')
        prefix=self.files.namespace+'-index-'+self.files.kind+'-'+self.files.run+'-'+self.files.role+'-'
        actual={path for path in self.files.root.iterdir()if path.name.startswith(prefix)};need(actual==expected)
        return expected

    def owned_paths(self):return self.inventory()
