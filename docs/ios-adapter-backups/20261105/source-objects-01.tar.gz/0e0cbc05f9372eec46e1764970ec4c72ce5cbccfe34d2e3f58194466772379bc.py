"""Read only actual original numeric timeline; no target import/query/test."""
import hashlib,json,sys
from pathlib import Path
repo=Path.cwd();path=repo/'.ios-host-tmp/lifecycle-resource4-join-bookend-timeline-root-preparation-20261102/01-source-first1/actual-original-join-bookend-timeline.json'
raw=path.read_bytes();timeline=json.loads(raw)
assert timeline['status']=='ACTUAL_ORIGINAL_NUMERIC_TIMELINE' and timeline['privateToolFreed']
assert timeline['observerFailures']==timeline['dropped']==0 and timeline['noFunctionsReplaced'] and timeline['noClockFieldsChanged']
events=timeline['events'];stamps={};report=[]
for event in events:
 packet=event.get('originalNativeCoordinates')
 if packet is not None:
  key=tuple(packet.get(field) for field in ('processId','instance','sequence','capturedEpochMs'))
  assert key not in stamps;stamps[key]=event
for event in events:
 joined=event.get('originalJoinCoordinates')
 if joined is None:continue
 first,last=joined['native'];a,b=[tuple(packet.get(field) for field in ('processId','instance','sequence','capturedEpochMs')) for packet in (first,last)]
 assert a in stamps and b in stamps
 begin,end=joined['hostBeforeMonotonic'],joined['hostAfterMonotonic'];native=last['capturedEpochMs']-first['capturedEpochMs']
 first_stamp,last_stamp=stamps[a]['diagnosticMonotonic'],stamps[b]['diagnosticMonotonic']
 assert begin<=first_stamp<=last_stamp<=end
 phase_events=[row for row in events if row['event']=='LINE' and row.get('originalHostCoordinates',{}).get('started')==begin and 'step-' in str(row.get('point'))]
 starts=[row for row in phase_events if 'step-clock-started-before-anchor' in row['point']]
 anchors=[row for row in phase_events if 'step-anchor-returned' in row['point']]
 assert len(starts)<=1 and len(anchors)<=1
 row=dict(phase=starts[0].get('phase') if starts else None,nativeSequences=[first['sequence'],last['sequence']],originalHostElapsedMs=(end-begin)*1000,
  originalNativeElapsedMs=native,originalJoinGapMs=(end-begin)*1000-native,
  observedFirstStampAfterHostStartMs=(first_stamp-begin)*1000,
  observedHostEndAfterLastStampMs=(end-last_stamp)*1000,
  observedStampSpanMinusOriginalNativeSpanMs=(last_stamp-first_stamp)*1000-native,
  originalHostCoordinates=joined,
  diagnosticOnly=True,monitoringObserverLatencyNotSubtracted=True,noNativeTimeRetimed=True)
 if starts and anchors:
  assert starts[0]['diagnosticMonotonic']<=anchors[0]['diagnosticMonotonic']<=first_stamp
  row['observedHistoricalAnchorBoundaryMs']=(anchors[0]['diagnosticMonotonic']-starts[0]['diagnosticMonotonic'])*1000
  row['observedAfterAnchorToFirstStampMs']=(first_stamp-anchors[0]['diagnosticMonotonic'])*1000
 row['algebraicDecompositionErrorMs']=row['originalJoinGapMs']-(row['observedFirstStampAfterHostStartMs']+row['observedHostEndAfterLastStampMs']+row['observedStampSpanMinusOriginalNativeSpanMs'])
 assert abs(row['algebraicDecompositionErrorMs'])<.0001
 report.append(row)
assert report,'No actual join coordinates observed'
print(json.dumps(dict(timeline=str(path),timelineSHA256=hashlib.sha256(raw).hexdigest(),actualJoins=report,performanceQualified=False),indent=2))
assert path.read_bytes()==raw
