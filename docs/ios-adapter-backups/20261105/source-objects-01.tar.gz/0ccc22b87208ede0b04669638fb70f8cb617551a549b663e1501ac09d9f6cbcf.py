"""Actual staged Lifecycle Script VM plus explicit native parent transforms.

Only the marker Script executes in Node. Original Overte/Qt/physics/native
World and parent lookup are independently declared MODELS. No saved original
or PNG is modified to match a later pose. This is not a renderer qualification.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib,json,subprocess,uuid
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_script_manager import NormalScriptManager
from adapters.token_script_ui import TokenScriptUI
from adapters.token_script_file_ui import TokenScriptFilePicker
from ios.self_tests.test_ios_avatar_marker_scope import AvatarDomain
from ios.self_tests.test_ios_emote_marker_measurements import frames


PROGRAM=r'''
const fs=require('node:fs'),vm=require('node:vm');
const data=JSON.parse(fs.readFileSync(0,'utf8'));let added=[],deleted=[],endings=[];
const sandbox={Script:{require:path=>{if(path!=='./companion.js')throw Error('foreign module');
 const module={exports:{}};vm.runInNewContext(data.companion,{module});return module.exports;},scriptEnding:{connect:f=>endings.push(f)}},
 Entities:{addEntity:(properties,host)=>{added.push({id:data.uuid,properties,host});return data.uuid;},deleteEntity:id=>deleted.push(id)},
 MyAvatar:Object.freeze({SELF_ID:'00000000-0000-0000-0000-000000000001'})};
vm.runInNewContext(data.main,sandbox,{timeout:1000});for(const ending of endings)ending();
process.stdout.write(JSON.stringify({added,deleted}));
'''
SELF_ID='00000000-0000-0000-0000-000000000001'


def native_parent_transform(local,position,quaternion):
    """Declared native SpatiallyNestable root transform, not the join helper."""
    # Matrix terms are explicit here; importing the product's rotate() into
    # this independent producer would make a matching defect invisible.
    x,y,z,w=quaternion;a,b,c=local
    rotated=[(1-2*y*y-2*z*z)*a+(2*x*y-2*z*w)*b+(2*x*z+2*y*w)*c,
        (2*x*y+2*z*w)*a+(1-2*x*x-2*z*z)*b+(2*y*z-2*x*w)*c,
        (2*x*z-2*y*w)*a+(2*y*z+2*x*w)*b+(1-2*x*x-2*y*y)*c]
    return [p+v for p,v in zip(position,rotated)]


class LifecycleParentDomain(AvatarDomain):
    def __init__(self,scope):
        super().__init__(scope)
        self.pose=dict(position=[0.,0.,4.],orientation=[0.,0.,0.,1.],velocity=[0.,0.,0.])
        self.foreign_pose=dict(position=[20.,0.,4.],orientation=[0.,0.,0.,1.])
        self.parent_fault=None;self.frozen_marker=None;self.parent_reads=[]
        self.world_template['source']['view']['mode']='look at'

    def manager(self):
        s=self.scope;ui=TokenScriptUI(self.io,monotonic=lambda:self.time,sleep=self.io.sleep)
        picker=TokenScriptFilePicker(self.io,self.files.root.as_uri(),monotonic=lambda:self.time,sleep=self.io.sleep)
        return NormalScriptManager(ui,self.io.observe,PrivateFeatureState(s.store.path.with_name('ios-lifecycle-'+s.role+'-marker-script.json')),
            s.binding,source_kind='script-file-bundle',file_owner=s.files,file_picker=picker,monotonic=lambda:self.time,sleep=self.io.sleep)

    def start(self):
        raw=(self.files.root/'script-bundle/main.js').read_bytes();companion=(self.files.root/'script-bundle/companion.js').read_text()
        actual_id=str(uuid.uuid4());result=subprocess.run(['node','-e',PROGRAM],
            input=json.dumps(dict(main=raw.decode(),companion=companion,uuid=actual_id)),capture_output=True,text=True,timeout=5,check=True)
        self.vm=json.loads(result.stdout)
        assert len(self.vm['added'])==1 and self.vm['deleted']==[actual_id]
        properties=self.vm['added'][0]['properties'];assert properties['parentID']==SELF_ID and properties['parentJointIndex']==65535
        assert self.vm['added'][0]['host']=='local'and 'position'not in properties and 'rotation'not in properties
        self.original_properties=deepcopy(properties)
        self.time+=.005;self.worker=dict(instance=uuid.uuid4().hex,assigned=True,url=self.file_url(),loadGeneration=1,assignedEpochMs=self.epoch())
        self.time+=.005;self.terminal_events=[dict(eventSequence=1,capturedEpochMs=self.epoch(),monotonicMs=round(self.time*1000),
            kind='thread-bound',threadInstance='a'*32,manager=deepcopy(self.worker),code=None,work=None)]
        self.time+=.005;code=dict(submitted=True,encoding='utf-16le-code-units',codeUnits=len(raw.decode().encode('utf-16le'))//2,
            sha256=hashlib.sha256(raw.decode().encode('utf-16le')).hexdigest(),submittedEpochMs=self.epoch())
        self.engine=deepcopy(frames()[1]['source']['scriptOriginal']['source']['engines'][0]);self.engine.update(url=self.file_url(),code=code)
        self.engine['required']['instance']=self.worker['instance'];self.engine['required']['modules'][0]['url']=(self.files.root/'script-bundle/companion.js').as_uri()
        self.marker_stamp=str(self.epoch()*1000);self.running=True;self.marker=self.original_marker()

    def original_marker(self):
        properties=self.original_properties;parent=self.foreign_pose if self.parent_fault=='foreign-parent'else self.pose
        local=[properties['localPosition'][axis]for axis in ('x','y','z')]
        assert [properties['localRotation'][axis]for axis in ('x','y','z','w')]==[0,0,0,1]
        marker={k:deepcopy(properties[k])for k in ('name','type','userData','sourceUrl','visible','collisionless')}
        marker.update(id=self.vm['added'][0]['id'],hostType='local',lastEditedEpochUs=self.marker_stamp,
            position=native_parent_transform(local,parent['position'],parent['orientation']),rotation=deepcopy(parent['orientation']),
            dimensions=[properties['dimensions'][axis]for axis in ('x','y','z')])
        if self.parent_fault=='stationary-marker':
            if self.frozen_marker is None:self.frozen_marker=deepcopy(marker)
            marker=deepcopy(self.frozen_marker)
        self.parent_reads.append(dict(parent=properties['parentID'],joint=properties['parentJointIndex'],
            host='local',scalesWithParent=False,body=deepcopy(parent),marker=deepcopy(marker)))
        return marker

    def world(self,run):
        p,q=self.pose['position'],self.pose['orientation'];source=self.world_template['source']
        source['avatar'].update(feetPosition=deepcopy(p),orientation=deepcopy(q),velocity=deepcopy(self.pose['velocity']))
        source['view'].update(position=native_parent_transform([0,1.6,4],p,q),rotation=deepcopy(q))
        source['sceneUrl']='hifi://lifecycle-fixture.invalid/'+','.join(map(str,p))+'/'+','.join(map(str,q))
        if self.running:self.marker=self.original_marker()
        value=super().world(run)
        # Select the declared native body producer BEFORE this fresh return;
        # the inherited schema's stationary prototype never becomes history.
        row=value['source']['bodies']['avatars'][0]
        row.update(position=deepcopy(p),orientation=deepcopy(q),velocity=deepcopy(self.pose['velocity']))
        return value
