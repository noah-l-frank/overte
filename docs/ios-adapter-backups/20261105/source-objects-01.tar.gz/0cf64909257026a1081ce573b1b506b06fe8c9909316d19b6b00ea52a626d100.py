"""Normal-action old-client retirement after real Model-removal Home.

Only known Reply3 jobs and the actual owned Files4 may retire. The original
Upload2/Picker2/Tree/Usage headers stay historical; a distinct sidecar retains
their dead-root/quiet resolution. No server, Model/cache or whole end is inferred.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import time
from types import SimpleNamespace
from adapters.native_feature_observation import exact,need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same,pack,unpack
from ios.adapters.assets_action_phase import AssetsActionScope,AssetsActionPhases
from ios.adapters.assets_action_reply_owner import ActionAssetsReplyReads
from ios.adapters.assets_budget import operation
from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
from ios.adapters.assets_episode_metadata_graph import readonly_store
from ios.adapters.assets_end_metadata import signature
from ios.adapters.assets_generation_action_history import action_original
from ios.adapters.assets_model_removal import OwnedAssetsModelRemoval
from ios.adapters.assets_page_clients import PageLeaseUpload
from ios.adapters.assets_picker import root
from ios.adapters.assets_selected_profile import EpisodeAssetsFiles
from ios.adapters.assets_tree_owner import OwnedAssetsTree
from ios.adapters.assets_upload import OwnedAssetsUpload
from ios.adapters.assets_usage_owner import OwnedAssetsUsage

VERSION=1
ACTIONS={2:9,3:16,4:22}


class AssetsDeadPageRetirement:
    def __init__(self,upload,removal,action,store,*,tree,usage,monotonic=time.monotonic,sleep=time.sleep):
        need(type(action) is AssetsActionScope and isinstance(store,PrivateFeatureState)
            and callable(monotonic) and callable(sleep))
        self.upload,self.removal,self.action,self.store=upload,removal,action,store
        self.actions,self.monotonic,self.sleep,self.historical=action.owner,monotonic,sleep,False
        self.bind(tree,usage);self.previous=store.read();self.state=None
        if self.previous is not None:self.state=self.decode(self.previous)
        self.guard()

    def bind(self,tree,usage):
        upload=self.upload
        need(type(upload) is PageLeaseUpload and type(upload.files) is EpisodeAssetsFiles
            and type(upload.replies) is ActionAssetsReplyReads and type(self.removal) is OwnedAssetsModelRemoval
            and (isinstance(tree,OwnedAssetsTree) and tree.upload is upload or self.historical and tree is None)
            and isinstance(usage,OwnedAssetsUsage) and usage.source is upload and self.removal.usage is usage
            and self.removal.parsed.model.usage.source is upload)
        self.episode,self.files,self.replies=upload.episode,upload.files,upload.replies
        self.run,self.binding,self.lock=self.files.run,deepcopy(upload.binding),upload.lock
        self.clients={'tree':tree,'usage':usage}
        need(self.episode.index in ACTIONS and self.action.index==ACTIONS[self.episode.index]
            and self.actions is self.replies.action_history and self.replies.reply_episode is self.episode
            and self.actions.selected is self.episode.owner.selected
            and self.store.path==Path(self.episode.descriptor['directories']['primary']['stateRoot']['path'])/
                ('ios-assets-dead-page-clients-'+self.run+'-primary.json'))
        parsed=self.removal.parsed;baking=getattr(parsed,'baking',None)
        backend=parsed.backend if baking is None else baking.backend
        owners=dict(upload=upload,picker=upload.picker,tree=tree,usage=usage,removal=self.removal,
            parsed=parsed,parsed_sources=parsed.sources,model=parsed.model,model_sources=parsed.model.sources,backend=backend)
        if baking is not None:owners['baking']=baking
        self.origins={kind:(owner,deepcopy(owner.previous) if owner is not None else None,deepcopy(owner.state) if owner is not None else None)
            for kind,owner in owners.items()}

    @classmethod
    def from_archive(cls,graph,actions,store):
        need(type(graph) is AssetsEpisodeModelGraph and graph.dependency_mode and graph.metadata is None
            and type(actions) is AssetsActionPhases and graph.actions is actions and isinstance(store,PrivateFeatureState))
        graph.guard();owner=object.__new__(cls);owner.upload,owner.removal,owner.actions=graph.upload,graph.removal,actions
        original=action_original(actions,ACTIONS[graph.episode.index],include_saved_pending=True)
        owner.action=SimpleNamespace(index=ACTIONS[graph.episode.index],ticket=original['ticket'])
        owner.store,owner.monotonic,owner.sleep,owner.historical=readonly_store(store),time.monotonic,None,True
        owner.bind(graph.tree,graph.usage);owner.previous=owner.store.read();owner.state=None;need(owner.previous is not None)
        owner.state=owner.decode(owner.previous);owner.guard();graph.guard();return owner

    def guard(self):
        self.lock.assert_held();self.episode.guard();self.actions.guard()
        need(same(self.store.read(),self.previous) and self.upload.state is not None and self.upload.state['phase']=='uploaded')
        for kind,(owner,header,state) in self.origins.items():
            if owner is None:need(kind=='tree' and PrivateFeatureState(self.origin_path(kind,owner)).read() is None)
            else:need(same(owner.store.read(),header) and same(owner.previous,header) and same(owner.state,state))
        need(self.removal.state['phase']=='model-gone' and self.removal.state['contextClosedBy'] is not None)
        if not self.historical:
            self.action.guard();need(self.replies.reply_action is self.action and self.files.native.guard() is not False)
        else:action_original(self.actions,self.action.index,include_saved_pending=True)
        need(same(self.files.store.read(),self.files.previous) and same(self.replies.store.read(),self.replies.previous))
        if self.state is not None:need(same(self.state['knownJobs'],self.known_jobs()) and same(self.state['originFiles'],self.origin_files()))
        return True

    def context(self):
        return dict(path=str(self.actions.store.path),index=self.action.index,ticket=self.action.ticket)

    def origin_path(self,kind,owner):
        if owner is not None:return owner.store.path
        need(kind=='tree');return Path(self.episode.descriptor['directories']['primary']['stateRoot']['path'])/('ios-assets-'+self.run+'-primary-tree.json')

    def headers(self):
        return {kind:dict(path=str(self.origin_path(kind,owner)),sha256=digest(header)) for kind,(owner,header,_state) in self.origins.items()}

    def known_jobs(self):
        need(self.replies.state is not None)
        return [{key:deepcopy(job[key]) for key in ('slot','query','issuedEpochMs')} for job in self.replies.state['jobs']]

    def settled_inputs(self):
        for kind,(owner,_header,_state) in self.origins.items():
            if owner is None:continue
            if kind=='removal':
                owner.decode(owner.previous);continue
            if kind in ('upload','picker','tree','usage') and owner.state is not None:
                need(all(entry.get('resolvedBy') is not None and entry.get('abandonedBy') is None for entry in owner.state.get('inputs',[])))

    def origin_files(self):
        paths=set()
        for _kind,(owner,_header,_state) in self.origins.items():
            if owner is None or owner.previous is None:continue
            paths.add(owner.store.path)
            originals=getattr(owner,'originals',None)
            if originals is not None:
                need(owner.state.get('pending') is None and not owner.state.get('interrupted',[]))
                paths.update(originals.path(originals.expand(ref)) for ref in owner.state.get('frames',[]))
            raws=getattr(owner,'raws',None)
            if raws is not None:need(raws.pending is None);paths.update(raws.owned_paths())
            if _kind=='backend':
                for row in owner.state['samples']:
                    if row['parts'] is not None:
                        need(row['parts']['complete'])
                        paths.update(owner.parts.store.path(ref) for ref in row['parts']['chunks'])
        result=[]
        for path in sorted(paths,key=str):
            pin=signature(path);need(pin is not None);result.append(dict(path=str(path),signature=list(pin)))
        return result

    def inspect_origins(self):
        # Once, before retirement, reopen each actual origin codec. Subsequent
        # guards retain that exact immutable set while only File4/Reply3 advance.
        for _kind,(owner,_header,_state) in self.origins.items():
            if owner is not None and owner.previous is not None:need(same(owner.decode(owner.previous),owner.state))

    def cleanup_page(self,current,state):return root(current,'page',alive=False,identifier=state['page'])

    def window(self,value,*,complete):return OwnedAssetsUpload.window(self,value,self.upload.state,complete=complete)

    def packet(self,request):
        rows=[row for row in self.files.state['originals'] if row['query']['operation']=='observe' and row['packet']['requestId']==request]
        need(len(rows)==1);return rows[0]['packet']

    def epoch_bounds(self,packets):
        if self.historical:
            original=action_original(self.actions,self.action.index,include_saved_pending=True)
            before,after=original['phaseBefore']['capturedEpochMs'],original['phaseAfter']['capturedEpochMs']
        else:
            pending=self.actions.state['pending'];need(pending is not None and pending['index']==self.action.index)
            before,after=pending['before']['capturedEpochMs'],None
        for packet in packets:
            need(packet['clockBefore']['epochMs']>=before and (after is None or packet['clockAfter']['epochMs']<=after))

    def decode(self,value):
        exact(value,{'iosAssetsDeadPageRetirementVersion','binding','runId','episode','action','origins','fileOwnerToken','replyOwnerToken','payload'})
        need(type(value['iosAssetsDeadPageRetirementVersion']) is int and value['iosAssetsDeadPageRetirementVersion']==VERSION
            and same(value['binding'],self.binding) and value['runId']==self.run and same(value['episode'],self.episode.link())
            and same(value['action'],self.context()) and same(value['origins'],self.headers())
            and value['fileOwnerToken']==self.files.state['token'] and value['replyOwnerToken']==self.replies.state['token'])
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0]
        exact(state,{'phase','knownJobs','originFiles','window','releasedBy'})
        need(state['phase'] in ('closing-replies','quiet','releasing','retired') and same(state['knownJobs'],self.known_jobs()) and same(state['originFiles'],self.origin_files()))
        self.settled_inputs();frames=self.window(state['window'],complete=state['phase'] in ('releasing','retired'));self.epoch_bounds(frames)
        if state['phase']!='closing-replies':need(self.replies.state['phase']=='closed')
        if state['phase']=='retired':
            need(self.files.state['phase']=='retired' and state['releasedBy'] is not None)
            packet=self.packet(state['releasedBy']);need(packet['source']['files']=={'exists':False,'files':[]})
            from ios.adapters.assets_files import quiet
            quiet(packet['source']);self.cleanup_page(dict(inventory=packet['source']['ui']),self.upload.state)
            root(dict(inventory=packet['source']['ui']),'picker',alive=False,identifier=self.upload.state['picker']);self.epoch_bounds([packet])
        else:need(state['releasedBy'] is None)
        return state

    def envelope(self):
        return dict(iosAssetsDeadPageRetirementVersion=VERSION,binding=self.binding,runId=self.run,episode=self.episode.link(),
            action=self.context(),origins=self.headers(),fileOwnerToken=self.files.state['token'],replyOwnerToken=self.replies.state['token'],payload=pack([self.state]))

    def save(self):
        self.guard();need(not self.historical);value=self.envelope();self.decode(value)
        self.store.write(value,self.previous);self.previous=deepcopy(value)

    @operation
    def reserve(self):
        self.guard();need(self.state is None and self.files.state['phase']=='staged');self.inspect_origins();self.settled_inputs()
        self.state=dict(phase='closing-replies',knownJobs=self.known_jobs(),originFiles=self.origin_files(),window=dict(requests=[],hostBrackets=[]),releasedBy=None);self.save()

    def recover_saved_sources(self):
        # Partial/unknown/unissued originals remain duties. Only an actual
        # saved original may finish data bookkeeping; no request is replayed.
        self.guard()
        if self.replies.query_sources.state['pending'] is not None:
            row=self.replies.query_sources.state['pending']['row'];query=row['query']
            need(row['actionIndex']==self.action.index and query['operation'] in ('observe','retire')
                and query.get('jobId') in {job['query']['commandId'] for job in self.state['knownJobs']})
            self.replies.query_sources.recover()
        if self.replies.sources.pending is not None:self.replies.recover_capture()
        if self.files.sources.pending is not None:self.files.recover_capture()

    @operation
    def retire(self):
        self.guard();need(not self.historical and self.state is not None);self.recover_saved_sources()
        if self.state['phase']=='retired':self.decode(self.previous);return self.packet(self.state['releasedBy'])
        if self.state['phase']=='closing-replies':
            need(same(self.state['knownJobs'],self.known_jobs()));self.replies.close()
            self.state['phase']='quiet';self.save()
        if self.state['phase']=='quiet':
            window=self.state['window']
            for _ in range(64-len(window['requests'])):
                self.guard();before=self.monotonic();packet=self.files.observe();after=self.monotonic()
                window['requests'].append(packet['requestId']);window['hostBrackets'].append(dict(before=before,after=after))
                frames=self.window(window,complete=False);self.save()
                if len(frames)>=2 and before-window['hostBrackets'][0]['after']>=3 and all(
                        packet['clockBefore'][key]-frames[0]['clockAfter'][key]>=3000 for key in ('epochMs','monotonicMs')):
                    self.window(window,complete=True);break
                self.sleep(.1)
            else:need(False)
            self.state['phase']='releasing';self.save()
        need(self.state['phase']=='releasing');self.guard()
        packet=self.files.release() if self.files.state['phase']=='staged' else self.files.recover_release()
        self.state.update(phase='retired',releasedBy=packet['requestId']);self.save();return packet

    def retired(self):
        self.guard();need(self.state is not None and self.state['phase']=='retired' and same(self.decode(self.previous),self.state))
        return dict(iosAssetsDeadPageRetirementLinkVersion=1,path=str(self.store.path),sha256=digest(self.previous),
            episode=self.episode.link(),action=self.context(),oldUploadUnchanged=True,wholeEndEligible=False)
