"""Real Restoration Current7/navigation clock joins; Qt/native/SDK are models.

No packet, clock, source method or expected native state is altered to pass.
The explicit hostile copies below never replace an original or durable WAL.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,json
from copy import deepcopy
from adapters.native_clock_join import validate_join
from adapters.normal_ui import NativeUIError
from ios.adapters import lifecycle_restoration as product,navigation_state
from lifecycle_whole_fresh_fixture import FreshWholeFixture


class LifecycleRestorationClockOriginalModels(FreshWholeFixture):
    async def test_actual_nested_navigation_endpoints_join_and_replay_without_new_query(self):
        before=self.counts();scope=self.restoration
        def read():
            with scope.lock.held():
                reference=deepcopy(scope.state['baseline']);original=scope.files.expand(reference);path=scope.files.path(original)
                identity=(path.stat().st_ino,path.read_bytes())
                frame=scope.original(reference);again=scope.original(reference)
                self.assertEqual(frame,again);self.assertEqual(identity,(path.stat().st_ino,path.read_bytes()))
                self.assertEqual(json.loads(self.normal.raw[navigation_state.FILE]),frame['navigation'])
                packet=deepcopy(frame['navigation']);joined=validate_join(frame['clockJoin'],product.navigation_clock_originals(packet))
                self.assertEqual([dict(source='getterBefore',field='capturedEpochMs',epochMs=packet['clockBefore']['epochMs']),
                    dict(source='getterAfter',field='capturedEpochMs',epochMs=packet['clockAfter']['epochMs'])],joined['sourceTimes'])
                self.assertEqual(packet,frame['navigation']);return identity
        await asyncio.to_thread(read);self.assertEqual(before,self.counts())

    async def test_changed_clock_copies_and_same_helper_code_refuse_without_requery_or_original_change(self):
        before=self.counts();scope=self.restoration
        def reject():
            with scope.lock.held():
                reference=deepcopy(scope.state['baseline']);path=scope.files.path(scope.files.expand(reference))
                identity=(path.stat().st_ino,path.read_bytes());frame=scope.original(reference)
                for side in ('clockBefore','clockAfter'):
                    hostile=deepcopy(frame);hostile['navigation'][side]['epochMs']+=1
                    with self.assertRaises(NativeUIError):product.baseline_original(hostile,self.binding,self.run)
                hostile=deepcopy(frame);hostile['clockJoin']['sourceTimes'][0]['epochMs']+=1
                with self.assertRaises(NativeUIError):product.baseline_original(hostile,self.binding,self.run)
                function=product.navigation_clock_originals;code=function.__code__
                function.__code__=code.replace(co_consts=(*code.co_consts,'explicit-foreign-navigation-clock-helper'))
                try:
                    with self.assertRaisesRegex(RuntimeError,'receiver/code changed'):scope.check()
                finally:function.__code__=code
                self.assertEqual(frame,scope.original(reference));self.assertEqual(identity,(path.stat().st_ino,path.read_bytes()))
        await asyncio.to_thread(reject);self.assertEqual(before,self.counts())
