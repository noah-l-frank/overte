"""All29 original membership and real cleanup-activation/server counters.

No external acceptance consumers or hardware execute in these host models.
Global scene/image/resource/process/SDK duties remain explicitly blocking.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_ui import NativeUIError
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.assets_cleanup_phase import AssetsCleanupPhase
from ios.adapters.assets_cleanup_runtime import CurrentCleanupAssetsRuntime
from ios.adapters.assets_whole_cleanup import AssetsWholeCleanup
from ios.self_tests.assets_whole_input_fixture import Fixture
from ios.self_tests.assets_picker_fixture import RUN


class AssetsWholeMembershipCleanupTests(unittest.TestCase):
    def setUp(self):self.f=Fixture(self);self.b=self.f.boundary
    def no_native(self,*args,**kwargs):raise AssertionError('Actual original-only ownership may not send native work')
    def activate_cleanup(self):
        a=self.f.a;a.epoch=max(a.epoch,self.b.clock())+1;a.journal.activate(RUN,'f'*32,'cleanup',{})
    def native_cleanup(self,instance,selector,lock):
        role=instance.assets_episode.role(selector);self.assertIs(lock,instance.assets_episode.locks[role])
        instance.assets_cleanup.guard()
        return (self.f.ports(instance.assets_cleanup) if role=='primary' else self.f.peer_permissions.ports(instance.assets_cleanup))
    def test_all29_exact_original_membership_reopens_all_four_generations_without_native_queries(self):
        self.f.until(29);before=deepcopy(self.b.inputs)
        with patch.object(self.b,'exchange',side_effect=self.no_native),patch.object(self.b,'send',side_effect=self.no_native),patch.object(self.b.reads,'send',side_effect=self.no_native),patch.object(self.b.native_clock,'send',side_effect=self.no_native):
            report=self.f.driver.input_ownership()
        self.assertEqual(before,self.b.inputs);self.assertEqual(29,report['completedActionOriginals'])
        self.assertEqual((5,4),(report['bornEpisodes'],report['actualPageGenerations']))
        self.assertEqual({2,3,4},set(report['views']));self.assertEqual({2,3,4},set(report['graphs']))
        self.assertEqual(report['paths'],set(report['filePins']));self.assertLessEqual(report['paths'],report['actualOriginalReads'])
        self.assertFalse(report['wholeEndEligible']);self.assertIn('independent-peer-observation',report['duties'])
    def test_unknown_real_reply_original_cannot_hide_beside_completed_generations(self):
        self.f.until(29);root=self.f.scope.owner.path(4,'primary','stateRoot')
        orphan=root/('assets-g4-a23-native-replies-frame-sources-'+RUN+'-primary-0031-'+('f'*64)+'.json')
        orphan.touch(mode=0o600,exist_ok=False);info=orphan.stat()
        with self.assertRaises(NativeUIError):self.f.driver.input_ownership()
        self.assertTrue(orphan.exists());self.assertEqual((info.st_dev,info.st_ino,0),(orphan.stat().st_dev,orphan.stat().st_ino,orphan.stat().st_size))
    def test_actual_distinct_cleanup_restores_settings_and_exact_server_baseline_with_old_upload_headers_unchanged(self):
        self.f.until(29);before={scope.index:(scope.owner.path(scope.index,'primary','stateRoot')/('ios-assets-'+RUN+'-primary-upload.json')).read_bytes()
            for scope in self.f.scopes if scope.index in (2,3,4)}
        self.activate_cleanup()
        with patch.object(CurrentCleanupAssetsRuntime,'_assets_sources',lambda instance,selector,lock:self.native_cleanup(instance,selector,lock)):report=self.f.driver.cleanup_normal()
        self.assertTrue(report['settingsOriginalRestored']);self.assertTrue(report['knownInputFilesRetired'])
        self.assertGreaterEqual(report['originalServerMappingBlobAndWorkerRestoration']['nativeQuietMs'],3000)
        self.assertGreaterEqual(report['originalServerMappingBlobAndWorkerRestoration']['hostQuietMs'],3000)
        self.assertFalse(report['wholeEndEligible']);self.assertFalse(report['performed'])
        self.assertEqual(['set','set','restore'],[row['query']['operation'] for row in self.f.driver.permissions.client.state['commands']])
        for scope in self.f.scopes:
            if scope.index in before:self.assertEqual(before[scope.index],(scope.owner.path(scope.index,'primary','stateRoot')/('ios-assets-'+RUN+'-primary-upload.json')).read_bytes())
        self.assertTrue(self.f.driver.actions.state['complete']);self.assertEqual('f'*32,self.f.driver.last_cleanup.owner.read()['ticket'])
    def test_real_foreign_new_blob_blocks_server_restoration_and_is_not_deleted(self):
        self.f.until(29);digest=self.f.backend.blob(b'Unowned actual server blob after the admitted first baseline')
        # The real model's persisted file is the authority; neither cleanup nor
        # the test supplies an expected restoration result to the collector.
        path=self.f.backend.b.files/digest;info=path.stat();self.activate_cleanup()
        with patch.object(CurrentCleanupAssetsRuntime,'_assets_sources',lambda instance,selector,lock:self.native_cleanup(instance,selector,lock)):
            with self.assertRaises(NativeUIError):self.f.driver.cleanup_normal()
        cleanup=self.f.driver.last_cleanup;self.assertEqual('observing-server',cleanup.state['phase'])
        self.assertIsNone(cleanup.state['serverProof']);self.assertTrue(path.exists())
        self.assertEqual((info.st_dev,info.st_ino),(path.stat().st_dev,path.stat().st_ino));self.assertEqual(29,len(self.f.a.owner.state['records']))
    def test_actual_prefix_cleanup_retains_pending_regular_action_and_cannot_claim_normal_restoration(self):
        self.f.until(2);self.f.input(3);self.activate_cleanup();driver=self.f.driver
        owner=AssetsCleanupPhase(driver.selected,driver.actions,driver.episodes,
            PrivateFeatureState(driver.root/('ios-assets-cleanup-phase-'+RUN+'.json')),driver.actions.locks,monotonic=driver.monotonic)
        cleanup=AssetsWholeCleanup(driver,owner);before=deepcopy(self.b.inputs);commands=deepcopy(driver.permissions.client.state)
        with self.assertRaises(NativeUIError):cleanup.normal()
        self.assertEqual(before,self.b.inputs);self.assertEqual(commands,driver.permissions.client.state)
        self.assertEqual('prefix',owner.read()['mode']);self.assertIn('regular-action-pending-original',owner.read()['prefixDuties'])
        self.assertEqual(2,len(self.f.a.owner.state['records']));self.assertIsNotNone(self.f.a.owner.state['pending']);self.assertIsNone(cleanup.state)


if __name__=='__main__':unittest.main()
