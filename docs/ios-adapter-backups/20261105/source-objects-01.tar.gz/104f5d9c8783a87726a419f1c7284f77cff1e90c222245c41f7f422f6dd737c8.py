"""Source-only prospect: one readonly60+5 target, no automatic second lease."""
from pathlib import Path
import importlib.util
import json
import os
import signal
import subprocess
import sys
import threading
import time
import traceback
from metadata import SOURCE, REPO, INPUT, CASE, head, validate, sha, pin, census, load, fds, proc


def main():
    assert sys.dont_write_bytecode and Path.cwd() == REPO and len(sys.argv) == 6
    expected_head, source_sha, plan_sha, plan_path, output = sys.argv[1:]
    assert head() == expected_head
    plan, _operands = validate(Path(plan_path), plan_sha, source_sha, expected_head)
    here = Path(output)
    outer = Path(str(here) + '-outer')
    assert here.is_absolute() and here.resolve(strict=False) == here
    assert here.parent == REPO / '.ios-host-tmp' and here.name.startswith('audio-normal4-retained-probe-')
    assert here != SOURCE and not here.exists() and not outer.exists()
    custody = plan['globalCustody']
    for key in ('helperPath', 'seedPath', 'baselinePath'):
        assert custody[key] in plan['physicalPins']
    assert sha(custody['helperPath']) == 'bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
    helper_path = Path(custody['helperPath'])
    assert Path(custody['seedPath']) == helper_path.with_name('global-original-roots-seed.json')
    assert sha(custody['seedPath']) == custody['seedSha256']
    assert sha(custody['baselinePath']) == custody['baselineSha256']
    spec = importlib.util.spec_from_file_location('audio_retained_global_corpus_controller', helper_path)
    corpus = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(corpus)
    old_global = load(custody['baselinePath'])
    assert set(old_global) == set(load(custody['seedPath'])['roots'])
    assert corpus.current() == old_global
    input_before = census(INPUT)
    assert input_before == load(plan['inputBaseline']) and len(input_before) == 869
    before = {path: pin(path) for path in plan['physicalPins']}
    assert before == plan['physicalPins']
    parent_fds, parent_threads = fds(), tuple(threading.enumerate())
    outer.mkdir(mode=0o700)
    here.mkdir(mode=0o700)
    def save(name, body):
        path = outer / name
        with path.open('x') as stream:
            json.dump(body, stream, sort_keys=True, indent=2)
            stream.write('\n')
        path.chmod(0o600)
    save('all-pins-before.json', before)
    save('input-before.json', input_before)
    save('global-before.json', old_global)
    baseline = {int(path.name): proc(int(path.name)) for path in Path('/proc').iterdir() if path.name.isdecimal()}
    child = None
    birth = None
    owned = {}
    problems = []
    timed_out = forced = False
    term_at = None
    started = time.monotonic()
    try:
        with (here / 'child-stdin.eof').open('xb'):
            pass
        with (here / 'child-stdin.eof').open('rb') as incoming, (here / 'child-stdout.log').open('xb') as stdout, (here / 'child-stderr.log').open('xb') as stderr:
            child = subprocess.Popen([sys.executable, '-B', str(SOURCE / 'run-one.py'), expected_head, source_sha,
                plan_sha, str(Path(plan_path).resolve(strict=True)), str(here)], cwd=REPO,
                stdin=incoming, stdout=stdout, stderr=stderr, start_new_session=True,
                env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        birth = proc(child.pid)
        assert birth is not None and birth['parent'] == os.getpid()
        assert birth['group'] == birth['session'] == birth['pid']
        owned[birth['pid']] = birth
        save('child-birth.json', birth)
        while child.poll() is None:
            table = {int(path.name): proc(int(path.name)) for path in Path('/proc').iterdir() if path.name.isdecimal()}
            changed = True
            while changed:
                changed = False
                for pid, row in table.items():
                    if row is None or pid in owned:
                        continue
                    if row['parent'] in owned or row['group'] == birth['group'] or row['session'] == birth['session']:
                        assert pid not in baseline
                        owned[pid] = row
                        problems.append(dict(kind='forbidden-child-birth', identity=row))
                        changed = True
            for pid, identity in owned.items():
                actual = proc(pid)
                assert actual is None or actual == identity
            elapsed = time.monotonic() - started
            if elapsed >= 60 and term_at is None:
                assert proc(child.pid) == birth
                timed_out = True
                term_at = time.monotonic()
                os.kill(child.pid, signal.SIGTERM)
            if term_at is not None and time.monotonic() - term_at >= 5:
                assert proc(child.pid) == birth
                forced = True
                os.kill(child.pid, signal.SIGKILL)
                break
            time.sleep(0.05)
        child.wait()
    except BaseException:
        problems.append(dict(kind='supervisor-exception', traceback=traceback.format_exc()))
    finally:
        residual = []
        for pid, identity in owned.items():
            actual = proc(pid)
            if actual is not None:
                residual.append(dict(bound=identity, actual=actual))
                if actual == identity:
                    os.kill(pid, signal.SIGKILL)
        if child is not None:
            child.wait()
        remaining = {pid: proc(pid) for pid in owned if proc(pid) is not None}
        save('process-drain.json', dict(owned=list(owned.values()), residual=residual, remaining=remaining))
        assert not remaining
        if residual:
            problems.append(dict(kind='residual-required-kill', identities=residual))
        # All own processes and stdio handles are closed before these reads.
        input_first, input_second = census(INPUT), census(INPUT)
        global_first, global_second = corpus.current(), corpus.current()
        after = {path: pin(path) for path in before}
        result = load(here / 'child-result.json') if (here / 'child-result.json').is_file() else None
        restoration = load(here / 'write-port-restoration.json') if (here / 'write-port-restoration.json').is_file() else None
        whole_first, whole_second = census(here), census(here)
        expected_files = {'child-stdin.eof', 'child-stdout.log', 'child-stderr.log', 'preimport-proof.json',
            'term-stack.log', 'child-input-first.json', 'child-input-second.json', 'child-result.json',
            'write-port-restoration.json'}
        passed = child is not None and child.returncode == 0 and not problems and not timed_out and not forced
        passed = passed and input_first == input_second == input_before
        passed = passed and global_first == global_second == old_global and before == after and head() == expected_head
        passed = passed and whole_first == whole_second and set(whole_first) == expected_files | {'.'}
        passed = passed and result is not None and result['status'] == 'PASS' and result['testsRun'] == 1 and result['selected'] == CASE
        passed = passed and restoration is not None and restoration['restored'] and restoration['actualCportCount'] == 27
        passed = passed and fds() == parent_fds and tuple(threading.enumerate()) == parent_threads
        for name, body in (('input-first.json', input_first), ('input-second.json', input_second),
                ('global-first.json', global_first), ('global-second.json', global_second),
                ('all-pins-after.json', after), ('whole-output-first.json', whole_first),
                ('whole-output-second.json', whole_second)):
            save(name, body)
        save('terminal.json', dict(status='PASS' if passed else 'FAIL_OR_REFUSED', selected=CASE,
            childReturnCode=None if child is None else child.returncode,
            elapsedOuterSeconds=time.monotonic()-started, timedOut=timed_out, forced=forced,
            problems=problems, input869Unchanged=input_first == input_second == input_before,
            oldGlobalBodiesUnchanged=global_first == global_second == old_global,
            allPhysicalPinsUnchanged=before == after, twoClosedWholeOutputsEqual=whole_first == whole_second,
            actualParentFDThreadDrain=fds() == parent_fds and tuple(threading.enumerate()) == parent_threads,
            noOwnProcesses=not remaining, nativeQualified=False, normalFourthActionQualified=False, wholeQualified=False))
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
