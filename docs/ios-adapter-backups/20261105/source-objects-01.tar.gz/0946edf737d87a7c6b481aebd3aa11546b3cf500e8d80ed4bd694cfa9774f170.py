"""Root external custody around the exact reviewed four-case Snapshot Scene utility."""
from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys
R=Path.cwd()/'.ios-host-tmp';D=Path(__file__).resolve().parent
C=R/'root-ios-current757-after-avatar-own7-negative-context-20261104'
H=R/'snapshot-scene-own4-prepared-root757-head9d58-b4-20261104'
SHA='4ea123c07a1d0bf3dccbae915421894a68cef0ed5a6415478dc5e2224364d885'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,v):
 p=D/n
 with p.open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 p.chmod(0o600)
assert sys.flags.no_site and sys.dont_write_bytecode
assert sha(H/'approved-inputs.json')==SHA
assert sha(C/'root-context.json')=='760372671baed848a79f470c83e146a679e6c0017ef1c96ef7922b101bc0b0be'
assert sha(C/'global_original_corpus.py')=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
helper=runpy.run_path(str(C/'global_original_corpus.py'))
expected=json.loads((C/'global-original-corpus-baseline.json').read_text());before=helper['current']()
assert before==expected and len(before)==757
put('global-before.json',before);put('preflight.json',dict(status='EXACT_757_OLD_ORIGINAL_BODIES_MATCH',roots=len(before)))
print('ROOT_757_PREFLIGHT_PASS_SNAPSHOT_OWN4_START',flush=True)
with(D/'supervisor-stdout.log').open('xb')as out,(D/'supervisor-stderr.log').open('xb')as err:
 result=subprocess.run([sys.executable,'-S','-B',str(H/'supervise-own4.py'),SHA],cwd=Path.cwd(),env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err)
put('supervisor-return.json',dict(returnCode=result.returncode))
outer=H.with_name(H.name+'-outer');terminal=json.loads((outer/'terminal.json').read_text());drain=json.loads((outer/'actual-process-drain.json').read_text())
assert terminal['ownProcessesAbsent']is True and not drain['remaining']
for b in drain['owned']:
 try:text=Path('/proc',str(b['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 values=text[text.rfind(')')+2:].split();assert int(values[19])!=b['startTicks'],'Original owned process still present'
first=helper['current']();second=helper['current']();assert first==second
assert all(first[k]==v for k,v in expected.items()) and set(first)==set(expected)
put('global-after-first.json',first);put('global-after-second.json',second)
put('postflight.json',dict(status='ALL_757_OLD_ORIGINAL_BODIES_UNCHANGED_BOTH_POST_STOP_CENSUSES',roots=len(first),censuses=3,supervisorReturnCode=result.returncode,actualUtilityStatus=terminal['status'],allProcessesAbsent=True))
files={p.name:dict(sha256=sha(p))for p in D.iterdir()if p.is_file()}
put('freeze.json',dict(files=files))
print(json.dumps(dict(returnCode=result.returncode,status=terminal['status'],freeze=sha(D/'freeze.json'),oldRoots=len(first))),flush=True)
