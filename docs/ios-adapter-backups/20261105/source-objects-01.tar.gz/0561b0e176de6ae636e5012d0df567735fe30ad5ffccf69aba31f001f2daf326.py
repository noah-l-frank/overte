import cProfile
import hashlib
import json
from pathlib import Path
import pstats
import socket
import subprocess
import time
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.native_feature_observation import NativeFeatureObservation
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.witness import Client
from ios.adapters.emote_rooted_fence_original import local
from ios.adapters.emote_archive_round import validation_batch as archive_round

data=json.loads(Path('.ios-host-tmp/resume442-emote-round-compare.case.json').read_text())
root=Path(data['root']);lock=ScriptSourceLock(Path(data['lock']));assert lock.path.is_file()
def pins():
    result={}
    for path in root.iterdir():
        if path.is_file():
            info=path.stat();result[str(path)]=(info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns,info.st_ctime_ns,hashlib.sha256(path.read_bytes()).hexdigest())
    return result
before=pins()
def decode():return local(data['value'],data['copies'],root=root,binding=data['binding'],run=data['run'],role=data['role'],lock=lock)
def measure(label,function):
    profile=cProfile.Profile();started=time.monotonic();profile.enable()
    try:result=function()
    finally:
        profile.disable();profile.dump_stats(str(Path(__file__).with_suffix('.'+label+'.pstats')))
    print(json.dumps(dict(label=label,seconds=time.monotonic()-started,originals=len(before))),flush=True)
    stats=pstats.Stats(profile)
    for (filename,line,method),value in sorted(stats.stats.items()):
        if filename.endswith(('emote_keys.py','emote_archive_round.py','original_frame_store.py')) and method in ('_original','_packet','original','packet','key_original','read','guard'):
            print(json.dumps(dict(file=Path(filename).name,line=line,method=method,primitive=value[0],calls=value[1],own=value[2],cumulative=value[3])),flush=True)
    stats.sort_stats('cumulative').print_stats(10)
    return result
with lock.held(),patch.object(socket,'socket',side_effect=AssertionError('No socket')),patch.object(socket,'create_connection',side_effect=AssertionError('No connection')),patch.object(subprocess,'Popen',side_effect=AssertionError('No child')),patch.object(PrivateFeatureState,'write',side_effect=AssertionError('No write')),patch.object(PrivateFeatureState,'discard',side_effect=AssertionError('No discard')),patch.object(Client,'request',side_effect=AssertionError('No fixture')),patch.object(NativeFeatureObservation,'read',side_effect=AssertionError('No native read')):
    old=measure('literal',decode)
    def batched():
        with archive_round(dict(artifactRoot=str(root),stateRoot=str(lock.path.parent)),lock=lock,primary_lock=lock):return decode()
    new=measure('pure-batch',batched)
    assert old['metadata']==new['metadata']
    for name in ('scope','keys','pointers'):assert old[name].previous==new[name].previous
assert before==pins()
print(json.dumps(dict(identicalOriginals=len(before),unchanged=True,forbiddenBoundaryCalls=0,wholeQualification=False)),flush=True)
