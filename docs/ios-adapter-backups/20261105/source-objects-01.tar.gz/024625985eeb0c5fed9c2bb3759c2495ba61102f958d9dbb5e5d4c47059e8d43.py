"""Root-only actual historical reader proof; never live/consumer authority."""
from pathlib import Path
import json
ROOT_SHA='2ff5ee4410313892fc57b88221dee193286f946c8f1655599d8599ad5fe78b55'
RESULT_SHA='a33977694dee68569977c0bbdedde235144f46f479a9b5a90d161edb67442d37'
REFS_SHA='8c8970ca87797f53590deed218bdcb9f868a29ce1fe7f473b60d5b4da425342a'
SUBJECT_SHA='94dd4070dc2bb3fea90df3fbc50bee393666e70d4bee6e98a39ca6200e4925e9'
BOOTSTRAP_SHA='ee5d241465b4590bbed0e7d967d5cc7ebcb43fdd947f1bdcc04019790b28ebe3'
GROUP_SHAS=('3c53025aa65d9670cf563d6a45b88e28bf7e3ab741760ef27533869de6f8183e','9150ae236ab2367baf70048cf0893e12454499f8359cdaa4739ce3fd3a3d16c1')


def qualification(repo,reference,pin):
    repo=Path(repo)
    assert repo.is_absolute()and repo.resolve(strict=True)==repo
    root=repo/'.ios-host-tmp/root-audio-received-mixer-ten-original-host-qualified-results-20261104'
    assert reference==dict(path=str(root/'freeze.json'),sha256=ROOT_SHA)
    physical={}
    def keep(path,sha=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        value=pin(path)
        if sha is not None:assert value['sha256']==sha
        physical[str(path)]=value;return path
    def read(path,sha=None):
        path=keep(path,sha);before=physical[str(path)];value=json.loads(path.read_text());assert pin(path)==before;return value
    def packet(path,sha):
        value=read(path,sha)
        for name,row in value['files'].items():
            assert not Path(name).is_absolute()and '..'not in Path(name).parts
            keep(path.parent/name,row if type(row)is str else row['sha256'])
        return value
    f=packet(root/'freeze.json',ROOT_SHA)
    assert f['files']=={'actual-receipt-references.json':{'sha256':REFS_SHA},'results.json':{'sha256':RESULT_SHA}}
    refs=read(root/'actual-receipt-references.json',REFS_SHA);assert type(refs)is dict and len(refs)==138
    for name,row in refs.items():assert set(row)=={'path','sha256'}and name==row['path'];keep(name,row['sha256'])
    result=read(root/'results.json',RESULT_SHA)
    assert result['status']=='ROOT_QUALIFIED_RECEIVED_MIXER_ORIGINAL_READER_TEN_HOST_CASES_ONLY'
    assert result['PCMOriginalReaderHostCasesQualified']is result['allOriginalClocksAndWAVBytesAndInodesPreserved']is result['allThirteenFreshOriginsPerGroupEstablished']is True
    assert result['actualCaseCount']==result['actualRetainedTemporaryDirectories']==10
    assert result['sourceFreeze']==SUBJECT_SHA and result['bootstrapFreeze']==BOOTSTRAP_SHA
    assert result['receivedMixerLiveAdmission']is result['consumerAdmission']is None
    for name in('nativeCompiled','featureQualified','individualPeerQualified','physicalADCQualified','physicalDACQualified','renderedOutputQualified','acousticQualified','wholeQualified'):assert result[name]is False
    subject=repo/'.ios-host-tmp/audio-received-mixer-original-pcm-source2-decoder-lifetime-private-20261104'
    bootstrap=repo/'.ios-host-tmp/audio-received-mixer-originals-ten-bootstrap1-closed-source-code-preparation-20261104'
    packet(subject/'source-freeze.json',SUBJECT_SHA);packet(bootstrap/'source-freeze.json',BOOTSTRAP_SHA)
    selections=read(bootstrap/'FIXED-TWO-GROUPS.json')
    groups=result['groups'];assert len(groups)==2
    cases=[];roots=[]
    for index,group in enumerate(groups):
        assert group['group']=='original-five-'+str(index+1)and group['freezeSha256']==GROUP_SHAS[index]and group['actualRetainedTDs']==5
        folder=Path(group['path']);packet(folder/'freeze.json',GROUP_SHAS[index]);original=read(folder/'results.json')
        assert original['status']=='ROOT_QUALIFIED_RECEIVED_PCM_ORIGINALS_FIVE_HOST_CASES_ONLY'
        assert original['group']==group['group']and original['sourceFreeze']==BOOTSTRAP_SHA
        assert original['PCMOriginalReaderHostCasesQualified']is original['allOldOriginalBodiesUnchanged']is True
        assert original['receivedMixerLiveAdmission']is original['consumerAdmission']is None
        assert original['nativeCompiled']is original['featureQualified']is original['individualPeerQualified']is original['wholeQualified']is False
        assert group['cases']==original['actualCases']==selections['groups'][group['group']]['caseIds']and len(group['cases'])==5
        cases.extend(group['cases']);terminal=group['actualTerminal'];assert terminal==original['terminal']
        here=Path(terminal['fullOwnCensusRoot']);assert terminal==read(here.with_name(here.name+'-outer')/'terminal.json')
        assert terminal['status']=='PASS'and terminal['childReturnCode']==terminal['NodeExecutions']==terminal['PythonExecutions']==terminal['globalScans']==0
        assert terminal['forcedKill']is terminal['timedOut']is terminal['individualPeerQualified']is terminal['nativeQualified']is False
        assert terminal['PCMUtilityQualification']is terminal['receivedMixerLiveAdmission']is None
        assert terminal['problems']==terminal['orphansRequiredKill']==terminal['fullOwnCensusExclusions']==[]
        for name in('actualClassCleanupCustodyEstablished','actualFiveCaseReceiptsEstablished','actualFiveTemporaryDirectoriesEstablished','actualOriginalLockCustodyEstablished','actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allThirteenSelectedActualRuntimeOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','ownProcessesAbsent','twoFullOwnOutputCensusesEqual','zeroCaseChildBirthsEstablished'):assert terminal[name]is True
        report=original['actualReport'];assert report==read(here/'child-receipts/report.json')and report['status']=='PASS'and report['testsRun']==5
        assert len(original['newOriginalRoots'])==4;roots.extend(original['newOriginalRoots'])
    assert result['actualCases']==cases and len(set(cases))==10 and result['requiredOriginalRoots']==roots and len(set(roots))==8
    for path in roots:assert Path(path).is_dir()and Path(path).resolve(strict=True)==Path(path)
    return dict(status='QUALIFIED_ORIGINAL_READER_HOST_TEN_ONLY_NOT_LIVE_OR_CONSUMER',rootProof=dict(reference),
        sourceFreeze=SUBJECT_SHA,bootstrapFreeze=BOOTSTRAP_SHA,actualCases=cases,requiredOriginalRoots=roots,
        historicalReaderQualified=True,receivedMixerLiveAdmission=None,consumerAdmission=None,nativeCompiled=False,wholeQualified=False),physical
