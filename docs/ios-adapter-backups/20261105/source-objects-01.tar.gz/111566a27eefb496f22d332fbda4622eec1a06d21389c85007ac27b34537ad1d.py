from pathlib import Path
import ast,hashlib,json
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');A=R/'.ios-host-tmp/audio-normal-close-evidence-root-preparation-20261028';C=R/'.ios-host-tmp/emote-original-target-pair-containment-final-composition-20261028';OLD=R/'.ios-host-tmp/emote-public-rooted-common-vertical-proposal-20261028';H=R/'.ios-host-tmp/emote-contained-public-root-preparation-20261028';H.mkdir(mode=0o700,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,v):(H/n).write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def virtual(rel):
 c=C/'candidate'/rel
 return c if c.is_file() else R/rel
def ids(rel,classes=None):
 module=rel.removeprefix('tests/device/').removesuffix('.py').replace('/','.')
 t=ast.parse(virtual(rel).read_bytes(),filename=rel)
 return [module+'.'+c.name+'.'+m.name for c in t.body if isinstance(c,ast.ClassDef) and (classes is None or c.name in classes) for m in c.body if isinstance(m,ast.FunctionDef) and m.name.startswith('test_')]
old=json.loads((OLD/'plan.json').read_text());metadata=old['suites']['metadata3']['caseIds'];full=old['suites']['full28']['caseIds'];codec=ids('tests/device/ios/self_tests/test_ios_emote_original_target_pair.py')
assert len(metadata)==3 and len(codec)==6 and len(full)==1
rooted=ids('tests/device/ios/self_tests/test_ios_emote_rooted_admission.py');legacy=ids('tests/device/ios/self_tests/test_ios_emote_admission.py',{'EmoteAdmissionTests'});regression=[i for i in rooted+legacy if i not in metadata]
assert len(rooted)==9 and len(legacy)==2 and len(regression)==10
allids=metadata+codec+regression+full;assert len(allids)==len(set(allids))==20
for case in allids:
 module,klass,method=case.rsplit('.',2);t=ast.parse(virtual('tests/device/'+module.replace('.','/')+'.py').read_bytes());c=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name==klass);assert any(isinstance(n,ast.FunctionDef) and n.name==method for n in c.body)
def suite(ids,cap,roots):return dict(caseIds=ids,count=len(ids),initialTimeoutSeconds=cap,killAfterSeconds=5,expectedRetainedRootsNotProof=roots)
suites=dict(metadata9=suite(metadata+codec,30,9),regression10=suite(regression,30,10),full28=suite(full,1800,5))
cp=json.loads((C/'plan.json').read_text());dump('expected-publication.json',[dict(path=x['path'],expectedSha256=x['candidateSha256']) for x in cp['nonRegistryPaths']])
owned=json.loads((C/'own-registry-spec.json').read_text());dump('own-registry-required.json',{k:v['after'] for k,v in owned.items()})
config=json.loads((A/'source-root-final-map.json').read_text());roots=config['orderedRoots'];modules={};queue=[i.rsplit('.',2)[0] for i in allids]+['ios.self_tests.retained_host_roots','ios.self_tests.test_ios_emote_marker_scope','ios.self_tests.test_ios_installed_code','ios.self_tests.emote_rooted_whole_end_fixture','ios.self_tests.test_ios_emote_configuration','ios.self_tests.test_ios_installed_adapter','ios.self_tests.test_ios_emote_terminal_journal']
def modulefile(name):
 for root in roots:
  for tail in [name.replace('.','/')+'.py',name.replace('.','/')+'/__init__.py']:
   rel=(Path(root)/tail).as_posix()
   if virtual(rel).is_file():return rel
 return None
while queue:
 name=queue.pop()
 if name in modules:continue
 rel=modulefile(name)
 if rel is None:continue
 modules[name]=dict(path=rel);t=ast.parse(virtual(rel).read_bytes())
 for n in ast.walk(t):
  if isinstance(n,ast.Import):queue.extend(x.name for x in n.names)
  elif isinstance(n,ast.ImportFrom):
   base=n.module or ''
   if n.level:
    parent=name.split('.')[:-1] if not rel.endswith('/__init__.py') else name.split('.')
    base='.'.join(parent[:len(parent)-n.level+1]+([base] if base else []))
   if base:queue.append(base);queue.extend(base+'.'+x.name for x in n.names if x.name!='*')
config['modules']=dict(sorted(modules.items()));dump('source-root-final-map.json',config)
md=(A/'run_metadata.py').read_text();line="    boundary=plan['unchangedGuard'];assert sha(REPO/boundary['path'])==boundary['sha256'],'Original Audio25 API source changed'\n";assert line in md;md=md.replace(line,'')
start=md.index('def registry_original():');md=md[:start]+'''def registry_original():
    raw=(REPO/'tests/device/contract-versions.json').read_bytes();value=json.loads(raw)
    required=load_plan()['registryRequired']
    assert all(value['contracts'].get(key)==row for key,row in required.items()),'Own Emote/config contract changed'
    validator=REPO/'tests/device/validate_contract_versions.py';tree=ast.parse(validator.read_text())
    assignments=[node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='REQUIRED' for target in node.targets)]
    assert len(assignments)==1;actual=ast.literal_eval(assignments[0].value)
    assert all(actual[key]==row['current'] for key,row in required.items()),'Own required Emote/config version changed'
    return dict(sha256=hashlib.sha256(raw).hexdigest(),required=required,validator=pin(validator))
'''
(H/'run_metadata.py').write_text(md)
kindtuple="('metadata9','regression10','full28')";audioTuple="('newSmall7','normalClose1','components25','legacy1','strict1')"
for name in ['root-supervise.py','run-selected.py']:
 s=(A/name).read_text().replace(audioTuple,kindtuple).replace('OVERTE_AUDIO_NORMAL_CLOSE_RUN_ROOT','OVERTE_EMOTE_CONTAINED_PUBLIC_RUN_ROOT').replace('ACTUAL_AUDIO_NORMAL_CLOSE_ROOT','ACTUAL_EMOTE_CONTAINED_ROOT')
 s=s.replace('wholeAudioQualified=False,physicalADCQualified=False,acousticQualified=False,peerQualified=False,physicalTimingQualified=False','wholeEmoteQualified=False,worldV7Qualified=False,nativeDeviceQualified=False')
 s=s.replace('Root current registry/foreign Photo/World or own PCM3 changed','Root current registry/foreign Photo/PCM/World or own Emote4keys changed')
 if name=='run-selected.py':
  start=s.index('from ios.self_tests import test_ios_audio_recorded_owner');end=s.index('from ios.self_tests.retained_host_roots',start)
  s=s[:start]+'''if kind=='metadata9':
    from ios.self_tests import test_ios_emote_configuration as settings_fixture
    from ios.self_tests import test_ios_installed_adapter as installed_fixture
    from ios.self_tests import test_ios_emote_original_target_pair as pair_fixture
    fixture_modules=[settings_fixture,installed_fixture,pair_fixture]
elif kind=='regression10':
    from ios.self_tests import test_ios_emote_configuration as settings_fixture
    from ios.self_tests import test_ios_installed_adapter as installed_fixture
    from ios.self_tests import test_ios_emote_terminal_journal as journal_fixture
    fixture_modules=[settings_fixture,installed_fixture,journal_fixture]
else:
    from ios.self_tests import test_ios_emote_marker_scope as marker_fixture
    from ios.self_tests import test_ios_installed_code as installed_code_fixture
    from ios.self_tests import emote_rooted_whole_end_fixture as end_fixture
    fixture_modules=[marker_fixture,installed_code_fixture,end_fixture]
''' +s[end:]
  s=s.replace('(recorded_fixture,installed_fixture)','fixture_modules')
 (H/name).write_text(s)
(H/'prepare-actual-map.py').write_text((A/'prepare-actual-map.py').read_text().replace('exact13+own2','exact17+own4-key-only2'))
packetnames=['.ios-host-tmp/emote-original-target-pair-containment-final-composition-20261028','.ios-host-tmp/emote-original-target-pair-final-composition-20261028','.ios-host-tmp/emote-original-target-pair-containment-overlay-20261028']
plan=dict(status='PRIVATE_SEPARATE_METADATA9_REGRESSION10_FULL28_UNRUN',suites=suites,broadSourceRoots=['tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml'],explicitExtraSourcePins=['CMakeLists.txt','tests/device/contract-versions.json','tests/device/validate_contract_versions.py'],explicitMainPin='interface/src/main.cpp',sourceRootMapSha256=sha(H/'source-root-final-map.json'),expectedPublicationCount=17,expectedPublicationSha256=sha(H/'expected-publication.json'),registryRequired={k:v['after'] for k,v in owned.items()},frozenPackets=[dict(path=n,freezeSha256=sha(R/n/'freeze.json')) for n in packetnames],timingEvidence=[],selection='metadata9=original metadata3 (including v6/v7/v8 Graphics and first closed RootedConfiguration)+accepted Codec6. regression10=other8 RootedAdmission methods plus2 old literal EmoteAdmission, excluding two already-covered metadata IDs. full28 exact1 unchanged body.20 globally unique IDs, no discovery or duplicate import TestCase collection.',localTempfileAliases=dict(metadata9=['ios.self_tests.test_ios_emote_configuration.tempfile','ios.self_tests.test_ios_installed_adapter.tempfile','ios.self_tests.test_ios_emote_original_target_pair.tempfile'],regression10=['ios.self_tests.test_ios_emote_configuration.tempfile','ios.self_tests.test_ios_installed_adapter.tempfile','ios.self_tests.test_ios_emote_terminal_journal.tempfile'],full28=['ios.self_tests.test_ios_emote_marker_scope.tempfile','ios.self_tests.test_ios_installed_code.tempfile','ios.self_tests.emote_rooted_whole_end_fixture.tempfile']),sourceGate='Root first runs frozen composition verify-before-publication.py immediately BEFORE mutation, applies reviewed17+own4 registry hunks only, then creates separate fresh actual map per kind AFTER publication. All complete source/stat/SHA/module expected hashes only from those actual maps, no old current maps copied.',budgetBeforeFirst='Root explicitly fixed BEFORE first actual runs: metadata9 at30+kill5; regression10 at30+kill5; FIRST actual full28 at1800+kill5. World1200 is unrelated. Existing inner act25/observe30/cleanup60/terminal30/checkpoint20/native1.5, worker1800 and scheduler65 remain unchanged.',resourceAudit='Metadata9 and regression10 hooks read: only actual private-file/CAS/model codec/routing, no Node/listeners/native/compiler/SDK. Full28 actual WholeRootedEnd root1, MarkerScope Primary+Actor roots2, InstalledCode roots2=5 roots; original retain_owned_root in paired is idempotent after wrapper retention. Pointer/Entity domains use existing marker roots. Full28 actual ordinary Node phoneEmote VM, real authenticated loopback HTTP/listener, UDP sockets, W3C input/PNG/typed original owners, independent Actor run_flow thread; native/Qt/GPU/OS/SDK/candidate preflight are declared models. LIFO cleanup closes worker before original source/Node/listener/UDP owners. No result/end authorization spy added.',worldV7Qualified=False,wholeEmoteQualified=False,acceptedCountUnchanged='5/14',targetImports=False,tests=False,publicEdits=False)
dump('suite-plan.json',plan)
for f in H.iterdir():
 if f.suffix=='.py':ast.parse(f.read_bytes(),filename=str(f))
 if f.suffix=='.json':json.loads(f.read_bytes())
print(json.dumps(dict(preparation=str(H),suites={k:v['count'] for k,v in suites.items()},globalUniqueIds=len(allids),pathOnlyModules=len(modules),actualMapsPresent=False)))
