"""Original Audio cleanup replacement and final distinct-SDK process ends.

The immutable old native history remains archived. Only a newly admitted actual
SDK/native process may establish restored initial idle history. Neither an ACK
nor a saved End DTO is accepted as live authority.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import os
from pathlib import Path
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.restart_inputs import validate_native_restart
from adapters.script_feature.history import same
from feature_journeys import terminal
from feature_journeys.retirement_receipts import binding_from_context
from ios.adapters.audio_passive_runtime import identity,fsync_directory
from ios.adapters.audio_whole_scope_retirement import IOSAudioWholeRetiredScope

class AudioWholeTerminal:
    def __init__(self,flow):self.flow=flow

    def end_row(self,stage,*,create=False):
        f=self.flow
        if stage==0:
            if f.state['oldEnd'] is None and create:f.state['oldEnd']=dict(root=str(Path(f.config['primaryWholeRoot'])/'ios-audio11-primary-end-0'),phase='planned',rootIdentity=None,proof=None);f.save()
            row=f.state['oldEnd']
        else:
            need(f.state['terminal'] is not None)
            if f.state['terminal']['primaryEnd'] is None and create:f.state['terminal']['primaryEnd']=dict(root=str(Path(f.config['primaryWholeRoot'])/'ios-audio11-primary-end-1'),phase='planned',rootIdentity=None,proof=None);f.save()
            row=f.state['terminal']['primaryEnd']
        return row

    def actual_end(self,stage,*,create=False):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
        f=self.flow;row=self.end_row(stage,create=create);need(row is not None);root=Path(row['root'])
        need(root==Path(f.config['primaryWholeRoot'])/('ios-audio11-primary-end-'+str(stage)))
        if row['phase']=='planned':
            need(create and row['rootIdentity'] is None and not root.exists());os.mkdir(root,0o700);fsync_directory(Path(f.config['primaryWholeRoot']))
            row['rootIdentity']=identity(root);row['phase']='opened';f.save()
        need(identity(root)==row['rootIdentity'])
        binding=f.state['bindings']['primary'] if stage==0 else f.state['replacement']['newBinding']
        return IOSOriginalKeeperProcessEnd(f.primary_runtime,f.primary_selector,root,binding,f.run,'primary',stage,'audiowhole',f.locks[1],epoch_ms=f.epoch_ms,monotonic=f.monotonic,sleep=f.sleep)

    def save_end(self,stage,end):
        f=self.flow;proof=end.retirement_original();need(proof['resourceRetirementEstablished'] is True)
        compact=deepcopy(proof);compact.pop('archive');row=self.end_row(stage);row.update(phase='complete',proof=compact);f.save();return proof

    def archived_end(self,stage):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd,filename
        f=self.flow;row=self.end_row(stage);need(row is not None and row['phase']=='complete')
        proof=deepcopy(row['proof']);store=PrivateFeatureState(f.adapter.state_path(f.primary_selector).with_name(filename('audiowhole','primary',stage)))
        proof['archive']=store.read();need(digest(proof['archive'])==proof['archiveSha256'])
        IOSOriginalKeeperProcessEnd.archived_original(proof,store=store,root=Path(row['root']),binding=proof['binding'],run=f.run,role='primary',stage=stage,profile_key='audiowhole',lock=f.locks[1]);return proof

    def replacement_owner(self,old_end):
        from ios.adapters.original_keeper_readmission import IOSOriginalKeeperReadmission
        f=self.flow;scope=IOSAudioWholeRetiredScope(f)
        return IOSOriginalKeeperReadmission(f.primary_runtime,f.primary_selector,old_end,scope,lock=f.locks[1],epoch_ms=f.epoch_ms,monotonic=f.monotonic)

    def replacement(self):
        f=self.flow
        with f.held():
            need(f.role=='primary' and f.state['phase'] in ('cleaning','replacing'))
            scope=IOSAudioWholeRetiredScope(f)
            if scope.original is None:scope.capture()
            end=self.actual_end(0,create=True)
            if self.end_row(0)['phase']!='complete':end.finish();self.save_end(0,end)
            else:self.archived_end(0)
            f.state['phase']='replacing';f.save()
            owner=self.replacement_owner(end);owner.prepare();owner.launch();proof=owner.replacement_original()
            need(proof['oldEndArchiveSha256']==end.retirement_original()['archiveSha256'] and proof['oldBinding']==f.state['bindings']['primary'])
            compact=deepcopy(proof);compact.pop('archive')
            if f.state['replacement'] is None:f.state['replacement']=compact;f.save()
            else:need(same(f.state['replacement'],compact))
            self.validate_replacement()
            from ios.adapters.audio_whole_restore import AudioWholeRestore
            AudioWholeRestore(f,f.current()).finish()
            # Real new native state must be initial idle; no old final event
            # is mapped onto the initial baseline and no counter is reset.
            current=f.current();refs=[]
            for i in range(2):
                if i:f.sleep(.35)
                ref,value=current.capture();actual=current.current_state(value)
                baseline=f.current(historical=True,stage='initial').original(f.state['baseline']['reference'])
                need(same(actual,f.current(historical=True,stage='initial').current_state(baseline)))
                from ios.adapters.audio_settings_source import settings
                from ios.adapters.audio_session_source import definite_permission
                need(same(settings(value['originals']['settings']),settings(baseline['originals']['settings']))
                    and definite_permission(value['originals']['session'])==definite_permission(baseline['originals']['session'])=='granted')
                refs.append(ref)
            f.state['phase']='cleaned';f.save()

    def validate_replacement(self):
        if self.flow.role=='actor':
            from ios.adapters.audio_whole_actor_replacement import validate
            return validate(self.flow)
        from ios.adapters.original_keeper_readmission import IOSOriginalKeeperReadmission
        f=self.flow;need(f.state['replacement'] is not None);proof=deepcopy(f.state['replacement']);end=self.actual_end(0)
        store=PrivateFeatureState(f.adapter.state_path(f.primary_selector).with_name('ios-original-keeper-readmission-audiowhole-primary-0.json'))
        scope=IOSAudioWholeRetiredScope(f);scope.end=end;proof['archive']=store.read();need(digest(proof['archive'])==proof['archiveSha256'])
        IOSOriginalKeeperReadmission.archived_original(proof,store=store,root=end.root,old_end=end,scope=scope,lock=f.locks[1])
        need(proof['oldBinding']==f.state['bindings']['primary'] and proof['newBinding']['sourceRevision']==proof['oldBinding']['sourceRevision']
            and proof['newBinding']['artifactSha256']==proof['oldBinding']['artifactSha256'] and proof['newBinding']['targetFingerprint']==proof['oldBinding']['targetFingerprint']
            and proof['newBinding']['sessionId']!=proof['oldBinding']['sessionId'] and proof['oldNativeFeatureInstance']!=proof['newNativeFeatureInstance'])
        return proof

    def validate_replacement_restoration(self):
        """Pure original idle/settings/permission join after real replacement.

        A cleaned phase or two arbitrary saved references does not prove the
        mandatory initial idle history. Replay the real two restoration cuts
        on the native instance established by actual original Readmission.
        """
        f=self.flow;need(f.role=='primary'and f.state['phase']in ('cleaned','terminal-ready','ending','ended'))
        proof=self.validate_replacement();f.validate_restoration()
        verified=f.state['replacementRestoration']['verified'];need(len(verified)==2 and verified[0]!=verified[1])
        current=f.current(historical=True,stage='replacement');initial=f.current(historical=True,stage='initial')
        baseline=initial.original(f.state['baseline']['reference']);expected=initial.current_state(baseline)
        from ios.adapters.audio_settings_source import settings
        from ios.adapters.audio_session_source import definite_permission
        previous=None
        for ref in verified:
            need(ref in current.state['records']);value=current.original(ref)
            need(same(current.current_state(value),expected)and value['originals']['native']['instance']==proof['newNativeFeatureInstance']
                and same(settings(value['originals']['settings']),settings(baseline['originals']['settings']))
                and definite_permission(value['originals']['session'])==definite_permission(baseline['originals']['session'])=='granted')
            if previous is not None:
                need(ref['index']>previous[0]['index']and value['clockJoin']['hostBeforeMonotonic']>=previous[1]['clockJoin']['hostAfterMonotonic'])
            previous=(ref,value)
        return proof

    def actor_peer(self):
        from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
        f=self.flow;peer=IOSAudioWholeFeature(f.adapter,f.primary_selector,f.run,'actor',f.client,f.config,epoch_ms=f.epoch_ms,monotonic=f.monotonic,sleep=f.sleep,runtimes=(f.actor_runtime,f.primary_runtime),source_locks=f.locks)
        peer.load();need(peer.state is not None);return peer

    def inspect(self):
        f=self.flow;need(f.role=='primary' and f.state['phase'] in ('cleaned','terminal-ready'));self.validate_replacement_restoration()
        if f.state['terminal'] is not None:return deepcopy(f.state['terminal']['description'])
        current=f.current(historical=True);need(current.state['records']);ref=current.state['records'][-1];cut=current.original(ref)
        from ios.adapters.audio_whole_inventory import actor
        ledger=actor(f);need(ledger is not None)
        actor_original=dict(binding=ledger.binding,runId=f.run,leases=ledger.rows)
        from ios.adapters.audio_once_end import family
        if family(ledger)[1]=='audioreceived':actor_original.update(receivedMixerSDKLedgerVersion=ledger.version,actorFamily='received-mixer')
        primary_original=dict(reference=ref,replacementArchiveSha256=f.state['replacement']['archiveSha256'],state=current.current_state(cut))
        description=dict(featureTerminalVersion=1,profile=terminal.ORIGINAL_KEEPER_PROFILE,area='audio',runId=f.run,ticket=f.state['cleanupTicket'],roles={
            'primary':dict(binding=binding_from_context(f.state['replacement']['newBinding']),heldResources=f.held_resources('primary'),originalSha256=digest(primary_original)),
            'actor':dict(binding=binding_from_context(f.state['bindings']['actor']),heldResources=f.held_resources('actor'),originalSha256=digest(actor_original))})
        terminal.description(description,area='audio',run=f.run,ticket=f.state['cleanupTicket'])
        f.state['terminal']=dict(description=description,primaryOriginal=primary_original,actorOriginal=actor_original,seal=None,samples=None,pendingSeal=None,primaryEnd=None,end=None)
        f.state['phase']='terminal-ready';f.save();return description

    def qualify_window(self,samples,description):
        f=self.flow;terminal.window(samples,description)
        own=f.public_index.originals();peer=self.actor_peer()
        store=PrivateFeatureState(f.adapter.state_path(f.actor_selector).with_name('phase-publication-audio-'+f.run+'-actor.json'));value=store.read();need(value is not None)
        from adapters.phase_witness_publisher import PhaseWitnessPublisher
        state=PhaseWitnessPublisher.archive(value,store=store,binding=f.state['bindings']['actor'],run=f.run,area='audio',fixture_url=f.client.url,phase_instance=value['phaseInstance'],validate_original=peer.publication_original)
        scope=object.__new__(PhaseWitnessPublisher);scope.store=store;scope.binding=f.state['bindings']['actor'];scope.run=f.run;scope.area='audio';scope.url=f.client.url;scope.instance=value['phaseInstance'];scope.validate_original=peer.publication_original;scope.live=False;scope.decode_context=None
        entries=[scope.load(ref)['entry'] for ref in state['records'] if scope.load(ref)['mode']=='published']
        for sample in samples:
            need(any(same(sample['primary'],row['public']) for row in own))
            need(any(same(sample['actor'],entry) for entry in entries))
        return True

    def seal_codec(self):
        from adapters.original_frame_store import OriginalFrameStore
        f=self.flow
        return OriginalFrameStore(f.root,f.state['replacement']['newBinding'],f.run,'primary',f.guard,self.seal_intent,namespace='ios-audio11-seal',schema_prefix='iosAudio11Seal',monotonic=f.monotonic)
    def seal_intent(self,event,wire):
        f=self.flow;need(event=='original' and wire['index']==1)
        f.state['terminal']['pendingSeal']=deepcopy(wire);f.save();return True
    def retain_seal(self,description,samples,seal):
        f=self.flow;row=f.state['terminal'];codec=self.seal_codec()
        value=dict(iosAudio11SealOriginalVersion=1,description=description,samples=samples,seal=seal)
        if row['samples'] is not None:
            need(same(codec.read(codec.expand(row['samples'])),value) and same(row['seal'],seal));return
        pending=row['pendingSeal']
        if pending is not None:
            need(pending['phase'] in ('opened','saved') and same(codec.read(pending),value));reference=codec.compact(dict(pending,phase='saved'))
        else:reference=codec.write(1,value)
        row.update(samples=reference,seal=deepcopy(seal),pendingSeal=None);f.save()
    def sealed_samples(self):
        f=self.flow;row=f.state['terminal'];need(row is not None and row['samples'] is not None)
        value=self.seal_codec().read(self.seal_codec().expand(row['samples']));exact(value,{'iosAudio11SealOriginalVersion','description','samples','seal'})
        need(type(value['iosAudio11SealOriginalVersion']) is int and value['iosAudio11SealOriginalVersion']==1 and same(value['description'],row['description']) and same(value['seal'],row['seal']))
        terminal.sealed(value['seal'],value['description'],value['samples']);return value['samples']

    def finish(self):
        f=self.flow;need(f.state['terminal'] is not None and f.state['terminal']['seal'] is not None)
        if f.state['terminal']['end'] is not None:self.admit_archives();return deepcopy(f.state['terminal']['end'])
        phase=f.phase.status();need(not phase['active']);self.qualify_window(self.sealed_samples(),f.state['terminal']['description'])
        f.state['phase']='ending';f.save();end=self.actual_end(1,create=True)
        if self.end_row(1)['phase']!='complete':end.finish();self.save_end(1,end)
        primary=self.archived_end(1)
        # This is a different actual SDK; no peers= or shared Stop receipt.
        from ios.adapters.audio_whole_inventory import actor
        ledger=actor(f);need(ledger is not None)
        if ledger.process_end is None or ledger.process_end['phase']!='complete':f.journey.finish_process()
        ledger=actor(f);actor_proof=ledger.retired()['originalProcessEnd']
        roles={}
        for role,proof in (('primary',primary),('actor',actor_proof)):
            roles[role]=dict(binding=binding_from_context(proof['binding']),heldOriginalSha256=f.state['terminal']['description']['roles'][role]['originalSha256'],
                stopOriginalSha256=proof['stopOriginalSha256'],osAbsence=proof['osAbsence'],sdkDeletionOriginalSha256=proof['sdkDeletionOriginalSha256'],archiveSha256=proof['archiveSha256'])
        result=dict(featureTerminalEndVersion=1,seal=deepcopy(f.state['terminal']['seal']),roles=roles);terminal.ended(result)
        f.state['terminal']['end']=result;f.state['phase']='ended';f.save();return result

    def call(self,call):
        f=self.flow;call=terminal.arguments('audio',call);need(call['runId']==f.run and f.role=='primary')
        with f.held():
            if call['stage']=='inspect':return dict(stage='inspect',description=self.inspect())
            if call['stage']=='seal':
                description=self.inspect();need(same(call['description'],description));self.qualify_window(call['samples'],description)
                seal=dict(featureTerminalSealVersion=1,description=description,windowSha256=digest(call['samples']),liveOriginalSha256=digest(dict(primary=f.state['terminal']['primaryOriginal'],actor=f.state['terminal']['actorOriginal'],samples=call['samples'])))
                terminal.sealed(seal,description,call['samples'])
                self.retain_seal(description,call['samples'],seal)
                return dict(stage='seal',seal=seal)
            need(f.state['terminal'] is not None and same(call['seal'],f.state['terminal']['seal']));return dict(stage='finish',end=self.finish())

    def actor_finish_if_authorized(self):
        f=self.flow;need(f.role=='actor')
        with f.held():
            from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
            primary=IOSAudioWholeFeature(f.adapter,f.primary_selector,f.run,'primary',f.client,f.config,epoch_ms=f.epoch_ms,monotonic=f.monotonic,sleep=f.sleep,runtimes=(f.actor_runtime,f.primary_runtime),source_locks=f.locks);primary.load()
            if primary.state is None or primary.state['phase'] not in ('ending','ended','aborted'):return False
            if f.state is None:return False
            from ios.adapters.audio_whole_inventory import actor
            ledger=actor(f)
            if ledger is None:
                row=primary.state['actorEnd']
                if row is None or row['phase']!='complete':return False
                AudioWholeTerminal(primary).actor_no_lease_archive();f.state['actorEnd']=deepcopy(row)
            else:
                if ledger.process_end is None or ledger.process_end['phase']!='complete':f.journey.finish_process()
                actor(f).retired()
            f.worker_aborted=primary.state['phase']=='aborted';f.state['phase']='aborted' if f.worker_aborted else 'ended';f.save();return True

    def actor_no_lease_end(self):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
        f=self.flow;root=f.actor_root/'ios-audio-process-end'
        row=f.state['actorEnd']
        if row is None and f.role=='primary':
            peer=self.actor_peer()
            if peer.state['actorEnd'] is not None and peer.state['actorEnd']['phase']=='complete':
                AudioWholeTerminal(peer).actor_no_lease_archive();row=deepcopy(peer.state['actorEnd']);f.state['actorEnd']=row;f.save()
        if row is None:
            need(not root.exists());row=dict(root=str(root),phase='planned',rootIdentity=None,proof=None);f.state['actorEnd']=row;f.save()
        if row['phase']=='planned':
            need(not root.exists());os.mkdir(root,0o700);fsync_directory(f.actor_root);row['phase']='opened';row['rootIdentity']=identity(root);f.save()
        need(identity(root)==row['rootIdentity'])
        end=IOSOriginalKeeperProcessEnd(f.actor_runtime,f.actor_selector,root,f.state['bindings']['actor'],f.run,'actor',0,'audioonce',f.locks[0],epoch_ms=f.epoch_ms,monotonic=f.monotonic,sleep=f.sleep)
        if row['phase']!='complete':
            end.finish();proof=end.retirement_original();compact=deepcopy(proof);compact.pop('archive');row.update(phase='complete',proof=compact);f.save()
        return self.actor_no_lease_archive()

    def actor_no_lease_archive(self):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd,filename
        f=self.flow;row=f.state['actorEnd'];need(row is not None and row['phase']=='complete')
        store=PrivateFeatureState(f.adapter.state_path(f.actor_selector).with_name(filename('audioonce','actor',0)))
        proof=deepcopy(row['proof']);proof['archive']=store.read();need(digest(proof['archive'])==proof['archiveSha256'])
        IOSOriginalKeeperProcessEnd.archived_original(proof,store=store,root=Path(row['root']),binding=f.state['bindings']['actor'],run=f.run,role='actor',stage=0,profile_key='audioonce',lock=f.locks[0]);return proof

    def closed_media_originals(self):
        f=self.flow
        from ios.adapters.audio_whole_inventory import primary,actor
        parent=primary(f)
        if parent is not None:
            from ios.adapters.audio_pcm_lease import IOSAudioPCMLease
            for name in ('ios-audio-pcm-lease.json','ios-audio-close-lease.json'):
                store=PrivateFeatureState(parent.store.path.with_name(name))
                if store.read() is not None:IOSAudioPCMLease.archive_retired(store,parent).retired()
        ledger=actor(f)
        if ledger is not None:
            for owner in ledger.archives.values():owner.passive_retired()
        return True

    def abort_end(self):
        f=self.flow
        with f.held():
            if f.role=='primary':
                stage=1 if f.state['replacement'] is not None else 0
                if stage==1 and f.state['terminal'] is None:f.state['terminal']=dict(description=None,primaryOriginal=None,actorOriginal=None,seal=None,samples=None,pendingSeal=None,primaryEnd=None,end=None);f.save()
                row=self.end_row(stage)
                if row is None or row['phase']!='complete':end=self.actual_end(stage,create=True);end.finish();self.save_end(stage,end)
                else:self.archived_end(stage)
            from ios.adapters.audio_whole_inventory import actor
            ledger=actor(f)
            if ledger is not None:
                if ledger.process_end is None or ledger.process_end['phase']!='complete':f.journey.finish_process()
                actor(f).retired()
            else:self.actor_no_lease_end()
            self.closed_media_originals();f.state['phase']='aborted';f.save()

    def admit_archives(self,*,skip_readmission=False):
        f=self.flow
        if f.state is None:return
        retired=PrivateFeatureState(f.adapter.state_path(f.primary_selector).with_name('ios-audio11-scope-retirement.json'));retired.read()
        if f.state['terminal'] is not None and f.state['terminal']['samples'] is not None:self.sealed_samples()
        elif f.state['terminal'] is not None and f.state['terminal']['pendingSeal'] is not None:
            pending=f.state['terminal']['pendingSeal']
            if pending['phase']!='planned':self.seal_codec().read(pending)
        if f.state['actorEnd'] is not None and f.state['actorEnd']['phase']=='complete':self.actor_no_lease_archive()
        if f.role=='actor':
            if f.state['replacement'] is not None and not skip_readmission:self.validate_replacement()
            if f.state['phase'] in ('ended','aborted'):
                from ios.adapters.audio_whole_inventory import actor
                ledger=actor(f)
                if ledger is not None:ledger.retired()
                else:self.actor_no_lease_archive()
            return
        if f.state['phase']=='ended':need(f.state['terminal'] is not None and f.state['terminal']['end'] is not None and f.state['replacement'] is not None)
        if f.state['phase'] in ('ended','aborted'):
            self.closed_media_originals()
            stage=1 if f.state['replacement'] is not None else 0
            row=self.end_row(stage);need(row is not None and row['phase']=='complete')
            from ios.adapters.audio_whole_inventory import actor
            ledger=actor(f)
            if ledger is not None:ledger.retired()
            else:self.actor_no_lease_archive()
        for stage in (0,1):
            row=self.end_row(stage) if stage==0 or f.state['terminal'] is not None else None
            if row is None:continue
            if row['phase']=='complete':self.archived_end(stage)
            elif row['phase']=='opened':
                # Reconstructing an unfinished actual End may retain only its
                # original canonical transport; never construct a new Source.
                end=self.pure_pending_end(stage);end.owned_paths()
        if f.state['replacement'] is not None and not skip_readmission:
            if f.state['phase']in ('cleaned','terminal-ready','ending','ended'):self.validate_replacement_restoration()
            else:self.validate_replacement()

    def pure_pending_end(self,stage):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd,filename
        from adapters.original_frame_store import OriginalFrameStore
        f=self.flow;row=self.end_row(stage);end=object.__new__(IOSOriginalKeeperProcessEnd)
        end.runtime,end.selector=f.primary_runtime,f.primary_selector
        end.root,end.lock=Path(row['root']),f.locks[1];end.run,end.role,end.stage,end.profile_key=f.run,'primary',stage,'audiowhole'
        end.profile='ios-original-keeper-process-end-v1';end.binding=deepcopy(f.state['bindings']['primary'] if stage==0 else f.state['replacement']['newBinding'])
        end.store=PrivateFeatureState(f.adapter.state_path(f.primary_selector).with_name(filename('audiowhole','primary',stage)))
        end.previous=end.store.read();need(end.previous is not None);end.state=end.decode(end.previous)
        end.files=OriginalFrameStore(end.root,end.binding,end.run,end.role,end.bound,lambda *_:need(False),namespace='original-process-end' if stage==0 else 'original-process-end-replacement',schema_prefix='iosOriginalProcessEnd')
        for ref in end.state['records']:end.original(ref)
        pending=end.state['pending']
        if pending is not None and pending['file'] is not None and pending['file']['phase']!='planned':end.files.read(pending['file'])
        return end
