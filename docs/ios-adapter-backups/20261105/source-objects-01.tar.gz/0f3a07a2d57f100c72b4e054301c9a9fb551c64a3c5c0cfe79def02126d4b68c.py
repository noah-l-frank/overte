"""Explicit whole Emote version two selects rooted cleanup and scene3.

Normal actions, original source observations, roles and delivery journals stay
the existing coordinator. Terminal/process integration is separately required;
this class does not advertise a complete capability or a legacy Complete.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import need
from adapters.script_feature.history import same
from feature_journeys.retirement_receipts import WEB_SCENE_STAGE
from ios.adapters.emote_feature import IOSEmoteFeature
from ios.adapters.emote_observer import EmoteObservationPending
from ios.adapters.emote_rooted_marker_scope import IOSEmoteRootedMarkerScope
from ios.adapters.emote_rooted_observation import IOSEmoteRootedObserver
from ios.adapters.emote_rooted_retirement import (IOSEmoteRootedNativeRetirement,
    IOSEmoteRootedRenderedRetirement,IOSEmoteRootedKeyedRetirement)
from ios.adapters.emote_rooted_scene_retirement import IOSEmoteRootedSceneRetirement
from ios.adapters.emote_rooted_live import IOSEmoteRootedLive
from ios.adapters.emote_rooted_quiet import refresh,extend
from ios.adapters.emote_scene_proof import rooted
from ios.adapters.emote_scene_order import IOSEmoteSceneOrder
from adapters.normal_feature_state import PrivateFeatureState
from feature_journeys.retirement_receipts import stage
from ios.adapters.emote_operation import operation


VERSION=3
READS=(2,3)

class IOSEmoteRootedFeature(IOSEmoteFeature):
    RETRY_OBSERVATION_READINESS=True
    FORMAT_VERSION=2
    Marker=IOSEmoteRootedMarkerScope
    Observer=IOSEmoteRootedObserver
    NativeRetirement=IOSEmoteRootedNativeRetirement
    RenderedRetirement=IOSEmoteRootedRenderedRetirement
    KeyedRetirement=IOSEmoteRootedKeyedRetirement
    scene_proof_version=2
    scene_validator=staticmethod(rooted)
    retirement_stage=WEB_SCENE_STAGE
    paired_retirement_kind='primary-scene-ordered'

    def __init__(self,*args,target_pair=None,**kwargs):
        from ios.adapters.emote_target_pair import configuration
        self.configured_pair=None if target_pair is None else configuration(target_pair)
        if self.configured_pair is not None:
            self.FORMAT_VERSION=3;self.PROFILE_FIELDS=frozenset({'targetPair'})
        super().__init__(*args,**kwargs)
        if self.configured_pair is not None:
            chosen=self.configured_pair
            need(self.selector==chosen[self.role+'Target'] and self.primary_selector==chosen['primaryTarget']
                and (self.role=='actor' or self.actor_selector==chosen['actorTarget'])
                and str(self.root)==chosen[self.role+'ArtifactRoot'])

    def profile_envelope(self,state):
        if getattr(self,'configured_pair',None) is None:return {}
        from ios.adapters.emote_target_pair import bind
        value=bind(self,state)
        if self.previous is not None:
            need(type(self.previous.get('iosEmoteFeatureVersion')) is int and self.previous['iosEmoteFeatureVersion']==3
                and same(value,self.previous['targetPair']))
        return dict(targetPair=value)

    @staticmethod
    def quiet_refresh(scope,*,clock,sleep,pointers,keys):
        return refresh(scope,pointers,keys,clock=clock,sleep=sleep)

    @staticmethod
    def quiet_extend(scope,pointers,*,keys):return extend(scope,pointers,keys)

    def retirement_public(self,owner,reference,public):
        value=IOSEmoteRootedLive(owner).append(reference)['measurement']
        need(same(value['sourcePublic'],public));return value['public']

    def retirement_sample(self,parts,after_sequence=0,*,fresh_end=False):
        if self.state['cleanup']:
            live=IOSEmoteRootedLive(self.retirement_owner(parts))
            if live.state['pending'] is not None:live.recover()
        return super().retirement_sample(parts,after_sequence,fresh_end=fresh_end)

    def retirement_decoder(self,owner):return IOSEmoteRootedSceneRetirement(owner).actor_original

    def peer_retirement_reader(self,binding,guard,admission,admitted):
        return IOSEmoteSceneOrder(PrivateFeatureState(self.runtime.state_path(self.selector).with_name(
            'ios-emote-primary-scene-order-'+self.run+'.json')),binding,self.phase,guard,admission,admitted,
            epoch_ms=self.epoch_ms,monotonic=self.monotonic,stage=self.retirement_stage)

    def qualify_peer_retirement(self,receipt):
        # This proves historical scene ordering, never a renewed freshness
        # lease. Present cleanup requires the separately acquired local cut
        # and the subsequent paired terminal window before process end.
        need(self.state['phase']=='cleaned' and self.state['cleanup'] and stage(receipt['entry'])==WEB_SCENE_STAGE
            and receipt['entry']['area']=='emotes' and receipt['entry']['phaseRetirementVersion']==3
            and receipt['entry']['ticket']==self.phase.previous['activations'][-1]['ticket'])
        self.clock()

    def publish_retirement(self,parts):
        """One committed scene receipt per ticket; new facts for every cut.

        The scene journal deliberately rejects a second scene-stage POST for
        the same cleanup activation. Later quiet observations still have their
        own typed cleanup originals and independent ordinary fact publication.
        """
        need(self.role=='actor' and self.state['cleanup'])
        if not parts['observer'].publisher().resolve():
            raise EmoteObservationPending('An earlier facts publication is still unresolved')
        publisher=self.retirement_publisher(parts)
        if not publisher.resolve():
            raise EmoteObservationPending('An earlier scene publication is still unresolved')
        ticket=self.phase.previous['activations'][-1]['ticket'];matches=[]
        for reference in publisher.state['records']:
            row=publisher.load(reference)
            if row['mode']=='published' and row['intent']['body']['ticket']==ticket:
                need(row['intent']['body']['stage']==self.retirement_stage)
                matches.append((reference,row))
        need(len(matches)<=1)
        if matches:reference,row=matches[0]
        else:
            publisher.publish(self.state['cleanup'][-1])
            reference=publisher.state['records'][-1];row=publisher.load(reference)
        need(row['mode']=='published' and row['intent']['original'] in self.state['cleanup'])
        parts['observer'].publish_latest()
        actual=dict(kind='actor-published',original=row['intent']['original'],publisher=reference)
        if not same(self.state['retirement'],actual):self.state['retirement']=actual;self.save()
        return dict(performed=True)

    def finalize(self):
        # Version-one finalization declares full native drainage. A rooted
        # source cannot use it before its separate actual process-end owner.
        raise EmoteObservationPending('Rooted Emote responsibility still requires its typed terminal process end')

    @operation(30)
    def terminal(self,call):
        """Same installed operation path, with exact paired terminal owners."""
        need(self.role=='primary')
        from feature_journeys.terminal import arguments
        call=arguments('emotes',call);need(call['runId']==self.run)
        controller=self.runtime._emote_rooted_terminal(self)
        while True:
            try:return controller.invoke(call)
            except EmoteObservationPending:
                if call['stage']!='finish':raise
                # The controller has unwound Actor -> Primary ownership before
                # polling. Durable issued intents are reopened; never resent.
                need(self.lock._owner is None and controller.actor.lock._owner is None)
                self.clock();self.sleep(.05);self.clock()
