"""C8's exact five-field identity, checked before and after owned /proc reads.

This is a NEW unqualified Moving utility subject. It does not import or claim
KernelOwn5's different API or verdict. No atomic procfs snapshot is claimed.
"""
import os
from pathlib import Path
_FIELDS=('pid','parentPid','pgid','sid','startTicks')
_READLINK=os.readlink

def process(pid):
    assert type(pid)is int and pid>0
    try:row=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except(FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(row[1]),pgid=int(row[2]),sid=int(row[3]),startTicks=int(row[19]))

def _identity(value):
    assert type(value)is dict and set(value)==set(_FIELDS)
    assert all(type(value[name])is int for name in _FIELDS)and value['pid']>0
    return value

def owned_executable(expected,bound):
    """Only a discovered owned identity may reach exe/cmdline; never a bare PID.

    A vanished process yields no positive original. A live, reused, reparented,
    regrouped or detached identity refuses. Permission and other errors remain
    errors. Final identity equality is mandatory for every positive return.
    """
    _identity(expected);_identity(bound)
    assert bound['pid']==bound['pgid']==bound['sid'],'Bound runner is not its original session/group root'
    assert expected['sid']==bound['pid']or expected['pgid']==bound['pid'],'Foreign identity before executable read'
    before=process(expected['pid'])
    if before is None:return None
    assert before==expected,'Discovered owned identity changed before executable read'
    try:
        executable=Path(_READLINK('/proc/'+str(expected['pid'])+'/exe')).resolve(strict=True)
    except(FileNotFoundError,ProcessLookupError):
        after=process(expected['pid'])
        if after is None:return None
        assert after==expected,'Owned identity changed during failed executable read'
        raise
    after_executable=process(expected['pid'])
    if after_executable is None:return None
    assert after_executable==expected,'Owned identity changed during executable read'
    try:raw=Path('/proc',str(expected['pid']),'cmdline').read_bytes()
    except(FileNotFoundError,ProcessLookupError):
        after=process(expected['pid'])
        if after is None:return None
        assert after==expected,'Owned identity changed during failed command read'
        raise
    after=process(expected['pid'])
    if after is None:return None
    assert after==expected,'Owned identity changed during command read'
    return dict(identity=after,executable=str(executable),command=[value.decode()for value in raw.split(b'\0')if value])

def require_actual_utility(plan):
    # The forthcoming Root proof schema is deliberately not invented here.
    # A new source successor must join the actual four-case proof before use.
    assert plan['kernelIdentityUtilityRootProof']is None
    raise RuntimeError('Moving C9 owned-identity utility is UNRUN; exact real Root proof/reader required before a Moving target')
