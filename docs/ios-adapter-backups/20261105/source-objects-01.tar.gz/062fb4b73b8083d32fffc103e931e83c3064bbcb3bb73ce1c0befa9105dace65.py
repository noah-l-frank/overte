"""Approved sequential Common checks after the Avatar publisher reuse qualification doc."""
from pathlib import Path
import hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics',
       'libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
def census():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    rows={};fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    for path in sorted([REPO/name for name in names if name]+[Path(__file__).resolve()]):
        a=path.lstat();raw=path.read_bytes();b=path.lstat();first={name:getattr(a,name) for name in fields};last={name:getattr(b,name) for name in fields}
        assert first==last,str(path);rows[str(path.relative_to(REPO))]=dict(stat=last,sha256=hashlib.sha256(raw).hexdigest())
    return rows
before=census();(HERE/'final-common-before.json').write_text(json.dumps(before,indent=2)+'\n')
commands=[
 [sys.executable,'tests/run-project-tests.py','--profile','quick','--suite','documentation','--suite','documentation-contracts','--suite','ios-input-selection','--suite','policy-consistency','--suite','project-coverage','--timeout','240'],
 [sys.executable,'tests/device/validate_contract_versions.py'],
 [sys.executable,'tests/check-documentation.py','--all'],
 ['git','diff','--check'],['git','diff','--cached','--check']]
code=0
try:
    for argv in commands:
        print('CHECK',json.dumps(argv),flush=True);result=subprocess.run(argv,cwd=REPO)
        if result.returncode:code=result.returncode;break
finally:
    after=census();(HERE/'final-common-after.json').write_text(json.dumps(after,indent=2)+'\n')
    assert before==after,'Source/launcher changed during approved common checks'
    print('SOURCE_LAUNCHER_PINS_UNCHANGED',len(after),flush=True)
raise SystemExit(code)
