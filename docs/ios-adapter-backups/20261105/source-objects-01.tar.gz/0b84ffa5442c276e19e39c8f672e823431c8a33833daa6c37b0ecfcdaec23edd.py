"""Only exact reviewed Assets52 plus one fixture delta; no Emote parser change."""
import ast,hashlib,json,stat
from pathlib import Path
HERE=Path(__file__).resolve().parent;MASTER=HERE.parent
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def apply(mapping,repo):
 plan=json.loads((MASTER/'foreign53-publication-rebase.json').read_text());source=Path(plan['sourceManifest']);fixture=Path(plan['fixtureManifest'])
 assert sha(source)==plan['sourceManifestSha256']and sha(fixture)==plan['fixtureManifestSha256']
 a=json.loads(source.read_text());b=json.loads(fixture.read_text());assert a['files']==plan['sourceRows']and len(a['files'])==52 and a['ownSemanticKeys']==plan['ownRegistryKeys']and a['foreignRegistryAndValidatorSemanticsPreserved']and a['wholeFeatureFlagsUnchanged']
 assert (b['path'],b['beforeSha256'],b['sha256'])==(plan['fixtureRow']['path'],plan['fixtureRow']['baseSha256'],plan['fixtureRow']['sha256'])and not b['productionCodeChanged']and not b['testsReplayed']
 packet=Path(plan['sourcePacket']);assert sha(packet/'source-freeze.json')==plan['sourceFreezeSha256']
 oldregistry=MASTER/'old-registry.json';oldvalidator=MASTER/'old-validator.py';assert sha(oldregistry)==plan['oldRegistrySha256']and sha(oldvalidator)==plan['oldValidatorSha256']
 own=set(plan['ownRegistryKeys']);old=json.loads(oldregistry.read_text());new=json.loads((repo/'tests/device/contract-versions.json').read_text())
 assert {k:v for k,v in old.items()if k!='contracts'}=={k:v for k,v in new.items()if k!='contracts'}
 assert {k:v for k,v in old['contracts'].items()if k not in own}=={k:v for k,v in new['contracts'].items()if k not in own}
 def validator(path):
  tree=ast.parse(path.read_text());found=[]
  for node in tree.body:
   if isinstance(node,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='REQUIRED'for t in node.targets):
    value=ast.literal_eval(node.value);found.append(value);node.value=ast.Dict(keys=[],values=[])
  assert len(found)==1
  return {k:v for k,v in found[0].items()if k not in own},ast.dump(tree,include_attributes=False)
 assert validator(oldvalidator)==validator(repo/'tests/device/validate_contract_versions.py')
 result=dict(mapping);rows=plan['sourceRows']+[plan['fixtureRow']];assert len({r['path']for r in plan['sourceRows']})==52
 for row in rows:
  path=row['path'];assert not Path(path).is_absolute()and '..'not in Path(path).parts
  assert result.get(path)==row['baseSha256'];result[path]=row['sha256']
 for path in {row['path']for row in rows}:assert sha(repo/path)==result[path]
 # Exact dependency closure from the failed original stage: only registry and
 # validator are shared changes, whose entire foreign semantics were checked.
 stage=Path(json.loads((HERE/'input-plan.json').read_text())['actualWindowStage']);deps=set(json.loads((stage/'run-plan.json').read_text())['requiredPublicDependencies'])
 assert deps&{r['path']for r in rows}=={'tests/device/contract-versions.json','tests/device/validate_contract_versions.py'}
 return result
def retained_paths():
 output=[]
 for name,expected in json.loads((MASTER/'prior-preimport-failure-current-pins.json').read_text()).items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();row=dict(stat=[getattr(a,k)for k in F]);assert stat.S_ISDIR(a.st_mode)or stat.S_ISREG(a.st_mode)
  if stat.S_ISREG(a.st_mode):row['sha256']=sha(p)
  assert row==expected and row['stat']==[getattr(p.lstat(),k)for k in F];output.append(p)
 return output
