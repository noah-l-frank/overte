"""Prospective actual constructor/Current7/parent End composition, Root only.

The external gateway creates actual Node ChildProcess/keeper/registry owners.
Raw device/native/OS/Appium behavior is explicitly modeled. No DTO replaces
IOSScriptRuntime, InstalledCodeBinding, parent End or original-frame replay.
This file does NOT qualify complete Audio custody/readmission/restoration.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,os,subprocess,sys,tempfile,unittest
from pathlib import Path
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.appium_adapter import WebDriver,WebDriverRequestError
from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
from audio_original_parent_model import DeclaredCanonicalSDK


class OriginalSDKGateway:
    def __init__(self,case):
        path=Path(os.environ['AUDIO_ORIGINAL_PARENT_SOURCE_MAP']);raw=path.read_bytes()
        case.assertEqual(os.environ['AUDIO_ORIGINAL_PARENT_SOURCE_MAP_SHA256'],hashlib.sha256(raw).hexdigest());mapping=json.loads(raw)
        case.assertEqual({'keeper','registry','child','wrapper','provider','producer','gateway'},set(mapping))
        for row in mapping.values():
            case.assertEqual({'path','sha256'},set(row));case.assertTrue(Path(row['path']).is_absolute())
            case.assertEqual(row['sha256'],hashlib.sha256(Path(row['path']).read_bytes()).hexdigest())
        temporary=tempfile.TemporaryDirectory(prefix='audio-original-parent-');case.addCleanup(temporary.cleanup)
        self.root=Path(temporary.name);self.root.chmod(0o700);self.report=self.root/'gateway-retirement.json'
        config=dict(mapping,root=str(self.root),report=str(self.report),python=sys.executable,
            pythonPath=os.pathsep.join([str(Path(__file__).resolve().parent),*[str(Path(p).absolute())for p in sys.path if p]]))
        p=self.root/'configuration.json';p.write_text(json.dumps(config)+'\n');p.chmod(0o600)
        self.stderr=(self.root/'gateway-stderr.log').open('wb');self.stdout=(self.root/'gateway-stdout.log').open('wb')
        # Root's outer process-tree supervisor owns the fixed budget. No inner
        # timeout may kill a Node parent while abandoning its original children.
        self.process=subprocess.Popen([os.environ['AUDIO_ORIGINAL_PARENT_NODE'],mapping['gateway']['path'],str(p)],
            stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=self.stderr)
        self.closed=False;case.addCleanup(self.close)
        line=self.process.stdout.readline(16385);self.stdout.write(line);self.stdout.flush()
        case.assertLessEqual(len(line),16384);ready=json.loads(line);case.assertEqual('ready',ready['event'])
        self.client=WebDriver(ready['origin']);self.ready=ready
    def close(self):
        if self.closed:return
        self.closed=True
        if self.process.poll()is None:
            try:self.client.call('POST','/fixture-shutdown',{})
            except BaseException:
                # This is fixture resource teardown, never a typed feature End.
                self.process.terminate()
        output,_=self.process.communicate();self.stdout.write(output);self.stdout.close();self.stderr.close()
        if self.process.returncode!=0:raise RuntimeError('Original fixture gateway did not close cleanly')
    def inventory(self):return self.client.call('GET','/fixture-inventory')


class AudioOriginalParentCompositionTests(unittest.TestCase):
    def setUp(self):
        self.gateway=OriginalSDKGateway(self);g=self.gateway
        self.adapter=DeclaredCanonicalSDK(g.root/'parent-sdk',g.ready['origin'],g.ready['session'],case=self);self.adapter.describe('model')
        self.runtime=self.adapter.runtime();self.binding=self.runtime._sources('model')['binding'];self.run='4'*32
        self.originals=g.root/'parent-end-originals';self.originals.mkdir(mode=0o700)
        self.lock=ScriptSourceLock(self.adapter.root/'script-feature-sources.lock')
    def end(self):return IOSOriginalKeeperProcessEnd(self.runtime,'model',self.originals,self.binding,self.run,'primary',0,'audiowhole',self.lock)
    def test_actual_constructor_seven_reads_parent_end_and_creator_prove_canonical_absence(self):
        with self.lock.held():
            end=self.end();proof=end.finish();self.assertTrue(proof['resourceRetirementEstablished'])
            cutoff=end.original(end.state['cutoff'])['sourceFrame']['frame']['original']['original']
            self.assertEqual(7,len(cutoff['reads']));self.assertTrue(cutoff['originalServiceCloseReturned'])
            self.assertEqual(['nativeBefore','beforeUI','pending','ui','keyboard','world','nativeAfter'],[r['name']for r in cutoff['reads']])
            self.assertEqual(7,len({r['query']['commandId']for r in cutoff['reads']}))
            creator=end.original(end.state['creator'])['creatorRetirement'];self.assertEqual(0,creator['exitCode'])
            self.assertIsNone(creator['signalCode']);self.assertEqual([True,True,True],creator['originalStdioClosed'])
            self.assertEqual(end.previous,proof['archive']);self.assertIsNone(self.adapter.read_session('model'))
            self.assertIsNone(self.adapter._binding_store('model').read())
            files={p:(p.stat().st_ino,p.read_bytes())for p in end.owned_paths()}
            replay=IOSOriginalKeeperProcessEnd.archived_original(proof,store=end.store,root=end.root,binding=self.binding,
                run=self.run,role='primary',stage=0,profile_key='audiowhole',lock=self.lock)
            self.assertEqual(proof,replay);self.assertEqual(files,{p:(p.stat().st_ino,p.read_bytes())for p in end.owned_paths()})
        inventory=self.gateway.inventory();self.assertEqual(1,inventory['canonicalDeletes']);self.assertEqual(0,inventory['replacementBirths'])
        self.assertFalse(inventory['wholeQualified']);self.gateway.close()
        self.assertTrue(json.loads(self.gateway.report.read_text())['allFixtureChildrenClosed'])
    def test_wrong_seven_reader_raw_nonce_retains_failure_before_stop_or_canonical_deletion(self):
        self.gateway.client.call('POST','/fixture-fault',dict(fault='wrong-ui-nonce'))
        with self.lock.held():
            end=self.end()
            with self.assertRaises((WebDriverRequestError,RuntimeError,ValueError)):end.arm()
            self.assertIsNone(end.state['stop']);self.assertIsNone(end.state['sdk']);self.assertIsNone(end.state['creator'])
            self.assertIsNone(end.state['deletion']);self.assertIsNotNone(end.state['pending'])
        inventory=self.gateway.inventory();self.assertEqual(0,inventory['canonicalDeletes']);self.assertEqual(0,inventory['replacementBirths'])
        self.assertTrue(inventory['live']);current=inventory['native']['currentOwners']['primary']
        self.assertEqual(0,current['frames']);self.assertEqual('failed',current['ioPending']['phase'])
