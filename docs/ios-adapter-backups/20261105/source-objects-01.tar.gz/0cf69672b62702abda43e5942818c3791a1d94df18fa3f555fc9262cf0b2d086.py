"""Owned original process observer: local START/RETURN, global UNWIND only.

No source function or process method is replaced. A normal close return and a
throwing close are different receipts. Unsupported monitoring refuses; there
is deliberately no global sys.setprofile fallback.
"""
import os
import subprocess
import sys
import traceback
from types import CodeType


class OriginalProcessObserver:
    def __init__(self,proc):
        if not callable(proc):raise TypeError('Actual process metadata reader required')
        self.proc=proc;self.processes=[];self.owners=[];self.closes=[];self.tool=None
        self.name='overte-owned-original-process-observer-'+str(os.getpid())+'-'+str(id(self))
        self.popen_code=subprocess.Popen.__init__.__code__;self.birth_codes=();self.close_codes=()
        self.codes={};self.starts=0;self.returns=0;self.unwinds=0;self.unrelated_unwinds=0
        self.diagnostic_codes={};self.diagnostic_sink=None;self.diagnostic_count=0
        self.previous_profile=sys.getprofile();self.previous_trace=sys.gettrace()

    def start(self):
        if self.tool is not None:raise RuntimeError('Observer already admitted')
        if self.previous_profile is not None or self.previous_trace is not None:
            raise RuntimeError('Original observer requires unchanged inactive profile/trace')
        monitoring=getattr(sys,'monitoring',None)
        if monitoring is None:raise RuntimeError('Local Python monitoring unavailable; no global profile fallback')
        events=monitoring.events
        if not all(hasattr(events,n) for n in ('PY_START','PY_RETURN','PY_UNWIND')):
            raise RuntimeError('Required original monitoring events unavailable')
        free=[i for i in (2,5,4,3,1,0) if monitoring.get_tool(i) is None]
        if not free:raise RuntimeError('No private monitoring tool slot available')
        self.monitoring=monitoring;self.events=events;self.tool=free[0]
        monitoring.use_tool_id(self.tool,self.name)
        try:
            if monitoring.get_events(self.tool)!=0:raise RuntimeError('New tool has unexpected global events')
            monitoring.register_callback(self.tool,events.PY_START,self._start)
            monitoring.register_callback(self.tool,events.PY_RETURN,self._return)
            monitoring.register_callback(self.tool,events.PY_UNWIND,self._unwind)
            self._local(self.popen_code)
            # CPython3.14 rejects UNWIND in local masks. This ONLY global
            # exception-unwind event never instruments unrelated normal calls.
            monitoring.set_events(self.tool,events.PY_UNWIND)
            if monitoring.get_events(self.tool)!=events.PY_UNWIND:raise RuntimeError('Global call/return events are forbidden')
        except BaseException:
            self.stop();raise
        return self

    def _local(self,code):
        if type(code) is not CodeType:raise TypeError('Actual code object required')
        self.codes[id(code)]=code
        self.monitoring.set_local_events(self.tool,code,self.events.PY_START|self.events.PY_RETURN)
        if self.monitoring.get_local_events(self.tool,code)!=(self.events.PY_START|self.events.PY_RETURN):
            raise RuntimeError('Exact local event mask not installed')

    def bind_owners(self,birth_codes,close_codes):
        if self.tool is None or type(birth_codes) is not tuple or type(close_codes) is not tuple:
            raise RuntimeError('Active observer and explicit original code tuples required')
        if self.birth_codes or self.close_codes:raise RuntimeError('Original code bindings cannot be replaced')
        if len(birth_codes)!=len(close_codes) or not birth_codes:raise ValueError('Matching original constructors/close codes required')
        self.birth_codes=birth_codes;self.close_codes=close_codes
        for code in (*birth_codes,*close_codes):self._local(code)

    def bind_diagnostics(self,codes,sink):
        # Reuse only the already-owned global UNWIND event. No extra START,
        # RETURN, RAISE, profile/trace or project-function replacement.
        if self.tool is None or self.diagnostic_codes or not callable(sink):
            raise RuntimeError('Exact unwind diagnostics cannot be rebound')
        if type(codes) is not tuple or not codes or any(type(code) is not CodeType for code in codes):
            raise TypeError('Original diagnostic code tuple required')
        self.diagnostic_codes={id(code):code for code in codes};self.diagnostic_sink=sink

    def _diagnostic(self,code,offset,exception):
        if self.diagnostic_codes.get(id(code)) is not code:return
        chain=[];seen=set();value=exception
        for _ in range(8):
            if value is None or id(value) in seen:break
            seen.add(id(value))
            chain.append(dict(type=type(value).__name__,suppressedContext=bool(value.__suppress_context__),
                frames=[dict(file=row.filename,line=row.lineno,function=row.name)
                    for row in traceback.extract_tb(value.__traceback__)]))
            value=value.__cause__ if value.__cause__ is not None else value.__context__
        self.diagnostic_count+=1
        self.diagnostic_sink(dict(event='actual-selected-original-unwind',file=code.co_filename,
            function=code.co_name,instructionOffset=offset,thread=__import__('threading').get_ident(),chain=chain))

    def _start(self,code,offset):self._observe('start',code,sys._getframe(1),None)
    def _return(self,code,offset,value):self._observe('return',code,sys._getframe(1),value)
    def _unwind(self,code,offset,exception):
        # There is no global PY_START/PY_RETURN callback. Unrelated exceptions
        # exit before inspecting any frame locals or owner object.
        self._diagnostic(code,offset,exception)
        if id(code) not in self.codes:self.unrelated_unwinds+=1;return
        self._observe('unwind',code,sys._getframe(1),exception)

    @staticmethod
    def command_kind(process):
        args=process.args
        executable=args[0] if type(args) in (tuple,list) and args else args
        if type(executable) not in (str,bytes):return 'unknown'
        name=os.path.basename(os.fsdecode(executable))
        return 'node' if name=='node' else 'openssl' if name=='openssl' else 'metadata-rg' if name=='rg' else 'python' if name.startswith('python') else 'other'

    def _observe(self,event,code,frame,value):
        if self.codes.get(id(code)) is not code or frame.f_code is not code:
            raise RuntimeError('Original monitoring frame/code identity changed')
        owner=frame.f_locals.get('self')
        if owner is None:raise RuntimeError('Original selected method has no self')
        if event=='start':self.starts+=1
        elif event=='return':self.returns+=1
        else:self.unwinds+=1
        if code is self.popen_code:
            if event=='start':return
            pid=getattr(owner,'pid',None)
            if type(pid) is int and not any(row['process'] is owner for row in self.processes):
                self.processes.append(dict(process=owner,birth=self.proc(pid),pid=pid,commandKind=self.command_kind(owner),constructorOutcome=event))
        elif any(code is item for item in self.birth_codes):
            if event=='start':return
            process=getattr(owner,'process',None)
            if process is not None and not any(row['owner'] is owner for row in self.owners):
                self.owners.append(dict(owner=owner,process=process,pid=process.pid,constructorOutcome=event))
        elif any(code is item for item in self.close_codes):
            if event=='start':
                process=getattr(owner,'process',None)
                if process is not None:self.closes.append(dict(owner=owner,process=process,entered=True,returned=False,unwound=False,returnCode=None))
            else:
                for row in reversed(self.closes):
                    if row['owner'] is owner and not row['returned'] and not row['unwound']:
                        row['returned']=event=='return';row['unwound']=event=='unwind';row['returnCode']=row['process'].returncode
                        if event=='unwind':row['exceptionType']=type(value).__name__
                        break

    def stop(self):
        if self.tool is None:return
        m=self.monitoring;tool=self.tool
        if m.get_tool(tool)!=self.name:raise RuntimeError('Private monitoring slot ownership changed; foreign tool is not cleared')
        for code in self.codes.values():m.set_local_events(tool,code,0)
        m.set_events(tool,0)
        for event in (self.events.PY_START,self.events.PY_RETURN,self.events.PY_UNWIND):m.register_callback(tool,event,None)
        if m.get_events(tool)!=0 or any(m.get_local_events(tool,code)!=0 for code in self.codes.values()):
            raise RuntimeError('Private monitoring events remained installed')
        m.free_tool_id(tool)
        if m.get_tool(tool) is not None:raise RuntimeError('Private monitoring tool not freed')
        self.tool=None
        if sys.getprofile() is not self.previous_profile or sys.gettrace() is not self.previous_trace:
            raise RuntimeError('Caller profile/trace changed')

    def metadata(self):
        return dict(localStartReturnOnly=True,globalUnwindOnly=True,globalProfileInstalled=False,
            observedCodeCount=len(self.codes),diagnosticCodeCount=len(self.diagnostic_codes),diagnosticUnwinds=self.diagnostic_count,starts=self.starts,normalReturns=self.returns,selectedUnwinds=self.unwinds,
            unrelatedUnwinds=self.unrelated_unwinds,privateToolFreed=self.tool is None)
