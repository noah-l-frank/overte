"""Prospective real-constructor PageBirth v2 controls, all UNRUN."""
from copy import deepcopy
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import pack,unpack
from ios.adapters.assets_page_birth import AssetsPageBirth
from ios.self_tests.test_ios_assets_page_birth import AssetsPageBirthTests
from ios.self_tests.assets_picker_fixture import RUN

class AssetsPageBirthObservationTests(AssetsPageBirthTests):
    def current_owner(self):
        return AssetsPageBirth(self.a.selected,self.store,self.a.h.locks['primary'],self.action,
            self.b.native_input(),self.b.clock_reader,monotonic=self.b.monotonic)

    def test_opened_sampling_adds_one_real_original_without_more_input_and_keeps_birth_anchor(self):
        page=self.owner.open();before=deepcopy(self.owner.state);inputs=deepcopy(self.b.inputs)
        files={self.owner.originals.path(self.owner.originals.expand(ref)):None for ref in before['frames']}
        saved={path:(path.stat().st_dev,path.stat().st_ino,path.read_bytes())for path in files}
        packet=self.owner.capture()
        self.assertEqual('opened',self.owner.state['phase']);self.assertIsNone(self.owner.state['pending'])
        self.assertIsNone(self.owner.state['observation']);self.assertEqual(before['openedBy'],self.owner.state['openedBy'])
        self.assertEqual(before['frames'],self.owner.state['frames'][:-1]);self.assertEqual(inputs,self.b.inputs)
        self.assertEqual(packet,self.owner.frame_read(len(self.owner.state['frames']))['ui'])
        self.assertEqual(page,self.owner.page())
        self.assertEqual(saved,{path:(path.stat().st_dev,path.stat().st_ino,path.read_bytes())for path in files})

    def test_cancelled_native_read_stays_pending_and_cold_retry_never_queries_or_inputs(self):
        self.owner.open();error=KeyboardInterrupt('original native read cancelled');inputs=deepcopy(self.b.inputs)
        with patch.object(self.owner,'_native_capture',side_effect=error):
            with self.assertRaises(KeyboardInterrupt)as raised:self.owner.capture()
        self.assertIs(raised.exception,error);self.assertIsNone(self.owner.state['pending']['original'])
        with self.assertRaises(NativeUIError):self.owner.page()
        cold=self.current_owner();saved=deepcopy(cold.previous)
        with patch.object(cold,'_native_capture',side_effect=self.forbidden),patch.object(cold.clock,'read',side_effect=self.forbidden):
            with self.assertRaises(NativeUIError):cold.capture()
        self.assertEqual(inputs,self.b.inputs);self.assertEqual(saved,self.store.read())

    def test_lost_full_original_return_reopens_exact_inode_without_query_or_input_replay(self):
        self.owner.open();write=self.owner.originals.write;error=OSError('full original inode saved; return lost')
        def lost(index,frame):write(index,frame);raise error
        with patch.object(self.owner.originals,'write',lost),self.assertRaises(OSError)as raised:self.owner.capture()
        self.assertIs(raised.exception,error);pending=deepcopy(self.owner.state['pending']);self.assertIsNotNone(pending['original'])
        path=self.owner.originals.path(pending['original']);original=(path.stat().st_dev,path.stat().st_ino,path.read_bytes())
        inputs=deepcopy(self.b.inputs);cold=self.current_owner()
        with patch.object(cold,'_native_capture',side_effect=self.forbidden),patch.object(cold.clock,'read',side_effect=self.forbidden):packet=cold.capture()
        self.assertEqual(packet,cold.frame_read(len(cold.state['frames']))['ui']);self.assertEqual(inputs,self.b.inputs)
        self.assertEqual(original,(path.stat().st_dev,path.stat().st_ino,path.read_bytes()))
        self.assertEqual('opened',cold.state['phase']);self.assertIsNone(cold.state['pending'])

    def test_lost_final_parent_cas_return_latches_old_owner_then_reopens_actual_complete_parent(self):
        self.owner.open();old=PrivateFeatureState.write;error=OSError('final opened CAS committed; return lost');faults=[]
        def lost(store,value,previous):
            result=old(store,value,previous)
            if store.path==self.store.path and previous is not None and unpack(previous['payload'])[0]['phase']=='observing-opened'and unpack(value['payload'])[0]['phase']=='opened':
                faults.append(store.path);raise error
            return result
        with patch.object(PrivateFeatureState,'write',lost),self.assertRaises(OSError)as raised:self.owner.capture()
        self.assertIs(raised.exception,error);self.assertEqual(faults,[self.store.path])
        with self.assertRaises(NativeUIError):self.owner.page()
        cold=self.current_owner();inputs=deepcopy(self.b.inputs)
        with patch.object(cold,'_native_capture',side_effect=self.forbidden),patch.object(cold.clock,'read',side_effect=self.forbidden):self.assertTrue(cold.page()['alive'])
        self.assertEqual(inputs,self.b.inputs);self.assertEqual('opened',cold.state['phase'])

    def test_legacy_v1_pending_cannot_be_reinterpreted_as_opened_success(self):
        self.owner.open();error=KeyboardInterrupt('pending read cancelled')
        with patch.object(self.owner,'_native_capture',side_effect=error),self.assertRaises(KeyboardInterrupt):self.owner.capture()
        value=deepcopy(self.store.read());state=unpack(value['payload'])[0]
        state.pop('observation');state['phase']='opened';value['iosAssetsPageBirthVersion']=1;value['payload']=pack([state])
        cold=self.current_owner()
        with self.assertRaises(NativeUIError):cold.decode(value)

    def test_foreign_samebytes_saved_pending_inode_refuses_before_cold_query(self):
        self.owner.open();write=self.owner.originals.write
        def lost(index,frame):write(index,frame);raise OSError('original return lost')
        with patch.object(self.owner.originals,'write',lost),self.assertRaises(OSError):self.owner.capture()
        pending=self.owner.state['pending'];path=self.owner.originals.path(pending['original']);raw=path.read_bytes();backup=path.with_name('source7-retained-'+path.name)
        path.rename(backup);path.write_bytes(raw);path.chmod(0o600);inputs=deepcopy(self.b.inputs)
        with patch.object(self.b,'normal',side_effect=self.forbidden),self.assertRaises(NativeUIError):self.current_owner()
        self.assertEqual(inputs,self.b.inputs);self.assertEqual(raw,backup.read_bytes());self.assertEqual(raw,path.read_bytes())
