"""Private protocol extraction of the unapplied helper; no typed admission."""
from contextvars import ContextVar
from adapters.native_feature_observation import need
_ACTIVE=ContextVar('private_atomic_inventory_protocol',default=None)

def inventory_original_with_fresh_proof(owner):
    area=_ACTIVE.get()
    if area is None:
        value,raw=owner.original();return value,raw,owner.proof()
    area.check();value,raw=owner.original()
    def current_original():
        key=area.inventory_key(owner);entry=area.cache.get(key)
        need(entry is not None and entry['owner'] is owner and area.inventory_headers(owner)==entry['headers'])
        owner.bound()
        need(area.inventory_key(owner)==key and entry['owner'] is owner and area.inventory_headers(owner)==entry['headers'])
    current_original();result=owner._proof_from_original(value,raw)
    current_original();area.check();return value,raw,result
