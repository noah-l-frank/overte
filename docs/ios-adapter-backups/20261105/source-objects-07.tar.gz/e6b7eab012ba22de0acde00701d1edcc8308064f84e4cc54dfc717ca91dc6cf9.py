"""Outer true kernel boundary for fourteen pure C24 diagnostic utility counters, fixed30+5."""
from pathlib import Path
from metadata_reader import pin
from host_common import head
import ast,hashlib,json,os,signal,stat,subprocess,sys,threading,time,traceback
REPO=Path.cwd().resolve(strict=True);HERE=Path(__file__).resolve().parent
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert sys.flags.no_site==1, 'Explicit no-site startup required'
assert len(sys.argv)==2
INPUT=HERE/'approved-inputs.json';assert hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[1]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert head()==plan['actualPublicHead']
assert plan['status']=='PRIVATE_C24_DIAGNOSTIC_SOURCE3_UTILITY14_UNRUN'and plan['cases']==json.loads((HERE/'exact-fourteen-selectors.json').read_text())
assert plan['wallSeconds']==30 and plan['killGraceSeconds']==5 and len(plan['cases'])==14

def checked(path):
    path=Path(path);assert path.resolve().is_relative_to(REPO);return path

def meta(info):return[info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns]
def census(root):
    result={}
    def visit(path):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):
            names=sorted(item.name for item in path.iterdir());row=dict(stat=meta(info),namespace=names)
            for name in names:visit(path/name)
            assert meta(path.lstat())==meta(info)
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        result[str(path.relative_to(root))]=row
    visit(root);return result

def identity(pid):
    try:text=Path('/proc',str(pid),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    values=text[text.rfind(')')+2:].split()
    return dict(pid=int(text[:text.index('(')].strip()),parent=int(values[1]),group=int(values[2]),session=int(values[3]),startTicks=int(values[19]))
def table():
    result={}
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            row=identity(int(path.name))
            if row is not None:result[row['pid']]=row
    return result

def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:info=path.stat();result[path.name]=dict(target=os.readlink(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result

parent_fds=fds();parent_threads=tuple(threading.enumerate())
COLLECTOR=checked(HERE.with_name(HERE.name+'-outer'));assert not COLLECTOR.exists();checked(COLLECTOR).mkdir(mode=0o700)
def save(name,body):
    path=checked(COLLECTOR/name);assert path.parent==COLLECTOR
    with path.open('x')as stream:stream.write(json.dumps(body,sort_keys=True,indent=2)+'\n')
    path.chmod(0o600)

input_before=pin(INPUT);assert input_before['sha256']==sys.argv[1]
save('approved-input-before.json',input_before)
before={name:pin(name)for name in plan['sourceAndBinaryPins']};assert before==plan['sourceAndBinaryPins']
save('source-binary-before.json',before)
initial_names=sorted(path.name for path in HERE.iterdir())
for name in('own-toys','child-receipts','child-logs'):
    path=checked(HERE/name);assert not path.exists();path.mkdir(mode=0o700)
expected_names=sorted(initial_names+['own-toys','child-receipts','child-logs'])
LOGS=HERE/'child-logs';stdin=checked(LOGS/'stdin.eof');stdin.write_bytes(b'')
process=None;born=None;owned={};discovered={};identity_observations={};problems=[];timed_out=False;forced=False;term_at=None;baseline=table();started=time.monotonic()
# No case child is admitted. Only the genuine outer-created runner original
# may ever enter owned/signal bindings; all discovered extra PIDs are errors.
def observe(row):
    pid=row['pid'];identity_observations.setdefault(pid,[]).append(dict(row))
    # Keep first discovery as DATA; it is not an original creator binding.
    discovered.setdefault(pid,dict(row))
    original=owned.get(pid)
    if original is not None and any(row[name]!=original[name]for name in('pid','parent','startTicks')):
        problems.append(dict(kind='kernel-identity-reused-or-reparented',original=original,observed=row))

def actual_owned_left():
    result=[]
    for pid in set(owned)|set(discovered):
        actual=identity(pid)
        if actual is not None:result.append(dict(original=owned.get(pid),firstDiscovery=discovered.get(pid),current=actual))
    return result

try:
    with stdin.open('rb')as incoming,(LOGS/'stdout.log').open('xb')as output,(LOGS/'stderr.log').open('xb')as error:
        process=subprocess.Popen([plan['pythonExecutable']['path'],'-S','-B',str(HERE/'run-fourteen.py'),str(INPUT),sys.argv[1]],cwd=REPO,
            stdin=incoming,stdout=output,stderr=error,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(HERE/'own-toys')})
    born=identity(process.pid);assert born is not None and born['parent']==os.getpid()and born['group']==born['session']==born['pid']
    owned[born['pid']]=born;save('actual-runner-birth.json',born)
    while True:
        actual=table();selected={born['pid']};changed=True
        while changed:
            changed=False
            for pid,row in actual.items():
                if pid in selected:continue
                if row['parent']in selected or row['group']==born['group']or row['session']==born['session']:
                    assert pid not in baseline;selected.add(pid);observe(row);changed=True
                    if row['parent']!=born['pid']:problems.append(dict(kind='unselected-child-ancestry',identity=row))
                    if len(selected)>1:problems.append(dict(kind='too-many-actual-utility-children',identity=row))
        for pid,original in tuple(owned.items()):
            fresh=identity(pid)
            if fresh is not None:observe(fresh)
        # Only genuine unchanged runner binding has TERM/KILL authority.
        code=process.poll();elapsed=time.monotonic()-started
        if code is not None:break
        if elapsed>=30 and term_at is None:
            timed_out=True;term_at=time.monotonic();assert identity(born['pid'])==born;os.kill(born['pid'],signal.SIGTERM)
        if term_at is not None and time.monotonic()-term_at>=5:
            forced=True;assert identity(born['pid'])==born;os.kill(born['pid'],signal.SIGKILL);process.wait();break
        time.sleep(.025)
    process.wait()
except BaseException:problems.append(dict(kind='original-parent-exception',traceback=traceback.format_exc()))
finally:
    if born is not None:
        actual=table();selected={born['pid']};changed=True
        while changed:
            changed=False
            for pid,row in actual.items():
                if pid in selected:continue
                if row['parent']in selected or row['group']==born['group']or row['session']==born['session']:
                    assert pid not in baseline;selected.add(pid);observe(row);changed=True
    orphans=[]
    for pid,binding in owned.items():
        actual=identity(pid)
        if actual is not None:
            orphans.append(dict(bound=binding,current=actual))
            if actual==binding:
                assert identity(pid)==binding
                os.kill(pid,signal.SIGKILL) # exact ORIGINAL birth only, never fresh observed identity
    if process is not None:process.wait()
    remaining=actual_owned_left()
    save('actual-process-drain.json',dict(owned=list(owned.values()),firstDiscoveries=list(discovered.values()),observations=identity_observations,observationsGrantNoSignalAuthority=True,orphansRequiredKill=orphans,remaining=remaining,timedOut=timed_out,forced=forced))
    assert not remaining,'No quiet original census while a bound process remains'
    # Entire controller root, including approved-inputs and every metadata,
    # code, output and directory row. These reports are in sibling COLLECTOR.
    first=census(HERE);second=census(HERE)
    save('actual-child-output-first.json',first);save('actual-child-output-second.json',second)
    def child_subtrees(full):
        result={}
        for name in('own-toys','child-receipts','child-logs'):
            assert name in full
            prefix=name+'/'
            result[name]={'.'if key==name else key[len(prefix):]:row for key,row in full.items()if key==name or key.startswith(prefix)}
        return result
    first_children=child_subtrees(first);second_children=child_subtrees(second)
    save('actual-child-subtrees-first.json',first_children);save('actual-child-subtrees-second.json',second_children)
    input_after=pin(INPUT);save('approved-input-after.json',input_after)
    assert head()==plan['actualPublicHead']
    input_unchanged=input_before==input_after and input_before['sha256']==input_after['sha256']==sys.argv[1]
    assert all(name in first and name in second for name in('approved-inputs.json','run-fourteen.py','supervise-fourteen.py'))
    source_after_pins={name:pin(name)for name in plan['sourceAndBinaryPins']};save('source-binary-after.json',source_after_pins)
    report_path=HERE/'child-receipts/report.json';restore_path=HERE/'child-receipts/actual-port-restoration.json'
    report=json.loads(report_path.read_text())if report_path.is_file()else None
    restore=json.loads(restore_path.read_text())if restore_path.is_file()else None
    selection_path=HERE/'child-receipts/actual-selection.json'
    selection=json.loads(selection_path.read_text())if selection_path.is_file()else None
    origins_path=HERE/'child-receipts/actual-source-model-origins.json'
    origins=json.loads(origins_path.read_text())if origins_path.is_file()else None
    origins_ok=origins is not None and origins['allThreeActualRuntimeOriginsEstablished']is True
    if origins_ok:
        rows=origins['subjectOrigins'];origins_ok=set(rows)==set(plan['subjectOriginModules'])and len(rows)==plan['subjectOriginCount']==3
        for name,expected in plan['subjectOriginModules'].items():
            row=rows.get(name,{})
            origins_ok=origins_ok and row.get('actualModulePresent')is True and row.get('exactOriginMatched')is True
            origins_ok=origins_ok and row.get('actualModuleFile')==row.get('actualLoaderExecutedPath')==expected['path']
            origins_ok=origins_ok and origins['actualExecutedOrigins'].get(name)==expected['path']
            origins_ok=origins_ok and row.get('expectedSha256')==expected['sha256']==pin(expected['path'])['sha256']
    no_case_children=set(owned)=={born['pid']}and not(set(discovered)-{born['pid']})
    case_rows=[]
    for index in range(1,15):
        path=HERE/('child-receipts/standard-case-'+str(index)+'.json')
        if path.is_file():case_rows.append(json.loads(path.read_text()))
    cases_ok=len(case_rows)==14 and[row['id']for row in case_rows]==plan['cases']
    cases_ok=cases_ok and all(row['standardStopAfterCleanup']and row['remainingStandardCleanups']==0 and row['originalMethodsUnchanged']and row['monitorMasksSlotsUnchanged']and row['profileRestored']and row['fdUnchanged']and row['threadsUnchanged']and row['kernelChildrenUnchanged']for row in case_rows)
    class_path=HERE/'child-receipts/actual-class-cleanup-calls.json';class_restore_path=HERE/'child-receipts/actual-class-cleanup-restoration.json'
    class_calls=json.loads(class_path.read_text())if class_path.is_file()else None
    class_restore=json.loads(class_restore_path.read_text())if class_restore_path.is_file()else None
    class_ok=class_calls is not None and class_calls['expectedSelectedClasses']==plan['expectedClassCleanupGroups']==3 and class_calls['allActualOriginalCallsAccepted']is True and class_calls['actualOriginalClassCleanupCalls']==3
    class_ok=class_ok and class_restore is not None and class_restore['originalDescriptorRestored']is True and class_restore['originalFunctionCodeGlobalsUnchanged']is True and class_restore['summary']['allActualOriginalCallsAccepted']is True
    parent_fd_after=fds();parent_thread_after=tuple(threading.enumerate())
    save('actual-parent-drain.json',dict(fdsEqual=parent_fds==parent_fd_after,threadsEqual=parent_threads==parent_thread_after))
    passed=process is not None and process.returncode==0 and not problems and not orphans and not remaining and not timed_out and not forced
    passed=passed and first==second and first_children==second_children and input_unchanged and before==source_after_pins and parent_fds==parent_fd_after and parent_threads==parent_thread_after
    passed=passed and sorted(path.name for path in HERE.iterdir())==expected_names
    passed=passed and report is not None and report['status']=='PASS'and report['testsRun']==14 and report['actualCaseReceipts']==14 and report['PythonExecutions']==0
    passed=passed and selection is not None and selection['ids']==plan['cases']and not selection['loaderErrors']
    passed=passed and no_case_children and cases_ok and class_ok and origins_ok and report['allActualLoadedOriginsAccounted']is True
    passed=passed and restore is not None and restore['restored']and restore['count']==27 and not restore['controlDescriptors']and restore['dupPortsRestored']and restore['toolsRestored']and restore['builtinsCioRestored']and restore['actualC10dHelperSha256']==plan['subjectHelperSha256']
    terminal=dict(status='PASS'if passed else'FAIL_OR_REFUSED',childReturnCode=None if process is None else process.returncode,
        elapsedSeconds=time.monotonic()-started,problems=problems,timedOut=timed_out,forcedKill=forced,
        ownProcessesAbsent=not remaining,orphansRequiredKill=orphans,twoFullOwnOutputCensusesEqual=first==second,
        fullOwnCensusRoot=str(HERE),fullOwnCensusExclusions=[],approvedInputsExactPinAndCliShaUnchanged=input_unchanged,
        originalChildSubtreesCensusesEqual=first_children==second_children,
        allSourceBinaryPinsEqual=before==source_after_pins,actualStdlibParentFDThreadDrain=parent_fds==parent_fd_after and parent_threads==parent_thread_after,
        allThreeActualRuntimeOriginsEstablished=origins_ok,zeroCaseChildBirthsEstablished=no_case_children,PythonExecutions=0,
        actualFourteenCaseReceiptsEstablished=cases_ok,actualClassCleanupCustodyEstablished=class_ok,NodeExecutions=0,assetsPhaseQualified=False,nativeQualified=False,globalScans=0)
    save('terminal.json',terminal)
# No writes to HERE or COLLECTOR occur after these complete snapshots.
CENSUSES=checked(HERE.with_name(HERE.name+'-censuses'));assert not CENSUSES.exists();CENSUSES.mkdir(mode=0o700)
assert not actual_owned_left()
whole_first=dict(HERE=census(HERE),outer=census(COLLECTOR))
whole_second=dict(HERE=census(HERE),outer=census(COLLECTOR))
for name,value in(('whole-first.json',whole_first),('whole-second.json',whole_second)):
    path=CENSUSES/name
    with path.open('x')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    path.chmod(0o600)
qualified=passed and whole_first==whole_second and not actual_owned_left()
with(CENSUSES/'qualification.json').open('x')as stream:
    json.dump(dict(status='PASS'if qualified else'FAIL_OR_REFUSED',actualUtilityCases=14,
        priorTerminalPassed=passed,twoCompleteHEREAndOuterCensusesEqual=whole_first==whole_second,
        noCensusExclusions=True,ownProcessesAbsent=not actual_owned_left(),
        originalRoots=[str(HERE),str(COLLECTOR),str(CENSUSES)],diagnosticAdmission=None,assetsPhaseQualified=False,wholeQualified=False),stream,indent=2,sort_keys=True);stream.write('\n')
(CENSUSES/'qualification.json').chmod(0o600)
raise SystemExit(0 if qualified else 1)
