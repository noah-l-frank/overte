//
//  MixedProcessedAudioStream.h
//  libraries/audio/src
//
//  Created by Yixin Wang on 8/4/14.
//  Copyright 2013 High Fidelity, Inc.
//
//  Distributed under the Apache License, Version 2.0.
//  See the accompanying file LICENSE or http://www.apache.org/licenses/LICENSE-2.0.html
//

#ifndef hifi_MixedProcessedAudioStream_h
#define hifi_MixedProcessedAudioStream_h

#include "InboundAudioStream.h"
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
#include <atomic>
#include <QThread>
// Stack-only observation of one actual accepted packet and its real decode.
// No packet/buffer/frame is retained by this ticket, and no input may be supplied.
struct ReceivedMixerDecodedOriginal {
    ReceivedMixerDecodedOriginal() = default;
    ReceivedMixerDecodedOriginal(const ReceivedMixerDecodedOriginal&) = delete;
    ReceivedMixerDecodedOriginal& operator=(const ReceivedMixerDecodedOriginal&) = delete;
    const void* stream {nullptr}; ReceivedMessage* message {nullptr};
    const QByteArray* encoded {nullptr}; const QByteArray* decoded {nullptr}; const void* decoder {nullptr};
    const QThread* thread {nullptr}; quint16 sequence {0}; QString packetCodec, selectedCodec; bool early {false}, consumed {false};
    qint64 beforeEpoch {0}, afterEpoch {0}, beforeMono {0}, afterMono {0}, beforeReceiveClockUs {0}, afterReceiveClockUs {0}; QByteArray originalMessageDigest;
};
#endif

class AudioClient;

class MixedProcessedAudioStream  : public InboundAudioStream {
    Q_OBJECT
public:
    MixedProcessedAudioStream(int numFramesCapacity, int numStaticJitterFrames = -1);

signals:

    void addedSilence(int silentSamplesPerChannel);
    void addedLastFrameRepeatedWithFade(int samplesPerChannel);
    void addedStereoSamples(const QByteArray& samples);

    void processSamples(const QByteArray& inputBuffer, QByteArray& outputBuffer);
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
    // Only the AudioClient direct original-observer connection may consume this stack ticket.
    void receivedMixerDecodedOriginal(ReceivedMixerDecodedOriginal* original);
#endif

public:
    void outputFormatChanged(int sampleRate, int channelCount);
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
    void observeReceivedMixerOriginals(bool enabled) { _receivedOriginalsEnabled.store(enabled, std::memory_order_release); }
#endif

protected:
    int writeDroppableSilentFrames(int silentFrames) override;
    int parseAudioData(const QByteArray& packetAfterStreamProperties) override;
    int lostAudioData(int numPackets) override;
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
    int parseAcceptedAudioOriginal(ReceivedMessage& message, quint16 sequence, const QString& codec, bool early, const QByteArray& payload) override;
#endif

private:
    int networkToDeviceFrames(int networkFrames);
    int deviceToNetworkFrames(int deviceFrames);

private:
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
    std::atomic<bool> _receivedOriginalsEnabled {false};
    int decodeAudioOriginal(const QByteArray& payload, ReceivedMixerDecodedOriginal* original);
#endif
    quint64 _outputSampleRate;
    quint64 _outputChannelCount;
};

#endif // hifi_MixedProcessedAudioStream_h
