"""Paired original-only Avatar Keeper End2 replay, never a live factory.

All live Keeper/Source/SDK ownership originates in the pre-Stop coordinator.
This reader neither queries the current target nor reconstructs a live owner.
"""
from contextlib import ExitStack
from copy import deepcopy
from pathlib import Path

from adapters.native_feature_observation import exact, need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as original_reads
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.witness import Client
from ios.adapters.avatar_feature import IOSAvatarFeature
from ios.adapters.avatar_runtime import IOSAvatarRuntime
from ios.adapters.avatar_terminal import AvatarTerminal
from ios.adapters.avatar_keeper_handoff import filename as handoff_filename
from ios.adapters.avatar_keeper_terminal import AvatarKeeperTerminal, filename
from ios.adapters.emote_archive_lock import ArchiveSourceLock
from ios.adapters.emote_original_lease import EmoteOriginalLease


class OriginalsOnlyClient(Client):
    def request(self, *_args, **_kwargs):
        need(False)


def present(runtime, selectors, run):
    path = runtime.state_path(selectors['primary']).with_name(filename(run))
    return PrivateFeatureState(path).read() is not None


def verify(adapter, selector, coordinator, terminal_original, *, membership=None,
           held_locks=None, check=lambda: None):
    need(callable(check) and (membership is None or type(membership) is set))
    check()
    exact(coordinator, {'iosAvatarFeatureVersion','runId','role','selectors','artifactRoot',
        'imagePolicy','fixtureUrl','payload'})
    need(coordinator['role'] == 'primary' and selector in coordinator['selectors'].values())
    exact(coordinator['selectors'], {'primary','actor'})
    selectors = coordinator['selectors']
    need(selectors['primary'] != selectors['actor'])
    paths = {role:Path(adapter.state_path(target)) for role,target in selectors.items()}
    need(len({path.parent for path in paths.values()}) == 2
        and all(path.name == 'session.json' and path.is_absolute()
            and path.parent.resolve(strict=True) == path.parent for path in paths.values()))
    if held_locks is None:
        locks = {role:ArchiveSourceLock(path.with_name('script-feature-sources.lock'))
            for role,path in paths.items()}
    else:
        exact(held_locks, {'primary','actor'})
        locks = dict(held_locks)
        for role,lock in locks.items():
            need(isinstance(lock, ScriptSourceLock)
                and lock.path == paths[role].with_name('script-feature-sources.lock'))
            lock.assert_held()
    suffix = '/runs/'+coordinator['runId']+'/'
    need(coordinator['fixtureUrl'].endswith(suffix))
    client = OriginalsOnlyClient(coordinator['fixtureUrl'][:-len(suffix)],
        'avatar-keeper-originals-only-'+'a'*32)
    # This is the actual runtime constructor with the caller's actual adapter.
    # Historical methods below do not ask it to resolve a target or SDK.
    runtime = IOSAvatarRuntime(adapter)
    primary = paths['primary']
    flow_store = PrivateFeatureState(primary.with_name('ios-avatar-primary-feature.json'))
    terminal_store = PrivateFeatureState(primary.with_name(
        'ios-avatar-primary-'+coordinator['runId']+'-terminal.json'))
    with ExitStack() as held:
        for lock in sorted(locks.values(), key=lambda value:str(value.path)):
            held.enter_context(lock.held())
        need(same(flow_store.read(), coordinator) and same(terminal_store.read(), terminal_original))
        flow = IOSAvatarFeature.archive(runtime, coordinator, client, locks)
        need(flow.state['phase'] == 'terminal-ready')
        terminal = AvatarTerminal.archive(flow, terminal_original)
        owner = AvatarKeeperTerminal(terminal, historical=True)
        roles = terminal.roles(terminal.state['sealedRoles'])
        roots = {path.parent for path in paths.values()} | {role.root for role,_raw in roles.values()}
        # All metadata, child roots and original files are fixed after End2.
        # No blanket exclusion or current SDK/target lookup is permitted.
        leases = [EmoteOriginalLease(root, []) for root in sorted(roots)]
        with original_reads(fresh=True) as reads:
            need(same(flow_store.read(), coordinator) and same(terminal_store.read(), terminal_original))
            flow = IOSAvatarFeature.archive(runtime, coordinator, client, locks)
            terminal = AvatarTerminal.archive(flow, terminal_original)
            owner = AvatarKeeperTerminal(terminal, historical=True)
            owner.original(membership=reads)
            for role,path in paths.items():
                need(PrivateFeatureState(path).read() is None
                    and adapter._binding_store(selectors[role]).read() is None)
            from ios.adapters.avatar_session_carriers import covered
            for path in paths.values():
                covered(path.parent, roots, reads)
            check()
        for lease in leases:
            lease.guard()
        if membership is not None:
            membership.update(reads)
        check()
        role = next(role for role,target in selectors.items() if target == selector)
        return deepcopy(flow.state['bindings'][role])


def verify_flow(flow, call, result):
    from ios.adapters.avatar_keeper_terminal_contract import arguments, result as validate_result
    arguments(call)
    validate_result(result)
    need(call['runId'] == flow.run and same(call['seal'], result['end']['seal']))
    with flow.held(paired=True):
        flow.load()
        terminal = AvatarTerminal(flow)
        owner = AvatarKeeperTerminal(terminal, historical=True)
        need(same(owner.original(), result['end']))
        binding = verify(flow.runtime.adapter, flow.selector, flow.previous,
            terminal.previous, held_locks=flow.locks)
        need(same(binding, flow.state['bindings']['primary']))
    return deepcopy(result)


def actor_ended(flow):
    """False is only a typed incomplete composition, not missing-proof success."""
    need(flow.role == 'actor')
    primary = flow.runtime.state_path(flow.selectors['primary'])
    value = PrivateFeatureState(primary.with_name(filename(flow.run))).read()
    if value is None:
        return None
    coordinator = PrivateFeatureState(primary.with_name('ios-avatar-primary-feature.json')).read()
    terminal_original = PrivateFeatureState(primary.with_name('ios-avatar-primary-'+flow.run+'-terminal.json')).read()
    need(coordinator is not None and terminal_original is not None)
    parent = IOSAvatarFeature.archive(flow.runtime, coordinator, flow.client, flow.locks)
    terminal = AvatarTerminal.archive(parent, terminal_original)
    owner = AvatarKeeperTerminal(terminal, historical=True)
    roles = terminal.roles(terminal.state['sealedRoles'])
    roots = {flow.runtime.state_path(target).parent for target in flow.selectors.values()}
    roots.update(role.root for role,_raw in roles.values())
    leases = [EmoteOriginalLease(root, []) for root in sorted(roots)]
    owner.inventory()
    need(same(PrivateFeatureState(primary.with_name('ios-avatar-primary-feature.json')).read(), coordinator)
        and same(PrivateFeatureState(primary.with_name('ios-avatar-primary-'+flow.run+'-terminal.json')).read(), terminal_original))
    for lease in leases:
        lease.guard()
    if owner.state['phase'] != 'complete':
        return False
    binding = verify(flow.runtime.adapter, flow.selector, coordinator, terminal_original,
        held_locks=flow.locks)
    need(same(binding, flow.state['bindings']['actor']))
    return True
