"""Read actual closed PCM five-case originals; no target or live/native admission."""
from pathlib import Path
import argparse,hashlib,json,runpy,stat
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,x):
 with(d/n).open('x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
p=argparse.ArgumentParser();p.add_argument('--collector',required=True,type=Path);p.add_argument('--collector-sha',required=True);p.add_argument('--old-roots',required=True,type=int);p.add_argument('--output',required=True,type=Path);a=p.parse_args()
C=a.collector;assert C.parent==B and a.output.parent==B and not a.output.exists()
assert sha(C/'freeze.json')==a.collector_sha
for n,v in load(C/'freeze.json')['files'].items():assert sha(C/n)==v['sha256']
t=load(C/'terminal.json');assert len(t['groups'])==1 and t['oldRootCount']==a.old_roots and len(t['newOriginalRoots'])==4
assert t['allOldOriginalBodiesUnchanged']and t['wholeOwnOutputsTwiceEqual']and t['allExecutedOwnedProcessesAbsent']and not t['unrunGroups']
assert load(C/'global-before.json')==load(C/'global-after-first.json')==load(C/'global-after-second.json')
assert len(load(C/'global-before.json'))==a.old_roots
assert load(C/'whole-output-first.json')==load(C/'whole-output-second.json')
q=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py'
assert sha(q)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be'
census=runpy.run_path(str(q))['census']
for name,value in load(C/'whole-output-first.json').items():assert census(Path(name))==value
row=t['groups'][0];h=Path(row['input']).parent;o=h.with_name(h.name+'-outer');c=h.with_name(h.name+'-censuses')
assert sha(row['input'])==row['inputSha256'];plan=load(row['input'])
assert plan['sourceFreeze']=='ee5d241465b4590bbed0e7d967d5cc7ebcb43fdd947f1bdcc04019790b28ebe3'
assert plan['wallSeconds']==30 and plan['killGraceSeconds']==5 and len(plan['cases'])==5
assert plan['receivedMixerLiveAdmission']is plan['PCMUtilityQualification']is plan['consumerAdmission']is None
terminal=row['originalTerminal'];assert row['supervisorReturnCode']==0 and terminal['status']==row['originalQualification']['status']=='PASS'
assert terminal['childReturnCode']==0 and terminal['ownProcessesAbsent']and not terminal['timedOut']and not terminal['forcedKill']and not terminal['problems']and not terminal['orphansRequiredKill']
for key in('twoFullOwnOutputCensusesEqual','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','allSourceBinaryPinsEqual','actualStdlibParentFDThreadDrain','allThirteenSelectedActualRuntimeOriginsEstablished','zeroCaseChildBirthsEstablished','actualFiveCaseReceiptsEstablished','actualClassCleanupCustodyEstablished','actualOriginalLockCustodyEstablished','actualFiveTemporaryDirectoriesEstablished'):assert terminal[key]is True
assert load(o/'source-binary-before.json')==load(o/'source-binary-after.json')==plan['sourceAndBinaryPins']
for x,y in [('approved-input-before.json','approved-input-after.json'),('actual-child-output-first.json','actual-child-output-second.json'),('actual-child-subtrees-first.json','actual-child-subtrees-second.json')]:assert load(o/x)==load(o/y)
assert load(c/'whole-first.json')==load(c/'whole-second.json')
assert load(o/'actual-parent-drain.json')==dict(fdsEqual=True,threadsEqual=True)
drain=load(o/'actual-process-drain.json');assert len(drain['owned'])==1 and not drain['remaining']and not drain['orphansRequiredKill']and not drain['timedOut']and not drain['forced']
for v in drain['owned']:
 try:raw=Path('/proc',str(v['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(raw[raw.rfind(')')+2:].split()[19])!=v['startTicks']
r=load(h/'child-receipts/report.json');ports=load(h/'child-receipts/actual-port-restoration.json')
assert r['status']=='PASS'and r['testsRun']==r['actualCaseReceipts']==5 and r['fatal']is None and r['cleanupEstablished']
for key in('fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','twoToyCensusesEqual','allActualLoadedOriginsAccounted'):assert r[key]is True
assert r['NodeExecutions']==r['SDKExecutions']==r['PythonExecutions']==r['overteNativeQueries']==0 and not r['realNetwork']and r['temporaryDirectoryAbsenceClaimed']is False
assert len(r['retainedTemporaryDirectories'])==5
for v in r['retainedTemporaryDirectories']:
 st=Path(v['path']).lstat();assert stat.S_ISDIR(st.st_mode)and(st.st_dev,st.st_ino)==(v['device'],v['inode'])
for key in('restored','builtinsCioRestored','dupPortsRestored','toolsRestored'):assert ports[key]is True
assert ports['count']==27 and not ports['controlDescriptors']and ports['classCleanupRestorationError']is None and ports['actualClassCleanupRestoration']['originalDescriptorRestored']
origins=load(h/'child-receipts/actual-source-model-origins.json');assert origins['allThirteenSelectedActualRuntimeOriginsEstablished']and len(origins['subjectOrigins'])==13
for name,v in origins['subjectOrigins'].items():
 expected=plan['subjectOriginModules'][name];assert v['exactOriginMatched']and v['actualModulePresent']and v['actualLoaderExecutedPath']==v['actualModuleFile']==v['expectedPath']==expected['path']and v['expectedSha256']==expected['sha256']
 e=v['actualSourceExecution'];assert e['kind']=='fresh-pinned-python-source-bytes'and e['sourceSha256']==expected['sha256']and e['cachedBytecodeConsulted']is False
 assert sha(Path(expected['path']))==expected['sha256']
selected=load(h/'child-receipts/actual-selection.json');assert selected['ids']==plan['cases']and not selected['loaderErrors']
cases=[load(h/('child-receipts/standard-case-'+str(j)+'.json'))for j in range(1,6)];assert [v['id']for v in cases]==plan['cases']
for v in cases:
 for key in('standardStopAfterCleanup','originalMethodsUnchanged','monitorMasksSlotsUnchanged','fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','profileRestored'):assert v[key]is True
 assert v['remainingStandardCleanups']==0 and v['newTemporaryDirectories']==1
 for call in v['actualNestedCleanupCalls']:assert call['originalReturned']is True and call['remaining']==0 and call['originalRaised']is None and not call['newCallbackErrors']and not call['newCallbackFailures']
locks=load(h/'child-receipts/actual-original-lock-owners.json');assert locks['actualOriginalHeldCalls']>0 and locks['allObservedOwnersReleased']and locks['allOriginalLockDescriptorsClosed']
refs={str(p):dict(path=str(p),sha256=sha(p))for root in map(Path,t['newOriginalRoots'])for p in sorted(root.rglob('*'))if p.is_file()and not p.is_symlink()}
a.output.mkdir(mode=0o700)
put(a.output,'results.json',dict(status='ROOT_QUALIFIED_RECEIVED_PCM_ORIGINALS_FIVE_HOST_CASES_ONLY',terminal=terminal,newOriginalRoots=t['newOriginalRoots'],originalCollectorFreeze=a.collector_sha,oldOriginalRootCount=a.old_roots,allOldOriginalBodiesUnchanged=True,group=plan['group'],actualCases=plan['cases'],actualReport=r,actualOriginalLocks=locks,sourceFreeze=plan['sourceFreeze'],PCMOriginalReaderHostCasesQualified=True,receivedMixerLiveAdmission=None,consumerAdmission=None,individualPeerQualified=False,nativeCompiled=False,featureQualified=False,wholeQualified=False))
put(a.output,'actual-receipt-references.json',refs);put(a.output,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in a.output.iterdir()}));print(json.dumps(dict(freeze=sha(a.output/'freeze.json'),references=len(refs),cases=5)))
