from pathlib import Path
import ast,hashlib,json,importlib.util
r=Path.cwd().resolve();assert r.name=='overte-ios-feature-adapters-resume-20261026'and(r/'.git').is_file()
p=r/'.ios-host-tmp/audio-original-keeper-profile-route-closed-utility6-bootstrap2-genuine-class-cleanup-current-actor-code-preparation-20261104';assert p.resolve().is_relative_to(r)and not(p/'source-freeze.json').exists();p.mkdir(exist_ok=True)
b=r/'.ios-host-tmp/c24-diagnostic-source3-closed-utility14-bootstrap2-genuine-class-cleanup-code-preparation-20261104'
s=r/'.ios-host-tmp/audio-original-keeper-cli-profile-adapter-source2-exact-interface-inventory-private-20261104'
stage=r/'.ios-host-tmp/audio-normal14-original-handoff-integration-staging1-private-20261104'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,t):
 f=p/n;assert f.resolve().is_relative_to(r);f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(t if isinstance(t,bytes)else t.encode())
def dump(v):return json.dumps(v,indent=2,sort_keys=True)+'\n'
for n in ['metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','class_cleanup_custody.py','source_execution_readiness.py','readonly-shared-stdlib-sources.json']:put(n,(b/n).read_bytes())
put('exact-six-selectors.json',(s/'prospective-six-selectors.json').read_bytes())
external=r/'.ios-host-tmp/audio-original-handoff-first1-bootstrap3-qualified-c10d-kernel-real-namespace-code-preparation-20261104/third-party-source-declarations.json'
assert sha(external)=='0df1d3968a70455a27b8a1c4c69d9b97178960ff187888d2e14677093cdacf1b';put('third-party-source-declarations.json',external.read_bytes())
# Finite real-source read closure only. No code import, module birth or builder.
rows=json.loads((stage/'STAGING-MANIFEST.json').read_text())['rows'];assert len(rows)==107
bylogical={v['path']:stage/'candidate'/v['path']for v in rows}
candidates=json.loads((s/'CANDIDATES.json').read_text());assert len(candidates)==4
for v in candidates:bylogical[v['path']]=s/'candidate'/v['path'];assert sha(bylogical[v['path']])==v['candidateSha256']
def lookup(name):
 stem='tests/device/'+name.replace('.','/')
 for key,package in ((stem+'.py',False),(stem+'/__init__.py',True)):
  actual=bylogical.get(key,r/key)
  if actual.is_file():return actual,package,key
 return None
selected={};todo=['self_tests.test_audio_original_keeper_terminal_profile']
def top_imports(body):
 for node in body:
  if isinstance(node,(ast.Import,ast.ImportFrom)):yield node
  elif isinstance(node,(ast.Try,ast.If,ast.With)):
   for key in('body','orelse','finalbody'):
    yield from top_imports(getattr(node,key,[]))
   for h in getattr(node,'handlers',[]):yield from top_imports(h.body)
while todo:
 name=todo.pop(0)
 if name in selected:continue
 found=lookup(name)
 if found is None:continue
 actual,package,logical=found;assert actual.resolve(strict=True)==actual
 selected[name]=dict(path=str(actual),sha256=sha(actual),package=package,logical=logical,physicalRole='exact-route-source2'if actual.is_relative_to(s)else'exact-audio107-staged'if actual.is_relative_to(stage)else'current-public-defining-dependency')
 parts=name.split('.')
 for size in range(1,len(parts)):todo.append('.'.join(parts[:size]))
 tree=ast.parse(actual.read_text(),filename=str(actual));context=name if package else name.rsplit('.',1)[0]if'.'in name else ''
 for node in top_imports(tree.body):
  if isinstance(node,ast.Import):todo.extend(alias.name for alias in node.names)
  else:
   base=importlib.util.resolve_name('.'*node.level+(node.module or ''),context)if node.level else node.module or ''
   if base:todo.append(base)
   todo.extend(base+'.'+alias.name for alias in node.names if alias.name!='*'and base)
# The existing Journey lazily imports its selected terminal. It was reached from
# the selected module already; unselected CLI/Audio owner imports are data only.
assert 'feature_journeys.engine'in selected and'feature_journeys.terminal'in selected and'self_tests.test_feature_terminal'in selected
assert not any(name.startswith(('pymobiledevice3','appium','selenium','ios.'))for name in selected)
for name,row in selected.items():
 ast.parse(Path(row['path']).read_text())
project_namespaces={}
for name in selected:
 for size in range(1,len(name.split('.'))):
  parent='.'.join(name.split('.')[:size])
  if parent in selected:continue
  physical=r/'tests/device'/parent.replace('.','/');assert physical.is_dir()and physical.resolve(strict=True)==physical
  project_namespaces[parent]=[str(physical)]
subjects=('feature_journeys.engine','feature_journeys.terminal','feature_journeys.fixtures','self_tests.test_audio_original_keeper_terminal_profile','self_tests.test_feature_terminal','self_tests.test_feature_journeys')
assert all(n in selected for n in subjects)
put('PROJECT-DEFINING-ORIGINS.json',dump(dict(status='SOURCE_ONLY_EXACT_DEFINITION_ROWS_NO_IMPORT',modules=selected,namespacePackages=project_namespaces,subjectModules=list(subjects),dataOnlyCandidatePaths=['tests/device/modules/feature_journey.py'],staticImportClosureMethod='Actual top-level import definitions plus their real parent packages; selected Journey lazy terminal already explicit; other scenario dynamic imports stay unplanned/refuse.',stage107Freeze='28babecbcbb390c5638a695965f0a822fc872c86b505cb011d2c5bcdba1c986a',routeSource2Freeze='cf980ab55fe1801ff683281440b41dfc54595193dd1953a98898c9ef98b0373b')))
# Adapt the already-closed pure harness. No counter or production body changes.
t=(b/'run-fourteen.py').read_text().replace('Fourteen pure C24 diagnostic utility counters','Six Audio profile wire/model utility counters').replace('PRIVATE_C24_DIAGNOSTIC_SOURCE3_UTILITY14_UNRUN','PRIVATE_AUDIO_KEEPER_PROFILE_ROUTE_UTILITY6_UNRUN').replace('exact-fourteen-selectors.json','exact-six-selectors.json').replace('==14','==6').replace('Utility14','Utility6')
a=t.index("    declarations=(('intent_graph_diagnostic'");z=t.index('    for module_name,class_names in declarations:',a)
t=t[:a]+'''    declarations=(('feature_journeys.engine',('Journey',)),
        ('self_tests.test_audio_original_keeper_terminal_profile',('TerminalWireInputs','AudioOriginalKeeperTerminalProfileTests')),
        ('self_tests.test_feature_terminal',('Boundary','FeatureTerminalTests')),
        ('self_tests.test_feature_journeys',('Boundary',)),('feature_journeys.witness',('Journal',)),('class_cleanup_custody',('ClassCleanupCustody',)))
''' +t[z:]
t=t.replace("plan['subjectOriginCount']==2","plan['subjectOriginCount']==6").replace('allTwoActualRuntimeOriginsEstablished','allSixActualRuntimeOriginsEstablished')
# Use the selected source's exact real function boundaries, including all codec
# functions. No decorated operation or native owner is introduced here.
t=t.replace('    for module_name,class_names in declarations:\n',"    declarations+=(('feature_journeys.terminal',()),)\n    for module_name,class_names in declarations:\n")
put('run-six.py',t)
t=(b/'supervise-fourteen.py').read_text().replace('fourteen pure C24 diagnostic utility counters','six Audio profile wire/model utility counters').replace('PRIVATE_C24_DIAGNOSTIC_SOURCE3_UTILITY14_UNRUN','PRIVATE_AUDIO_KEEPER_PROFILE_ROUTE_UTILITY6_UNRUN').replace('exact-fourteen-selectors.json','exact-six-selectors.json').replace('run-fourteen.py','run-six.py').replace('supervise-fourteen.py','supervise-six.py').replace('==14','==6').replace('range(1,15)','range(1,7)').replace('actualUtilityCases=14','actualUtilityCases=6').replace('actualFourteenCaseReceiptsEstablished','actualSixCaseReceiptsEstablished').replace("plan['subjectOriginCount']==2","plan['subjectOriginCount']==6").replace('allTwoActualRuntimeOriginsEstablished','allSixActualRuntimeOriginsEstablished').replace('assetsPhaseQualified','audioEndQualified')
put('supervise-six.py',t)
t=(b/'prepare.py').read_text().replace('C24 diagnostic pure Utility14','Audio profile pure Utility6').replace("SUBJECT=REPO/'.ios-host-tmp/assets-c24-policy-value-bounded-diagnostic-source3-unknown-mutating-c-return-private-20261104'","SUBJECT=REPO/'.ios-host-tmp/audio-original-keeper-cli-profile-adapter-source2-exact-interface-inventory-private-20261104'")
t=t.replace("SUBJECT_SHA='5430c80f66b464f1cb233e54482323b55c1b3cb95ef794b1df2d14e382b5ddfd'","SUBJECT_SHA='cf980ab55fe1801ff683281440b41dfc54595193dd1953a98898c9ef98b0373b'")
a=t.index('EXECUTORS=');z=t.index('\ndef frozen',a)
t=t[:a]+'''STAGE=REPO/'.ios-host-tmp/audio-normal14-original-handoff-integration-staging1-private-20261104'
STAGE_SHA='28babecbcbb390c5638a695965f0a822fc872c86b505cb011d2c5bcdba1c986a'
EXECUTORS=('run-six.py','supervise-six.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','class_cleanup_custody.py','source_execution_readiness.py','readonly-shared-stdlib-sources.json','exact-six-selectors.json','PROJECT-DEFINING-ORIGINS.json','third-party-source-declarations.json')
''' +t[z:]
a=t.index("    for name in('intent_graph_diagnostic.py'");z=t.index('    current_qualification',a)
t=t[:a]+'''    frozen(STAGE,'source-freeze.json',STAGE_SHA,physical)
    frozen(REPO/'.ios-host-tmp/root-audio-original-keeper-profile-routing-source2-review-20261104','freeze.json','59d2213ef3927ae46c3403030dd46f82bbf7cdb2f69358e7c4868f39591eab1f',physical)
    stage_rows=json.loads((STAGE/'STAGING-MANIFEST.json').read_text())['rows'];assert len(stage_rows)==107
    for row in stage_rows:
        path=STAGE/'candidate'/row['path'];assert path.resolve(strict=True).is_relative_to(STAGE/'candidate')
        assert pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
    candidates=json.loads((SUBJECT/'CANDIDATES.json').read_text());assert len(candidates)==4
    for row in candidates:
        path=SUBJECT/'candidate'/row['path'];assert pin(path)['sha256']==row['candidateSha256'];physical[str(path)]=pin(path)
    closure=json.loads((SOURCE/'PROJECT-DEFINING-ORIGINS.json').read_text())
    assert closure['stage107Freeze']==STAGE_SHA and closure['routeSource2Freeze']==SUBJECT_SHA
    project_modules={}
    for name,row in closure['modules'].items():
        path=Path(row['path']);assert path.resolve(strict=True)==path and pin(path)['sha256']==row['sha256']
        physical[str(path)]=pin(path);project_modules[name]={k:row[k]for k in('path','sha256','package')};project_modules[name]['loader']='source'
    project_namespaces=closure['namespacePackages']
    for roots in project_namespaces.values():
        for root in roots:assert Path(root).is_dir()and Path(root).resolve(strict=True)==Path(root)
    third={};external=json.loads((SOURCE/'third-party-source-declarations.json').read_text());assert len(external)==39
    for name,row in external.items():
        assert name=='PIL'or name.startswith('PIL.')or name=='defusedxml'or name.startswith('defusedxml.')
        path=Path(row['path']);assert path.resolve(strict=True)==path and pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
        assert row['kind']in('python','extension')
        third[name]=dict(path=str(path),sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
''' +t[z:]
t=t.replace("startswith('c24-diagnostic-utility14-prepared-')","startswith('audio-keeper-profile-utility6-prepared-')")
a=t.index('    modules={');z=t.index('    origin=dict',a)
t=t[:a]+'''    modules=dict(project_modules)
    for name in('metadata_reader','host_common','source_execution_readiness','closed_import_origins','owned_write_boundary','class_cleanup_custody'):
        assert name not in modules
        modules[name]=dict(path=str(dest/(name+'.py')),sha256=physical[str(dest/(name+'.py'))]['sha256'],package=False,loader='source')
    cases=json.loads((SOURCE/'exact-six-selectors.json').read_text());assert len(cases)==len(set(cases))==6
    subjects={name:dict(path=modules[name]['path'],sha256=modules[name]['sha256'])for name in(*closure['subjectModules'],'class_cleanup_custody')};assert len(subjects)==7
''' +t[z:]
t=t.replace('namespacePackages={},thirdPartyModules={}','namespacePackages=project_namespaces,thirdPartyModules=third').replace('modules=modules,namespaces={},thirdPartyModules={}','modules=modules,namespaces=project_namespaces,thirdPartyModules=third')
t=t.replace('PRIVATE_C24_DIAGNOSTIC_SOURCE3_UTILITY14_UNRUN','PRIVATE_AUDIO_KEEPER_PROFILE_ROUTE_UTILITY6_UNRUN').replace('subjectOriginCount=2','subjectOriginCount=6').replace('expectedJoinedThreadCases=1','expectedJoinedThreadCases=0')
t=t.replace('diagnosticAdmission=None,assetsPhaseQualified=False','audioEndAdmission=None,audioEndQualified=False,fullAudioQualified=False')
t=t.replace("historicalApplicationReferenceLedgerRole='Pinned literal source metadata only; original C24 raw log/phase outputs are not utility inputs.'","staged107PhysicalOriginsRetained=True,CLIImportedOrExecuted=False,modeledExistingFeatureTerminalCase=True")
t=t.replace('cases=14,targets=0','cases=6,targets=0').replace('delegated kernel/test modules','delegated selected project modules')
put('prepare.py',t)
for f in p.glob('*.py'):ast.parse(f.read_text(),filename=str(f))
print(p);print('finite defining project modules',len(selected));print('\n'.join(selected))
