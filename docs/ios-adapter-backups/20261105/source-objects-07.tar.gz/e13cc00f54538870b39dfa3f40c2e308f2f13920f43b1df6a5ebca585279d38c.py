"""Explicit Python original-keeper Stop, OS quiet and canonical SDK retirement.

One planned request may recover its actual completed child original. An unknown
return never authorizes another request. The archive reader has no live Source.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import base64,hashlib,json,time,uuid
from copy import deepcopy
from pathlib import Path
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need,number
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import canonical,pack,unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import identifier
from ios.adapters import appium_adapter as backend
from ios.adapters import original_keeper_retired_process as os_original
from ios.adapters.installed_code import cleanup_record

PROFILE='ios-original-keeper-process-end-v1'
FAMILIES={'lifecycle':('primary','actor'),'audioonce':('actor',),'audiowhole':('primary',),'avatar':('primary','actor'),'audioreceived':('actor',)}


def filename(profile_key,role,stage):
    need(profile_key in FAMILIES and role in FAMILIES[profile_key]and type(stage)is int and stage in ((0,1)if profile_key=='audiowhole'else (0,)))
    family={'audioonce':'audio-once','audiowhole':'audio-whole','lifecycle':'lifecycle','avatar':'avatar-original','audioreceived':'audio-received'}[profile_key]
    return 'ios-'+family+'-'+role+'-'+str(stage)+'-process-retirement.json'


class IOSOriginalKeeperProcessEnd:
    def __init__(self,runtime,selector,root,binding,run,role,stage,profile_key,lock,*,epoch_ms=lambda:time.time()*1000,monotonic=time.monotonic,sleep=time.sleep):
        from ios.adapters.script_runtime import IOSScriptRuntime
        need(isinstance(runtime,IOSScriptRuntime)and isinstance(lock,ScriptSourceLock))
        self.runtime,self.selector,self.root=runtime,selector,Path(root)
        self.binding,self.run,self.role=deepcopy(context(binding)),identifier(run),role
        self.stage,self.profile_key,self.profile=stage,profile_key,PROFILE
        self.lock,self.epoch_ms,self.monotonic,self.sleep=lock,epoch_ms,monotonic,sleep
        self.store=PrivateFeatureState(runtime.state_path(selector).with_name(filename(profile_key,role,stage)))
        need(lock.path==self.store.path.with_name('script-feature-sources.lock')and self.root!=self.store.path.parent)
        lock.assert_held();self.previous=self.store.read();self.state=None
        self.files=OriginalFrameStore(self.root,self.binding,self.run,self.role,self.bound,self.intent,
            namespace=('original-process-end'if stage==0 else 'original-process-end-replacement'),schema_prefix='iosOriginalProcessEnd')
        if self.previous is not None:
            self.state=self.decode(self.previous)
            if self.state['phase']=='complete':return
            # The exact original transport was journaled before Stop. Final
            # canonical deletion may already have removed one or both local
            # states before the completed CAS returns; _existing() would fail
            # there and must never create/require another SDK or Source.
            scope={key:value for key,value in self.binding.items()if key!='processIdentity'}
            target=runtime.adapter._retired_candidate_scope(selector,scope)
            need(target['serverUrl']==self.state['sdkOrigin'])
            sdk=PrivateFeatureState(runtime.state_path(selector)).read()
            need(same(sdk,self.state['sdkState'])or sdk is None and self.state['deleteIssued'])
            self.client,self.target=backend.WebDriver(self.state['sdkOrigin']),target
        else:
            source=runtime._sources(selector);need(same(source['binding'],self.binding))
            self.client,self.target=source['client'],source['target']
            installed=runtime.adapter._binding_store(selector).read();need(installed is not None and installed['phase']=='bound')
            self.state=dict(phase='prepared',records=[],pending=None,owner=None,roles=None,cutoff=None,stop=None,os=[],sdk=None,creator=None,deletion=None,
                sdkState=deepcopy(source['state']),sdkOrigin=self.client.server_url,installed=deepcopy(installed),deleteIssued=False,canonicalStateAbsence=None)
            self.save()
        self.birth()

    def birth(self):
        need(type(self.client)is backend.WebDriver)
        self.origin=self.client.server_url
        self.receivers=tuple((name,getattr(self.client,name),getattr(self.client,name).__func__.__code__)for name in ('execute','call','_read_reply'))
        self.send,self.http=self.receivers[0][1],self.receivers[1][1]

    def transport(self):
        self.bound();need(self.client.server_url==self.origin)
        for name,bound,code in self.receivers:
            current=getattr(self.client,name)
            need(current.__self__ is self.client and current.__func__ is bound.__func__ and bound.__func__.__code__ is code)

    def envelope(self):
        return dict(iosOriginalKeeperRetirementArchiveVersion=1,profile=PROFILE,profileKey=self.profile_key,binding=self.binding,
            runId=self.run,role=self.role,stage=self.stage,artifactRoot=str(self.root),payload=pack([self.state]))

    def bound(self):
        self.lock.assert_held();need(same(self.store.read(),self.previous))
        expected={self.files.path(self.files.expand(ref))for ref in self.state['records']}if self.state is not None else set()
        pending=None if self.state is None else self.state['pending']
        if pending is not None and pending['file']is not None and pending['file']['phase']!='planned':expected.add(self.files.path(pending['file']))
        actual=set(self.root.glob(self.files.namespace+'-frame-sources-'+self.run+'-'+self.role+'-*.json'))
        need(actual==expected);return True

    def save(self):
        self.bound();value=self.envelope();self.store.write(value,self.previous);self.previous=deepcopy(value)

    def intent(self,kind,value):
        need(kind=='original'and self.state['pending']is not None);self.files.original(value)
        pending=self.state['pending'];need(value['index']==len(self.state['records'])+1)
        old=pending['file']
        if old is None:need(value['phase']=='planned')
        else:need(all(same(old[k],value[k])for k in old if k not in ('phase','file'))
            and (old['phase'],value['phase'])in (('planned','opened'),('opened','saved')))
        pending['file']=deepcopy(value);self.save()

    def original(self,reference):return self.files.read(self.files.expand(reference))

    def fetch(self,result):
        self.transport();exact(result,{'iosOriginalKeeperEndReferenceVersion','ownerInstance','binding','runId','reference','profile'})
        need(type(result['iosOriginalKeeperEndReferenceVersion'])is int and result['iosOriginalKeeperEndReferenceVersion']==1
            and result['profile']==PROFILE and same(result['binding'],self.binding)and result['runId']==self.run)
        owner=identifier(result['ownerInstance'])
        need(self.state['owner']in (None,owner));reference=result['reference']
        codec=OriginalFrameStore(self.root,self.binding,self.run,'primary',self.bound,lambda *_:need(False),
            namespace=('original-keeper-end'if self.stage==0 else 'original-keeper-end-next'),schema_prefix='iosOriginalKeeperEnd')
        codec.expand(reference);parts=[];started=self.monotonic()
        for offset in range(0,reference['bytes'],4096):
            self.transport();need(self.monotonic()-started<5)
            chunk=self.send(self.binding['sessionId'],'mobile: overteOriginalKeeperOperation',dict(operation='original-process-end-read',args=dict(reference=reference,offset=offset)))
            self.transport();exact(chunk,{'reference','offset','contentBase64'})
            need(same(chunk['reference'],reference)and type(chunk['offset'])is int and chunk['offset']==offset)
            raw=base64.b64decode(chunk['contentBase64'],validate=True);need(len(raw)==min(4096,reference['bytes']-offset));parts.append(raw)
        raw=b''.join(parts);need(len(raw)==reference['bytes']and hashlib.sha256(raw).hexdigest()==reference['sha256'])
        body=json.loads(raw.decode('utf-8'));need(canonical(body)==raw)
        exact(body,{'iosOriginalKeeperEndFrameVersion','kind','binding','runId','role','index','frame'})
        need(type(body['iosOriginalKeeperEndFrameVersion'])is int and body['iosOriginalKeeperEndFrameVersion']==1
            and body['kind']=='sources'and body['binding']==self.binding and body['runId']==self.run and body['role']=='primary'
            and type(body['index'])is int and body['index']==reference['index'])
        row=body['frame'];exact(row,{'kind','role','operationId','original'})
        return dict(sourceReference=deepcopy(reference),sourceOwnerInstance=owner,sourceFrame=deepcopy(body))

    def adopt(self,result):
        pending=self.state['pending'];need(pending is not None)
        value=self.fetch(result);row=value['sourceFrame']['frame']
        need(row['kind']==pending['kind']and row['role']==pending['role']and row['operationId']==pending['operationId'])
        reference=self.files.write(len(self.state['records'])+1,value)
        self.state['records'].append(reference);self.state['owner']=value['sourceOwnerInstance'];self.state['pending']=None
        kind=row['kind']
        if kind=='os':self.state['os'].append(reference)
        else:self.state[{'cutoff':'cutoff','stop':'stop','sdk':'sdk'}[kind]]=reference
        self.state['phase']={'cutoff':'armed','stop':'stopped','os':'observing','sdk':'sdk-closed'}[kind]
        self.save();self.validate_history();return reference

    def recover(self):
        pending=self.state['pending']
        if pending is None:return
        if pending['file']is not None and pending['file']['phase']in ('opened','saved'):
            value=self.files.read(pending['file']);reference=self.files.compact(dict(pending['file'],phase='saved'))
            if pending['kind']=='deletion':
                exact(value,{'canonicalDeletion'});need(value['canonicalDeletion']['operationId']==pending['operationId'])
                self.state['records'].append(reference);self.state.update(deletion=reference,pending=None,phase='delete-observed');self.save();return
            if pending['kind']=='creator':
                exact(value,{'creatorRetirement'});self.validate_creator(value['creatorRetirement'])
                self.state['records'].append(reference);self.state.update(creator=reference,pending=None,phase='creator-closed');self.save();return
            row=value['sourceFrame']['frame'];need(row['operationId']==pending['operationId'])
            # The local frame is already complete; use its exact source ref.
            result=dict(iosOriginalKeeperEndReferenceVersion=1,ownerInstance=value['sourceOwnerInstance'],binding=self.binding,
                runId=self.run,profile=PROFILE,reference=value['sourceReference'])
            # Do not create another local original when recovering saved bytes.
            self.state['records'].append(reference);self.state['owner']=value['sourceOwnerInstance'];self.state['pending']=None
            kind=row['kind']
            if kind=='os':self.state['os'].append(reference)
            else:self.state[{'cutoff':'cutoff','stop':'stop','sdk':'sdk'}[kind]]=reference
            self.state['phase']={'cutoff':'armed','stop':'stopped','os':'observing','sdk':'sdk-closed'}[kind];self.save();self.validate_history();return
        self.transport()
        if pending['kind']=='creator':
            result=self.send(self.binding['sessionId'],'mobile: overteOriginalKeeperOperation',dict(operation='original-process-end-creator-status',args={}))
            self.transport();self.adopt_creator(result);return
        status=self.send(self.binding['sessionId'],'mobile: overteOriginalKeeperOperation',dict(operation='original-process-end-status',args=dict(operationId=pending['operationId'])))
        self.transport();exact(status,{'iosOriginalKeeperEndStatusVersion','profile','ownerInstance','binding','runId','records','pending','phase'})
        need(type(status['iosOriginalKeeperEndStatusVersion'])is int and status['iosOriginalKeeperEndStatusVersion']==1
            and status['profile']==PROFILE and status['binding']==self.binding and status['runId']==self.run)
        rows=[row for row in status['records']if row['operationId']==pending['operationId']]
        need(len(rows)==1 and rows[0]['kind']==pending['kind']and rows[0]['role']==pending['role'])
        self.adopt(dict(iosOriginalKeeperEndReferenceVersion=1,profile=PROFILE,ownerInstance=status['ownerInstance'],
            binding=self.binding,runId=self.run,reference=rows[0]['reference']))

    def rpc(self,kind,args,*,role=None):
        self.transport();pending=deepcopy(self.state['pending']);self.recover();need(self.state['pending']is None)
        if pending is not None:
            need(pending['kind']==kind and pending['role']==role);return self.state['records'][-1]
        operation_id=uuid.uuid4().hex
        self.state['pending']=dict(kind=kind,role=role,operationId=operation_id,file=None);self.save()
        args=dict(args,operationId=operation_id)
        operation={'cutoff':'arm','stop':'stop','os':'os','sdk':'sdk'}[kind]
        result=self.send(self.binding['sessionId'],'mobile: overteOriginalKeeperOperation',dict(operation='original-process-end-'+operation,args=args))
        self.transport();return self.adopt(result)

    def arm(self,roles=None):
        self.recover()
        if self.state['cutoff']is not None:return
        roles=[self.role]if roles is None else list(roles);need(set(roles)<=set(FAMILIES[self.profile_key])and self.role in roles)
        self.state['roles']=roles;self.save()
        base=self.runtime.adapter;installed=base._binding_store(self.selector).read()
        cleanup_record(self.state['installed'],installed);need(installed['phase']in ('bound','retiring'))
        # Original installed-code admission precedes the irreversible Stop.
        client,session,sdk,target,_scope=self.runtime._existing(self.selector)
        need(sdk==self.state['sdkState'])
        if installed['phase']=='bound':
            gate=base._binding(self.selector,client,session,sdk,target);gate.begin_retirement()
        test=self.target['testBuild']
        self.rpc('cutoff',dict(originalProcessEndVersion=1,stage=self.stage,binding=self.binding,runId=self.run,roles=roles,profileKey=self.profile_key,
            resultsDirectory=test['resultsDirectory'],origin=test['fixtureOrigin']))

    def share(self,other,kind):
        need(type(other)is IOSOriginalKeeperProcessEnd and other is not self and other.binding==self.binding and other.run==self.run
            and other.profile_key==self.profile_key and other.lock is self.lock and other.root!=self.root)
        other.bound();reference=other.state[kind];need(reference is not None and self.state[kind]is None and self.state['pending']is None)
        row=other.original(reference);frame=row['sourceFrame']['frame']
        self.state['roles']=deepcopy(other.state['roles']);self.state['pending']=dict(kind=kind,role=frame['role'],operationId=frame['operationId'],file=None);self.save()
        self.adopt(dict(iosOriginalKeeperEndReferenceVersion=1,profile=PROFILE,ownerInstance=row['sourceOwnerInstance'],binding=self.binding,
            runId=self.run,reference=row['sourceReference']))

    def validate_history(self):
        self.bound();need(self.state['pending']is None)
        owner=self.state['owner'];instance=None;previous=None;rows=[];seen=set()
        for ordinal,reference in enumerate(self.state['records'],1):
            need(reference['index']==ordinal);value=self.original(reference)
            if 'creatorRetirement'in value:
                exact(value,{'creatorRetirement'});need(reference==self.state['creator']);self.validate_creator(value['creatorRetirement']);continue
            if 'canonicalDeletion'in value:
                exact(value,{'canonicalDeletion'});need(ordinal==len(self.state['records'])and reference==self.state['deletion']);continue
            exact(value,{'sourceReference','sourceOwnerInstance','sourceFrame'});need(value['sourceOwnerInstance']==owner)
            body=value['sourceFrame'];row=body['frame'];original=row['original']
            need(row['operationId']not in seen);seen.add(identifier(row['operationId']))
            need(body['binding']==self.binding and body['runId']==self.run and body['role']=='primary')
            if row['kind']=='cutoff':
                need(ordinal==1 and self.state['cutoff']==reference)
                exact(original,{'iosOriginalKeeperCutoffVersion','source','binding','runId','ownerInstance','nativeFeatureInstance','reference','original'})
                need(type(original['iosOriginalKeeperCutoffVersion'])is int and original['iosOriginalKeeperCutoffVersion']==1 and original['source']==PROFILE)
                from ios.adapters.lifecycle_current_transport import frame_original
                current=original['original'];frame_original(current,self.binding,self.run,'primary',current['ticket'],owner)
                instance=identifier(original['nativeFeatureInstance']);need(instance==current['current']['clockJoin']['nativeAfter']['instance'])
            elif row['kind']=='stop':
                need(instance is not None and self.state['stop']==reference)
                exact(original,{'iosOriginalKeeperStopVersion','binding','runId','ownerInstance','processId','nativeFeatureInstance','before','after','anchor','killAwaitReturned'})
                need(type(original['iosOriginalKeeperStopVersion'])is int and original['iosOriginalKeeperStopVersion']==1
                    and type(original['processId'])is int and str(original['processId'])==self.binding['processIdentity']and original['killAwaitReturned']is True)
                os_original.clocks(original['before'],original['after'],30000);anchor=os_original.process(original['anchor'],owner)
                need(anchor['bundlePids']==[original['processId']]*2 and anchor['pidChecks']==[True,True])
            elif row['kind']=='os':
                need(reference in self.state['os']and row['role']==self.role and self.state['stop']is not None)
                os_original.os_row(original,binding=self.binding,run=self.run,role=self.role,owner=owner,instance=instance,previous=previous)
                previous=original;rows.append(original)
            elif row['kind']=='sdk':
                need(self.state['sdk']==reference);self.validate_sdk(original,owner,instance)
            else:need(False)
            need(original['binding']==self.binding and original['runId']==self.run and original['ownerInstance']==owner
                and original['nativeFeatureInstance']==instance)
        need(len(rows)==len(self.state['os']));return instance,rows

    @staticmethod
    def validate_sdk(value,owner,instance):
        exact(value,{'iosOriginalKeeperSDKCloseVersion','binding','runId','ownerInstance','source','nativeFeatureInstance','providers',
            'originalWdaTaskReturned','originalWatcherDone','originalRelayTasksDone','originalSDKTasksDone','originalHTTPThreads','originalAFCServices',
            'originalExecutorThreadsDone','originalThreadCensusOnlyControl','originalRemainingTaskCensusOnlyControlAndEnd','originalControlTasks','rsdWriterWaitClosedReturned','authenticationWriterWaitClosedReturned',
            'proxyWriterWaitClosedReturned','relayListenerClosed','originalRelayListenerWaitClosedReturned','originalListenerSocketFds','stackStopReturned','originalStreamSocketFds','tunSocketFds','sourceSlotCleared',
            'resourceRetirementEstablished','canonicalSessionDeleted'})
        need(type(value)is dict and type(value.get('iosOriginalKeeperSDKCloseVersion'))is int and value['iosOriginalKeeperSDKCloseVersion']==1
            and value['source']==PROFILE and value['ownerInstance']==owner and value['nativeFeatureInstance']==instance
            and value['resourceRetirementEstablished']is True and value['canonicalSessionDeleted']is False
            and type(value['originalListenerSocketFds'])is list and value['originalListenerSocketFds']
            and all(type(fd)is int and fd==-1 for fd in value['originalListenerSocketFds'])and value['tunSocketFds']==[-1,-1]and value['originalStreamSocketFds']==[-1,-1,-1]and type(value['providers'])is list and value['providers'])
        for key in ('originalWdaTaskReturned','originalWatcherDone','originalRelayTasksDone','originalSDKTasksDone',
            'originalExecutorThreadsDone','originalThreadCensusOnlyControl','originalRemainingTaskCensusOnlyControlAndEnd','rsdWriterWaitClosedReturned',
            'authenticationWriterWaitClosedReturned','proxyWriterWaitClosedReturned','relayListenerClosed','originalRelayListenerWaitClosedReturned','stackStopReturned','sourceSlotCleared'):
            need(value[key]is True)
        controls=value['originalControlTasks'];need(type(controls)is list and len(controls)==2)
        need({row.get('kind')for row in controls}=={'reading','stopping'})
        ids=[]
        for row in controls:
            exact(row,{'kind','id','originalCreatorRegistered','originalReceiverCodeBound','originalLoopBound','done'})
            ids.append(identifier(row['id']))
            need(all(row[key]is True for key in ('originalCreatorRegistered','originalReceiverCodeBound','originalLoopBound'))
                and type(row['done'])is bool)
        need(len(set(ids))==2)
        for row in value['originalHTTPThreads']:need(row==dict(finished=True,alive=False))
        for row in value['originalAFCServices']:
            need(row==dict(originalCloseReturned=True,originalTaskDone=True,serviceSlotCleared=True,readerSlotCleared=True,pending=0))
        identifiers=[]
        for row in value['providers']:
            exact(row,{'id','providerSlotCleared','originalDtxCloseAwaitReturned','originalReaderTaskDone','originalWriterWaitClosedReturned',
                'originalSocketFd','channels','services','pendingReplies','pendingOutgoingReplies'})
            identifiers.append(identifier(row['id']))
            need(all(row[key]is True for key in ('providerSlotCleared','originalDtxCloseAwaitReturned','originalReaderTaskDone','originalWriterWaitClosedReturned'))
                and type(row['originalSocketFd'])is int and row['originalSocketFd']==-1
                and all(type(row[key])is int and row[key]==0 for key in ('channels','services','pendingReplies','pendingOutgoingReplies')))
        need(len(set(identifiers))==len(identifiers))

    def validate_creator(self,value):
        exact(value,{'iosOriginalKeeperCreatorRetirementVersion','profile','source','ownerInstance','keeperProcessId','exitCode','signalCode',
            'originalCloseCode','originalCloseSignal','originalStdioClosed','intent','drainOriginal','replacementGrant'})
        need(type(value['iosOriginalKeeperCreatorRetirementVersion'])is int and value['iosOriginalKeeperCreatorRetirementVersion']==1
            and value['profile']==PROFILE and value['source']=='node-original-child-exit'and value['ownerInstance']==self.state['owner']
            and type(value['keeperProcessId'])is int and value['keeperProcessId']>0 and type(value['exitCode'])is int and value['exitCode']==0
            and value['signalCode']is None and type(value['originalCloseCode'])is int and value['originalCloseCode']==0
            and value['originalCloseSignal']is None and value['originalStdioClosed']==[True,True,True])
        identifier(value['replacementGrant']);intent=value['intent']
        exact(intent,{'iosOriginalKeeperCreatorExitIntentVersion','profile','profileKey','binding','runId','stage','ownerInstance','keeperProcessId',
            'sdkReference','nativeFeatureInstance','providerResourcesSha256'})
        need(type(intent['iosOriginalKeeperCreatorExitIntentVersion'])is int and intent['iosOriginalKeeperCreatorExitIntentVersion']==1
            and intent['profile']==PROFILE and intent['profileKey']==self.profile_key and intent['binding']==self.binding
            and intent['runId']==self.run and type(intent['stage'])is int and intent['stage']==self.stage
            and intent['ownerInstance']==self.state['owner']and type(intent['keeperProcessId'])is int and intent['keeperProcessId']==value['keeperProcessId'])
        sdk=self.original(self.state['sdk']);original=sdk['sourceFrame']['frame']['original']
        need(intent['sdkReference']==sdk['sourceReference']and intent['nativeFeatureInstance']==original['nativeFeatureInstance']
            and intent['providerResourcesSha256']==digest(original))
        drain=value['drainOriginal'];exact(drain,{'originalKeeperDrainVersion','ownerInstance','inputAdmissionClosed',
            'originalTouchWorkersSettled','originalOperationsSettled','nativeTouchSupport','resourceRetirementEstablished'})
        need(type(drain['originalKeeperDrainVersion'])is int and drain['originalKeeperDrainVersion']==1
            and drain['ownerInstance']==self.state['owner']and drain['inputAdmissionClosed']is True
            and drain['originalTouchWorkersSettled']is True and drain['originalOperationsSettled']is True
            and drain['nativeTouchSupport']is False and drain['resourceRetirementEstablished']is False)

    def adopt_creator(self,value):
        self.bound();pending=self.state['pending'];need(pending is not None and pending['kind']=='creator'and pending['file']is None)
        self.validate_creator(value)
        reference=self.files.write(len(self.state['records'])+1,dict(creatorRetirement=deepcopy(value)))
        self.state['records'].append(reference);self.state.update(creator=reference,pending=None,phase='creator-closed');self.save()

    def retire_creator(self):
        self.recover()
        if self.state['creator']is not None:return
        self.transport();need(self.state['sdk']is not None and self.state['pending']is None)
        sdk=self.original(self.state['sdk']);self.state['pending']=dict(kind='creator',role=None,operationId=uuid.uuid4().hex,file=None);self.save()
        result=self.send(self.binding['sessionId'],'mobile: overteOriginalKeeperOperation',dict(operation='original-process-end-creator-retire',
            args=dict(binding=self.binding,runId=self.run,stage=self.stage,sdkReference=sdk['sourceReference'])))
        self.transport();self.adopt_creator(result)

    def share_creator(self,other):
        self.bound();need(type(other)is IOSOriginalKeeperProcessEnd and other.binding==self.binding and other.run==self.run
            and other.stage==self.stage and other.profile_key==self.profile_key and other.lock is self.lock
            and self.state['creator']is None and self.state['sdk']is not None)
        other.bound();need(other.state['creator']is not None)
        self.state['pending']=dict(kind='creator',role=None,operationId=uuid.uuid4().hex,file=None);self.save()
        self.adopt_creator(other.original(other.state['creator'])['creatorRetirement'])

    def advance(self):
        self.recover();need(self.state['stop']is not None and self.state['sdk']is None and len(self.state['os'])<128)
        self.rpc('os',dict(role=self.role),role=self.role)
        _instance,rows=self.validate_history();return os_original.quiet(rows,owner=self.state['owner'],pid=self.binding['processIdentity'],complete=False)is not None

    def finish(self,*,peers=()):
        owners=(self,*peers);need(len({owner.role for owner in owners})==len(owners))
        for owner in owners:need(type(owner)is IOSOriginalKeeperProcessEnd and owner.binding==self.binding and owner.run==self.run and owner.lock is self.lock)
        if all(owner.state['phase']=='complete'for owner in owners):return self.retirement_original()
        roles=[owner.role for owner in owners];self.arm(roles)
        for owner in peers:
            if owner.state['cutoff']is None:owner.share(self,'cutoff')
        if self.state['stop']is None:self.rpc('stop',{})
        for owner in peers:
            if owner.state['stop']is None:owner.share(self,'stop')
        started=self.monotonic()
        while True:
            need(self.monotonic()-started<30);complete=True
            for owner in owners:
                if owner.state['sdk']is None:complete=owner.advance()and complete
            if complete:break
            self.sleep(.1)
        if self.state['sdk']is None:self.rpc('sdk',{})
        for owner in peers:
            if owner.state['sdk']is None:owner.share(self,'sdk')
        self.retire_creator()
        for owner in peers:
            if owner.state['creator']is None:owner.share_creator(self)
        deletion=self.delete_canonical()
        for owner in peers:
            owner.retain_deletion(deletion);owner.complete_canonical()
        return self.retirement_original()

    def retain_deletion(self,value):
        self.bound();need(self.state['sdk']is not None)
        if self.state['deletion']is not None:need(same(self.original(self.state['deletion'])['canonicalDeletion'],value));return
        # A canonical deletion is a genuine HTTP original shared by logical
        # roles. It is never reissued to manufacture an independent receipt.
        self.state['pending']=dict(kind='deletion',role=None,operationId=identifier(value['operationId']),file=None);self.save()
        reference=self.files.write(len(self.state['records'])+1,dict(canonicalDeletion=deepcopy(value)))
        self.state['records'].append(reference);self.state.update(deletion=reference,pending=None,phase='delete-observed');self.save()

    def delete_canonical(self):
        if self.state['deletion']is not None:
            self.complete_canonical();return deepcopy(self.original(self.state['deletion'])['canonicalDeletion'])
        self.transport();self.validate_history();need(self.state['sdk']is not None and self.state['creator']is not None)
        base=self.runtime.adapter;path='/session/'+self.binding['sessionId'];before=self.epoch_ms()
        sdk_store=PrivateFeatureState(self.runtime.state_path(self.selector));installed_store=base._binding_store(self.selector)
        need(sdk_store.read()in (None,self.state['sdkState']))
        installed=installed_store.read();need(installed is not None)
        cleanup_record(self.state['installed'],installed);need(installed['phase']=='retiring')
        # A lost DELETE return may recover only its observed canonical 404.
        try:self.http('GET',path)
        except backend.WebDriverRequestError as error:need(error.status==404 and self.state['deleteIssued'])
        else:
            need(not self.state['deleteIssued']);self.state['deleteIssued']=True;self.save()
            try:self.http('DELETE',path)
            except backend.WebDriverRequestError as error:need(error.status==404)
            try:self.http('GET',path)
            except backend.WebDriverRequestError as error:need(error.status==404)
            else:need(False)
        need(same(sdk_store.read(),self.state['sdkState'])and same(installed_store.read(),installed))
        value=dict(iosOriginalKeeperCanonicalDeletionVersion=1,operationId=uuid.uuid4().hex,binding=self.binding,runId=self.run,
            sessionId=self.binding['sessionId'],observedStatus=404,deleteIssued=True,hostBeforeEpochMs=before,hostAfterEpochMs=self.epoch_ms(),
            sdkState=deepcopy(self.state['sdkState']),installedBefore=deepcopy(self.state['installed']),installedAtDeletion=deepcopy(installed))
        # Retain all evidence BEFORE discarding only the two canonical states.
        self.retain_deletion(value)
        self.complete_canonical();return value

    def complete_canonical(self):
        self.bound();need(self.state['deletion']is not None)
        sdk_store=PrivateFeatureState(self.runtime.state_path(self.selector));installed_store=self.runtime.adapter._binding_store(self.selector)
        sdk=sdk_store.read();installed=installed_store.read()
        if sdk is not None:
            need(same(sdk,self.state['sdkState']));sdk_store.discard(sdk)
        if installed is not None:
            cleanup_record(self.state['installed'],installed);need(installed['phase']=='retiring');installed_store.discard(installed)
        need(sdk_store.read()is None and installed_store.read()is None)
        self.state['canonicalStateAbsence']=dict(sessionState=True,installedBinding=True)
        self.state['phase']='complete';self.save()

    def decode(self,value):
        exact(value,{'iosOriginalKeeperRetirementArchiveVersion','profile','profileKey','binding','runId','role','stage','artifactRoot','payload'})
        need(type(value['iosOriginalKeeperRetirementArchiveVersion'])is int and value['iosOriginalKeeperRetirementArchiveVersion']==1
            and value['profile']==PROFILE and value['profileKey']==self.profile_key and same(value['binding'],self.binding)
            and value['runId']==self.run and value['role']==self.role and type(value['stage'])is int and value['stage']==self.stage
            and value['artifactRoot']==str(self.root))
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0]
        exact(state,{'phase','records','pending','owner','roles','cutoff','stop','os','sdk','creator','deletion','sdkState','installed','sdkOrigin','deleteIssued','canonicalStateAbsence'})
        need(state['phase']in ('prepared','armed','stopped','observing','sdk-closed','creator-closed','delete-observed','complete')and type(state['records'])is list
            and len(state['records'])<=134 and type(state['os'])is list and len(state['os'])<=128 and type(state['deleteIssued'])is bool)
        return deepcopy(state)

    def process_original(self):
        # Typed evidence endpoint also usable before canonical deletion.
        instance,rows=self.validate_history();quiet=os_original.quiet(rows,owner=self.state['owner'],pid=self.binding['processIdentity'])
        return dict(binding=deepcopy(self.binding),runId=self.run,role=self.role,nativeFeatureInstance=instance,osAbsence=quiet)

    def retirement_original(self):
        return self.archived_original(self._summary(),store=self.store,root=self.root,binding=self.binding,run=self.run,
            role=self.role,stage=self.stage,profile_key=self.profile_key,lock=self.lock)

    def _summary(self):
        self.bound();need(self.state['phase']=='complete'and self.state['pending']is None)
        instance,rows=self.validate_history()
        need(self.state['canonicalStateAbsence']==dict(sessionState=True,installedBinding=True))
        deletion=self.original(self.state['deletion'])['canonicalDeletion']
        exact(deletion,{'iosOriginalKeeperCanonicalDeletionVersion','operationId','binding','runId','sessionId','observedStatus','deleteIssued',
            'hostBeforeEpochMs','hostAfterEpochMs','sdkState','installedBefore','installedAtDeletion'})
        need(type(deletion['iosOriginalKeeperCanonicalDeletionVersion'])is int and deletion['iosOriginalKeeperCanonicalDeletionVersion']==1)
        need(deletion['binding']==self.binding and deletion['runId']==self.run and deletion['sessionId']==self.binding['sessionId']
            and type(deletion['observedStatus'])is int and deletion['observedStatus']==404 and deletion['deleteIssued']is True
            and number(deletion['hostAfterEpochMs'],deletion['hostBeforeEpochMs'],1e15)
            and deletion['sdkState']==self.state['sdkState'])
        cleanup_record(deletion['installedBefore'],self.state['installed'])
        cleanup_record(self.state['installed'],deletion['installedAtDeletion'])
        cutoff=self.original(self.state['cutoff'])
        return dict(iosOriginalKeeperRetirementVersion=1,profile=PROFILE,profileKey=self.profile_key,binding=deepcopy(self.binding),
            runId=self.run,role=self.role,stage=self.stage,ownerInstance=self.state['owner'],nativeFeatureInstance=instance,
            processId=int(self.binding['processIdentity']),nativeCutoffReference=deepcopy(cutoff['sourceFrame']['frame']['original']['reference']),
            stopOriginalSha256=digest(self.original(self.state['stop'])['sourceFrame']['frame']['original']),
            osAbsence=os_original.quiet(rows,owner=self.state['owner'],pid=self.binding['processIdentity']),
            providerResourcesSha256=digest(self.original(self.state['sdk'])['sourceFrame']['frame']['original']),
            creatorRetirementOriginalSha256=digest(self.original(self.state['creator'])['creatorRetirement']),
            sdkDeletionOriginalSha256=digest(deletion),archiveSha256=digest(self.previous),archive=deepcopy(self.previous),resourceRetirementEstablished=True)

    @classmethod
    def archived_original(cls,value,*,store,root,binding,run,role,stage,profile_key,lock):
        need(type(store)is PrivateFeatureState and isinstance(lock,ScriptSourceLock));lock.assert_held()
        need(store.path.name==filename(profile_key,role,stage)and lock.path==store.path.with_name('script-feature-sources.lock'))
        scope=object.__new__(cls);scope.store,scope.root,scope.lock=store,Path(root),lock
        scope.binding,scope.run,scope.role=deepcopy(context(binding)),identifier(run),role
        scope.stage,scope.profile_key,scope.profile=stage,profile_key,PROFILE
        scope.previous=store.read();need(scope.previous is not None and value['archive']==scope.previous and digest(scope.previous)==value['archiveSha256'])
        scope.state=scope.decode(scope.previous)
        scope.files=OriginalFrameStore(scope.root,scope.binding,scope.run,scope.role,scope.bound,lambda *_:need(False),
            namespace=('original-process-end'if stage==0 else 'original-process-end-replacement'),schema_prefix='iosOriginalProcessEnd')
        expected=scope._summary();need(same(value,expected));return deepcopy(expected)

    def owned_paths(self):
        self.bound();paths={self.store.path}
        paths.update(self.files.path(self.files.expand(reference))for reference in self.state['records'])
        pending=self.state['pending']
        if pending is not None and pending['file']is not None and pending['file']['phase']!='planned':paths.add(self.files.path(pending['file']))
        return paths
