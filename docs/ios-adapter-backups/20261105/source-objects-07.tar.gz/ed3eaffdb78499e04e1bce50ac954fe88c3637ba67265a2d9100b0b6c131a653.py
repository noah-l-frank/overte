"""External cProfile observer around byte-identical65d00 passive probe.

No reader/guard/parser/callback is replaced. Literal probe mode fields remain
false in its own output; this wrapper's mode is authoritative for profiling.
"""
import cProfile
import json
import os
from pathlib import Path
import pstats
import runpy
import sys
import time
from types import CodeType

HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
assert len(sys.argv)==2
OUTPUT=Path(sys.argv[1]).resolve(strict=True)
assert OUTPUT.parent==HERE and OUTPUT.name.startswith('first-')
assert not any(name.split('.',1)[0] in ('ios','adapters','feature_journeys','pymobiledevice3') for name in sys.modules)
profiler=cProfile.Profile();started=time.monotonic();cut=None

def save(name,value):
    with (OUTPUT/name).open('w') as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())

sys.argv=[str(HERE/'probe.py'),str(OUTPUT)]
try:
    profiler.enable()
    runpy.run_path(str(HERE/'probe.py'),run_name='__main__')
finally:
    profiler.disable()
    # Exactly self-produced in-process stats, never a read of external pickle.
    profiler.dump_stats(str(OUTPUT/'raw.pstats'))
    qualified={}
    for entry in profiler.getstats():
        code=entry.code
        if type(code) is CodeType:qualified[(code.co_filename,code.co_firstlineno,code.co_name)]=code.co_qualname
    stats=pstats.Stats(profiler);rows=[]
    def label(key):
        filename,line,name=key
        path=Path(filename)
        if not path.is_absolute() or not path.is_relative_to(REPO/'tests/device'):return None
        return dict(module=str(path.relative_to(REPO)),line=line,qualifiedName=qualified.get(key,name))
    for key,(primitive,calls,self_time,cumulative,callers) in stats.stats.items():
        source=label(key)
        if source is None:continue
        caller_rows=[]
        for caller,cost in callers.items():
            owner=label(caller)
            if owner is None:continue
            caller_rows.append(dict(**owner,cost=list(cost) if type(cost) is tuple else cost))
        caller_rows.sort(key=lambda row:row['cost'][3] if type(row['cost']) is list and len(row['cost'])>3 else 0,reverse=True)
        rows.append(dict(**source,primitiveCalls=primitive,calls=calls,selfSeconds=self_time,cumulativeSeconds=cumulative,callers=caller_rows[:8]))
    save('profile-summary.json',dict(status='ACTUAL_EXTERNAL_CPROFILE_METADATA_ONLY',
        totalProfileSeconds=stats.total_tt,profiledLocalFunctions=len(rows),
        topSelf=sorted(rows,key=lambda row:row['selfSeconds'],reverse=True)[:20],
        topCumulative=sorted(rows,key=lambda row:row['cumulativeSeconds'],reverse=True)[:20],
        acceptanceAuthority=False,performanceQualified=False,old214CauseKnown=False))
    save('external-cprofile-mode.json',dict(enabled=True,traceEnabled=False,
        originalProbeSha256='65d00dcd4386a3c8f3b137a7617e556487e57e043ddfb0ea2569c74e89278535',
        originalBodyUnchanged=True,originalProbeLiteralModeFields=False,
        note='Original probe reports its literal internal profiling flag false; this wrapper genuinely profiled all of it externally.',
        elapsedSeconds=time.monotonic()-started,performanceQualified=False,acceptanceAuthority=False))
