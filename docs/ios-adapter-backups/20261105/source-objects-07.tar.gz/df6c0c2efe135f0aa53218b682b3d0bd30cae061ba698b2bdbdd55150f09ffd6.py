"""Physical/cache policy counterexamples; no native/feature success is modeled."""
import hashlib,tempfile,unittest,os
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.original_file_reads import record,scope
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters import emote_rooted_live as rooted
from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
from ios.adapters.emote_callback_live_records import CallbackLiveRecords
from ios.adapters import emote_callback_live_records as record_policy
from ios.adapters.emote_archive_round import validation_batch


class CallbackLivePolicySmokeTests(unittest.TestCase):
    def test_actual_reviewed_parser_policy_supports_literal_admission_before_graph_work(self):
        history=CallbackLiveRecords()
        self.assertTrue(history.literal(),repr(history.unsupported))
        self.assertEqual({},history.cache.rows)


class CallbackLiveHistoricalRowsTests(unittest.TestCase):
    def setUp(self):
        self.stack=ExitStack();self.addCleanup(self.stack.close)
        self.temporary=self.stack.enter_context(tempfile.TemporaryDirectory())
        self.root=Path(self.temporary);self.root.chmod(0o700)
        self.lock=ScriptSourceLock(self.root/'script-feature-sources.lock');self.stack.enter_context(self.lock.held())
        self.file=self.root/'actual-historical-input.json';self.file.write_bytes(b'{"historical":"one"}');self.file.chmod(0o600)
        self.reference=dict(index=1,sha256=hashlib.sha256(self.file.read_bytes()).hexdigest())
        self.history=CallbackLiveRecords();self.assertTrue(self.history.literal(),repr(self.history.unsupported));self.calls=0
        self.owner=self.owner_shell()
    def owner_shell(self):
        # Explicit cache/controller MODEL. This is not a native record or
        # claimed feature measurement; actual cache, locks/files/censuses run.
        owner=object.__new__(IOSEmoteCallbackLive);owner._historical_rows=self.history
        owner.root=self.root;owner.run='a'*32;owner.role='primary';owner.lock=owner.primary_lock=self.lock
        owner.binding=dict(sourceRevision='a'*40,artifactSha256='b'*64,sessionId='cache-model',generation=1,targetFingerprint='c'*64,processIdentity='42')
        owner.primary_binding=dict(owner.binding);owner.fixture_url='http://127.0.0.1';owner.phase_instance='d'*32
        owner.policy=dict(source='world-render-target');owner.store=PrivateFeatureState(self.root/'model-live.json')
        owner.originals=OriginalFrameStore(self.root,owner.binding,owner.run,owner.role,owner.file_guard,lambda *_:False,
            namespace='emote-rooted-live',schema_prefix='iosEmoteRootedLive',kind='inputs')
        return owner
    def decode_model(self):
        self.calls+=1;rooted.sha(self.reference['sha256'])
        if rooted.LIMIT!=96:raise NativeUIError('Declared policy change reached literal decoder')
        record(self.file);raw=self.file.read_bytes()
        return dict(reference=dict(self.reference),mechanismOnlyOriginalBytes=raw.decode('ascii'))
    def read(self,owner=None):return self.history.read(self.owner if owner is None else owner,self.reference,self.decode_model)
    def test_cold_twice_then_reconstructed_owner_warm_keeps_original_bytes_and_actual_read_membership(self):
        with scope(fresh=True) as first:original=self.read()
        self.assertEqual(2,self.calls);self.assertEqual({self.file},first)
        before=self.history.cache.signatures({self.file});other=self.owner_shell()
        with scope(fresh=True) as second:again=self.read(other)
        self.assertEqual(original,again);self.assertEqual(2,self.calls);self.assertEqual(first,second)
        self.assertEqual(before,self.history.cache.signatures({self.file}))
    def test_samebyte_inode_replacement_cannot_reuse_previous_original(self):
        self.read();before=self.file.stat().st_ino;other=self.root/'declared-samebyte-replacement.json'
        other.write_bytes(self.file.read_bytes());other.chmod(0o600);os.replace(other,self.file)
        self.assertNotEqual(before,self.file.stat().st_ino)
        with self.assertRaises(NativeUIError):self.read()
        self.assertEqual(2,self.calls)
    def test_changed_original_body_cannot_reuse_previous_original(self):
        self.read();self.file.write_bytes(b'{"historical":"changed"}')
        with self.assertRaises(NativeUIError):self.read()
        self.assertEqual(2,self.calls)
    def test_replaced_parser_function_forces_actual_literal_refusal(self):
        self.read()
        def refuse(value):raise NativeUIError('Declared changed parser')
        with patch.object(rooted,'sha',refuse),self.assertRaisesRegex(NativeUIError,'Declared changed parser'):self.read()
        self.assertEqual(3,self.calls)
    def test_replaced_parser_code_forces_actual_literal_refusal(self):
        self.read();before=rooted.sha.__code__
        self.assertTrue(any(value is before for value in self.history.references))
        def refuse(value):raise RuntimeError('Declared changed parser code')
        rooted.sha.__code__=refuse.__code__
        try:
            with self.assertRaisesRegex(RuntimeError,'Declared changed parser code'):self.read()
        finally:rooted.sha.__code__=before
        self.assertEqual(3,self.calls)
    def test_changed_policy_constant_forces_actual_literal_refusal(self):
        self.read()
        with patch.object(rooted,'LIMIT',97),self.assertRaisesRegex(NativeUIError,'Declared policy change'):self.read()
        self.assertEqual(3,self.calls)
    def test_complete_outer_immutable_inventory_rejects_inserted_orphan_during_historical_read(self):
        self.read()
        with self.assertRaises(NativeUIError):
            with validation_batch(dict(artifactRoot=str(self.root),stateRoot=str(self.root)),lock=self.lock,primary_lock=self.lock):
                orphan=self.root/'emote-rooted-live-frame-inputs-declared-orphan.json';orphan.write_text('{}');orphan.chmod(0o600)
                self.read()
    def test_changed_actual_owner_context_cannot_borrow_cached_role(self):
        self.read();other=self.owner_shell();other.role='actor'
        self.read(other);self.assertEqual(4,self.calls);self.assertEqual(2,len(self.history.cache.rows))
    def test_unsupported_parser_namespace_value_uses_literal_decoder_instead_of_cached_success(self):
        self.read()
        with patch.object(rooted,'declared_unsupported_policy',object(),create=True):self.read()
        self.assertEqual(3,self.calls)

    def test_changed_own_helper_policy_constant_forces_literal_decoder(self):
        self.read()
        with patch.object(record_policy,'PARSER_MODULES',record_policy.PARSER_MODULES+('declared-different-policy',)):
            self.assertFalse(self.history.literal());self.read()
        self.assertEqual(3,self.calls)
    def test_changed_own_helper_parser_code_forces_literal_decoder(self):
        self.read();before=record_policy._token.__code__
        self.assertTrue(any(value is before for value in self.history.references))
        def refuse(value,refs,active,depth=0):raise _Unsupported
        record_policy._token.__code__=refuse.__code__
        try:
            self.assertFalse(self.history.literal());self.read()
        finally:record_policy._token.__code__=before
        self.assertEqual(3,self.calls)
