"""Fresh original child native cut; no Input/Down gate or qualification."""
import asyncio,json,hashlib,os
from copy import deepcopy
import test_motion_selected_join_models as join_fixture


class NativeCurrentBeforeDownModels(join_fixture.MotionSelectedJoinModels):
    async def setup_prepared(self):
        await self.select_original();packet,_=await self.capture_selected();self.assertEqual('complete',packet['status']);await self.prepared(packet['result']);return self.ops.touch_resources
    async def current(self,resource):
        with resource.lock.held():return await resource.native_before_down()
    async def close_current_tasks(self):
        self.window_gate.set()
        for task in self.source._native_current_tasks:
            try:await asyncio.shield(task)
            except BaseException:pass
    async def asyncSetUp(self):
        await super().asyncSetUp();self.addAsyncCleanup(self.close_current_tasks)

    async def test_genuinely_new_native_cut_after_old_preparation_expires_preserves_old_intent_and_uses_new_originals(self):
        resource=await self.setup_prepared();old=deepcopy(resource.previous);old_ref=resource._motion_original;old_bytes=self.frame_path(old_ref.reference).read_bytes();await asyncio.sleep(1.55)
        self.assertGreater(asyncio.get_running_loop().time(),old_ref._deadline)
        receipt=await self.current(resource);self.assertIsNot(receipt,old_ref);self.assertEqual(old,resource.previous);self.assertEqual(old_bytes,self.frame_path(old_ref.reference).read_bytes())
        with resource.lock.held():frame=receipt.original(self.source,resource,self.ops.instance)
        self.assertGreater(frame['clockJoin']['hostBeforeMonotonic'],old['state']['frame']['clockJoin']['hostAfterMonotonic']);self.assertEqual([],self.f.states());self.assertEqual([],self.source._born)
        self.assertTrue(receipt._capture().done());self.assertIn(receipt._capture(),self.source._native_current_tasks);self.assertFalse(self.creator.done())

    async def test_new_current_receipt_cannot_be_reused_after_its_own_original_1_5_interval(self):
        resource=await self.setup_prepared();receipt=await self.current(resource);before=self.frame_path(receipt.reference).read_bytes();await asyncio.sleep(1.55)
        with resource.lock.held(),self.assertRaises((RuntimeError,ValueError)):receipt.original(self.source,resource,self.ops.instance)
        self.assertEqual(before,self.frame_path(receipt.reference).read_bytes());self.assertTrue(self.selected[3]['revoked']);self.assertEqual([],self.f.states())

    async def test_actual_current_wda_origin_change_refuses_same_viewport_and_source_before_any_input(self):
        resource=await self.setup_prepared();self.sdk_rect['x']+=3
        with self.assertRaises((RuntimeError,ValueError)):await self.current(resource)
        self.assertTrue(resource._motion_failed);self.assertTrue(self.selected[3]['revoked']);self.assertEqual([],self.f.states());self.assertTrue(all(row.done() for row in self.source._native_current_tasks))

    async def test_current_native_world_displacement_refuses_unchanged_requested_path_without_input(self):
        resource=await self.setup_prepared()
        # Existing actual MODEL avatar state changes BEFORE the next native
        # producer acquisition; old retained fields/coordinates remain intact.
        self.world_source.position[0]+=.1
        with self.assertRaises((RuntimeError,ValueError)):await self.current(resource)
        self.assertTrue(resource._motion_failed);self.assertEqual([],self.f.states())

    async def test_unknown_original_window_return_keeps_actual_task_and_fd_under_source_drain(self):
        resource=await self.setup_prepared();self.window_entered.clear();self.window_closed.clear();self.window_gate.clear()
        caller=asyncio.create_task(self.current(resource));self.controls_motion.append(caller);await self.window_entered.wait()
        task=self.source._native_current_tasks[-1]
        try:
            with self.assertRaises((RuntimeError,ValueError)):await caller
            self.assertFalse(task.done());self.assertFalse(task.cancelled());self.assertFalse(self.window_closed.is_set());self.assertTrue(any(fd.fileno()!=-1 for fd in self.window_sockets))
            drain=asyncio.create_task(self.source.settle_touches());self.controls_motion.append(drain);await asyncio.sleep(.02);self.assertFalse(drain.done());self.assertFalse(self.creator.done())
        finally:self.window_gate.set()
        try:await task
        except (RuntimeError,ValueError):pass
        await drain;self.assertTrue(self.window_closed.is_set());self.assertTrue(all(fd.fileno()==-1 for fd in self.window_sockets));self.assertEqual([],self.f.states())

    async def test_cancelled_actor_keeps_original_capture_task_until_sdk_return_without_accepting_old_frame(self):
        resource=await self.setup_prepared();self.window_entered.clear();self.window_closed.clear();self.window_gate.clear()
        caller=asyncio.create_task(self.current(resource));self.controls_motion.append(caller);await self.window_entered.wait();task=self.source._native_current_tasks[-1]
        caller.cancel()
        try:
            with self.assertRaises(asyncio.CancelledError):await caller
            self.assertFalse(task.done());self.assertFalse(task.cancelled());self.assertFalse(self.window_closed.is_set());self.assertEqual([],self.f.states())
        finally:self.window_gate.set()
        try:await task
        except (RuntimeError,ValueError):pass
        self.assertTrue(task.done());self.assertTrue(resource._motion_failed);self.assertEqual([],self.f.states())

    async def test_original_frame_inode_replacement_refuses_before_issuing_any_new_current_queries(self):
        resource=await self.setup_prepared();path=self.frame_path(resource._motion_original.reference);replacement=path.with_name('same-byte-current-anchor');replacement.write_bytes(path.read_bytes());replacement.chmod(0o600);os.replace(replacement,path);before=len(self.commands)
        with self.assertRaises((RuntimeError,ValueError)):await self.current(resource)
        self.assertEqual(before,len(self.commands));self.assertEqual([],self.source._native_current_tasks);self.assertEqual([],self.f.states())

    async def test_fresh_current_object_does_not_open_resource_make_lease_or_replace_missing_born_worker_admission(self):
        from adapters.normal_feature_state import PrivateFeatureState
        resource=await self.setup_prepared();receipt=await self.current(resource);self.assertTrue(receipt._capture().done())
        store=PrivateFeatureState(self.resource_path().with_name('ios-lifecycle-touch-lease-'+self.run+'.json'))
        with self.assertRaises((RuntimeError,ValueError)):
            self.source.touch_lease(store,binding=self.binding,run=self.run,check=lambda:self.ops.fresh_touch_scope(self.binding),resource_owner=resource)
        self.assertIsNone(store.read());self.assertEqual([],self.f.states());self.assertEqual([],self.source._born);self.assertEqual([],self.source._leases)

    async def test_real_resource_pointer_without_original_registered_current_task_cannot_mint_current_capture(self):
        resource=await self.setup_prepared();before=len(self.commands);args=dict(self.acquire_args(),selectedQueryId=self.selection)
        with resource.lock.held(),self.assertRaises((RuntimeError,ValueError)):
            await self.ops.native_acquire(args,self.binding['sessionId'],_motion_window=True,_current_resource=resource)
        self.assertEqual(before,len(self.commands));self.assertEqual([],self.source._native_current_tasks);self.assertEqual([],self.f.states())
