// Copyright 2026 Overte contributors.
// SPDX-License-Identifier: Apache-2.0
// Private SOURCE-ONLY native counter. Not wired into a product build.
// The additional dedicated flag is OFF by default; no installed/native/peer verdict.
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS) && defined(OVERTE_E2E_RECEIVED_MANAGER_COUNTER)
#include <AudioConstants.h>
#include <MixedProcessedAudioStream.h>
#include <ReceivedMixerCapture.h>
#include <ReceivedMessage.h>
#include <NLPacket.h>
#include <udt/Socket.h>
#include <QCoreApplication>
#include <QEventLoop>
#include <QTimer>
#include <QRandomGenerator>
#include <QUuid>
#include <QJsonDocument>
#include <QCryptographicHash>
#include <memory>
#include <stdexcept>
#include "IOSAudioPassiveCapture.h"

namespace overte::e2e::counter {
static void require(bool value) { if (!value) { throw std::runtime_error("Actual received-manager lower boundary unavailable"); } }
static QString freshId() { return QUuid::createUuid().toString(QUuid::WithoutBraces).remove('-'); }

// Caller must predeclare the actual private retained root in its own resource
// harness. Returned originals are actual newly created manager bytes. This is
// the real lower C++ manager/capture variant, not production AudioClient/SDK.
QVariantMap receivedMixerManagerOriginalBoundary(const QString& nativeRoot) {
    require(QCoreApplication::instance() && QCoreApplication::arguments().contains("--testScript"));
    QVariantMap result; QVariantList receivedRaw; QByteArray intent, original, wav;
    {
        const QString instance = freshId(), run = freshId(), lease = freshId(), startId = "ios-" + freshId();
        // Independent NEW transport input exists before Start. Never a saved
        // original, expected acoustic tone or desired returned sample buffer.
        QVector<QByteArray> inputs;
        for (quint16 index = 0; index < 64; ++index) {
            QByteArray bytes(960, Qt::Uninitialized);
            for (int i = 0; i < bytes.size(); ++i) { bytes[i] = static_cast<char>(QRandomGenerator::global()->generate() & 255); }
            inputs.push_back(bytes);
        }
        MixedProcessedAudioStream stream(100, 1); stream.outputFormatChanged(24000, 2);
        QObject output; ReceivedMixerCapture capture;
        auto admission = std::make_shared<RecordedPreviewAdmission>(instance); admission->advance(true);
        std::unique_ptr<QTimer> watchdog;
        const auto current = [&] { return RecordedPreviewAdmission::available(admission->state()) && stream.e2eDecoderLifetime() != 0; };
        const auto observer = QObject::connect(&stream, &MixedProcessedAudioStream::receivedMixerDecodedOriginal, &output,
            [&](ReceivedMixerDecodedOriginal* ticket) { capture.append(ticket); }, Qt::DirectConnection);
        const auto invalidation = QObject::connect(&stream, &InboundAudioStream::e2eReceivedDecoderLifetimeChanged, &output,
            [&] { capture.invalidateOwned(); }, Qt::DirectConnection);
        IOSAudioPassiveCapture manager(instance, IOSAudioPassiveCapture::Family::ReceivedMixer);
        IOSAudioPassiveCapture::Audio backend {
            [&](const QString& r, const QString& l, int seconds) {
                if (watchdog || !current() || !capture.start(r, l, seconds, admission, &stream, &output)) { return false; }
                const auto generation = capture.generation(); watchdog = std::make_unique<QTimer>(); watchdog->setSingleShot(true);
                QObject::connect(watchdog.get(), &QTimer::timeout, &output, [&, generation] { stream.observeReceivedMixerOriginals(false); capture.stop(generation); });
                watchdog->start(seconds * 1000); stream.observeReceivedMixerOriginals(true); return true;
            },
            [&] { auto value = capture.snapshot(current()); value["watchdogOwned"] = watchdog != nullptr; value["watchdogActive"] = watchdog && watchdog->isActive(); return value; },
            [&] { return capture.wav(current()); },
            [&](const QString& r, const QString& l, quint64 generation) {
                if (!capture.release(r, l, generation)) { return false; }
                stream.observeReceivedMixerOriginals(false);
                if (watchdog) { watchdog->stop(); watchdog.reset(); } return true;
            }, current
        };
        const auto query = [&](const QString& operation, QVariantMap fields = QVariantMap()) {
            QVariantMap value {{"schemaVersion", 1}, {"commandId", operation == "start" ? startId : "ios-" + freshId()},
                {"action", "feature-ios-audio-received-mixer"}, {"operation", operation}, {"instance", instance},
                {"runId", run}, {"role", "actor"}, {"leaseId", lease}, {"startCommandId", startId}};
            for (auto it = fields.cbegin(); it != fields.cend(); ++it) { value.insert(it.key(), it.value()); }
            return manager.request(nativeRoot, value, backend);
        };
        const auto started = query("start", {{"seconds", 6}}); require(!started.isEmpty());
        udt::Socket sender, receiver;
        sender.bind(SocketType::UDP, QHostAddress(QHostAddress::LocalHost), 0);
        receiver.bind(SocketType::UDP, QHostAddress(QHostAddress::LocalHost), 0);
        require(sender.localPort(SocketType::UDP) && receiver.localPort(SocketType::UDP));
        const SockAddr senderEndpoint(SocketType::UDP, QHostAddress(QHostAddress::LocalHost), sender.localPort(SocketType::UDP));
        const SockAddr receiverEndpoint(SocketType::UDP, QHostAddress(QHostAddress::LocalHost), receiver.localPort(SocketType::UDP));
        QEventLoop loop; QTimer deadline; deadline.setSingleShot(true); bool expired = false, failed = false;
        QObject::connect(&deadline, &QTimer::timeout, &output, [&] { expired = true; loop.quit(); });
        receiver.setPacketFilterOperator([&](const udt::Packet& packet) { return packet.getSenderSockAddr() == senderEndpoint; });
        receiver.setPacketHandler([&](std::unique_ptr<udt::Packet> packet) {
            try {
                require(packet && packet->getSenderSockAddr() == senderEndpoint && receivedRaw.size() < 64);
                // Actual Socket receiveTime only. Packet move/copyMembers
                // preserves it. No setter/byte-array-zero message is used.
                auto nl = NLPacket::fromBase(std::move(packet)); require(nl && nl->getType() == PacketType::MixedAudio);
                ReceivedMessage message(*nl); require(message.getFirstPacketReceiveTime() > 0 && message.isComplete());
                receivedRaw.push_back(message.getMessage().toBase64()); stream.parseData(message);
                if (receivedRaw.size() == 64) { loop.quit(); }
            } catch (...) { failed = true; loop.quit(); }
        });
        // Actual ordinary transport constructor/writer: the input is not the
        // manager's returned effect. Returned PCM is checked through originals.
        QTimer::singleShot(0, &output, [&] {
            try {
                for (int index = 0; index < inputs.size(); ++index) {
                    auto packet = NLPacket::create(PacketType::MixedAudio); packet->writeSourceID(7);
                    const quint16 sequence = static_cast<quint16>(index + 1);
                    require(packet->write(reinterpret_cast<const char*>(&sequence), sizeof(sequence)) == sizeof(sequence));
                    require(packet->writeString("pcm") > 0); require(packet->write(inputs[index]) == inputs[index].size());
                    require(sender.writePacket(*packet, receiverEndpoint) > 0);
                }
            } catch (...) { failed = true; loop.quit(); }
        });
        deadline.start(5000); loop.exec(); deadline.stop(); require(!expired && !failed && receivedRaw.size() == 64);
        const auto captured = query("capture"); require(!captured.isEmpty());
        const auto files = captured.value("source").toMap().value("files").toList(); require(files.size() == 3);
        const auto download = [&](const QString& kind) {
            QVariantMap descriptor;
            for (const auto& value : files) { if (value.toMap().value("kind").toString() == kind) { descriptor = value.toMap(); } }
            require(descriptor.value("exists").toBool() && descriptor.value("complete").toBool());
            const int size = descriptor.value("bytes").toInt(); require(size > 0 && size <= 512 * 1024); QByteArray bytes;
            while (bytes.size() < size) {
                const auto chunk = query("read", {{"kind", kind}, {"offset", bytes.size()}, {"bytes", qMin<int>(4096, size - static_cast<int>(bytes.size()))}});
                const auto source = chunk.value("source").toMap(); require(source.value("original").toMap() == descriptor);
                const auto part = QByteArray::fromBase64(source.value("base64").toByteArray()); require(!part.isEmpty()); bytes.append(part);
            }
            require(bytes.size() == size && QString::fromLatin1(QCryptographicHash::hash(bytes, QCryptographicHash::Sha256).toHex()) == descriptor.value("sha256").toString()); return bytes;
        };
        intent = download("intent"); original = download("capture"); wav = download("wav");
        QByteArray inputPCM; for (const auto& bytes : inputs) { inputPCM.append(bytes); }
        require(wav.size() == 44 + inputPCM.size() && wav.mid(44) == inputPCM);
        const auto release = query("release"); require(!release.isEmpty());
        const auto after = query("files"); const auto state = after.value("source").toMap();
        require(state.value("retired").toBool() && state.value("openOriginalFds").toInt() == 0 && state.value("originalBytes").toLongLong() == 0);
        require(!state.value("state").toMap().value("owned").toBool() && !watchdog);
        for (const auto& file : state.value("files").toList()) { require(!file.toMap().value("exists").toBool()); }
        stream.observeReceivedMixerOriginals(false); QObject::disconnect(observer); QObject::disconnect(invalidation);
        receiver.setPacketHandler({}); receiver.setPacketFilterOperator({}); sender.clearConnections(); receiver.clearConnections();
        result = {{"lowerManagerOriginalsAvailable", true}, {"instance", instance}, {"runId", run}, {"leaseId", lease},
            {"actualProcessId", QCoreApplication::applicationPid()}, {"actualNewReceivedMessages", receivedRaw},
            {"intentBase64", intent.toBase64()}, {"captureBase64", original.toBase64()}, {"wavBase64", wav.toBase64()},
            {"backendVariant", "genuine-stream-capture-manager-with-owned-UDT-fixture-not-AudioClient"}};
    } // Actual local socket/Qt/timer/capture objects destruct BEFORE returning.
    result["externalResourceHarnessRequired"] = true; result["nativeQualified"] = false;
    result["individualPeerQualified"] = false; result["acousticQualified"] = false; result["wholeQualified"] = false;
    return result;
}
} // namespace overte::e2e::counter
#endif
