"""Prepared exact4 host suite. UNRUN until explicit Root publication/run grant."""
from pathlib import Path
import hashlib,json,sys,tempfile,types,unittest

ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PLAN=json.loads((OUT/'selected-four-plan.json').read_text())
def need(condition,message):
    if not condition:raise AssertionError(message)
need(str(ROOT)==PLAN['worktree'],'Unexpected worktree')
need(hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==PLAN['runnerSha256'],'Changed reviewed launcher')
pins_path=OUT/'required-source-pins.json'
need(hashlib.sha256(pins_path.read_bytes()).hexdigest()==PLAN['sourcePinsSha256'],'Changed source pin manifest')
SOURCES=json.loads(pins_path.read_text())['sources']
PACKAGE=Path(PLAN['frozenPackage'])
for name,expected in PLAN['frozenPackageFiles'].items():
    need(hashlib.sha256((PACKAGE/name).read_bytes()).hexdigest()==expected,'Changed frozen package: '+name)

def unchanged_sources():
    for name,expected in SOURCES.items():
        need(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected,'Changed source before/after imports: '+name)

# Every reviewed dependency/native/JS input is checked BEFORE test/fixture imports.
unchanged_sources()
RUN=OUT/'run-01';RUN.mkdir(mode=0o700)
sys.path.insert(0,str(ROOT/'tests/device'))
from ios.self_tests import test_ios_emote_marker_scope as marker_fixture
from ios.self_tests import test_ios_installed_code as installed_fixture
from self_tests import test_account_provider as tls_fixture
from ios.self_tests.retained_host_roots import retain_owned_root

REAL_TD=tempfile.TemporaryDirectory;roots=[];directories=[];result=None
aliases=[(marker_fixture,marker_fixture.tempfile),(installed_fixture,installed_fixture.tempfile),
    (tls_fixture,tls_fixture.tempfile)]

def persist_roots():
    (RUN/'retained-original-roots.json').write_text(json.dumps(dict(retainedOriginalRoots=roots),indent=2)+'\n')

def retained_temporary_directory(*args,**kwargs):
    directory=REAL_TD(*args,**kwargs)
    # Retain BEFORE fixture.addCleanup(directory.cleanup) captures its bound
    # method. Keeping only a later helper call would leave an old rmtree call.
    root=retain_owned_root(directory,expected_root=Path(directory.name))
    directories.append(directory);roots.append(str(root));persist_roots()
    print('Retained Avatar preparation original root: '+str(root),flush=True)
    return directory

try:
    for module,_original in aliases:
        module.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_temporary_directory)
    need(tempfile.TemporaryDirectory is REAL_TD,'Global tempfile type changed')
    ids=PLAN['caseIds'];need(len(ids)==len(set(ids))==4,'Expected exactly four distinct cases')
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    need(not loader.errors and suite.countTestCases()==4,'Unexpected testcase loading: '+repr(loader.errors))
    def case_ids(group):
        for item in group:
            if isinstance(item,unittest.TestSuite):yield from case_ids(item)
            else:yield item.id()
    need(list(case_ids(suite))==ids,'Imported duplicate or different case IDs')
    unchanged_sources()
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    need(result.testsRun==4 and not result.skipped,'Not all four actual cases executed')
finally:
    for module,original in aliases:module.tempfile=original
    need(tempfile.TemporaryDirectory is REAL_TD,'Global tempfile type was replaced')
    for directory in directories:
        need(isinstance(directory,REAL_TD),'A retained root lost its real TemporaryDirectory owner')
        retain_owned_root(directory,expected_root=Path(directory.name))
    persist_roots();unchanged_sources()
    summary=dict(testsRun=None if result is None else result.testsRun,
        successful=False if result is None else result.wasSuccessful(),retainedOriginalRoots=roots,
        realTemporaryDirectoryTypePreserved=True,sourcePathsChecked=len(SOURCES),
        nativeEffectOnly=True,sdkReturnRecovered=False,inputOrWorkerRetired=False,
        osProcessSdkEndQualified=False,wholeFeatureQualified=False)
    (RUN/'selected-result.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary),flush=True)

if result is not None and result.wasSuccessful():
    need(len(roots)==len(set(roots))==17,'Expected one TLS plus four pairs of Scene/Installed roots')
sys.exit(0 if result is not None and result.wasSuccessful() else 1)
