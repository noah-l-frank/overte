"""Explicit ordinary Actor SDK-source route for received-mixer ownership.

Reuses the existing source/parent/lock/birth architecture. The distinct saved
family stays discoverable as an Audio SDK duty. The existing original End
architecture is selected by exact ledger type; unavailable external proofs and
unknown microphone/cache/Whole inventories remain fail-closed.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
import time
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.phase_fixture import PhaseFixtureReader
from ios.adapters.audio_passive_runtime import PassiveSDKLedger,IOSAudioPassiveRuntime
from ios.adapters.audio_received_mixer_owner import IOSAudioReceivedMixerOwner
from ios.adapters.audio_received_mixer_source import FILE,MAX_ORIGINAL


class ReceivedMixerSDKLedger(PassiveSDKLedger):
    OWNER_TYPE=IOSAudioReceivedMixerOwner
    LEDGER_FILE='ios-audio-received-mixer-ledger.json'
    LEDGER_KEY='iosAudioReceivedMixerSDKLedgerVersion'
    LEDGER_VERSIONS=(1,2)
    CHILD_PREFIX='ios-audio-received-mixer-'



class IOSAudioReceivedMixerRuntime(IOSAudioPassiveRuntime):
    @contextmanager
    def received_mixer_owner(self,selector,run,lease,artifact_root,client,*,epoch_ms=lambda:time.time()*1000,
                             monotonic=time.monotonic,sleep=time.sleep,source_lock=None):
        path=self.state_path(selector).with_name('script-feature-sources.lock')
        lock=ScriptSourceLock(path)if source_lock is None else source_lock
        need(type(lock)is ScriptSourceLock and lock.path==path)
        with lock.held():
            # All typed historical originals are admitted before any fresh SDK
            # source. No unknown parent/child or foreign binding is adopted.
            ledger=ReceivedMixerSDKLedger(self,selector,run,lease,artifact_root,client,lock)
            ledger.transfer_completed();need(ledger.process_end is None)
            if ledger.shared is not None:ledger.shared.require_live()
            source=self._sources(selector);need(source['check']()is not False)
            child=ledger.select(lease,source['binding']);ledger.guard()
            original=source['check']
            def check():ledger.guard();need(original()is not False);ledger.guard();return True
            observer=source['observer'];remote=observer.remote.rsplit('/',1)[0]+'/'+FILE
            for transport in(observer,getattr(source['clock_source'].send,'__self__',None)):
                need(transport is not None);before=getattr(transport,'before_send',None)
                def final(before=before):
                    check()
                    if before is not None:need(before()is not False)
                    check()
                transport.before_send=final
            owner=IOSAudioReceivedMixerOwner(PrivateFeatureState(child/IOSAudioReceivedMixerOwner.STORE_NAME),child,
                source['binding'],run,lease,lock,check,native=source['clock_source'],
                transport=dict(send=observer.send,read=lambda:observer.original(remote=remote,limit=MAX_ORIGINAL)),
                phase=PhaseFixtureReader(client,run,'audio',epoch_ms=epoch_ms,monotonic=monotonic),
                epoch_ms=epoch_ms,monotonic=monotonic,sleep=sleep)
            with self.existing_input_session(selector):
                yield owner
                check()
