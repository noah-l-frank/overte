"""Exactly one three-prefix UIKit5 host case, with its original test unchanged."""
from pathlib import Path
import hashlib,json,os,stat,unittest
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
CASE='test_ios_tablet_web_native_peer_flow.TabletNativePeerUIKitFlowTests.test_actual_UIKit5_proves_sources129_before_normal130_and_preserves_original_DOM_and_parent'
def save(name,value):(HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def originals(path):
    path=Path(path);assert path.parent==REPO/'.ios-host-tmp' and path.name.startswith('continuation5-dom-native-')
    assert stat.S_IMODE(path.lstat().st_mode)==0o700
    result={};fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    for item in (path,*sorted(path.rglob('*'))):
        before=item.lstat();row={key:getattr(before,key) for key in fields}
        if stat.S_ISREG(before.st_mode):row['sha256']=hashlib.sha256(item.read_bytes()).hexdigest()
        else:assert stat.S_ISDIR(before.st_mode)
        after=item.lstat();assert all(getattr(before,key)==getattr(after,key) for key in fields)
        result[str(item.relative_to(path))]=row
    return result
print('RUNNER_PID',os.getpid(),'PARENT_PID',os.getppid(),flush=True)
suite=unittest.defaultTestLoader.loadTestsFromName(CASE)
assert suite.countTestCases()==1
result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
save('unittest-result.json',dict(tests=result.testsRun,errors=len(result.errors),failures=len(result.failures),successful=result.wasSuccessful(),wholeFeatureQualified=False,nativeCompiled=False,deviceQualified=False))
raise SystemExit(not result.wasSuccessful())
