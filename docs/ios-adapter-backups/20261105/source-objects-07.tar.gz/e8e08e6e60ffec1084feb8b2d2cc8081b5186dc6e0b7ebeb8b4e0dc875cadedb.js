module.exports = {kind: "lifecycle-relative-marker-v1"};
