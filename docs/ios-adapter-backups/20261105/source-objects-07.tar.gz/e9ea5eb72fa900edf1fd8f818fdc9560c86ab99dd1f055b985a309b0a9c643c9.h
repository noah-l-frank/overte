// Copyright 2026 Overte contributors.
// SPDX-License-Identifier: Apache-2.0
#pragma once
#if defined(OVERTE_E2E_FEATURE_TESTS) && defined(Q_OS_IOS)
#include <QCoreApplication>
#include <QDateTime>
#include <QMutex>
#include <QMutexLocker>
#include <QVariantMap>
#include <QUuid>

namespace overte::e2e {
// Owned by the real Model. Only completed CPU palette preparation is recorded.
// No draw/upload/fence/pixel verdict and no desired clip or pose input.
class IOSEmotePaletteObservation {
public:
    static bool enabled() {
        return QCoreApplication::instance()
            && QCoreApplication::arguments().contains("--testScript")
            && QCoreApplication::arguments().contains("--emote-palette-observe");
    }
    void record(const QVariantMap& cut,const QString& modelUrl,const QString& mode,const QVariantList& meshes) {
        if (!enabled()) { return; }
        QMutexLocker lock(&_mutex);
        const auto epoch=QDateTime::currentMSecsSinceEpoch();
        _original.clear(); // An invalid new preparation cannot borrow old data.
        const auto animation=cut.value("animation").toMap();
        const auto pose=cut.value("postControllerPose").toMap();
        if (!_valid || epoch<=0 || epoch<_epoch || _sequence>=1000000000
                || animation.isEmpty() || animation.value("history").toMap().value("instance").toString().isEmpty()
                || !animation.value("graphLoaded").toBool() || !animation.value("animationsEnabled").toBool()
                || !animation.value("evaluationSequence").toULongLong()
                || pose.value("emotePostControllerPoseVersion").toInt()!=1
                || animation.value("capturedEpochMs").toLongLong()>pose.value("capturedEpochMs").toLongLong()
                || pose.value("capturedEpochMs").toLongLong()>epoch
                || modelUrl.isEmpty() || meshes.isEmpty() || meshes.size()>16
                || (mode!="matrix" && mode!="dual-quaternion-matrix-projection")) {
            if (epoch<=0 || epoch<_epoch || _sequence>=1000000000) { _valid=false; }
            return;
        }
        if (_instance.isEmpty()) { _instance=QUuid::createUuid().toString(QUuid::WithoutBraces).remove('-'); }
        _epoch=epoch;
        _original={{"emotePaletteOriginalVersion",2},{"modelInstance",_instance},
            {"sequence",static_cast<double>(++_sequence)},{"computedEpochMs",static_cast<double>(epoch)},
            {"modelUrl",modelUrl},{"paletteMode",mode},{"animation",animation},{"postControllerPose",pose},{"meshes",meshes},
            {"stage","cpu-skinning-palette-prepared"}};
    }
    QVariantMap snapshot(const QVariantMap& currentCut) const {
        if (!enabled()) { return {}; }
        QMutexLocker lock(&_mutex);
        // A newer graph/evaluation or native override cannot borrow this cut.
        return _valid && !_original.isEmpty() && _original.value("animation").toMap()==currentCut.value("animation").toMap()
            && _original.value("postControllerPose").toMap()==currentCut.value("postControllerPose").toMap()
            ? _original : QVariantMap();
    }
private:
    mutable QMutex _mutex;
    QString _instance;
    QVariantMap _original;quint64 _sequence {0};qint64 _epoch {0};bool _valid {true};
};
}
#endif
