"""Root-only source utility preparer; no work executes on import.

Three finite selections, independent fresh processes. This preparer has no
old original/corpus input and never creates a feature admission proof.
"""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
SOURCE=Path(__file__).resolve().parent
VARIANT=REPO/'.ios-host-tmp/tablet-current-c10d-mp-variant-nine-counter-source-plan1-private-20261104'
VARIANT_FREEZE='9e739f4360fce7442da06301bbac3a7444dbe8c0825875ede4b2b4dcfe63e887'
VARIANT_SHA='a7977c6b9399a94df0cd9e6b44729e76ce67cbb121998d787dc5b97f27d74f44'
BASE=REPO/'.ios-host-tmp/chat-c10d-baseline6-transaction8-closed-utility-bootstrap1-code-preparation-20261104'
BASE_FREEZE='ca3dadde214da0b296fc7df3298fa232706db65fd681b4afbcd553fbd97f70a2'
B6=REPO/'.ios-host-tmp/tablet-fresh-primary-four-bootstrap6-real-namespace-audit-closed-mp-proof-code-preparation-20261104'
B6_FREEZE='9890ccd467a21a2621d8d20b116b775214919d8d830783f38109ffd5d9f28e73'

def load(path):return json.loads(Path(path).read_text())
def packet(folder,leaf,digest):
    path=folder/leaf;assert pin(path)['sha256']==digest
    result={str(path):pin(path)};body=load(path)
    for name,row in body['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        actual=folder/name;assert actual.resolve(strict=True)==actual
        result[str(actual)]=pin(actual);assert result[str(actual)]['sha256']==(row if type(row)is str else row['sha256'])
    return result

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source-freeze',required=True);parser.add_argument('--expected-head',required=True)
    parser.add_argument('--selection',choices=('baseline6','mp3','transaction8'),required=True);parser.add_argument('--destination',type=Path,required=True)
    args=parser.parse_args();assert Path.cwd()==REPO and sys.flags.no_site==1 and sys.dont_write_bytecode and sys.flags.optimize==0
    assert len(args.expected_head)==40 and all(ch in'0123456789abcdef'for ch in args.expected_head)and head()==args.expected_head
    physical=packet(SOURCE,'source-freeze.json',args.source_freeze)
    previous=REPO/'.ios-host-tmp/tablet-current-c10d-mp-variant-seventeen-utility-bootstrap1-code-preparation-20261104'
    peer=REPO/'.ios-host-tmp/avatar-independent-tablet-current-variant17-bootstrap1-full-source-review-20261104'
    physical.update(packet(previous,'source-freeze.json','1cae41162d8ca9234299bdaa08a1e491dc760a5cf48f4b0cc9b2d046bf50f338'))
    physical.update(packet(peer,'freeze.json','fe83906d112711b9b0311fe793d96ed9deaf406837a6e43c45fe187106e238ff'))
    for folder,leaf,digest in((VARIANT,'source-freeze.json',VARIANT_FREEZE),(BASE,'source-freeze.json',BASE_FREEZE),(B6,'source-freeze.json',B6_FREEZE)):
        physical.update(packet(folder,leaf,digest))
    assert pin(SOURCE/'closed_import_origins.py')['sha256']==pin(VARIANT/'candidate/closed_import_origins.py')['sha256']==VARIANT_SHA
    for name in('test_c10_source_execution.py','test_c10d_defused_transaction.py','owned_write_boundary.py','metadata_reader.py','readonly-shared-stdlib-sources.json'):
        assert(SOURCE/name).read_bytes()==(BASE/name).read_bytes()
    retainer=REPO/'tests/device/ios/self_tests/retained_host_roots.py';physical[str(retainer)]=pin(retainer)
    assert physical[str(retainer)]['sha256']=='07ddd7913819ee1c7d21bd36567c207906c7cc9df82e59d6fe80b64b0dadbcf6'
    recipe=load(SOURCE/'COUNTER-RESOURCE-RECIPE.json');choice=recipe['selections'][args.selection]
    assert choice['caseCount']==len(set(choice['cases']))==len(choice['cases'])and choice['TDs']==choice['caseCount']and choice['TDsPerCase']==1
    assert choice['wallSeconds']==30 and choice['graceSeconds']==5
    selector={'baseline6':'baseline-six-selectors.json','mp3':'mp-three-selectors.json','transaction8':'new-eight-selectors.json'}[args.selection]
    assert choice['cases']==load(SOURCE/selector)
    std=Path(os.__file__).resolve(strict=True).parent;std_namespaces={};suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    for current,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current);dirs[:]=sorted(name for name in dirs if name not in('site-packages','dist-packages','__pycache__')and not(folder/name).is_symlink())
        relative=folder.relative_to(std)
        if relative.parts and all(part.isidentifier()for part in relative.parts)and not(folder/'__init__.py').is_file():std_namespaces['.'.join(relative.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix=='.py'or str(path).endswith(suffixes):
                assert path.resolve(strict=True)==path and not path.is_symlink();physical[str(path)]=pin(path)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ')
    gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(path)]=pin(path)
    ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    actual_ref=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs')
    physical[str(actual_ref)]=pin(actual_ref)
    declared=load(SOURCE/'exact-defused-source-declarations.json')
    assert set(declared)=={'defusedxml','defusedxml.common','defusedxml.ElementTree'}
    for row in declared.values():
        actual=Path(row['path']);physical[str(actual)]=pin(actual);assert physical[str(actual)]['sha256']==row['sha256']and row['loader']=='source'
    third=declared if args.selection=='transaction8'else{}
    # Every copied source is independently pinned before declaration, including
    # unselected old bodies and genuine package __main__ physical startup.
    copied=sorted(name for name in load(SOURCE/'source-freeze.json')['files']if name.endswith('.py')or name.endswith('.json'))
    copied=[name for name in copied if name not in('source-freeze.json','SOURCE-REFERENCES.json','STATIC-SOURCE-AUDIT.json')]
    destination=args.destination
    assert destination.is_absolute()and destination.resolve(strict=False)==destination and destination.parent==REPO/'.ios-host-tmp'
    assert destination.name.startswith('tablet-mp-variant-prepared-')and not destination.exists()
    before=dict(physical);assert all(pin(path)==row for path,row in before.items())and head()==args.expected_head
    destination.mkdir(mode=0o700)
    for name in copied:
        target=destination/name;assert target.resolve(strict=False).is_relative_to(destination)
        target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(target)]=pin(target)
    projects={}
    for name in copied:
        path=Path(name)
        if path.suffix!='.py'or path.name in('build-approved-inputs.py','run-utility.py','supervise-utility.py','supervise-mp.py','mp_child_guard.py'):continue
        parts=path.with_suffix('').parts
        package=parts[-1]=='__init__';alias='.'.join(parts[:-1]if package else parts)
        if not alias or any(not item.isidentifier()for item in alias.split('.')):continue
        actual=destination/path;projects[alias]=dict(path=str(actual),sha256=physical[str(actual)]['sha256'],package=package)
    projects['ios.self_tests.retained_host_roots']=dict(path=str(retainer),sha256=physical[str(retainer)]['sha256'],package=False)
    namespaces={'ios':[str(REPO/'tests/device/ios')],'ios.self_tests':[str(REPO/'tests/device/ios/self_tests')]}
    if args.selection=='mp3':
        main=projects['tablet_mp_variant_utility.__main__']
        projects['__main__']=dict(main);projects['__mp_main__']=dict(main)
    subject_names=['test_c10_source_execution','ios.self_tests.retained_host_roots']
    if args.selection=='transaction8':subject_names.append('test_c10d_defused_transaction')
    if args.selection=='mp3':subject_names=['test_tablet_mp_variant','mp_core','ios.self_tests.retained_host_roots']
    subjects={name:dict(path=projects[name]['path'],sha256=projects[name]['sha256'])for name in subject_names}
    origins=dict(modules=projects,namespacePackages=namespaces,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=std_namespaces,
        stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='PRIVATE_TABLET_MP_VARIANT_UTILITY_UNRUN_UNQUALIFIED',repositoryRoot=str(REPO),controllerRoot=str(destination),actualPublicHead=args.expected_head,
        sourceFreeze=args.source_freeze,subjectSourceFreeze=VARIANT_FREEZE,subjectOriginalPath=str(VARIANT/'candidate/closed_import_origins.py'),subjectActualCopiedPath=str(destination/'closed_import_origins.py'),subjectHelperSha256=VARIANT_SHA,
        sourceAndBinaryPins=physical,originPlan=origins,modules=projects,namespaces=namespaces,thirdPartyModules=third,subjectOriginModules=subjects,subjectOriginCount=len(subjects),
        utilitySelection=args.selection,cases=choice['cases'],caseCount=choice['caseCount'],expectedTemporaryDirectories=choice['TDs'],expectedTemporaryDirectoriesPerCase=1,
        wallSeconds=30,killGraceSeconds=5,NodeExecutions=0,SDKExecutions=0,overteNativeQueries=0,realNetwork=False,oldCorpusInputs=0,globalOriginalScans=0,
        helperQualified=False,consumerAdmissionClosed=True,actualHistoricalC10dProofIsNotVariantQualification=True,featureQualified=False,nativeQualified=False,wholeQualified=False,
        actualMPChildCount=6 if args.selection=='mp3'else 0,maxLiveMPChildren=2 if args.selection=='mp3'else 0,
        actualCommandMainAliasesOnly=args.selection=='mp3',hostBootstrapScope='Actual pinned package/interpreter/private controller startup is trusted HOSTBOOTSTRAP; delegated subjects execute fresh pinned source bytes.')
    target=destination/'approved-inputs.json';fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,sort_keys=True,indent=2);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(target),inputSha256=pin(target)['sha256'],selection=args.selection,cases=choice['caseCount'],sourcePins=len(physical),targets=0,globalScans=0)))
    return 0
if __name__=='__main__':raise SystemExit(main())
