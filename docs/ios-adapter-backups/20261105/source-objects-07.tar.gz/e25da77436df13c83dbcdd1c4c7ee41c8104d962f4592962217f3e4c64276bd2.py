"""One actual saved third748 original, passive Source3 historical read costs.

No whole-window retry, current/native acquisition, HTTP, Node, SDK or write to
any input root. This diagnostic header path does not qualify full Live decode.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import cProfile,hashlib,json,os,pstats,signal,stat,sys,time,unittest
from pathlib import Path
from PIL import Image
from adapters.native_clock_join import digest
from adapters.original_file_reads import readonly,collect
from adapters.script_feature.history import unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
from ios.adapters.emote_callback_live_records import CallbackLiveRecords
from ios.adapters.emote_retirement import Frozen
from ios.adapters.emote_callback_drain_originals import checked_read

FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')


def checked(path):
    repo=Path.cwd().resolve(strict=True)
    assert repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file()
    path=Path(path);assert path.resolve().is_relative_to(repo);return path


def census(roots):
    rows={}
    for root in roots:
        for path in(root,*sorted(root.rglob('*'))):
            a=path.lstat();assert stat.S_ISDIR(a.st_mode)or stat.S_ISREG(a.st_mode)
            row=dict(stat=[getattr(a,key)for key in FIELDS])
            if stat.S_ISREG(a.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
            assert row['stat']==[getattr(path.lstat(),key)for key in FIELDS];rows[str(path)]=row
    return rows


class EmoteSavedThird748PassiveDiagnostic(unittest.TestCase):
    def test_actual_saved_third_original_cold_warm_record_policy_archive_keys_and_lease_costs(self):
        plan=json.loads(Path(os.environ['EMOTE_SAVED_THIRD_PLAN']).read_text())
        output=checked(os.environ['EMOTE_SAVED_THIRD_DIAGNOSTIC_OUTPUT']);self.assertTrue(output.is_dir())
        def save(name,value):
            with checked(output/name).open('x')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
        roots=[Path(path)for path in plan['roots']];before=census(roots)
        expected=json.loads(Path(os.environ['EMOTE_SAVED_THIRD_INPUT_PINS']).read_text());self.assertEqual(expected,before)
        header=Path(plan['header']);raw=header.read_bytes();self.assertEqual(plan['headerSha256'],hashlib.sha256(raw).hexdigest())
        value=json.loads(raw);rows=unpack(value['payload']);self.assertEqual(1,len(rows));state=rows[0]
        self.assertEqual(plan['recordReferences'],state['records']);self.assertEqual(plan['pending'],state['pending'])
        self.assertEqual(2,len(state['records']));pending=state['pending'];self.assertEqual(3,pending['index'])
        self.assertEqual('saved',pending['original']['phase']);self.assertEqual(plan['savedOriginal'],pending['original'])
        lock=ScriptSourceLock(value['sourceLock']);primary=lock if value['sourceLock']==value['primaryLock']else ScriptSourceLock(value['primaryLock'])
        Image.preinit();history=CallbackLiveRecords()
        # Report actual support; unsupported remains the ordinary literal path.
        supported=history.literal();save('policy-before.json',dict(supported=supported,unsupported=history.unsupported_members()))
        self.assertEqual({},history.cache.rows)
        self.assertIsNone(sys.monitoring.get_tool(getattr(sys.monitoring,'PROFILER_ID',2)))
        profile=cProfile.Profile();phase='before-header';reads=[];result=[];durations=[];events=[]
        def interrupted(_signum,frame):
            stack=[]
            while frame is not None and len(stack)<96:
                stack.append(dict(file=frame.f_code.co_filename,function=frame.f_code.co_qualname,line=frame.f_lineno));frame=frame.f_back
            save('actual-interruption-stack.json',dict(phase=phase,kind='ACTUAL_SIGNAL_FRAME_NO_LOCALS',stack=stack))
            raise TimeoutError('New saved-third90s passive diagnostic boundary; partial costs retained')
        previous=signal.signal(signal.SIGALRM,interrupted)
        signal.setitimer(signal.ITIMER_REAL,plan['diagnosticAlarmSeconds'])
        try:
            with lock.held(),primary.held(),readonly():
                # Existing literal original-header factory; committed rows1/2
                # are NOT decoded/warmed here. Pending grammar is independently
                # checked with the actual public pending() decoder.
                live=IOSEmoteCallbackLive._archive_header(value,store=Frozen(header,value),lock=lock,primary_lock=primary)
                live._historical_rows=history;live.state=live.structure(value)
                live.pending(live.state['pending'],len(live.state['records'])+1)
                ref=live.originals.compact(pending['original'])
                self.assertEqual(3,ref['index']);self.assertEqual(pending['original']['sha256'],ref['sha256'])
                self.assertEqual({},history.cache.rows)
                for phase in('cold','warm'):
                    profile.clear();started=time.monotonic();completed=False
                    events.append(dict(phase=phase,operation='before-actual-record',cacheRows=len(history.cache.rows)))
                    with collect()as membership:
                        profile.enable()
                        try:
                            row=checked_read(roots,lambda:live.record(ref));completed=True
                        finally:
                            profile.disable();elapsed=time.monotonic()-started
                            path=checked(output/(phase+'-partial-or-complete.pstats'));profile.dump_stats(str(path))
                            stats=pstats.Stats(profile)
                            selected=[dict(file=f,line=line,function=name,primitiveCalls=v[0],totalCalls=v[1],selfSeconds=v[2],cumulativeSeconds=v[3])
                                for(f,line,name),v in sorted(stats.stats.items())if '/tests/device/'in f]
                            save(phase+'-actual-costs.json',dict(phase=phase,completed=completed,seconds=elapsed,calls=selected,
                                actualReadMembership=sorted(str(p)for p in membership),cacheRows=len(history.cache.rows)))
                    self.assertEqual(ref,row['reference']);self.assertEqual(pending['measurementSha256'],digest(row['measurement']))
                    frame=live.read_frame(ref);self.assertEqual(frame['measurementSha256'],digest(row['measurement']))
                    self.assertEqual(before,census(roots));result.append(row);reads.append(set(membership));durations.append(elapsed)
        finally:
            signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous);profile.disable()
            save('actual-progress.json',dict(events=events,coldWarmComplete=len(result)==2))
            self.assertEqual(before,census(roots))
        self.assertTrue(same(result[0],result[1]));self.assertTrue(reads[0]);self.assertEqual(reads[0],reads[1])
        self.assertEqual(before,census(roots));save('diagnostic-result.json',dict(status='ACTUAL_SAVED_THIRD_HISTORICAL_ONLY',
            coldSeconds=durations[0],warmSeconds=durations[1],cacheRows=len(history.cache.rows),initialPolicySupported=supported,
            finalPolicySupported=history.literal(),readMembership=len(reads[0]),nativeSDKHTTPNodeExecuted=False,
            currentMetadataOrClockRenewed=False,actualRuntimeCacheReconstructed=False,stoppedWindowStackProved=False,
            completeLiveJournalQualified=False,freshnessQualified=False,wholeFeatureQualified=False))
