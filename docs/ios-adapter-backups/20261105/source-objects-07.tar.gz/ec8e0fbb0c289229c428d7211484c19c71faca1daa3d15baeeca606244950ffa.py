"""File-only Callback copy owner1, never a native/process/SDK end owner.

Each exact metadata value uses the existing OriginalFrameStore protocol.
Opened/saved recovery reads that actual inode. A planned-path collision or
incomplete file remains unresolved; no file is deleted or silently adopted.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.original_file_reads import scope as read_scope
from ios.adapters.emote_session_carriers import inventory
from ios.adapters import emote_callback_drain_originals as drains
from adapters.script_feature.history import pack,unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import identifier
from ios.adapters.emote_observer import EmoteObservationPending
from ios.adapters.emote_callback_copied_ownership import IOSEmoteCallbackCopiedOwnership,checkpoint_shape

VERSION=1
NAMESPACE='emote-callback-copied'
PREFIX='iosEmoteCallbackCopied'


class IOSEmoteCallbackCopiedArchive:
    def __init__(self,store,*,root,binding,run,lock,actor_lock,guard):
        need(isinstance(store,PrivateFeatureState) and isinstance(lock,ScriptSourceLock)
            and isinstance(actor_lock,ScriptSourceLock) and callable(guard) and lock.path!=actor_lock.path)
        self.store,self.root,self.binding,self.run=store,Path(root),deepcopy(context(binding)),identifier(run)
        self.lock,self.actor_lock,self.check,self.failed=lock,actor_lock,guard,False
        need(self.root.is_absolute() and self.root.resolve()==self.root and self.root.is_dir()
            and store.path==lock.path.with_name('ios-emote-primary-'+run+'-callback-copied.json'))
        self.originals=OriginalFrameStore(self.root,self.binding,run,'primary',self.bound,self.intent,
            namespace=NAMESPACE,schema_prefix=PREFIX,kind='inputs')
        self.previous=store.read();self.state=None
        if self.previous is not None:self.state=self.decode(self.previous)
        self.bound()
    def envelope(self,state):
        return dict(iosEmoteCallbackCopiedArchiveVersion=VERSION,runId=self.run,binding=self.binding,artifactRoot=str(self.root),
            locks=dict(primary=str(self.lock.path),actor=str(self.actor_lock.path)),payload=pack([state]))
    def decode(self,value):
        exact(value,{'iosEmoteCallbackCopiedArchiveVersion','runId','binding','artifactRoot','locks','payload'})
        rows=unpack(value['payload']);need(type(value['iosEmoteCallbackCopiedArchiveVersion']) is int
            and value['iosEmoteCallbackCopiedArchiveVersion']==VERSION and len(rows)==1 and same(value,self.envelope(rows[0])))
        state=rows[0];exact(state,{'phase','paths','hashes','checkpointSha256','seed','records','pending','staged'})
        need(state['phase'] in ('copying','validated') and type(state['paths']) is list and 1<=len(state['paths'])<=256
            and len(set(state['paths']))==len(state['paths']) and type(state['hashes']) is list and len(state['hashes'])==len(state['paths'])
            and type(state['records']) is list and len(state['records'])<=len(state['paths'])+1)
        for path in state['paths']:
            need(type(path) is str and Path(path).is_absolute() and Path(path).resolve()==Path(path) and Path(path)!=self.store.path)
        for index,reference in enumerate(state['records'],1):
            self.originals.expand(reference);need(reference['index']==index)
        if state['records']:need(state['seed'] is None)
        else:
            checkpoint_shape(state['seed'],run=self.run);need(digest(state['seed'])==state['checkpointSha256'])
        if state['pending'] is None:need(state['staged'] is None)
        else:
            need(state['phase']=='copying');self.originals.original(state['pending'])
            need(state['pending']['index']==len(state['records'])+1)
            self.validate_frame(state['staged'],state['pending']['index'],state)
        if state['phase']=='validated':need(len(state['records'])==len(state['paths'])+1 and state['pending'] is None)
        return deepcopy(state)
    def validate_frame(self,frame,index,state=None):
        state=self.state if state is None else state
        if index==1:
            exact(frame,{'kind','checkpoint'});need(frame['kind']=='inactive-checkpoint')
            checkpoint_shape(frame['checkpoint'],run=self.run);need(digest(frame['checkpoint'])==state['checkpointSha256'])
        else:
            exact(frame,{'kind','path','value'});need(frame['kind']=='metadata' and index<=len(state['paths'])+1
                and frame['path']==state['paths'][index-2] and digest(frame['value'])==state['hashes'][index-2]
                and (frame['value'] is None or type(frame['value']) is dict))
        return frame
    def owned_paths(self):
        result={self.store.path}
        if self.state is not None:
            result.update(self.originals.path(self.originals.expand(reference)) for reference in self.state['records'])
            if self.state['pending'] is not None:result.add(self.originals.path(self.state['pending']))
        return result
    def bound(self):
        self.lock.assert_held();self.actor_lock.assert_held();need(not self.failed and self.check() is not False)
        need(same(self.store.read(),self.previous))
        actual={path for path in self.root.iterdir() if path.name.startswith(NAMESPACE+'-')}
        expected={path for path in self.owned_paths() if path.parent==self.root and path!=self.store.path and path.exists()}
        need(actual==expected)
        if self.state is not None and self.state['phase']=='copying':
            need(all(digest(PrivateFeatureState(path).read())==hash_ for path,hash_ in zip(self.state['paths'],self.state['hashes'])))
        return True
    def save(self):
        self.bound();value=self.envelope(self.state);self.decode(value)
        try:self.store.write(value,self.previous);need(same(self.store.read(),value));self.previous=deepcopy(value)
        except BaseException:self.failed=True;raise
    def begin(self,paths,checkpoint):
        self.bound();need(self.state is None and type(paths) is list and 1<=len(paths)<=256
            and all(isinstance(store,PrivateFeatureState) for store in paths))
        checkpoint_shape(checkpoint,run=self.run)
        need(len({str(store.path) for store in paths})==len(paths) and all(store.path!=self.store.path for store in paths))
        copies={str(store.path):store.read() for store in paths}
        self.validate_context(copies)
        ownership=IOSEmoteCallbackCopiedOwnership(copies,run=self.run,lock=self.lock,actor_lock=self.actor_lock)
        ownership.read(checkpoint)
        self.state=dict(phase='copying',paths=list(copies),hashes=[digest(value) for value in copies.values()],
            checkpointSha256=digest(checkpoint),seed=deepcopy(checkpoint),records=[],pending=None,staged=None)
        self.save()
    def intent(self,kind,value):
        need(kind=='original' and self.state is not None and self.state['phase']=='copying');self.bound()
        self.originals.original(value);need(value['index']==len(self.state['records'])+1)
        old=self.state['pending']
        if old is None:need(value['phase']=='planned')
        else:
            need(all(same(value[key],old[key]) for key in value if key not in ('phase','file'))
                and ((old['phase'],value['phase']) in (('planned','opened'),('opened','saved'))
                     or same(old,value) and value['phase']=='planned'))
            if old['file'] is not None:need(same(old['file'],value['file']))
        need(self.state['staged'] is not None);self.state['pending']=deepcopy(value);self.save()
    def retained(self):
        self.bound();need(self.state is not None and len(self.state['records'])==len(self.state['paths'])+1)
        frames=[self.validate_frame(self.originals.read(self.originals.expand(ref)),ref['index']) for ref in self.state['records']]
        checkpoint=frames[0]['checkpoint'];copies={frame['path']:frame['value'] for frame in frames[1:]}
        need(set(copies)==set(self.state['paths']));return copies,checkpoint
    def validate_context(self,copies):
        value=copies.get(str(self.lock.path.with_name('ios-emote-primary-feature.json')))
        need(type(value) is dict and value.get('runId')==self.run and value.get('role')=='primary'
            and value.get('artifactRoot')==str(self.root) and type(value.get('targetPair')) is dict
            and same(value['targetPair'].get('primaryBinding'),self.binding))
    def qualify(self):
        copies,checkpoint=self.retained();self.validate_context(copies)
        ownership=IOSEmoteCallbackCopiedOwnership(copies,run=self.run,lock=self.lock,actor_lock=self.actor_lock)
        roots={self.lock.path.parent,self.actor_lock.path.parent}
        for role,lock in ownership.roles.locks.items():
            roots.add(Path(copies[str(lock.path.with_name('ios-emote-'+role+'-feature.json'))]['artifactRoot']))
        def literal():
            with read_scope(fresh=True) as reads:
                result=ownership.read(checkpoint)
                need(inventory(roots)<=reads|{Path(path) for path in copies}|self.owned_paths())
                self.bound();return result
        return drains.checked_read(roots,literal)
    def freeze(self):
        self.bound();need(self.state is not None)
        if self.state['phase']=='validated':return self.qualify()
        while len(self.state['records'])<len(self.state['paths'])+1:
            index=len(self.state['records'])+1;pending=self.state['pending']
            if pending is None:
                if index==1:frame=dict(kind='inactive-checkpoint',checkpoint=deepcopy(self.state['seed']))
                else:
                    path=self.state['paths'][index-2];frame=dict(kind='metadata',path=path,value=PrivateFeatureState(path).read())
                self.validate_frame(frame,index)
                # Staged alone is not a file intent. Save it together with the
                # real planned callback before O_EXCL, never as an owner ACK.
                self.state['staged']=deepcopy(frame)
                reference=self.originals.write(index,frame)
            elif pending['phase']=='planned':
                need(not self.originals.path(pending).exists() and not self.originals.path(pending).is_symlink())
                reference=self.originals.write(index,self.state['staged'])
            else:
                need(pending['phase'] in ('opened','saved') and same(self.originals.read(pending),self.state['staged']))
                reference=self.originals.compact(dict(pending,phase='saved'))
            need(same(self.originals.read(self.originals.expand(reference)),self.state['staged']))
            self.state['records'].append(reference);self.state['pending']=self.state['staged']=None
            if index==1:self.state['seed']=None
            self.save()
        result=self.qualify();self.state['phase']='validated';self.save();return result
    def retire(self):
        raise EmoteObservationPending('Callback copied ownership retains all metadata until a separate typed fence/process/SDK end')
