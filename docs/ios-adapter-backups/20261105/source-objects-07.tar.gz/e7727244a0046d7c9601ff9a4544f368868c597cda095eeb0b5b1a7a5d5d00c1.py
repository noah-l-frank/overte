"""Root-only closed source metadata; no project, external or SDK imports."""
from pathlib import Path
import os,sys,json,stat,importlib.machinery

def closed_frontier(prep,origins,namespaces,args,physical,pin,sha):
    manifest=Path(args.external_manifest);assert manifest.is_absolute()and manifest.resolve(strict=True)==manifest and sha(manifest)==args.external_manifest_sha256
    external=json.loads(manifest.read_text());assert set(external)=={'modules','namespaces'};physical.add(manifest)
    std=Path(vars(os)['__file__']).resolve(strict=True).parent
    assert std.name=='python3.14'and not any(part in('site-packages','dist-packages')for part in std.parts)
    std_namespaces={}
    for current,dirs,files in os.walk(std,topdown=True,followlinks=False):
        base=Path(current);assert base.resolve(strict=True)==base and not base.is_symlink()
        dirs[:]=sorted(name for name in dirs if name not in('site-packages','dist-packages','__pycache__')and not(base/name).is_symlink())
        for name in sorted(files):
            path=base/name
            if path.suffix=='.py'or any(name.endswith(ext)for ext in importlib.machinery.EXTENSION_SUFFIXES):
                assert not path.is_symlink()and path.resolve(strict=True)==path;physical.add(path)
        if base!=std and not(base/'__init__.py').exists():
            parts=base.relative_to(std).parts
            if all(part.isidentifier()for part in parts):std_namespaces['.'.join(parts)]=[str(base)];physical.add(base)
    modules={name:dict(path=path,sha256=sha(path),package=Path(path).name=='__init__.py',loader='source')for name,path in origins.items()}
    assert not set(modules).intersection(external['modules'])and not set(namespaces).intersection(external['namespaces'])
    for name,row in external['modules'].items():
        assert set(row)=={'path','sha256','package','loader'}and type(row['package'])is bool and row['loader']in('source','extension')
        path=Path(row['path']);assert path.is_absolute()and path.resolve(strict=True)==path and sha(path)==row['sha256']
        if row['loader']=='source':assert path.suffix=='.py'
        else:assert any(path.name.endswith(ext)for ext in importlib.machinery.EXTENSION_SUFFIXES)
        physical.add(path)
    for roots in external['namespaces'].values():
        assert type(roots)is list and roots
        for value in roots:
            path=Path(value);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_dir();physical.add(path)
    python=Path(sys.executable).resolve(strict=True);assert python.is_file();physical.add(python)
    # Enforce INITIAL regular source custody before writing a plan, not merely
    # a post-import equality check. pin() now uses the exact strict reader.
    for path in sorted(physical):
        if path.is_file():pin(path)
    # Dynamic plan and the full immutable map are separate files to avoid any
    # self-hash. The child supplies actual immutable-source-pins as physicalPins.
    return dict(modules=modules,namespacePackages={name:[value]for name,value in namespaces.items()},thirdPartyModules=external['modules'],
        thirdPartyNamespacePackages=external['namespaces'],stdlibNamespacePackages=std_namespaces,stdlibRoots=[str(std)],
        pythonExecutable=dict(path=str(python),pin=pin(python)),externalManifest=dict(path=str(manifest),sha256=sha(manifest)),
        helperSha256='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d',
        hostBootstrapScope='Held physical pre-import controller and interpreter modules; no fresh-source claim for bootstrap.')
