"""Exact ordinary Emote host resources; never product/SDK/End authority."""
from pathlib import Path
from types import FrameType
import traceback,_socket,hashlib,http.client,http.server,io,json,os,shutil,signal,socket,socketserver,stat,subprocess,sys,threading
from owned_write_boundary import OwnedWrites
from byte_streams import install as install_streams
from kernel import absent,observe,OwnedTerminal

class Resources:
    def __init__(self,plan,here,pin,proc):
        self.plan,self.here,self.pin,self.proc=plan,Path(here),pin,proc
        self.main=threading.current_thread();self.roles={};self.bindings=[];self.pending=None;self.nodes=[];self.sockets=[];self.servers=[];self.threads=[]
        self.artifact=None;self.artifact_depth=False;self.pin_code=pin.__code__;self.pin_globals=pin.__globals__
        self.kernel_observations=[];self.kernel_births=[];self.kernel_module=sys.modules['kernel'];self.kernel_controls=tuple((name,getattr(self.kernel_module,name),getattr(self.kernel_module,name).__code__,getattr(self.kernel_module,name).__globals__,getattr(self.kernel_module,name).__defaults__,getattr(self.kernel_module,name).__kwdefaults__,tuple((getattr(self.kernel_module,name).__kwdefaults__ or{}).items()))for name in('_sample','_stat','_executable','_same_identity','_expected','observe','process','absent','descendants'));self.terminal_class=OwnedTerminal;self.terminal_init=OwnedTerminal.__init__;self.terminal_init_code=OwnedTerminal.__init__.__code__
        self.tds=[];self.receivers=[];self.cleanups=[];self.partial_drains=[];self.monitor=None;self.tool=None;self.palette=None;self.palette_unlink_rows=[];self.palette_pending=None
        self.popen=subprocess.Popen;self.popen_init=self.popen.__init__;self.execute_child=self.popen._execute_child
        self.communicate=self.popen._communicate;self.send_signal=self.popen.send_signal;self.wait=self.popen.wait
        self.original_read=os.read;self.original_write=os.write;self.original_io=(io.open,__import__('builtins').open)
        self.socket_class=socket.socket;self.csocket=_socket.socket
        self.c_fileno=_socket.socket.fileno;self.c_name=_socket.socket.getsockname;self.c_peer=_socket.socket.getpeername
        self.c_option=_socket.socket.getsockopt;self.c_family=_socket.socket.family;self.c_kind=_socket.socket.type;self.fstat=os.fstat
        self.constants=tuple((name,getattr(socket,name))for name in('AF_INET','SOCK_STREAM','SOCK_DGRAM','SOL_SOCKET','SO_TYPE','SO_REUSEPORT','IPPROTO_TCP'))
        self.create_connection=socket.create_connection;self.http_connect=http.client.HTTPConnection.connect
        self.http_thread=socketserver.ThreadingMixIn.process_request_thread
        self.tcp_init=socketserver.TCPServer.__init__;self.tcp_request=socketserver.TCPServer.get_request
        self.server_bind=http.server.HTTPServer.server_bind;self.getfqdn=socket.getfqdn;self.reverse=socket.gethostbyaddr
        self.accept=socket.socket.accept;self.thread_start=threading.Thread.start;self.thread_run=threading.Thread.run
        self.path=os.environ.get('PATH');self.env_digest=self.environment();self.router=None;self.installed=False
        self.implementation=tuple((name,fn,fn.__code__,fn.__globals__)for name,fn in type(self).__dict__.items()if hasattr(fn,'__code__'))
        self.port_seals=[]
        self.hold(self.popen,'__init__');self.hold(self.popen,'_execute_child');self.hold(self.popen,'_communicate');self.hold(self.popen,'send_signal');self.hold(self.popen,'wait');self.hold(subprocess,'run')
        for owner,name in((socket,'create_connection'),(socket,'getfqdn'),(http.server.HTTPServer,'server_bind'),(socket.socket,'__init__'),(http.client.HTTPConnection,'connect'),(socketserver.ThreadingMixIn,'process_request_thread'),
            (socketserver.TCPServer,'__init__'),(socketserver.TCPServer,'get_request'),(socket.socket,'accept'),(threading.Thread,'start'),(threading.Thread,'run')):self.hold(owner,name)
    def environment(self):return hashlib.sha256(json.dumps(dict(os.environ),sort_keys=True,separators=(',',':')).encode()).hexdigest()
    def hold(self,owner,name):
        function=getattr(owner,name);self.bindings.append((owner,name,function,function.__code__,function.__globals__))
    def check(self):
        assert threading.current_thread()is self.main or any(row is threading.current_thread()for row in self.threads)
        assert subprocess.Popen is self.popen and socket.socket is self.socket_class and (io.open,__import__('builtins').open)==self.original_io
        assert all(type(self).__dict__.get(name)is fn and fn.__code__ is code and fn.__globals__ is namespace for name,fn,code,namespace in self.implementation)
        if self.installed:
            assert os.read is self.read_port and all(getattr(os,name)is fn for name,fn in self.ports.items())
            for fn,code,closure,contents,defaults,kw,items in self.port_seals:
                assert fn.__code__ is code and fn.__closure__ is closure and fn.__defaults__ is defaults and fn.__kwdefaults__ is kw
                assert tuple(kw or())==tuple(name for name,value in items)and all(kw[name]is value for name,value in items)
                assert all(cell.cell_contents is value for cell,value in zip(closure or(),contents))
        assert all(getattr(owner,name)is fn and fn.__code__ is code and fn.__globals__ is namespace for owner,name,fn,code,namespace in self.bindings)
        assert all(getattr(socket,name)is value for name,value in self.constants)
        assert os.environ.get('PATH')==self.path and self.environment()==self.env_digest and not any(name.startswith('NODE_')for name in os.environ)
        binary=Path(shutil.which('node')).resolve(strict=True);assert str(binary)==self.plan['node']['path']and self.pin(binary)==self.plan['node']['pin']
    def frames(self,frame):
        while frame is not None:
            assert type(frame)is FrameType
            yield frame;frame=frame.f_back
    def frame_for(self,function,frame):
        return next((f for f in self.frames(frame)if f.f_code is function.__code__ and f.f_globals is function.__globals__),None)
    def loaded(self,name,module):
        # Called only after the actual C10c delegate executed this exact source.
        v=vars(module)
        if name=='feature_journeys.server':
            self.roles['server-class']=v['FixtureServer'];self.roles['server-factory']=v['make_server'];self.hold(module,'make_server')
        selected={'ios.self_tests.emote_script_vm_fixture':('vm','ActualEmoteVM','__init__'),
            'ios.self_tests.emote_marker_domain_fixture':('marker','RunningDomain','start'),
            'ios.self_tests.emote_post9_whole_end_fixture':('whole','Profile9WholeEndFixture','__init__'),
            'ios.self_tests.emote_post9_paired_fixture':('pair',None,'paired'),
            'ios.self_tests.test_ios_installed_code':('installed','InstalledCodeTests','setUp'),
            'ios.self_tests.emote_active_observer_fixture':('observer','ActiveObserverFixture','__init__'),
            'ios.self_tests.emote_post9_native_file_model':('palette','HostPaletteFile','__init__'),
            'ios.self_tests.emote_post9_active_actor_fixture':('actor','ActiveActorFixture','__init__')}
        if name in selected:
            role,cls,member=selected[name];owner=v[cls]if cls is not None else module;function=getattr(owner,member)
            self.roles[role]=(owner,function,function.__code__,function.__globals__);self.hold(owner,member)
            if role=='vm':self.hold(owner,'close');self.hold(owner,'command')
            if role=='actor':self.hold(owner,'receive_reader');self.roles['actor-reader']=(owner,owner.receive_reader)
            if role=='palette':self.hold(owner,'command');self.hold(owner,'root_current');self.hold(owner,'close')
        if name in('ios.self_tests.emote_script_vm_fixture','ios.self_tests.emote_marker_domain_fixture'):
            program=v['PROGRAM'];assert type(program)is str and hashlib.sha256(program.encode()).hexdigest()==self.plan['programs'][name]['sha256']
            self.roles[name]=(module,program)
    def source_frame(self,role,frame):
        owner,fn,code,namespace=self.roles[role];assert getattr(owner,fn.__name__)is fn and fn.__code__ is code and fn.__globals__ is namespace
        found=next((f for f in self.frames(frame)if f.f_code is code and f.f_globals is namespace),None)
        assert found is not None;return found
    def td_role(self,frame):
        for role,limit in(('whole',1),('pair',2),('installed',2)):
            if role not in self.roles:continue
            owner,fn,code,namespace=self.roles[role]
            if frame.f_code is code and frame.f_globals is namespace:
                assert getattr(owner,fn.__name__)is fn and fn.__code__ is code
                if role!='pair':assert isinstance(frame.f_locals.get('self'),owner)
                assert sum(row['role']==role for row in self.tds)<limit
                return role
        raise RuntimeError('TemporaryDirectory outside exact genuine Emote constructor')
    def socket_signature(self,sock):
        assert type(sock)is self.socket_class
        fd=self.c_fileno(sock);info=self.fstat(fd);assert stat.S_ISSOCK(info.st_mode)
        return(fd,info.st_dev,info.st_ino,info.st_mode,int(self.c_family.__get__(sock)),int(self.c_kind.__get__(sock))&15)
    def socket_row(self,sock):
        rows=[row for row in self.sockets if row['socket']is sock];assert len(rows)==1;row=rows[0]
        assert self.socket_signature(sock)==row['identity'];return row
    def event_socket(self,event,args,frame):
        self.check()
        if event=='socket.gethostbyaddr':
            assert args==('127.0.0.1',)and socket.gethostbyaddr is self.reverse
            fqdn=self.frame_for(self.getfqdn,frame);binding=self.frame_for(self.server_bind,frame);assert fqdn is not None and binding is not None
            owner=binding.f_locals['self'];row=self.socket_row(owner.socket);assert row['role']=='http-listener'and row['owner']is owner;return
        if event=='socket.getaddrinfo':
            assert args[0]=='127.0.0.1'and len(self.servers)==1 and args[1]==self.servers[0]['port'];self.http_origin(frame);return
        if event=='socket.__new__':
            sock,family,kind,proto=args;assert type(sock)is self.socket_class and int(family)==int(socket.AF_INET)and int(proto)in(0,int(socket.IPPROTO_TCP))
            if int(kind)&15==int(socket.SOCK_DGRAM):
                assert proto==0
                source=self.source_frame('actor',frame);owner=source.f_locals['self'];rows=[r for r in self.sockets if r['role'].startswith('udp')]
                assert len(rows)<2;role='udp-receiver'if not rows else'udp-sender'
                if rows:assert rows[0]['owner']is owner and vars(owner).get('socket')is rows[0]['socket']
            else:
                assert int(kind)&15==int(socket.SOCK_STREAM)
                ctor=self.frame_for(self.tcp_init,frame);accept=self.frame_for(self.accept,frame)
                if ctor is not None:
                    self.source_frame('observer',frame);assert not self.servers
                    owner=ctor.f_locals['self'];assert type(owner)is self.roles['server-class']and self.frame_for(self.roles['server-factory'],frame)is not None
                    role='http-listener'
                elif accept is not None:
                    request=self.frame_for(self.tcp_request,frame);assert request is not None and len(self.servers)==1
                    owner=request.f_locals['self'];assert owner is self.servers[0]['server'];role='http-accepted'
                else:owner=self.http_origin(frame);role='http-client'
            # __new__ precedes a usable descriptor. The real socket Python
            # constructor return below supplies its actual identity.
            self.sockets.append(dict(socket=sock,role=role,owner=owner,identity=None));return
        sock=args[0];row=self.socket_row(sock)
        if event=='socket.bind':
            assert row['role']in('http-listener','udp-receiver')and args[1]==('127.0.0.1',0)
        elif event=='socket.connect':
            assert row['role']=='http-client'and args[1]==('127.0.0.1',self.servers[0]['port']);self.http_origin(frame)
        elif event=='socket.sendto':
            assert row['role']=='udp-sender'
            matches=[r for r in self.receivers if r['owner']is row['owner']and self.frame_for(r['function'],frame)is not None]
            assert len(matches)==1;held=matches[0];fn=held['function']
            assert fn.__code__ is held['code']and fn.__globals__ is held['globals']and fn.__closure__ is held['closure']
            assert all(cell.cell_contents is value for cell,value in zip(held['closure'],held['contents']))
            assert args[-1]==self.c_name(row['owner'].socket)
        else:raise RuntimeError('Unselected socket audit port: '+event)
    def http_origin(self,frame):
        connect=self.frame_for(self.create_connection,frame);caller=self.frame_for(self.http_connect,frame)
        assert connect is not None and caller is not None and len(self.servers)==1
        owner=caller.f_locals['self'];assert type(owner)is http.client.HTTPConnection and owner._create_connection is self.create_connection
        assert owner.host=='127.0.0.1'and owner.port==self.servers[0]['port'];return owner
    def reader_return(self,frame):
        owner,original=self.roles['actor-reader'];assert frame.f_code is original.__code__ and frame.f_globals is original.__globals__
        receiver=frame.f_locals['self'];assert isinstance(receiver,owner);fn=frame.f_locals['send']
        assert fn.__globals__ is original.__globals__ and fn.__code__ in original.__code__.co_consts
        assert fn.__closure__ and any(cell.cell_contents is receiver for cell in fn.__closure__)
        self.receivers.append(dict(owner=receiver,function=fn,code=fn.__code__,globals=fn.__globals__,closure=fn.__closure__,contents=tuple(cell.cell_contents for cell in fn.__closure__)))
    def http_return(self,frame):
        assert frame.f_code is self.http_connect.__code__ and frame.f_globals is self.http_connect.__globals__
        owner=frame.f_locals['self'];assert type(owner)is http.client.HTTPConnection and owner._create_connection is self.create_connection
        row=self.socket_row(owner.sock);assert row['role']=='http-client'and row['owner']is owner
        server=self.servers[0];self.socket_row(server['socket'])
        assert self.c_peer(owner.sock)==('127.0.0.1',server['port'])and self.c_name(server['socket'])==('127.0.0.1',server['port'])
        assert self.c_option(server['socket'],int(socket.SOL_SOCKET),int(socket.SO_REUSEPORT))==0
        row['actualConnectedPeer']=self.c_peer(owner.sock)
    def socket_return(self,frame):
        sock=frame.f_locals['self'];rows=[row for row in self.sockets if row['socket']is sock];assert len(rows)==1
        row=rows[0];assert row['identity']is None;row['identity']=self.socket_signature(sock)
    def server_return(self,frame):
        server=frame.f_locals['self'];rows=[row for row in self.sockets if row['role']=='http-listener'and row['owner']is server]
        assert len(rows)==1 and not self.servers and server.socket is rows[0]['socket']
        self.socket_row(server.socket);address=self.c_name(server.socket)
        assert address[0]=='127.0.0.1'and 0<address[1]<=65535
        assert self.c_option(server.socket,int(socket.SOL_SOCKET),int(socket.SO_REUSEPORT))==0
        self.servers.append(dict(server=server,socket=server.socket,port=address[1],identity=rows[0]['identity']))
    def thread_birth(self,frame):
        thread=frame.f_locals['self'];assert type(thread)is threading.Thread and thread not in self.threads
        target=thread._target
        if getattr(target,'__func__',None)is self.http_thread:
            assert len(self.servers)==1 and target.__self__ is self.servers[0]['server']and len(thread._args)==2
            sock,address=thread._args;row=self.socket_row(sock);assert row['role']=='http-accepted'and self.c_peer(sock)==address
        else:
            source=self.source_frame('observer',frame);owner=source.f_locals['self']
            assert len(self.servers)==1 and vars(owner).get('server')is self.servers[0]['server']
            assert any(target.__code__ is code for code in source.f_code.co_consts if hasattr(code,'co_code'))
            assert target.__globals__ is source.f_globals and any(cell.cell_contents is owner for cell in target.__closure__ or())
        self.threads.append(thread)
    def node_frames(self,frame,stage):
        self.check();ctor=self.frame_for(self.popen_init,frame);assert ctor is not None
        values=ctor.f_locals;process=values['self'];assert type(process)is self.popen
        original=self.frame_for(self.roles['vm'][1],frame)
        if original is not None:role='vm';owner=original.f_locals['self'];assert type(owner)is self.roles['vm'][0]
        else:
            original=self.source_frame('marker',frame);owner=original.f_locals['self'];role='marker-'+owner.scope.role
            assert role in('marker-primary','marker-actor')and owner.marker_program is None
        source='ios.self_tests.emote_script_vm_fixture'if role=='vm'else'ios.self_tests.emote_marker_domain_fixture'
        module,program=self.roles[source];assert vars(module)['PROGRAM']is program
        assert values['args']==['node','-e',program]
        for name,expected in dict(stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,shell=False,cwd=None,env=None,executable=None,
            preexec_fn=None,start_new_session=False,pass_fds=(),close_fds=True).items():assert values[name]==expected
        assert stage in('entry','normalized')
        requested=1 if role=='vm'else-1
        if stage=='entry':
            assert values['bufsize']==requested
        else:
            assert self.pending is not None and self.pending['process']is process and self.pending['role']==role and self.pending['owner']is owner
            assert self.pending['originalBufsize']==requested
            # Actual original CPython text-mode normalization, before io.open.
            assert values['bufsize']==-1 and values['line_buffering']is(role=='vm')
            assert process.text_mode is True
        assert values['process_group']in(None,-1)
        return ctor,process,role,owner
    def node_start(self,frame):
        assert self.pending is None;ctor,process,role,owner=self.node_frames(frame,'entry')
        assert not any(row['role']==role for row in self.nodes)and len(self.nodes)<3
        assert sum(row['process'].poll()is None for row in self.nodes)<2
        self.pending=dict(process=process,role=role,owner=owner,spawned=False,pipes=[],originalBufsize=ctor.f_locals['bufsize'])
    def node_pipe(self,args,frame):
        if type(args[0])is not int:return False
        ctor=self.frame_for(self.popen_init,frame)
        if ctor is None or args[0]!=ctor.f_locals.get('p2cwrite'):return False
        ctor,process,role,owner=self.node_frames(frame,'normalized');assert self.pending is not None and self.pending['process']is process
        assert args[0]==ctor.f_locals['p2cwrite']and args[1]in('w','wb')
        info=self.fstat(args[0]);assert stat.S_ISFIFO(info.st_mode);self.pending['pipes'].append((args[0],info.st_dev,info.st_ino));return True
    def node_spawn(self,args,frame):
        ctor,process,role,owner=self.node_frames(frame,'normalized');assert self.frame_for(self.execute_child,frame)is not None
        assert self.pending['process']is process and not self.pending['spawned']and len(self.pending['pipes'])==1
        assert args[0]=='node'and args[1]==ctor.f_locals['args']and args[2]is args[3]is None
        self.pending['spawned']=True
    def kernel_check(self):
        assert sys.modules['kernel']is self.kernel_module and self.proc is self.kernel_module.process and observe is self.kernel_module.observe and absent is self.kernel_module.absent and OwnedTerminal is self.kernel_module.OwnedTerminal
        assert all(getattr(self.kernel_module,name)is fn and fn.__code__ is code and fn.__globals__ is namespace is vars(self.kernel_module)and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and tuple((keywords or{}).items())==items for name,fn,code,namespace,defaults,keywords,items in self.kernel_controls)
        assert OwnedTerminal is self.terminal_class and OwnedTerminal.__init__ is self.terminal_init and self.terminal_init.__code__ is self.terminal_init_code and self.terminal_init.__globals__ is vars(self.kernel_module)
    def node_expected(self,row):
        self.kernel_check();held=[value for value in self.kernel_births if value[0]is row['process']];assert len(held)==1
        process,items,executable=held[0];identity=dict(items)
        assert process.pid==identity['pid']and row['birth']=={name:identity[name]for name in('pid','parent','group','startTicks')}|dict(executable=executable)
        return dict(identity,executable=executable)
    def node_return(self,frame):
        ctor,process,role,owner=self.node_frames(frame,'normalized');assert self.pending['process']is process and self.pending['spawned']
        self.kernel_check();original=observe(process.pid,parent=os.getpid(),group=os.getpgrp())
        self.kernel_observations.append(dict(role=role,phase='actual-constructor-return',observation=original))
        if original['kind']=='PRESENT_TERMINAL':raise OwnedTerminal(original)
        assert original['kind']=='PRESENT_LIVE'and original['after']['identity']['parent']==os.getpid()
        identity=original['after']['identity'];birth={name:identity[name]for name in('pid','parent','group','startTicks')}|dict(executable=original['executable'])
        assert birth['executable']==self.plan['node']['path']and not any(item[0]is process for item in self.kernel_births)
        self.kernel_births.append((process,tuple(identity.items()),original['executable']))
        row=self.pending;row['birth']=birth;row['originalKernelObservation']=original;self.nodes.append(row)
        folder=self.here/'node-raw'/role;folder.mkdir(mode=0o700);row['streams']=install_streams(process,folder);self.pending=None
    def communicate_row(self,fd,frame):
        actual=self.frame_for(self.communicate,frame)
        if actual is None:return None,None
        self.check()
        process=actual.f_locals['self'];rows=[row for row in self.nodes if row['process']is process];assert len(rows)==1
        stream=[row for row in rows[0]['streams']if row['fd']==fd];assert len(stream)==1
        row=stream[0];info=self.fstat(fd);original=row['stat'];assert(info.st_dev,info.st_ino)==(original.st_dev,original.st_ino)and stat.S_ISFIFO(info.st_mode)
        return rows[0],row
    def pipe_read(self,fd,size):
        row,stream=self.communicate_row(fd,sys._getframe(1));value=self.original_read(fd,size)
        if row is not None:assert stream['name']in('stdout','stderr');stream['buffer'].seen(value)
        return value
    def pipe_write(self,fd,data):
        row,stream=self.communicate_row(fd,sys._getframe(1))
        if row is None:return self.helper.mutate('write',fd,data)
        assert stream['name']=='stdin';count=self.original_write(fd,data);stream['buffer'].seen(bytes(data[:count]));return count
    def signal(self,args,frame):
        pid,sig=args;rows=[row for row in self.nodes if row['process'].pid==pid];assert len(rows)==1
        row=rows[0];expected=self.node_expected(row);assert self.proc(pid,expected=expected)==row['birth']and sig in(signal.SIGTERM,signal.SIGKILL)
        sender=self.frame_for(self.send_signal,frame);assert sender is not None and sender.f_locals['self']is row['process']
        assert self.frame_for(self.roles['vm'][0].close,frame)is not None or self.frame_for(subprocess.run,frame)is not None or self.frame_for(type(self).abort,frame)is not None
        row.setdefault('signals',[]).append(int(sig))
    def start(self,protected):
        self.helper=OwnedWrites(self.here,protected=protected);self.original=self.helper.original;self.original_items=self.helper.original_items;assert len(self.original_items)==27;self.ports={}
        # The unchanged E458 helper is intentionally not installed separately:
        # this narrow router owns the actual aliases and delegates normal paths.
        for name,original in self.original_items:
            if name=='close':continue
            if name=='write':port=self.pipe_write
            else:
                def port(*args,_name=name,**kwargs):
                    if _name=='open'and not args[1]&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):return self.original['open'](*args,**kwargs)
                    assert threading.current_thread()is self.main
                    if _name=='unlink'and kwargs.get('dir_fd')is not None:return self.palette_unlink(*args,**kwargs)
                    return self.helper.os_open(*args,**kwargs)if _name=='open'else self.helper.mutate(_name,*args,**kwargs)
            self.ports[name]=port;setattr(os,name,port)
        self.read_port=self.pipe_read;os.read=self.read_port
        for port in(*self.ports.values(),self.read_port):
            fn=getattr(port,'__func__',port);kw=fn.__kwdefaults__
            self.port_seals.append((fn,fn.__code__,fn.__closure__,tuple(cell.cell_contents for cell in fn.__closure__ or()),fn.__defaults__,kw,tuple((kw or{}).items())))
        self.installed=True
    def restore(self):
        control=list(self.helper.control_fds)
        for name,value in self.original_items:setattr(os,name,value)
        os.read=self.original_read;self.installed=False
        assert not control;self.helper.close()
        assert all(getattr(os,name)is value for name,value in self.original_items)and os.read is self.original_read
    def metadata_pin_caller(self,args,caller):
        # Exactly one known readonly router hop; no ancestor search. The
        # original pin's actual frame remains the immediate router caller.
        assert type(caller)is FrameType
        for name,fn,code,namespace in self.implementation:
            assert type(self).__dict__.get(name)is fn and fn.__code__ is code and fn.__globals__ is namespace
        value,mode,flags=args;expected=os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC
        assert type(value)in(str,bytes)and mode is None and flags==expected
        path=Path(os.fsdecode(value))
        if self.installed:
            port=self.ports['open'];assert os.open is port
            seals=[row for row in self.port_seals if row[0]is port];assert len(seals)==1
            fn,code,closure,contents,defaults,kw,items=seals[0]
            assert fn.__code__ is code and fn.__closure__ is closure and fn.__defaults__ is defaults and fn.__kwdefaults__ is kw
            assert len(closure or())==len(contents)and all(cell.cell_contents is value for cell,value in zip(closure or(),contents))
            assert tuple(kw or())==tuple(name for name,value in items)and all(kw[name]is value for name,value in items)
            assert caller.f_code is code and caller.f_globals is fn.__globals__
            assert caller.f_locals.get('self')is self and caller.f_locals.get('_name')=='open'
            assert caller.f_locals.get('args')==(path,expected)and caller.f_locals.get('kwargs')=={}
            caller=caller.f_back;assert type(caller)is FrameType
        else:assert os.open is self.original['open']
        assert self.pin.__code__ is self.pin_code and self.pin.__globals__ is self.pin_globals
        assert caller.f_code is self.pin_code and caller.f_globals is self.pin_globals and caller.f_locals.get('path')==path
        return caller
    def artifact_read(self,args,frame):
        value,mode,flags=args
        if type(value)not in(str,bytes):return
        if flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)or type(mode)is str and any(c in mode for c in'wa+'):return
        path=Path(os.fsdecode(value))
        if self.artifact_depth:
            assert self.artifact is not None and path==Path(self.artifact['path'])
            self.metadata_pin_caller(args,frame);return
        if self.artifact is None:
            if path.name!='Overte.ipa'or not path.is_relative_to(self.here/'temporary'):return
            original=self.source_frame('whole',frame);owner=original.f_locals['self'];cls=self.roles['whole'][0]
            assert type(owner)is cls and owner.ipa==path and path==owner.root/'candidate'/'Overte.ipa'and 'sha'not in vars(owner)
            roots=[row for row in self.tds if row['role']=='whole'];assert len(roots)==1 and owner.root==Path(roots[0]['path'])
            assert stat.S_IMODE(path.lstat().st_mode)==0o600
            self.artifact=dict(path=str(path),pin=None,selection='genuine Source3 constructor chosen synthetic IPA before first SHA/header consumer')
            self.artifact_depth=True
            try:self.artifact['pin']=self.pin(path)
            finally:self.artifact_depth=False
            self.helper.protected.add(path)
        elif path==Path(self.artifact['path']):
            self.artifact_depth=True
            try:assert self.pin(path)==self.artifact['pin']
            finally:self.artifact_depth=False
    def palette_return(self,frame):
        cls,fn,code,namespace=self.roles['palette']
        assert frame.f_code is code and frame.f_globals is namespace and self.palette is None
        owner=frame.f_locals['self'];assert type(owner)is cls and owner.fd==-1 and owner.directory>=0
        roots=[row for row in self.tds if row['role']=='pair'];assert len(roots)==2
        assert str(owner.root)==roots[0]['path']and owner.path==owner.root/'feature-ios-emote-palette.json'
        actual=self.fstat(owner.directory);path=owner.root.lstat()
        assert stat.S_ISDIR(actual.st_mode)and stat.S_IMODE(actual.st_mode)==0o700 and actual.st_uid==os.geteuid()
        identity=tuple(getattr(actual,k)for k in('st_dev','st_ino','st_mode','st_uid','st_gid'))
        assert identity==tuple(getattr(path,k)for k in('st_dev','st_ino','st_mode','st_uid','st_gid'))
        self.palette=dict(owner=owner,fd=owner.directory,parentIdentity=identity)
    def palette_unlink(self,path,*,dir_fd=None):
        self.check();assert self.palette is not None and self.palette_pending is None and not self.palette_unlink_rows
        owner=self.palette['owner'];cls=self.roles['palette'][0];fn=cls.command;frame=sys._getframe(1)
        # Exactly the installed unlink port, then the actual held original
        # command frame. No ancestor search/foreign dir_fd authority.
        assert frame.f_code is self.ports['unlink'].__code__ and frame.f_globals is self.ports['unlink'].__globals__
        caller=frame.f_back;assert type(caller)is FrameType and caller.f_code is fn.__code__ and caller.f_globals is fn.__globals__
        assert caller.f_locals.get('self')is owner and type(owner)is cls and path=='feature-ios-emote-palette.json'
        query=caller.f_locals['query'];assert query['operation']=='retire'and owner.issued is True and owner.retired is False and owner.unknown is False
        assert dir_fd==owner.directory==self.palette['fd']and owner.current()
        actual=self.fstat(dir_fd);assert tuple(getattr(actual,k)for k in('st_dev','st_ino','st_mode','st_uid','st_gid'))==self.palette['parentIdentity']
        target=owner.root/path;assert target not in self.helper.protected
        info=self.fstat(owner.fd);physical=target.lstat();assert stat.S_ISREG(info.st_mode)and info.st_nlink==1
        before=tuple(getattr(info,k)for k in('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns'))
        assert before==tuple(getattr(physical,k)for k in('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns'))
        self.palette_pending=(owner,path,dir_fd,fn,caller,info.st_dev,info.st_ino)
        try:result=self.original['unlink'](path,dir_fd=dir_fd)
        finally:self.palette_pending=None
        after=self.fstat(owner.fd);assert(after.st_dev,after.st_ino,after.st_nlink)==(info.st_dev,info.st_ino,0)
        assert not target.exists()and not target.is_symlink()
        self.palette_unlink_rows.append(dict(path=str(target),directoryFD=dir_fd,device=info.st_dev,inode=info.st_ino,afterNlink=after.st_nlink,originalReturnedNone=result is None))
        return result
    def palette_audit(self,event,args,frame):
        if self.palette_pending is None:return False
        owner,path,fd,fn,caller,device,inode=self.palette_pending
        assert event=='os.remove'and args==(path,fd)and frame.f_code is type(self).palette_unlink.__code__ and frame.f_globals is globals()
        assert frame.f_locals.get('self')is self and frame.f_locals.get('owner')is owner
        assert caller.f_code is fn.__code__ and caller.f_globals is fn.__globals__ and caller.f_locals.get('self')is owner
        assert self.fstat(owner.fd).st_ino==inode and self.fstat(owner.fd).st_dev==device
        return True
    def audit(self,event,args,frame):
        if self.palette_audit(event,args,frame):return
        if event=='open':self.artifact_read(args,frame)
        if event.startswith('socket.'):return self.event_socket(event,args,frame)
        if event=='subprocess.Popen':return self.node_spawn(args,frame)
        if event=='os.kill':return self.signal(args,frame)
        if event=='open'and type(args[0])is int and(type(args[1])is str and any(c in args[1]for c in'wa+')):
            if self.node_pipe(args,frame):return
        if event=='open':
            value,mode,flags=args
            if not flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)and not(type(mode)is str and any(c in mode for c in'wa+')):return
        assert threading.current_thread()is self.main,'No filesystem writes from the readonly HTTP handler threads'
        return self.helper.audit(event,args,frame)
    def abort(self):
        # Failure-only rescue; genuine standard callbacks are attempted first.
        # New observations never replace original constructor/signal authority.
        self.kernel_check();problems=[];pending=self.pending
        rows=list(self.nodes)
        if pending is not None and not any(row is pending for row in rows):rows.append(pending)
        for row in rows:
            process=row['process'];known=[value for value in self.kernel_births if value[0]is process]
            assert type(process)is self.popen
            try:
                if getattr(process,'pid',None)is not None and process._child_created:
                    # poll/wait belong only to this real creator-held Popen;
                    # the watcher itself never reaps, signals or claims absence.
                    if process.poll()is None:
                        expected=self.node_expected(row)if known else None
                        actual=observe(process.pid,expected=expected,parent=os.getpid(),group=os.getpgrp())
                        self.kernel_observations.append(dict(role=row['role'],phase='failure-rescue',observation=actual))
                        self.partial_drains.append(dict(role=row['role'],originalBirth=row.get('birth'),observation=actual,standardCleanupQualified=False))
                        if actual['kind']=='PRESENT_LIVE'and known:
                            try:process.kill() # os.kill audit repeats strict original live binding.
                            except OwnedTerminal as terminal:
                                self.kernel_observations.append(dict(role=row['role'],phase='signal-unwind-terminal',observation=terminal.observation))
                        # Terminal/missing/unbound creator only receives original
                        # stdin EOF and wait. No zombie or discovery signal grant.
                        stream=getattr(process,'stdin',None)
                        if stream is not None and not stream.closed:stream.close()
                        process.wait(timeout=5)
            except BaseException as original:
                problems.append((original,dict(role=row['role'],phase='original-rescue-failure',traceback=traceback.format_exc())))
                # Even unknown live exe errors keep their original failure,
                # while independent safe EOF/wait is attempted on the SAME owner.
                try:
                    stream=getattr(process,'stdin',None)
                    if stream is not None and not stream.closed:stream.close()
                    if getattr(process,'pid',None)is not None and process._child_created:process.wait(timeout=5)
                except BaseException as secondary:problems.append((secondary,dict(role=row['role'],phase='secondary-owner-wait',traceback=traceback.format_exc())))
            finally:
                for name in('stdin','stdout','stderr'):
                    try:
                        stream=getattr(process,name,None)
                        if stream is not None and not stream.closed:stream.close()
                    except BaseException as secondary:problems.append((secondary,dict(role=row['role'],phase='secondary-stream-close',stream=name,traceback=traceback.format_exc())))
        self.abort_problems=[row for error,row in problems]
        if pending is not None:self.partial_drains.append(dict(role=pending['role'],constructorReturnQualified=False,standardCleanupQualified=False))
        if problems:raise problems[0][0]
    def finish(self):
        self.check();self.kernel_check()
        assert self.pending is None and not self.partial_drains and len(self.nodes)==3
        assert self.artifact is not None and self.pin(self.artifact['path'])==self.artifact['pin']
        assert {row['role']for row in self.nodes}=={'vm','marker-primary','marker-actor'}
        assert all(row['process'].poll()==0 and absent(row['process'].pid) and not row.get('signals')
            and all(stream['text'].closed and stream['buffer'].closed and stream['buffer'].log.closed for stream in row['streams'])for row in self.nodes)
        assert len(self.tds)==5 and len(self.servers)==1 and all(not t.is_alive()for t in self.threads)
        assert self.palette is not None and len(self.palette_unlink_rows)==1 and self.palette_pending is None
        assert self.palette['owner'].fd==self.palette['owner'].directory==-1
        assert all(self.c_fileno(row['socket'])==-1 for row in self.sockets)
        return dict(NodeExecutions=3,nodeRoles=[row['role']for row in self.nodes],HTTPListeners=1,UDPReceivers=1,UDPSenders=1,TLSExecutions=0,
            realSDKExecutions=0,temporaryDirectoryBirths=5,allOwnSocketsClosed=True,allOwnThreadsStopped=True,standardCleanupQualified=True,actualKernelObservations=list(self.kernel_observations),immutableKernelBirths=[dict(identity=dict(items),executable=executable)for process,items,executable in self.kernel_births])
