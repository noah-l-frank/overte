"""One frozen capture/Page/WDA vertical component selection; no process/network/device API."""
from pathlib import Path
import importlib.abc,importlib.util,json,os,signal,sys,tempfile,threading,unittest
from types import SimpleNamespace
from metadata import HERE,REPO,save,sha,pin,proc,processes,fds,census
plan=json.loads((HERE/'plan.json').read_text());run=Path(os.environ['SNAPSHOT_REVIEW_RUN'])
assert run.resolve(strict=True)==run and run.is_relative_to(HERE/'runs') and sys.dont_write_bytecode
temporary=run/'temporary';assert temporary.is_dir()and not list(temporary.iterdir())
approved=json.loads((run/'source-before.json').read_text());baseline_fds=fds();baseline_threads=set(threading.enumerate())
identity=proc(os.getpid());assert identity['session']==identity['group']
original_path=list(sys.path);original_meta=list(sys.meta_path);refusals=[]
forbidden=('pymobiledevice3','tidevice','pyidevice','zeroconf','selenium','playwright')
def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Vendor SDK/browser import refused')
    if event=='subprocess.Popen'or event.startswith('socket.')or event in('os.system','os.exec','os.fork','os.forkpty'):
        refusals.append(event);raise RuntimeError('No network/process authority in Snapshot pure component selection')
    if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
        path=Path(os.fsdecode(args[0])).absolute();flags=args[2]
        writing=isinstance(flags,int)and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if writing and not path.resolve().is_relative_to(run):refusals.append('foreign-write');raise RuntimeError('Writes confined to new owned run')
    if event in('os.mkdir','os.remove','os.rmdir','os.chmod','os.rename','os.link','os.symlink'):
        for value in args[:2]if event in('os.rename','os.link','os.symlink')else args[:1]:
            if isinstance(value,(str,bytes,os.PathLike))and not Path(os.fsdecode(value)).absolute().resolve().is_relative_to(run):
                refusals.append('foreign-mutation');raise RuntimeError('Old originals and all source are read-only')
sys.addaudithook(audit)
class Overlay(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        for row in plan['overlays']:
            if name==row['module']:
                source=REPO/row['path'];assert sha(source)==row['sha256']
                return importlib.util.spec_from_file_location(name,source)
sys.meta_path.insert(0,Overlay())
sys.path[:]=[str(REPO/p)for p in ('tests/device','tests/device/self_tests','tests/device/ios/self_tests')]+[
    p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
from ios.self_tests.retained_host_roots import retain_owned_root
import ios.self_tests.test_ios_snapshot_resume_cursor as module
real_td=tempfile.TemporaryDirectory;roots=[];objects=[]
class RetainedTemporaryDirectory(real_td):
    def __init__(self,*args,**kwargs):
        assert kwargs.get('dir') is None;kwargs['dir']=temporary
        super().__init__(*args,**kwargs);root=Path(self.name)
        assert root.parent==temporary and root.stat().st_mode&0o077==0
        retain_owned_root(self,expected_root=root);roots.append(str(root));objects.append(self)
        save(run/('created-root-'+str(len(roots))+'.json'),dict(root=str(root)))
old_temporary_directory=tempfile.TemporaryDirectory;tempfile.TemporaryDirectory=RetainedTemporaryDirectory
loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['caseIds'])
def flatten(value):
    if isinstance(value,unittest.TestSuite):
        for child in value:yield from flatten(child)
    else:yield value
cases=list(flatten(suite));assert not loader.errors and [c.id()for c in cases]==plan['caseIds']and len(cases)==4
save(run/'selected-ids.json',[c.id()for c in cases]);result=None;returned=False;cleanup=[]
def stop(*_args):raise KeyboardInterrupt('Fixed supervisor stop')
signal.signal(signal.SIGTERM,stop)
try:
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite);returned=True
finally:
    # Python TestCase.run may bypass cleanup on BaseException. Invoke ONLY the
    # actual still-registered original cleanup chain, retaining its outcome.
    for case in cases:
        prior=case._outcome;drain=unittest.TestResult();pending=len(case._cleanups)
        try:
            if pending:case._outcome=unittest.case._Outcome(drain);unittest.TestCase.doCleanups(case)
        finally:case._outcome=prior
        cleanup.append(dict(id=case.id(),pendingBefore=pending,remaining=len(case._cleanups),errors=[dict(testId=t.id(),traceback=trace)for t,trace in drain.errors],failures=[dict(testId=t.id(),traceback=trace)for t,trace in drain.failures]))
    tempfile.TemporaryDirectory=old_temporary_directory
    origins={}
    for name,loaded in tuple(sys.modules.items()):
        value=getattr(loaded,'__file__',None)
        if value:
            path=Path(value).resolve()
            if path.is_relative_to(REPO):
                assert str(path)in approved and pin(path)==approved[str(path)],name
                origins[name]=str(path)
    for row in plan['overlays']:
        assert origins.get(row['module'])==str(REPO/row['path']),row['module']
    sys.path[:]=original_path;sys.meta_path[:]=original_meta
    assert not[name for name in sys.modules if name.split('.')[0]in forbidden]
    new_threads=[t.name for t in threading.enumerate()if t not in baseline_threads and t.is_alive()]
    remaining=[p for p in processes(identity['session'])if p['pid']not in(identity['pid'],identity['parentPid'])]
    fd_after=fds();first=census(temporary);second=census(temporary)
    clean=returned and result is not None and result.wasSuccessful()and result.testsRun==4 and not result.skipped
    clean=clean and len(roots)==plan['expectedTD'] and not refusals and not new_threads and not remaining and fd_after==baseline_fds and first==second
    clean=clean and all(not row['remaining']and not row['errors']and not row['failures']for row in cleanup)
    save(run/'originals-first.json',first);save(run/'originals-second.json',second)
    save(run/'selected-result.json',dict(successful=clean,testsRun=None if result is None else result.testsRun,
        selectedIds=[c.id()for c in cases],retainedRoots=roots,actualStandardRunReturned=returned,cleanup=cleanup,
        fdBefore=baseline_fds,fdAfter=fd_after,newThreads=new_threads,remainingOwned=remaining,refusals=refusals,
        importedSourceOrigins=origins,twoOriginalCensusesEqual=first==second,wholeSnapshotsQualified=False,nativeCompiled=False,devicesTested=False))
    print('ACTUAL_COMPONENT_TERMINAL',clean,flush=True)
if not clean:raise SystemExit(1)
