"""Finite genuine Combined-flow counters; all lower native/render/SDK is model.

No completed destination DTO is injected. Every positive first executes the
actual old Upload/Photos/Share/cleanup/return constructors and coordinators.
"""
from copy import deepcopy
import unittest
from unittest.mock import patch
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.snapshot_capture_phase_temporal_png_join import SnapshotCapturePhaseTemporalPNGJoin
from ios.self_tests import test_ios_snapshot_page_return as old_return
from ios.self_tests.snapshot_capture_png_photos_domain import CapturePNGPhotosReturnFlow


class MissingAfterFlow(CapturePNGPhotosReturnFlow):emit_after=False
class LateBeforeFlow(CapturePNGPhotosReturnFlow):before_after_prepare=True


class SnapshotCapturePNGPhotosJoinTests(unittest.TestCase):
    def prepared(self,flow=CapturePNGPhotosReturnFlow):
        with patch.object(old_return,'PageReturnFlow',flow):domain,host=old_return.SnapshotPageReturnOwnerTests.prepared(self)
        with domain.return_owner()as returned:returned.restore()
        return domain,returned,host
    def test_real_same_capture_actor_baseline_photos_result2_join_keeps_all_end_duties(self):
        d,returned,host=self.prepared();original=(host.stat().st_ino,host.read_bytes())
        with d.original_join(returned)as joined:
            literal=joined.photos_journey.proof();value=joined.proof()
            self.assertEqual(literal,value['literalResult2']);self.assertEqual(2,literal['snapshotCombinedJourneyResultVersion'])
            self.assertTrue(value['exactCaptureArtifactPhaseAndPhotosOriginalsJoined']);self.assertEqual('c'*32,value['captureTicket'])
            self.assertEqual('a'*32,joined.photos_journey.journey.returned.page.state['ticket'])
            self.assertTrue(literal['photosSDKRetirementRequired']);self.assertTrue(literal['independentActorSceneAndRenderedReviewRequired']);self.assertTrue(literal['wholeFeatureRequired'])
            self.assertFalse(value['processOrSDKEndEstablished']or value['wholeQualified']or value['nativeQualified'])
        self.assertEqual(original,(host.stat().st_ino,host.read_bytes()));self.assertFalse(d.photos.library)
        self.assertEqual((2,1,1,1,1),(d.main.capture_count,d.main.cancel_count,d.main.png_count,d.main.upload_count,d.share_count))
        self.assertEqual((1,1,1,1),(d.photos.save_count,d.photos.helper.read_count,d.photos.helper.delete_count,d.photos.helper.retire_count))
        self.assertEqual(2,len(d.page.pixel.queries));self.assertEqual(2,len(d.page.pixel.render_events))
    def test_historical_join_reopens_originals_without_input_query_sdk_write_or_retiming(self):
        d,returned,host=self.prepared()
        with d.original_join(returned)as joined:first=joined.proof()
        before=(host.stat().st_ino,host.read_bytes());commands=deepcopy(d.main.commands);queries=deepcopy(d.page.pixel.queries)
        with d.original_join(returned)as joined:
            with patch.object(PrivateFeatureState,'write',side_effect=AssertionError('Historical join wrote state')),patch.object(d.photos.helper,'execute',side_effect=AssertionError('Historical Photos SDK')),patch.object(d.archive,'execute',side_effect=AssertionError('Historical Archive SDK')):
                self.assertEqual(first,joined.proof())
        self.assertEqual(commands,d.main.commands);self.assertEqual(queries,d.page.pixel.queries);self.assertEqual(before,(host.stat().st_ino,host.read_bytes()))
    def test_genuine_before_observed_after_prepare_cannot_invert_saved_baseline_cut(self):
        d,returned,_host=self.prepared(LateBeforeFlow)
        with d.original_join(returned)as joined:
            with self.assertRaises((NativeUIError,ValueError)):joined.proof()
    def test_missing_actual_actor_after_original_cannot_be_filled_by_photos_success(self):
        d,returned,_host=self.prepared(MissingAfterFlow);self.assertEqual(1,len(d.page.pixel.queries))
        with self.assertRaises((NativeUIError,ValueError,OSError)):
            with d.original_join(returned)as joined:joined.proof()
        self.assertEqual((1,1),(d.main.upload_count,d.photos.save_count))
    def test_reversed_genuine_actor_owners_refuse_without_issuing_another_observation(self):
        d,returned,_host=self.prepared();queries=deepcopy(d.page.pixel.queries)
        with d.original_join(returned)as joined:
            temporal=joined.temporal
            with self.assertRaises((NativeUIError,ValueError)):SnapshotCapturePhaseTemporalPNGJoin(temporal.after,temporal.before)
        self.assertEqual(queries,d.page.pixel.queries)
    def test_foreign_genuine_capture_graph_cannot_borrow_result2_destination_history(self):
        from ios.adapters.snapshot_temporal_png_photos_join import SnapshotTemporalPNGPhotosJoin
        first,r1,_h1=self.prepared();second,r2,_h2=self.prepared()
        commands=(deepcopy(first.main.commands),deepcopy(second.main.commands))
        with first.original_join(r1)as a,second.original_join(r2)as b:
            foreign=SnapshotTemporalPNGPhotosJoin(a.photos_journey,b.temporal)
            with self.assertRaises((NativeUIError,ValueError)):foreign.proof()
        self.assertEqual(commands,(first.main.commands,second.main.commands))
