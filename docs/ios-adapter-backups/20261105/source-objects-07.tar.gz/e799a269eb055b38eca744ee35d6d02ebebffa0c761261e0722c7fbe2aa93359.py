"""Exactly three real Moving manager/file constructor counters; lower native/SDK are models."""
from pathlib import Path
import builtins,hashlib,importlib.abc,importlib.util,io,json,os,signal,stat,sys,tempfile,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert sys.flags.no_site==1, 'Explicit no-site startup required'
assert len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert len(plan['cases'])==len(set(plan['cases']))==3 and plan['wallSeconds']==30 and plan['killGraceSeconds']==5
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    path=Path(path);a=path.lstat();assert path.resolve(strict=True)==path and stat.S_ISREG(a.st_mode)
    raw=path.read_bytes();assert all(getattr(a,k)==getattr(path.lstat(),k)for k in FIELDS)
    return dict(stat=[getattr(a,k)for k in FIELDS],sha256=hashlib.sha256(raw).hexdigest())
def fds():
    out={}
    for path in Path('/proc/self/fd').iterdir():
        try:v=path.stat();out[path.name]=dict(target=os.readlink(path),device=v.st_dev,inode=v.st_ino,mode=v.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return out
def children():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
def census(root):
    out={}
    for path in(root,*sorted(root.rglob('*'))):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):row=dict(stat=[getattr(info,k)for k in FIELDS],namespace=sorted(p.name for p in path.iterdir()))
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        out[str(path.relative_to(root))]=row
    return out
assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
original_path=tuple(sys.path);original_meta=tuple(sys.meta_path);loaded={};td_callers=[]
assert not any(name in sys.modules for name in(*plan['modules'],*plan['thirdPartyModules']))
sys.path[:]=[p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespaces'],*plan['thirdPartyModules'])}
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright')
class Loader(importlib.abc.Loader):
    def __init__(self,name,row):self.name,self.row=name,row
    def create_module(self,spec):return None
    def exec_module(self,module):
        path=Path(self.row['path']);assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
        module.__file__=str(path)
        if self.row.get('package'):module.__path__=[str(path.parent)]
        exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__)
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)];loaded[self.name]=str(path)
        if self.name=='ios.self_tests.test_ios_installed_adapter':
            cls=vars(module)['InstalledAdapterTests'];setup=cls.__dict__['setUp']
            td_callers.append((cls,setup,setup.__code__,setup.__globals__))
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in forbidden:raise ImportError('Native SDK/browser package refused')
        row=plan['modules'].get(name)or plan['thirdPartyModules'].get(name)
        if row is not None:
            source=Path(row['path']);assert pin(source)==plan['sourceAndBinaryPins'][str(source)]
            if row.get('kind')=='extension':return importlib.util.spec_from_file_location(name,source)
            return importlib.util.spec_from_loader(name,Loader(name,row),is_package=row.get('package',False))
        if name in plan['namespaces']:
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=[plan['namespaces'][name]];return spec
        if name.split('.')[0]in tops:raise ImportError('Unmapped project/third-party import: '+name)
        spec=importlib.machinery.PathFinder.find_spec(name,path)
        if spec is not None and spec.origin not in(None,'built-in','frozen'):
            source=Path(spec.origin).resolve(strict=True);std=Path(os.__file__).resolve(strict=True).parent
            assert source.is_relative_to(std)and not any(p in source.parts for p in('site-packages','dist-packages'))
            assert str(source)in plan['sourceAndBinaryPins']and pin(source)==plan['sourceAndBinaryPins'][str(source)]
            return spec
        if spec is not None and spec.origin is None:
            std=Path(os.__file__).resolve(strict=True).parent
            assert spec.submodule_search_locations
            real_namespaces=tuple(Path(p).resolve(strict=True)for p in spec.submodule_search_locations)
            assert all(real.is_relative_to(std)and not any(x in real.parts for x in('site-packages','dist-packages'))for real in real_namespaces)
            return spec
        return spec
finder=Finder();sys.meta_path.insert(0,finder)
TOYS=HERE/'own-toys';RECEIPTS=HERE/'child-receipts'
assert TOYS.is_dir()and RECEIPTS.is_dir()and not any(TOYS.iterdir())and not any(RECEIPTS.iterdir())
assert os.environ['TMPDIR']==str(TOYS)and Path(tempfile.gettempdir())==TOYS
from owned_write_boundary import OwnedWrites
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={n:getattr(os,n)for n in ports if hasattr(os,n)};original_io=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
original_cleanup=unittest.TestCase.doCleanups;original_td=tempfile.TemporaryDirectory;original_time=time.time
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):
    path=Path(os.readlink('/proc/self/fd/'+str(fd)));assert path.resolve(strict=True)==path and path.is_relative_to(HERE);protected.append(path)
boundary=OwnedWrites(HERE,protected=protected)
def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Native SDK/browser import refused')
    if event.startswith('socket.')or event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('No real network/process/native/signal port in Moving navigation models')
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if relevant:boundary.audit(event,args,sys._getframe(1))
boundary.install();sys.addaudithook(audit)
from ios.self_tests.retained_host_roots import retain_owned_root
retained=[];retained_objects=[];cleanup_calls=[]
class RetainedTemporaryDirectory(original_td):
    def __init__(self,*args,**kwargs):
        frame=sys._getframe(1)
        matches=[(cls,setup,code,namespace)for cls,setup,code,namespace in td_callers
            if frame.f_code is code and frame.f_globals is namespace and type(frame.f_locals.get('self'))is cls]
        assert len(matches)==1 and not args and not kwargs,'Only the genuine InstalledAdapterTests constructor TD'
        cls,setup,code,namespace=matches[0]
        assert cls.__dict__['setUp']is setup and setup.__code__ is code and setup.__globals__ is namespace
        super().__init__(dir=TOYS)
        root=Path(self.name);assert root.parent==TOYS and root.resolve(strict=True)==root
        retain_owned_root(self,expected_root=root);info=root.lstat();retained_objects.append(self)
        retained.append(dict(path=str(root),device=info.st_dev,inode=info.st_ino,
            actualConstructor=cls.__module__+'.'+cls.__qualname__,actualSetupFile=code.co_filename))
def observe_original_cleanup(case):
    before=len(case._cleanups);returned=original_cleanup(case)
    cleanup_calls.append(dict(case=type(case).__module__+'.'+type(case).__qualname__,pendingBefore=before,
        remaining=len(case._cleanups),originalReturned=returned))
    return returned
unittest.TestCase.doCleanups=observe_original_cleanup;tempfile.TemporaryDirectory=RetainedTemporaryDirectory

def save(name,body):
    p=RECEIPTS/name
    with p.open('x')as stream:stream.write(json.dumps(body,indent=2,sort_keys=True)+'\n')
    p.chmod(0o600)
fd_before=fds();threads_before=tuple(threading.enumerate());children_before=children()
case_receipts=[];selected=[];result=None;fatal=None;cleanup_rows=[];cleanup_ok=True
class Result(unittest.TextTestResult):
    def startTest(self,test):
        assert original_methods_unchanged()and tools_unchanged()
        self.before=(fds(),tuple(threading.enumerate()),children(),len(cleanup_calls),len(retained));super().startTest(test)
    def stopTest(self,test):
        fd,threads,kernel,cleanup_count,roots=self.before
        row=dict(id=test.id(),standardStopAfterCleanup=True,originalMethodsUnchanged=original_methods_unchanged(),monitorSlotsUnchanged=tools_unchanged(),remainingStandardCleanups=len(test._cleanups),
            fdUnchanged=fds()==fd,threadsUnchanged=tuple(threading.enumerate())==threads,kernelChildrenUnchanged=children()==kernel,
            actualNestedCleanupCalls=deepcopy_rows(cleanup_calls[cleanup_count:]),newTemporaryDirectories=len(retained)-roots)
        case_receipts.append(row);save('standard-case-'+str(len(case_receipts))+'.json',row);super().stopTest(test)
def deepcopy_rows(rows):return json.loads(json.dumps(rows))
method_seals=[]
def bind_original_methods():
    declarations=(
        ('adapters.normal_script_manager','NormalScriptManager',('open','file_picker_open','file_picker_cancel','close','mark','require_current')),
        ('adapters.token_script_ui','TokenScriptUI',('capture','activate','manager_visible','wait_manager','open_manager','open_tablet','close_tablet','wait_tablet_absent','release')),
        ('adapters.token_script_file_ui','TokenScriptFilePicker',('__init__','capture','open','cancel','wait')),
        ('adapters.normal_ui','NativeUI',('__init__','click','click_with_token','_request','_check','release_actions')),
        ('ios.adapters.normal_scripts','IOSScriptIO',('__init__','capture','activate','tablet','release')),
        ('adapters.native_script_files','NativeScriptFiles',('__init__','request')),
        ('adapters.native_script_files','OwnedScriptFiles',('__init__','stage','verify','release','owned')),
        ('lifecycle_moving_raw_ui','RawMovingUI',('__init__','controls','token','decorate','activate','call')),
        ('source6_lifecycle_moving_raw_ui','RawMovingUI',('__init__','controls','token','decorate','activate','call')),
        ('lifecycle_moving_raw_files','RawMovingScriptFiles',('__init__','request')))
    for module_name,class_name,names in declarations:
        module=sys.modules[module_name];cls=vars(module)[class_name]
        path=Path(vars(module)['__file__']);assert str(path)in plan['sourceAndBinaryPins']and pin(path)==plan['sourceAndBinaryPins'][str(path)]
        # Pin the full actual class-method table, including static control/
        # selector helpers transitively called by the explicit recipe methods.
        for name,member in cls.__dict__.items():
            function=member.__func__ if type(member)in(classmethod,staticmethod)else member
            if hasattr(function,'__code__'):
                method_seals.append((module,module_name,cls,class_name,name,member,function,function.__code__,function.__globals__))
def original_methods_unchanged():
    for module,module_name,cls,class_name,name,member,function,code,namespace in method_seals:
        assert sys.modules.get(module_name)is module and vars(module)[class_name]is cls and cls.__dict__[name]is member
        assert function.__code__ is code and function.__globals__ is namespace and namespace is vars(module)
    return True
monitor=sys.monitoring
monitor_ports=tuple((name,getattr(monitor,name))for name in('get_tool','get_events','get_local_events','set_local_events','register_callback','use_tool_id','free_tool_id'))
monitor_before=tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6))
def tools_unchanged():
    return (all(getattr(monitor,name)is port for name,port in monitor_ports)
        and monitor_before==tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6)))

original_term=signal.getsignal(signal.SIGTERM)
def interrupted(*_args):raise KeyboardInterrupt('Fixed30-second Moving navigation model boundary')
signal.signal(signal.SIGTERM,interrupted)
try:
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(suite):
        if isinstance(suite,unittest.TestSuite):
            for item in suite:yield from flatten(item)
        else:yield suite
    selected=list(flatten(suite));ids=[case.id()for case in selected]
    save('actual-selection.json',dict(ids=ids,loaderErrors=loader.errors));assert not loader.errors and ids==plan['cases']and suite.countTestCases()==3
    bind_original_methods();assert original_methods_unchanged()and tools_unchanged()
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    try:
        for case in selected:
            pending=len(case._cleanups);old=case._outcome;drain=unittest.TestResult();success=True
            try:
                if pending:case._outcome=unittest.case._Outcome(drain);success=observe_original_cleanup(case)
            except BaseException:success=False;print(traceback.format_exc(),flush=True)
            finally:case._outcome=old
            row=dict(id=case.id(),pendingBeforeOuter=pending,remaining=len(case._cleanups),success=success,
                errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],failures=[dict(id=t.id(),traceback=text)for t,text in drain.failures]);cleanup_rows.append(row)
            if not success or case._cleanups or drain.errors or drain.failures:cleanup_ok=False
        for row in retained:
            root=Path(row['path']);info=root.lstat();assert root.parent==TOYS and(root.stat().st_dev,root.stat().st_ino)==(row['device'],row['inode'])
        nested_ok=all(row['originalReturned']is True and row['remaining']==0 for row in cleanup_calls)
        first=census(TOYS);second=census(TOYS)
        after={p:pin(p)for p in plan['sourceAndBinaryPins']}
        passed=fatal is None and result is not None and result.testsRun==3 and result.wasSuccessful()and not result.skipped and cleanup_ok and nested_ok
        passed=passed and len(retained)==3 and len(case_receipts)==3 and all(row['remainingStandardCleanups']==0 and row['fdUnchanged']and row['threadsUnchanged']and row['kernelChildrenUnchanged']and row['newTemporaryDirectories']==1 and row['originalMethodsUnchanged']and row['monitorSlotsUnchanged']for row in case_receipts)
        passed=passed and after==plan['sourceAndBinaryPins']and fd_before==fds()and threads_before==tuple(threading.enumerate())and children_before==children()and first==second
        source_origins={}
        for name,expected in plan['subjectOriginModules'].items():
            module=sys.modules.get(name);actual=None if module is None else getattr(module,'__file__',None)
            source_origins[name]=dict(actualModulePresent=module is not None,actualModuleFile=actual,
                actualLoaderExecutedPath=loaded.get(name),expectedPath=expected['path'],expectedSha256=expected['sha256'],
                exactOriginMatched=actual==loaded.get(name)==expected['path'])
        origins_ok=len(source_origins)==plan['subjectOriginCount']==5 and all(row['exactOriginMatched']for row in source_origins.values())
        passed=passed and origins_ok and len(td_callers)==1 and original_methods_unchanged()and tools_unchanged()
        save('actual-source-model-origins.json',dict(subjectOrigins=source_origins,
            allFiveActualOriginsEstablished=origins_ok,actualExecutedOrigins=loaded))
        save('actual-toy-first.json',first);save('actual-toy-second.json',second);save('outer-cleanup.json',dict(success=cleanup_ok,cases=cleanup_rows,nestedActualCalls=cleanup_calls,nestedActualCleanupSucceeded=nested_ok))
        save('report.json',dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=None if result is None else result.testsRun,
            actualCaseReceipts=len(case_receipts),fatal=fatal,cleanupEstablished=cleanup_ok and nested_ok,
            retainedTemporaryDirectories=retained,temporaryDirectoryAbsenceClaimed=False,fdUnchanged=fd_before==fds(),
            threadsUnchanged=threads_before==tuple(threading.enumerate()),kernelChildrenUnchanged=children_before==children(),
            pinsUnchanged=after==plan['sourceAndBinaryPins'],twoToyCensusesEqual=first==second,
            declaredModelNativeObservationsAllowed=True,realNetwork=False,NodeExecutions=0,SDKExecutions=0,nativeQualified=False,wholeQualified=False))
    finally:
        signal.signal(signal.SIGTERM,original_term)
        tempfile.TemporaryDirectory=original_td;unittest.TestCase.doCleanups=original_cleanup
        tools_restored=tempfile.TemporaryDirectory is original_td and unittest.TestCase.doCleanups is original_cleanup and time.time is original_time and tools_unchanged()
        boundary.restore()
        restored=all(getattr(os,n)is v for n,v in original_ports.items())and original_io==(io.open,builtins.open)
        dup_restored=original_dup==(os.dup,os.dup2)
        with boundary.original_io(RECEIPTS/'actual-port-restoration.json','x')as stream:stream.write(json.dumps(dict(restored=restored,count=len(original_ports),
            controlDescriptors=sorted(boundary.control_fds),dupPortsRestored=dup_restored,toolsRestored=tools_restored))+'\n')
        boundary.close();sys.meta_path[:]=original_meta;sys.path[:]=original_path
raise SystemExit(0 if passed and restored and tools_restored and dup_restored else 1)
