"""Exact fresh-process cold4 OR existing metadata guards6; no End qualification."""
from pathlib import Path
import json,os,stat,sys,tempfile,threading,types,unittest
from importlib.machinery import PathFinder
from run_metadata import HERE,REPO,pin,proc,publication,save,sha,validate_frozen,sources
assert len(sys.argv)==2 and sys.argv[1] in ('small13',)
kind=sys.argv[1];plan=validate_frozen();selected=plan['suites'][kind];publication()
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/'publication-ready-source-map.json';assert ready.is_file(),'Root must refresh after source publication'
runroot=Path(os.environ['OVERTE_TABLET_OWNED_ROOT_RUN']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs'/kind) and runroot!=HERE/'runs'/kind
info=runroot.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
temporary=Path(os.environ['TMPDIR']).resolve(strict=True)
assert temporary==runroot/'temporary' and Path(tempfile.gettempdir())==temporary
info=temporary.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
assert not any(temporary.iterdir()) and not (runroot/'selected-result.json').exists()
save(runroot/'runner-process-binding.json',proc(os.getpid()))
config=json.loads((HERE/'source-root-final-map.json').read_text())
approved=json.loads(ready.read_text());assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
assert set(approved['modulePins'])==set(config['modules'])
all_sources_before=sources(plan);assert all_sources_before==approved['sourcePins'],'Actual full Source map differs before imports'
config['modules']=approved['modulePins']
sourcepaths={REPO/row['path'] for row in config['modules'].values()}
sourcepaths.update(HERE/name for name in ('run-selected.py','run_metadata.py','suite-plan.json','source-root-final-map.json','expected-publication.json','expected-registry-own-keys.json','freeze.json','publication-ready-source-map.json'))
source_before={str(path):pin(path) for path in sourcepaths}

def spec_without_import(name):
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:assert search is not None,name
    return spec

def preimport_source_roots():
    top_names={name.split('.')[0] for name in config['packageRoots']}
    assert not any(name.split('.')[0] in top_names for name in sys.modules),'Target imported before source preflight'
    expected=[str(REPO/name) for name in config['orderedRoots']];remaining=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==REPO or REPO in path.parents:continue
        if str(path) not in remaining:remaining.append(str(path))
    sys.path[:]=expected+remaining
    for name,relative in config['packageRoots'].items():
        spec=spec_without_import(name)
        assert [str(Path(path).resolve()) for path in spec.submodule_search_locations or ()]==[str(REPO/relative)],name
    actual={}
    for name,row in config['modules'].items():
        spec=spec_without_import(name);assert spec.origin is not None,name
        path=Path(spec.origin).resolve(strict=True)
        assert path==REPO/row['path'] and sha(path)==row['sha256'],name
        actual[name]=str(path)
    save(runroot/'preimport-source-map-actual.json',dict(orderedRoots=expected,modules=actual))
threads_before=set(threading.enumerate())
# Audit is actually installed BEFORE any target import, not a plan-only claim.
def audit(event,args):
    if event=='import':
        name=args[0]
        assert not any(name==bad or name.startswith(bad+'.') for bad in ('pymobiledevice3','tidevice','pyidevice','zeroconf')),'SDK import prohibited'
    elif event=='subprocess.Popen':
        executable,arguments=args[0],args[1]
        node=Path(os.fsdecode(executable)).name=='node'
        metadata_rg=(Path(os.fsdecode(executable)).name=='rg'
            and list(arguments)==['rg','--files','-0',*plan['broadSourceRoots']]
            and args[2] is not None and Path(args[2]).resolve()==REPO)
        assert node or metadata_rg,'Only declared Node or exact current-source rg metadata command is selected'
    elif event in ('socket.connect','socket.bind'):
        address=args[1]
        if isinstance(address,tuple):assert address[0] in ('127.0.0.1','::1','localhost'),'Only owned loopback fixture endpoints are selected'
sys.addaudithook(audit)
preimport_source_roots()
import importlib
fixture_modules=[importlib.import_module(name) for name in selected['fixtureAliasModules']]
from ios.self_tests import tablet_web_host_app as host_app
from ios.self_tests import tablet_web_echo_fixture as echo_fixture
import subprocess
real_profile=sys.getprofile();assert real_profile is None
popen_code=subprocess.Popen.__init__.__code__;host_birth_codes=(host_app.TabletHostApp.__init__.__code__,echo_fixture.ActualDOMSession.__init__.__code__);host_close_codes=(host_app.TabletHostApp.close.__code__,echo_fixture.ActualDOMSession.close.__code__)
node_processes=[];host_owners=[];host_closes=[]
def observe_processes(frame,event,arg):
    code=frame.f_code
    # Exact identity prefilter: every other code previously matched no branch.
    # Avoid generator/any creation on millions of unrelated Python events.
    if (code is not popen_code and code is not host_birth_codes[0] and code is not host_birth_codes[1]
            and code is not host_close_codes[0] and code is not host_close_codes[1]):return
    if event=='return' and frame.f_code is popen_code:
        process=frame.f_locals['self'];pid=getattr(process,'pid',None)
        if type(pid) is int and not any(row['process'] is process for row in node_processes):
            node_processes.append(dict(process=process,birth=proc(pid),pid=pid))
    elif event=='return' and any(frame.f_code is code for code in host_birth_codes):
        owner=frame.f_locals['self'];process=getattr(owner,'process',None)
        if process is not None:host_owners.append(dict(owner=owner,process=process,pid=process.pid))
    elif event=='call' and any(frame.f_code is code for code in host_close_codes):
        owner=frame.f_locals['self'];process=getattr(owner,'process',None)
        if process is not None:host_closes.append(dict(owner=owner,process=process,entered=True,returned=False,returnCode=None))
    elif event=='return' and any(frame.f_code is code for code in host_close_codes):
        owner=frame.f_locals['self']
        for row in reversed(host_closes):
            if row['owner'] is owner and not row['returned']:
                row['returned']=True;row['returnCode']=row['process'].returncode;break
sys.setprofile(observe_processes)
from ios.self_tests.retained_host_roots import retain_owned_root
real_td=tempfile.TemporaryDirectory;retained=[];objects=[]
def retained_directory(*args,**kwargs):
    directory=real_td(*args,**kwargs);root=Path(directory.name)
    assert root.is_relative_to(temporary)
    root=retain_owned_root(directory,expected_root=root)
    retained.append(str(root));objects.append(directory)
    save(runroot/'created-original-roots.json',retained)
    print('RETAINED_ACTUAL_TABLET_ROOT',root,flush=True)
    return directory
aliases=[(module,module.tempfile) for module in fixture_modules]
result=None;actual_ids=[]

class ImmediateResult(unittest.TextTestResult):
    def report_exception(self,test,error,kind):
        import traceback
        # Preserve the original traceback immediately, BEFORE any optional
        # metadata diagnostic. Never capture generic locals or configuration.
        text=''.join(traceback.format_exception(*error))
        self.stream.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text)
        self.stream.flush()
        with (runroot/'immediate-exceptions.log').open('a') as output:
            output.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text);output.flush();os.fsync(output.fileno())
        # Attached only to THIS failure event, including explicitly suppressed
        # from-None contexts. No global trace, stale exception or locals dump.
        pending=[('event',error[1])];seen=set();attached=[]
        while pending and len(attached)<16:
            edge,value=pending.pop(0)
            if id(value) in seen:continue
            seen.add(id(value));attached.append(dict(edge=edge,type=type(value).__name__,
                suppressedContext=bool(value.__suppress_context__),
                traceback=''.join(traceback.format_exception(type(value),value,value.__traceback__,chain=False))))
            if value.__cause__ is not None:pending.append(('cause',value.__cause__))
            if value.__context__ is not None:pending.append(('context',value.__context__))
        with (runroot/'event-exception-contexts.jsonl').open('a') as output:
            output.write(json.dumps(dict(testId=test.id(),kind=kind,attached=attached))+'\n');output.flush();os.fsync(output.fileno())

    def addError(self,test,error):
        super().addError(test,error);self.report_exception(test,error,'ERROR')
    def addFailure(self,test,error):
        super().addFailure(test,error);self.report_exception(test,error,'FAILURE')

try:
    for module,original in aliases:
        assert original is tempfile;module.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_directory)
    ids=selected['caseIds'];assert len(ids)==len(set(ids))==selected['count']
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for child in value:yield from flatten(child)
        else:yield value
    actual_ids=[test.id() for test in flatten(suite)]
    assert not loader.errors and actual_ids==ids and suite.countTestCases()==selected['count'],(loader.errors,actual_ids)
    save(runroot/'selected-ids-actual.json',actual_ids);print('ACTUAL_SELECTED_IDS',json.dumps(actual_ids),flush=True)
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=ImmediateResult).run(suite)
    if result.wasSuccessful():assert result.testsRun==selected['count'] and not result.skipped,'All exact cases must execute without skip'
finally:
    sys.setprofile(real_profile)
    for module,original in aliases:module.tempfile=original
    assert tempfile.TemporaryDirectory is real_td and all(module.tempfile is original for module,original in aliases)
    assert source_before=={str(path):pin(path) for path in sourcepaths},'Source/launcher/map changed'
    assert all_sources_before==sources(plan),'Full Source/launcher membership changed'
    imported={}
    for name,module in tuple(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if file is not None:
            path=Path(file).resolve()
            if REPO in path.parents:
                relative=str(path.relative_to(REPO));assert relative in all_sources_before,(name,relative)
                imported[name]=relative
    save(runroot/'actual-imported-local-sources.json',imported)
    def census():return {str(path.relative_to(temporary)):pin(path) for path in (temporary,*sorted(temporary.rglob('*')))}
    remaining_before=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
    first=census();second=census();assert first==second,'Post-test originals changed'
    save(runroot/'selected-originals-first.json',first);save(runroot/'selected-originals-second.json',second)
    remaining=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in threads_before and thread.is_alive()]
    if result is not None and result.wasSuccessful() and result.testsRun==selected['count']:
        assert len(retained)==selected['expectedRetainedRoots'],'Unexpected actual fixture roots on full success'
    report=dict(kind=kind,testsRun=None if result is None else result.testsRun,selectedIds=actual_ids,
        successful=False if result is None else result.wasSuccessful(),skipped=[] if result is None else result.skipped,
        retainedTemporaryDirectoryRoots=retained,expectedRetainedRootCountOnFullSuccess=selected['expectedRetainedRoots'],fixtureAliasesRestored=True,sourceLauncherPinsUnchanged=True,
        originalCensusesEqual=True,remainingNewThreadsBeforeCensuses=remaining_before,remainingNewThreads=remaining,nativeCompiled=False,sdkExecuted=False,
        deviceQualified=False,wholeTabletQualified=False,publicAreaAcceptanceChanged=False)
    def original_streams(process):
        return {name:None if getattr(process,name) is None else getattr(process,name).closed for name in ('stdin','stdout','stderr')}
    node_rows=[dict(pid=row['pid'],birth=row['birth'],returnCode=row['process'].returncode,current=proc(row['pid']),originalStreamsClosed=original_streams(row['process'])) for row in node_processes]
    close_rows=[dict(pid=row['process'].pid,entered=row['entered'],returned=row['returned'],returnCode=row['returnCode']) for row in host_closes]
    save(runroot/'actual-node-and-original-close.json',dict(nodes=node_rows,hostOwnerPids=[row['pid'] for row in host_owners],originalCloseCalls=close_rows))
    report.update(actualPreimportAuditInstalled=True,actualNodeProcessCount=len(node_rows),originalHostOwnerCount=len(host_owners),originalCloseCount=len(close_rows))
    save(runroot/'selected-result.json',report);print('ACTUAL_RESULT',json.dumps(report),flush=True)
    assert all(row['returnCode'] is not None and (row['current'] is None or row['birth'] is not None and row['current']['startTicks']!=row['birth']['startTicks']) for row in node_rows),'Original Node process remained live'
    assert all(all(closed is None or closed is True for closed in row['originalStreamsClosed'].values()) for row in node_rows),'Original Node stream still open after original cleanup'
    assert all(any(row['process'] is original['process'] and row['returned'] and row['returnCode']==0 for row in host_closes) for original in host_owners),'Original host app did not complete its own normal close/wait'
    assert not remaining_before and not remaining,'New fixture/worker/listener thread remains live around censuses'
sys.exit(0 if result is not None and result.wasSuccessful() else 1)
