"""Actual prefix cleanup activation and once-only owned settings restoration.

This connected route retains every pending ordinary input and original. Native
read jobs, scene/marker/image resources and process/SDK end remain separate
obligations. Settings restoration never supplies current client permissions.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import need
from adapters.native_clock_join import digest
from adapters.script_feature.history import same
from ios.adapters.assets_budget import operation
from ios.adapters.assets_cleanup_phase import AssetsCleanupScope
from ios.adapters.assets_whole_cleanup import AssetsWholeCleanup


class AssetsWholePrefixAbort(AssetsWholeCleanup):
    def activate(self):
        self.metadata_guard()
        if self.owner.state is None:self.scope=self.owner.begin()
        elif self.owner.state['phase']=='recording':self.scope=self.owner.recover_saved()
        else:self.scope=AssetsCleanupScope(self.owner);self.scope.guard()
        row=self.owner.read();need(row['mode']=='prefix' and row['completedActionOriginals']<29)
        return self.scope

    @operation
    def prefix(self):
        self.activate();self.guard();client=self.driver.permissions.client
        # An unstarted client has no independently retained settings baseline.
        # Do not create a new baseline after an aborted prefix and claim that it
        # restores the earlier state. Its separate duty remains visible.
        if client.state is None:
            need(self.state is None)
            return self.prefix_report(None)
        need(client.state['commands'])
        if client.state['commands'][-1]['original'] is None:
            previous=client.guard
            def current():self.guard();need(previous() is not False);return True
            client.guard=current
            try:client.recover()  # Exact command-id recovery; no set/restore resend.
            finally:client.guard=previous
        original=self.restore_settings()
        self.guard();return self.prefix_report(original)

    def prefix_report(self,original):
        self.guard();row=self.owner.read();need(row['mode']=='prefix')
        client=self.driver.permissions.client;duties=set(row['prefixDuties'])
        if original is None:
            need(client.state is None and self.state is None)
            duties.add('settings-baseline-not-owned')
        else:
            need(self.state is not None and self.state['phase']=='observing-server'
                and self.state['serverProof'] is None and not self.state['nativePermissions'])
            commands=client.state['commands'];index=self.state['permissionCommandIndex']
            need(len(commands)==index and commands[index-1]['query']['operation']=='restore'
                and same(commands[index-1]['original'],original)
                and digest(original)==self.state['permissionOriginalSha256'])
        duties.update(('known-native-read-job-retirement','file-and-page-prefix-retirement',
            'scene-model-and-parser-resources','marker-and-image-resources',
            'independent-current-native-permission-restoration',
            'independent-server-blob-and-worker-restoration',
            'global-typed-evidence-membership','local-process-and-sdk-end'))
        return dict(assetsWholePrefixCleanupObservationVersion=1,runId=self.driver.run,
            cleanup=self.owner.link(),completedActionOriginals=row['completedActionOriginals'],
            regularActivations=row['regularActivations'],
            settingsOriginalRestored=original is not None,
            settingsRestorationOriginal=None if original is None else deepcopy(original),
            regularJournalsUnchanged=True,retainedDuties=sorted(duties),
            currentNativeFactsProduced=False,prefixAbortComplete=False,
            wholeEndEligible=False,performed=False)
