"""Root-owned single fixed-cap supervisor; full source pins and actual originals."""
from pathlib import Path
import json,os,stat,subprocess,sys,tempfile,time
from run_metadata import HERE,REPO,originals,pin,proc,publication,save,sha,sources,validate_frozen,prior_originals
assert len(sys.argv)==2 and sys.argv[1] in ('terminal1',)
kind=sys.argv[1];plan=validate_frozen();selected=plan['suites'][kind]
# First prospective600+5 equals the old Final cap; no inner clock is widened.
# Existing prior_originals() enforces actual Regression7 PASS before root/spawn.
assert type(selected['initialTimeoutSeconds']) is int and selected['initialTimeoutSeconds']>0 and not selected['budgetDecisionRequired'],'A separately frozen prospective cost cap is required before any run'
publication()
ready_path=HERE/'publication-ready-source-map.json';approved=json.loads(ready_path.read_text());ready_pin=pin(ready_path)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
reportpath=HERE/(kind+'-report.json');logpath=HERE/(kind+'-first.log')
assert not reportpath.exists() and not logpath.exists(),'No unchanged repeat'
before=sources(plan);assert before==approved['sourcePins'],'Actual sources differ from reviewed post-publication map'
assert 'interface/src/main.cpp' in before and 'CMakeLists.txt' in before
save(HERE/(kind+'-source-before.json'),before)
prior_before=prior_originals(plan);save(HERE/(kind+'-prior-originals-before.json'),prior_before)
runs=HERE/'runs'/kind;runs.mkdir(mode=0o700,parents=True,exist_ok=True)
runroot=Path(tempfile.mkdtemp(prefix='first-',dir=runs));runroot.chmod(0o700)
temporary=runroot/'temporary';temporary.mkdir(mode=0o700)
environment=os.environ.copy();environment.update(PYTHONDONTWRITEBYTECODE='1',
    PYTHONPATH='tests/device:tests/device/self_tests:tests/device/ios/self_tests',
    TMPDIR=str(temporary),OVERTE_AVATAR_SCENE_FINAL_RUN=str(runroot))
command=['timeout','--signal=TERM','--kill-after='+str(selected['killAfterSeconds'])+'s',
    str(selected['initialTimeoutSeconds'])+'s',sys.executable,str(HERE/'run-selected.py'),kind]
print('SOURCE_LAUNCHER_REFERENCE_PINS',len(before),flush=True);started=time.monotonic()
with logpath.open('x') as log:
    task=subprocess.Popen(command,cwd=REPO,env=environment,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    binding=proc(task.pid);assert binding is not None and binding['session']==task.pid and binding['processGroup']==task.pid
    save(HERE/(kind+'-process-binding.json'),dict(supervisor=proc(os.getpid()),task=binding,command=command))
    print('ACTUAL_PROCESS',json.dumps(binding,sort_keys=True),flush=True);code=task.wait()
# Full stop checks and preserved originals run also after failure/timeout.
after=sources(plan);save(HERE/(kind+'-source-after.json'),after)
prior_after=prior_originals(plan);save(HERE/(kind+'-prior-originals-after.json'),prior_after)
def owned_processes():
    found=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        value=proc(int(path.name))
        if value is not None and (value['session']==task.pid or value['processGroup']==task.pid):found.append(value)
    runnerpath=runroot/'runner-process-binding.json'
    if runnerpath.exists():
        runner=json.loads(runnerpath.read_text());current=proc(runner['pid'])
        if current is not None and current['startTicks']==runner['startTicks'] and current not in found:found.append(current)
    # Independent child birth identities also catch an escaped group/session.
    for childpath in temporary.rglob('child-process.json'):
        child=json.loads(childpath.read_text());current=proc(child['pid'])
        if current is not None and current['startTicks']==child['startTicks'] and current not in found:found.append(current)
    return found
# Establish process absence BEFORE the purported post-stop censuses, then recheck.
remaining_before=owned_processes()
first=originals(temporary);save(HERE/(kind+'-originals-first.json'),first)
second=originals(temporary);save(HERE/(kind+'-originals-second.json'),second)
remaining=owned_processes()
runnerpath=runroot/'runner-process-binding.json';runner=json.loads(runnerpath.read_text()) if runnerpath.exists() else None
report=dict(kind=kind,exitCode=code,seconds=time.monotonic()-started,runRoot=str(runroot),
    initialTimeoutSeconds=selected['initialTimeoutSeconds'],killAfterSeconds=selected['killAfterSeconds'],
    sourceLauncherReferencePins=len(after),mainCppPinned=True,rootCMakePinned=True,allPinsEqual=before==after,
    publicationReadyMapUnchanged=pin(ready_path)==ready_pin,postStopOriginalCensusesEqual=first==second,
    allPreviouslyRetainedInputsUnchanged=prior_before==prior_after,
    ownedProcessesBeforeCensuses=remaining_before,postStopCensusesQualified=not remaining_before and not remaining,
    originalFiles=sum(stat.S_ISREG(row['st_mode']) for row in first.values()),remainingOwnedProcesses=remaining,
    taskBinding=binding,runnerBinding=runner,nativeCompiled=False,sdkExecuted=False,deviceQualified=False,
    wholeAvatarQualified=False,publicAreaAcceptanceChanged=False)
save(reportpath,report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
assert before==after and pin(ready_path)==ready_pin,'Source/launcher/map drift'
assert first==second,'Retained originals changed after process stop'
assert prior_before==prior_after,'Old failed425 or firstCold23 originals changed'
assert not remaining_before and not remaining,'Owned process group/session/runner remained live around censuses'
raise SystemExit(code)
