"""Root-only metadata step AFTER exact reviewed publication; no target imports."""
import sys
from run_metadata import HERE,REPO,pin,publication,registry_original,save,sources,validate_frozen,prior_originals
assert len(sys.argv)==2
kind=sys.argv[1];plan=dict(validate_frozen(),activeSelection=kind);assert kind in plan['allowedRunKinds']
publication();ready=HERE/(kind+'-publication-ready-source-map.json')
assert not ready.exists(),'Do not replace an approved actual map'
root=REPO.stat();prior_before=prior_originals(plan);before=sources(plan);registry=registry_original();after=sources(plan);prior_after=prior_originals(plan)
assert prior_before==prior_after,'Retained originals changed during actual map preparation'
assert before==after,'Source/launcher/registry changed during map preparation'
config=__import__('json').loads((HERE/'source-root-final-map.json').read_text())
modules={name:dict(row,sha256=before[row['path']]['sha256']) for name,row in config['modules'].items()}
save(ready,dict(status='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA',worktreeRoot=str(REPO),
    rootIdentity=dict(st_dev=root.st_dev,st_ino=root.st_ino),broadSourceRoots=plan['broadSourceRoots'],
    sourcePins=before,modulePins=modules,registry=registry,priorOriginalRoots=list(prior_before)))
print('ACTUAL_SOURCE_LAUNCHER_PINS',len(before),flush=True)
