"""Root-only readback of a terminal public Chat group; never launches a test."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--here', type=Path, required=True)
    parser.add_argument('--preparation', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    repo = Path(__file__).resolve().parents[2]
    private = repo / '.ios-host-tmp'
    here, prep, output = args.here, args.preparation, args.output
    assert all(p.is_absolute() and p.parent == private for p in (here, prep, output))
    assert not output.exists()
    outer = Path(str(here) + '-outer')
    child = load(here / 'child-result.json')
    terminal = load(outer / 'terminal.json')
    plan = load(prep / 'plan.json')
    count = len(plan['cases'])
    assert count in (4, 5) and child['testsRun'] == count
    assert child['status'] == terminal['status'] == 'PASS'
    assert child['selected'] == terminal['selected'] == plan['cases']
    assert child['selectionGroup'] == terminal['selectionGroup'] == plan['selectionGroup']
    assert child['fatal'] is None and not child['refusals']
    assert not child['finalizationFailures'] and not child['failureOnlyControllerDrains']
    for key in ('actualAllLoadedOriginsAccounted', 'actualApprovedInputUnchanged',
                'actualFDThreadDrain', 'actualFivePublicOriginsEstablished',
                'allPhysicalPinsUnchanged', 'monitorRestored', 'noSDKImported',
                'suiteReturned', 'twoOwnRawCensusesEqual'):
        assert child[key] is True, key
    for key in ('actualApprovedInputUnchanged', 'actualNodesAbsent',
                'actualParentFDThreadDrain', 'allPhysicalPinsUnchanged',
                'noOwnProcesses', 'oldGlobalBodiesUnchanged',
                'twoClosedWholeOutputsEqual', 'twoRawCensusesEqual'):
        assert terminal[key] is True, key
    assert terminal['childReturnCode'] == 0 and not terminal['problems']
    assert not terminal['timedOut'] and not terminal['forced']
    assert load(outer / 'all-pins-before.json') == load(outer / 'all-pins-after.json') == plan['physicalPins']
    old = load(plan['globalCustody']['baselinePath'])
    assert load(outer / 'global-before.json') == old
    first = load(outer / 'global-first.json')
    assert first == load(outer / 'global-second.json')
    assert all(first.get(name) == body for name, body in old.items())
    assert set(first) - set(old) == {str(here / 'temporary')}
    for before, after in (('approved-input-before.json', 'approved-input-after.json'),
                          ('raw-first.json', 'raw-second.json'),
                          ('whole-output-first.json', 'whole-output-second.json')):
        assert load(outer / before) == load(outer / after)
    assert load(here / 'raw-first.json') == load(here / 'raw-second.json')
    assert all(row['passed'] for row in child['finalizationChecks'])
    assert len(child['cleanup']) == len(child['cases']) == count
    assert all(row['success'] and row['remaining'] == 0 and not row['errors']
               and row['originalException'] is None for row in child['cleanup'])
    assert [row['id'] for row in child['cases']] == plan['cases']
    assert all(row['controllerGatePassed'] and row['pendingCleanups'] == 0
               and len(row['roots']) == 3 for row in child['cases'])
    assert all(row['node']['exitCode'] == 0 and row['node']['actualScriptEndAndZeroSubscriptions']
               and row['node']['allRawStreamsClosed'] for row in child['cases'])
    assert load(here / 'write-port-restoration.json') == {
        'actualCportCount': 27, 'controlDescriptors': [], 'restored': True}
    public = child['actualPublicSubjectOrigins']
    assert len(public) == 5
    for name, value in public.items():
        assert value['actualLoadedRow'] == plan['modules'][name]
        assert value['actualModuleFile'] == value['expectedPublicPath']
        assert value['actualAdmission']['origin'] == value['expectedPublicPath']
        assert plan['modules'][name]['sha256'] == value['expectedSha256']
        assert not Path(value['expectedPublicPath']).is_relative_to(private)
    refs = {}
    for room in (here, outer):
        for path in sorted(room.rglob('*')):
            if path.is_file():
                assert not path.is_symlink()
                refs[str(path.relative_to(private))] = dict(path=str(path), sha256=sha(path))
    origins = load(here / 'all-loaded-origins-after.json')
    seconds = float(re.search(r'Ran \d+ tests in ([\d.]+)s',
                             (here / 'child-stderr.log').read_text()).group(1))
    result = dict(
        status='ACTUAL_CHAT_PUBLIC_SOURCE1_' + plan['selectionGroup'].upper().replace('-', '_') + '_QUALIFIED_PASS',
        selectionGroup=plan['selectionGroup'], actualIds=plan['cases'],
        actualStartedCases=count, actualPassedCases=count, qualifiedCases=count,
        actualGenuineTemporaryDirectories=3 * count, actualNodeBirths=count,
        actualAllNodeEndZeroSubscriptionsStreamCloseAbsence=True,
        actualRegisteredStandardCleanupsDrained=True,
        actualFivePublicOriginsEstablished=True, actualPublicSubjectOrigins=public,
        actualLoadedOriginSnapshots=child['allLoadedOriginSnapshots'],
        allOldOriginalBodiesUnchanged=True, oldOriginalRoots=len(old),
        allPhysicalPinsUnchanged=True, physicalPins=len(plan['physicalPins']),
        all27PortsAndCioRestored=True, controllerSourceFreeze=plan['controllerSourceFreeze'],
        preparationFreeze=sha(prep / 'freeze.json'), planSha256=sha(prep / 'plan.json'),
        head=plan['head'], executionScope=origins['executionScope'],
        unittestSeconds=seconds, outerTerminal=terminal,
        terminal=dict(childReturnCode=0, forcedKill=False, ownProcessesAbsent=True,
                      problems=[], timedOut=False),
        newOriginalRoots=[str(here), str(here / 'temporary'), str(outer)],
        finalizerSource=dict(path=str(Path(__file__).resolve()), sha256=sha(Path(__file__).resolve())),
        nativeQualified=False, deviceQualified=False, wholeQualified=False,
        completeFeatureCountUnchanged=5,
        limitation='One original public-source group only; complete Chat, native execution and device qualification remain open.')
    output.mkdir(mode=0o700)

    def put(name, value):
        raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
        descriptor = os.open(output / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(raw)
        return dict(sha256=sha(output / name))

    files = {'results.json': put('results.json', result),
             'actual-receipt-references.json': put('actual-receipt-references.json', refs)}
    put('freeze.json', dict(files=files))
    print(json.dumps(dict(freeze=sha(output / 'freeze.json'), references=len(refs),
                          cases=count, seconds=seconds, oldRoots=len(old))))


if __name__ == '__main__':
    main()
