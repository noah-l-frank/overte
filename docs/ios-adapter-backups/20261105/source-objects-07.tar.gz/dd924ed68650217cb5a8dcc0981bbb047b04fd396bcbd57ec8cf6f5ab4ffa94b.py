"""CleanupScope custody for known original generation Reply4 jobs only."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from types import SimpleNamespace
import time
from adapters.native_feature_observation import decode,exact,need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.operation_transport_guard import check as transport_check
from adapters.script_feature.history import same,pack,unpack
from ios.adapters import assets_replies as source
from ios.adapters.assets_cleanup_phase import AssetsCleanupScope
from ios.adapters.assets_episodes import AssetsEpisodeScope
from ios.adapters.assets_generation_replies import GenerationActionReplyReads,GenerationReplyActionSources
from ios.adapters.assets_model_sources import AssetsModelSources
from ios.adapters.assets_reply_cleanup import OwnedAssetsReplyCleanup,CleanupReplySources
from ios.adapters.assets_end_metadata import signature
from ios.adapters.assets_file_sources import sync

VERSION=1


class GenerationCleanupReplySources(CleanupReplySources):
    SCHEMA_PREFIX='iosAssetsGenerationReplyCleanNative'
    RECORD_KEY='iosAssetsGenerationReplyCleanNativeRecordVersion'
    MIGRATION_KEY='iosAssetsGenerationReplyCleanNativeMigrationVersion'
    def __init__(self,*args,generation,action_index,**kwargs):
        self.NAMESPACE='assets-g'+str(generation)+'-a'+str(action_index)+'-reply-clean-native'
        self.MIGRATION_PREFIX='assets-g'+str(generation)+'-a'+str(action_index)+'-reply-clean-migration-'
        super().__init__(*args,**kwargs)


class AssetsGenerationReplyCleanup(OwnedAssetsReplyCleanup):
    def __init__(self,origin,cleanup,episode,store,*,native=None,historical=False,monotonic=time.monotonic):
        need(type(origin) is GenerationActionReplyReads and origin.storage_version==4
            and origin.reply_action is None and origin.generation.historical
            and type(cleanup) is AssetsCleanupScope and type(episode) is AssetsEpisodeScope
            and episode is origin.reply_episode and episode.owner is cleanup.owner.episodes
            and origin.action_history is cleanup.owner.actions and origin.lock is episode.locks['primary']
            and isinstance(store,PrivateFeatureState) and type(historical) is bool
            and origin.previous is not None and origin.state is not None and callable(monotonic)
            and (native is None if historical else type(native) is source.IOSAssetsReplies))
        self.origin,self.cleanup,self.episode,self.store,self.historical=origin,cleanup,episode,store,historical
        self.run,self.role,self.url,self.binding,self.lock=origin.run,origin.role,origin.url,deepcopy(origin.binding),origin.lock
        generation,index=origin.generation.generation,origin.action_index
        expected='ios-assets-'+self.run+'-primary-gen'+str(generation)+'-action'+str(index)+'-reply-cleanup.json'
        need(self.role=='primary' and self.run==cleanup.owner.run
            and self.url==cleanup.owner.selected.context['fixtureUrl'] and same(self.binding,cleanup.owner.binding)
            and store.path.parent==origin.store.path.parent and store.path.name==expected)
        self.native=SimpleNamespace(pid=int(self.binding['processIdentity']),monotonic=monotonic) if historical else native
        need(str(self.native.pid)==self.binding['processIdentity']);self.previous=store.read();self.state=None;self.storage_version=2
        self.query_refs=[];self.query_pending=None;self.query_by_id={}
        origin.source_guard();need(type(origin.query_sources) is GenerationReplyActionSources)
        origin.state=origin.decode(origin.previous)
        need(origin.sources.pending is None and origin.query_sources.state['pending'] is None)
        known={query['commandId'] for query in origin.state['commands']}
        for ref in origin.query_sources.state['refs']:
            row=origin.query_sources.originals.read(origin.query_sources.originals.expand(ref))
            need(row['query']['commandId'] in known)
        self.origin_reference=self._origin_reference()
        self.sources=GenerationCleanupReplySources(self,'primary',self.metadata_guard,self.save,generation=generation,action_index=index)
        self.query_originals=OriginalFrameStore(store.path.parent,self.binding,self.run,'primary',self.metadata_guard,self.intent,
            namespace='assets-g'+str(generation)+'-a'+str(index)+'-reply-clean-query',
            schema_prefix='iosAssetsGenerationReplyCleanQuery',kind='inputs',monotonic=monotonic)
        self.metadata_guard()
        if not historical:
            for record in origin.state['originals']:
                packet=record['packet'];job=packet['source']['job']['request']['commandId'];native.last=deepcopy(packet);native.jobs[job]=deepcopy(packet)
            before=native.guard
            def current():self.live();need(before() is not False);return True
            native.guard=current
        if self.previous is not None:
            self.state=self.decode(self.previous)
            if not historical:
                for record in self.state['originals']:
                    packet=record['packet'];job=packet['source']['job']['request']['commandId'];native.last=deepcopy(packet);native.jobs[job]=deepcopy(packet)
    def _origin_reference(self):
        origin=self.origin;provenance=origin.query_sources
        for owner in (origin,provenance):need(same(owner.store.read(),owner.previous))
        pins={}
        for owner in (origin,provenance):
            pin=signature(owner.store.path);need(pin is not None);pins[str(owner.store.path)]=list(pin)
        return dict(path=str(origin.store.path),version=4,sha256=digest(origin.previous),physicalPins=pins,
            queryPath=str(provenance.store.path),querySha256=digest(provenance.previous))
    def origin_link(self):
        current=self._origin_reference();need(same(current,self.origin_reference));return deepcopy(self.origin_reference)
    def report(self):
        value=super().report();provenance=self.origin.query_sources
        need(type(provenance) is GenerationReplyActionSources and provenance.state['pending'] is None)
        known={query['commandId'] for query in self.origin.state['commands']}
        for reference in provenance.state['refs']:
            row=provenance.originals.read(provenance.originals.expand(reference))
            need(row['query']['commandId'] in known)
        return dict(value,generation=self.origin.generation.generation,actionIndex=self.origin.action_index,
            originalGenerationQuerySourcesUnchanged=True)
    def decode(self,value):
        exact(value,{'iosAssetsGenerationReplyCleanupVersion','binding','runId','role','fixtureUrl','originReply','cleanup','episode','queries','payload','pageGeneration','queryActionIndex'})
        need(type(value['iosAssetsGenerationReplyCleanupVersion']) is int and value['iosAssetsGenerationReplyCleanupVersion']==VERSION
            and same(value['binding'],self.binding) and value['runId']==self.run and value['role']=='primary' and value['fixtureUrl']==self.url
            and same(value['originReply'],self.origin_link()) and same(value['cleanup'],self.cleanup.owner.link()) and same(value['episode'],self.episode.link()) and same(value['pageGeneration'],self.origin.generation.link())
            and type(value['queryActionIndex']) is int and value['queryActionIndex']==self.origin.action_index)
        self.origin.state=self.origin.decode(self.origin.previous)
        queries=value['queries'];exact(queries,{'refs','pending'});need(type(queries['refs']) is list and len(queries['refs'])<=512)
        self.query_refs=deepcopy(queries['refs']);self.query_pending=deepcopy(queries['pending']);mapping={}
        for index,reference in enumerate(self.query_refs,1):
            full=self.query_originals.expand(reference);need(full['index']==index);row=self.query_row(self.query_originals.read(full),index)
            need(row['query']['commandId'] not in mapping);mapping[row['query']['commandId']]=reference
        self.query_by_id=mapping
        if self.query_pending is not None:
            pending=self.query_pending;exact(pending,{'row','original'});self.query_row(pending['row'],len(self.query_refs)+1)
            if pending['original'] is not None:
                self.query_originals.original(pending['original']);need(pending['original']['index']==len(self.query_refs)+1)
                AssetsModelSources.prefix(SimpleNamespace(originals=self.query_originals),pending['original'])
                if pending['original']['phase']=='saved':need(same(self.query_originals.read(pending['original']),pending['row']))
        rows=unpack(value['payload']);need(len(rows)==1);stored=rows[0]
        exact(stored,{'phase','ticket','token','resource','namespace','commands','jobs','sources'})
        self.sources.load(stored['sources']);need(self.sources.migration is None);entries=deepcopy(self.origin.state['originals'])
        for reference in self.sources.refs:
            record=self.sources.read_record(reference);need(record['kind']=='native');entries.append(dict(query=deepcopy(record['query']),packet=decode(record['raw'])))
        state={key:deepcopy(stored[key]) for key in ('phase','ticket','token','resource','namespace','commands','jobs')};state['originals']=entries;self.baseline(state)
        need(self.sources.pending is None or state['phase']!='closed');return self.validate_state(state)
    def save(self):
        self.live();transport_check();need(self.native.guard() is not False)
        state={key:deepcopy(self.state[key]) for key in ('phase','ticket','token','resource','namespace','commands','jobs')};state['sources']=self.sources.manifest()
        value=dict(iosAssetsGenerationReplyCleanupVersion=VERSION,binding=self.binding,runId=self.run,role='primary',fixtureUrl=self.url,
            originReply=self.origin_link(),cleanup=self.cleanup.owner.link(),episode=self.episode.link(),
            pageGeneration=self.origin.generation.link(),queryActionIndex=self.origin.action_index,
            queries=dict(refs=deepcopy(self.query_refs),pending=deepcopy(self.query_pending)),payload=pack([state]))
        need(same(self.decode(value),self.state));self.store.write(value,self.previous);sync(self.store.path.parent);self.previous=deepcopy(value)
