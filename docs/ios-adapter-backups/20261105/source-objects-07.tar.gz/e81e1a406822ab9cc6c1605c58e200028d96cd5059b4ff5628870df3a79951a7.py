"""Real owned import/cache inputs; no product/native owner is constructed."""
from pathlib import Path
import builtins
import hashlib
import importlib.machinery
import importlib.util
from importlib import _bootstrap_external
import json
import os
import sys
from types import FrameType
import unittest
import uuid
from closed_import_origins import ClosedOrigins

_CONTEXT = None


def configure(context):
    global _CONTEXT
    assert _CONTEXT is None and type(context) is dict
    assert set(context) == {'plan','guard','pin','source','repo'}
    assert type(context['guard']) is ClosedOrigins
    _CONTEXT = context


class SourceExecutionTests(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.directory = tempfile.TemporaryDirectory()
        self.root = Path(self.directory.name)
        self.addCleanup(self.directory.cleanup)
        self.modules = []
        self.hooks = []
        self.addCleanup(self.release_owned_modules)
        self.source = self.root / 'actual_source.py'
        self.source.write_bytes(b"VALUE = 'actual-source'\n")
        self.source.chmod(0o600)
        self.name = '_c10_actual_owned_' + uuid.uuid4().hex

    def release_owned_modules(self):
        for state in self.hooks:
            state['enabled'] = False
        for name, module in reversed(self.modules):
            assert sys.modules.get(name) is module
            del sys.modules[name]

    def guard(self):
        context = _CONTEXT
        original = context['plan']
        plan = dict(original)
        plan['modules'] = dict(original['modules'])
        plan['physicalPins'] = dict(original['physicalPins'])
        row = context['pin'](self.source)
        plan['physicalPins'][str(self.source)] = row
        plan['modules'][self.name] = dict(path=str(self.source),sha256=row['sha256'],package=False)
        return ClosedOrigins(plan,context['source'],context['repo'],context['pin'])

    def actual_module(self, guard, *, ordinary=False):
        if ordinary:
            spec = importlib.util.spec_from_file_location(self.name,self.source)
            self.assertIs(type(spec.loader),importlib.machinery.SourceFileLoader)
        else:
            row = guard.projects[self.name]
            spec = guard.file_spec(self.name,dict(row,loader='source'),'project')
            self.assertIs(type(spec.loader.original),importlib.machinery.SourceFileLoader)
        module = importlib.util.module_from_spec(spec)
        self.assertNotIn(self.name,sys.modules)
        sys.modules[self.name] = module
        self.modules.append((self.name,module))
        return module,spec

    def forget_last(self):
        name,module = self.modules.pop()
        self.assertIs(sys.modules[name],module)
        del sys.modules[name]

    def cache(self, *, unchecked=False):
        poison = builtins.compile(b"VALUE = 'cached-poison'\n",str(self.source),'exec',dont_inherit=True)
        if unchecked:
            raw = _bootstrap_external._code_to_hash_pyc(poison,importlib.util.source_hash(self.source.read_bytes()),checked=False)
        else:
            info = self.source.stat()
            raw = _bootstrap_external._code_to_timestamp_pyc(poison,int(info.st_mtime),info.st_size)
        path = Path(importlib.util.cache_from_source(str(self.source)))
        path.parent.mkdir(mode=0o700)
        path.write_bytes(raw)
        path.chmod(0o600)
        return path

    def observe_cache_reads(self,path):
        state = dict(enabled=True,reads=[])
        self.hooks.append(state)
        def observe(event,args):
            if event != 'open' or not state['enabled']:
                return
            value,mode,flags = args
            if type(value) in (str,bytes) and os.fsdecode(value) == str(path):
                state['reads'].append(dict(mode=mode,flags=flags))
        sys.addaudithook(observe)
        return state

    def check_cache(self, *, unchecked):
        cache = self.cache(unchecked=unchecked)
        original_cache = _CONTEXT['pin'](cache)
        original_source = _CONTEXT['pin'](self.source)
        observed = self.observe_cache_reads(cache)
        # Explicit negative demonstration, not a successful source-custody
        # proof: the ordinary genuine loader executes the real cached poison.
        module,spec = self.actual_module(None,ordinary=True)
        spec.loader.exec_module(module)
        self.assertEqual('cached-poison',module.VALUE)
        self.assertTrue(observed['reads'])
        self.forget_last()
        cut = len(observed['reads'])
        guard = self.guard()
        module,spec = self.actual_module(guard)
        spec.loader.exec_module(module)
        self.assertEqual('actual-source',module.VALUE)
        row = guard.source_row(self.name,module,guard.projects[self.name],'project')
        self.assertEqual('fresh-pinned-python-source-bytes',row['actualExecution']['kind'])
        self.assertFalse(row['actualExecution']['cachedBytecodeConsulted'])
        self.assertEqual(cut,len(observed['reads']))
        self.assertEqual(original_cache,_CONTEXT['pin'](cache))
        self.assertEqual(original_source,_CONTEXT['pin'](self.source))

    def test_valid_timestamp_cache_cannot_replace_actual_pinned_source(self):
        self.check_cache(unchecked=False)

    def test_unchecked_hash_cache_cannot_replace_actual_pinned_source(self):
        self.check_cache(unchecked=True)

    def test_changed_actual_source_identity_or_bytes_refuses_before_body(self):
        guard = self.guard()
        module,spec = self.actual_module(guard)
        original = _CONTEXT['pin'](self.source)
        before_bytes = self.source.read_bytes()
        self.assertNotIn('VALUE',vars(module))
        function = type(guard).__dict__['execute_python_source']
        code,namespace = function.__code__,function.__globals__
        state = dict(enabled=True,fired=False)
        self.hooks.append(state)
        def change(event,args):
            if event != 'open' or not state['enabled'] or state['fired']:
                return
            value,mode,flags = args
            if type(value) not in (str,bytes) or os.fsdecode(value) != str(self.source):
                return
            if mode is not None or flags != os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC:
                return
            frame = sys._getframe(1)
            # A retained readonly E458 os.open may be the immediate caller;
            # exactly its genuine next frame must be the actual source port.
            if frame.f_code is not code:
                frame = frame.f_back
            if type(frame) is not FrameType or frame.f_code is not code or frame.f_globals is not namespace:
                return
            if frame.f_locals.get('self') is not guard or frame.f_locals.get('path') != self.source:
                return
            state['fired'] = True
            self.source.write_bytes(b"VALUE = 'changed-input'\n")
        sys.addaudithook(change)
        with self.assertRaises(AssertionError):
            spec.loader.exec_module(module)
        self.assertTrue(state['fired'])
        self.assertNotIn('VALUE',vars(module))
        self.assertNotEqual(before_bytes,self.source.read_bytes())
        self.assertEqual((original['device'],original['inode']),
            (_CONTEXT['pin'](self.source)['device'],_CONTEXT['pin'](self.source)['inode']))
        self.assertNotIn(self.name,guard.python_executions)

    def test_rebound_compile_or_exec_alias_refuses_and_original_ports_restore(self):
        for port in ('compile','exec'):
            guard = self.guard()
            module,spec = self.actual_module(guard)
            original = getattr(builtins,port)
            called = []
            def foreign(*args,**kwargs):
                called.append((args,kwargs))
                raise AssertionError('Foreign compiler/executor must never execute')
            try:
                setattr(builtins,port,foreign)
                with self.assertRaises(AssertionError):
                    spec.loader.exec_module(module)
            finally:
                setattr(builtins,port,original)
            self.assertFalse(called)
            self.assertNotIn('VALUE',vars(module))
            self.assertNotIn(self.name,guard.python_executions)
            self.forget_last()

    def test_actual_stdlib_admission_and_snapshot_execution_rows_match(self):
        guard = self.guard()
        module,spec = self.actual_module(guard)
        spec.loader.exec_module(module)
        actual = guard.snapshot('actual-owned-source-row')
        self.assertEqual(guard.admissions[self.name],actual['modules'][self.name])
        self.assertEqual('fresh-pinned-python-source-bytes',actual['modules'][self.name]['actualExecution']['kind'])
        self.assertEqual(hashlib.sha256(self.source.read_bytes()).hexdigest(),
            actual['modules'][self.name]['actualExecution']['sourceSha256'])
        # Exercise the exact generic stdlib snapshot composition too, using
        # an actual source-delegated stdlib import, not a synthetic row.
        self.forget_last()
        self.assertNotIn('fractions',sys.modules)
        import fractions
        current = _CONTEXT['guard'].snapshot('actual-stdlib-source-row')
        row = current['modules']['fractions']
        self.assertEqual('fresh-pinned-python-source-bytes',row['actualExecution']['kind'])
        self.assertEqual(_CONTEXT['guard'].admissions['fractions'],row)

    def test_genuine_extension_wrapper_aliases_remain_exact_and_foreign_alias_refuses(self):
        # Foreign receiver comes from this real owned file and genuine import
        # objects; it is never accepted as a product/native owner.
        guard = self.guard()
        foreign,spec = self.actual_module(guard)
        spec.loader.exec_module(foreign)
        self.forget_last()
        import xml.parsers.expat as wrapper
        import pyexpat
        outer = _CONTEXT['guard']
        before = outer.snapshot('genuine-wrapper-aliases')
        for leaf in ('errors','model'):
            self.assertIs(getattr(wrapper,leaf),getattr(pyexpat,leaf))
            self.assertIs(sys.modules['xml.parsers.expat.'+leaf],getattr(pyexpat,leaf))
            self.assertEqual('stdlib-source-reexported-extension-module',before['modules']['xml.parsers.expat.'+leaf]['kind'])
        self.assertEqual('fresh-pinned-python-source-bytes',before['modules']['xml.parsers.expat']['actualExecution']['kind'])
        self.assertEqual('genuine-pinned-extension-loader',before['modules']['pyexpat']['actualExecution']['kind'])
        name = 'xml.parsers.expat.model'
        original = sys.modules[name]
        try:
            sys.modules[name] = foreign
            with self.assertRaises(AssertionError):
                outer.snapshot('foreign-real-receiver-refusal')
        finally:
            sys.modules[name] = original
        after = outer.snapshot('restored-genuine-wrapper-aliases')
        self.assertEqual(before['modules'][name],after['modules'][name])
