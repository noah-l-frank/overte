from pathlib import Path
import ast,hashlib,json,shutil,difflib,stat
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');B=R/'.ios-host-tmp/avatar-primary-control-explicit-budget-root-preparation-20261029';P=R/'.ios-host-tmp/avatar-canonical-frontdoor-target-birth-draft-20261029';G=R/'.ios-host-tmp/avatar-primary-control-reviewed-checks-20261029'
D=R/'.ios-host-tmp/avatar-canonical-birth3-root-two-selections-preparation-20261029';assert not D.exists();D.mkdir(mode=0o700)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
for name in ('root-supervise.py','run-selected.py','run_metadata.py','monitoring_observer.py','refresh-after-publication.py','source-root-final-map.json','retained-prior-original-pins.json'):
    shutil.copyfile(B/name,D/name)
old="('tls6','owner2','checkpoint1','legacyTLS5','legacySessions3')"
for name in ('root-supervise.py','run-selected.py'):
    f=D/name;s=f.read_text();assert s.count(old)==1;f.write_text(s.replace(old,"('birth2','defaultPrepare2')").replace('OVERTE_AVATAR_PRIMARY_CONTROL_RUN','OVERTE_AVATAR_CANONICAL_BIRTH_RUN'))
plan=json.loads((B/'suite-plan.json').read_text());birth=json.loads((P/'test-plan.json').read_text())['caseIds']
legacy=['ios.self_tests.test_ios_avatar_prepare_composed.AvatarPrepareComposedTests.'+name for name in ('test_actual_both_owned_accounts_then_both_untouched_frames_and_normal_scripts','test_both_public_prepare_retries_after_lost_actual_uikit_close_reach_paired_initial_and_marker_admission_once')]
methods={n.name for c in ast.parse((R/'tests/device/ios/self_tests/test_ios_avatar_prepare_composed.py').read_text()).body if isinstance(c,ast.ClassDef) and c.name=='AvatarPrepareComposedTests' for n in c.body if isinstance(n,ast.FunctionDef)}
assert all(x.rsplit('.',1)[-1] in methods for x in legacy)
aliases=['self_tests.test_account_provider','ios.self_tests.test_ios_emote_marker_scope','ios.self_tests.test_ios_installed_code']
plan['suites']={kind:dict(caseIds=ids,count=len(ids),initialTimeoutSeconds=120,killAfterSeconds=5,budgetDecisionRequired=False,expectedRetainedRoots=roots,fixtureAliasModules=mods,directTemporaryDirectoryModules=[]) for kind,ids,roots,mods in [('birth2',birth,11,aliases+['ios.self_tests.avatar_canonical_frontdoor_fixture']),('defaultPrepare2',legacy,9,aliases)]}
plan.update(status='PRIVATE_ORIGINAL_BIRTH3_AND_LITERAL_DEFAULT2_UNRUN_NO_CONFIG10',requiredSplitComponents=[],expectedPublicationCount=3,frozenPackets=[dict(path=str(P.relative_to(R)),freezeSha256=sha(P/'freeze.json'))])
for field in ('budgetJustification','workerJoin','actualRegression7','alreadyQualifiedSmallActual','same1113Actual'):plan.pop(field,None)
plan['budgetJustification']=dict(birth2=dict(outerSeconds=120,reason='First pure metadata/binding/source-original admission2, no normal Avatar input/full journey; prospective original Birth3 packet cap120 preserved.'),defaultPrepare2=dict(outerSeconds=120,reason='Only current noop before-birth fixture hook changed; existing true paired default/lost-close prepare recipe previously actual7.867/8.131s single cases. No later Scene/Final/End replays.'),innerClocksLiteral=True,no600Retry=True,SDKDeviceCompilerServices=False)
rows=[dict(path=name,expectedSha256=row['candidateSha256']) for name,row in json.loads((P/'candidate-manifest.json').read_text()).items()]
save(D/'expected-publication.json',rows);save(D/'expected-registry-own-keys.json',{})
config=json.loads((D/'source-root-final-map.json').read_text())
for row in rows:
    path=row['path'];name=path.removeprefix('tests/device/').removesuffix('.py').replace('/','.')
    config['modules'][name]=dict(path=path)
save(D/'source-root-final-map.json',config)
# Inherit exact old golden originals and add ALL Root globally verified stopped
# corpora from the last completed before/after check. No running tree snapshots.
prior=json.loads((D/'retained-prior-original-pins.json').read_text())
report_refs=json.loads((G/'retention-plan.json').read_text())
for label,reportname,censusname in report_refs:
    report=json.loads((R/reportname).read_text());expected=json.loads((R/censusname).read_text());root=Path(report['runRoot'])/'temporary'
    for name,row in expected.items():
        assert 'st_mode' in row,(label,name);prior[str((root/name).relative_to(R))]=row
# Native staged old cases use the exact alternate stat-list format documented
# by the same already-completed Root checker; read its literal lists only.
tree=ast.parse((G/'check-retention-and-source.py').read_text());stages=[]
for n in tree.body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='stage_roots' for t in n.targets):stages=ast.literal_eval(n.value)
    if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name) and n.value.func.value.id=='stage_roots':
        values=ast.literal_eval(n.value.args[0]);stages.extend(values if n.value.func.attr=='extend' else [values])
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
for packet,dirname,outname in stages:
    base=R/packet;root=base/dirname;expected=json.loads((base/outname/'originals-first.json').read_text())
    for name,raw in expected.items():
        row=dict(zip(fields,raw['stat']));assert len(raw['stat'])==len(fields)
        if 'sha256' in raw:row['sha256']=raw['sha256']
        prior[str((root/name).relative_to(R))]=row
root=R/'.ios-host-tmp/lifecycle-owner-exact26-async-setup-testprep-20261028/retained-first26'
expected=json.loads((R/'.ios-host-tmp/lifecycle-owner-exact26-async-setup-root-preparation-20261028/originals-first.json').read_text())
for name,raw in expected.items():
    row=dict(zip(fields,raw['stat']))
    if 'sha256' in raw:row['sha256']=raw['sha256']
    prior[str((root/name).relative_to(R))]=row
# New qualified17 Control component source/report/raw receipts too.
for kind in ('tls6','legacySessions3','owner2','legacyTLS5','checkpoint1'):
    report=json.loads((B/(kind+'-report.json')).read_text());assert report['exitCode']==0 and report['allPinsEqual'] and report['postStopCensusesQualified']
    root=Path(report['runRoot'])/'temporary';expected=json.loads((B/(kind+'-originals-first.json')).read_text())
    for name,row in expected.items():prior[str((root/name).relative_to(R))]=row
save(D/'retained-prior-original-pins.json',prior)
plan['sourceRootMapSha256']=sha(D/'source-root-final-map.json');plan['expectedPublicationSha256']=sha(D/'expected-publication.json');plan['expectedOwnRegistrySha256']=sha(D/'expected-registry-own-keys.json');plan['retainedPriorPinsSha256']=sha(D/'retained-prior-original-pins.json')
plan['retentionBaselineAuthority']=dict(reportPlan=str((G/'retention-plan.json').relative_to(R)),before=str((G/'before-retention.json').relative_to(R)),after=str((G/'after-retention.json').relative_to(R)),scope='Completed stopped originals only, expected golden bytes/stat/SHA; Root rechecks actual before and after. Active Native58 excluded.')
save(D/'suite-plan.json',plan)
(D/'ROOT-REVIEW.txt').write_text('Original Birth3 ONLY:5621/6956/b09, no NativeChannels/real-time profile/Config10. Two separate exact selections first120+5 each: Birth2 expected11TD (TLS class1+two cases5); DefaultPrepare2 expected9TD (TLS1+two cases4). Existing original dropped-return preparation test is repeated solely for the new default-noop hook. No Scene/Final/end retry.\nQualified process/Node/TLS/stdio/thread/local-monitor/Tool/census/SDK-audit controls are unchanged. Per-suite budgetDecisionRequired:false explicit. Parent+child share OVERTE_AVATAR_CANONICAL_BIRTH_RUN. No ready map; Root refresh-after-publication.py after exact3 publication resolves actual canonical namespaces and all broad files/main/interface/root CMake.\nGlobal expected original pins derive from last Root-verified stopped retention receipts + new17/431 and all inherited failures/1111. No active test originals were scanned or snapshot. All actual paths/stat/SHA are checked by Root prior_originals before and after, process absence precedes both fresh poststop censuses. No imports/tests/public edits here.\n')
diff=[]
for name in ('root-supervise.py','run-selected.py'):
    diff.extend(difflib.unified_diff((B/name).read_text().splitlines(True),(D/name).read_text().splitlines(True),fromfile='qualified/'+name,tofile='birth/'+name))
(D/'launcher-only.diff').write_text(''.join(diff))
for p in D.glob('*.py'):ast.parse(p.read_text())
files={str(p.relative_to(D)):sha(p) for p in sorted(D.rglob('*')) if p.is_file()};save(D/'freeze.json',dict(frozen=True,targetImportsExecuted=False,testsExecuted=False,files=files))
print('freeze',sha(D/'freeze.json'),'priorpins',len(prior),'cases',birth+legacy)
