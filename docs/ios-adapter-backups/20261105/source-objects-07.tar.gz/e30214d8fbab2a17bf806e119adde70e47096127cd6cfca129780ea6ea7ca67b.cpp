// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:critical data-parser

#include "qv4compileddata_p.h"

#include <private/inlinecomponentutils_p.h>
#include <private/qqmlscriptdata_p.h>
#include <private/qqmltypenamecache_p.h>
#include <private/qv4resolvedtypereference_p.h>

#include <QtQml/qqmlfile.h>

#include <QtCore/qdir.h>
#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
#include <QtCore/qthread.h>
#include <QtCore/qjsondocument.h>
#include <algorithm>
#endif
#include <QtCore/qscopeguard.h>
#include <QtCore/qstandardpaths.h>
#include <QtCore/qxpfunctional.h>

QT_BEGIN_NAMESPACE
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
namespace QV4::OverteCacheOriginals {
namespace { std::atomic<bool> admitted { false },unavailable { false };std::atomic<quint64> sequence { 0 }; }
bool active() noexcept { return admitted.load() && !unavailable.load(); }
void setEnabled(bool value) noexcept { admitted.store(value); }
void fail() noexcept { unavailable.store(true); }
quint64 next() noexcept {
    const auto value=sequence.fetch_add(1)+1;
    if (value==0 || value>1000000000) { fail();return 0; }
    return value;
}
}
#endif

namespace QV4 {
namespace CompiledData {


bool Unit::verifyHeader(QDateTime expectedSourceTimeStamp, QString *errorString) const
{
    if (strncmp(magic, CompiledData::magic_str, sizeof(magic))) {
        *errorString = QStringLiteral("Magic bytes in the header do not match");
        return false;
    }

    if (version != quint32(QV4_DATA_STRUCTURE_VERSION)) {
        *errorString = QString::fromUtf8("V4 data structure version mismatch. Found %1 expected %2")
                               .arg(quint32(version), 0, 16).arg(QV4_DATA_STRUCTURE_VERSION, 0, 16);
        return false;
    }

    if (sourceTimeStamp) {
        // Files from the resource system do not have any time stamps, so fall back to the application
        // executable.
        if (!expectedSourceTimeStamp.isValid())
            expectedSourceTimeStamp = QFileInfo(QCoreApplication::applicationFilePath()).lastModified();

        if (expectedSourceTimeStamp.isValid()
            && expectedSourceTimeStamp.toMSecsSinceEpoch() != sourceTimeStamp) {
            *errorString = QStringLiteral("QML source file has a different time stamp than cached file.");
            return false;
        }
    }

    return true;
}

/*!
    \internal
    This function creates a temporary key vector and sorts it to guarantuee a stable
    hash. This is used to calculate a check-sum on dependent meta-objects.
 */
bool ResolvedTypeReferenceMap::addToHash(
        QCryptographicHash *hash, QHash<quintptr, QByteArray> *checksums) const
{
    std::vector<int> keys (size());
    int i = 0;
    for (auto it = constBegin(), end = constEnd(); it != end; ++it) {
        keys[i] = it.key();
        ++i;
    }
    std::sort(keys.begin(), keys.end());
    for (int key: keys) {
        if (!this->operator[](key)->addToHash(hash, checksums))
            return false;
    }

    return true;
}

CompilationUnit::CompilationUnit(
        const Unit *unitData, const QString &fileName, const QString &finalUrlString)
{
    setUnitData(unitData, nullptr, fileName, finalUrlString);
}

CompilationUnit::~CompilationUnit()
{
#if defined(QT_OVERTE_E2E_QML_DEPENDENCY_ORIGINALS)
    overteE2eRetireDependencies();
#endif
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    overteE2eInvalidateSourceReceipt();
#endif
    qDeleteAll(resolvedTypes);

    if (data) {
        if (data->qmlUnit() != qmlData)
            free(const_cast<QmlUnit *>(qmlData));
        qmlData = nullptr;

        if (!(data->flags & QV4::CompiledData::Unit::StaticData))
            free(const_cast<Unit *>(data));
    }
    data = nullptr;
#if Q_BYTE_ORDER == Q_BIG_ENDIAN
    delete [] constants;
    constants = nullptr;
#endif
}

QString CompilationUnit::localCacheFilePath(const QUrl &url)
{
    static const QByteArray envCachePath = qgetenv("QML_DISK_CACHE_PATH");

    const QString localSourcePath = QQmlFile::urlToLocalFileOrQrc(url);
    const QString cacheFileSuffix
            = QFileInfo(localSourcePath + QLatin1Char('c')).completeSuffix();
    QCryptographicHash fileNameHash(QCryptographicHash::Sha1);
    fileNameHash.addData(localSourcePath.toUtf8());
    QString directory = envCachePath.isEmpty()
            ? QStandardPaths::writableLocation(QStandardPaths::CacheLocation)
                    + QLatin1String("/qmlcache/")
            : QString::fromLocal8Bit(envCachePath) + QLatin1String("/");
    QDir::root().mkpath(directory);
    return directory + QString::fromUtf8(fileNameHash.result().toHex())
            + QLatin1Char('.') + cacheFileSuffix;
}

bool CompilationUnit::loadFromDisk(
        const QUrl &url, const QDateTime &sourceTimeStamp, QString *errorString)
{
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    // Preserve only the actual preceding write as a candidate; the mapper
    // must independently bind its opened FD and mapped bytes before adoption.
    const auto observedCacheWrite=overteE2eCacheWriteOriginal;
    overteE2eInvalidateSourceReceipt();
#endif
    if (!QQmlFile::isLocalFile(url)) {
        *errorString = QStringLiteral("File has to be a local file.");
        return false;
    }

    const QString sourcePath = QQmlFile::urlToLocalFileOrQrc(url);
    auto cacheFile = std::make_unique<CompilationUnitMapper>();
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    cacheFile->setOverteE2eExpectedWrite(observedCacheWrite);
#endif

    const QStringList cachePaths = { sourcePath + QLatin1Char('c'), localCacheFilePath(url) };
    for (const QString &cachePath : cachePaths) {
        Unit *mappedUnit = cacheFile->get(cachePath, sourceTimeStamp, errorString);
        if (!mappedUnit)
            continue;

        const Unit *oldData = unitData();
        const Unit * const oldDataPtr
                = (oldData && !(oldData->flags & Unit::StaticData))
                ? oldData
                : nullptr;

        auto dataPtrRevert = qScopeGuard([this, oldData](){
            setUnitData(oldData);
        });
        setUnitData(mappedUnit);

        if (mappedUnit->sourceFileIndex != 0) {
            if (mappedUnit->sourceFileIndex >=
                mappedUnit->stringTableSize + dynamicStrings.size()) {
                *errorString = QStringLiteral("QML source file index is invalid.");
                continue;
            }
            if (sourcePath !=
                QQmlFile::urlToLocalFileOrQrc(stringAt(mappedUnit->sourceFileIndex))) {
                *errorString = QStringLiteral("QML source file has moved to a different location.");
                continue;
            }
        }

        dataPtrRevert.dismiss();
        free(const_cast<Unit*>(oldDataPtr));
        backingFile = std::move(cacheFile);
        return true;
    }

    return false;
}

bool CompilationUnit::saveToDisk(const QUrl &unitUrl, QString *errorString)
{
    if (unitData()->sourceTimeStamp == 0) {
        *errorString = QStringLiteral("Missing time stamp for source file");
        return false;
    }

    if (!QQmlFile::isLocalFile(unitUrl)) {
        *errorString = QStringLiteral("File has to be a local file.");
        return false;
    }

#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    // This executes BEFORE SaveableUnitPointer temporarily changes StaticData.
    QVariantMap compilerInput;
    const auto *observedUnit=data;const auto observedGeneration=overteE2eSourceGeneration;
    QT_TRY {
        if (OverteCacheOriginals::active() && data && !aotCompiledFunctions
                && !overteE2ePendingCompilerInput.isEmpty()
                && data->unitSize>0 && data->unitSize<=4*1024*1024
                && OverteCacheOriginals::sha(data,data->unitSize)
                    ==overteE2ePendingCompilerInput.value("compilerUnitSha256").toString()) {
            if (overteE2eOwnerId.isEmpty()) overteE2eOwnerId=OverteCacheOriginals::nonce();
            compilerInput=overteE2ePendingCompilerInput;
        }
        if (data!=observedUnit || overteE2eSourceGeneration!=observedGeneration) compilerInput.clear();
        overteE2eCacheWriteOriginal.clear();
    } QT_CATCH (...) { OverteCacheOriginals::fail(); }
#endif
    return SaveableUnitPointer(unitData()).saveToDisk<char>(
            [this,&unitUrl, errorString
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
             ,compilerInput,observedUnit,observedGeneration
#endif
             ](const char *data, quint32 size) {
                const QString cachePath = localCacheFilePath(unitUrl);
                if (SaveableUnitPointer::writeDataToFile(
                            cachePath, data, size, errorString
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
                            ,(unitData()==observedUnit && overteE2eSourceGeneration==observedGeneration
                                && data==reinterpret_cast<const char *>(observedUnit)) ? &overteE2eCacheWriteOriginal : nullptr,
                            compilerInput,overteE2eOwnerId,observedGeneration
#endif
                            )) {
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
                    if (unitData()!=observedUnit || overteE2eSourceGeneration!=observedGeneration)
                        overteE2eCacheWriteOriginal.clear();
#endif
                    CompilationUnitMapper::invalidate(cachePath);
                    return true;
                }

                return false;
            });
}

#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
QVariantMap CompilationUnit::overteE2eCodeIdentity() const noexcept
{
    QT_TRY {
        if (!OverteCacheOriginals::active() || !data || overteE2eOwnerId.isEmpty()
                || overteE2eSourceGeneration>=1000000000) return {};
        const auto *actual=data;const auto generation=overteE2eSourceGeneration;
        const quint64 size=actual->unitSize;
        if (size<sizeof(Unit) || size>4*1024*1024) return {};
        const auto digest=OverteCacheOriginals::sha(actual,qsizetype(size));
        if (data!=actual || overteE2eSourceGeneration!=generation || actual->unitSize!=size) return {};
        return {{"unitOwnerId",overteE2eOwnerId},{"unitGeneration",qulonglong(generation)},
            {"unitBytes",qulonglong(size)},{"unitSha256",digest},{"aot",bool(aotCompiledFunctions)}};
    } QT_CATCH (...) { OverteCacheOriginals::fail();return {}; }
}

struct FrozenDependencyUnit;
struct ScriptDiagnosticState {
    const QString id=OverteCacheOriginals::nonce();std::atomic<bool> live{true};
    std::shared_ptr<const QVariantMap> event;
};
struct DependencyDiagnosticState {
    std::atomic<bool> live{true};std::atomic<quint64> revision{0};
    std::shared_ptr<const FrozenDependencyUnit> value;
};
struct FrozenDependencyEdge {
    QString kind;int slot=0;bool missing=false;
    std::weak_ptr<DependencyDiagnosticState> target;
    std::weak_ptr<ScriptDiagnosticState> script;
    QString scriptId;
};
struct FrozenDependencyUnit {
    quint64 revision=0;QVariantMap code,source,before,after;QString kind;
    QList<FrozenDependencyEdge> edges;
};

std::shared_ptr<ScriptDiagnosticState> ensureScriptDiagnostic(std::shared_ptr<ScriptDiagnosticState> &slot) noexcept {
    QT_TRY {
        auto state=std::atomic_load(&slot);
        if (!state && OverteCacheOriginals::active()) {
            auto candidate=std::make_shared<ScriptDiagnosticState>();
            if (std::atomic_compare_exchange_strong(&slot,&state,candidate)) state=std::move(candidate);
        }
        return state;
    } QT_CATCH (...) { OverteCacheOriginals::fail();return {}; }
}
QString scriptDiagnosticIdentity(const std::shared_ptr<ScriptDiagnosticState> &state) noexcept {
    QT_TRY {return state && state->live.load() ? state->id : QString();}
    QT_CATCH (...) {OverteCacheOriginals::fail();return {};}
}
void publishScriptDiagnostic(const std::shared_ptr<ScriptDiagnosticState> &state,const QVariantMap &original) noexcept {
    QT_TRY {
        if (!state || !state->live.load()) return;
        std::shared_ptr<const QVariantMap> value;
        if (!original.isEmpty()) value=std::make_shared<const QVariantMap>(original);
        std::atomic_store(&state->event,std::move(value));
    } QT_CATCH (...) {OverteCacheOriginals::fail();}
}
void retireScriptDiagnostic(const std::shared_ptr<ScriptDiagnosticState> &state) noexcept {
    if (state) {state->live.store(false);std::atomic_store(&state->event,std::shared_ptr<const QVariantMap>());}
}
QVariantMap readScriptDiagnostic(const std::shared_ptr<ScriptDiagnosticState> &state,const QVariantMap &unit) noexcept {
    QT_TRY {
        if (!state || !state->live.load()) return {};
        const auto value=std::atomic_load(&state->event);
        if (!value || value->value("unit").toMap()!=unit || !state->live.load()) return {};
        return {{"scriptDataId",state->id},{"original",*value},
            {"currentExecutableAssociationAvailable",false},{"parentContextAssociationAvailable",false}};
    } QT_CATCH (...) {OverteCacheOriginals::fail();return {};}
}

std::shared_ptr<DependencyDiagnosticState> CompilationUnit::overteE2eDependencyToken() const noexcept {
    QT_TRY {
        auto state=std::atomic_load(&overteE2eDependencyState);
        if (!state && OverteCacheOriginals::active()) {
            auto candidate=std::make_shared<DependencyDiagnosticState>();
            if (std::atomic_compare_exchange_strong(&overteE2eDependencyState,&state,candidate)) state=std::move(candidate);
        }
        return state;
    } QT_CATCH (...) {OverteCacheOriginals::fail();return {};}
}
void CompilationUnit::overteE2eInvalidateDependencies() noexcept {
    const auto state=std::atomic_load(&overteE2eDependencyState);
    if (state) {state->revision.fetch_add(1);std::atomic_store(&state->value,std::shared_ptr<const FrozenDependencyUnit>());}
}
void CompilationUnit::overteE2eRetireDependencies() noexcept {
    const auto state=std::atomic_load(&overteE2eDependencyState);
    if (state) state->live.store(false);
    overteE2eInvalidateDependencies();
}

void CompilationUnit::overteE2eCaptureDependencies() noexcept {
    QT_TRY {
        // Called at the EXISTING loader-thread completion, after its own
        // writes. No UI callback may inspect these mutable Qt containers.
        if (!OverteCacheOriginals::active()) return;
        const auto state=overteE2eDependencyToken();if (!state || !state->live.load()) return;
        auto value=std::make_shared<FrozenDependencyUnit>();value->revision=state->revision.load();
        value->before=OverteCacheOriginals::clock();value->code=overteE2eCodeIdentity();
        if (value->code.isEmpty()) return;
        value->kind="unavailable";
        if (!value->code.value("aot").toBool()) {
            value->source=overteE2eCacheOriginalForCurrentUnit();
            if (!value->source.isEmpty()) value->kind="mapped-cache";
            else if (overteE2eSourceReceipt.value("unitGeneration")==value->code.value("unitGeneration")
                    && overteE2eSourceReceipt.value("unitSha256")==value->code.value("unitSha256")) {
                value->source=overteE2eSourceReceipt;value->kind="direct-unit";
            } else if (overteE2ePendingCompilerInput.value("compilerUnitSha256")==value->code.value("unitSha256")
                    && overteE2ePendingCompilerInput.value("compilerUnitBytes")==value->code.value("unitBytes")) {
                value->source=overteE2ePendingCompilerInput;value->kind="compiler-prefix";
            }
        }
        auto keys=resolvedTypes.keys();std::sort(keys.begin(),keys.end());
        for (int key:keys) {
            const auto *reference=resolvedTypes.value(key);if (!reference) return;
            FrozenDependencyEdge edge;edge.slot=key;
            const auto *child=reference->isSelfReference() ? this : reference->overteE2eCompilationUnitIdentity();
            edge.kind=reference->isSelfReference()?"self-type":"resolved-type";edge.missing=!child;
            if (child) {const auto token=child->overteE2eDependencyToken();if (!token) return;edge.target=token;}
            value->edges.append(edge);if (value->edges.size()>256) return;
        }
        for (int slot=0;slot<dependentScripts.size();++slot) {
            const auto *script=dependentScripts.at(slot).data();if (!script) return;
            FrozenDependencyEdge edge;edge.kind="dependent-script";edge.slot=slot;
            const auto *child=script->overteE2eCompilationUnitIdentity();edge.missing=!child;
            if (child) {const auto token=child->overteE2eDependencyToken();if (!token) return;edge.target=token;}
            const auto scriptState=script->overteE2eScriptDiagnosticToken();
            edge.scriptId=scriptDiagnosticIdentity(scriptState);if (edge.scriptId.isEmpty()) return;edge.script=scriptState;
            value->edges.append(edge);if (value->edges.size()>256) return;
        }
        value->after=OverteCacheOriginals::clock();
        if (overteE2eCodeIdentity()!=value->code || !state->live.load() || state->revision.load()!=value->revision) return;
        std::shared_ptr<const FrozenDependencyUnit> immutable=std::move(value);
        std::atomic_store(&state->value,std::move(immutable));
    } QT_CATCH (...) {OverteCacheOriginals::fail();}
}

namespace {
struct OverteDependencyPass {
    QList<std::shared_ptr<DependencyDiagnosticState>> states;
    QList<std::shared_ptr<const FrozenDependencyUnit>> originals;
    QList<std::shared_ptr<ScriptDiagnosticState>> scripts;
    QList<std::shared_ptr<const QVariantMap>> evaluations;
    QHash<const DependencyDiagnosticState *,int> indices;QVariantList nodes,edges;quint64 bytes=0;
    int add(const std::shared_ptr<DependencyDiagnosticState> &state) {
        if (!state || !state->live.load()) return -1;
        const auto found=indices.constFind(state.get());if (found!=indices.constEnd()) return found.value();
        const auto value=std::atomic_load(&state->value);
        if (!value || value->revision!=state->revision.load() || states.size()>=64) return -1;
        bytes+=value->code.value("unitBytes").toULongLong();if (bytes>16*1024*1024) return -1;
        const int index=states.size();states.append(state);originals.append(value);indices.insert(state.get(),index);
        nodes.append(QVariantMap{{"index",index},{"unit",value->code},{"sourceKind",value->kind},{"sourceOriginal",value->source},
            {"captureBefore",value->before},{"captureAfter",value->after}});return index;
    }
    bool read(const std::shared_ptr<DependencyDiagnosticState> &root) {
        if (add(root)!=0) return false;
        for (int from=0;from<states.size();++from) {
            const auto captured=originals.at(from);
            for (const auto &edge:captured->edges) {
                if (edges.size()>=256) return false;
                int target=-1;if (!edge.missing && (target=add(edge.target.lock()))<0) return false;
                QVariantMap result{{"from",from},{"kind",edge.kind},{"slot",edge.slot},{"to",target},{"missing",edge.missing}};
                if (edge.kind==QStringLiteral("dependent-script")) {
                    const auto script=edge.script.lock();if (!script || !script->live.load() || script->id!=edge.scriptId) return false;
                    const auto event=std::atomic_load(&script->event);scripts.append(script);evaluations.append(event);
                    result.insert("scriptDataId",edge.scriptId);
                    result.insert("evaluation",target>=0 ? readScriptDiagnostic(script,originals.at(target)->code) : QVariantMap());
                }
                edges.append(result);
            }
        }
        return stable();
    }
    bool stable() const {
        for (int i=0;i<states.size();++i)
            if (!states.at(i)->live.load() || states.at(i)->revision.load()!=originals.at(i)->revision
                    || std::atomic_load(&states.at(i)->value)!=originals.at(i)) return false;
        for (int i=0;i<scripts.size();++i)
            if (!scripts.at(i)->live.load() || std::atomic_load(&scripts.at(i)->event)!=evaluations.at(i)) return false;
        return true;
    }
    QVariantMap original() const {return {{"nodes",nodes},{"edges",edges}};}
};
}

QVariantMap CompilationUnit::overteE2eDependencyOriginal() const noexcept {
    QT_TRY {
        if (!OverteCacheOriginals::active() || !QCoreApplication::instance()
                || QThread::currentThread()!=QCoreApplication::instance()->thread()) return {};
        const auto state=std::atomic_load(&overteE2eDependencyState);if (!state) return {};
        const auto before=OverteCacheOriginals::clock();OverteDependencyPass first,second;
        if (!first.read(state) || !second.read(state) || first.original()!=second.original()
                || !first.stable() || !second.stable() || overteE2eCodeIdentity()!=second.originals.first()->code) return {};
        const auto after=OverteCacheOriginals::clock();
        const auto elapsed=after.value("monotonicMs").toLongLong()-before.value("monotonicMs").toLongLong();
        if (elapsed<0 || elapsed>=1500) return {};
        QVariantMap result{{"qtOverteQmlDependencyOriginalVersion",1},{"processId",QCoreApplication::applicationPid()},
            {"clockDomain","native-qt-steady-clock"},{"before",before},{"after",after},
            {"beforeOriginal",first.original()},{"afterOriginal",second.original()},
            {"coverage",QVariantMap{{"importGraphAvailable",false},{"aotGraphAvailable",false},{"nativeTypeCodeAvailable",false},
                {"dynamicDependenciesAvailable",false},{"currentRootEvaluationAvailable",false},
                {"dependencyMembershipCurrentAvailable",false},{"installedQtSourceAvailable",false}}}};
        return QJsonDocument::fromVariant(result).toJson(QJsonDocument::Compact).size()<=65536 ? result : QVariantMap();
    } QT_CATCH (...) {OverteCacheOriginals::fail();return {};}
}

QVariantMap CompilationUnit::overteE2eCacheOriginalForCurrentUnit() const
{
    QT_TRY {
        if (!OverteCacheOriginals::active() || !data || !backingFile || aotCompiledFunctions
                || overteE2eOwnerId.isEmpty() || overteE2eSourceGeneration>=1000000000) return {};
        const auto *pointer=data;const auto generation=overteE2eSourceGeneration;
        const auto bytes=pointer->unitSize;const auto before=OverteCacheOriginals::clock();
        const auto actual=backingFile->overteE2eOriginalFor(pointer);
        const auto after=OverteCacheOriginals::clock();
        if (actual.isEmpty() || data!=pointer || overteE2eSourceGeneration!=generation || pointer->unitSize!=bytes) return {};
        return {{QStringLiteral("qtOverteQmlCacheUnitVersion"),1},{QStringLiteral("clockDomain"),QStringLiteral("native-qt-steady-clock")},{QStringLiteral("processId"),QCoreApplication::applicationPid()},
            {QStringLiteral("unitOwnerId"),overteE2eOwnerId},{QStringLiteral("unitReadBefore"),before},{QStringLiteral("unitReadAfter"),after},
            {QStringLiteral("unitGeneration"),qulonglong(generation)},
            {QStringLiteral("unitBytes"),qlonglong(bytes)},
            {QStringLiteral("unitSha256"),actual.value(QStringLiteral("mappedSha256"))},
            {QStringLiteral("mappingOriginal"),actual}};
    } QT_CATCH (...) { OverteCacheOriginals::fail();return {}; }
}
#endif

QStringList CompilationUnit::moduleRequests() const
{
    QStringList requests;
    requests.reserve(data->moduleRequestTableSize);
    for (uint i = 0; i < data->moduleRequestTableSize; ++i)
        requests << stringAt(data->moduleRequestTable()[i]);
    return requests;
}

ResolvedTypeReference *CompilationUnit::resolvedType(QMetaType type) const
{
    for (ResolvedTypeReference *ref : std::as_const(resolvedTypes)) {
        if (ref->type().typeId() == type)
            return ref;
    }
    return nullptr;

}

void CompiledData::CompilationUnit::finalizeCompositeType(const QQmlType &type)
{
    // Add to type registry of composites
    if (propertyCaches.needsVMEMetaObject(/*root object*/0)) {
        // qmlType is only valid for types that have references to themselves.
        if (type.isValid()) {
            qmlType = type;
        } else {
            qmlType = QQmlMetaType::findCompositeType(
                    url(), this, (unitData()->flags & CompiledData::Unit::IsSingleton)
                            ? QQmlMetaType::Singleton
                            : QQmlMetaType::NonSingleton);
        }

        QQmlMetaType::registerInternalCompositeType(this);
    } else {
        const QV4::CompiledData::Object *obj = objectAt(/*root object*/0);
        auto *typeRef = resolvedTypes.value(obj->inheritedTypeNameIndex);
        Q_ASSERT(typeRef);
        qmlType = typeRef->type();
    }
}

bool CompilationUnit::verifyChecksum(const DependentTypesHasher &dependencyHasher) const
{
    if (!dependencyHasher) {
        for (size_t i = 0; i < sizeof(data->dependencyMD5Checksum); ++i) {
            if (data->dependencyMD5Checksum[i] != 0)
                return false;
        }
        return true;
    }
    const QByteArray checksum = dependencyHasher();
    return checksum.size() == sizeof(data->dependencyMD5Checksum)
            && memcmp(data->dependencyMD5Checksum, checksum.constData(),
                      sizeof(data->dependencyMD5Checksum)) == 0;
}

QQmlType CompilationUnit::qmlTypeForComponent(const QString &inlineComponentName) const
{
    if (inlineComponentName.isEmpty())
        return qmlType;
    return inlineComponentData[inlineComponentName].qmlType;
}

} // namespace CompiledData
} // namespace QV4

QT_END_NAMESPACE
