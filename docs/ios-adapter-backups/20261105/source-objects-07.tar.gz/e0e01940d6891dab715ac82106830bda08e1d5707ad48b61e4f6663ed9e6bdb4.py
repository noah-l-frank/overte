"""Explicit post-acquisition host events, written only after original refusal.

This optional diagnostic never supplies a verdict, original, clock join, phase
value or cache decision. All timestamps belong to this separate host event log.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,marshal,threading,time
from adapters.native_feature_observation import need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState

PROFILE='ios-lifecycle-post-acquisition-host-phases-v1'
EVENTS=frozenset(('acquisition-complete','observation-write-enter','observation-write-return',
    'first-validation-enter','first-validation-return','observation-index-enter','observation-index-return',
    'observation-save-enter','observation-save-return','publish-latest-enter','publisher-prepare-return',
    'publication-original-enter','publication-original-return','publisher-save-enter','publisher-decode-enter',
    'publisher-decode-return','publisher-save-return','publication-pending-enter','publication-pending-return',
    'scope-enter','scope-exit','policy-admitted','memo-allowed','original-refusal'))


class LifecycleSparseHostDiagnostic:
    def __init__(self,path):
        repo=Path.cwd().resolve(strict=True)
        need(repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file())
        self.path=Path(path)
        need(self.path.resolve().is_relative_to(repo)and self.path.name=='publication-post-acquisition-events.json')
        self.store=PrivateFeatureState(self.path);need(self.store.read()is None)
        self.observer=self.publisher=self.sink=self.policy=self.phase=None
        self.events=[];self.active=False;self.completed=False;self.refusal=None
        self.thread=threading.get_ident();self.now=time.perf_counter_ns;self.ident=threading.get_ident
        self.methods=tuple((name,value,value.__code__)for name,value in type(self).__dict__.items()
            if type(value)is type(type(self).__init__))
        self.receivers=();self.code_originals=()

    def bind(self,observer,publisher,sink):
        from ios.adapters.lifecycle_observer import LifecycleObserver
        from ios.adapters.lifecycle_publication_read_phase import ParserPolicy,LifecyclePublicationReadPhase
        from adapters.phase_witness_publisher import PhaseWitnessPublisher
        from adapters.phase_publication_refusal_original import PublicationRefusalOriginal
        need(self.observer is None and type(observer)is LifecycleObserver and observer.role=='actor'
            and type(publisher)is PhaseWitnessPublisher and type(sink)is PublicationRefusalOriginal
            and sink.owner is publisher and publisher.refusal_original is sink
            and publisher.validate_original.__self__ is observer and observer._publisher is publisher
            and observer.sparse_diagnostic is None and publisher.sparse_diagnostic is None
            and type(observer._publication_parser_policy)is ParserPolicy
            and observer._publication_parser_policy.sparse_diagnostic is None)
        self.observer,self.publisher,self.sink,self.policy=observer,publisher,sink,observer._publication_parser_policy
        targets=((LifecycleObserver,'observe'),(LifecycleObserver,'publish_latest'),(LifecycleObserver,'prepare_publication'),
            (LifecycleObserver,'validate_original'),(PhaseWitnessPublisher,'save'),(PhaseWitnessPublisher,'publish'),
            (PhaseWitnessPublisher,'publication_original'),(PhaseWitnessPublisher,'publication_pending'),
            (ParserPolicy,'admitted'),(LifecyclePublicationReadPhase,'memo_allowed'))
        self.receivers=tuple((cls,name,getattr(cls,name),getattr(cls,name).__code__)for cls,name in targets)
        self.code_originals=tuple(dict(receiver=cls.__name__+'.'+name,
            codeSha256=hashlib.sha256(marshal.dumps(code)).hexdigest())for cls,name,function,code in self.receivers)
        observer.sparse_diagnostic=publisher.sparse_diagnostic=self.policy.sparse_diagnostic=self
        return self

    def check(self):
        need(self.ident is threading.get_ident and self.now is time.perf_counter_ns and self.ident()==self.thread
            and not self.completed and self.observer is not None)
        for name,function,code in self.methods:need(type(self).__dict__.get(name)is function and function.__code__ is code)
        for cls,name,function,code in self.receivers:need(getattr(cls,name)is function and function.__code__ is code)
        need(self.observer.sparse_diagnostic is self and self.publisher.sparse_diagnostic is self
            and self.policy.sparse_diagnostic is self and self.publisher.refusal_original is self.sink)

    def begin(self,observer):
        self.check();need(observer is self.observer and not self.active and not self.events)
        self.active=True;self.event(observer,'acquisition-complete')

    def event(self,owner,stage,value=None):
        # Pre-acquisition prepare/save/guard activity is deliberately unobserved.
        if not self.active:return
        self.check();need(any(owner is actual for actual in(self.observer,self.publisher,self.policy,self.phase)))
        need(type(stage)is str and stage in EVENTS and len(self.events)<2048)
        need(value is None or type(value)is bool or type(value)is tuple and len(value)==4
            and all(type(number)is int and number>=0 for number in value))
        self.events.append(dict(sequence=len(self.events)+1,stage=stage,threadId=self.thread,
            hostPerfCounterNs=self.now(),value=value))

    def decision(self,owner,stage,value):
        need(type(value)is bool and stage in('policy-admitted','memo-allowed'))
        self.event(owner,stage,value) # Never read or replay a decision here.

    def phase_enter(self,phase):
        self.check();need(self.phase is None and phase.owner is self.observer and phase.policy is self.policy
            and phase.sparse_diagnostic is self)
        self.phase=phase;self.event(phase,'scope-enter')

    def phase_exit(self,phase):
        need(phase is self.phase)
        # Existing counters only, after the scope's original guard/admitted calls.
        stats=phase.stats
        self.event(phase,'scope-exit',(stats['cold'],stats['hits'],stats['literal'],len(phase.cache.rows)))

    def refused(self,publisher,sink,stage,condition):
        self.check();need(publisher is self.publisher and sink is self.sink and sink.written
            and condition is False and stage in('before-issued','after-issued')and self.refusal is None)
        self.event(publisher,'original-refusal',False);self.refusal=stage

    def finish(self,observer):
        self.check();need(observer is self.observer)
        if self.refusal is None:return # Positive or earlier failure: no invented refusal/output.
        original=self.sink.store.read()
        need(self.sink.written and original is not None and original['condition']is False
            and original['stage']==self.refusal and original['binding']==observer.binding
            and original['runId']==observer.run and self.sink.owner is self.publisher)
        need(self.events and self.events[0]['stage']=='acquisition-complete')
        value=dict(lifecycleSparseHostPhasesVersion=1,profile=PROFILE,binding=observer.binding,runId=observer.run,
            role=observer.role,refusalStage=self.refusal,refusalOriginalSha256=digest(original),
            timeBasis='separate-host-perf-counter-ns-not-native-or-acquisition-clock',
            actualCodeOriginals=list(self.code_originals),events=self.events)
        self.store.write(value,None);self.completed=True
