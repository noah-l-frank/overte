"""Root-only one-shot300+5 supervision; historical originals never excluded."""
from pathlib import Path
import argparse,builtins,hashlib,io,json,os,signal,subprocess,sys,threading,time,traceback
from metadata_reader import pin,load
from kernel import process,descendants,state,census,absent as kernel_absent
from host_common import head
from admission import require
from project_namespace_admission import project_namespace_admission
import global_original_corpus as global_corpus
HERE=Path(__file__).resolve().parent;REPO=HERE.parent.parent;OUTER=HERE.with_name(HERE.name+'-outer')
PORTS=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--approved-inputs-sha',required=True);args=parser.parse_args()
    assert sys.dont_write_bytecode and sys.flags.no_site==1 and Path.cwd()==REPO
    INPUT=HERE/'approved-inputs.json';assert hashlib.sha256(INPUT.read_bytes()).hexdigest()==args.approved_inputs_sha
    plan=load(INPUT);assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)and head()==plan['expectedHead']
    assert plan['wallSeconds']==300 and plan['killGraceSeconds']==5 and len(plan['cases'])==1
    current_readiness,current_readiness_pins=require(plan['rootAdmission'],pin)
    assert current_readiness==plan['qualifiedSourceExecution']and current_readiness['consumerCompositionQualified']is False
    assert plan['subjectSourceFreeze']==current_readiness['subjectSourceFreeze']and plan['subjectHelperSha256']==current_readiness['helperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
    assert pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
    assert plan['helperQualificationRequiredOriginalRooms']==current_readiness['requiredOriginalRoots']
    assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in current_readiness_pins.items())
    namespace_declared=dict(plan['modules'])
    for name,row in plan['projectAliasAdmission']['unadmittedAliases'].items():
        assert name not in namespace_declared;namespace_declared[name]=row['origin']
    namespace_modules,namespace_paths,namespace_original=project_namespace_admission(namespace_declared,
        (REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests'))
    assert namespace_modules==plan['modules']and namespace_paths==plan['originPlan']['namespacePackages']and namespace_original==plan['projectAliasAdmission']
    assert plan['originPlan']['modules']==plan['modules']and plan['originPlan']['projectAliasAdmission']==plan['projectAliasAdmission']
    for name,row in namespace_declared.items():
        assert row['path']in plan['sourceAndBinaryPins']and pin(row['path'])==plan['sourceAndBinaryPins'][row['path']]
        assert row['sha256']==plan['sourceAndBinaryPins'][row['path']]['sha256']

    assert plan['cases']==load(HERE/'exact-one-selector.json')and not OUTER.exists()
    assert not(HERE/'temporary').exists()and not(HERE/'child-logs').exists()and not(HERE/'child-receipts').exists()and not(HERE/'node-raw').exists()
    pins=plan['sourceAndBinaryPins'];before_pins={p:pin(p)for p in pins};assert before_pins==pins
    input_before=pin(INPUT);parent_before=state();ports_before={n:getattr(os,n)for n in PORTS if hasattr(os,n)};io_before=(io.open,builtins.open,os.dup,os.dup2,os.read)
    old=global_corpus.guard();assert len(old)==plan['oldRootCount']
    assert set(current_readiness['requiredOriginalRoots'])<=set(old)
    OUTER.mkdir(mode=0o700)
    def save(name,value):
        path=OUTER/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'w')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    save('source-binary-before.json',before_pins);save('approved-input-before.json',input_before);save('global-before.json',old)
    for name in('temporary','child-logs','child-receipts','node-raw'):(HERE/name).mkdir(mode=0o700)
    logs=HERE/'child-logs';fds=[]
    for name in('stdin.eof','stdout.log','stderr.log','term-stack.log'):
        fd=os.open(logs/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600);os.close(fd)
    start=time.monotonic();child=None;birth=None;observed={};forced=False;timed=False;signal_rows=[];problems=[];report=None
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(HERE/'temporary'))
    argv=[plan['pythonExecutable']['path'],'-B','-S',str(HERE/'run-one.py'),str(INPUT),args.approved_inputs_sha]
    save('actual-argv.json',dict(argv=argv,wallSeconds=300,drainSeconds=5,onlyOneSelector=plan['cases']))
    try:
        with(logs/'stdin.eof').open('rb')as stdin,(logs/'stdout.log').open('ab',buffering=0)as stdout,(logs/'stderr.log').open('ab',buffering=0)as stderr:
            child=subprocess.Popen(argv,stdin=stdin,stdout=stdout,stderr=stderr,cwd=REPO,env=env,start_new_session=True,close_fds=True)
            birth=process(child.pid,parent=os.getpid(),group=child.pid);assert birth is not None and birth['parent']==os.getpid()and birth['group']==child.pid
            save('actual-runner-birth.json',birth)
            while child.poll()is None and time.monotonic()-start<300:
                for pid,row in descendants(os.getpid()).items():
                    if pid!=child.pid:
                        assert row['group']==birth['group'];previous=observed.get(pid)
                        if previous is not None:assert previous['startTicks']==row['startTicks']
                        observed[pid]=row
                time.sleep(.1)
            if child.poll()is None:
                timed=True;actual=process(child.pid,expected=birth,parent=os.getpid(),group=child.pid);assert actual is not None and actual['startTicks']==birth['startTicks']and actual['group']==birth['group']
                members=descendants(os.getpid());assert all(row['group']==birth['group']for row in members.values())
                signal_rows.append(dict(signal='SIGTERM',group=birth['group'],identities=members));os.killpg(birth['group'],signal.SIGTERM)
                deadline=time.monotonic()+5
                while child.poll()is None and time.monotonic()<deadline:time.sleep(.05)
                remaining=descendants(os.getpid())
                if child.poll()is None or remaining:
                    forced=True
                    assert all(row['group']==birth['group']for row in remaining.values())
                    signal_rows.append(dict(signal='SIGKILL',group=birth['group'],identities=remaining));os.killpg(birth['group'],signal.SIGKILL)
            child.wait()
    except BaseException:
        problems.append(dict(gate='actual-supervision',traceback=traceback.format_exc()))
        if child is not None and child.poll()is None:
            actual=process(child.pid,expected=birth,parent=os.getpid(),group=child.pid)
            if birth is not None and actual is not None and actual['startTicks']==birth['startTicks']and actual['group']==birth['group']:
                forced=True;os.killpg(birth['group'],signal.SIGKILL);child.wait()
    def check(name,function):
        try:return function()
        except BaseException:problems.append(dict(gate=name,traceback=traceback.format_exc()));return None
    report=check('child-result',lambda:load(HERE/'child-receipts/child-result.json'))
    resource=check('actual-resource-ledger',lambda:load(HERE/'child-receipts/actual-resources.json'))
    restoration=check('actual-current-helper-restoration',lambda:load(HERE/'child-receipts/actual-restoration.json'))
    if report is not None:
        if report['subjectHelperSha256']!=plan['subjectHelperSha256']or report['currentSourceExecutionRootFreeze']!=current_readiness['rootFreeze']:problems.append(dict(gate='actual-current-helper-child-proof'))
    if restoration is None or restoration.get('actualC10dHelperSha256')!=plan['subjectHelperSha256']:problems.append(dict(gate='actual-current-helper-restored-source'))
    node_rows=[] if not resource else resource['nodes']
    if report and report['status']=='PASS':
        def nodes():
            assert len(node_rows)==3 and {r['role']for r in node_rows}=={'vm','marker-primary','marker-actor'}
            for row in node_rows:
                b=row['birth'];assert b['parent']==child.pid and b['group']==birth['group']and b['executable']==plan['node']['path']
                assert kernel_absent(b['pid']) and row['returnCode']==0 and not row['signals']
                assert {r['name']for r in row['streams']}=={'stdin','stdout','stderr'}and all(r['closed']for r in row['streams'])
            # Every sampled descendant must also belong to the actual child
            # ledger. Short-lived processes still require constructor receipts.
            assert set(observed)<={r['birth']['pid']for r in node_rows}
            return True
        check('three-actual-node-identities',nodes)
    absent=check('owned-kernel-absence',lambda:not descendants(os.getpid())and(child is None or kernel_absent(child.pid))and all(kernel_absent(r['birth']['pid']) for r in node_rows))
    if absent is not True:problems.append(dict(gate='owned-kernel-absence',value=absent))
    after_pins=check('source-binary-after',lambda:{p:pin(p)for p in pins});save('source-binary-after.json',after_pins)
    input_after=check('approved-input-after',lambda:pin(INPUT));save('approved-input-after.json',input_after)
    global_first=check('global-first',lambda:global_corpus.guard(new_root=HERE/'temporary'))
    global_second=check('global-second',lambda:global_corpus.guard(new_root=HERE/'temporary'))
    save('global-after-first.json',global_first);save('global-after-second.json',global_second)
    first=check('whole-child-first',lambda:census(HERE));second=check('whole-child-second',lambda:census(HERE))
    save('whole-child-first.json',first);save('whole-child-second.json',second)
    drain=state();save('actual-parent-drain.json',dict(before=parent_before,after=drain,equal=drain==parent_before))
    checks=dict(childReturnCode=child.returncode if child else None,actualChildReportPass=bool(report and report['status']=='PASS'and report['testsRun']==1),
        expectedHeadUnchanged=head()==plan['expectedHead'],pinsEqual=before_pins==after_pins,approvedInputEqual=input_before==input_after,
        allOldGlobalBodiesExact=bool(global_first and global_second and all(global_first.get(p)==v==global_second.get(p)for p,v in old.items())),
        twoCompleteGlobalCensusesEqual=global_first==global_second and global_first is not None,
        twoWholeChildCensusesEqual=first==second and first is not None,parentFDThreadKernelDrain=drain==parent_before,
        actualOriginalParentPorts=all(getattr(os,n)is fn for n,fn in ports_before.items())and io_before==(io.open,builtins.open,os.dup,os.dup2,os.read),
        ownedProcessesAbsent=absent is True)
    passed=child is not None and child.returncode==0 and not timed and not forced and not problems and all(v is True for k,v in checks.items()if k!='childReturnCode')
    save('terminal.json',dict(status='PASS'if passed else'FAIL',checks=checks,problems=problems,timedOut=timed,forcedKill=forced,
        actualElapsedSeconds=time.monotonic()-start,actualSignals=signal_rows,actualObservedDescendants=observed,newOriginalRootSpellings=[str(HERE),str(HERE/'temporary'),str(OUTER)],
        nativeQualified=False,wholeQualified=False,publicFinishEnabled=False))
    print(json.dumps(dict(status='PASS'if passed else'FAIL',terminal=str(OUTER/'terminal.json')),sort_keys=True));return 0 if passed else 1
if __name__=='__main__':sys.exit(main())
