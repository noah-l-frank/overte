from pathlib import Path
import ast,json,hashlib,difflib
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';F=T/'lifecycle-original-owner-final-lifetime-integration-20261028/candidate/repo';P=T/'lifecycle-original-owner-resource-borrow-proposal-20261028';P.mkdir(mode=0o700);h=lambda b:hashlib.sha256(b).hexdigest();rows=[];d=[]
def rep(s,a,b):assert s.count(a)==1,(a[:85],s.count(a));return s.replace(a,b,1)
def put(rel,base,s):
 b=base.read_bytes();q=P/'candidate/repo'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s)
 if q.suffix=='.py':ast.parse(s)
 rows.append(dict(path=rel,base=str(base),baseSHA256=h(b),candidate=str(q),candidateSHA256=h(q.read_bytes())))
 d.extend(difflib.unified_diff(b.decode().splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
rel='tests/device/ios/adapters/lifecycle_touch_resource_owner.py';base=R/rel;s=base.read_text();s=rep(s,'from copy import deepcopy','from copy import deepcopy\nfrom contextlib import asynccontextmanager')
s=rep(s,'    def make_lease(self,store,rsd,local_address,*,check,options=None):','    def make_lease(self,store,rsd,local_address,*,check,options=None,admit_begin=None,on_worker_birth=None,worker_lock=False):')
s=rep(s,'        self.current();need(self.previous is None and self._factory is None and callable(check))','''        self.current();need(self.previous is None and self._factory is None and callable(check)
            and type(worker_lock) is bool
            and all(callback is None or callable(callback) for callback in (admit_begin,on_worker_birth)))''')
s=rep(s,'        self._factory=factory;lease=TouchLease(store,factory,binding=self.binding,run=self.run,check=check)','''        if worker_lock:
            @asynccontextmanager
            async def selected_factory():
                # This SAME actual worker owns the actual lock across original
                # context entry/Down/Up/drain. Callers never nest it across an
                # await that can finish the worker's outer lock context.
                with self.lock.held():
                    async with factory() as hid:yield hid
        else:selected_factory=factory
        self._factory=selected_factory
        lease=TouchLease(store,selected_factory,binding=self.binding,run=self.run,check=check,
                         admit_begin=admit_begin,on_worker_birth=on_worker_birth)''')
put(rel,base,s)
rel='tests/device/ios/pymobiledevice3_wda_xctest.py';base=F/rel;s=base.read_text();s=rep(s,'    def touch_lease(self, store, *, binding, run, check):','    def touch_lease(self, store, *, binding, run, check, resource_owner=None):')
a='''        lease = TouchLease(store, session, binding=binding, run=run, check=continuity,
                           admit_begin=admission, on_worker_birth=self._birth)'''
b='''        if resource_owner is None:
            lease = TouchLease(store, session, binding=binding, run=run, check=continuity,
                               admit_begin=admission, on_worker_birth=self._birth)
        else:
            from ios.adapters.lifecycle_touch_resource_owner import LifecycleTouchResourceOwner
            if (type(resource_owner) is not LifecycleTouchResourceOwner
                    or resource_owner.binding!=binding or resource_owner.run!=run
                    or resource_owner.store.path.parent!=store.path.parent):
                raise LaunchError("session-lifetime")
            rsd,local_address=self.current()
            # The existing resource owner runs INSIDE the original lease
            # worker. Actual auth/RSD/stack/loop remain owned here, not in JSON.
            lease=resource_owner.make_lease(store,rsd,local_address,check=continuity,
                options={'socket_factory':self._source.udp_socket},admit_begin=admission,
                on_worker_birth=self._birth,worker_lock=True)'''
s=rep(s,a,b)
s=rep(s,'        self.issued={};self.operations=set();self.state_root=state_root','        self.issued={};self.operations=set();self.state_root=state_root;self.touch_resources=None')
a="        if operation=='touch-begin':\n            if self.touch is not None or set(args)!={'binding','runId','width','height','x','y','seconds'}:raise LaunchError('request')"
b="""        if operation in ('touch-resource-capture','touch-resource-recover'):
            resource=self.touch_resources
            if args or resource is None:raise LaunchError('request')
            # Existing live candidate/session checks apply to NEW captures.
            # Saved-only metadata recovery performs no SDK query or input.
            if operation=='touch-resource-capture':
                await self.fresh_touch_scope(self.touch._binding)
                if self.scope(session) is not rsd:raise LaunchError('session-lifetime')
            with resource.lock.held():
                value=resource.capture() if operation=='touch-resource-capture' else resource.recover_capture()
                original=resource.files.read(resource.files.expand(resource.state['frames'][-1]))
                if original!=value:raise LaunchError('session-lifetime')
                owner=resource.previous
            return dict(originalKeeperTouchResourceVersion=1,ownerInstance=self.instance,
                        capture=value,owner=owner,nativeTouchSupport=False,resourceRetirementEstablished=False)
        if operation=='touch-begin':
            if self.touch is not None or self.touch_resources is not None or set(args)!={'binding','runId','width','height','x','y','seconds'}:raise LaunchError('request')"""
s=rep(s,a,b)
a="""            self.touch=self.source.touch_lease(PrivateFeatureState(self.state_root/'original-touch-lease.json'),
                binding=binding,run=args['runId'],check=lambda:self.fresh_touch_scope(binding))"""
b="""            if type(args['runId']) is not str or re.fullmatch('[0-9a-f]{32}',args['runId']) is None:raise LaunchError('request')
            from adapters.script_feature.lock import ScriptSourceLock
            from ios.adapters.lifecycle_touch_resource_owner import LifecycleTouchResourceOwner
            original_session=self.session;original_source=self.source
            def resource_current():
                if self.session is not original_session or self.source is not original_source:
                    raise LaunchError('session-lifetime')
                original_source.current();return True
            lock=ScriptSourceLock(self.state_root/'script-feature-sources.lock')
            with lock.held():
                resource=LifecycleTouchResourceOwner(PrivateFeatureState(self.state_root/('ios-lifecycle-touch-resources-'+args['runId']+'.json')),
                    binding,args['runId'],lock,resource_current)
                # Retain the actual owner before an original factory/ACK can
                # fail. No restored WAL recreates an absent source or worker.
                self.touch_resources=resource
                self.touch=self.source.touch_lease(PrivateFeatureState(self.state_root/('ios-lifecycle-touch-lease-'+args['runId']+'.json')),
                    binding=binding,run=args['runId'],check=lambda:self.fresh_touch_scope(binding),resource_owner=resource)"""
s=rep(s,a,b);put(rel,base,s)
rel='tests/device/ios/appium_wda_host_ops.js';base=F/rel;s=base.read_text();s=rep(s,"['process-read', 'touch-begin', 'touch-release', 'touch-inspect', 'touch-settle'].includes(operation)","['process-read', 'touch-begin', 'touch-release', 'touch-inspect', 'touch-settle', 'touch-resource-capture', 'touch-resource-recover'].includes(operation)");put(rel,base,s)
rel='tests/device/ios/remotexpc_tunnel.py';base=F/rel;s=base.read_text();a='pending = ["ios.adapters.touch_lease", "ios.adapters.hid_session", "ios.adapters.lifecycle_touch_transport"]';b='pending = ["ios.adapters.touch_lease", "ios.adapters.hid_session", "ios.adapters.lifecycle_touch_transport", "ios.adapters.lifecycle_touch_resource_owner"]';s=rep(s,a,b);put(rel,base,s)
(P/'proposal.diff').write_text(''.join(d));(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE BOUNDED SAME-LOOP RESOURCE BORROW UNRUN',files=rows,baseFinal35Freeze='895712ef935a84bbacf58cbca3e657beafaf32fbdaea415076f21ecc9a657785',canonicalProductionAdmissionOpened=False,installedSourceAdmission=False,actualSDKAuthObserved=False,nativeTouchSupport=False),indent=2)+'\n');print(json.dumps(rows,indent=2))
