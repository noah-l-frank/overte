"""Exact7 pre-import Assets UI sources and10 literal existing screen regressions; no discovery/native/SDK/device execution."""
from pathlib import Path
import json,os,stat,sys,tempfile,threading,types,unittest
from importlib.machinery import PathFinder
from run_metadata import HERE,REPO,pin,proc,publication,save,sha,sources,registry_original,validate_frozen
assert len(sys.argv)==2
assert sys.argv[1] in validate_frozen()['suites']
kind=sys.argv[1];plan=dict(validate_frozen(),activeSelection=kind);selected=plan['suites'][kind];publication()
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/(kind+'-publication-ready-source-map.json');assert ready.is_file(),'Root must refresh after source publication'
runroot=Path(os.environ['OVERTE_ASSETS_CANONICAL_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs'/kind) and runroot!=HERE/'runs'/kind
info=runroot.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
temporary=Path(os.environ['TMPDIR']).resolve(strict=True)
assert temporary==runroot/'temporary' and Path(tempfile.gettempdir())==temporary
info=temporary.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
assert not any(temporary.iterdir()) and not (runroot/'selected-result.json').exists()
save(runroot/'runner-process-binding.json',proc(os.getpid()))
config=json.loads((HERE/'source-root-final-map.json').read_text())
approved=json.loads(ready.read_text());ready_pin=pin(ready)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
assert approved['broadSourceRoots']==plan['broadSourceRoots']
root=REPO.stat();assert approved['worktreeRoot']==str(REPO) and approved['rootIdentity']==dict(st_dev=root.st_dev,st_ino=root.st_ino)
source_before=sources(plan);assert source_before==approved['sourcePins'],'Current full Source membership/bytes differ from after-publication map'
assert 'interface/src/main.cpp' in source_before and approved['registry']==registry_original()
for row in config['modules'].values():assert row['path'] in source_before

def spec_without_import(name):
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:assert search is not None,name
    return spec

def preimport_source_roots():
    top_names={name.split('.')[0] for name in config['packageRoots']}
    assert not any(name.split('.')[0] in top_names for name in sys.modules),'Target imported before source preflight'
    expected=[str(REPO/name) for name in config['orderedRoots']];remaining=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==REPO or REPO in path.parents:continue
        if str(path) not in remaining:remaining.append(str(path))
    sys.path[:]=expected+remaining
    for name,relative in config['packageRoots'].items():
        spec=spec_without_import(name)
        assert [str(Path(path).resolve()) for path in spec.submodule_search_locations or ()]==[str(REPO/relative)],name
    actual={}
    for name,row in config['modules'].items():
        spec=spec_without_import(name);assert spec.origin is not None,name
        path=Path(spec.origin).resolve(strict=True)
        assert path==REPO/row['path'] and sha(path)==approved['sourcePins'][row['path']]['sha256'],name
        actual[name]=str(path)
    save(runroot/'preimport-source-map-actual.json',dict(orderedRoots=expected,modules=actual))
threads_before=set(threading.enumerate())
process_before_import=proc(os.getpid())
def current_group_processes():
    values=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        value=proc(int(path.name))
        if value is not None and (value['session']==process_before_import['session'] or value['processGroup']==process_before_import['processGroup']):values.append(value)
    return values
process_baseline={(row['pid'],row['startTicks']) for row in current_group_processes()}
save(runroot/'processes-before-target-imports.json',current_group_processes())
def remaining_children():
    return [row for row in current_group_processes() if (row['pid'],row['startTicks']) not in process_baseline]
# The audited SDK and process boundary is installed BEFORE target imports.
sdk_bad=('pymobiledevice3','tidevice','pyidevice','zeroconf')
sdk_attempts=[];execution_audit=[]
def forbidden_sdk_source(path):
    if type(path) not in (str,bytes):return False
    parts=Path(os.fsdecode(path)).parts
    return any(part in ('overte-ios-remotexpc',*sdk_bad) or any(part.startswith(bad+'_') for bad in sdk_bad) for part in parts)
def audit_loaded_sdk():
    bad=[]
    for name,module in tuple(sys.modules.items()):
        path=getattr(module,'__file__',None)
        if any(part in sdk_bad for part in name.split('.')) or forbidden_sdk_source(path):bad.append(dict(module=name,path=path))
    assert not bad,'SDK module/source was already imported'
    return bad
sdk_before=audit_loaded_sdk()
expected_markers=plan['hostExecutionAudit']['synchronousMarkerProgramSha256s']
expected_picker=[str(REPO/name) for name in ('tests/device/ios/self_tests/assets_picker_host.js',
    'interface/resources/qml/hifi/dialogs/TabletAssetServer.qml','interface/resources/qml/dialogs/NativeFileBrowser.qml',
    'interface/resources/qml/hifi/tablet/TabletNavigation.qml')]
def audit(event,args):
    if event=='import':
        name=args[0];path=args[1]
        if any(part in sdk_bad for part in name.split('.')) or forbidden_sdk_source(path):
            sdk_attempts.append(dict(event='import',module=name));raise RuntimeError('SDK import prohibited')
    elif event=='open':
        path=args[0]
        if isinstance(path,(str,bytes,os.PathLike)):
            parts=Path(os.fsdecode(path)).parts
            if any(part in ('overte-ios-remotexpc',*sdk_bad) for part in parts):
                sdk_attempts.append(dict(event='sdk-source-open'));raise RuntimeError('External SDK source/read prohibited')
    elif event=='subprocess.Popen':
        executable,arguments,cwd,environment=args
        assert type(arguments) in (tuple,list) and all(type(x) in (str,bytes) for x in arguments)
        argv=[os.fsdecode(x) for x in arguments];name=Path(os.fsdecode(executable)).name
        picker=name=='node' and argv[:5]==['node',*expected_picker] and argv[5:] in ([],[str(REPO/'interface/resources/qml/hifi/dialogs/NativeModelTree.qml')],[str(REPO/'interface/resources/qml/hifi/dialogs/NativeModelTree.qml'),'usage'])
        marker=name=='node' and len(argv)==3 and argv[:2]==['node','-e'] and __import__('hashlib').sha256(argv[2].encode()).hexdigest() in expected_markers
        metadata=name=='rg' and argv==['rg','--files','-0',*plan['broadSourceRoots']] and cwd is not None and Path(cwd)==REPO and environment is None
        if not (picker or marker or metadata):
            save(runroot/'refused-execution-metadata.json',dict(executableBasename=name,argumentCount=len(argv),nodeProgramSha256=__import__('hashlib').sha256(argv[2].encode()).hexdigest() if name=='node' and len(argv)==3 and argv[1]=='-e' else None))
        assert picker or marker or metadata,'Unselected SDK/build/service/execution command refused'
        execution_audit.append(dict(kind='assets-picker-node' if picker else 'original-marker-node' if marker else 'exact-metadata-rg'))
    elif event in ('socket.connect','socket.bind'):
        address=args[1]
        if isinstance(address,tuple):assert address[0] in ('127.0.0.1','::1','localhost'),'Only owned loopback fixtures selected'
    elif event in ('os.system','os.exec','os.posix_spawn'):
        raise RuntimeError('Unselected native/SDK execution refused')
sys.addaudithook(audit)
# Reviewed monitoring helper is loaded by exact pinned private path; no sys.path workaround.
import importlib.util
helper=HERE/'monitoring_observer.py';assert sha(helper)==plan['hostExecutionAudit']['monitoringObserverSha256']
spec=importlib.util.spec_from_file_location('assets_original_process_observer',helper)
assert spec is not None and spec.loader is not None and 'assets_original_process_observer' not in sys.modules
monitoring_module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=monitoring_module;spec.loader.exec_module(monitoring_module)
observer=monitoring_module.OriginalProcessObserver(proc).start()
preimport_source_roots()
from importlib import import_module
# Actual module-local producers only; global tempfile/subprocess stay untouched.
genuine_names=(
    'ios.self_tests.test_ios_assets_ui_samples','ios.self_tests.test_ios_graphics_images',
    'ios.self_tests.test_ios_tablet_web_screen_archive','ios.self_tests.test_ios_tablet_web_samples',
    'ios.self_tests.test_ios_assets_selected_end_profile','ios.self_tests.assets_paired_end_fixture',
    'ios.self_tests.test_ios_installed_code','test_asset_backend_source',
    'ios.self_tests.test_ios_assets_session_owners','ios.self_tests.test_ios_installed_adapter',
    'ios.self_tests.test_ios_assets_image_sample','ios.self_tests.test_ios_assets_image_ownership',
    'ios.self_tests.test_ios_create_marker_scope','ios.self_tests.test_ios_emote_marker_scope')
mkdtemp_names=('ios.self_tests.test_ios_assets_image_reader_lifecycle_sources','ios.self_tests.test_ios_assets_image_processing_sources',
    'ios.self_tests.test_ios_assets_image_storage_sources','ios.self_tests.test_ios_assets_image_pool_sources')
genuine_modules=[import_module(name) for name in genuine_names];mkdtemp_modules=[import_module(name) for name in mkdtemp_names]
from ios.self_tests import assets_picker_fixture as node_fixture
from ios.self_tests import emote_marker_domain_fixture as sync_node_fixture
from ios.self_tests.retained_host_roots import retain_owned_root
real_td=tempfile.TemporaryDirectory;real_mkdtemp=tempfile.mkdtemp;retained=[];objects=[];root_identities=[]
def record_root(root,kind):
    root=Path(root);info=root.lstat()
    assert root.is_relative_to(temporary) and root.resolve(strict=True)==root
    assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
    retained.append(str(root));root_identities.append(dict(root=str(root),producer=kind,device=info.st_dev,inode=info.st_ino))
    save(runroot/'created-original-roots.json',retained);save(runroot/'created-original-root-identities.json',root_identities)
    return root
def retained_directory(*args,**kwargs):
    directory=real_td(*args,**kwargs);root=record_root(directory.name,'genuineTemporaryDirectory')
    retain_owned_root(directory,expected_root=root);objects.append(directory);return directory
def observed_mkdtemp(*args,**kwargs):return str(record_root(real_mkdtemp(*args,**kwargs),'originalMkdtemp'))
def roots_guard():
    for row in root_identities:
        p=Path(row['root']);info=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(temporary)
        assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
        assert (info.st_dev,info.st_ino)==(row['device'],row['inode'])
aliases=[(module,module.tempfile) for module in (*genuine_modules,*mkdtemp_modules)]
node_original=node_fixture.subprocess;node_children=[]
def node_popen(*args,**kwargs):
    child=node_original.Popen(*args,**kwargs);node_children.append((child,proc(child.pid)));return child
node_fixture.subprocess=types.SimpleNamespace(Popen=node_popen,PIPE=node_original.PIPE,TimeoutExpired=node_original.TimeoutExpired)
sync_original=sync_node_fixture.subprocess;sync_nodes=[]
def observed_run(*args,**kwargs):
    event=dict(entered=True,returned=False);sync_nodes.append(event)
    save(runroot/'actual-synchronous-node-observations.json',sync_nodes)
    try:
        result=sync_original.run(*args,**kwargs)
        event.update(returned=True,exitCode=result.returncode,
            stdoutBytes=None if result.stdout is None else len(result.stdout),stderrBytes=None if result.stderr is None else len(result.stderr))
        return result
    finally:save(runroot/'actual-synchronous-node-observations.json',sync_nodes)
sync_node_fixture.subprocess=types.SimpleNamespace(run=observed_run)
case_receipts=[];case_audit_failures=[];result=None;actual_ids=[]
def nodes_since(index):
    return [dict(binding=binding,exitCode=child.poll(),stdinClosed=child.stdin.closed,stdoutClosed=child.stdout.closed,stderrClosed=child.stderr.closed)
        for child,binding in node_children[index:]]
def clean_nodes(rows):return all(x['binding'] is not None and x['exitCode'] is not None and x['stdinClosed'] and x['stdoutClosed'] and x['stderrClosed'] for x in rows)

class ImmediateResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.error_serial=0
    def startTest(self,test):
        self.case_node_start=len(node_children);self.case_sync_start=len(sync_nodes)
        super().startTest(test)
    def stopTest(self,test):
        # Actual unittest tearDown/doCleanups have returned before this hook.
        nodes=nodes_since(self.case_node_start)
        threads=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
        processes=remaining_children();sync=sync_nodes[self.case_sync_start:]
        expected_nodes=selected['expectedNodeChildrenPerCaseNotProof']
        clean=not threads and not processes and (expected_nodes is None or len(nodes)==expected_nodes) and clean_nodes(nodes) and all(x['returned'] and x['exitCode']==0 for x in sync)
        row=dict(testId=test.id(),originalCleanupsReturned=True,nodeCloseObservations=nodes,synchronousNodeOriginalRuns=sync,
            remainingNewThreads=threads,remainingOwnedChildren=processes,cleanAtCaseBoundary=clean)
        case_receipts.append(row)
        path=runroot/('case-stop-receipt-'+format(len(case_receipts),'06d')+'.json')
        descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(descriptor,'w') as output:
            output.write(json.dumps(row,indent=2,sort_keys=True)+'\n');output.flush();os.fsync(output.fileno())
        if not clean:case_audit_failures.append(test.id())
        super().stopTest(test)

    def report_exception(self,test,error,kind):
        import traceback
        # Preserve the original traceback immediately, BEFORE any optional
        # metadata diagnostic. Never capture generic locals or configuration.
        text=''.join(traceback.format_exception(*error))
        pending=[error[1]];seen=set();chain=[]
        while pending and len(chain)<64:
            actual=pending.pop()
            if id(actual) in seen:continue
            seen.add(id(actual));chain.append(dict(type=type(actual).__name__,module=type(actual).__module__,
                traceback=''.join(traceback.format_exception(type(actual),actual,actual.__traceback__,chain=False)),suppressContext=actual.__suppress_context__))
            for linked in (actual.__context__,actual.__cause__):
                if linked is not None:pending.append(linked)
        self.error_serial+=1
        path=runroot/('explicit-original-exception-chain-'+format(self.error_serial,'06d')+'.json')
        descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(descriptor,'w') as output:
            output.write(json.dumps(dict(testId=test.id(),event=kind,exceptions=chain),indent=2,sort_keys=True)+'\n')
            output.flush();os.fsync(output.fileno())
        self.stream.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text)
        self.stream.flush()
        descriptor=os.open(runroot/'immediate-exceptions.log',os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
        with os.fdopen(descriptor,'a') as output:
            output.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text);output.flush();os.fsync(output.fileno())
    def addError(self,test,error):
        super().addError(test,error);self.report_exception(test,error,'ERROR')
    def addFailure(self,test,error):
        super().addFailure(test,error);self.report_exception(test,error,'FAILURE')
    def addSubTest(self,test,subtest,error):
        super().addSubTest(test,subtest,error)
        if error is not None:self.report_exception(subtest,error,'SUBTEST_ERROR')

try:
    for module,original in aliases:assert original is tempfile
    for module in genuine_modules:module.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_directory)
    for module in mkdtemp_modules:module.tempfile=types.SimpleNamespace(mkdtemp=observed_mkdtemp)
    ids=selected['caseIds'];assert len(ids)==len(set(ids))==selected['count']
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for child in value:yield from flatten(child)
        else:yield value
    actual_ids=[test.id() for test in flatten(suite)]
    assert not loader.errors and actual_ids==ids and suite.countTestCases()==selected['count'],(loader.errors,actual_ids)
    save(runroot/'selected-ids-actual.json',actual_ids);print('ACTUAL_SELECTED_IDS',json.dumps(actual_ids),flush=True)
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=ImmediateResult).run(suite)
    assert result.testsRun==selected['count'] and not result.skipped,'All exact cases must execute without skip'
    if result.wasSuccessful() and selected['expectedRetainedRootsNotProof'] is not None:assert len(retained)==selected['expectedRetainedRootsNotProof'],'Unexpected actual root count'
finally:
    for module,original in aliases:module.tempfile=original
    node_fixture.subprocess=node_original;sync_node_fixture.subprocess=sync_original
    assert tempfile.TemporaryDirectory is real_td and tempfile.mkdtemp is real_mkdtemp and all(m.tempfile is original for m,original in aliases)
    imported={}
    for name,module in tuple(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if file is not None:
            path=Path(file).resolve()
            if REPO in path.parents:
                relative=str(path.relative_to(REPO));assert relative in source_before,(name,relative);imported[name]=relative
    save(runroot/'actual-imported-local-sources.json',imported)
    assert source_before==sources(plan) and pin(ready)==ready_pin
    assert registry_original()==approved['registry']
    def census():return {str(p.relative_to(temporary)):pin(p) for p in (temporary,*sorted(temporary.rglob('*')))}
    threads_first=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
    processes_first=remaining_children();nodes=nodes_since(0);roots_guard();first=census();second=census();roots_guard()
    save(runroot/'selected-originals-first.json',first);save(runroot/'selected-originals-second.json',second)
    threads_second=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
    processes_second=remaining_children()
    complete=result is not None and result.testsRun==selected['count'] and not result.skipped
    node_complete=(selected['expectedNodeChildrenTotalNotProof'] is None or len(nodes)==selected['expectedNodeChildrenTotalNotProof']) and clean_nodes(nodes) and all(x['returned'] and x['exitCode']==0 for x in sync_nodes)
    sdk_after=audit_loaded_sdk()
    observed_processes=[]
    for row in observer.processes:
        process=row['process'];current=proc(row['pid'])
        streams={name:None if getattr(process,name) is None else getattr(process,name).closed for name in ('stdin','stdout','stderr')}
        observed_processes.append(dict(pid=row['pid'],birth=row['birth'],current=current,commandKind=row['commandKind'],constructorOutcome=row['constructorOutcome'],returnCode=process.returncode,originalStreamsClosed=streams))
    observer.stop();observer_receipt=observer.metadata()
    save(runroot/'actual-all-original-processes.json',dict(processes=observed_processes,observer=observer_receipt,executions=execution_audit))
    assert not sdk_attempts and not sdk_before and not sdk_after
    assert all(row['returnCode'] is not None and (row['current'] is None or row['birth'] is not None and row['current']['startTicks']!=row['birth']['startTicks']) and all(closed is None or closed is True for closed in row['originalStreamsClosed'].values()) for row in observed_processes)
    report=dict(actualSDKNameAndSourceImportAuditInstalled=True,sdkImportAttempts=sdk_attempts,sdkModulesBefore=sdk_before,sdkModulesAfter=sdk_after,originalProcessMonitoring=observer_receipt,actualObservedSubprocesses=observed_processes,kind=kind,testsRun=None if result is None else result.testsRun,selectedIds=actual_ids,successful=complete and result.wasSuccessful() and node_complete and not case_audit_failures,
        caseStopReceipts=case_receipts,caseAuditFailures=case_audit_failures,originalProducerRoots=root_identities,originalNodeCloseObservations=nodes,synchronousOriginalNodeRuns=sync_nodes,synchronousNodeProducerRestored=sync_node_fixture.subprocess is sync_original,
        fixtureAliasesRestored=all(m.tempfile is original for m,original in aliases),nodeProducerAliasRestored=node_fixture.subprocess is node_original,
        sourceLauncherPinsUnchanged=True,originalCensusesEqual=first==second,remainingOwnedChildrenBeforeCensuses=processes_first,remainingOwnedChildrenAfterCensuses=processes_second,
        remainingNewThreadsBeforeCensuses=threads_first,remainingNewThreads=threads_second,nativeCompiled=False,sdkExecuted=False,wholeAssetsQualified=False)
    save(runroot/'selected-result.json',report);print('ACTUAL_RESULT',json.dumps(report),flush=True)
    assert first==second and not threads_first and not threads_second and not processes_first and not processes_second and not case_audit_failures
    if complete and result.wasSuccessful():assert node_complete and (selected['expectedRetainedRootsNotProof'] is None or len(retained)==selected['expectedRetainedRootsNotProof'])
sys.exit(0 if result is not None and result.wasSuccessful() and not case_audit_failures else 1)
