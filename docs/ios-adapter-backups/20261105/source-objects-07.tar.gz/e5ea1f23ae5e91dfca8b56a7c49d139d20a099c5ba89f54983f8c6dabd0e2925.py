"""Passive original-function host costs, never a Chat/effect/time verdict.

The engine is copied exactly from Root World Source11. This adapter supplies
only genuine current C10d module/execution tuples and finite Chat targets.
"""
from pathlib import Path
from types import ModuleType,FunctionType
import sys,threading
from host_function_timing import HostFunctionTimings

TARGETS=(
    ('ios.adapters.chat_archive_round',None,('module_signature','original_methods','inventory','factory','memory','proof_key','decode','qml_authority')),
    ('ios.adapters.chat_archive_round','ArchiveRound',('__init__','check','run','close')),
    ('ios.adapters.chat_draft_owner','IOSChatDraftOwner',('decode','decode_body','_frame','frame','original')),
    ('ios.adapters.chat_receive_sources','IOSChatReceiveSources',('decode','decode_body','frame','original')),
    ('ios.adapters.chat_peer_receipts','IOSChatPeerReceipts',('read','before','effect')),
    ('ios.adapters.chat_send_receive',None,('original_sent',)),
)
ENGINE_SHA='2ad2223660ddc2948066523d491feeca458c9d9fb1be277c08f862825a0dccb0'
MAX_UNFINISHED_ROWS=64


class ChatHostCosts:
    def __init__(self,plan,origins,pin):
        self.plan,self.origins,self.pin=plan,origins,pin
        assert origins.plan is plan and type(plan)is dict
        module=sys.modules['host_function_timing'];row=plan['modules']['host_function_timing'];path=Path(row['path'])
        assert type(module)is ModuleType and vars(module)['__file__']==str(path)and pin(path)['sha256']==ENGINE_SHA==row['sha256']
        execution=origins.python_executions['host_function_timing']
        assert type(execution)is tuple and len(execution)==4 and execution[0]is module and execution[1]==path and execution[2]==ENGINE_SHA
        receipt=origins.execution_row('host_function_timing',module,path)
        assert receipt['kind']=='fresh-pinned-python-source-bytes'and receipt['cachedBytecodeConsulted']is False and receipt['sourceSha256']==ENGINE_SHA
        self.timer=HostFunctionTimings(TARGETS);self.binding_receipts={};self.installed=False
        self.thread=threading.get_ident();self.errors=[];self.term_attempted=False;self.restoration=None
        for name in dict.fromkeys(row[0]for row in TARGETS):
            actual=sys.modules[name];source=plan['modules'][name];file=Path(source['path'])
            original=origins.python_executions[name]
            assert type(actual)is ModuleType and vars(actual)['__file__']==str(file)
            assert type(original)is tuple and len(original)==4 and original[0]is actual and original[1]==file and original[2]==source['sha256']
            saved=origins.execution_row(name,actual,file)
            assert saved['kind']=='fresh-pinned-python-source-bytes'and saved['cachedBytecodeConsulted']is False and saved['sourceSha256']==source['sha256']
            self.timer.bind_module(actual,source,original,pin);self.binding_receipts[name]=saved
        assert len(self.timer.bindings)==25 and not self.timer.excluded
        self.controls=tuple((name,fn,fn.__code__,fn.__globals__)for name,fn in type(self).__dict__.items()if type(fn)is FunctionType)

    def bound(self):
        assert threading.get_ident()==self.thread and self.origins.plan is self.plan
        for name,fn,code,namespace in self.controls:
            assert type(self).__dict__[name]is fn and fn.__code__ is code and fn.__globals__ is namespace
        self.timer._control_bound()

    def install(self):
        self.bound();assert not self.installed
        self.timer.install();self.installed=True

    def snapshot(self,phase):
        self.bound();assert type(phase)is str
        # Snapshot is outside event callbacks. The engine callback stack holds
        # only code objects, numeric frame IDs, times/counts and fixed labels.
        # No frame, self, argument, native getter or decoded value is copied.
        value=self.timer.snapshot();self.timer._control_bound()
        now_wall=self.timer.wall();now_cpu=self.timer.cpu()
        stack=self.timer.stack;total=len(stack)
        selected=list(range(total))if total<=MAX_UNFINISHED_ROWS else list(range(16))+list(range(total-48,total))
        partial=[]
        for index in selected:
            row=stack[index];self.timer._definition_bound(row[0])
            wall=now_wall-row[2];cpu=now_cpu-row[3]
            active_child_wall=0 if index+1==total else now_wall-stack[index+1][2]
            active_child_cpu=0 if index+1==total else now_cpu-stack[index+1][3]
            exclusive_wall=wall-row[4]-active_child_wall;exclusive_cpu=cpu-row[5]-active_child_cpu
            assert min(wall,cpu,exclusive_wall,exclusive_cpu)>=0
            partial.append(dict(label=row[6],selectedStackIndex=index,inclusiveSoFarWallNs=wall,inclusiveSoFarThreadCpuNs=cpu,
                exclusiveAmongSelectedSoFarWallNs=exclusive_wall,exclusiveAmongSelectedSoFarThreadCpuNs=exclusive_cpu,
                partial=True,originalReturnOrUnwindObserved=False))
        return dict(profile='chat-paired-host-cost-source11-v1',phase=phase,diagnosticOnly=True,
            originalCaseOrFeatureQualificationGranted=False,currentPairedConsumerQualified=False,
            actualFreshSourceBindings=self.binding_receipts,engineSourceSha256=ENGINE_SHA,
            engineSnapshot=value,unfinishedSelectedCalls=total,unfinishedRows=partial,unfinishedRowsTruncated=total>MAX_UNFINISHED_ROWS,
            activeRowsArePartial=True,includesObserverAndSignalHandlerOverhead=True,
            exclusiveMeaning='subtract completed and active directly nested SELECTED calls; unselected work remains included',
            noCausalOrSpeedConclusion=True,noNativeClockQueryOrRetiming=True,noDecodedValuesFramesOrRuntimeOwnersRecorded=True,
            originalWallLimitSeconds=300,originalGraceSeconds=5,nativeQualified=False,wholeQualified=False)

    def restore(self):
        self.bound()
        self.restoration=self.timer.restore();self.installed=False
        return self.restoration
