"""Private fixed180 forensic supervisor; survives the child's outer timeout."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import time

root=Path.cwd();private=root/'.ios-host-tmp'
output=private/'snapshot-photos-end-normal17-forensic-cprofile02'
output.mkdir(mode=0o700,exist_ok=True)
child=private/'profile-snapshot-photos-end-normal17-cprofile02.py'
roots=tuple(private/name for name in ('tmpb5jf228l','snapshot-companion-oh487x71','snapshot-companion-gz75s566'))
def pin(path):
    before=path.lstat();row=dict(stat=[before.st_dev,before.st_ino,before.st_mode,before.st_uid,before.st_gid,before.st_nlink,before.st_size,before.st_mtime_ns,before.st_ctime_ns])
    if stat.S_ISREG(before.st_mode):
        descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        with os.fdopen(descriptor,'rb') as stream:
            actual=os.fstat(stream.fileno())
            if (actual.st_dev,actual.st_ino)!=(before.st_dev,before.st_ino):raise AssertionError('Changed original inode')
            digest=hashlib.sha256()
            for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
        row['sha256']=digest.hexdigest()
    elif not stat.S_ISDIR(before.st_mode):raise AssertionError('Nonregular original')
    after=path.lstat()
    if row['stat']!=[after.st_dev,after.st_ino,after.st_mode,after.st_uid,after.st_gid,after.st_nlink,after.st_size,after.st_mtime_ns,after.st_ctime_ns]:raise AssertionError('Changed original during census')
    return row
def originals():
    return {str(path):pin(path) for folder in roots for path in (folder,*sorted(folder.rglob('*')))}
def sources():
    paths=[path for path in (root/'tests/device').rglob('*') if path.is_file() and path.suffix in ('.py','.js','.cjs','.json','.qml','.html','.h','.cpp','.md') and '__pycache__' not in path.parts]
    paths.extend((child,Path(__file__)))
    return {str(path.relative_to(root)):pin(path) for path in sorted(paths)}
def save(name,value):(output/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
before=originals();source_before=sources();save('supervisor-originals-before.json',before);save('supervisor-sources-before.json',source_before)
print('FORENSIC_UNTRUSTED_POLICY_NO_AUTHORITY','START','originals',len(before),'sources',len(source_before),'fixed_outer_seconds',180,flush=True)
task_env=os.environ.copy();task_env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.:tests/device:tests/device/self_tests:tests/device/ios/self_tests')
started=time.monotonic();log=output/'forensic01.log'
with log.open('w') as stream:result=subprocess.run(['timeout','--signal=TERM','--kill-after=5s','180s','python3',str(child)],env=task_env,stdout=stream,stderr=subprocess.STDOUT)
after=originals();source_after=sources();save('supervisor-originals-after.json',after);save('supervisor-sources-after.json',source_after)
changed=[name for name in set(before)|set(after) if before.get(name)!=after.get(name)]
changed_source=[name for name in set(source_before)|set(source_after) if source_before.get(name)!=source_after.get(name)]
report=dict(label='FORENSIC_UNTRUSTED_POLICY_NO_AUTHORITY',authority=False,exitCode=result.returncode,elapsedSeconds=time.monotonic()-started,changedOriginals=sorted(changed),changedSources=sorted(changed_source),log=str(log))
save('supervisor-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
raise SystemExit(result.returncode if not changed and not changed_source else 98)
