"""Original-only PNG Before/Primary-cut/PNG After composition.

One PNG-only canonical family. No acquisition, transport, deadline or journal
write is owned here. Existing Scene-family publication remains a separate API.
"""
from copy import deepcopy
from adapters.native_clock_join import digest
from adapters.native_feature_observation import integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from ios.adapters.graphics_history import follow_native
from ios.adapters.snapshot_actor_pixel_set import SnapshotActorPixelSet
from ios.adapters.snapshot_actor_pixel_publication import SnapshotActorPixelCanonicalPublication
from ios.adapters.snapshot_actor_primary_png_join import SnapshotActorPrimaryPNGJoin
from ios.adapters.snapshot_capture_owner import IOSSnapshotCaptureOwner
from ios.adapters.snapshot_page_owner import IOSSnapshotPageOwner
from ios.adapters.snapshot_scene_capture_order import SnapshotSceneCaptureOrder
from ios.adapters import snapshot_actor_pixels


class SnapshotActorTemporalPNGJoin:
    def __init__(self,page,primary_before,before,after):
        need(type(page)is IOSSnapshotPageOwner and page.historical is True and page.combined_profile()
            and type(primary_before)is dict
            and type(before)is SnapshotActorPrimaryPNGJoin and type(after)is SnapshotActorPrimaryPNGJoin
            and before.capture is after.capture and before.provenance is after.provenance
            and before.publication is after.publication
            and before.actor.index<after.actor.index
            and before.actor.lock is after.actor.lock and same(before.actor.binding,after.actor.binding)
            and before.actor.store.path.parent==after.actor.store.path.parent)
        capture=before.capture
        need(page.lock is capture.lock and same(page.binding,capture.binding)and page.run==capture.run
            and page.fixture_url==capture.phase.fixture_url and page.store.path.parent==capture.store.path.parent)
        self.page,self.primary_before,self.before,self.after=page,deepcopy(primary_before),before,after

    @staticmethod
    def stamp(clock,which):
        return dict(epochMs=clock['host'+which+'EpochMs'],monotonic=clock['host'+which+'Monotonic'])

    def proof(self):
        # Existing readers revalidate exact PFS/OFS originals, their native
        # clock brackets, phase prefixes, canonical records and actual PNGs.
        self.page.bound();capture=self.before.capture;capture.bound()
        before_pixels=self.before.proof();after_pixels=self.after.proof()
        before=self.before.actor.validate_original(self.before.actor_original)
        after=self.after.actor.validate_original(self.after.actor_original)
        need(before['ticket']==after['ticket']==capture.state['ticket']==self.page.state['ticket'])
        records=self.page.state['records'];index=self.primary_before.get('index')
        need(integer(index,1,len(records))and same(records[index-1],self.primary_before))
        anchor=self.page.original(self.primary_before)
        need(self.page.route(anchor)['kind']=='snapshot')
        phase=capture.state['phaseOriginal']
        for original in(anchor,before,after):
            for key in('phaseBefore','phaseAfter'):
                need(original[key]['instance']==phase['instance']and original[key]['runId']==phase['runId']
                    and same(original[key]['activations'],phase['activations']))
        provenance=self.before.provenance.historical()
        primary=self.before.provenance.join_capture(capture)['provenance']['frame']
        a=before['nativeOriginal']['packet'];b=after['nativeOriginal']['packet']
        # Follow each OWN role's native sequence. Numeric PIDs on different
        # targets are never compared to infer identity or independence.
        follow_native(before['clockJoin']['nativeAfter'],after['clockJoin']['nativeBefore'])
        snapshot_actor_pixels.validate(b,after['nativeOriginal']['query'],int(self.after.actor.binding['processIdentity']),previous=a)
        follow_native(anchor['clockJoin']['nativeAfter'],provenance['acquisition']['nativeBefore'])
        first=a['source']['frame'];last=b['source']['frame']
        need(last['frameInstance']!=first['frameInstance']and last['frameIndex']>first['frameIndex'])
        need(primary['recordedEpochMs']>anchor['clockJoin']['nativeAfter']['capturedEpochMs'])
        need(last['recordedEpochMs']>=after['clockJoin']['nativeBefore']['capturedEpochMs']
            and last['consumedEpochMs']>=after['clockJoin']['nativeBefore']['capturedEpochMs'])
        start=self.stamp(before['clockJoin'],'After');cut_before=self.stamp(anchor['clockJoin'],'Before')
        cut_after=self.stamp(provenance['acquisition'],'After');finish=self.stamp(after['clockJoin'],'Before')
        need(start['epochMs']<=cut_before['epochMs']and start['monotonic']<=cut_before['monotonic']
            and cut_after['epochMs']<=finish['epochMs']and cut_after['monotonic']<=finish['monotonic'])
        # Reuse the original bounded epoch/monotonic agreement predicate on
        # SAVED intervals only. This starts/rebases no operation or live clock.
        SnapshotSceneCaptureOrder.span(self.stamp(before['clockJoin'],'Before'),self.stamp(after['clockJoin'],'After'))
        return dict(iosSnapshotActorTemporalPNGJoinVersion=1,profile='canonical-png-before-primary-native-cut-after-original-v1',
            runId=capture.run,ticket=capture.state['ticket'],primaryBinding=deepcopy(capture.binding),actorBinding=deepcopy(self.before.actor.binding),
            primaryBeforeOriginalSha256=digest(anchor),primaryBeforeReference=deepcopy(self.primary_before),
            primaryProvenanceOwnerSha256=digest(self.before.provenance.previous),
            actorBeforeOriginalSha256=digest(self.before.actor_original),actorAfterOriginalSha256=digest(self.after.actor_original),
            actorBeforeComparison=before_pixels,actorAfterComparison=after_pixels,
            originalHostCuts=dict(actorBeforeEnd=start,primaryAnchorStart=cut_before,primaryProvenanceEnd=cut_after,actorAfterStart=finish),
            actorBeforePrimaryCaptureActorAfterOriginalOrderEstablished=True,
            bothCanonicalPNGOriginalsAndExactCropsEstablished=True,newCaptureOrQueryOrPOST=False,
            historicalOriginalsOnly=True,liveFreshnessOrDeadlineRebase=False,unknownInputResendAllowed=False,
            legacyCanonicalScenePublicationClaimed=False,independentProcessAuthenticationEstablished=False,
            completeSceneAppearanceFidelityEstablished=False,destinationCompositionEstablished=False,processOrSDKEndEstablished=False,
            nativeCompiled=False,nativeQualified=False,deviceQualified=False,wholeQualified=False)


def retained_temporal_pixel_join(page,primary_before,provenance_index,actors,before_index,after_index):
    need(type(page)is IOSSnapshotPageOwner and page.combined_profile()and type(actors)is SnapshotActorPixelSet
        and type(primary_before)is dict and integer(provenance_index,1,128)
        and integer(before_index,1,8)and integer(after_index,before_index+1,8))
    page.lock.assert_held();actors.lock.assert_held()
    saved_page=IOSSnapshotPageOwner.archive(page.store,page.lock,page.binding,page.run,page.fixture_url,combined=True)
    capture=IOSSnapshotCaptureOwner.archive(PrivateFeatureState(page.store.path.with_name('ios-snapshot-primary-capture-owner.json')),
        page.lock,page.binding,page.run,page.fixture_url,combined=True)
    provenance=capture.history('provenance',provenance_index)
    history=SnapshotActorPixelSet(actors.root,actors.lock,actors.binding,actors.run,actors.fixture_url)
    publication=SnapshotActorPixelCanonicalPublication(history,historical=True)
    before=history.owner(before_index,historical=True);after=history.owner(after_index,historical=True)
    first=SnapshotActorPrimaryPNGJoin(capture,provenance,before,before.original(),publication)
    last=SnapshotActorPrimaryPNGJoin(capture,provenance,after,after.original(),publication)
    return SnapshotActorTemporalPNGJoin(saved_page,primary_before,first,last)
