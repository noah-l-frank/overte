"""Outer true kernel boundary for exactly5 Moving navigation model counters, fixed30+5."""
from pathlib import Path
import hashlib,json,os,signal,stat,subprocess,sys,threading,time,traceback
REPO=Path.cwd().resolve(strict=True);HERE=Path(__file__).resolve().parent
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert len(sys.argv)==2
INPUT=HERE/'approved-inputs.json';assert hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[1]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert plan['wallSeconds']==30 and plan['killGraceSeconds']==5 and len(plan['cases'])==5

def checked(path):
    path=Path(path);assert path.resolve().is_relative_to(REPO);return path

def meta(info):return[info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns]
def pin(path):
    path=Path(path);a=path.lstat();assert path.resolve(strict=True)==path and stat.S_ISREG(a.st_mode)
    descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        assert meta(os.fstat(descriptor))==meta(a)
        with os.fdopen(descriptor,'rb',closefd=False)as stream:raw=stream.read()
        assert len(raw)==a.st_size and meta(os.fstat(descriptor))==meta(a)and meta(path.lstat())==meta(a)
    finally:os.close(descriptor)
    return dict(stat=meta(a),sha256=hashlib.sha256(raw).hexdigest())
def census(root):
    result={}
    def visit(path):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):
            names=sorted(item.name for item in path.iterdir());row=dict(stat=meta(info),namespace=names)
            for name in names:visit(path/name)
            assert meta(path.lstat())==meta(info)
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        result[str(path.relative_to(root))]=row
    visit(root);return result

def identity(pid):
    try:text=Path('/proc',str(pid),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    values=text[text.rfind(')')+2:].split()
    return dict(pid=int(text[:text.index('(')].strip()),parent=int(values[1]),group=int(values[2]),session=int(values[3]),startTicks=int(values[19]))
def table():
    result={}
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            row=identity(int(path.name))
            if row is not None:result[row['pid']]=row
    return result

def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:info=path.stat();result[path.name]=dict(target=os.readlink(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result

parent_fds=fds();parent_threads=tuple(threading.enumerate())
COLLECTOR=checked(HERE.with_name(HERE.name+'-outer'));assert not COLLECTOR.exists();checked(COLLECTOR).mkdir(mode=0o700)
def save(name,body):
    path=checked(COLLECTOR/name);assert path.parent==COLLECTOR
    with path.open('x')as stream:stream.write(json.dumps(body,sort_keys=True,indent=2)+'\n')
    path.chmod(0o600)

input_before=pin(INPUT);assert input_before['sha256']==sys.argv[1]
save('approved-input-before.json',input_before)
before={name:pin(name)for name in plan['sourceAndBinaryPins']};assert before==plan['sourceAndBinaryPins']
save('source-binary-before.json',before)
initial_names=sorted(path.name for path in HERE.iterdir())
for name in('own-toys','child-receipts','child-logs'):
    path=checked(HERE/name);assert not path.exists();path.mkdir(mode=0o700)
expected_names=sorted(initial_names+['own-toys','child-receipts','child-logs'])
LOGS=HERE/'child-logs';stdin=checked(LOGS/'stdin.eof');stdin.write_bytes(b'')
process=None;born=None;owned={};problems=[];timed_out=False;forced=False;term_at=None;baseline=table();started=time.monotonic()
try:
    with stdin.open('rb')as incoming,(LOGS/'stdout.log').open('xb')as output,(LOGS/'stderr.log').open('xb')as error:
        process=subprocess.Popen([sys.executable,'-B',str(HERE/'run-own5.py'),str(INPUT),sys.argv[1]],cwd=REPO,
            stdin=incoming,stdout=output,stderr=error,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(HERE/'own-toys')})
    born=identity(process.pid);assert born is not None and born['parent']==os.getpid()and born['group']==born['session']==born['pid']
    owned[born['pid']]=born;save('actual-runner-birth.json',born)
    while True:
        actual=table();changed=True
        while changed:
            changed=False
            for pid,row in actual.items():
                if pid in owned:continue
                if row['parent']in owned or row['group']==born['group']or row['session']==born['session']:
                    assert pid not in baseline;owned[pid]=row;problems.append(dict(kind='forbidden-child-birth',identity=row));changed=True
        for pid,row in owned.items():
            fresh=identity(pid)
            if fresh is not None and fresh!=row:problems.append(dict(kind='kernel-identity-changed',before=row,after=fresh))
        code=process.poll();elapsed=time.monotonic()-started
        if code is not None:break
        if elapsed>=30 and term_at is None:
            timed_out=True;term_at=time.monotonic();assert identity(born['pid'])==born;os.kill(born['pid'],signal.SIGTERM)
        if term_at is not None and time.monotonic()-term_at>=5:
            forced=True;assert identity(born['pid'])==born;os.kill(born['pid'],signal.SIGKILL);process.wait();break
        time.sleep(.025)
    process.wait()
except BaseException:problems.append(dict(kind='original-parent-exception',traceback=traceback.format_exc()))
finally:
    orphans=[]
    for pid,binding in owned.items():
        actual=identity(pid)
        if actual is not None:
            orphans.append(dict(bound=binding,current=actual))
            if actual==binding:os.kill(pid,signal.SIGKILL)
    if process is not None:process.wait()
    remaining=[dict(bound=row,current=identity(pid))for pid,row in owned.items()if identity(pid)is not None]
    save('actual-process-drain.json',dict(owned=list(owned.values()),orphansRequiredKill=orphans,remaining=remaining,timedOut=timed_out,forced=forced))
    assert not remaining,'No quiet original census while a bound process remains'
    # Entire controller root, including approved-inputs and every metadata,
    # code, output and directory row. These reports are in sibling COLLECTOR.
    first=census(HERE);second=census(HERE)
    save('actual-child-output-first.json',first);save('actual-child-output-second.json',second)
    def child_subtrees(full):
        result={}
        for name in('own-toys','child-receipts','child-logs'):
            assert name in full
            prefix=name+'/'
            result[name]={'.'if key==name else key[len(prefix):]:row for key,row in full.items()if key==name or key.startswith(prefix)}
        return result
    first_children=child_subtrees(first);second_children=child_subtrees(second)
    save('actual-child-subtrees-first.json',first_children);save('actual-child-subtrees-second.json',second_children)
    input_after=pin(INPUT);save('approved-input-after.json',input_after)
    input_unchanged=input_before==input_after and input_before['sha256']==input_after['sha256']==sys.argv[1]
    assert all(name in first and name in second for name in('approved-inputs.json','run-own5.py','supervise-own5.py'))
    after={name:pin(name)for name in plan['sourceAndBinaryPins']};save('source-binary-after.json',after)
    report_path=HERE/'child-receipts/report.json';restore_path=HERE/'child-receipts/actual-port-restoration.json'
    report=json.loads(report_path.read_text())if report_path.is_file()else None
    restore=json.loads(restore_path.read_text())if restore_path.is_file()else None
    selection_path=HERE/'child-receipts/actual-selection.json'
    selection=json.loads(selection_path.read_text())if selection_path.is_file()else None
    origins_path=HERE/'child-receipts/actual-source-model-origins.json'
    origins=json.loads(origins_path.read_text())if origins_path.is_file()else None
    origins_ok=origins is not None and origins['allThreeActualOriginsEstablished']is True
    if origins_ok:
        rows=origins['subjectOrigins'];origins_ok=set(rows)==set(plan['subjectOriginModules'])and len(rows)==3
        for name,expected in plan['subjectOriginModules'].items():
            row=rows.get(name,{})
            origins_ok=origins_ok and row.get('actualModulePresent')is True and row.get('exactOriginMatched')is True
            origins_ok=origins_ok and row.get('actualModuleFile')==row.get('actualLoaderExecutedPath')==expected['path']
            origins_ok=origins_ok and origins['actualExecutedOrigins'].get(name)==expected['path']
            origins_ok=origins_ok and row.get('expectedSha256')==expected['sha256']==pin(expected['path'])['sha256']
    parent_fd_after=fds();parent_thread_after=tuple(threading.enumerate())
    save('actual-parent-drain.json',dict(fdsEqual=parent_fds==parent_fd_after,threadsEqual=parent_threads==parent_thread_after))
    passed=process is not None and process.returncode==0 and not problems and not orphans and not remaining and not timed_out and not forced
    passed=passed and first==second and first_children==second_children and input_unchanged and before==after and parent_fds==parent_fd_after and parent_threads==parent_thread_after
    passed=passed and sorted(path.name for path in HERE.iterdir())==expected_names
    passed=passed and report is not None and report['status']=='PASS'and report['testsRun']==5 and report['actualCaseReceipts']==5
    passed=passed and selection is not None and selection['ids']==plan['cases']and not selection['loaderErrors']
    passed=passed and origins_ok
    passed=passed and restore is not None and restore['restored']and restore['count']==27 and not restore['controlDescriptors']and restore['dupPortsRestored']and restore['toolsRestored']
    terminal=dict(status='PASS'if passed else'FAIL_OR_REFUSED',childReturnCode=None if process is None else process.returncode,
        elapsedSeconds=time.monotonic()-started,problems=problems,timedOut=timed_out,forcedKill=forced,
        ownProcessesAbsent=not remaining,orphansRequiredKill=orphans,twoFullOwnOutputCensusesEqual=first==second,
        fullOwnCensusRoot=str(HERE),fullOwnCensusExclusions=[],approvedInputsExactPinAndCliShaUnchanged=input_unchanged,
        originalChildSubtreesCensusesEqual=first_children==second_children,
        allSourceBinaryPinsEqual=before==after,actualStdlibParentFDThreadDrain=parent_fds==parent_fd_after and parent_threads==parent_thread_after,
        allThreeActualModelOriginsEstablished=origins_ok,
        NodeExecutions=0,movingQualified=False,nativeQualified=False,globalScans=0)
    save('terminal.json',terminal)
raise SystemExit(0 if passed else 1)
