"""Byte-exact original signature oracle on a genuine imported test module."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextvars import ContextVar
from types import FunctionType,ModuleType
from adapters.native_feature_observation import need
from ios.adapters.chat_archive_round import function,_MUTATORS


def module_signature(namespace,*,class_cache=None):
    class_cache={} if class_cache is None else class_cache
    values=[]
    for name,value in sorted(namespace.items()):
        if isinstance(value,FunctionType):values.append((name,function(value)))
        elif isinstance(value,type):
            # Imported aliases refer to the same actual class. Compute its
            # complete current MRO/method signature once per guard pass; this
            # dictionary never survives original_methods()/qml_authority().
            entry=class_cache.get(id(value))
            if entry is None:
                methods=[]
                for parent in value.__mro__:
                    for key,item in sorted(vars(parent).items()):
                        if key in _MUTATORS:continue
                        if isinstance(item,(staticmethod,classmethod)):item=item.__func__
                        if isinstance(item,FunctionType):methods.append((parent,key,function(item)))
                entry=(value,tuple(methods));class_cache[id(value)]=entry
            need(entry[0] is value)
            values.append((name,value,entry[1]))
        elif isinstance(value,ContextVar):values.append((name,id(value)))
        elif isinstance(value,ModuleType):values.append((name,id(value)))
        elif name.isupper() and isinstance(value,(str,int,float,bool,tuple,frozenset,type(None))):values.append((name,value))
    return tuple(values)

