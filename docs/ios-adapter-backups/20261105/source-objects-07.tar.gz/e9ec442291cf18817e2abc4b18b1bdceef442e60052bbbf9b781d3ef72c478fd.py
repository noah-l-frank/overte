"""Own-Actor passive World originals, not Primary facts or input authority.

One closed extra kind reuses SnapshotOwnedPacket's actual query/WAL/OFS engine.
The phase owner adds its own durable responsibility; it never resends unknown
native queries or makes a later Source/phase current by reopening old bytes.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import re
from types import MethodType,FunctionType,CodeType
from adapters.native_clock_join import digest
from adapters.native_feature_observation import NativeFeatureObservation,exact,integer,need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.normal_ui import NativeUIError
from adapters.normal_script_manager import DIAGNOSTIC_FILE
from adapters.script_feature.history import pack,unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import identifier
from feature_journeys.phase_fixture import PhaseFixtureReader,validate as phase_original
from ios.adapters import avatar_world
from ios.adapters.feature_observation import FeatureObservation
from ios.adapters.snapshot_owned_packet import SnapshotOwnedPacket
from ios.adapters.snapshot_capture_clock import operation
from ios.adapters.script_runtime import IOSScriptRuntime


def _function_original(function):
    need(type(function)is FunctionType)
    return (function,function.__code__,function.__globals__,function.__defaults__,function.__kwdefaults__,
        function.__closure__,tuple(cell.cell_contents for cell in function.__closure__ or()),
        deepcopy(function.__defaults__),deepcopy(function.__kwdefaults__))


def _function_unchanged(original):
    function,code,namespace,defaults,kwdefaults,closure,cells,default_values,kwdefault_values=original
    need(function.__code__ is code and function.__globals__ is namespace and function.__defaults__ is defaults
        and function.__kwdefaults__ is kwdefaults and same(function.__defaults__,default_values)
        and same(function.__kwdefaults__,kwdefault_values)and function.__closure__ is closure
        and all(cell.cell_contents is value for cell,value in zip(closure or(),cells)))


def _effective_method(owner,name,function):
    actual=getattr(owner,name)
    need(type(actual)is MethodType and actual.__self__ is owner and actual.__func__ is function)
    return actual


class LifecycleActorWorldPending(NativeUIError):pass


class LifecycleActorWorldPacket(SnapshotOwnedPacket):
    _store_prefix='ios-lifecycle'
    _name='independent-world'
    _key='iosLifecycleIndependentActorWorldPacketVersion'
    _namespace='ios-lifecycle-independent-world'
    _schema='iosLifecycleActorWorld'
    _kind='lifecycle-actor-world'
    _source=avatar_world

    def __init__(self,store,lock,binding,run,role,index,feature,native,guard,*,epoch_ms,monotonic):
        need(type(feature)is FeatureObservation and type(native)is NativeFeatureObservation and feature.session==binding['sessionId'])
        need(type(native.send)is MethodType and native.send.__func__ is FeatureObservation.send)
        clock_feature=native.send.__self__
        need(type(clock_feature)is FeatureObservation and type(native.guard)is MethodType
            and native.guard.__self__ is clock_feature and native.guard.__func__ is FeatureObservation.guard
            and clock_feature.client is feature.client and clock_feature.session==feature.session
            and clock_feature.target is feature.target and clock_feature.observe_process is feature.observe_process
            and type(native.original)is FunctionType and native.original.__globals__ is FeatureObservation.native_observer.__globals__)
        factory=FeatureObservation.native_observer
        need(any(native.original.__code__ is code for code in factory.__code__.co_consts if type(code)is CodeType))
        cells=dict(zip(native.original.__code__.co_freevars,native.original.__closure__ or()))
        need(set(cells)=={'self','remote'}and cells['self'].cell_contents is clock_feature
            and cells['remote'].cell_contents==clock_feature.remote.rsplit('/',1)[0]+'/feature-native-observation.json')
        super().__init__(store,lock,binding,run,role,index,feature,native,guard,epoch_ms=epoch_ms,monotonic=monotonic)
        process=feature.observe_process;factory=IOSScriptRuntime._sources
        need(type(process)is FunctionType and process.__globals__ is factory.__globals__
            and any(process.__code__ is code for code in factory.__code__.co_consts if type(code)is CodeType and code.co_name=='process'))
        process_cells=dict(zip(process.__code__.co_freevars,process.__closure__ or()))
        need(set(process_cells)=={'actual','check'})
        source_check=process_cells['check'].cell_contents
        need(type(source_check)is FunctionType and source_check.__globals__ is factory.__globals__
            and any(source_check.__code__ is code for code in factory.__code__.co_consts if type(code)is CodeType and code.co_name=='check'))
        self.process_factory=factory
        clock=feature.epoch_ms
        need(type(clock)is FunctionType and clock.__globals__ is factory.__globals__
            and any(clock.__code__ is code for code in factory.__code__.co_consts if type(code)is CodeType and code.co_name=='native_clock'))
        clock_cells=dict(zip(clock.__code__.co_freevars,clock.__closure__ or()))
        need(set(clock_cells)=={'clock_source'}and clock_cells['clock_source'].cell_contents is native)
        self.clock_epoch_default=FeatureObservation.__init__.__kwdefaults__['epoch_ms']
        need(clock_feature.epoch_ms is self.clock_epoch_default and native.clock_ms is clock_feature.epoch_ms
            and native.monotonic is clock_feature.monotonic and native.sleep is clock_feature.sleep)
        self.source_channels=(feature,clock_feature,native)
        self.effective_ports=tuple((owner,key,vars(FeatureObservation)[key])for owner in(feature,clock_feature)
            for key in('send','original','guard','native_observer'))+((native,'read',NativeFeatureObservation.read),)
        for owner,key,function in self.effective_ports:_effective_method(owner,key,function)
        self.source_callbacks=tuple(_function_original(function)for function in
            (*[function for _,_,function in self.effective_ports],native.original,process,source_check,factory,clock,self.clock_epoch_default,FeatureObservation.native_observer,SnapshotOwnedPacket.send))
        for owner in(feature,clock_feature):
            need(owner.remote=='@'+owner.target['appId']+':documents/'+owner.target['testBuild']['resultsDirectory']+'/'+DIAGNOSTIC_FILE
                and owner.origin==owner.target['testBuild']['fixtureOrigin']and owner.bundle==owner.target['appId'])
        self.source_paths=tuple((owner,owner.remote,deepcopy(owner.target))for owner in(feature,clock_feature))
        self.before_send=getattr(feature,'before_send',None)
        need(self.before_send is None) # No caller-supplied transport wrapper is authority.
        self.send_guard_code=next(code for code in SnapshotOwnedPacket.send.__code__.co_consts
            if type(code)is CodeType and code.co_name=='guard')
        self.source_members=tuple((owner,key,getattr(owner,key))for owner,keys in(
            (feature,('client','session','target','observe_process','remote','origin','bundle','epoch_ms','monotonic','sleep')),(clock_feature,('client','session','target','observe_process','remote','origin','bundle','epoch_ms','monotonic','sleep')),
            (native,('send','original','clock_ms','guard','pid','ios','monotonic','sleep','native_clock_bound')))for key in keys)
        self.source_read_functions=tuple((cls,key,vars(cls)[key],vars(cls)[key].__code__)for cls,keys in(
            (FeatureObservation,('send','guard','native_observer','original')),(NativeFeatureObservation,('read',)))for key in keys)

    def setup(self,store,lock,binding,run,role,index):
        need(role=='actor');super().setup(store,lock,binding,run,role,index)
        self.failed=False;self.source_members=None;self.source_read_functions=None

    def bound(self):
        try:
            need(not self.failed and self.source_members is not None)
            need(IOSScriptRuntime._sources is self.process_factory)
            need(FeatureObservation.__init__.__kwdefaults__['epoch_ms']is self.clock_epoch_default)
            for owner,key,function in self.effective_ports:_effective_method(owner,key,function)
            for callback in self.source_callbacks:_function_unchanged(callback)
            need(all(owner.remote==remote and same(owner.target,target)for owner,remote,target in self.source_paths))
            actual=getattr(self.feature,'before_send',None)
            if actual is not self.before_send:
                need(type(actual)is FunctionType and actual.__code__ is self.send_guard_code
                    and actual.__globals__ is SnapshotOwnedPacket.send.__globals__ and actual.__defaults__ is None
                    and actual.__kwdefaults__ is None)
                cells=dict(zip(actual.__code__.co_freevars,actual.__closure__ or()))
                need(set(cells)=={'prior','self'}and cells['self'].cell_contents is self
                    and cells['prior'].cell_contents is self.before_send)
            need(all(getattr(owner,key)is value for owner,key,value in self.source_members))
            need(all(vars(cls).get(key)is function and function.__code__ is code for cls,key,function,code in self.source_read_functions))
            super().bound()
        except BaseException:self.failed=True;raise

    def save(self):
        try:return super().save()
        except BaseException:self.failed=True;raise

    def historical(self):
        need(not self.failed);return super().historical()


class LifecycleIndependentActorWorld:
    _version=1
    _version_key='iosLifecycleIndependentActorWorldVersion'
    _original_key='iosLifecycleIndependentActorWorldOriginalVersion'
    _metadata_name='ios-lifecycle-independent-actor-world-'
    _packet_metadata_name='ios-lifecycle-actor-independent-world-'
    _packet_type=LifecycleActorWorldPacket
    def __init__(self,store,lock,binding,run,index,fixture_url,*,phase=None,feature=None,native=None,guard=None,
                 epoch_ms=None,monotonic=None,historical=False):
        need(type(store)is PrivateFeatureState and type(lock)is ScriptSourceLock and type(historical)is bool and integer(index,1,128))
        self.store,self.lock,self.binding,self.run,self.index=store,lock,deepcopy(context(binding)),identifier(run),index
        self.fixture_url,self.historical=fixture_url,historical;self.failed=False
        need(store.path.name==self._metadata_name+format(index,'04d')+'.json'
            and lock.path==store.path.with_name('script-feature-sources.lock')
            and type(fixture_url)is str and fixture_url.endswith('/runs/'+run+'/'))
        lock.assert_held();self.phase,self.feature,self.native,self.guard=phase,feature,native,guard
        self.epoch_ms,self.monotonic=epoch_ms,monotonic
        if historical:need(phase is feature is native is guard is epoch_ms is monotonic is None)
        else:need(type(phase)is PhaseFixtureReader and phase.area=='lifecycle-input'and phase.run==run
            and phase.fixture_url==fixture_url and all(callable(f)for f in(guard,epoch_ms,monotonic)))
        self.previous=store.read();self.state=dict(phase='new',ticket=None,before=None,childStarted=False,after=None,packetSha256=None)
        if self.previous is not None:self.state=self.decode(self.previous)
        elif historical:need(False)

    def envelope(self,state):
        return dict({self._version_key:self._version},binding=deepcopy(self.binding),runId=self.run,role='actor',
            index=self.index,fixtureUrl=self.fixture_url,payload=pack([state]))

    def file_guard(self):
        need(not self.failed);self.lock.assert_held();need(same(self.store.read(),self.previous)
            and(self.previous is None or same(self.envelope(self.state),self.previous)))
        return True

    def bound(self):
        try:
            self.file_guard()
            if not self.historical:need(self.guard()is not False)
            return True
        except BaseException:self.failed=True;raise

    def packet_store(self):
        return PrivateFeatureState(self.store.path.with_name(self._packet_metadata_name+format(self.index,'04d')+'.json'))

    def child(self,*,historical):
        args=(self.packet_store(),self.lock,self.binding,self.run,'actor',self.index)
        if historical:return self._packet_type.history(*args)
        need(not self.historical and not self.failed)
        return self._packet_type(*args,self.feature,self.native,self.bound,epoch_ms=self.epoch_ms,monotonic=self.monotonic)

    def decode(self,value):
        exact(value,{self._version_key,'binding','runId','role','index','fixtureUrl','payload'})
        states=unpack(value['payload']);need(len(states)==1 and type(value[self._version_key])is int
            and value[self._version_key]==self._version and same(value,self.envelope(states[0])))
        state=states[0];exact(state,{'phase','ticket','before','childStarted','after','packetSha256'})
        need(state['phase']in('new','reading','complete')and type(state['childStarted'])is bool)
        if state['phase']=='new':need(state==dict(phase='new',ticket=None,before=None,childStarted=False,after=None,packetSha256=None))
        else:
            identifier(state['ticket']);before=state['before']
            phase_original(before,run=self.run,area='lifecycle-input',request=before['requestId'],epoch=before['capturedEpochMs'])
            need(before['active']and before['activations']and before['activations'][-1]['ticket']==state['ticket'])
            if state['phase']=='reading':need(state['after']is state['packetSha256']is None)
            else:
                need(state['childStarted']);after=state['after']
                phase_original(after,run=self.run,area='lifecycle-input',request=after['requestId'],epoch=after['capturedEpochMs'],previous=before)
                need(after['active']and same(before['activations'],after['activations']))
                packet=self.child(historical=True);need(digest(packet.previous)==state['packetSha256']);packet.qualified()
        return deepcopy(state)

    def save(self):
        # Preparation, serialization, source checks, CAS and readback all latch.
        try:
            need(not self.historical and not self.failed);self.lock.assert_held()
            need(self.guard()is not False and same(self.store.read(),self.previous))
            value=self.envelope(self.state);self.decode(value);self.store.write(value,self.previous)
            need(same(self.store.read(),value));self.previous=deepcopy(value)
        except BaseException:self.failed=True;raise

    def query_floor(self):
        # The fixed native World file is one channel. Another unfinished or
        # orphan family owner cannot be overwritten by a new index/query.
        self.bound();entries=list(self.store.path.parent.iterdir());need(len(entries)<=4096)
        samples={};packets={}
        for path in entries:
            if path.name.startswith(self._metadata_name):
                match=re.fullmatch(re.escape(self._metadata_name)+'([0-9]{4})[.]json',path.name)
                need(match is not None);index=int(match[1]);need(integer(index,1,128));samples[index]=path
            elif path.name.startswith(self._packet_metadata_name):
                match=re.fullmatch(re.escape(self._packet_metadata_name)+'([0-9]{4})[.]json',path.name)
                need(match is not None);index=int(match[1]);need(integer(index,1,128));packets[index]=path
        need(set(packets)<=set(samples))
        for index,path in samples.items():
            if index==self.index:continue
            other=type(self)(PrivateFeatureState(path),self.lock,self.binding,self.run,index,self.fixture_url,historical=True)
            if other.state['phase']!='complete':
                raise LifecycleActorWorldPending('Another Actor World original is unresolved; no new fixed-file query')
            other.original() # Full original bytes/FD identity/phase, no getter.
        return True

    @operation
    def acquire(self,ticket):
        try:return self._acquire(ticket)
        except BaseException:self.failed=True;raise

    def _acquire(self,ticket):
        need(not self.historical);identifier(ticket);self.bound()
        if self.state['phase']=='complete':need(self.state['ticket']==ticket);return self.original()
        if self.state['phase']=='new':
            current=self.phase.read();need(current['ticket']==ticket)
            self.state.update(phase='reading',ticket=ticket,before=deepcopy(current['status']));self.save()
        need(self.state['ticket']==ticket);started=self.state['childStarted']
        if started and self.packet_store().read()is None:
            raise LifecycleActorWorldPending('Actor packet birth is uncertain; no native resend is authorized')
        if not started:self.state['childStarted']=True;self.save()
        packet=self.child(historical=False)
        if packet.state is None:need(not started);packet.reserve()
        if packet.state['phase']=='reserved':self.query_floor();packet.send()
        if packet.state['phase']=='issued':packet.retain()
        need(packet.state['phase']=='retained');packet.qualified()
        after=self.phase.status(self.state['before'])
        need(after['active']and same(after['activations'],self.state['before']['activations']))
        self.state.update(phase='complete',after=deepcopy(after),packetSha256=digest(packet.previous));self.save()
        return self.original()

    def original(self):
        # Historical read has no current phase/Source/native query authority.
        self.file_guard();need(self.state['phase']=='complete');self.decode(self.previous)
        child=self.child(historical=True);frame=child.historical();clock=child.qualified()
        return dict({self._original_key:self._version},binding=deepcopy(self.binding),runId=self.run,role='actor',
            index=self.index,ticket=self.state['ticket'],fixtureUrl=self.fixture_url,phaseBefore=deepcopy(self.state['before']),
            phaseAfter=deepcopy(self.state['after']),nativeOriginal=frame,clockJoin=clock,
            ownerSha256=digest(self.previous),packetOwnerSha256=digest(child.previous),
            owner=deepcopy(self.previous),packetOwner=deepcopy(child.previous),
            nativeOriginalReference=deepcopy(child.state['storage']),nativeOriginalPath=str(child.files().path(child.state['storage'])),
            independentActorSourceOriginalEstablished=True,currentActorObservationEstablished=False,
            canonicalPublicationEstablished=False,nativeQualified=False,wholeQualified=False)
