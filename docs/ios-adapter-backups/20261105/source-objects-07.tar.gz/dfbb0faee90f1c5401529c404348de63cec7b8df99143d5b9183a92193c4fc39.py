"""UNRUN metadata-only assembler; Root quiet/terminal context required."""
from pathlib import Path
import ast,hashlib,importlib.util,json,subprocess,sys

SOURCE=Path(__file__).resolve().parent
REPO=SOURCE.parent.parent
CONTROLLER=REPO/'.ios-host-tmp/audio-normal-mute-prefix-controller3-source2-code-preparation-20261104'
PREFIX=REPO/'.ios-host-tmp/audio-normal-open-first-mute-literal-prefix-source2-actor-projection-private-20261103'
PREFIX1=REPO/'.ios-host-tmp/audio-normal-open-first-mute-literal-prefix-source1-private-20261103'
PREVIOUS=REPO/'.ios-host-tmp/audio-normal-mute-prefix-controller2-final-preparation-20261103'
PREFIX1_RESULT=REPO/'.ios-host-tmp/root-audio-first-mute-prefix1-journal-schema-error-clean-20261104'
PREFIX1_TEMP=PREVIOUS/'temporary'
BASIS=REPO/'.ios-host-tmp/audio-whole-positive2-snapshot-return1-agent-run-20261103'
PREP=REPO/'.ios-host-tmp/audio-normal-mute-prefix-controller3-final-preparation-20261104'
HEAD='00fafcc4c097552198456c7e7687f243801d3ed8'
CASE='ios.self_tests.test_ios_audio_normal_mute_prefix.AudioNormalMutePrefixTests.test_actual_prepare_open_first_mute_original_inputs_silence_and_actor_publication'

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def packet(root,filename,expected):
    root=Path(root);assert root.resolve(strict=True)==root and root.is_relative_to(REPO/'.ios-host-tmp')
    file=root/filename;assert sha(file)==expected
    manifest=json.loads(file.read_text());rows=manifest['files']
    items=rows.items()if type(rows)is dict else((row['path'],row)for row in rows)
    for name,row in items:
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        path=root/name;assert path.resolve(strict=True)==path
        assert sha(path)==(row['sha256']if type(row)is dict else row)
    return dict(path=str(file),sha256=expected)
def write(name,value):
    path=PREP/name;assert path.parent==PREP and not path.exists()
    with path.open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    path.chmod(0o600)
def name(path,base):
    parts=path.relative_to(base).with_suffix('').parts
    return '.'.join(parts[:-1]if parts[-1]=='__init__'else parts)
def main():
    assert sys.dont_write_bytecode and len(sys.argv)==4
    source=packet(SOURCE,'source-freeze.json',sys.argv[1])
    context_path=Path(sys.argv[2]);assert context_path.resolve(strict=True)==context_path
    assert context_path.is_relative_to(REPO/'.ios-host-tmp')and sha(context_path)==sys.argv[3]
    terminal=json.loads(context_path.read_text())
    assert terminal['publicHead']==HEAD and terminal['allTargetWindowsTerminal']is True and terminal['Prefix1Terminal']is True
    assert type(terminal['expectedOldRootCount'])is int and terminal['expectedOldRootCount']==650
    previous=packet(PREVIOUS,'freeze.json','d6d29eaf0d31a92be5be23372385aa5ca2abd99993f996b504051bdd245584af')
    baseline=Path(terminal['baselinePath']);assert baseline==PREVIOUS/'global-original-corpus-baseline.json'and baseline.resolve(strict=True)==baseline
    assert sha(baseline)==terminal['baselineSha256']
    old650=json.loads(baseline.read_text());assert len(old650)==650
    assert PREFIX1_TEMP.resolve(strict=True)==PREFIX1_TEMP and PREFIX1_TEMP.is_dir()and str(PREFIX1_TEMP)not in old650
    additional=terminal.get('additionalOriginalRoots',[])
    assert type(additional)is list and all(type(value)is str for value in additional)and len(set(additional))==len(additional)
    for value in additional:
        path=Path(value)
        assert path.is_absolute()and path.resolve(strict=True)==path and path.is_dir()and path.is_relative_to(REPO/'.ios-host-tmp')
        assert value not in old650 and path!=PREFIX1_TEMP
    expected_roots=set(old650)|{str(PREFIX1_TEMP)}|set(additional)
    assert type(terminal['expectedFinalRootCount'])is int and terminal['expectedFinalRootCount']==len(expected_roots)==651+len(additional)
    proofs=[]
    for row in terminal['resultPackets']:proofs.append(packet(Path(row['path']),'freeze.json',row['freezeSha256']))
    assert proofs,'Actual terminal Root proof packets are required'
    proof_pairs={(row['path'],row['sha256'])for row in proofs};assert len(proof_pairs)==len(proofs)
    prefix_failure=packet(PREFIX1_RESULT,'freeze.json','9c34af83e85f9af729584c182bfffc52ea6ee58203ea4defaa4e45373488248d')
    assert(prefix_failure['path'],prefix_failure['sha256'])in proof_pairs
    additional_proofs=terminal.get('additionalOriginalRootProofs',{})
    assert type(additional_proofs)is dict and set(additional_proofs)==set(additional)
    for root,row in additional_proofs.items():
        assert type(row)is dict and set(row)=={'path','freezeSha256'}
        file=Path(row['path'])/'freeze.json'
        assert(str(file),row['freezeSha256'])in proof_pairs,'Each extra root needs its exact Root-declared actual terminal proof'
    git=Path((REPO/'.git').read_text().split('gitdir: ',1)[1].strip()).resolve(strict=True)
    common=(git/(git/'commondir').read_text().strip()).resolve(strict=True);ref=(git/'HEAD').read_text().strip()
    assert ref.startswith('ref: ')and(common/ref[5:]).read_text().strip()==HEAD
    controller=packet(CONTROLLER,'code-preparation-freeze.json','c6ab4ffa2182767a47ef890deecb61b904fb1ef75b794b1fb7d451a4e9e94b11')
    prefix=packet(PREFIX,'freeze.json','6924845568ac27f52598b48255ccf995c984d10e2401fd20979982a3e360de40')
    prior_prefix_source=packet(PREFIX1,'freeze.json','81a7df7cd0691af5599be8f28e9fa77e3304c16009648d83bde9d065e75f5f21')
    basis_original=packet(BASIS,'freeze.json','3866f8d3c7382660cdfdc03dfca3df952837d3e5593d070032681d850543bc5f')
    original_map=BASIS/'preimport-map.json';assert sha(original_map)=='2e6281834267ef38fb38d83eb18dba17a8a0a59634d9e04f79c511800e0d1ed8'
    old=json.loads(original_map.read_text());private={key:dict(row)for key,row in old['modules'].items()if Path(row['path']).is_relative_to(REPO/'.ios-host-tmp')}
    assert len(private)==86 and all(sha(row['path'])==row['sha256']for row in private.values())
    assert not [row for row in private.values()if 'importer-custody7'in row['path']or 'audio_original_validation_graph.py'in row['path']]
    modules=dict(private);public=REPO/'tests/device'
    namespaces={key:[value for value in values if Path(value).is_relative_to(REPO/'.ios-host-tmp')]for key,values in old['namespacePackages'].items()}
    paths=[Path(value)for value in subprocess.check_output(['rg','--files',str(public),'-g','*.py'],text=True).splitlines()]
    for path in sorted(paths):
        assert path.resolve(strict=True)==path and not path.is_symlink()
        module=name(path,public)
        if module and module not in modules:modules[module]=dict(path=str(path),sha256=sha(path),package=path.name=='__init__.py',layer='public-current-00faf')
        parts=path.relative_to(public).with_suffix('').parts
        for index in range(1,len(parts)):
            key='.'.join(parts[:index]);directory=str(public.joinpath(*parts[:index]))
            if directory not in namespaces.setdefault(key,[]):namespaces[key].append(directory)
    test=PREFIX/'candidate/tests/device/ios/self_tests/test_ios_audio_normal_mute_prefix.py'
    modules['ios.self_tests.test_ios_audio_normal_mute_prefix']=dict(path=str(test),sha256=sha(test),package=False,layer='new-one-prefix-test-only')
    namespaces={key:values for key,values in namespaces.items()if values and key not in modules}
    assert all(modules[key]==row for key,row in private.items())
    for row in old['frozenPackets']:assert sha(row['path'])==row['sha256']
    assert not PREP.exists();PREP.mkdir(mode=0o700)
    for file in('owned_write_boundary.py','global_original_corpus.py'):(PREP/file).write_bytes((CONTROLLER/file).read_bytes())
    roots=expected_roots
    write('global-original-roots-seed.json',dict(roots=sorted(roots),allOld650Preserved=True,mandatoryPrefix1Temporary=str(PREFIX1_TEMP),authoritativeAdditionalOriginalRoots=additional,noWriterExclusions=True))
    spec=importlib.util.spec_from_file_location('prefix_metadata_original_census',PREP/'global_original_corpus.py')
    census=importlib.util.module_from_spec(spec);spec.loader.exec_module(census)
    first=census.current();second=census.current();assert first==second and set(first)==expected_roots and len(first)==terminal['expectedFinalRootCount']
    assert all(first[key]==row for key,row in old650.items())and str(PREFIX1_TEMP)in first and all(value in first for value in additional)
    write('global-original-corpus-baseline.json',first)
    write('terminal-context.json',terminal)
    frozen=list(old['frozenPackets'])+[source,controller,prefix,prior_prefix_source,previous,basis_original,dict(path=str(original_map),sha256=sha(original_map)),dict(path=str(context_path),sha256=sha(context_path)),*proofs]
    files=['run-prefix.py','external-supervisor.py','owned_write_boundary.py','global_original_corpus.py','preimport-map.json','global-original-roots-seed.json','global-original-corpus-baseline.json','terminal-context.json','SOURCE-READBACK.json','EXECUTION-PLAN.md']
    plan=dict(old,root=str(PREP),repository=str(REPO),reportedRootHead=HEAD,status='PRIVATE_UNRUN_PREFIX_SOURCE2_REQUIRES_ROOT_REVIEW',cases=[CASE],modules=modules,namespacePackages=namespaces,
        frozenPackets=frozen,controllerFiles=files,writeBoundarySource=dict(path=str(PREP/'owned_write_boundary.py'),sha256=sha(PREP/'owned_write_boundary.py')),
        historicalCorpus=None,historicalLock=None,needsTemporaryRoot=True,baseNormalMap=str(original_map),baseNormalMapSha256=sha(original_map),noSource7ProductAdoption=True)
    write('preimport-map.json',plan);map_sha=sha(PREP/'preimport-map.json')
    for template,file in(('run-prefix.template.py','run-prefix.py'),('external-supervisor.template.py','external-supervisor.py')):
        text=(CONTROLLER/template).read_text().replace('SOURCE_MAP_PENDING_ROOT_REVIEW',map_sha);ast.parse(text);(PREP/file).write_text(text)
    write('SOURCE-READBACK.json',dict(baseNormalMapSha256=sha(original_map),privateRows=len(private),allPrivateRowsPhysicallyEqual=True,publicPythonPaths=len(paths),modules=len(modules),cases=[CASE],old650BodiesExact=True,mandatoryPrefix1Temporary=str(PREFIX1_TEMP),authoritativeAdditionalOriginalRoots=additional,expectedFinalRootCount=terminal['expectedFinalRootCount'],globalRoots=len(first),globalEntries=sum(len(value)for value in first.values()),noSource7ProductAdoption=True,targetExecutions=0,rawRootsCreated=0))
    (PREP/'EXECUTION-PLAN.md').write_bytes((CONTROLLER/'REVIEW.md').read_bytes())
    assert first==census.current()and all(sha(row['path'])==row['sha256']for row in modules.values())
    assert(common/ref[5:]).read_text().strip()==HEAD
    files={str(path.relative_to(PREP)):dict(bytes=path.stat().st_size,sha256=sha(path))for path in sorted(PREP.iterdir())if path.is_file()}
    write('freeze.json',dict(status='UNRUN_PREFIX_SOURCE2_REQUIRES_ROOT_REVIEW_AND_NEW_WINDOW',files=files,mapSha256=map_sha,publicHead=HEAD,sourceFreeze=source['sha256'],cases=[CASE],wallSeconds=180,killGraceSeconds=5,failfast=True,noSource7ProductAdoption=True,globalRoots=len(first),targetExecutions=0,rawRootsCreated=0))
    print(json.dumps(dict(freeze=sha(PREP/'freeze.json'),map=map_sha,modules=len(modules),globalRoots=len(first),targetExecutions=0)))
if __name__=='__main__':main()
