"""Root diagnostic metadata only; no project import or operation on import."""
from pathlib import Path
import hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as stream:
        stream.write(json.dumps(value,indent=2,sort_keys=True)+'\n');stream.flush();os.fsync(stream.fileno())
def pin(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
    result={key:getattr(a,key) for key in FIELDS}
    if stat.S_ISREG(a.st_mode):result['sha256']=sha(path)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in FIELDS),str(path)
    return result
def plan():return json.loads((HERE/'profile-plan.json').read_text())
def frozen():
    for name,expected in json.loads((HERE/'freeze.json').read_text())['files'].items():assert sha(HERE/name)==expected,name
    value=plan()
    for name,expected in value['publicWorldSourceRequiredSha256'].items():assert sha(REPO/name)==expected,name
    for required in value.get('requiredPassedSelections',[]):
        report=json.loads((REPO/required['report']).read_text());assert report['exitCode']==0
        actual=json.loads((Path(report['runRoot'])/'selected-result.json').read_text())
        assert actual['successful'] and actual['testsRun']==required['count']
        pins=json.loads((REPO/required['sourceMap']).read_text())
        for source in value['qualifiedPureSourcePaths']:assert pins[source]['sha256']==sha(REPO/source),source
    return value
def sources(value):
    names=subprocess.check_output(['rg','--files','-0',*value['broadSourceRoots']],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name};paths.update(REPO/name for name in value['explicitExtraSourcePins'])
    paths.update(HERE/name for name in json.loads((HERE/'freeze.json').read_text())['files']);paths.add(HERE/'freeze.json')
    assert REPO/'interface/src/main.cpp' in paths and REPO/'CMakeLists.txt' in paths and REPO/'interface/CMakeLists.txt' in paths
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}
def originals(value):
    root=Path(value['actualRetainedTemporaryRoot']);assert root.resolve(strict=True)==root
    result={str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
    assert result==json.loads((REPO/value['originalReference']).read_text())
    assert sum(stat.S_ISREG(v['st_mode']) for v in result.values())==value['originalFiles']==789
    return result
def process(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
def group(session,pgid):
    result=[]
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            item=process(int(path.name))
            if item is not None and (item['session']==session or item['processGroup']==pgid):result.append(item)
    return result
