"""Finite genuine constructor monitoring; global-only unwind, owned tool rollback."""
import sys,types
from tablet_constructor_custody import FunctionBinding,CustodyRefusal
class LocalMonitor:
    def __init__(self):
        self.api=sys.monitoring;self.getframe=sys._getframe
        assert type(self.getframe)is types.BuiltinFunctionType and self.getframe.__self__ is sys and self.getframe.__name__=='_getframe'
        self.names=('get_tool','use_tool_id','free_tool_id','register_callback','set_events','set_local_events','get_local_events','get_events')
        self.ports=tuple((name,getattr(self.api,name))for name in self.names)
        self.tool=None;self.candidate=None;self.name='tablet-fresh4-owned-constructors-b3'
        self.rows={};self.callbacks=[];self.active=False;self.acquired=False;self.closed=False
        self.registered=[];self.local_codes=[];self.global_attempted=False;self.rollback_errors=[]
        self.original_global=None;self.original_local={};self.callback_exchange_unknown=False
        self.events=self.api.events
        self.event_values=tuple((name,getattr(self.events,name))for name in('PY_START','PY_RETURN','PY_UNWIND'))
        self.start_event,self.return_event,self.unwind_event=(value for name,value in self.event_values)
        self.local_mask=self.start_event|self.return_event;self.global_mask=self.unwind_event
        self.methods=tuple((name,fn,FunctionBinding(fn))for name,fn in vars(type(self)).items()if type(fn)is types.FunctionType)
    def add(self,function,start=None,returned=None,unwind=None):
        assert not self.active and not self.acquired;binding=FunctionBinding(function)
        assert binding.code not in self.rows
        self.rows[binding.code]=(binding,start,returned,unwind)
        for callback in(start,returned,unwind):
            if callback is not None:
                fn=getattr(callback,'__func__',callback);self.callbacks.append(FunctionBinding(fn))
    def check(self):
        self.check_ports()
        if self.acquired:assert self.tool is not None and self.api.get_tool(self.tool)is self.name
        if self.active:
            assert self.api.get_events(self.tool)==self.global_mask
            assert all(self.api.get_local_events(self.tool,code)==self.local_mask for code in self.rows)
    def start(self,code,offset):
        self.check();binding,callback,unused,unused2=self.rows[code];frame=self.getframe(1);binding.frame(frame)
        if callback is not None:callback(frame)
    def returned(self,code,offset,value):
        self.check();binding,unused,callback,unused2=self.rows[code];frame=self.getframe(1);binding.frame(frame)
        if callback is not None:callback(frame,value)
    def unwound(self,code,offset,error):
        # PY_UNWIND is global-only. Unselected code supplies no frame/owner.
        if not any(code is original for original in self.rows):return
        self.check();binding,unused,unused2,callback=self.rows[code];frame=self.getframe(1);binding.frame(frame)
        if callback is not None:callback(frame,error)
    def install(self):
        self.check();assert not self.active and not self.acquired and not self.closed
        candidate=next((i for i in range(6)if self.api.get_tool(i)is None),None)
        if candidate is None:raise CustodyRefusal('No free genuine monitoring tool')
        self.candidate=candidate
        self.original_global=self.api.get_events(candidate);self.original_local={code:self.api.get_local_events(candidate,code)for code in self.rows}
        assert self.original_global==0 and all(mask==0 for mask in self.original_local.values()),'Free tool retains unknown event masks'
        try:
            self.api.use_tool_id(candidate,self.name)
            self.tool=candidate;self.acquired=True
            for event,callback in((self.start_event,self.start),(self.return_event,self.returned),(self.unwind_event,self.unwound)):
                row=dict(event=event,installed=callback,previousKnown=False,previous=None,restored=False)
                self.registered.append(row)
                previous=self.api.register_callback(self.tool,event,callback)
                row.update(previous=previous,previousKnown=True)
                assert previous is None,'Free tool retains an actual prior callback; restore it and refuse'
            for code in self.rows:
                self.local_codes.append(code);self.api.set_local_events(self.tool,code,self.local_mask)
            self.global_attempted=True;self.api.set_events(self.tool,self.global_mask)
            self.active=True;self.check()
        except BaseException:
            try:self.restore()
            except BaseException as secondary:self.rollback_errors.append(dict(type=type(secondary).__name__,message=str(secondary)))
            raise
    def restore(self):
        if self.closed:
            self.check_ports();assert not self.acquired and not self.active
            return dict(localOriginalConstructorToolsRestored=True,functions=len(self.rows),priorRollbackErrors=list(self.rollback_errors),originalCallbackExchangesKnown=all(row['previousKnown']and row['restored']for row in self.registered),originalEventMasksRestored=self.closed and not self.acquired)
        errors=[]
        def attempt(label,fn):
            try:
                self.check_ports();assert self.acquired and self.api.get_tool(self.tool)is self.name
                fn()
            except BaseException as error:errors.append(dict(label=label,type=type(error).__name__,message=str(error)))
        # A failed use_tool_id never grants authority to mutate or free a slot.
        if self.acquired:
            self.active=False
            if self.global_attempted:attempt('global-mask',lambda:self.api.set_events(self.tool,self.original_global))
            for code in self.local_codes:attempt('local-mask',lambda code=code:self.api.set_local_events(self.tool,code,self.original_local[code]))
            for row in self.registered:
                if not row['previousKnown']:
                    self.callback_exchange_unknown=True
                    errors.append(dict(label='callback-original-return-unknown',event=row['event']))
                    continue
                def restore_callback(row=row):
                    returned=self.api.register_callback(self.tool,row['event'],row['previous'])
                    assert returned is row['installed'],'Original callback exchange no longer owns this registration'
                    row['restored']=True
                attempt('callback-original-exchange',restore_callback)
            if not errors:
                def restored_masks():
                    assert self.api.get_events(self.tool)==self.original_global
                    assert all(self.api.get_local_events(self.tool,code)==self.original_local[code]for code in self.local_codes)
                attempt('original-mask-readback',restored_masks)
            if not errors:
                slot=self.tool
                attempt('free-owned-tool',lambda:self.api.free_tool_id(slot))
                if not errors:
                    self.acquired=False;self.tool=None;self.closed=True
                    assert self.api.get_tool(slot)is None
        else:
            self.check_ports()
            # An interrupted C return/authority-record gap is unavailable, not
            # a restoration claim and never permission to free a slot.
            assert self.candidate is None or self.api.get_tool(self.candidate)is not self.name
            self.closed=True
        self.rollback_errors.extend(errors)
        assert not errors,errors
        return dict(localOriginalConstructorToolsRestored=self.closed and not self.acquired,functions=len(self.rows),priorRollbackErrors=list(self.rollback_errors),originalCallbackExchangesKnown=all(row['previousKnown']and row['restored']for row in self.registered),originalEventMasksRestored=self.closed and not self.acquired)
    def check_ports(self):
        assert type(self)is LocalMonitor and sys._getframe is self.getframe
        assert sys.monitoring is self.api and all(getattr(self.api,k)is v for k,v in self.ports)
        assert self.api.events is self.events and all(getattr(self.events,name)is value for name,value in self.event_values)
        for name,fn,binding in self.methods:
            assert vars(type(self))[name]is fn;binding.guard()
        for binding,unused,unused2,unused3 in self.rows.values():binding.guard()
        for binding in self.callbacks:binding.guard()
