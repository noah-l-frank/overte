"""Actual moving Lifecycle pixels, native geometry and parent-relative marker.

Avatar's stationary-image contract is unchanged. These observations keep real
native before/after poses and the actual GPU recorded view; no pose or pixel is
resampled, rewritten or inferred from the requested movement/expected state.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from ios.adapters.lifecycle_scene_identity import same_scene
from adapters.graphics_subject_geometry import projected_box,near,rotate
from adapters.native_clock_join import validate_join
from adapters.native_feature_observation import exact,need
from adapters.native_vulkan_world_frame import validate as frame_packet,storage,absent,original_pixels
from adapters.normal_feature_state import context
from adapters.script_feature.history import same
from feature_journeys.contract import identifier
from feature_journeys.evidence import image_observation
from ios.adapters import avatar_world as world,avatar_renderers
from ios.adapters.avatar_images import exclusive_subject
from ios.adapters.emote_images import avatar_box,within
from ios.adapters.emote_marker_measurements import orientation

FIELDS={'worldBefore','renderersBefore','capture','retirement','renderersAfter','worldAfter','clockJoin'}
MARKER_OFFSET=[0,1.6,-3]


def self_body(packet):
    world.original(packet);rows=[row for row in packet['source'].get('bodies',{}).get('avatars',[])if row['self']]
    need(len(rows)==1);return world.body(packet,rows[0]['sessionId'])


def relative_marker(packet,marker):
    body=self_body(packet);offset=rotate(MARKER_OFFSET,body['orientation'])
    need(near(marker['position'],[a+b for a,b in zip(body['position'],offset)],.005)
        and orientation(marker['rotation'],body['orientation']) and near(marker['dimensions'],[1.6,.4,.01],.0001))
    return body


def compose(run,ticket,binding,frame,raw,policy,*,marker_nonce,marker_url):
    identifier(run);identifier(ticket);context(binding);exact(frame,FIELDS)
    clock=validate_join(frame['clockJoin'],{k:v for k,v in frame.items()if k!='clockJoin'});pid=int(binding['processIdentity']);epoch=clock['nativeAfter']['capturedEpochMs']
    need(clock['nativeBefore']['processId']==clock['nativeAfter']['processId']==pid)
    before,after=frame['worldBefore'],frame['worldAfter']
    for packet in (before,after):world.original(packet);need(packet['processId']==pid and packet['runId']==run)
    world.validate(after,dict(schemaVersion=1,commandId=after['requestId'],action=world.ACTION,runId=run),pid,epoch,before)
    need(world.actual_domain(before)==world.actual_domain(after) and same_scene(before['source']['sceneUrl'],after['source']['sceneUrl']))
    markers=[world.owned_marker(p,marker_nonce,marker_url)for p in (before,after)]
    stable=('id','name','type','hostType','sourceUrl','userData','dimensions','visible','collisionless','lastEditedEpochUs')
    need(all(same(markers[0][key],markers[1][key])for key in stable));world.preserve_unowned(before,after,{markers[0]['id']})
    bodies=[relative_marker(p,m)for p,m in zip((before,after),markers)]
    need(bodies[0]['sessionId']==bodies[1]['sessionId'] and orientation(bodies[0]['orientation'],bodies[1]['orientation'])
        and not any(p['source']['avatar']['flying']or p['source']['avatar']['inAir']for p in (before,after)))
    a,b=before['source']['view'],after['source']['view']
    need(a['mode']==b['mode']=='look at' and a['perspective']is b['perspective']is True
        and orientation(a['rotation'],b['rotation']) and near([a['fieldOfViewDegrees']],[b['fieldOfViewDegrees']],.001)
        and near([a['aspectRatio']],[b['aspectRatio']],.0001) and same(before['source']['cameraOrbit'],after['source']['cameraOrbit']))
    # Actual same body/camera relative transform brackets a translating camera.
    # A stationary or unrelated view cannot stand in for a moving capture.
    offsets=[[x-y for x,y in zip(body['position'],view['position'])]for body,view in zip(bodies,(a,b))]
    need(near(offsets[0],offsets[1],.005))
    capture,retirement=frame['capture'],frame['retirement'];query=dict(schemaVersion=1,action='feature-vulkan-world-frame',operation='read',commandId=capture.get('commandId'),requestId=capture.get('requestId'))
    frame_packet(capture,query,pid,epoch);original_pixels(capture,raw)
    storage(retirement,dict(query,operation=retirement.get('operation'),commandId=retirement.get('commandId')),pid,epoch)
    need(absent(retirement) and retirement['instance']==capture['instance'] and retirement['sequence']>capture['sequence'])
    source=capture['source'];trace=source['renderTrace'];view=trace['recordedView'];extent=source['targetExtent']
    need(trace['forwardDrawCalls']>0 and orientation(view['rotation'],a['rotation'])
        and near([view['fieldOfViewDegrees']],[a['fieldOfViewDegrees']],.001) and near([view['aspectRatio']],[a['aspectRatio']],.0001)
        and all(min(x,y)-.005<=z<=max(x,y)+.005 for x,y,z in zip(a['position'],b['position'],view['position']))
        and abs(a['aspectRatio']-extent[0]/extent[1])<=.01)
    left,right=frame['renderersBefore'],frame['renderersAfter'];avatar_renderers.original(left)
    avatar_renderers.validate(right,dict(schemaVersion=1,commandId=right['requestId'],action=avatar_renderers.ACTION,runId=run),pid,epoch,left)
    avatar_id=bodies[0]['sessionId'];rows=[avatar_renderers.avatar(p,avatar_id)for p in (left,right)]
    need(left['runId']==run and left['processId']==pid and all(same(rows[0][key],rows[1][key])for key in ('requestedUrl','resourceUrl','geometryLoaded','rigReady','modelScale','targetScale','addedToScene','shouldRender')))
    need(all(row['geometryLoaded']and row['rigReady']and row['addedToScene']and row['shouldRender']for row in rows))
    for packet,row,body in zip((before,after),rows,bodies):
        actual=packet['source']['avatar']
        need(row['self'] and abs(row['modelScale']-actual['modelScale'])<.0001
            and row['boundsReady']==actual['boundsReady'] and same(row['bounds'],actual['bounds'])
            and orientation(body['orientation'],actual['orientation']) and near(body['velocity'],actual['velocity'],.00001))
    # Keep the actual fence projection. Only bracket-native camera poses are
    # substituted for projecting THEIR native bounds/marker geometry; these
    # are derived comparison boxes, never invented frame/pixel observations.
    views=[dict(view,position=p['position'],rotation=p['rotation'])for p in (a,b)]
    marker_boxes=[projected_box(marker,projection,extent)for marker,projection in zip(markers,views)]
    need(max(abs(x-y)for x,y in zip(*marker_boxes))<=1)
    for box in marker_boxes:within(policy['marker'],box)
    for packet,projection in zip((left,right),views):
        bound=avatar_renderers.bounds(packet,avatar_id);within(policy['subject'],avatar_box(bound,projection,extent));exclusive_subject(packet,avatar_id,policy,projection,extent)
    for box in marker_boxes:
        subject=policy['subject'];need(max(box[0],subject[0])>=min(box[2],subject[2])or max(box[1],subject[1])>=min(box[3],subject[3]))
    order=[before['clockBefore']['epochMs'],before['clockAfter']['epochMs'],left['clockBefore']['epochMs'],left['clockAfter']['epochMs'],capture['requestedEpochMs'],trace['recordedEpochMs'],source['submittedEpochMs'],source['fenceObservedEpochMs'],source['pixelsReadEpochMs'],capture['capturedEpochMs'],retirement['requestedEpochMs'],retirement['capturedEpochMs'],right['clockBefore']['epochMs'],right['clockAfter']['epochMs'],after['clockBefore']['epochMs'],after['clockAfter']['epochMs']]
    need(order==sorted(order)and clock['nativeBefore']['capturedEpochMs']<=order[0]<=order[-1]<=epoch)
    image,subject=image_observation(raw,run,ticket,policy)
    return dict(iosLifecycleMovingImageVersion=1,ticket=ticket,frameId=trace['frameId'],capturedEpochMs=clock['hostBeforeEpochMs'],
        image=image,markerId=markers[0]['id'],avatarId=avatar_id,nativeBodyBefore=deepcopy(bodies[0]),nativeBodyAfter=deepcopy(bodies[1]),
        actualRecordedView=deepcopy(view),markerBracketBoxes=marker_boxes),subject
