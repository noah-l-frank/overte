"""Prospective ordinary16/independent Actor restoration, all cases UNRUN.

Raw SDK/Qt/native/mixer are declared lower models. Real owner constructors,
ordinary actions, native-input journal, Current7/OFS, canonical HTTP/WAL and
original cleanup run. No independent held-motion or native/device result.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio
from copy import deepcopy
from unittest.mock import patch
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from feature_journeys.contract import VERSION,context,expand
from feature_journeys.scenarios import SCENARIOS
from feature_journeys.phase_fixture import PhaseFixtureReader
from feature_journeys.server import make_server
from ios.adapters import appium_adapter
from ios.adapters.lifecycle_actor_publication import LifecycleActorCanonicalPublication
from ios.adapters.lifecycle_independent_actor_restoration import (restore_with_independent_actor,
    compare_restored_actor_originals,LifecycleActorRestorationPending)
from ios.self_tests.lifecycle_restoration_actor_domain import LifecycleRestorationActorDomain
from ios.self_tests.test_ios_lifecycle_actor_server_route import ActualEndpointClient
from lifecycle_moving_raw_constructor_fixture import LifecycleMovingRawConstructorFixture
from lifecycle_moving_raw_world_renderer import SELF
import test_lifecycle_actor_phase_publication_models as phase_fixture


class LifecycleIndependentActorRestorationTests(LifecycleMovingRawConstructorFixture):
    async def asyncSetUp(self):
        def enabled(reader,actor,**kwargs):
            need('lifecycle_actor_originals'not in kwargs)
            return make_server(reader,actor,lifecycle_actor_originals=True,**kwargs)
        # The real factory flag is selected BEFORE the original Journal/server
        # and registration. No saved instance, packet or phase is rewritten.
        with patch.object(phase_fixture,'make_server',enabled):await super().asyncSetUp()
        self.peer=LifecycleRestorationActorDomain(self,self.run,primary_session=SELF,domain_id=self.normal.boundary.domain)
        need(self.peer.sequence==0 and not self.peer.queries and self.peer.raw is None)
        self.actor_endpoint=ActualEndpointClient(self.fixture_url,'a'*64)
        self.peer.client=self.actor_endpoint;self.peer.journal=self.phase_server.journal
        self.peer.phase=PhaseFixtureReader(self.actor_endpoint,self.run,'lifecycle-input',epoch_ms=self.peer.clock,monotonic=self.peer.mono)
        original_arrive=self.address.arrive
        def arrive(url):
            result=original_arrive(url)
            self.peer.restore_peer_event() # No address/Primary pose is input.
            return result
        self.address.arrive=arrive

    def action_call(self,index):
        step=expand(SCENARIOS['lifecycle-input']['steps'][index],context(self.run))
        ticket=self.activate(step['verb'],step['inputs'])
        return dict(contractVersion=VERSION,runId=self.run,ticket=ticket,verb=step['verb'],
            inputs=deepcopy(step['inputs']),fixtureUrl=self.fixture_url+'/runs/'+self.run+'/')

    async def before_restore(self):
        await self.acquire_through_feature()
        with self.peer.lock.held():
            owners=(self.peer.owner(1),self.peer.owner(2))
            owners[0].acquire(self.active_ticket)
            LifecycleActorCanonicalPublication(owners,self.actor_endpoint).publish(1)
        # All first fifteen ACTUAL ordinary actions, including the real held
        # input and original Up/quiet cuts, run without replacing their methods.
        # We do not claim fifteen image checks: the original five Moving bodies
        # remain separate; this new test acquires baseline and held images.
        steps=SCENARIOS['lifecycle-input']['steps'];self.assertEqual(16,len(steps))
        for index in range(len(steps)-1):
            call=self.action_call(index)
            self.assertEqual(dict(performed=True),await asyncio.to_thread(self.feature.act,call))
            if index==13:
                await self.acquire_through_feature();self.peer.peer_event()
                with self.peer.lock.held():
                    owners=(self.peer.owner(1),self.peer.owner(2))
                    owners[1].acquire(self.active_ticket)
                    LifecycleActorCanonicalPublication(owners,self.actor_endpoint).publish(2)
        self.assertEqual(2,len(self.peer.queries));self.assertEqual(2,len(self.actor_endpoint.posts))
        self.restore_call=self.action_call(len(steps)-1)
        return deepcopy(self.restore_call)

    async def restore(self):
        def invoke():
            with patch.object(appium_adapter,'WebDriver',return_value=self.peer.sdk_client):
                return restore_with_independent_actor(self.feature,self.peer.runtime,'test-only',self.actor_endpoint,self.restore_call)
        return await asyncio.to_thread(invoke)

    async def test_full_ordinary_restore_joins_three_own_actor_originals_and_reopens_without_new_go_or_query(self):
        await self.before_restore();value=await self.restore();counts=(len(self.address.inputs),len(self.peer.queries),len(self.actor_endpoint.posts))
        self.assertTrue(value['historicalIndependentRestorationAgreementEstablished'])
        self.assertTrue(value['allClosedScenarioActionsReturned']);self.assertEqual(3,len(value['canonicalOriginals']))
        self.assertEqual([0.,0.,0.],value['actorMeasuredRestoredBodyDelta']);self.assertEqual(1,self.peer.restore_events)
        for key in('oldHeldMotionAgreementEstablished','currentStateEstablished','pairedTemporalOrderEstablished',
                'actorPixelsEstablished','authenticatedTouchEstablished','resourceRetirementEstablished','nativeQualified','wholeQualified'):
            self.assertFalse(value[key])
        self.assertEqual(value,await self.restore())
        self.assertEqual(counts,(len(self.address.inputs),len(self.peer.queries),len(self.actor_endpoint.posts)))

    async def test_ignored_actor_restore_is_measured_failure_and_replay_cannot_replace_original_or_go(self):
        await self.before_restore();self.peer.ignore_restore=True
        with self.assertRaises(NativeUIError):await self.restore()
        counts=(len(self.address.inputs),len(self.peer.queries),len(self.actor_endpoint.posts))
        with self.peer.lock.held():saved=self.peer.owner(3,historical=True).original()
        self.assertEqual([0.,0.,-.7],saved['nativeOriginal']['packet']['source']['world']['source']['bodies']['avatars'][0]['position'])
        with self.assertRaises(NativeUIError):await self.restore()
        self.assertEqual(counts,(len(self.address.inputs),len(self.peer.queries),len(self.actor_endpoint.posts)))
        with self.peer.lock.held():self.assertEqual(saved,self.peer.owner(3,historical=True).original())

    async def test_lost_third_actor_http_return_reopens_same_nonce_without_second_go_or_native_send(self):
        await self.before_restore();self.peer.lost=True
        with self.assertRaises(OSError):await self.restore()
        queries=deepcopy(self.peer.queries);inputs=deepcopy(self.address.inputs)
        self.assertEqual(3,len(queries));value=await self.restore()
        self.assertEqual(queries,self.peer.queries);self.assertEqual(inputs,self.address.inputs)
        self.assertTrue(value['canonicalPublicationEstablished']);self.assertEqual(1,self.peer.restore_events)

    async def test_saved_planned_restore_return_loss_before_input_refuses_reentry_before_go_or_actor_query(self):
        await self.before_restore();original=PrivateFeatureState.write;faults=[]
        def write(store,value,previous):
            result=original(store,value,previous)
            if store.path.name=='ios-lifecycle-actions.json'and value['state']['events'][-1]['call']['verb']=='restore':
                self.assertEqual('planned',value['state']['events'][-1]['phase']);faults.append(store.path)
                raise OSError('Genuine planned-intent CAS succeeded; return lost BEFORE original input')
            return result
        before=(len(self.address.inputs),len(self.peer.queries))
        with patch.object(PrivateFeatureState,'write',write),self.assertRaises(OSError):await self.restore()
        self.assertEqual(1,len(faults))
        with self.assertRaises(LifecycleActorRestorationPending):await self.restore()
        self.assertEqual(before,(len(self.address.inputs),len(self.peer.queries)));self.assertEqual(0,self.peer.restore_events)
        # The existing independent fixture cleanup may still discharge owned
        # Primary work; this route itself has no uncertain-input retry power.

    async def test_same_bytes_foreign_actor_inode_refuses_after_actual_restore_without_query(self):
        await self.before_restore();await self.restore()
        with self.peer.lock.held():
            owner=self.peer.owner(3,historical=True);child=owner.child(historical=True)
            path=child.files().path(child.state['storage']);raw=path.read_bytes();backup=path.with_name('source4-retained-'+path.name)
            path.rename(backup);path.write_bytes(raw);path.chmod(0o600)
        counts=(len(self.address.inputs),len(self.peer.queries),len(self.actor_endpoint.posts))
        with self.assertRaises(NativeUIError):
            await asyncio.to_thread(compare_restored_actor_originals,self.feature,self.peer.binding,self.peer.ctx.root)
        self.assertEqual(raw,backup.read_bytes());self.assertEqual(raw,path.read_bytes())
        self.assertEqual(counts,(len(self.address.inputs),len(self.peer.queries),len(self.actor_endpoint.posts)))

    async def test_committed_third_publication_lost_return_recovers_without_post_or_go_replay(self):
        await self.before_restore();self.actor_endpoint.lose_next_post=True
        with self.assertRaises(OSError):await self.restore()
        posts=deepcopy(self.actor_endpoint.posts);queries=deepcopy(self.peer.queries);inputs=deepcopy(self.address.inputs)
        self.assertEqual(3,len(posts));value=await self.restore()
        self.assertEqual(posts,self.actor_endpoint.posts);self.assertEqual(queries,self.peer.queries);self.assertEqual(inputs,self.address.inputs)
        self.assertEqual(3,len(value['canonicalOriginals']));self.assertEqual(1,self.peer.restore_events)
