/* Original creator's existing child pipe; no new listener or tunnel broker. */
import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import path from 'node:path';
import {mkdir, lstat} from 'node:fs/promises';

const MAX_BYTES = 16384;
export class OriginalUserspaceKeeper {
  constructor(child, target) {
    this.child=child;this.target=target;this.instance=null;this.pending=new Map();
    this.failed=false;this.session=null;
    this.ready=new Promise((resolve,reject)=>{this.resolveReady=resolve;this.rejectReady=reject;});
    this.partial='';
    const line=raw=>{
      try {
        if(Buffer.byteLength(raw)>MAX_BYTES)throw new Error();
        const value=JSON.parse(raw);
        if(value?.schemaVersion!==2)throw new Error();
        if(value.event==='owner-ready' && this.instance===null && /^[0-9a-f]{32}$/.test(value.ownerInstance)) {
          this.instance=value.ownerInstance;this.resolveReady(this);return;
        }
        if(value.ownerInstance!==this.instance || !/^[0-9a-f]{32}$/.test(value.requestId))throw new Error();
        const pending=this.pending.get(value.requestId);
        if(!pending || !['complete','failed'].includes(value.status))throw new Error();
        this.pending.delete(value.requestId);clearTimeout(pending.timer);
        if(pending.expired)return; // Keep original effect ownership; never replay.
        if(value.status==='complete')pending.resolve(value.result);
        else pending.reject(new Error('Original keeper operation failed'));
      } catch (_) {this.poison();}
    };
    child.stdout.on('data',chunk=>{
      if(this.failed)return;
      for(const byte of chunk) {
        if(byte===10) {const raw=this.partial;this.partial='';line(raw);}
        else if(byte>127 || this.partial.length>=MAX_BYTES) {this.poison();return;}
        else this.partial+=String.fromCharCode(byte);
      }
    });
    child.once('error',()=>this.poison());child.once('exit',()=>this.poison());
    // Existing keeper errors are deliberately not forwarded with target data.
    child.stderr.resume();
  }
  poison() {
    this.failed=true;this.rejectReady(new Error('Original keeper unavailable'));
    for(const pending of this.pending.values()) {
      clearTimeout(pending.timer);pending.expired=true;
      pending.reject(new Error('Original keeper unavailable'));
    }
    // Leave originals retained until child exit/explicit creator cleanup.
  }
  async request(request) {
    await this.ready;
    if(this.failed || this.child.exitCode!==null || this.pending.size>=32 ||
       request?.schemaVersion!==2 || request.ownerInstance!==this.instance ||
       !/^[0-9a-f]{32}$/.test(request.requestId) || typeof request.operation!=='string' ||
       !request.args || typeof request.args!=='object' || Array.isArray(request.args) ||
       !(request.sessionId===null || typeof request.sessionId==='string'))throw new Error('Original keeper unavailable');
    if(this.pending.has(request.requestId))throw new Error('Original keeper request remains owned');
    if(request.operation==='claim') {
      if(this.session!==null || request.sessionId!==request.args.sessionId)throw new Error('Original keeper session changed');
      this.session=request.sessionId;
    } else if(request.operation!=='inspect' && this.session!==request.sessionId)throw new Error('Original keeper session changed');
    const raw=JSON.stringify(request)+'\n';
    if(Buffer.byteLength(raw)>MAX_BYTES)throw new Error('Original keeper request too large');
    return await new Promise((resolve,reject)=>{
      const pending={resolve,reject,expired:false,timer:null};this.pending.set(request.requestId,pending);
      // Existing WDA bootstrap max35s; reads5s; touch intent remains <=12s.
      const budget=request.operation==='wda-start'?35000:
        ['touch-begin','touch-release','wda-stop'].includes(request.operation)?15000:5000;
      pending.timer=setTimeout(()=>{
        pending.expired=true;reject(new Error('Original keeper return is unresolved'));
        // Do not cancel a child/SDK call or treat timeout as Up/release.
      },budget);
      this.child.stdin.write(raw,error=>{if(error)this.poison();});
    });
  }
  async inspect() {
    return await this.request({schemaVersion:2,ownerInstance:this.instance,requestId:randomUUID().replaceAll('-',''),
      operation:'inspect',sessionId:null,args:{}});
  }
  async close() {
    // Reuse existing keeper SIGTERM/graceful12s/force3s policy. A forced kill
    // is reported as incomplete ownership, never a resource-retirement proof.
    if(this.child.exitCode!==null || this.child.signalCode!==null)return;
    const exited=new Promise(resolve=>this.child.once('exit',resolve));
    this.child.kill('SIGTERM');let timer;
    const graceful=await Promise.race([exited.then(()=>true),new Promise(resolve=>{timer=setTimeout(()=>resolve(false),12000);})]);
    clearTimeout(timer);
    if(graceful || this.child.exitCode!==null || this.child.signalCode!==null)return;
    this.child.kill('SIGKILL');
    await Promise.race([exited,new Promise(resolve=>{timer=setTimeout(resolve,3000);})]);clearTimeout(timer);
    throw new Error('Original keeper shutdown remains unqualified');
  }
}

export async function startOriginalUserspaceKeeper(device) {
  const helper=process.env.OVERTE_PYMOBILEDEVICE3_XCTEST_HELPER;
  const packages=process.env.OVERTE_PYMOBILEDEVICE3_SITE_PACKAGES;
  const sourceRoot=process.env.OVERTE_IOS_ADAPTER_SOURCE_ROOT;
  const home=process.env.XDG_DATA_HOME;
  if([helper,packages,sourceRoot,home].some(value=>typeof value!=='string'||!path.isAbsolute(value)||/[\0\r\n]/.test(value)))
    throw new Error('Pinned original creator resources unavailable');
  const stateRoot=path.join(home,'original-userspace-'+randomUUID().replaceAll('-',''));
  await mkdir(stateRoot,{mode:0o700});const state=await lstat(stateRoot);
  if(!state.isDirectory()||state.isSymbolicLink()||(state.mode&0o077)!==0||state.uid!==process.geteuid())
    throw new Error('Private original keeper state unavailable');
  const child=spawn('/usr/bin/python3.14',['-S','-P','-B',helper],{
    cwd:'/',stdio:['pipe','pipe','pipe'],windowsHide:true,
    env:{HOME:home,LANG:'C.UTF-8',LC_ALL:'C.UTF-8',PATH:'/usr/bin',PYTHONNOUSERSITE:'1',PYTHONDONTWRITEBYTECODE:'1',
      PYTHONPATH:[packages,path.join(sourceRoot,'tests/device')].join(path.delimiter)}});
  const owner=new OriginalUserspaceKeeper(child,device.Properties.SerialNumber);
  child.stdin.write(JSON.stringify({schemaVersion:2,creatorMode:'original-userspace-owner',
    udid:owner.target,stateRoot})+'\n');
  let timer;
  try {
    await Promise.race([owner.ready,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Original creator start timeout')),35000);})]);
    await owner.inspect();return owner;
  } catch(error) {await owner.close();throw error;}
  finally {clearTimeout(timer);}
}
