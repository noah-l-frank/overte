"""Explicit Profile9 native-file -> copied/fence -> paired process/SDK End."""
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from adapters.operation_transport_guard import scope as transport_scope
from ios.adapters.emote_runtime import IOSEmoteRuntime
from ios.adapters.emote_callback_terminal import IOSEmotePostControllerCallbackFeature,IOSEmotePostControllerCallbackTerminal
from ios.adapters.emote_post9_terminal import IOSEmotePost9Terminal
from ios.adapters.emote_post_controller_end_boundary import Profile9EndBoundary
from ios.adapters.emote_palette_file_delivery import PaletteFileDelivery
from ios.adapters.feature_observation import FeatureObservation
from ios.adapters.emote_rooted_end_lock import held_existing
from ios.adapters.emote_operation import operation,clock as operation_clock
from ios.adapters.emote_observer import EmoteObservationPending


def stop(runtime,owner,cut):
    from ios.adapters.emote_post9_process_end import IOSEmotePost9ProcessEnd
    from ios.adapters.emote_post9_fence_cut import IOSEmotePost9FenceCut
    from ios.adapters.emote_post9_fence import current
    from ios.adapters.emote_post9_response_retirement import source_current
    need(isinstance(runtime,IOSEmoteRuntime)and type(owner)is IOSEmotePost9ProcessEnd and owner.runtime is runtime
        and type(cut)is IOSEmotePost9FenceCut and cut.end is owner and cut.expected_issued is not None
        and type(cut.value)is dict and type(cut.proof)is dict)
    owner.bound();need(owner.state['phase']=='stop-issued'and owner.state['fence']is not None and owner.state['pending']is None)
    need(owner.store.path==runtime.state_path(owner.flow.selector).with_name('ios-emote-'+owner.role+'-'+owner.run+'-post9-process-end.json'))
    def guard():
        owner.bound();cut.guard();value=owner.fence_original()
        current(value['acquisitions'],value['nativeClock'],epoch_ms=owner.flow.epoch_ms,monotonic=owner.monotonic)
    guard()
    with transport_scope(guard):
        owner.response.completed(owner.fence_original())
        need(same(source_current(owner),owner.state['source']))
    base=runtime.adapter;outer=base._operation;need(outer in(None,'feature.emotes.terminal'));base._operation=None
    try:
        with transport_scope(guard):guard();return base.invoke(owner.flow.selector,'app.stop',{})
    finally:base._operation=outer


class Profile9End:
    def __init__(self,primary,actor=None):
        need(type(primary)is IOSEmotePostControllerCallbackFeature and primary.role=='primary')
        self.terminal=IOSEmotePost9Terminal(primary,actor);self.flow,self.actor=primary,self.terminal.actor
        self.runtime,self.monotonic=primary.runtime,primary.monotonic;self.deadline=self.last_clock=None
    def clock(self):return operation_clock(self)
    @operation(30)
    def prepare_families(self):
        p,a=self.flow,self.actor;need(p.lock._owner is None and a.lock._owner is None)
        copied=PrivateFeatureState(p.lock.path.with_name('ios-emote-primary-'+p.run+'-post9-copied.json'))
        if copied.read()is not None:
            # Existing copy validation is entirely historical. Native file,
            # clock/source/phase getters are forbidden on this path.
            return
        boundary=Profile9EndBoundary(IOSEmotePostControllerCallbackTerminal(p,a));boundary.archive_sources();self.boundary=boundary
        with held_existing(a.lock),held_existing(p.lock):
            # Actual existing installed SDK and genuine FeatureObservation.
            client,session,state,target,scope=p.runtime._existing(p.selector)
            gate=p.runtime.adapter._binding(p.selector,client,session,state,target);gate.verify();actual=gate.continuity()
            need(same(dict(scope,processIdentity=str(actual['pid'])),p.state['binding']))
            def guard():
                self.clock();p.runtime.adapter._candidate_guard()
                need(same(gate.continuity(),actual));return True
            observer=FeatureObservation(client,session,target,lambda:(guard(),actual)[1],monotonic=p.monotonic,sleep=p.sleep,epoch_ms=lambda:int(p.epoch_ms()))
            native=observer.native_observer()
            def native_clock():return native.read(native.sequence)['capturedEpochMs']
            owner=PaletteFileDelivery(observer,PrivateFeatureState(p.lock.path.with_name('ios-emote-primary-'+p.run+'-palette-file-delivery.json')),
                p.root,p.state['binding'],p.run,p.lock,native_clock,guard,monotonic=p.monotonic,epoch_ms=p.epoch_ms,sleep=p.sleep)
            if owner.state['pending']is not None:owner.recover()
            if not owner.state['records']:owner.request()
            value=owner.original(owner.state['records'][-1])['delivery']['original']['source']['ownership']
            if value['phase']=='owned':owner.request('retire',owned=value)
            value=owner.original(owner.state['records'][-1])['delivery']['original']['source']['ownership']
            need(value['phase']=='retired'and value['retirementIssued']is True and value['pendingPublication']is False)
    @operation(30)
    def invoke(self,seal):
        from ios.adapters.emote_post9_finish import IOSEmotePost9Finish
        self.prepare_families();failure=None
        with held_existing(self.actor.lock),held_existing(self.flow.lock),self.actor.held(30):
            try:result=IOSEmotePost9Finish(self.terminal,seal).invoke()
            except BaseException as error:failure=(error,error.__traceback__)
        if failure is not None:raise failure[0].with_traceback(failure[1])
        return result


def finish(primary,seal,actor=None):
    """Recover an actual absent Actor only through its typed per-path End."""
    need(type(primary)is IOSEmotePostControllerCallbackFeature)
    if actor is None:
        path=primary.runtime.state_path(primary.actor_selector).with_name('ios-emote-actor-feature.json')
        if PrivateFeatureState(path).read()is None:
            from ios.adapters.emote_post9_finish import existing_end_actor
            actor=existing_end_actor(primary,seal)
    return Profile9End(primary,actor).invoke(seal)
