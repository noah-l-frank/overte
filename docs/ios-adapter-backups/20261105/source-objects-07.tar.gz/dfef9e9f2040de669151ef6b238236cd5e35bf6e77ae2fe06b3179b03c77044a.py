class _OriginalKeeperWorldConnection:
    """Existing client/child operation path; no local HID context or new Source."""
    def __init__(self,runtime,selector,source,run):
        need(type(runtime) is IOSLifecycleWorldHoldRuntime and source['check']() is not False)
        self.runtime,self.selector,self.source,self.run=runtime,selector,source,identifier(run)
        self.binding=deepcopy(source['binding']);self.owner=None;self.lease=None;self.preparation=None
    def current(self):
        need(self.source['binding']==self.binding and self.source['check']() is not False);return True
    async def prepare(self,seconds):
        import asyncio
        from adapters.native_feature_observation import number
        from ios.adapters.lifecycle_world_hold import coordinates
        need(self.preparation is None and self.lease is None and number(seconds,0,12) and seconds>0)
        self.current()
        query=await asyncio.to_thread(self.runtime.adapter._lifecycle_owned_native_query,self.selector,self.run,
            'ios-bundle-observe',original_child_artifact=True)
        self.current()
        flags={'nativeAcquisitionBound','originalChildCandidateBound','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished'}
        exact(query,{'originalKeeperInstalledQueryVersion','binding','queryOriginal','installedBefore','installedAfter','selectedArtifactBundle','childBundleOriginal'}|flags)
        need(type(query['originalKeeperInstalledQueryVersion']) is int and query['originalKeeperInstalledQueryVersion']==3
            and query['binding']==self.binding and all(query[k] is False for k in flags))
        original=query['queryOriginal'];need(type(original['originalKeeperNativeQueryVersion']) is int and original['originalKeeperNativeQueryVersion']==3)
        selection=original['query']['commandId']
        value=await asyncio.to_thread(self.runtime.native_original_acquisition,self.selector,self.run,selected_query=selection)
        self.current();need(value['binding']==self.binding and value['runId']==self.run and value['ownerInstance']==original['ownerInstance'])
        frame=value['originalFrame'];path=coordinates(frame)
        # Bind cleanup to the ORIGINAL transport before preparation can leave
        # unknown child responsibility. It grants no authenticated/input fact.
        self.owner=value['ownerInstance'];self.lease=_OriginalKeeperMotionLease(self.source,self.run,self.owner,value['reference'],path,seconds)
        prepared=await self.lease._request('touch-motion-prepare',dict(binding=deepcopy(self.binding),runId=self.run,
            referenceJson=canonical(value['reference']).decode('ascii'),seconds=seconds),forward=True)
        exact(prepared,{'originalKeeperMotionPreparationVersion','ownerInstance','preparationRecorded','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished'})
        need(type(prepared['originalKeeperMotionPreparationVersion']) is int and prepared['originalKeeperMotionPreparationVersion']==3
            and prepared['ownerInstance']==self.owner and prepared['preparationRecorded'] is True
            and all(prepared[k] is False for k in ('nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished')))
        self.preparation=deepcopy(value)
        return dict(originals=deepcopy(frame['originals']),clockJoin=deepcopy(frame['clockJoin']),originalChild=deepcopy(value))
    def bind_preparation(self,frame,seconds):
        """Rebind TRANSPORT to an existing source; never restore a worker from JSON."""
        from ios.adapters.lifecycle_world_hold import coordinates
        need(self.lease is None and self.preparation is None)
        value=frame['originalChild'];need(value['binding']==self.binding and value['runId']==self.run)
        self.owner=value['ownerInstance'];self.preparation=deepcopy(value)
        self.lease=_OriginalKeeperMotionLease(self.source,self.run,self.owner,value['reference'],coordinates(frame),seconds)
        # Any resumed read/release/begin still reaches the original child's
        # actual opaque lease/resource gates; this DTO mints none of them.
    async def capture(self,phase):
        import asyncio
        self.current();need(self.lease is not None and self.preparation is not None)
        value=await asyncio.to_thread(self.runtime.native_passive_world,self.selector,self.run,phase)
        self.current();need(value['ownerInstance']==self.owner)
        frame=value['originalFrame']
        return dict(originals=deepcopy(frame['originals']),clockJoin=deepcopy(frame['clockJoin']),originalChild=deepcopy(value))
    async def inspect(self):need(self.lease is not None);return await self.lease.inspect()
    async def release(self):need(self.lease is not None);return await self.lease.release()
    async def settle(self):need(self.lease is not None);return await self.lease.settle()

