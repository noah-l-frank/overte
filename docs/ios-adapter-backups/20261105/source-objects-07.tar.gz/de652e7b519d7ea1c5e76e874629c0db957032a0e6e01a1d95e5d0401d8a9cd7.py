"""One actual historical consumer graph; no raw-root birth or live authority."""
from pathlib import Path
import cProfile,faulthandler,importlib.abc,importlib.machinery,importlib.util,json,os,signal,sys,sysconfig,threading,traceback,unittest
from metadata import HERE,REPO,RAW,ARTIFACT,ARTIFACT_SHA,load,save,pin,sha,census,proc,processes,fds,validate

assert Path.cwd()==REPO and sys.dont_write_bytecode
assert sha(HERE/'freeze.json')==os.environ['CHAT_READONLY_EXPECTED_FREEZE']
plan=validate();approved=load('approved-source-map.json')
# Complete source/physical verification and independent IPA pin precede ALL
# candidate imports and all sender/receive header reads.
assert all(pin(Path(path))==row for path,row in approved.items())
assert pin(ARTIFACT)==load('input-originals-baseline.json')['tmp27bwiir_/candidate.ipa'] and sha(ARTIFACT)==ARTIFACT_SHA
assert census(RAW)==load('input-originals-baseline.json')
origins=load('absolute-module-origins.json');source_before=dict(approved)
project_tops={name.split('.',1)[0]for name in(*origins['modules'],*origins['namespaces'])}
old_path=list(sys.path);old_meta=list(sys.meta_path)
baseline_fds=fds();baseline_threads=set(threading.enumerate())
identity=proc(os.getpid());assert identity is not None and identity['group']==identity['session']
refusals=[];output_allowed=True;actual_origins={};cleanup=[];returned=False;result=None;case=None;failure=None;diagnostic=None;coverage=None
held_ports=None;held_owners={};held_opens=[];held_flocks=[]
current_frame=sys._getframe;real_fstat=os.fstat;real_lstat=os.lstat
outputs={'term-stack.log','profile.pstats','child-result.json','child-input-first.json','child-input-second.json','child-output-first.json','child-output-second.json'}
locks={str(RAW/relative):load('input-originals-baseline.json')[relative]for relative in(
    'tmpm0n175js/script-feature-sources.lock','tmp4anb7giw/script-feature-sources.lock')}
forbidden={'pymobiledevice3','tidevice','pyidevice','zeroconf','selenium','playwright','appium','PySide6','PyQt6'}

def refuse(reason):
    refusals.append(reason);raise RuntimeError(reason)

def original_held_frame():
    if held_ports is None:refuse('Original held ports not installed')
    cls,wrapper,wrapper_code,function,code,namespace,fcntl_module,flock,cells=held_ports
    if (cls.held is not wrapper or wrapper.__code__ is not wrapper_code or wrapper.__wrapped__ is not function
            or function.__code__ is not code or function.__globals__ is not namespace
            or sys.modules.get('fcntl') is not fcntl_module or fcntl_module.flock is not flock):
        refuse('Installed original held/flock identity changed')
    current_cells=wrapper.__closure__ or ()
    if len(current_cells)!=len(cells)or any(cell is not previous or cell.cell_contents is not value
            for cell,(previous,value)in zip(current_cells,cells)):
        refuse('Original held wrapper closure changed')
    # audit -> this checker -> original held generator. No other caller gets
    # the writable-open or flock port, even for an otherwise pinned lock path.
    frame=current_frame(2)
    if frame.f_code is not code or frame.f_globals is not namespace:
        refuse('Lock operation outside the exact original held frame')
    owner=frame.f_locals.get('self');path=frame.f_locals.get('path')
    if type(owner)is not cls or path!=owner.path or not isinstance(path,Path):
        refuse('Original held receiver/path custody changed')
    key=str(path)
    if key not in locks:refuse('Unpinned original held lock path')
    previous=held_owners.get(key)
    if previous is not None and previous is not owner:refuse('Second lock owner substituted')
    held_owners[key]=owner
    info=real_lstat(path)
    if any(getattr(info,k)!=v for k,v in locks[key].items()if k!='sha256'):
        refuse('Pinned zero-byte original lock changed')
    return frame,owner,key

def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:refuse('SDK/browser/vendor import refused')
    if event=='import'and args[0].split('.')[0]in project_tops and args[0]not in origins['modules']and args[0]not in origins['namespaces']:
        refuse('Project import absent from exact origin map')
    if event=='subprocess.Popen'or event.startswith('socket.')or event in('os.system','os.exec','os.fork','os.forkpty','os.posix_spawn'):
        refuse('No network/Node/SDK/subprocess authority')
    if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
        path=os.path.abspath(os.fsdecode(args[0]));flags=args[2]
        writing=isinstance(flags,int)and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if writing:
            if path in locks:
                # Real flock only: exact preexisting inode, no truncation,
                # append or exclusive create. Existing O_CREAT does not create.
                row=locks[path];info=os.lstat(path)
                frame,owner,key=original_held_frame()
                if key!=path or owner._owner is not None:refuse('Original held open receiver/state mismatch')
                if flags&(os.O_WRONLY|os.O_TRUNC|os.O_APPEND|os.O_EXCL):refuse('Invalid retained lock open')
                if not(flags&os.O_RDWR)or any(getattr(info,k)!=v for k,v in row.items()if k!='sha256'):
                    refuse('Retained lock inode changed')
                held_opens.append(dict(path=key,receiver=id(owner),frameLine=frame.f_lineno))
            elif not(output_allowed and Path(path).parent==HERE and Path(path).name in outputs):
                refuse('Original/source/foreign file write refused')
    if event=='fcntl.flock':
        frame,owner,key=original_held_frame();descriptor,operation=args
        module=held_ports[6]
        if (type(descriptor)is not int or descriptor!=frame.f_locals.get('descriptor')
                or operation!=(module.LOCK_EX|module.LOCK_NB)):
            refuse('flock outside exact original held descriptor/operation')
        info=real_fstat(descriptor)
        if any(getattr(info,k)!=v for k,v in locks[key].items()if k!='sha256'):
            refuse('flock descriptor is not the pinned zero-byte lock inode')
        if not any(row['path']==key and row['receiver']==id(owner)for row in held_opens):
            refuse('flock without the genuine held open prefix')
        held_flocks.append(dict(path=key,receiver=id(owner),descriptor=descriptor,operation=operation,
            device=info.st_dev,inode=info.st_ino))
    if event in('os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.rename','os.link','os.symlink','os.truncate','os.utime'):
        refuse('No filesystem mutation or temporary-directory birth')
sys.addaudithook(audit)

class Origins(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name in origins['modules']:
            source=Path(origins['modules'][name]);assert pin(source)==approved[str(source)],name
            # Build from this one exact source. No cwd, sibling worktree,
            # arbitrary sys.path or unpinned alternate source is searched.
            return importlib.util.spec_from_file_location(name,source,
                submodule_search_locations=[str(source.parent)]if source.name=='__init__.py'else None)
        if name in origins['namespaces']:
            directory=origins['namespaces'][name]
            spec=importlib.machinery.ModuleSpec(name,loader=None,is_package=True)
            spec.submodule_search_locations=[directory];return spec
        if name.split('.')[0]in project_tops:
            refuse('Project module absent from absolute origin map')
        return None

sys.meta_path.insert(0,Origins())
stdlib=Path(sysconfig.get_path('stdlib')).resolve()
sys.path[:]=[p for p in sys.path if p and(str(p).endswith('.zip')or
    Path(p).resolve().is_relative_to(stdlib))and'site-packages'not in p and'dist-packages'not in p]
trace_stream=(HERE/'term-stack.log').open('x')
profiler=cProfile.Profile()

def stop(*_args):
    faulthandler.dump_traceback(file=trace_stream,all_threads=True)
    trace_stream.flush()
    raise KeyboardInterrupt('Fixed300+5 supervisor stop; original stack captured')
signal.signal(signal.SIGTERM,stop)

class RetainedPhase(unittest.TestCase):
    def test_actual_original_phase_graph(self):
        from chat_retained_readonly_phase_probe import diagnose
        global diagnostic,coverage
        diagnostic=diagnose(RAW,(ARTIFACT,ARTIFACT_SHA))
        self.assertTrue(diagnostic['diagnosticOnly'])
        self.assertFalse(diagnostic['wholeChatQualified'])
        from ios.adapters import chat_archive_round
        actual=chat_archive_round._LAST_CONSTRUCTION.get()
        self.assertIs(type(actual),dict)
        coverage=dict(actual)
        self.assertTrue(coverage['scopeClosed'])
        self.assertFalse(coverage['disabled'])
        self.assertEqual(11,coverage['profile'])
        self.assertGreater(coverage['frameHits'],0)
        self.assertIsNone(chat_archive_round._ACTIVE.get())

try:
    # Bind only these already origin-pinned original ports. Do not construct a
    # lock owner or call held()/flock while installing the audit boundary.
    import fcntl
    from adapters.script_feature.lock import ScriptSourceLock
    held_wrapper=ScriptSourceLock.held;held_function=held_wrapper.__wrapped__
    cells=tuple((cell,cell.cell_contents)for cell in held_wrapper.__closure__ or ())
    assert held_wrapper.__code__.co_freevars==('func',)and len(cells)==1 and cells[0][1]is held_function
    held_ports=(ScriptSourceLock,held_wrapper,held_wrapper.__code__,held_function,
        held_function.__code__,held_function.__globals__,fcntl,fcntl.flock,cells)
    output_allowed=False
    case=RetainedPhase('test_actual_original_phase_graph');assert case.id()==plan['caseId']
    profiler.enable()
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(unittest.TestSuite([case]));returned=True
except BaseException as exc:
    failure=dict(type=type(exc).__name__,traceback=traceback.format_exc())
finally:
    profiler.disable();output_allowed=True
    if case is not None:
        prior=case._outcome;drain=unittest.TestResult();pending=len(case._cleanups)
        try:
            if pending:case._outcome=unittest.case._Outcome(drain);unittest.TestCase.doCleanups(case)
        finally:case._outcome=prior
        cleanup.append(dict(id=case.id(),pendingBefore=pending,remaining=len(case._cleanups),
            errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],
            failures=[dict(id=t.id(),traceback=text)for t,text in drain.failures]))
    profiler.dump_stats(str(HERE/'profile.pstats'))
    trace_stream.close()
    for name,module in tuple(sys.modules.items()):
        filename=getattr(module,'__file__',None)
        if filename:
            path=Path(filename).resolve()
            if path.is_relative_to(REPO):
                assert str(path)in approved and pin(path)==approved[str(path)],name
                assert origins['modules'].get(name)==str(path),name
                actual_origins[name]=str(path)
    sdk_absent=not any(name.split('.')[0]in forbidden for name in sys.modules)
    fd_after=fds();threads=[t.name for t in threading.enumerate()if t not in baseline_threads and t.is_alive()]
    remaining=[p for p in processes(identity['session'])if p['pid']not in(identity['pid'],identity['parentPid'])]
    first=census(RAW);second=census(RAW)
    assert all(pin(Path(path))==row for path,row in source_before.items())
    sys.path[:]=old_path;sys.meta_path[:]=old_meta
    save(HERE/'child-input-first.json',first);save(HERE/'child-input-second.json',second)
    # Fixed output membership, with complete bytes/inodes for every artifact
    # already closed at this point. These observer files and the still-open
    # parent log/result are not misrepresented as sealed producer originals.
    sealed={name:pin(HERE/name)for name in('profile.pstats','term-stack.log','child-input-first.json','child-input-second.json')}
    save(HERE/'child-output-first.json',sealed)
    again={name:pin(HERE/name)for name in sealed};save(HERE/'child-output-second.json',again)
    clean=returned and result is not None and result.wasSuccessful()and result.testsRun==1 and not result.skipped
    clean=clean and failure is None and not refusals and sdk_absent and not threads and not remaining and fd_after==baseline_fds
    clean=clean and set(held_owners)==set(locks)and all(owner._owner is None for owner in held_owners.values())
    clean=clean and {row['path']for row in held_opens}==set(locks)and {row['path']for row in held_flocks}==set(locks)
    clean=clean and first==second==load('input-originals-baseline.json')and sealed==again
    clean=clean and all(not row['remaining']and not row['errors']and not row['failures']for row in cleanup)
    save(HERE/'child-result.json',dict(successful=clean,diagnostic=diagnostic,coverage=coverage,standardRunReturned=returned,
        selectedId=plan['caseId'],testsRun=None if result is None else result.testsRun,
        cleanup=cleanup,failure=failure,fdBefore=baseline_fds,fdAfter=fd_after,newThreads=threads,
        remainingOwned=remaining,refusals=refusals,sdkAbsent=sdk_absent,importedOrigins=actual_origins,
        projectTopLevelNamespaces=sorted(project_tops),originalHeldOpens=held_opens,originalHeldFlocks=held_flocks,
        inputCensusesEqual=first==second,inputUnchanged=first==load('input-originals-baseline.json'),
        sealedOutputCensusesEqual=sealed==again,profileOverheadIncluded=True,
        nativeQualified=False,wholeChatQualified=False,deviceQualified=False))
    print('RETAINED_CHAT_DIAGNOSTIC_TERMINAL',clean,flush=True)
if not clean:raise SystemExit(1)
