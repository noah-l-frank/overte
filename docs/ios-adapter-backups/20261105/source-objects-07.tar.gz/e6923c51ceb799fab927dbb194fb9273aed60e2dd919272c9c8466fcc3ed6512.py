"""Root-only metadata assembler for one new World Source5 unissued-input/retirement case.

Imports only stdlib and the independently qualified strict metadata reader.
Nothing runs merely by importing this module; no SUT/Pillow import is made.
"""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,shutil,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
from project_namespace_admission import project_namespace_admission
SOURCE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/chat-controller10d-exact-defused-et-transaction-source-private-20261104'
SUBJECT_SHA='fbcc253aebc8a11883bfebe4ffae10888351337e3e0f4092c477c4550c342f4b'
HELPER_SHA='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
PROPOSAL=REPO/'.ios-host-tmp/world-web-uncaptured-input-recovery-source3-original-baseline-owner-load-private-20261104'
PROPOSAL_SHA='f5b3a3d581668b089c646cee18169de23706596a8b0db27ca172feea88d7bd0c'
GLOBAL_HELPER_SHA='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
WORLD_CAP_HEADER_SHA='eb8a39a4d8a5683aaff16f803b041bcdbff7bfa820945fb1d9020f312464ae05'
SELECTOR='ios.self_tests.test_ios_world_web_uncaptured_input_recovery.WorldWebUncapturedActionRetirementTests.test_action_recovery_then_genuine_retirement_preserves_originals'
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript')


def load(path):return json.loads(Path(path).read_text())
def packet(folder,leaf,digest):
    path=folder/leaf;assert pin(path)['sha256']==digest
    result={str(path):pin(path)};value=load(path)
    for name,row in value['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        actual=folder/name;assert actual.resolve(strict=True)==actual
        expected=row if type(row)is str else row['sha256'];result[str(actual)]=pin(actual);assert result[str(actual)]['sha256']==expected
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--source-freeze',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--destination',required=True,type=Path);p.add_argument('--root-context',required=True,type=Path);p.add_argument('--root-context-sha256',required=True);p.add_argument('--root-context-freeze-sha256',required=True);args=p.parse_args()
    assert Path.cwd()==REPO and sys.dont_write_bytecode and sys.flags.no_site==1
    assert len(args.expected_head)==40 and all(c in'0123456789abcdef'for c in args.expected_head)and head()==args.expected_head
    physical=packet(SOURCE,'source-freeze.json',args.source_freeze)
    physical.update(packet(REPO/'.ios-host-tmp/world-web-uncaptured-source5-action-retirement-first1-bootstrap7-host-function-timing-source-private-20261104','source-freeze.json','5520ed1a0623f8e33316e40fc144c28ef383555d6cbbf6ec348bbde9337524d0'))
    physical.update(packet(REPO/'.ios-host-tmp/world-web-uncaptured-source5-action-retirement-first1-bootstrap6-original-error-context-code-preparation-20261104','source-freeze.json','543721bf459748de63d97fb5c250306d39383731c5410b78b9aed37e265eab2f'))
    actual_b6=REPO/'.ios-host-tmp/root-world-b6-original-context-api-budget-exhaustion-negative-results-20261104'
    physical.update(packet(actual_b6,'freeze.json','2ad27ca370541404d900213283fe0637fda6cf0dc0281afef99691785600df10'))
    for name,row in load(actual_b6/'actual-receipt-references.json').items():
        assert name==row['path']and pin(name)['sha256']==row['sha256'];physical[name]=pin(name)
    physical.update(packet(REPO/'.ios-host-tmp/world-web-uncaptured-source5-action-retirement-first1-bootstrap5-original-baseline-owner-load-code-preparation-20261104','source-freeze.json','af89904df903e82268be00138c23663771969c7d6cf344f8b63882e53322afcd'))
    closed_b5=REPO/'.ios-host-tmp/root-world-b5-retirement-gpu-clock-query-pending-negative-results-20261104'
    physical.update(packet(closed_b5,'freeze.json','7eb152b4be3b4d895f6cc7ceb5107b3f666cbb8d2b3732f2e8c53c3e1939b4b2'))
    for name,row in load(closed_b5/'actual-receipt-references.json').items():
        assert name==row['path']and pin(name)['sha256']==row['sha256'];physical[name]=pin(name)
    previous=REPO/'.ios-host-tmp/world-web-uncaptured-source5-action-retirement-first1-bootstrap1-c10c-code-preparation-20261104'
    physical.update(packet(previous,'source-freeze.json','7096929aeda2bb6150683c8d4bc55cf2bf1633f7c3f40ccdc5e6218a63b4acbe'))
    wrapped_source=REPO/'.ios-host-tmp/audio-original-handoff-first1-bootstrap1-code-preparation-20261104'
    physical.update(packet(wrapped_source,'source-freeze.json','7fcb92756e95dc34767353a7074461e7f35c51b3a8259c1301197974ac961234'))
    physical.update(packet(SUBJECT,'source-freeze.json',SUBJECT_SHA));assert pin(SOURCE/'closed_import_origins.py')['sha256']==HELPER_SHA
    current_readiness,current_readiness_pins=qualification(pin);physical.update(current_readiness_pins)
    physical.update(packet(REPO/'.ios-host-tmp/world-web-uncaptured-source5-action-retirement-first1-bootstrap2-wrapped-chain-origin-negative-code-preparation-20261104','source-freeze.json','630d09b8f7b95112680ced1152c7cd786b97aa379af23830a45785e8d5dc1891'))
    physical.update(packet(REPO/'.ios-host-tmp/snapshot-scene-source1-ordered-source3-own4-bootstrap5-qualified-c10d-original-readiness-private-20261104','source-freeze.json','9ccd59d94fe0403306e733ed7e66771b15e00a9c1d25ff16f2966920917dbb21'))
    physical.update(packet(REPO/'.ios-host-tmp/world-web-uncaptured-source5-action-retirement-first1-bootstrap3-qualified-c10d-original-readiness-code-preparation-20261104','source-freeze.json','b5e23f712cfe7b51979b743f820d06a686ae659aa69985ca80f2efc0f93face8'))
    physical.update(packet(REPO/'.ios-host-tmp/world-web-uncaptured-source5-action-retirement-first1-bootstrap4-genuine-baseline-reconstruction-code-preparation-20261104','source-freeze.json','5d3f97955b71dcc02c0962aacb814f266dd106ed0174bac06c5d253483c64713'))
    physical.update(packet(PROPOSAL,'source-freeze.json',PROPOSAL_SHA))
    candidate_files=('tests/device/ios/adapters/world_web_input.py','tests/device/ios/adapters/world_web_actions.py',
        'tests/device/ios/self_tests/test_ios_world_web_uncaptured_input_recovery.py')
    manifest=load(PROPOSAL/'source-freeze.json');overlays={}
    for logical in candidate_files:
        source=PROPOSAL/'candidate'/logical;expected=manifest['files']['candidate/'+logical]['sha256']
        assert pin(source)['sha256']==expected;physical[str(source)]=pin(source)
        name='.'.join(Path(logical).relative_to('tests/device').with_suffix('').parts)
        overlays[name]=dict(path=str(source),sha256=expected,package=False)
    assert len(overlays)==3
    # Explicit authoritative current Root contract. Only saved metadata bodies
    # are compared during assembly; no current original root is inventoried.
    ctxpath=args.root_context
    assert ctxpath.is_absolute()and ctxpath.resolve(strict=True)==ctxpath and ctxpath.is_relative_to(REPO/'.ios-host-tmp')
    physical.update(packet(ctxpath.parent,'freeze.json',args.root_context_freeze_sha256))
    assert pin(ctxpath)['sha256']==args.root_context_sha256;physical[str(ctxpath)]=pin(ctxpath)
    context=load(ctxpath)
    assert set(context)=={'status','expectedHead','allTargetsTerminal','globalCustody','terminalAdditions','additionalPhysicalProofs'}
    assert context['status']=='ROOT_REVIEWED_QUIET_CURRENT_SOURCE_AND_ORIGINAL_CONTEXT'and context['allTargetsTerminal']is True
    assert context['expectedHead']==args.expected_head
    custody=context['globalCustody'];assert set(custody)=={'helper','seed','baseline'}
    for row in custody.values():
        assert type(row)is dict and set(row)=={'path','sha256'}
        path=Path(row['path']);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_relative_to(REPO/'.ios-host-tmp')
        assert pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
    assert custody['helper']['sha256']==GLOBAL_HELPER_SHA and pin(SOURCE/'global_original_corpus.py')['sha256']==GLOBAL_HELPER_SHA
    assert Path(custody['seed']['path'])==Path(custody['helper']['path']).with_name('global-original-roots-seed.json')
    baseline=load(custody['baseline']['path']);seed=load(custody['seed']['path'])
    assert type(baseline)is dict and len(baseline)>=653 and set(baseline)==set(seed['roots'])
    assert set(current_readiness['requiredOriginalRoots'])<=set(baseline)
    # Exact old653 + extra12 remain literal body subsets, independent from a
    # changing current count; remaining additions are Root-authoritative.
    old=REPO/'.ios-host-tmp/audio-normal-mute-prefix-controller3-final-preparation-20261104/global-original-corpus-baseline.json'
    extras=REPO/'.ios-host-tmp/root-chat-own17-original-extra12-baselines-20261104/expected-additional-originals.json'
    for path,digest,count in((old,'1e89fcf8ce75273e569fb83b2c865251bd6f2b35b4377aa30a7c570a0fa08cff',653),
        (extras,'282a52d6496d3beea42a694b6631ee5d0ca233193c95f21db4419995492d0329',12)):
        assert pin(path)['sha256']==digest;physical[str(path)]=pin(path);body=load(path);assert len(body)==count
        assert all(name in baseline and baseline[name]==rows for name,rows in body.items())
    for addition in context['terminalAdditions']:
        assert set(addition)=={'freezeFile','freezeSha256','packet','roots'}and type(addition['roots'])is list and addition['roots']
        assert set(addition['roots'])<=set(baseline)
        physical.update(packet(Path(addition['packet']),addition['freezeFile'],addition['freezeSha256']))
    for row in context['additionalPhysicalProofs']:
        assert set(row)=={'path','sha256'};path=Path(row['path'])
        assert path.is_absolute()and path.resolve(strict=True)==path and path.is_relative_to(REPO/'.ios-host-tmp')
        assert pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
    old_world=REPO/'.ios-host-tmp/world-web-foreign-sequence-exit-epoch-cache-root32-and-full19-preparation-20261028'
    header=old_world/'ROOT-PLAN.txt'
    assert pin(header)['sha256']==WORLD_CAP_HEADER_SHA and 'short31=300+kill5'in header.read_text()
    physical[str(header)]=pin(header)
    assert str(old_world/'runs')in baseline,'The actual old789 World original run-root must remain in full global custody'
    namespace_source=REPO/'.ios-host-tmp/assets-picker3-reserved-phase-controller18-real-namespace-alias-admission-source-private-20261104'
    physical.update(packet(namespace_source,'source-freeze.json','632fd9563b63356e559b69680766306dd2a74a8c77a8105614ecc686667a5b43'))
    # Preserve actual historical public originals while independently admitting
    # CURRENT public definitions. Original full19 inputs are never runtime Source authority.
    public=set()
    for name in ROOTS:
        root=REPO/name;assert root.resolve(strict=True)==root and root.is_dir()
        for path in root.rglob('*'):
            assert not path.is_symlink()
            if path.is_file():public.add(path)
    for path in public:physical[str(path)]=pin(path)
    modules={};ambiguous={};ordered_roots=(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests')
    for root in ordered_roots:
        for path in sorted(root.rglob('*.py')):
            parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
            if package:parts.pop()
            if not parts:continue
            name='.'.join(parts);row=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=package)
            if name in ambiguous:
                if row not in ambiguous[name]:ambiguous[name].append(row)
            elif name in modules and modules[name]!=row:ambiguous[name]=[modules.pop(name),row]
            else:modules[name]=row
    assert set(ambiguous)=={'test_appium_adapter','test_voice_roundtrip'}
    for name,row in overlays.items():modules[name]=row
    # Pin all source files before narrowing impossible import aliases. Exact
    # C18 function retains every bad alias/full origin row as unadmitted data.
    modules,namespaces,alias_admission=project_namespace_admission(modules,ordered_roots)
    assert all(name in modules and modules[name]==row for name,row in overlays.items())
    external=load(SOURCE/'third-party-source-declarations.json');assert len(external)==39
    third={}
    for name,row in external.items():
        path=Path(row['path']);assert pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
        assert row['kind']in('python','extension')
        third[name]=dict(path=str(path),sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    std=Path(os.__file__).resolve(strict=True).parent;suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);std_namespaces={}
    for current,dirs,files in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink())
        relative=folder.relative_to(std)
        if relative.parts and all(part.isidentifier()for part in relative.parts)and not(folder/'__init__.py').is_file():std_namespaces['.'.join(relative.parts)]=[str(folder)]
        for name in files:
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(suffixes):continue
            assert path.resolve(strict=True)==path;physical[str(path)]=pin(path)
    node=Path(shutil.which('node')).resolve(strict=True);physical[str(node)]=pin(node)
    script=REPO/'tests/device/ios/self_tests/world_web_page_fixture.js'
    model=REPO/'tests/device/ios/self_tests/world_web_whole_fixture.py'
    assert script.is_file()and model.is_file();physical[str(script)]=pin(script);physical[str(model)]=pin(model)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    gd=Path((REPO/'.git').read_text().split('gitdir: ',1)[1].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(path)]=pin(path)
    refpath=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs');physical[str(refpath)]=pin(refpath)
    destination=args.destination
    assert destination.is_absolute()and destination.resolve(strict=False)==destination and destination.parent==REPO/'.ios-host-tmp'
    assert destination.name.startswith('world-web-source5-uncaptured-first1-prepared-')and not destination.exists()
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    destination.mkdir(mode=0o700)
    names=('run-first1.py','supervise-first1.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','world_node_port.py','raw_pipe_tee.py','readonly-own-public-source-verification.json','readonly-shared-stdlib-sources.json','exact-one-selector.json','global_original_corpus.py','project_namespace_admission.py','source_execution_readiness.py','host_function_timing.py')
    for name in names:
        target=destination/name;fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(target)]=pin(target)
    for key,leaf in(('seed','global-original-roots-seed.json'),('baseline','global-original-corpus-baseline.json')):
        original=Path(custody[key]['path']);target=destination/leaf
        fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write(original.read_bytes())
        physical[str(target)]=pin(target);assert physical[str(target)]['sha256']==custody[key]['sha256']
    for name in('metadata_reader','host_common','closed_import_origins','owned_write_boundary','world_node_port','raw_pipe_tee','global_original_corpus','project_namespace_admission','source_execution_readiness','host_function_timing'):
        path=destination/(name+'.py');assert name not in modules
        modules[name]=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=False)
    complete_declared=dict(modules)
    for name,row in alias_admission['unadmittedAliases'].items():
        assert name not in complete_declared;complete_declared[name]=row['origin']
    modules,final_namespaces,alias_admission=project_namespace_admission(complete_declared,ordered_roots)
    assert namespaces==final_namespaces and all(modules[name]==row for name,row in overlays.items())
    cases=load(SOURCE/'exact-one-selector.json');assert cases==[SELECTOR]and len(cases)==1
    origin=dict(modules=modules,namespacePackages=namespaces,projectAliasAdmission=alias_admission,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=std_namespaces,
        stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='PRIVATE_WORLD_SOURCE5_UNCAPTURED_ACTION_RETIREMENT_FIRST1_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(destination),actualPublicHead=args.expected_head,
        projectAliasAdmission=alias_admission,orderedProjectRoots=list(map(str,ordered_roots)),sourceFreeze=args.source_freeze,sourceAndBinaryPins=physical,modules=modules,namespaces=namespaces,thirdPartyModules=third,originPlan=origin,
        subjectOriginModules={name:dict(path=row['path'],sha256=row['sha256'])for name,row in overlays.items()},subjectOriginCount=3,
        cases=cases,wallSeconds=300,killGraceSeconds=5,expectedTemporaryDirectories=1,expectedTemporaryDirectoriesPerCase=1,
        subjectOriginalPath=str(SUBJECT/'closed_import_origins.py'),subjectActualCopiedPath=str(destination/'closed_import_origins.py'),subjectHelperSha256=HELPER_SHA,
        NodeExecutions=1,maxTotalNodes=1,maxNodePerCase=1,maxLiveNodes=1,SDKExecutions=0,physicalNativeQueries=0,declaredModelNativeObservationsAllowed=True,realNetwork=False,oldCorpusInputs=0,assemblerGlobalOriginalCensusCalls=0,prospectiveOuterGlobalOriginalCensusCalls=3,
        helperQualificationOriginalReferenceCount=141,qualifiedSourceExecution=current_readiness,helperQualificationRequiredOriginalRooms=current_readiness['requiredOriginalRoots'],externalRootGuardMustIncludeAllHelperOriginalRooms=True,helperQualificationIsNotWorldQualification=True,source3CompatibilityCasesSelected=False,oldFull19Replayed=False,
        globalCustody=dict(helperPath=str(destination/'global_original_corpus.py'),seedSha256=pin(destination/'global-original-roots-seed.json')['sha256'],baselineSha256=pin(destination/'global-original-corpus-baseline.json')['sha256']),
        oldRootCount=len(baseline),node=dict(path=str(node),pin=physical[str(node)]),nodeScript=dict(path=str(script),pin=physical[str(script)]),nodeModel=dict(path=str(model),pin=physical[str(model)]),
        ambiguousPublicAliasRows=ambiguous,ambiguousPublicAliasesExcluded=sorted(ambiguous),hostBootstrapScope='Held original interpreter/stdlib and fresh private entry/controller definitions are trusted HOSTBOOTSTRAP; delegated SUT/PIL/stdlib Python executes fresh pinned bytes through exact qualified C10d.',
        hostFunctionTimingDiagnostics=dict(enabled=True,profile='world-b7-main-thread-host-function-cost-v1',hostOnly=True,nativeClockUnchanged=True,noBusinessAuthority=True),
        nativeCompiled=False,nativeQualified=False,wholeQualified=False)
    output=destination/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(name)==row for name,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),inputSha256=pin(output)['sha256'],sourcePins=len(physical),cases=1,TDs=1,Node=1,targets=0,globalScans=0)))
    return 0


if __name__=='__main__':raise SystemExit(main())
