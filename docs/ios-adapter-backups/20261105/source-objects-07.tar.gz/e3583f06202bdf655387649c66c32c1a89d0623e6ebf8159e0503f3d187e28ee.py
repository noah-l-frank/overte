"""Actual phase/original-journal cancellation gates; no SDK or abort verdict."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_ui import NativeUIError
from ios.adapters.assets_cancel_intent import AssetsCancelIntent,read
from ios.adapters.assets_episodes import AssetsEpisodes
from ios.adapters.script_runtime import IOSScriptRuntime
from ios.self_tests.test_ios_assets_action_phase import AssetsActionPhaseTests


class AssetsCancelIntentTests(unittest.TestCase):
    def setUp(self):
        self.a=AssetsActionPhaseTests();self.a.setUp();self.addCleanup(self.a.doCleanups)
        ticket,row=self.a.activate(1);self.action=self.a.owner.begin(1,ticket,row['verb'],row['inputs'])
        self.episodes=AssetsEpisodes(self.a.selected,self.a.h.locks);self.owner=AssetsCancelIntent(self.a.selected,self.a.owner,self.episodes)
    def test_intent_revokes_existing_normal_factory_before_sdk_or_new_phase_query_and_new_episode_birth(self):
        runtime=self.a.runtime(self.action);self.owner.begin(self.action,'journey-failure');count=len(self.a.requests)
        with patch.object(IOSScriptRuntime,'_sources',side_effect=self.a.h.no_native) as native:
            with self.assertRaises(NativeUIError):runtime._sources('primary')
            with self.assertRaises(NativeUIError):runtime._assets_sources('primary',self.a.h.locks['primary'])
            self.assertEqual(0,native.call_count)
        self.assertEqual(count,len(self.a.requests))
        with self.assertRaises(NativeUIError):self.episodes.begin(1,'f'*32)
        self.assertEqual([],self.episodes.state['entries']);self.assertEqual([],self.a.h.native_calls)
        self.assertEqual('intent',read(self.a.selected)['phase'])
    def test_explicit_current_cleanup_scope_admits_guard_but_later_foreign_activation_revokes_it(self):
        scope=self.owner.begin(self.action,'user-cancel');runtime=self.a.runtime(self.action);runtime.assets_cancel=scope
        self.assertTrue(runtime._action_guard('primary'));self.assertEqual([],self.a.h.native_calls)
        self.a.activate(2)
        with patch.object(IOSScriptRuntime,'_sources',side_effect=self.a.h.no_native) as native:
            with self.assertRaises(NativeUIError):runtime._sources('primary')
            self.assertEqual(0,native.call_count)
        self.assertEqual([],self.a.h.native_calls);self.assertEqual('intent',self.owner.previous['phase'])
    def test_just_completed_current_action_can_record_terminal_intent_and_prior_originals_stay_pure(self):
        self.a.owner.complete(self.action);scope=self.owner.begin(self.action,'journey-failure');runtime=self.a.runtime(self.action);runtime.assets_cancel=scope
        self.assertTrue(runtime._action_guard('primary'));ticket=self.action.ticket;before=len(self.a.requests)
        self.assertEqual(ticket,self.a.owner.ticket_for(1));self.assertEqual(before,len(self.a.requests))
        self.assertEqual([],self.a.h.native_calls);self.assertEqual(0,self.owner.previous['episodeIndex'])
        # A new requested action is refused BEFORE fixture/source query.
        row=self.a.owner.plan()[1]
        with self.assertRaises(NativeUIError):self.a.owner.begin(2,'e'*32,row['verb'],row['inputs'])
        self.assertEqual(before,len(self.a.requests));self.assertEqual(1,len(self.a.owner.state['records']))
    def test_only_independently_current_ready_episode_can_acquire_cleanup_after_intent(self):
        self.a.owner.complete(self.action)
        ticket,row=self.a.activate(2);action=self.a.owner.begin(2,ticket,row['verb'],row['inputs']);first=self.episodes.begin(1,ticket)
        self.a.owner.complete(action);ticket,row=self.a.activate(3);action=self.a.owner.begin(3,ticket,row['verb'],row['inputs']);self.a.owner.complete(action)
        ticket,row=self.a.activate(4);self.action=self.a.owner.begin(4,ticket,row['verb'],row['inputs']);second=self.episodes.begin(2,ticket)
        scope=self.owner.begin(self.action,'journey-failure')
        runtime=self.a.runtime(self.action);runtime.assets_cancel=scope;runtime.assets_episode=first
        with first.held(),self.assertRaises(NativeUIError):first.runtime_guard(runtime,'primary',first.locks['primary'])
        runtime.assets_episode=second
        with second.held():self.assertTrue(second.runtime_guard(runtime,'primary',second.locks['primary']))
        self.assertEqual('intent',self.owner.previous['phase']);self.assertEqual([],self.a.h.native_calls)
    def test_foreign_intent_body_refuses_existing_cleanup_before_sdk_and_cannot_claim_closed_abort(self):
        scope=self.owner.begin(self.action,'user-cancel');runtime=self.a.runtime(self.action);runtime.assets_cancel=scope
        value=deepcopy(self.owner.previous);value['phase']='closed';self.owner.store.write(value,self.owner.previous)
        try:
            with patch.object(IOSScriptRuntime,'_sources',side_effect=self.a.h.no_native) as native:
                with self.assertRaises(NativeUIError):runtime._sources('primary')
                self.assertEqual(0,native.call_count)
        finally:self.owner.store.write(self.owner.previous,value)
        self.assertEqual('intent',self.owner.previous['phase']);self.assertEqual([],self.a.h.native_calls)


if __name__=='__main__':unittest.main()
