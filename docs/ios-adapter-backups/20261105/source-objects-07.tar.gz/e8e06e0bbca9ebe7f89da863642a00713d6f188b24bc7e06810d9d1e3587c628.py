from pathlib import Path
import ast,hashlib,json,shutil,stat
R=Path.cwd();T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-passive-carrier10-host-binding-root-preparation-20261029/48-native-passive-carrier10';FIX=T/'lifecycle-original-owner-passive-carrier-single-caller-read-overlay-20261029';P=T/'lifecycle-original-owner-passive-carrier10-single-read-root-preparation-20261029';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
for rel,d in json.loads((FIX/'freeze.json').read_text())['files'].items():assert H(FIX/rel)==d
report=json.loads((B/'root-run-first/report.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==26 and report['allPinsEqual'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses']
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((B/'prior-retained-original-pins.json').read_text());root=B/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==26
for p in [root,*sorted(root.rglob('*'))]:prior[str(p)]=pin(p)
assert sum('sha256' in v for v in prior.values())==2727;P.mkdir(mode=0o700);S=P/'49-native-passive-carrier10';S.mkdir(mode=0o700)
for rel,d in json.loads((B/'freeze.json').read_text())['files'].items():
 assert H(B/rel)==d;out=S/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/rel,out)
(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n');stage=json.loads((S/'source-manifest.json').read_text());own={r['path']:r for r in json.loads((FIX/'manifest.json').read_text())['files']};changes=[]
for row in stage['sourcePaths']:
 rel=row['path'];actual=H(R/rel)
 if rel in own:row.update(candidate=own[rel]['candidate'],candidateSHA256=own[rel]['candidateSHA256'],observedPublicSHA256=actual,changesCurrentPublic=actual!=own[rel]['candidateSHA256']);continue
 if actual!=row['candidateSHA256']:
  out=S/'actual-current-dependency/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out);changes.append(dict(path=rel,old=row['candidateSHA256'],actual=actual));row.update(candidate=str(out),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
stage.update(stage=49,name=S.name,status='PRIVATE_UNRUN_SINGLE_MANDATORY_CALLER_READ',exactPublicMutationPlan='Root ONLY Source1 keeper7a7f; Runtime da56, own8 schema alreadycurrent; preserve Live7/fremd bytes.')
stage['orderedParentFreezes'][FIX.name]=H(FIX/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');shutil.copyfile(FIX/'source1.diff',S/'source1-single-caller-read.diff');(S/'clone-provenance-single-caller.json').write_text(json.dumps(dict(parent48Freeze=H(B/'freeze.json'),overlayFreeze=H(FIX/'freeze.json'),original48FailPreserved=True,priorActualFiles=2727,caseCount=10,initialSeconds=90,killAfterSeconds=5,genuineRoots=20,actualDependencyChanges=changes,old43TimeoutChildTerminalQualified=False,executed=False),indent=2)+'\n');(S/'README-single-caller.txt').write_text('Root49 Source1 keeper7a7f only, same10model e115/90+kill5/20realTD. Fresh actual Live7 shared snapshots preserve foreignkeys; no ownregistry writes. Original Store.write fullchecks and mandatory physical caller.read after completed capture Task remain; no outbound before read.2727prioractualfiles incl48FAIL26;43timeout childterminal remains unqualified. No agent tests/imports/PUB.\n')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(S)):H(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(stage=str(S),stageFreeze=H(S/'freeze.json'),parentFreeze=H(P/'freeze.json'),changes=changes),indent=2))
