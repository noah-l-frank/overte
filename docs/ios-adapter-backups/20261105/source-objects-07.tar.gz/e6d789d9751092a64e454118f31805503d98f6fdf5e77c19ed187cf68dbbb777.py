"""Fresh Source/Input constructors recover an unissued passive-read boundary.

The inherited producer runs real page JS in Node. Native/Qt/SDK/GPU operands
remain the existing explicit host models; this is not installed-device proof.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from copy import deepcopy
import uuid
import unittest
from unittest.mock import patch
from adapters.native_script_files import NativeScriptFiles
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUI,NativeUIError
from adapters.script_feature.history import unpack
from feature_journeys.fixtures import context
from ios.adapters.world_web_api_clock import scope as api_scope
from ios.adapters.world_web_file_receipts import WorldWebFileReceipts
from ios.adapters.world_web_identity import WorldWebLease
from ios.adapters.world_web_input import WorldWebInput
from ios.adapters.world_web_retirement import WorldWebRetirement
from ios.self_tests.test_ios_world_web_input import WorldWebInputTests
from ios.self_tests.test_ios_world_web_retirement import Files
from ios.self_tests.world_web_gpu_fixture import sample
from ios.self_tests.world_web_whole_fixture import ComposedWorldWeb


class NormalSDKInputTransport:
    """Existing SDK producer behind a genuinely constructed NativeUI client.

    Session routing and release run through NativeUI's original methods.
    Submitted action bytes still drive the existing Node/DOM/Qt model; the
    transport does not read a requested control or fill an expected state.
    """
    def __init__(self,sdk):
        self.sdk=sdk;self.base='/session/'+sdk.binding['sessionId']
    def call(self,method,path,body=None):
        if not path.startswith(self.base+'/'):raise AssertionError('Foreign modeled W3C session')
        route=path[len(self.base):]
        if method=='DELETE' and route=='/actions':return self.sdk.release()
        return self.sdk.request(method,route,body)


def normal_ui(sdk):
    return NativeUI(NormalSDKInputTransport(sdk),sdk.binding['sessionId'],
        lambda:sdk.process.poll() is None,monotonic=lambda:sdk.time,sleep=sdk.sleep)


@contextmanager
def lose_committed_capture(source,label):
    """Raise after the real Source head commits its real complete record.

    This fault changes only return delivery from the actual PFS write. All
    acquisition, original part writes, record bytes and CAS happen normally.
    No desired document/input value is returned by the fault producer.
    """
    write=source.store.write;fault=dict(fired=False,reference=None)
    def writing(value,previous):
        result=write(value,previous);state=unpack(value['payload'])[0]
        if not fault['fired'] and state['pending'] is None and state['records']:
            ref=state['records'][-1];record=source.record_store(ref['index']).read()
            if unpack(record['payload'])[0]['label']==label:
                fault.update(fired=True,reference=deepcopy(ref))
                raise OSError('Actual Source head committed; modeled return lost')
        return result
    with patch.object(source.store,'write',writing):yield fault


def retained_parts(source):
    # Source declares the exact original graph. Its appendable head is the
    # sole excluded member here; every old record/part remains immutable.
    return {path:(path.read_bytes(),signature) for path,signature in
        source.original_pins(source.previous).items() if path!=source.store.path}


class WorldWebUncapturedInputRecoveryTests(unittest.TestCase):
    setUp=WorldWebInputTests.setUp
    held=WorldWebInputTests.held
    def owner(self,source):
        return WorldWebInput(self.store,source,normal_ui(self.sdk),self.sdk.entity,
            lambda:self.sdk.process.poll() is None,epoch_ms=self.sdk.epoch,monotonic=lambda:self.sdk.time)

    def assert_retained(self,source,pins):
        for path,(body,signature) in pins.items():
            self.assertEqual(body,path.read_bytes())
            self.assertEqual(signature,source.original_signature(path))

    def test_committed_source_lost_return_reconstructs_and_delivers_once(self):
        with self.held():
            source=self.sdk.owner(self.source_store,self.lock);owner=self.owner(source)
            with self.assertRaises(OSError),api_scope(lambda:self.sdk.time),lose_committed_capture(source,'input-focus') as fault:
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'focus','tap','text')
            self.assertTrue(fault['fired']);self.assertEqual([],self.sdk.posted)
            source=self.sdk.owner(self.source_store,self.lock);fresh=self.owner(source)
            old=fault['reference'];pins=retained_parts(source)
            self.assertIsNone(fresh.state['records'][-1]['source'])
            with self.assertRaises(NativeUIError),api_scope(lambda:self.sdk.time):
                fresh.perform(self.sdk.ticket,'focus','tap','text')
            self.assertEqual([],self.sdk.posted)
            with api_scope(lambda:self.sdk.time):
                row=fresh.perform_or_recover_uncaptured(self.sdk.ticket,'focus','tap','text')
            self.assertEqual('returned',row['phase']);self.assertGreater(row['source']['index'],old['index'])
            self.assertEqual(1,len(self.sdk.posted));self.assertEqual(1,self.sdk.releases)
            observed=source.frame(source.capture('actual-focus-after-recovery'))
            self.assertTrue(observed['originals']['document']['source']['dom']['editor']['focused'])
            self.assert_retained(source,pins);before=deepcopy(source.state)
            rebuilt=self.owner(self.sdk.owner(self.source_store,self.lock))
            with api_scope(lambda:self.sdk.time):
                self.assertEqual(row,rebuilt.perform_or_recover_uncaptured(self.sdk.ticket,'focus','tap','text'))
            self.assertEqual(before,rebuilt.source.state);self.assertEqual(1,len(self.sdk.posted))

    def test_partial_source_keeps_abandoned_query_floor_before_fresh_delivery(self):
        with self.held():
            source=self.sdk.owner(self.source_store,self.lock);owner=self.owner(source);self.sdk.fail='geometry'
            with self.assertRaises(NativeUIError),api_scope(lambda:self.sdk.time):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'partial','tap','text')
            self.assertEqual([],self.sdk.posted);partial=deepcopy(source.state['pending'])
            self.assertTrue(partial['nativeQueries']);self.sdk.fail=None
            source=self.sdk.owner(self.source_store,self.lock);fresh=self.owner(source)
            with api_scope(lambda:self.sdk.time):
                row=fresh.perform_or_recover_uncaptured(self.sdk.ticket,'partial','tap','text')
            self.assertIn(partial,source.state['interrupted'])
            current=source.frame(row['source'])
            self.assertNotEqual(partial['start']['nativeBefore']['requestId'],current['clockJoin']['nativeBefore']['requestId'])
            self.assertEqual('returned',row['phase']);self.assertEqual(1,len(self.sdk.posted))

    def test_unknown_post_and_prepared_read_stay_owned_without_replay(self):
        with self.held():
            source=self.sdk.owner(self.source_store,self.lock);owner=self.owner(source);self.sdk.lose=True
            with self.assertRaises(NativeUIError),api_scope(lambda:self.sdk.time):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'unknown','tap','text')
            self.sdk.lose=False;source=self.sdk.owner(self.source_store,self.lock);owner=self.owner(source)
            before=deepcopy(source.state)
            with self.assertRaises(NativeUIError),api_scope(lambda:self.sdk.time):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'unknown','tap','text')
            self.assertEqual(before,source.state);self.assertEqual(1,len(self.sdk.posted))
            write=self.store.write;fired=[]
            def writing(value,previous):
                result=write(value,previous);row=unpack(value['payload'])[0]['records'][-1]
                if row['label']=='prepared' and row['source'] is not None and row['body'] is None and not fired:
                    fired.append(True);raise OSError('Actual input Source-ref committed; modeled return lost')
                return result
            with patch.object(self.store,'write',writing),self.assertRaises(OSError),api_scope(lambda:self.sdk.time):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'prepared','tap','text')
            self.assertEqual([True],fired);source=self.sdk.owner(self.source_store,self.lock);owner=self.owner(source)
            before=deepcopy(source.state);row=owner.state['records'][-1]
            self.assertEqual('reading',row['phase']);self.assertIsNotNone(row['source'])
            with self.assertRaises(NativeUIError),api_scope(lambda:self.sdk.time):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'prepared','tap','text')
            self.assertEqual(before,source.state);self.assertEqual(1,len(self.sdk.posted))

    def test_changed_arguments_or_memory_laundering_refuse_before_acquisition(self):
        with self.held():
            source=self.sdk.owner(self.source_store,self.lock);owner=self.owner(source)
            with self.assertRaises(OSError),api_scope(lambda:self.sdk.time),lose_committed_capture(source,'input-exact'):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'exact','tap','text')
            source=self.sdk.owner(self.source_store,self.lock);owner=self.owner(source);before=deepcopy(source.state)
            with self.assertRaises(NativeUIError),api_scope(lambda:self.sdk.time):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'exact','tap','foreign')
            owner.state['records'][-1]['body']={}
            with self.assertRaises(NativeUIError),api_scope(lambda:self.sdk.time):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'exact','tap','text')
            self.assertEqual(before,source.state);self.assertEqual([],self.sdk.posted)
            owner=self.owner(source)
            with api_scope(lambda:self.sdk.time):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'later','tap','text')
            before=deepcopy(source.state)
            with self.assertRaises(NativeUIError),api_scope(lambda:self.sdk.time):
                owner.perform_or_recover_uncaptured(self.sdk.ticket,'exact','tap','text')
            self.assertEqual(before,source.state);self.assertEqual(1,len(self.sdk.posted))


class WorldWebUncapturedActionRetirementTests(unittest.TestCase):
    assert_retained=WorldWebUncapturedInputRecoveryTests.assert_retained

    def test_action_recovery_then_genuine_retirement_preserves_originals(self):
        # The existing producer exposes an explicit UI factory. Select the real
        # NativeUI constructor there before any WorldWebInput is constructed.
        whole=ComposedWorldWeb(wall_clock=True,use_whole_snapshot=True,configure=lambda fixture:setattr(fixture.sdk,'ui',lambda:normal_ui(fixture.sdk)))
        self.addCleanup(whole.close);sdk,source,marker=whole.sdk,whole.source,whole.scope
        samples={}
        def image(request):
            if request not in samples:samples[request]=sample(whole,request)
            return samples[request]
        baseline=image('ios-'+uuid.uuid4().hex);baseline.capture(sdk.ticket)
        actions=whole.actions();self.assertEqual(5,source.version)
        with api_scope(lambda:sdk.time):actions.act(sdk.activate('open',{}))
        opened=deepcopy(actions.state['calls'][-1]);lease=WorldWebLease(marker,source,opened['before'],opened['after'])
        actions.inputs.entity=lease.packet()['returned']['returned']['entityId']
        call=sdk.activate('focus-type',dict(text=context(sdk.run)['unicode']))
        with self.assertRaises(OSError),api_scope(lambda:sdk.time),lose_committed_capture(source,'input-type-text') as fault:
            actions.act(call)
        self.assertTrue(fault['fired']);self.assertEqual(1,len(sdk.posted));self.assertIsNone(actions.inputs.state['records'][-1]['source'])
        source=sdk.owner(actions.source.store,marker.lock);whole.source=source;pins=retained_parts(source)
        # Reopen the same actual baseline through its genuine constructors.
        # A recovered Source cannot borrow a live sample's old owner identity.
        old_baseline=baseline
        baseline_paths=(baseline.store.path,baseline.clocks.store.path,baseline.frame_owner.store.path)
        baseline_originals={path:(path.read_bytes(),source.original_signature(path)) for path in baseline_paths}
        baseline=sample(whole,old_baseline.request);samples[baseline.request]=baseline
        self.assertIsNot(old_baseline,baseline);self.assertIs(baseline.source,source)
        self.assertEqual(old_baseline.previous,baseline.previous);self.assertEqual(old_baseline.state,baseline.state)
        self.assertEqual(old_baseline.clocks.previous,baseline.clocks.previous)
        self.assertEqual(old_baseline.frame_owner.state,baseline.frame_owner.state)
        self.assert_retained(source,baseline_originals)
        actions=whole.actions()
        with api_scope(lambda:sdk.time):self.assertEqual(dict(performed=True),actions.act(call))
        self.assertEqual(2,len(sdk.posted));self.assertEqual(2,sdk.releases)
        row=actions.inputs.state['records'][-1]
        self.assertGreater(row['source']['index'],fault['reference']['index'])
        actual=source.frame(actions.state['calls'][-1]['after'])['originals']['document']['source']['dom']['editor']
        self.assertEqual(context(sdk.run)['unicode'],actual['text']);self.assertTrue(actual['focused'])
        lease=WorldWebLease(marker,source,opened['before'],opened['after']);fixture=Files(whole)
        files=NativeScriptFiles(fixture.send,fixture.read,sdk.tick,lambda:True,sdk.pid,ios=True,monotonic=lambda:sdk.time,sleep=sdk.sleep)
        receipt=WorldWebFileReceipts(PrivateFeatureState(marker.root/'ios-world-web-primary-files.json'),marker.root,sdk.binding,sdk.run,'primary',marker.lock,
            lambda:True,native=source.native,files=files,epoch_ms=sdk.host_epoch,monotonic=lambda:sdk.time)
        retirement=WorldWebRetirement(PrivateFeatureState(marker.root/'ios-world-web-primary-retirement.json'),lease,baseline,receipt,image,actions.inputs,sdk.origins,sleep=sdk.sleep)
        ticket=sdk.activate('cleanup',{})['ticket']
        with api_scope(lambda:sdk.time):retirement.cleanup(ticket)
        self.assertEqual('retired',retirement.state['phase']);proof=retirement.qualification(retirement.state)
        self.assertEqual([],proof['public']['resources']);self.assertEqual(0,proof['pixels']['changedPixels'])
        intentions=deepcopy(whole.domain.io.actions);posts=deepcopy(sdk.posted)
        with api_scope(lambda:sdk.time):retirement.cleanup(ticket)
        self.assertEqual(intentions,whole.domain.io.actions);self.assertEqual(posts,sdk.posted)
        rebuilt=WorldWebRetirement(retirement.store,lease,baseline,receipt,image,actions.inputs,sdk.origins,sleep=sdk.sleep)
        self.assertEqual(retirement.previous,rebuilt.previous);self.assert_retained(source,pins)
