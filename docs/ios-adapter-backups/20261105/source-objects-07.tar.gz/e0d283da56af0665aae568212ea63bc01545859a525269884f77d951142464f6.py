"""Metadata-only finalizer. Run only after Root reports new HEAD + quiet roots.

No target import or target execution. It creates final files once and cannot
replace a frozen packet. All full raw/source scans wait until this explicit step.
"""
from pathlib import Path
import argparse,ast,hashlib,json,os,shutil,stat,sys,sysconfig
import importlib.metadata
from guard import PREP,REPO,target,pin,census,model_census,namespace,sha

def write(name,value):
    path=target(PREP/name);assert not path.exists()
    with target(path).open('x')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')
    target(path).chmod(0o600)


def git_anchors():
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ')
    directory=Path(git[8:].strip()).resolve(strict=True)
    common=(directory/(directory/'commondir').read_text().strip()).resolve(strict=True)
    head=directory/'HEAD';text=head.read_text().strip();assert text.startswith('ref: refs/heads/')
    reference=common/text[5:];assert reference.is_file()
    return reference.read_text().strip(),[REPO/'.git',head,directory/'commondir',directory/'index',reference]


def runtime_files():
    result={Path(sys.executable).resolve(strict=True),Path(shutil.which('timeout')).resolve(strict=True)}
    stdlib=Path(sysconfig.get_path('stdlib')).resolve(strict=True)
    for current,dirs,files in os.walk(stdlib):
        dirs[:]=[name for name in dirs if name not in('site-packages','dist-packages','__pycache__')]
        for name in files:
            path=Path(current)/name
            if path.suffix in('.py','.so')and path.is_file():result.add(path.resolve(strict=True))
    pillow=Path(importlib.metadata.distribution('Pillow').locate_file('PIL')).resolve(strict=True)
    assert pillow.is_dir()
    for path in pillow.rglob('*'):
        if path.is_file()and path.suffix in('.py','.so'):result.add(path.resolve(strict=True))
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--expected-head',required=True)
    parser.add_argument('--quiet-root-receipt',required=True)
    args=parser.parse_args();assert len(args.expected_head)==40 and all(c in'0123456789abcdef'for c in args.expected_head)
    assert args.quiet_root_receipt.strip()and sys.dont_write_bytecode and not(PREP/'freeze.json').exists()
    draft=json.loads((PREP/'plan-draft.json').read_text());assert draft['status']=='CODE_PREPARATION_ONLY_NO_FINAL_GLOBAL_PINS_NO_START'
    actual,git=git_anchors();assert actual==args.expected_head,'Root HEAD is not the specifically reviewed new HEAD'
    code=json.loads((PREP/'code-preparation-freeze.json').read_text())
    for name,digest in code['files'].items():assert sha(PREP/name)==digest,name
    source=Path(draft['sourceRoot']);frozen=json.loads((source/'freeze.json').read_text())
    assert sha(source/'freeze.json')==draft['sourceFreezeSha256']
    for name,digest in frozen['files'].items():assert sha(source/name)==digest,name
    for row in json.loads((source/'actual-readonly-facts.json').read_text())['sourcePins'].items():assert sha(REPO/row[0])==row[1],row[0]
    input_plan=json.loads(Path(draft['sourceModelPlan']).read_text());assert input_plan['diagnosticAlarmSeconds']==90
    input_paths=[Path(path)for path in input_plan['roots']]
    assert all(p.resolve(strict=True)==p and p.is_relative_to(REPO)for p in input_paths)
    first_inputs=model_census(input_paths)
    assert sum('sha256'in row for row in first_inputs.values())==748
    locks={str(Path(input_plan[key])):pin(Path(input_plan[key]))for key in('sourceLock','primaryLock')}
    assert all(row['stat'][6]==0 and row['stat'][5]==1 and stat.S_ISREG(row['stat'][2])and row['sha256']==hashlib.sha256(b'').hexdigest()for row in locks.values())
    # Do not rebase the old timed-out source map. Its receipts remain exact
    # historical custody, while this new source map is independently current.
    old=Path(input_plan['actualWindowStage']);out=old/'root-run-first'
    report=json.loads((out/'report.json').read_text());assert sha(out/'report.json')==input_plan['actualWindowReportSha256']
    assert report['exitCode']==124 and report['retainedFiles']==748 and report['allPinsEqual']and report['retainedOriginalsUnchanged']and not report['remainingOwnedProcesses']
    assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
    assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text())
    historical=[out/name for name in('report.json','source-before.json','source-after.json','originals-first.json','originals-second.json','process-binding.json')]
    historical+=[old/'created-original-roots.json',old/'source-manifest.json']
    # Merge actual existing root seeds, add this latest43 retained corpus and
    # the entire748 original parent. Dynamic runs/temporary roots remain in
    # the unchanged global helper, with no foreign writer exclusion.
    seeds=[];names=set()
    for packet in sorted((REPO/'.ios-host-tmp').iterdir()):
        if not packet.is_dir()or packet.is_symlink():continue
        f=packet/'global-original-roots-seed.json'
        if f.exists():
            data=json.loads(f.read_text());seeds.append(dict(path=str(f),sha256=sha(f)));names.update(data['roots'])
    names.add(str(Path(draft['additionalCompletedRoot']).relative_to(REPO)))
    names.add(str(Path(draft['fullEmoteInputRoot']).relative_to(REPO)))
    for name in names:
        p=REPO/name;assert not Path(name).is_absolute()and p.resolve(strict=True)==p and p.is_dir()and p.is_relative_to(REPO)
        assert not PREP.is_relative_to(p),'Global seed would encompass this new own output namespace'
    write('global-original-roots-seed.json',dict(schemaVersion=1,roots=sorted(names),actualSeedSources=seeds,noWriterExclusions=True))
    from global_original_corpus import current
    first_global=current();second_global=current();assert first_global==second_global,'Active or changing old raw namespace: do not finalize'
    write('global-original-corpus-baseline.json',first_global)
    assert first_inputs==model_census(input_paths)
    write('input-graph-pins.json',first_inputs);write('existing-lock-pins.json',locks)
    public=namespace();paths={REPO/name for name in public}
    paths.update(runtime_files());paths.update(git);paths.update(historical)
    paths.add(source/'freeze.json');paths.update(source/name for name in frozen['files'])
    paths.update(PREP/name for name in code['files']);paths.add(PREP/'code-preparation-freeze.json')
    # All source entries receive actual stable leaf/directory metadata; Git
    # common-dir anchors are read-only exact files, never remote/config data.
    pinned={str(path):pin(path)for path in sorted(paths)}
    write('immutable-source-pins.json',pinned)
    write('source-map.json',dict(schemaVersion=1,repositoryRoot=str(REPO),publicHead=actual,publicNamespace=public,
        sourcePins=len(pinned),sourceModelFreeze=draft['sourceFreezeSha256'],zeroOverlays=True,hostRuntimeFiles=len(runtime_files()),
        quietRootReceipt=args.quiet_root_receipt,globalRoots=len(first_global),inputOriginalFiles=748,
        newTemporaryDirectories=0,wholeFeatureQualified=False))
    plan=dict(draft,status='FROZEN_UNRUN_REQUIRES_ROOT_REVIEW_AND_WINDOW',publicHead=actual,quietRootReceipt=args.quiet_root_receipt)
    write('plan.json',plan)
    assert pinned=={name:pin(name)for name in pinned}
    assert first_inputs==model_census(input_paths)and first_global==current()
    files={str(f.relative_to(PREP)):sha(f)for f in sorted(PREP.rglob('*'))if f.is_file()and f.name!='freeze.json'}
    write('freeze.json',dict(schemaVersion=1,status='UNRUN_REQUIRES_ROOT_REVIEW_AND_COORDINATED_WINDOW',files=files,
        sourceFreezeSha256=draft['sourceFreezeSha256'],publicHead=actual,case=draft['case'],wallSeconds=180,killAfterSeconds=5,innerAlarmSeconds=90))
    print(json.dumps(dict(freezeSha256=sha(PREP/'freeze.json'),sourcePins=len(pinned),globalRoots=len(first_global),
        inputOriginalFiles=748,caseCount=1,targetsExecuted=0)))

if __name__=='__main__':main()
