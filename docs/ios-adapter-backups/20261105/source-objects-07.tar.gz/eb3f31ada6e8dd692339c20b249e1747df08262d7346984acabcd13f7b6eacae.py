from pathlib import Path
import hashlib,importlib.util,json,stat,sys
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
assert len(sys.argv)==2 and sys.argv[1] in ('before','after')
phase=sys.argv[1];metadata=REPO/'.ios-host-tmp/audio-normal-close-evidence-root-preparation-20261028/run_metadata.py'
spec=importlib.util.spec_from_file_location('audio_private_check_metadata',metadata);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
plan=module.validate_frozen();sources=module.sources(plan);sources[str(Path(__file__).resolve().relative_to(REPO))]=module.pin(Path(__file__).resolve());sources[str((HERE/'retention-plan.json').relative_to(REPO))]=module.pin(HERE/'retention-plan.json')
module.save(HERE/(phase+'-sources.json'),sources)
if phase=='after':assert sources==json.loads((HERE/'before-sources.json').read_text()),'Public/launcher source changed'
reports=[]
for label,reportname,censusname in json.loads((HERE/'retention-plan.json').read_text()):
    report=json.loads((REPO/reportname).read_text());expected=json.loads((REPO/censusname).read_text())
    root=Path(report['runRoot'])/'temporary';actual=module.originals(root);assert actual==expected,label
    reports.append(dict(label=label,files=sum(stat.S_ISREG(v['st_mode']) for v in actual.values()),originalsUnchanged=True))
root=REPO/'.ios-host-tmp/lifecycle-owner-exact26-async-setup-testprep-20261028/retained-first26'
expected=json.loads((REPO/'.ios-host-tmp/lifecycle-owner-exact26-async-setup-root-preparation-20261028/originals-first.json').read_text())
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
actual={}
for p in (root,*sorted(root.rglob('*'))):
    a=p.lstat();row=dict(stat=[getattr(a,k) for k in fields])
    if stat.S_ISREG(a.st_mode):row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    actual[str(p.relative_to(root))]=row
assert actual==expected,'Lifecycle model originals changed'
reports.append(dict(label='lifecycle-async-setup26',files=sum(stat.S_ISREG(v['stat'][2]) for v in actual.values()),originalsUnchanged=True))
module.save(HERE/(phase+'-retention.json'),reports)
print(json.dumps(dict(phase=phase,sourcePins=len(sources),retainedFiles=sum(v['files'] for v in reports),allOriginalsUnchanged=True)),flush=True)
