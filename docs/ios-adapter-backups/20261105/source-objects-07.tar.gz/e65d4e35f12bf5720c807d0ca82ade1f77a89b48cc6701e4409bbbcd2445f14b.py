"""Action-separated normal picker stages with existing durable input slots."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import need
from ios.adapters.assets_files import BUNDLES,local
from ios.adapters.assets_picker import root
from ios.adapters.assets_page_picker import PageLeasePicker


def open_only(picker):
    need(type(picker) is PageLeasePicker and picker.files.state['phase']=='staged')
    picker.page_lease.live(picker.episode)
    if picker.state is None:picker.reserve()
    need(picker.state['phase'] in ('reserved','page-open','picker-open'))
    if picker.state['phase']=='reserved':picker.open_page()
    if picker.state['phase']=='page-open':
        picker._prepare_slot('open-picker','assets.upload');current=picker.capture();actual=root(current,'picker')
        need(actual['ownerRootId']==picker.state['page'] and actual['visible'] and not actual['closing']
            and not actual['requestId'] and not actual['chosen'] and not actual['bundleReview'])
        picker.state.update(picker=actual['rootId'],phase='picker-open');picker.save()
    directory=local(picker.files.state['directory'])
    picker._prepare_slot('focus-folder','asset-file.folder')
    picker._prepare_slot('replace-folder','asset-file.folder','replace',directory)
    current=picker.capture();fields=[row for row in current['controls'] if row['id']=='asset-file.folder']
    need(len(fields)==1 and fields[0]['assetControl']['fieldText']==directory)
    picker._prepare_slot('submit-folder','asset-file.folder','submit');current=picker.capture()
    actual=root(current,'picker',identifier=picker.state['picker'])
    need(actual['directory']==picker.files.state['directory'] and not actual['chosen'])
    need(not any(row['slot']=='choose-primary' for row in picker.state['inputs']));return current


def choose_only(picker):
    need(type(picker) is PageLeasePicker and picker.state['phase'] in ('picker-open','primary-chosen')
        and picker.files.state['phase']=='staged')
    picker.page_lease.live(picker.episode)
    chosen=[entry for entry in picker.state['inputs'] if entry['slot']=='choose-primary']
    if not chosen:return picker.choose_primary()
    need(len(chosen)==1);picker._prepare_slot('choose-primary',chosen[0]['id']);current=picker.capture()
    actual=root(current,'picker',identifier=picker.state['picker']);url=picker.files.state['directory']+'/'+BUNDLES[picker.files.state['resource']][0]
    need(actual['chosen']==[url] and not actual['bundleReview'] and not actual['closing'])
    if picker.state['phase']!='primary-chosen':picker.state['phase']='primary-chosen';picker.save()
    return current


def select_unavailable_only(picker):
    need(type(picker) is PageLeasePicker and picker.files.state['phase']=='primary-retired'
        and picker.state['phase'] in ('primary-chosen','checking-unavailable','unavailable'))
    picker.page_lease.live(picker.episode)
    issued=[entry for entry in picker.state['inputs'] if entry['slot']=='select-unavailable']
    if not issued:return picker.select_after_primary()
    need(len(issued)==1 and picker.state['workBeforeSelect'] is not None)
    return picker.observe_unavailable()
