"""Worker4 completion reads exact Callback9/End2 originals, never an ACK.

Legacy workers1/2/3 retain their existing literal step. No live acquisition may
resume after an actual typed seal or issued end; incomplete ends stay pending.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same


def step(flow,config):
    """Publish before sealing; only the exact paired completed end permits exit."""
    from ios.adapters.emote_callback_finish_profile import IOSEmoteCallbackFinishFeature
    from ios.adapters.emote_callback_canonical_end import completed
    from adapters.script_feature.history import unpack
    from feature_journeys.retirement_receipts import binding_from_context
    from feature_journeys import terminal
    need(type(flow) is IOSEmoteCallbackFinishFeature and flow.role=='actor')
    with flow.held(30):
        flow.load()
        primary=IOSEmoteCallbackFinishFeature(flow.runtime,config['primaryTarget'],flow.client,flow.run,'primary',
            config['primaryArtifactRoot'],config['primaryImagePolicy'],actor_selector=flow.selector,
            epoch_ms=flow.epoch_ms,monotonic=flow.monotonic,sleep=flow.sleep,target_pair=getattr(flow,'configured_pair',None))
        primary.lock=primary.primary_lock=flow.primary_lock
        end=PrivateFeatureState(primary.store.path.with_name('ios-emote-primary-'+flow.run+'-rooted-end.json')).read()
        if end is not None:
            exact(end,{'iosEmoteRootedEndArchiveVersion','runId','archiveSha256','seal','payload'})
            need(type(end['iosEmoteRootedEndArchiveVersion']) is int and end['iosEmoteRootedEndArchiveVersion']==2
                and end['runId']==flow.run)
            rows=unpack(end['payload']);need(len(rows)==1 and type(rows[0]) is dict
                and rows[0].get('phase') in ('prepared','retiring','complete'))
            terminal.sealed(end['seal']);need(end['seal']['description']['runId']==flow.run)
            if rows[0]['phase']=='complete':
                actual=completed(primary,end['seal'],actor=flow);need(actual['stage']=='finish');return 'complete'
            return 'sealed'
        original=PrivateFeatureState(primary.store.path.with_name('ios-emote-primary-'+flow.run+'-terminal.json')).read()
        if original is not None:
            exact(original,{'iosEmoteTerminalJournalVersion','runId','artifactRoot','bindings','locks','payload'})
            need(type(original['iosEmoteTerminalJournalVersion']) is int and original['iosEmoteTerminalJournalVersion']==2
                and original['runId']==flow.run and original['artifactRoot']==str(primary.root)
                and same(original['locks'],dict(primary=str(flow.primary_lock.path),actor=str(flow.lock.path))))
            need(flow.state is not None and same(original['bindings'],
                dict(primary=flow.state['primaryBinding'],actor=flow.state['binding'])))
            rows=unpack(original['payload']);need(len(rows)==1 and type(rows[0]) is dict)
            state=rows[0];terminal.description(state.get('description'),area='emotes',run=flow.run)
            need(all(same(state['description']['roles'][role]['binding'],binding_from_context(binding))
                for role,binding in (('primary',flow.state['primaryBinding']),('actor',flow.state['binding']))))
            if state.get('phase') in ('sealing','sealed'):
                terminal.sealed(state['seal'],state['description']);return 'sealed'
            need(state.get('phase')=='inspected')
        # No live query follows an actual sealed journal or typed end. An
        # inactive fixture without that end remains unresolved responsibility.
        if not flow.phase.status()['active']:return 'inactive'
    # Ordinary observation may have to yield for an original effect or peer.
    # Its own leases/deadline must unwind before that readiness poll; the
    # control-journal read above cannot leave an enclosing SDK lease behind.
    flow.publish();return 'published'
