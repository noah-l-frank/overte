"""Private connected Audio11 coordinator on two existing installed SDKs.

Preparation/current originals, normal fourteen actions, once inputs, immutable
PCM handoff, restoration, abort and original process ends share durable owners.
The independent worker alone receives the publisher token. This implementation
adds no public capability and does not qualify its unrun native dependency.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from copy import deepcopy
import hashlib
from pathlib import Path
import time
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import arguments,result
from feature_journeys.phase_fixture import PhaseFixtureReader
from feature_journeys.witness import Client,projection
from ios.adapters.audio_api_clock import operation
from ios.adapters.audio_configuration import settings
from ios.adapters.audio_once_journey import IOSAudioOnceJourney
from ios.adapters.audio_once_primary import paired_sdk_locks
from ios.adapters.audio_passive_runtime import IOSAudioPassiveRuntime,PassiveSDKLedger
from ios.adapters.audio_runtime import IOSAudioRuntime
from ios.adapters.audio_recorded_owner import IOSAudioRecordedOwner
from ios.adapters.audio_whole_sources import AudioWholeSources
from ios.adapters.audio_whole_evidence import AudioWholeEvidence

NAME='ios-audio11-whole-{}.json'
class AudioWholePending(ValueError):pass

class IOSAudioWholeFeature:
    def __init__(self,adapter,primary,run,role,client,configuration,*,publisher=None,epoch_ms=lambda:time.time()*1000,monotonic=time.monotonic,sleep=time.sleep,runtimes=None,source_locks=None):
        need(role in ('primary','actor') and isinstance(client,Client) and (publisher is None or role=='actor' and isinstance(publisher,Client) and publisher is not client and publisher.token!=client.token and publisher.url==client.url))
        self.adapter,self.primary_selector,self.run,self.role,self.client=adapter,primary,run,role,client
        self.config=settings(configuration,target=primary);self.actor_selector=self.config['actorTarget']
        if runtimes is None:self.actor_runtime,self.primary_runtime=IOSAudioPassiveRuntime(adapter),IOSAudioRuntime(adapter)
        else:
            need(type(runtimes) is tuple and len(runtimes)==2 and isinstance(runtimes[0],IOSAudioPassiveRuntime) and isinstance(runtimes[1],IOSAudioRuntime)
                and all(r.adapter is adapter for r in runtimes));self.actor_runtime,self.primary_runtime=runtimes
        self.primary_root=Path(self.config['primaryArtifactRoot']);self.actor_root=Path(self.config['actorArtifactRoot']);self.public_root=Path(self.config['artifactRoot'])
        self.root=Path(self.config['primaryWholeRoot' if role=='primary' else 'actorWholeRoot'])
        self.selector=primary if role=='primary' else self.actor_selector
        self.store=PrivateFeatureState(adapter.state_path(self.selector).with_name(NAME.format(role)))
        self.publisher,self.epoch_ms,self.monotonic,self.sleep=publisher,epoch_ms,monotonic,sleep
        paths=(adapter.state_path(self.actor_selector).with_name('script-feature-sources.lock'),adapter.state_path(primary).with_name('script-feature-sources.lock'))
        self.locks=tuple(ScriptSourceLock(path) for path in paths) if source_locks is None else source_locks
        need(type(self.locks) is tuple and len(self.locks)==2 and all(isinstance(lock,ScriptSourceLock) and lock.path==path for lock,path in zip(self.locks,paths)))
        roots=[self.primary_root,self.actor_root,self.public_root,Path(self.config['primaryWholeRoot']),Path(self.config['actorWholeRoot'])]
        need(all(root!=path.parent and root not in path.parent.parents and path.parent not in root.parents for root in roots for path in paths))
        need(self.locks[0].path!=self.locks[1].path and self.locks[0].path.parent!=self.locks[1].path.parent)
        self.phase=PhaseFixtureReader(client,run,'audio',epoch_ms=epoch_ms,monotonic=monotonic)
        self.journey=IOSAudioOnceJourney(self.actor_runtime,self.actor_selector,self.primary_runtime,primary,run,self.actor_root,self.primary_root,client,epoch_ms=epoch_ms,monotonic=monotonic,sleep=sleep,source_locks=self.locks)
        self.previous=None;self.state=None;self.public_index=None;self.evidence=AudioWholeEvidence(self)

    @contextmanager
    def held(self):
        with paired_sdk_locks(self.actor_runtime,self.actor_selector,self.primary_runtime,self.primary_selector,source_locks=self.locks):
            self.load();yield

    def load(self):
        self.public_index=None;self.previous=self.store.read();self.state=None if self.previous is None else self.decode(self.previous)
        if self.state is not None:
            from ios.adapters.audio_whole_public_journal import AudioWholePublicJournal
            self.public_index=AudioWholePublicJournal(self)
    def envelope(self):return dict(iosAudio11WholeVersion=1,runId=self.run,role=self.role,primaryTarget=self.primary_selector,fixtureUrl=self.client.url,settings=self.config,state=deepcopy(self.state))
    def decode(self,value):
        exact(value,{'iosAudio11WholeVersion','runId','role','primaryTarget','fixtureUrl','settings','state'})
        need(type(value['iosAudio11WholeVersion']) is int and value['iosAudio11WholeVersion']==1 and value['runId']==self.run and value['role']==self.role and value['primaryTarget']==self.primary_selector and value['fixtureUrl']==self.client.url and same(value['settings'],self.config))
        state=deepcopy(value['state']);exact(state,{'phase','bindings','baseline','actions','pending','sequence','publication','restoration','artifacts','cleanupTicket','terminal','failure','oldEnd','replacement','publicIndex','preparationDone','replacementRestoration','actorEnd'})
        need(state['phase'] in ('preparing','ready','acting','cleaning','cleaned','replacing','terminal-ready','ending','ended','aborting','aborted') and type(state['actions']) is list and len(state['actions'])<=32
            and type(state['sequence']) is int and 0<=state['sequence']<=1000000000)
        exact(state['bindings'],{'primary','actor'})
        for binding in state['bindings'].values():context(binding)
        a,b=state['bindings']['primary'],state['bindings']['actor'];need(a['targetFingerprint']!=b['targetFingerprint'] and a['sessionId']!=b['sessionId']
            and a['artifactSha256']==b['artifactSha256'] and a['sourceRevision']==b['sourceRevision'])
        tickets=set()
        for row in state['actions']+([] if state['pending'] is None else [state['pending']]):
            exact(row,{'call','returned','completed'});arguments('feature.audio.act',row['call']);need(row['call']['runId']==self.run and row['call']['ticket'] not in tickets)
            tickets.add(row['call']['ticket']);need(type(row['returned']) is bool and type(row['completed']) is bool)
        old_state=self.state
        try:
            self.state=state;self.evidence.decode(state['artifacts']);self.validate_actions();self.validate_restoration_grammar()
        finally:self.state=old_state
        return state
    def validate_actions(self):
        completed=[row for row in self.state['actions'] if row['completed']]
        if not completed:return
        parent=self.primary_parent()
        for row in completed:
            call=row['call'];need(row['returned'])
            if call['verb']=='background-resume':
                child=parent.state['background'];need(child is not None and child['after'] is not None)
                original=parent.original(child['after']);need(original['ticket']==call['ticket'] and original['verb']=='background-resume')
            else:
                operations=[o for o in parent.state['operations'] if o['ticket']==call['ticket'] and o['verb']==call['verb']]
                need(len(operations)==1 and operations[0]['after'] is not None);operation=operations[0]
                original=parent.original(operation['before']);need(same(parent.phase_original(original['phaseBefore'],call['ticket'],call['verb']),call['inputs']))
                parent.effect(operation,parent.original(operation['after']))

    def validate_restoration_grammar(self):
        for field,stage in (('restoration','initial'),('replacementRestoration','replacement')):
            journal=self.state[field];exact(journal,{'operations','pending','verified'})
            need(type(journal['operations']) is list and len(journal['operations'])<=24 and type(journal['verified']) is list and len(journal['verified'])<=2)
            rows=journal['operations']+([] if journal['pending'] is None else [journal['pending']])
            if not rows and not journal['verified']:continue
            current=self.current(historical=True,stage=stage)
            for row in rows:
                exact(row,{'verb','wanted','before','inputs','after','launcher'})
                need(row['verb'] in ('cancel','muted','localEcho','open','page-close','page-launcher') and row['before'] in current.state['records']
                    and type(row['inputs']) is list and len(row['inputs'])<=80)
                need(type(row['wanted']) is bool if row['verb'] in ('muted','localEcho') else row['wanted'] is None)
                for item in row['inputs']:
                    exact(item,{'verb','identifier','control','before','returned'}|({'label','element'} if item['verb']=='page' else set()))
                    need(item['before'] in current.state['records'] and type(item['returned']) is bool)
                    original=current.original(item['before'])['originals']['ui'];controls=[c for c in original['controls'] if c['id']==item['identifier']]
                    need(len(controls)==1 and same(controls[0],item['control']))
                if row['after'] is not None:
                    need(row['after'] in current.state['records'])
                    from ios.adapters.audio_whole_restore import AudioWholeRestore
                    restore=object.__new__(AudioWholeRestore);restore.flow,restore.current,restore.journal=self,current,journal
                    need(restore.effect(row,current.original(row['after'])))
                if row in journal['operations']:need(row['after'] is not None)
            for ref in journal['verified']:need(ref in current.state['records']);current.original(ref)

    def guard(self):
        for lock in self.locks:lock.assert_held()
        need(same(self.store.read(),self.previous));return True

    def save(self):
        if self.public_index is not None:self.state['publicIndex']=self.public_index.manifest()
        for lock in self.locks:lock.assert_held()
        need(same(self.store.read(),self.previous));value=self.envelope()
        # Complete historical replay belongs to load()/entry admission. A
        # local CAS write retains the actual just-produced intent/original;
        # it does not reclassify historical data as a current observation.
        self.store.write(value,self.previous)
        need(same(self.store.read(),value));self.previous=deepcopy(value)

    def current(self,*,historical=False,stage=None):
        need(self.state is not None);stage=('replacement' if self.state['replacement'] is not None else 'initial') if stage is None else stage
        need(stage in ('initial','replacement'))
        binding=self.state['bindings']['primary'] if stage=='initial' else self.state['replacement']['newBinding']
        store=PrivateFeatureState(self.adapter.state_path(self.selector).with_name('ios-audio11-current-'+self.role+('-replacement' if stage=='replacement' else '')+'.json'))
        current=AudioWholeSources(store,self.root,binding,self.run,self.role,self.locks[1],source=None,client=self.client,epoch_ms=self.epoch_ms,monotonic=self.monotonic)
        if not historical:
            current.attach(self.primary_runtime._sources(self.primary_selector))
        return current
    def primary_parent(self):
        return IOSAudioRecordedOwner.archive(PrivateFeatureState(self.adapter.state_path(self.primary_selector).with_name('ios-audio-recorded-owner.json')),
            self.primary_root,self.state['bindings']['primary'],self.run,self.locks[1],self.client.url+'/runs/'+self.run+'/')

    @operation
    def prepare(self):
        with self.held():
            if self.state is not None and self.state['phase']!='preparing':return
            if self.state is not None:
                from ios.adapters.audio_whole_inventory import admit
                admit(self)
            if self.state is None:
                from ios.adapters.audio_whole_inventory import admit
                admit(self)
                # Existing canonical bindings only. No ensure_session/create,
                # app restart, permission grant or initial-state replacement.
                sources={role:runtime._sources(selector) for role,runtime,selector in (('primary',self.primary_runtime,self.primary_selector),('actor',self.actor_runtime,self.actor_selector))}
                bindings={role:source['binding'] for role,source in sources.items()}
                self.state=dict(phase='preparing',bindings=bindings,baseline=None,actions=[],pending=None,sequence=0,publication=None,
                    restoration=dict(operations=[],pending=None,verified=[]),artifacts=[],cleanupTicket=None,terminal=None,failure=None,oldEnd=None,replacement=None,publicIndex=dict(revision=0,manifests=[],pending=None),preparationDone=False,replacementRestoration=dict(operations=[],pending=None,verified=[]),actorEnd=None);self.save()
            if self.role=='primary':
                # Publish discoverable Actor responsibility before any input.
                # This is preparation metadata, never independent Actor facts.
                peer=IOSAudioWholeFeature(self.adapter,self.primary_selector,self.run,'actor',self.client,self.config,epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep,runtimes=(self.actor_runtime,self.primary_runtime),source_locks=self.locks)
                peer.load()
                if peer.state is None:
                    peer.state=deepcopy(self.state);peer.state.update(phase='preparing',baseline=None,preparationDone=False,sequence=0,publication=None,restoration=dict(operations=[],pending=None,verified=[]),replacementRestoration=dict(operations=[],pending=None,verified=[]))
                    peer.save()
                else:need(same(peer.state['bindings'],self.state['bindings']))
                # Parent scope exists before current capture or any input. A
                # failure leaves preparing + exact binding/roots discoverable.
                with self.primary_runtime.recorded_owner(self.primary_selector,self.run,self.primary_root,self.client,source_lock=self.locks[1],epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep):pass
                from ios.adapters.audio_whole_restore import AudioWholeRestore
                if self.state['baseline'] is None:AudioWholeRestore(self,self.current()).baseline()
                if not self.state['preparationDone']:
                    current=self.current();restore=AudioWholeRestore(self,current)
                    if restore.journal['pending'] is not None:restore.perform('resolve')
                    _ref,value=current.capture()
                    from ios.adapters.audio_settings_source import settings as original_settings
                    if original_settings(value['originals']['settings'])['client']['localEcho']:
                        from ios.adapters.audio_page_inputs import AudioPageInputs
                        if AudioPageInputs.route(value['originals']['ui'])!='audio':restore.perform('open')
                        restore.perform('localEcho',False)
                    _ref,value=current.capture()
                    from ios.adapters.audio_page_inputs import AudioPageInputs
                    if AudioPageInputs.route(value['originals']['ui'])!='closed':restore.perform('page-close')
                    self.state['preparationDone']=True;self.save()
            else:
                # Independently requalify both actual SDK bindings; prepared
                # peer metadata supplies ordering, never an Actor fact.
                for role,runtime,selector in (('primary',self.primary_runtime,self.primary_selector),('actor',self.actor_runtime,self.actor_selector)):
                    source=runtime._sources(selector);need(same(source['binding'],self.state['bindings'][role]) and source['check']() is not False)
                current=self.current();ref,value=current.capture()
                from ios.adapters.audio_settings_source import admissible
                from ios.adapters.audio_session_source import definite_permission
                admissible(value['originals']['settings']);need(definite_permission(value['originals']['session'])=='granted')
                self.state['baseline']=dict(reference=ref,route='observed',launcher=None)
            self.state['phase']='ready';self.save()

    def active_call(self):
        status=self.phase.read();return status,dict(contractVersion=16,runId=self.run,ticket=status['ticket'],verb=status['verb'],inputs=status['inputs'],fixtureUrl=self.client.url+'/runs/'+self.run+'/')

    @operation
    def act(self,call):
        need(self.role=='primary');call=deepcopy(arguments('feature.audio.act',call));need(call['runId']==self.run);self.prepare()
        with self.held():
            need(self.state['phase'] in ('ready','acting'));status,actual=self.active_call();need(same(actual,call))
            rows=[r for r in self.state['actions'] if r['call']['ticket']==call['ticket']]
            if rows:
                need(len(rows)==1 and same(rows[0]['call'],call) and rows[0]['completed']);return dict(performed=True)
            if self.state['pending'] is None:self.state['pending']=dict(call=call,returned=False,completed=False);self.state['phase']='acting';self.save()
            else:need(same(self.state['pending']['call'],call))
        # Source5 owns each uncertain native/normal input; no completed result
        # cache is passed back as a fresh observation.
        self.journey.act(call,pcm_profile='qt-source-read-to-preview-tap')
        with self.held():
            self.state['pending']['returned']=True;self.save()
        self.finish_evidence(call)
        with self.held():
            self.state['pending']['completed']=True;self.state['actions'].append(self.state['pending']);self.state['pending']=None;self.state['phase']='ready';self.save()
        return dict(performed=True)

    def silence_required(self,call):
        return call['verb'] in ('record-cancel','background-resume') or call['verb']=='mute' and call['inputs']['enabled'] or call['verb']=='record-start' and self.state['actions'] and self.state['actions'][-1]['call']['verb']=='mute' and self.state['actions'][-1]['call']['inputs']['enabled']

    def finish_evidence(self,call):
        if call['verb']=='await-completion':
            with self.held():
                ticket=self.journey.current_ticket(self.locks[0]);need(ticket is not None)
                with self.journey.episode(ticket,self.locks[0]) as custody:
                    from ios.adapters.audio_once_window import retain
                    from ios.adapters.audio_passive_capture_source import original_frame
                    window=retain(custody);owner=custody.owner;snapshot=owner.proof(owner.state['snapshot']);wav=owner.snapshot()['wav']
                    raw=owner.assembled(snapshot['chunks']['capture'],'capture',snapshot['selection'],owner.state['snapshot'])
                    native=original_frame(raw,wav,owner.state['capture'],owner.pid)
                    selected=owner.proof(snapshot['selection']);last=native['source']['rows'][-1]['readAfterEpochMs']
                    need(0<=selected['clockJoin']['nativeAfter']['capturedEpochMs']-last<1500)
                    end=selected['clockJoin']['hostAfterEpochMs']
                    self.evidence.retain(call['ticket'],'audio',wav,source_ticket=ticket,source_reference=window['original'],capture_epoch=end)
                    parent=self.primary_parent()
                    from ios.adapters.audio_pcm_lease import IOSAudioPCMLease
                    lease=IOSAudioPCMLease.archive(PrivateFeatureState(parent.store.path.with_name('ios-audio-pcm-lease.json')),parent)
                    original=lease.snapshot();frame=lease.originals.read(lease.state['snapshot'])
                    # The original input snapshot acquisition time is kept,
                    # even when a later common observation cannot accept it.
                    epoch=frame['clockJoin']['hostAfterEpochMs']
                    self.evidence.retain(call['ticket'],'file',lease.input_wav(),source_ticket=ticket,source_reference=lease.state['snapshot'],capture_epoch=epoch)
        elif self.silence_required(call):
            from ios.adapters.audio_whole_silence import acquire
            acquire(self,call)

    def validate_artifact_source(self,row,*,return_bytes=False):
        # Reopen the actual child hierarchy; the output file is not its own
        # evidence of capture, ticket membership or original acquisition age.
        if row['kind']=='file':
            parent=self.primary_parent()
            from ios.adapters.audio_pcm_lease import IOSAudioPCMLease
            store=PrivateFeatureState(parent.store.path.with_name('ios-audio-pcm-lease.json'))
            lease=IOSAudioPCMLease.archive_retired(store,parent) if parent.state['pending'] is not None or parent.state['observation'] is not None else IOSAudioPCMLease.archive(store,parent)
            need(lease.recording['ticket']==row['sourceTicket'] and lease.state['snapshot']==row['sourceReference'])
            frame=lease.originals.read(lease.state['snapshot']);raw=lease.input_wav();epoch=frame['clockJoin']['hostAfterEpochMs']
        else:
            from ios.adapters.audio_whole_inventory import actor
            ledger=actor(self);need(ledger is not None)
            if 'leaseId' in row['sourceReference']:
                from ios.adapters.audio_whole_silence import lease_id
                need(row['sourceReference']['leaseId']==lease_id(self.run,row['ticket']) and row['sourceTicket']==row['ticket'])
                owner=ledger.archives[row['sourceReference']['leaseId']]
                need(row['sourceReference']==dict(leaseId=owner.lease,snapshot=owner.state['snapshot'],absence=owner.state['absence']))
            else:
                from ios.adapters.audio_passive_actor import lease_id
                owner=ledger.archives[lease_id(self.run,row['sourceTicket'])]
                reference=row['sourceReference'];need(owner.journals['proofs'].reference(reference['index'])==reference)
                proof=owner.proof(reference['index']);need(proof['kind']=='once-window')
            snapshot=owner.snapshot_original();raw=snapshot['raw']['wav']
            need(snapshot['original']==owner.state['snapshot']and same(snapshot['capture'],owner.state['capture']))
            native=snapshot['native'];selected=snapshot['selection']
            need(0<=selected['clockJoin']['nativeAfter']['capturedEpochMs']-native['source']['rows'][-1]['readAfterEpochMs']<1500)
            epoch=selected['clockJoin']['hostAfterEpochMs']
        need(row['captureEpochMs']==epoch and row['bytes']==len(raw) and row['sha256']==hashlib.sha256(raw).hexdigest())
        return raw if return_bytes else True

    def sync_replacement(self):
        if self.role!='actor':return
        from ios.adapters.audio_whole_actor_replacement import synchronize
        return synchronize(self)

    @operation
    def observe(self,call):
        call=arguments('feature.audio.observe',call);need(call['runId']==self.run);self.prepare()
        with self.held():
            need(self.state['phase'] in ('ready','acting','cleaning','cleaned','terminal-ready'))
            self.sync_replacement();current=self.current();reference,value=current.capture();status=value['phaseAfter']
            need(status['active'] and status['activations']);ticket=status['activations'][-1]['ticket']
            self.state['sequence']+=1;sequence=self.state['sequence'];need(sequence>call['afterSequence'])
            captured=value['clockJoin']['hostAfterEpochMs'];actual=current.current_state(value)
            resources=self.held_resources('primary') if self.state['phase'] in ('cleaned','terminal-ready') else []
            observation=dict(schemaVersion=1,contractVersion=16,runId=self.run,sequence=sequence,capturedEpochMs=captured,state=actual,
                artifacts=self.evidence.public(ticket,sequence,captured) if self.role=='primary' else [],resources=[r['resource'] for r in resources],lifecycle=deepcopy(value['originals']['native']['lifecycle']))
            result('feature.audio.observe',observation)
            if self.public_index is None:
                from ios.adapters.audio_whole_public_journal import AudioWholePublicJournal
                self.public_index=AudioWholePublicJournal(self)
            if self.public_index.pending is not None:self.public_index.accept_capture()
            self.public_index.append_public(dict(currentReference=reference,sequence=sequence,bindingStage='replacement' if self.state['replacement'] is not None else 'initial'),observation)
            self.save()
            need(-250<=self.epoch_ms()-captured<=1500);return observation

    def publication_original(self,original,*,current=None):
        exact(original,{'currentReference','sequence','bindingStage'})
        if current is None:current=self.current(historical=True,stage=original['bindingStage'])
        else:
            # The journal may share one newly reconstructed historical reader
            # during its own synchronous replay. It supplies no decoded frame
            # or saved native result: original() below reads exact bytes anew.
            stage=original['bindingStage'];need(stage in ('initial','replacement'))
            binding=self.state['bindings']['primary'] if stage=='initial' else self.state['replacement']['newBinding']
            path=self.adapter.state_path(self.selector).with_name('ios-audio11-current-'+self.role+('-replacement' if stage=='replacement' else '')+'.json')
            need(type(current) is AudioWholeSources and current.historical and current.source is None
                and current.store.path==path and current.root==self.root and current.binding==binding
                and current.run==self.run and current.role==self.role and current.lock is self.locks[1])
            current.bound()
        need(original['currentReference'] in current.state['records'])
        value=current.original(original['currentReference']);phase=value['phaseAfter']
        need(phase['active'] and phase['activations'])
        clock=value['clockJoin'];public=dict(schemaVersion=1,contractVersion=16,runId=self.run,sequence=original['sequence'],
            capturedEpochMs=clock['hostAfterEpochMs'],state=current.current_state(value),artifacts=[],resources=[],lifecycle=value['originals']['native']['lifecycle'])
        result('feature.audio.observe',public)
        return dict(ticket=phase['activations'][-1]['ticket'],public=public,
            acquisition={k:clock[k] for k in ('hostBeforeEpochMs','hostAfterEpochMs','hostBeforeMonotonic','hostAfterMonotonic')})

    def witness_publisher(self):
        from adapters.phase_witness_publisher import PhaseWitnessPublisher
        phase=PhaseFixtureReader(self.publisher,self.run,'audio',epoch_ms=self.epoch_ms,monotonic=self.monotonic);phase.status()
        store=PrivateFeatureState(self.adapter.state_path(self.actor_selector).with_name('phase-publication-audio-'+self.run+'-actor.json'))
        return PhaseWitnessPublisher(store,self.state['bindings']['actor'],phase,self.locks[0],lambda:same(self.store.read(),self.previous),self.publication_original,epoch_ms=self.epoch_ms,monotonic=self.monotonic)

    @operation
    def publish(self):
        need(self.role=='actor' and self.publisher is not None);self.prepare()
        with self.held():
            publisher=self.witness_publisher()
            if not publisher.resolve():raise AudioWholePending('Original planned Actor publication remains owned')
        observation=self.observe(dict(contractVersion=16,runId=self.run,afterSequence=0))
        with self.held():
            current=self.current(historical=True)
            original=dict(currentReference=current.state['records'][-1],sequence=observation['sequence'],bindingStage='replacement' if self.state['replacement'] is not None else 'initial')
            publisher=self.witness_publisher();sequence=publisher.publish(original)
            self.state['publication']=dict(sequence=sequence,sha256=digest(original),returned=True);self.save()
        return observation

    @operation
    def cleanup(self,call):
        need(self.role=='primary');call=arguments('feature.audio.cleanup',call);need(call['runId']==self.run)
        with self.held():
            if self.state is None:raise AudioWholePending('Cleanup has no captured binding; no SDK may be inferred owned')
            status=self.phase.read();need(status['verb']=='cleanup')
            if self.state['cleanupTicket'] is None:self.state['cleanupTicket']=status['ticket'];self.state['phase']='cleaning';self.save()
            need(self.state['cleanupTicket']==status['ticket'] and self.state['phase'] in ('cleaning','replacing','cleaned','terminal-ready'))
            if self.state['phase'] in ('cleaned','terminal-ready'):
                from ios.adapters.audio_whole_terminal import AudioWholeTerminal
                self.validate_restoration();AudioWholeTerminal(self).validate_replacement()
                current=self.current();_ref,value=current.capture();baseline=self.current(historical=True,stage='initial')
                need(same(current.current_state(value),baseline.current_state(baseline.original(self.state['baseline']['reference']))))
                return dict(performed=True)
            old_end=self.state['oldEnd']
            retired_scope=PrivateFeatureState(self.adapter.state_path(self.primary_selector).with_name('ios-audio11-scope-retirement.json')).read()
        if old_end is None and retired_scope is None:
            self.retire_actor()
            with self.held():
                from ios.adapters.audio_whole_restore import AudioWholeRestore
                AudioWholeRestore(self,self.current()).finish()
                with self.primary_runtime.recorded_owner(self.primary_selector,self.run,self.primary_root,self.client,source_lock=self.locks[1],epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep) as parent:
                    need(parent.state['pending'] is None and parent.state['observation'] is None)
                    self.primary_runtime.close_recording_evidence(self.primary_selector,parent)
        from ios.adapters.audio_whole_terminal import AudioWholeTerminal
        AudioWholeTerminal(self).replacement()
        return dict(performed=True)

    def validate_restoration(self):
        need(self.state['baseline'] is not None and len(self.state['restoration']['verified'])==2)
        from ios.adapters.audio_whole_restore import AudioWholeRestore
        current=self.current(historical=True,stage='initial');restore=object.__new__(AudioWholeRestore);restore.flow,restore.current=self,current
        for ref in self.state['restoration']['verified']:
            value=current.original(ref);old,new=restore.guarded(value)
            from ios.adapters.audio_settings_source import settings as actual_settings
            need(same(actual_settings(old['settings']),actual_settings(new['settings'])))
        return True

    def retire_actor(self,*,wait=True):
        started=self.monotonic()
        while True:
            with self.held():
                value=PrivateFeatureState(self.adapter.state_path(self.actor_selector).with_name('ios-audio-passive-ledger.json')).read()
                if value is None:return
                lease=value['leases'][-1]['leaseId'] if value['leases'] else None
                if lease is None:return
                ledger=PassiveSDKLedger(self.actor_runtime,self.actor_selector,self.run,lease,self.actor_root,self.client,self.locks[0]);ledger.transfer_completed();archived=ledger.archives.get(lease)
                if archived is None:raise AudioWholePending('An uncertain Actor child birth remains owned until original End')
                if archived.version==1:
                    if archived.state['absence'] is not None:return
                    with self.actor_runtime.passive_owner(self.actor_selector,self.run,lease,self.actor_root,self.client,source_lock=self.locks[0],epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep) as owner:owner.retire()
                    return
                ticket=archived.state['once']['ticket']
                with self.journey.episode(ticket,self.locks[0]) as custody:
                    custody.owner.retire(passive_only=True)
                    if self.journey.close_inputs(custody):return
            if not wait:raise AudioWholePending('Uncertain native receivers require actual original End')
            need(self.monotonic()-started<20);self.sleep(.1)

    def held_resources(self,role):
        if role=='primary':
            self.validate_restoration()
            born=[r for r in self.state['replacementRestoration']['operations'] if r['verb']=='open']
            # Visual Close is not a Qt object-destruction proof. An input-born
            # replacement Audio UI remains a process-owned lifetime duty.
            return [dict(resource='panel:audio-primary-ui',kind='native-holder',originalSha256=digest(born))] if born else []
        value=PrivateFeatureState(self.adapter.state_path(self.actor_selector).with_name('ios-audio-passive-ledger.json')).read()
        if value is None:return []
        lease=value['leases'][-1]['leaseId'] if value['leases'] else '0'*32
        ledger=PassiveSDKLedger(self.actor_runtime,self.actor_selector,self.run,lease,self.actor_root,self.client,self.locks[0]);ledger.transfer_completed()
        duties=[]
        for owner in ledger.archives.values():
            duty=owner.episode_retired()['cacheCustody']
            if duty is not None:duties.extend(duty['inputs'])
        result=[]
        for key,kind in (('cache','audio-cache-pcm'),('control','audio-control-sender')):
            rows=[d for d in duties if (d['processOwnedControlLive'] if key=='control' else any(d[k] for k in ('cacheObjectStillLive','inputPCMStillHeld','resourcePCMStillHeld')))]
            if rows:result.append(dict(resource='panel:'+kind,kind=kind,originalSha256=digest(rows)))
        return sorted(result,key=lambda row:row['resource'])

    @operation
    def abort(self):
        """Failed preparation/action keeps its originals and invokes actual End.

        Restoration is attempted from a saved baseline, never manufactured.
        Failure is retained and prevents a successful cleanup acknowledgment;
        original End still retires process-bound media/native uncertainty.
        """
        if self.role=='actor':
            from ios.adapters.audio_whole_terminal import AudioWholeTerminal
            if AudioWholeTerminal(self).actor_finish_if_authorized():return dict(performed=True)
        with self.held():
            if self.state is None:raise AudioWholePending('No captured Audio binding exists for abort authority')
            if self.state['phase'] in ('ended','aborted'):return dict(performed=True)
            self.state['phase']='aborting';self.save()
        errors=[]
        try:self.retire_actor(wait=False)
        except (OSError,RuntimeError,ValueError,TypeError,KeyError) as failed:errors.append(failed)
        restoration=False
        if self.role=='primary' and self.state['baseline'] is not None:
            try:
                with self.held():
                    from ios.adapters.audio_whole_restore import AudioWholeRestore
                    AudioWholeRestore(self,self.current()).finish();restoration=True
                    with self.primary_runtime.recorded_owner(self.primary_selector,self.run,self.primary_root,self.client,source_lock=self.locks[1],epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep) as owner:
                        owner.recover_observation()
                        if owner.state['pending'] is not None:owner.resolve() # Observe only; no input replay.
                        self.primary_runtime.close_recording_evidence(self.primary_selector,owner)
            except (OSError,RuntimeError,ValueError,TypeError,KeyError) as failed:errors.append(failed)
        if errors:
            with self.held():self.state['failure']=dict(kind=type(errors[-1]).__name__,restorationEstablished=restoration);self.save()
        from ios.adapters.audio_whole_terminal import AudioWholeTerminal
        AudioWholeTerminal(self).abort_end()
        if self.role=='primary' and self.state['baseline'] is not None and not restoration:
            raise AudioWholePending('Original End completed; pre-run restoration was not established') from (errors[-1] if errors else None)
        return dict(performed=True)

    def terminal(self,call):
        from ios.adapters.audio_whole_terminal import AudioWholeTerminal
        return AudioWholeTerminal(self).call(call)
