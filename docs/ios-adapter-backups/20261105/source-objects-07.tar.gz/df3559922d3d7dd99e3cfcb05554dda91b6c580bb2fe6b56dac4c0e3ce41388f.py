"""Five prospective genuine-source counters, NOT added to World first1.

A separate future closed utility must supply its actual approved plan/origin
reader; these bodies never construct fake modules/specs/frames or source proof.
"""
import json,sys,unittest
from host_function_timing import HostFunctionTimings
_CONTEXT=None

def configure(context):
    global _CONTEXT
    assert _CONTEXT is None and set(context)=={'plan','origins','pin'}
    assert context['origins'].plan is context['plan']
    _CONTEXT=context

def _leaf():return sum(range(100))
def _outer():return _leaf()+_leaf()
def _raises(error):raise error
def _generator():yield 1
def _alternate():return 7

class HostFunctionTimingTests(unittest.TestCase):
    def recorder(self,names):
        assert _CONTEXT is not None
        actual=sys.modules[__name__];context=_CONTEXT
        recorder=HostFunctionTimings(((__name__,None,tuple(names)),))
        recorder.bind_module(actual,context['plan']['modules'][__name__],context['origins'].python_executions[__name__],context['pin'])
        return recorder
    def test_real_nested_selected_calls_have_inclusive_and_selected_exclusive_counts(self):
        recorder=self.recorder(('_leaf','_outer'));recorder.install()
        try:self.assertEqual(sum(range(100))*2,_outer());row=recorder.snapshot()
        finally:restored=recorder.restore()
        self.assertTrue(restored['actualSeparateToolRestored']);self.assertTrue(row['timingComplete'])
        rows={r['label'].rsplit('.',1)[-1]:r for r in row['aggregate']}
        self.assertEqual((2,1),(rows['_leaf']['calls'],rows['_outer']['calls']))
        self.assertEqual(rows['_outer']['inclusiveWallNs'],rows['_outer']['exclusiveAmongSelectedWallNs']+rows['_leaf']['inclusiveWallNs'])
        self.assertEqual(rows['_outer']['inclusiveThreadCpuNs'],rows['_outer']['exclusiveAmongSelectedThreadCpuNs']+rows['_leaf']['inclusiveThreadCpuNs'])
        json.dumps(row)
    def test_genuine_unwind_keeps_original_exception_and_leaves_no_live_frame(self):
        recorder=self.recorder(('_raises',));recorder.install();error=LookupError('actual original toy error')
        try:
            with self.assertRaises(LookupError)as actual:_raises(error)
            self.assertIs(actual.exception,error);row=recorder.snapshot()
        finally:recorder.restore();error.__traceback__=None
        self.assertEqual(1,row['aggregate'][0]['unwinds']);self.assertEqual(0,row['unfinishedSelectedCalls'])
        self.assertFalse(any(type(value).__name__=='frame'for value in recorder.stack));json.dumps(row)
    def test_genuine_generator_is_explicitly_excluded_without_resume_or_yield_claim(self):
        recorder=self.recorder(('_generator',));recorder.install()
        try:self.assertEqual([1],list(_generator()));row=recorder.snapshot()
        finally:recorder.restore()
        self.assertEqual(0,row['boundFunctions']);self.assertEqual(1,len(row['excludedFunctions']));self.assertEqual([],row['aggregate'])
        self.assertEqual('generator-or-coroutine-excluded',row['excludedFunctions'][0]['reason'])
    def test_changed_actual_function_code_only_invalidates_diagnostic_and_original_body_result_survives(self):
        recorder=self.recorder(('_leaf',));recorder.install();old=_leaf.__code__
        try:
            _leaf.__code__=_alternate.__code__
            self.assertEqual(7,_leaf());row=recorder.snapshot()
        finally:_leaf.__code__=old;restored=recorder.restore()
        self.assertFalse(row['timingComplete']);self.assertGreater(row['faultCount'],0);self.assertTrue(restored['actualSeparateToolRestored'])
    def test_wrong_existing_source_origin_refuses_before_own_tool_birth(self):
        recorder=HostFunctionTimings(((__name__,None,('_leaf',)),));context=_CONTEXT
        with self.assertRaises(AssertionError):
            recorder.bind_module(sys.modules[__name__],context['plan']['modules']['host_function_timing'],context['origins'].python_executions[__name__],context['pin'])
        self.assertIsNone(recorder.tool)
