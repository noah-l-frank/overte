"""Discharge SDK-owned Audio cache/PCM only by the actual original keeper end.

No provider-exit shortcut, Node relabel, cache purge or native counter rewrite.
The existing SDK parent predeclares the exact end metadata/artifact scope and
retains every child original. A copied DTO never creates live End authority.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import os
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from ios.adapters.audio_passive_runtime import identity,fsync_directory

NAME='ios-audio-once-actor-0-process-retirement.json'
PROFILE='ios-original-keeper-process-end-v1'
PROFILE_KEY='audioonce'


def family(ledger):
    # Fixed actual ledger types, never a user-supplied profile name. Original
    # microphone paths/keys remain exactly their old defaults.
    from ios.adapters.audio_passive_runtime import PassiveSDKLedger
    if type(ledger)is PassiveSDKLedger:return NAME,PROFILE_KEY,'ios-audio-process-end'
    from ios.adapters.audio_received_mixer_runtime import ReceivedMixerSDKLedger
    need(type(ledger)is ReceivedMixerSDKLedger)
    return 'ios-audio-received-actor-0-process-retirement.json','audioreceived','ios-audio-received-process-end'


def root(ledger):return ledger.root/family(ledger)[2]
def store(ledger):return PrivateFeatureState(ledger.sdkroot/family(ledger)[0])


def prepare(ledger):
    """Parent directory birth and all residual handoffs precede any Stop."""
    ledger.lock.assert_held();ledger.guard()
    unresolved=[]
    for lease,owner in ledger.archives.items():
        slots=[] if owner.version==1 else list(owner.state['once']['inputs'].values())
        closed=owner.state['absence'] is not None and all(slot['claim'] is None or slot['last'] is not None
            and owner.proof(slot['last'])['packet']['complete'] and owner.proof(slot['last'])['packet']['released'] for slot in slots)
        if not closed:
            # Stop may resolve an uncertain native input. It does not pretend
            # that the episode or objects were closed before process death.
            unresolved.append(dict(leaseId=lease,ownerSha256=digest(owner.previous),nativeInstance=owner.state['instance']))
            continue
        episode=owner.episode_retired();duty=episode['cacheCustody']
        if duty is not None and duty['inputs']:
            row=next(row for row in ledger.rows if row['leaseId']==lease)
            if 'onceCacheCustody' not in row:ledger.pending_cache_transfers.append((row,deepcopy(duty)))
    ledger.transfer_completed()
    if ledger.process_end is None:
        need(not root(ledger).exists() and store(ledger).read() is None)
        ledger.version=2;ledger.process_end=dict(phase='planned',rootIdentity=None,proof=None,unresolvedChildren=unresolved);ledger.save()
    if ledger.process_end['phase']=='planned':
        need(not root(ledger).exists());os.mkdir(root(ledger),0o700);fsync_directory(ledger.root)
        ledger.process_end.update(phase='opened',rootIdentity=identity(root(ledger)));ledger.save()
    need(ledger.process_end['phase']=='opened');ledger.guard()
    return dict(store=store(ledger),root=root(ledger),binding=deepcopy(ledger.binding),run=ledger.run,
        role='actor',stage=0,profile_key=family(ledger)[1],lock=ledger.lock)


def shape(ledger):
    value=ledger.process_end
    if value is None:return
    exact(value,{'phase','rootIdentity','proof','unresolvedChildren'});need(value['phase'] in ('planned','opened','complete'))
    need(type(value['unresolvedChildren']) is list and len(value['unresolvedChildren'])<=16)
    for child in value['unresolvedChildren']:
        exact(child,{'leaseId','ownerSha256','nativeInstance'});owner=ledger.archives.get(child['leaseId'])
        need(owner is not None and digest(owner.previous)==child['ownerSha256'] and owner.state['instance']==child['nativeInstance'])
    if value['phase']=='planned':need(value['rootIdentity'] is None and value['proof'] is None and not root(ledger).exists() and store(ledger).read() is None)
    else:
        need(identity(root(ledger))==value['rootIdentity'])
        if value['phase']=='opened':need(value['proof'] is None)
        else:archived(ledger)


def check(ledger,proof):
    need(type(proof['iosOriginalKeeperRetirementVersion']) is int and proof['iosOriginalKeeperRetirementVersion']==1 and proof['profile']==PROFILE and proof['profileKey']==family(ledger)[1]
        and proof['resourceRetirementEstablished'] is True and same(proof['binding'],ledger.binding)
        and proof['runId']==ledger.run and proof['role']=='actor' and type(proof['stage']) is int and proof['stage']==0
        and type(proof['processId']) is int and proof['processId']==int(ledger.binding['processIdentity']))
    instances={owner.state['instance'] for owner in ledger.archives.values() if owner.state['instance'] is not None}
    need(len(instances)==1 and proof['nativeFeatureInstance'] in instances)
    return proof


def finish(ledger,end):
    from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
    need(type(end) is IOSOriginalKeeperProcessEnd and end.lock is ledger.lock and end.store.path==store(ledger).path
        and end.root==root(ledger) and end.profile==PROFILE and end.role=='actor' and end.stage==0
        and end.profile_key==family(ledger)[1] and same(end.binding,ledger.binding) and end.run==ledger.run)
    ledger.lock.assert_held();need(ledger.process_end is not None and ledger.process_end['phase']=='opened')
    proof=check(ledger,end.retirement_original())
    # The class's pure reader independently reopens actual retained files and
    # completed Source/provider/SDK-delete originals, before parent discharge.
    IOSOriginalKeeperProcessEnd.archived_original(proof,store=store(ledger),root=root(ledger),binding=ledger.binding,
        run=ledger.run,role='actor',stage=0,profile_key=family(ledger)[1],lock=ledger.lock)
    compact=deepcopy(proof);compact.pop('archive')
    ledger.process_end.update(phase='complete',proof=compact);ledger.save()
    return archived(ledger)


def archived(ledger):
    from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
    value=ledger.process_end;need(value is not None and value['phase']=='complete')
    proof=deepcopy(value['proof']);proof['archive']=store(ledger).read()
    need(digest(proof['archive'])==proof['archiveSha256'])
    IOSOriginalKeeperProcessEnd.archived_original(proof,store=store(ledger),root=root(ledger),binding=ledger.binding,
        run=ledger.run,role='actor',stage=0,profile_key=family(ledger)[1],lock=ledger.lock)
    check(ledger,proof)
    return dict(retired=True,originalProcessEnd=deepcopy(value['proof']),cachePCMDischargedByOriginalProcessEnd=True,
        nativeQualified=False,physicalADCQualified=False,acousticQualified=False,peerQualified=False,wholeQualified=False)
