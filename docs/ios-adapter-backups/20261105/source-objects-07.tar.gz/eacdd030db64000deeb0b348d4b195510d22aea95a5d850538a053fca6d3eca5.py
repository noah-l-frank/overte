"""Metadata-only prior raw custody; no original writer or result authority."""
from pathlib import Path
import hashlib,json,stat
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
HERE=Path(__file__).resolve().parent
REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()
def pin(path):
    first=path.lstat();value={name:getattr(first,name)for name in FIELDS}
    if stat.S_ISREG(first.st_mode):value['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    elif stat.S_ISLNK(first.st_mode):value['target']=str(path.readlink())
    else:assert stat.S_ISDIR(first.st_mode),'Historical special raw file'
    assert value.items()>=dict((name,getattr(path.lstat(),name))for name in FIELDS).items()
    return value

def roots():
    seed=json.loads((HERE/'global-original-roots-seed.json').read_text())
    result={REPO/name for name in seed['roots']}
    # Include every later run namespace. There is NO writer/controller exclusion.
    for directory in(REPO/'.ios-host-tmp').iterdir():
        if directory.is_dir()and not directory.is_symlink():
            path=directory/'runs'
            if path.is_dir()and not path.is_symlink():result.add(path)
    for path in result:assert path.resolve(strict=True).is_relative_to(REPO)and not path.is_symlink()
    return sorted(result)

def current():
    result={}
    for root in roots():
        assert root.is_dir()and root.resolve(strict=True)==root
        result[str(root)]={str(path.relative_to(root)):pin(path)for path in(root,*sorted(root.rglob('*')))}
    return result

def baseline():return json.loads((HERE/'global-original-corpus-baseline.json').read_text())

def guard():
    value=current();assert value==baseline(),'Global historical corpus membership/bytes/inode changed; wait for writer, never exclude it'
    return value
