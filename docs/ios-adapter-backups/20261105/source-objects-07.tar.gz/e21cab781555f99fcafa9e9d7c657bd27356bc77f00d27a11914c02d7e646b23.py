"""Original Source/worker/touch_session/files; RSD/HID/display remain MODELS."""
import asyncio,json,os
from copy import deepcopy
from types import SimpleNamespace
from unittest.mock import patch
from test_native_passive_carrier_models import NativePassiveCarrierModels


class Resource4ObservationModels(NativePassiveCarrierModels):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        self.assertEqual({},self.ops.native_query_journals);self.assertEqual([],self.f.states())
        self.rsd.service=SimpleNamespace(address=('fd00::2',1)) # SDK MODEL, before selection/birth.
        from ios.self_tests.lifecycle_touch_resources_fixture import Display
        self.resource_display=Display();self.resource_receiver=None;self.resource_sdk_births=[]
    async def prepare_rpc(self):
        args=await super().prepare_rpc()
        from ios.adapters.hid_session import touch_session as actual_touch_session
        from ios.adapters.lifecycle_touch_resource_owner import owner_header
        from ios.self_tests.lifecycle_touch_resources_fixture import Receiver
        outer=self
        def header_before_sdk(kind):
            recorder=outer.resource._observation_owner;outer.assertIsNotNone(recorder)
            outer.assertEqual(recorder.previous,recorder.store.read())
            owner_header(recorder.previous,outer.binding,outer.run)
            outer.assertEqual([],recorder.state['frames']);outer.assertIsNone(recorder.state['pending'])
            outer.assertEqual(outer.prepared_bytes,outer.resource.store.path.read_bytes())
            outer.resource_sdk_births.append(kind)
        def receiver():
            header_before_sdk('receiver');outer.assertIsNone(outer.resource_receiver)
            outer.resource_receiver=Receiver();return outer.resource_receiver
        def display(rsd):
            header_before_sdk('display');outer.assertIs(outer.rsd,rsd);return outer.resource_display
        def hid(rsd):
            header_before_sdk('hid');outer.assertIs(outer.rsd,rsd);return outer.f.context
        def observed_session(rsd,address,**options):
            outer.assertIs(outer.rsd,rsd);outer.assertEqual('fd00::1',address)
            outer.assertIs(options['observation'],outer.resource._source)
            outer.assertIs(options['socket_factory'],outer.cap.udp_socket)
            # Actual existing source function and context cleanup run unchanged.
            # Only its three explicit original SDK producer factories are DI.
            return actual_touch_session(rsd,address,observation=options['observation'],
                display_factory=display,hid_factory=hid,socket_factory=receiver)
        self.enterContext(patch('ios.adapters.lifecycle_touch_resource_owner.touch_session',new=observed_session))
        return args
    def observation_args(self):
        from adapters.script_feature.history import canonical
        return dict(binding=deepcopy(self.binding),runId=self.run,nativeMotionResourceObservationVersion=1,
            expectedOwnerInstance=self.ops.instance,preparationReferenceJson=canonical(self.ops.retained_motion_resource[8]).decode('ascii'))
    async def observation(self,*,recover=False):
        operation='touch-resource-recover' if recover else 'touch-resource-capture'
        result=await self.passive_rpc(operation,self.observation_args())
        self.assertEqual(3,result['originalKeeperTouchResourceVersion']);self.assertFalse(result['nativeTouchSupport']);self.assertFalse(result['resourceRetirementEstablished'])
        return result,json.loads(result['resourceJson'])
    async def read_observation(self,result,value):
        return await asyncio.to_thread(self.runtime._resource_metadata_original_read,
            'modeled-original-source',self.observation_args(),result,value)
    async def test_same_original_worker_has_pre_sdk_observation_wal_then_actual_five_resource_edges_and_returned_cleanup_without_retirement(self):
        await self.open_motion();self.assertEqual(['receiver','display','hid'],self.resource_sdk_births)
        resource=self.resource;recorder=resource._observation_owner;original_prep=resource.store.path.read_bytes()
        self.assertEqual(self.prepared_bytes,original_prep);self.assertEqual([],recorder.state['frames'])
        first,selector=await self.observation();held=await self.read_observation(first,selector)
        self.assertEqual({'rsd','receiver','drain','display','hid'},{r['kind'] for r in held['capture']['source']['resources']})
        self.assertTrue(held['capture']['worker']['workerRunning']);self.assertFalse(held['capture']['worker']['contextExitReturned'])
        self.assertIs(self.source._born[0]['motionObservation'],recorder._observation_birth)
        self.assertIs(recorder,recorder._observation_birth[7]);self.assertEqual(16,len(self.commands))
        await self.passive_rpc('touch-release',{})
        self.assertIsNone(resource.lock._owner) # Original worker's with-lock actually returned.
        self.assertEqual(original_prep,resource.store.path.read_bytes())
        last,selector=await self.observation();released=await self.read_observation(last,selector)
        self.assertIsNone(resource.lock._owner) # RPC/read acquire and release their own SAME lock.
        self.assertFalse(released['capture']['worker']['workerRunning']);self.assertTrue(released['capture']['worker']['contextExitReturned'])
        edges={r['edge'] for r in released['capture']['source']['events']}
        self.assertTrue({'receiver-close-returned','source-finally-body-tail-observed','drain-await-settled','hid-context-exit-returned'}<=edges)
        self.assertTrue(all(fd.fileno()==-1 for fd in self.resource_receiver.sockets));self.assertEqual(1,len(self.resource_display.stops))
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(original_prep,resource.store.path.read_bytes())
        self.assertFalse(released['resourceRetirementEstablished']);self.assertEqual(2,len(recorder.state['frames']))
        with resource.lock.held(),self.assertRaises(RuntimeError):resource.ensure_retired()
    async def test_foreign_owner_or_preparation_cannot_snapshot_write_or_release_original_resource(self):
        from adapters.script_feature.history import canonical
        await self.open_motion();recorder=self.resource._observation_owner;args=self.observation_args();before=(recorder.store.path.stat().st_ino,recorder.store.path.read_bytes())
        reference=deepcopy(self.ops.retained_motion_resource[8]);reference['inode']+=1
        for changed in (dict(args,expectedOwnerInstance='f'*32),dict(args,preparationReferenceJson=canonical(reference).decode('ascii'))):
            with self.assertRaises(RuntimeError):await self.passive_rpc('touch-resource-capture',changed)
        self.assertEqual([],recorder.state['frames']);self.assertEqual(before,(recorder.store.path.stat().st_ino,recorder.store.path.read_bytes()))
        self.assertFalse(self.ops.touch.up_issued);self.assertEqual([0xC2,0xC2],self.f.states())
        await self.passive_rpc('touch-release',{});self.assertEqual([0xC2,0xC2,0x02],self.f.states())
    async def test_lost_saved_capture_return_recovers_exact_original_without_snapshot_or_second_input(self):
        await self.open_motion();write=self.frame_store_type.write
        def lost(store,index,frame):
            result=write(store,index,frame)
            if store.namespace=='lifecycle-touch-resource':raise OSError('Declared capture return loss AFTER actual saved original')
            return result
        with patch.object(self.frame_store_type,'write',new=lost),self.assertRaises(RuntimeError):await self.observation()
        recorder=self.resource._observation_owner;self.assertEqual('saved',recorder.state['pending']['phase']);self.assertEqual([],recorder.state['frames'])
        full=deepcopy(recorder.state['pending']);path=recorder.files.path(full);before=(path.stat().st_ino,path.read_bytes());commands=len(self.commands)
        await self.passive_rpc('touch-release',{})
        self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        # A recover operation MUST NOT call the native/SDK/observer producer.
        # Existing snapshot function identity stays unchanged. Forbid only a
        # NEW producer clock read: saved-only recovery cannot call snapshot.
        with patch.object(recorder._source,'clock',side_effect=AssertionError('Recovery sampled a new resource clock')):
            result,selector=await self.observation(recover=True)
            saved=await self.read_observation(result,selector)
        self.assertEqual(before,(path.stat().st_ino,path.read_bytes()));self.assertEqual(full['sha256'],selector['reference']['sha256'])
        self.assertIsNone(recorder.state['pending']);self.assertEqual(1,len(recorder.state['frames']));self.assertEqual(commands,len(self.commands))
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertTrue(saved['capture']['worker']['workerRunning'])
        self.assertTrue(self.ops.touch.worker.done()) # Saved capture remains historical, never re-clocked.
        # Current Source loss cannot block ORIGINAL already-saved recovery or Up.
        with patch.object(self.cap,'current',side_effect=RuntimeError('Declared Source/RSD current loss')):
            recovered,_=await self.observation(recover=True);self.assertEqual(result['resourceJson'],recovered['resourceJson'])
            await self.passive_rpc('touch-release',{})
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,len(self.resource_display.stops))
    async def test_busy_original_native_query_refuses_observation_without_changing_recorder_then_original_return_allows_capture(self):
        await self.open_motion();self.response_gate.clear();before=len(self.commands);query=asyncio.create_task(self.issue('feature-native-observe'));self.controls_motion.append(query)
        try:
            while len(self.commands)==before:await asyncio.sleep(.001)
            recorder=self.resource._observation_owner;saved=(recorder.store.path.stat().st_ino,recorder.store.path.read_bytes())
            with self.assertRaises(RuntimeError):await self.observation()
            self.assertEqual([],recorder.state['frames']);self.assertEqual(saved,(recorder.store.path.stat().st_ino,recorder.store.path.read_bytes()))
            self.assertFalse(query.done());self.assertFalse(self.resource._native_step._failed)
        finally:self.response_gate.set()
        await query;result,value=await self.observation();self.assertEqual(1,(await self.read_observation(result,value))['reference']['index'])
        await self.passive_rpc('touch-release',{})
    async def test_samebyte_capture_inode_replacement_refuses_original_reader_without_capture_or_input_replay(self):
        await self.open_motion();result,selector=await self.observation();recorder=self.resource._observation_owner
        path=recorder.files.path(recorder.files.expand(selector['reference']));raw=path.read_bytes();inode=path.stat().st_ino
        other=path.with_name('declared-foreign-resource-original');other.write_bytes(raw);other.chmod(0o600);os.replace(other,path);self.assertNotEqual(inode,path.stat().st_ino)
        commands=len(self.commands)
        with self.assertRaises((RuntimeError,ValueError)):await self.read_observation(result,selector)
        self.assertEqual(commands,len(self.commands));self.assertEqual(1,len(recorder.state['frames']))
        await self.passive_rpc('touch-release',{});self.assertEqual([0xC2,0xC2,0x02],self.f.states())
    async def test_foreign_recorder_alias_cannot_borrow_original_source_birth_and_original_release_stays_possible(self):
        await self.open_motion();resource=self.resource;original=resource._observation_owner;commands=len(self.commands)
        from ios.adapters.lifecycle_touch_resource_owner import LifecycleTouchResourceOwner
        # Real class, copied same fields/source/store/observer: only actual
        # source-born row identity distinguishes this forged recorder alias.
        foreign=LifecycleTouchResourceOwner.__new__(LifecycleTouchResourceOwner);foreign.__dict__.update(original.__dict__)
        resource._observation_owner=foreign
        try:
            with self.assertRaises(RuntimeError):await self.observation()
            self.assertEqual(commands,len(self.commands));self.assertEqual([],original.state['frames'])
            await self.passive_rpc('touch-release',{})
        finally:resource._observation_owner=original
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,len(self.resource_display.stops))
    async def test_next_actual_capture_changes_owner_wal_generation_so_old_header_reference_cannot_be_spliced(self):
        await self.open_motion();first,old=await self.observation();second,new=await self.observation();self.assertNotEqual(old['ownerReference'],new['ownerReference']);self.assertNotEqual(old['ownerReference']['sha256'],new['ownerReference']['sha256'])
        commands=len(self.commands)
        with self.assertRaises((RuntimeError,ValueError)):await self.read_observation(first,old)
        value=await self.read_observation(second,new);self.assertEqual(2,value['reference']['index']);self.assertEqual(2,len(value['owner']['state']['frames']))
        self.assertEqual(commands,len(self.commands));self.assertEqual([0xC2,0xC2],self.f.states());await self.passive_rpc('touch-release',{})

    async def test_postrelease_changed_preparation_is_refused_under_same_original_lock_without_new_clock_query_or_second_up(self):
        await self.open_motion();result,selector=await self.observation();await self.read_observation(result,selector)
        resource=self.resource;recorder=resource._observation_owner;prepared=resource.store.path.read_bytes()
        await self.passive_rpc('touch-release',{});self.assertIsNone(resource.lock._owner)
        self.assertEqual(prepared,resource.store.path.read_bytes());self.assertTrue(self.ops.touch.worker.done())
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());commands=len(self.commands)
        # Preserve the task-owned original bytes before this DECLARED new-test
        # metadata corruption. Never restore them as a new source admission.
        original=resource.store.path.with_name('retained-original-preparation-before-declared-corruption.json')
        original.write_bytes(prepared);original.chmod(0o600)
        changed=deepcopy(resource.previous);changed['state']['seconds']=11
        with resource.lock.held():resource.store.write(changed,resource.previous)
        actual=resource.store.path.read_bytes();frames=deepcopy(recorder.state['frames']);owner=recorder.store.path.read_bytes()
        with patch.object(recorder._source,'clock',side_effect=AssertionError('Changed preparation reached snapshot clock')):
            with self.assertRaises(RuntimeError):await self.observation()
        self.assertIsNone(resource.lock._owner);self.assertEqual(actual,resource.store.path.read_bytes())
        self.assertEqual(owner,recorder.store.path.read_bytes());self.assertEqual(frames,recorder.state['frames'])
        self.assertEqual(prepared,original.read_bytes());self.assertEqual(commands,len(self.commands))
        await self.passive_rpc('touch-release',{});self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        self.assertTrue(all(fd.fileno()==-1 for fd in self.resource_receiver.sockets));self.assertEqual(1,len(self.resource_display.stops))
