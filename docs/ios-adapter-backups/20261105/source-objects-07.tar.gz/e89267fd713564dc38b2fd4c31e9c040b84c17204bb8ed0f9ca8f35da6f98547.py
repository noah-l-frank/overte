from pathlib import Path
import difflib
import hashlib
import json

repo = Path.cwd()
reference = repo / '.ios-host-tmp/qt-qml-readonly-6.11.1-9es8y5lo'
files = {
    'src/qml/common/qv4compileddata_p.h': '97515f80b0ad8e5ad1465db0cc532f286f27be2d1ab4e9861dbe087eb23c6ff3',
    'src/qml/common/qv4compileddata.cpp': '1b0e725e00b52f3bb61c6b6e5dfd5724475fd304fe782b18a494626885d21240',
    'src/qml/jsruntime/qv4executablecompilationunit_p.h': '853ec1242470df783f1515a76b07178dbdf69d2d8bc840218e08f46a545e40cc',
    'src/qml/qml/qqmltypedata_p.h': '54d732b64bb03817e83ebe071cced92e9a94e0bb8fd95c8107314c3e666da089',
    'src/qml/qml/qqmltypedata.cpp': 'a353c4d89e3d4500beffc35129f1b20993adb3ac095824a6729892ec3c23e0c5',
}
originals = {}
updated = {}
for name, expected in files.items():
    data = (reference / Path(name).name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected, name
    originals[name] = data.decode('utf-8')
    updated[name] = originals[name]

def replace(name, before, after):
    assert updated[name].count(before) == 1, (name, before)
    updated[name] = updated[name].replace(before, after)

compiled = 'src/qml/common/qv4compileddata_p.h'
replace(compiled, '#include <QtCore/qtyperevision.h>\n', '''#include <QtCore/qtyperevision.h>

#if defined(Q_OS_IOS)
// Dedicated Overte E2E Qt package; inactive until explicit native admission.
// This changes only the in-memory owner, never the persistent Unit format.
#define QT_OVERTE_E2E_QML_SOURCE_RECEIPTS 1
#include <QtCore/qvariant.h>
#endif
''')
replace(compiled, '    const QQmlPrivate::AOTCompiledFunction *aotCompiledFunctions = nullptr;\n', '''    const QQmlPrivate::AOTCompiledFunction *aotCompiledFunctions = nullptr;
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    // Owned by this actual compiled unit. No URL/global/raw-pointer cache.
    QVariantMap overteE2eSourceReceipt;
    quint64 overteE2eSourceGeneration = 0;
    void overteE2eInvalidateSourceReceipt()
    {
        overteE2eSourceReceipt.clear();
        if (overteE2eSourceGeneration < 1000000000)
            ++overteE2eSourceGeneration;
    }
#endif
''')
replace(compiled, '        data = unitData;\n', '''#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
        overteE2eInvalidateSourceReceipt();
#endif
        data = unitData;
''')

compiled_cpp = 'src/qml/common/qv4compileddata.cpp'
replace(compiled_cpp, 'CompilationUnit::~CompilationUnit()\n{\n', '''CompilationUnit::~CompilationUnit()
{
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    overteE2eInvalidateSourceReceipt();
#endif
''')
replace(compiled_cpp, '        const QUrl &url, const QDateTime &sourceTimeStamp, QString *errorString)\n{\n', '''        const QUrl &url, const QDateTime &sourceTimeStamp, QString *errorString)
{
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    // Invalidate before every cache attempt, even failure or equal-byte reload.
    overteE2eInvalidateSourceReceipt();
#endif
''')

executable = 'src/qml/jsruntime/qv4executablecompilationunit_p.h'
replace(executable, '    const CompiledData::Unit *unitData() const { return m_compilationUnit->data; }\n', '''    const CompiledData::Unit *unitData() const { return m_compilationUnit->data; }
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    QVariantMap overteE2eSourceReceipt() const
    {
        const auto &owner = *m_compilationUnit;
        if (owner.aotCompiledFunctions || owner.overteE2eSourceGeneration >= 1000000000
                || owner.overteE2eSourceReceipt.value(QStringLiteral("unitGeneration")).toULongLong()
                        != owner.overteE2eSourceGeneration)
            return {};
        return owner.overteE2eSourceReceipt;
    }
#endif
''')

typed = 'src/qml/qml/qqmltypedata_p.h'
replace(typed, 'Q_DECLARE_LOGGING_CATEGORY(lcCycle)\n', '''Q_DECLARE_LOGGING_CATEGORY(lcCycle)
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
class QQmlComponent;
#endif
''')
replace(typed, '    QV4::CompiledData::CompilationUnit *compilationUnit() const;\n', '''    QV4::CompiledData::CompilationUnit *compilationUnit() const;
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    static Q_QML_EXPORT int overteE2eSourceObservationApiVersion();
    static Q_QML_EXPORT void setOverteE2eSourceObservationEnabled(bool enabled);
    static Q_QML_EXPORT QVariantMap overteE2eSourceReceiptForObject(
            const QObject *object, const QQmlComponent *component = nullptr);
#endif
''')
replace(typed, '    SourceCodeData m_backupSourceCode; // used when cache verification fails.\n', '''    SourceCodeData m_backupSourceCode; // used when cache verification fails.
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    QVariantMap m_overteE2eSourceInput;
    const QV4::CompiledData::CompilationUnit *m_overteE2eDirectOwner = nullptr;
    const QV4::CompiledData::Unit *m_overteE2eDirectUnit = nullptr;
    quint64 m_overteE2eDirectGeneration = 0;
#endif
''')

cpp = 'src/qml/qml/qqmltypedata.cpp'
replace(cpp, '#include <memory>\n', '''#include <memory>
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
#include <private/qqmlcomponent_p.h>
#include <private/qqmldata_p.h>
#include <QtCore/qcoreapplication.h>
#include <QtCore/qdatetime.h>
#include <QtCore/qthread.h>
#include <QtCore/quuid.h>
#include <atomic>
#endif
''')
replace(cpp, 'Q_LOGGING_CATEGORY(lcCycle, "qt.qml.typeresolution.cycle", QtWarningMsg)\n', '''Q_LOGGING_CATEGORY(lcCycle, "qt.qml.typeresolution.cycle", QtWarningMsg)

#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
namespace {
std::atomic<bool> overteE2eSourceEnabled { false };
std::atomic<quint64> overteE2eSourceSequence { 0 };

QVariantMap overteE2eCompilerInput(const QString &source, const QString &requested,
                                 const QString &resolved)
{
    QT_TRY {
    if (!overteE2eSourceEnabled.load(std::memory_order_acquire)
            || source.isEmpty() || source.size() > 1024 * 1024)
        return {};
    static const QString instance = QUuid::createUuid().toString(QUuid::WithoutBraces)
            .remove(QLatin1Char('-'));
    const auto before = QDateTime::currentMSecsSinceEpoch();
    QCryptographicHash hash(QCryptographicHash::Sha256);
    // Exact decoded QString code units, not a guessed QFile encoding.
    for (const QChar character : source) {
        const auto unit = character.unicode();
        const char bytes[2] { char(unit & 255), char(unit >> 8) };
        hash.addData(QByteArrayView(bytes, 2));
    }
    const auto sequence = overteE2eSourceSequence.fetch_add(1) + 1;
    if (sequence == 0 || sequence > 1000000000) {
        overteE2eSourceEnabled.store(false, std::memory_order_release);
        return {};
    }
    return {{QStringLiteral("qtOverteQmlCompilerInputVersion"), 1},
            {QStringLiteral("instance"), instance},
            {QStringLiteral("sequence"), qulonglong(sequence)},
            {QStringLiteral("processId"), QCoreApplication::applicationPid()},
            {QStringLiteral("qtVersion"), QString::fromLatin1(qVersion())},
            {QStringLiteral("encoding"), QStringLiteral("utf16-le-code-units")},
            {QStringLiteral("codeUnits"), qlonglong(source.size())},
            {QStringLiteral("sha256"), QString::fromLatin1(hash.result().toHex())},
            {QStringLiteral("requestedUrl"), requested},
            {QStringLiteral("resolvedUrl"), resolved},
            {QStringLiteral("sourceBeforeEpochMs"), before}};
    } QT_CATCH (...) {
        // Observation failure never changes the actual compiler input/result.
        return {};
    }
}
}

int QQmlTypeData::overteE2eSourceObservationApiVersion()
{
    return 1;
}

void QQmlTypeData::setOverteE2eSourceObservationEnabled(bool enabled)
{
    overteE2eSourceEnabled.store(false, std::memory_order_release);
    QT_TRY {
    const bool admitted = enabled && QCoreApplication::instance()
            && QCoreApplication::arguments().contains(QStringLiteral("--testScript"));
    overteE2eSourceEnabled.store(admitted, std::memory_order_release);
    } QT_CATCH (...) {
        // Remain disabled without changing ordinary application loading.
    }
}

QVariantMap QQmlTypeData::overteE2eSourceReceiptForObject(
        const QObject *object, const QQmlComponent *component)
{
    QT_TRY {
        if (!overteE2eSourceEnabled.load(std::memory_order_acquire)
                || !QCoreApplication::instance() || !object
                || object->thread() != QThread::currentThread())
            return {};
        const auto *data = QQmlData::get(object);
        if (!data || !data->compilationUnit)
            return {};
        const auto actual = data->compilationUnit;
        if (component) {
            if (component->thread() != QThread::currentThread()
                    || !component->isReady() || component->isError())
                return {};
            const auto owner = QQmlComponentPrivate::get(
                    const_cast<QQmlComponent *>(component))->compilationUnit();
            if (owner.data() != actual.data())
                return {};
        }
        const auto receipt = actual->overteE2eSourceReceipt();
        const auto *unit = actual->unitData();
        if (receipt.isEmpty() || !unit || unit->unitSize < sizeof(QV4::CompiledData::Unit)
                || unit->unitSize > 4 * 1024 * 1024
                || (unit->flags & QV4::CompiledData::Unit::PendingTypeCompilation)
                || receipt.value(QStringLiteral("unitBytes")).toLongLong() != qint64(unit->unitSize)
                || receipt.value(QStringLiteral("processId")).toLongLong() != QCoreApplication::applicationPid())
            return {};
        const auto bytes = QByteArray::fromRawData(reinterpret_cast<const char *>(unit),
                                                  qsizetype(unit->unitSize));
        const auto digest = QString::fromLatin1(QCryptographicHash::hash(
                bytes, QCryptographicHash::Sha256).toHex());
        if (receipt.value(QStringLiteral("unitSha256")).toString() != digest)
            return {};
        return receipt;
    } QT_CATCH (...) {
        return {};
    }
}
#endif
''')
replace(cpp, '    auto cleanup = qScopeGuard([this]{\n        m_backupSourceCode = SourceCodeData();', '''    auto cleanup = qScopeGuard([this]{
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
        QT_TRY {
        // Publish only the successful actual source -> completed unit join.
        // Disk/AOT cache construction does not invent an input receipt.
        if (!isError() && m_compiledData && !m_overteE2eSourceInput.isEmpty()
                && m_overteE2eSourceInput.contains(QStringLiteral("sourceAfterEpochMs"))
                && m_overteE2eSourceInput.contains(QStringLiteral("compilerUnitSha256"))
                && m_compiledData.data() == m_overteE2eDirectOwner
                && m_compiledData->data == m_overteE2eDirectUnit
                && m_compiledData->overteE2eSourceGeneration == m_overteE2eDirectGeneration
                && m_overteE2eDirectGeneration < 1000000000) {
            const auto *unit = m_compiledData->data;
            if (unit && unit->unitSize >= sizeof(QV4::CompiledData::Unit)
                    && unit->unitSize <= 4 * 1024 * 1024
                    && !m_compiledData->aotCompiledFunctions) {
                auto receipt = m_overteE2eSourceInput;
                const auto bytes = QByteArray::fromRawData(reinterpret_cast<const char *>(unit),
                                                          qsizetype(unit->unitSize));
                const auto digest = QString::fromLatin1(QCryptographicHash::hash(
                        bytes, QCryptographicHash::Sha256).toHex());
                if (receipt.value(QStringLiteral("compilerUnitBytes")).toLongLong() == qint64(unit->unitSize)
                        && receipt.value(QStringLiteral("compilerUnitSha256")).toString() == digest) {
                    receipt.insert(QStringLiteral("unitBytes"), qlonglong(unit->unitSize));
                    receipt.insert(QStringLiteral("unitGeneration"), qulonglong(m_overteE2eDirectGeneration));
                    receipt.insert(QStringLiteral("unitSha256"), digest);
                    const auto completed = QDateTime::currentMSecsSinceEpoch();
                    const auto before = receipt.value(QStringLiteral("sourceBeforeEpochMs")).toLongLong();
                    const auto after = receipt.value(QStringLiteral("sourceAfterEpochMs")).toLongLong();
                    if (before > 0 && before <= after && after <= completed) {
                        receipt.insert(QStringLiteral("compiledEpochMs"), completed);
                        m_compiledData->overteE2eSourceReceipt = std::move(receipt);
                    }
                }
            }
        }
        } QT_CATCH (...) {
            // The ordinary Qt cleanup and error/result path still run.
        }
        m_overteE2eSourceInput.clear();
        m_overteE2eDirectOwner = nullptr;
        m_overteE2eDirectUnit = nullptr;
#endif
        m_backupSourceCode = SourceCodeData();''')
replace(cpp, '    m_backupSourceCode = data;\n', '''#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    m_overteE2eSourceInput.clear();
    m_overteE2eDirectOwner = nullptr;
    m_overteE2eDirectUnit = nullptr;
#endif
    m_backupSourceCode = data;
''')
replace(cpp, '    const bool trySaveToDisk = m_typeLoader->writeCacheFile() && !typeRecompilation;', '''#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    QT_TRY {
        // Bind the compiler's direct output before Qt's existing cache reload.
        // A later different cache body cannot inherit this source association.
        const auto *unit = compilationUnit->data;
        if (!m_overteE2eSourceInput.isEmpty() && unit
                && unit->unitSize >= sizeof(QV4::CompiledData::Unit)
                && unit->unitSize <= 4 * 1024 * 1024
                && !compilationUnit->aotCompiledFunctions) {
            const auto bytes = QByteArray::fromRawData(reinterpret_cast<const char *>(unit),
                                                      qsizetype(unit->unitSize));
            m_overteE2eSourceInput.insert(QStringLiteral("compilerUnitBytes"), qlonglong(unit->unitSize));
            m_overteE2eSourceInput.insert(QStringLiteral("compilerUnitSha256"), QString::fromLatin1(
                    QCryptographicHash::hash(bytes, QCryptographicHash::Sha256).toHex()));
            m_overteE2eDirectOwner = compilationUnit.data();
            m_overteE2eDirectUnit = unit;
            m_overteE2eDirectGeneration = compilationUnit->overteE2eSourceGeneration;
        }
    } QT_CATCH (...) {
        m_overteE2eSourceInput.clear();
        m_overteE2eDirectOwner = nullptr;
        m_overteE2eDirectUnit = nullptr;
    }
#endif
    const bool trySaveToDisk = m_typeLoader->writeCacheFile() && !typeRecompilation;''')
replace(cpp, '        if (compilationUnit->saveToDisk(url(), &errorString)) {\n            QString error;', '''        if (compilationUnit->saveToDisk(url(), &errorString)) {
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
            // A cache read can replace even a byte-equivalent direct unit.
            // It needs its own actual generation/handle provenance bridge.
            m_overteE2eSourceInput.clear();
            m_overteE2eDirectOwner = nullptr;
            m_overteE2eDirectUnit = nullptr;
#endif
            QString error;''')
replace(cpp, 'void QQmlTypeData::initializeFromCachedUnit(const QQmlPrivate::CachedQmlUnit *unit)\n{\n    assertTypeLoaderThread();', '''void QQmlTypeData::initializeFromCachedUnit(const QQmlPrivate::CachedQmlUnit *unit)
{
    assertTypeLoaderThread();
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    m_overteE2eSourceInput.clear();
    m_overteE2eDirectOwner = nullptr;
    m_overteE2eDirectUnit = nullptr;
#endif''')
replace(cpp, '    if (!compiler.generateFromQml(source, finalUrlString(), m_document.data())) {', '''#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    m_overteE2eDirectOwner = nullptr;
    m_overteE2eDirectUnit = nullptr;
    m_overteE2eSourceInput = overteE2eCompilerInput(source, urlString(), finalUrlString());
#endif
    if (!compiler.generateFromQml(source, finalUrlString(), m_document.data())) {''')
replace(cpp, '        setError(errors);\n        return false;\n    }\n    return true;\n}\n\nvoid QQmlTypeData::restoreIR', '''        setError(errors);
        return false;
    }
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    QT_TRY {
        if (!m_overteE2eSourceInput.isEmpty())
            m_overteE2eSourceInput.insert(QStringLiteral("sourceAfterEpochMs"),
                                        QDateTime::currentMSecsSinceEpoch());
    } QT_CATCH (...) {
        m_overteE2eSourceInput.clear();
        m_overteE2eDirectOwner = nullptr;
        m_overteE2eDirectUnit = nullptr;
    }
#endif
    return true;
}

void QQmlTypeData::restoreIR''')

patch = ''.join(''.join(difflib.unified_diff(originals[name].splitlines(keepends=True),
    updated[name].splitlines(keepends=True), fromfile='a/qtdeclarative/' + name,
    tofile='b/qtdeclarative/' + name)) for name in files)
patch = ''.join('\n' if line == ' \n' else line for line in patch.splitlines(keepends=True))
target = repo / 'ios/patches/qtdeclarative-overte-e2e-qml-source-receipts.patch'
target.write_text(patch)
manifest = dict(qtVersion='6.11.1', apiVersion=1, patch=target.name,
    sourceSha256={'qtdeclarative/' + name: value for name, value in files.items()},
    referenceSha256={
        'qtdeclarative/src/qml/qml/qqmlcomponent_p.h': '93cfa3ae0fb9fbea9b1afb39f85f8992892b0660a012babdfc8b5501917d79d4',
        'qtdeclarative/src/qml/qml/qqmldata_p.h': '4945ed8c20b6635e869c45b29089f605de4238fc46ed2cb20e40c7262ec5022e',
        'qtdeclarative/src/qml/qml/qqmldatablob.cpp': '9e4fd53d9d8a82d9e1b8a32b9b39b4cf33d51135f9176e191a144e156e78bbe3',
    })
(repo / 'tests/device/ios/qt-qml-source-patch.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Generated an unapplied source-only patch for five exact Qt reference files.')
