"""Future explicit Foreign1 metadata assembly only; no global/raw scan."""
from pathlib import Path
import hashlib,json,stat,sys
REPO=Path.cwd().resolve(strict=True);SOURCE=Path(__file__).resolve().parent
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode

def pin(path):
    path=Path(path);a=path.lstat();assert path.resolve(strict=True)==path and stat.S_ISREG(a.st_mode)
    raw=path.read_bytes();b=path.lstat();fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    row=dict(stat=[getattr(a,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest());assert row['stat']==[getattr(b,key)for key in fields];return row

def check_packet(path,sha):
    assert pin(path)['sha256']==sha;return json.loads(path.read_text())

def main():
    assert len(sys.argv)==3,'new private controller path plus independent source-freeze SHA required'
    dest=Path(sys.argv[1]);assert dest.is_absolute()and dest.resolve().is_relative_to(REPO)and not dest.exists()
    own=check_packet(SOURCE/'source-freeze.json',sys.argv[2])
    for name,row in own['files'].items():assert pin(SOURCE/name)['sha256']==row['sha256']
    base=REPO/'.ios-host-tmp/lifecycle-publisher-refusal-controller5-source4-utility-roots-final-preparation-20261103'
    frozen=check_packet(base/'freeze.json','a58a0d916c40163e9d9ee126a04807da7658a230d8809c64991d89cb8845b570')
    # Exact source-origin metadata only. No global corpus/history row is opened.
    for name in('module-origins.json','immutable-source-pins.json'):
        expected=frozen['files'][name];expected=expected['sha256']if type(expected)is dict else expected
        assert pin(base/name)['sha256']==expected
    origins=json.loads((base/'module-origins.json').read_text());old=json.loads((base/'immutable-source-pins.json').read_text())
    modules={name:dict(path=path)for name,path in origins['modules'].items()}
    for row in modules.values():assert pin(row['path'])==old[row['path']]
    sparse=REPO/'.ios-host-tmp/lifecycle-post-acquisition-sparse-host-phases-source2-private-20261103'
    split=REPO/'.ios-host-tmp/lifecycle-sparse-eight-separated-counter-source-preparation-20261103'
    sparse_frozen=check_packet(sparse/'freeze.json','7fc244b8e9f73dd6536c6f25400521ed5cd48eb8d40588cf64782eb2025b9db5')
    split_frozen=check_packet(split/'source-freeze.json','46bfc9e3969aa4350f1d1ba47952a867ff8ae1f287c495c4857a2746832ecf16')
    for module,relative in(('ios.adapters.lifecycle_observer','ios/adapters/lifecycle_observer.py'),
        ('ios.adapters.lifecycle_publication_read_phase','ios/adapters/lifecycle_publication_read_phase.py'),
        ('adapters.phase_witness_publisher','adapters/phase_witness_publisher.py'),
        ('adapters.lifecycle_sparse_host_diagnostic','adapters/lifecycle_sparse_host_diagnostic.py')):
        candidate=sparse/'candidate/tests/device'/relative
        expected=sparse_frozen['files']['candidate/tests/device/'+relative]
        expected=expected['sha256']if type(expected)is dict else expected
        assert pin(candidate)['sha256']==expected
        modules[module]=dict(path=str(candidate))
    assert pin(split/'test_lifecycle_sparse_foreign_one.py')['sha256']==split_frozen['files']['test_lifecycle_sparse_foreign_one.py']['sha256']
    modules['test_lifecycle_sparse_foreign_one']=dict(path=str(split/'test_lifecycle_sparse_foreign_one.py'))
    helper=REPO/'.ios-host-tmp/audio-own14-canonical-fd-supervisor4-source-private-20261103/owned_write_boundary.py'
    assert pin(helper)['sha256']=='156560033c0c292aa72be6cd66af136683de28490341dceacc191398b5167bda'
    modules['foreign_counter_owned_writes']=dict(path=str(helper))
    paths={Path(row['path'])for row in modules.values()}|{Path(sys.executable).resolve(strict=True),base/'freeze.json',base/'module-origins.json',base/'immutable-source-pins.json',sparse/'freeze.json',split/'source-freeze.json',SOURCE/'source-freeze.json'}
    for name in own['files']:paths.add(SOURCE/name)
    paths.update(Path('/usr/lib64/python3.14')/name for name in('socket.py','asyncio/selector_events.py','asyncio/runners.py','unittest/async_case.py','unittest/case.py'))
    before={str(path):pin(path)for path in paths}
    assert dest.resolve().is_relative_to(REPO);dest.mkdir(mode=0o700)
    for name in('run-foreign1.py','supervise-foreign1.py'):
        target=dest/name;assert target.resolve().is_relative_to(REPO)and not target.exists();target.write_bytes((SOURCE/name).read_bytes());before[str(target)]=pin(target)
    body=dict(status='UNRUN_REQUIRES_ROOT_REVIEW',repositoryRoot=str(REPO),controllerRoot=str(dest),modules=modules,namespaces=origins['namespaces'],
        sourceAndBinaryPins=before,case='test_lifecycle_sparse_foreign_one.LifecycleSparseForeignRecorderTests.test_unbound_foreign_recorder_cannot_become_an_original_owner_or_write_a_result',
        wallSeconds=30,killGraceSeconds=5,bindingsWriteAllowed=False,expectedTemporaryDirectories=0,CurrentSourceBirths=0,SDKExecutions=0,NodeExecutions=0,
        preloads=['ios.adapters.lifecycle_observer','ios.adapters.lifecycle_publication_read_phase','adapters.phase_witness_publisher','adapters.phase_publication_refusal_original'])
    target=dest/'approved-inputs.json';assert target.resolve().is_relative_to(REPO);target.write_text(json.dumps(body,sort_keys=True,indent=2)+'\n')
    assert before=={path:pin(path)for path in before}
    print(json.dumps(dict(controllerRoot=str(dest),approvedInputsSha256=pin(target)['sha256'],targets=0,globalScans=0)))
if __name__=='__main__':main()
