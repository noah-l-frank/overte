"""Prospective original-only temporal PNG join; no device/native build."""
import unittest
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters import feature_observation
from ios.adapters.snapshot_actor_temporal_png_join import retained_temporal_pixel_join
from ios.self_tests.snapshot_actor_temporal_png_domain import TemporalActorPNGDomain
from ios.self_tests.test_ios_snapshot_actor_primary_png_join import counts,originals


class SnapshotActorTemporalPNGJoinTests(unittest.TestCase):
    def test_genuine_canonical_png_before_primary_native_cut_after_and_readonly_reopen(self):
        d=TemporalActorPNGDomain(self)
        with d.completed()as args:
            join=retained_temporal_pixel_join(*args);before=counts(d);saved=originals(d);value=join.proof()
            self.assertTrue(value['actorBeforePrimaryCaptureActorAfterOriginalOrderEstablished'])
            self.assertTrue(value['bothCanonicalPNGOriginalsAndExactCropsEstablished'])
            self.assertFalse(value['newCaptureOrQueryOrPOST']or value['nativeQualified']or value['wholeQualified'])
            self.assertFalse(value['legacyCanonicalScenePublicationClaimed'])
            self.assertEqual(value['actorBeforeComparison']['hashes']['primaryRGBA'],value['actorAfterComparison']['hashes']['actorCropRGBA'])
            self.assertEqual(1,d.primary.capture.capture_count);self.assertEqual(2,len(d.pixel_queries));self.assertEqual(2,len(d.posts))
            self.assertEqual(1,len(d.pixel_render_events));self.assertEqual(0,d.primary.screen_calls)
            def forbidden(*_a,**_k):raise AssertionError('Original-only temporal join attempted live IO or a write')
            with patch.object(PrivateFeatureState,'write',side_effect=forbidden),patch.object(feature_observation,'post_request',forbidden),                    patch.object(type(d.actor_client),'request',forbidden),patch.object(d.actor.ctx.native,'send',forbidden),                    patch.object(d.primary.ctx.native,'send',forbidden):
                self.assertEqual(value,retained_temporal_pixel_join(*args).proof())
            self.assertEqual(before,counts(d));self.assertEqual(saved,originals(d))

    def test_complete_old_after_png_cannot_be_promoted_to_temporal_after(self):
        d=TemporalActorPNGDomain(self,emit_after=False)
        with d.completed()as args:
            join=retained_temporal_pixel_join(*args);before=counts(d);saved=originals(d)
            with self.assertRaises(NativeUIError):join.proof()
            self.assertEqual(before,counts(d));self.assertEqual(saved,originals(d));self.assertEqual([],d.pixel_render_events)

    def test_reversed_genuine_actor_indices_refuse_without_extra_original_acquisition(self):
        d=TemporalActorPNGDomain(self)
        with d.completed()as args:
            before=counts(d);saved=originals(d)
            with self.assertRaises(NativeUIError):retained_temporal_pixel_join(*args[:4],2,1)
            self.assertEqual(before,counts(d));self.assertEqual(saved,originals(d))

    def test_foreign_genuine_actor_phase_and_root_cannot_supply_the_primary_bracket(self):
        d=TemporalActorPNGDomain(self)
        with d.completed()as own:
            other=TemporalActorPNGDomain(self)
            with other.completed()as foreign:
                before=(counts(d),counts(other));saved=(originals(d),originals(other))
                join=retained_temporal_pixel_join(*own[:3],foreign[3],1,2)
                with self.assertRaises(NativeUIError):join.proof()
                self.assertEqual(before,(counts(d),counts(other)));self.assertEqual(saved,(originals(d),originals(other)))

    def test_missing_actor_after_png_original_is_not_reconstructed_or_queried(self):
        d=TemporalActorPNGDomain(self)
        with d.completed(after=False)as args:
            before=counts(d);saved=originals(d)
            with self.assertRaises(NativeUIError):retained_temporal_pixel_join(*args)
            self.assertEqual(before,counts(d));self.assertEqual(saved,originals(d));self.assertEqual(1,len(d.pixel_queries))
