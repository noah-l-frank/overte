"""Genuine shared Journey/codec counters over declared raw protocol inputs.

No Native/SDK/End owner or native effect producer is fabricated. Fixed wire
fixtures exercise profile/request binding only; they are NOT retirement proof.
All callbacks other than the declared wire invoke are forbidden. All UNRUN.
"""
from copy import deepcopy
import unittest
from feature_journeys import terminal
from feature_journeys.engine import Journey
from feature_journeys.scenarios import VERSION
from feature_journeys.witness import projection
from self_tests.test_feature_terminal import FeatureTerminalTests

RUN='01'*16
TICKET='02'*16

class TerminalWireInputs:
    """Predeclared codec input, not a native/server/SDK observation provider."""
    def __init__(self):
        self.calls=[];self.fail=False;self.response=None
        primary=dict(sourceRevision='a'*40,artifactSha256='b'*64,targetFingerprint='c'*64,sessionSha256='d'*64,generation=2,processIdentity='31')
        actor=dict(primary,targetFingerprint='e'*64,sessionSha256='f'*64,processIdentity='32')
        self.description=dict(featureTerminalVersion=1,profile=terminal.ORIGINAL_KEEPER_PROFILE,area='audio',runId=RUN,ticket=TICKET,roles={
            'primary':dict(binding=primary,originalSha256='1'*64,heldResources=[dict(resource='panel:audio-primary-ui',kind='native-holder',originalSha256='2'*64)]),
            'actor':dict(binding=actor,originalSha256='3'*64,heldResources=[dict(resource='panel:audio-cache-pcm',kind='audio-cache-pcm',originalSha256='4'*64),dict(resource='panel:audio-control-sender',kind='audio-control-sender',originalSha256='5'*64)])})
        # Finite raw contract inputs are chosen before the genuine Journey.
        # They claim no physical acquisition/source, no desired-value effect.
        state=dict(recording=False,preview=False,muted=False,recordedFrames=0,playedFrames=0,bufferedFrames=0,phase='idle',history=[],error='none',open=False)
        self.samples=[]
        for index in range(1,5):
            epoch=1700000000000+(index-1)*1000
            primary_row=dict(schemaVersion=1,contractVersion=VERSION,runId=RUN,sequence=index,capturedEpochMs=epoch,state=deepcopy(state),artifacts=[],resources=['panel:audio-primary-ui'],lifecycle=dict(backgrounds=0,activations=1,launches=1))
            actor_row=dict(ticket=TICKET,actor='owned-observer',actorSequence=index,capturedEpochMs=epoch,facts=projection('audio',state),sequence=index,receivedEpochMs=epoch)
            self.samples.append(dict(primary=primary_row,actor=actor_row))
        self.seal=dict(featureTerminalSealVersion=1,description=deepcopy(self.description),windowSha256=terminal.digest(self.samples),liveOriginalSha256='6'*64)
    def forbidden(self,*_args,**_kwargs):raise AssertionError('Wire binding called an observation/clock/retirement port')
    def invoke(self,operation,fields):
        self.calls.append((operation,deepcopy(fields)))
        if self.fail:raise OSError('Declared terminal wire return is unknown')
        return deepcopy(self.response)
    def journey(self,capabilities):
        return Journey('audio',RUN,'https://controlled.invalid/feature-fixture/v1/runs/'+RUN+'/',invoke=self.invoke,
            witness=self.forbidden,activate=self.forbidden,read_artifact=self.forbidden,image_policy={},continuity=self.forbidden,
            monotonic=self.forbidden,epoch_ms=self.forbidden,sleep=self.forbidden,report=self.forbidden,
            terminal_profile=terminal.profile_for_area('audio',capabilities),retire_fixture=self.forbidden)

class AudioOriginalKeeperTerminalProfileTests(unittest.TestCase):
    def test_unadvertised_audio_cannot_deliver_terminal_and_advertised_original_profile_keeps_duties(self):
        wire=TerminalWireInputs();wire.response=dict(stage='inspect',description=deepcopy(wire.description))
        with self.assertRaises(ValueError):wire.journey(set()).terminal_call('inspect')
        self.assertEqual([],wire.calls)
        journey=wire.journey({'feature.audio.terminal'});before=deepcopy(wire.response)
        self.assertEqual(before,journey.terminal_call('inspect'));self.assertEqual(before,wire.response)
        self.assertEqual(1,len(wire.calls));self.assertIsNone(journey.terminal_end)
        self.assertIsNone(terminal.profile_for_area('audio',{'feature.audio.observe'}))

    def test_other_valid_terminal_profile_is_refused_without_relabeling_the_wire(self):
        wire=TerminalWireInputs();wrong=deepcopy(wire.description);wrong['profile']=terminal.PROFILE
        wrong['roles']['actor']['heldResources']=[dict(resource='panel:actor-root',kind='native-holder',originalSha256='7'*64)]
        terminal.description(wrong,area='audio',run=RUN) # Valid OTHER profile, not a preceding grammar fault.
        wire.response=dict(stage='inspect',description=wrong);before=deepcopy(wire.response)
        with self.assertRaises(ValueError):wire.journey({'feature.audio.terminal'}).terminal_call('inspect')
        self.assertEqual(before,wire.response);self.assertEqual(1,len(wire.calls))

    def test_foreign_binding_in_an_otherwise_valid_seal_cannot_replace_inspected_roles(self):
        wire=TerminalWireInputs();foreign=deepcopy(wire.seal);foreign['description']['roles']['actor']['binding']['generation']+=1
        wire.response=dict(stage='seal',seal=foreign);terminal.result('audio',wire.response)
        journey=wire.journey({'feature.audio.terminal'})
        with self.assertRaises(ValueError):journey.terminal_call('seal',description=wire.description,samples=wire.samples)
        self.assertEqual(['seal'],[row[1]['stage']for row in wire.calls]);self.assertIsNone(journey.terminal_end)

    def test_missing_cache_or_control_duties_cannot_be_laundered_in_valid_seal(self):
        for kind in ('audio-cache-pcm','audio-control-sender'):
            with self.subTest(kind=kind):
                wire=TerminalWireInputs();changed=deepcopy(wire.seal)
                duties=changed['description']['roles']['actor']['heldResources'];duties[:]=[row for row in duties if row['kind']!=kind]
                wire.response=dict(stage='seal',seal=changed);terminal.result('audio',wire.response)
                with self.assertRaises(ValueError):wire.journey({'feature.audio.terminal'}).terminal_call('seal',description=wire.description,samples=wire.samples)
                self.assertEqual(1,len(wire.calls));self.assertEqual(2,len(wire.description['roles']['actor']['heldResources']))

    def test_unknown_terminal_return_preserves_original_error_and_is_not_retried(self):
        wire=TerminalWireInputs();wire.fail=True;journey=wire.journey({'feature.audio.terminal'})
        with self.assertRaisesRegex(OSError,'Declared terminal wire return is unknown'):journey.terminal_call('finish',seal=wire.seal)
        self.assertEqual(1,len(wire.calls));self.assertEqual('finish',wire.calls[0][1]['stage']);self.assertIsNone(journey.terminal_end)

    def test_existing_native_profile_journey_body_retains_original_restoration_and_once_stop(self):
        FeatureTerminalTests.test_live_restoration_precedes_once_stop_and_no_live_observation_follows_process_end(self)
