"""Root-only Source12 six Combined PNG/Photos cases metadata; no subject import or target."""
from pathlib import Path
import argparse,ast,importlib.machinery,json,os,shutil,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
from public_subject_readiness import readiness,packet
from kernel_algorithm_readiness import algorithm as kernel_algorithm
from lifetime_composition_readiness import qualification as lifetime_qualification
SOURCE=Path(__file__).resolve().parent
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript','domain-server/resources')
def load(path):return json.loads(Path(path).read_text())

def project_namespace_admission(declared,ordered_roots):
    """Keep impossible aliases as pinned data; admit only real parent paths.

    Splitting a fullname produced from overte.sikuli/overte.py cannot create
    the nonexistent directories overte/sikuli. No namespace is invented and
    no bare alias or fallback loader is granted for such retained source.
    """
    choices={};failed={}
    for fullname in declared:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in declared:continue
            if name not in choices:
                choices[name]=sorted({str((Path(root)/Path(*parts[:size])).resolve(strict=True))
                    for root in ordered_roots if(Path(root)/Path(*parts[:size])).is_dir()})
            if len(choices[name])!=1:
                failed.setdefault(name,dict(physicalChoices=choices[name],affectedAliases=[]))['affectedAliases'].append(fullname)
    refused={}
    for name,row in failed.items():
        row['affectedAliases']=sorted(set(row['affectedAliases']))
        for fullname in row['affectedAliases']:
            entry=refused.setdefault(fullname,dict(origin=dict(declared[fullname]),unresolvableNamespaces=[]))
            entry['unresolvableNamespaces'].append(name)
    for row in refused.values():row['unresolvableNamespaces'].sort()
    admitted={name:row for name,row in declared.items()if name not in refused}
    namespaces={}
    for fullname in admitted:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            name='.'.join(parts[:size])
            if name in admitted:continue
            assert name not in refused and len(choices[name])==1
            namespaces[name]=choices[name]
    return admitted,namespaces,dict(version=1,declaredAliasCount=len(declared),
        admittedAliasCount=len(admitted),unadmittedAliases=refused,unresolvableNamespaces=failed,
        unadmittedSourcesRetainedAsData=True,unadmittedImportAuthority=False)

def declared_class_preflight(modules):
    """Resolve every sealed class and wrapper against exact declared ASTs before birth."""
    tree=ast.parse((SOURCE/'run-group.py').read_text())
    declarations=[];wrappers=None
    for node in ast.walk(tree):
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            name=node.targets[0].id
            if name=='declarations':declarations.append(ast.literal_eval(node.value))
            elif name=='WRAPPER_METHODS':
                assert wrappers is None
                wrappers=ast.literal_eval(node.value)
    assert len(declarations)==1 and len(declarations[0])==144 and len(wrappers)==48
    trees={};classes={}
    for module_name,class_name,unused in declarations[0]:
        assert (module_name,class_name)not in classes
        if module_name not in trees:
            path=SOURCE/'closed_import_origins.py'if module_name=='closed_import_origins'else Path(modules[module_name]['path'])
            if module_name!='closed_import_origins':assert pin(path)['sha256']==modules[module_name]['sha256']
            trees[module_name]={node.name:node for node in ast.parse(path.read_text()).body if isinstance(node,ast.ClassDef)}
        assert class_name in trees[module_name],(module_name,class_name)
        classes[module_name,class_name]=trees[module_name][class_name]
    for (module_name,class_name,method),profile in wrappers.items():
        assert (module_name,class_name)in classes,(module_name,class_name,method)
        methods={node.name:node for node in classes[module_name,class_name].body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}
        assert method in methods,(module_name,class_name,method)
        assert profile in ('contextmanager','operation'),profile
    return dict(classes=144,wrapperMethods=48,allExactDeclaredClassesAndWrapperDefinitionsPresent=True,subjectImports=0)

def main():
    p=argparse.ArgumentParser();p.add_argument('--source-freeze',required=True);p.add_argument('--expected-head',required=True);p.add_argument('--destination',required=True,type=Path);p.add_argument('--group',required=True);p.add_argument('--root-context',required=True,type=Path);p.add_argument('--root-context-sha',required=True);p.add_argument('--copy-manifest',required=True,type=Path);p.add_argument('--copy-manifest-sha',required=True);p.add_argument('--root-reviewed-source12-resource-composition',action='store_true',required=True);args=p.parse_args()
    assert Path.cwd()==REPO and sys.flags.no_site==1 and sys.dont_write_bytecode
    assert len(args.expected_head)==40 and head()==args.expected_head
    physical={};packet(SOURCE,'source-freeze.json',args.source_freeze,pin,physical)
    packet(REPO/'.ios-host-tmp/snapshot-capture-phase-png-photos-six-bootstrap8-original-budget-refusal-trace-private-20261105','source-freeze.json','09e2bd32633929d7ad7c2ca0f9557ed85b73920b444331b53c64452db377350b',pin,physical)
    packet(REPO/'.ios-host-tmp/snapshot-capture-phase-png-photos-six-bootstrap7-actual-own4-original-lifetime-readiness-code-preparation-20261105','source-freeze.json','ea89540a07967693079d12868aae09ccda8b4205b84b79bf0220ca1a85e57ebe',pin,physical)
    negative=REPO/'.ios-host-tmp/root-snapshot-source13-b7-original-capture-budget-negative-results-20261105'
    packet(negative,'freeze.json','3fec1d5172c43601450915a8a8b41853e04c4f5b9920ba9b895ce68fc5f0588e',pin,physical)
    for name,row in load(negative/'actual-receipt-references.json').items():
        original=Path(row['path']);assert str(original)==name and pin(original)['sha256']==row['sha256'];physical[str(original)]=pin(original)
    recipe=load(SOURCE/'SOURCE-RECIPE.json');assert args.group in recipe['groups'];group=recipe['groups'][args.group]
    assert recipe['source9RootReview']is not None,'Source9 Root semantic review not yet provided; no destination/target admission'
    actual_subjects,subject_pins=readiness(pin,args.copy_manifest,args.copy_manifest_sha);physical.update(subject_pins)
    assert args.expected_head==actual_subjects['expectedParentHead']
    assert recipe['source9RootReview']==actual_subjects['source9RootReview']
    current_readiness,current_pins=qualification(pin);physical.update(current_pins)
    kernel_proof,kernel_pins=kernel_algorithm(REPO,SOURCE,pin,packet);physical.update(kernel_pins)
    lifetime_proof,lifetime_pins=lifetime_qualification(REPO,SOURCE,pin,packet);physical.update(lifetime_pins)
    assert lifetime_proof['actualFourParentLifetimeControlsQualified']is True and lifetime_proof['SnapshotConsumerCompositionQualified']is False
    packet(REPO/'.ios-host-tmp/snapshot-capture-phase-png-photos-six-bootstrap6-owned-natural-exit-observations-code-preparation-20261105','source-freeze.json','e2c604b309759f38658b814347988d069a7cd339dce3f382976d9100762159dc',pin,physical)
    packet(REPO/'.ios-host-tmp/snapshot-capture-phase-png-photos-six-bootstrap5-explicit-system-cp437-bootstrap-code-preparation-20261104','source-freeze.json','8ecad0ecd87a9d96cf2c056e6cffa2f9305a7a2e11c773f96d344a95da5e4567',pin,physical)
    context_path=args.root_context;assert context_path.is_absolute()and context_path.resolve(strict=True)==context_path
    assert context_path.is_relative_to(REPO/'.ios-host-tmp')and pin(context_path)['sha256']==args.root_context_sha
    context=load(context_path);assert context['allTargetsTerminal']is True and context['expectedHead']==args.expected_head
    assert context['status']=='ROOT_REVIEWED_QUIET_CURRENT_SOURCE_AND_ORIGINAL_CONTEXT'
    physical[str(context_path)]=pin(context_path)
    for item in (*context['globalCustody'].values(),*context['additionalPhysicalProofs']):
        path=Path(item['path']);assert pin(path)['sha256']==item['sha256'];physical[str(path)]=pin(path)
    roots=load(context['globalCustody']['seed']['path'])['roots'];baseline=load(context['globalCustody']['baseline']['path'])
    assert set(roots)==set(baseline)and len(roots)==len(set(roots))
    assert set(actual_subjects['requiredOriginalRoots'])|set(current_readiness['requiredOriginalRoots'])|set(kernel_proof['requiredOriginalRoots'])|set(lifetime_proof['requiredOriginalRoots'])<=set(roots)
    # Required private execution ancestors remain SOURCE data, never the active
    # module path or a current public qualification claim.
    for folder,leaf,digest in ((REPO/'.ios-host-tmp/snapshot-scene-canonical-actor-source4-own10-bootstrap2-complete-controller-data-closure-private-20261104','source-freeze.json','a93b7869e4cc67cbfdd7cb18adb4b7bcf0efc286d9a56e255d45410301ee77c6'),(REPO/'.ios-host-tmp/snapshot-scene-first4-bootstrap6-lost-return-render-event-source5-private-20261104','source-freeze.json','3abf57795003f63b0d84dbe6df97c4ac10f2635d4cc80fd80c5ad52a45175d8a')):packet(folder,leaf,digest,pin,physical)
    for root_name in ROOTS:
        root=REPO/root_name;assert root.resolve(strict=True)==root
        for path in root.rglob('*'):
            assert not path.is_symlink()
            if path.is_file():physical[str(path)]=pin(path)
    modules={};ambiguous={};ordered=(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests')
    for root in ordered:
        for path in sorted(root.rglob('*.py')):
            parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
            if package:parts.pop()
            if not parts:continue
            name='.'.join(parts);row=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=package)
            if name in ambiguous:
                if row not in ambiguous[name]:ambiguous[name].append(row)
            elif name in modules and modules[name]!=row:ambiguous[name]=[modules.pop(name),row]
            else:modules[name]=row
    assert set(ambiguous)=={'test_appium_adapter','test_voice_roundtrip'}
    subject_origins=dict(actual_subjects['subjectOrigins'])
    assert len(actual_subjects['privateOverlayOrigins'])==5
    for name,row in actual_subjects['privatePureTestOrigins'].items():
        path=Path(row['path']);assert pin(path)['sha256']==row['sha256']and name not in ambiguous and name not in modules
        modules[name]=dict(path=str(path),sha256=row['sha256'],package=False)
    for name,row in actual_subjects['privateOverlayOrigins'].items():
        path=Path(row['path']);assert path.resolve(strict=True)==path and pin(path)['sha256']==row['sha256']
        assert name not in ambiguous;physical[str(path)]=pin(path)
        modules[name]=dict(path=str(path),sha256=row['sha256'],package=False)
    for name,row in subject_origins.items():
        assert name in modules and modules[name]['path']==row['path']and modules[name]['sha256']==row['sha256']
    declared_preflight=declared_class_preflight(modules)
    third={};external=load(SOURCE/'third-party-source-declarations.json');assert len(external)==31
    for name,row in external.items():
        path=Path(row['path']);value=pin(path);assert value['sha256']==row['sha256'];physical[str(path)]=value
        third[name]=dict(path=str(path),sha256=value['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    std=Path(os.__file__).resolve(strict=True).parent;suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);std_namespaces={}
    for current,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current);dirs[:]=sorted(x for x in dirs if x not in('site-packages','dist-packages','__pycache__')and not(folder/x).is_symlink());relative=folder.relative_to(std)
        if relative.parts and all(x.isidentifier()for x in relative.parts)and not(folder/'__init__.py').is_file():std_namespaces['.'.join(relative.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix=='.py'or str(path).endswith(suffixes):physical[str(path)]=pin(path)
    # One existing interpreter codec is supplied only as real system bytecode.
    # It is explicit HOSTBOOTSTRAP, never a C10d fresh-source or native claim.
    codec=std/'encodings/cp437.pyc';assert codec.resolve(strict=True)==codec and not codec.is_symlink()
    assert not(std/'encodings/cp437.py').exists()
    codec_pin=pin(codec);physical[str(codec)]=codec_pin
    assert codec.read_bytes()[:4]==__import__('importlib.util',fromlist=['MAGIC_NUMBER']).MAGIC_NUMBER
    host_codec=dict(fullname='encodings.cp437',path=str(codec),pin=codec_pin,
        loader='genuine-original-system-SourcelessFileLoader',sourceAvailable=False,
        scope='held-original-host-bootstrap-only',cachedBytecodeConsulted=True,compiledThroughC10d=False)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    assert not any(name.startswith('NODE_')for name in os.environ)
    node=Path(shutil.which('node')).resolve(strict=True);physical[str(node)]=pin(node)
    gd=Path((REPO/'.git').read_text().split('gitdir: ',1)[1].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True);common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(path)]=pin(path)
    refpath=next((root/ref[5:]for root in(gd,common)if(root/ref[5:]).is_file()),common/'packed-refs');physical[str(refpath)]=pin(refpath)
    destination=args.destination
    assert destination.is_absolute()and destination.resolve(strict=False)==destination and destination.parent==REPO/'.ios-host-tmp'and not destination.exists()
    assert destination.name.startswith('snapshot-capture-phase-photos6-')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    destination.mkdir(mode=0o700)
    names=('run-group.py','supervise-group.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','readonly-shared-stdlib-sources.json','source_execution_readiness.py','public_subject_readiness.py','historical_public_readiness.py','SOURCE-RECIPE.json','SUBJECT-DECLARATIONS.json','SUBJECT-METHOD-AND-FREE-FACTORY-INVENTORY.json','snapshot_resource_ports.py','kernel.py','owned_node_observations.py','kernel_algorithm_readiness.py','lifetime_composition_readiness.py','test_owned_node_natural_exit.py')
    for name in names:
        target=destination/name;fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(target)]=pin(target)
    for name in('metadata_reader','host_common','closed_import_origins','owned_write_boundary','source_execution_readiness','public_subject_readiness','historical_public_readiness','snapshot_resource_ports','kernel','owned_node_observations','kernel_algorithm_readiness','lifetime_composition_readiness'):
        path=destination/(name+'.py');assert name not in modules;modules[name]=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=False)
    # Complete physical pins precede the exact C18 real-namespace narrowing.
    modules,namespaces,alias_admission=project_namespace_admission(modules,ordered)
    assert all(modules[name]['path']==row['path']and modules[name]['sha256']==row['sha256']for name,row in subject_origins.items())
    origin=dict(modules=modules,namespacePackages=namespaces,projectAliasAdmission=alias_admission,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=std_namespaces,stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='SOURCE12_CAPTURE_PHASE_PNG_PHOTOS_GROUP_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(destination),actualPublicHead=args.expected_head,projectAliasAdmission=alias_admission,sourceFreeze=args.source_freeze,sourceAndBinaryPins=physical,modules=modules,namespaces=namespaces,thirdPartyModules=third,originPlan=origin,
        subjectOriginModules=subject_origins,subjectOriginCount=len(subject_origins),allSnapshotImplementationDefiningOriginsPublic=False,publicSubjectOriginCount=79,privatePureOriginCount=1,publicCopyManifest=actual_subjects['publicCopyManifest'],privateOverlayOriginsExplicit=actual_subjects['privateOverlayOrigins'],declaredSubjectSourceBytes=actual_subjects,source9RootReview=recipe['source9RootReview'],nativeAdmission=None,canonicalTransportIsModel=True,realAuthenticationOrIndependentProcessQualified=False,actorRenderedPixelsQualified=False,
        cases=group['cases'],group=args.group,caseCount=group['caseCount'],wallSeconds=180,killGraceSeconds=5,expectedTemporaryDirectories=group['expectedTemporaryDirectories'],expectedTemporaryDirectoriesPerCase=group['expectedTemporaryDirectoriesPerCase'],
        subjectActualCopiedPath=str(destination/'closed_import_origins.py'),subjectHelperSha256='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d',NodeExecutions=group['resourceRecipe']['NodeExecutions'],resourceRecipe=group['resourceRecipe'],nodeBinary=dict(path=str(node),pin=physical[str(node)]),SDKExecutions=0,physicalNativeQueries=0,declaredModelNativeObservationsAllowed=True,realNetwork=False,oldCorpusInputs=0,globalOriginalScans=0,
        qualifiedSourceExecution=current_readiness,helperQualificationRequiredOriginalRooms=current_readiness['requiredOriginalRoots'],externalRootGuardMustIncludeAllHelperOriginalRooms=True,externalRootOriginalRoots=roots,externalRootContext=dict(path=str(context_path),sha256=args.root_context_sha),externalRootGlobalWindowRequired=True,
        ambiguousPublicAliasRows=ambiguous,ambiguousPublicAliasesExcluded=sorted(ambiguous),hostBootstrapScope='Original interpreter/stdlib/controller sources are explicitly held bootstrap;explicit public defining origins+5 exact private Source12/temporal overlays+1 explicit private pure-default predecessor definition execute fresh69093. No old body PASS qualifies this new composition. Native/probe remains DATA only.',nativeCompiled=False,nativeQualified=False,wholeQualified=False)
    plan['ownedKernelAlgorithmProof']=kernel_proof
    plan['newParentLifetimeCompositionQualified']=True
    plan['ownedParentLifetimeUtilityProof']=lifetime_proof
    plan['ownedParentLifetimeRequiredOriginalRooms']=lifetime_proof['requiredOriginalRoots']
    plan['snapshotConsumerCompositionQualified']=False
    plan['explicitHostCodecBootstrap']=host_codec
    output=destination/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),inputSha256=pin(output)['sha256'],group=args.group,cases=group['caseCount'],TDs=group['expectedTemporaryDirectories'],sourcePins=len(physical),runtimeOrigins=len(subject_origins),targets=0,censuses=0)))
    return 0
if __name__=='__main__':raise SystemExit(main())
