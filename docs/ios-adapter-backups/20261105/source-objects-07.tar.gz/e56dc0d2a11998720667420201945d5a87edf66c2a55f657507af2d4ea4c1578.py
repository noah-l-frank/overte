"""Private source reconstruction only; no compiler, loader or test execution."""
from pathlib import Path
import difflib,hashlib,json,re
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
refs=json.loads((OUT/'reviewed-reference-originals.json').read_text())
base={name:Path(row['path']).read_text() for name,row in refs.items()}
text=(ROOT/'ios/patches/qtdeclarative-overte-e2e-qml-source-receipts.patch').read_text().splitlines(True)
# Reconstruct the already reviewed v1 textual source; never touch references.
current=None;i=0
while i<len(text):
    line=text[i]
    if line.startswith('+++ b/'):
        current=line[6:].strip();i+=1;continue
    if line.startswith('@@ '):
        old=[];new=[];i+=1
        while i<len(text) and not text[i].startswith(('@@ ','--- a/')):
            row=text[i]
            if row.startswith(' '):old.append(row[1:]);new.append(row[1:])
            elif row.startswith('-'):old.append(row[1:])
            elif row.startswith('+'):new.append(row[1:])
            elif row=='\n':old.append(row);new.append(row)
            else:raise AssertionError('Unexpected reviewed patch syntax')
            i+=1
        before=''.join(old);after=''.join(new)
        assert base[current].count(before)==1,(current,before[:60]);base[current]=base[current].replace(before,after,1)
        continue
    i+=1
candidate=dict(base)
def replace(name,before,after):
    assert candidate[name].count(before)==1,(name,before[:70]);candidate[name]=candidate[name].replace(before,after,1)
common='qtdeclarative/src/qml/common/qv4compileddata_p.h'
cpp='qtdeclarative/src/qml/common/qv4compileddata.cpp'
mapper='qtdeclarative/src/qml/jsruntime/qv4compilationunitmapper_p.h'
mapper_cpp='qtdeclarative/src/qml/jsruntime/qv4compilationunitmapper.cpp'
unix='qtdeclarative/src/qml/jsruntime/qv4compilationunitmapper_unix.cpp'
typecpp='qtdeclarative/src/qml/qml/qqmltypedata.cpp'
helper=(OUT/'qv4overtecacheoriginals_p.h').read_text().replace('#pragma once\n','')
replace(common,'QT_BEGIN_NAMESPACE\n',helper+'\nQT_BEGIN_NAMESPACE\n')
replace(common,'    QVariantMap overteE2eSourceReceipt;\n', '''    QVariantMap overteE2eSourceReceipt;
    // Actual source/output capture, not an expected source selector.
    QVariantMap overteE2ePendingCompilerInput, overteE2eCacheWriteOriginal;
    QString overteE2eOwnerId;
    Q_QML_EXPORT QVariantMap overteE2eCacheOriginalForCurrentUnit() const;
''')
replace(common,'        overteE2eSourceReceipt.clear();\n','''        overteE2eSourceReceipt.clear();
        overteE2ePendingCompilerInput.clear();overteE2eCacheWriteOriginal.clear();
''')
replace(common,'        overteE2eInvalidateSourceReceipt();\n#endif\n        data = unitData;','''        overteE2eInvalidateSourceReceipt();
        QT_TRY {
            if (OverteCacheOriginals::active() && overteE2eOwnerId.isEmpty())
                overteE2eOwnerId=OverteCacheOriginals::nonce();
        } QT_CATCH (...) { OverteCacheOriginals::fail(); }
#endif
        data = unitData;''')

# A dedicated overload carries an actual observer token; old callers keep
# the original signature and behavior through the default optional context.
replace(common,'                                QString *errorString)\n    {\n#if QT_CONFIG(temporaryfile)', '''                                QString *errorString
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
                                , QVariantMap *writeOriginal = nullptr,
                                const QVariantMap &compilerInput = {},
                                const QString &compilerOwner = {},quint64 compilerGeneration = 0
#endif
                                )
    {
#if QT_CONFIG(temporaryfile)''')
replace(common,'''        if (!cacheFile.open(QIODevice::WriteOnly | QIODevice::Truncate)
                || cacheFile.write(data, size) != size
                || !cacheFile.commit()) {
            *errorString = cacheFile.errorString();
            return false;
        }
''','''        if (!cacheFile.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
            *errorString = cacheFile.errorString();return false;
        }
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
        OverteCacheOriginals::Write observed(cacheFile,data,size,compilerInput,compilerOwner,compilerGeneration);
#endif
        const auto actualWritten = cacheFile.write(data,size);
        if (actualWritten != size) { *errorString=cacheFile.errorString();return false; }
        const bool actualCommit=cacheFile.commit();
        if (!actualCommit) { *errorString=cacheFile.errorString();return false; }
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
        QT_TRY {
            if (writeOriginal) *writeOriginal=observed.committed(actualWritten,actualCommit);
        } QT_CATCH (...) { OverteCacheOriginals::fail(); }
#endif
''')
replace(cpp,'QT_BEGIN_NAMESPACE\n','''QT_BEGIN_NAMESPACE
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
namespace QV4::OverteCacheOriginals {
namespace { std::atomic<bool> admitted { false },unavailable { false };std::atomic<quint64> sequence { 0 }; }
bool active() noexcept { return admitted.load() && !unavailable.load(); }
void setEnabled(bool value) noexcept { admitted.store(value); }
void fail() noexcept { unavailable.store(true); }
quint64 next() noexcept {
    const auto value=sequence.fetch_add(1)+1;
    if (value==0 || value>1000000000) { fail();return 0; }
    return value;
}
}
#endif
''')
replace(cpp,'    auto cacheFile = std::make_unique<CompilationUnitMapper>();\n', '''    auto cacheFile = std::make_unique<CompilationUnitMapper>();
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    cacheFile->setOverteE2eExpectedWrite(observedCacheWrite);
#endif
''')
replace(cpp,'''    // Invalidate before every cache attempt, even failure or equal-byte reload.
    overteE2eInvalidateSourceReceipt();''','''    // Preserve only the actual preceding write as a candidate; the mapper
    // must independently bind its opened FD and mapped bytes before adoption.
    const auto observedCacheWrite=overteE2eCacheWriteOriginal;
    overteE2eInvalidateSourceReceipt();''')
replace(cpp,'''    return SaveableUnitPointer(unitData()).saveToDisk<char>(
            [&unitUrl, errorString](const char *data, quint32 size) {''','''#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    // This executes BEFORE SaveableUnitPointer temporarily changes StaticData.
    QVariantMap compilerInput;
    const auto *observedUnit=data;const auto observedGeneration=overteE2eSourceGeneration;
    QT_TRY {
        if (OverteCacheOriginals::active() && data && !aotCompiledFunctions
                && !overteE2ePendingCompilerInput.isEmpty()
                && data->unitSize>0 && data->unitSize<=4*1024*1024
                && OverteCacheOriginals::sha(data,data->unitSize)
                    ==overteE2ePendingCompilerInput.value("compilerUnitSha256").toString()) {
            if (overteE2eOwnerId.isEmpty()) overteE2eOwnerId=OverteCacheOriginals::nonce();
            compilerInput=overteE2ePendingCompilerInput;
        }
        if (data!=observedUnit || overteE2eSourceGeneration!=observedGeneration) compilerInput.clear();
        overteE2eCacheWriteOriginal.clear();
    } QT_CATCH (...) { OverteCacheOriginals::fail(); }
#endif
    return SaveableUnitPointer(unitData()).saveToDisk<char>(
            [this,&unitUrl, errorString
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
             ,compilerInput,observedUnit,observedGeneration
#endif
             ](const char *data, quint32 size) {''')
replace(cpp,'''                            cachePath, data, size, errorString)) {''','''                            cachePath, data, size, errorString
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
                            ,(unitData()==observedUnit && overteE2eSourceGeneration==observedGeneration
                                && data==reinterpret_cast<const char *>(observedUnit)) ? &overteE2eCacheWriteOriginal : nullptr,
                            compilerInput,overteE2eOwnerId,observedGeneration
#endif
                            )) {''')
replace(cpp,'                    CompilationUnitMapper::invalidate(cachePath);\n','''#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
                    if (unitData()!=observedUnit || overteE2eSourceGeneration!=observedGeneration)
                        overteE2eCacheWriteOriginal.clear();
#endif
                    CompilationUnitMapper::invalidate(cachePath);\n''')
replace(cpp,'QStringList CompilationUnit::moduleRequests() const\n', '''#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
QVariantMap CompilationUnit::overteE2eCacheOriginalForCurrentUnit() const
{
    QT_TRY {
        if (!OverteCacheOriginals::active() || !data || !backingFile || aotCompiledFunctions
                || overteE2eOwnerId.isEmpty() || overteE2eSourceGeneration>=1000000000) return {};
        const auto *pointer=data;const auto generation=overteE2eSourceGeneration;
        const auto bytes=pointer->unitSize;const auto before=OverteCacheOriginals::clock();
        const auto actual=backingFile->overteE2eOriginalFor(pointer);
        const auto after=OverteCacheOriginals::clock();
        if (actual.isEmpty() || data!=pointer || overteE2eSourceGeneration!=generation || pointer->unitSize!=bytes) return {};
        return {{"qtOverteQmlCacheUnitVersion",1},{"clockDomain",QStringLiteral("native-qt-steady-clock")},{"processId",QCoreApplication::applicationPid()},
            {"unitOwnerId",overteE2eOwnerId},{"unitReadBefore",before},{"unitReadAfter",after},
            {"unitGeneration",qulonglong(generation)},
            {"unitBytes",qlonglong(bytes)},
            {"unitSha256",actual.value("mappedSha256")},
            {"mappingOriginal",actual}};
    } QT_CATCH (...) { OverteCacheOriginals::fail();return {}; }
}
#endif

QStringList CompilationUnit::moduleRequests() const
''')
replace(mapper,'#include <QFile>\n', '#include <QFile>\n#if defined(Q_OS_IOS)\n#include <QtCore/qvariant.h>\n#endif\n')
replace(mapper,'    static void invalidate(const QString &cacheFilePath);\n','''    static void invalidate(const QString &cacheFilePath);
#if defined(Q_OS_IOS)
    void setOverteE2eExpectedWrite(const QVariantMap &value) { overteExpectedWrite=value; }
    QVariantMap overteE2eOriginalFor(const void *actualUnit) const;
#endif
''')
replace(mapper,'    void *dataPtr = nullptr;\n','''    void *dataPtr = nullptr;
#if defined(Q_OS_IOS)
    // Default mapper copies retain this exact mapping generation and source.
    QVariantMap overteExpectedWrite,overteMappingOriginal;
#endif
''')
replace(mapper_cpp,'void CompilationUnitMapper::invalidate(const QString &cacheFilePath)\n','''#if defined(Q_OS_IOS)
QVariantMap CompilationUnitMapper::overteE2eOriginalFor(const void *actualUnit) const
{
    QT_TRY {
        if (!OverteCacheOriginals::active() || !dataPtr || actualUnit!=dataPtr || overteMappingOriginal.isEmpty()) return {};
        const auto *unit=static_cast<const CompiledData::Unit *>(dataPtr);
        if (unit->unitSize<sizeof(CompiledData::Unit) || unit->unitSize>4*1024*1024
                || unit->unitSize!=overteMappingOriginal.value("mappedBytes").toLongLong()
                || OverteCacheOriginals::sha(dataPtr,unit->unitSize)!=overteMappingOriginal.value("mappedSha256").toString()) return {};
        return overteMappingOriginal;
    } QT_CATCH (...) { OverteCacheOriginals::fail();return {}; }
}
#endif

void CompilationUnitMapper::invalidate(const QString &cacheFilePath)
''')
replace(unix,'    dataPtr = ptr;\n','''    dataPtr = ptr;
#if defined(Q_OS_IOS)
    overteMappingOriginal=OverteCacheOriginals::mapped(fd,ptr,qsizetype(length),overteExpectedWrite);
    overteExpectedWrite.clear();
#endif
''')
replace(unix,'void CompilationUnitMapper::close()\n{\n','''void CompilationUnitMapper::close()
{
#if defined(Q_OS_IOS)
    overteMappingOriginal.clear();
#endif
''')
replace(typecpp,'    overteE2eSourceEnabled.store(false, std::memory_order_release);\n    QT_TRY {','''    overteE2eSourceEnabled.store(false, std::memory_order_release);
    QV4::OverteCacheOriginals::setEnabled(false);
    QT_TRY {''')
replace(typecpp,'    overteE2eSourceEnabled.store(admitted, std::memory_order_release);','''    overteE2eSourceEnabled.store(admitted, std::memory_order_release);
    QV4::OverteCacheOriginals::setEnabled(admitted);''')
replace(typecpp,'            m_overteE2eDirectOwner = compilationUnit.data();','''            compilationUnit->overteE2ePendingCompilerInput=m_overteE2eSourceInput;
            m_overteE2eDirectOwner = compilationUnit.data();''')
diagnostic_keys=set(re.findall(r'"([A-Za-z][A-Za-z0-9]*)"',helper))|{'qtOverteQmlCacheUnitVersion','unitOwnerId','unitReadBefore','unitReadAfter','unitGeneration','unitBytes','unitSha256','mappingOriginal'}
for name in candidate:
    original_lines=set(base[name].splitlines(True));converted=[]
    for line in candidate[name].splitlines(True):
        if line not in original_lines:
            for key in diagnostic_keys:
                line=re.sub(r'(?<!QStringLiteral\()"'+re.escape(key)+r'"','QStringLiteral("'+key+'")',line)
        converted.append(line)
    candidate[name]=''.join(converted)
rows=[];diff='' 
for name in sorted(candidate):
    path=OUT/'source'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(candidate[name])
    if candidate[name]==base[name]:continue
    diff+=''.join(difflib.unified_diff(base[name].splitlines(True),candidate[name].splitlines(True),fromfile='a/'+name,tofile='b/'+name))
    rows.append(dict(path=name,baseReviewedV1Sha256=hashlib.sha256(base[name].encode()).hexdigest(),candidateSha256=hashlib.sha256(candidate[name].encode()).hexdigest(),candidate=str(path.relative_to(ROOT))))
(OUT/'qt-cache-originals-incremental.patch').write_text(diff)
(OUT/'native-candidates.json').write_text(json.dumps(dict(status='Private native source reconstruction only; uncompiled/unapplied to SDK; no patch-verifier/tests run',paths=rows,publicV1PatchUnchanged=True,sourceObservationApiUnchanged=True,cacheGetterNotYetExportedToClient=True),indent=2)+'\n')
print('private native source candidates',len(rows),'incremental patch bytes',len(diff.encode()))
