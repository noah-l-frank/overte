"""All29 connected input host producer with declared SDK/Domain/Qt models.

The production dispatcher and child WALs receive actual original JS normal
inputs, private file bytes/inodes, HTTP settings originals and independently
produced backend/Geometry/HFM rows. Effective permission propagation is an
explicit modeled boundary, and external peer/image/file consumers are absent.
These fixtures cannot qualify whole29 acceptance or hardware execution.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.native_feature_observation import need
from ios.adapters.assets_shared_action_runtime import SharedActionAssetsRuntime
from ios.adapters.assets_page_generation_runtime import PageGenerationAssetsRuntime
from ios.adapters.assets_generation_runtime import GenerationActionAssetsRuntime
from ios.adapters.assets_whole_input import AssetsWholeInput
from ios.adapters.assets_write_client import AssetsWriteClient
from ios.adapters.assets_permission_actions import AssetsPermissionActions
from ios.self_tests.assets_page_generations_fixture import Fixture as OriginalFixture,Boundary as OriginalBoundary
from ios.self_tests.test_ios_assets_write_control import AssetsWriteControlTests
from ios.self_tests.assets_picker_fixture import RUN,URL,BINDING,uid


class Boundary(OriginalBoundary):
    def __init__(self,directory):
        self.permission_settings=None;self.propagate_permissions=True;self.permission_instance=uid();self.permission_sequence=0;super().__init__(directory)
    def extensions(self,ui):
        value=super().extensions(ui);self.permission_sequence+=1
        value.update(assetPermissionsVersion=1,assetPermissions=dict(iosAssetsPermissionSourceVersion=1,
            instance=self.permission_instance,sequence=self.permission_sequence,processId=42,capturedEpochMs=self.clock(),
            available=True,complete=True,binding=dict(apiId=self.usage_ids['apiId'],clientNodeId=self.usage_ids['clientNodeId'],
                domainId=self.reads.binding['domainId']),permissions=deepcopy(self.host_state['usageInfo']['permissions'])))
        return value

    def normal(self):
        if self.permission_settings is not None and self.propagate_permissions:
            # An explicit host model of eventual native permission delivery.
            # The input route never supplies this state; the independent actual
            # HTTP settings server's persisted anonymous row drives the model.
            rows=self.permission_settings.security['standard_permissions']
            allowed=next(row['id_can_write_to_asset_server'] for row in rows if row['permissions_id']=='anonymous')
            self.configure(canWrite=allowed,effectiveWrite=allowed)
        return super().normal()


class Fixture(OriginalFixture):
    boundary_type=Boundary
    def __init__(self,test):
        super().__init__(test);self.write=AssetsWriteControlTests();self.write.setUp();test.addCleanup(self.write.doCleanups)
        self.write.h.binding['domainId']=self.boundary.reads.binding['domainId']
        for row in self.write.h.security['standard_permissions']:
            if row['permissions_id']=='anonymous':row['id_can_write_to_asset_server']=True
        self.write.authority=self.write.make_authority()
        from fixture.assets_write_authority import AssetsWriteControl
        self.write.control=AssetsWriteControl(self.write.authority,self.write.control_store)
        self.write.config['domainId']=self.write.h.binding['domainId'];self.boundary.permission_settings=self.write.h
        fixture=self
        class Adapter:
            def state_path(_self,selector):return fixture.a.h.roots[selector]/'session.json'
            def _candidate_guard(_self):return True
            def _binding(_self,*_args):raise AssertionError('SDK acquisition is an explicit host model')
        client=AssetsWriteClient(PrivateFeatureState(self.a.h.roots['primary']/('ios-assets-write-client-'+RUN+'.json')),
            self.a.h.locks['primary'],BINDING,RUN,self.write.config,lambda:self.selected.selected_guard())
        from ios.self_tests.assets_peer_permission_fixture import PeerPermissionBoundary
        self.peer_permissions=PeerPermissionBoundary(self.boundary.peer,self.boundary,self.selected.context['roles']['actor']['binding'],self.write.h)
        self.driver=AssetsWholeInput(Adapter(),self.selected,self.a.owner,self.episodes,backend_config=self.backend.config,
            permission_client=client,monotonic=self.boundary.monotonic,epoch_ms=lambda:self.boundary.clock()+5000)
        test.addCleanup(self.driver.release_local_leases)
        def sources(instance,selector,lock):
            episode=instance.assets_episode
            expected=self.a.h.locks['primary'] if episode is None else episode.locks['primary']
            need(selector=='primary' and lock is expected);lock.assert_held();instance.assets_action.guard()
            if getattr(instance,'assets_generations',None) is not None:instance.assets_generations.base_guard()
            return fixture.ports(instance.assets_action)
        for cls in (SharedActionAssetsRuntime,PageGenerationAssetsRuntime,GenerationActionAssetsRuntime):
            test.enterContext(patch.object(cls,'_assets_sources',sources))
    def perform_action(self,index):
        self.a.epoch=max(self.a.epoch,self.boundary.clock())+1;ticket,row=self.a.activate(index)
        if index in (4,14,18,24):self.boundary.reads.resource={4:'gltf-bundle/main.gltf',14:'obj-bundle/main.obj',18:'asset-stand.fbx',24:'gltf-bundle/main.gltf'}[index]
        if index in (9,16,22):self.boundary.attach_create()
        self.driver.act(dict(contractVersion=16,runId=RUN,verb=row['verb'],inputs=deepcopy(row['inputs']),ticket=ticket,fixtureUrl=URL))
        self.action=self.driver.last['runtime'].assets_action;self.parts=self.driver.last['parts'];self.scopes=self.driver.scopes
        if index>1:self.scope=self.scopes[-1];self.lock=self.scope.locks['primary']
        return self.parts
    def consume_input(self,index):
        # Test invokes the existing seam directly. This does not pretend that
        # the engine's actual external evidence consumers have run here.
        return self.driver.consumed(dict(contractVersion=1,runId=RUN,stepIndex=index,ticket=self.action.ticket))
    def until(self,index):
        for step in range(len(self.a.owner.state['records'])+1,index+1):self.perform_action(step);self.consume_input(step)
        return self.parts
