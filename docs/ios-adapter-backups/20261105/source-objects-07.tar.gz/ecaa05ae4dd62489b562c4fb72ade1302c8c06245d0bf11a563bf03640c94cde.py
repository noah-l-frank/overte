"""Counter-only real CPython pre-spawn event observer. No child admission.

The actual command/pipe guard may accept its real event, but the counter ALWAYS
raises PreSpawnStop there. This never proves a process was created or exited.
"""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,threading


class PreSpawnStop(RuntimeError):pass


_ACTIVE=None
_INSTALLED=False


def metadata(path):
    path=Path(path);before=path.lstat()
    assert path.resolve(strict=True)==path and not path.is_symlink()and stat.S_ISREG(before.st_mode)
    raw=path.read_bytes();after=path.lstat()
    fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    row=dict(stat=[getattr(before,key)for key in fields],sha256=hashlib.sha256(raw).hexdigest())
    assert row['stat']==[getattr(after,key)for key in fields];return row


def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:
            link=os.readlink(path);info=path.stat()
            result[path.name]=dict(link=link,device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result


def children():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()


def audit(event,args):
    # Classification precedes function-code/frame inspection. No global active
    # exception authorizes an OS child: every actual subprocess event raises.
    if event=='subprocess.Popen':
        current=_ACTIVE
        if current is None:raise RuntimeError('Counter forbids all unbound subprocesses')
        current.before_spawn(args,sys._getframe(1))
        raise PreSpawnStop('Actual accepted audit event stopped before fork/exec')
    if event in('os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen')or event.startswith('os.spawn'):
        raise RuntimeError('Counter never creates OS children or native SDK loads')
    if event.startswith('socket.')and event not in('socket.__new__',):
        current=_ACTIVE
        if current is None or current.loopbacks is None:raise RuntimeError('Unbound socket transport refused')
        if current.before_socket_event is not None:current.before_socket_event(event,args)
        current.loopbacks.audit(event,args,sys._getframe(1))
    if event=='open'and _ACTIVE is not None:
        descriptor,mode,flags=args
        writing=type(mode)is str and any(letter in mode for letter in'wax+')or type(flags)is int and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if writing:
            current=_ACTIVE;frame=sys._getframe(1)
            current.observe_constructor(frame)
            if type(descriptor)is int and current.port.pipe_open(args,frame):return
            current.boundary.audit(event,args)


def install():
    global _INSTALLED
    if not _INSTALLED:sys.addaudithook(audit);_INSTALLED=True


class OriginalPreSpawnObserver:
    def __init__(self,port,boundary,loopbacks=None):
        self.port,self.boundary,self.loopbacks=port,boundary,loopbacks;self.before_socket_event=None
        self.descriptors=[];self.original_streams=[];self.actual_constructor=None
        self.actual_audit_events=[];self.accepted=0;self.thread=threading.get_ident();self.kernel_children_before=children()
        self.original_drain_established=None;self.early_incomplete_observed=False
        self.controller_retirement_established=False;self.retirement_events=[];self.rescue_closed=[]
    def observe_constructor(self,frame):
        assert threading.get_ident()==self.thread
        code=self.port.popen_methods[0][2]
        while frame is not None:
            if frame.f_code is code and frame.f_globals is self.port.popen_methods[0][1].__globals__:
                child=frame.f_locals['self'];assert type(child)is self.port.popen
                if self.actual_constructor is None:self.actual_constructor=child
                assert child is self.actual_constructor
                for name in('p2cread','p2cwrite','c2pread','c2pwrite','errread','errwrite'):
                    descriptor=frame.f_locals.get(name)
                    if type(descriptor)is int and descriptor>=0:
                        info=os.fstat(descriptor);assert stat.S_ISFIFO(info.st_mode)
                        row=dict(role=name,descriptor=descriptor,device=info.st_dev,inode=info.st_ino,mode=info.st_mode,uid=info.st_uid,gid=info.st_gid)
                        if row not in self.descriptors:self.descriptors.append(row)
                for name in('stdin','stdout','stderr'):
                    stream=getattr(child,name,None)
                    if stream is not None and not any(stream is old for old in self.original_streams):self.original_streams.append(stream)
                return
            frame=frame.f_back
    def before_spawn(self,args,frame):
        self.observe_constructor(frame)
        self.actual_audit_events.append(dict(executable=args[0],command=list(args[1]),cwd=args[2],environmentWasNone=args[3]is None))
        self.port.spawn(args,frame);self.accepted+=1
        assert self.actual_constructor is self.port.pending and len(self.descriptors)==6
        assert not getattr(self.actual_constructor,'_child_created',False)
    def original_exception_inventory(self):
        rows=[]
        for original in self.descriptors:
            row=dict(original)
            try:info=os.fstat(row['descriptor'])
            except OSError as error:
                row.update(state='closed-ebadf'if error.errno==9 else'other-fstat-error',errno=error.errno,actual=None)
            else:
                actual=dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,uid=info.st_uid,gid=info.st_gid)
                row.update(state='live-owned'if all(actual[key]==row[key]for key in actual)else'live-reused-foreign',errno=None,actual=actual)
            rows.append(row)
        child=self.actual_constructor
        return dict(rows=rows,actualConstructorPresent=child is not None,
            actualPid=None if child is None else child.pid,
            childCreated=False if child is None else getattr(child,'_child_created',False),
            kernelChildrenBefore=self.kernel_children_before,kernelChildrenAfter=children(),
            streams=[]if child is None else[dict(name=name,present=getattr(child,name,None)is not None,
                closed=None if getattr(child,name,None)is None else getattr(child,name).closed)for name in('stdin','stdout','stderr')])

    def assert_original_exception_drain(self):
        # Positive post-open sentinel MUST retain genuine full stdlib drain.
        value=self.original_exception_inventory()
        assert all(row['state']in('closed-ebadf','live-reused-foreign')for row in value['rows'])
        assert value['actualPid']is None and not value['childCreated']
        assert value['kernelChildrenBefore']==value['kernelChildrenAfter']
        assert all(not row['present']or row['closed']for row in value['streams'])
        self.original_drain_established=True
        return value

    def persist_early_exception_inventory(self,path):
        # Preserve observed six descriptor states BEFORE controller close. The
        # 3-live/3-closed expectation is a separately checked source prediction.
        value=self.original_exception_inventory()
        complete=(len(value['rows'])==6 and value['actualConstructorPresent']and value['actualPid']is None and not value['childCreated']
            and value['kernelChildrenBefore']==value['kernelChildrenAfter']
            and all(row['state']in('closed-ebadf','live-reused-foreign')for row in value['rows'])
            and all(not row['present']or row['closed']for row in value['streams']))
        value.update(originalStdlibDrainEstablished=complete,controllerRetirementEstablished=False)
        self.write_original(path,value)
        assert complete is False
        roles={row['role']:row for row in value['rows']}
        assert set(roles)=={'p2cread','p2cwrite','c2pread','c2pwrite','errread','errwrite'}
        assert all(roles[name]['state']=='closed-ebadf'and roles[name]['errno']==9 for name in('p2cread','c2pwrite','errwrite'))
        assert all(roles[name]['state']=='live-owned'for name in('p2cwrite','c2pread','errread'))
        assert value['actualConstructorPresent']and value['actualPid']is None and not value['childCreated']
        assert value['kernelChildrenBefore']==value['kernelChildrenAfter']
        assert all(not row['present']for row in value['streams'])
        self.original_drain_established=False;self.early_incomplete_observed=True
        return value

    @staticmethod
    def write_original(path,value):
        repo=Path.cwd().resolve(strict=True)
        assert repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file()
        path=Path(path);assert path.resolve().is_relative_to(repo)
        with path.open('x')as stream:
            stream.write(json.dumps(value,sort_keys=True,indent=2)+'\n');stream.flush();os.fsync(stream.fileno())

    def retire_observed_early_parent_fds(self,directory):
        assert self.early_incomplete_observed and self.original_drain_established is False
        directory=Path(directory)
        repo=Path.cwd().resolve(strict=True);assert repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file()
        assert directory.resolve().is_relative_to(repo)and directory.is_dir()
        roles={row['role']:row for row in self.descriptors}
        for name in('p2cwrite','c2pread','errread'):
            original=roles[name];info=os.fstat(original['descriptor'])
            before=dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,uid=info.st_uid,gid=info.st_gid)
            assert stat.S_ISFIFO(info.st_mode)and all(before[key]==original[key]for key in before)
            assert os.readlink('/proc/self/fd/'+str(original['descriptor']))=='pipe:['+str(original['inode'])+']'
            os.close(original['descriptor'])
            try:os.fstat(original['descriptor'])
            except OSError as error:assert error.errno==9;after=dict(state='closed-ebadf',errno=error.errno)
            else:raise AssertionError('Controller-owned descriptor close not established')
            event=dict(sequence=len(self.retirement_events)+1,role=name,descriptor=original['descriptor'],
                actualBefore=before,actualAfter=after,originalStdlibDrainEstablished=False,
                source='explicit-controller-owned-retirement-after-original-incomplete-exception')
            self.retirement_events.append(event)
            self.write_original(directory/('controller-retirement-'+str(event['sequence'])+'.json'),event)
        after=self.original_exception_inventory()
        assert all(row['state']=='closed-ebadf'and row['errno']==9 for row in after['rows'])
        assert after['actualPid']is None and not after['childCreated']and after['kernelChildrenBefore']==after['kernelChildrenAfter']
        self.controller_retirement_established=True
        self.write_original(directory/'controller-retirement-complete.json',dict(originalStdlibDrainEstablished=False,
            controllerRetirementEstablished=True,events=self.retirement_events,actualAfter=after))
        return after

    def rescue_close(self):
        # Any earlier drain assertion remains a test failure; cleanup cannot
        # turn rescue into an original successful constructor cleanup proof.
        for stream in self.original_streams:
            if not stream.closed:stream.close()
        for row in self.descriptors:
            try:info=os.fstat(row['descriptor'])
            except OSError:continue
            if(info.st_dev,info.st_ino)==(row['device'],row['inode']):
                os.close(row['descriptor']);self.rescue_closed.append(dict(descriptor=row['descriptor'],device=row['device'],inode=row['inode']))
    def enter(self):
        global _ACTIVE
        install();assert _ACTIVE is None;_ACTIVE=self
    def leave(self):
        global _ACTIVE
        assert _ACTIVE is self;_ACTIVE=None
