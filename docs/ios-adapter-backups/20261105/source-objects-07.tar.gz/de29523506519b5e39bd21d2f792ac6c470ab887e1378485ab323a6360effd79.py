import ast,hashlib,json,shutil,difflib
from pathlib import Path
R=Path.cwd();D=R/'.ios-host-tmp/emote-callback-live-prefix-nested-metadata-test-only-fix-20261103';P=R/'.ios-host-tmp/emote-callback-live-prefix-json-pixel-result-test-only-fix-20261103';assert not(P/'freeze.json').exists()
shutil.copytree(D/'candidate',P/'base');shutil.copytree(D/'candidate',P/'candidate');rel='tests/device/ios/self_tests/test_ios_emote_callback_live_history_cache.py';f=P/'candidate'/rel;s=f.read_text();assert s.count('return image.tobytes()')==2;s=s.replace('return image.tobytes()','return image.tobytes().hex()');f.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a,b=[ast.parse((P/n/rel).read_text()) for n in ('base','candidate')];changed=[]
for ca,cb in zip(a.body,b.body,strict=True):
 if isinstance(ca,ast.ClassDef):
  assert ast.dump(type(ca)(**{k:[] if k=='body' else getattr(ca,k) for k in ca._fields}))==ast.dump(type(cb)(**{k:[] if k=='body' else getattr(cb,k) for k in cb._fields}))
  for na,nb in zip(ca.body,cb.body,strict=True):
   if ast.dump(na)!=ast.dump(nb):assert isinstance(na,ast.FunctionDef);changed.append(ca.name+'.'+na.name)
 else:assert ast.dump(ca)==ast.dump(cb)
assert changed==['CallbackLiveHistoricalRowsTests.test_same_png_parser_function_code_change_cannot_borrow_warm_original_pixels','CallbackLiveHistoricalRowsTests.test_actual_raw_encoder_registry_change_cannot_borrow_warm_original_pixels']
rows=[];parts=[]
for f in sorted((P/'candidate').rglob('*.py')):
 r=f.relative_to(P/'candidate');rows.append(dict(path=str(r),baseSHA256=sha(P/'base'/r),candidateSHA256=sha(f)));parts.extend(difflib.unified_diff((P/'base'/r).read_text().splitlines(True),f.read_text().splitlines(True),fromfile='a/'+str(r),tofile='b/'+str(r)))
(P/'source.diff').write_text(''.join(parts));(P/'plan.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_ROOT_TEST_ONLY_REVIEW_REQUIRED',sourceRows=rows,changedMethods=changed,helperUnchanged=True,testOnly=True,targetImports=False,testsRun=False,measuredBytesExecutionUnchanged=True,reason='Only canonical JSON measurement result hex; actual original PNG Image.load/tobytes and parser/encoder changes remain exercised.'),indent=2)+'\n')
(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(f.relative_to(P)):sha(f) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='freeze.json'}),indent=2)+'\n');print(json.dumps(dict(freeze=sha(P/'freeze.json'),rows=rows)))
