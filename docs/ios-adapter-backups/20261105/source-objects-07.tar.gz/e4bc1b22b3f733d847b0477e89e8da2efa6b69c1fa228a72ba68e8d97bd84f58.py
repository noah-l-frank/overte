"""Pinned fixed60 retained02 read; independent original/source census survives timeout."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,time
root=Path.cwd();private=root/'.ios-host-tmp';out=private/'snapshot-retained02-forensic-cost04';out.mkdir(mode=0o700,exist_ok=True);child=private/'read-snapshot-retained02-child-forensic-cost04.py'
folders=tuple(private/name for name in ('tmpuie9i6w6','snapshot-companion-0tx6e3ru','snapshot-companion-uusdz4h9','snapshot-photos-selection-yufig1gt'))
def pin(path):
 s=path.lstat();value=dict(stat=[s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns])
 if stat.S_ISREG(s.st_mode):value['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
 elif not stat.S_ISDIR(s.st_mode):raise AssertionError('Nonregular original')
 return value
def originals():return {str(p):pin(p) for folder in folders for p in (folder,*sorted(folder.rglob('*')))}
def sources():
 paths=set()
 for folder in (root/'tests/device',root/'scripts',root/'interface/resources/qml'):
  if folder.exists():paths.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py','.js','.cjs','.mjs','.json','.qml','.html','.h','.cpp','.md') and '__pycache__' not in p.parts)
 paths.update((Path(__file__),child));return {str(p.relative_to(root)):pin(p) for p in sorted(paths)}
def save(name,value):(out/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
head=subprocess.run(['git','rev-parse','HEAD'],check=True,text=True,capture_output=True).stdout.strip()
assert head=='6aff8774d394fba02ba6e2e065b1dc3474a6203b'
save('repository-before.json',dict(head=head,label='FORENSIC_RETAINED02_COSTS_NO_END_OR_TIMING_QUALIFICATION'))
before=originals();source_before=sources();save('originals-before.json',before);save('sources-before.json',source_before)
print('SOURCE_BEFORE',len(source_before),'originalNodes',len(before),'launcherSHAs',{p.name:source_before[str(p.relative_to(root))]['sha256'] for p in (Path(__file__),child)},flush=True)
task_env=os.environ.copy();task_env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.:tests/device:tests/device/self_tests:tests/device/ios/self_tests')
started=time.monotonic();log=out/'read01.log'
with log.open('w') as stream:result=subprocess.run(['timeout','--signal=TERM','--kill-after=5s','60s','python3',str(child)],env=task_env,stdout=stream,stderr=subprocess.STDOUT)
after=originals();source_after=sources();save('originals-after.json',after);save('sources-after.json',source_after)
changed=sorted(k for k in set(before)|set(after) if before.get(k)!=after.get(k));changed_sources=sorted(k for k in set(source_before)|set(source_after) if source_before.get(k)!=source_after.get(k))
report=dict(exitCode=result.returncode,elapsedSeconds=time.monotonic()-started,changedOriginals=changed,changedSources=changed_sources,endpointAcceptance=False,wholeAcceptance=False)
head_after=subprocess.run(['git','rev-parse','HEAD'],check=True,text=True,capture_output=True).stdout.strip()
report.update(headBefore=head,headAfter=head_after);assert head_after==head
save('supervisor-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
raise SystemExit(result.returncode if not changed and not changed_sources else 98)
