"""Representative fresh account-only capture, no Avatar/Scene/end claim."""
from pathlib import Path
import cProfile,faulthandler,pstats,time,unittest,os,io
from contextlib import nullcontext
from unittest.mock import patch
from adapters.original_file_reads import scope as membership
from adapters.native_clock_join import digest
from ios.adapters.emote_original_lease import EmoteOriginalLease
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.lock import ScriptSourceLock
from ios.self_tests.avatar_terminal_domain import TerminalDomain
from self_tests import test_account_provider as tls
class Fixture(unittest.TestCase):retain_originals=True
test=Fixture();tls.AccountProviderTests.setUpClass()
try:
    domain=TerminalDomain(test);selector='primary';lock=ScriptSourceLock(domain.runtime.state_path(selector).with_name('script-feature-sources.lock'))
    faulthandler.enable();faulthandler.dump_traceback_later(100,repeat=False)
    with lock.held():
        owner=domain.runtime._avatar_account_reads(selector,domain.client,domain.owners['primary'].run,'primary','primary',domain.scenes[selector].root,lock,epoch_ms=domain.host,monotonic=lambda:domain.clock[0])
        for index in range(1,17):
            before=len(domain.scenes[selector].domain.history);start=time.perf_counter()
            profile=cProfile.Profile()
            if index==16:profile.enable()
            row=owner.read()
            if index==16:profile.disable()
            print('Fresh actual account component read='+str(index)+' elapsed='+format(time.perf_counter()-start,'.6f')+' newNativeQueries='+str(len(domain.scenes[selector].domain.history)-before)+' observed='+str(row['status']=='observed')+' sceneQualified=false',flush=True)
        print('Profile actual original frame reads='+str(sum(row.callcount for row in profile.getstats() if row.code is OriginalFrameStore.read.__code__)),flush=True)
        pstats.Stats(profile).strip_dirs().sort_stats('cumulative').print_stats(25).print_callers('deepcopy')
        lease=EmoteOriginalLease(owner.store.path.parent,[]);raw=owner.previous
        native_count=len(domain.scenes[selector].domain.history)
        actual_os_open,actual_io_open=os.open,io.open
        expected=None
        for collected in (False,True):
            for label,parse in (('baseline',owner._parse),('scoped',owner.parse)):
                opened=[]
                def os_open(path,*args,**kwargs):
                    opened.append(['os',os.fspath(path),str(args)]);return actual_os_open(path,*args,**kwargs)
                def io_open(path,*args,**kwargs):
                    opened.append(['io',os.fspath(path) if not isinstance(path,int) else '<fd>',str(args)]);return actual_io_open(path,*args,**kwargs)
                profile=cProfile.Profile();start=time.perf_counter()
                with patch.object(os,'open',os_open),patch.object(io,'open',io_open),membership(fresh=True) if collected else nullcontext(set()) as reads:
                    profile.enable();result=parse(raw);profile.disable()
                elapsed=time.perf_counter()-start;lease.guard()
                assert len(domain.scenes[selector].domain.history)==native_count
                observed=(digest(result),opened)
                if expected is None:expected=observed
                else:assert observed==expected
                if label=='baseline':previous_members=set(reads)
                else:assert previous_members==reads
                print('Live exact original parse collector='+str(collected)+' mode='+label+' seconds='+format(elapsed,'.6f')+' opens='+str(len(opened))+' actualFrames='+str(sum(x.callcount for x in profile.getstats() if x.code is OriginalFrameStore.read.__code__))+' membership='+str(len(reads))+' exactOpenTraceAndOutputParity=True nativeQueries=0 originalInventoryUnchanged=True',flush=True)
                pstats.Stats(profile).strip_dirs().sort_stats('cumulative').print_stats(12)
finally:
    test.doCleanups();tls.AccountProviderTests.tearDownClass()
