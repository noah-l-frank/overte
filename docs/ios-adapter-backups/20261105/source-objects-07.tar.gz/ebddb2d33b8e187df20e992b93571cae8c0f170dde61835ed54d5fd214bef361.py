"""One normal new canonical SDK after a fully proved original keeper End.

Feature-specific retired scope admission stays typed and independently owns
its old originals. This owner never restores native state by changing a DTO,
clears an old feature ledger, or resends an uncertain launch.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from contextvars import ContextVar
from contextlib import contextmanager
from pathlib import Path
import time,inspect
from adapters.native_clock_join import digest,NativeClockAcquisition,validate_join
from adapters.native_feature_observation import exact,need,number,validate as native_original
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import pack,unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import identifier
from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd
from ios.adapters.script_runtime import IOSScriptRuntime

PROFILE='ios-original-keeper-readmission-v1'
_CREATION=ContextVar('ios_original_keeper_creation_owner',default=None)


def filename(profile_key,role,stage):
    need(profile_key=='audiowhole'and role=='primary'and type(stage)is int and stage==0)
    return 'ios-original-keeper-readmission-'+profile_key+'-'+role+'-'+str(stage)+'.json'


def creation_requested():return _CREATION.get()is not None


def creation_capabilities(adapter,target):
    owner=_CREATION.get()
    if owner is None:return target['capabilities']
    need(type(owner)is IOSOriginalKeeperReadmission and owner.runtime.adapter is adapter and owner.state['phase']=='launch-issued'
        and owner.state['pending']is None and adapter._target(owner.selector)==target)
    owner.bound();creator=owner.old_end.original(owner.old_end.state['creator'])['creatorRetirement']
    need(digest(creator)==owner.old_proof['creatorRetirementOriginalSha256'])
    capability=dict(profile=PROFILE,profileKey=owner.profile_key,stage=owner.stage,runId=owner.run,binding=deepcopy(owner.binding),
        oldOwnerInstance=owner.old_proof['ownerInstance'],oldCreatorRetirementSha256=digest(creator),replacementGrant=creator['replacementGrant'])
    value=deepcopy(target['capabilities']);need('appium:overteOriginalKeeperReplacement'not in value)
    value['appium:overteOriginalKeeperReplacement']=capability;return value


class IOSOriginalKeeperReadmission:
    def __init__(self,runtime,selector,old_end,scope,*,lock,epoch_ms=lambda:time.time()*1000,monotonic=time.monotonic):
        from ios.adapters.audio_whole_scope_retirement import IOSAudioWholeRetiredScope
        need(isinstance(runtime,IOSScriptRuntime)and type(old_end)is IOSOriginalKeeperProcessEnd
            and type(scope)is IOSAudioWholeRetiredScope and isinstance(lock,ScriptSourceLock)
            and runtime.adapter is old_end.runtime.adapter and selector==old_end.selector and lock is old_end.lock)
        self.runtime,self.selector,self.old_end,self.scope,self.lock=runtime,selector,old_end,scope,lock
        self.root,self.binding,self.run,self.role=old_end.root,deepcopy(old_end.binding),old_end.run,old_end.role
        self.stage,self.profile_key=old_end.stage,old_end.profile_key
        self.epoch_ms,self.monotonic=epoch_ms,monotonic
        self.store=PrivateFeatureState(old_end.store.path.with_name(filename(self.profile_key,self.role,self.stage)))
        self.lock.assert_held();self.old_proof,self.scope_original=scope.readmission_originals(old_end)
        self.scope_original=deepcopy(self.scope_original)
        self.receivers=[]
        for obj,names in ((scope,('readmission_originals','guard_readmission_originals','readmission_original','guard_readmission','admitted_readmission')),
            (old_end,('retirement_original','_summary','validate_history','decode','bound')),(type(old_end),('_completed_reader',)),
            (runtime,('_sources','_existing')),(runtime.adapter,('describe','ensure_session'))):
            for name in names:
                method=getattr(obj,name);function=method.__func__;wrapped=inspect.unwrap(function)
                self.receivers.append((obj,name,function,function.__code__,wrapped,wrapped.__code__))
        self.previous=self.store.read();self.state=dict(phase='new',records=[],pending=None,end=None,scope=None,replacement=None,
            launch=None)if self.previous is None else self.decode(self.previous)
        self.files=OriginalFrameStore(self.root,self.binding,self.run,self.role,self.bound,self.intent,
            namespace='original-readmission',schema_prefix='iosOriginalReadmission')
        self.bound()
        if self.previous is not None and self.state['pending']is None:self.validate_history()

    def envelope(self):
        return dict(iosOriginalKeeperReadmissionArchiveVersion=1,profile=PROFILE,profileKey=self.profile_key,binding=self.binding,
            runId=self.run,role=self.role,oldStage=self.stage,artifactRoot=str(self.root),payload=pack([self.state]))

    def decode(self,value):
        exact(value,{'iosOriginalKeeperReadmissionArchiveVersion','profile','profileKey','binding','runId','role','oldStage','artifactRoot','payload'})
        need(type(value['iosOriginalKeeperReadmissionArchiveVersion'])is int and value['iosOriginalKeeperReadmissionArchiveVersion']==1
            and value['profile']==PROFILE and value['profileKey']==self.profile_key and value['binding']==self.binding
            and value['runId']==self.run and value['role']==self.role and type(value['oldStage'])is int and value['oldStage']==self.stage
            and value['artifactRoot']==str(self.root))
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0]
        exact(state,{'phase','records','pending','end','scope','replacement','launch'})
        need(state['phase']in ('new','prepared','launch-issued','complete')and type(state['records'])is list and len(state['records'])<=3)
        return deepcopy(state)

    def bound(self):
        self.lock.assert_held();need(same(self.store.read(),self.previous))
        for obj,name,function,code,wrapped,wrapped_code in self.receivers:
            method=getattr(obj,name);need(method.__self__ is obj and method.__func__ is function and function.__code__ is code
                and inspect.unwrap(function)is wrapped and wrapped.__code__ is wrapped_code)
        actual_end,actual_scope=self.scope.guard_readmission_originals(self.scope_original)
        need(same(actual_end,self.old_proof)and same(actual_scope,self.scope_original))
        expected={self.files.path(self.files.expand(ref))for ref in self.state['records']}
        pending=self.state['pending']
        if pending is not None and pending['file']is not None and pending['file']['phase']!='planned':expected.add(self.files.path(pending['file']))
        actual=set(self.root.glob('original-readmission-frame-sources-'+self.run+'-'+self.role+'-*.json'));need(actual==expected)
        return True

    def save(self):
        self.bound();value=self.envelope();self.store.write(value,self.previous);self.previous=deepcopy(value)

    def intent(self,kind,value):
        self.lock.assert_held();need(kind=='original'and self.state['pending']is not None);self.files.original(value)
        pending=self.state['pending'];need(value['index']==len(self.state['records'])+1)
        old=pending['file']
        if old is None:need(value['phase']=='planned')
        else:need(all(same(old[key],value[key])for key in old if key not in ('phase','file'))
            and (old['phase'],value['phase'])in (('planned','opened'),('opened','saved')))
        pending['file']=deepcopy(value);self.save()

    def original(self,reference):return self.files.read(self.files.expand(reference))

    def retain(self,kind,value):
        self.bound();need(kind in ('end','scope','replacement'))
        pending=self.state['pending']
        if pending is None:
            self.state['pending']=dict(kind=kind,file=None);self.save()
        else:need(pending['kind']==kind and pending['file']is None)
        reference=self.files.write(len(self.state['records'])+1,dict(kind=kind,original=deepcopy(value)))
        self.state['records'].append(reference);self.state[kind]=reference;self.state['pending']=None;self.save()
        return reference

    def recover_saved(self):
        self.bound();pending=self.state['pending']
        if pending is None:return
        file=pending['file'];need(file is not None and file['phase']in ('opened','saved'))
        value=self.files.read(file);need(value['kind']==pending['kind'])
        reference=self.files.compact(dict(file,phase='saved'))
        self.state['records'].append(reference);self.state[pending['kind']]=reference;self.state['pending']=None;self.save()

    def prepare(self):
        self.recover_saved()
        if self.state['phase']!='new':self.validate_history();return
        need(PrivateFeatureState(self.runtime.state_path(self.selector)).read()is None
            and self.runtime.adapter._binding_store(self.selector).read()is None)
        if self.state['end']is None:self.retain('end',self.old_proof)
        if self.state['scope']is None:self.retain('scope',self.scope_original)
        self.state['phase']='prepared';self.save();self.validate_history()

    def fresh_source_original(self):
        """Read ONLY the already created canonical SDK; never ensure/launch."""
        source=self.runtime._sources(self.selector);source['check']()
        client,session=source['client'],source['session'];origin=client.server_url
        receivers=tuple((name,getattr(client,name),getattr(client,name).__func__.__code__)for name in ('execute','call','_read_reply'))
        def guard():
            self.bound();need(source['client']is client and source['session']==session and client.server_url==origin)
            for name,method,code in receivers:
                selected=getattr(client,name);need(selected.__self__ is client and selected.__func__ is method.__func__ and method.__func__.__code__ is code)
            need(source['check']()is not False)
        guard()
        identity=receivers[0][1](session,'mobile: overteOriginalKeeperOperation',dict(operation='original-readmission-identity',args={}))
        guard();exact(identity,{'iosOriginalKeeperReadmissionIdentityVersion','ownerInstance','sessionId','source','sourceLive','existingWdaBound','originalCreatorReplacement'})
        need(type(identity['iosOriginalKeeperReadmissionIdentityVersion'])is int and identity['iosOriginalKeeperReadmissionIdentityVersion']==1
            and identity['sessionId']==session and identity['source']=='original-userspace-rsd'and identity['sourceLive']is True
            and identity['existingWdaBound']is True and identifier(identity['ownerInstance'])!=self.old_proof['ownerInstance'])
        self.validate_creator_replacement(identity)
        clock=source['clock_source'];fence=NativeClockAcquisition(clock,epoch_ms=self.epoch_ms,monotonic=self.monotonic)
        fence.begin(self.epoch_ms());native=clock.read(clock.sequence);guard()
        joined=fence.finish(dict(native=native),[('native','capturedEpochMs')]);guard()
        installed=self.runtime.adapter._binding_store(self.selector).read()
        value=dict(iosOriginalKeeperReplacementOriginalVersion=1,oldBinding=self.binding,newBinding=deepcopy(source['binding']),
            runId=self.run,role=self.role,oldEndArchiveSha256=self.old_proof['archiveSha256'],scopeOriginalSha256=digest(self.scope_original),
            identity=deepcopy(identity),sdkState=deepcopy(source['state']),installedBinding=deepcopy(installed),native=deepcopy(native),clockJoin=deepcopy(joined),
            hostCapturedEpochMs=self.epoch_ms(),hostCapturedMonotonic=self.monotonic())
        self.validate_replacement(value);return value

    @contextmanager
    def admitted_creation(self):
        self.bound();need(self.state['phase']=='launch-issued'and _CREATION.get()is None)
        token=_CREATION.set(self)
        try:yield
        finally:_CREATION.reset(token)

    def launch(self):
        self.prepare()
        if self.state['phase']=='complete':return self.replacement_original()
        if self.state['replacement']is not None:
            self.state['phase']='complete';self.save();return self.replacement_original()
        if self.state['phase']=='prepared':
            self.state['phase']='launch-issued';self.state['launch']=dict(hostBeforeEpochMs=self.epoch_ms(),hostBeforeMonotonic=self.monotonic());self.save()
            # Only this exact typed scope context authorizes its retained old
            # feature metadata. Ordinary candidate/installed launch stays real.
            with self.scope.admitted_readmission(self.scope_original,owner=self),self.admitted_creation():
                self.bound();self.runtime.adapter.describe(self.selector)
                original=self.fresh_source_original()
        else:
            # A lost describe/session/launch result never authorizes another
            # creation. Existing canonical state must already be bound before
            # a fresh read-only Source can recover its actual new originals.
            need(self.state['phase']=='launch-issued')
            state=PrivateFeatureState(self.runtime.state_path(self.selector)).read()
            installed=self.runtime.adapter._binding_store(self.selector).read()
            need(state is not None and installed is not None and installed['phase']=='bound')
            with self.scope.admitted_readmission(self.scope_original,owner=self):original=self.fresh_source_original()
        if self.state['replacement']is None:self.retain('replacement',original)
        self.state['phase']='complete';self.save();return self.replacement_original()

    def validate_creator_replacement(self,identity):
        receipt=identity['originalCreatorReplacement']
        exact(receipt,{'originalKeeperReplacementVersion','profile','previousOwnerInstance','ownerInstance','runId','stage','oldCreatorRetirementSha256'})
        need(type(receipt['originalKeeperReplacementVersion'])is int and receipt['originalKeeperReplacementVersion']==1
            and receipt['profile']==PROFILE and receipt['previousOwnerInstance']==self.old_proof['ownerInstance']
            and receipt['ownerInstance']==identity['ownerInstance']and receipt['ownerInstance']!=receipt['previousOwnerInstance']
            and receipt['runId']==self.run and type(receipt['stage'])is int and receipt['stage']==self.stage
            and receipt['oldCreatorRetirementSha256']==self.old_proof['creatorRetirementOriginalSha256'])

    def validate_replacement(self,value):
        exact(value,{'iosOriginalKeeperReplacementOriginalVersion','oldBinding','newBinding','runId','role','oldEndArchiveSha256',
            'scopeOriginalSha256','identity','sdkState','installedBinding','native','clockJoin','hostCapturedEpochMs','hostCapturedMonotonic'})
        need(type(value['iosOriginalKeeperReplacementOriginalVersion'])is int and value['iosOriginalKeeperReplacementOriginalVersion']==1
            and value['oldBinding']==self.binding and value['runId']==self.run and value['role']==self.role
            and value['oldEndArchiveSha256']==self.old_proof['archiveSha256']and value['scopeOriginalSha256']==digest(self.scope_original))
        new=context(value['newBinding']);need(all(new[key]==self.binding[key]for key in ('sourceRevision','artifactSha256','targetFingerprint'))
            and new['sessionId']!=self.binding['sessionId']and new['processIdentity']!=self.binding['processIdentity'])
        identity=value['identity'];exact(identity,{'iosOriginalKeeperReadmissionIdentityVersion','ownerInstance','sessionId','source','sourceLive','existingWdaBound','originalCreatorReplacement'})
        need(type(identity['iosOriginalKeeperReadmissionIdentityVersion'])is int and identity['iosOriginalKeeperReadmissionIdentityVersion']==1
            and identity['source']=='original-userspace-rsd'and identity['sourceLive']is True and identity['existingWdaBound']is True
            and identity['sessionId']==new['sessionId']and identifier(identity['ownerInstance'])!=self.old_proof['ownerInstance'])
        self.validate_creator_replacement(identity)
        packet=value['native'];native_original(packet,packet['requestId'],int(new['processIdentity']),packet['capturedEpochMs'])
        joined=validate_join(value['clockJoin'],dict(native=packet))
        need(joined['nativeBefore']['processId']==joined['nativeAfter']['processId']==int(new['processIdentity'])
            and joined['nativeBefore']['instance']==joined['nativeAfter']['instance']==packet['instance']
            and identifier(packet['instance'])!=self.old_proof['nativeFeatureInstance'])
        sdk=value['sdkState'];installed=value['installedBinding']
        need(type(sdk)is dict and sdk['sessionId']==new['sessionId']and sdk['processIdentity']==new['processIdentity']
            and sdk['targetFingerprint']==new['targetFingerprint']and sdk['generation']==new['generation'])
        need(type(installed)is dict and installed['phase']=='bound'and installed['scope']=={key:v for key,v in new.items()if key!='processIdentity'}
            and installed['process']['pid']==int(new['processIdentity']))
        # Decode actual installed bundle bytes through the existing historical
        # candidate decoder. No live query or process-source DTO is substituted.
        self.runtime.adapter._avatar_retired_binding_record(self.selector,installed['scope'],installed)
        launch=self.state['launch'];need(launch is not None)
        need(number(value['hostCapturedEpochMs'],launch['hostBeforeEpochMs'],1e15)
            and number(value['hostCapturedMonotonic'],launch['hostBeforeMonotonic'],1e15))

    def validate_history(self):
        self.bound();need(self.state['pending']is None)
        order=('end','scope','replacement')
        for ordinal,reference in enumerate(self.state['records'],1):
            need(reference['index']==ordinal and self.state[order[ordinal-1]]==reference)
            value=self.original(reference);exact(value,{'kind','original'});need(value['kind']==order[ordinal-1])
            if value['kind']=='end':need(same(value['original'],self.old_proof))
            elif value['kind']=='scope':need(same(value['original'],self.scope_original))
            else:self.validate_replacement(value['original'])
        return True

    def replacement_original(self):
        self.validate_history();need(self.state['phase']=='complete'and self.state['replacement']is not None)
        value=self.original(self.state['replacement'])['original'];new=value['newBinding']
        return dict(iosOriginalKeeperReplacementVersion=1,profile=PROFILE,profileKey=self.profile_key,runId=self.run,role=self.role,oldStage=self.stage,
            oldBinding=deepcopy(self.binding),newBinding=deepcopy(new),oldOwnerInstance=self.old_proof['ownerInstance'],
            newOwnerInstance=value['identity']['ownerInstance'],oldNativeFeatureInstance=self.old_proof['nativeFeatureInstance'],
            newNativeFeatureInstance=value['native']['instance'],oldEndArchiveSha256=self.old_proof['archiveSha256'],
            scopeOriginalSha256=digest(self.scope_original),newSDKStateSha256=digest(value['sdkState']),
            newInstalledBindingSha256=digest(value['installedBinding']),newNativeOriginalSha256=digest(value['native']),
            archiveSha256=digest(self.previous),archive=deepcopy(self.previous))

    @classmethod
    def archived_original(cls,value,*,store,root,old_end,scope,lock):
        # __init__ performs only typed old-End/scope/PFS replay. It must not
        # acquire Source/SDK objects; launch() is the sole creation path above.
        need(type(old_end)is IOSOriginalKeeperProcessEnd and Path(root)==old_end.root and type(store)is PrivateFeatureState)
        current=cls(old_end.runtime,old_end.selector,old_end,scope,lock=lock)
        need(current.store.path==store.path and same(value['archive'],store.read())and digest(store.read())==value['archiveSha256'])
        expected=current.replacement_original();need(same(value,expected));return deepcopy(expected)

    def owned_paths(self):
        self.bound();paths={self.store.path}
        paths.update(self.files.path(self.files.expand(ref))for ref in self.state['records'])
        pending=self.state['pending']
        if pending is not None and pending['file']is not None and pending['file']['phase']!='planned':paths.add(self.files.path(pending['file']))
        return paths
