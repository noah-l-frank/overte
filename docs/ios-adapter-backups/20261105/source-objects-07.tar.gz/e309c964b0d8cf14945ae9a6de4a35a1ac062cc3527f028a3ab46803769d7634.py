"""UNRUN joined actual-Script peer/offline/restoration counters; no full25 claim."""
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.chat_offline_send_operation import IOSChatOfflineSendOperation
from chat_paired_offline_history_fixture import PairedOfflineHistoryFixture


class PairedOfflineHistoryContinuationTests(unittest.TestCase):
    def setUp(self):self.f=PairedOfflineHistoryFixture(self)
    def initial(self):
        f=self.f;f.f.open();f.f.type('primary',token='unicode')
        first=f.continuation.send('primary',f.f.models['primary'].ticket)
        f.f.type('peer',token='reply');reply=f.continuation.send('peer',f.f.models['peer'].ticket)
        return first,reply
    def offline(self):
        f=self.f;f.mixer(False);f.f.drafts['primary'].act('type',dict(text=self.retry_text()))
        f.phase('send','8'*32);return f.continuation.send_offline('8'*32)
    def retry_text(self):
        from feature_journeys.fixtures import context
        return context(self.f.f.drafts['primary'].run)['retry']
    def quiet(self):
        f=self.f;f.mixer(True);f.phase('await-no-replay','9'*32)
        return f.continuation.no_replay('9'*32,'8'*32)
    def test_two_actual_scripts_reply_offline_quiet_explicit_resend_and_paired_null_restore(self):
        self.initial();echo=self.offline();f=self.f
        self.assertTrue(echo['localEcho']['localOnly']);self.assertFalse(echo['remoteDeliveryEstablished'])
        before=deepcopy(f.wires);quiet=self.quiet();self.assertTrue(quiet['noRemoteReplayObserved']);self.assertEqual(before,f.wires)
        f.f.drafts['primary'].act('type',dict(text=self.retry_text()));f.phase('send','a'*32)
        online=f.continuation.send('primary','a'*32);self.assertEqual(self.retry_text(),online['sent']['events']['peer']['text'])
        f.phase('cleanup','b'*32);result=f.continuation.restore_history('b'*32)
        self.assertTrue(result['historyRestored']);self.assertFalse(result['processOrSDKRetirementEstablished'])
        for model in f.f.models.values():
            original=model.command('read');self.assertIsNone(original['history']);self.assertEqual([],original['local']);self.assertEqual([],original['domain']);self.assertEqual(1,original['erases'])
        before=f.snapshots();self.assertEqual(result,f.continuation.restore_history('b'*32));self.assertEqual(before,f.snapshots())
    def test_lost_offline_send_after_actual_wire_recovers_same_wal_without_second_send(self):
        self.initial();f=self.f;f.mixer(False);f.f.drafts['primary'].act('type',dict(text=self.retry_text()));f.phase('send','8'*32)
        f.f.models['primary'].lose_bus_return=True
        with self.assertRaises(OSError):f.continuation.send_offline('8'*32)
        before=deepcopy(f.wires);calls=deepcopy(f.f.models['primary'].widgets.calls);f.f.models['primary'].lose_bus_return=False
        self.assertTrue(f.continuation.send_offline('8'*32)['localEcho']['localOnly'])
        self.assertEqual(before,f.wires);self.assertEqual(calls,f.f.models['primary'].widgets.calls)
    def test_unexpected_independent_peer_event_blocks_local_echo_and_never_invokes_peer_receipt(self):
        self.initial();f=self.f;f.unexpected_peer=True
        with self.assertRaises(NativeUIError):self.offline()
        self.assertFalse(f.offline.store.read()is not None and f.offline.store.read()['payload']['complete'])
    def test_missing_sender_script_callback_cannot_be_replaced_by_native_self_echo(self):
        self.initial();self.f.no_sender_callback=True
        with self.assertRaises(NativeUIError):self.offline()
        self.assertEqual(3,len(self.f.wires))
    def test_lost_primary_erase_after_peer_restore_keeps_error_and_resumes_without_second_erase(self):
        self.initial();f=self.f;f.phase('cleanup','b'*32);f.f.models['primary'].lose_erase=True
        with self.assertRaises(NativeUIError)as caught:f.continuation.restore_history('b'*32)
        self.assertIs(caught.exception,f.f.models['primary'].erase_error)
        self.assertEqual(1,f.f.models['peer'].command('read')['erases']);self.assertEqual(1,f.f.models['primary'].command('read')['erases'])
        peer_calls=deepcopy(f.f.models['peer'].widgets.calls);f.f.models['primary'].lose_erase=False
        self.assertTrue(f.continuation.restore_history('b'*32)['historyRestored']);self.assertEqual(peer_calls,f.f.models['peer'].widgets.calls)
        self.assertEqual(1,f.f.models['primary'].command('read')['erases'])
    def test_completed_no_replay_stays_pure_after_the_other_script_has_a_real_reply(self):
        self.initial();self.offline();quiet=self.quiet();before=self.f.snapshots()
        # Repeat resolves the same original complete quiet journal. No new
        # phase, normal input or receive capture may appear.
        with patch.object(PrivateFeatureState,'write',side_effect=AssertionError('No completed journal write')):
            self.assertEqual(quiet,self.f.continuation.no_replay('9'*32,'8'*32))
        self.assertEqual(before,self.f.snapshots())

if __name__=='__main__':unittest.main()
