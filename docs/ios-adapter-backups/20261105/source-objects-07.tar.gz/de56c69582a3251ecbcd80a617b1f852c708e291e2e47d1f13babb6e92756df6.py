"""Current six-second original negative acquisition after emission retirement.

This schedules readonly passive capture on the existing Actor parent; it sends
no sound, resets no cache and infers no physical ADC/output qualification.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import hashlib
from adapters.native_feature_observation import need
from ios.adapters.audio_passive_capture_source import original_frame


def lease_id(run,ticket):return hashlib.sha256(('ios-audio11-negative-v1:'+run+':'+ticket).encode('ascii')).hexdigest()[:32]

def acquire(flow,call):
    f=flow;lease=lease_id(f.run,call['ticket']);f.retire_actor();started=f.monotonic()
    with f.held():
        status=f.phase.read();need(status['ticket']==call['ticket'] and status['verb']==call['verb'] and status['inputs']==call['inputs'])
        # One actual SDK/source/owner remains bound through this acquisition.
        # Every poll still acquires fresh phase/native originals and all source,
        # ledger, file and durable query-intent guards remain active.
        with f.actor_runtime.passive_owner(f.actor_selector,f.run,lease,f.actor_root,f.client,source_lock=f.locks[0],epoch_ms=f.epoch_ms,monotonic=f.monotonic,sleep=f.sleep) as owner:
            while True:
                f.guard()
                status=f.phase.read();need(status['ticket']==call['ticket'] and status['verb']==call['verb'] and status['inputs']==call['inputs'])
                if owner.state['birth'] is None:owner.start(6)
                _index,observation=owner.control('observe');state=observation['packet']['source']['state']
                if state['complete']:
                    owner.capture();snapshot=owner.proof(owner.state['snapshot']);wav=owner.snapshot()['wav']
                    raw=owner.assembled(snapshot['chunks']['capture'],'capture',snapshot['selection'],owner.state['snapshot'])
                    native=original_frame(raw,wav,owner.state['capture'],owner.pid);owner.retire()
                    # Original last read is the real capture endpoint. The
                    # whole observation age guard can refuse a slow producer.
                    selection=owner.proof(snapshot['selection']);last=native['source']['rows'][-1]['readAfterEpochMs']
                    need(0<=selection['clockJoin']['nativeAfter']['capturedEpochMs']-last<1500)
                    epoch=selection['clockJoin']['hostAfterEpochMs']
                    f.evidence.retain(call['ticket'],'audio',wav,source_ticket=call['ticket'],source_reference=dict(leaseId=lease,snapshot=owner.state['snapshot'],absence=owner.state['absence']),capture_epoch=epoch)
                    return
                need(f.monotonic()-started<20);f.sleep(.5) # Host status only; native input callbacks/rows remain independent.
