"""Actual Whole11/Runtime/Actor10/WAL consumers, declared raw native producers.

No consumer, archive, restoration verdict or End proof is replaced. Native,
settings, UIKit, audio, fixture HTTP and clock producers are modeled. Existing
Source5 fixture births remain real private files. The composed Original-Keeper
End/replacement positive producer remains a separate required integration.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
from adapters.native_feature_observation import need
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.witness import Client,Journal
from ios.adapters import audio_settings_source
from ios.adapters.audio_whole_feature import IOSAudioWholeFeature
from ios.self_tests.audio_once_journey_fixture import OnceJourneyFixture,RUN
from ios.self_tests.audio_settings_fixture import Domain as SettingsDomain

class AudioWholeFixture:
    def __init__(self,case):
        self.case=case;tmp=tempfile.TemporaryDirectory();case.addCleanup(tmp.cleanup);self.root=Path(tmp.name);self.root.chmod(0o700)
        self.roots={}
        for key,name in (('artifactRoot','public'),('primaryArtifactRoot','primary-originals'),('actorArtifactRoot','actor-originals'),('primaryWholeRoot','primary-current'),('actorWholeRoot','actor-current')):
            root=self.root/name;root.mkdir(mode=0o700);self.roots[key]=str(root)
        self.once=OnceJourneyFixture(case,primary_artifact_root=Path(self.roots['primaryArtifactRoot']),register_primary_scope=False)
        f=self.once;m=f.p.m;self.m=m;f.artifacts=Path(self.roots['actorArtifactRoot'])
        self.original_adapter=f.p.runtime.adapter
        outer=self
        class Adapter:
            def state_path(self,selector):return f.actor_root/'session.json' if selector=='actor' else f.p.root/'session.json'
            def __getattr__(self,name):return getattr(outer.original_adapter,name)
        self.adapter=Adapter();f.p.runtime.adapter=self.adapter;f.runtime.adapter=self.adapter
        self.settings_template=SettingsDomain();self.settings_queries=[];self.source_calls=0;self.settings_sequence=0;self.settings_raw='';self.settings_fault=None
        source=f.p.runtime._sources
        def sources(selector):
            self.source_calls+=1;value=source(selector);original=value['native']
            class Normal:
                observe_intent=None;last_receipt=None
                def capture(self):
                    sent=[];previous=original.observe_intent
                    def log(query):
                        sent.append(deepcopy(query))
                        if self.observe_intent is not None:self.observe_intent(query)
                    original.observe_intent=log
                    try:packet=original.capture()
                    finally:original.observe_intent=previous
                    need(sent);self.last_receipt=dict(schemaVersion=1,commandId=sent[-1]['commandId'],observation=deepcopy(packet));return packet
                def scroll(self,*args,**kwargs):return original.scroll(*args,**kwargs)
            value['native']=Normal()
            observer=value['observer']
            def settings(clock_source):return audio_settings_source.IOSAudioSettings(self.send_settings,lambda:self.settings_raw,lambda:clock_source.read(clock_source.sequence)['capturedEpochMs'],m.guard,42,monotonic=lambda:m.clock,sleep=m.sleep)
            observer.audio_settings=settings;return value
        f.p.runtime._sources=sources
        f.session.mutate=lambda packet:packet.update(lifecycle=deepcopy(f.p.lifecycle))
        self.journal=Journal(clock=m.epoch);registered=self.journal.register('audio');self.journal.runs[RUN]=self.journal.runs.pop(registered)
        m.activations.clear()
        class FixtureClient(Client):
            def __init__(self,publisher):super().__init__('https://controlled.invalid/feature-fixture/v1',('p' if publisher else 'r')*64,monotonic=lambda:m.clock,sleep=m.sleep);self.publisher=publisher
            def request(self,path,value=None,method=None,*,phase_nonce=None,**kwargs):
                if path=='/runs/'+RUN+'/phase':need(value is None and phase_nonce is not None);return outer.journal.phase(RUN,phase_nonce)
                if path=='/runs/'+RUN:need(value is None);return outer.journal.snapshot(RUN)
                if path=='/runs/'+RUN+'/samples':need(self.publisher and type(value) is dict);outer.journal.publish(RUN,value);return {}
                raise ValueError('Declared fixture transport refused an unsupported endpoint')
        self.reader,self.publisher=FixtureClient(False),FixtureClient(True)
        self.config=dict(actorTarget='actor',**self.roots)
        self.locks=(f.actor_lock,f.p.lock);self.runtimes=(f.runtime,f.p.runtime)
        self.primary=self.flow('primary');self.actor=self.flow('actor')
        self.activate('baseline','0'*32)
    def flow(self,role):return IOSAudioWholeFeature(self.adapter,'test-only',RUN,role,self.reader,self.config,publisher=self.publisher if role=='actor' else None,
        epoch_ms=self.m.epoch,monotonic=lambda:self.m.clock,sleep=self.m.sleep,runtimes=self.runtimes,source_locks=self.locks)
    def send_settings(self,query):
        m=self.m;self.settings_queries.append(deepcopy(query));self.settings_sequence+=1;m.tick();before=dict(epochMs=m.native_epoch(),monotonicMs=round(m.clock*1000))
        template=self.settings_template;script=deepcopy(template.script);script['hmdContext']=m.hmd;script['mutedHmd' if m.hmd else 'mutedDesktop']=m.muted
        client=dict(template.client,muted=m.muted,localEcho=m.echo,voiceActive=m.active)
        source=dict(iosAudioSettingsReadVersion=1,nativeHmd=m.hmd,scriptBefore=deepcopy(script),scriptAfter=deepcopy(script),clientBefore=deepcopy(client),clientAfter=deepcopy(client),mixerBefore=deepcopy(template.mixer),mixerAfter=deepcopy(template.mixer))
        m.tick();after=dict(epochMs=m.native_epoch(),monotonicMs=round(m.clock*1000))
        packet=dict(iosAudioSettingsVersion=1,requestId=query['commandId'],runId=query['runId'],instance=m.native_instance,sequence=self.settings_sequence,processId=42,clockDomain='native-main-ios-audio-settings',clockBefore=before,clockAfter=after,lifecycle=deepcopy(self.once.p.lifecycle),source=source,**{key:False for key in audio_settings_source.UNAVAILABLE})
        if self.settings_fault:self.settings_fault(packet)
        self.settings_raw=json.dumps(packet)
    def activate(self,verb,ticket,inputs=None):
        inputs={} if inputs is None else inputs;self.m.add_phase(verb,ticket,**inputs);self.journal.activate(RUN,ticket,verb,inputs)
        return dict(contractVersion=16,runId=RUN,fixtureUrl=self.reader.url+'/runs/'+RUN+'/',ticket=ticket,verb=verb,inputs=inputs)
    def observe(self):return self.primary.observe(dict(contractVersion=16,runId=RUN,afterSequence=0))
    def step(self,verb,ticket,inputs=None):
        call=self.activate(verb,ticket,inputs);self.primary.act(call);value=self.observe();self.actor.publish();return value
