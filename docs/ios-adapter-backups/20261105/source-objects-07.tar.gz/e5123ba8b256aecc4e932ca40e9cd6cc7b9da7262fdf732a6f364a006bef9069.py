"""Exact actual B6 KernelOwn5 Root proof; no feature qualification or PID I/O.

Every read below is of an explicitly frozen saved receipt, never a /proc query,
corpus discovery, fresh process verdict or reconstruction of missing originals.
"""
from pathlib import Path
import json
KERNEL_SOURCE_FREEZE='c9231c5e1bd3b1de57f7e4f1d03b549e6ed735d27b71420d8454fcd511b3270f'
UTILITY_SOURCE_FREEZE='b7bb7fea1810e6495a4928f041f0ec7ba04ec1b5416ce0233d661dfffb73e583'
HISTORICAL_LOADER_SOURCE_FREEZE='63f5ffc563996ad7793a600cb6a16c53d8df05a54d65db24321a1a2b5c020fc4'
ACTUAL_ROOT_FREEZE='c0cbb12c3b2d468cb83686f8df3e538cfce13dbcea058a6b7b9638692dfbe0b8'
ACTUAL_RESULT_SHA='9e4354a52300fc7d68adb255eeffb4fbabdb39be579be7ddd6c4fe011bc6c46f'
ACTUAL_REFERENCES_SHA='75a6a39e7a6850c37883f28b212c047eee8bb3a7f16b185c4718d58d0b3bb520'
KERNEL_SHA='5f292a04667435808e9ea7c8cdc3921380ffbad174cfae0bc695df92cfa0d9bf'
TEST_SHA='b1905d424f21a35162d9f6ce4137a348419a7bb00f6c7874a0b3c3582b948816'
EXPECTED_IDS=tuple('test_owned_kernel_discovery.OwnedKernelDiscoveryTests.'+name for name in(
 'test_real_owned_python_resolves_only_its_executable_after_stat_only_foreign_discovery',
 'test_unreadable_actual_owned_executable_propagates_without_absence_or_permission_skip',
 'test_missing_executable_with_actual_owned_pid_still_alive_is_not_absence',
 'test_actual_child_exit_between_original_stat_and_executable_read_is_verified_absent',
 'test_identity_comparator_refuses_each_changed_actual_tuple_component'))

def require(value,pin):
    assert type(value)is dict and set(value)=={'path','sha256'}and value['sha256']==ACTUAL_ROOT_FREEZE
    physical={}
    def checked(path,sha):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        actual=pin(path);assert actual['sha256']==sha
        physical[str(path)]=actual
        return path
    def read(path,sha):return json.loads(checked(path,sha).read_text())
    path=checked(value['path'],ACTUAL_ROOT_FREEZE);root=path.parent
    assert path.name=='freeze.json'and root.name=='root-emote-kernel-own5-five-qualified-results-20261104'
    frozen=json.loads(path.read_text());assert set(frozen)=={'files'}
    assert frozen['files']=={'results.json':{'sha256':ACTUAL_RESULT_SHA},'actual-receipt-references.json':{'sha256':ACTUAL_REFERENCES_SHA}}
    actual=read(root/'results.json',ACTUAL_RESULT_SHA)
    refs=read(root/'actual-receipt-references.json',ACTUAL_REFERENCES_SHA);assert type(refs)is dict and len(refs)==54
    for name,row in refs.items():
        assert type(row)is dict and set(row)=={'path','sha256'}and row['path']==name
        checked(name,row['sha256'])
    assert actual['schemaVersion']==1 and actual['status']=='ROOT_QUALIFIED_GENUINE_OWNED_KERNEL_UTILITY_FIVE_ACTUAL_CASES_FOUR_PYTHON_CHILDREN'
    assert actual['subjectKernelSourceFreeze']==KERNEL_SOURCE_FREEZE
    assert actual['bootstrapFreeze']==UTILITY_SOURCE_FREEZE
    # This field is the historical C10c loader subject in the actual receipt.
    assert actual['subjectBootstrapFreeze']==HISTORICAL_LOADER_SOURCE_FREEZE
    assert tuple(actual['actualCaseIds'])==EXPECTED_IDS
    assert actual['actualTests']==5 and actual['actualPythonChildren']==4 and actual['actualOriginalPipesClosed']==24
    assert actual['RootExternalGlobalCensuses']==3 and actual['completeFeaturesUnchanged']==5
    for key in('actualStandardCleanupsQualified','all714SourceBinaryPinsUnchanged','all743OldOriginalBodiesUnchanged','twoCompleteOwnOutputCensusesEqual'):assert actual[key]is True
    for key in('audioQualified','emoteQualified','deviceQualified','nativeQualified','wholeQualified'):assert actual[key]is False
    assert actual['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
    report=actual['actualReport'];assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==5 and report['PythonExecutions']==4
    assert report['fatal']is None
    for key in('cleanupEstablished','fdUnchanged','threadsUnchanged','kernelChildrenUnchanged','pinsUnchanged','twoToyCensusesEqual','allActualLoadedOriginsAccounted'):assert report[key]is True
    for key in('NodeExecutions','SDKExecutions','overteNativeQueries'):assert report[key]==0
    assert report['realNetwork']is False and report['nativeQualified']is report['wholeQualified']is False
    outer=actual['originalSupervisorTerminal'];assert outer['status']=='PASS'and outer['childReturnCode']==0 and outer['PythonExecutions']==4 and outer['NodeExecutions']==0
    for key in('actualFourGenuineUtilityChildrenEstablished','actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allTwoActualRuntimeOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','ownProcessesAbsent','twoFullOwnOutputCensusesEqual'):assert outer[key]is True
    assert outer['forcedKill']is outer['timedOut']is False and outer['problems']==outer['orphansRequiredKill']==outer['fullOwnCensusExclusions']==[]
    origins=actual['actualSubjectOrigins'];assert set(origins)=={'kernel','test_owned_kernel_discovery'}
    for name,sha in(('kernel',KERNEL_SHA),('test_owned_kernel_discovery',TEST_SHA)):
        assert origins[name]['sha256']==sha;checked(origins[name]['path'],sha)
        assert Path(origins[name]['path']).name==name+'.py'
    children=actual['actualChildren'];assert len(children)==4
    assert len({(c['birth']['pid'],c['birth']['startTicks'])for c in children})==4
    for child in children:
        assert child['returnCode']==0 and child['actualKernelAbsent']is child['allThreeParentStreamsClosed']is True
        assert child['actualStat']['pid']==child['birth']['pid']and child['actualStat']['startTicks']==child['birth']['startTicks']
        assert len(child['pipes'])==6 and {row['name']for row in child['pipes']}=={'p2cread','p2cwrite','c2pread','c2pwrite','errread','errwrite'}
        for row in child['pipes']:
            assert row['sameOriginalStillLive']is False and row['state']=='EBADF'
            assert set(row['original'])=={'device','fd','inode','mode'}
    checked(Path(__file__).resolve(strict=True).with_name('kernel.py'),KERNEL_SHA)
    roots=actual['newOriginalRoots'];assert len(roots)==len(set(roots))==3
    assert all(Path(name).is_absolute()for name in roots)
    return dict(rootProof=dict(value),kernelSourceFreeze=KERNEL_SOURCE_FREEZE,utilitySourceFreeze=UTILITY_SOURCE_FREEZE,
        historicalLoaderSubjectFreeze=HISTORICAL_LOADER_SOURCE_FREEZE,actualCases=list(EXPECTED_IDS),actualChildren=4,
        featureQualification=False,newOriginalRoots=roots,physicalFiles=physical)
