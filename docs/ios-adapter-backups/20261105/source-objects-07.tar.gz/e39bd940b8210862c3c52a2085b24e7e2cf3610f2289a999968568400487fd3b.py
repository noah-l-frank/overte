from pathlib import Path
import ast,hashlib,json,difflib
r=Path.cwd();t=r/'.ios-host-tmp';p=t/'lifecycle-original-wda-session-route-overlay-20261028';p.chmod(0o700)
app=Path('/usr/local/lib/overte-ios-remotexpc/5.15.3-r12/appium')
def sha(x):return hashlib.sha256(x).hexdigest()
def replace(s,a,z):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
rows=[];diff=''
# This is the ACTUAL nested dependency of XCUITest+its nested WDA16.8.0.
rel='node_modules/appium-xcuitest-driver/node_modules/@appium/base-driver/lib/jsonwp-proxy/proxy.ts';origin=app/rel;raw=origin.read_bytes();s=raw.decode()
s=replace(s,'export class JWProxy {', '''type OriginalDownstreamSessionSource = Readonly<{sessionId: string; epoch: object}>;
const ORIGINAL_DOWNSTREAM_SESSION_EPOCHS = new WeakMap<object, object>();
const ORIGINAL_DOWNSTREAM_SESSION_SOURCES = new WeakMap<object, OriginalDownstreamSessionSource>();

export class JWProxy {''')
s=replace(s,'  cancelActiveRequests(): void {\n', '''  cancelActiveRequests(): void {
    ORIGINAL_DOWNSTREAM_SESSION_EPOCHS.set(this, Object.freeze({}));
    ORIGINAL_DOWNSTREAM_SESSION_SOURCES.delete(this);
''')
s=replace(s,'  getActiveRequestsCount(): number {', '''  getOriginalDownstreamSessionSource(): OriginalDownstreamSessionSource | null {
    const original = ORIGINAL_DOWNSTREAM_SESSION_SOURCES.get(this);
    return original && ORIGINAL_DOWNSTREAM_SESSION_EPOCHS.get(this) === original.epoch
      && this.sessionId === original.sessionId ? original : null;
  }

  getActiveRequestsCount(): number {''')
s=replace(s,'    const newUrl = this.getUrlForProxy(url, method as HTTPMethod);', '''    const newUrl = this.getUrlForProxy(url, method as HTTPMethod);
    // Passive source receipt only. No extra request, session or functional
    // setter. A creation/deletion/cancel entry revokes BEFORE any await.
    const originalCreation = url.endsWith('/session') && method === 'POST';
    const originalDeletion = method === 'DELETE'
      && /\\/session\\/[^/]+\\/?$/.test(nodeUrl.parse(newUrl).pathname ?? '');
    const originalEpoch = originalCreation || originalDeletion ? Object.freeze({}) : undefined;
    if (originalEpoch) {
      ORIGINAL_DOWNSTREAM_SESSION_EPOCHS.set(this, originalEpoch);
      ORIGINAL_DOWNSTREAM_SESSION_SOURCES.delete(this);
    }
    let originalReturnedSessionId: string | undefined;''')
s=replace(s,'          const raw = data.sessionId ?? value?.sessionId;\n          this.sessionId', '          const raw = data.sessionId ?? value?.sessionId;\n          originalReturnedSessionId = typeof raw === \'string\' ? raw : undefined;\n          this.sessionId')
s=replace(s,"      if (Object.hasOwn(data, 'status') && parseInt(data.status as string, 10) !== 0) {\n        throwProxyError(data);\n      }\n      return [", '''      if (Object.hasOwn(data, 'status') && parseInt(data.status as string, 10) !== 0) {
        throwProxyError(data);
      }
      const originalValue = data.value as Record<string, unknown> | undefined;
      if (originalCreation && status === 200 && originalEpoch
          && ORIGINAL_DOWNSTREAM_SESSION_EPOCHS.get(this) === originalEpoch
          && typeof originalReturnedSessionId === 'string'
          && /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}$/.test(originalReturnedSessionId)
          && this.sessionId === originalReturnedSessionId && !originalValue?.error) {
        ORIGINAL_DOWNSTREAM_SESSION_SOURCES.set(this, Object.freeze({
          sessionId: originalReturnedSessionId, epoch: originalEpoch,
        }));
      }
      return [''')
rows.append(('appium-runtime',rel,raw,s,str(origin)))
# Borrow original WDA object/proxy/receipt from that same module instance.
rel='tests/device/ios/appium_wda_host_ops.js';origin=t/'lifecycle-original-owner-route-draft-20261028/candidates/repo'/rel;raw=origin.read_bytes();s=raw.decode()
s=replace(s,"import {randomUUID} from 'node:crypto';", "import {randomUUID} from 'node:crypto';\nimport {WebDriverProxy} from '@appium/base-driver';")
s=replace(s,"const ORIGINAL_KEEPER_ROUTE = Symbol.for('overte.originalKeeperRoute.v1');", "const ORIGINAL_KEEPER_ROUTE = Symbol.for('overte.originalKeeperRoute.v1');\nconst ORIGINAL_WDA_SESSION_GETTER = WebDriverProxy.prototype.getOriginalDownstreamSessionSource;")
s=replace(s,'    const bridge = {\n        async request(operation, args, cleanup = false) {', '''    let wdaBinding = null, wdaBind = null;
    const originalWda = () => {
        const wda = driver.wda, proxy = wda?.jwproxy;
        if (!proxy || Object.getPrototypeOf(proxy) !== WebDriverProxy.prototype ||
            typeof ORIGINAL_WDA_SESSION_GETTER !== 'function' ||
            WebDriverProxy.prototype.getOriginalDownstreamSessionSource !== ORIGINAL_WDA_SESSION_GETTER)
            throw new Error('Original WDA session source unavailable');
        const source = ORIGINAL_WDA_SESSION_GETTER.call(proxy);
        if (!source || typeof source.sessionId !== 'string') throw new Error('Original WDA session source unavailable');
        if (wdaBinding && (wdaBinding.wda.deref() !== wda || wdaBinding.proxy.deref() !== proxy || wdaBinding.source !== source))
            throw new Error('Original WDA session source changed');
        return {wda, proxy, source};
    };
    const bindWda = async () => {
        const current = originalWda();
        if (!wdaBinding) wdaBinding = {wda: new WeakRef(current.wda), proxy: new WeakRef(current.proxy), source: current.source};
        if (!wdaBind) wdaBind = bridge.request('wda-bind', {wdaSessionId: current.source.sessionId});
        await wdaBind;
        originalWda();
    };
    const bridge = {
        async request(operation, args, cleanup = false) {
            // Gate only NEW input. Existing original Up/drain/cleanup remains
            // available if the WDA source is later revoked or disappears.
            if (operation === 'touch-begin') await bindWda();''')
s=replace(s,"                (!cleanup && driver.sessionId !== session)) throw new Error('Original keeper scope changed');\n            return response.result;", "                (!cleanup && driver.sessionId !== session)) throw new Error('Original keeper scope changed');\n            if (operation === 'touch-begin') originalWda();\n            return response.result;")
rows.append(('repo',rel,raw,s,str(origin)))
# Keeper must observe an EXISTING actual FBSession before using its literal route.
rel='tests/device/ios/pymobiledevice3_wda_xctest.py';origin=t/'lifecycle-original-owner-post-wda-pid-overlay-20261028/candidate'/rel;raw=origin.read_bytes();s=raw.decode()
s=replace(s,'import uuid\n','import uuid\nfrom urllib.parse import quote\n')
s=replace(s,'        self.wda=None;self.wda_stop=None;self.touch=None;self.closed=False','        self.wda=None;self.wda_stop=None;self.wda_session=None;self.wda_binding_claimed=False;self.touch=None;self.closed=False')
s=replace(s,"        state=await WdaServiceClient(rsd,port=8100,timeout=2.0)._request_json(\n            'POST','/wda/apps/state',{'bundleId':self.session['archiveBundleId']})", "        if self.wda_session is None:raise LaunchError('session-lifetime')\n        state=await WdaServiceClient(rsd,port=8100,timeout=2.0)._request_json(\n            'POST','/session/'+quote(self.wda_session,safe='')+'/wda/apps/state',{'bundleId':self.session['archiveBundleId']})")
a="        if operation in ('process-read','process-terminate'):"
z="""        if operation=='wda-bind':
            if (set(args)!={'wdaSessionId'} or self.wda_binding_claimed or self.wda_session is not None or self.wda is None or self.wda.done()
                    or type(args['wdaSessionId']) is not str
                    or re.fullmatch('[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}',args['wdaSessionId']) is None):
                raise LaunchError('request')
            # Correlated JSON is NOT a session birth producer. The Appium
            # original proxy receipt is held in its owning process; this side
            # independently queries that EXISTING FBSession on original target.
            self.wda_binding_claimed=True
            original=await WdaServiceClient(rsd,port=8100,timeout=2.0)._request_json(
                'GET','/session/'+quote(args['wdaSessionId'],safe=''))
            if (self.scope(session) is not rsd or self.wda.done() or type(original.get('value')) is not dict
                    or original['value'].get('sessionId')!=args['wdaSessionId']):
                raise LaunchError('session-lifetime')
            self.wda_session=args['wdaSessionId']
            return dict(originalKeeperWdaSessionVersion=1,ownerInstance=self.instance,existingSessionBound=True,
                        nativeTouchSupport=False,resourceRetirementEstablished=False)
        if operation in ('process-read','process-terminate'):"""
s=replace(s,a,z);ast.parse(s);rows.append(('repo',rel,raw,s,str(origin)))
entries=[]
for kind,rel,raw,s,origin in rows:
 out=p/'candidate'/kind/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s);before=p/'base'/kind/rel;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(raw)
 entries.append(dict(kind=kind,path=rel,base=origin,baseSHA256=sha(raw),candidate=str(out),candidateSHA256=sha(s.encode()),AST='PASS' if rel.endswith('.py') else 'UNPARSED SOURCE ONLY'))
 diff+=''.join(difflib.unified_diff(raw.decode().splitlines(True),s.splitlines(True),fromfile='a/'+kind+'/'+rel,tofile='b/'+kind+'/'+rel))
(p/'proposal.diff').write_text(diff);(p/'manifest.json').write_text(json.dumps({'status':'PRIVATE ACTIVE R3 SOURCE UNRUN','entries':entries,'diffSHA256':sha(diff.encode()),'baseDriverSourceVersion':'10.7.2 actual nested XCUITest/WDA dependency, not top-level10.8.0'},indent=2)+'\n');print(json.dumps(entries,indent=2))
