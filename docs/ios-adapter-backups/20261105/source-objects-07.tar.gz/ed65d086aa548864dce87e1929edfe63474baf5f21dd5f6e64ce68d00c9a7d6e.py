"""Existing seventeen phase publisher protocol tests; owned originals retained."""
from pathlib import Path
import hashlib,json,subprocess,unittest

HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics',
       'libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')

def census():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths=[REPO/name for name in names if name]+[Path(__file__).resolve(),HERE/'actual-publication.json']
    rows={};fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    for path in sorted(paths):
        a=path.lstat();raw=path.read_bytes();b=path.lstat()
        before={name:getattr(a,name) for name in fields};after={name:getattr(b,name) for name in fields}
        assert before==after,'Source changed during actual original read: '+str(path)
        rows[str(path.relative_to(REPO))]=dict(stat=after,sha256=hashlib.sha256(raw).hexdigest())
    return rows

before=census();(HERE/'public-shared17-first-before.json').write_text(json.dumps(before,indent=2)+'\n')
print('SOURCE_LAUNCHER_PINS_BEFORE',len(before),flush=True)
result=None
try:
    from pathlib import Path
    import tempfile,threading
    from self_tests import test_phase_witness_publisher as fixture
    original_setup=fixture.PhaseWitnessPublisherTests.setUp
    def retained_setup(self):
        # Equivalent original fixture initialization with one deliberate
        # difference: retained private mkdtemp instead of automatic deletion.
        self.server=fixture.make_server('r'*64,'a'*64)
        self.thread=threading.Thread(target=lambda:self.server.serve_forever(poll_interval=.01),daemon=True);self.thread.start()
        self.addCleanup(self.stop)
        self.url='http://127.0.0.1:'+str(self.server.server_address[1])+'/feature-fixture/v1'
        self.reader=fixture.Client(self.url,'r'*64);self.actor=fixture.Client(self.url,'a'*64)
        self.root=Path(tempfile.mkdtemp(prefix='avatar-publisher-shared17-'));self.root.chmod(0o700)
        print('retained publisher original root',self.root,flush=True)
        self.lock=fixture.ScriptSourceLock(self.root/'script-feature-sources.lock');self.known={};self.okay=True;self.validations=0
        self.area='emotes';self.attach(self.area)
    fixture.PhaseWitnessPublisherTests.setUp=retained_setup
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(fixture.PhaseWitnessPublisherTests)
    assert suite.countTestCases()==17,suite.countTestCases()
    print('EXACT_HOST_CASES',suite.countTestCases(),flush=True)
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
finally:
    if 'original_setup' in locals():fixture.PhaseWitnessPublisherTests.setUp=original_setup
    after=census();(HERE/'public-shared17-first-after.json').write_text(json.dumps(after,indent=2)+'\n')
    assert before==after,'Source/launcher inventory, bytes or metadata changed'
    print('SOURCE_LAUNCHER_PINS_UNCHANGED',len(after),flush=True)
raise SystemExit(result is None or not result.wasSuccessful())
