"""Actual -S -m parent plus six original MP children, fixed30+5; no feature qualification."""
from pathlib import Path
from metadata_reader import pin
from host_common import head
import hashlib,json,os,signal,stat,subprocess,sys,threading,time,traceback
REPO=Path.cwd().resolve(strict=True);HERE=Path(__file__).resolve().parent
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert sys.flags.no_site==1 and sys.flags.optimize==0, 'Explicit no-site and original assertions required'
assert len(sys.argv)==2
INPUT=HERE/'approved-inputs.json';assert hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[1]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert head()==plan['actualPublicHead']
assert plan['status']=='PRIVATE_TABLET_MP_VARIANT_UTILITY_UNRUN_UNQUALIFIED'
recipe=json.loads((HERE/'COUNTER-RESOURCE-RECIPE.json').read_text());selection=recipe['selections'][plan['utilitySelection']]
assert plan['utilitySelection']=='mp3'and plan['cases']==selection['cases']and plan['caseCount']==selection['caseCount']
assert plan['expectedTemporaryDirectories']==selection['TDs']and plan['caseCount']==3 and plan['actualMPChildCount']==6 and plan['maxLiveMPChildren']==2
assert plan['wallSeconds']==30 and plan['killGraceSeconds']==5 and len(plan['cases'])==plan['caseCount']

def checked(path):
    path=Path(path);assert path.resolve().is_relative_to(REPO);return path

def meta(info):return[info.st_dev,info.st_ino,info.st_mode,info.st_uid,info.st_gid,info.st_nlink,info.st_size,info.st_mtime_ns,info.st_ctime_ns]
def census(root):
    result={}
    def visit(path):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):
            names=sorted(item.name for item in path.iterdir());row=dict(stat=meta(info),namespace=names)
            for name in names:visit(path/name)
            assert meta(path.lstat())==meta(info)
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        result[str(path.relative_to(root))]=row
    visit(root);return result

def identity(pid):
    try:text=Path('/proc',str(pid),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    values=text[text.rfind(')')+2:].split()
    return dict(pid=int(text[:text.index('(')].strip()),parent=int(values[1]),group=int(values[2]),session=int(values[3]),startTicks=int(values[19]))
def table():
    result={}
    for path in Path('/proc').iterdir():
        if path.name.isdecimal():
            row=identity(int(path.name))
            if row is not None:result[row['pid']]=row
    return result

def fds():
    result={}
    for path in Path('/proc/self/fd').iterdir():
        try:info=path.stat();result[path.name]=dict(target=os.readlink(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return result

parent_fds=fds();parent_threads=tuple(threading.enumerate())
COLLECTOR=checked(HERE.with_name(HERE.name+'-outer'));assert not COLLECTOR.exists();checked(COLLECTOR).mkdir(mode=0o700)
def save(name,body):
    path=checked(COLLECTOR/name);assert path.parent==COLLECTOR
    with path.open('x')as stream:stream.write(json.dumps(body,sort_keys=True,indent=2)+'\n')
    path.chmod(0o600)

input_before=pin(INPUT);assert input_before['sha256']==sys.argv[1]
save('approved-input-before.json',input_before)
before={name:pin(name)for name in plan['sourceAndBinaryPins']};assert before==plan['sourceAndBinaryPins']
save('source-binary-before.json',before)
initial_names=sorted(path.name for path in HERE.iterdir())
for name in('own-toys','child-receipts','child-logs'):
    path=checked(HERE/name);assert not path.exists();path.mkdir(mode=0o700)
expected_names=sorted(initial_names+['own-toys','child-receipts','child-logs'])
LOGS=HERE/'child-logs';stdin=checked(LOGS/'stdin.eof');stdin.write_bytes(b'')
process=None;born=None;owned={};problems=[];timed_out=False;forced=False;term_at=None;baseline=table();started=time.monotonic()
try:
    with stdin.open('rb')as incoming,(LOGS/'stdout.log').open('xb')as output,(LOGS/'stderr.log').open('xb')as error:
        process=subprocess.Popen([sys.executable,'-S','-B','-m','tablet_mp_variant_utility',str(INPUT),sys.argv[1]],cwd=REPO,
            stdin=incoming,stdout=output,stderr=error,start_new_session=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','TMPDIR':str(HERE/'own-toys'),'PYTHONPATH':str(HERE)})
    born=identity(process.pid);assert born is not None and born['parent']==os.getpid()and born['group']==born['session']==born['pid']
    owned[born['pid']]=born;save('actual-runner-birth.json',born)
    while True:
        actual=table();changed=True
        while changed:
            changed=False
            for pid,row in actual.items():
                if pid in owned:continue
                if row['parent']in owned or row['group']==born['group']or row['session']==born['session']:
                    assert pid not in baseline;owned[pid]=row;changed=True
                    observed=HERE/'child-receipts'/('outer-observed-%s-%s.json'%(pid,row['startTicks']))
                    assert not observed.exists()and identity(pid)==row
                    with observed.open('x')as stream:json.dump(dict(actualKernel=row,source='outer-actual-owned-stat',featureEvidence=False),stream,sort_keys=True);stream.write('\n')
                    observed.chmod(0o600)
                    if len(owned)>7 or row['parent']!=born['pid']:
                        problems.append(dict(kind='unadmitted-child-birth',identity=row))
        live_owned=[pid for pid in owned if identity(pid)is not None and pid!=born['pid']]
        if len(live_owned)>2:problems.append(dict(kind='live-child-cap-exceeded',actualPIDs=live_owned))
        for pid,row in owned.items():
            fresh=identity(pid)
            if fresh is not None and fresh!=row:problems.append(dict(kind='kernel-identity-changed',before=row,after=fresh))
        code=process.poll();elapsed=time.monotonic()-started
        if code is not None:break
        if elapsed>=30 and term_at is None:
            timed_out=True;term_at=time.monotonic();assert identity(born['pid'])==born;os.kill(born['pid'],signal.SIGTERM)
        if term_at is not None and time.monotonic()-term_at>=5:
            forced=True;assert identity(born['pid'])==born;os.kill(born['pid'],signal.SIGKILL);process.wait();break
        time.sleep(.025)
    process.wait()
except BaseException:problems.append(dict(kind='original-parent-exception',traceback=traceback.format_exc()))
finally:
    orphans=[]
    for pid,binding in owned.items():
        actual=identity(pid)
        if actual is not None:
            orphans.append(dict(bound=binding,current=actual))
            if actual==binding:os.kill(pid,signal.SIGKILL)
    if process is not None:process.wait()
    remaining=[dict(bound=row,current=identity(pid))for pid,row in owned.items()if identity(pid)is not None]
    save('actual-process-drain.json',dict(owned=list(owned.values()),orphansRequiredKill=orphans,remaining=remaining,timedOut=timed_out,forced=forced))
    assert not remaining,'No quiet original census while a bound process remains'
    # Entire controller root, including approved-inputs and every metadata,
    # code, output and directory row. These reports are in sibling COLLECTOR.
    first=census(HERE);second=census(HERE)
    save('actual-child-output-first.json',first);save('actual-child-output-second.json',second)
    def child_subtrees(full):
        result={}
        for name in('own-toys','child-receipts','child-logs'):
            assert name in full
            prefix=name+'/'
            result[name]={'.'if key==name else key[len(prefix):]:row for key,row in full.items()if key==name or key.startswith(prefix)}
        return result
    first_children=child_subtrees(first);second_children=child_subtrees(second)
    save('actual-child-subtrees-first.json',first_children);save('actual-child-subtrees-second.json',second_children)
    input_after=pin(INPUT);save('approved-input-after.json',input_after)
    assert head()==plan['actualPublicHead']
    input_unchanged=input_before==input_after and input_before['sha256']==input_after['sha256']==sys.argv[1]
    assert all(name in first and name in second for name in('approved-inputs.json','mp_runner.py','supervise-mp.py','tablet_mp_variant_utility'))
    after={name:pin(name)for name in plan['sourceAndBinaryPins']};save('source-binary-after.json',after)
    receipt_errors=[]
    def read_original(name):
        try:
            value=json.loads((HERE/'child-receipts'/name).read_text())
            assert type(value)is dict,'Original receipt must be an object'
            return value
        except BaseException:
            receipt_errors.append(dict(name=name,available=False,traceback=traceback.format_exc()))
            return None
    report=read_original('report.json');restore=read_original('actual-port-restoration.json')
    selection=read_original('actual-selection.json');origins=read_original('actual-source-model-origins.json')
    origins_ok=False;actual_children=[];child_join=False
    try:
        origins_ok=origins is not None and origins['allActualSubjectOriginsEstablished']is True
        if origins_ok:
            rows=origins['subjectOrigins'];origins_ok=set(rows)==set(plan['subjectOriginModules'])and len(rows)==plan['subjectOriginCount']==3
            for name,expected in plan['subjectOriginModules'].items():
                row=rows.get(name,{})
                origins_ok=origins_ok and row.get('actualModuleFile')==expected['path']
                origins_ok=origins_ok and row.get('actualLoaded')==dict(path=expected['path'],sha256=expected['sha256'])
                origins_ok=origins_ok and pin(expected['path'])['sha256']==expected['sha256']
        actual_children=[];child_join=False
        if report is not None:
            actual_children=report.get('actualChildReceipts',[])
            child_join=len(actual_children)==6 and len({row['actualKernel']['pid']for row in actual_children})==6
            child_join=child_join and sum(row['role']=='actor'for row in actual_children)==3 and sum(row['role']=='tracker'for row in actual_children)==3
            for row in actual_children:
                kernel=row['actualKernel'];expected=owned.get(kernel['pid'])
                child_join=child_join and expected is not None and kernel['startTicks']==expected['startTicks']and kernel['parentPID']==born['pid']
                child_join=child_join and row['status']=='PASS'and identity(kernel['pid'])is None
                child_join=child_join and row['portRestoration']['all27OriginalPortsRestored']is True
                command=row['actualCommand']['originalCommandSha256']
                main_rows=row['beforeOriginalEntry']['modules']
                child_join=child_join and all(main_rows[name]['kind']=='interpreter-command'and main_rows[name]['role']==row['role']and main_rows[name]['originalCommandSha256']==command for name in('__main__','__mp_main__'))
                child_join=child_join and row['actualCommand']['actualMainFile']is None and row['actualCommand']['actualMainSpec']is None and row['actualCommand']['noSyntheticModuleOrSpec']is True
                if row['role']=='actor':
                    child_join=child_join and row['guardVerifiedBeforeOriginalEntry']is True and len(row['unpickleCalls'])==2
                    child_join=child_join and row['targetStarted']is True and row['targetReturned']is True
                    child_join=child_join and [call['ordinal']for call in row['unpickleCalls']]==[1,2]and all(call['guardWasReady']is True for call in row['unpickleCalls'])
                    if row['actualMode']=='hostile':
                        child_join=child_join and len(row['hostileRefusals'])==5 and len({r['kind']for r in row['hostileRefusals']})==5 and all(r['beforeUnpickle']is True for r in row['hostileRefusals'])
                        child_join=child_join and row['actualOwnedNegativeSourceAtRefusal']['sha256']!=row['actualOwnedNegativeSourceOriginal']['sha256']==row['actualOwnedNegativeSourceRestoredBytes']['sha256']
                    retirement=next((r for r in report['retirements']if r['actualCaseRoot']==row['actualCaseRoot']),None)
                    child_join=child_join and retirement is not None and retirement['status']=='PASS'
                    if retirement is not None:
                        actual_sem=row['actualRebuiltSemLock'];parent_sem=retirement['originalRetirement']['actualSemaphoreRows']
                        child_join=child_join and len(parent_sem)==1 and (actual_sem['name'],actual_sem['device'],actual_sem['inode'])==(parent_sem[0]['name'],parent_sem[0]['device'],parent_sem[0]['inode'])
                        child_join=child_join and retirement['originalRetirement']['originalSemaphoreNamesAbsent']is True and retirement['originalRetirement']['trackerStatAbsent']is True
                        child_join=child_join and all(r['afterState']in('EBADF','REUSED_DIFFERENT_IDENTITY')for r in retirement['originalRetirement']['actualOriginalPipeRetirements'])
                        if row['actualMode']=='lifetime':child_join=child_join and len(retirement['actualNegativeRows'])==1 and retirement['actualNegativeRows'][0]['actualLiveKernelBefore']==retirement['actualNegativeRows'][0]['actualLiveKernelAfter']
        child_join=child_join and len(owned)==7
    except BaseException:
        origins_ok=False;child_join=False
        receipt_errors.append(dict(name='actual-original-receipt-schema-and-joins',available=False,traceback=traceback.format_exc()))
    parent_fd_after=fds();parent_thread_after=tuple(threading.enumerate())
    save('actual-parent-drain.json',dict(fdsEqual=parent_fds==parent_fd_after,threadsEqual=parent_threads==parent_thread_after))
    passed=process is not None and process.returncode==0 and not problems and not orphans and not remaining and not timed_out and not forced
    passed=passed and first==second and first_children==second_children and input_unchanged and before==after and parent_fds==parent_fd_after and parent_threads==parent_thread_after
    passed=passed and sorted(path.name for path in HERE.iterdir())==expected_names
    try:
        passed=passed and report is not None and report['status']=='PASS'and report['testsRun']==plan['caseCount']and report['actualCaseReceipts']==plan['caseCount']
        passed=passed and selection is not None and selection['ids']==plan['cases']and not selection['loaderErrors']
        passed=passed and origins_ok and child_join and report['allActualSubjectOriginsEstablished']is True and report['originalStandardCleanupEstablished']is True and report['allExtraFDsActualArenaOwned']is True
        passed=passed and restore is not None and restore['allCasePortsRestored']and restore['actualOSPortCount']==27 and restore['unittestCleanupRestored']and restore['localToolsRestored']and restore['originalFilePhase']['original27PortsRestored']and not restore['originalFilePhase']['controlFDs']and restore['actualHelperSha256']==plan['subjectHelperSha256']
        passed=passed and not receipt_errors and restore.get('passed')is True and not restore.get('finalizationErrors')and not restore.get('unavailableOriginalReceipts')
    except BaseException:
        passed=False
        receipt_errors.append(dict(name='actual-original-pass-gates',available=False,traceback=traceback.format_exc()))
    terminal=dict(status='PASS'if passed else'FAIL_OR_REFUSED',childReturnCode=None if process is None else process.returncode,
        elapsedSeconds=time.monotonic()-started,problems=problems,unavailableOrMalformedOriginalReceipts=receipt_errors,timedOut=timed_out,forcedKill=forced,
        ownProcessesAbsent=not remaining,orphansRequiredKill=orphans,twoFullOwnOutputCensusesEqual=first==second,
        fullOwnCensusRoot=str(HERE),fullOwnCensusExclusions=[],approvedInputsExactPinAndCliShaUnchanged=input_unchanged,
        originalChildSubtreesCensusesEqual=first_children==second_children,
        allSourceBinaryPinsEqual=before==after,actualStdlibParentFDThreadDrain=parent_fds==parent_fd_after and parent_threads==parent_thread_after,
        allActualSubjectOriginsEstablished=origins_ok,actualSixOriginalChildrenJoined=child_join,actualBoundChildren=None if born is None else len(owned)-1,actualParentExitDischargedCachedMappings=process is not None and process.returncode is not None and not remaining,
        utilitySelection=plan['utilitySelection'],caseCount=plan['caseCount'],NodeExecutions=0,movingQualified=False,nativeQualified=False,helperVariantQualified=False,featureQualified=False,globalScans=0)
    save('terminal.json',terminal)
# After the terminal write there are NO further HERE/outer writes. Whole
# snapshots and qualification are outside both covered roots, without exclusions.
CENSUSES=checked(HERE.with_name(HERE.name+'-censuses'))
assert not CENSUSES.exists();CENSUSES.mkdir(mode=0o700)
assert all(identity(pid)is None for pid in owned)
whole_first=dict(HERE=census(HERE),outer=census(COLLECTOR))
whole_second=dict(HERE=census(HERE),outer=census(COLLECTOR))
for name,value in(('whole-first.json',whole_first),('whole-second.json',whole_second)):
    target=CENSUSES/name
    with target.open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    target.chmod(0o600)
qualified=passed and whole_first==whole_second and all(identity(pid)is None for pid in owned)
with(CENSUSES/'qualification.json').open('x')as stream:
    json.dump(dict(status='PASS'if qualified else'FAIL_OR_REFUSED',utilitySelection=plan['utilitySelection'],
        actualCases=plan['caseCount'],priorTerminalPassed=passed,twoCompleteHEREAndOuterCensusesEqual=whole_first==whole_second,
        noCensusExclusions=True,ownProcessesAbsent=all(identity(pid)is None for pid in owned),
        originalRoots=[str(HERE),str(COLLECTOR),str(CENSUSES)],helperVariantQualified=False,featureQualified=False),stream,sort_keys=True,indent=2);stream.write('\n')
(CENSUSES/'qualification.json').chmod(0o600)
raise SystemExit(0 if qualified else 1)
