"""Private same-selection diagnostics; keep only this worktree's new temp roots."""
from pathlib import Path
import tempfile
import unittest

keep_root=Path.cwd()/'.ios-host-tmp'
actual_directory=tempfile.TemporaryDirectory
retained=[]
class RetainedSnapshotDirectory(actual_directory):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self._snapshot_keep=Path(self.name).resolve().is_relative_to(keep_root.resolve())
        if self._snapshot_keep:
            self._finalizer.detach();retained.append(self.name)
    def cleanup(self):
        if not getattr(self,'_snapshot_keep',False):return super().cleanup()

tempfile.TemporaryDirectory=RetainedSnapshotDirectory
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name) for name in ['test_ios_snapshot_combined_journey.SnapshotCombinedJourneyTests.test_lost_conditional_unlink_return_reopens_original_without_second_delete_or_capture', 'test_ios_snapshot_combined_journey.SnapshotCombinedJourneyTests.test_default_profile_cannot_adopt_combined_pair_or_issue_file_removal', 'test_ios_snapshot_combined_journey.SnapshotCombinedJourneyTests.test_new_capture_manager_cannot_reanchor_pending_pair_or_authorize_unlink', 'test_ios_snapshot_journey_files.SnapshotJourneyFilesTests'])
result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
for path in retained:print('Retained original temporary root:',path,flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
