from pathlib import Path
import hashlib,json,sys,unittest
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
def sources():
 files={p for p in (ROOT/'tests/device').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
 files.update(p for p in (ROOT/'scripts').rglob('*.js') if p.is_file())
 files.update(p for p in (ROOT/'interface/resources/qml/hifi').rglob('*.qml') if p.is_file())
 files.add(Path(__file__).resolve())
 return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
before=sources();(OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
from ios.self_tests.test_ios_avatar_peer_template_binding import AvatarPeerTemplateBindingTests
from ios.self_tests.test_ios_avatar_feature import AvatarFeatureLocksTests
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(AvatarPeerTemplateBindingTests),unittest.defaultTestLoader.loadTestsFromTestCase(AvatarFeatureLocksTests)])
result=unittest.TextTestRunner(verbosity=2).run(suite)
after=sources();(OUT/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
if before!=after:raise AssertionError('Complete selected source/launcher inventory changed')
print('Complete source/launcher SHA inventory unchanged: '+str(len(after)),flush=True)
sys.exit(not result.wasSuccessful())
