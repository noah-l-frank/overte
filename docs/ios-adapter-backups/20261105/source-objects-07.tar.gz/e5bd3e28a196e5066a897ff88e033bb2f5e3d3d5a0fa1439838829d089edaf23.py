"""One real outer native bracket for fresh original Audio read-only responses.

No current observation or clock is reused. Existing actual NativeInput and
IOSAudioSettings/Session transports issue their ordinary nonce once and read
original responses. Their unchanged codecs validate against the real final
NativeAfter, within the unchanged outer1.5s join. Ordinary .read/.capture stay.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import json,time,uuid
from adapters.native_clock_join import digest
from adapters.native_feature_observation import decode,need,number
from adapters.script_feature.history import same
from ios.adapters.normal_input import NativeInput
from ios.adapters.audio_settings_source import IOSAudioSettings
from ios.adapters.audio_session_source import IOSAudioSession


def supported(source,readers):
    return type(source['native'])is NativeInput and type(readers['settings'])is IOSAudioSettings and type(readers['session'])is IOSAudioSession


def function(value):
    return (id(getattr(value,'__self__',None)),id(getattr(value,'__func__',value)),id(getattr(getattr(value,'__func__',value),'__code__',None)))


class AudioOuterOriginalAcquisition:
    def __init__(self,source,readers,run,*,monotonic):
        need(supported(source,readers));self.source,self.readers,self.run=source,readers,run
        self.native=source['native'];self.before=None;self.pid=int(source['binding']['processIdentity']);self.monotonic=monotonic
        need(self.pid==readers['settings'].pid==readers['session'].pid)
        self.reader_objects={kind:readers[kind]for kind in ('settings','session')};self.session=source['session'];self.target=deepcopy(source['target'])
        self.binding=deepcopy(source['binding']);self.components={key:source[key]for key in ('client','native','clock_source','check')}
        self.receivers=[(self.native,name,function(getattr(self.native,name)))for name in ('_request','_check','_accept_observation')]
        for kind in ('settings','session'):
            reader=readers[kind]
            self.receivers.extend((reader,name,function(getattr(reader,name)))for name in ('send','original','guard','_command','_validate'))
        self.values={};self.ui=None;self.receipt=None;self.guard()
    def guard(self):
        need(same(self.source['binding'],self.binding)and self.source['session']==self.session and same(self.source['target'],self.target)
            and all(self.source[key]is value for key,value in self.components.items())
            and all(self.readers[kind]is reader and reader.pid==self.pid for kind,reader in self.reader_objects.items()))
        for obj,name,token in self.receivers:need(function(getattr(obj,name))==token)
        need(self.source['check']()is not False);return True
    def bind_before(self,before):
        self.guard();need(self.before is None and before['processId']==self.pid)
        self.before=deepcopy(before)
    def ui_original(self):
        self.guard();need(self.ui is None and self.before is not None)
        # Exact same existing read-only _request, including its real original
        # intent, one-send nonce, return/AFC receipt and original SDK checks.
        self.ui=self.native._request('observe');self.receipt=deepcopy(self.native.last_receipt)
        need(self.receipt is not None and same(self.receipt['observation'],self.ui));self.guard()
        return deepcopy(self.ui)
    def reader_original(self,kind):
        need(kind in ('settings','session')and kind not in self.values);self.guard();reader=self.readers[kind]
        before=self.monotonic();previous=deepcopy(reader.last)
        query=reader._command(dict(schemaVersion=1,commandId='ios-'+uuid.uuid4().hex,action=reader._action,runId=self.run))
        need(reader.guard()is not False);reader.send(deepcopy(query));last=before
        for attempt in range(61):
            self.guard();need(reader.guard()is not False);raw=reader.original()
            need(type(raw)is str and len(raw.encode())<=reader._limit)
            try:value=decode(raw,limit=reader._limit)if raw else None
            except json.JSONDecodeError:value=None
            now=self.monotonic();need(number(now,last,before+1.5)and now-before<1.5);last=now
            if type(value)is dict and value.get('requestId')==query['commandId']:
                self.values[kind]=dict(query=deepcopy(query),value=deepcopy(value),previous=previous,before=before,rawSha256=digest(value))
                self.guard();return deepcopy(value)
            if attempt<60:reader.sleep(.025)
        need(False)
    def accept(self,after):
        self.guard();need(self.ui is not None and set(self.values)=={'settings','session'}and after['processId']==self.pid
            and after['instance']==self.before['instance']and after['sequence']>self.before['sequence'])
        epoch=after['capturedEpochMs'];need(0<=epoch-self.before['capturedEpochMs']<1500)
        need(same(self.native.last_receipt,self.receipt))
        ended=self.monotonic()
        for kind,row in self.values.items():
            reader=self.readers[kind];value=row['value'];need(same(reader.last,row['previous'])and digest(value)==row['rawSha256'])
            reader._validate(value,row['query'],self.pid,epoch,row['previous'])
            need(value['instance']==after['instance']and value['lifecycle']==after['lifecycle']
                and value['clockBefore']['epochMs']>=self.before['capturedEpochMs']and value['clockAfter']['epochMs']<=epoch
                and 0<=ended-row['before']<1.5 and reader.guard()is not False)
        # This factors the exact existing NativeInput.capture acceptance path.
        # The raw UI packet/receipt is unchanged; no fabricated native time.
        self.native._check();ui=self.native._accept_observation(deepcopy(self.ui),epoch);self.guard()
        for kind,row in self.values.items():
            reader=self.readers[kind];reader.last=deepcopy(row['value'])
            reader.acquisition=dict(hostBeforeMonotonic=row['before'],hostAfterMonotonic=ended,
                nativeRequestedEpochMs=self.before['capturedEpochMs'],nativeAfterEpochMs=epoch,originalSha256=row['rawSha256'],
                nativeBeforeOriginalFloorSha256=digest(self.before));reader.acquisition[reader._acquisition_key]=1
        return ui
