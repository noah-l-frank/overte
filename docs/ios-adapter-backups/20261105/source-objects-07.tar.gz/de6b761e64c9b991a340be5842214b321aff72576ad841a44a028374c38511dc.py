"""Retain actual fourteen controls and the separate genuine three-MP result."""
from pathlib import Path
import json,hashlib
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(o,n,v):
 with(o/n).open('x')as s:json.dump(v,s,sort_keys=True,indent=2);s.write('\n')
C=B/'root-tablet-b7-baseline6-transaction8-window-current1193-20261105'
assert sha(C/'freeze.json')=='cc9265ef7cd82e7af6e583a1941d8685935c53b1974466d1249f2a53217b0f70'
for n,r in load(C/'freeze.json')['files'].items():assert sha(C/n)==r['sha256']
t=load(C/'terminal.json');assert t['status']=='ROOT_TABLET_B7_BASELINE_TRANSACTION_ORIGINAL_HOST_GROUP_COMPLETED'and t['oldRootCount']==1193
assert t['allOldOriginalBodiesUnchanged']is t['wholeOwnOutputsTwiceEqual']is t['allExecutedOwnedProcessesAbsent']is True
assert [g['group']for g in t['groups']]==['baseline6','transaction8']and t['unrunGroups']==[]
reports=[]
for group,count in zip(t['groups'],(6,8)):
 h=Path(group['input']).parent;o=h.with_name(h.name+'-outer');c=h.with_name(h.name+'-censuses')
 assert sha(h/'approved-inputs.json')==group['inputSha256']
 terminal=load(o/'terminal.json');q=load(c/'qualification.json');assert terminal==group['originalTerminal']and q==group['originalQualification']
 assert group['supervisorReturnCode']==terminal['childReturnCode']==0 and terminal['status']==q['status']=='PASS'
 assert terminal['ownProcessesAbsent']is q['ownProcessesAbsent']is q['noCensusExclusions']is True
 assert terminal['problems']==terminal['orphansRequiredKill']==[]and terminal['timedOut']is terminal['forcedKill']is False
 report=load(h/'child-receipts/report.json');assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==count and report['fatal']is None
 assert len(report['retainedTemporaryDirectories'])==count and report['temporaryDirectoryAbsenceClaimed']is False
 for key in('fdUnchanged','kernelChildrenUnchanged','threadsUnchanged','pinsUnchanged','cleanupEstablished','twoToyCensusesEqual','allActualLoadedOriginsAccounted'):assert report[key]is True
 restore=load(h/'child-receipts/actual-port-restoration.json');assert restore['count']==27 and restore['controlDescriptors']==[]
 for key in('restored','dupPortsRestored','builtinsCioRestored','toolsRestored'):assert restore[key]is True
 assert restore['actualVariantHelperSha256']=='a7977c6b9399a94df0cd9e6b44729e76ce67cbb121998d787dc5b97f27d74f44'
 drain=load(o/'actual-process-drain.json');assert drain['remaining']==drain['orphansRequiredKill']==[]
 for row in drain['owned']:
  try:raw=Path('/proc',str(row['pid']),'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  assert int(raw[raw.rfind(')')+2:].split()[19])!=row['startTicks']
 reports.append(dict(group=group['group'],report=report,restoration=restore))
ctx=load(B/'root-ios-current1193-after-tablet-b7-mp3-positive-context-20261105/root-context.json');old=load(ctx['globalCustody']['baseline']['path'])
assert len(old)==1193 and load(C/'global-before.json')==load(C/'global-after-first.json')==load(C/'global-after-second.json')==old
assert load(C/'whole-output-first.json')==load(C/'whole-output-second.json')
prior=B/'root-tablet-b7-mp3-three-original-host-positive-results-20261105'
assert sha(prior/'freeze.json')=='b1db82b9dcc7e7b824aeeb0b22b549d77b74f3a8b1d7f7a1e5c381bf13ffe839'
for n,r in load(prior/'freeze.json')['files'].items():assert sha(prior/n)==r['sha256']
for row in load(prior/'actual-receipt-references.json').values():assert sha(row['path'])==row['sha256']
mp=load(prior/'results.json');assert mp['actualCases']==3 and mp['actualOriginalChildren']==6 and mp['originalReport']['status']=='PASS'
roots=t['newOriginalRoots'];assert len(roots)==7
refs={str(p):dict(path=str(p),sha256=sha(p))for root in map(Path,roots)for p in sorted(root.rglob('*'))if p.is_file()and not p.is_symlink()}
for p in prior.iterdir():refs[str(p)]=dict(path=str(p),sha256=sha(p))
out=B/'root-tablet-b7-fourteen-plus-three-original-host-controls-results-20261105';out.mkdir(mode=0o700)
custody=dict(childReturnCode=0,returnCodeScope='Both actual original supervisors and runners returned0; original terminals retained separately',ownProcessesAbsent=True,problems=[],timedOut=False,forcedKill=False)
put(out,'results.json',dict(status='ROOT_QUALIFIED_CURRENT_TABLET_VARIANT_SEVENTEEN_ORIGINAL_HOST_CONTROLS',terminal=custody,originalRootTerminal=t,newOriginalRoots=roots,actualNewCases=14,separatePreviousMPCases=3,actualSeventeenControlsPassed=True,helperSha256='a7977c6b9399a94df0cd9e6b44729e76ce67cbb121998d787dc5b97f27d74f44',bootstrapFreeze='7e54930076aec3c0545c1cbf2707ca3a92f2ed0ef48ae273ed2e67ceb03091e3',originalReports=reports,previousMPProof=dict(path=str(prior/'freeze.json'),sha256=sha(prior/'freeze.json')),consumerAdmission=None,normalFeatureCaseQualified=False,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(out,'actual-receipt-references.json',refs);put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}));print(json.dumps(dict(freeze=sha(out/'freeze.json'),results=sha(out/'results.json'),references=len(refs))))
