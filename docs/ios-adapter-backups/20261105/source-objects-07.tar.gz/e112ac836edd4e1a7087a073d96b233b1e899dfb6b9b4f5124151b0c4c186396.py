"""Utility-owned writer lifetimes; never product or native authority."""
from pathlib import Path
from types import SimpleNamespace,FrameType
import hashlib,io,json,os,signal,subprocess,sys,tempfile,threading,traceback
from avatar_ports import AvatarPorts
from entry_observer import EntryObserver
from owned_write_boundary import OwnedWrites
from prefix_common import save
from utility_common import REPO

ACTIVE=None


class AfterActualBirth(RuntimeError):pass


class UtilityMonitor:
    """Retain genuine communicate outputs and one actual post-birth fault."""
    def __init__(self,runtime):
        self.runtime=runtime;self.tool=None;self.inject=False;self.fired=False;self.owner=None
        self.popen=subprocess.Popen.__init__;self.communicate=subprocess.Popen.communicate
        self.bindings=tuple((function,function.__code__,function.__globals__)for function in(self.popen,self.communicate))
        self.name='avatar-boundary-own-actual-outputs-'+str(os.getpid())+'-'+str(id(self))
    def start(self):
        m=sys.monitoring;free=[x for x in(2,5,4,3,1,0)if m.get_tool(x)is None];assert free
        self.m=m;self.tool=free[0];m.use_tool_id(self.tool,self.name)
        m.register_callback(self.tool,m.events.PY_RETURN,self.returned)
        for function,code,namespace in self.bindings:m.set_local_events(self.tool,code,m.events.PY_RETURN)
        assert m.get_events(self.tool)==0;return self
    def returned(self,code,offset,value):
        binding=next((row for row in self.bindings if row[1]is code),None);assert binding is not None
        function,unused,namespace=binding;frame=sys._getframe(1)
        assert type(frame)is FrameType and frame.f_code is code and frame.f_globals is namespace and function.__code__ is code
        owner=frame.f_locals.get('self');ports=self.runtime.ports
        row=next((row for row in ports.births if row['process']is owner),None)
        if code is self.popen.__code__:
            if not self.inject:return
            assert not self.fired and row is not None and row['kind']=='openssl'
            # Actual Popen frame, PID/stdio and kernel object. This invokes the
            # unchanged existing reader if callback order has not read it yet.
            ports.popen_returned(frame)
            assert row['birth']is not None and type(owner.pid)is int
            self.owner=owner;self.fired=True
            raise AfterActualBirth('Utility fault after actual birth, before caller receives original Popen')
        if row is None:return
        assert type(value)is tuple and len(value)==2
        for label,raw in zip(('stdout','stderr'),value):
            assert raw is None or type(raw)is bytes
            if raw is not None:self.runtime.raw(label,raw)
        self.runtime.communicates.append(dict(pid=owner.pid,returnCode=owner.returncode,actualReturnedTuple=True))
    def stop(self):
        if self.tool is None:return
        m=self.m;t=self.tool;assert m.get_tool(t)==self.name
        for function,code,namespace in self.bindings:m.set_local_events(t,code,0);assert m.get_local_events(t,code)==0
        m.register_callback(t,m.events.PY_RETURN,None);assert m.get_events(t)==0;m.free_tool_id(t);self.tool=None


class Runtime:
    def __init__(self,root,plan,proc):
        self.root=Path(root);self.temp=self.root/'temporary';self.plan=plan;self.proc=proc
        self.outer=None;self.owner=None;self.ports=None;self.entry=None;self.monitor=None
        self.original_flock=None;self.protected=tuple(Path(p)for p in plan['physicalPins'])
        self.retained=[];self.rescues=[];self.communicates=[];self.raw_records=[];self.case_records=[]
        self.real_td=tempfile.TemporaryDirectory;self.real_tempdir=tempfile.tempdir;self.tls_alias=None
        self.stdout_paths=tuple(Path(os.readlink('/proc/self/fd/'+str(fd))).resolve(strict=True)for fd in(1,2))
        self.pid_rows=[]
        self.case=None;self.case_index=0
    def boot(self):
        global ACTIVE
        assert ACTIVE is None;ACTIVE=self
        self.outer=OwnedWrites(self.root,protected=self.stdout_paths);self.outer.install();self.owner=self.outer
        return self
    def audit(self,event,args,caller):
        if event.startswith('socket.')and(self.ports is None or self.owner is not self.ports):raise RuntimeError('Network outside genuine TLS case boundary')
        if event=='subprocess.Popen':
            if self.owner is not self.ports or self.ports is None:raise RuntimeError('Process outside actual selected TLS boundary')
            if os.path.basename(os.fsdecode(args[0]))!='openssl':raise RuntimeError('Utility permits original OpenSSL only, never Node')
        if event=='os.kill':
            frame=caller;found=None
            while frame is not None:
                if frame.f_code is subprocess.Popen.send_signal.__code__ and frame.f_globals is subprocess.Popen.send_signal.__globals__:
                    found=frame.f_locals.get('self');break
                frame=frame.f_back
            row=next((row for row in self.ports.births if row['process']is found),None)if self.ports is not None else None
            assert row is not None and row['birth']is not None and args[0]==found.pid and self.proc(found.pid)==row['birth']
            return
        if self.owner is None:
            # Read-only transitions, never a broad inactive mutation exception.
            if event=='open':
                unused,mode,flags=args
                if flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)or type(mode)is str and any(x in mode for x in 'wax+'):
                    raise RuntimeError('Write during owner handoff')
            elif event.startswith(('socket.','fcntl.'))or event in('os.mkdir','os.remove','os.rmdir','os.rename','os.chmod','os.chown','os.utime','os.truncate','os.link','os.symlink'):
                raise RuntimeError('Mutation during owner handoff')
            return
        if self.owner is self.ports:self.ports.audit(event,args,caller)
        else:self.outer.audit(event,args,caller)
    def enter(self,test):
        global ACTIVE
        assert ACTIVE is self and self.owner is self.outer and self.case is None
        self.outer.close();self.owner=None;self.case=test;self.case_index+=1
        test.addCleanup(self.leave)
        self.PROTECTED=self.stdout_paths
        # Same unchanged actual Prefix4 class; originals are captured while all
        # aliases are restored, not from another active wrapper namespace.
        env=hashlib.sha256(json.dumps(dict(os.environ),sort_keys=True,separators=(',',':')).encode()).hexdigest()
        self.ports=AvatarPorts(self.temp,self.root,save,globals(),sys._getframe(),expected_node=(),node_pin=self.plan['executables']['node'],environment_digest=env,openssl_pin=self.plan['executables']['openssl'])
        # The borrowed adapter reads the actual namespace's plan/PROTECTED.
        globals()['plan']=self.plan;globals()['PROTECTED']=self.stdout_paths
        self.ports.bind_callbacks(tuple(function for name,function in type(self).__dict__.items()if hasattr(function,'__code__')))
        self.ports.install();self.owner=self.ports
        self.entry=EntryObserver(self.ports).start()
        for name in('feature_journeys.server','self_tests.test_account_provider','ios.self_tests.avatar_people_node'):
            self.entry.imported(name,sys.modules[name])
        self.monitor=UtilityMonitor(self).start()
        self.outputs_index=0
        tempfile.tempdir=str(self.temp)
        tls=sys.modules['self_tests.test_account_provider'];assert tls.tempfile is tempfile
        self.tls_alias=(tls,tls.tempfile);tls.tempfile=SimpleNamespace(TemporaryDirectory=self.directory)
        test.directory=self.directory();test.path=Path(test.directory.name)
        test.addCleanup(test.directory.cleanup)
    def directory(self,*args,**kwargs):
        assert kwargs.get('dir')is None
        value=self.real_td(*args,**kwargs);path=Path(value.name);assert path.parent==self.temp and path.resolve(strict=True)==path
        from ios.self_tests.retained_host_roots import retain_owned_root
        retain_owned_root(value,expected_root=path);self.retained.append(str(path));return value
    def raw(self,label,raw):
        self.outputs_index+=1;path=self.root/('case-'+str(self.case_index)+'-actual-'+str(self.outputs_index)+'-'+label+'.raw')
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
        self.raw_records.append(dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    def tls(self):
        cls=sys.modules['self_tests.test_account_provider'].AccountProviderTests
        # The original method owns key/cert/TLS creation. Its original teardown
        # is registered before invocation so a post-birth failure retains it.
        self.case.addCleanup(cls.tearDownClass);cls.setUpClass();return cls
    def drain_partial(self,owner):
        row=next(row for row in self.ports.births if row['process']is owner);assert row['birth']is not None
        before=dict(row['birth']);timed_out=False
        try:owner.communicate(timeout=10)
        except subprocess.TimeoutExpired:
            timed_out=True;owner.kill();owner.communicate(timeout=5)
        owner.wait(timeout=5)
        for stream in(owner.stdin,owner.stdout,owner.stderr):
            if stream is not None and not stream.closed:stream.close()
        current=self.proc(owner.pid);absent=current is None or current['startTicks']!=before['startTicks']
        record=dict(pid=owner.pid,originalBirth=before,callerReturnEstablished=False,originalTLSSetupEstablished=False,
            actualControllerRescue=True,rescueTimedOut=timed_out,returnCode=owner.returncode,processAbsent=absent,
            originalStreamsClosed=all(stream is None or stream.closed for stream in(owner.stdin,owner.stdout,owner.stderr)))
        self.rescues.append(record);assert absent and record['originalStreamsClosed'];return record
    def leave(self):
        failures=[]
        def attempt(label,call):
            try:return call()
            except BaseException:failures.append(dict(check=label,traceback=traceback.format_exc()));return None
        if self.monitor is not None:self.monitor.inject=False
        try:
            for row in self.ports.births if self.ports is not None else():
                p=row['process']
                def drain(p=p,row=row):
                    if row['birth']is None:
                        for name in('stdin','stdout','stderr'):
                            stream=getattr(p,name,None)
                            if stream is not None and not stream.closed:stream.close()
                        raise RuntimeError('Partial original Popen has no proven birth; no absent-process authority')
                    if p.poll()is None or any(s is not None and not s.closed for s in(p.stdin,p.stdout,p.stderr)):self.drain_partial(p)
                attempt('actual-owned-process-drain',drain)
            for thread,helper,root in self.ports.helper_records if self.ports is not None else():
                if thread is not self.ports.main:
                    def joined(thread=thread,helper=helper):thread.join(timeout=5);assert not thread.is_alive()and helper.closed
                    attempt('actual-writer-thread-join',joined)
            if self.monitor is not None:attempt('actual-output-monitor-stop',self.monitor.stop)
            if self.entry is not None:attempt('actual-original-entry-monitor-stop',self.entry.stop)
            processes=[]
            for row in self.ports.births if self.ports is not None else():
                p=row['process'];pid=getattr(p,'pid',None);now=self.proc(pid)if type(pid)is int else None
                streams_known=all(hasattr(p,name)for name in('stdin','stdout','stderr'))
                closed=streams_known and all(getattr(p,name)is None or getattr(p,name).closed for name in('stdin','stdout','stderr'))
                absent=row['birth']is not None and(now is None or now['startTicks']!=row['birth']['startTicks'])
                if row['kind']!='openssl'or row['birth']is None or not absent or not closed:failures.append(dict(check='actual-child-not-drained',pid=pid,streamsKnown=streams_known,streamsClosed=closed,absenceProven=absent))
                processes.append(dict(kind=row['kind'],birth=row['birth'],returnCode=getattr(p,'returncode',None),originalStreamsKnown=streams_known,originalStreamsClosed=closed,absenceProven=absent))
            restored=attempt('genuine-prefix-port-restore',self.ports.restore)if self.ports is not None else None
            if self.ports is None or restored is not None:self.owner=None
            self.case_records.append(dict(testId=self.case.id(),actualProcesses=processes,actualFixtureListeners=0 if self.ports is None else len(self.ports.listener_rows),actualOriginalNSSReads=[]if self.ports is None else self.ports.host_nss_reads,actualRejectedStartOriginal=None if self.entry is None else self.entry.rejection_original(),restoration=restored,cleanupFailures=failures,positiveActorAuthority=False))
        finally:
            if self.tls_alias is not None:
                module,original=self.tls_alias;module.tempfile=original;self.tls_alias=None
            tempfile.tempdir=self.real_tempdir
        if self.owner is None:
            self.case=None;self.ports=None;self.entry=None;self.monitor=None
            self.outer=OwnedWrites(self.root,protected=self.stdout_paths);self.outer.install();self.owner=self.outer
        if failures:raise RuntimeError('Actual utility cleanup failed: '+json.dumps(failures))
    def finish(self):
        global ACTIVE
        assert self.case is None and self.owner is self.outer
        self.outer.close();self.owner=None
        ACTIVE=None
        return dict(actualCaseBoundaries=len(self.case_records),actualTLSBirths=sum(len(row['actualProcesses'])for row in self.case_records),
            actualFixtureListeners=sum(row['actualFixtureListeners']for row in self.case_records),actualOriginalNSSReads=sum(len(row['actualOriginalNSSReads'])for row in self.case_records),actualRejectedStarts=sum(row['actualRejectedStartOriginal']['actualRejectedStarts']for row in self.case_records),actualMatchingRejectedUnwinds=sum(row['actualRejectedStartOriginal']['actualMatchingOriginalUnwinds']for row in self.case_records),originalPortsRestored=True,NodeExecutions=0,actualControllerRescues=self.rescues,positiveActorAuthority=False)
