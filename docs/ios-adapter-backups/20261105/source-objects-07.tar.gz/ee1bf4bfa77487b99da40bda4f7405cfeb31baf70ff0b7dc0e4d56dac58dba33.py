import ast,base64,hashlib,json,stat,zlib
from pathlib import Path
R=Path.cwd();P=R/'.ios-host-tmp/emote-callback-live-prefix-current235-readonly-profile-root-preparation-20261103';G=R/'.ios-host-tmp/emote-callback-live-prefix-fresh-postboot-scoped22-graph-root-preparation-20261103/graph1';BASE=R/'.ios-host-tmp/emote-callback-live-prefix-scoped22-tail5-root-preparation-20261103/tail5';T=P/'profile1';ROOT=G/'retained-first/tmpthtln4db';HEADER=ROOT/'ios-emote-primary-cccccccccccccccccccccccccccccccc-terminal-live.json';assert not(P/'freeze.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.open('x').write(s)
def save(p,v):write(p,json.dumps(v,indent=2,sort_keys=True)+'\n')
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in F])
 if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
 assert v['stat']==[getattr(p.lstat(),k) for k in F];return v
report=json.loads((G/'root-run-first/report.json').read_text());assert report['exitCode']==1 and report['retainedFiles']==235 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
header=json.loads(HEADER.read_text());payload=header['payload'];raw=zlib.decompress(base64.b64decode(payload['data'],validate=True));assert len(raw)==payload['bytes'] and hashlib.sha256(raw).hexdigest()==payload['sha256'];state=json.loads(raw)[0];assert len(state['records'])==1 and state['pending'] is None
reference=state['records'][0];assert reference['device']==ROOT.stat().st_dev==53
nodes={str(p):pin(p) for p in (ROOT,*sorted(ROOT.rglob('*')))};assert sum('sha256'inv for inv in nodes.values())==235
prior=json.loads((BASE/'prior-retained-original-pins.json').read_text());frozen=set(json.loads((G/'freeze.json').read_text())['files'])|{'freeze.json'};graphpins={str(p):pin(p) for p in G.rglob('*') if str(p.relative_to(G)) not in frozen};prior.update(graphpins)
T.mkdir();save(T/'input-graph-pins.json',nodes);save(T/'actual-graph-output-pins.json',graphpins)
save(T/'input-plan.json',dict(actualGraphStage=str(G),root=str(ROOT),header=str(HEADER),headerSha256=sha(HEADER),binding=header['binding'],runId=header['runId'],role=header['role'],sourceLock=header['sourceLock'],primaryLock=header['primaryLock'],recordReferences=state['records'],expectedOriginalFiles=235,currentDevice=53,old747RuntimeReplayForbidden=True))
for name,d in json.loads((BASE/'freeze.json').read_text())['files'].items():
 assert sha(BASE/name)==d
 if name.endswith('.py') or name=='sdk-original-pins.json':write(T/name,(BASE/name).read_text())
# Keep actual composite27 helper/gate code exact and invoke it at its original master.
(T/'reviewed_scoped_prerequisite.py').write_text((G/'reviewed_scoped_prerequisite.py').read_text())
(T/'prior_scoped_prerequisite.py').write_text((G/'prior_scoped_prerequisite.py').read_text())
write(T/'reviewed_graph_prerequisite.py',(G/'actual_smoke_prerequisite.py').read_text())
gate='''"""Actual stopped current235 graph and actual27 mechanisms; no regeneration."""
import hashlib,json,stat
from pathlib import Path
from reviewed_graph_prerequisite import require as require27
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def checkpins(file):
 data=json.loads(file.read_text())
 for name,expected in data.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();v=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):v['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert v==expected and v['stat']==[getattr(p.lstat(),k) for k in F]
 return [Path(name) for name in data]
def require(here,repo,current=None):
 paths=require27(here,repo,current);plan=json.loads((here/'input-plan.json').read_text());stage=Path(plan['actualGraphStage']);out=stage/'root-run-first';report=json.loads((out/'report.json').read_text())
 assert report['exitCode']==1 and report['retainedFiles']==235 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=1,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text())
 for root in (stage,stage/'case-cleanup-1'):
  a=json.loads((root/'terminal-census-1.json').read_text());b=json.loads((root/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 receipt=json.loads((stage/'case-cleanup-1/receipt.json').read_text());assert receipt['actualStandardCaseRunReturned'] and receipt['twoCensusesPassed']
 closes=json.loads((stage/'actual-node-original-close.json').read_text());assert closes['observer']['privateToolFreed'] and closes['actualHostOwnerCount']>0
 assert all(n['returnCode']==0 and (n['current'] is None or n['birth'] is not None and n['current']['startTicks']!=n['birth']['startTicks']) and all(v is None or v is True for v in n['originalStreamsClosed'].values()) for n in closes['nodes'])
 assert all(c['entered'] and c['returned'] and not c['unwound'] and c['returnCode']==0 for c in closes['originalCloseCalls'])
 old=json.loads((out/'root-source-map.json').read_text());assert old['repositoryRoot']==str(repo)
 if current is not None:assert current['currentSourcePins']==old['currentSourcePins'] and current['reviewedCandidates']==old['reviewedCandidates']
 process=json.loads((out/'process-binding.json').read_text())['task']
 try:row=Path('/proc',str(process['pid']),'stat').read_text().rsplit(') ',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):row=None
 assert row is None or int(row[19])!=process['startTicks']
 assert Path(plan['root']).stat().st_dev==plan['currentDevice']==53
 paths+=checkpins(here/'input-graph-pins.json');paths+=checkpins(here/'actual-graph-output-pins.json')
 return paths
'''
(T/'actual_smoke_prerequisite.py').write_text(gate)
# This runner creates ZERO fixtures/processes/new input originals. Actual supplied
# graph is read through production archive/cold cache and physically guarded.
model='''"""Literal current235 cold/warm read only; no current/native fact is minted."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import cProfile,hashlib,json,os,pstats,stat,sys,time,unittest
from pathlib import Path
from PIL import Image
from adapters.native_clock_join import digest
from adapters.original_file_reads import readonly,collect
from adapters.script_feature.history import unpack,same
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
from ios.adapters.emote_callback_live_records import CallbackLiveRecords
from ios.adapters.emote_retirement import Frozen
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def census(root):
 values={}
 for p in (root,*sorted(root.rglob('*'))):
  a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in F])
  if stat.S_ISREG(a.st_mode):v['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert v['stat']==[getattr(p.lstat(),k) for k in F];values[str(p)]=v
 return values
class Current235ReadOnlyProfile(unittest.TestCase):
 def test_literal_current235_archive_cold_warm_preserves_every_original_and_read_membership(self):
  here=Path(__file__).resolve().parent;plan=json.loads((here/'input-plan.json').read_text());root=Path(plan['root']);header=Path(plan['header'])
  expected=json.loads((here/'input-graph-pins.json').read_text());self.assertEqual(expected,census(root))
  raw=header.read_bytes();self.assertEqual(plan['headerSha256'],hashlib.sha256(raw).hexdigest());value=json.loads(raw)
  self.assertEqual(str(root),value['artifactRoot']);self.assertEqual(plan['binding'],value['binding']);self.assertEqual(2,value['iosEmoteRootedLiveVersion'])
  actual=unpack(value['payload']);self.assertEqual(1,len(actual));references=actual[0]['records'];self.assertEqual(plan['recordReferences'],references);self.assertIsNone(actual[0]['pending'])
  lock=ScriptSourceLock(value['sourceLock']);primary=lock if value['sourceLock']==value['primaryLock'] else ScriptSourceLock(value['primaryLock'])
  # Recreate only ordinary parser registration already performed by the real
  # graph producer's PNG loads. No originals are decoded or cache rows warmed.
  Image.preinit();self.assertEqual(expected,census(root))
  history=CallbackLiveRecords();self.assertTrue(history.literal(),repr(history.unsupported_members()));self.assertEqual({},history.cache.rows)
  profiler_id=getattr(sys.monitoring,'PROFILER_ID',2);self.assertIsNone(sys.monitoring.get_tool(profiler_id))
  profile=cProfile.Profile();rows=[];members=[];elapsed=[];reopens=[]
  with lock.held(),primary.held():
   for phase in ('cold','warm'):
    profile.clear();started=time.monotonic()
    with readonly(),collect() as membership:
     profile.enable()
     try:
      archive=IOSEmoteCallbackLive.archive(value,store=Frozen(header,value),lock=lock,primary_lock=primary,historical_rows=history)
      actual_rows=[archive.record(reference) for reference in archive.state['records']]
     finally:profile.disable()
    elapsed.append(time.monotonic()-started);rows.append(actual_rows);members.append(set(membership));self.assertEqual(expected,census(root))
    self.assertEqual(references,[row['reference'] for row in actual_rows]);self.assertEqual(1,len(actual_rows))
    for row in actual_rows:
     frame=archive.read_frame(row['reference']);self.assertEqual(frame['measurementSha256'],digest(row['measurement']))
     expanded=archive.originals.expand(row['reference']);path=archive.originals.path(expanded);descriptor=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
     try:
      fd=os.fstat(descriptor);self.assertEqual(expanded['file']['device'],fd.st_dev);self.assertEqual(expanded['file']['inode'],fd.st_ino);archive.originals.file(path,descriptor,expanded)
     finally:os.close(descriptor)
    profile.dump_stats(str(here/(phase+'-actual-decoders.pstats')));stats=pstats.Stats(profile)
    reopens.append(sum(data[1] for (filename,line,function),data in stats.stats.items() if filename.endswith('/ios/adapters/emote_callback_archive.py') and function=='reopen'))
    calls=[dict(file=f,line=l,function=n,primitiveCalls=v[0],totalCalls=v[1],cumulativeSeconds=v[3]) for (f,l,n),v in sorted(stats.stats.items()) if f.startswith(str(here.parents[2]))]
    with (here/(phase+'-actual-project-calls.json')).open('x') as output:json.dump(calls,output,indent=2);output.write('\\n')
  profile.disable();del profile
  self.assertTrue(same(rows[0],rows[1]));self.assertTrue(members[0]);self.assertEqual(members[0],members[1]);self.assertEqual(1,len(history.cache.rows));self.assertTrue(history.literal())
  self.assertGreaterEqual(reopens[0],2);self.assertEqual(0,reopens[1]);self.assertEqual(expected,census(root))
  report=dict(status='ACTUAL_CURRENT235_LITERAL_ORIGINAL_GRAPH_COLD_WARM_HOST_READ',historicalOnly=True,records=1,cacheRows=1,
   coldSeconds=elapsed[0],warmSeconds=elapsed[1],coldReopenCalls=reopens[0],warmReopenCalls=reopens[1],readMembership=len(members[0]),
   readMembershipEqual=True,actualReadMembership=[str(p) for p in sorted(members[0])],originalFiles=235,allOriginalPinsUnchanged=True,
   currentDevice=plan['currentDevice'],old747RuntimeReplay=False,subprocesses=False,network=False,SDKExecuted=False,inputsOrNativeQueries=False,
   noOriginalsDecodedBeforeCold=True,parserRegistrationOnlyBeforeCold=True,nativeCompiled=False,deviceAcceptance=False,wholeFeatureQualified=False)
  with (here/'profile-result.json').open('x') as output:json.dump(report,output,indent=2);output.write('\\n')
'''
write(T/'test_current235_readonly_profile.py',model)
code=(T/'run-selected.py').read_text();code=code.replace("            if isinstance(address,tuple) and address[0] not in ('127.0.0.1','::1','localhost'):raise RuntimeError('Only owned loopback fixtures are selected')","            raise RuntimeError('Read-only current235 replay admits zero network connect/bind')")
# Guard against accidental original writes, with only the existing exact source
# lock opened RW for flock. Raw/physical files and rootmembership remain pinned.
anchor="            path=os.fsdecode(args[0])\n";assert code.count(anchor)==1
code=code.replace(anchor,anchor+"            if path.startswith(input_root+os.sep):\n                mode=args[1];flags=args[2];writing=(type(mode) is str and any(c in mode for c in 'wax+')) or type(flags) is int and bool(flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))\n                if writing and path not in input_locks:raise RuntimeError('Retained current235 original write prohibited')\n")
anchor='    sys.addaudithook(audit) # BEFORE any target import or fixture birth.';assert code.count(anchor)==1
code=code.replace(anchor,"    input_plan=json.loads((HERE/'input-plan.json').read_text());input_root=input_plan['root'];input_locks={input_plan['sourceLock'],input_plan['primaryLock']}\n"+anchor)
# Never let local instrumentation reserve cProfile's actual PROFILER_ID.
r=(T/'raise_observer.py').read_text();r=r.replace("(4,3,5,2,1,0)","(4,3,5)");(T/'raise_observer.py').write_text(r)
(T/'run-selected.py').write_text(code)
parent=(T/'root-supervise.py').read_text();a=" for name in ('scope-plan.json','actual-history-current-pins.json','scoped_prerequisite.py','prior_scoped_prerequisite.py','scope-first22.py'):\n  p=HERE.parent/name;assert sha(p)==json.loads((HERE/'master-guard-pins.json').read_text())[name];paths.add(p)\n";assert parent.count(a)==1;parent=parent.replace(a,'');(T/'root-supervise.py').write_text(parent)
plan=json.loads((BASE/'run-plan.json').read_text());case='test_current235_readonly_profile.Current235ReadOnlyProfile.test_literal_current235_archive_cold_warm_preserves_every_original_and_read_membership';plan.update(status='PRIVATE_UNRUN_CURRENT235_READONLY_ARCHIVE_PROFILE',cases=[case],caseCount=1,totalCaseCount=1,expectedRetainedRoots=0,initialOuterSeconds=60,retainedTemporaryDirectoryAliases=[],mkdtempAliases=[],retainInstalledFixture=False,modelMaps={});plan['privateFiles']={f.name:sha(f) for f in T.glob('*.py')};save(T/'run-plan.json',plan);save(T/'prior-retained-original-pins.json',prior)
manifest=json.loads((BASE/'source-manifest.json').read_text());manifest.update(name='profile1',stage='current235-readonly-cold-warm-profile',status=plan['status'],caseCount=1,pythonCaseCount=1,initialTimeoutSeconds=60);manifest['actualPublicBasis']='Actual unchangedhelper4fea/Live d6/test f4ed after composite27. Actual stopped current235 from productioncapture+append, original graphERROR62s preserved; no fixture/input regeneration, no old747 replay.';save(T/'source-manifest.json',manifest)
superplan=json.loads((BASE/'supervisor-plan.json').read_text());superplan['initialSeconds']=60;save(T/'supervisor-plan.json',superplan)
for f in P.rglob('*.py'):ast.parse(f.read_text())
save(T/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={f.name:sha(f) for f in T.iterdir() if f.is_file() and f.name!='freeze.json'}))
write(P/'ROOT-PLAN.txt','Root-only readonly profile1/root-supervise.py original60+kill5 budget (old full747 profile used60+5),zero newTD/fixtures/processes/network/SDK/nativequeries/inputs. Uses ONLY stopped postboot current235 tmpthtln4db, exact originalheader/physicalbody/inode/device53/membership beforeafter. Literal actual storedLive2 record derivedcold thenwarm; no expected answer/DTO/retime. Actual composite27+stoppedgraph235 originalnormalNodeclose/process/source/percase+aggregatecensuses hardgate before targetimport. Current publicmap equals actualtail5/graph samehelper4fea/Lived6/testf4ed. Pure parserImage.preinit registration only beforecold, matches originalproductioncapture priorPNGloads and neverdecodesoriginals; no cachewarm. Single cProfile reused cold/warm; RAISE monitoring only3/4/5, no processobserver needed/admitted; PROFILER_ID2 reserved for actualcProfile. All235 rawpins/body/currentinode/device exact; old747 runtime stillforbidden. No performance claim until actualrun.\n')
save(P/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',case=case,initialSeconds=60,killAfterSeconds=5,originalGraphStage=str(G),inputRoot=str(ROOT),inputHeaderSha256=sha(HEADER),currentOriginalFiles=235,currentDevice=53,records=1,sourceHelperUnchanged=True,old747RuntimeReplayForbidden=True,fixturesRegenerated=False,targetImports=False,testsRun=False))
save(P/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(f.relative_to(P)):sha(f) for f in sorted(P.rglob('*')) if f.is_file() and f.name!='freeze.json'},stageFreeze=sha(T/'freeze.json')))
print(json.dumps(dict(freeze=sha(P/'freeze.json'),stageFreeze=sha(T/'freeze.json'),inputPins=len(nodes),actualGraphPins=len(graphpins))))
