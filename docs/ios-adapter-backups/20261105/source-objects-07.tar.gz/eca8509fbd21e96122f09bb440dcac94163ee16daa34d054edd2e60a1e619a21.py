"""Read actual completed Audio25 original receipts, retaining failure gates."""
from pathlib import Path
import argparse,hashlib,json,os,stat
B=Path.cwd()/'.ios-host-tmp'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def raw_pin(p):
 p=Path(p);a=p.lstat();assert p.resolve(strict=True)==p and stat.S_ISREG(a.st_mode)
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  assert all(getattr(os.fstat(fd),f)==getattr(a,f)for f in FIELDS);d=hashlib.sha256()
  while z:=os.read(fd,1024*1024):d.update(z)
  assert all(getattr(os.fstat(fd),f)==getattr(a,f)for f in FIELDS)
 finally:os.close(fd)
 assert all(getattr(p.lstat(),f)==getattr(a,f)for f in FIELDS)
 return dict(path=str(p),sha256=d.hexdigest(),bytes=a.st_size)
def put(d,n,v):
 with(d/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
def main():
 parser=argparse.ArgumentParser()
 for n in('collector','collector-freeze','output'):parser.add_argument('--'+n,required=True)
 a=parser.parse_args();c=Path(a.collector);out=Path(a.output)
 assert c.is_absolute()and c.parent==out.parent==B and not out.exists()
 assert sha(c/'freeze.json')==a.collector_freeze
 for n,x in load(c/'freeze.json')['files'].items():assert sha(c/n)==x['sha256']
 top=load(c/'terminal.json');rows=top['groups'];assert 1<=len(rows)<=25
 assert [r['group']for r in rows]==['audio-%02d'%n for n in range(2,2+len(rows))]
 for k in('allOldOriginalBodiesUnchanged','wholeOwnOutputsTwiceEqual','allExecutedOwnedProcessesAbsent','allOldAndOwnTemporaryRowsMatchActualTwoPosts'):assert top[k]is True
 before=load(c/'global-before.json');after=load(c/'global-after-first.json');assert after==load(c/'global-after-second.json')
 assert len(before)==top['oldRootCount']and all(after[n]==v for n,v in before.items())
 temps=set(top['ownTemporaryRootsExplicitlyIncluded']);assert set(after)==set(before)|temps and set(before).isdisjoint(temps)
 whole=load(c/'whole-output-first.json');assert whole==load(c/'whole-output-second.json')and all(after[n]==whole[n]for n in temps)
 assert set(whole)==set(top['newOriginalRoots'])-{str(c)}and len(top['newOriginalRoots'])==len(set(top['newOriginalRoots']))==4*len(rows)+1
 details=[];passed=0
 for row in rows:
  h=Path(row['input']).parent;o=h.with_name(h.name+'-outer');cs=h.with_name(h.name+'-censuses');tmp=h/'temporary'
  assert sha(row['input'])==row['inputSha256'];p=load(row['input']);assert p['sourceFreeze']=='114e2c19ba09919bd9264c58d1ece1cce7721ed4e8f636ccbbf76f46827a2bfa'
  assert p['groupName']==row['group']and p['subjectOriginCount']==447 and p['wallSeconds']==180 and p['killGraceSeconds']==5
  t=load(o/'terminal.json');q=load(cs/'qualification.json');drain=load(o/'actual-process-drain.json')
  assert t==row['originalTerminal']and q==row['originalQualification']and t['ownProcessesAbsent']is q['ownProcessesAbsent']is True and not drain['remaining']
  assert row['originalRoots']==q['originalRoots']==list(map(str,[h,o,cs]))and q['noCensusExclusions']is True
  assert str(tmp)in temps
  for owned in drain['owned']:
   try:raw=Path('/proc',str(owned['pid']),'stat').read_text()
   except(FileNotFoundError,ProcessLookupError):continue
   assert int(raw[raw.rfind(')')+2:].split()[19])!=owned['startTicks']
  def optional(n):
   path=h/'child-receipts'/n;return load(path)if path.exists()else None
  report=optional('report.json');case=optional('standard-case-1.json');ports=optional('actual-port-restoration.json');origins=optional('actual-source-model-origins.json')
  positive=row['supervisorReturnCode']==0 and t['status']==q['status']=='PASS'
  if positive:
   assert t['childReturnCode']==0 and not t['problems']and not t['timedOut']and not t['forcedKill']and not t['orphansRequiredKill']
   for k in('actualClassCleanupCustodyEstablished','actualOneCaseReceiptsEstablished','actualRetainedAudioResourceRecipeEstablished','actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allSubjectActualRuntimeOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','twoFullOwnOutputCensusesEqual','zeroCaseChildBirthsEstablished'):assert t[k]is True
   assert report['testsRun']==report['actualCaseReceipts']==1 and report['status']=='PASS'and report['cleanupEstablished']and report['fatal']is None
   assert len(report['retainedTemporaryDirectories'])==p['expectedTemporaryDirectories']
   assert case['id']==p['cases'][0]and len(case['actualNestedCleanupCalls'])==p['expectedNestedCleanupCalls']and case['newTemporaryDirectories']==p['expectedTemporaryDirectories']
   for call in case['actualNestedCleanupCalls']:assert call['originalReturned']is True and call['remaining']==0 and call['originalRaised']is None and not call['newCallbackErrors']and not call['newCallbackFailures']
   assert ports['count']==27 and ports['controlDescriptors']==[]
   for k in('restored','dupPortsRestored','toolsRestored','builtinsCioRestored'):assert ports[k]is True
   assert ports['actualClassCleanupRestoration']['originalDescriptorRestored']is True
   assert origins['allSubjectActualRuntimeOriginsEstablished']and len(origins['subjectOrigins'])==447
   passed+=1
  details.append(dict(group=row['group'],caseIds=p['cases'],originalTerminal=t,originalQualification=q,originalReport=report,originalCaseReceipt=case,originalPortRestoration=ports,originalProcessDrain=drain,positiveHostCaseQualified=positive))
 assert passed==len(rows)or rows[-1]['supervisorReturnCode']!=0
 complete=len(rows)==passed==25
 refs={str(f):raw_pin(f)for root in map(Path,top['newOriginalRoots'])for f in sorted(root.rglob('*'))if f.is_file()and not f.is_symlink()}
 out.mkdir(mode=0o700)
 put(out,'results.json',dict(status='ROOT_QUALIFIED_AUDIO26_REMAINING25_ORIGINAL_HOST_CASES_ONLY'if complete else'ROOT_RETAINED_AUDIO26_REMAINING_GROUPS_ACTUAL_PARTIAL_OR_NEGATIVE_ORIGINALS',terminal=details[-1]['originalTerminal'],newOriginalRoots=top['newOriginalRoots'],allExecutedOwnProcessOriginalsIndependentlyAbsent=True,actualCaseCount=len(details),actualPassedCases=passed,actualGroupReceipts=details,unrunGroups=top['unrunGroups'],sourceFreeze='114e2c19ba09919bd9264c58d1ece1cce7721ed4e8f636ccbbf76f46827a2bfa',source5Freeze='f2ce27ae7d7e94f99e71476cc78fc8625dbdd8243f2284fe9183298e22826f3f',source6Freeze='5d9b109c2e0db1f34fba8b023a85ae3695e2f63ccf08db526a1cf79cb9c64819',originalCollectorFreeze=a.collector_freeze,oldRootCount=top['oldRootCount'],allOldOriginalBodiesUnchanged=True,allNewOwnTemporaryRootsExplicitlyIncluded=True,remaining25HostCasesQualified=complete,receivedMixerLiveAdmission=None,sharedActorAggregateEndAdmission=None,nativeQualified=False,featureQualified=False,wholeQualified=False))
 put(out,'actual-receipt-references.json',refs);put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in sorted(out.iterdir())if p.is_file()}));print(json.dumps(dict(freeze=sha(out/'freeze.json'),results=sha(out/'results.json'),references=len(refs),executed=len(rows),passed=passed,complete=complete)))
if __name__=='__main__':main()
