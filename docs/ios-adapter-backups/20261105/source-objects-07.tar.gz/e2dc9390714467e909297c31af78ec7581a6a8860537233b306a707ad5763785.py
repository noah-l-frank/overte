"""Actual live marker constructor BEFORE lower producer attachment.

Every unavailable port refuses before a producer exists. No prebuilt State,
__dict__ copy or allocation bypass creates a live marker owner. The existing
Domain constructor subsequently attaches its explicit lower model ports;
full installed Runtime replaces the setup boundary before first normal input.
"""
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import NativeFeatureObservation,need
from adapters.native_script_files import NativeScriptFiles
from ios.adapters.script_runtime import IOSScriptRuntime
from ios.adapters.emote_rooted_marker_scope import IOSEmoteRootedMarkerScope
from ios.self_tests.emote_post9_setup_adapter import SetupOnlyAdapter
from ios.self_tests.test_ios_emote_sources import BINDING,RUN


def unavailable(*_args,**_kwargs):need(False)


class UnavailableReadPort:
    def __init__(self):self.last=None
    def read(self,*args,**kwargs):return unavailable()
    def capture(self,*args,**kwargs):return unavailable()


class ConstructorPorts:
    def __init__(self,pid):self.pid=pid
    def bound_native_observer(self,_clock):
        return NativeFeatureObservation(unavailable,unavailable,unavailable,unavailable,self.pid,ios=True,native_clock_bound=True)
    def emote_world(self,_clock):return UnavailableReadPort()
    def script_terminal(self,_clock):return UnavailableReadPort()
    def script_work(self,_clock):return UnavailableReadPort()
    def script_dialogs(self,_clock):return UnavailableReadPort()
    def web_closures(self):return UnavailableReadPort()
    def script_fixture_files(self):return NativeScriptFiles(unavailable,unavailable,unavailable,unavailable,self.pid,ios=True)


class ConstructorRuntime(IOSScriptRuntime):
    def __init__(self,model,binding):
        super().__init__(SetupOnlyAdapter());self.model,self.binding=model,deepcopy(binding)
    def state_path(self,selector):need(selector=='model-only');return self.model.root/'session.json'
    def _sources(self,selector):
        need(selector=='model-only');return dict(binding=deepcopy(self.binding),check=unavailable,
            observer=ConstructorPorts(int(self.binding['processIdentity'])),clock_source=None,native=UnavailableReadPort())


def rooted(model,binding=BINDING,*,role='primary'):
    need(role in('primary','actor'));model.lock.assert_held()
    runtime=ConstructorRuntime(model,binding)
    return IOSEmoteRootedMarkerScope(runtime,'model-only',model.root,RUN,role,
        'http://controlled.invalid/feature-fixture/v1/runs/'+RUN+'/','a'*32,model.lock)
