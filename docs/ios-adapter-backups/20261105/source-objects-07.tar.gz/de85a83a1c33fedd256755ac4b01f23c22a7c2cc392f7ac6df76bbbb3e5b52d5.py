"""Connected normal29 cleanup using the actual distinct cleanup activation.

Only already-known closed input generations may take this normal route. A
prefix remains explicitly owned and cannot acquire an end/Stop capability.
Permission restore is once-only settings custody; current native target/peer
permission and Model/image/resource/process/SDK absence remain separate duties.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.asset_backend_client import AssetsBackendClient
from adapters.native_feature_observation import exact,integer,need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same,pack,unpack
from ios.adapters.assets_budget import operation
from ios.adapters.assets_cleanup_phase import AssetsCleanupPhase,AssetsCleanupScope
from ios.adapters.assets_cleanup_runtime import CurrentCleanupAssetsRuntime
from ios.adapters.assets_whole_server_cleanup import AssetsWholeServerCleanup


class AssetsWholeCleanup:
    def __init__(self,driver,owner):
        from ios.adapters.assets_whole_input import AssetsWholeInput
        need(type(driver) is AssetsWholeInput and type(owner) is AssetsCleanupPhase
            and owner.selected is driver.selected and owner.actions is driver.actions and owner.episodes is driver.episodes)
        self.driver,self.owner=driver,owner;self.monotonic=driver.monotonic;self.scope=None;self.server=None
        self.store=PrivateFeatureState(driver.root/('ios-assets-whole-cleanup-'+driver.run+'.json'))
        self.previous=self.store.read();self.state=None
        if self.previous is not None:self.state=self.decode(self.previous)
    def metadata_guard(self):
        self.driver.guard();self.owner.metadata_guard();need(same(self.store.read(),self.previous));return True
    def guard(self):
        self.metadata_guard();need(type(self.scope) is AssetsCleanupScope and self.scope.owner is self.owner);self.scope.guard();return True
    def envelope(self):return dict(iosAssetsWholeCleanupVersion=1,runId=self.driver.run,cleanup=self.owner.link(),payload=pack([self.state]))
    def decode(self,value):
        exact(value,{'iosAssetsWholeCleanupVersion','runId','cleanup','payload'})
        need(type(value['iosAssetsWholeCleanupVersion']) is int and value['iosAssetsWholeCleanupVersion']==1
            and value['runId']==self.driver.run and same(value['cleanup'],self.owner.link()))
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0]
        exact(state,{'phase','permissionCommandIndex','permissionOriginalSha256','serverProof'})
        need(state['phase'] in ('restoring-settings','observing-server','known-inputs-restored')
            and integer(state['permissionCommandIndex'],1,128))
        client=self.driver.permissions.client;commands=[] if client.state is None else client.state['commands']
        index=state['permissionCommandIndex'];need(len(commands)>=index-1)
        if len(commands)>=index:
            row=commands[index-1];need(row['query']['operation']=='restore' and row['query']['runId']==self.driver.run)
            if state['permissionOriginalSha256'] is not None:need(row['original'] is not None and digest(row['original'])==state['permissionOriginalSha256'])
        else:need(state['permissionOriginalSha256'] is None)
        if state['phase']!='restoring-settings':need(state['permissionOriginalSha256'] is not None)
        need((state['phase']=='known-inputs-restored')==(state['serverProof'] is not None));return state
    def save(self):
        self.guard();value=self.envelope();self.decode(value);self.store.write(value,self.previous);self.previous=deepcopy(value)
    def activate(self):
        self.metadata_guard()
        if self.owner.state is None:self.scope=self.owner.begin()
        elif self.owner.state['phase']=='recording':self.scope=self.owner.recover_saved()
        else:self.scope=AssetsCleanupScope(self.owner);self.scope.guard()
        row=self.owner.read()
        need(row['mode']=='all-action-originals' and row['completedActionOriginals']==29 and not row['prefixDuties'])
        return self.scope
    @operation
    def restore_settings(self):
        self.guard();client=self.driver.permissions.client
        if self.state is None:
            commands=[] if client.state is None else client.state['commands'];need(commands and commands[-1]['original'] is not None)
            self.state=dict(phase='restoring-settings',permissionCommandIndex=len(commands)+1,permissionOriginalSha256=None,serverProof=None);self.save()
        index=self.state['permissionCommandIndex'];previous=client.guard
        def current():self.guard();need(previous() is not False);self.scope.guard();return True
        client.guard=current
        try:
            commands=[] if client.state is None else client.state['commands']
            if len(commands)==index-1:client.request('restore')
            else:
                need(len(commands)==index and commands[-1]['query']['operation']=='restore')
                if commands[-1]['original'] is None:client.recover()
            original=client.state['commands'][index-1]['original'];need(original is not None)
            if self.state['permissionOriginalSha256'] is None:
                self.state.update(phase='observing-server',permissionOriginalSha256=digest(original));self.save()
            else:need(digest(original)==self.state['permissionOriginalSha256'])
            return deepcopy(original)
        finally:client.guard=previous
    @operation
    def normal(self):
        self.activate();self.restore_settings()
        # Reconstruct all actual old owners after the phase transition. Their
        # metadata remains data; no obsolete normal ActionScope is reacquired.
        from ios.adapters.assets_page_generation_recovery import reconstruct_page_generations
        from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
        driver=self.driver;scopes=tuple(driver.scopes)
        recovered=reconstruct_page_generations(driver.episodes,driver.actions,scopes)
        need(len(scopes)==5 and recovered['owner'].state['complete'])
        graph=AssetsEpisodeModelGraph(scopes[1],recovered['pageReports'][0]['owner'],actions=driver.actions,dependency_mode=True).decode()
        runtime=CurrentCleanupAssetsRuntime(driver.adapter,self.scope,scopes[-1],monotonic=driver.monotonic,epoch_ms=driver.epoch_ms)
        native=runtime._assets_sources(driver.selector,scopes[-1].locks['primary'])
        def current():self.guard();need(native['check']() is not False);self.scope.guard();return True
        self.server=AssetsWholeServerCleanup(self.scope,graph,AssetsBackendClient(driver.backend_config,current),
            PrivateFeatureState(driver.root/('ios-assets-server-cleanup-'+driver.run+'.json')),
            monotonic=driver.monotonic,sleep=native['observer'].sleep)
        proof=self.server.restore()
        if self.state['serverProof'] is None:self.state.update(phase='known-inputs-restored',serverProof=deepcopy(proof));self.save()
        else:need(same(self.state['serverProof'],proof))
        return self.report()
    def report(self):
        self.guard();need(self.state is not None and self.state['phase']=='known-inputs-restored' and self.server is not None)
        self.server.metadata_guard();need(same(self.server.decode(self.server.previous),self.server.state)
            and self.server.state['phase']=='restored' and same(self.server.state['restoration']['proof'],self.state['serverProof']))
        return dict(assetsWholeCleanupObservationVersion=1,knownInputFilesRetired=True,settingsOriginalRestored=True,
            originalServerMappingBlobAndWorkerRestoration=deepcopy(self.state['serverProof']),
            retainedDuties=['current-native-permission-restoration','scene-model-and-parser-resources','marker-and-image-resources',
                'global-typed-evidence-membership','local-process-and-sdk-end'],wholeEndEligible=False,performed=False)
