"""Qualify one original host pair only, no speed/cause/adoption conclusion."""
from pathlib import Path
import hashlib,json
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,v):
 with(d/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
C=B/'root-chat-one-namespace-measurement-window-current1145-20261105';assert sha(C/'freeze.json')=='26e9ed003b3151a8fd2206946049f243f8630c5bf661eb3b980887cd76b30a6f'
for n,r in load(C/'freeze.json')['files'].items():assert sha(C/n)==r['sha256']
top=load(C/'terminal.json');assert len(top['groups'])==1 and top['oldRootCount']==1145 and len(top['newOriginalRoots'])==4
for k in('allOldOriginalBodiesUnchanged','wholeOwnOutputsTwiceEqual','allExecutedOwnedProcessesAbsent'):assert top[k]is True
assert load(C/'global-before.json')==load(C/'global-after-first.json')==load(C/'global-after-second.json')and len(load(C/'global-before.json'))==1145
assert load(C/'whole-output-first.json')==load(C/'whole-output-second.json')
row=top['groups'][0];h=Path(row['input']).parent;assert sha(row['input'])==row['inputSha256']=='ec3a50fbb246845b5c080e047a360b6dd14022d3d1d549a9eae2a35e16850620';p=load(row['input']);o=h.with_name(h.name+'-outer');c=h.with_name(h.name+'-censuses')
t=load(o/'terminal.json');assert t==row['originalTerminal']and t['status']=='PASS'and t['childReturnCode']==0 and t['ownProcessesAbsent']is True
assert t['problems']==t['orphansRequiredKill']==[]and t['timedOut']is t['forcedKill']is False
for k in('actualSinglePairCaseReceiptEstablished','actualClassCleanupCustodyEstablished','actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allSubjectActualRuntimeOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','twoFullOwnOutputCensusesEqual','zeroCaseChildBirthsEstablished'):assert t[k]is True
report=load(h/'child-receipts/report.json');assert report['status']=='PASS'and report['testsRun']==report['actualCaseReceipts']==1 and report['cleanupEstablished']is True and report['fatal']is None
assert report['performanceMeasured']is report['rawSinglePairOnly']is True and report['speedOrCPUCauseConclusion']is False and report['chatAdoptionAdmission']is None
case=load(h/'child-receipts/standard-case-1.json');assert case['id']==p['cases'][0]and case['remainingStandardCleanups']==case['newTemporaryDirectories']==0 and len(case['actualNestedCleanupCalls'])==1
ports=load(h/'child-receipts/actual-port-restoration.json');assert ports['count']==27 and ports['controlDescriptors']==[]
for k in('restored','dupPortsRestored','toolsRestored','builtinsCioRestored'):assert ports[k]is True
cl=ports['actualClassCleanupRestoration'];assert cl['originalDescriptorRestored']is cl['originalFunctionCodeGlobalsUnchanged']is True
closure=load(h/'child-receipts/actual-expected-comparison-closure-restoration.json');assert closure['originalCallSetUpRestored']is closure['noSetUpObserverInstalled']is True and closure['actualBoundCases']==0
q=load(c/'qualification.json');assert q==row['originalQualification']and q['status']=='PASS'and q['ownProcessesAbsent']is q['noCensusExclusions']is True
measured=load(h/'child-receipts/one-literal-first-candidate-second-measurement.json');assert measured['iterationsPerPath']==1 and measured['fixedOrder']=='literal-first,candidate-second'
assert measured['module']=='ios.adapters.chat_peer_receipts'and measured['projectionEqual']is measured['sameActualCollectorObject']is measured['registeredExpectedTupleUntouched']is True
assert measured['speedOrCPUCauseConclusion']is measured['nativeQualified']is measured['wholeQualified']is False and measured['chatAdoptionAdmission']is None
for name in('old','candidate'):
 for key in('cpuNanoseconds','wallNanoseconds'):assert type(measured[name][key])is int and measured[name][key]>=0
drain=load(o/'actual-process-drain.json');assert drain['remaining']==drain['orphansRequiredKill']==[]
for owned in drain['owned']:
 try:raw=Path('/proc',str(owned['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(raw[raw.rfind(')')+2:].split()[19])!=owned['startTicks']
refs={str(f):dict(path=str(f),sha256=sha(f))for root in map(Path,top['newOriginalRoots'])for f in sorted(root.rglob('*'))if f.is_file()and not f.is_symlink()}
OUT=B/'root-chat-one-real-namespace-single-original-host-measurement-results-20261105';OUT.mkdir(mode=0o700)
put(OUT,'results.json',dict(status='ROOT_QUALIFIED_ONE_REAL_REGISTERED_CHAT_NAMESPACE_SINGLE_ORIGINAL_HOST_PAIR_ONLY',terminal=t,newOriginalRoots=top['newOriginalRoots'],sourceFreeze=p['sourceFreeze'],subjectSourceFreeze=p['utilitySubjectSourceFreeze'],originalCollectorFreeze=sha(C/'freeze.json'),actualCaseCount=1,actualFreshSubjectOrigins=10,actualReport=report,actualCaseReceipt=case,actualPortRestoration=ports,actualClosureRestoration=closure,actualRawMeasurement=measured,performanceMeasured=True,rawSinglePairOnly=True,fixedOrderAndClockOverheadRetained=True,wholeGuardCostsIncluded=False,speedOrCPUCauseConclusion=False,chatComparatorAdopted=False,chatAdoptionAdmission=None,runtimeAdmission=None,EndAdmission=None,all1145OldOriginalBodiesUnchanged=True,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(OUT,'actual-receipt-references.json',refs);put(OUT,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in OUT.iterdir()}));print(json.dumps(dict(freeze=sha(OUT/'freeze.json'),results=sha(OUT/'results.json'),references=len(refs))))
