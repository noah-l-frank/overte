"""Two exact frozen disjoint five-case groups; no target import."""
from pathlib import Path
import ast
import hashlib
import json
REPO=Path(__file__).resolve().parent.parent.parent
SELECTION=REPO/'.ios-host-tmp/chat-offline-source1-additional10-fixed-five-selections-source1-20261104'
SELECTION_SHA='9d313952596279cd62bd248c842a8b433acbddf55ec3ce0dbecc7b1f12b58d6a'
GROUPS=('additional-five-1','additional-five-2')

def selected(group):
    assert type(group)is str and group in GROUPS
    freeze=SELECTION/'source-freeze.json'
    assert hashlib.sha256(freeze.read_bytes()).hexdigest()==SELECTION_SHA
    for name,row in json.loads(freeze.read_text())['files'].items():
        assert hashlib.sha256((SELECTION/name).read_bytes()).hexdigest()==row['sha256']
    value=json.loads((SELECTION/'selections.json').read_text())
    assert set(value['groups'])==set(GROUPS)
    initial=value['preservedInitialFour'];first=value['groups'][GROUPS[0]];second=value['groups'][GROUPS[1]]
    assert len(initial)==len(set(initial))==4 and len(first)==len(set(first))==len(second)==len(set(second))==5
    assert not set(initial)&set(first+second)and not set(first)&set(second)
    assert set(initial+first+second)==set(value['actualOriginalIds'])and len(value['actualOriginalIds'])==14
    source=Path(value['actualTestSource']['path'])
    assert hashlib.sha256(source.read_bytes()).hexdigest()==value['actualTestSource']['sha256']
    tree=ast.parse(source.read_text(),filename=str(source))
    cls=next(node for node in tree.body if isinstance(node,ast.ClassDef)and node.name=='ChatOfflineSendTests')
    actual={'ios.self_tests.test_ios_chat_offline_send.ChatOfflineSendTests.'+node.name for node in cls.body if isinstance(node,ast.FunctionDef)and node.name.startswith('test_')}
    assert actual==set(value['actualOriginalIds'])
    assert value['perGroup']==dict(failfast=True,genuineTDsPerExecutedCase=3,graceSeconds=5,maxLiveNodes=1,maximumSequentialNodes=5,seconds=180)
    return list(value['groups'][group])
