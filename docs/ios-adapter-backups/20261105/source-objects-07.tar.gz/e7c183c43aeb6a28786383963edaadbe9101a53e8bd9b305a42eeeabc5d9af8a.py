"""Root-granted future exact45 suite. Preparation is not a test execution."""
from pathlib import Path
import hashlib,json,os,sys,tempfile,types,unittest

ROOT=Path(__file__).resolve().parents[2]
PACKAGE=Path(__file__).resolve().parent
plan=json.loads((PACKAGE/'selected-suite-plan.json').read_text())
sourcepins=json.loads((PACKAGE/'sourcepins.json').read_text())
refs=PACKAGE/'reviewed-qt-reference'
assert os.environ.get('OVERTE_QT_SOURCE_REFERENCE_ROOT')==str(refs)
sha=lambda data:hashlib.sha256(data).hexdigest()
for row in sourcepins['publicPaths']:
    assert sha((ROOT/row['path']).read_bytes())==row['candidateSha256'],row['path']
reference_before={row['path']:(refs/row['path']).read_bytes() for row in sourcepins['qtSourcePins']}
assert all(sha(reference_before[row['path']])==row['upstreamSha256'] for row in sourcepins['qtSourcePins'])
sys.path.insert(0,str(ROOT/'tests/device'))
from ios.self_tests import test_ios_installed_adapter as installed_fixture
from ios.self_tests.retained_host_roots import retain_owned_root

real_temporary_directory=tempfile.TemporaryDirectory
original_fixture_module=installed_fixture.tempfile
retained=[]
def retained_temporary_directory(*args,**kwargs):
    directory=real_temporary_directory(*args,**kwargs)
    root=retain_owned_root(directory,expected_root=Path(directory.name))
    retained.append(str(root));print('retained legacy installed fixture root',root,flush=True)
    return directory

# Change this fixture's name binding only. The real global tempfile module and
# real TemporaryDirectory type remain intact for isinstance and other fixtures.
installed_fixture.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_temporary_directory)
try:
    ids=plan['caseIds'];assert len(ids)==45 and len(set(ids))==45
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    assert not loader.errors and suite.countTestCases()==45,loader.errors
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.testsRun==45 and not result.skipped,'Exact45 must run; no reference skip or partial success'
finally:
    installed_fixture.tempfile=original_fixture_module
    assert tempfile.TemporaryDirectory is real_temporary_directory
    assert all((refs/name).read_bytes()==data for name,data in reference_before.items())
    print(json.dumps(dict(retainedInstalledFixtureRoots=retained,referenceOriginalsUnchanged=True)),flush=True)
sys.exit(0 if result.wasSuccessful() else 1)
