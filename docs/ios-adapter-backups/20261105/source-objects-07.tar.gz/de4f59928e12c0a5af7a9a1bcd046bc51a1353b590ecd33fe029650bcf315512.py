"""AST-only body for Root audited passive harness; no execution on import."""
def one_historical_factory(spec,output):
    # Root must install actual preimport source/audit guards BEFORE calling this.
    from pathlib import Path
    import cProfile
    import json
    import pstats
    import time
    from adapters.script_feature.lock import ScriptSourceLock
    from adapters.original_file_reads import readonly,collect
    from ios.adapters.tablet_web_aggregate_root import source_owner
    from ios.adapters import tablet_web_record_cache as records
    assert records._ACTIVE.get() is None
    def forbidden(*_args,**_kwargs):raise AssertionError('Passive historical factory reached live callback')
    root=Path(spec['root']);lock=ScriptSourceLock(root/'script-feature-sources.lock')
    profiler=cProfile.Profile();answer=None
    with lock.held(),readonly(),collect() as paths:
        started=time.monotonic();profiler.enable()
        try:
            owner=source_owner(root,spec['binding'],spec['runId'],spec['role'],spec['fixtureUrl'],spec['processId'],lock,
                forbidden,epoch_ms=forbidden,monotonic=time.monotonic,historical=True)
            answer=dict(type=type(owner).__name__,historical=owner.historical,blocked=owner.blocked,
                originalReferenceCount=len(owner.record_references()),pendingIndex=None if owner.state['pending'] is None else owner.state['pending']['index'])
        finally:
            profiler.disable();profiler.dump_stats(str(output/'actual-factory-profile.pstats'))
            stats=pstats.Stats(profiler);rows=[]
            for (filename,line,name),(primitive,calls,own,cumulative,callers) in stats.stats.items():
                rows.append(dict(file=filename,line=line,name=name,primitiveCalls=primitive,calls=calls,ownSeconds=own,cumulativeSeconds=cumulative))
            rows.sort(key=lambda row:row['cumulativeSeconds'],reverse=True)
            (output/'actual-factory-profile-selected.json').write_text(json.dumps(dict(seconds=time.monotonic()-started,
                top25=rows[:25],actualReadPaths=len(paths),answer=answer,recordCacheScopeInactive=records._ACTIVE.get() is None,
                authority=False,wholeQualified=False),indent=2)+'\n')
    return answer
