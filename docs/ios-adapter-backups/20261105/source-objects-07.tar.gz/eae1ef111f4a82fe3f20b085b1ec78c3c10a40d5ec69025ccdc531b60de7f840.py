"""One exact failfast4-case host suite180+5; no runtime map is supplied here."""
from pathlib import Path
import builtins,faulthandler,importlib.abc,importlib.machinery,importlib.util
import io,json,os,signal,sys,tempfile,threading,traceback,unittest
from metadata import SOURCE,REPO,PROPOSAL,validate,sha,pin,load,census,fds,proc,head
from chat_node_port import ChatNodePort

assert sys.dont_write_bytecode and Path.cwd()==REPO and len(sys.argv)==6
expected_head,source_sha,plan_sha,plan_path,output=sys.argv[1:]
plan=validate(Path(plan_path),plan_sha,source_sha,expected_head)
HERE=Path(output);TEMP=HERE/'temporary'
assert HERE.is_absolute()and HERE.resolve(strict=True)==HERE and HERE.parent==REPO/'.ios-host-tmp'
assert HERE.name.startswith('chat-offline-own4-')and TEMP.is_dir()and not list(TEMP.iterdir())
initial_fds,initial_threads=fds(),tuple(threading.enumerate())
initial_path,initial_meta=list(sys.path),list(sys.meta_path)
real_td=tempfile.TemporaryDirectory;real_cleanup=unittest.TestCase.doCleanups;cleanup_code=real_cleanup.__code__
initial_io=io.open,builtins.open
loaded={};td_callers=[];roots=[];directories=[];refusals=[];case_receipts=[];pending_case=None
result=None;returned=False;fatal=None;selected_cases=[]
method_seals=[]

def sdk_free():
    assert not [name for name in sys.modules if name.split('.')[0]in forbidden]

def seal(cls):
    for name,member in cls.__dict__.items():
        function=member.__func__ if type(member)in(classmethod,staticmethod)else member
        if hasattr(function,'__code__'):
            method_seals.append((cls,name,member,function,function.__code__,function.__globals__))
            wrapped=getattr(function,'__wrapped__',None)
            if wrapped is not None:method_seals.append((function,'__wrapped__',wrapped,wrapped,wrapped.__code__,wrapped.__globals__))

def unchanged_methods():
    for owner,name,member,function,code,namespace in method_seals:
        actual=owner.__dict__[name]if isinstance(owner,type)else getattr(owner,name)
        assert actual is member and function.__code__ is code and function.__globals__ is namespace

def save(name,value):
    path=HERE/name
    with path.open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
    path.chmod(0o600)

boundary_path=SOURCE/'owned_write_boundary.py'
assert sha(boundary_path)=='156560033c0c292aa72be6cd66af136683de28490341dceacc191398b5167bda'
spec=importlib.util.spec_from_file_location('chat_offline_e458_controller',boundary_path)
boundary_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(boundary_module)
boundary=boundary_module.OwnedWrites(HERE,protected=[Path(os.readlink('/proc/self/fd/'+str(n))).resolve(strict=True)for n in(1,2)])
original_ports=dict(boundary.original);boundary.install()
node=ChatNodePort(plan,HERE,pin,proc)
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright','PySide6','PyQt6')
project_tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespacePackages'])}
assert not any(name.split('.')[0]in project_tops for name in sys.modules)

def refuse(event,detail):
    refusals.append(dict(event=event,detail=detail));raise RuntimeError('CHAT_OFFLINE_CONTROLLER_REFUSED_'+event)

def audit(event,args):
    if event=='open'and type(args[0])is int and node.pipe_open(args,sys._getframe(1)):return
    if event=='subprocess.Popen':node.spawn(args,sys._getframe(1));return
    if event=='os.kill':node.signal(args,sys._getframe(1));return
    if event.startswith('socket.')or event in('os.system','os.exec','os.fork','os.forkpty','os.posix_spawn',
        'pty.spawn','ctypes.dlopen','os.killpg','os.setsid','os.setpgid','os.putenv','os.unsetenv','os.fchdir')or event.startswith('os.spawn'):
        refuse(event,'Only exact owned model Node/process/stdio, no network/SDK/compiler/device/service')
    if event=='import'and any(args[0]==name or args[0].startswith(name+'.')for name in forbidden):
        refuse(event,'Installed/vendor SDK import')
    if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
        path=os.fsdecode(args[0])
        if '/overte-ios-remotexpc/'in path or any('/'+name+'/'in path for name in forbidden):
            refuse(event,'Installed SDK path')
    if event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate',
        'os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.'):
        boundary.audit(event,args,sys._getframe(1))

sys.addaudithook(audit)
sdk_free()
monitor=sys.monitoring
monitor_ports=tuple((name,getattr(monitor,name))for name in('get_tool','get_events','use_tool_id','register_callback',
    'set_local_events','get_local_events','free_tool_id'))
tool_slots=[(monitor.get_tool(n),monitor.get_events(n))for n in range(6)]
tool=next((n for n in(5,4,3)if monitor.get_tool(n)is None),None)
assert tool is not None and monitor.get_events(tool)==0
monitor.use_tool_id(tool,'chat-offline-genuine-node-constructor-custody')
monitor.register_callback(tool,monitor.events.PY_START,node.constructor_start)
monitor.register_callback(tool,monitor.events.PY_RETURN,node.constructor_return)
constructor_code=node.popen.__init__.__code__
monitor.set_local_events(tool,constructor_code,monitor.events.PY_START|monitor.events.PY_RETURN)

class Loader(importlib.abc.Loader):
    def __init__(self,name,row):self.name,self.row=name,row
    def create_module(self,spec):return None
    def exec_module(self,module):
        path=Path(self.row['path']);assert pin(path)==plan['physicalPins'][str(path)]
        raw=path.read_bytes();module.__file__=str(path)
        if self.row['package']:module.__path__=[str(path.parent)]
        loaded[self.name]=self.row;exec(compile(raw,str(path),'exec'),module.__dict__)
        assert pin(path)==plan['physicalPins'][str(path)]
        names={'ios.self_tests.test_ios_installed_code':'InstalledCodeTests',
            'ios.self_tests.test_ios_chat_receive_runtime':'IOSChatReceiveRuntimeTests',
            'ios.self_tests.test_ios_chat_draft_owner':'ChatDraftOwnerTests'}
        if self.name in names:
            cls=vars(module)[names[self.name]];setup=cls.__dict__['setUp']
            td_callers.append((cls,setup,setup.__code__,setup.__globals__))

class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        row=plan['modules'].get(name)
        if row is not None:return importlib.util.spec_from_loader(name,Loader(name,row),is_package=row['package'])
        roots_=plan['namespacePackages'].get(name)
        if roots_ is not None:
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots_;return spec
        if name.split('.')[0]in project_tops:raise ImportError('Project import missing exact origin: '+name)
        return None

sys.meta_path.insert(0,Finder())
trace=(HERE/'term-stack.log').open('x')
def stop(_sig,_frame):
    faulthandler.dump_traceback(file=trace,all_threads=True);trace.flush()
    raise KeyboardInterrupt('Fixed180+5 four-case suite boundary')
old_term=signal.signal(signal.SIGTERM,stop)

class Result(unittest.TextTestResult):
    def startTest(self,test):
        global pending_case
        pending_case=test;node.current_case=test.id()
        self.case_fds=fds();self.case_threads=tuple(threading.enumerate())
        super().startTest(test)
    def stopTest(self,test):
        row=dict(id=test.id(),pendingCleanups=len(test._cleanups),roots=[r for r in roots if r['case']==test.id()])
        try:
            assert len(row['roots'])==3 and not test._cleanups
            row['node']=node.finish_case(test.id())
            unchanged_methods();sdk_free()
            assert fds()==self.case_fds and tuple(threading.enumerate())==self.case_threads
            assert not any(t not in initial_threads and t.is_alive()for t in threading.enumerate())
            row['controllerGatePassed']=True
        except BaseException:
            row['controllerGatePassed']=False;row['controllerFailure']=traceback.format_exc();self.stop()
        case_receipts.append(row);super().stopTest(test)

try:
    from ios.self_tests.chat_message_script_domain import ScriptMessageModel
    from ios.self_tests.chat_send_receive_fixture import BusScriptModel
    from ios.self_tests.retained_host_roots import retain_owned_root
    node.bind(ScriptMessageModel,BusScriptModel)
    from ios.adapters.chat_draft_owner import IOSChatDraftOwner
    from ios.adapters.chat_receive_sources import IOSChatReceiveSources
    from ios.adapters.chat_send_operation import IOSChatSendOperation
    from ios.adapters.chat_offline_send_operation import IOSChatOfflineSendOperation
    from ios.adapters.chat_draft_runtime import IOSChatDraftRuntime
    from ios.adapters.chat_draft_clock import Budget
    from adapters.normal_feature_state import PrivateFeatureState
    for cls in(IOSChatDraftOwner,IOSChatReceiveSources,IOSChatSendOperation,IOSChatOfflineSendOperation,IOSChatDraftRuntime,Budget,PrivateFeatureState):seal(cls)
    class RetainedDirectory(real_td):
        def __init__(self,*args,**kwargs):
            frame=sys._getframe(1)
            matches=[(cls,setup,code,namespace)for cls,setup,code,namespace in td_callers
                if frame.f_code is code and frame.f_globals is namespace and type(frame.f_locals.get('self'))is cls]
            assert len(matches)==1 and not args and not kwargs and node.current_case in plan['cases']
            cls,setup,code,namespace=matches[0]
            assert cls.__dict__['setUp']is setup and setup.__code__ is code and setup.__globals__ is namespace
            super().__init__(dir=TEMP)
            directory=Path(self.name);assert directory.parent==TEMP and directory.stat().st_mode&0o777==0o700
            retain_owned_root(self,expected_root=directory)
            roots.append(dict(case=node.current_case,path=str(directory),actualSetup=cls.__module__+'.'+cls.__qualname__))
            directories.append(self)
    tempfile.TemporaryDirectory=RetainedDirectory
    module_name='ios.self_tests.test_ios_chat_offline_send'
    module=__import__(module_name,fromlist=['ChatOfflineSendTests'])
    assert len(td_callers)==3
    suite=unittest.TestSuite()
    for selected in plan['cases']:
        prefix,cls,method=selected.rsplit('.',2);assert prefix==module_name and method in module.ChatOfflineSendTests.__dict__
        part=unittest.defaultTestLoader.loadTestsFromName(cls+'.'+method,module)
        assert part.countTestCases()==1
        case=next(iter(part));assert case.id()==selected;selected_cases.append(case);suite.addTest(case)
    assert sys.gettrace()is None and sys.getprofile()is None
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite);returned=True
except BaseException:
    fatal=traceback.format_exc()
finally:
    # On KeyboardInterrupt standard unittest may leave registered cleanups.
    # Drain only remaining callbacks in real stdlib order, retaining errors.
    cleanup=[]
    for case in selected_cases:
        old_outcome=case._outcome;drain=unittest.TestResult();ok=True;exception=None
        try:
            assert unittest.TestCase.doCleanups is real_cleanup and real_cleanup.__code__ is cleanup_code
            if case._cleanups:
                case._outcome=unittest.case._Outcome(drain);ok=real_cleanup(case)
        except BaseException:
            ok=False;exception=traceback.format_exc()
        finally:case._outcome=old_outcome
        cleanup.append(dict(id=case.id(),remaining=len(case._cleanups),success=ok,
            errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],originalException=exception))
    if fatal is not None or result is None or not result.wasSuccessful()or any(not row['controllerGatePassed']for row in case_receipts):
        save('original-failure-before-controller-drain.json',dict(fatal=fatal,cleanup=cleanup,
            cases=case_receipts,errors=[]if result is None else[dict(id=t.id(),traceback=text)for t,text in result.errors],
            failures=[]if result is None else[dict(id=t.id(),traceback=text)for t,text in result.failures]))
        node.abort_all()
    assert not [row['birth']for row in node.entries if proc(row['process'].pid)is not None], 'Refuse quiet inventory while an own Node remains'
    tempfile.TemporaryDirectory=real_td
    signal.signal(signal.SIGTERM,old_term);trace.close()
    monitor.set_local_events(tool,constructor_code,0)
    monitor.register_callback(tool,monitor.events.PY_START,None);monitor.register_callback(tool,monitor.events.PY_RETURN,None)
    assert monitor.get_local_events(tool,constructor_code)==0 and monitor.get_events(tool)==0
    monitor.free_tool_id(tool)
    monitor_ok=all(getattr(monitor,name)is value for name,value in monitor_ports)
    monitor_ok=monitor_ok and tool_slots==[(monitor.get_tool(n),monitor.get_events(n))for n in range(6)]
    sys.path[:]=initial_path;sys.meta_path[:]=initial_meta
    code_ok=all(pin(path)==row for path,row in plan['physicalPins'].items())
    sdk_ok=not any(name.split('.')[0]in forbidden for name in sys.modules)
    unchanged_methods()
    raws_first,raws_second=census(TEMP),census(TEMP)
    passed=returned and fatal is None and result is not None and result.wasSuccessful()and result.testsRun==4 and not result.skipped
    passed=passed and len(case_receipts)==4 and all(row['controllerGatePassed']for row in case_receipts)
    passed=passed and len(roots)==12 and len(node.entries)==4 and node.completed_cases==plan['cases']
    passed=passed and all(row['success']and not row['remaining']and not row['errors']for row in cleanup)
    passed=passed and not refusals and not node.controller_drains and sdk_ok and code_ok and monitor_ok and raws_first==raws_second
    passed=passed and fds()==initial_fds and tuple(threading.enumerate())==initial_threads and head()==expected_head
    passed=passed and sys.getprofile()is None and sys.gettrace()is None
    save('raw-first.json',raws_first);save('raw-second.json',raws_second)
    save('child-result.json',dict(status='PASS'if passed else'FAIL_OR_REFUSED',selected=plan['cases'],
        suiteReturned=returned,testsRun=0 if result is None else result.testsRun,fatal=fatal,refusals=refusals,
        cases=case_receipts,cleanup=cleanup,retainedTemporaryRoots=roots,importedOrigins=loaded,
        failureOnlyControllerDrains=node.controller_drains,
        allPhysicalPinsUnchanged=code_ok,monitorRestored=monitor_ok,
        actualFDThreadDrain=fds()==initial_fds and tuple(threading.enumerate())==initial_threads,
        twoOwnRawCensusesEqual=raws_first==raws_second,noSDKImported=sdk_ok,
        nativeQualified=False,currentDomainQualified=False,wholeQualified=False))
    restoration=HERE/'write-port-restoration.json'
    fd=os.open(restoration,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.close(fd)
    boundary.restore()
    restored=all(getattr(os,name)is value for name,value in original_ports.items())and(io.open,builtins.open)==initial_io
    restored=restored and not boundary.control_fds
    with boundary.original_io(restoration,'w')as stream:
        json.dump(dict(restored=restored,actualCportCount=len(original_ports),controlDescriptors=sorted(boundary.control_fds)),stream);stream.write('\n')
    boundary.close()
sys.exit(0 if passed and restored else 1)
