"""Check only retained private copies; this does not compile or execute Qt."""
from pathlib import Path
import hashlib
import json
import re
import stat
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
OWNED = REPO / '.ios-host-tmp'
PATCH = HERE / 'qtbase-overte-e2e-metacall-receipts.patch'
EXPECTED = {
    'qtbase/src/corelib/kernel/qobject_p.h': '5fa0582289ed0af15fb19de364b249b79f434ef4158df6810d4f22d6a0c68772',
    'qtbase/src/corelib/kernel/qobject.cpp': '937574b0def9e2afc48e8b8e8a2c51d42572b128af5b6137bfc69837e3a2fbbf',
    'qtbase/src/corelib/kernel/qmetaobject.cpp': 'd91a6cea78c54ef455e206bd8042eadfc7fbd4dff6fdceea8b7d7645fd0757ba',
}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def original(path):
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and not path.is_symlink()
            and before.st_size <= 262144, 'Unreviewed reference file')
    fields = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_gid', 'st_nlink',
              'st_size', 'st_mtime_ns', 'st_ctime_ns')
    pin = lambda item: tuple(getattr(item, field) for field in fields)
    data = path.read_bytes()
    require(pin(before) == pin(path.lstat()), 'Reference changed while read')
    return data, pin(before)


def verify(source_root, scratch_parent):
    source_root = Path(source_root).resolve(strict=True)
    scratch_parent = Path(scratch_parent).resolve(strict=True)
    owned = OWNED.resolve(strict=True)
    require(scratch_parent == owned or owned in scratch_parent.parents,
            'Scratch writes must remain within this worktree .ios-host-tmp')
    require(PATCH.resolve(strict=True) == PATCH and owned in PATCH.parents,
            'Patch must remain private')
    patch, patch_pins = original(PATCH)
    names = re.findall(rb'^--- a/([^\n]+)\n\+\+\+ b/([^\n]+)$', patch, re.M)
    require(len(names) == 3 and all(a == b for a, b in names)
            and {a.decode() for a, _ in names} == set(EXPECTED), 'Unexpected patch inventory')
    inputs = {}
    for name, digest in EXPECTED.items():
        path = source_root / name
        require(path.resolve(strict=True) == path, 'Noncanonical reference path')
        inputs[name] = original(path)
        require(sha(inputs[name][0]) == digest, 'Unknown Qt source: ' + name)
    # No result creation or git call occurs until every immutable source is accepted.
    target = Path(tempfile.mkdtemp(prefix='metacall-private-check-', dir=scratch_parent))
    target.chmod(0o700)
    for name, (data, _) in inputs.items():
        output = target / name
        output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        output.write_bytes(data)
        output.chmod(0o600)
    command = ['git', 'apply', '--whitespace=error-all',
               '--directory=' + str(target.relative_to(REPO))]
    for options in (['--check'], [], ['--reverse', '--check'], ['--reverse']):
        result = subprocess.run(command + options + [str(PATCH)], cwd=REPO,
                                capture_output=True, text=True, timeout=10)
        require(result.returncode == 0, 'Private apply/reverse failed: ' + result.stderr)
    for name, (data, pins) in inputs.items():
        require((target / name).read_bytes() == data, 'Reverse did not restore exact original')
        require(original(source_root / name) == (data, pins), 'Read-only original changed')
    require(original(PATCH) == (patch, patch_pins), 'Private patch changed during check')
    report = dict(qtMetaCallSourcePatchCheckVersion=1, qtVersion='6.11.1', apiVersion=1,
                  patchSha256=sha(patch), originalSha256=EXPECTED,
                  privateApplicationChecked=True, reverseApplicationChecked=True,
                  exactReverseBytesRestored=True, sourceOriginalsUnchanged=True,
                  nativeCompilationVerified=False, runtimeApiVerified=False,
                  deviceQualified=False, queuedProvenanceVerified=False,
                  argumentDestructionVerified=False, storageRetirementVerified=False)
    path = target / 'source-patch-check.json'
    path.write_text(json.dumps(report, indent=2) + '\n')
    path.chmod(0o600)
    return path
