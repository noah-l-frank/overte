"""Root-only single fixed source-model stage; no SDK/native execution."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,time
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[2];OUT=HERE/'root-run-first'
FIELDS=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
 p=OUT/name;fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode),str(p)
 value=dict(sha256=sha(p)) if stat.S_ISREG(a.st_mode) else {};value['stat']=[getattr(a,k) for k in FIELDS]
 assert value['stat']==[getattr(p.lstat(),k) for k in FIELDS];return value
def process(pid):
 try:v=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):return None
 return dict(pid=pid,parentPid=int(v[1]),pgid=int(v[2]),sid=int(v[3]),startTicks=int(v[19]))
def remaining(binding):
 rows=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  value=process(int(p.name))
  if value is not None and (value['pgid']==binding['pid'] or value['sid']==binding['pid']):rows.append(value)
 return rows
def sources(stage):
 names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0');paths={REPO/n for n in names if n};paths.add(REPO/'CMakeLists.txt')
 for relative,digest in json.loads((HERE/'freeze.json').read_text())['files'].items():
  path=HERE/relative;assert sha(path)==digest,str(path);paths.add(path)
 paths.add(HERE/'freeze.json')
 for row in stage['sourcePaths']:paths.add(REPO/row['path'])
 for relative in json.loads((HERE/'run-plan.json').read_text())['requiredPublicDependencies']:
  path=REPO/relative;assert path.resolve(strict=True)==path and path.is_file(),relative;paths.add(path)
 for packet_name,digest in stage['orderedParentFreezes'].items():
  packet=REPO/'.ios-host-tmp'/packet_name;assert sha(packet/'freeze.json')==digest
  paths.add(packet/'freeze.json')
  frozen=json.loads((packet/'freeze.json').read_text())['files']
  if isinstance(frozen,list):
   assert all(type(row) is dict and set(row)=={'path','sha256','bytes'} for row in frozen)
   assert len({row['path'] for row in frozen})==len(frozen)
   frozen={row['path']:row['sha256'] for row in frozen}
  for relative,expected in frozen.items():
   path=packet/relative;assert sha(path)==expected,str(path);paths.add(path)
 for row in json.loads((HERE/'sdk-original-pins.json').read_text()):
  for key in ('path','copy'):
   path=Path(row[key]);assert sha(path)==row['sha256'];paths.add(path)
 for name,expected in json.loads((HERE/'prior-retained-original-pins.json').read_text()).items():
  path=Path(name);assert pin(path)==expected,str(path);paths.add(path)
 return {str(path):pin(path) for path in sorted(paths)}
def census(root):return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
assert Path.cwd()==REPO and sys.dont_write_bytecode
for name,expected in json.loads((HERE/'freeze.json').read_text())['files'].items():assert sha(HERE/name)==expected,name
stage=json.loads((HERE/'source-manifest.json').read_text());expected={row['path']:row['candidateSHA256'] for row in stage['sourcePaths']}
for relative,digest in expected.items():assert sha(REPO/relative)==digest,relative
OUT.mkdir(mode=0o700,exist_ok=False)
before=sources(stage);save('source-before.json',before)
current={str(Path(path).relative_to(REPO)):row['sha256'] for path,row in before.items() if Path(path).is_relative_to(REPO) and '.ios-host-tmp' not in Path(path).relative_to(REPO).parts and 'sha256' in row}
config=dict(repositoryRoot=str(REPO),currentSourcePins=current,reviewedCandidates=expected)
save('root-source-map.json',config);map_pin=pin(OUT/'root-source-map.json')
settings=json.loads((HERE/'supervisor-plan.json').read_text());env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1')
for key,value in settings['environmentFiles'].items():env[key]=str(HERE/value);env[key+'_SHA256']=sha(HERE/value)
map_key=settings['rootMapEnvironment'];env[map_key]=str(OUT/'root-source-map.json');env[map_key+'_SHA256']=sha(OUT/'root-source-map.json')
root=HERE/settings['retainedDirectory'];assert not root.exists()
command=['timeout','--signal=TERM','--kill-after=5s',str(settings['initialSeconds'])+'s',sys.executable,str(HERE/'root-child.py')]
print('SOURCE_PINS',len(before),flush=True);started=time.monotonic()
with (OUT/'first.log').open('x') as log:
 task=subprocess.Popen(command,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 bound=process(task.pid);assert bound is not None and bound['sid']==bound['pgid']==task.pid
 save('process-binding.json',dict(task=bound,supervisor=process(os.getpid()),command=command));print('ACTUAL_PROCESS',json.dumps(bound),flush=True);code=task.wait()
assert not remaining(bound),'Owned process remains before original census'
after=sources(stage);save('source-after.json',after)
first=census(root) if root.exists() else {};assert not remaining(bound),'Owned process remains before second census'
second=census(root) if root.exists() else {};save('originals-first.json',first);save('originals-second.json',second)
left=remaining(bound);report=dict(exitCode=code,seconds=time.monotonic()-started,sourcePins=len(after),allPinsEqual=before==after,
 rootMapUnchanged=pin(OUT/'root-source-map.json')==map_pin,retainedOriginalsUnchanged=first==second,
 retainedFiles=sum(stat.S_ISREG(row['stat'][2]) for row in first.values()),remainingOwnedProcesses=left,
 nativeCompiled=False,actualAuthenticationQualified=False,wholeFeatureQualified=False)
save('report.json',report);print('ACTUAL_TERMINAL',json.dumps(report),flush=True)
assert before==after and first==second and not left and pin(OUT/'root-source-map.json')==map_pin
raise SystemExit(code)
