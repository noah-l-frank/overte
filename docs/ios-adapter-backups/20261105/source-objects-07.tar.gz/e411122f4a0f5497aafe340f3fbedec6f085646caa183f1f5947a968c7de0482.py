"""Proposed controller-only -S pre-unpickle bootstrap at real creator ports.

The original multiprocessing constructors and spawnv_passfds body still run.
Only their actual -c text is prefixed with an explicit independently pinned
child guard. This is new instrumentation, UNRUN and not a complete controller.
"""
from pathlib import Path
import hashlib, json, os, stat, sys, threading, types
from tablet_constructor_custody import FunctionBinding,CustodyRefusal

FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def file_pin(path):
    path=Path(path);before=path.lstat()
    if path.resolve(strict=True)!=path or not stat.S_ISREG(before.st_mode)or before.st_nlink!=1:
        raise CustodyRefusal('Exact ordinary canonical bootstrap source required')
    raw=path.read_bytes();after=path.lstat()
    values=tuple(getattr(before,k)for k in FIELDS)
    if values!=tuple(getattr(after,k)for k in FIELDS):raise CustodyRefusal('Bootstrap source changed while read')
    return dict(stat=list(values),sha256=hashlib.sha256(raw).hexdigest())

def kernel_identity(pid):
    if type(pid)is not int or pid<=0:raise CustodyRefusal('Actual positive kernel PID required')
    root=Path('/proc')/str(pid);raw=(root/'stat').read_text();end=raw.rfind(')')
    if end<0 or int(raw[:raw.index('(')].strip())!=pid:raise CustodyRefusal('Kernel stat identity unavailable')
    fields=raw[end+2:].split()
    return dict(pid=pid,state=fields[0],parentPID=int(fields[1]),processGroup=int(fields[2]),
        session=int(fields[3]),startTicks=int(fields[19]),executable=str((root/'exe').resolve(strict=True)))

class GuardedOriginalSpawn:
    def __init__(self,*,util_module,spawn_module,popen_module,tracker_module,
            actor_function,paired_class,run_open_function,guard_path,guard_pin,
            policy_path,policy_pin,owned_root,actor_roots,save_row):
        self.thread=threading.current_thread();self.util=util_module;self.spawn=spawn_module
        self.popen_module=popen_module;self.tracker_module=tracker_module
        self.original=FunctionBinding(util_module.spawnv_passfds)
        self.launch=FunctionBinding(popen_module.Popen._launch)
        self.tracker_class=tracker_module.ResourceTracker;self.tracker=tracker_module._resource_tracker
        self.tracker_launch=FunctionBinding(self.tracker_class._launch)
        self.actor=FunctionBinding(actor_function);self.open=FunctionBinding(run_open_function)
        self.paired_class=paired_class;self.paired=FunctionBinding(paired_class.__init__)
        self.guard_path=Path(guard_path);self.guard_pin=guard_pin
        self.policy_path=Path(policy_path);self.policy_pin=policy_pin
        self.root=Path(owned_root).resolve(strict=True);self.actor_roots=actor_roots
        self.save=FunctionBinding(save_row);self.records=[];self.installed=False;self.active=False;self.closed=False
        self.executable=Path(sys.executable).resolve(strict=True);self.executable_pin=file_pin(self.executable)
        self.parent=kernel_identity(os.getpid());self.std=Path(os.__file__).resolve(strict=True).parent
        self.std_paths=(str(self.std),str(self.std/'lib-dynload'))
        for path in self.std_paths:
            if Path(path).resolve(strict=True)!=Path(path):raise CustodyRefusal('Actual canonical stdlib paths required')
        if not sys.flags.no_site or not sys.dont_write_bytecode:raise CustodyRefusal('Parent must actually use -S and -B')
        if self.tracker._pid is not None or self.tracker._fd is not None:
            raise CustodyRefusal('Existing tracker is outside the selected original family')
        owner=self
        def guarded_spawnv_passfds(path,args,passfds):
            return owner.invoke(sys._getframe(1),path,args,passfds)
        self.port=guarded_spawnv_passfds;self.port_binding=FunctionBinding(self.port)
        self.method_bindings=tuple((key,value,FunctionBinding(value))for key,value in vars(type(self)).items()
            if type(value)is types.FunctionType)
        self.guard()
    def guard(self):
        if self.closed or threading.current_thread()is not self.thread:raise CustodyRefusal('Spawn bridge lifetime/thread')
        for key,value,binding in self.method_bindings:
            if vars(type(self)).get(key)is not value:raise CustodyRefusal('Spawn bridge method replaced')
            binding.guard()
        for binding in(self.original,self.launch,self.tracker_launch,self.actor,self.open,self.paired,self.save,self.port_binding):binding.guard()
        if self.util.spawnv_passfds is not(self.port if self.installed else self.original.function):
            raise CustodyRefusal('Actual spawn port installation changed')
        if self.popen_module.Popen._launch is not self.launch.function or self.tracker_class._launch is not self.tracker_launch.function:
            raise CustodyRefusal('Genuine child constructor member changed')
        if self.tracker_module._resource_tracker is not self.tracker or type(self.tracker)is not self.tracker_class:
            raise CustodyRefusal('Actual tracker receiver changed')
        if self.paired_class.__init__ is not self.paired.function:raise CustodyRefusal('Paired fixture constructor changed')
        if file_pin(self.guard_path)!=self.guard_pin or file_pin(self.policy_path)!=self.policy_pin:
            raise CustodyRefusal('Actual independent bootstrap/policy source changed')
        if Path(sys.executable).resolve(strict=True)!=self.executable or file_pin(self.executable)!=self.executable_pin:
            raise CustodyRefusal('Actual interpreter executable changed')
    def install(self):
        self.guard()
        if self.installed:raise CustodyRefusal('Spawn bridge installed twice')
        self.util.spawnv_passfds=self.port;self.installed=True;self.guard()
    def source_frame(self,frame,binding):
        binding.frame(frame)
        return frame.f_locals
    def role(self,caller,args,passfds):
        if caller.f_code is self.tracker_launch.code and caller.f_globals is self.tracker_launch.namespace:
            values=self.source_frame(caller,self.tracker_launch)
            if values.get('self')is not self.tracker or args is not values.get('args')or passfds is not values.get('fds_to_pass'):
                raise CustodyRefusal('Tracker actual receiver/argv/passfd object mismatch')
            ancestor=caller.f_back;found=False
            while ancestor is not None:
                if ancestor.f_code is self.paired.code and ancestor.f_globals is self.paired.namespace:
                    self.paired.frame(ancestor)
                    if type(ancestor.f_locals.get('self'))is not self.paired_class:raise CustodyRefusal('Foreign Paired fixture receiver')
                    found=True;break
                ancestor=ancestor.f_back
            if not found or self.records:raise CustodyRefusal('Tracker must be the fresh original initial Value child')
            return 'tracker',None
        values=self.source_frame(caller,self.launch);process=values.get('process_obj');owner=values.get('self')
        if type(owner)is not self.popen_module.Popen or args is not values.get('cmd')or passfds is not owner._fds:
            raise CustodyRefusal('Actor genuine Popen/argv/passfd receiver mismatch')
        if process is None or process._target is not self.actor.function or type(process._args)is not tuple or len(process._args)!=3:
            raise CustodyRefusal('Actor actual target/arguments changed')
        ancestor=caller.f_back;found=None
        while ancestor is not None:
            if ancestor.f_code is self.open.code and ancestor.f_globals is self.open.namespace:found=ancestor;break
            ancestor=ancestor.f_back
        if found is None:raise CustodyRefusal('Actor birth outside original run_open')
        self.open.frame(found);values=found.f_locals;fixture=values.get('f')
        if type(fixture)is not self.paired_class or values.get('process')is not process:
            raise CustodyRefusal('Actor original run_open process/fixture mismatch')
        inputs,clock,channel=process._args
        if type(inputs)is not tuple or len(inputs)!=5 or clock is not fixture.clock or channel is not values.get('child'):
            raise CustodyRefusal('Actor actual shared Value/channel mismatch')
        producer=Path(inputs[0])
        if producer.resolve(strict=True)!=producer or producer!=fixture.boundary.root or producer not in self.actor_roots():
            raise CustodyRefusal('Actor actual producer root is not one of the retained real roots')
        if len(self.records)!=1 or self.records[0]['role']!='tracker':
            raise CustodyRefusal('Actor birth requires exactly the actual preceding original tracker')
        return 'actor',producer
    def startup(self,role,producer,original_text):
        binding=dict(version=1,role=role,parent=self.parent,ownedRoot=str(self.root),
            actorRoot=None if producer is None else str(producer),
            policyPath=str(self.policy_path),policyPin=self.policy_pin,
            guardPath=str(self.guard_path),guardPin=self.guard_pin,
            originalCommandSha256=hashlib.sha256(original_text.encode()).hexdigest())
        # sys is a genuine builtin under -S. Remove every non-stdlib search
        # path BEFORE importing hashlib/pathlib or executing the pinned guard.
        # The original command text is subsequently executed verbatim; its
        # target/Process pickle, auth material and semantics are never rewritten.
        prefix='import sys as _tg_sys;_tg_sys.path[:]=%r;'%(list(self.std_paths),)
        prefix+='import hashlib as _tg_hashlib;'
        prefix+='_tg_path=%r;_tg_raw=open(_tg_path,"rb").read();'%str(self.guard_path)
        prefix+='assert _tg_hashlib.sha256(_tg_raw).hexdigest()==%r;'%self.guard_pin['sha256']
        prefix+='_tg_ns={"__name__":"tablet_spawn_guard","__file__":_tg_path,"BOOTSTRAP":%r};'%binding
        prefix+='exec(compile(_tg_raw,_tg_path,"exec"),_tg_ns);'
        prefix+='exec(compile(%r,"<string>","exec"));'%original_text
        return prefix,binding
    def invoke(self,caller,path,args,passfds):
        self.guard()
        if not self.installed or self.active or len(self.records)>=2:raise CustodyRefusal('Unexpected/recursive interpreter child birth')
        if Path(os.fsdecode(path)).resolve(strict=True)!=self.executable or type(args)is not list or type(passfds)is not list:
            raise CustodyRefusal('Exact actual interpreter/argv/passfd types required')
        if not all(type(item)in(str,bytes)for item in args)or not all(type(fd)is int and fd>=0 for fd in passfds):
            raise CustodyRefusal('Actual child argument types refused')
        if len(passfds)!=len(set(passfds)):raise CustodyRefusal('Duplicate child FD capability')
        role,producer=self.role(caller,args,passfds)
        if args.count('-c')!=1:raise CustodyRefusal('Only original single -c child entry')
        position=args.index('-c')+1
        if position>=len(args)or type(args[position])is not str:raise CustodyRefusal('Original child command missing')
        original_text=args[position];actual=list(args)
        actual[position],binding=self.startup(role,producer,original_text)
        fd_rows={str(fd):dict(device=(s:=os.fstat(fd)).st_dev,inode=s.st_ino,mode=s.st_mode)for fd in passfds}
        self.active=True
        try:pid=self.original.function(path,actual,passfds)
        finally:self.active=False
        # Read the actual numeric child's kernel executable before potentially
        # slow source/JSON validation. No basename, parent DTO or return ACK is
        # substituted if /proc already became unavailable.
        identity=kernel_identity(pid)
        if identity['parentPID']!=self.parent['pid']or identity['executable']!=str(self.executable):
            raise CustodyRefusal('Actual original child parent/executable mismatch')
        row=dict(role=role,originalArguments=[os.fsdecode(x)for x in args],
            actualArguments=[os.fsdecode(x)for x in actual],actualOriginalCommand=original_text,
            startupBinding=binding,passedDescriptors=fd_rows,kernel=identity,
            originalSpawnvPassfdsReturned=True,childGuardClaimedPassed=False)
        self.records.append(row);self.save.guard();self.save.function('spawn-'+role+'-original.json',row)
        self.guard();return pid
    def restore(self):
        self.guard()
        if self.active:raise CustodyRefusal('Original child creator still active')
        self.util.spawnv_passfds=self.original.function;self.installed=False;self.guard();self.closed=True
        return dict(originalSpawnPortRestored=True,actualInterpreterChildren=len(self.records),
            expectedRoles=['tracker','actor'],observedRoles=[row['role']for row in self.records],
            allChildrenClaimedAbsent=False,guardBeforeUnpickleClaimedQualified=False)
