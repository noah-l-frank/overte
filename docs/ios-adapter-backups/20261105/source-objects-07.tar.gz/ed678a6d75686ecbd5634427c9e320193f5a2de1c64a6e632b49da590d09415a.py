"""Root exact Source3 base/candidate metadata only. No public mutation/import."""
from pathlib import Path
import hashlib
import json
import os

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
own=json.loads((HERE/'freeze.json').read_text())
for name,expected in own['files'].items():assert sha(HERE/name)==expected,name
plan=json.loads((HERE/'composition/plan.json').read_text())
assert len(plan['paths'])==3
actual=[]
for row in plan['paths']:
    path=REPO/row['path'];base=row['base']
    if base is None:assert not path.exists() and not path.is_symlink(),row['path']
    else:assert path.resolve(strict=True)==path and sha(path)==base['sha256'],row['path']
    candidate=HERE/'composition/candidate'/row['path'];assert sha(candidate)==row['candidateSha256']
    actual.append(dict(path=row['path'],baseSha256=None if base is None else sha(path),candidateSha256=sha(candidate)))
target=HERE/'root-prepublication-readback.json'
descriptor=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(descriptor,'w') as output:
    output.write(json.dumps(dict(status='ACTUAL_SOURCE3_BASES_CANDIDATES_READONLY',paths=actual),indent=2)+'\n')
    output.flush();os.fsync(output.fileno())
print('EXACT3_SOURCE_BASES_CANDIDATES_VERIFIED_NO_PUBLIC_MUTATION',flush=True)
