// Copyright 2026 Overte contributors.
// SPDX-License-Identifier: Apache-2.0
#pragma once
#include <QVariant>
#include <QVariantList>
#include <QVariantMap>
#include <cmath>
// Passive diagnostic boundary only. No global ScriptEngine/V8 conversion is
// changed. Existing native v1 receipt keys and bounded values stay untouched.
namespace overte::e2e {
inline bool chatQmlWireValue(const QVariant &value,int depth,int &nodes) {
    if (depth>32 || ++nodes>16384) return false;
    switch (value.metaType().id()) {
    case QMetaType::QVariantMap:
        for (const auto &child:value.toMap()) if (!chatQmlWireValue(child,depth+1,nodes)) return false;
        return true;
    case QMetaType::QVariantList:
        for (const auto &child:value.toList()) if (!chatQmlWireValue(child,depth+1,nodes)) return false;
        return true;
    case QMetaType::QString:case QMetaType::Bool:case QMetaType::Int:case QMetaType::UInt:return true;
    // Actual V8 cast converts Long/ULong through toInt/toUInt, even on LP64.
    case QMetaType::Long:return value.toLongLong()>=-2147483648LL && value.toLongLong()<=2147483647LL;
    case QMetaType::ULong:return value.toULongLong()<=4294967295ULL;
    case QMetaType::LongLong:return value.toLongLong()>=-9007199254740991LL && value.toLongLong()<=9007199254740991LL;
    case QMetaType::ULongLong:return value.toULongLong()<=9007199254740991ULL;
    case QMetaType::Float:case QMetaType::Double: {
        const auto number=value.toDouble();return std::isfinite(number) && std::trunc(number)==number && std::abs(number)<=9007199254740991.0;
    }
    default:return false;
    }
}
inline bool chatQmlWireValue(const QVariantMap &value) { int nodes=0;return chatQmlWireValue(QVariant(value),0,nodes); }
}
