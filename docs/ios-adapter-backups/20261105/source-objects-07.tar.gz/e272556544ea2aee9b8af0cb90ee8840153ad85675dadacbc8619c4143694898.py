from pathlib import Path
import ast,difflib,hashlib,json,shutil
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';OLD=T/'lifecycle-original-owner-native-acquisition8-current-shared-root-preparation-20261028/10-native-acquisition8';PACK=T/'lifecycle-original-owner-motion-owned-reference-proposal-20261028';TOP=T/'lifecycle-original-owner-motion-owned-root-preparation-20261028';TOP.mkdir(mode=0o700);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(PACK/'freeze.json')=='14974e3f73f758b2d812c6f69d63b02a56bf7266a7511b0bf709a63052b21bff'
for rel,sha in json.loads((PACK/'freeze.json').read_bytes())['files'].items():assert h(PACK/rel)==sha
m=json.loads((PACK/'manifest.json').read_bytes());test=json.loads((PACK/'test-plan.json').read_bytes());base_stage=json.loads((OLD/'source-manifest.json').read_bytes());base_plan=json.loads((OLD/'run-plan.json').read_bytes());original_pins=json.loads((OLD/'prior-retained-original-pins.json').read_bytes())
# Root reported correctedAcq8 terminal PASS: preserve its ACTUAL36 originals too.
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=h(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=OLD/'retained-first';assert prior.is_dir()
for p in [prior,*sorted(prior.rglob('*'))]:original_pins[str(p)]=pin(p)
assert sum('sha256' in v for v in original_pins.values())==147
# Build exact future shared bytes by applying ONLY reviewed three own lines to
# actual CURRENT registry/validator. No stale whole shared file is authoritative.
shared={};owned_line_changes=json.loads((PACK/'compatibility-own-lines.json').read_bytes())
for relative in ('tests/device/contract-versions.json','tests/device/validate_contract_versions.py'):
 raw=(R/relative).read_text();value=raw
 for row in owned_line_changes:
  if row['path']!=relative:continue
  assert value.count(row['originalLine'])==1,(relative,row['key']);value=value.replace(row['originalLine'],row['newLine'],1)
 shared[relative]=(raw,value)
for number,name,with_node in ((11,'11-owned-motion14',True),(12,'12-default-acquisition8',False)):
 S=TOP/name;S.mkdir(mode=0o700)
 for filename in ('root-child.py','root-supervise.py','root_stage_guard.py','source_model_bindings.py','run-selected.py','sdk-original-pins.json','supervisor-plan.json'):
  shutil.copyfile(OLD/filename,S/filename)
 source_rows={row['path']:dict(row) for row in base_stage['sourcePaths']};source_delta=[];snapshot_changes=[]
 # Owned3 exact candidates. Identical runtime is only dependency.
 for row in m['files']:
  if row['path'] in shared or not row['changesBase']:continue
  source_rows[row['path']]=dict(path=row['path'],candidate=row['candidate'],candidateSHA256=row['candidateSHA256'],observedPublicSHA256=h(R/row['path']),changesCurrentPublic=h(R/row['path'])!=row['candidateSHA256']);source_delta.append(row['path'])
 for relative,(raw,value) in shared.items():
  dest=S/'shared-after-owned-lines/repo'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(value)
  source_rows[relative]=dict(path=relative,candidate=str(dest),candidateSHA256=h(dest),observedPublicSHA256=h(R/relative),changesCurrentPublic=raw!=value,ownThreeLinesOnly=True)
  source_delta.append(relative)
 # Every unchanged dependency remains precisely pinned. Explicit snapshots
 # absorb independently Root-reviewed/current changes; no sourcepin is removed.
 owned=set(source_delta)
 for relative,row in source_rows.items():
  if relative in owned:continue
  current=h(R/relative)
  if current!=row['candidateSHA256']:
   dest=S/'current-dependency-snapshots/repo'/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/relative,dest)
   snapshot_changes.append(dict(path=relative,previousCandidateSHA256=row['candidateSHA256'],actualCurrentSHA256=current))
   row.update(candidate=str(dest),candidateSHA256=current,observedPublicSHA256=current,changesCurrentPublic=False)
 stage=json.loads(json.dumps(base_stage));stage.update(stage=number,name=name,status='PRIVATE_UNRUN_OWNED_MOTION14' if with_node else 'PRIVATE_UNRUN_DEFAULT_ACQUISITION8_POST_MOTION',caseCount=14 if with_node else 8,pythonCaseCount=10 if with_node else 8,nodeCaseCount=4 if with_node else 0,sourcePaths=list(source_rows.values()),sourcePathCount=len(source_rows),sourceDeltaPaths=source_delta,exactPublicMutationPlan='Own runtime3 exact hunks + own3 version lines per current shared file; source already published for regression stage. NEVER apply whole shared snapshots.')
 stage['orderedParentFreezes']['lifecycle-original-owner-motion-owned-source-checkpoint-20261028']=h(T/'lifecycle-original-owner-motion-owned-source-checkpoint-20261028/freeze.json');stage['orderedParentFreezes']['lifecycle-original-owner-motion-owned-reference-proposal-20261028']=h(PACK/'freeze.json')
 (S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n');(S/'prior-retained-original-pins.json').write_text(json.dumps(original_pins,indent=2)+'\n');shutil.copyfile(PACK/'proposal.diff',S/'source-checkpoint-and-own-lines.diff')
 (S/'own-shared-lines.diff').write_text(''.join(''.join(difflib.unified_diff(raw.splitlines(True),value.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)) for relative,(raw,value) in shared.items()))
 plan=json.loads(json.dumps(base_plan));plan.update(status='PRIVATE_UNRUN_PY10_NODE4' if with_node else 'PRIVATE_UNRUN_SAME_OLD8_PROFILE1',caseCount=10 if with_node else 8,totalCaseCount=14 if with_node else 8,cases=test['pythonExactIds'] if with_node else base_plan['cases'],expectedRetainedRoots=10 if with_node else 8)
 if with_node:
  for filename in ('test_motion_owned_reference_models.py','test_native_cold_wda_models.mjs','native_acquisition_fixture.py','native_file_fixture.py'):shutil.copyfile(PACK/filename,S/filename)
  p=S/'run-selected.py';s=p.read_text();s=s.replace('import hashlib,json,os,sys,tempfile,threading,unittest','import hashlib,json,os,sys,tempfile,threading,unittest,subprocess')
  a='        return 0 if result.wasSuccessful() else 1';b="""        if not result.wasSuccessful():return 1
        # Four exact actual-JS cold-WDA models; same owned process group, no
        # installed SDK imports or services. Actual engine bytes are pinned.
        node=plan['node'];pinned(node['executable'],node['sha256'])
        environment={'PATH':'/usr/bin','LANG':'C.UTF-8',
            'LIFECYCLE_WDA_SESSION_MODEL_MAP':os.environ['LIFECYCLE_WDA_SESSION_MODEL_MAP'],
            'LIFECYCLE_WDA_SESSION_MODEL_MAP_SHA256':os.environ['LIFECYCLE_WDA_SESSION_MODEL_MAP_SHA256']}
        child=subprocess.run([node['executable'],'--test',str(HERE/node['module'])],cwd=HERE,
            env=environment,timeout=node['initialSeconds'],check=False)
        return 0 if child.returncode==0 else 1""";assert s.count(a)==1;p.write_text(s.replace(a,b));ast.parse(p.read_bytes())
  (S/'runner-node4.diff').write_text(''.join(difflib.unified_diff((OLD/'run-selected.py').read_text().splitlines(True),p.read_text().splitlines(True),fromfile='a/run-selected.py',tofile='b/run-selected.py')))
  node=Path('/usr/local/lib/overte-ios-remotexpc/5.15.3-r12/bin/node').resolve(strict=True)
  plan['node']=dict(executable=str(node),sha256=h(node),module='test_native_cold_wda_models.mjs',initialSeconds=15,caseCount=4,exactNames=test['nodeExactNames'])
  sdk=json.loads((S/'sdk-original-pins.json').read_bytes());sdk.append(dict(path=str(node),copy=str(node),sha256=h(node),scope='Actual existing Node engine original. No binary copy/install, same path in both slots, source-model interpreter only, not SDK/native qualification.'));(S/'sdk-original-pins.json').write_text(json.dumps(sdk,indent=2)+'\n')
  plan['modelMaps']['LIFECYCLE_WDA_SESSION_MODEL_MAP']={'proxy':'tests/device/ios/source-patches/original-owner-appium/node_modules/appium-xcuitest-driver/node_modules/@appium/base-driver/lib/jsonwp-proxy/proxy.ts','hostops':'tests/device/ios/appium_wda_host_ops.js'}
  model_names=('test_motion_owned_reference_models.py','test_native_cold_wda_models.mjs','native_acquisition_fixture.py','native_file_fixture.py')
 else:
  for filename in ('test_native_acquisition_models.py','native_file_fixture.py'):shutil.copyfile(OLD/filename,S/filename)
  assert h(S/'test_native_acquisition_models.py')=='d5296ffd701ed4ecedc3d57f2bcfbb687a1f4f3b3090131f6d4f617b05306d09'
  model_names=('test_native_acquisition_models.py','native_file_fixture.py')
 plan['privateFiles']={filename:h(S/filename) for filename in ('root_stage_guard.py','source_model_bindings.py','run-selected.py',*model_names)}
 plan['modelMaps']['LIFECYCLE_NATIVE_FILE_MAP']['resourceOwner']='tests/device/ios/adapters/lifecycle_touch_resource_owner.py'
 plan['requiredPublicDependencies']=sorted(set(plan['requiredPublicDependencies'])|{'tests/device/ios/adapters/lifecycle_touch_resource_owner.py','tests/device/ios/source-patches/original-owner-appium/node_modules/appium-xcuitest-driver/node_modules/@appium/base-driver/lib/jsonwp-proxy/proxy.ts'})
 for key,value in [('ios-lifecycle-touch-resource-owner',{'current':3,'reads':[1,2,3]}),('original-keeper-motion-preparation',{'current':2,'reads':[1,2]}),('original-keeper-native-acquisition',{'current':2,'reads':[1,2]})]:plan['registryRequirements'][key]=value
 plan['qualification']='Explicit SDK/native/RSD/window/WDA/creator/HTTP producer models. Actual source dispatch/issued Task retention/birth AST, nonce/WAL/raw FD/frame/source-ref/CAS and Node original source flow. No actual installed source/binary/candidate/native/motion/end admission.'
 (S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
 (S/'clone-provenance.json').write_text(json.dumps(dict(parentFreezeSHA256=h(OLD/'freeze.json'),packetFreezeSHA256=h(PACK/'freeze.json'),sourcePathCount=len(source_rows),pythonCount=10 if with_node else 8,nodeCount=4 if with_node else 0,initialOuterSeconds=60,killAfterSeconds=5,nodeInnerSeconds=15 if with_node else None,expectedRealRoots=10 if with_node else 8,priorOriginalFilesGuarded=147,source3CheckpointUnchanged=True,unchangedDependencySnapshots=snapshot_changes,sharedPolicy='Exact own3 changes on current whole shared snapshots for expected post-PUB bytes. NEVER overwrite foreign shared files. Fresh actual Root map BEFORE target imports; Sourcepins remain strict.'),indent=2)+'\n')
 (S/'README.txt').write_text('''ROOT ONLY / PRIVATE UNRUN. New owned Motion source3 +own compatibility3 lines
per file, frozen14974e3f. Capture/native/candidate/end/canonical gates stay false.
Main stage: exact10 Python+4 actual-JS cold-WDA cases, outer60+kill5/Nodeinner15,
expected10 genuine TouchLease TD. Regression stage: same old NativeAcq8/model
d5296ffd,60+5/8TD to check DEFAULT profile1; no old Motion7 positive frameJSON
suite is claimed unchanged (new RPC explicitly requires actual source refs).

Root source/launcher/official SDK/current Node engine byte+stat pins mandatory,
all shared registry/validator expected bytes are freshly based on ACTUAL current
foreign keys plus ONLY three own version edits, no stale whole candidate apply.
Every existing selected source hash remains checked; independently Root-updated
unchanged dependencies are explicitly snapshotted, no pins removed or relaxed.
Parent must generate actual current full source map AFTER own-hunk publication,
BEFORE target imports. Original root source/SDK/context/clock authority unqualified.

Actual retained REAL TD via single TouchLease module-local alias; preserve all
original socketpair/HTTP server/reader-task cleanup LIFO. Models compile actual
keeper dispatch/writer and exact issued/schedule/add/discard statements, actual
creator birth fields execute inside real live creator Task. Weak capture Task
has actual ops.issued strong lifetime; no fake returned/awaited Task. Actual
window read Task/FD remains original and shielded until original return under
cancellation/source drain. Root deadline is not a resource completion witness.

Before both retained original censuses, actual pending Task/Thread/FD/child/SDK
import guards remain unchanged; no GC assumption/FD exception/fake close. Prior
actual147 native/candidate/original files+allnodes pinned in both full source
censuses. Node child inherits owned process group, uses ONLY builtins+actual
source snippets and declared SDK producer models, no service/SDK initializer.
Code/AST hashes are diagnostic provenance, not runtime binary/auth identity.

Root reviews then from repository with PYTHONDONTWRITEBYTECODE=1:
python3 <this directory>/root-supervise.py
No agent imports/resolver/Node parser/tests/build/device/services/public/index.
''')
 for p in S.rglob('*.py'):ast.parse(p.read_bytes())
 (S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN_ROOT_MOTION_AND_DEFAULT_REGRESSION',files={str(p.relative_to(S)):h(p) for p in sorted(S.rglob('*')) if p.is_file()}),indent=2)+'\n')
 print(json.dumps(dict(stage=name,freeze=h(S/'freeze.json'),python=10 if with_node else 8,node=4 if with_node else 0,sources=len(source_rows),snapshots=snapshot_changes)))
(TOP/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_BOTH_STAGES_UNRUN',files={str(p.relative_to(TOP)):h(p) for p in sorted(TOP.rglob('*')) if p.is_file()}),indent=2)+'\n');print('PARENT',h(TOP/'freeze.json'))
