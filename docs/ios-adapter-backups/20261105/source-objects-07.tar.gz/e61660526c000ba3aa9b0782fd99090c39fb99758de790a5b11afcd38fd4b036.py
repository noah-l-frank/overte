"""Prospective genuine host parents/PFS/OFS/locks; no completed End fixture.

The existing native capture/received producer boundary remains explicitly
modeled by the original fixture. AFC close-decision models below exercise only
connection identity; they are not HouseArrest/SDK/file-absence originals.
"""
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.self_tests.test_ios_audio_shared_actor import SharedActorTests
from ios.adapters.audio_shared_actor_end import SharedActorEnd
from ios.adapters.audio_shared_actor_response_retirement import ReplyReadView
from ios.adapters.audio_response_command import FILES,command,target_flags
from ios.adapters.audio_response_afc_original import close_original_handle


class DeclaredTargetAdapter:
    """Only explicit lower-fixture target metadata, never a live SDK owner."""
    def __init__(self,path):self.path=path
    def state_path(self,_selector):return self.path
    def _target(self,_selector):
        return dict(testBuild=dict(launchArguments=['--e2e-audio-response-file-ownership']))


class AudioReplyParentTests(unittest.TestCase):
    close_manager=SharedActorTests.close_manager
    receive=SharedActorTests.receive
    coordinator=SharedActorTests.coordinator
    def setUp(self):
        SharedActorTests.setUp(self)
        self.runtime.adapter=DeclaredTargetAdapter(self.base.f.root/'session.json')
    def end(self):
        c=self.coordinator();self.receive(c)
        e=SharedActorEnd(c,epoch_ms=self.m.epoch,monotonic=lambda:self.m.clock,sleep=self.m.sleep)
        e.prepare();return c,e
    def test_real_two_parents_prepare_three_empty_slots_and_reopen_without_source(self):
        with self.lock.held():
            c,e=self.end();calls=self.runtime.calls;commands=deepcopy(self.manager.commands)
            self.assertEqual(2,e.previous['iosAudioSharedActorEndVersion'])
            self.assertEqual(set(FILES),set(e.state['responses']));self.assertIsNone(e.state['replyContext'])
            for filename in FILES:
                view=ReplyReadView(e,filename);self.assertEqual('empty',view.state()['phase']);self.assertEqual(set(),view.owned_paths())
            fresh=SharedActorEnd(c,epoch_ms=self.m.epoch,monotonic=lambda:self.m.clock,sleep=self.m.sleep)
            self.assertEqual(e.previous,fresh.previous);self.assertEqual(e.original_snapshot(),fresh.original_snapshot())
            self.assertEqual(calls,self.runtime.calls);self.assertEqual(commands,self.manager.commands)
            with self.assertRaises(NativeUIError):fresh.original()
    def test_actual_unparsed_reply_artifact_remains_a_duty(self):
        with self.lock.held():
            c,e=self.end();path=e.root/'foreign-reply-original.json'
            PrivateFeatureState(path).write(dict(unknown=True),None);calls=self.runtime.calls
            with self.assertRaises(NativeUIError):c.guard()
            self.assertTrue(path.exists());self.assertEqual(calls,self.runtime.calls)
    def test_real_final_cas_lost_return_latches_old_owner_and_reopens_actual_header(self):
        with self.lock.held():
            c,e=self.end();write=PrivateFeatureState.write;observed=[]
            def lost(store,value,previous):
                result=write(store,value,previous)
                if store.path==e.store.path and not observed:
                    observed.append(True);raise OSError('Actual saved End header return lost')
                return result
            e.state['phase']='ending'
            with patch.object(PrivateFeatureState,'write',lost),self.assertRaises(OSError):e.save()
            self.assertTrue(e.failed)
            with self.assertRaises(NativeUIError):e.bound()
            fresh=SharedActorEnd(c,epoch_ms=self.m.epoch,monotonic=lambda:self.m.clock,sleep=self.m.sleep)
            self.assertEqual('ending',fresh.state['phase']);self.assertIsNone(fresh.state['keeperProof'])
            self.assertTrue(all(row['phase']=='empty'for row in fresh.state['responses'].values()))
    def test_literal_old_end_version_is_not_migrated_or_rebased(self):
        with self.lock.held():
            c,e=self.end();old=e.store.read();prior=deepcopy(old);prior['iosAudioSharedActorEndVersion']=1
            e.store.write(prior,old);calls=self.runtime.calls
            with self.assertRaises(NativeUIError):SharedActorEnd(c)
            self.assertEqual(prior,e.store.read());self.assertEqual(calls,self.runtime.calls)
    def test_missing_reply_originals_cannot_become_complete_from_phase_bits(self):
        with self.lock.held():
            c,e=self.end();calls=self.runtime.calls
            for filename in FILES:
                with self.assertRaises(NativeUIError):ReplyReadView(e,filename).original({})
            with self.assertRaises(NativeUIError):e.reply_original()
            self.assertEqual(calls,self.runtime.calls);self.assertIsNone(e.state['keeperProof'])
    def test_exact_file_command_and_explicit_target_flags_refuse_other_duties(self):
        with self.lock.held():
            c,e=self.end();calls=self.runtime.calls
            request=dict(schemaVersion=1,commandId='ios-'+'a'*32,action='feature-ios-audio-response-retire',runId=c.run,
                file=FILES[0],lastReplyId='ios-'+'b'*32,rawSha256='c'*64)
            self.assertEqual(request,command(request))
            for name in('../'+FILES[0],'feature-native-observation-other.json','feature-ios-audio-session.json'):
                with self.assertRaises(NativeUIError):command(dict(request,file=name))
            with self.assertRaises(NativeUIError):command(dict(request,schemaVersion=True))
            with self.assertRaises(NativeUIError):target_flags(dict(testBuild=dict(launchArguments=[])))
            with self.assertRaises(NativeUIError):target_flags(dict(testBuild=dict(launchArguments=['--e2e-audio-response-file-ownership','--e2e-emote-response-file-ownership'])))
            self.assertEqual(calls,self.runtime.calls);self.assertTrue(all(row['phase']=='empty'for row in e.state['responses'].values()))


class DeclaredConnection:pass
class DeclaredAFC:
    """Lowest close-decision model only; no absence/SDK/native verdict."""
    def __init__(self,connection):self._service=connection;self.closed=[]
    async def fclose(self,handle):self.closed.append(handle)


class AudioReplyCloseTests(unittest.IsolatedAsyncioTestCase):
    async def test_held_actual_model_connection_closes_only_its_supplied_handle(self):
        connection=DeclaredConnection();service=DeclaredAFC(connection)
        await close_original_handle(service,connection,17,NativeUIError)
        self.assertEqual([17],service.closed);self.assertIs(connection,service._service)
    async def test_replaced_or_missing_connection_refuses_before_lazy_close(self):
        connection=DeclaredConnection();service=DeclaredAFC(DeclaredConnection())
        with self.assertRaises(NativeUIError):await close_original_handle(service,connection,17,NativeUIError)
        self.assertEqual([],service.closed);service._service=None
        with self.assertRaises(NativeUIError):await close_original_handle(service,connection,17,NativeUIError)
        self.assertEqual([],service.closed)
