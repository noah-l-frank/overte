"""Actual existing RPC query/read/retained worker; SDK/native/HID are models."""
import asyncio,json
from copy import deepcopy
from unittest.mock import patch
import test_native_motion_existing_rpc_models as rpc_fixture


class NativePassiveScopeModels(rpc_fixture.NativeMotionExistingRPCModels):
    async def open_motion(self):
        args=await self.prepare_rpc();packet,_=await self.rpc_begin(args);self.assertEqual('complete',packet['status'])
        return self.ops.touch
    def passive_args(self,action):return dict(self.acquire_args(),action=action,nativePassiveReadVersion=1)
    async def issue(self,action):
        value=await self.ops.execute('touch-native-query',self.passive_args(action),self.binding['sessionId'])
        self.assertEqual(4,value['originalKeeperNativeQueryVersion']);return value
    async def read(self,issued):
        args=dict(binding=deepcopy(self.binding),runId=self.run,resultsDirectory=self.acquire_args()['resultsDirectory'],
            query=deepcopy(issued['query']),nativePassiveReadVersion=1)
        return await self.ops.execute('touch-native-original-read',args,self.binding['sessionId'])
    async def observed(self):
        from ios.adapters import lifecycle_world as world
        issued=await self.issue(world.ACTION);value=await self.read(issued)
        self.assertEqual(4,value['originalKeeperNativeFileVersion']);self.assertEqual(issued['passiveLeaseId'],value['passiveLeaseId'])
        self.assertEqual(issued['passivePhase'],value['passivePhase']);packet=json.loads(value['rawJson']);world.original(packet)
        self.assertEqual(42,packet['processId']);self.assertEqual(self.run,packet['runId']);return issued,value,packet

    async def test_actual_held_world_then_after_own_up_terminal_world_share_original_source_and_unchanged_input_intent(self):
        from ios.adapters import lifecycle_world as world
        lease=await self.open_motion();source=self.source;rsd=self.rsd
        issued,held,packet=await self.observed();self.assertEqual('holding',held['passivePhase'])
        self.assertEqual(1,len(packet['source']['touch']['active']));self.assertFalse(source._closing)
        self.assertEqual(4,self.ops.native_query_journals[self.run]['previous']['originalKeeperNativeQueryOwnerVersion'])
        result=await self.ops.execute('touch-release',{},self.binding['sessionId']);self.assertEqual(2,result['iosOriginalKeeperTouchVersion'])
        self.assertFalse(result['inspection']['hostResponsibility']);self.assertFalse(source._closing)
        _,released,current=await self.observed();self.assertEqual('released',released['passivePhase'])
        proof=world.contact_released(packet,current);self.assertEqual('released',proof['terminal'])
        self.assertIs(self.source,source);self.assertIs(self.rsd,rsd);self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes());self.assertEqual(3,len(self.journal()['previous']['frames']))
        self.assertEqual({},self.ops.native_passive_tasks);await self.ops.execute('touch-settle',{},self.binding['sessionId']);self.assertTrue(source._closing)

    async def test_profile_without_actual_born_lease_cannot_use_preparation_or_dto_as_passive_source(self):
        from ios.adapters import lifecycle_world as world
        await self.prepare_rpc();before=len(self.commands)
        with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
        self.assertEqual(before,len(self.commands));self.assertEqual([],self.source._born);self.assertEqual([],self.f.states())
        self.assertEqual({},self.ops.native_passive_tasks)

    async def test_foreign_or_old_unprofiled_nonce_cannot_borrow_current_passive_scope_before_service_open(self):
        await self.open_motion();await self.ops.execute('touch-release',{},self.binding['sessionId'])
        await self.issue('feature-native-observe');services=len(self.services)
        old=next(row['query'] for row in self.ops.native_query_journals[self.run]['previous']['records']
            if row['query']['action']=='feature-native-observe' and 'passiveLeaseId' not in row)
        for query in (old,dict(schemaVersion=1,commandId='ios-'+'f'*32,action='feature-native-observe')):
            with self.assertRaises((RuntimeError,ValueError)):await self.read(dict(query=query))
        self.assertEqual(services,len(self.services));self.assertEqual({},self.ops.native_passive_tasks)

    async def test_foreign_finished_worker_slot_then_restoration_cannot_revive_passive_source(self):
        from ios.adapters import lifecycle_world as world
        lease=await self.open_motion();await self.ops.execute('touch-release',{},self.binding['sessionId']);original=lease.worker
        foreign=asyncio.create_task(asyncio.sleep(0));await foreign;lease.worker=foreign;before=len(self.commands)
        try:
            with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
        finally:lease.worker=original
        with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
        self.assertEqual(before,len(self.commands));self.assertTrue(self.selected[3]['revoked']);self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        self.assertEqual({},self.ops.native_passive_tasks)

    async def test_original_source_loss_refuses_new_passive_read_but_final_old_settle_remains_possible(self):
        from ios.adapters import lifecycle_world as world
        await self.open_motion();await self.ops.execute('touch-release',{},self.binding['sessionId']);before=len(self.commands);services=len(self.services)
        with patch.object(self.cap,'current',side_effect=RuntimeError('Explicit current source loss')):
            with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
            await self.ops.execute('touch-settle',{},self.binding['sessionId'])
        self.assertEqual(before,len(self.commands));self.assertEqual(services,len(self.services));self.assertTrue(self.source._closing)
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual({},self.ops.native_passive_tasks)

    async def test_profile4_journal_cannot_silently_accept_or_downgrade_unprofiled_bundle_calls(self):
        from ios.adapters import lifecycle_world as world
        await self.open_motion();await self.issue(world.ACTION);owner=self.ops.native_query_journals[self.run]
        before=deepcopy(owner['previous']);body=owner['store'].path.read_bytes();commands=len(self.commands)
        args=dict(self.acquire_args(),action='ios-bundle-observe',nativeBundleProfileVersion=1)
        with self.assertRaises((RuntimeError,ValueError)):await self.ops.execute('touch-native-query',args,self.binding['sessionId'])
        self.assertEqual(before,owner['previous']);self.assertEqual(body,owner['store'].path.read_bytes());self.assertEqual(commands,len(self.commands))
        self.assertEqual(4,owner['previous']['originalKeeperNativeQueryOwnerVersion']);self.assertEqual({},self.ops.native_passive_tasks)

    async def test_pending_original_drain_is_unavailable_then_same_original_return_allows_released_world(self):
        from ios.adapters import lifecycle_world as world
        lease=await self.open_motion();self.f.context.drain_gate.clear();self.f.context.drain_started.clear()
        release=asyncio.create_task(self.ops.execute('touch-release',{},self.binding['sessionId']));self.controls_motion.append(release)
        await self.f.context.drain_started.wait();before=len(self.commands)
        try:
            with self.assertRaises((RuntimeError,ValueError)):await self.issue(world.ACTION)
            self.assertEqual(before,len(self.commands));self.assertFalse(lease.worker.done());self.assertFalse(self.resource._native_step._failed)
        finally:self.f.context.drain_gate.set()
        await release;_,value,packet=await self.observed();self.assertEqual('released',value['passivePhase']);self.assertEqual([],packet['source']['touch']['active'])
        self.assertEqual(1,self.f.context.exited);self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual({},self.ops.native_passive_tasks)

    async def test_read_crossing_actual_up_refuses_held_result_then_new_released_query_still_works(self):
        from ios.adapters import lifecycle_world as world
        lease=await self.open_motion();issued=await self.issue(world.ACTION)
        self.hook=lambda _service:lease.request_release.set()
        try:
            with self.assertRaises((RuntimeError,ValueError)):await self.read(issued)
        finally:self.hook=None
        await lease.worker;self.assertFalse(self.resource._native_step._failed);self.assertEqual({},self.ops.native_passive_tasks)
        _,value,packet=await self.observed();self.assertEqual('released',value['passivePhase']);self.assertEqual([],packet['source']['touch']['active'])
        self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_original_unprofiled_default1_release_still_closes_whole_source_and_remains_version1(self):
        lease=await self.touch();result=await self.ops.execute('touch-release',{},self.binding['sessionId'])
        self.assertEqual(1,result['iosOriginalKeeperTouchVersion']);self.assertTrue(self.source._closing)
        self.assertFalse(result['inspection']['hostResponsibility']);self.assertEqual([0xC2,0x02],self.f.states())
        self.assertTrue(lease.closed);self.assertEqual({},self.ops.native_passive_tasks)

    async def test_unrelated_loop_callback_or_foreign_task_cannot_borrow_live_original_query_scope(self):
        from ios.adapters import lifecycle_world as world
        await self.open_motion();await self.ops.execute('touch-release',{},self.binding['sessionId'])
        before=len(self.commands);self.response_gate.clear()
        query=asyncio.create_task(self.issue(world.ACTION));self.controls_motion.append(query)
        try:
            # Actual owned HTTP reaches its original producer, then waits for
            # the real response gate. The original before-send callback has
            # already run; no synthetic predicate or SDK result is supplied.
            while len(self.commands)==before:await asyncio.sleep(.001)
            scope=self.ops.native_passive_tasks[query]
            self.assertIsNotNone(scope._query_callback);self.assertFalse(scope._query_callback._active)
            with self.assertRaises((RuntimeError,ValueError)):scope.current()
            completed=asyncio.Event();outcome=[]
            def unrelated():
                self.assertIsNone(asyncio.current_task())
                try:scope.current()
                except (RuntimeError,ValueError):outcome.append('refused')
                else:outcome.append('accepted')
                finally:completed.set()
            self.loop.call_soon(unrelated);await completed.wait()
            self.assertEqual(['refused'],outcome);self.assertIsNone(self.ops.native_passive_callback)
            self.assertFalse(self.resource._native_step._failed)
        finally:self.response_gate.set()
        value=await query;self.assertEqual(4,value['originalKeeperNativeQueryVersion'])
        self.assertEqual('released',value['passivePhase']);self.assertIsNone(self.ops.native_passive_callback)
        self.assertEqual({},self.ops.native_passive_tasks);self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_copied_check_code_from_foreign_task_cannot_register_actual_pending_http_bridge(self):
        import types
        from unittest.mock import patch
        from ios.adapters import lifecycle_world as world
        await self.open_motion();await self.ops.execute('touch-release',{},self.binding['sessionId'])
        original=self.loop.call_soon_threadsafe;captured=[];ready=asyncio.Event()
        def delayed(callback,*args,**kwargs):
            # Explicit scheduling model: retain the FIRST real source check
            # before delivery. Its original HTTP Thread/Future remain pending.
            scope=next(iter(self.ops.native_passive_tasks.values()),None)
            token=None if scope is None else scope._query_callback
            if token is not None and getattr(callback,'__code__',None) is token._check_code and not captured:
                captured.append(callback);original(ready.set);return None
            return original(callback,*args,**kwargs)
        with patch.object(self.loop,'call_soon_threadsafe',side_effect=delayed):
            query=asyncio.create_task(self.issue(world.ACTION));self.controls_motion.append(query)
            try:
                await ready.wait();scope=self.ops.native_passive_tasks[query];token=scope._query_callback
                actual=captured[0];future=token._registered[actual]
                forged=types.FunctionType(actual.__code__,actual.__globals__,name=actual.__name__,closure=actual.__closure__)
                self.assertIs(actual.__code__,forged.__code__);self.assertFalse(future.done())
                self.assertIsNotNone(token._thread);self.assertTrue(token._thread.is_alive())
                with self.assertRaises((RuntimeError,ValueError)):token.register(forged,future)
                self.assertEqual({actual:future},token._registered);self.assertFalse(future.done())
                self.assertFalse(self.resource._native_step._failed)
            finally:
                if captured:original(captured[0])
            result=await query
        self.assertEqual(4,result['originalKeeperNativeQueryVersion']);self.assertEqual('released',result['passivePhase'])
        self.assertEqual({},self.ops.native_passive_tasks);self.assertIsNone(self.ops.native_passive_callback)
        self.assertEqual([0xC2,0xC2,0x02],self.f.states())
