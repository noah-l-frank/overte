"""Three UNRUN genuine ordinary-flow preflight controls, not SDK positives.

The inherited TerminalDomain explicitly models native/SDK/GPU observations.
Original JS/HTTPS/Scene/Final inputs, owners/constructors/files/locks stay real.
None of these bodies fabricates a provider, Source, frame, PID, spec or End.
"""
from copy import deepcopy
import unittest

from adapters.normal_ui import NativeUIError
from ios.self_tests.test_ios_avatar_keeper_handoff import AvatarKeeperHandoffTests as HandoffCase
from avatar_existing_end_verification import run_existing_sealed_pair, reopen_completed_pair


class AvatarExistingEndPreflightTests(unittest.TestCase):
    retain_originals = True
    domain_type = HandoffCase.domain_type
    domain = HandoffCase.domain
    issued_original_pin = HandoffCase.issued_original_pin
    recovered_public_preparation = HandoffCase.recovered_public_preparation
    preparation_unchanged = HandoffCase.preparation_unchanged
    recovered_scene = HandoffCase.recovered_scene
    continue_final = HandoffCase.continue_final
    ready = HandoffCase.ready

    @classmethod
    def setUpClass(cls):
        HandoffCase.setUpClass()

    @classmethod
    def tearDownClass(cls):
        HandoffCase.tearDownClass()

    @staticmethod
    def effects(domain):
        return deepcopy(dict(sdk=domain.sdk_requests,
            inputs={role:native.lifecycle_inputs for role,native in domain.natives.items()}))

    def test_genuine_unsealed_scene_final_pair_refuses_before_any_Stop_or_DELETE(self):
        domain = self.ready(sealed=False)
        before = self.effects(domain)
        with self.assertRaises(NativeUIError):
            run_existing_sealed_pair(domain.owners['primary'])
        self.assertEqual(before, self.effects(domain))

    def test_actual_actor_owner_cannot_become_the_primary_end_coordinator(self):
        domain = self.ready(sealed=False)
        before = self.effects(domain)
        with self.assertRaises(NativeUIError):
            run_existing_sealed_pair(domain.owners['actor'])
        self.assertEqual(before, self.effects(domain))

    def test_real_sealed_pair_without_original_End_refuses_historical_reopen(self):
        domain = self.ready()
        before = self.effects(domain)
        with self.assertRaises(NativeUIError):
            reopen_completed_pair(domain.owners['primary'])
        self.assertEqual(before, self.effects(domain))
