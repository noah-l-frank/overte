"""Exactly four real boundary counters. No feature or device qualification."""
from pathlib import Path
from types import FrameType
import argparse,builtins,importlib.abc,importlib.machinery,io,json,os,signal,sys,tempfile,threading,traceback,unittest
from utility_common import SOURCE,REPO,admitted,pin,load,sha,head,proc,table,fds,census
from closed_import_origins import ClosedOrigins
p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--input-sha',required=True);p.add_argument('--output',required=True);a=p.parse_args()
plan,input_before=admitted(a.input,a.input_sha);HERE=Path(a.output)
assert plan['ownBoundaryCompositionVersion']==9 and plan['currentHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
assert pin(SOURCE/'closed_import_origins.py')['sha256']==plan['currentHelperSha256']
assert plan['prefixGuardSourceVersion']==8 and plan['prefix4Freeze']=='3c5d0d06fd79e0c24c0abff81a0caed89a025695e63b06e8040729281ff87f09'
assert plan['requiredActualRejectedStarts']==plan['requiredActualMatchingRejectedUnwinds']==1
assert plan['requiredActualOriginalNSSReads']==1 and plan['actualOwnB6NegativeFreeze']=='7208810ae09a1349805ac1b3e03b1a82ba92ba2633317ece432447d719d2f7c2'
assert HERE.is_absolute()and HERE.resolve(strict=True)==HERE and HERE.parent==REPO/'.ios-host-tmp'and HERE.name.startswith('avatar-boundary-own4-output-')
assert not(HERE/'temporary').exists();(HERE/'temporary').mkdir(mode=0o700)
source_before={path:pin(path)for path in plan['physicalPins']};fd_before=fds();threads_before=tuple(threading.enumerate());kernel_before=table()
path_before=list(sys.path);meta_before=list(sys.meta_path);temp_before=tempfile.tempdir
profile_before=sys.getprofile();trace_before=sys.gettrace();assert profile_before is None and trace_before is None
tools_before=tuple((sys.monitoring.get_tool(i),sys.monitoring.get_events(i))for i in range(6))
origins=ClosedOrigins(plan,SOURCE,REPO,pin)
native_entries=[]
class NativeDefinitions:
    def __init__(self):
        self.tool=None;self.codes={};self.name='avatar-own-definition-only-'+str(os.getpid())
    def start(self):
        m=sys.monitoring;free=[i for i in(2,5,4,3,1,0)if m.get_tool(i)is None];assert free
        self.m=m;self.tool=free[0];m.use_tool_id(self.tool,self.name);m.register_callback(self.tool,m.events.PY_START,self.entered)
    def imported(self,name,module):
        if name=='ios.self_tests.avatar_people_node':
            function=module.PeopleNode.__init__;code=function.__code__;self.codes[id(code)]=(code,function,function.__globals__)
            self.m.set_local_events(self.tool,code,self.m.events.PY_START);return
        if not name.startswith('adapters.native_'):return
        for value in vars(module).values():
            if type(value)is not type or value.__module__!=name or not value.__name__.startswith('Native'):continue
            for member_name in('__init__','read','send','capture','query'):
                function=value.__dict__.get(member_name)
                if type(function)in(classmethod,staticmethod):function=function.__func__
                if not hasattr(function,'__code__'):continue
                code=function.__code__;self.codes[id(code)]=(code,function,function.__globals__)
                self.m.set_local_events(self.tool,code,self.m.events.PY_START)
    def entered(self,code,offset):
        row=self.codes.get(id(code));assert row is not None and row[0]is code and row[1].__code__ is code
        frame=sys._getframe(1);assert frame.f_code is code and frame.f_globals is row[2]
        native_entries.append(dict(file=code.co_filename,function=code.co_name));raise RuntimeError('Native definitions only: instance/query refused before body')
    def stop(self):
        m=self.m;t=self.tool;assert m.get_tool(t)==self.name
        for code,function,namespace in self.codes.values():m.set_local_events(t,code,0)
        m.register_callback(t,m.events.PY_START,None);assert m.get_events(t)==0;m.free_tool_id(t);self.tool=None
native_guard=NativeDefinitions();native_guard.start()
class AfterActualLoader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name=name;self.delegate=delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module);native_guard.imported(self.name,module)
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name in plan['modules']:
            spec=origins.file_spec(name,dict(plan['modules'][name],loader='source'),'project')
            spec.loader=AfterActualLoader(name,spec.loader);return spec
        if name in plan['namespacePackages']:
            roots=plan['namespacePackages'][name];origins.namespaces(name,roots,roots,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots;return spec
        return origins.remaining_spec(name,path)
finder=Finder();sys.meta_path.insert(0,finder)
import utility_runtime
original_io,original_builtin=io.open,builtins.open
runtime=utility_runtime.Runtime(HERE,plan,proc).boot()
assert runtime.outer.original_io is original_io and runtime.outer.original_builtin is original_builtin
assert io.open is original_io and builtins.open is original_builtin
# Exact E458 currently leaves C IO original. Capture before installation for
# independent custody anyway; no observed wrapper failure is inferred.
original_ports=dict(runtime.outer.original)
tail_births={};tail_code=None;tail_function=None;tail_globals=None
def audit(event,args):
    if event=='import'and any(part in('pymobiledevice3','tidevice','pyidevice','zeroconf','appium','selenium','playwright')for part in args[0].split('.')):
        raise RuntimeError('Actual vendor SDK import refused')
    if event in('os.system','os.exec','os.fork','os.forkpty','os.posix_spawn','pty.spawn','os.killpg','os.setsid','os.setpgid')or event.startswith('ctypes.'):
        raise RuntimeError('Unselected process/native port')
    relevant=event in('open','subprocess.Popen','os.kill','os.mkdir','os.remove','os.rmdir','os.rename','os.chmod','os.chown','os.utime','os.truncate','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith(('socket.','fcntl.'))
    if not relevant:return
    caller=sys._getframe(1)
    if event=='open'and runtime.owner is None and tail_function is not None:
        target,mode,flags=args;path=Path(os.fsdecode(target))if type(target)in(str,bytes)else None
        row=tail_births.get(path)
        if (row is not None and mode=='w'and flags==(os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC)
                and caller.f_code is tail_code and caller.f_globals is tail_globals and caller.f_locals.get('path')==path
                and tail_function.__code__ is tail_code and tail_function.__globals__ is tail_globals
                and all(getattr(os,name)is original for name,original in original_ports.items())and io.open is original_io and builtins.open is original_builtin and pin(path)==row):return
    runtime.audit(event,args,caller)
sys.addaudithook(audit)
cleanup_function=unittest.TestCase.doCleanups;cleanup_code=cleanup_function.__code__;cleanup_globals=cleanup_function.__globals__;cleanups=[]
cleanup_name='avatar-own-original-cleanups-'+str(os.getpid());m=sys.monitoring;free=[i for i in(2,5,4,3,1,0)if m.get_tool(i)is None];assert free;cleanup_tool=free[0];m.use_tool_id(cleanup_tool,cleanup_name)
def cleaned(code,offset,value):
    assert code is cleanup_code and cleanup_function.__code__ is cleanup_code and unittest.TestCase.doCleanups is cleanup_function
    frame=sys._getframe(1);assert type(frame)is FrameType and frame.f_code is code and frame.f_globals is cleanup_globals
    owner=frame.f_locals['self'];cleanups.append(dict(testId=owner.id(),returned=value,remaining=len(owner._cleanups)))
m.register_callback(cleanup_tool,m.events.PY_RETURN,cleaned);m.set_local_events(cleanup_tool,cleanup_code,m.events.PY_RETURN)
cases=[];result=None;fatal=None;returned=False;checks=[];failures=[]
class Result(unittest.TextTestResult):
    def startTest(self,test):cases.append(test);super().startTest(test)
def interrupted(signum,frame):raise KeyboardInterrupt('Actual outer utility deadline')
old_term=signal.signal(signal.SIGTERM,interrupted)
def save(name,value):
    path=HERE/name
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as out:json.dump(value,out,sort_keys=True,indent=2);out.write('\n');out.flush();os.fsync(out.fileno())
def check(name,function):
    try:
        value=function();checks.append(dict(name=name,returned=True));return value
    except BaseException:
        failures.append(dict(name=name,traceback=traceback.format_exc()));return None
try:
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases']);assert not loader.errors and suite.countTestCases()==4
    def flatten(s):
        for test in s:
            if isinstance(test,unittest.TestSuite):yield from flatten(test)
            else:yield test
    assert [test.id()for test in flatten(suite)]==plan['cases']
    save('actual-selection.json',dict(ids=plan['cases'],loaderErrors=loader.errors))
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite);returned=True
except BaseException:fatal=traceback.format_exc();traceback.print_exc()
finally:
    # Each real pending callback still uses the exact original standard order.
    for case in cases:
        if case._cleanups:check('pending-original-cleanups-'+case.id(),lambda case=case:cleanup_function(case))
    if runtime.case is not None:check('actual-partial-case-controller-drain',runtime.leave)
    signal.signal(signal.SIGTERM,old_term)
    # Never make one failed verification suppress later independent attempts.
    def clear_cleanup_tool():
        assert m.get_tool(cleanup_tool)==cleanup_name
        m.set_local_events(cleanup_tool,cleanup_code,0);m.register_callback(cleanup_tool,m.events.PY_RETURN,None);assert m.get_events(cleanup_tool)==0;m.free_tool_id(cleanup_tool)
    check('original-cleanup-monitor-stop',clear_cleanup_tool)
    check('actual-native-definition-monitor-stop',native_guard.stop)
    origin_after=check('all-actual-origin-snapshot',lambda:origins.snapshot('after-actual-cleanup'))
    pins_after=check('all-actual-source-pins',lambda:{path:pin(path)for path in source_before})
    input_after=check('actual-input-pin',lambda:pin(a.input))
    first=check('actual-owned-raw-first',lambda:census(HERE/'temporary'));second=check('actual-owned-raw-second',lambda:census(HERE/'temporary'))
    data=dict(cases=runtime.case_records,retainedTemporaryDirectories=runtime.retained,controllerRescues=runtime.rescues,actualCommunicateReturns=runtime.communicates,actualRawOutputs=runtime.raw_records,standardCleanups=cleanups)
    check('save-actual-case-data',lambda:save('actual-case-data.json',data))
    check('save-source-origin-data',lambda:save('actual-origins.json',origin_after))
    check('save-owned-raw-first',lambda:save('actual-raw-first.json',first));check('save-owned-raw-second',lambda:save('actual-raw-second.json',second))
    # Birth exact tail inodes through active real mutation ports.
    for name in('result.json','restoration.json','finalization.json'):
        def birth(name=name):
            path=HERE/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600);os.close(fd);tail_births[path]=pin(path)
        check('tail-birth-'+name,birth)
    restored=check('real-final-port-restoration',runtime.finish)
    def restore_imports():
        assert sys.meta_path==[finder,*meta_before];sys.meta_path[:]=meta_before;sys.path[:]=path_before;tempfile.tempdir=temp_before
    check('original-path-and-import-restoration',restore_imports)
    fd_ok=fds()==fd_before;thread_ok=tuple(threading.enumerate())==threads_before
    kernel=table();new_children=[row for pid,row in kernel.items()if row['parentPid']==os.getpid()and row!=kernel_before.get(pid)]
    tool_ok=tuple((m.get_tool(i),m.get_events(i))for i in range(6))==tools_before and sys.getprofile()is profile_before and sys.gettrace()is trace_before
    port_ok=all(getattr(os,name)is original for name,original in original_ports.items())and io.open is original_io and builtins.open is original_builtin
    cleanup_ok=len(cleanups)==4 and all(row['returned']is True and row['remaining']==0 for row in cleanups)
    passed=(result is not None and result.wasSuccessful()and result.testsRun==4 and returned and fatal is None and not failures
        and pins_after==source_before and input_after==input_before and first is not None and first==second and origin_after is not None
        and fd_ok and thread_ok and tool_ok and port_ok and not new_children and not native_entries and cleanup_ok and restored is not None
        and restored['actualRejectedStarts']==plan['requiredActualRejectedStarts']==1 and restored['actualMatchingRejectedUnwinds']==plan['requiredActualMatchingRejectedUnwinds']==1
        and restored['actualTLSBirths']==2 and restored['actualFixtureListeners']==1 and restored['actualOriginalNSSReads']==plan['requiredActualOriginalNSSReads']==1 and len(runtime.rescues)==1 and len(runtime.retained)==6)
    def tail_write(path,value):
        assert path in tail_births and pin(path)==tail_births[path]and runtime.owner is None and port_ok
        with original_io(path,'w')as out:json.dump(value,out,sort_keys=True,indent=2);out.write('\n');out.flush();os.fsync(out.fileno())
    tail_function=tail_write;tail_code=tail_write.__code__;tail_globals=tail_write.__globals__
    check('save-actual-restoration',lambda:tail_write(HERE/'restoration.json',restored))
    report=dict(actualSourceExecutionHelperSha256=sha(SOURCE/'closed_import_origins.py'),actualSourceExecutionQualification=plan['currentSourceExecution']['rootFreeze'],ownBoundaryCompositionVersion=9,historicalOwn8IsNotCurrentQualification=True,fullPrefixQualified=False,status='PASS'if passed else'FAIL_OR_REFUSED',testsRun=0 if result is None else result.testsRun,selected=plan['cases'],suiteReturned=returned,fatal=fatal,
        actualFDsEqual=fd_ok,actualThreadsEqual=thread_ok,actualToolsEqual=tool_ok,actualPortsEqual=port_ok,remainingKernelChildren=new_children,originalCleanupEstablished=cleanup_ok,
        allPinsEqual=pins_after==source_before,inputPinAndCliShaEqual=input_after==input_before,twoRawCensusesEqual=first==second,finalizationFailures=failures,retainedTDs=runtime.retained,
        actualRejectedStarts=0 if restored is None else restored['actualRejectedStarts'],actualMatchingRejectedUnwinds=0 if restored is None else restored['actualMatchingRejectedUnwinds'],actualTLSBirths=0 if restored is None else restored['actualTLSBirths'],actualFixtureListeners=0 if restored is None else restored['actualFixtureListeners'],actualOriginalNSSReads=0 if restored is None else restored['actualOriginalNSSReads'],NodeExecutions=0,SDKExecutions=0,prohibitedNativeOrNodeEntries=native_entries,positiveActorAuthority=False,nativeQualified=False,wholeQualified=False)
    check('save-actual-result',lambda:tail_write(HERE/'result.json',report));check('save-independent-finalization',lambda:tail_write(HERE/'finalization.json',dict(checks=checks,failures=failures)))
    passed=passed and not failures
raise SystemExit(0 if passed else 1)
