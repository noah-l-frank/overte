"""Review-only single-root envelope around the unchanged Chat2 supervisor."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,time

HERE=Path(__file__).resolve().parent
REPO=HERE.parent.parent
HEAD='0bad4b4a6cdda7dd6979c1ac707db5b3f81db629'
CHAT=REPO/'.ios-host-tmp/chat-source15-retained-phase-readonly-controller2-20261103'
CHAT_FREEZE='ffe5550362f1bb6db14ff6327a54168f0103856a3fa67ae5448a3b6a8d53ef93'
EMOTE=REPO/'.ios-host-tmp/emote-saved-third748-single-passive-controller3-complete-old-corpora-root0bad-preparation-20261103'
ROOT=REPO/'.ios-host-tmp/emote-shared-current-round-own5-qualified-window600-root-preparation-20261103/first1/retained-first'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads(path.read_text())
def save(path,value):
    descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(descriptor,'w')as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def metadata_module(name,path,expected):
    assert sha(path)==expected
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module

assert Path.cwd()==REPO and sys.dont_write_bytecode
assert len(sys.argv)==2 and sys.argv[1]==sha(HERE/'freeze.json'),'Exact reviewed outer freeze required'
outer_freeze=sys.argv[1];manifest=load(HERE/'freeze.json')
for name,digest in manifest['files'].items():assert sha(HERE/name)==digest
plan=load(HERE/'plan.json')
assert not(HERE/'report.json').exists()and not(HERE/'chat-supervisor.log').exists(),'Single use; no unchanged retry'
assert sha(CHAT/'freeze.json')==CHAT_FREEZE
assert sha(EMOTE/'freeze.json')==plan['emoteFreeze']
assert sha(EMOTE/'global-original-corpus-baseline.json')==plan['emoteBaselineSha256']
expected=load(EMOTE/'global-original-corpus-baseline.json')[str(ROOT)]
assert expected==load(HERE/'expected-extra-root.json')and sum('sha256'in row for row in expected.values())==748
chat=metadata_module('_chat2_outer_metadata',CHAT/'metadata.py',plan['chatMetadataSha256'])
prior=metadata_module('_emote631_exact_census',EMOTE/'global_original_corpus.py',plan['emoteCensusSha256'])
chat.validate();host=chat.load('host-executable-pins.json')
assert str(Path(sys.executable).resolve())==host['python']['path']
assert sha(Path(plan['gitPath']))==plan['gitSha256']
assert subprocess.check_output([plan['gitPath'],'rev-parse','HEAD'],cwd=REPO,text=True).strip()==HEAD

def known_root_census():
    # EXACT original pin() and the same per-root body from Emote.current().
    # Never call roots(), current() or guard(): no global rescan or root-set
    # replacement, monkeypatch, optional omission or new observation authority.
    assert ROOT.is_dir()and ROOT.resolve(strict=True)==ROOT
    return {str(path.relative_to(ROOT)):prior.pin(path)for path in(ROOT,*sorted(ROOT.rglob('*')))}

before=known_root_census();assert before==expected,'Existing748-root baseline changed before Chat'
save(HERE/'extra-root-before.json',before)
fd_before=chat.fds()
assert not(CHAT/'report.json').exists()and not(CHAT/'test.log').exists(),'No old target artifacts may be reused'
command=[host['python']['path'],'-B',str(CHAT/'supervise.py'),CHAT_FREEZE]
started=time.monotonic()
environment=os.environ.copy();environment.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='')
with(HERE/'chat-supervisor.log').open('x')as output:
    process=subprocess.Popen(command,cwd=REPO,env=environment,stdin=subprocess.DEVNULL,
        stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
    bound=chat.proc(process.pid);assert bound is not None and bound['group']==bound['session']==process.pid
    save(HERE/'outer-supervisor-binding.json',dict(command=command,process=bound));code=process.wait()
remaining=chat.processes(process.pid)
binding=load(CHAT/'process-binding.json')if(CHAT/'process-binding.json').exists()else None
if binding is not None:remaining+=chat.processes(binding['task']['pid'])
if remaining:
    save(HERE/'remaining-owned-processes.json',remaining)
    raise RuntimeError('No post-census qualification while owned processes remain')
# The real original child and its timeout group have terminated. No process is
# killed or excluded here, and missing child results cannot qualify a timeout.
first=known_root_census();second=known_root_census()
save(HERE/'extra-root-after-first.json',first);save(HERE/'extra-root-after-second.json',second)
fd_after=chat.fds()
assert sha(CHAT/'freeze.json')==CHAT_FREEZE and sha(HERE/'freeze.json')==outer_freeze
assert sha(EMOTE/'global_original_corpus.py')==plan['emoteCensusSha256']
assert sha(EMOTE/'global-original-corpus-baseline.json')==plan['emoteBaselineSha256']
assert sha(Path(plan['gitPath']))==plan['gitSha256']
head_unchanged=subprocess.check_output([plan['gitPath'],'rev-parse','HEAD'],cwd=REPO,text=True).strip()==HEAD
inner=load(CHAT/'report.json')if(CHAT/'report.json').exists()else None
clean=code==0 and inner is not None and inner['qualifiedDiagnostic']
clean=clean and before==first==second==expected and not remaining and fd_before==fd_after and head_unchanged
save(HERE/'report.json',dict(qualifiedDiagnostic=clean,innerExitCode=code,seconds=time.monotonic()-started,
    extraOriginalRoot=str(ROOT),originalFiles=748,entries=len(expected),extraRootUnchanged=before==first==second==expected,
    postProcessCensusesEqual=first==second,ownedProcessesAbsent=not remaining,fdEqual=fd_before==fd_after,
    headUnchanged=head_unchanged,innerQualified=inner is not None and inner['qualifiedDiagnostic'],
    unchangedChatFreeze=CHAT_FREEZE,unchangedTargetBudgetSeconds=300,unchangedKillGraceSeconds=5,
    controllerModified=False,additionalTargets=0,wholeChatQualified=False,nativeQualified=False,deviceQualified=False))
print('CHAT2_OUTER748_TERMINAL',json.dumps(load(HERE/'report.json')),flush=True)
raise SystemExit(0 if clean else code if code else 1)
