"""Connected original admission DAG: actual model originals, no native proof."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import cProfile,time,unittest
from adapters.normal_ui import NativeUIError
from adapters.original_frame_store import OriginalFrameStore
from ios.adapters import audio_passive_capture_source as contract
from ios.adapters.audio_original_validation_graph import original_validation_graph,SemanticFence
from ios.self_tests.test_ios_audio_passive_owner import AudioPassiveOwnerTests


def replacement_command(value):return value

_ORDERED_LITERAL={'first':1,'second':2}
_NESTED_LITERAL={'allowed':True}

class NestedLiteralCodec:
    def read(self):return _NESTED_LITERAL['allowed']


class AudioOriginalValidationGraphTests(unittest.TestCase):
    def fixture(self):
        f=AudioPassiveOwnerTests();f.setUp();self.addCleanup(f.doCleanups);f.begin()
        with f.owner()as owner:owner.capture();owner.retire()
        return f

    def test_actual_complete_admission_shares_local_semantics_but_reads_actual_originals_and_rebuilds_next_round(self):
        f=self.fixture()
        with f.owner()as owner:
            originals={p:(p.stat().st_ino,p.read_bytes())for p in owner.root.iterdir()};commands=deepcopy(f.boundary.commands)
            # Prove actual positive sharing without profiler observer cost.
            owner.admit();first=deepcopy(owner._last_validation_graph_profile)
            self.assertIsNone(first['unsupported'],first)
            self.assertGreater(first['reusedLocalValidations'],0,first)
            self.assertGreater(first['freshFrames'],first['semanticValidations'])
            self.assertIsNone(owner._validation_graph)
            # Independent admission for measured real call counts. Profiling
            # may cross real50ms boundaries and legitimately discard all reuse.
            profile=cProfile.Profile();profile.runcall(owner.admit)
            measured=deepcopy(owner._last_validation_graph_profile)
            self.assertIsNone(measured['unsupported'],measured)
            calls=sum(row.callcount for row in profile.getstats()if row.code is owner.validate_entry.__func__.__code__)
            self.assertEqual(calls,measured['semanticValidations'])
            raw_reads=sum(row.callcount for row in profile.getstats()if row.code is OriginalFrameStore.read.__code__)
            self.assertGreaterEqual(raw_reads,sum(row['revision']for row in owner.state['streams'].values()))
            self.assertGreaterEqual(measured['freshFrames'],measured['semanticValidations'])
            self.assertIsNone(owner._validation_graph);self.assertIsNone(owner._inventory_round)
            owner.admit();second=owner._last_validation_graph_profile
            self.assertGreater(second['semanticValidations'],0);self.assertGreater(second['freshFrames'],0)
            self.assertEqual(commands,f.boundary.commands)
            self.assertEqual(originals,{p:(p.stat().st_ino,p.read_bytes())for p in owner.root.iterdir()})

    def test_same_inode_rewrite_and_new_foreign_namespace_refuse_and_clear_entire_round(self):
        for foreign in (False,True):
            f=self.fixture()
            with self.subTest(foreign=foreign),f.owner()as owner:
                journal=owner.journals['proofs'];actual=journal.files.read;changed=[]
                signed=next(p for p in owner._signatures if '-native-frame-'in p.name);raw=signed.read_bytes();inode=signed.stat().st_ino
                def read(ref):
                    result=actual(ref)
                    if not changed:
                        if foreign:
                            path=owner.root/'foreign-original-duty.json';path.write_text('{}');path.chmod(0o600)
                        else:signed.write_bytes(raw)
                        changed.append(True)
                    return result
                with patch.object(journal.files,'read',read),self.assertRaises(NativeUIError):owner.admit()
                self.assertTrue(changed);self.assertEqual(signed.stat().st_ino,inode)
                self.assertIsNone(owner._validation_graph);self.assertIsNone(owner._inventory_round)

    def test_same_object_parser_code_and_owner_state_mutations_refuse_before_round_can_escape(self):
        for parser in (True,False):
            f=self.fixture()
            with self.subTest(parser=parser),f.owner()as owner:
                journal=owner.journals['native'];actual=journal.files.read;changed=[];original_code=contract.command.__code__
                def read(ref):
                    result=actual(ref)
                    if not changed:
                        if parser:contract.command.__code__=replacement_command.__code__
                        else:owner.state['phase']='captured'
                        changed.append(True)
                    return result
                try:
                    with patch.object(journal.files,'read',read),self.assertRaises(NativeUIError):owner.admit()
                finally:contract.command.__code__=original_code
                self.assertTrue(changed);self.assertIsNone(owner._validation_graph);self.assertIsNone(owner._inventory_round)

    def test_external_owner_authority_callback_and_real_time_boundary_discard_local_status(self):
        f=self.fixture()
        with f.owner()as owner:
            commands=deepcopy(f.boundary.commands)
            with original_validation_graph(owner)as graph:
                for journal in owner.journals.values():journal.restore()
                self.assertTrue(graph.enabled,graph.fence.unsupported)
                first=graph.counts['semanticValidations'];owner.bound()
                self.assertGreater(graph.counts['externalInvalidations'],0);self.assertFalse(graph.tokens)
                owner.proof(owner.state['snapshot']);self.assertGreater(graph.counts['semanticValidations'],first)
                before=graph.counts['timeInvalidations'];time.sleep(.055);graph.guard()
                self.assertGreater(graph.counts['timeInvalidations'],before);self.assertFalse(graph.tokens)
            self.assertIsNone(owner._validation_graph);self.assertEqual(commands,f.boundary.commands)

    def test_reordered_parser_literal_mapping_refuses_even_with_identical_keys_values_and_identity(self):
        f=self.fixture()
        with f.owner()as owner:
            fence=SemanticFence(owner);self.assertTrue(fence.supported,fence.unsupported)
            fence.bind(globals(),'_ORDERED_LITERAL',());fence.guard(owner)
            before=tuple(_ORDERED_LITERAL.items());identity=_ORDERED_LITERAL
            try:
                first=_ORDERED_LITERAL.pop('first');_ORDERED_LITERAL['first']=first
                self.assertIs(identity,_ORDERED_LITERAL);self.assertEqual(dict(before),_ORDERED_LITERAL)
                self.assertNotEqual(before,tuple(_ORDERED_LITERAL.items()))
                with self.assertRaises(NativeUIError):fence.guard(owner)
            finally:_ORDERED_LITERAL.clear();_ORDERED_LITERAL.update(before)

    def test_changed_referenced_nested_reader_class_global_refuses_without_method_or_class_replacement(self):
        f=self.fixture()
        with f.owner()as owner:
            fence=SemanticFence(owner);self.assertTrue(fence.supported,fence.unsupported)
            function=NestedLiteralCodec.read;code=function.__code__
            fence.bind(globals(),'NestedLiteralCodec',());fence.guard(owner)
            old=_NESTED_LITERAL['allowed']
            try:
                _NESTED_LITERAL['allowed']=False
                self.assertIs(function,NestedLiteralCodec.read);self.assertIs(code,function.__code__)
                self.assertFalse(NestedLiteralCodec().read())
                with self.assertRaises(NativeUIError):fence.guard(owner)
            finally:_NESTED_LITERAL['allowed']=old
