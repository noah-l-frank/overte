from pathlib import Path
import hashlib,importlib.util,json,os,stat,sys
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
assert len(sys.argv)==2 and sys.argv[1] in ('before','after');phase=sys.argv[1]
metadata=REPO/'.ios-host-tmp/assets-paired-model-delivery6-active-gates-root-preparation-20261102/run_metadata.py'
spec=importlib.util.spec_from_file_location('root_parallel_review_metadata',metadata);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=m.validate_frozen();sources=m.sources(plan);sources[str(Path(__file__).relative_to(REPO))]=m.pin(Path(__file__))
originals=m.prior_originals(plan)
extra=json.loads((HERE/'extra-corpora.json').read_text());sources[str((HERE/'extra-corpora.json').relative_to(REPO))]=m.pin(HERE/'extra-corpora.json')
for row in extra:
 report=REPO/row['report'];reference=REPO/row['reference'];sources[str(report.relative_to(REPO))]=m.pin(report);sources[str(reference.relative_to(REPO))]=m.pin(reference)
 actual=m.originals(Path(row['root']));expected=json.loads(reference.read_text())
 if row['schema']=='stat-list':
  fields=row['fields'];actual={name:dict(stat=[v[k] for k in fields],**({'sha256':v['sha256']} if 'sha256' in v else {})) for name,v in actual.items()}
 assert actual==expected,row['report'];originals[row['root']]=actual
m.save(HERE/(phase+'-source-pins.json'),sources)
summary={name:dict(entries=len(rows),files=sum('sha256' in row for row in rows.values())) for name,rows in originals.items()}
m.save(HERE/(phase+'-retention.json'),summary)
if phase=='after':
 assert sources==json.loads((HERE/'before-source-pins.json').read_text()),'Source/launcher/report drift during common checks'
 assert summary==json.loads((HERE/'before-retention.json').read_text())
print(json.dumps(dict(phase=phase,sourcePins=len(sources),cohortReferences=len(summary),retainedFileReferences=sum(v['files'] for v in summary.values()),allCurrentOriginalPinsExact=True,historicalBridgeOnlyForRetention=True)),flush=True)
