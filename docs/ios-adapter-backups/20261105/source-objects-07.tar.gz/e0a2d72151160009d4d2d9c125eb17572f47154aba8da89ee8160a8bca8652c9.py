"""Normal action9 retirement over actual QML/File4/Reply3 originals.

These are declared host producer models, not native/device or whole29 results.
Each case owns fresh originals; failed/partial sources are preserved as duties.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.assets_dead_page_retirement import AssetsDeadPageRetirement
from ios.self_tests.assets_dead_page_retirement_fixture import Fixture
from ios.self_tests.assets_picker_fixture import RUN,URL


class AssetsDeadPageRetirementTests(unittest.TestCase):
    def setUp(self):
        self.f=Fixture(self);self.runtime,self.parts=self.f.prepare();self.b=self.f.boundary
    def forbidden(self,*_args,**_kwargs):raise AssertionError('Invalid/historical retirement cannot acquire native sources or write')
    def owner(self):
        self.f.close_context();parts=self.f.retirement();self.parts=parts
        owner=parts['dead_page_retirement'];owner.reserve();return owner
    def headers(self):
        return {name:owner.store.path.read_bytes() if owner.previous is not None else None
            for name,owner in dict(upload=self.parts['upload'],picker=self.parts['picker'],tree=self.parts['tree'],usage=self.parts['usage'],removal=self.parts['model_removal']).items()}
    def releases(self):return [row for row in self.b.requests if row['operation']=='release']
    def test_actual_dead_root_quiet_retires_only_known_old_jobs_and_files_without_relabeling_upload_birth(self):
        owner=self.owner();headers=self.headers();releases=len(self.releases());queries=len(self.b.reads.requests)
        jobs=deepcopy(owner.state['knownJobs']);originals={job['query']['commandId']:job['query'] for job in jobs}
        proof=deepcopy(self.parts['owned_replies'].proof('bundle-final-inventory'));owner.retire()
        self.assertEqual('retired',self.parts['owned_files'].state['phase']);self.assertEqual('uploaded',self.parts['upload'].state['phase'])
        self.assertEqual(format(4,'032x'),self.parts['owned_files'].state['ticket']);self.assertEqual(format(9,'032x'),owner.action.ticket)
        self.assertEqual(headers,self.headers());self.assertEqual(proof,self.parts['owned_replies'].proof('bundle-final-inventory'))
        self.assertEqual(releases+1,len(self.releases()));self.assertEqual(jobs,owner.state['knownJobs'])
        for query in self.b.reads.requests[queries:]:
            self.assertIn(query['operation'],('observe','retire'));start=originals[query['jobId']]
            self.assertEqual({key:start[key] for key in ('ticket','ownerToken','resource','namespace')},
                {key:query[key] for key in ('ticket','ownerToken','resource','namespace')})
        window=owner.state['window'];frames=owner.window(window,complete=True)
        self.assertGreaterEqual(window['hostBrackets'][-1]['before']-window['hostBrackets'][0]['after'],3)
        self.assertTrue(all(frames[-1]['clockBefore'][key]-frames[0]['clockAfter'][key]>=3000 for key in ('epochMs','monotonicMs')))
        link=owner.retired();self.assertFalse(link['wholeEndEligible']);self.f.complete();graph=self.f.archive_graph()
        before=deepcopy(self.f.a.owner.state)
        with patch.object(self.b,'send',side_effect=self.forbidden),patch.object(self.b.reads,'send',side_effect=self.forbidden),patch.object(self.f.a.phase,'status',side_effect=self.forbidden),patch.object(PrivateFeatureState,'write',side_effect=self.forbidden):
            archived=AssetsDeadPageRetirement.from_archive(graph,self.f.a.owner,owner.store)
            self.assertEqual(link['episode'],archived.retired()['episode'])
        self.assertEqual(before,self.f.a.owner.state);self.assertEqual(headers,self.headers())
    def test_actual_unclosed_Create_context_refuses_before_native_query_new_header_or_release(self):
        self.assertIsNone(self.parts['model_removal'].state['contextClosedBy']);releases=len(self.releases())
        with patch.object(self.b,'send',side_effect=self.forbidden),patch.object(self.b.reads,'send',side_effect=self.forbidden),patch.object(PrivateFeatureState,'write',side_effect=self.forbidden):
            with self.assertRaises(NativeUIError):self.f.retirement()
        self.assertEqual(releases,len(self.releases()));self.assertEqual('staged',self.parts['owned_files'].state['phase'])
    def test_real_held_work_blocks_quiet_and_never_releases_files_or_claims_old_client_retirement(self):
        owner=self.owner();headers=self.headers();releases=len(self.releases());self.b.hold_consumer(pending=1)
        with self.assertRaises(NativeUIError):owner.retire()
        self.assertEqual('quiet',owner.state['phase']);self.assertEqual(releases,len(self.releases()))
        self.assertEqual('staged',owner.files.state['phase']);self.assertEqual(headers,self.headers())
        with self.assertRaises(NativeUIError):owner.retired()
    def test_actual_extra_reply_job_after_reservation_remains_unknown_and_is_not_adopted_or_closed(self):
        owner=self.owner();owner.replies.read('outside-retirement-reservation');count=len(self.b.reads.requests);releases=len(self.releases())
        with self.assertRaises(NativeUIError):owner.retire()
        self.assertEqual(count,len(self.b.reads.requests));self.assertEqual(releases,len(self.releases()))
        self.assertEqual('open',owner.replies.state['phase']);self.assertEqual('closing-replies',owner.state['phase'])
    def test_actual_foreign_activation_revokes_normal_retirement_before_native_query_or_sidecar_write(self):
        owner=self.owner();header=owner.store.path.read_bytes();self.f.a.activate(10)
        with patch.object(self.b,'send',side_effect=self.forbidden),patch.object(self.b.reads,'send',side_effect=self.forbidden),patch.object(PrivateFeatureState,'write',side_effect=self.forbidden):
            with self.assertRaises(NativeUIError):owner.retire()
        self.assertEqual(header,owner.store.path.read_bytes());self.assertEqual('staged',owner.files.state['phase'])
    def test_lost_actual_release_return_reassembles_current_factories_and_recovers_without_release_resend(self):
        owner=self.owner();headers=self.headers();releases=len(self.releases());self.b.lost='release'
        with self.assertRaises(NativeUIError):owner.retire()
        self.assertEqual('releasing',owner.state['phase']);self.assertEqual('releasing',owner.files.state['phase'])
        self.assertEqual(releases+1,len(self.releases()));runtime,parts=self.f.removal_parts()
        recovered=runtime._assets_retire_dead_page_clients('primary',RUN,'primary',URL,self.f.lock,self.f.backend.config,parts=parts)
        self.parts=recovered;self.assertEqual('retired',recovered['dead_page_retirement'].state['phase'])
        self.assertEqual('retired',recovered['owned_files'].state['phase']);self.assertEqual(releases+1,len(self.releases()))
        self.assertEqual(headers,self.headers())
    def test_lost_sidecar_parent_CAS_after_actual_files_retirement_recovers_without_second_release(self):
        owner=self.owner();headers=self.headers();save=owner.save;releases=len(self.releases())
        def lost_parent():
            if owner.state['phase']=='retired':raise OSError('Lost sidecar parent CAS after actual Files4 retirement')
            return save()
        owner.save=lost_parent
        with self.assertRaises(OSError):owner.retire()
        self.assertEqual('retired',owner.files.state['phase']);self.assertEqual(releases+1,len(self.releases()))
        runtime,parts=self.f.removal_parts();recovered=runtime._assets_retire_dead_page_clients('primary',RUN,'primary',URL,self.f.lock,self.f.backend.config,parts=parts)
        self.parts=recovered;self.assertEqual('retired',recovered['dead_page_retirement'].state['phase'])
        self.assertEqual(releases+1,len(self.releases()));self.assertEqual(headers,self.headers())
    def test_real_opened_zero_byte_file_original_keeps_partial_duty_and_is_never_adopted_or_retried(self):
        owner=self.owner();source=owner.files.sources;intent=source.store.intent;releases=len(self.releases())
        def stop_opened(kind,value):
            result=intent(kind,value)
            if kind=='original' and value['phase']=='opened':raise OSError('Declared interruption after real O_EXCL/opened WAL before body')
            return result
        source.store.intent=stop_opened
        with self.assertRaises(OSError):owner.retire()
        self.assertIsNotNone(source.pending);reference=source.pending['original'];self.assertEqual('opened',reference['phase'])
        path=source.store.path(reference);self.assertEqual(0,path.stat().st_size);count=len(self.b.requests)
        with self.assertRaises(NativeUIError):owner.retire()
        self.assertTrue(path.exists());self.assertEqual(0,path.stat().st_size);self.assertEqual(count,len(self.b.requests))
        self.assertEqual(releases,len(self.releases()));self.assertEqual('staged',owner.files.state['phase'])
    def test_samebytes_foreign_old_reply_original_inode_refuses_before_native_close_or_file_release(self):
        owner=self.owner();source=owner.replies.sources;reference=source.refs[0]
        path=source.store.path(source.store.expand(reference));raw=path.read_bytes()
        path.rename(path.with_name('retained-before-foreign-old-reply-inode'));path.write_bytes(raw);path.chmod(0o600)
        count=len(self.b.reads.requests);releases=len(self.releases())
        with self.assertRaises(NativeUIError):owner.retire()
        self.assertEqual(count,len(self.b.reads.requests));self.assertEqual(releases,len(self.releases()))
        self.assertEqual('staged',owner.files.state['phase'])
    def test_samebytes_foreign_old_model_original_inode_cannot_inherit_dead_context_or_release_authority(self):
        owner=self.owner();source=owner.removal.sources;reference=source.state['frames'][0]
        path=source.originals.path(source.originals.expand(reference));raw=path.read_bytes()
        path.rename(path.with_name('retained-before-foreign-old-model-inode'));path.write_bytes(raw);path.chmod(0o600)
        count=len(self.b.reads.requests);releases=len(self.releases())
        with self.assertRaises(NativeUIError):owner.retire()
        self.assertEqual(count,len(self.b.reads.requests));self.assertEqual(releases,len(self.releases()))
        self.assertEqual('staged',owner.files.state['phase'])


if __name__=='__main__':unittest.main()
