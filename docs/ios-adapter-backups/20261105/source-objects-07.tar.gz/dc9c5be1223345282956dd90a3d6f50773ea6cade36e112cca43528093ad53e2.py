"""Root-only metadata preparation before publication. Never writes public files."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import os

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(path):
    row=path.lstat()
    return dict(sha256=sha(path),**{key:getattr(row,key) for key in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')})


def required(text):
    tree=ast.parse(text)
    values=[node for node in tree.body if isinstance(node,ast.Assign)
        and any(isinstance(target,ast.Name) and target.id=='REQUIRED' for target in node.targets)]
    assert len(values)==1
    return ast.literal_eval(values[0].value)


def own_patch(raw,values,old,*,registry):
    lines=raw.splitlines(True)
    for key,expected in values.items():
        prefix='    '+json.dumps(key)+': '
        matching=[index for index,line in enumerate(lines) if line.startswith(prefix)]
        value=expected if registry else expected['current']
        replacement=prefix+json.dumps(value)+',\n'
        if key in old:
            assert len(matching)==1,key
            lines[matching[0]]=replacement
        else:
            assert not matching,key
            anchor='    "ios-chat-root-ownership": '
            locations=[index for index,line in enumerate(lines) if line.startswith(anchor)]
            assert len(locations)==1
            lines.insert(locations[0]+1,replacement)
    return ''.join(lines)


plan=json.loads((HERE/'composition/plan.json').read_text())
frozen=json.loads((HERE/'freeze.json').read_text())
for name,expected in frozen['files'].items():assert sha(HERE/name)==expected,name
for row in plan['paths']:
    path=REPO/row['path'];base=row['base']
    if base is None:assert not path.exists() and not path.is_symlink(),row['path']
    else:assert path.resolve(strict=True)==path and sha(path)==base['sha256'],row['path']
    assert sha(HERE/'composition/candidate'/row['path'])==row['candidateSha256']
values=json.loads((HERE/'own-registry-required.json').read_text())
assert len(values)==6
registry=REPO/'tests/device/contract-versions.json';validator=REPO/'tests/device/validate_contract_versions.py'
before_registry=registry.read_text();before_validator=validator.read_text()
contracts=json.loads(before_registry);versions=required(before_validator)
old=json.loads((HERE/'own-registry-before.json').read_text())
assert all(contracts['contracts'].get(key)==old[key]['contract'] and versions.get(key)==old[key]['required'] for key in values)
assert all((key in contracts['contracts'])==old[key]['contractPresent'] and (key in versions)==old[key]['requiredPresent'] for key in values)
after_registry=own_patch(before_registry,values,contracts['contracts'],registry=True)
after_validator=own_patch(before_validator,values,versions,registry=False)
new_contracts=json.loads(after_registry);new_versions=required(after_validator)
assert all(new_contracts['contracts'][key]==row and new_versions[key]==row['current'] for key,row in values.items())
assert {key:value for key,value in contracts['contracts'].items() if key not in values}=={key:value for key,value in new_contracts['contracts'].items() if key not in values}
assert {key:value for key,value in versions.items() if key not in values}=={key:value for key,value in new_versions.items() if key not in values}
assert {key:value for key,value in contracts.items() if key!='contracts'}=={key:value for key,value in new_contracts.items() if key!='contracts'}
out=HERE/'root-prepublication-readback';out.mkdir(mode=0o700)
patch=[]
for path,before,after in ((registry,before_registry,after_registry),(validator,before_validator,after_validator)):
    relative=str(path.relative_to(REPO));patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative,n=0))
    file=out/(path.name+'.candidate');file.write_text(after);file.chmod(0o600)
readback=dict(status='ACTUAL_PREPUBLICATION17_BASES_AND_OWN6_REGISTRY_ONLY',sourceBases=plan['paths'],
    registryBefore={str(path.relative_to(REPO)):pin(path) for path in (registry,validator)},
    ownRequired=values,allForeignContractsAndRequiredPreserved=True,
    registryCandidateSha256=sha(out/(registry.name+'.candidate')),validatorCandidateSha256=sha(out/(validator.name+'.candidate')))
(out/'actual-own-six-key-hunks.patch').write_text(''.join(patch))
(out/'readback.json').write_text(json.dumps(readback,sort_keys=True,indent=2)+'\n')
for path in out.iterdir():path.chmod(0o600)
print('READONLY_BASES17_OWN_REGISTRY6_VERIFIED_FOREIGN_WIP_PRESERVED',flush=True)
