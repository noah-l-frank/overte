"""Canonical physical iOS adapter guarded by actual original installed app bytes."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import stat

from contracts import validate_operation_arguments
from ios.adapters.assets_session_owners import installed_entry as assets_api_entry,ensure_released as ensure_assets_released
from ios.adapters.lifecycle_session_owners import installed_entry as lifecycle_api_entry
from ios.adapters.audio_session_owners import installed_entry as audio_api_entry
from ios.adapters.chat_session_owners import installed_entry as chat_api_entry
from ios.adapters.create_api_clock import installed_entry as create_api_entry
from ios.adapters.avatar_api_entry import installed_entry as avatar_api_entry
from ios.adapters.avatar_session_cleanup import session_entry as avatar_session_entry
from ios.adapters.tablet_web_session_cleanup import session_entry as tablet_web_session_entry
from ios.adapters.emote_api_entry import installed_entry as emote_api_entry
from ios.adapters.navigation_api_entry import installed_entry as navigation_api_entry
from ios.adapters.world_web_api_clock import installed_entry as world_web_api_entry
from ios.adapters.emote_session_cleanup import session_entry as emote_session_entry,ensure_finalized as finalize_emotes
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.adapter import IOSNativeMixin
from ios.adapters.feature_observation import FeatureObservation
from ios.adapters.installed_code import InstalledCodeBinding, cleanup_record, need, source


class ArtifactLease:
    """Bounded original kernel metadata around full candidate preflight.

    No digest is derived from metadata. The original verifier hashes the files;
    unchanged original kernel records allow cheap guards during native input.
    Complete provenance/inputs are revalidated before returning each operation.
    """
    def __init__(self, root):
        self.root = Path(root)
        need(self.root.is_absolute() and self.root.resolve(strict=True) == self.root)
        self.rows = self.snapshot()

    def snapshot(self):
        rows = {}
        def visit(path, depth):
            need(depth <= 64 and len(rows) < 50000)
            before = path.lstat()
            need(stat.S_ISDIR(before.st_mode) or stat.S_ISREG(before.st_mode) and before.st_nlink == 1)
            key = str(path.relative_to(self.root))
            record = lambda s:(s.st_dev,s.st_ino,s.st_mode,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
            rows[key] = record(before)
            if stat.S_ISDIR(before.st_mode):
                with os.scandir(path) as children:
                    names = sorted(item.name for item in children)
                for name in names:visit(path / name, depth + 1)
            need(record(path.lstat()) == rows[key])
        visit(self.root, 0)
        return rows

    def guard(self):
        need(self.snapshot() == self.rows)


def create_physical_adapter(args, base_class, preflight, *, cleanup_only=False):
    lease = candidate = None
    if not cleanup_only:
        lease = ArtifactLease(args.artifact_root)
        candidate = preflight(args)
        lease.guard()
        need(candidate.get('physicalHandoffVersion') == 1)

    if cleanup_only and getattr(args,'physical_candidate_metadata',None) and getattr(args,'artifact_root',None):
        try:
            lease=ArtifactLease(args.artifact_root);candidate=preflight(args);lease.guard()
            need(candidate.get('physicalHandoffVersion')==1)
        except (OSError,RuntimeError,ValueError,TypeError,KeyError):
            lease=candidate=None

    class IOSInstalledAdapter(IOSNativeMixin, base_class):
        def __init__(self):
            self._operation = None
            self._session_recreation_forbidden = False
            self._preparing = self._retiring = self._recovering = None
            super().__init__()

        @classmethod
        def advertised_capabilities(cls, target):
            # One selected candidate cannot authorize a signed upgrade pair.
            from ios.adapters.feature_configuration import capabilities
            features=capabilities(target) if candidate is not None else []
            return sorted((set(super().advertised_capabilities(target)) | set(features)) - {'app.install','app.upgrade'})

        def _candidate_guard(self, *, complete=False):
            if candidate is None or lease is None:
                raise ValueError('OVT_IOS_INSTALLED_CODE_BINDING_UNAVAILABLE')
            lease.guard()
            if complete:
                need(preflight(args) == candidate)
                lease.guard()

        def _chat_qml_cache_source(self,selector,run):
            # Diagnostic source acquisition only. No normal Chat input,
            # SDK/session creation, source-graph approval or complete receipt.
            from ios.adapters.script_runtime import IOSScriptRuntime
            from ios.adapters.feature_observation import FeatureObservation
            self._candidate_guard()
            client,session,state,target,scope=IOSScriptRuntime(self)._existing(selector)
            gate=self._binding(selector,client,session,state,target)
            record=gate.record();need(record is not None and record['phase']=='bound')
            process=gate.continuity()
            def check():
                self._candidate_guard()
                need(self._scope(selector,session,state,target)==scope
                    and gate.continuity()==process and gate.record()==record)
            def current_process():
                check();return dict(process)
            observer=FeatureObservation(client,session,target,current_process)
            clock=observer.native_observer()
            reader=observer.chat_qml_sources(clock_source=clock)
            original=reader.read(run)
            # A lost read is not replayed. A later binding failure raises and
            # cannot return the previous query's successful root or receipt.
            bound=self._chat_qt_entry_image_bytes(selector,original)
            check()
            need(bound['imageBytesBound'] is True and bound['qtSdkSourceAvailable'] is False
                and bound['importGraphAvailable'] is False and bound['aotGraphAvailable'] is False)
            return original,bound

        def _chat_qt_entry_image_bytes(self,selector,value):
            # The already admitted candidate supplies the selector; a requested
            # Qt/version/hash cannot choose another IPA or native code address.
            from ios.adapters.script_runtime import IOSScriptRuntime
            from ios.adapters.chat_qml_sources import original
            original(value);need(value['iosChatQmlSourcesVersion']==2)
            self._candidate_guard()
            client,session,state,target,scope=IOSScriptRuntime(self)._existing(selector)
            gate=self._binding(selector,client,session,state,target)
            need(type(candidate.get('runtime')) is dict and type(candidate.get('artifactIdentity')) is dict)
            relative=candidate['runtime'].get('artifact');need(type(relative) is str)
            path=Path(args.artifact_root)/relative
            need(path.is_absolute() and path.resolve(strict=True).is_relative_to(Path(args.artifact_root).resolve(strict=True)))
            result=gate.qt_entry_image_bytes(value['qtEntryImage'],path,candidate['artifactIdentity']['artifactSha256'])
            self._candidate_guard();need(self._scope(selector,session,state,target)==scope)
            return result

        def _chat_qml_dependency_source(self,selector,run):
            # Diagnostic source acquisition only. No normal Chat input,
            # SDK/session creation, source-graph approval or complete receipt.
            from ios.adapters.script_runtime import IOSScriptRuntime
            from ios.adapters.feature_observation import FeatureObservation
            self._candidate_guard()
            client,session,state,target,scope=IOSScriptRuntime(self)._existing(selector)
            gate=self._binding(selector,client,session,state,target)
            record=gate.record();need(record is not None and record['phase']=='bound')
            process=gate.continuity()
            def check():
                self._candidate_guard()
                need(self._scope(selector,session,state,target)==scope
                    and gate.continuity()==process and gate.record()==record)
            def current_process():
                check();return dict(process)
            observer=FeatureObservation(client,session,target,current_process)
            clock=observer.native_observer()
            reader=observer.chat_qml_sources(clock_source=clock)
            original=reader.read(run)
            # A lost read is not replayed. A later binding failure raises and
            # cannot return the previous query's successful root or receipt.
            bound=self._chat_qt_dependency_images_bytes(selector,original)
            check()
            need(type(bound) is list and len(bound)==2 and all(value['imageBytesBound'] is True
                and value['qtSdkSourceAvailable'] is False and value['importGraphAvailable'] is False
                and value['aotGraphAvailable'] is False for value in bound))
            return original,bound


        def _chat_qt_dependency_images_bytes(self,selector,value):
            # The already admitted candidate supplies the selector; a requested
            # Qt/version/hash cannot choose another IPA or native code address.
            from ios.adapters.script_runtime import IOSScriptRuntime
            from ios.adapters.chat_qml_sources import original
            original(value);need(value['iosChatQmlSourcesVersion']==3)
            self._candidate_guard()
            client,session,state,target,scope=IOSScriptRuntime(self)._existing(selector)
            gate=self._binding(selector,client,session,state,target)
            need(type(candidate.get('runtime')) is dict and type(candidate.get('artifactIdentity')) is dict)
            relative=candidate['runtime'].get('artifact');need(type(relative) is str)
            path=Path(args.artifact_root)/relative
            need(path.is_absolute() and path.resolve(strict=True).is_relative_to(Path(args.artifact_root).resolve(strict=True)))
            result=gate.qt_entry_images_bytes([value['qtEntryImage'],value['qtDependencyEntryImage']],path,candidate['artifactIdentity']['artifactSha256'])
            self._candidate_guard();need(self._scope(selector,session,state,target)==scope)
            return result


        def _chat_qml_owner_artifact(self,selector):
            # An independently selected candidate path, never a path from a
            # native observation, WAL or desired source hash.
            from ios.adapters.script_runtime import IOSScriptRuntime
            self._candidate_guard()
            _client,session,state,target,scope=IOSScriptRuntime(self)._existing(selector)
            need(type(candidate.get('runtime')) is dict and type(candidate.get('artifactIdentity')) is dict)
            relative=candidate['runtime'].get('artifact');need(type(relative) is str)
            path=Path(args.artifact_root)/relative
            need(path.is_absolute() and path.resolve(strict=True)==path
                and path.is_relative_to(Path(args.artifact_root).resolve(strict=True)))
            self._candidate_guard();need(self._scope(selector,session,state,target)==scope)
            return path,candidate['artifactIdentity']['artifactSha256']

        def _chat_qml_owner_image_originals(self,selector,value):
            from ios.adapters.script_runtime import IOSScriptRuntime
            from ios.adapters.chat_qml_sources import original
            original(value);need(value['iosChatQmlSourcesVersion']==3)
            self._candidate_guard()
            client,session,state,target,scope=IOSScriptRuntime(self)._existing(selector)
            gate=self._binding(selector,client,session,state,target)
            record=deepcopy(gate.record());need(record is not None and record['phase']=='bound')
            path,digest=self._chat_qml_owner_artifact(selector)
            bound=gate.qt_entry_images_bytes([value['qtEntryImage'],value['qtDependencyEntryImage']],path,digest)
            self._candidate_guard();need(self._scope(selector,session,state,target)==scope and gate.record()==record)
            return dict(bindingOriginal=record,entryBindings=bound)

        def _native_source_scope(self,*args,**kwargs):
            self._candidate_guard()
            return super()._native_source_scope(*args,**kwargs)

        def _scripts(self, selector):
            self._candidate_guard()
            return super()._scripts(selector)

        def _script_runtime(self, selector):
            self._candidate_guard()
            return super()._script_runtime(selector)

        def _script_missing_manager(self, selector):
            self._candidate_guard()
            return super()._script_missing_manager(selector)

        def _script_manager_status(self, selector):
            self._candidate_guard()
            return super()._script_manager_status(selector)

        def _bound_script_files(self, *args, **kwargs):
            self._candidate_guard()
            return super()._bound_script_files(*args, **kwargs)

        def _script_restart_handoff(self, *args, **kwargs):
            self._candidate_guard()
            return super()._script_restart_handoff(*args, **kwargs)

        def _script_restart_prepare(self, *args, **kwargs):
            self._candidate_guard()
            return super()._script_restart_prepare(*args, **kwargs)

        def _script_restart_adopt(self, *args, **kwargs):
            self._candidate_guard()
            return super()._script_restart_adopt(*args, **kwargs)

        def _script_restart_inputs(self, *args, **kwargs):
            self._candidate_guard()
            return super()._script_restart_inputs(*args, **kwargs)

        def _script_restart_source(self, selector):
            self._candidate_guard()
            owned = self._binding_store(selector).read()
            if owned is not None and owned.get('phase') == 'preparing':
                self._recover_script_restart_launch(selector)
            return super()._script_restart_source(selector)

        def _recover_script_restart_launch(self, selector, *, inputs=None):
            # Only the explicit restart coordinator may enter this read-only
            # recovery path. Ordinary ensure_session/describe/launch still fail
            # on abandoned launch intent, without delivering another SDK input.
            self._candidate_guard(complete=True)
            need(self._recovering is None)
            inputs = self._script_restart_inputs(selector) if inputs is None else inputs
            from adapters.restart_inputs import RestartInputs
            need(isinstance(inputs, RestartInputs))
            client, state, target = self._script_restart_session(selector, inputs=inputs)
            session = state['sessionId']
            gate = self._binding(selector, client, session, state, target)
            actual = gate.original_process()
            need(actual is not None)
            pid = actual['pid']
            def process():
                return gate.preparing_continuity(pid)
            observer = FeatureObservation(client, session, target, process)
            def ready(measured, native_after):
                need(measured == actual and state.get('processIdentity') in
                     (None, str(inputs.read()['oldNative']['pid']), str(pid)))
                state['processIdentity'] = str(pid)
                # Compare original device probe time to an original native
                # fence; neither AFC metadata nor host UTC supplies freshness.
                self.wait_first_ios_probe(selector, client, session, state, target, str(pid), native_after)
                state.update(iosE2ELaunchCompleted=True,
                    iosE2ESceneUrl=target['testBuild']['fixtureOrigin'] + target['testBuild']['scenePath'])
                self.save_session(selector, state)
            self._recovering = (selector, session, pid)
            try:
                gate.recover_prepared(inputs, observer.native_observer(),
                    observer.process_presence(), ready)
                self._candidate_guard(complete=True)
            finally:
                self._recovering = None

        def _script_restart(self, *args, **kwargs):
            self._candidate_guard()
            return super()._script_restart(*args, **kwargs)

        def _script_restart_stopped(self, selector):
            self._candidate_guard()
            client, state, target = self._script_restart_session(selector)
            gate = self._binding(selector, client, state['sessionId'], state, target)
            record = gate.record()
            if record is not None and record['phase'] == 'retiring':
                # Recover host retirement after a lost terminateApp receipt;
                # never deliver terminateApp again or bypass original source.
                gate.finish_retirement()
            gate.retired_absence()
            self.reset_launch_state(selector, state)
            return {'running': False, 'identity': None}

        def _private_login_input(self, *args, **kwargs):
            self._candidate_guard()
            return super()._private_login_input(*args, **kwargs)

        def _login_controls(self, *args, **kwargs):
            self._candidate_guard()
            return super()._login_controls(*args, **kwargs)

        def _target(self, selector):
            self._candidate_guard()
            target = self.target(selector)
            need(target.get('platform') == 'ios' and target.get('physical') is True
                 and target.get('artifactMode') == 'personal-team-preinstalled'
                 and target.get('_artifactMode') == 'personal-team-preinstalled'
                 and target.get('appId') == candidate['bundleIdentity']['bundleId']
                 and target.get('testBuild') and target.get('probe') == {'kind':'ios-documents'})
            return target

        def _scope(self, selector, session, state, target):
            self._candidate_guard()
            actual = self.read_session(selector)
            fingerprint = hashlib.sha256(json.dumps(target,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            need(actual is not None and state.get('sessionId') == session == actual.get('sessionId')
                 and state.get('generation') == actual.get('generation')
                 and state.get('targetFingerprint') == fingerprint == actual.get('targetFingerprint')
                 and hashlib.sha256(json.dumps(self.target(selector),sort_keys=True,separators=(',',':')).encode()).hexdigest() == fingerprint)
            return dict(sourceRevision=candidate['artifactIdentity']['sourceRevision'],
                        artifactSha256=candidate['artifactIdentity']['artifactSha256'],sessionId=session,
                        generation=state['generation'],targetFingerprint=fingerprint)

        def _binding_store(self, selector):
            return PrivateFeatureState(self.state_path(selector).with_name('installed-code-binding.json'))

        def _retired_candidate_scope(self,selector,scope):
            # Historical SDK teardown still belongs to this exact candidate
            # and target, even when no live SDK state remains for _scope().
            self._candidate_guard(complete=True);target=self._target(selector)
            fingerprint=hashlib.sha256(json.dumps(target,sort_keys=True,separators=(',',':')).encode()).hexdigest()
            need(scope['sourceRevision']==candidate['artifactIdentity']['sourceRevision']
                 and scope['artifactSha256']==candidate['artifactIdentity']['artifactSha256']
                 and scope['targetFingerprint']==fingerprint)
            return target

        def _avatar_retired_binding_record(self,selector,scope,value):
            # Decode historical Installed bytes against this actual selected
            # candidate bundle, without acquiring any live SDK/native source.
            self._retired_candidate_scope(selector,scope)
            class Frozen:
                def read(_self):return value
            def forbidden():need(False)
            return InstalledCodeBinding(Frozen(),scope,candidate['bundleIdentity'],forbidden,forbidden,forbidden).record()

        def _binding(self, selector, client, session, state, target):
            scope = self._scope(selector, session, state, target)
            def process():
                need(self._scope(selector, session, state, target) == scope)
                return IOSNativeMixin.native_process(client, session, target)
            def source():
                need(self._scope(selector, session, state, target) == scope)
                return client.execute(session,'mobile: overteProcessSourceInfo',{'bundleId':target['appId']})
            observer = FeatureObservation(client,session,target,process)
            return InstalledCodeBinding(self._binding_store(selector),scope,candidate['bundleIdentity'],
                                        process,source,lambda:observer.installed_bundle().read())

        def ensure_session(self, selector):
            target = self._target(selector)
            owned = self._binding_store(selector).read()
            if owned is not None:
                persisted = self.read_session(selector)
                need(persisted is not None)
                need(owned.get('scope') == self._scope(selector,persisted['sessionId'],persisted,target))
                if owned.get('phase') in ('preparing','retiring'):
                    need(self._retiring == (selector,persisted['sessionId']))
            existing_only = self._session_recreation_forbidden
            self._session_recreation_forbidden = existing_only or owned is not None
            try:
                client, session, state = super().ensure_session(selector)
            finally:
                self._session_recreation_forbidden = existing_only
            gate = self._binding(selector,client,session,state,target)
            record = gate.record()
            if self._retiring == (selector,session):
                need(record is not None and record['phase'] == 'retiring')
                gate.retirement_continuity()
            elif record is None or record['phase'] == 'retired':
                if record is not None and self._operation == 'app.process':
                    gate.retired_absence()
                    return client,session,state
                need(self._operation in ('describe','app.launch'))
                provenance = source(gate.process_source())
                gate.begin()
                self._preparing = (selector,session)
                try:
                    self.launch_ios_test_build(selector,client,session,state,target)
                    need(source(gate.process_source()) == provenance)
                    gate.bind()
                finally:self._preparing = None
            elif record['phase'] == 'bound':
                if self._operation in ('app.foreground','app.launch'):gate.continuity(allow_background=True)
                else:gate.verify()
            else:
                raise ValueError('OVT_IOS_INSTALLED_CODE_BINDING_REJECTED')
            return client,session,state

        def assert_ios_process_identity(self, selector, client, session, state, target):
            gate = self._binding(selector,client,session,state,target)
            if self._recovering is not None and self._recovering[:2] == (selector, session):
                actual = gate.preparing_continuity(self._recovering[2])
                need(state.get('processIdentity') in (None, str(actual['pid'])))
                return str(actual['pid'])
            if self._preparing == (selector,session):
                need(gate.record()['phase'] == 'preparing')
                return super().assert_ios_process_identity(selector,client,session,state,target)
            actual = gate.retirement_continuity() if self._retiring == (selector,session) else gate.continuity()
            need(actual['foreground'] is True)
            need(state.get('processIdentity') == str(actual['pid']))
            return str(actual['pid'])

        @chat_api_entry
        @audio_api_entry
        @lifecycle_api_entry
        def describe(self, selector):
            ensure_assets_released(self,selector)
            self._candidate_guard(complete=True)
            self._operation = 'describe'
            try:
                client,session,state = self.ensure_session(selector)
                result = super().describe(selector)
                result['executionIdentity'] = self._binding(selector,client,session,state,self._target(selector)).verify()
                self._candidate_guard(complete=True)
                return result
            finally:self._operation = None

        @chat_api_entry
        @audio_api_entry
        @assets_api_entry
        @create_api_entry
        @avatar_api_entry
        @emote_api_entry
        @navigation_api_entry
        @world_web_api_entry
        @lifecycle_api_entry
        def invoke(self, selector, operation, values):
            validate_operation_arguments(operation,values)
            need(operation not in ('app.install','app.upgrade'))
            if operation.startswith('feature.'):
                from ios.adapters.feature_configuration import OPERATIONS,configuration,capabilities,reader
                from ios.adapters.script_runtime import IOSScriptRuntime
                need(operation in OPERATIONS and configuration() is not None and self._operation is None)
                self._candidate_guard(complete=True)
                need(operation in capabilities(self._target(selector)))
                self._operation=operation
                try:
                    if operation.split('.')[1]=='graphics':
                        from ios.adapters.graphics_runtime import IOSGraphicsRuntime
                        config=configuration();runtime=IOSGraphicsRuntime(self)
                        flow=runtime._graphics_feature(selector,values['runId'],role='primary',client=reader(config),settings=config['graphics'])
                    elif operation.split('.')[1]=='create':
                        from ios.adapters.create_runtime import IOSCreateRuntime
                        config=configuration();runtime=IOSCreateRuntime(self)
                        flow=runtime._create_feature(selector,values['runId'],role='primary',client=reader(config),settings=config['create'])
                    elif operation.split('.')[1]=='emotes':
                        from ios.adapters.emote_runtime import IOSEmoteRuntime
                        config=configuration();runtime=IOSEmoteRuntime(self)
                        factory=(runtime._emote_rooted_feature if config.get('iosFeatureAdapterVersion',0)>=6
                            and config.get('emoteCoordinatorVersion')==2 else runtime._emote_feature)
                        flow=factory(selector,values['runId'],role='primary',client=reader(config),settings=config['emotes'])
                    elif operation.split('.')[1]=='avatar-people':
                        from ios.adapters.avatar_runtime import IOSAvatarRuntime
                        config=configuration();runtime=IOSAvatarRuntime(self)
                        flow=runtime._avatar_feature(selector,values['runId'],role='primary',client=reader(config),settings=config['avatarPeople'])
                    elif operation.split('.')[1]=='world-navigation':
                        from ios.adapters.navigation_runtime import IOSNavigationRuntime
                        config=configuration();runtime=IOSNavigationRuntime(self)
                        flow=runtime._navigation_feature(selector,values['runId'],role='primary',client=reader(config),settings=config['worldNavigation'])
                    elif operation.split('.')[1]=='world-web':
                        from ios.adapters.world_web_runtime import IOSWorldWebRuntime
                        config=configuration();runtime=IOSWorldWebRuntime(self)
                        flow=runtime._world_web_feature(selector,values['runId'],role='primary',client=reader(config),settings=config['worldWeb'])
                    elif operation.split('.')[1]=='tablet-web':
                        from ios.adapters.tablet_web_runtime import IOSTabletWebRuntime
                        config=configuration();runtime=IOSTabletWebRuntime(self)
                        flow=runtime._tablet_web_feature(selector,values['runId'],role='primary',client=reader(config),settings=config['tabletWeb'])
                    elif operation.split('.')[1]=='authentication':
                        from ios.adapters.authentication_runtime import IOSAuthenticationRuntime
                        runtime=IOSAuthenticationRuntime(self,reader(configuration()),values['runId'])
                        flow=runtime._authentication_feature(selector,values['runId'])
                    else:
                        runtime=IOSScriptRuntime(self)
                        flow=runtime._script_feature(selector,values['runId'])
                    result=getattr(flow,operation.rsplit('.',1)[1])(values)
                    if operation=='feature.world-navigation.terminal' and values['stage']=='finish':
                        from ios.adapters.navigation_canonical_end import verify
                        verify(flow,values,result)
                    elif operation=='feature.world-web.terminal' and values['stage']=='finish':
                        from ios.adapters.world_web_canonical_end import verify
                        verify(flow,values,result)
                    elif operation=='feature.tablet-web.terminal' and values['stage']=='finish':
                        from ios.adapters.tablet_web_canonical_end import verify
                        verify(flow,values,result)
                    elif operation=='feature.emotes.terminal' and values['stage']=='finish':
                        from ios.adapters.emote_canonical_end import verify
                        verify(flow,values,result)
                    elif operation=='feature.avatar-people.terminal' and values['stage']=='finish':
                        from ios.adapters.avatar_canonical_end import verify
                        verify(flow,values,result)
                    elif operation=='feature.avatar-people.cleanup':
                        from ios.adapters.avatar_canonical_end import verify_failed_cleanup
                        if not verify_failed_cleanup(flow,values,result):
                            client,session,state,target,_scope=runtime._existing(selector)
                            self._binding(selector,client,session,state,target).verify()
                    elif operation=='feature.world-navigation.cleanup':
                        from ios.adapters.navigation_failed_preparation_cleanup import verify
                        if not verify(flow,values,result):
                            client,session,state,target,_scope=runtime._existing(selector)
                            self._binding(selector,client,session,state,target).verify()
                    else:
                        client,session,state,target,_scope=runtime._existing(selector)
                        self._binding(selector,client,session,state,target).verify()
                    self._candidate_guard(complete=True)
                    return result
                finally:self._operation=None
            if self._operation is not None:
                need(self._operation in ('permission.snapshot','permission.set') and operation == 'voice.exchange')
                return super().invoke(selector,operation,values)
            self._candidate_guard(complete=True)
            self._operation = operation
            try:
                client,session,state = self.ensure_session(selector)
                target = self._target(selector)
                gate = self._binding(selector,client,session,state,target)
                if operation in ('app.stop','app.crash'):
                    gate.begin_retirement();self._retiring = (selector,session)
                result = super().invoke(selector,operation,values)
                if self._retiring:
                    gate.finish_retirement()
                elif operation == 'lifecycle.background':
                    need(gate.continuity(allow_background=True)['foreground'] is False)
                elif operation == 'app.process' and gate.record()['phase'] == 'retired':
                    gate.retired_absence()
                elif operation == 'app.foreground':gate.continuity(allow_background=True)
                else:gate.verify()
                self._candidate_guard(complete=True)
                return result
            finally:
                self._operation = self._retiring = None

        @chat_api_entry
        @audio_api_entry
        @lifecycle_api_entry
        @tablet_web_session_entry
        @avatar_session_entry
        def cleanup(self, selector):
            # Inspect the Assets successor before any feature finalization or
            # ordinary SDK teardown. Local client retirement cannot discharge
            # remaining server/oven/blob responsibility.
            ensure_assets_released(self,selector)
            from ios.adapters.feature_configuration import configuration
            # Retained Tablet responsibility must be decoded before another
            # feature finalizer or ordinary SDK fallback can perform teardown.
            from ios.adapters.tablet_web_runtime import IOSTabletWebRuntime
            from ios.adapters.tablet_web_session_cleanup import retire_existing as retire_tablet_web
            tablet_web=retire_tablet_web(IOSTabletWebRuntime(self),selector,configuration())
            if tablet_web is not None:return tablet_web
            from ios.adapters.avatar_runtime import IOSAvatarRuntime
            from ios.adapters.avatar_metadata_retirement import retire_existing as retire_avatar
            avatar=retire_avatar(IOSAvatarRuntime(self),selector,configuration())
            if avatar is not None:return avatar
            from ios.adapters.emote_runtime import IOSEmoteRuntime
            from ios.adapters.emote_rooted_session_cleanup import retire_existing as retire_rooted_emotes
            emotes=retire_rooted_emotes(IOSEmoteRuntime(self),selector,configuration())
            if emotes is not None:return emotes
            # A typed Worlds end must precede any unrelated GPU-name scan or
            # fallback lifecycle input, including when its SDK is already gone.
            from ios.adapters.feature_configuration import configuration
            from ios.adapters.navigation_runtime import IOSNavigationRuntime
            from ios.adapters.navigation_session_cleanup import retire_existing
            navigation=retire_existing(IOSNavigationRuntime(self),selector,configuration())
            if navigation is not None:return navigation
            from ios.adapters.world_web_runtime import IOSWorldWebRuntime
            from ios.adapters.world_web_finalization import retire_existing as retire_world_web
            world_web=retire_world_web(IOSWorldWebRuntime(self),selector,configuration(),None)
            if world_web is not None:return world_web
            return self._cleanup_other_features(selector)

        @emote_session_entry
        def _cleanup_other_features(self, selector):
            need(finalize_emotes(self,selector))
            # Graphics has its own paired original-world/final-Stop protocol.
            # Its durable handoff survives metadata retirement and a lost SDK
            # DELETE return. Never fall through to another terminate on error.
            from ios.adapters.feature_configuration import configuration,reader
            def state(name):return PrivateFeatureState(self.state_path(selector).with_name(name)).read()
            from ios.adapters.create_runtime import IOSCreateRuntime
            from ios.adapters.create_finalization import finalize_existing
            config=configuration()
            finalize_existing(IOSCreateRuntime(self),selector,config,None if config is None else reader(config))
            graphics=state('ios-graphics-feature.json')
            graphics_retirement=state('ios-graphics-retirement.json')
            graphics_session=state('ios-feature-session-retirement.json')
            graphics_receipt=state('ios-feature-session-retired.json')
            original=next((value for value in (graphics_session,graphics_retirement,graphics) if value is not None),None)
            historical=(original is None and graphics_receipt is not None and self.read_session(selector) is None
                        and self._binding_store(selector).read() is None)
            if original is not None or historical:
                from ios.adapters.graphics_runtime import IOSGraphicsRuntime
                from ios.adapters.graphics_session_retirement import IOSGraphicsSessionRetirement
                need(state('ios-authentication-feature.json') is None and state('ios-authentication-retirement.json') is None
                     and state('script-feature-owner.json') is None and state('script-feature-retirement.json') is None)
                if historical:
                    need(self.component_owners_absent(selector))
                    transaction=IOSGraphicsSessionRetirement.from_receipt(IOSGraphicsRuntime(self),selector,graphics_receipt)
                    return transaction.historical(graphics_receipt)
                config=configuration();need(config is not None and config['iosFeatureAdapterVersion'] in (2,3,4,5,6,7) and 'graphics' in config['areas'])
                transaction=IOSGraphicsSessionRetirement(IOSGraphicsRuntime(self),selector,reader(config),config['graphics'],original)
                need(self.cleanup_components(selector) and self.component_owners_absent(selector))
                return transaction.finalize()
            # Preserve the original component cleanup and independent native
            # process/session teardown even if all candidate inputs are lost.
            store = self._binding_store(selector)
            previous = store.read()
            feature_error=False
            from ios.adapters.authentication_runtime import IOSAuthenticationRuntime
            from ios.adapters.feature_configuration import configuration,reader
            authentication=PrivateFeatureState(self.state_path(selector).with_name('ios-authentication-feature.json')).read()
            authentication_retirement=PrivateFeatureState(self.state_path(selector).with_name('ios-authentication-retirement.json')).read()
            if authentication is not None or authentication_retirement is not None:
                try:
                    original=authentication if authentication is not None else authentication_retirement
                    runtime=IOSAuthenticationRuntime(self,reader(configuration()),original['runId'])
                    runtime._authentication_feature(selector,original['runId']).finalize()
                except Exception:feature_error=True
            from ios.adapters.script_runtime import IOSScriptRuntime
            runtime=IOSScriptRuntime(self)
            owner=runtime.script_feature_store(selector).read()
            retirement=runtime.script_retirement_store(selector).read()
            if owner is not None or retirement is not None:
                try:
                    original=owner if owner is not None else retirement
                    runtime._script_feature(selector,original['runId']).finalize()
                except Exception:feature_error=True
            result = super().cleanup(selector)
            need(not feature_error)
            need(type(result) is dict and result == {'cleaned':True} and self.read_session(selector) is None)
            current=cleanup_record(previous,store.read())
            if current is not None:store.discard(current)
            return result

    return IOSInstalledAdapter()
