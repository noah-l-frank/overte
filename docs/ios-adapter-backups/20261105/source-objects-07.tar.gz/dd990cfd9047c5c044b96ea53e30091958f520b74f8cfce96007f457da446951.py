from pathlib import Path
import ast,hashlib,json,shutil,stat,difflib
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-native-motion-rpc-window-number-root-preparation-20261028/41-native-motion-rpc6';PACK=T/'lifecycle-original-owner-passive-after-own-up-proposal-20261028';P=T/'lifecycle-original-owner-passive9-root-preparation-20261028';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert H(PACK/'freeze.json')=='42d0278d2c31b2f43d546833e3e31789a1aa302797716b28859aa25602b3dfbe'
for rel,d in json.loads((PACK/'freeze.json').read_text())['files'].items():assert H(PACK/rel)==d
report=json.loads((B/'root-run-first/report.json').read_text());assert report['exitCode']==0 and report['retainedFiles']==87 and report['allPinsEqual'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses'];P.mkdir(mode=0o700);S=P/'42-native-passive9';S.mkdir(mode=0o700)
for rel,d in json.loads((B/'freeze.json').read_text())['files'].items():
 assert H(B/rel)==d;out=S/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/rel,out)
names=['test_native_passive_scope_models.py','test_native_motion_existing_rpc_models.py','test_native_motion_worker_scope_models.py','test_motion_selected_join_models.py','motion_reference_fixture.py','native_acquisition_fixture.py','native_file_fixture.py']
for name in names:shutil.copyfile(PACK/name,S/name)
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode);v=dict(stat=[getattr(a,k) for k in fields]);v.update(dict(sha256=H(p)) if p.is_file() else {});assert v['stat']==[getattr(p.lstat(),k) for k in fields];return v
prior=json.loads((B/'prior-retained-original-pins.json').read_text());root=B/'retained-first';assert sum(p.is_file() for p in root.rglob('*'))==87
for path in [root,*sorted(root.rglob('*'))]:prior[str(path)]=pin(path)
assert sum('sha256' in v for v in prior.values())==2487;(S/'prior-retained-original-pins.json').write_text(json.dumps(prior,indent=2)+'\n')
manifest=json.loads((PACK/'manifest.json').read_text());own={row['path']:row for row in manifest['files']};stage=json.loads((S/'source-manifest.json').read_text());changes=[]
for row in stage['sourcePaths']:
 rel=row['path'];actual=H(R/rel)
 if rel in own and rel not in ('tests/device/contract-versions.json','tests/device/validate_contract_versions.py'):
  row.update(candidate=own[rel]['candidate'],candidateSHA256=own[rel]['candidateSHA256'],observedPublicSHA256=actual,changesCurrentPublic=actual!=own[rel]['candidateSHA256']);continue
 if rel in ('tests/device/contract-versions.json','tests/device/validate_contract_versions.py'):
  raw=(R/rel).read_text();value=raw
  for family in ['original-keeper-native-query','original-keeper-native-file']:
   before='"'+family+'": {"current": 3, "reads": [1, 2, 3]}' if rel.endswith('.json') else '"'+family+'": 3,'
   after='"'+family+'": {"current": 4, "reads": [1, 2, 3, 4]}' if rel.endswith('.json') else '"'+family+'": 4,'
   assert value.count(before)==1 or value.count(after)==1;value=value.replace(before,after)
  out=S/'actual-current-own-registry/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(value);row.update(candidate=str(out),candidateSHA256=H(out),observedPublicSHA256=actual,changesCurrentPublic=actual!=H(out));continue
 if actual!=row['candidateSHA256']:
  out=S/'actual-current-dependency/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,out);changes.append(dict(path=rel,old=row['candidateSHA256'],current=actual));row.update(candidate=str(out),candidateSHA256=actual)
 row.update(observedPublicSHA256=actual,changesCurrentPublic=False)
stage.update(stage=42,name='42-native-passive9',status='PRIVATE_UNRUN_PASSIVE_SOURCE2_OWN2',caseCount=9,pythonCaseCount=9,initialTimeoutSeconds=90,sourceDeltaPaths=list(own),exactPublicMutationPlan='Root ONLY passive2 keeper94fc/Resource5b96 +native-query/native-file3->4 own two registry/validator hunks. Touch2/default1/foreign allpreserved.')
stage['orderedParentFreezes'][PACK.name]=H(PACK/'freeze.json');(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
plan=json.loads((S/'run-plan.json').read_text());plan.update(status='PRIVATE_UNRUN_PASSIVE9',cases=json.loads((PACK/'test-plan.json').read_text())['cases'],caseCount=9,totalCaseCount=9,initialOuterSeconds=90,killAfterSeconds=5,expectedRetainedRoots=18);plan['privateFiles']={n:H(S/n) for n in ['root_stage_guard.py','source_model_bindings.py','run-selected.py',*names]}
for family in ('original-keeper-native-query','original-keeper-native-file'):plan['registryRequirements'][family]=dict(current=4,reads=[1,2,3,4])
(S/'run-plan.json').write_text(json.dumps(plan,indent=2)+'\n');settings=json.loads((S/'supervisor-plan.json').read_text());settings['initialSeconds']=90;(S/'supervisor-plan.json').write_text(json.dumps(settings,indent=2)+'\n')
(S/'source2.diff').write_bytes((PACK/'source2.diff').read_bytes());diff=[]
for row in stage['sourcePaths']:
 if row['path'] in ('tests/device/contract-versions.json','tests/device/validate_contract_versions.py'):
  diff.extend(difflib.unified_diff((R/row['path']).read_text().splitlines(True),Path(row['candidate']).read_text().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path']))
(S/'registry-own2-actual-current.diff').write_text(''.join(diff));(S/'clone-provenance-passive9.json').write_text(json.dumps(dict(parentStageFreezeSHA256=H(B/'freeze.json'),sourcePacketFreezeSHA256=H(PACK/'freeze.json'),allPriorActualFiles=2487,caseCount=9,initialSeconds=90,killAfterSeconds=5,expectedGenuineRoots=18,actualDependencyChanges=changes,executed=False,publicEdits=False),indent=2)+'\n');(S/'README-passive9.txt').write_text('''Root42 exact9/90+kill5/18actualTD, mainmodelsabf099a1 fromfrozen42d027.
Actual oldRPC6PASS87files added to2400prior=2487all oldfiles preserved. Source2
keeper94fc/Resource5b96 plus ownquery/file3->4 lines only; everyforeign/touch2 key
and field staysactualcurrent. Strict broadSource/launcher/SDK snapshots BEFORE
imports and AFTERRootPUB mandatory; canonical3namespace resolver unchanged.
Actual realTDretention/helper/localaliases, Source/Task/Thread/AFC/HTTP/context/
FD children cleanup and two originalcensuses unchanged. Default1 release still
closeswholeSource; onlyactualbornmotion2 originalUp leavesSource for genuine
passive observations, finalsettlecloses. No SDK/auth/native/quiet/whole claim.
Rootonly PUB/run; no target imports/tests byagent. Clockcarrier/strict4quiet
collector is a separate nextSource packet, not qualified bythese9.
''')
for f in S.rglob('*.py'):ast.parse(f.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(f.relative_to(S)):H(f) for f in sorted(S.rglob('*')) if f.is_file()}),indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(f.relative_to(P)):H(f) for f in sorted(P.rglob('*')) if f.is_file()}),indent=2)+'\n');print(json.dumps(dict(stageFreeze=H(S/'freeze.json'),parentFreeze=H(P/'freeze.json'),actualDependencyChanges=changes),indent=2))
