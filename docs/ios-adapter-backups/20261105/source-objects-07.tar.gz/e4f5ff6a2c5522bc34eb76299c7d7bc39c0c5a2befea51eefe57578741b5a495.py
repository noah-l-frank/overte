"""Metadata-only exact eight-case preparation; never imports target modules."""
from pathlib import Path
import ast,hashlib,json,stat,subprocess
R=Path.cwd().resolve(strict=True)
assert R.name=='overte-ios-feature-adapters-resume-20261026'and(R/'.git').is_file()
def target(p):
    p=Path(p);assert p.resolve().is_relative_to(R);return p
def write(p,text):target(p).write_text(text)
def mkdir(p):target(p).mkdir(parents=True,exist_ok=True,mode=0o700)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
O=R/'.ios-host-tmp/lifecycle-policy-member-cost-passive-one-pinned-overlay-root-preparation-20261103'
P=R/'.ios-host-tmp/lifecycle-policy-member-cost-passive-profile-source-proposal-20261103'
S=R/'.ios-host-tmp/lifecycle-literal-container-policy-plan-bound-source-proposal-20261103'
H=R/'.ios-host-tmp/lifecycle-literal-token-eight-optional-path-pinned-overlay-root-preparation-20261103'
assert sha(O/'freeze.json')=='c7d10c746bf6e38b943b41758b24e0c715493f17322182ac74ac272f8aba8826'
assert sha(S/'freeze.json')=='3b7329a0d8ba3624ebda49a2c958fba0f4f89f11e6a35a3bd1f762f583f207b8'
head=subprocess.run(['git','rev-parse','HEAD'],check=True,capture_output=True,text=True).stdout.strip()
assert head=='4a8287f147ad33555c34dbda420b0f09162fb368'and not H.exists()
for root in(O,S):
    for relative,digest in json.loads((root/'freeze.json').read_text())['files'].items():assert sha(root/relative)==digest
mkdir(H)
# Copy only frozen preparation sources/metadata, never completed output trees.
for relative in json.loads((O/'freeze.json').read_text())['files']:
    if relative in('immutable-source-pins.json','AST-ONLY.json')or relative.startswith('models/'):continue
    out=H/relative;mkdir(out.parent);write(out,(O/relative).read_text())
for original in sorted((S/'models').rglob('*')):
    if original.is_file():out=H/'models'/original.relative_to(S/'models');mkdir(out.parent);target(out).write_bytes(original.read_bytes())
def rebase(value):
    if type(value)is dict:return {key:rebase(row)for key,row in value.items()}
    if type(value)is list:return [rebase(row)for row in value]
    return value.replace(str(O),str(H)).replace(str(P),str(S)).replace(sha(P/'freeze.json'),sha(S/'freeze.json'))if type(value)is str else value
for relative in('plan.json','maps.json',*[str(p.relative_to(O))for p in(O/'maps').glob('*.json')]):
    write(H/relative,json.dumps(rebase(json.loads((H/relative).read_text())),indent=2,sort_keys=True)+'\n')
rows=json.loads((H/'maps.json').read_text())
for row in rows.values():row['sha256']=sha(Path(row['path']))
write(H/'maps.json',json.dumps(rows,indent=2,sort_keys=True)+'\n')
stages=(
 ('literalRefs1','test_literal_tree_aliases_preserve_current_outcomes_and_exact_reference_order'),
 ('aliasMutation1','test_each_alias_reads_a_nested_mutation_and_new_unsupported_value_again'),
 ('fallbackLimits1','test_current_recursive_depth_key_and_primitive_types_take_exact_literal_behavior'),
 ('callbackOnce1','test_fallback_never_runs_a_changed_nonliteral_producer_twice'),
 ('classifier1','test_actual_classifier_mutation_uses_original_path_without_a_scan_result_memo'),
 ('planBinding1','test_foreign_plan_expected_identity_and_replaced_sealed_maps_refuse'),
 ('sameCode1','test_same_tokenizer_or_compiler_code_mutation_refuses_before_fast_comparison'),
 ('actualPolicy1','test_passive_actual_literal_instruction_policy_equivalence_without_publisher_post'))
case_rows=[]
for stage,method in stages:
    actual=stage=='actualPolicy1';kind='LifecycleLiteralTokenActualPolicyModels'if actual else'LifecycleLiteralTokenInstructionModels'
    value=dict(case='test_lifecycle_literal_token_instruction_models.'+kind+'.'+method,
        expectedTemporaryDirectories=3 if actual else 0,wallSeconds=180 if actual else 30,killAfterSeconds=5,
        diagnosticOnly=True,freshPublishQualified=False,pureTokenCounter=not actual,actualPublisherPOSTs=0)
    mkdir(H/stage);write(H/stage/'case.json',json.dumps(value,indent=2,sort_keys=True)+'\n');case_rows.append(dict(stage=stage,**value))
# Remove inherited UNRUN selection metadata so this preparation exposes only
# the exact eight authorized methods. The old preparation remains unchanged.
for path in sorted(H.rglob('case.json')):
    if path.parent.name not in {stage for stage,_method in stages}:
        target(path).unlink();target(path.parent).rmdir()
plan=json.loads((H/'plan.json').read_text());plan.update(caseCount=8,cases=[row['case']for row in case_rows],stageOrder=[v[0]for v in stages],stageCases=case_rows,
    sourceFreezeSha256=sha(S/'freeze.json'),diagnosticOnly=True,publicHead=head,
    expectedTemporaryDirectoriesPerCase=None,wallSeconds=None,killAfterSeconds=5)
for row in plan['overlays']:
    row['sha256']=sha(Path(row['path']));pub=Path(row['publicPath'])if row.get('publicPath')else R/'tests/device'/Path(*row['module'].split('.')).with_suffix('.py');row['publicPath']=str(pub);row['publicSha256']=sha(pub)if pub.is_file()else None
helper=S/'candidate/tests/device/ios/adapters/lifecycle_literal_token_instructions.py'
assert not any(row['module']=='ios.adapters.lifecycle_literal_token_instructions'for row in plan['overlays'])
plan['overlays'].append(dict(module='ios.adapters.lifecycle_literal_token_instructions',path=str(helper),sha256=sha(helper),
    publicPath=str(R/'tests/device/ios/adapters/lifecycle_literal_token_instructions.py'),publicSha256=None))
write(H/'plan.json',json.dumps(plan,indent=2,sort_keys=True)+'\n')
# Exact existing host drain/FD/task/thread/raw guard is preserved byte-for-byte.
assert sha(H/'root_stage_guard.py')==sha(O/'root_stage_guard.py')
# Generalize only the selected stage's literal TD count and fixed wall budget.
p=H/'root-supervise.py';text=p.read_text()
text=text.replace('original180+5 wall/process boundary','fixed30/180+5 wall/process boundary')
text=text.replace("plan=json.loads((PREP/'plan.json').read_text());REPO=Path(plan['repositoryRoot'])", "plan=json.loads((PREP/'plan.json').read_text());REPO=Path.cwd().resolve(strict=True)\nassert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and str(REPO)==plan['repositoryRoot']\ndef target(p):\n    p=Path(p);assert p.resolve().is_relative_to(REPO);return p")
text=text.replace("HERE.name in ('first1',)","HERE.name in "+repr(tuple(v[0]for v in stages)))
text=text.replace("out=HERE/'run';out.mkdir(mode=0o700,exist_ok=False)","selection=json.loads((HERE/'case.json').read_text());wall=selection['wallSeconds'];assert wall==(180 if HERE.name=='actualPolicy1'else 30)and selection['killAfterSeconds']==5\nout=HERE/'run';target(out).mkdir(mode=0o700,exist_ok=False)")
text=text.replace("os.open(out/name,", "os.open(target(out/name),")
text=text.replace("'180s',sys.executable", "str(wall)+'s',sys.executable")
text=text.replace("with(out/'test.log').open('x')", "with target(out/'test.log').open('x')")
write(p,text)
p=H/'run-selected.py';text=p.read_text()
text=text.replace('Root-only ONE own Fresh16 method','Root-only ONE exact literal-token own method')
text=text.replace("plan=json.loads((PREP/'plan.json').read_text());REPO=Path(plan['repositoryRoot']);assert Path.cwd()==REPO", "plan=json.loads((PREP/'plan.json').read_text());REPO=Path.cwd().resolve(strict=True)\nassert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and str(REPO)==plan['repositoryRoot']\ndef target(p):\n    p=Path(p);assert p.resolve().is_relative_to(REPO);return p\nselection=json.loads((HERE/'case.json').read_text());expected_roots=selection['expectedTemporaryDirectories']\nassert expected_roots==(3 if HERE.name=='actualPolicy1'else 0)")
text=text.replace("(HERE/name).mkdir(", "target(HERE/name).mkdir(")
text=text.replace("actual=real_td(suffix=suffix,prefix=prefix,dir=HERE/'retained',", "actual=real_td(suffix=suffix,prefix=prefix,dir=target(HERE/'retained'),")
text=text.replace("(HERE/'created-original-roots.json').write_text(", "target(HERE/'created-original-roots.json').write_text(")
text=text.replace("terminal(HERE/'cleanup',initial,owned)", "target(HERE/'cleanup/terminal-census-1.json');target(HERE/'cleanup/terminal-census-2.json')\n    terminal(target(HERE/'cleanup'),initial,owned)")
text=text.replace("(HERE/'cleanup/receipt.json').write_text(", "target(HERE/'cleanup/receipt.json').write_text(")
text=text.replace("assert len(owned)==3,'Expected three genuine inherited fixture temp roots'", "assert len(owned)==expected_roots,'Exact case TD ownership differs'")
text=text.replace("(HERE/'selected-result.json').write_text(", "target(HERE/'selected-result.json').write_text(")
text=text.replace("'Fresh16 own3 permits ZERO subprocesses/Node/SDK/device'", "'Literal-token own8 permits ZERO subprocesses/Node/SDK/device'")
# Pure TestCase methods retain their literal standard synchronous cleanups; the
# ActualPolicy case retains its actual IsolatedAsyncio Runner/cleanup unchanged.
text=text.replace('Standard TestSuite.run has returned only after real IsolatedAsyncio\n    # teardown, cleanups and Runner.close.', 'Standard TestSuite.run has returned after actual TestCase cleanups;\n    # the passive async case also completed its real AsyncRunner.close.')
write(p,text)
p=H/'guard.py';text=p.read_text()
# Only the shared new/old qualified-pass helper varies roots by the pinned case;
# every historical old case still defaults to its original three roots.
needle="receipt['twoCensusesPassed']and len(receipt['retainedRoots'])==3\n    before="
assert text.count(needle)==1
text=text.replace(needle,"receipt['twoCensusesPassed']and len(receipt['retainedRoots'])==json.loads((stage/'case.json').read_text()).get('expectedTemporaryDirectories',3)\n    before=")
text=text.replace("order=('first1',)","order="+repr(tuple(v[0]for v in stages)))
write(p,text)
history=json.loads((H/'historical-proof-scope.json').read_text());stage=O/'first1';artifact=stage/'bindings/passive-policy-member-cost-profile.json'
report=json.loads((stage/'run/report.json').read_text());data=json.loads(artifact.read_text())
assert report['exitCode']==0 and report['retainedFiles']==42 and data['completed']and data['noPublisherWALOrPOST']and data['actualPublisherPOSTs']==0
history.setdefault('passiveDiagnostics',[]).append(dict(path=str(stage),reportSha256=sha(stage/'run/report.json'),artifactPath=str(artifact),artifactSha256=sha(artifact),scope='Historical actual supported policy scaffold profile only; NOT production matcher/FreshPublish'))
write(H/'historical-proof-scope.json',json.dumps(history,indent=2,sort_keys=True)+'\n')
# Explicit exact HEAD-backed metadata drift only. Every non-listed old source,
# failure, receipt and original keeps its full old stat/inode/hash pin.
F=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
    a=p.lstat();assert not p.is_symlink()and p.resolve(strict=True)==p
    out=dict(stat=[getattr(a,k)for k in F])
    if p.is_file():out['sha256']=sha(p)
    assert out['stat']==[getattr(p.lstat(),k)for k in F];return out
old=json.loads((O/'immutable-source-pins.json').read_text());pins={};drift=[]
allowed={'tests/device/ios/CHAT_LOADED_OBJECT_OWNER.md','tests/device/ios/FEATURE_ADAPTER_COVERAGE_20261021.md','tests/device/ios/README.md'}
for name,expected in old.items():
    path=Path(name);actual=pin(path)
    if actual!=expected:
        relative=str(path.relative_to(R));assert relative in allowed
        committed=subprocess.run(['git','show',head+':'+relative],check=True,capture_output=True).stdout
        assert hashlib.sha256(committed).hexdigest()==actual['sha256']
        drift.append(dict(path=name,old=expected,current=actual,head=head,scope='exact committed public documentation only'))
    pins[name]=actual
assert {str(Path(row['path']).relative_to(R))for row in drift}==allowed
write(H/'public-head-rebase-provenance.json',json.dumps(dict(oldControllerFreeze=sha(O/'freeze.json'),publicHead=head,exactChanges=drift,noHistoricalReceiptOrGuardSkipped=True),indent=2,sort_keys=True)+'\n')
write(H/'selection-provenance.json',json.dumps(dict(parentControllerFreeze=sha(O/'freeze.json'),sourceFreeze=sha(S/'freeze.json'),selected=case_rows,terminalGuardUnchanged=True,rootStageGuardSha256=sha(H/'root_stage_guard.py'),productionGuardReplacements=0,noPublisherPOSTs=True,noSDKOrNode=True,expectedPureTDs=0,expectedPassiveTDs=3),indent=2,sort_keys=True)+'\n')
write(H/'ROOT-PLAN.txt',"""ROOT REVIEW REQUIRED — EXACT OWN8, UNRUN

Current HEAD4a8287f147ad33555c34dbda420b0f09162fb368; source3b7329a0.
Run each stage exactly once, in plan.stageOrder: seven pure authored own methods
under30+5 each, then ONLY seven fully qualified PASS admit actualPolicy1 under
unchanged180+5. Root final review/authorization is required before any launch.
Failure/refusal/timeout stops selection; no retry, product or expected-state fix.
No automatic Own7/FreshPublish/Whole16/PNG/End/SDK/Node/service expansion.

Each pure method is the exact frozen unittest.TestCase method and uses its real
standard TestSuite/TestCase cleanup, no sockets/services/native acquisitions and
zero temporary fixture roots. The final passive subject uses the exact existing
independent Actor/Current7/History/PFS fixture, three genuine retained TDs and
actual IsolatedAsyncio teardown/cleanups/Runner.close. Its original publisher
journal remains empty before/after: no Publisher WAL, intent, POST or freshness
claim. All raw models remain explicitly SDK/native models; no vendor SDK runs.

The actual unchanged root_stage_guard checks two FD/task/thread/child/SDK/raw
censuses after genuine cleanup. Parent binds PGID/SID/startticks and requires
empty owned process group/session before two retained raw censuses. Before and
after full frozen source/dependency/maps/old failure and original pins must
match. Every predecessor result is rechecked from its actual saved report,
selection, cleanup, source pins and current unchanged original inode/hash census.

Only three exact committed public documentation changes since historical c7d10
are admitted into the new full pins, each matched against current Git HEAD.
Historical raw/source maps/receipts are preserved, never rewritten or bypassed.
All overlays execute exact complete candidate files, with new literal helper
added; no function, parent/native guard or expected state is substituted.
New controller writes require checked cwd+canonical repo and target containment.

Example command from checked Resume cwd (do not run before Root review):
python3 -B .ios-host-tmp/lifecycle-literal-token-eight-optional-path-pinned-overlay-root-preparation-20261103/root-supervise.py .ios-host-tmp/lifecycle-literal-token-eight-optional-path-pinned-overlay-root-preparation-20261103/literalRefs1
""")
# Add all newly reviewed source/model/birth-map files, previous complete output,
# builder and source freezes, while preserving original exact historical pins.
for p in(O/'freeze.json',O/'immutable-source-pins.json',*sorted((O/'first1').rglob('*')),Path(__file__).resolve()):pins[str(p)]=pin(p)
partial=R/'.ios-host-tmp/lifecycle-literal-token-eight-pinned-overlay-root-preparation-20261103'
for p in sorted(partial.rglob('*')):
    if p.is_file():pins[str(p)]=pin(p)
p=R/'.ios-host-tmp/lifecycle-literal-token-eight-controller-tools-20261103/prepare-controller.py';pins[str(p)]=pin(p)
for root in(S,R/'.ios-host-tmp/lifecycle-literal-container-policy-comparison-source-proposal-20261103'):
    for relative,digest in json.loads((root/'freeze.json').read_text())['files'].items():
        path=root/relative;assert sha(path)==digest;pins[str(path)]=pin(path)
    pins[str(root/'freeze.json')]=pin(root/'freeze.json')
for p in sorted(H.rglob('*')):
    if p.is_file():pins[str(p)]=pin(p)
write(H/'immutable-source-pins.json',json.dumps(pins,indent=2,sort_keys=True)+'\n')
asts=[]
for p in sorted(H.rglob('*.py')):
    tree=ast.parse(p.read_bytes(),filename=str(p));asts.append(dict(path=str(p.relative_to(H)),sha256=sha(p),astSha256=hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest()))
write(H/'AST-ONLY.json',json.dumps(dict(status='NO_TARGET_IMPORT_OR_EXECUTION',files=asts),indent=2,sort_keys=True)+'\n')
files={str(p.relative_to(H)):sha(p)for p in sorted(H.rglob('*'))if p.is_file()}
write(H/'freeze.json',json.dumps(dict(status='PRIVATE_FROZEN_OWN8_UNRUN_ROOT_REVIEW_REQUIRED',sourceFreeze=sha(S/'freeze.json'),parentControllerFreeze=sha(O/'freeze.json'),files=files),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(controller=str(H),freeze=sha(H/'freeze.json'),pins=len(pins),pythonFiles=len(asts),overlays=len(plan['overlays']),maps=len(rows),cases=case_rows,executed=False),indent=2))
