//
//  AudioScriptingInterface.cpp
//  libraries/audio/src
//
//  Created by Stephen Birarda on 1/2/2014.
//  Copyright 2014 High Fidelity, Inc.
//  Copyright 2022-2023 Overte e.V.
//
//  Distributed under the Apache License, Version 2.0.
//  See the accompanying file LICENSE or http://www.apache.org/licenses/LICENSE-2.0.html
//  SPDX-License-Identifier: Apache-2.0
//

#include "AudioScriptingInterface.h"

#include <QVector3D>

#include <shared/QtHelpers.h>

#include "ScriptAudioInjector.h"
#if defined(Q_OS_IOS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
#include "IOSAudioOnceCue.h"
#endif
#include <ScriptEngine.h>
#include <ScriptEngineCast.h>
#include <ScriptEngineLogging.h>
#include <ScriptManager.h>

STATIC_SCRIPT_TYPES_INITIALIZER(+[](ScriptManager* manager){
    auto scriptEngine = manager->engine().get();

    registerAudioMetaTypes(scriptEngine);
});

STATIC_SCRIPT_INITIALIZER(+[](ScriptManager* manager){
    auto scriptEngine = manager->engine().get();
    auto scopeGuard = scriptEngine->getScopeGuard();

    scriptEngine->registerGlobalObject(scopeGuard.get(), "Audio", DependencyManager::get<AudioScriptingInterface>().data());
});

void registerAudioMetaTypes(ScriptEngine* engine) {
    scriptRegisterMetaType<AudioInjectorOptions, injectorOptionsToScriptValue, injectorOptionsFromScriptValue>(engine);
    scriptRegisterMetaType<SharedSoundPointer, soundSharedPointerToScriptValue, soundSharedPointerFromScriptValue>(engine);
}


void AudioScriptingInterface::setLocalAudioInterface(AbstractAudioInterface* audioInterface) {
    if (_localAudioInterface) {
        QMetaObject::invokeMethod(_localAudioInterface, "cancelRecordedVoiceTest", Qt::QueuedConnection);
        disconnect(_localAudioInterface, &AbstractAudioInterface::isStereoInputChanged,
                   this, &AudioScriptingInterface::isStereoInputChanged);
        disconnect(_localAudioInterface, &AbstractAudioInterface::recordedVoiceTestStatusChanged,
                   this, nullptr);
    }
    
    _localAudioInterface = audioInterface;
    updateRecordedVoiceTestStatus({ { "phase", "idle" }, { "error", "" } });

    if (_localAudioInterface) {
        connect(_localAudioInterface, &AbstractAudioInterface::isStereoInputChanged,
                this, &AudioScriptingInterface::isStereoInputChanged);
        connect(_localAudioInterface, &AbstractAudioInterface::recordedVoiceTestStatusChanged,
                this, &AudioScriptingInterface::updateRecordedVoiceTestStatus);
    }
}

ScriptAudioInjector* AudioScriptingInterface::playSystemSound(SharedSoundPointer sound) {
    AudioInjectorOptions options;
    options.localOnly = true;
    options.positionSet = false;    // system sound
    return playSound(sound, options);
}

ScriptAudioInjector* AudioScriptingInterface::playSound(SharedSoundPointer sound, const AudioInjectorOptions& injectorOptions) {
    if (sound) {
        // stereo option isn't set from script, this comes from sound metadata or filename
        AudioInjectorOptions optionsCopy = injectorOptions;
        optionsCopy.stereo = sound->isStereo();
        optionsCopy.ambisonic = sound->isAmbisonic();
        optionsCopy.localOnly = optionsCopy.localOnly || sound->isAmbisonic();  // force localOnly when Ambisonic

#if defined(Q_OS_IOS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
        auto& cueOwner=overte::e2e::IOSAudioOnceCue::instance();
        const auto cue=cueOwner.consume(sound,optionsCopy,ScriptManager::featureNativeCallContext());
        if (cue.decision==overte::e2e::IOSAudioOnceCue::Decision::Refuse) { return nullptr; }
        overte::e2e::IOSAudioOnceCue::InjectionScope cueBirth(cue.claim);
#endif
        auto injector = DependencyManager::get<AudioInjectorManager>()->playSound(sound, optionsCopy);
#if defined(Q_OS_IOS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
        cueOwner.managerReturned(injector);
#endif
        if (!injector) {
            return nullptr;
        }
        auto wrapper=new ScriptAudioInjector(injector);
#if defined(Q_OS_IOS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
        cueOwner.wrapperBorn(wrapper);
#endif
        return wrapper;

    } else {
        qCDebug(scriptengine) << "AudioScriptingInterface::playSound called with null Sound object.";
        return nullptr;
    }
}

void AudioScriptingInterface::setStereoInput(bool stereo) {
    if (_localAudioInterface) {
        QMetaObject::invokeMethod(_localAudioInterface, "setIsStereoInput", Q_ARG(bool, stereo));
    }
}

bool AudioScriptingInterface::isStereoInput() {
    bool stereoEnabled = false;
    if (_localAudioInterface) {
        stereoEnabled = _localAudioInterface->isStereoInput();
    }
    return stereoEnabled;
}

bool AudioScriptingInterface::getServerEcho() {
    bool serverEchoEnabled = false;
    if (_localAudioInterface) {
        serverEchoEnabled = _localAudioInterface->getServerEcho();
    }
    return serverEchoEnabled;
}

void AudioScriptingInterface::setServerEcho(bool serverEcho) {
    if (_localAudioInterface) {
        QMetaObject::invokeMethod(_localAudioInterface, "setServerEcho", Q_ARG(bool, serverEcho));
    }
}

void AudioScriptingInterface::toggleServerEcho() {
    if (_localAudioInterface) {
        QMetaObject::invokeMethod(_localAudioInterface, "toggleServerEcho");
    }
}

bool AudioScriptingInterface::getLocalEcho() {
    bool localEchoEnabled = false;
    if (_localAudioInterface) {
        localEchoEnabled = _localAudioInterface->getLocalEcho();
    }
    return localEchoEnabled;
}

void AudioScriptingInterface::setLocalEcho(bool localEcho) {
    if (_localAudioInterface) {
        QMetaObject::invokeMethod(_localAudioInterface, "setLocalEcho", Q_ARG(bool, localEcho));
    }
}

void AudioScriptingInterface::toggleLocalEcho() {
    if (_localAudioInterface) {
        QMetaObject::invokeMethod(_localAudioInterface, "toggleLocalEcho");
    }
}

void AudioScriptingInterface::startRecordedVoiceTest() {
    if (_localAudioInterface) {
        QMetaObject::invokeMethod(_localAudioInterface, "startRecordedVoiceTest", Qt::QueuedConnection);
    } else {
        updateRecordedVoiceTestStatus({ { "phase", "error" }, { "error", "unsupported" } });
    }
}

void AudioScriptingInterface::cancelRecordedVoiceTest() {
    if (_localAudioInterface) {
        QMetaObject::invokeMethod(_localAudioInterface, "cancelRecordedVoiceTest", Qt::QueuedConnection);
    }
}

QVariantMap AudioScriptingInterface::getRecordedVoiceTestStatus() const {
    QMutexLocker lock(&_recordedVoiceTestMutex);
    return _recordedVoiceTestStatus;
}

void AudioScriptingInterface::updateRecordedVoiceTestStatus(const QVariantMap& status) {
    {
        QMutexLocker lock(&_recordedVoiceTestMutex);
        _recordedVoiceTestStatus = status;
    }
    emit recordedVoiceTestStatusChanged(status);
}
