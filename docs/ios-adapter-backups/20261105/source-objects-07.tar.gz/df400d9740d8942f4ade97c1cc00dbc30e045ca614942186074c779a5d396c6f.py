"""One bounded read-only attribution probe; never a timing/feature verdict."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tempfile,time
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
PLAN=json.loads((HERE/'profile-plan.json').read_text())
def pin(path):
    a=path.lstat();row={key:getattr(a,key) for key in FIELDS}
    if stat.S_ISREG(a.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    else:assert stat.S_ISDIR(a.st_mode)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in FIELDS),str(path)
    return row
def save(name,value):(HERE/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def sources():
    names=subprocess.check_output(['rg','--files','-0','tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml'],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name};assert REPO/'interface/src/main.cpp' in paths
    for root in (HERE,REPO/PLAN['retainedReview']):
        frozen=json.loads((root/'freeze.json').read_text());paths.update(root/name for name in frozen['files']);paths.add(root/'freeze.json')
    paths.add(Path(__file__).resolve());paths.add(Path(PLAN['expectedOriginals']))
    return {str(p.relative_to(REPO)):pin(p) for p in sorted(paths)}
def originals():
    root=Path(PLAN['actualRetainedTemporaryRoot']);return {str(p.relative_to(root)):pin(p) for p in (root,*sorted(root.rglob('*')))}
def process(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))
assert not (HERE/'root-profile-report.json').exists() and not (HERE/'root-profile-first.log').exists(),'Single probe only'
runs=HERE/'runs';runs.mkdir(mode=0o700,exist_ok=True)
out=Path(tempfile.mkdtemp(prefix='first-',dir=runs));out.chmod(0o700)
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='tests/device:tests/device/self_tests:tests/device/ios/self_tests',OVERTE_WORLD6_READONLY_PROFILE_ROOT=str(out))
before=sources();old=originals();assert old==json.loads(Path(PLAN['expectedOriginals']).read_text());save('root-profile-source-before.json',before);save('root-profile-originals-before.json',old)
print('SOURCE_PINS',len(before),flush=True);started=time.monotonic()
with (HERE/'root-profile-first.log').open('x') as log:
    task=subprocess.Popen(['timeout','--signal=TERM','--kill-after=5s','90s',sys.executable,str(HERE/'profile-saved-once.py')],cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    binding=process(task.pid);assert binding is not None;save('root-profile-process-binding.json',binding)
    print('ACTUAL_PROCESS',json.dumps(binding,sort_keys=True),flush=True);code=task.wait()
after=sources();save('root-profile-source-after.json',after)
first=originals();second=originals();save('root-profile-originals-first.json',first);save('root-profile-originals-second.json',second)
remaining=[]
for path in Path('/proc').iterdir():
    if not path.name.isdecimal():continue
    item=process(int(path.name))
    if item is not None and item['session']==task.pid:remaining.append(item)
report=dict(exitCode=code,seconds=time.monotonic()-started,outputRoot=str(out),sourcePins=len(after),allPinsEqual=before==after,all547OriginalsUnchanged=old==first==second,remainingOwnedProcesses=remaining,diagnosticOnly=True,performanceQualified=False,nativeExecuted=False,sdkExecuted=False,inputExecuted=False,wholeQualified=False)
save('root-profile-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
assert before==after and old==first==second and not remaining
raise SystemExit(code)
