"""Actual changed smoke PASS before any selected mechanisms target import."""
import hashlib,json,stat
from pathlib import Path
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def require(here,repo,current=None):
 if here.name=='smoke1':return []
 smoke=here.parent/'smoke1';out=smoke/'root-run-first';report=json.loads((out/'report.json').read_text())
 assert report['exitCode']==0 and report['retainedFiles']==0 and all(report[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not report['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text())
 cases=json.loads((smoke/'run-plan.json').read_text())['cases'];r=json.loads((smoke/'selected-result.json').read_text())
 assert len(cases)==1 and r['selectedIds']==cases and r['successful'] and r['testsRun']==1 and not any(r[k] for k in ('failureCount','errorCount','skippedCount'))
 old=json.loads((out/'root-source-map.json').read_text());assert old['repositoryRoot']==str(repo)
 if current is not None:assert current['currentSourcePins']==old['currentSourcePins'] and current['reviewedCandidates']==old['reviewedCandidates']
 for relative,digest in old['currentSourcePins'].items():
  p=repo/relative;assert p.is_relative_to(repo) and p.resolve(strict=True)==p and hashlib.sha256(p.read_bytes()).hexdigest()==digest
 c=smoke/'case-cleanup-1';a=json.loads((c/'terminal-census-1.json').read_text());b=json.loads((c/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 receipt=json.loads((c/'receipt.json').read_text());assert receipt['case']==cases[0] and receipt['actualStandardCaseRunReturned'] and receipt['twoCensusesPassed']
 process=json.loads((out/'process-binding.json').read_text())['task']
 try:row=Path('/proc',str(process['pid']),'stat').read_text().rsplit(') ',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):row=None
 assert row is None or int(row[19])!=process['startTicks']
 frozen=set(json.loads((smoke/'freeze.json').read_text())['files'])|{'freeze.json'};paths=[]
 for p in sorted(smoke.rglob('*')):
  if str(p.relative_to(smoke)) in frozen:continue
  assert p.resolve(strict=True)==p;v=p.lstat();assert stat.S_ISREG(v.st_mode) or stat.S_ISDIR(v.st_mode);paths.append(p)
 return paths
