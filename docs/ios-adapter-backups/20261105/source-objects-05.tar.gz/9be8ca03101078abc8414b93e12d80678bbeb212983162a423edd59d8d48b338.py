"""Versioned paired Avatar End through the existing original Keeper creator.

End1 remains separate. No completed role is made live again to inspect the
other role, and no process/SDK effect is inferred from a parent phase bit.
"""
from copy import deepcopy
from pathlib import Path
import os

from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact, need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.operation_transport_guard import scope as transport_scope
from adapters.script_feature.history import same
from ios.adapters.avatar_keeper_handoff import AvatarKeeperHandoff
from ios.adapters.avatar_terminal import AvatarTerminal, ROLES
from ios.adapters.installed_code import cleanup_record
from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd as Keeper
from ios.adapters.original_keeper_process_end import filename as keeper_filename
from adapters.normal_ui import NativeUIError


PROFILE = 'ios-avatar-original-keeper-end-v2'


class AvatarNativeReplyRetirementUnavailable(NativeUIError):
    pass


def filename(run):
    from feature_journeys.contract import identifier
    return 'ios-avatar-primary-'+identifier(run)+'-keeper-terminal2.json'


def directory_identity(path):
    path = Path(path)
    before = path.lstat()
    need(path.is_absolute() and path.resolve(strict=True) == path
        and before.st_uid == os.geteuid() and before.st_mode & 0o7777 == 0o700
        and __import__('stat').S_ISDIR(before.st_mode))
    after = path.lstat()
    fields = ('st_dev','st_ino','st_mode','st_uid','st_gid')
    need(all(getattr(before,key) == getattr(after,key) for key in fields))
    return {key:getattr(before,key) for key in fields}


class KeeperOriginalView:
    """Real historical constructor over the unchanged Keeper codec.

    It has no Source, WebDriver, factory, transport, clock or signal method.
    Assigned methods retain their real defining-module globals and code.
    """
    def __init__(self, flow, role, root):
        need(role in ROLES)
        self.root, self.lock = Path(root), flow.locks[role]
        self.binding, self.run = deepcopy(flow.state['bindings'][role]), flow.run
        self.role, self.stage, self.profile_key, self.profile = role, 0, 'avatar', 'ios-original-keeper-process-end-v1'
        self.store = PrivateFeatureState(flow.runtime.state_path(flow.selectors[role]).with_name(
            keeper_filename('avatar', role, 0)))
        self.lock.assert_held()
        self.previous = self.store.read()
        need(self.previous is not None)
        self.state = self.decode(self.previous)
        from adapters.original_frame_store import OriginalFrameStore
        self.files = OriginalFrameStore(self.root, self.binding, self.run, role,
            self.bound, self.no_write, namespace='original-process-end', schema_prefix='iosOriginalProcessEnd')
        self.bound()

    @staticmethod
    def no_write(*_args):
        need(False)

    decode = Keeper.decode
    bound = Keeper.bound
    original = Keeper.original
    owned_paths = Keeper.owned_paths
    validate_history = Keeper.validate_history
    validate_sdk = staticmethod(Keeper.validate_sdk)
    validate_creator = Keeper.validate_creator
    _summary = Keeper._summary

    def originals(self):
        self.bound()
        for ordinal, ref in enumerate(self.state['records'], 1):
            need(ref['index'] == ordinal)
            self.original(ref)
        pending = self.state['pending']
        if pending is None:
            self.validate_history()
        elif pending['file'] is not None and pending['file']['phase'] != 'planned':
            self.files.read(pending['file'])
        need({p for p in self.owned_paths() if p.parent == self.root} == set(self.root.iterdir()))


class AvatarKeeperTerminal:
    def __init__(self, terminal, *, historical=False):
        need(type(terminal) is AvatarTerminal and type(historical) is bool)
        self.terminal, self.flow, self.historical = terminal, terminal.flow, historical
        self.handoff = AvatarKeeperHandoff(terminal)
        self.store = PrivateFeatureState(self.flow.runtime.state_path(self.flow.selector).with_name(filename(self.flow.run)))
        self.previous = self.store.read()
        self.failed = False
        self.state = None if self.previous is None else self.decode(self.previous)
        if historical:
            need(self.previous is not None)
        self.bound()

    def envelope(self):
        return dict(iosAvatarKeeperTerminalVersion=2, profile=PROFILE,
            runId=self.flow.run, binding=deepcopy(self.flow.state['bindings']['primary']),
            handoffSha256=digest(self.handoff.previous), state=deepcopy(self.state))

    def decode(self, value):
        exact(value, {'iosAvatarKeeperTerminalVersion','profile','runId','binding','handoffSha256','state'})
        need(type(value['iosAvatarKeeperTerminalVersion']) is int and value['iosAvatarKeeperTerminalVersion'] == 2
            and value['profile'] == PROFILE and value['runId'] == self.flow.run
            and same(value['binding'], self.flow.state['bindings']['primary'])
            and self.handoff.previous is not None and value['handoffSha256'] == digest(self.handoff.previous))
        state = value['state']
        exact(state, {'phase','roles','end'})
        need(state['phase'] in ('preparing','ending','complete'))
        exact(state['roles'], set(ROLES))
        for role in ROLES:
            row = state['roles'][role]
            exact(row, {'phase','root','parentIdentity','rootIdentity','proof','nativeReplyDuty'})
            need(row['phase'] in ('planned','opened','complete')
                and row['root'] == str(self.role_root(role)))
            if row['phase'] == 'planned':
                need(row['rootIdentity'] is row['proof'] is None)
            else:
                need(type(row['rootIdentity']) is dict)
            need((row['proof'] is not None) == (row['phase'] == 'complete'))
            if row['nativeReplyDuty'] is not None:
                duty = row['nativeReplyDuty']
                exact(duty, {'iosAvatarNativeReplyDutyVersion','file','cutoffSourceReference',
                    'lastNativePacket','nativeWriterOriginal','originalAFCAbsence','retirementEstablished'})
                from adapters.native_feature_observation import FILE
                need(type(duty['iosAvatarNativeReplyDutyVersion']) is int and duty['iosAvatarNativeReplyDutyVersion'] == 1
                    and duty['file'] == FILE and duty['nativeWriterOriginal'] is None
                    and duty['originalAFCAbsence'] is None and duty['retirementEstablished'] is False)
            # A subsequent typed producer packet must replace the explicit
            # missing-interface branch; Source2 has no positive retirement
            # schema or setter that could mint the missing native original.
            if row['phase'] == 'complete':
                need(row['nativeReplyDuty'] is not None and row['nativeReplyDuty']['retirementEstablished'] is True)
        need((state['end'] is not None) == (state['phase'] == 'complete'))
        if state['phase'] == 'complete':
            need(all(row['phase'] == 'complete' for row in state['roles'].values()))
        return deepcopy(state)

    def role_root(self, role):
        need(role in ROLES)
        owners = self.terminal.roles(self.terminal.state['sealedRoles'])
        return owners[role][0].root/('avatar-original-keeper-'+self.flow.run+'-'+role)

    def bound(self):
        for lock in self.flow.locks.values():
            lock.assert_held()
        need(not self.failed and same(self.store.read(), self.previous))
        self.handoff.bound()
        if self.previous is not None:
            need(same(self.previous, self.envelope()))
        return True

    def save(self):
        need(not self.historical)
        try:
            # state may legitimately advance, while its original CAS operand
            # and every independent handoff original must stay exact.
            for lock in self.flow.locks.values():
                lock.assert_held()
            need(not self.failed and same(self.store.read(), self.previous))
            self.handoff.bound()
            value = self.envelope()
            self.decode(value)
            self.store.write(value, self.previous)
            need(same(self.store.read(), value))
            self.previous = deepcopy(value)
        except BaseException:
            self.failed = True
            raise

    def prepare(self):
        need(not self.historical)
        self.bound()
        if self.state is None:
            handoff = self.handoff.prepare()
            rows = {}
            for role in ROLES:
                root = self.role_root(role)
                need(not os.path.lexists(root))
                rows[role] = dict(phase='planned', root=str(root),
                    parentIdentity=directory_identity(root.parent), rootIdentity=None, proof=None, nativeReplyDuty=None)
            self.state = dict(phase='preparing', roles=rows, end=None)
            self.save()
        for role in ROLES:
            row = self.state['roles'][role]
            root = Path(row['root'])
            need(directory_identity(root.parent) == row['parentIdentity'])
            if row['phase'] == 'planned':
                # An uncertain mkdir with no saved identity is duty, never a
                # directory that a reopened constructor may silently adopt.
                need(not os.path.lexists(root))
                os.mkdir(root, 0o700)
                from ios.adapters.audio_passive_runtime import fsync_directory
                fsync_directory(root.parent)
                row.update(phase='opened', rootIdentity=directory_identity(root))
                self.save()
            need(directory_identity(root) == row['rootIdentity'])
        if self.state['phase'] == 'preparing':
            self.state['phase'] = 'ending'
            self.save()
        self.inventory()

    def view(self, role):
        return KeeperOriginalView(self.flow, role, self.state['roles'][role]['root'])

    def cutoff_join(self, role, view):
        """The real sealed-role native packet must precede its own cutoff.

        Neither a Python-host time nor a cross-role frame ID substitutes for
        the unchanged native continuation/instance/process checks.
        """
        if view.state['cutoff'] is None:
            return
        from adapters.native_clock_join import follow
        from ios.adapters.lifecycle_current_transport import frame_original
        last = self.terminal.verify_seal()[role]
        owners = self.terminal.roles(self.terminal.state['sealedRoles'])
        owner = owners[role][0]
        event = last['original']['event']
        final = owner.final_owner(value=owner.kept(event['owner']))
        group = final.group(final.record(event['references'][-1]))[role]
        before = group['right']['clockJoin']['nativeAfter']
        value = view.original(view.state['cutoff'])['sourceFrame']['frame']['original']
        current = value['original']
        frame_original(current, view.binding, view.run, 'primary', current['ticket'], view.state['owner'])
        need(value['nativeFeatureInstance'] == before['instance'])
        follow(before, current['current']['clockJoin']['nativeBefore'])

    def inventory(self):
        self.bound()
        self.handoff.original()
        if self.state is None:
            return {self.store.path, self.handoff.store.path}
        paths = {self.store.path, self.handoff.store.path}
        for role in ROLES:
            row = self.state['roles'][role]
            root = Path(row['root'])
            need(directory_identity(root.parent) == row['parentIdentity'])
            if row['phase'] == 'planned':
                need(not os.path.lexists(root))
                continue
            need(directory_identity(root) == row['rootIdentity'])
            store = PrivateFeatureState(self.flow.runtime.state_path(self.flow.selectors[role]).with_name(
                keeper_filename('avatar', role, 0)))
            if store.read() is None:
                need(row['phase'] == 'opened' and not list(root.iterdir()))
            else:
                view = self.view(role)
                view.originals()
                need(same(view.state['installed']['source'], self.handoff.previous['processSources'][role]))
                self.cutoff_join(role, view)
                paths.update(view.owned_paths())
                if row['phase'] == 'complete':
                    need(same(view._summary(), row['proof']))
        return paths

    def transport_guard(self):
        """Original API/finish bounds and all completed/pending duties persist."""
        self.inventory()
        self.handoff.check_deadline()
        f = self.flow
        for role in ROLES:
            row = self.state['roles'][role]
            selector = f.selectors[role]
            sdk = PrivateFeatureState(f.runtime.state_path(selector)).read()
            installed = f.runtime.adapter._binding_store(selector).read()
            store = PrivateFeatureState(f.runtime.state_path(selector).with_name(keeper_filename('avatar', role, 0)))
            if store.read() is None:
                # No Keeper exists yet: the first real constructor must still
                # acquire this exact existing SDK/source, never ensure_session.
                _client, session, state, _target, scope = f.runtime._existing(selector)
                need(sdk is not None and same(sdk, state) and session == f.state['bindings'][role]['sessionId']
                    and same(scope, {k:v for k,v in f.state['bindings'][role].items() if k != 'processIdentity'}))
            else:
                view = self.view(role)
                expected = view.state['sdkState']
                if view.state['phase'] == 'complete' or view.state['deletion'] is not None:
                    # Canonical CAS may have completed before its parent CAS
                    # returned. Only original deletion+creator+SDK proofs can
                    # admit actual missing states; they are not recreated.
                    need(view.state['sdk'] is not None and view.state['creator'] is not None
                        and view.state['deletion'] is not None and view.state['deleteIssued'])
                    need(sdk is None or same(sdk, expected))
                    if installed is not None:
                        cleanup_record(view.state['installed'], installed)
                        need(installed['phase'] == 'retiring')
                else:
                    need(same(sdk, expected) and installed is not None)
                    cleanup_record(view.state['installed'], installed)
                    need(installed['phase'] in ('bound','retiring'))
                if row['phase'] == 'complete':
                    need(sdk is None and installed is None)
        return True

    def before_original_stop(self, keeper):
        """Retain the real cutoff; an unimplemented writer is never an End."""
        need(type(keeper) is Keeper and keeper.role in ROLES and keeper.profile_key == 'avatar'
            and keeper.stage == 0 and keeper.runtime is self.flow.runtime
            and keeper.selector == self.flow.selectors[keeper.role]
            and keeper.root == self.role_root(keeper.role)
            and keeper.lock is self.flow.locks[keeper.role]
            and keeper.binding == self.flow.state['bindings'][keeper.role]
            and keeper.run == self.flow.run and keeper.state['cutoff'] is not None
            and keeper.state['stop'] is None)
        self.transport_guard()
        view = self.view(keeper.role)
        self.cutoff_join(keeper.role, view)
        original = view.original(view.state['cutoff'])
        packet = original['sourceFrame']['frame']['original']['original']['current']['clockJoin']['nativeAfter']
        from adapters.native_feature_observation import FILE
        value = dict(iosAvatarNativeReplyDutyVersion=1, file=FILE,
            cutoffSourceReference=deepcopy(original['sourceReference']),
            lastNativePacket=deepcopy(packet), nativeWriterOriginal=None,
            originalAFCAbsence=None, retirementEstablished=False)
        row = self.state['roles'][keeper.role]
        if row['nativeReplyDuty'] is None:
            row['nativeReplyDuty'] = value
            self.save()
        else:
            need(same(row['nativeReplyDuty'], value))
        raise AvatarNativeReplyRetirementUnavailable(
            'Original Avatar native fixed-response writer and independent AFC absence are not yet implemented; cutoff and SDK duties remain owned')

    def finish(self):
        need(not self.historical)
        self.prepare()
        if self.state['phase'] == 'complete':
            return self.original()
        with transport_scope(self.transport_guard):
            for role in ROLES:
                self.transport_guard()
                row = self.state['roles'][role]
                if row['phase'] == 'complete':
                    continue
                f = self.flow
                keeper = Keeper(f.runtime, f.selectors[role], row['root'], f.state['bindings'][role],
                    f.run, role, 0, 'avatar', f.locks[role], epoch_ms=f.epoch_ms,
                    monotonic=f.monotonic, sleep=f.sleep)
                keeper.arm()
                self.before_original_stop(keeper)
                proof = keeper.finish()
                view = self.view(role)
                need(same(view._summary(), proof))
                row.update(phase='complete', proof=deepcopy(proof))
                self.save()
            self.transport_guard()
            from ios.adapters.avatar_keeper_terminal_contract import end as validate_end
            value = dict(iosAvatarKeeperEndVersion=2, profile=PROFILE, runId=self.flow.run,
                seal=deepcopy(self.handoff.previous['seal']), handoffSha256=digest(self.handoff.previous),
                roles={role:deepcopy(self.state['roles'][role]['proof']) for role in ROLES})
            validate_end(value)
            self.state.update(phase='complete', end=value)
            self.save()
        return self.original()

    def original(self, *, membership=None):
        from ios.adapters.avatar_keeper_terminal_contract import end as validate_end
        from adapters.original_file_reads import scope as original_reads
        need(membership is None or type(membership) is set)
        self.bound()
        need(self.state is not None and self.state['phase'] == 'complete')
        with original_reads(fresh=True) as reads:
            paths = self.inventory()
            need(all(self.state['roles'][role]['phase'] == 'complete' for role in ROLES))
            value = validate_end(self.state['end'])
            need(value['handoffSha256'] == digest(self.handoff.previous)
                and same(value['seal'], self.handoff.previous['seal']))
            for role in ROLES:
                view = self.view(role)
                need(same(value['roles'][role], view._summary()))
                need(PrivateFeatureState(self.flow.runtime.state_path(self.flow.selectors[role])).read() is None
                    and self.flow.runtime.adapter._binding_store(self.flow.selectors[role]).read() is None)
            # Every newly owned path is decoded, never admitted by its name.
            need(paths <= reads)
        if membership is not None:
            membership.update(reads)
        return deepcopy(value)
