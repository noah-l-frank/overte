"""Root-only metadata for one exact Emote source-family group; no SUT imports.

This preparer pins source declarations; it never imports a project subject,
starts a counter, touches old original corpora, or infers a feature verdict.
"""
from pathlib import Path
import argparse,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
SOURCE=Path(__file__).resolve().parent
HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
S3=REPO/'.ios-host-tmp/emote-post-controller-durable-sources-source3-private-20261104'
S4=REPO/'.ios-host-tmp/emote-post-controller-runtime-inventory-source4-private-20261104'
PACKETS=((S3,'source-freeze.json','e5c0b8462ec16883a2da980fefdfe71edccc90bc18159db7a1acea37f1b20b69'),
 (S4,'source-freeze.json','d20d68491981a69caa33f34a0688c4010b31412fbdaa1b4257367b0c9ceaaf11'),
 (REPO/'.ios-host-tmp/lifecycle-independent-emote-durable-post-controller-source3-full-semantic-review-20261104','freeze.json','f37c610ac834c5ae9ed0d27fe56711922ee9c2fbb9f0fe1b9b18a2d861187b46'),
 (REPO/'.ios-host-tmp/lifecycle-independent-emote-post-controller-runtime-inventory-source4-full-semantic-review-20261104','freeze.json','9ee55d4fb6ce02151f2e74eda678fd8b444c26955ec3c95a59a1d330cf86067e'))
CONTROLS=('metadata_reader','host_common','source_execution_readiness','closed_import_origins','owned_write_boundary','class_cleanup_custody','definition_custody')
EXECUTORS=('run-group.py','supervise-group.py',*(name+'.py'for name in CONTROLS),'readonly-shared-stdlib-sources.json','third-party-source-declarations.json','SOURCE-RECIPE.json','PROJECT-DEFINING-ORIGINS.json','DEFINITION-INVENTORY.json')

def frozen(folder,leaf,sha,physical):
    path=folder/leaf;assert pin(path)['sha256']==sha;physical[str(path)]=pin(path);value=json.loads(path.read_text())
    for name,row in value['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        path=folder/name;assert pin(path)['sha256']==(row if type(row)is str else row['sha256']);physical[str(path)]=pin(path)
    return value

def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','expected-head','destination','group'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and head()==args.expected_head
    physical={};frozen(SOURCE,'source-freeze.json',args.source_freeze,physical)
    for packet in PACKETS:frozen(*packet,physical)
    closure=json.loads((SOURCE/'PROJECT-DEFINING-ORIGINS.json').read_text());recipe=json.loads((SOURCE/'SOURCE-RECIPE.json').read_text())
    assert recipe['status']=='SOURCE_ONLY_UNRUN'and recipe['caseCount']==20 and recipe['totalTDs']==22
    assert recipe['runtimeAdmission']is recipe['EndAdmission']is None and recipe['wholeQualified']is False
    group=recipe['groups'][args.group];assert len(group['cases'])==len(set(group['cases']))==group['caseCount']==4
    assert group['wallSeconds']==30 and group['killGraceSeconds']==5
    for row in closure['physicalComposition']:
        path=Path(row['path']);assert path.resolve(strict=True)==path and pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
    assert len(closure['physicalComposition'])==38 and len(closure['subjectModules'])==30
    modules={}
    for name,row in closure['modules'].items():
        path=Path(row['path']);assert path.resolve(strict=True)==path and pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
        modules[name]=dict(path=str(path),sha256=row['sha256'],package=row['package'],loader='source')
    namespaces=closure['namespacePackages']
    for name,roots in namespaces.items():
        assert all(part.isidentifier()for part in name.split('.'))and name not in modules
        for root in roots:
            path=Path(root);assert path.is_dir()and path.resolve(strict=True)==path and not any(z in('site-packages','dist-packages')for z in path.parts)
            # Namespace path comes from actual parent directories of a real
            # declared module, not from splitting a dotted directory basename.
            assert any(Path(row['path']).is_relative_to(path)for row in modules.values())
    for alias in closure['declaredBareAliases']:
        assert alias['name']in modules
        canonical=REPO/'tests/device'/(alias['canonical'].replace('.','/')+'.py')
        assert canonical.resolve(strict=True)==canonical and str(canonical)==alias['path']and pin(canonical)['sha256']==alias['sha256']
        if alias['canonical']in modules:assert modules[alias['name']]==modules[alias['canonical']]
        assert modules[alias['name']]['path']==alias['path']and modules[alias['name']]['sha256']==alias['sha256']
        assert any(edge['target']==alias['name']for edge in closure['actualASTImportEdges'])
    # New bare Rig name is an exact real import edge, never a fallback path.
    rig_alias=next(row for row in closure['declaredBareAliases']if row['name']=='test_emote_rig_measurements')
    rig_importer=modules['ios.self_tests.test_ios_emote_palette_original']
    import ast
    rig_edges=[node for node in ast.parse(Path(rig_importer['path']).read_text()).body
        if isinstance(node,ast.ImportFrom)and node.level==0 and node.module==rig_alias['name']]
    assert len(rig_edges)==1 and [item.name for item in rig_edges[0].names]==['RigPackets']
    assert modules[rig_alias['name']]==modules[rig_alias['canonical']]
    third={};external=json.loads((SOURCE/'third-party-source-declarations.json').read_text());assert len(external)==39
    for name,row in external.items():
        assert name=='PIL'or name.startswith('PIL.')or name=='defusedxml'or name.startswith('defusedxml.')
        path=Path(row['path']);assert path.resolve(strict=True)==path and pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
        assert row['kind']in('python','extension');third[name]=dict(path=str(path),sha256=row['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    current,current_pins=qualification(pin);physical.update(current_pins)
    assert current['actualReferenceCount']==141 and current['currentHelperAlgorithmQualified']is True and current['consumerCompositionQualified']is False
    assert len(current['requiredOriginalRoots'])==6 and pin(SOURCE/'closed_import_origins.py')['sha256']==HELPER
    # Actual checkout identity is fresh; historical source/utility proofs keep
    # their own original HEAD and are never relabeled as current composition.
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ');gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(path)]=pin(path)
    ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    refpath=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs');physical[str(refpath)]=pin(refpath)
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14');suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);stdnamespaces={}
    for current_dir,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current_dir);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink())
        rel=folder.relative_to(std)
        if rel.parts and all(n.isidentifier()for n in rel.parts)and not(folder/'__init__.py').is_file():stdnamespaces['.'.join(rel.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(suffixes):continue
            assert path.resolve(strict=True)==path and not path.is_symlink();physical[str(path)]=pin(path)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'and dest.name.startswith('emote-source34-own20-prepared-')and not dest.exists()
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    dest.mkdir(mode=0o700)
    for name in EXECUTORS:
        path=dest/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(path)]=pin(path)
    for name in CONTROLS:
        assert name not in modules;path=dest/(name+'.py');modules[name]=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=False,loader='source')
    subjects={name:{k:modules[name][k]for k in('path','sha256')}for name in closure['subjectModules']}
    origin=dict(modules=modules,namespacePackages=namespaces,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=stdnamespaces,stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='PRIVATE_EMOTE_SOURCE34_TWENTY_FIXED_GROUP_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(dest),actualPublicHead=args.expected_head,sourceFreeze=args.source_freeze,
        group=args.group,cases=group['cases'],caseCount=4,wallSeconds=30,killGraceSeconds=5,TDsPerCase=group['TDsPerCase'],nestedCleanupCallsPerCase=group['nestedCleanupCallsPerCase'],
        expectedTemporaryDirectories=group['expectedTemporaryDirectories'],expectedNestedCleanupCalls=group['expectedNestedCleanupCalls'],expectedClassCleanupGroups=1,classCleanupObservationVersion=1,
        sourceAndBinaryPins=physical,modules=modules,namespaces=namespaces,thirdPartyModules=third,originPlan=origin,subjectOriginModules=subjects,subjectOriginCount=30,
        pythonExecutable=dict(path=str(python),pin=physical[str(python)]),subjectHelperSha256=HELPER,subjectActualCopiedPath=str(dest/'closed_import_origins.py'),currentSourceExecution=current,
        helperQualificationRequiredOriginalRooms=current['requiredOriginalRoots'],externalRootGuardMustIncludeAllHelperOriginalRooms=True,
        NodeExecutions=0,PythonExecutions=0,SDKExecutions=0,overteNativeQueries=0,realNetwork=False,expectedJoinedThreadCases=0,maximumLiveUtilityChildren=0,
        oldApplicationCorpusInputs=0,globalOriginalScans=0,oldScenarioOriginalInputs=0,consumerCompositionQualified=False,runtimeAdmission=None,EndAdmission=None,FinishAdmission=None,nativeAdmission=None,nativeQualified=False,wholeQualified=False,utilityQualification=None,
        source3Freeze=recipe['source3Freeze'],source4Freeze=recipe['source4Freeze'],sourceFamilyModelOnly=True,
        trustedHostBootstrap='Actual interpreter/stdlib/initial controller modules are trusted physical origins. Delegated subjects use exact qualified C10d fresh source bytes; no entire-interpreter cache-absence claim.',
        limitations='No native execution, live paired Profile9, independent Actor/GPU evidence, new End, or feature qualification; negative originals and uncertain ownership duties remain retained.')
    output=dest/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),sha256=pin(output)['sha256'],group=args.group,cases=4,TDs=group['expectedTemporaryDirectories'],sourcePins=len(physical),targets=0,globalScans=0)))
if __name__=='__main__':main()
