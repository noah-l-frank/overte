"""Actual27 +current235 profile historical scope, exact reviewed12 PUB delta."""
import hashlib,json,stat
from pathlib import Path
from reviewed_scoped22 import historical
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
SC=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/emote-callback-live-prefix-scoped22-tail5-root-preparation-20261103');TAIL=SC/'tail5';PROFILE=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026/.ios-host-tmp/emote-callback-live-prefix-current235-readonly-profile-corrected-root-preparation-20261103/profile1')
def checkpins(master):
 pins=json.loads((master/'actual-proof-current-pins.json').read_text())
 for name,expected in pins.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();v=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):v['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert v==expected and v['stat']==[getattr(p.lstat(),k) for k in F]
 return [Path(name) for name in pins]
def exited(out):
 p=json.loads((out/'process-binding.json').read_text())['task']
 try:row=Path('/proc',str(p['pid']),'stat').read_text().rsplit(') ',1)[1].split()
 except (FileNotFoundError,ProcessLookupError):row=None
 assert row is None or int(row[19])!=p['startTicks']
def passed(stage,count):
 out=stage/'root-run-first';r=json.loads((out/'report.json').read_text());assert r['exitCode']==0 and all(r[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not r['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text());assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 cases=json.loads((stage/'run-plan.json').read_text())['cases'];a=json.loads((stage/'selected-result.json').read_text());assert len(cases)==count and a['selectedIds']==cases and a['successful'] and a['testsRun']==count and not any(a[k] for k in ('failureCount','errorCount','skippedCount'))
 for i,case in enumerate(cases,1):
  c=stage/('case-cleanup-'+str(i));r=json.loads((c/'receipt.json').read_text());assert r['case']==case and r['actualStandardCaseRunReturned'] and r['twoCensusesPassed']
  a=json.loads((c/'terminal-census-1.json').read_text());b=json.loads((c/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 a=json.loads((stage/'terminal-census-1.json').read_text());b=json.loads((stage/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 return cases

def require(here,repo,current=None):
 master=here.parent;paths=checkpins(master);actual,oldpaths=historical(SC,repo);paths+=oldpaths
 assert json.loads((SC/'root-scoped22-report.json').read_text())==actual;tail=passed(TAIL,5);scope=json.loads((SC/'scope-plan.json').read_text());assert tail==scope['tail'] and len(set(scope['unchangedPrefix']+tail))==27
 passed(PROFILE,1);metric=json.loads((PROFILE/'profile-result.json').read_text());assert metric['historicalOnly'] and metric['originalFiles']==235 and metric['records']==1 and metric['cacheRows']==1 and metric['coldReopenCalls']>=2 and metric['warmReopenCalls']==0 and metric['readMembership']==215 and metric['readMembershipEqual'] and metric['allOriginalPinsUnchanged'] and not metric['old747RuntimeReplay']
 delta=json.loads((master/'actual-reviewed-publication-delta.json').read_text());manifest=Path(delta['manifest']);assert hashlib.sha256(manifest.read_bytes()).hexdigest()==delta['manifestSHA256'];assert json.loads(manifest.read_text())['files']==delta['files']
 old=json.loads((PROFILE/'root-run-first/root-source-map.json').read_text());expected=dict(old['currentSourcePins']);assert old['repositoryRoot']==str(repo)
 for name,row in delta['files'].items():assert expected.get(name)==row['baseSha256'];expected[name]=row['candidateSha256']
 from foreign_publication_rebase import apply
 expected=apply(expected,repo)
 if current is not None:assert current['currentSourcePins']==expected
 for name,digest in expected.items():
  p=repo/name;assert p.is_relative_to(repo) and p.resolve(strict=True)==p and hashlib.sha256(p.read_bytes()).hexdigest()==digest
 if here.name=='window1':
  first=master/'focused2';passed(first,2)
  frozen=set(json.loads((first/'freeze.json').read_text())['files'])|{'freeze.json'}
  for p in first.rglob('*'):
   if str(p.relative_to(first)) not in frozen:assert p.resolve(strict=True)==p;paths.append(p)
 checkpins(master)
 return paths+[manifest,master/'actual-reviewed-publication-delta.json',master/'actual-proof-current-pins.json',master/'reviewed_scoped22.py',master/'prior_scoped_prerequisite.py']
