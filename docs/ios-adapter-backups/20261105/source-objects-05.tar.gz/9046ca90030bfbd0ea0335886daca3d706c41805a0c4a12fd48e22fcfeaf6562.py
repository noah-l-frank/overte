"""Private explicit extra received SDK scope; no public feature admission."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.avatar_configuration import selector


def settings(value,flow,received):
    exact(value,{'audioOrdinaryReceivedCompositionVersion','receivedTarget','receivedArtifactRoot','pairOriginalRoot'})
    need(type(value['audioOrdinaryReceivedCompositionVersion'])is int and value['audioOrdinaryReceivedCompositionVersion']==1)
    need(selector(value['receivedTarget'])==received.selector and received.selector not in(flow.primary_selector,flow.actor_selector))
    need(value['receivedArtifactRoot']==str(received.root))
    roots=[Path(value['receivedArtifactRoot']),Path(value['pairOriginalRoot'])]
    others=[flow.primary_root,flow.actor_root,flow.public_root,Path(flow.config['primaryWholeRoot']),Path(flow.config['actorWholeRoot'])]
    others.extend(flow.adapter.state_path(s).parent for s in(flow.primary_selector,flow.actor_selector))
    others.append(received.runtime.state_path(received.selector).parent)
    for root in roots:
        need(root.is_absolute()and root.resolve(strict=True)==root and root.is_dir())
        PrivateFeatureState(root/'composition-boundary.json')._parent()
    need(roots[0]!=roots[1]and roots[0]not in roots[1].parents and roots[1]not in roots[0].parents)
    need(all(a!=b and a not in b.parents and b not in a.parents for a in roots for b in others))
    return deepcopy(value)
