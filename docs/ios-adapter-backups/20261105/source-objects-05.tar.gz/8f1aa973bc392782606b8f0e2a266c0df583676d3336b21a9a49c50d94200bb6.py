"""Prepare, but never apply or import, the narrow publisher transfer proposal."""
from pathlib import Path
import ast,difflib,hashlib,json

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
source=ROOT/'tests/device/ios/adapters/avatar_feature.py';before=source.read_text()
boundary='    def observe_terminal(self,after_sequence):\n'
helper='''    def publish_terminal_witness(self,publisher,original):
        """Reuse this held Actor publisher; every live delivery guard remains."""
        need(self.role=='actor' and type(publisher) is AvatarWitnessPublisher)
        # Keep the same fresh phase read as the previous second factory call.
        self.phase.read()
        def current(method,actual):
            return (getattr(method,'__self__',None) is self
                and getattr(actual,'__self__',None) is self
                and getattr(method,'__func__',None) is getattr(actual,'__func__',None))
        need(publisher.phase is self.phase and publisher.lock is self.lock
            and publisher.run==self.run and publisher.area=='avatar-people'
            and same(publisher.binding,self.state['bindings']['actor'])
            and publisher.store.path==self.store.path.with_name('phase-publication-avatar-people-'+self.run+'-actor.json')
            and publisher.epoch_ms is self.epoch_ms and publisher.monotonic is self.monotonic
            and current(publisher.validate_original,self.terminal_witness_original)
            and current(publisher.guard,self.cleanup_deadline))
        return publisher.publish(original)

'''
old='                    self.terminal_witness_publisher().publish(original)\n'
new='                    self.publish_terminal_witness(publisher,original)\n'
assert before.count(boundary)==before.count(old)==1
candidate=before.replace(boundary,helper+boundary).replace(old,new)
ast.parse(candidate,filename=str(source));(OUT/'avatar_feature_candidate.py').write_text(candidate)
test=(OUT/'test_ios_avatar_terminal_publisher_reuse_candidate.py').read_text();ast.parse(test)
test_target='tests/device/ios/self_tests/test_ios_avatar_terminal_publisher_reuse.py'
patch=''.join(difflib.unified_diff(before.splitlines(True),candidate.splitlines(True),
    fromfile='a/tests/device/ios/adapters/avatar_feature.py',tofile='b/tests/device/ios/adapters/avatar_feature.py'))
patch+=''.join(difflib.unified_diff([],test.splitlines(True),fromfile='/dev/null',tofile='b/'+test_target))
(OUT/'proposal.diff').write_text(patch)
report=dict(status='Private AST-only; no repository mutation, imports or tests',
    exactPaths=['tests/device/ios/adapters/avatar_feature.py',test_target],
    candidateSourceSha256=hashlib.sha256(candidate.encode()).hexdigest(),
    candidateTestSha256=hashlib.sha256(test.encode()).hexdigest(),
    preserved=['fresh phase.read at old second-factory boundary','publisher.bound/resolve/current original callback',
        'latest receipt validation and planned/issued CAS save/decode','fresh phase.read(floor) and1.5s delivery bounds',
        'actual POST and original resolve; no verdict/DTO memo'],
    rejects=['foreign Actor binding/path/phase/lock/run','replaced callback/deadline/clock callable',
        'changed publisher store CAS','changed fixture phase before delivery'],
    testScope='Real AvatarWitnessPublisher, PhaseFixtureReader, ScriptSourceLock, private journals and existing HTTP fixture; existing modeled original decoder only; no Final proof/current product fact supplied',
    estimateSeconds='Under2 seconds expected, unmeasured; fixed60 proposed',
    wholeFeatureQualified=False,nativeCompiled=False,deviceQualified=False)
(OUT/'plan.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
