"""Optional negative-only host-budget originals; never observation authority."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from pathlib import Path
from types import ModuleType, FunctionType
import hashlib
import marshal
import struct
import sys
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError

PROFILE = 'host-api-budget-refusal-original-v1'
_ACTIVE = ContextVar('host_api_budget_refusal_original', default=None)
_SOURCES = {
    'avatar': ('ios.adapters.avatar_api_entry', (25, 30)),
    'world-web': ('ios.adapters.world_web_api_clock', (25,)),
}


def require(value):
    if not value:
        raise NativeUIError('Host budget diagnostic custody is invalid')


def grant_original(owner, seconds):
    active = _ACTIVE.get()
    if active is not None:
        active.grant(owner, seconds, sys._getframe(1))


def refusal_original(owner, value):
    active = _ACTIVE.get()
    if active is not None:
        active.capture(owner, value, sys._getframe(1))


def scalar(value):
    # No repr(), user conversions or math predicate is called. Exact float
    # bytes preserve non-finite values without JSON NaN or an invented value.
    if value is None:
        return {'type': 'NoneType', 'value': None}
    if type(value) is bool:
        return {'type': 'bool', 'value': value}
    if type(value) is int:
        return {'type': 'int', 'value': value}
    if type(value) is float:
        return {'type': 'float', 'ieee754BigEndianHex': struct.pack('>d', value).hex()}
    return {'type': 'unsupported', 'valueRetained': False}


class ApiBudgetRefusalOriginal:
    """One explicitly activated API call, one genuine owner, one refusal file.

    Source identity is supplied by the existing pinned import map/controller.
    This observer seals it through the scope; it cannot establish installed
    Source, SDK, native, process, clock or granted operation authority.
    """
    def __init__(self, path, family, diagnostic_context):
        require(type(self) is ApiBudgetRefusalOriginal and family in _SOURCES
                and type(diagnostic_context) is dict)
        repo = Path.cwd().resolve(strict=True)
        self.path = Path(path)
        require(repo.name == 'overte-ios-feature-adapters-resume-20261026'
                and (repo / '.git').is_file()
                and self.path.is_absolute() and self.path.resolve() == self.path
                and self.path.is_relative_to(repo / '.ios-host-tmp')
                and self.path.name == 'api-budget-refusal-original.json')
        self.family = family
        self.context = deepcopy(diagnostic_context)
        self.store = PrivateFeatureState(self.path)
        require(self.store.read() is None)
        self.used = False
        self.written = False
        self.ports = None
        self.owner = None
        self.origin = None
        self.monotonic = self.granted_deadline = None
        self.methods = tuple((name, getattr(type(self), name),
                              getattr(type(self), name).__code__)
                             for name in ('__init__', 'scope', '_bound', 'grant', 'capture'))

    @contextmanager
    def scope(self, source):
        require(_ACTIVE.get() is None and not self.used and self.ports is None)
        module_name, _seconds = _SOURCES[self.family]
        require(type(source) is ModuleType and source.__name__ == module_name
                and sys.modules.get(module_name) is source)
        namespace = vars(source)
        cls = namespace['Budget']
        init, check = cls.__init__, cls.check
        require(type(init) is FunctionType and type(check) is FunctionType
                and init.__globals__ is namespace and check.__globals__ is namespace
                and cls.__getattribute__ is object.__getattribute__
                and '__getattr__' not in vars(cls)
                and namespace['_budget_grant_original'] is grant_original
                and namespace['_budget_refusal_original'] is refusal_original
                and namespace['SECONDS'] == 25)
        self.ports = (source, namespace, cls, init, init.__code__, check, check.__code__,
                      grant_original, grant_original.__code__, refusal_original,
                      refusal_original.__code__, scalar, scalar.__code__)
        self.used = True
        token = _ACTIVE.set(self)
        try:
            yield self
        finally:
            _ACTIVE.reset(token)
            self.owner = self.origin = self.ports = None
            self.monotonic = self.granted_deadline = None

    def _bound(self, owner, caller, operation):
        require(_ACTIVE.get() is self and not self.written and self.ports is not None)
        for name, function, code in self.methods:
            require(getattr(type(self), name) is function and function.__code__ is code)
        (source, namespace, cls, init, init_code, check, check_code,
         grant, grant_code, refusal, refusal_code, encode, encode_code) = self.ports
        require(sys.modules.get(source.__name__) is source and vars(source) is namespace
                and namespace['Budget'] is cls and cls.__init__ is init and cls.check is check
                and init.__code__ is init_code and check.__code__ is check_code
                and init.__globals__ is namespace and check.__globals__ is namespace
                and namespace['_budget_grant_original'] is grant
                and namespace['_budget_refusal_original'] is refusal
                and grant_original is grant and grant.__code__ is grant_code
                and refusal_original is refusal and refusal.__code__ is refusal_code
                and scalar is encode and encode.__code__ is encode_code
                and namespace['SECONDS'] == 25 and type(owner) is cls
                and cls.__getattribute__ is object.__getattribute__
                and '__getattr__' not in vars(cls))
        expected = init_code if operation == 'grant' else check_code
        require(caller.f_code is expected and caller.f_globals is namespace
                and caller.f_locals.get('self') is owner)
        return vars(owner)

    def grant(self, owner, seconds, caller):
        state = self._bound(owner, caller, 'grant')
        require(self.owner is None and self.origin is None
                and type(seconds) is int and seconds in _SOURCES[self.family][1])
        if self.family == 'avatar':
            require(caller.f_locals.get('seconds') is seconds)
        else:
            require(seconds == self.ports[1]['SECONDS'])
        # These are the actual completed constructor assignments, not a new
        # start/clock or a recomputed grant. No file is written on birth.
        self.owner = owner
        self.origin = dict(seconds=seconds, initialLast=scalar(state['last']),
                           grantedDeadline=scalar(state['deadline']),
                           initialFailed=scalar(state['failed']))
        self.monotonic = state['monotonic']
        self.granted_deadline = state['deadline']

    def capture(self, owner, value, caller):
        state = self._bound(owner, caller, 'refusal')
        require(caller.f_locals.get('value') is value)
        source, namespace, cls, init, init_code, check, check_code, *_rest = self.ports
        if self.origin is None:
            # The original first check can fail before __init__ grants any
            # deadline. Require its actual constructor caller; invent no grant.
            parent = caller.f_back
            require(self.owner is None and parent is not None
                    and parent.f_code is init_code and parent.f_globals is namespace
                    and parent.f_locals.get('self') is owner
                    and state['deadline'] is None)
            origin = None
            self.owner = owner
        else:
            require(self.owner is owner and state['monotonic'] is self.monotonic
                    and state['deadline'] is self.granted_deadline)
            origin = deepcopy(self.origin)
        record = dict(apiBudgetRefusalOriginalVersion=1, profile=PROFILE,
                      family=self.family, diagnosticContext=deepcopy(self.context),
                      actualBudgetCheckCodeSha256=hashlib.sha256(marshal.dumps(check_code)).hexdigest(),
                      actualBudgetInitCodeSha256=hashlib.sha256(marshal.dumps(init_code)).hexdigest(),
                      originalPredicateRefused=True, constructorGrant=origin,
                      calculatedLocalValue=scalar(value),
                      afterPredicateStateSnapshot={name: scalar(state[name])
                                                   for name in ('last', 'deadline', 'failed')},
                      snapshotIsNotExecutedShortCircuitOperandTrace=True,
                      observationAuthority=False)
        self.store.write(record, None)
        self.written = True
