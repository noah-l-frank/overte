"""Actual normal first attempt/hold/HTTP/receiver/WAL; native/SDK are MODELS.

ACTIVE and UNRUN. No native/SDK/auth/current-resource/native-end/full gate opens.
"""
import asyncio
from copy import deepcopy
from unittest.mock import patch
from normal_child_fixture import NormalChildFixture


class NormalChildWorldHoldModels(NormalChildFixture):
    async def test_original_child_worker_runs_after_normal_intercepted_attempt_then_four_genuine_quiet_originals(self):
        from ios.adapters import lifecycle_world as world
        first=self.normal.owner
        protected={p:(p.stat().st_ino,p.read_bytes()) for p in first.store.path.parent.glob('ios-lifecycle-world-proof-*')}
        installed=self.normal.d.f.f.f;counts=(installed.sessions,installed.launches)
        old_actions=deepcopy(self.normal.calls);self.assertEqual(['POST','DELETE'],self.normal.counts())
        result=await self.owner.act(seconds=12);self.assertTrue(result['hostResponsibility'])
        self.assertEqual([0xC2,0xC2],self.f.states());self.assertEqual(16,len(self.commands))
        held=await self.owner.observe();self.assertEqual(.7,held['facts']['worldDisplacement'])
        self.assertIsNone(held['contact']['ended']);self.assertEqual('held',self.owner.state['phase'])
        released=await self.owner.release();self.assertEqual('released',released['terminal'])
        self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        for index in range(4):
            proof=await self.owner.sample_quiet()
            if index<3:self.assertIsNone(proof)
        self.assertGreaterEqual(proof['quiet']['nativeMilliseconds'],3000);self.assertEqual(4,proof['quiet']['samples'])
        self.assertEqual(30,len(self.commands));self.assertEqual(30,len({q['commandId'] for q in self.commands}))
        self.assertEqual(7,len(self.owner.state['frames']));self.assertEqual(counts,(installed.sessions,installed.launches))
        self.assertEqual(old_actions,self.normal.calls);self.assertEqual(protected,{p:(p.stat().st_ino,p.read_bytes()) for p in protected})
        for i in range(1,8):self.assertIn('originalChild',self.owner.frame(i))
        before=deepcopy(self.owner.proof());await self.owner.lease.settle();self.assertTrue(self.source._closing)
        self.assertEqual(before,self.owner.proof());self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_source_current_loss_after_real_down_keeps_original_up_but_cannot_supply_native_release_proof(self):
        await self.owner.act();commands=len(self.commands)
        with patch.object(self.cap,'current',side_effect=RuntimeError('Declared original Source/RSD current loss')):
            with self.assertRaises((RuntimeError,ValueError)):await self.owner.release()
            self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
            self.assertIsNone(self.owner.state['released']);self.assertEqual(commands,len(self.commands))
            status=await self.owner.lease.inspect();self.assertFalse(status['hostResponsibility'])
            await self.owner.lease.settle()
        self.assertTrue(self.source._closing);self.assertIsNone(self.owner.state['released'])
        self.assertEqual([0xC2,0xC2,0x02],self.f.states())

    async def test_lost_completed_prepare_return_keeps_exact_original_unborn_resource_cleanup_without_retry_or_native_release_claim(self):
        self.lose_prepare_response=True
        with self.assertRaises((RuntimeError,ValueError)):await self.owner.act()
        self.assertIsNone(self.ops.touch);self.assertEqual([],self.source._born);self.assertEqual([],self.f.states())
        resource=self.ops.retained_motion_resource[1];self.assertIs(resource,self.ops.touch_resources)
        self.assertIsNotNone(self.owner.original_child.lease);self.assertIsNone(self.owner.original_child.preparation)
        self.assertEqual([],self.owner.state['frames']);self.assertIsNone(self.owner.state['released'])
        before=len(self.commands);saved=(resource.store.path.stat().st_ino,resource.store.path.read_bytes())
        # Successful old-resource drainage has no corresponding native Up or
        # released frame. Existing release therefore still refuses its proof.
        with self.assertRaises((RuntimeError,ValueError)):await self.owner.release()
        self.assertTrue(self.source._closing);self.assertIsNone(self.ops.touch);self.assertEqual([],self.f.states())
        self.assertIsNone(self.owner.state['released']);self.assertEqual(before,len(self.commands))
        self.assertEqual(saved,(resource.store.path.stat().st_ino,resource.store.path.read_bytes()))
        with self.assertRaises((RuntimeError,ValueError)):await self.owner.act()
        self.assertEqual(before,len(self.commands));self.assertEqual([],self.f.states());self.assertIn('OSError',self.command_errors)

    async def test_public_connection_and_lease_aliases_cannot_redirect_or_block_original_up_after_actual_down(self):
        await self.owner.act();original=self.owner.lease;connection=self.owner._original_child;called=[]
        class Foreign:
            async def release(self):called.append('foreign-release');raise AssertionError('Foreign transport used')
            async def inspect(self):called.append('foreign-inspect');raise AssertionError('Foreign transport used')
            async def settle(self):called.append('foreign-settle');raise AssertionError('Foreign transport used')
        foreign=Foreign();self.owner.lease=foreign;connection.lease=foreign;self.owner.original_child=foreign
        commands=len(self.commands)
        with self.assertRaises((RuntimeError,ValueError)):await self.owner.release()
        self.assertEqual([],called);self.assertEqual([0xC2,0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        self.assertEqual(commands,len(self.commands));self.assertIsNone(self.owner.state['released'])
        self.assertIs(original,connection.retained_lease())
        status=await original.inspect();self.assertFalse(status['hostResponsibility'])
        await original.settle();self.assertTrue(self.source._closing);self.assertEqual([],called)
