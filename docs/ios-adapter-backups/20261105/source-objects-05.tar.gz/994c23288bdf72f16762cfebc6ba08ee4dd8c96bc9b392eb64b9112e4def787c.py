"""Private source/AST/JSON inventory; no tests/native/compiler execution."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
H=Path(__file__).resolve().parent;R=H.parent.parent;sha=lambda data:hashlib.sha256(data).hexdigest()
bases={r['path']:r['baseSha256'] for r in json.loads((H/'native-integration-plan.json').read_text())}
paths=sorted(str(p.relative_to(H)) for root in ('interface','tests') for p in (H/root).rglob('*') if p.is_file())
rows=[];patch=[];parsed=[];cases=[]
for name in paths:
 target=H/name;actual=R/name;data=target.read_bytes();base=actual.read_bytes() if actual.exists() else b''
 if name in bases:assert sha(base)==bases[name],('Base changed, private rebase needed',name)
 registry=name in ('tests/device/contract-versions.json','tests/device/validate_contract_versions.py')
 if registry:base=subprocess.check_output(['git','show','HEAD:'+name],cwd=R)
 rows.append(dict(path=name,privatePath=str(target.relative_to(R)),baseSha256=sha(base) if actual.exists() else None,sha256=sha(data),
     currentWorktreeSha256=sha(actual.read_bytes()) if actual.exists() else None,publication='OWN_REGISTRY_HUNKS_ONLY' if registry else 'VERIFY_BASE_SHA_THEN_EXACT_PATH'))
 if name.endswith('.py'):
  tree=ast.parse(data.decode(),filename=name);parsed.append(name)
  if '/self_tests/test_' in name:cases.extend(name+'::'+c.name+'::'+n.name for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
 if name.endswith('.json'):json.loads(data)
 patch.extend(difflib.unified_diff(base.decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),fromfile='a/'+name if actual.exists() else '/dev/null',tofile='b/'+name))
value=dict(status='PRIVATE_SOURCE_DRAFT_REQUIRES_ROOT_REVIEW_PUBLICATION_TEST_GRANT',feature='9/14 Audio partial settings vertical',
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),publicationPaths=rows,ownRegistryKeys=json.loads((H/'own-registry-keys.json').read_text()),
 astParsedOnly=parsed,authoredUnrunCases=cases,nativeCompilationVerified=False,hostTestsExecuted=False,deviceQualified=False,adapterCompletionCount='5/14',
 wholeSettingsRestorationAvailable=False,independentAcousticsAvailable=False,processSdkRetirementAvailable=False,
 missingNormalInput='iOS profile hides PTT; Audio unmute disables PTT. Active PTT must refuse new composition before normal mutation; no direct setter/hidden control supplied')
(H/'package-plan.json').write_text(json.dumps(value,indent=2)+'\n');(H/'full-private-packet.patch').write_text(''.join(patch));(H/'publication-paths.txt').write_text('\n'.join(paths)+'\n')
print(json.dumps(dict(paths=len(paths),astOnly=len(parsed),authoredUnrunCases=len(cases),ownRegistryKeys=len(value['ownRegistryKeys']))))
