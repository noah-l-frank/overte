"""Actual unchanged single held-terminal host case; diagnostic timings only."""
import faulthandler,inspect,time,unittest
from functools import wraps
from ios.adapters.avatar_scene import IOSAvatarScene
original=IOSAvatarScene.joined;counts={};started=time.perf_counter()
@wraps(original)
def measured(scene,reference):
    counts[scene.role]=counts.get(scene.role,0)+1;ordinal=counts[scene.role];at=time.perf_counter();chain=[]
    frame=inspect.currentframe().f_back
    try:
        while frame is not None and len(chain)<6:
            chain.append(frame.f_code.co_name);frame=frame.f_back
    finally:del frame
    label='role='+scene.role+' count='+str(ordinal)+' ref='+str(reference['index'])+' phase='+'/'.join(chain)
    print('Scene enter '+label+' hostWallElapsed='+format(at-started,'.3f'),flush=True)
    try:value=original(scene,reference)
    except BaseException as error:
        print('Scene failed '+label+' error='+type(error).__name__+' cpuWall='+format(time.perf_counter()-at,'.6f'),flush=True);raise
    print('Scene returned '+label+' cpuWall='+format(time.perf_counter()-at,'.6f'),flush=True);return value
IOSAvatarScene.joined=measured
faulthandler.enable();faulthandler.dump_traceback_later(540,repeat=False)
suite=unittest.defaultTestLoader.loadTestsFromName('ios.self_tests.test_ios_avatar_held_terminal.AvatarHeldTerminalTests.test_baseline_cleanup_preserves_login_holds_until_paired_os_and_sdk_end')
result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
print('Full held-terminal host diagnostic terminal: tests='+str(result.testsRun)+' errors='+str(len(result.errors))+' failures='+str(len(result.failures))+' sceneCounts='+str(counts)+' hostWallElapsed='+format(time.perf_counter()-started,'.3f')+' nativeBoundariesModeled=true',flush=True)
raise SystemExit(0 if result.wasSuccessful() else 1)
