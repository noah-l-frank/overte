from pathlib import Path
import ast,hashlib,json,difflib
r=Path.cwd();b=r/'.ios-host-tmp/lifecycle-authenticated-creator-draft-20261028';p=r/'.ios-host-tmp/lifecycle-authenticated-keeper-drain-overlay-20261028';p.chmod(0o700)
def sha(x):return hashlib.sha256(x).hexdigest()
def replace(s,a,z):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
rel='tests/device/ios/adapters/touch_lease.py';touch=(r/rel).read_text()
touch=replace(touch,'def __init__(self,store,session_factory,*,binding,run,check):','def __init__(self,store,session_factory,*,binding,run,check,admit_begin=None,on_worker_birth=None):')
touch=replace(touch,"        self.run,self.check=run,check;", "        if any(callback is not None and not callable(callback) for callback in (admit_begin,on_worker_birth)):raise TouchLeaseError('Touch worker owner is unavailable')\n        self._admit_begin,self._on_worker_birth=admit_begin,on_worker_birth\n        self._original_admit_begin,self._original_worker_birth=admit_begin,on_worker_birth\n        self.run,self.check=run,check;")
touch=replace(touch,'    async def begin(self,width,height,x,y,*,seconds):\n', '''    async def begin(self,width,height,x,y,*,seconds):
        # Optional host-owner admission is synchronous and precedes the WAL or
        # worker. It supplies no authentication/native touch fact.
        if self._admit_begin is not self._original_admit_begin or self._on_worker_birth is not self._original_worker_birth:raise TouchLeaseError('Original touch worker owner changed')
        if self._admit_begin is not None:
            admitted=self._admit_begin()
            if inspect.isawaitable(admitted) or admitted is False:raise TouchLeaseError('Touch acquisition is unavailable')
''')
touch=replace(touch,'        self.worker=asyncio.create_task(self._run())\n', '''        self.worker=asyncio.create_task(self._run())
        if self._on_worker_birth is not None:
            try:self._on_worker_birth(self,self.worker)
            except BaseException:
                self.request_release.set()
                raise
''')
relk='tests/device/ios/pymobiledevice3_wda_xctest.py';keeper=(b/'candidates/repo'/relk).read_text()
keeper=replace(keeper,'        self._leases = []\n','        self._leases = []\n        self._born = []\n')
start=keeper.index('    def touch_lease(self, store, *, binding, run, check):')
end=keeper.index('\n\n@asynccontextmanager\nasync def create_original_keeper_source',start)
keeper=keeper[:start]+'''    def _birth(self, lease, task):
        from ios.adapters.lifecycle_touch_transport import RetainedTouchWorker
        # Capture the ACTUAL born Task before validation can fail. Even a
        # changed public worker slot cannot erase this original responsibility.
        existing = next((row for row in self._born if row['lease'] is lease), None)
        if existing is not None:
            if existing['worker'] is not task:
                raise LaunchError("session-lifetime")
            if existing['owner'] is None:
                raise LaunchError("session-lifetime")
            existing['owner']._status()
            return existing
        row = dict(lease=lease, worker=task, loop=task.get_loop(),
                   release=lease.request_release, owner=None)
        self._born.append(row)
        if asyncio.get_running_loop() is not self._loop or row['loop'] is not self._loop:
            raise LaunchError("session-lifetime")
        row['owner'] = RetainedTouchWorker(lease)
        return row

    def touch_lease(self, store, *, binding, run, check):
        from ios.adapters.touch_lease import TouchLease
        from ios.adapters.hid_session import touch_session
        def admission():
            if self._closing:
                raise LaunchError("session-lifetime")
            self.current()
            return True
        admission()
        async def continuity():
            self._birth(lease, asyncio.current_task())
            # Only forward acquisition/Down is gated. Existing worker finally
            # sends its original ordinary Up/drain without this admission.
            admission()
            result = check()
            if inspect.isawaitable(result):
                result = await result
            admission()
            return result
        @asynccontextmanager
        async def session():
            admission()
            rsd, local_address = self.current()
            async with touch_session(rsd, local_address,
                                     socket_factory=self._source.udp_socket) as hid:
                admission()
                yield hid
        lease = TouchLease(store, session, binding=binding, run=run, check=continuity,
                           admit_begin=admission, on_worker_birth=self._birth)
        self._leases.append(lease)
        return lease

    async def settle_touches(self):
        # Close ALL future begin/acquire/Down admission before any await.
        self._closing = True
        failure = None
        for row in tuple(self._born):
            lease, worker, owner = row['lease'], row['worker'], row['owner']
            try:
                if (row['loop'] is not self._loop or worker.get_loop() is not self._loop
                        or lease.request_release is not row['release'] or owner is None):
                    raise LaunchError("session-lifetime")
                await owner.release()
            except BaseException as error:
                failure = failure or error
                # Request cleanup on the ORIGINAL worker's retained event. A
                # failed source check never cancels or replaces that worker.
                row['release'].set()
            while not worker.done():
                try:
                    await asyncio.shield(worker)
                except BaseException as error:
                    failure = failure or error
        if failure is not None:
            raise failure
''' +keeper[end:]
rows=[];diff=''
for path,original,candidate in [(rel,(r/rel).read_text(),touch),(relk,(b/'candidates/repo'/relk).read_text(),keeper)]:
 ast.parse(candidate);a=p/'originals'/path;z=p/'candidates'/path;a.parent.mkdir(parents=True,exist_ok=True);z.parent.mkdir(parents=True,exist_ok=True);a.write_text(original);z.write_text(candidate)
 rows.append(dict(path=path,baseSHA256=sha(original.encode()),candidateSHA256=sha(candidate.encode()),candidate=str(z)))
 diff+=''.join(difflib.unified_diff(original.splitlines(True),candidate.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
(p/'proposal.diff').write_text(diff);(p/'manifest.json').write_text(json.dumps(dict(status='PRIVATE UNRUN R3+R4',dependencyFreezeSHA256=sha((b/'freeze.json').read_bytes()),entries=rows,diffSHA256=sha(diff.encode())),indent=2)+'\n');print(json.dumps(rows,indent=2))
