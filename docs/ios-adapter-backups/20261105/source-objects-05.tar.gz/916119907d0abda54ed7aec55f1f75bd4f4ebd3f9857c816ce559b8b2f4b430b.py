"""Exactly five pure Emote-prefix cases; no runtime owner, original corpus or TD."""
from pathlib import Path
import builtins,io,hashlib,importlib.abc,importlib.util,json,os,signal,stat,sys,tempfile,threading,time,traceback,unittest,sysconfig
SOURCE=Path(__file__).resolve().parent;REPO=SOURCE.parent.parent
assert sys.dont_write_bytecode and len(sys.argv)==5
HERE=Path(sys.argv[4]);assert HERE.is_absolute()and HERE.resolve(strict=True)==HERE and HERE.parent==REPO/'.ios-host-tmp'and HERE.name.startswith('emote-graphics-prefix-pure5-output-')and HERE!=SOURCE
freeze_path=SOURCE/'source-freeze.json';assert hashlib.sha256(freeze_path.read_bytes()).hexdigest()==sys.argv[1]
source_freeze=json.loads(freeze_path.read_text())
for name,row in source_freeze['files'].items():assert hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()==row['sha256']
plan_path=Path(sys.argv[2]);assert plan_path.is_absolute()and plan_path.resolve(strict=True)==plan_path and plan_path.is_relative_to(REPO/'.ios-host-tmp')
assert hashlib.sha256(plan_path.read_bytes()).hexdigest()==sys.argv[3]
plan=json.loads(plan_path.read_text());declaration={};exec(compile((SOURCE/'declarations.py').read_bytes(),str(SOURCE/'declarations.py'),'exec'),declaration)
expected=declaration['DECLARATIONS']
assert all(plan[k]==expected[k]for k in expected)
assert plan['sourceRoot']==str(SOURCE)and plan['repository']==str(REPO)and plan['budgetSeconds']==30 and plan['killGraceSeconds']==5
assert len(plan['cases'])==5 and len(set(plan['cases']))==5
assert set(plan['modules'])==set(expected['moduleDeclarations'])
for name,row in plan['modules'].items():assert all(row[k]==v for k,v in expected['moduleDeclarations'][name].items())
EXPECTED=sys.argv[3]
stdlib_roots={Path(sysconfig.get_path(name)).resolve(strict=True)for name in ('stdlib','platstdlib')}
TEMP=HERE/'temporary'
if plan['needsTemporaryRoot']:assert TEMP.is_dir() and not list(TEMP.iterdir())
else:assert not TEMP.exists()
tempfile.tempdir=str(TEMP)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,value):
 path=HERE/name
 with path.open('w')as stream:stream.write(json.dumps(value,sort_keys=True,indent=2)+'\n')
 path.chmod(0o600)
for row in plan['frozenPackets']:assert digest(row['path'])==row['sha256']
for row in plan['modules'].values():assert digest(row['path'])==row['sha256']
save('preimport-verification.json',dict(status='EXACT_SOURCE_INVENTORY_CHECKED_BEFORE_ANY_TARGET_IMPORT',mappedModules=len(plan['modules']),frozenPackets=plan['frozenPackets'],python=sys.version,executable=sys.executable,executionPlanSha256=EXPECTED,supervisorPid=os.getpid()))
allowed_project_reads={Path(row['path'])for row in plan['modules'].values()}|{Path(row['path'])for row in plan['frozenPackets']}|{SOURCE/name for name in source_freeze['files']}|{freeze_path,plan_path}
loaded={};public_reads={};project_code_reads={};refusals=[];retained=[];depth=False
initial_modules=dict(sys.modules);initial_meta=list(sys.meta_path);initial_path=list(sys.path);initial_threads=set(threading.enumerate())
project_tops={name.split('.')[0]for name in plan['modules']}
assert not any(name.split('.')[0]in project_tops for name in sys.modules)

def pin_read(path):
 global depth
 if depth:return
 depth=True
 try:
  path=Path(path).resolve(strict=True)
  if path.is_relative_to(REPO) and path.is_file():
   assert path in allowed_project_reads,'Undeclared project/private/raw read refused'
   info=path.lstat();row=dict(sha256=digest(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode,bytes=info.st_size,mtimeNs=info.st_mtime_ns,ctimeNs=info.st_ctime_ns)
   if not path.is_relative_to(REPO/'.ios-host-tmp'):
    if str(path)in public_reads:assert public_reads[str(path)]==row,'Public dependency changed during this exact run'
    else:public_reads[str(path)]=row
   if path.suffix=='.py':
    if str(path)in project_code_reads:assert project_code_reads[str(path)]==row,'Actual private/public code origin changed during this exact run'
    else:project_code_reads[str(path)]=row
 finally:depth=False

def fd_census():
 rows={}
 for path in Path('/proc/self/fd').iterdir():
  try:target=os.readlink(path);info=path.stat();rows[path.name]=dict(target=target,device=info.st_dev,inode=info.st_ino,mode=info.st_mode)
  except(FileNotFoundError,ProcessLookupError):pass
 return rows

fd_before=fd_census()

def refuse(event,detail):
 row=dict(event=event,detail=detail);refusals.append(row);raise RuntimeError('AUDIT_REFUSED_'+event)

def audit(event,args):
 if event=='import':
  name=args[0]
  if any(name==prefix or name.startswith(prefix+'.')for prefix in ('pymobiledevice3','tidevice','pyidevice','zeroconf','appium','playwright','selenium','PIL')):refuse(event,name)
 elif event.startswith('socket.'):
  refuse(event,'All sockets, device/network transports and services are forbidden')
 elif event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','os.kill','os.killpg','os.setsid','os.setpgid') or event.startswith('os.spawn'):
  refuse(event,'All subprocess/compiler/Node/build/device actions are forbidden')
 elif event=='ctypes.dlopen':refuse(event,'Dynamic native SDK loads are forbidden')
 elif event=='open'and not depth:
  path,mode,flags=args
  writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
  if not writing and type(path)in (str,bytes,type(HERE)):
   path=Path(os.fsdecode(path))
   if path.is_absolute():pin_read(path)
 if event in ('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.'):
  # Classify before frame/code inspection. sys._getframe and __code__ reads
  # themselves emit audit events, which must return here without recursion.
  if event=='open':
   unused,mode,flags=args
   writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
   if not writing:return
  boundary.audit(event,args,sys._getframe(1))
# Loaded through its exact separately pinned controller source, before any
# target import. This is controller custody, never project reader authority.
boundary_path=SOURCE/'owned_write_boundary.py'
assert digest(boundary_path)==plan['writeBoundarySource']['sha256']
spec=importlib.util.spec_from_file_location('audio_owned_write_boundary_controller4',boundary_path)
boundary_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(boundary_module)
port_names=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_write_ports={name:getattr(os,name)for name in port_names if hasattr(os,name)}
original_c_io=(io.open,builtins.open)
assert plan['historicalLock']is None and plan['historicalCorpus']is None
boundary=boundary_module.OwnedWrites(HERE,protected=[SOURCE/name for name in plan['controllerFiles']]+[SOURCE/'source-freeze.json']+[Path(os.readlink('/proc/self/fd/'+str(fd))).resolve(strict=True)for fd in (1,2)])
boundary.install()
sys.addaudithook(audit)
pin_read(boundary_path)
def interrupted(signum,frame):raise KeyboardInterrupt('Original supervisor TERM at fixed30-second boundary')
original_term=signal.signal(signal.SIGTERM,interrupted)
monitor=sys.monitoring
def tool_state():return [(tool,monitor.get_tool(tool),monitor.get_events(tool))for tool in range(6)]
tools_before=tool_state();assert sys.getprofile()is None and sys.gettrace()is None
assert all(owner is None and mask==0 for tool,owner,mask in tools_before),'Dedicated pure suite requires all six real monitoring slots unused'

class Loader(importlib.abc.Loader):
 def __init__(self,name,row):self.name,self.row=name,row
 def create_module(self,spec):return None
 def exec_module(self,module):
  path=Path(self.row['path']);raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==self.row['sha256']
  module.__file__=str(path)
  if self.row['package']:module.__path__=[str(path.parent)]
  loaded[self.name]=self.row
  exec(compile(raw,str(path),'exec'),module.__dict__)
  assert digest(path)==self.row['sha256']
class Finder(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  row=plan['modules'].get(fullname)
  if row is not None:return importlib.util.spec_from_loader(fullname,Loader(fullname,row),is_package=row['package'])
  roots=plan['namespacePackages'].get(fullname)
  if roots is not None:
   spec=importlib.machinery.ModuleSpec(fullname,None,is_package=True);spec.submodule_search_locations=roots;return spec
  if fullname.split('.')[0]in project_tops:raise ImportError('Unmapped project import refused: '+fullname)
  spec=importlib.machinery.PathFinder.find_spec(fullname,path)
  if spec is not None and spec.origin not in (None,'built-in','frozen'):
   origin=Path(spec.origin).resolve(strict=True)
   assert any(origin.is_relative_to(root)for root in stdlib_roots)and not origin.is_relative_to(REPO)and 'site-packages'not in origin.parts and 'dist-packages'not in origin.parts,'Non-stdlib fallback refused before loader'
  return spec
finder=Finder();sys.meta_path.insert(0,finder)
real_td=tempfile.TemporaryDirectory
class RetainedDirectory:
 def __init__(self,*args,**kwargs):raise RuntimeError('Zero-TD pure suite refuses TemporaryDirectory before birth')
tempfile.TemporaryDirectory=RetainedDirectory
case_receipts=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  self.started=time.monotonic();print('EMOTE_GRAPHICS_PREFIX_PURE5_CASE_START',test.id(),flush=True);super().startTest(test)
 def stopTest(self,test):
  rows=[dict(name=t.name,ident=t.ident,daemon=t.daemon)for t in threading.enumerate()if t not in initial_threads and t.is_alive()]
  receipt=dict(id=test.id(),elapsedSeconds=time.monotonic()-self.started,newThreads=rows,auditRefusals=len(refusals))
  case_receipts.append(receipt);save('case-stop-receipts.json',case_receipts);print('EMOTE_GRAPHICS_PREFIX_PURE5_CASE_STOP',json.dumps(receipt),flush=True);super().stopTest(test)
  # Final census runs after the actual interrupted-case outer cleanup drain.
 def addError(self,test,error):
  super().addError(test,error);self.preserve(test,error,'ERROR')
 def addFailure(self,test,error):
  super().addFailure(test,error);self.preserve(test,error,'FAIL')
 def preserve(self,test,error,kind):
  raw=''.join(traceback.format_exception(*error));print('EMOTE_GRAPHICS_PREFIX_PURE5_'+kind,test.id(),raw,flush=True)
  with (HERE/'original-exceptions.log').open('a')as stream:stream.write(kind+' '+test.id()+'\n'+raw);stream.flush();os.fsync(stream.fileno())
result=None;fatal=None;actual_ids=[];selected_cases=[];cleanup_receipts=[];cleanup_ok=True;original_cleanup=unittest.TestCase.doCleanups;started=time.monotonic()
try:
 loader=unittest.TestLoader();suite=unittest.TestSuite()
 for selected in plan['cases']:
  module_name,class_name,method_name=selected.rsplit('.',2)
  assert module_name in plan['modules']
  actual_module=__import__(module_name,fromlist=['*'])
  suite.addTests(loader.loadTestsFromName(class_name+'.'+method_name,actual_module))
 def flatten(value):
  if isinstance(value,unittest.TestSuite):
   for child in value:yield from flatten(child)
  else:yield value
 selected_cases=list(flatten(suite));actual_ids=[case.id()for case in selected_cases];save('actual-selected-ids.json',dict(ids=actual_ids,loaderErrors=loader.errors))
 assert not loader.errors and actual_ids==plan['cases'] and suite.countTestCases()==5,'Exact overlay/selection unresolved; no broadened execution'
 result=unittest.TextTestRunner(verbosity=2,resultclass=Result,failfast=True).run(suite)
except BaseException:
 fatal=traceback.format_exc();(HERE/'original-fatal.log').write_text(fatal);print(fatal,flush=True)
finally:
 # Python3.14's original TestCase.run skips registered cleanups when its test
 # raises KeyboardInterrupt. Drain ONLY callbacks still registered, in actual
 # original stdlib order; normal completed cleanups are never called twice.
 for case in selected_cases:
  pending=len(case._cleanups);prior=case._outcome;drain=unittest.TestResult();success=True
  try:
   if pending:
    case._outcome=unittest.case._Outcome(drain)
    success=unittest.TestCase.doCleanups(case)
  except BaseException:
   success=False
   (HERE/('original-cleanup-error-'+str(len(cleanup_receipts))+'.log')).write_text(traceback.format_exc())
  finally:case._outcome=prior
  row=dict(id=case.id(),pendingBeforeOuterFinally=pending,remaining=len(case._cleanups),success=success,
   errors=[dict(testId=test.id(),traceback=text)for test,text in drain.errors],failures=[dict(testId=test.id(),traceback=text)for test,text in drain.failures],originalFunctionUnchanged=unittest.TestCase.doCleanups is original_cleanup)
  cleanup_receipts.append(row)
  if not success or case._cleanups or drain.errors or drain.failures or unittest.TestCase.doCleanups is not original_cleanup:cleanup_ok=False
 save('original-cleanup-chain.json',dict(success=cleanup_ok,cases=cleanup_receipts))
 restored=[]
 for name,module in list(sys.modules.items()):
  if name in loaded and getattr(module,'TemporaryDirectory',None)is RetainedDirectory:module.TemporaryDirectory=real_td;restored.append(name+'.TemporaryDirectory')
 tempfile.TemporaryDirectory=real_td;sys.meta_path[:]=initial_meta;sys.path[:]=initial_path
 assert tempfile.TemporaryDirectory is real_td
 after={};unchanged=True
 for path,before in public_reads.items():
  info=Path(path).lstat();row=dict(sha256=digest(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode,bytes=info.st_size,mtimeNs=info.st_mtime_ns,ctimeNs=info.st_ctime_ns);after[path]=row
  if row!=before:unchanged=False
 for row in loaded.values():assert digest(row['path'])==row['sha256']
 for row in plan['frozenPackets']:assert digest(row['path'])==row['sha256']
 for name,row in source_freeze['files'].items():assert digest(SOURCE/name)==row['sha256']
 fd_after=fd_census();save('actual-fd-census.json',dict(before=fd_before,after=fd_after,established=fd_before==fd_after))
 assert not TEMP.exists()and not retained
 tools_after=tool_state();local_after=[]
 actual_graphics=sys.modules.get('ios.adapters.graphics_history')
 if actual_graphics is not None:
  code=actual_graphics._follow_native.__code__
  local_after=[monitor.get_local_events(tool,code)for tool in range(6)]
 tools_restored=tools_after==tools_before and all(mask==0 for mask in local_after)and sys.getprofile()is None and sys.gettrace()is None
 save('actual-zero-producer-receipt.json',dict(temporaryRoots=[],rawInputs=[],sdkOwners=0,node=0,sockets=0,toolsBefore=tools_before,toolsAfter=tools_after,actualBodyLocalMasksAfter=local_after,toolSlotsRestored=tools_restored))
 statraw=Path('/proc/self/stat').read_text();fields=statraw[statraw.rfind(')')+2:].split()
 save('actual-runner-identity.json',dict(pid=os.getpid(),parent=int(fields[1]),group=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]),subprocessBirths=0,auditBlocksAllSpawnsAndTargetSignals=True))
 actual_code_after={}
 for path,before in project_code_reads.items():
  info=Path(path).lstat();row=dict(sha256=digest(path),device=info.st_dev,inode=info.st_ino,mode=info.st_mode,bytes=info.st_size,mtimeNs=info.st_mtime_ns,ctimeNs=info.st_ctime_ns);actual_code_after[path]=row
  if row!=before:unchanged=False
 save('actual-code-origins-before.json',project_code_reads);save('actual-code-origins-after.json',actual_code_after)
 unchanged=unchanged and project_code_reads==actual_code_after
 remaining=[dict(name=t.name,ident=t.ident)for t in threading.enumerate()if t not in initial_threads and t.is_alive()]
 save('loaded-project-modules.json',loaded);save('actual-public-dependencies-before.json',public_reads);save('actual-public-dependencies-after.json',after)
 report=dict(status='REFUSED_OR_FATAL'if fatal else'PASS'if result is not None and result.wasSuccessful()and result.testsRun==5 and not result.skipped and unchanged and fd_before==fd_after and cleanup_ok and not refusals and not remaining and tools_restored else'FAIL_OR_ERROR',testsRun=0 if result is None else result.testsRun,failures=0 if result is None else len(result.failures),errors=0 if result is None else len(result.errors),skips=0 if result is None else len(result.skipped),fatal=fatal is not None,elapsedSeconds=time.monotonic()-started,selected=actual_ids,actualPublicDependencies=len(public_reads),allPublicDependenciesUnchanged=unchanged,loadedProjectModules=len(loaded),actualPrivateAndPublicCodeOrigins=len(project_code_reads),allActualCodeOriginsUnchanged=project_code_reads==actual_code_after,toolSlotsRestored=tools_restored,auditRefusals=refusals,temporaryRootsRetained=retained,restoredAliases=restored,metaPathRestored=sys.meta_path==initial_meta,sysPathRestored=sys.path==initial_path,tempfileAliasRestored=tempfile.TemporaryDirectory is real_td,remainingNewThreads=remaining,nodeExecutions=0,SDKExecutions=0,builds=0,deviceActions=0,hostOnly=True,actualFDDrainEstablished=fd_before==fd_after,noOriginalInputs=True,originalRegisteredCleanupEstablished=cleanup_ok,originalBuiltinIOUnchanged=builtins.open is boundary.original_builtin and io.open is boundary.original_io,nativeQualified=False,wholeQualified=False)
 save('report.json',report);print('EMOTE_GRAPHICS_PREFIX_PURE5_TERMINAL',json.dumps(report),flush=True)

# Preserve actual alias restoration, rather than assuming it from a report.
signal.signal(signal.SIGTERM,original_term)
boundary.restore()
with boundary.original_io(HERE/'write-port-restoration.json','w')as stream:
 stream.write(json.dumps(dict(restored=all(getattr(os,name)is original for name,original in original_write_ports.items())and io.open is original_c_io[0]and builtins.open is original_c_io[1],actualCportCount=len(original_write_ports),controlDescriptors=sorted(boundary.control_fds)),sort_keys=True)+'\n')
boundary.close()
sys.exit(0 if report['status']=='PASS'else 1)
