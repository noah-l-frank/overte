"""Genuine utility objects/frames only. No Feature/SDK/native constructor."""
from pathlib import Path
import http.server,os,socket,subprocess,sys,threading,unittest
from urllib.request import HTTPSHandler,ProxyHandler,build_opener
from utility_runtime import AfterActualBirth
import utility_runtime
from owned_write_boundary import WriteRefusal
from feature_journeys.server import make_server
from self_tests.test_account_provider import AccountProviderTests
from ios.self_tests import avatar_people_node


class AvatarPrefixBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.runtime=utility_runtime.ACTIVE;assert self.runtime is not None
        self.runtime.enter(self)
    def test_foreign_real_thread_write_refuses_without_original_frame(self):
        target=self.path/'foreign-write';errors=[]
        def attempt():
            try:target.write_bytes(b'foreign')
            except BaseException as error:errors.append(error)
        thread=threading.Thread(target=attempt,name='avatar-installed-original-actor');thread.start();thread.join(timeout=5)
        self.assertFalse(thread.is_alive());self.assertEqual(1,len(errors));self.assertIs(type(errors[0]),WriteRefusal)
        self.assertFalse(target.exists());self.assertFalse(any(row[0]is thread for row in self.runtime.ports.helper_records))
    def test_original_http_request_closes_socket_and_its_own_writer_helper(self):
        tls=self.runtime.tls();target=self.path/'actual-request-write';threads=[]
        class OwnedHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(handler):
                # A declared controller utility handler, not a product effect
                # or replacement of any product Handler method or owner.
                threads.append(threading.current_thread());target.write_bytes(b'actual-owned-http-thread')
                handler.send_response(200);handler.send_header('Content-Length','0');handler.end_headers()
            def log_message(handler,*args):pass
        server=make_server('reader-'+'a'*32,'actor-'+'b'*32,tls_context=tls.server_context)
        server.RequestHandlerClass=OwnedHandler
        serving=threading.Thread(target=server.serve_forever,name='boundary-real-fixture-server');serving.start()
        def stop():server.shutdown();serving.join(timeout=5);server.server_close();self.assertFalse(serving.is_alive())
        self.addCleanup(stop)
        opener=build_opener(ProxyHandler({}),HTTPSHandler(context=tls.client_context))
        with opener.open('https://localhost:'+str(server.server_port)+'/owned-counter',timeout=5)as response:self.assertEqual(200,response.status);response.read()
        self.assertEqual(b'actual-owned-http-thread',target.read_bytes());self.assertEqual(1,len(threads));thread=threads[0]
        thread.join(timeout=5);self.assertFalse(thread.is_alive())
        row=next(row for row in self.runtime.ports.helper_records if row[0]is thread)
        self.assertTrue(row[1].closed);self.assertIn((thread,row[1]),self.runtime.ports.retired)
        self.assertTrue(self.runtime.ports.connected_endpoints)
        self.assertTrue(all(record['beforeTLSOrHTTP']and record['reusePort']==0 for record in self.runtime.ports.connected_endpoints))
    def test_matching_original_node_argv_foreign_caller_refuses_before_birth(self):
        repo=Path(avatar_people_node.__file__).resolve().parents[4]
        argv=['node','-e',avatar_people_node.PROGRAM,str(repo/'scripts'),str(repo/'interface/resources/qml/hifi/Pal.qml')]
        with self.assertRaises(WriteRefusal)as refused:subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
        self.assertEqual('No selected original subprocess constructor',str(refused.exception))
        self.assertEqual([],self.runtime.ports.births);self.assertEqual([],self.runtime.ports.pipe_opens)
    def test_actual_tls_postbirth_precallerreturn_fault_stays_nongreen_then_rescues(self):
        monitor=self.runtime.monitor;monitor.inject=True
        try:
            with self.assertRaises(AfterActualBirth):self.runtime.tls()
        finally:monitor.inject=False
        self.assertTrue(monitor.fired);self.assertIsNotNone(monitor.owner)
        owner=monitor.owner;row=next(row for row in self.runtime.ports.births if row['process']is owner)
        self.assertEqual('openssl',row['kind']);self.assertIsNotNone(row['birth']);self.assertIs(type(owner.pid),int)
        record=self.runtime.drain_partial(owner)
        self.assertTrue(record['actualControllerRescue']);self.assertTrue(record['processAbsent']);self.assertTrue(record['originalStreamsClosed'])
        self.assertFalse(record['callerReturnEstablished']);self.assertFalse(record['originalTLSSetupEstablished'])
        self.assertEqual(1,len(self.runtime.ports.births));self.assertEqual([],self.runtime.ports.connected_endpoints)
