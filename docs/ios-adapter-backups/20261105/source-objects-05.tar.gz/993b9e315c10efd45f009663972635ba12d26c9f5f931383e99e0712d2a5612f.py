"""Whole Lifecycle observations and independent Actor witness publication.

Input owners contribute their actual original gesture/return packets only.
Every new sample acquires a new own-role Current7; historical replay never
queries an app, calls a live Source guard or turns a stored result current.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from types import SimpleNamespace
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need,number
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.phase_witness_publisher import PhaseWitnessPublisher
from adapters.script_feature.history import same,pack,unpack
from feature_journeys.contract import VERSION as CONTRACT_VERSION,identifier,result
from feature_journeys.phase_fixture import PhaseFixtureReader,validate as phase_original
from ios.adapters import lifecycle_current as current,lifecycle_actor_history as history,lifecycle_pending_commands as stale,lifecycle_images as images
from ios.adapters.lifecycle_current_archive import LifecycleCurrentArchive
from ios.adapters.lifecycle_current_stream import LifecycleCurrentStream
from ios.adapters.lifecycle_checkpoint_index import LifecycleCheckpointIndex


def original_inputs(actions):
    """Actual already owned originals; no input/SDK query is issued here."""
    from ios.adapters.lifecycle_actions import LifecycleActions
    need(type(actions)is LifecycleActions);actions.check();pending,attempt,held=actions.parts()
    contacts=current.contact_origins(attempt,held);returns=[]
    for event in pending.state['events']:
        if event['operation']=='attempt'and event['phase']=='returned':
            packet=pending.files().read(pending.files().expand(event['proof']))['packet']
            returns.append(dict(request=deepcopy(event['request']),packet=packet))
    need(len(returns)<=1);return dict(contacts=contacts,staleReturns=returns)


def input_facts(value,cut,binding,run):
    exact(value,{'contacts','staleReturns'});need(type(value['contacts'])is list and len(value['contacts'])<=2
        and type(value['staleReturns'])is list and len(value['staleReturns'])<=1)
    keys=[];holder=cut['originals']['pending']
    for row in value['staleReturns']:
        exact(row,{'request','packet'});need(row['request']['operation']=='attempt')
        packet=row['packet'];need(packet['processId']==int(binding['processIdentity'])and packet['runId']==run)
        reply=stale.response(packet,row['request']);native=reply['commit']['observation'];actual=holder['commit']['observation']
        need(reply['performed']and len(native['events'])==2 and native['events'][-1]['kind']=='rejected'
            and all(same(native[key],actual[key])for key in ('instance','eventId','processId','createdEpochMs','source'))
            and same(native['events'],actual['events'][:len(native['events'])])and native['sequence']<=actual['sequence'])
        keys.append((native['instance'],native['eventId'],native['events'][-1]['sequence']))
    return value['contacts'],keys


def retained_roots(cut,aliases):
    """Native QObject identities born to this journey, never requested panels."""
    inventory=cut['originals']['ui']['lifecycleFieldInventory'];owned={alias['identity'][key]for alias in aliases
        for key in ('fieldId','rootId','contextId')}
    return [deepcopy(row)for row in inventory['objects']if row['id']in owned and row['alive']]


class LifecycleObserver:
    def __init__(self,store,stream,current_history,actions,phase,*,policy,epoch_ms,monotonic):
        need(isinstance(store,PrivateFeatureState)and type(stream)is LifecycleCurrentStream
            and type(current_history)is history.LifecycleCurrentHistory and current_history.stream is stream
            and isinstance(phase,PhaseFixtureReader)and phase.area=='lifecycle-input'and phase.run==stream.run)
        self.store,self.stream,self.history,self.actions,self.phase=store,stream,current_history,actions,phase
        self.binding,self.run,self.role,self.root,self.lock=stream.binding,stream.run,stream.role,stream.root,stream.lock
        self.policy,self.epoch_ms,self.monotonic=deepcopy(policy),epoch_ms,monotonic;self.live=True
        need(store.path==stream.store.path.with_name('ios-lifecycle-observer-'+self.role+'-'+self.run+'.json')and phase.previous is not None)
        self.phase_instance=phase.previous['instance'];self.previous=store.read()
        self.state=dict(records=[],pending=None,storage={});self.restoring=True
        self.files=OriginalFrameStore(self.root,self.binding,self.run,self.role,self.bound,self.intent,
            namespace='lifecycle-observation',schema_prefix='iosLifecycleObservation',kind='sources')
        stored=None if self.previous is None else unpack(self.previous['payload'])
        if stored is not None:need(len(stored)==1);stored=stored[0];exact(stored,{'checkpointIndex','pending','storage'})
        self.index=LifecycleCheckpointIndex(self.files,self.save,None if stored is None else stored['checkpointIndex'])
        if stored is not None:
            self.state=dict(records=self.index.references(),pending=deepcopy(stored['pending']),storage=deepcopy(stored['storage']))
            for reference in self.state['records']:self.state['storage'][str(reference['index'])]=self.files.expand(reference)
        self.restoring=False
        if self.previous is not None:need(same(self.previous,self.envelope()))
        self.bound();self.recover_saved()
        for reference in self.state['records']:self.validate_original(reference)
        # Parser identity policy is prepared before the next fresh observation;
        # immutable decoded row memos are still born only inside publish_latest.
        from ios.adapters.lifecycle_publication_read_phase import ParserPolicy
        self._publication_parser_policy=ParserPolicy()if self.role=='actor'else None
        self._publisher=None;self.sparse_diagnostic=None

    def envelope(self):
        return dict(iosLifecycleObserverVersion=1,binding=self.binding,runId=self.run,role=self.role,
            artifactRoot=str(self.root),fixtureUrl=self.phase.fixture_url,phaseInstance=self.phase_instance,payload=pack([self.metadata()]))

    def metadata(self):
        pending=self.state['pending'];storage={}
        if pending is not None:
            row=self.state['storage'].get(str(pending['index']))
            if row is not None:storage[str(pending['index'])]=deepcopy(row)
        return dict(checkpointIndex=self.index.snapshot(),pending=deepcopy(pending),storage=storage)

    def bound(self):
        self.lock.assert_held();self.index.guard()
        if self.live:
            self.stream.bound();self.history.bound()
            need(self.phase.previous is not None and self.phase.previous['instance']==self.phase_instance)
        need(same(self.store.read(),self.previous))
        if not self.restoring:self.inventory()
        return True

    def inventory(self):
        expected=set()
        for key,row in self.state['storage'].items():
            self.files.original(row);need(str(row['index'])==key)
            if row['phase']!='planned':expected.add(self.files.path(row))
        actual=set(self.root.glob('lifecycle-observation-frame-sources-'+self.run+'-'+self.role+'-*.json'))
        need(actual==expected)

    @classmethod
    def archived(cls,store,stream_store,root,binding,run,role,lock,policy,fixture_url,phase_instance):
        from pathlib import Path
        scope=object.__new__(cls);scope.store,scope.lock,scope.root=store,lock,Path(root)
        scope.binding,scope.run,scope.role=deepcopy(binding),run,role;scope.policy=deepcopy(policy);scope.phase_instance=phase_instance
        scope.live=False;scope.restoring=True;scope.stream=SimpleNamespace(store=stream_store);scope.phase=SimpleNamespace(fixture_url=fixture_url)
        scope.previous=store.read();need(scope.previous is not None)
        rows=unpack(scope.previous['payload']);need(len(rows)==1);stored=rows[0];exact(stored,{'checkpointIndex','pending','storage'})
        scope.state=dict(records=[],pending=deepcopy(stored['pending']),storage=deepcopy(stored['storage']))
        scope.files=scope.literal_files();scope.index=LifecycleCheckpointIndex(scope.files,lambda:need(False),stored['checkpointIndex'])
        scope.state['records']=scope.index.references()
        for reference in scope.state['records']:scope.state['storage'][str(reference['index'])]=scope.files.expand(reference)
        scope.restoring=False;need(same(scope.previous,scope.envelope()));scope.bound();scope.index.inventory()
        exact(scope.state,{'records','pending','storage'});need(scope.state['pending']is None)
        for ordinal,reference in enumerate(scope.state['records'],1):
            need(reference['index']==ordinal and same(reference,scope.files.compact(scope.state['storage'][str(ordinal)])))
            scope.validate_original(reference)
        return scope

    def save(self):
        self.bound();need(self.index.count()==len(self.state['records']));self.index.inventory()
        value=self.envelope();self.store.write(value,self.previous);self.previous=deepcopy(value)

    def intent(self,kind,value):
        self.lock.assert_held();need(same(self.store.read(),self.previous)and self.state['pending']is not None)
        if kind=='manifest':
            need(self.state['storage'][str(self.state['pending']['index'])]['phase']=='saved');self.index.intent(value);return
        need(kind=='original');self.files.original(value)
        need(value['index']==self.state['pending']['index']);key=str(value['index']);old=self.state['storage'].get(key)
        if old is None:need(value['phase']=='planned')
        else:need(all(same(old[k],value[k])for k in old if k not in ('phase','file'))and (old['phase'],value['phase'])in (('planned','opened'),('opened','saved')))
        self.state['storage'][key]=deepcopy(value);self.save()

    def literal_files(self):
        # A witness callback reads only private PFS/original bytes. It must not
        # invoke bound(), history.bound(), a Source guard or an SDK factory.
        def guard():self.lock.assert_held();return True
        return OriginalFrameStore(self.root,self.binding,self.run,self.role,guard,lambda *_:need(False),
            namespace='lifecycle-observation',schema_prefix='iosLifecycleObservation',kind='sources')

    def original(self,reference):
        self.lock.assert_held();need(reference in self.state['records']or self.state['pending']is not None
            and reference['index']==self.state['pending']['index'])
        files=self.literal_files();return files.read(files.expand(reference))

    def validate_original(self,reference):
        value=self.original(reference)
        exact(value,{'iosLifecycleObservationOriginalVersion','binding','runId','role','sequence','ticket','stream','source',
            'history','inputs','phaseBefore','phaseAfter','image','policy','acquisition'})
        need(type(value['iosLifecycleObservationOriginalVersion'])is int and value['iosLifecycleObservationOriginalVersion']==1
            and value['binding']==self.binding and value['runId']==self.run and value['role']==self.role
            and value['sequence']==reference['index']and same(value['policy'],self.policy));identifier(value['ticket'])
        clock=PhaseWitnessPublisher.acquisition(value['acquisition'])
        before,after=value['phaseBefore'],value['phaseAfter']
        phase_original(before,run=self.run,area='lifecycle-input',request=before['requestId'],epoch=before['capturedEpochMs'])
        phase_original(after,run=self.run,area='lifecycle-input',request=after['requestId'],epoch=after['capturedEpochMs'],previous=before)
        need(before['active']and after['active']and before['instance']==after['instance']==self.phase_instance
            and same(before['activations'],after['activations'])and before['activations'][-1]['ticket']==value['ticket']
            and clock['hostBeforeEpochMs']<=before['capturedEpochMs']<=after['capturedEpochMs']<=clock['hostAfterEpochMs']+250)
        stream=self.stream.held_archive(value['stream'])if self.live else None
        if stream is None:stream=LifecycleCurrentArchive(self.stream.store,value['stream'],self.root,self.binding,self.run,self.role,self.lock)
        exact(value['history'],{'records','aliases'});aliases,values=history.derive(stream,value['history']['records'])
        need(same(aliases,value['history']['aliases'])and values and same(value['source'],value['history']['records'][-1]))
        retained=stream.record(value['source']);cut=retained['current'];joined=cut['clockJoin']
        need(retained['ticket']==value['ticket']and before['activations'][-1]['activatedEpochMs']<=joined['hostBeforeEpochMs']
            and clock['hostBeforeEpochMs']<=joined['hostBeforeEpochMs']<=joined['hostAfterEpochMs']<=clock['hostAfterEpochMs']
            and clock['hostBeforeMonotonic']<=joined['hostBeforeMonotonic']<=joined['hostAfterMonotonic']<=clock['hostAfterMonotonic'])
        contacts,attempts=input_facts(value['inputs'],cut,self.binding,self.run)
        # The existing projection validates every contact against the genuine
        # native touch journal. Its alias table comes from this role's cuts.
        local=SimpleNamespace(binding=self.binding,run=self.run,state=dict(aliases=aliases),replay=lambda:None)
        state=current.projection(cut,local,values[0],contacts,attempts)
        artifacts=[]
        if value['image']is not None:
            need(self.role=='primary');image=value['image'];need(image['ticket']==value['ticket'])
            raw,name=images.archive(image,self.root,self.policy,self.lock);image_clock=image['frame']['clockJoin']
            need(joined['hostAfterEpochMs']<=image_clock['hostBeforeEpochMs']<=image_clock['hostAfterEpochMs']<=clock['hostAfterEpochMs']
                and clock['hostBeforeMonotonic']<=image_clock['hostBeforeMonotonic']<=image_clock['hostAfterMonotonic']<=clock['hostAfterMonotonic'])
            need(image['phase']=='observed')
            artifacts=[dict(kind='image',name=name,sequence=value['sequence'],capturedEpochMs=image_clock['hostBeforeEpochMs'],ticket=value['ticket'],source='world-render-target')]
        resources=[];roots=retained_roots(cut,aliases)
        if roots:resources.append('panel:lifecycle-qt-roots')
        if cut['originals']['pending']['resources']['pendingRuns']:resources.append('input:lifecycle-pending')
        if cut['originals']['world']['source']['touch']['active']:resources.append('input:lifecycle-forward')
        public=result('feature.lifecycle-input.observe',dict(schemaVersion=1,contractVersion=CONTRACT_VERSION,runId=self.run,
            sequence=value['sequence'],capturedEpochMs=clock['hostBeforeEpochMs'],state=state,artifacts=artifacts,resources=resources,
            lifecycle=deepcopy(joined['nativeAfter']['lifecycle'])))
        return dict(ticket=value['ticket'],public=public,acquisition=deepcopy(clock))

    def recover_saved(self):
        self.bound();exact(self.state,{'records','pending','storage'});need(type(self.state['records'])is list and len(self.state['records'])<=512)
        for index,reference in enumerate(self.state['records'],1):
            need(reference['index']==index and str(index)in self.state['storage']and same(reference,self.files.compact(self.state['storage'][str(index)])))
        pending=self.state['pending']
        if pending is not None:
            need(pending['index']==len(self.state['records'])+1);saved=self.state['storage'].get(str(pending['index']))
            if saved is None or saved['phase']!='saved':return
            reference=self.files.compact(saved);self.validate_original(reference)
            self.index.recover_saved_append(reference);self.state['records'].append(reference);self.state['pending']=None;self.save()

    def observe(self,*,image=None,for_publication=False):
        self.bound();self.recover_saved();need(self.state['pending']is None and len(self.state['records'])<512)
        need(type(for_publication)is bool and (not for_publication or self.role=='actor'))
        if for_publication:
            # Constructor replay and the first empty Publisher WAL are old work,
            # before the real acquisition clocks and the new Current7 query.
            publisher=self.prepare_publication()
            # Resolve a prior issued receipt before any new acquisition. This
            # is the original read-only reconciliation, never a repeated POST.
            publisher.resolve();need(publisher.state['pending']is None)
        started=dict(hostBeforeEpochMs=self.epoch_ms(),hostBeforeMonotonic=self.monotonic())
        before=self.phase.read();ticket=before['ticket']
        self.state['pending']=dict(index=len(self.state['records'])+1,ticket=ticket);self.save()
        # Once this call is issued an unknown result leaves both source and
        # observer planned. No repeated acquisition is allowed to fill its slot.
        self.stream.current(ticket);reference=deepcopy(self.stream.state['records'][-1]);self.history.recover_saved()
        image_value=None if image is None else image()
        inputs=original_inputs(self.actions);after=self.phase.read(before['status']);need(after['ticket']==ticket)
        acquisition=dict(started,hostAfterEpochMs=self.epoch_ms(),hostAfterMonotonic=self.monotonic())
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.begin(self)
        value=dict(iosLifecycleObservationOriginalVersion=1,binding=self.binding,runId=self.run,role=self.role,
            sequence=len(self.state['records'])+1,ticket=ticket,stream=deepcopy(self.stream.previous),source=reference,
            history=deepcopy(self.history.state),inputs=inputs,phaseBefore=before['status'],phaseAfter=after['status'],
            image=image_value,policy=self.policy,acquisition=acquisition)
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.event(self,'observation-write-enter')
        saved=self.files.write(value['sequence'],value)
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.event(self,'observation-write-return')
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.event(self,'first-validation-enter')
        derived=self.validate_original(saved)
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.event(self,'first-validation-return')
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.event(self,'observation-index-enter')
        self.index.append(saved)
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.event(self,'observation-index-return')
        self.state['records'].append(saved);self.state['pending']=None
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.event(self,'observation-save-enter')
        self.save()
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.event(self,'observation-save-return')
        return deepcopy(derived['public'])

    def prepare_publication(self):
        self.bound();need(self.role=='actor')
        if self._publisher is None:
            self._publisher=PhaseWitnessPublisher(PrivateFeatureState(self.store.path.with_name('phase-publication-lifecycle-input-'+self.run+'-actor.json')),
                self.binding,self.phase,self.lock,self.bound,self.validate_original,epoch_ms=self.epoch_ms,monotonic=self.monotonic)
        publisher=self._publisher
        need(type(publisher)is PhaseWitnessPublisher and publisher.phase is self.phase and publisher.lock is self.lock
            and publisher.store.path==self.store.path.with_name('phase-publication-lifecycle-input-'+self.run+'-actor.json')
            and publisher.binding==self.binding and publisher.run==self.run
            and getattr(publisher.guard,'__self__',None)is self and publisher.guard.__func__ is type(self).bound
            and getattr(publisher.validate_original,'__self__',None)is self
            and publisher.validate_original.__func__ is type(self).validate_original
            and publisher.epoch_ms is self.epoch_ms and publisher.monotonic is self.monotonic)
        publisher.bound()
        if self.sparse_diagnostic is not None:self.sparse_diagnostic.event(self,'publisher-prepare-return')
        return publisher

    def publish_latest(self):
        self.bound();need(self.role=='actor'and self.state['pending']is None and self.state['records'])
        from ios.adapters.lifecycle_publication_read_phase import publication_scope
        if self.sparse_diagnostic is None:
            with publication_scope(self):
                return self.prepare_publication().publish(deepcopy(self.state['records'][-1]))
        self.sparse_diagnostic.event(self,'publish-latest-enter')
        try:
            with publication_scope(self):
                return self.prepare_publication().publish(deepcopy(self.state['records'][-1]))
        finally:self.sparse_diagnostic.finish(self)
