"""Independent Actor admission around actual Main replacement WAL boundaries.

These are negative/order counters. They do not mint any positive End proof or
claim the still-missing composed actual End/readmission/Audio integration.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import unittest
from copy import deepcopy
from adapters.normal_ui import NativeUIError
from ios.adapters.audio_whole_feature import AudioWholePending
from ios.self_tests.audio_whole_fixture import AudioWholeFixture

class AudioWholeActorReplacementTests(unittest.TestCase):
    def setUp(self):
        self.f=AudioWholeFixture(self);self.f.primary.prepare();self.f.actor.prepare()

    def test_actual_replacing_wal_waits_before_new_source_even_when_replacement_header_exists(self):
        f=self.f
        with f.primary.held():
            # This deliberately incomplete saved header cannot authorize any
            # replacement. A real process End may already have closed Source.
            f.primary.state['phase']='replacing'
            f.primary.state['replacement']=dict(newBinding=deepcopy(f.primary.state['bindings']['primary']))
            f.primary.save()
        before=f.source_calls
        with self.assertRaises(AudioWholePending):f.actor.observe(dict(contractVersion=16,runId=f.actor.run,afterSequence=0))
        self.assertEqual(before,f.source_calls)
        with f.actor.held():self.assertIsNone(f.actor.state['replacement']);self.assertIsNone(f.actor.state['oldEnd'])

    def test_cleaned_header_without_actual_end_readmission_and_restoration_cannot_adopt_actor_stage(self):
        f=self.f
        with f.primary.held():
            f.primary.state['phase']='cleaned'
            f.primary.state['replacement']=dict(newBinding=deepcopy(f.primary.state['bindings']['primary']))
            f.primary.save()
        before=f.source_calls
        with self.assertRaises(NativeUIError):f.actor.observe(dict(contractVersion=16,runId=f.actor.run,afterSequence=0))
        self.assertEqual(before,f.source_calls)
        with f.actor.held():self.assertIsNone(f.actor.state['replacement']);self.assertIsNone(f.actor.state['oldEnd'])

    def test_ordinary_initial_actor_keeps_its_original_stage_and_independent_fresh_source(self):
        f=self.f;before=f.source_calls
        with f.actor.held():
            initial=deepcopy(f.actor.state['bindings']);f.actor.sync_replacement()
            self.assertIsNone(f.actor.state['replacement']);self.assertIsNone(f.actor.state['oldEnd'])
            current=f.actor.current();reference,value=current.capture()
            self.assertEqual(initial['primary'],current.binding)
            self.assertEqual(reference,current.state['records'][-1]);self.assertEqual(initial,f.actor.state['bindings'])
        self.assertGreater(f.source_calls,before)

    def test_unknown_or_corrupt_primary_header_refuses_without_any_source_and_preparing_waits(self):
        f=self.f;store=f.primary.store;base=store.read();self.assertIsNotNone(base)
        mutations=(
            lambda v:v.update(iosAudio11WholeVersion=True),lambda v:v.update(iosAudio11WholeVersion=2),
            lambda v:v.update(runId='f'*32),lambda v:v.update(role='actor'),
            lambda v:v.update(primaryTarget='foreign'),lambda v:v.update(fixtureUrl='https://foreign.invalid/feature-fixture/v1'),
            lambda v:v['settings'].update(actorTarget='foreign'),lambda v:v.update(unknown=True),
            lambda v:v['state'].update(phase='unknown'),lambda v:v['state'].update(phase=None),
            lambda v:v['state'].pop('oldEnd'),lambda v:v['state'].update(preparationDone=False),
            lambda v:v['state']['bindings']['primary'].update(sessionId='foreign'),
            lambda v:v['state']['bindings']['actor'].update(processIdentity='43'),
        )
        for mutate in mutations:
            with self.subTest(mutation=mutations.index(mutate)):
                value=deepcopy(base);mutate(value);store.write(value,base);before=f.source_calls
                try:
                    with f.actor.held():
                        with self.assertRaises(NativeUIError):f.actor.sync_replacement()
                        self.assertIsNone(f.actor.state['replacement']);self.assertIsNone(f.actor.state['oldEnd'])
                    self.assertEqual(before,f.source_calls)
                finally:store.write(base,value)
        value=deepcopy(base);value['state']['phase']='preparing';value['state']['preparationDone']=False
        store.write(value,base);before=f.source_calls
        try:
            with f.actor.held():
                with self.assertRaises(AudioWholePending):f.actor.sync_replacement()
            self.assertEqual(before,f.source_calls)
        finally:store.write(base,value)
