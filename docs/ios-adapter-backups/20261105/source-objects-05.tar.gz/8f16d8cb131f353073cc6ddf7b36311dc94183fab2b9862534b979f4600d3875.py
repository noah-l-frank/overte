from pathlib import Path
import ast,hashlib,difflib,json
r=Path.cwd();t=r/'.ios-host-tmp';p=t/'lifecycle-original-owner-python-packaging-proposal-20261028';p.chmod(0o700)
def sha(x):return hashlib.sha256(x).hexdigest()
def replace(s,a,z):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
rows=[];diff=''
rel='tests/device/ios/remotexpc_tunnel.py';origin=t/'lifecycle-original-owner-route-draft-20261028/candidates/repo'/rel;raw=origin.read_bytes();s=raw.decode()
s=replace(s,'def require_immutable_tree(root: Path, owner_uid: int = 0) -> None:',(p/'assembly.py.fragment').read_text()+'def require_immutable_tree(root: Path, owner_uid: int = 0) -> None:')
s=replace(s,'def serve(arguments: argparse.Namespace) -> int:\n','def serve(arguments: argparse.Namespace) -> int:\n    creator_mode = getattr(arguments, "creator_mode", "kernel")\n')
s=s.replace('arguments.creator_mode','creator_mode')
s=replace(s,'        environment["OVERTE_IOS_ADAPTER_SOURCE_ROOT"]=str(arguments.service_runtime/"original-owner-adapters")\n','')
s=replace(s,'    preflight_parser = subparsers.add_parser("preflight")','''    assembly_parser = subparsers.add_parser("assemble-original-owner-python")
    assembly_parser.add_argument("--source-site-packages", type=Path, required=True)
    assembly_parser.add_argument("--destination", type=Path, required=True)
    preflight_parser = subparsers.add_parser("preflight")''')
s=replace(s,'        if arguments.action == "preflight":','        if arguments.action == "assemble-original-owner-python":\n            return assemble_original_owner_python(arguments)\n        if arguments.action == "preflight":')
ast.parse(s);rows.append(('repo',rel,origin,raw,s))
rel='scripts/lib/userspace-keeper.mjs';origin=Path(json.loads((t/'lifecycle-original-owner-signaled-close-overlay-20261028/manifest.json').read_text())['candidate']);raw=origin.read_bytes();s=raw.decode();s=replace(s,"  const sourceRoot=process.env.OVERTE_IOS_ADAPTER_SOURCE_ROOT;\n",'');s=replace(s,'[helper,packages,sourceRoot,home]','[helper,packages,home]');s=replace(s,"PYTHONPATH:[packages,path.join(sourceRoot,'tests/device')].join(path.delimiter)",'PYTHONPATH:packages');rows.append(('node-sdk',rel,origin,raw,s))
# Actual reviewed SDK source bytes are resource inputs, not overwritten globals.
cor=json.loads((t/'lifecycle-authenticated-creator-corrections-20261028/manifest.json').read_text());orig=json.loads((t/'lifecycle-authenticated-creator-draft-20261028/manifest.json').read_text());spec=[]
for row in cor['entries']:
 f=Path(row['candidate']);payload='source-patches/original-owner-python/'+Path(row['path']).name;rel='tests/device/ios/'+payload
 spec.append({'path':row['path'],'originalSha256':next(x['baseSHA256'] for x in orig['entries'] if x['path']==row['path']),'payload':payload,'payloadSha256':row['candidateSHA256']})
 rows.append(('repo',rel,None,b'',f.read_text()))
manifest=json.dumps({'sourceProfileVersion':1,'upstreamVersion':'11.1.5','sources':spec},indent=2)+'\n';rows.append(('repo','tests/device/ios/original-owner-python-sources.json',None,b'',manifest))
entries=[]
for kind,rel,origin,raw,s in rows:
 out=p/'candidate'/kind/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s)
 if raw:
  before=p/'base'/kind/rel;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(raw)
 entries.append({'kind':kind,'path':rel,'base':None if origin is None else str(origin),'baseSHA256':sha(raw),'candidate':str(out),'candidateSHA256':sha(s.encode())})
 diff+=''.join(difflib.unified_diff(raw.decode().splitlines(True),s.splitlines(True),fromfile='a/'+kind+'/'+rel,tofile='b/'+kind+'/'+rel))
(p/'proposal.diff').write_text(diff);(p/'manifest.json').write_text(json.dumps({'status':'PRIVATE ACTIVE SOURCE ASSEMBLY UNRUN','entries':entries,'diffSHA256':sha(diff.encode())},indent=2)+'\n');print(json.dumps({'paths':len(entries),'candidateWrapperSHA256':entries[0]['candidateSHA256'],'candidateNodeHelperSHA256':entries[1]['candidateSHA256']},indent=2))
