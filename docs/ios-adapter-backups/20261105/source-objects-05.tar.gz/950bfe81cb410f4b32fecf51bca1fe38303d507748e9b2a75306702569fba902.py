"""Actual parent Current7 WAL/reconstruction/uncertain return counterparts.

The inherited model keeps the original Source/loop/SDK DI/HTTP/AFC actors.
Parent API instances/locks are newly created per call. No old loop or task is
passed into their new work, no saved native cut is retimed or reissued.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio
from copy import deepcopy
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.appium_adapter import WebDriver
from ios.adapters.script_runtime import IOSScriptRuntime
from ios.adapters.lifecycle_current_stream import LifecycleCurrentStream
from ios.adapters import lifecycle_current_transport as transport
from test_original_lifecycle_current_stream_models import OriginalLifecycleCurrentStreamModels


class OriginalLifecycleCurrentParentModels(OriginalLifecycleCurrentStreamModels):
    async def parent(self,operation='capture',*,role='primary',original_owner=None):
        def api():
            runtime=IOSScriptRuntime(self.runtime.adapter);source=runtime._sources('test-only')
            lock=ScriptSourceLock(runtime.state_path('test-only').with_name('script-feature-sources.lock'))
            with lock.held():
                store=PrivateFeatureState(lock.path.with_name('ios-lifecycle-current-stream-'+role+'-'+self.run+'.json'))
                stream=LifecycleCurrentStream(store,self.current_root,source,self.run,role,lock,original_owner=original_owner)
                self.last_stream=stream
                if operation=='capture':return stream.capture('b'*32)
                if operation=='read':return stream.record(stream.state['records'][-1])
                if operation=='code-fault':
                    function=transport.capture;code=function.__code__
                    function.__code__=code.replace(co_consts=(*code.co_consts,'declared changed parent receiver'))
                    try:
                        with self.assertRaises(NativeUIError):stream.capture('b'*32)
                    finally:function.__code__=code
                    return deepcopy(stream.state)
                raise AssertionError('Unknown declared parent model operation')
        return await asyncio.to_thread(api)

    async def test_distinct_parent_api_reconstructs_exact_original_body_and_new_capture_always_issues_seven_new_queries(self):
        first=await self.parent();raw=deepcopy(first);queries=len(self.current_queries)
        again=await self.parent('read');self.assertEqual(raw,again);self.assertEqual(queries,len(self.current_queries))
        second=await self.parent();self.assertEqual(7,len(self.current_queries)-queries)
        self.assertNotEqual(first['original']['reference'],second['original']['reference']);self.assertEqual(raw,first)
        actor=await self.parent(role='actor',original_owner=self.last_stream.state['owner'])
        self.assertEqual(first['original']['ownerInstance'],actor['original']['ownerInstance']);self.assertEqual('actor',actor['original']['role'])
        self.assertEqual([],self.f.states());self.assertIsNone(self.last_stream.state['pending'])

    async def test_lost_actual_acquisition_return_keeps_parent_pending_and_never_requeries_original_source(self):
        original=WebDriver.execute;lost=[]
        def drop(client,session,operation,values):
            value=original(client,session,operation,values)
            if operation=='mobile: overteOriginalKeeperOperation'and values.get('operation')=='touch-current-observe'and not lost:
                lost.append(True);raise OSError('Declared loss AFTER original Current7 frame saved and result returned')
            return value
        with patch.object(WebDriver,'execute',new=drop):
            with self.assertRaisesRegex(OSError,'Declared loss AFTER original Current7'):await self.parent()
        self.assertEqual([True],lost);self.assertEqual(1,len(self.ops._lifecycle_current['primary'].frames))
        self.assertEqual([],self.last_stream.state['records']);self.assertEqual('planned',self.last_stream.state['pending']['phase']);queries=len(self.current_queries)
        with self.assertRaises(NativeUIError):await self.parent()
        self.assertEqual(queries,len(self.current_queries));self.assertEqual([],self.last_stream.state['records']);self.assertEqual([],self.f.states())

    async def test_actual_parent_samebyte_foreign_inode_cannot_reconstruct_and_never_triggers_new_child_query(self):
        first=await self.parent();stream=self.last_stream;reference=stream.state['records'][0];path=stream.files.path(stream.files.expand(reference));raw=path.read_bytes();backup=path.with_name('owned-counter-original-inode')
        path.rename(backup);path.write_bytes(raw);path.chmod(0o600);self.assertNotEqual(reference['inode'],path.stat().st_ino);queries=len(self.current_queries)
        try:
            with self.assertRaises(NativeUIError):await self.parent('read')
            self.assertEqual(queries,len(self.current_queries));self.assertEqual(raw,path.read_bytes())
        finally:path.unlink();backup.rename(path)
        restored=await self.parent('read');self.assertEqual(first,restored);self.assertEqual(queries,len(self.current_queries))

    async def test_same_parent_transport_function_code_change_refuses_before_wal_or_query_and_original_reader_remains(self):
        original=await self.parent();queries=len(self.current_queries);saved=self.last_stream.store.path.read_bytes()
        state=await self.parent('code-fault');self.assertIsNone(state['pending']);self.assertEqual(queries,len(self.current_queries));self.assertEqual(saved,self.last_stream.store.path.read_bytes())
        self.assertEqual(original,await self.parent('read'));self.assertEqual(queries,len(self.current_queries))
