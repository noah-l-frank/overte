"""UNRUN real normal14/owner/media/restore composition; lower I/O is modeled.

The unchanged existing fourteen-action body is executed once per case. A
prior normal/Actor/clock refusal remains a failing prerequisite, never an
expected failure. No shared-End, native, acoustic or Whole qualification.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import unittest
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.audio_original_evidence_handoff import IOSAudioOriginalEvidenceHandoff
from ios.adapters.audio_whole_restore import AudioWholeRestore
from ios.self_tests.audio_whole_fixture import AudioWholeFixture
from ios.self_tests.test_ios_audio_whole import AudioWholeTests


class AudioOriginalEvidenceHandoffTests(unittest.TestCase):
    def setUp(self):self.f=AudioWholeFixture(self)
    def prepare(self):self.f.primary.prepare();self.f.actor.prepare()
    def normal(self):
        # The original test body is not extracted/recompiled or abbreviated.
        AudioWholeTests.test_normal14_actual_whole_runtime_actor_publication_and_original_evidence(self)
        self.assertEqual(14,len(self.f.primary.state['actions']))
    def handoff(self):return IOSAudioOriginalEvidenceHandoff(self.f.primary)

    def test_normal14_independent_wav_pcm_restore_and_live_sdk_duties_remain_distinct(self):
        self.normal();f=self.f;value=f.primary.original_evidence_handoff()
        self.assertEqual(14,value['normalActionCount']);self.assertEqual(2,len(value['restorationOriginals']))
        self.assertEqual(1,len(value['positiveWindows']));self.assertTrue(value['settingsRestorationEstablished'])
        self.assertTrue(value['ordinaryPCMCloseEstablished']);self.assertTrue(value['retainedProcessDutyOriginals'])
        self.assertTrue(value['originalProcessEndRequired'])
        for key in ('resourceRetirementEstablished','physicalADCQualified','physicalOutputQualified','acousticQualified','peerQualified','nativeQualified','wholeQualified'):
            self.assertIs(value[key],False)
        self.assertEqual({'primary','actor'},set(value['bindings']))
        self.assertNotEqual(value['bindings']['primary']['sessionId'],value['bindings']['actor']['sessionId'])

    def test_lost_final_restoration_cas_return_recovers_exact_originals_without_new_source(self):
        self.normal();f=self.f;write=PrivateFeatureState.write;lost=[]
        def uncertain(store,value,previous):
            result=write(store,value,previous)
            if store.path==f.primary.store.path and len(value.get('state',{}).get('restoration',{}).get('verified',[]))==2 and not lost:
                lost.append(deepcopy(value));raise NativeUIError('Declared lost return AFTER actual final restoration CAS')
            return result
        with patch.object(PrivateFeatureState,'write',uncertain),self.assertRaises(NativeUIError):self.handoff().finish()
        self.assertEqual(1,len(lost));calls=f.source_calls;commands=deepcopy(f.once.boundary.commands);once=deepcopy(f.once.boundary.once.commands)
        f.primary=f.flow('primary');value=self.handoff().finish()
        self.assertEqual(calls,f.source_calls);self.assertEqual(commands,f.once.boundary.commands);self.assertEqual(once,f.once.boundary.once.commands)
        self.assertEqual(lost[0]['state']['restoration']['verified'],[row['reference'] for row in value['restorationOriginals']])

    def test_reopened_historical_handoff_runs_with_both_fresh_source_factories_forbidden(self):
        self.normal();first=self.handoff().finish();f=self.f;f.primary=f.flow('primary')
        with patch.object(f.once.runtime,'_sources',side_effect=AssertionError('No Actor source allowed during original replay')),patch.object(f.once.p.runtime,'_sources',side_effect=AssertionError('No Primary source allowed during original replay')):
            second=self.handoff().original()
        self.assertEqual(first,second)

    def test_incomplete_normal_prefix_refuses_before_fresh_restore_or_actor_command(self):
        self.prepare();f=self.f;calls=f.source_calls;commands=deepcopy(f.once.boundary.commands)
        with self.assertRaises((NativeUIError,ValueError)):self.handoff().finish()
        self.assertEqual(calls,f.source_calls);self.assertEqual(commands,f.once.boundary.commands)
        with f.primary.held():self.assertEqual([],f.primary.state['restoration']['verified'])

    def test_same_byte_foreign_artifact_inode_cannot_join_original_source(self):
        self.normal();self.handoff().finish();f=self.f
        with f.primary.held():row=deepcopy(next(row for row in f.primary.state['artifacts'] if row['kind']=='audio'))
        path=f.primary.public_root/row['name'];raw=path.read_bytes();prior=path.stat().st_ino
        # New, task-owned counter files only; no historical input is modified.
        path.rename(path.with_suffix('.owned-before-replacement'));path.write_bytes(raw);path.chmod(0o600)
        self.assertNotEqual(prior,path.stat().st_ino);calls=f.source_calls
        with self.assertRaises((NativeUIError,ValueError,OSError)):self.handoff().original()
        self.assertEqual(calls,f.source_calls)

    def test_actual_completed_page_input_lost_return_resolves_without_second_open_audio(self):
        self.normal();f=self.f;f.m.muted=True;returned=AudioWholeRestore.page_returned;lost=[]
        def uncertain(restore,label):
            result=returned(restore,label)
            if label in ('open-audio','open-audio-settings') and not lost:
                lost.append(label);raise NativeUIError('Declared lost return AFTER actual open-Audio input and its original WAL')
            return result
        with patch.object(AudioWholeRestore,'page_returned',uncertain),self.assertRaises(NativeUIError):self.handoff().finish()
        self.assertEqual(1,len(lost));f.primary=f.flow('primary')
        with f.primary.held():
            pending=deepcopy(f.primary.state['restoration']['pending']);self.assertEqual('open',pending['verb'])
            self.assertEqual(1,sum(row.get('label')==lost[0] for row in pending['inputs']))
        value=self.handoff().finish();self.assertTrue(value['settingsRestorationEstablished'])
        with f.primary.held():
            rows=[i for op in f.primary.state['restoration']['operations'] for i in op['inputs']]
            self.assertEqual(1,sum(row.get('label')==lost[0] for row in rows));self.assertIsNone(f.primary.state['restoration']['pending'])
