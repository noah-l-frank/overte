from pathlib import Path
from types import SimpleNamespace
import json,sys,signal,time,traceback
REPO=Path.cwd();HERE=Path(__file__).resolve().parent
controller=REPO/'.ios-host-tmp/chat-current-pass-source7-guard3-root-preparation-20261103'
sys.path.insert(0,str(controller));import run_metadata as meta
plan=meta.validate_frozen();meta.publication();before=meta.sources(plan);own=meta.pin(Path(__file__).resolve())
corpus=controller/'runs/paired1/first-21c7jwd_/temporary';originals=meta.originals(corpus)
assert originals==json.loads((controller/'paired1-originals-second.json').read_text())
meta.save(HERE/'source-before.json',before)
def audit(event,args):
    if event=='import':assert not any(part in ('pymobiledevice3','tidevice','pyidevice','zeroconf') for part in args[0].split('.'))
    elif event=='subprocess.Popen':assert list(args[1])==['rg','--files','-0',*plan['broadSourceRoots']] and Path(args[2]).resolve()==REPO
    elif event in ('socket.connect','socket.bind'):raise AssertionError('Historical diagnostic cannot use a service')
    elif event=='open' and isinstance(args[0],(str,bytes)):
        p=Path(args[0]).absolute();flags=args[2]
        if p.is_relative_to(corpus) and isinstance(flags,int):
            assert not flags & (512|1024),'No original truncate/append'
            if flags & 64:assert p.exists() and p.name=='script-feature-sources.lock' and p.stat().st_size==0,'Only open an existing original lock inode'
sys.addaudithook(audit)
sys.path[:0]=[str(REPO/'tests/device'),str(REPO/'tests/device/self_tests'),str(REPO/'tests/device/ios/self_tests')]
from ios.adapters import chat_draft_runtime,chat_archive_round as a
from ios.adapters import chat_peer_receipts,chat_send_receive
from ios.adapters.chat_receive_sources import IOSChatReceiveSources
from ios.adapters.chat_draft_owner import IOSChatDraftOwner
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.script_runtime import IOSScriptRuntime
from feature_journeys.phase_fixture import Client
pair=corpus/'tmp_uaweyud';paths={role:pair/role/'ios-chat-draft-owner.json' for role in ('primary','peer')}
headers={role:json.loads(p.read_text()) for role,p in paths.items()}
saved=json.loads((pair/'peer/ios-chat-receive-sources.json').read_text())
locks={role:ScriptSourceLock(pair/role/'script-feature-sources.lock') for role in paths}
artifact=corpus/'tmpglnal2sp/candidate.ipa'
if not artifact.exists():
    possible=list((corpus/'tmpglnal2sp').rglob('*.ipa'));assert len(possible)==1;artifact=possible[0]
artifacts={role:(artifact,headers[role]['binding']['artifactSha256']) for role in paths}
runtime=object.__new__(chat_draft_runtime.IOSChatDraftRuntime);runtime.adapter=SimpleNamespace(state_path=lambda selector:paths[selector].with_name('session.json'))
client=object.__new__(Client);client.url=headers['primary']['fixtureUrl'].split('/runs/')[0]
rows={};stack={};refusals=[];status=None
watch=REPO/'tests/device'
def profile(frame,event,arg):
    code=frame.f_code
    if not code.co_filename.startswith(str(watch)):return
    key=(str(Path(code.co_filename).relative_to(REPO)),code.co_firstlineno,code.co_name)
    if event=='call':stack[id(frame)]=(key,time.monotonic())
    elif event=='return':
        entry=stack.pop(id(frame),None)
        if entry:
            row=rows.setdefault(key,[0,0.]);row[0]+=1;row[1]+=time.monotonic()-entry[1]
        if code.co_filename==str(REPO/'tests/device/ios/adapters/chat_archive_round.py'):
            if code.co_name=='eligible' and arg is False:refusals.append(dict(kind='ineligible',type=type(frame.f_locals.get('owner')).__name__))
            elif code.co_name=='disable':refusals.append(dict(kind='disabled',caller=frame.f_back.f_code.co_name,line=frame.f_back.f_lineno))
def alarm(*_args):raise TimeoutError('Pure frozen historical diagnostic fixed60-second cap')
started=time.monotonic();signal.signal(signal.SIGALRM,alarm)
try:
    with locks['primary'].held(),locks['peer'].held():
        sys.setprofile(profile);signal.setitimer(signal.ITIMER_REAL,60)
        receive=IOSChatReceiveSources.archive(PrivateFeatureState(pair/'peer/ios-chat-receive-sources.json'),saved['primaryBinding'],saved['binding'],saved['runId'],saved['peerBindingRecord']['primaryArtifactRoot']['path'],saved['artifactRoot'],saved['peerBindingRecord'],locks['primary'],locks['peer'])
        contexts=runtime._chat_receipt_contexts('primary','peer',saved['runId'],client,receive,qml_artifacts=artifacts)
        for role in ('peer','primary'):
            h=headers[role]
            IOSChatDraftOwner.archive(PrivateFeatureState(paths[role]),h['artifactRoot'],h['binding'],h['runId'],locks[role],h['fixtureUrl'],source_bound=True,peer_actor=role=='peer',peer_receipts=contexts[role],qml_bound=True,qml_artifact=artifacts[role])
        status='HISTORICAL_DIAGNOSTIC_RETURNED'
except BaseException as exc:status=type(exc).__name__;meta.save(HERE/'exception.json',dict(type=type(exc).__name__,traceback=traceback.format_exc()))
finally:signal.setitimer(signal.ITIMER_REAL,0);sys.setprofile(None)
after=meta.sources(plan);assert before==after and own==meta.pin(Path(__file__).resolve()) and originals==meta.originals(corpus)
meta.save(HERE/'source-after.json',after)
report=dict(status=status,seconds=time.monotonic()-started,authorityOriginal=a.original_methods(),lastCounts=a._LAST_COUNTS.get(),refusals=refusals[:30],refusalCount=len(refusals),hot=[dict(file=k[0],line=k[1],name=k[2],calls=v[0],inclusiveSeconds=v[1]) for k,v in sorted(rows.items(),key=lambda kv:kv[1][1],reverse=True)[:30]],sourcePins=len(before),allPinsUnchanged=True,originalsUnchanged=True,noServicesOrSDKOrNode=True,wholeChatQualified=False)
meta.save(HERE/'report.json',report);print(json.dumps(report))
