"""One unchanged Audio reply/configuration host utility case; no SDK/native authority."""
from pathlib import Path
from metadata_reader import pin
from closed_import_origins import ClosedOrigins
from host_common import head
from source_execution_readiness import qualification
from definition_custody import DefinitionCustody
from class_cleanup_custody import ClassCleanupCustody
from project_namespace_admission import project_namespace_admission
from audio_resources import AudioResources
from async_selfpipe_custody import AsyncSelfPipeCustody
import builtins,hashlib,importlib.abc,importlib.util,io,json,os,signal,stat,sys,tempfile,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert sys.flags.no_site==1, 'Explicit no-site startup required'
assert len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert plan['status']=='PRIVATE_AUDIO_REPLY10_ONECASE_UNRUN'
recipe=json.loads((HERE/'fixed-ten-onecase-groups.json').read_text())['groups'][plan['groupName']]
assert recipe==plan['resourceRecipe']and plan['cases']==recipe['caseIds']
assert plan['phaseAdmission']is plan['aggregateEndAdmission']is None
assert project_namespace_admission(plan['declaredProjectAliases'],[str(REPO/'tests/device')])==(plan['modules'],plan['namespaces'],plan['projectAliasAdmission'])
assert plan['NodeExecutions']==plan['SDKExecutions']==plan['overteNativeQueries']==plan['oldApplicationCorpusInputs']==plan['globalOriginalScans']==0
assert plan['realNetwork']is False and plan['classCleanupObservationVersion']==1 and plan['expectedClassCleanupGroups']==1
assert plan['subjectHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
assert Path(plan['subjectActualCopiedPath'])==HERE/'closed_import_origins.py'
assert pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
assert head()==plan['actualPublicHead']
current_q,current_q_pins=qualification(pin)
assert plan['currentSourceExecution']==current_q
assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in current_q_pins.items())
assert len(plan['cases'])==len(set(plan['cases']))==1 and plan['wallSeconds']==30 and plan['killGraceSeconds']==5
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def fds():
    out={}
    for path in Path('/proc/self/fd').iterdir():
        try:v=path.stat();out[path.name]=dict(target=os.readlink(path),device=v.st_dev,inode=v.st_ino,mode=v.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return out
def children():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
def census(root):
    out={}
    for path in(root,*sorted(root.rglob('*'))):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):row=dict(stat=[getattr(info,k)for k in FIELDS],namespace=sorted(p.name for p in path.iterdir()))
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        out[str(path.relative_to(root))]=row
    return out
assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
original_path=tuple(sys.path);original_meta=tuple(sys.meta_path);loaded={};td_callers=[]
bootstrap_names={'metadata_reader','host_common','closed_import_origins','source_execution_readiness','definition_custody','class_cleanup_custody','project_namespace_admission','audio_resources','async_selfpipe_custody'}
for name in(*plan['modules'],*plan['thirdPartyModules']):
    if name in bootstrap_names:
        actual=sys.modules[name]
        assert Path(vars(actual)['__file__'])==Path(plan['modules'][name]['path'])
        assert pin(Path(vars(actual)['__file__']))==plan['sourceAndBinaryPins'][vars(actual)['__file__']]
    else:assert name not in sys.modules
sys.path[:]=[p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespaces'],*plan['thirdPartyModules'])}
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright')
origin_plan=plan['originPlan']
assert origin_plan['physicalPins']==plan['sourceAndBinaryPins']and origin_plan['modules']==plan['modules']
origins=ClosedOrigins(origin_plan,HERE,REPO,pin)
origin_before=origins.snapshot('before-utility-project-imports')
class AfterActualLoader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name,self.delegate=name,delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module)
        path=Path(vars(module)['__file__']);loaded[self.name]=str(path)
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in forbidden:raise ImportError('Product SDK/browser package refused')
        if name in plan['projectAliasAdmission']['unadmittedAliases']:raise ImportError('Unadmitted project alias retained as DATA: '+name)
        row=plan['modules'].get(name)
        if row is not None:
            spec=origins.file_spec(name,dict(row,loader='source'),'project')
            spec.loader=AfterActualLoader(name,spec.loader);return spec
        if name in origin_plan['namespacePackages']:
            roots=origin_plan['namespacePackages'][name];origins.namespaces(name,roots,roots,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots;return spec
        if name in origin_plan['thirdPartyModules']or name in origin_plan['thirdPartyNamespacePackages']:return origins.remaining_spec(name,path)
        if name.split('.')[0]in tops:raise ImportError('Unmapped project/third-party import: '+name)
        return origins.remaining_spec(name,path)
finder=Finder();sys.meta_path.insert(0,finder)
TOYS=HERE/'own-toys';RECEIPTS=HERE/'child-receipts'
assert TOYS.is_dir()and RECEIPTS.is_dir()and not any(TOYS.iterdir())and not any(RECEIPTS.iterdir())
assert os.environ['TMPDIR']==str(TOYS)and Path(tempfile.gettempdir())==TOYS
from owned_write_boundary import OwnedWrites
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={n:getattr(os,n)for n in ports if hasattr(os,n)};original_io=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
original_profile=sys.getprofile();assert original_profile is None
resources=AudioResources(TOYS,recipe);selfpipe=AsyncSelfPipeCustody(recipe['expectedAsyncioRunners'])
original_cleanup=unittest.TestCase.doCleanups;original_td=tempfile.TemporaryDirectory;original_time=time.time
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):
    path=Path(os.readlink('/proc/self/fd/'+str(fd)));assert path.resolve(strict=True)==path and path.is_relative_to(HERE);protected.append(path)
boundary=OwnedWrites(HERE,protected=protected)
closed=False;tail_births={};tail_used=set()
def tail_write(path,value):
    assert closed and path in tail_births and path not in tail_used
    assert all(getattr(os,name)is original for name,original in original_ports.items())
    assert original_io==(io.open,builtins.open)and original_dup==(os.dup,os.dup2)
    assert pin(path)==tail_births[path]
    with original_io[0](path,'w',encoding='utf-8')as stream:
        json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    tail_used.add(path)
tail_function=tail_write;tail_code=tail_write.__code__;tail_globals=tail_write.__globals__
def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Product SDK/browser import refused')
    if event.startswith('socket.'):
        if selfpipe.accept(event,args,sys._getframe(1)):return
        raise RuntimeError('No external network; only original unittest AF_UNIX selfpipe')
    if event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('Audio utility admits no subprocess/native/signal/other exec')
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if not relevant:return
    if closed:
        if event=='open':
            value,mode,flags=args
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
            if not writing:return
            caller=sys._getframe(1);path=Path(value)if type(value)in(str,bytes)else None
            assert path in tail_births and path not in tail_used
            assert mode=='w'and flags==(os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC)
            assert caller.f_code is tail_code and caller.f_globals is tail_globals and caller.f_locals.get('path')==path
            assert tail_function is tail_write and tail_function.__code__ is tail_code and tail_function.__globals__ is tail_globals
            assert pin(path)==tail_births[path]
            assert all(getattr(os,name)is original for name,original in original_ports.items())and original_io==(io.open,builtins.open)
            return
        raise RuntimeError('Mutation after actual original port restoration')
    boundary.audit(event,args,sys._getframe(1))
boundary.install();sys.addaudithook(audit)
retained=[];cleanup_calls=[];selected=[];case_receipts=[];secondary=[]
result=None;fatal=None;definition=None;class_cleanup=None;class_cleanup_restoration=None
monitor=sys.monitoring
monitor_ports=tuple((name,getattr(monitor,name))for name in('get_tool','get_events','get_local_events','set_local_events','set_events','register_callback','use_tool_id','free_tool_id'))
original_term=signal.getsignal(signal.SIGTERM)
def interrupted(*_args):raise KeyboardInterrupt('Original fixed30-second Audio utility boundary')
signal.signal(signal.SIGTERM,interrupted)
def save(name,body):
    p=RECEIPTS/name
    with p.open('x')as stream:stream.write(json.dumps(body,indent=2,sort_keys=True)+'\n')
    p.chmod(0o600)
def record_secondary(label):secondary.append(dict(phase=label,traceback=traceback.format_exc()))
def methods_ok():
    assert definition is not None and(class_cleanup is None or class_cleanup.tables is definition.class_tables)
    return definition.check()
def monitor_snapshot():
    assert sys.monitoring is monitor and all(getattr(monitor,name)is fn for name,fn in monitor_ports)
    codes=()if definition is None else definition.codes
    return tuple((monitor.get_tool(tool),monitor.get_events(tool),tuple(monitor.get_local_events(tool,code)for code in codes))for tool in range(6))
class RetainedTemporaryDirectory(original_td):
    def __init__(self,*args,**kwargs):
        caller=resources.caller(sys._getframe(1),args,kwargs)
        super().__init__(dir=TOYS);resources.retain(self,caller);retained.append(self.name)
def observe_original_cleanup(case):
    before=len(case._cleanups);outcome=case._outcome;actual=None if outcome is None else outcome.result
    errors=0 if actual is None else len(actual.errors);failures=0 if actual is None else len(actual.failures)
    returned=None;raised=None
    try:returned=original_cleanup(case);return returned
    except BaseException as error:raised=type(error).__module__+'.'+type(error).__qualname__;raise
    finally:
        now=None if case._outcome is None else case._outcome.result;same=now is actual
        cleanup_calls.append(dict(case=type(case).__module__+'.'+type(case).__qualname__,pendingBefore=before,remaining=len(case._cleanups),originalReturned=returned,originalRaised=raised,
          callbackErrorDeltaEstablished=same and actual is not None,newCallbackErrors=[]if not same or actual is None else[trace for unused,trace in actual.errors[errors:]],
          newCallbackFailures=[]if not same or actual is None else[trace for unused,trace in actual.failures[failures:]]))
class Result(unittest.TextTestResult):
    def startTest(self,test):
        class_cleanup.bind_result(self,test);assert methods_ok();origins.snapshot('before-original-'+test.id());selfpipe.bind(test)
        self.before=(fds(),tuple(threading.enumerate()),children(),len(cleanup_calls),monitor_snapshot());super().startTest(test)
    def stopTest(self,test):
        # The original IsolatedAsyncioTestCase closes its Runner AFTER this
        # original TestCase stopTest call. Record that phase honestly; final
        # FD/loop closure is checked after the actual whole case.run returns.
        try:
            fd,threads,kernel,cleanups,monitor_before=self.before
            origins.snapshot('after-original-stop-'+test.id())
            row=dict(id=test.id(),standardStopAfterCleanup=True,remainingStandardCleanups=len(test._cleanups),originalMethodsUnchanged=methods_ok(),
              monitorMasksSlotsUnchanged=monitor_snapshot()==monitor_before,profileRestored=sys.getprofile()is original_profile,
              fdCheckDeferredUntilOriginalAsyncRunnerClose=bool(recipe['expectedAsyncioRunners']),fdUnchanged=None if recipe['expectedAsyncioRunners']else fds()==fd,
              threadsUnchanged=tuple(threading.enumerate())==threads,kernelChildrenUnchanged=children()==kernel,
              nestedCleanupCalls=cleanup_calls[cleanups:])
            case_receipts.append(row);save('standard-case-1.json',row)
        except BaseException:record_secondary('original-stop-observation')
        finally:super().stopTest(test)
fd_before=fds();threads_before=tuple(threading.enumerate());children_before=children();monitor_before=None;passed=False
resource_receipt=None;async_receipt=None;class_receipt=None;origin_after=None;source_ok=False;definition_ok=False;cleanup_rows=[]
try:
    # Actual complete declared definition source imports through the installed
    # closed C10d delegates, never a copied namespace or raw compile shortcut.
    for module_name in plan['subjectOriginModules']:__import__(module_name)
    resources.bind();tempfile.TemporaryDirectory=RetainedTemporaryDirectory;unittest.TestCase.doCleanups=observe_original_cleanup
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(value):
        if type(value)is unittest.TestSuite:
            for child in value:yield from flatten(child)
        else:yield value
    selected=list(flatten(suite));ids=[case.id()for case in selected]
    save('actual-selection.json',dict(ids=ids,loaderErrors=loader.errors));assert not loader.errors and ids==plan['cases']and suite.countTestCases()==1
    definition=DefinitionCustody(plan['definitionInventory'],plan,pin)
    class_cleanup=ClassCleanupCustody(definition.class_tables,suite,selected,Result,Result.startTest,save)
    monitor_before=monitor_snapshot();assert methods_ok();class_cleanup.install()
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    # Genuine pending original callbacks are drained independently. A failed
    # diagnostic/guard never prevents the other original restoration attempts.
    for case in selected:
        pending=len(case._cleanups);old=case._outcome;drain=unittest.TestResult();returned=True;raised=None
        try:
            if pending:case._outcome=unittest.case._Outcome(drain);returned=observe_original_cleanup(case)
        except BaseException:returned=False;raised=traceback.format_exc();record_secondary('original-pending-cleanup')
        finally:case._outcome=old
        cleanup_rows.append(dict(id=case.id(),pendingBeforeOuter=pending,remaining=len(case._cleanups),originalReturned=returned,raised=raised,errors=[s for unused,s in drain.errors],failures=[s for unused,s in drain.failures]))
    for label,operation in(('resources',resources.report),('async-original-closed',selfpipe.report),('class-summary',lambda:None if class_cleanup is None else class_cleanup.summary()),
      ('definitions',methods_ok),('origins-after',lambda:origins.snapshot('after-original-case-and-cleanups'))):
        try:
            value=operation()
            if label=='resources':resource_receipt=value
            elif label=='async-original-closed':async_receipt=value
            elif label=='class-summary':class_receipt=value
            elif label=='definitions':definition_ok=value is True
            else:origin_after=value
        except BaseException:record_secondary(label)
    try:
        assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']and pin(INPUT)['sha256']==sys.argv[2]and head()==plan['actualPublicHead'];source_ok=True
    except BaseException:record_secondary('source-input-guard')
    final_fd_equal=fds()==fd_before;final_threads_equal=tuple(threading.enumerate())==threads_before;final_children_equal=children()==children_before
    tools_ok=False
    try:tools_ok=monitor_before is not None and monitor_snapshot()==monitor_before and sys.getprofile()is original_profile
    except BaseException:record_secondary('monitor-restore-check')
    nested_ok=len(cleanup_calls)==recipe['expectedNestedCleanups']and all(row['originalReturned']is True and row['originalRaised']is None and row['remaining']==0 and not row['newCallbackErrors']and not row['newCallbackFailures']for row in cleanup_calls)
    cleanup_ok=all(row['originalReturned']is True and row['remaining']==0 and not row['errors']and not row['failures']for row in cleanup_rows)
    source_origins={}
    for name,expected in plan['subjectOriginModules'].items():
        module=sys.modules.get(name);actual=None if module is None else vars(module).get('__file__')
        source_origins[name]=dict(actualModulePresent=module is not None,actualModuleFile=actual,actualLoaderExecutedPath=loaded.get(name),expectedPath=expected['path'],expectedSha256=expected['sha256'],exactOriginMatched=actual==loaded.get(name)==expected['path'])
    origins_ok=len(source_origins)==plan['subjectOriginCount']==476 and all(row['exactOriginMatched']for row in source_origins.values())
    try:
        if class_cleanup is not None:class_cleanup_restoration=class_cleanup.restore()
    except BaseException:record_secondary('class-original-restore')
    tempfile.TemporaryDirectory=original_td;unittest.TestCase.doCleanups=original_cleanup;signal.signal(signal.SIGTERM,original_term)
    tools_ok=tools_ok and tempfile.TemporaryDirectory is original_td and unittest.TestCase.doCleanups is original_cleanup and class_cleanup_restoration is not None and class_cleanup_restoration['originalDescriptorRestored']
    first=second=None
    if final_children_equal and final_threads_equal:
        try:first=census(TOYS);second=census(TOYS)
        except BaseException:record_secondary('quiet-owned-toys-census')
    passed=fatal is None and not secondary and result is not None and result.testsRun==1 and result.wasSuccessful()and not result.skipped
    passed=passed and cleanup_ok and nested_ok and resource_receipt is not None and async_receipt is not None and class_receipt is not None and class_receipt['allActualOriginalCallsAccepted']and class_receipt['actualOriginalClassCleanupCalls']==1
    passed=passed and len(case_receipts)==1 and all(r['remainingStandardCleanups']==0 and r['originalMethodsUnchanged']and r['monitorMasksSlotsUnchanged']and r['profileRestored']and r['threadsUnchanged']and r['kernelChildrenUnchanged']and(r['fdUnchanged']is True or r['fdCheckDeferredUntilOriginalAsyncRunnerClose']and r['fdUnchanged']is None)for r in case_receipts)
    passed=passed and source_ok and definition_ok and origins_ok and tools_ok and final_fd_equal and final_threads_equal and final_children_equal and first is not None and first==second
    for name,body in(('actual-all-loaded-origins-before.json',origin_before),('actual-all-loaded-origins-after.json',origin_after),('actual-source-model-origins.json',dict(subjectOrigins=source_origins,allActualRuntimeOriginsEstablished=origins_ok,actualExecutedOrigins=loaded)),
      ('actual-resources.json',resource_receipt),('actual-async-selfpipe-close.json',async_receipt),('actual-class-cleanup-calls.json',class_receipt),('actual-class-cleanup-restoration.json',class_cleanup_restoration),('actual-toy-first.json',first),('actual-toy-second.json',second),
      ('outer-cleanup.json',dict(success=cleanup_ok and nested_ok,cases=cleanup_rows,nestedActualCalls=cleanup_calls)),('report.json',dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=None if result is None else result.testsRun,actualCaseReceipts=len(case_receipts),fatal=fatal,secondary=secondary,
      cleanupEstablished=cleanup_ok and nested_ok,retainedTemporaryDirectories=retained,fdUnchanged=final_fd_equal,threadsUnchanged=final_threads_equal,kernelChildrenUnchanged=final_children_equal,pinsUnchanged=source_ok,twoToyCensusesEqual=first is not None and first==second,
      allActualLoadedOriginsAccounted=origin_after is not None,allActualRuntimeOriginsEstablished=origins_ok,actualClassCleanupSummary=class_receipt,PythonExecutions=0,NodeExecutions=0,SDKExecutions=0,overteNativeQueries=0,realNetwork=False,nativeQualified=False,wholeQualified=False))):
        try:save(name,body)
        except BaseException:passed=False;record_secondary('receipt-'+name);print(traceback.format_exc(),flush=True)
    # Qualified original-CIO receipt pattern: exact empty0600 file born while
    # E458 active; only held original C IO writes after actual port restore.
    restored=False;dup_restored=False
    try:
        tail=RECEIPTS/'actual-port-restoration.json';descriptor=os.open(tail,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        try:assert stat.S_IMODE(os.fstat(descriptor).st_mode)==0o600
        finally:os.close(descriptor)
        tail_births[tail]=pin(tail)
    except BaseException:passed=False;record_secondary('tail-birth')
    try:boundary.restore()
    except BaseException:passed=False;record_secondary('original-port-restore')
    try:
        restored=all(getattr(os,n)is v for n,v in original_ports.items())and original_io==(io.open,builtins.open)
        dup_restored=original_dup==(os.dup,os.dup2);boundary.close();closed=True
    except BaseException:passed=False;record_secondary('original-control-descriptor-close')
    sys.meta_path[:]=original_meta;sys.path[:]=original_path
    if closed and tail_births:
        try:tail_write(RECEIPTS/'actual-port-restoration.json',dict(restored=restored,count=len(original_ports),controlDescriptors=sorted(boundary.control_fds),dupPortsRestored=dup_restored,toolsRestored=tools_ok,builtinsCioRestored=original_io==(io.open,builtins.open),actualC10dHelperSha256=plan['subjectHelperSha256'],secondary=secondary))
        except BaseException:passed=False;print(traceback.format_exc(),flush=True)
raise SystemExit(0 if passed and restored and tools_ok and dup_restored else 1)
