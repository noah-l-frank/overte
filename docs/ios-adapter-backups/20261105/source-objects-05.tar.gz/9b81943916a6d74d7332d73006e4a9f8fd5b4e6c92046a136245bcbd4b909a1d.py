"""Root-only exact Chat comparison Utility14 metadata; never imports subjects."""
from pathlib import Path
_ENTRY_SOURCE_ROOT=Path(__file__).resolve(strict=True).parent
assert not(_ENTRY_SOURCE_ROOT/'__pycache__').exists()and not any(_ENTRY_SOURCE_ROOT.glob('*.pyc')),'Fresh private control root contains bytecode'
import argparse,hashlib,importlib.machinery,json,os,sys
from metadata_reader import pin
from host_common import REPO,head
from source_execution_readiness import qualification
SOURCE=Path(__file__).resolve(strict=True).parent
SUBJECT=REPO/'.ios-host-tmp/chat-archive-expected-roster-comparison-source2-private-20261104'
SUBJECT_SHA='530f269df9057b3ce57d691d751713086eb9bef57702ab9bd8402369deba5b92'
HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
CONTROLS=('metadata_reader','host_common','source_execution_readiness','closed_import_origins','owned_write_boundary','class_cleanup_custody','definition_custody','expected_comparison_custody')
EXECUTORS=('run-fourteen.py','supervise-fourteen.py',*(name+'.py'for name in CONTROLS),'readonly-shared-stdlib-sources.json','SOURCE-RECIPE.json','DEFINITION-INVENTORY.json','exact-fourteen-selectors.json')

def frozen(folder,leaf,digest,physical):
    path=folder/leaf;assert pin(path)['sha256']==digest;physical[str(path)]=pin(path);value=json.loads(path.read_text())
    for name,row in value['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        path=folder/name;assert pin(path)['sha256']==(row if type(row)is str else row['sha256']);physical[str(path)]=pin(path)
    return value

def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','expected-head','destination'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and head()==args.expected_head
    physical={};frozen(SOURCE,'source-freeze.json',args.source_freeze,physical);frozen(SUBJECT,'source-freeze.json',SUBJECT_SHA,physical)
    for directory,digest in(('root-chat-c10-original-timeout-passive-host-cost-results-20261104','4c7ecc1c7dfe108e0b96ddb6c801ae03567cf4d9898f0f24655870491f492d79'),
        ('root-chat-b6-paired-first1-original-timeout-negative-results-20261104','9c3817d979951666407ab1646512fa383eccd9e79217b5e2690076dbfbef7a89')):
        frozen(REPO/'.ios-host-tmp'/directory,'freeze.json',digest,physical)
    recipe=json.loads((SOURCE/'SOURCE-RECIPE.json').read_text())
    assert recipe['sourceFreeze']==dict(path=str(SUBJECT/'source-freeze.json'),sha256=SUBJECT_SHA)
    assert recipe['caseCount']==14 and recipe['TDs']==recipe['caseChildren']==recipe['threads']==0 and recipe['network']is False
    assert recipe['wallSeconds']==30 and recipe['stopGraceSeconds']==5 and recipe['oldSubsetSelected']==[]
    cases=json.loads((SOURCE/'exact-fourteen-selectors.json').read_text());assert cases==recipe['cases']and len(cases)==len(set(cases))==14
    assert cases==[row['id']for row in json.loads((SUBJECT/'PROSPECTIVE-COUNTERS.json').read_text())['cases']]
    modules={}
    for name,row in recipe['projectDefinitionModules'].items():
        path=Path(row['path']);assert path.resolve(strict=True)==path and pin(path)['sha256']==row['sha256'];physical[str(path)]=pin(path)
        modules[name]=dict(path=str(path),sha256=row['sha256'],package=row['package'],loader='source')
    assert len(modules)==30
    # Every declared namespace is one actual public directory, never a guessed
    # parent reconstructed from a dotted legacy directory name.
    namespaces=recipe['actualNamespaceDirectories'];assert len(namespaces)==4
    for name,roots in namespaces.items():
        assert name not in modules and all(part.isidentifier()for part in name.split('.'))
        assert roots==[str(REPO/'tests/device'/Path(*name.split('.')))]
        for root in roots:assert Path(root).is_dir()and Path(root).resolve(strict=True)==Path(root)
    # Closed diagnostic negatives remain literal source metadata/data. Their
    # timeout originals are neither scenarios replayed nor current authority.
    for name,digest in json.loads((SUBJECT/'SOURCE-REFERENCES.json').read_text()).items():
        assert pin(name)['sha256']==digest;physical[name]=pin(name)
    current,current_pins=qualification(pin);physical.update(current_pins)
    assert current['actualReferenceCount']==141 and current['currentHelperAlgorithmQualified']is True and current['consumerCompositionQualified']is False
    assert len(current['requiredOriginalRoots'])==6 and pin(SOURCE/'closed_import_origins.py')['sha256']==HELPER
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ');gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    for path in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(path)]=pin(path)
    ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    refpath=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs');physical[str(refpath)]=pin(refpath)
    std=Path(os.__file__).resolve(strict=True).parent;assert std==Path('/usr/lib64/python3.14');suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);stdnamespaces={}
    for stdlib_dir,dirs,names in os.walk(std,topdown=True,followlinks=False):
        folder=Path(stdlib_dir);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink())
        rel=folder.relative_to(std)
        if rel.parts and all(n.isidentifier()for n in rel.parts)and not(folder/'__init__.py').is_file():stdnamespaces['.'.join(rel.parts)]=[str(folder)]
        for name in names:
            path=folder/name
            if path.suffix!='.py'and not str(path).endswith(suffixes):continue
            assert path.resolve(strict=True)==path and not path.is_symlink();physical[str(path)]=pin(path)
    python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
    dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'and dest.name.startswith('chat-expected-comparison-own14-prepared-')and not dest.exists()
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    dest.mkdir(mode=0o700)
    for name in EXECUTORS:
        path=dest/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write((SOURCE/name).read_bytes())
        physical[str(path)]=pin(path)
    for name in CONTROLS:
        assert name not in modules;path=dest/(name+'.py');modules[name]=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=False,loader='source')
    subject_names=('ios.adapters.chat_archive_round','ios.self_tests.chat_archive_order_subject','ios.self_tests.chat_archive_signature_oracle','ios.self_tests.test_ios_chat_expected_roster_comparison','class_cleanup_custody','definition_custody','expected_comparison_custody')
    subjects={name:{k:modules[name][k]for k in('path','sha256')}for name in subject_names}
    origin=dict(modules=modules,namespacePackages=namespaces,thirdPartyModules={},thirdPartyNamespacePackages={},stdlibNamespacePackages=stdnamespaces,stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
    plan=dict(status='PRIVATE_CHAT_EXPECTED_COMPARISON_UTILITY14_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(dest),actualPublicHead=args.expected_head,sourceFreeze=args.source_freeze,
        cases=cases,caseCount=14,wallSeconds=30,killGraceSeconds=5,TDsPerCase=[0]*14,nestedCleanupCallsPerCase=[1]*14,
        expectedTemporaryDirectories=0,expectedNestedCleanupCalls=14,expectedClassCleanupGroups=1,classCleanupObservationVersion=1,
        sourceAndBinaryPins=physical,modules=modules,namespaces=namespaces,thirdPartyModules={},originPlan=origin,subjectOriginModules=subjects,subjectOriginCount=7,
        pythonExecutable=dict(path=str(python),pin=physical[str(python)]),subjectHelperSha256=HELPER,subjectActualCopiedPath=str(dest/'closed_import_origins.py'),currentSourceExecution=current,
        helperQualificationRequiredOriginalRooms=current['requiredOriginalRoots'],externalRootGuardMustIncludeAllHelperOriginalRooms=True,
        NodeExecutions=0,PythonExecutions=0,SDKExecutions=0,overteNativeQueries=0,realNetwork=False,expectedJoinedThreadCases=0,maximumLiveUtilityChildren=0,
        oldApplicationCorpusInputs=0,globalOriginalScans=0,oldScenarioOriginalInputs=0,consumerCompositionQualified=False,runtimeAdmission=None,EndAdmission=None,chatAdoptionAdmission=None,nativeAdmission=None,nativeQualified=False,wholeQualified=False,utilityQualification=None,
        utilitySubjectSourceFreeze=SUBJECT_SHA,actualCompilerClosureCustody='GENUINE_ORIGINAL_CALL_SETUP_RETURN_NOT_A_MONITOR_OR_FAKE_FRAME',performanceMeasured=False,
        trustedHostBootstrap='Actual interpreter/stdlib/initial controller modules are trusted physical origins. Delegated subjects use exact qualified C10d fresh source bytes; no entire-interpreter cache-absence claim.',
        limitations='Fourteen new comparison controls only. No historical paired case replay, archive/native/feature/Whole qualification, gain claim or Chat adoption; future actual namespace measurement remains separate.')
    output=dest/'approved-inputs.json';fd=os.open(output,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
    assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
    print(json.dumps(dict(status='ROOT_METADATA_ONLY_UNRUN',input=str(output),sha256=pin(output)['sha256'],cases=14,TDs=0,sourcePins=len(physical),targets=0,globalScans=0)))
if __name__=='__main__':main()
