"""Separate observational-test correction, never changes runtime candidates."""
from pathlib import Path
import ast,difflib,hashlib,json
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent.parent
BASE=ROOT/'.ios-host-tmp/tablet-parent-guard-policy-scanner-overlay-20261028'
PATH='tests/device/ios/self_tests/test_ios_tablet_web_parent_guard_cache.py'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
original=(BASE/'candidate'/PATH).read_text()
old="""                second_parts,second_row=self.f.capture(self.owner)
                current=self.f.historical()
                self.assertEqual(first_parts,current.frame_at(self.owner.state['records'][0])[1])
"""
new="""                second_parts,second_row=self.f.capture(self.owner)
                self.assertEqual([],seen)
                current=self.f.historical()
                # The new real owner must still initially validate its own
                # Source3 capsule, before it can borrow the immutable proof.
                self.assertEqual([code],seen);seen.clear()
                self.assertEqual(first_parts,current.frame_at(self.owner.state['records'][0])[1])
"""
assert original.count(old)==1;candidate=original.replace(old,new)
ast.parse(candidate);target=HERE/'candidate'/PATH;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(candidate)
before=HERE/'originals'/PATH;before.parent.mkdir(parents=True,exist_ok=True);before.write_text(original)
manifest={PATH:dict(baseSha256=hashlib.sha256(original.encode()).hexdigest(),candidateSha256=sha(target),
    actualPublicBaseSha256=sha(ROOT/PATH))}
(HERE/'candidate-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(HERE/'proposal-after-opaque.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),candidate.splitlines(True),fromfile='a/'+PATH,tofile='b/'+PATH)))
(HERE/'proposal-from-actual-public.diff').write_text(''.join(difflib.unified_diff((ROOT/PATH).read_text().splitlines(True),candidate.splitlines(True),fromfile='a/'+PATH,tofile='b/'+PATH)))
(HERE/'ROOT-REVIEW.txt').write_text('''TEST ONLY / ALL5 corrected selection UNRUN. Original five IDs remain exact.
Actual first run reached positive literal2/cache0 and both real captures plus
historical frame reads. The final zero count wrongly included one mandatory
new historical constructor decode. Preserve that constructor validation:
zero immediately after captures; exactly the original code once after actual
historical construction; clear observer; zero for subsequent frame/hit reads.
No arbitrary outcome threshold, decoder patch or constructor bypass. This
full test also contains the separately frozen meaningful opaque-policy case.
Runtime Root wrapper c78 and helper e46 stay unchanged. Retain failed86 plus
legacy11 PASS235 and all older original corpora; rerun fresh ALL5/300+5 because
four original cases never ran. Do not repeat unchanged passed legacy11.
''')
files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'}
(HERE/'freeze.json').write_text(json.dumps(dict(status='FROZEN_PRIVATE_UNRUN',files=files),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(freezeSha256=sha(HERE/'freeze.json'),paths=manifest),indent=2))
