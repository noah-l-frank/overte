"""Root-only serial metadata preparation of four reviewed utility profiles."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
R=Path.cwd().resolve(strict=True);B=R/'.ios-host-tmp';D=Path(__file__).resolve().parent
P=B/'root-four-reviewed-utility-groups-window-source1-20261104/PROFILES.json'
C=B/'root-ios-current918-after-public73-context-20261104/root-context.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(name,value):
    with(D/name).open('x')as f:json.dump(value,f,sort_keys=True,indent=2);f.write('\n')
assert sys.flags.no_site and sys.dont_write_bytecode and sha(C)=='c512e89eecede7e64423257fb5ee21e34deea47f723925830418ebe403906ea2'
assert load(C)['allTargetsTerminal']and load(C)['expectedHead']=='cb79372ab9ec96df5e1320f9c573259ac3fbebed'
profiles=load(P);assert len(profiles)==4
rows=[]
for index,profile in enumerate(profiles,1):
    source=B/profile['sourceDirectory'];assert sha(source/'source-freeze.json')==profile['sourceFreeze']
    h=B/(profile['destinationPrefix']+'root918-headcb793-utility'+str(index)+'-20261104');assert not h.exists()
    command=[sys.executable,'-S','-B',str(source/'prepare.py'),'--source-freeze',profile['sourceFreeze'],
        '--expected-head','cb79372ab9ec96df5e1320f9c573259ac3fbebed','--destination',str(h)]
    with(D/(profile['group']+'-stdout.log')).open('xb')as stdout,(D/(profile['group']+'-stderr.log')).open('xb')as stderr:
        result=subprocess.run(command,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
    if result.returncode:
        put('preparation-failure.json',dict(group=profile['group'],returnCode=result.returncode,completed=rows,possibleMetadataRoom=str(h),targets=0,globalScans=0))
        raise SystemExit(result.returncode)
    p=h/'approved-inputs.json';plan=load(p)
    assert plan['status']==profile['inputStatus']and plan['sourceFreeze']==profile['sourceFreeze']and len(plan['cases'])==profile['cases']
    rows.append(dict(group=profile['group'],input=str(p),inputSha256=sha(p),cases=len(plan['cases']),physicalPins=len(plan['sourceAndBinaryPins'])))
    put('generated-after-'+profile['group']+'.json',rows)
    print('METADATA_PREPARED '+profile['group'],flush=True)
assert len(rows)==4 and sum(row['cases']for row in rows)==32
put('results.json',dict(status='ROOT_METADATA_ONLY_FOUR_UTILITY_INPUTS_PREPARED_UNRUN',groups=rows,profiles=str(P),context=str(C),contextSha256=sha(C),targets=0,subjectImports=0,globalScans=0))
put('freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in sorted(D.iterdir())if p.is_file()}))
print(json.dumps(dict(status='METADATA_ONLY_UNRUN',freeze=sha(D/'freeze.json'),groups=4)),flush=True)
