"""Connected exact known Reply4 inventory and CleanupScope holder retirement.

This namespace is only generation/action read holders. It cannot cover pending
births, Reply2/3/5, Files, scenes, marker/images or OS/SDK resources.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import stat
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.assets_cleanup_phase import AssetsCleanupScope
from ios.adapters.assets_cleanup_runtime import CurrentCleanupAssetsRuntime
from ios.adapters.assets_generation_replies import GenerationActionReplyReads
from ios.adapters.assets_generation_reply_cleanup import AssetsGenerationReplyCleanup
from ios.adapters.assets_page_generation_recovery import reconstruct_page_generations
from ios.adapters.assets_end_metadata import signature


def original_paths(store,references,pending=None):
    paths={store.path(store.expand(ref)) for ref in references}
    if pending is not None:
        ref=pending['original']
        if ref is not None:
            if ref['phase']=='planned':need(not store.path(ref).exists())
            else:paths.add(store.path(ref))
    return paths


def generation_jobs(driver,cleanup):
    """Read actual known originals before any current cleanup transport exists."""
    from ios.adapters.assets_whole_input import AssetsWholeInput
    need(type(driver) is AssetsWholeInput and type(cleanup) is AssetsCleanupScope
        and cleanup.owner.actions is driver.actions and cleanup.owner.episodes is driver.episodes)
    driver.guard();cleanup.guard();scopes=tuple(driver.scopes)
    store=PrivateFeatureState(driver.root/('ios-assets-page-generations-'+driver.run+'-primary.json'))
    # No canonical source means no generation jobs can be authorized here.
    # It never establishes their absence; prefix duties remain in the caller.
    if store.read() is None:return dict(origins=[],cleanups=[],paths=set(),filePins={},canonicalPresent=False)
    recovered=reconstruct_page_generations(driver.episodes,driver.actions,scopes)
    canonical=recovered['owner'];canonical.guard();specs=[];directories={}
    for generation,context in canonical.contexts.items():
        if generation==1:continue
        need(context.birth.historical and generation in (2,3,4) and len(scopes)>=generation)
        episode=scopes[generation-1];root=Path(episode.descriptor['directories']['primary']['stateRoot']['path'])
        episode.guard();episode.locks['primary'].assert_held();info=root.lstat()
        need(stat.S_ISDIR(info.st_mode) and not root.is_symlink())
        directories[root]=(info.st_dev,info.st_ino,info.st_mode,info.st_uid)
        first,last={2:(9,13),3:(16,17),4:(22,23)}[generation]
        for index in range(first,last+1):
            specs.append((generation,index,context.birth,episode,root))
    def inventory():
        result={}
        for root in directories:
            entries=list(root.iterdir());need(len(entries)<=4096)
            prefixes=tuple(prefix for generation,index,_birth,_episode,directory in specs if directory==root
                for prefix in ('ios-assets-'+driver.run+'-primary-gen'+str(generation)+'-action'+str(index)+'-',
                    'assets-g'+str(generation)+'-a'+str(index)+'-'))
            for path in entries:
                if path.name.startswith(prefixes):
                    pin=signature(path);need(pin is not None and stat.S_ISREG(pin[2]) and pin[3]==1
                        and not path.is_symlink());result[path]=pin
        return result
    before=inventory();known=set();origins=[];cleanups=[]
    for generation,index,birth,episode,root in specs:
        prefix='ios-assets-'+driver.run+'-primary-gen'+str(generation)+'-action'+str(index)
        header=root/(prefix+'-replies.json')
        if header not in before:continue
        origin=GenerationActionReplyReads.from_archive(PrivateFeatureState(header),generation=birth,
            episode=episode,actions=driver.actions,action_index=index,monotonic=driver.monotonic)
        provenance=origin.query_sources;known.update((header,provenance.store.path));known.update(origin.sources.owned_paths())
        known.update(original_paths(provenance.originals,provenance.state['refs'],provenance.state['pending']))
        # No saved/query prefix is promoted into a native command here.
        need(origin.sources.pending is None and provenance.state['pending'] is None)
        commands={row['commandId'] for row in origin.state['commands']}
        for ref in provenance.state['refs']:
            row=provenance.originals.read(provenance.originals.expand(ref));need(row['query']['commandId'] in commands)
        origins.append(origin);cleanup_header=root/(prefix+'-reply-cleanup.json')
        if cleanup_header in before:
            owner=AssetsGenerationReplyCleanup(origin,cleanup,episode,PrivateFeatureState(cleanup_header),
                historical=True,monotonic=driver.monotonic)
            known.add(cleanup_header);known.update(owner.sources.owned_paths())
            known.update(original_paths(owner.query_originals,owner.query_refs,owner.query_pending))
            need(set(owner.report()['retainedDuties'])<={'original-read-jobs'});cleanups.append(owner)
    need(set(before)==known and before==inventory())
    for root,expected in directories.items():
        value=root.lstat();need((value.st_dev,value.st_ino,value.st_mode,value.st_uid)==expected)
    canonical.guard();driver.guard();cleanup.guard()
    return dict(origins=origins,cleanups=cleanups,paths=known,filePins=before,canonicalPresent=True)


def close_known_generation_jobs(driver,cleanup):
    graph=generation_jobs(driver,cleanup);reports=[]
    for origin in graph['origins']:
        previous=[owner for owner in graph['cleanups'] if owner.origin.store.path==origin.store.path];need(len(previous)<=1)
        if origin.state['phase']=='closed' and not previous:
            reports.append(dict(generation=origin.generation.generation,actionIndex=origin.action_index,
                knownJobs=len(origin.state['jobs']),knownJobsClosed=True,originalReplyUnchanged=True,
                currentNativeFactsProduced=False,wholeEndEligible=False));continue
        runtime=CurrentCleanupAssetsRuntime(driver.adapter,cleanup,origin.reply_episode,
            monotonic=driver.monotonic,epoch_ms=driver.epoch_ms)
        owner=runtime.asset_generation_reply_cleanup(driver.selector,origin)
        if owner.state is None:owner.reserve()
        need(set(owner.report()['retainedDuties'])<={'original-read-jobs'})
        owner.close();report=owner.report();need(report['knownJobsClosed'] and not report['retainedDuties'])
        reports.append(report);cleanup.guard()
    after=generation_jobs(driver,cleanup)
    need(len(after['origins'])==len(graph['origins']))
    for origin in graph['origins']:origin.source_guard();origin.decode(origin.store.read())
    return dict(assetsGenerationPrefixJobCleanupVersion=1,canonicalPresent=after['canonicalPresent'],
        originalOwners=len(graph['origins']),knownJobs=sum(row['knownJobs'] for row in reports),reports=reports,
        exactKnownGenerationNamespaceRead=after['canonicalPresent'],wholeNativeHolderAbsence=False,wholeEndEligible=False)
