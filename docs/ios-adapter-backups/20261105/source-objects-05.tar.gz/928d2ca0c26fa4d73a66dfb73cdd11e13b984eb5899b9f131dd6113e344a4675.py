"""Connected actual current-state/peer producers; no public whole acceptance.

All native/SDK/Qt/Node/server/parser/platform boundaries remain declared host
models. Original QML/HTTP/file/weak entity/model/backend/WAL producers execute
only if Root runs these tests. These cases are not hardware qualification.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import unittest
from adapters.normal_ui import NativeUIError
from feature_journeys.scenarios import SCENARIOS,expand
from feature_journeys.fixtures import context
from ios.adapters.assets_current_state import AssetsCheckpointNotReady
from ios.adapters.assets_checkpoint_replies import AssetsCheckpointReplies
from ios.adapters.assets_checkpoint_scene import AssetsCheckpointScene
from ios.self_tests.assets_whole_observation_fixture import Fixture
from ios.self_tests.assets_picker_fixture import RUN


class AssetsWholeCurrentObservationTests(unittest.TestCase):
    def setUp(self):self.f=Fixture(self);self.b=self.f.boundary
    def expected(self,index):return expand(SCENARIOS['assets']['steps'][index-1]['state'],context(RUN))
    def test_actual_all29_current_states_and_independent_peer_states_match_the_closed_scenario(self):
        for index in range(1,30):
            with self.subTest(index=index):
                left,right=self.f.observed(index)
                self.assertEqual(self.expected(index),left['state']);self.assertEqual(self.expected(index),right['state'])
                self.assertFalse(left['publicObservationReady']);self.assertFalse(right['publicObservationReady'])
                self.assertEqual('primary',left['subject']);self.assertEqual('actor',right['subject'])
                self.assertNotEqual(left['ui']['path'],right['ui']['path']);self.assertNotEqual(left['replies']['path'],right['replies']['path'])
                self.assertIsNotNone(right['peerScene']);self.assertFalse(left['wholeEndEligible'])
                scope=None if index==1 else self.f.driver.scopes[{2:1,3:1,**{n:2 for n in range(4,14)},**{n:3 for n in range(14,18)},**{n:4 for n in range(18,24)},**{n:5 for n in range(24,30)}}[index]-1]
                for subject in ('primary','actor'):
                    owner=AssetsCheckpointReplies.from_archive(self.f.a.owner,index,subject,episode=scope)
                    self.assertEqual(5,owner.storage_version);self.assertEqual('closed',owner.state['phase']);self.assertIsNone(owner.sources.pending)
    def test_live_peer_Model_not_loaded_is_not_replaced_with_the_primary_success_or_action8_ACK(self):
        self.f.until(7);self.f.perform_action(8);identity=next(iter(self.b.peer.models));self.b.peer.models[identity].loaded=False
        left=self.f.driver.observe_current('primary');self.assertTrue(left['state']['sceneModel'])
        before=deepcopy(self.b.inputs)
        with self.assertRaises(AssetsCheckpointNotReady):self.f.driver.observe_current('actor')
        self.assertEqual(before,self.b.inputs);self.assertEqual(7,len(self.f.a.owner.state['records']))
        self.assertIsNone(self.f.driver.observers[(8,'actor')].last);self.assertFalse(self.b.peer.models[identity].loaded)
    def test_foreign_current_peer_Node_permission_blocks_even_when_primary_and_settings_reached10(self):
        self.f.until(9);self.f.peer_permissions.propagate=False;self.f.peer_permissions.can_write=True;self.f.perform_action(10)
        left=self.f.driver.observe_current('primary');self.assertFalse(left['state']['canWrite'])
        with self.assertRaises(AssetsCheckpointNotReady):self.f.driver.observe_current('actor')
        self.assertEqual(9,len(self.f.a.owner.state['records']));self.assertTrue(self.f.peer_permissions.can_write)
        self.assertTrue(all(not row['id_can_write_to_asset_server'] for row in self.f.write.h.security['standard_permissions']))
    def test_unadmitted_actual_zero_byte_checkpoint_UI_original_blocks_before_any_new_current_UI_query(self):
        self.f.perform_action(1);root=self.f.driver.root
        path=root/('assets-cp-a1-primary-ui-frame-sources-'+RUN+'-primary-0032-'+('f'*64)+'.json');path.touch(mode=0o600,exist_ok=False)
        info=path.stat();before=deepcopy(self.b.inputs);sequence=self.b.sequence
        with self.assertRaises(NativeUIError):self.f.driver.observe_current('primary')
        self.assertEqual(before,self.b.inputs);self.assertEqual(sequence,self.b.sequence);self.assertEqual(0,len(self.f.a.owner.state['records']))
        self.assertEqual((info.st_dev,info.st_ino,0),(path.stat().st_dev,path.stat().st_ino,path.stat().st_size))
    def test_samebytes_foreign_scene_original_inode_is_never_a_historical_peer_fact(self):
        self.f.observed(1);observer=self.f.driver.observers[(1,'actor')];source=observer.peer_scene['scene']
        ref=source.originals.expand(source.state['frames'][0]);path=source.originals.path(ref);body=path.read_bytes()
        path.rename(path.with_name('retained-before-foreign-scene-inode'));path.write_bytes(body);path.chmod(0o600)
        with self.assertRaises(NativeUIError):AssetsCheckpointScene.from_archive(self.f.a.owner,1,'actor')
        self.assertEqual(1,len(self.f.a.owner.state['records']));self.assertEqual(body,path.read_bytes())


if __name__=='__main__':unittest.main()
