"""New cleanup-only backend originals over the unchanged first upload baseline.

No original Upload/Backend header is relabeled or rewritten. The existing
strict restoration codec must reopen exact foreign mappings/blobs/meta and
both native/host worker quiet intervals. Settings ACKs, Delete UI receipts,
normal input completion and process Stop never substitute for this source.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import hashlib,json,os
from adapters.asset_backend_client import AssetsBackendClient,export as decode_export
from adapters import asset_backend_evidence as evidence,asset_backend_source as source
from adapters.native_feature_observation import exact,integer,need
from adapters.script_feature.history import same,pack,unpack,canonical
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.assets_backend_owner import OwnedAssetsBackend,BackendSegments,public_configuration,MAX_SAMPLES
from ios.adapters.assets_cleanup_phase import AssetsCleanupScope
from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
from ios.adapters.assets_budget import operation


class AssetsWholeServerCleanup:
    tag=OwnedAssetsBackend.tag
    config_for_decode=OwnedAssetsBackend.config_for_decode
    raw=OwnedAssetsBackend.raw
    packet=OwnedAssetsBackend.packet
    parts_intent=OwnedAssetsBackend.parts_intent
    acquire=OwnedAssetsBackend.acquire
    sample=OwnedAssetsBackend.sample
    recover=OwnedAssetsBackend.recover
    checkpoint=OwnedAssetsBackend.checkpoint
    def __init__(self,cleanup,baseline_graph,client,store,*,monotonic,sleep):
        need(type(cleanup) is AssetsCleanupScope and type(baseline_graph) is AssetsEpisodeModelGraph
            and baseline_graph.episode.index==2 and baseline_graph.dependency_mode and isinstance(client,AssetsBackendClient)
            and isinstance(store,PrivateFeatureState) and callable(monotonic) and callable(sleep))
        self.cleanup,self.graph,self.client,self.store=cleanup,baseline_graph,client,store
        self.run,self.role,self.binding=cleanup.owner.run,'primary',deepcopy(baseline_graph.binding)
        self.config=public_configuration(client.config);self.lock=cleanup.owner.locks['primary']
        self.monotonic,self.sleep=monotonic,sleep
        need(store.path==Path(cleanup.owner.selected.context['roles']['primary']['stateRoot'])/('ios-assets-server-cleanup-'+self.run+'.json')
            and baseline_graph.actions is cleanup.owner.actions and same(self.config,baseline_graph.backend.config))
        self.previous=store.read();self.state=None
        self.parts=BackendSegments(store.path.parent,self.binding,self.run,'primary','primary',self.guard,self.parts_intent,monotonic=monotonic)
        if self.previous is not None:self.state=self.decode(self.previous)
    def baseline(self):
        graph=self.graph;graph.guard();backend=graph.backend;index=backend.state['baseline'];need(index is not None)
        row=backend.state['samples'][index-1];need(row['parts'] is not None and row['parts']['complete'])
        return row,dict(path=str(backend.store.path),headerSha256=hashlib.sha256(canonical(backend.previous)).hexdigest(),
            index=index,query=deepcopy(row['query']))
    def metadata_guard(self):
        self.lock.assert_held();self.cleanup.owner.metadata_guard();self.graph.guard();need(same(self.store.read(),self.previous));return True
    def guard(self):
        self.metadata_guard();self.cleanup.guard();need(self.client.guard() is not False);return True
    def envelope(self):
        _base,link=self.baseline()
        return dict(iosAssetsWholeServerCleanupVersion=1,runId=self.run,binding=self.binding,cleanup=self.cleanup.owner.link(),
            initialBaseline=link,backendConfiguration=self.config,payload=pack([self.state]))
    def decode(self,value):
        exact(value,{'iosAssetsWholeServerCleanupVersion','runId','binding','cleanup','initialBaseline','backendConfiguration','payload'})
        base,link=self.baseline()
        need(type(value['iosAssetsWholeServerCleanupVersion']) is int and value['iosAssetsWholeServerCleanupVersion']==1
            and value['runId']==self.run and same(value['binding'],self.binding) and same(value['cleanup'],self.cleanup.owner.link())
            and same(value['initialBaseline'],link) and same(value['backendConfiguration'],self.config))
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0];exact(state,{'phase','samples','restoration'})
        need(state['phase'] in ('observing','restored') and type(state['samples']) is list and len(state['samples'])<=MAX_SAMPLES)
        prior=None;slots=set();next_chunk=1;pending=False
        from fixture.asset_backend_control import command
        for row in state['samples']:
            exact(row,{'slot','query','requests','parts'});need(not pending and row['slot'] not in slots and row['slot']=='cleanup-'+str(len(slots)+1));slots.add(row['slot'])
            query=command(row['query']);need(query['operation']=='observe' and query['runId']==self.run and query['ticket']==self.cleanup.owner.read()['ticket'])
            need(type(row['requests']) is list and len(row['requests'])<=32)
            for index,request in enumerate(row['requests']):
                command(request);need(same(request,dict(query,operation='observe' if index==0 else 'poll')))
            parts=row['parts'];pending=parts is None or not parts['complete']
            if parts is not None:
                self.parts.parent(parts);need(parts['label']=='raw' and parts['first']==next_chunk and parts['tag']==self.tag(row))
                next_chunk+=max(1,(parts['bytes']+524287)//524288)
                if parts['complete']:
                    need(row['requests']);raw=self.parts.read(parts);original=json.loads(raw);need(canonical(original)==raw)
                    packet=decode_export(original,query,self.config_for_decode());source.accept(prior,packet);prior=packet
                else:self.parts.inspect(parts)
        if state['restoration'] is not None:
            proof=state['restoration'];exact(proof,{'first','last','proof'})
            need(integer(proof['first'],1,len(state['samples'])) and integer(proof['last'],proof['first']+1,len(state['samples'])))
            actual=self.restoration(state,proof['first'],proof['last']);need(actual is not None and same(actual,proof['proof']))
        need((state['phase']=='restored')==(state['restoration'] is not None))
        if state['phase']=='restored':need(not pending and state['restoration']['last']==len(state['samples']))
        return state
    def save(self):
        self.guard();value=self.envelope();self.decode(value);self.store.write(value,self.previous)
        descriptor=os.open(self.store.path.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
        try:os.fsync(descriptor)
        finally:os.close(descriptor)
        self.previous=deepcopy(value)
    def restoration(self,state,first,last):
        base,_link=self.baseline();start,end=state['samples'][first-1],state['samples'][last-1]
        return evidence.restored(self.graph.backend.raw(base),base['query'],self.raw(start),start['query'],self.raw(end),end['query'],self.config_for_decode())
    @operation
    def restore(self):
        self.guard()
        if self.state is None:self.state=dict(phase='observing',samples=[],restoration=None);self.save()
        if self.state['phase']=='restored':self.decode(self.previous);return deepcopy(self.state['restoration']['proof'])
        ticket=self.cleanup.owner.read()['ticket']
        while len(self.state['samples'])<MAX_SAMPLES:
            pending=self.state['samples'][-1] if self.state['samples'] and (self.state['samples'][-1]['parts'] is None or not self.state['samples'][-1]['parts']['complete']) else None
            slot=pending['slot'] if pending is not None else 'cleanup-'+str(len(self.state['samples'])+1)
            packet=self.checkpoint(slot,ticket)
            if packet is None:self.sleep(.1);continue
            last=len(self.state['samples'])
            for first in range(1,last):
                proof=self.restoration(self.state,first,last)
                if proof is not None:
                    self.state.update(phase='restored',restoration=dict(first=first,last=last,proof=proof));self.save();return deepcopy(proof)
            self.sleep(.1)
        need(False)
