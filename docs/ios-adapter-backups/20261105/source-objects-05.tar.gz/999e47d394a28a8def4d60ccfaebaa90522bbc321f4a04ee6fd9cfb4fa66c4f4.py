"""UNRUN stdlib-only real-child counters for the controller kernel utility.

No product/native process authority is supplied. These tests spawn one actual
-S Python child at a time; they never launch Node, SDKs, sockets or old inputs.
A separate Root-reviewed utility controller/30+5 admission is required.
"""
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch
import kernel

CHILD="import sys; print('ready',flush=True); sys.stdin.buffer.read()"


class OwnedKernelDiscoveryTests(unittest.TestCase):
    def child(self):
        child=subprocess.Popen([str(Path(sys.executable).resolve(strict=True)),'-B','-S','-c',CHILD],
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True)
        def retire():
            if child.stdin is not None and not child.stdin.closed:child.stdin.close()
            try:code=child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                child.kill();child.wait();raise AssertionError('Utility child required forced rescue, not a successful original drain')
            finally:
                for stream in (child.stdout,child.stderr):
                    if stream is not None:stream.close()
            self.assertEqual(0,code);self.assertIsNone(kernel.process(child.pid))
        self.addCleanup(retire)
        self.assertEqual(b'ready\n',child.stdout.readline())
        self.assertIsNotNone(kernel._stat(child.pid))
        return child

    def test_real_owned_python_resolves_only_its_executable_after_stat_only_foreign_discovery(self):
        child=self.child();self.assertNotEqual(1,os.getpid());self.assertIsNotNone(kernel._stat(1))
        original=kernel._executable;seen=[]
        def observed(pid):
            self.assertEqual(child.pid,pid,'Foreign executable resolution is forbidden by this observer')
            seen.append(pid);return original(pid)
        with patch.object(kernel,'_executable',observed):rows=kernel.descendants(os.getpid())
        self.assertEqual({child.pid},set(rows));self.assertEqual([child.pid],seen)
        self.assertEqual(str(Path(sys.executable).resolve(strict=True)),rows[child.pid]['executable'])
        self.assertEqual(os.getpid(),rows[child.pid]['parent'])
        self.assertEqual({'pid','parent','group','startTicks','executable'},set(rows[child.pid]))

    def test_unreadable_actual_owned_executable_propagates_without_absence_or_permission_skip(self):
        child=self.child();original=kernel._executable;fault=PermissionError(13,'Declared owned executable port refusal')
        def refused(pid):
            if pid==child.pid:raise fault
            return original(pid)
        with patch.object(kernel,'_executable',refused):
            with self.assertRaises(PermissionError) as caught:kernel.descendants(os.getpid())
        self.assertIs(fault,caught.exception);self.assertIsNotNone(kernel._stat(child.pid))

    def test_missing_executable_with_actual_owned_pid_still_alive_is_not_absence(self):
        child=self.child();original=kernel._executable;fault=FileNotFoundError('Declared unavailable executable, actual owned PID still alive')
        def refused(pid):
            if pid==child.pid:raise fault
            return original(pid)
        with patch.object(kernel,'_executable',refused):
            with self.assertRaises(FileNotFoundError) as caught:kernel.process(child.pid)
        self.assertIs(fault,caught.exception);self.assertIsNotNone(kernel._stat(child.pid))

    def test_actual_child_exit_between_original_stat_and_executable_read_is_verified_absent(self):
        child=self.child();original=kernel._executable;exits=[]
        def ended(pid):
            self.assertEqual(child.pid,pid);child.stdin.close();self.assertEqual(0,child.wait(timeout=2))
            exits.append(pid);return original(pid)
        with patch.object(kernel,'_executable',ended):self.assertIsNone(kernel.process(child.pid))
        self.assertEqual([child.pid],exits);self.assertIsNone(kernel._stat(child.pid))

    def test_identity_comparator_refuses_each_changed_actual_tuple_component(self):
        # This is a pure comparison counter over a real stat-derived base.
        # It does not claim to force or observe genuine kernel PID reuse.
        actual=kernel._stat(os.getpid());self.assertIsNotNone(actual)
        self.assertTrue(kernel._same_identity(actual,dict(actual)))
        for key in ('pid','parent','group','session','startTicks'):
            changed=dict(actual);changed[key]+=1
            self.assertFalse(kernel._same_identity(actual,changed),key)
        self.assertFalse(kernel._same_identity(actual,None));self.assertFalse(kernel._same_identity(None,actual))
