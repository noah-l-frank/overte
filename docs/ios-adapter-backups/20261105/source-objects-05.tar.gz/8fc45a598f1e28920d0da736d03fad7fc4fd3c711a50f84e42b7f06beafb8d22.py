"""Source-only audit counters, never a runtime Snapshot/Scene qualification."""
from pathlib import Path
import ast
import unittest

ROOT = Path(__file__).resolve().parents[2]


def tree(relative):
    return ast.parse((ROOT / relative).read_bytes())


def literal_assignment(module, name):
    return next(ast.literal_eval(node.value) for node in module.body
                if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == name for target in node.targets))


class SnapshotMissingOriginalInterfaceSourceTests(unittest.TestCase):
    def test_ordinary_snapshot_component_does_not_advertise_whole_feature(self):
        module = tree('tests/device/ios/adapters/normal_snapshot.py')
        self.assertEqual('NATIVE_UI_COMPONENT_ONLY', literal_assignment(module, 'SCOPE'))
        self.assertEqual({'snapshot.open', 'snapshot.capture', 'snapshot.files', 'snapshot.close'},
                         ast.literal_eval(next(node.value.args[0] for node in module.body
                            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name)
                            and t.id == 'OPERATIONS' for t in node.targets))))
        config = tree('tests/device/ios/adapters/feature_configuration.py')
        self.assertNotIn('snapshots', literal_assignment(config, 'WHOLE_SETTINGS'))
        complete = next(node.value for node in config.body if isinstance(node, ast.Assign)
                        and any(isinstance(t, ast.Name) and t.id == 'COMPLETE_AREAS' for t in node.targets))
        self.assertNotIn('snapshots', ast.literal_eval(complete.args[0]))

    def test_existing_native_capture_row_schema_has_no_frame_camera_relation(self):
        module = tree('tests/device/ios/adapters/snapshot_captures.py')
        fn = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == 'ledger')
        rows = [call for call in ast.walk(fn) if isinstance(call, ast.Call)
                and isinstance(call.func, ast.Name) and call.func.id == 'exact'
                and len(call.args) == 2 and isinstance(call.args[0], ast.Name)
                and call.args[0].id == 'row' and isinstance(call.args[1], ast.Set)]
        capture = [ast.literal_eval(call.args[1]) for call in rows
                   if 'requestId' in ast.literal_eval(call.args[1])]
        self.assertEqual([{'instance', 'requestId', 'bornEpochMs', 'alive', 'state', 'announced'}], capture)

    def test_vulkan_snapshot_operator_loop_remains_comment_not_acquisition(self):
        raw = (ROOT / 'libraries/display-plugins/src/display-plugins/VulkanDisplayPlugin.cpp').read_text()
        start = raw.index('// VKTODO\n        /*{ // If we have any snapshots this frame, handle them')
        end = raw.index('}*/', start)
        body = raw[start:end]
        self.assertIn('_currentFrame->snapshotOperators', body)
        self.assertIn('std::get<0>(snapshotOperator)(getScreenshot', body)
        opengl = (ROOT / 'libraries/display-plugins/src/display-plugins/OpenGLDisplayPlugin.cpp').read_text()
        self.assertIn('std::get<0>(snapshotOperator)(getScreenshot', opengl)


if __name__ == '__main__':
    unittest.main()
