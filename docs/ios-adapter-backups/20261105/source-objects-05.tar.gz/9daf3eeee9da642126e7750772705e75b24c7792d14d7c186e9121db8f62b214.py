"""One authorized stdlib CPython observer counter; no Emote/SUT imports."""
import hashlib,json,os,sys,threading
from pathlib import Path
from observer_only import sensitive_event,ActualExceptionOriginal
ROOT=Path.cwd().resolve(strict=True);assert ROOT.name=='overte-ios-feature-adapters-resume-20261026'
HERE=Path(__file__).resolve().parent;assert HERE.resolve()==HERE and HERE.is_relative_to(ROOT)
def out(name):
 path=HERE/name;assert path.resolve().is_relative_to(ROOT)and path.parent==HERE and not path.exists();return path
real_fstat=os.fstat;real_close=os.close
fd=os.open(out('observer-counter-exception.log'),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
original=ActualExceptionOriginal(HERE/'observer-counter-exception.log',fd)
def fds():
 rows={}
 for p in Path('/proc/self/fd').iterdir():
  try:rows[p.name]=os.readlink(p)
  except FileNotFoundError:pass
 return rows
before=fds();threads=set(threading.enumerate());events=[];checks=[];check_depth=0;maximum=0
state={'mutated':False}
def subject():return 1
def alternate():return 2
code=subject.__code__
def audit(event,args):
 global check_depth,maximum
 if event=='object.__getattr__':events.append(event)
 if not sensitive_event(event):return
 check_depth+=1;maximum=max(maximum,check_depth)
 try:
  checks.append(event)
  if subject.__code__ is not code:raise RuntimeError('Actual observer code identity changed')
 finally:check_depth-=1
sys.addaudithook(audit)
# Real fresh opens cause the relevant audit event; actual __code__ accesses
# generate CPython object.__getattr__ events inside that same callback.
assert Path(__file__).read_bytes();first=len(events);assert first>0 and maximum==1
try:
 subject.__code__=alternate.__code__;state['mutated']=True
 try:Path(__file__).read_bytes()
 except RuntimeError as error:
  assert str(error)=='Actual observer code identity changed'
  original.observe(type(error),error,error.__traceback__)
 else:raise AssertionError('Changed observer code was not refused')
finally:subject.__code__=code
assert Path(__file__).read_bytes()and maximum==1 and original.called
assert fds()==before and set(threading.enumerate())==threads
real_close(fd)
result=dict(status='PASS_CPYTHON_OBSERVER_ONLY',actualObjectGetattrEvents=len(events),sensitiveChecks=len(checks),maximumIdentityCheckDepth=maximum,actualChangedCodeRefused=True,actualExceptionOriginalRetained=True,sourceImports=0,EmoteImports=0,SDK=0,Node=0,network=0,rawRoots=0,FDsUnchangedBeforeClosingOwnObserver=True,newThreads=0)
with out('observer-counter-report.json').open('x')as stream:json.dump(result,stream,indent=2,sort_keys=True);stream.write('\n')
print(json.dumps(result),flush=True)
