"""Pinned prefix, actually executed before the original MP -c/unpickle.

Bootstrap source is trusted physical instrumentation, not disguised as a
fresh delegated module. The target module itself is fresh-source delegated.
"""
from pathlib import Path
import atexit,builtins,hashlib,io,json,os,stat,sys,threading,traceback
B=BOOTSTRAP
assert sys.flags.no_site==1 and sys.dont_write_bytecode and sys.flags.optimize==0
HERE=Path(__file__).resolve().parent;POLICY=Path(B['policyPath'])
assert HERE==Path(B['ownedRoot'])and POLICY==HERE/'approved-inputs.json'
raw=POLICY.read_bytes();assert hashlib.sha256(raw).hexdigest()==B['policyPin']['sha256']
plan=json.loads(raw);assert plan['controllerRoot']==str(HERE)and plan['utilitySelection']=='mp3'
assert B['parent']['pid']==os.getppid()and B['role']in('tracker','actor')
for name in('metadata_reader.py','readonly-shared-stdlib-sources.json','closed_import_origins.py','mp_origin.py','mp_identity.py','mp_command.py','tablet_guarded_spawn.py','tablet_constructor_custody.py'):
    p=HERE/name;before=p.lstat();assert p.resolve(strict=True)==p and before.st_nlink==1
    assert hashlib.sha256(p.read_bytes()).hexdigest()==plan['sourceAndBinaryPins'][str(p)]['sha256']
    assert before==p.lstat()
sys.path.insert(0,str(HERE))
from metadata_reader import pin
from tablet_guarded_spawn import file_pin
from mp_identity import current,fd_row,stat_identity
from mp_command import verify
from mp_origin import Finder
assert file_pin(POLICY)==B['policyPin']and file_pin(Path(__file__))==B['guardPin']
for p,row in plan['sourceAndBinaryPins'].items():assert pin(p)==row
binding=verify(B,POLICY,Path(__file__))
root=Path(B['transportScope']['caseRoot']);assert root.parent==HERE/'own-toys'and root.resolve(strict=True)==root
assert root.name==B['transportScope']['caseName']
finder=Finder(plan['originPlan'],HERE,Path(plan['repositoryRoot']),B);finder.install()
STATE=dict(actualCaseRoot=str(root),actualMode=B['transportScope']['mode'],guardVerifiedBeforeOriginalEntry=True,actualCommand=binding,role=B['role'],unpickleCalls=[],hostileRefusals=[],targetStarted=False,targetReturned=False,errors=[])
report_path=HERE/'child-receipts'/(root.name+'-'+B['role']+'-child.json')
fd=os.open(report_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
report=os.fdopen(fd,'wb',buffering=0);report_identity=fd_row(fd)
def actual_fds():
    result={}
    for entry in Path('/proc/self/fd').iterdir():
        try:result[entry.name]=dict(fd_row(int(entry.name)),target=os.readlink(entry))
        except(FileNotFoundError,ProcessLookupError):pass
    return result
STATE['actualFDsBeforeOriginalEntry']=actual_fds()
original_threads=tuple(threading.enumerate());ports=None;ipc=None;monitor=None;call_tool=None;ready=False
# LIFO registration is real: multiprocessing.util's later _exit_function
# registration runs before this report, including real tracker/actor exit.
def finish():
    global ready
    ready=False
    try:
        STATE['allActualLoadedOrigins']=finder.origins.snapshot('after-original-child-and-finalizers')
        if monitor is not None:STATE['monitorRestoration']=monitor.restore()
        if call_tool is not None:
            sys.monitoring.set_local_events(call_tool,spawn._main.__code__,0)
            sys.monitoring.register_callback(call_tool,sys.monitoring.events.CALL,None)
            sys.monitoring.free_tool_id(call_tool);assert sys.monitoring.get_tool(call_tool)is None
        if ports is not None:STATE['portRestoration']=ports.restore()
        if ipc is not None:
            STATE['ipcRestoration']=ipc.finish();assert not STATE['ipcRestoration']['stillLiveConnections']
        assert tuple(threading.enumerate())==original_threads
        if B['role']=='actor':
            assert STATE['targetStarted']and STATE['targetReturned']and len(STATE['unpickleCalls'])==2
            assert all(row['guardWasReady']is True for row in STATE['unpickleCalls'])
            if B['transportScope']['mode']=='hostile':assert len(STATE['hostileRefusals'])==5
        else:assert STATE.get('trackerOriginalExitCode')==0 and not STATE['unpickleCalls']and not STATE['targetStarted']
        assert not STATE['errors']and file_pin(POLICY)==B['policyPin']
        STATE['status']='PASS'
    except BaseException:STATE['status']='FAIL';STATE['originalFailure']=traceback.format_exc()
    finally:
        STATE['actualFDsAfterOriginalFinalizersBeforeProcessExit']=actual_fds()
        STATE.update(actualKernel=current(),actualReportDescriptor=fd,processLifetimeFDDischargeClaimedInsideChild=False,
            featureQualified=False,helperVariantQualified=False,Node=0,SDK=0)
        assert fd_row(fd)==report_identity
        report.write((json.dumps(STATE,sort_keys=True,indent=2)+'\n').encode());report.close()
atexit.register(finish)
import multiprocessing.connection as connection,multiprocessing.heap as heap,multiprocessing.spawn as spawn
import multiprocessing.resource_tracker as tracker,multiprocessing.popen_spawn_posix as popen,multiprocessing.util as util
import multiprocessing.process as process,multiprocessing.synchronize as synchronize
from tablet_constructor_custody import FunctionBinding,CustodyRefusal
from tablet_ipc_capacity import ActualIPCCapacities
from local_monitor import LocalMonitor
from mp_ports import Ports
ipc=ActualIPCCapacities(connection,tracker,B['actualPassedDescriptors'],B['trackerWriteDescriptor']);ipc.install()
modules=dict(connection=connection,heap=heap,popen=popen,tracker=tracker,spawn=spawn,util=util)
transport=dict(B,protected=[POLICY,*map(Path,plan['sourceAndBinaryPins'])])
from mp_file_scope import install_router
install_router(HERE,Ports)
ports=Ports(HERE,ipc,modules,parent=False,transport=transport);ports.install()
monitor=LocalMonitor();monitor.add(connection.rebuild_connection,returned=lambda frame,value:ipc.register_rebuilt_connection(frame,value))
run_binding=FunctionBinding(process.BaseProcess.run);sem_binding=FunctionBinding(synchronize.SemLock.__setstate__)
def started(frame):
    run_binding.frame(frame);owner=frame.f_locals['self']
    assert process.current_process()is owner and owner._parent_pid==B['parent']['pid']
    target=owner._target;actual=sys.modules['mp_core'].actor
    assert target is actual and type(owner)is __import__('multiprocessing.context',fromlist=['SpawnProcess']).SpawnProcess
    assert owner._args[0][0]==str(root)and owner._args[2]in ipc.connections
    assert len(STATE['unpickleCalls'])==2 and ready
    finder.origins.snapshot('after-original-unpickle-before-real-target')
    STATE['targetStarted']=True
monitor.add(process.BaseProcess.run,start=started,returned=lambda frame,value:STATE.__setitem__('targetReturned',True),
    unwind=lambda frame,error:STATE['errors'].append(dict(type=type(error).__name__,message=str(error))))
def sem_rebuilt(frame,value):
    sem_binding.frame(frame);owner=frame.f_locals['self'];actual=owner._semlock;original=frame.f_locals['state']
    assert actual.name==original[3]
    matches=[row for row in B['transportScope']['actualSemaphores']if row['name']==actual.name];assert len(matches)==1
    row=matches[0];p=Path(row['path']);info=p.lstat()
    assert(info.st_dev,info.st_ino,info.st_mode)==(row['device'],row['inode'],row['mode'])and info.st_uid==os.geteuid()
    STATE['actualRebuiltSemLock']=dict(name=actual.name,device=info.st_dev,inode=info.st_ino,actualOriginalSetstate=True)
monitor.add(synchronize.SemLock.__setstate__,returned=sem_rebuilt)
def tracker_exit(frame,error):
    assert B['role']=='tracker'and type(error)is SystemExit;STATE['trackerOriginalExitCode']=error.code
monitor.add(tracker.main,unwind=tracker_exit);monitor.install()
actual_main=FunctionBinding(spawn._main);actual_load=spawn.reduction.pickle.load
call_tool=next((i for i in range(6)if sys.monitoring.get_tool(i)is None),None);assert call_tool is not None
sys.monitoring.use_tool_id(call_tool,'tablet-mp-variant-before-unpickle')
def before_unpickle(frame,called):
    actual_main.frame(frame);assert called is actual_load and ready and B['role']=='actor'
    stream=frame.f_locals['from_parent'];descriptor=stream.fileno();identity=fd_row(descriptor)
    expected=B['actualPassedDescriptors'][str(descriptor)]
    assert identity==expected and stat.S_ISFIFO(identity['mode'])
    return dict(actualDescriptor=descriptor,identity=identity,guardWasReady=ready,ordinal=len(STATE['unpickleCalls'])+1)
def called(code,offset,fn,arg0):
    if fn is actual_load:STATE['unpickleCalls'].append(before_unpickle(sys._getframe(1),fn))
sys.monitoring.register_callback(call_tool,sys.monitoring.events.CALL,called)
sys.monitoring.set_local_events(call_tool,spawn._main.__code__,sys.monitoring.events.CALL)
def refuses(label,fn):
    assert not ready and not STATE['unpickleCalls']
    try:fn()
    except(AssertionError,ImportError,CustodyRefusal)as error:STATE['hostileRefusals'].append(dict(kind=label,type=type(error).__name__,beforeUnpickle=True))
    else:raise AssertionError('Hostile startup admitted: '+label)
if B['role']=='actor'and B['transportScope']['mode']=='hostile':
    main=sys.modules['__main__'];namespace=vars(main);old_spec=namespace.get('__spec__')
    try:
        namespace['__spec__']=sys.modules['os'].__spec__  # A genuine foreign spec; negative only.
        refuses('actual-command-main-foreign-genuine-spec',lambda:verify(B,POLICY,Path(__file__)))
    finally:namespace['__spec__']=old_spec
    old_alias=sys.modules.get('__mp_main__');had_alias='__mp_main__'in sys.modules
    try:
        sys.modules['__mp_main__']=sys.modules['sys']
        refuses('foreign-genuine-main-alias',lambda:finder.origins.snapshot('hostile-main-alias'))
    finally:
        if had_alias:sys.modules['__mp_main__']=old_alias
        else:sys.modules.pop('__mp_main__',None)
    wrong=dict(B,guardPath=str(POLICY))
    refuses('foreign-bootstrap-path',lambda:verify(wrong,POLICY,Path(__file__)))
    # New own toy source, not an old original or frozen bootstrap. A fresh
    # real spec/source delegate must reject the changed pinned bytes.
    toy=root/'child_negative_source.py';toy.write_bytes(b'VALUE=1\n');toy.chmod(0o600)
    toyplan=dict(plan['originPlan']);toyplan['modules']=dict(toyplan['modules']);toyplan['physicalPins']=dict(toyplan['physicalPins'])
    toyrow=pin(toy);STATE['actualOwnedNegativeSourceOriginal']=toyrow;toyplan['physicalPins'][str(toy)]=toyrow;toyplan['modules']['_mp_owned_negative_source']=dict(path=str(toy),sha256=toyrow['sha256'],package=False)
    toyguard=type(finder.origins)(toyplan,HERE,Path(plan['repositoryRoot']),pin,command_binding=B)
    toy.write_bytes(b'VALUE=2\n');STATE['actualOwnedNegativeSourceAtRefusal']=pin(toy)
    refuses('changed-own-pinned-source-before-execution',lambda:toyguard.file_spec('_mp_owned_negative_source',dict(toyplan['modules']['_mp_owned_negative_source'],loader='source'),'project'))
    toy.write_bytes(b'VALUE=1\n');STATE['actualOwnedNegativeSourceRestoredBytes']=pin(toy)
    assert toy.read_bytes()==b'VALUE=1\n'and pin(toy)['sha256']==toyrow['sha256']
    # Metadata changed genuinely; the abandoned hostile guard is not reused.
    refuses('foreign-actual-frame-before-unpickle',lambda:before_unpickle(sys._getframe(),actual_load))
    assert not STATE['unpickleCalls'];verify(B,POLICY,Path(__file__))
STATE['beforeOriginalEntry']=finder.origins.snapshot('guard-installed-before-original-command-and-unpickle')
ready=True
# Control returns to the retained original startup prefix. It executes the
# actual stdlib command text, including original pickle loads, unchanged.
