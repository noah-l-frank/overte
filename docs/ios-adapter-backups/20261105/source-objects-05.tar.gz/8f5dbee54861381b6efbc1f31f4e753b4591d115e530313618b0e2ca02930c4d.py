"""Root-only future metadata assembly. No subject import or target execution."""
from pathlib import Path
from metadata_reader import pin
from host_common import REPO,head
import argparse,importlib.machinery,json,os,sys
CODE=Path(__file__).resolve().parent
SUBJECT=REPO/'.ios-host-tmp/assets-picker3-reserved-phase-controller22-backend-own-dirfd-source-private-20261104'
SUBJECT_SHA='62c467dccc9ab7d5857ba756a06c81b2b685101fb7f97c767271791f08f0a070'
HELPER='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
CONTROL=('run-nine.py','supervise-nine.py','own9_controls.py','method_custody.py','metadata_reader.py','host_common.py',
 'closed_import_origins.py','readonly-shared-stdlib-sources.json','project-source-inputs.json','exact-nine-selectors.json')
def frozen(folder,name,expected,physical):
 path=folder/name;assert pin(path)['sha256']==expected;physical[str(path)]=pin(path);body=json.loads(path.read_text())
 for leaf,row in body['files'].items():
  assert not Path(leaf).is_absolute()and '..'not in Path(leaf).parts
  p=folder/leaf;assert pin(p)['sha256']==(row if type(row)is str else row['sha256']);physical[str(p)]=pin(p)
 return body

def main():
 parser=argparse.ArgumentParser()
 for name in('source-freeze','root-reviewed-source-freeze','expected-head','peer-freeze','peer-sha','destination'):parser.add_argument('--'+name,required=True)
 args=parser.parse_args();assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
 assert len(args.expected_head)==40 and head()==args.expected_head and args.root_reviewed_source_freeze==args.source_freeze
 physical={};frozen(CODE,'source-freeze.json',args.source_freeze,physical);frozen(SUBJECT,'source-freeze.json',SUBJECT_SHA,physical)
 # The actual independent review is supplied by Root, not guessed here. Pin
 # its genuine frozen members, retain its full bytes, and leave target
 # authorization explicitly separate from this metadata-only operation.
 peer=Path(args.peer_freeze);assert peer.is_absolute()and peer.name=='freeze.json'and peer.is_relative_to(REPO/'.ios-host-tmp')
 frozen(peer.parent,peer.name,args.peer_sha,physical)
 helper=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller10c-copied-bootstrap-namespace-row-code-preparation-20261104'
 frozen(helper,'source-freeze.json','63f5ffc563996ad7793a600cb6a16c53d8df05a54d65db24321a1a2b5c020fc4',physical)
 assert pin(CODE/'closed_import_origins.py')['sha256']==HELPER
 qroot=REPO/'.ios-host-tmp/root-c10c-source-execution-six-cache-mutation-alias-counters-qualified-results-20261104'
 frozen(qroot,'freeze.json','8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a',physical)
 q=json.loads((qroot/'results.json').read_text())
 assert q['actualPassedCases']==q['actualStartedCases']==q['actualOriginalStandardCleanupCalls']==6
 assert q['actualFailedCases']==q['actualUnrunCases']==q['actualCallbackErrors']==0 and q['subjectHelperSha256']==HELPER
 assert all(q[k]is True for k in('sourceExecutionCounterQualified','all27OsCioDupToolsRestored','actualInputAndCliShaUnchanged','twoWholeOwnCensusesEqual','parentFDThreadAndKernelDrain'))
 for row in json.loads((qroot/'actual-receipt-references.json').read_text()).values():
  p=Path(row['path']);assert pin(p)['sha256']==row['sha256'];physical[str(p)]=pin(p)
 declared=json.loads((CODE/'project-source-inputs.json').read_text());modules=declared['modules']
 assert len(modules)==39
 git=(REPO/'.git').read_text();assert git.startswith('gitdir: ')
 gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
 common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
 for p in(REPO/'.git',gd/'HEAD',gd/'index',gd/'commondir'):physical[str(p)]=pin(p)
 ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
 rp=next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs');physical[str(rp)]=pin(rp)
 for name,row in modules.items():
  p=Path(row['path']);assert pin(p)['sha256']==row['sha256'];physical[str(p)]=pin(p)
 # Actual physical namespace parents only. This bounded closure contains no
 # desktop aliases; neither invented paths nor bare fallback names are added.
 namespaces={}
 for name,row in modules.items():
  parts=name.split('.');path=Path(row['path']);directory=path.parent
  # Package files represent their own directory; ordinary files represent it
  # for their immediate dotted parent.
  count=len(parts)if row['package']else len(parts)-1
  for length in range(count,0,-1):
   parent='.'.join(parts[:length])
   if parent not in modules:
    assert directory.is_dir()and directory.resolve(strict=True)==directory
    candidate=namespaces.setdefault(parent,[str(directory)]);assert candidate==[str(directory)]
   directory=directory.parent
 std=Path(os.__file__).resolve(strict=True).parent;suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES);std_namespaces={}
 for current,dirs,names in os.walk(std,topdown=True,followlinks=False):
  folder=Path(current);dirs[:]=sorted(n for n in dirs if n not in('site-packages','dist-packages','__pycache__')and not(folder/n).is_symlink())
  relative=folder.relative_to(std)
  if relative.parts and all(p.isidentifier()for p in relative.parts)and not(folder/'__init__.py').is_file():std_namespaces['.'.join(relative.parts)]=[str(folder)]
  for name in names:
   path=folder/name
   if path.suffix!='.py'and not str(path).endswith(suffixes):continue
   assert path.resolve(strict=True)==path and not path.is_symlink();physical[str(path)]=pin(path)
 python=Path(sys.executable).resolve(strict=True);physical[str(python)]=pin(python)
 assert len(json.loads((CODE/'readonly-shared-stdlib-sources.json').read_text())['sources'])==7
 dest=Path(args.destination);assert dest.is_absolute()and dest.resolve()==dest and dest.parent==REPO/'.ios-host-tmp'and dest.name.startswith('assets-c22-own9-prepared-')and not dest.exists()
 assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
 dest.mkdir(mode=0o700)
 for name in CONTROL:
  path=dest/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
  with os.fdopen(fd,'wb')as stream:stream.write((CODE/name).read_bytes())
  physical[str(path)]=pin(path)
 for name in('metadata_reader','host_common','closed_import_origins','own9_controls','method_custody'):
  path=dest/(name+'.py');assert name not in modules
  modules[name]=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=False)
 origin=dict(modules=modules,namespacePackages=namespaces,thirdPartyModules={},thirdPartyNamespacePackages={},stdlibNamespacePackages=std_namespaces,
  stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=physical[str(python)]),physicalPins=physical)
 cases=json.loads((CODE/'exact-nine-selectors.json').read_text());assert len(cases)==len(set(cases))==9
 plan=dict(status='PRIVATE_ASSETS_C22_DIRFD_OWN9_SOURCE_UNRUN',repositoryRoot=str(REPO),controllerRoot=str(dest),actualPublicHead=args.expected_head,
  sourceFreeze=args.source_freeze,subjectFreeze=SUBJECT_SHA,independentReview=dict(path=str(peer),sha256=args.peer_sha,conclusionNotInferred=True),
  sourceAndBinaryPins=physical,modules=modules,namespaces=namespaces,thirdPartyModules={},originPlan=origin,cases=cases,wallSeconds=30,killGraceSeconds=5,
  pythonExecutable=dict(path=str(python),pin=physical[str(python)]),expectedTemporaryDirectories=9,expectedTemporaryDirectoriesPerCase=1,actualHelperThreadBirths=1,
  PythonChildExecutions=0,NodeExecutions=0,HTTPExecutions=0,UDPExecutions=0,TLSExecutions=0,SDKExecutions=0,overteNativeQueries=0,oldCorpusInputs=0,globalOriginalScans=0,
  subjectHelperSha256=HELPER,subjectActualCopiedPath=str(dest/'closed_import_origins.py'),
  trustedHostBootstrap='Actual pinned initial interpreter/stdlib/controller receivers; selected project/subject modules are fresh C10c delegates. No XML preloading or alias waiver.',
  closedUtilityScopeOnly=True,executionAuthorized=False,rootGeneratedReviewRequiredBeforeTarget=True,C22PhaseAdmission=None,normalAction2Qualified=False,wholeQualified=False,nativeQualified=False)
 path=dest/'approved-inputs.json';fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
 with os.fdopen(fd,'w')as stream:json.dump(plan,stream,indent=2,sort_keys=True);stream.write('\n')
 assert all(pin(path)==row for path,row in physical.items())and head()==args.expected_head
 print(json.dumps(dict(status='METADATA_ONLY_UNRUN_REQUIRES_ROOT_GENERATED_REVIEW',input=str(path),sha256=pin(path)['sha256'],sourcePins=len(physical),modules=len(modules),cases=9,targets=0)))
if __name__=='__main__':main()
