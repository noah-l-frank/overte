"""Approved fixed60 guard/default/collector selection; no typed cache hit."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root=Path.cwd();private=root/'.ios-host-tmp';prefix='snapshot-photos-end-read-area-metadata22-20261027'
names=(
 'test_ios_snapshot_photos_end_read_area.PassiveMutationBarrierTests',
 'test_ios_snapshot_photos_end_read_area.PassiveReadAreaMetadataTests',
 'test_ios_original_file_read_collection.OriginalFileReadCollectionTests',
 'self_tests.test_original_file_reads.FileReadMembershipTests',
 'self_tests.test_original_file_reads.ActualFileReadHookTests.test_actual_private_json_read_records_only_a_successfully_parsed_existing_file',
 'self_tests.test_normal_script_manager.NormalScriptManagerTests.test_private_state_rejects_links_public_permissions_and_concurrent_change',
 'self_tests.test_normal_script_manager.NormalScriptManagerTests.test_nonregular_private_state_is_rejected_before_a_blocking_open',
 'self_tests.test_normal_script_manager.NormalScriptManagerTests.test_actual_load_restart_stop_missing_and_idempotent_cleanup',
)
def pin(path):
 s=path.stat();return dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),stat=[s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns])
def census():
 paths=[p for p in (root/'tests/device').rglob('*') if p.is_file() and p.suffix in ('.py','.js','.cjs','.json','.qml','.html','.h','.cpp','.md') and '__pycache__' not in p.parts]
 paths.append(Path(__file__))
 return {str(p.relative_to(root)):pin(p) for p in sorted(paths)}
before=census();(private/(prefix+'-source-before.json')).write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
print('SOURCE_BEFORE',len(before),'launcherSHA',before[str(Path(__file__).relative_to(root))]['sha256'],flush=True)
task_env=os.environ.copy();task_env.update(TMPDIR=str(private),PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.:tests/device:tests/device/self_tests:tests/device/ios/self_tests')
started=time.monotonic();log=private/(prefix+'.log')
with log.open('w') as stream:result=subprocess.run(['timeout','--signal=TERM','--kill-after=5s','60s','python3','-m','unittest','-v','-f',*names],env=task_env,stdout=stream,stderr=subprocess.STDOUT)
after=census();(private/(prefix+'-source-after.json')).write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
changed=sorted(name for name in set(before)|set(after) if before.get(name)!=after.get(name))
print('ACTUAL_TERMINAL',result.returncode,'elapsed',round(time.monotonic()-started,3),'changedSources',changed,'log',str(log),flush=True)
raise SystemExit(result.returncode if not changed else 98)
