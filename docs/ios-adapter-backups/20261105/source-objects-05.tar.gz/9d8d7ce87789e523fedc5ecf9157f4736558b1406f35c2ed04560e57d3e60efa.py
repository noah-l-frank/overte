"""Bind actual qualified C10d 6+8 receipts; never qualifies an Own9 consumer."""
from pathlib import Path
import json

HELPER='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
SUBJECT='fbcc253aebc8a11883bfebe4ffae10888351337e3e0f4092c477c4550c342f4b'
BOOTSTRAP='ca3dadde214da0b296fc7df3298fa232706db65fd681b4afbcd553fbd97f70a2'
AGGREGATE='fbfffcd6e329efd65d6fbfe84a3e7d535241263046f70f313173b52436d65d2b'
RESULTS='345df0a0c71de9c298cb37b2b5dfc80c52f59c3a233284ec590e77200ac32d46'


def qualify(repo,pin,physical):
    """Only explicit saved files are read; no original-directory census."""
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        value=pin(path)
        if digest is not None:assert value['sha256']==digest
        if str(path)in physical:assert physical[str(path)]==value
        physical[str(path)]=value;return path
    def packet(folder,name,digest):
        folder=Path(folder);path=keep(folder/name,digest);body=json.loads(path.read_text())
        assert type(body['files'])is dict
        for leaf,row in body['files'].items():
            assert not Path(leaf).is_absolute()and '..'not in Path(leaf).parts
            keep(folder/leaf,row if type(row)is str else row['sha256'])
        return body
    root=repo/'.ios-host-tmp/root-c10d-current-helper-baseline6-transaction8-qualified-readiness-20261104'
    packet(root,'freeze.json',AGGREGATE);keep(root/'results.json',RESULTS)
    body=json.loads((root/'results.json').read_text())
    assert body['schemaVersion']==1 and body['status']=='ROOT_QUALIFIED_C10D_CURRENT_HELPER_BASELINE6_AND_GENUINE_TRANSACTION8'
    assert body['helperSha256']==HELPER and body['subjectSourceFreeze']==SUBJECT and body['bootstrapSourceFreeze']==BOOTSTRAP
    assert body['actualCounterCases']==14 and body['actualSeparateFreshProcessGroups']==2 and body['actualExternalGlobalCensusesPerGroup']==3
    assert all(body[n]is True for n in('actualBaseline6Qualified','actualTransaction8Qualified','actualStandardCleanupsQualified','actualWholeRoomsTwiceCensusedPerGroup','historicalProofsAreNotCurrentCompositionQualification'))
    assert body['actualNodeSDKNetworkNativeExecutions']==body['globalCensuses']==body['targets']==0
    assert body['consumerCompositionsQualified']is body['nativeQualified']is body['deviceQualified']is body['wholeQualified']is False
    assert body['historicalC10cHelperPreserved']=='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
    assert body['historicalC10cSourceProofPreserved']=='8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a'
    refs=json.loads((root/'actual-receipt-references.json').read_text());assert len(refs)==141
    for row in refs.values():keep(row['path'],row['sha256'])
    subject=repo/'.ios-host-tmp/chat-controller10d-exact-defused-et-transaction-source-private-20261104'
    bootstrap=repo/'.ios-host-tmp/chat-c10d-baseline6-transaction8-closed-utility-bootstrap1-code-preparation-20261104'
    packet(subject,'source-freeze.json',SUBJECT);packet(bootstrap,'source-freeze.json',BOOTSTRAP)
    keep(subject/'closed_import_origins.py',HELPER);keep(bootstrap/'closed_import_origins.py',HELPER)
    expected_groups=(('baseline6',6,'e8d88ebdc37d5ac5844f5ec8dc9ff77a29d29f781bfb3a7fe515e9c64af4177c'),
        ('transaction8',8,'753c44af4b0621e2f4a4a6ae734bf969a2da92b1d430fd5fee0cc2baaff1959a'))
    assert len(body['groups'])==2;roots=[];ids=[]
    for group,(selection,count,freeze)in zip(body['groups'],expected_groups):
        f=Path(group['rootFreeze']['path']);assert f.name=='freeze.json'and group['rootFreeze']['sha256']==freeze
        packet(f.parent,'freeze.json',freeze);keep(f.parent/'results.json',group['resultsSha256'])
        result=json.loads((f.parent/'results.json').read_text())
        assert result['schemaVersion']==1 and result['utilitySelection']==selection and result['actualTests']==group['actualCases']==count
        assert result['subjectHelperSha256']==HELPER and result['subjectSourceFreeze']==SUBJECT and result['bootstrapSourceFreeze']==BOOTSTRAP
        assert result['actualCaseIds']==group['actualCaseIds']and len(set(group['actualCaseIds']))==count
        assert result['actualSourceOrigins']==group['actualSourceOrigins']and result['newOriginalRoots']==group['originalRoots']
        assert result['RootExternalGlobalCensuses']==3 and result['actualStandardCleanupsQualified']is result['twoCompleteOwnOutputsEqual']is True
        assert result['consumerAdmissionQualified']is result['nativeQualified']is result['deviceQualified']is result['wholeQualified']is False
        assert result['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
        terminal=result['originalSupervisorTerminal'];assert terminal['status']=='PASS'and terminal['childReturnCode']==0 and terminal['caseCount']==count
        assert not terminal['forcedKill']and not terminal['timedOut']and not terminal['problems']and not terminal['orphansRequiredKill']and terminal['fullOwnCensusExclusions']==[]
        for key in('actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allTwoActualRuntimeOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','ownProcessesAbsent','twoFullOwnOutputCensusesEqual'):assert terminal[key]is True
        report=result['actualChildReport'];assert report['status']=='PASS'and report['fatal']is None and report['testsRun']==report['actualCaseReceipts']==count
        for key in('allActualLoadedOriginsAccounted','cleanupEstablished','fdUnchanged','kernelChildrenUnchanged','pinsUnchanged','threadsUnchanged','twoToyCensusesEqual'):assert report[key]is True
        assert report['NodeExecutions']==report['SDKExecutions']==report['overteNativeQueries']==0 and report['realNetwork']is False
        for row in group['actualSourceOrigins'].values():keep(row['path'],row['sha256'])
        if selection=='baseline6':assert result['transaction8Qualified']is False
        else:
            transactions=result['actualOriginalTransactionReceipts'];assert len(transactions)==1
            for row in transactions:
                path=keep(row['path'],row['sha256']);actual=json.loads(path.read_text());assert actual==row['actual']
                assert actual['profile']=='defusedxml-original-single-et-transaction-v1'
                for key in('actualFinallyRestoredCanonicalAndAcceleratorAndPackage','originalCanonicalExecutionPreserved','pureFreshSourceExecuted','pureParseErrorPatchEstablished'):assert actual[key]is True
                assert actual['currentReceiverHistoryAdmission']is actual['productNativeEvidence']is False
        roots.extend(group['originalRoots']);ids.extend(group['actualCaseIds'])
    assert len(roots)==len(set(roots))==6 and roots==body['requiredOriginalRoots']and len(set(ids))==14
    # Current Root external literal guards protect these completed rooms. They
    # are prerequisites, not utility case inputs or write-authorized roots.
    for name in roots:
        path=Path(name);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_dir()and path.is_relative_to(repo/'.ios-host-tmp')
    return dict(aggregate=dict(path=str(root/'freeze.json'),sha256=AGGREGATE,resultsSha256=RESULTS),
        helperSha256=HELPER,subjectSourceFreeze=SUBJECT,bootstrapSourceFreeze=BOOTSTRAP,actualGroups=2,actualCases=14,
        requiredOriginalRoots=roots,consumerCompositionsQualified=False,C22PhaseAdmission=None)
