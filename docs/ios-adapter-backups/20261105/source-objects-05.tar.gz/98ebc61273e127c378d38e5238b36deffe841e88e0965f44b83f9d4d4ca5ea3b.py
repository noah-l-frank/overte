"""One actual Source/Current7/Actor sparse diagnostic; UNRUN."""
from adapters.normal_ui import NativeUIError
from test_lifecycle_publisher_refusal_original_diagnostic_models import LifecyclePublisherRefusalOriginalDiagnosticModels

class LifecycleSparseConnectedOriginalModels(LifecyclePublisherRefusalOriginalDiagnosticModels):
 async def test_actual_post_acquisition_events_and_existing_policy_decisions_are_retained_only_after_original_refusal(self):
  self._capture_sparse_host_phases=True
  await self.test_actual_already_read_publisher_refusal_locals_without_clock_or_phase_reread()
  recorder=self.sparse_host_diagnostic
  if self.publication_refusal_original.written:
   packet=recorder.store.read();self.assertTrue(recorder.completed)
   events=packet['events'];self.assertEqual('acquisition-complete',events[0]['stage'])
   self.assertEqual(list(range(1,len(events)+1)),[row['sequence']for row in events])
   self.assertEqual(sorted(row['hostPerfCounterNs']for row in events),[row['hostPerfCounterNs']for row in events])
   self.assertEqual(1,len({row['threadId']for row in events}))
   self.assertEqual(1,sum(row['stage']=='original-refusal'for row in events))
   self.assertIsNone(recorder.phase.cache.rows.get('not-an-admission-key'))
   self.assertEqual({},recorder.phase.cache.rows);self.assertFalse(recorder.phase.active)
   for row in events:
    if row['stage']in('policy-admitted','memo-allowed'):self.assertIs(type(row['value']),bool)
   with self.assertRaises(NativeUIError):recorder.event(recorder.observer,'publish-latest-enter')
  else:
   self.assertFalse(recorder.completed);self.assertIsNone(recorder.store.read())
