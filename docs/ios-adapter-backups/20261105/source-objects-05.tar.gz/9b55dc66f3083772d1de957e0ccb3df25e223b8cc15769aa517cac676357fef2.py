"""Root-only immutable one-case execution, original180+5 wall/process boundary."""
import json,os,stat,subprocess,sys,time
from pathlib import Path
from guard import pin,sources,first_pass
PREP=Path(__file__).resolve().parent;HERE=Path(sys.argv[1]).resolve()
plan=json.loads((PREP/'plan.json').read_text());REPO=Path(plan['repositoryRoot'])
assert HERE.parent==PREP and HERE.name in ('first1',)and Path.cwd()==REPO and sys.dont_write_bytecode
sources(HERE);first_pass(HERE)
out=HERE/'run';out.mkdir(mode=0o700,exist_ok=False)
def save(name,value):
    fd=os.open(out/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w')as stream:json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())
def process(pid):
    try:row=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except(FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(row[1]),pgid=int(row[2]),sid=int(row[3]),startTicks=int(row[19]))
def remaining(bound):
    rows=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        row=process(int(path.name))
        if row is not None and(row['sid']==bound['pid']or row['pgid']==bound['pid']):rows.append(row)
    return rows
def census():
    root=HERE/'retained'
    return {}if not root.exists()else {str(p):pin(p)for p in (root,*sorted(root.rglob('*')))}
before=sources(HERE);save('source-before.json',before)
command=['timeout','--signal=TERM','--kill-after=5s','180s',sys.executable,'-B',str(PREP/'run-selected.py')]
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',LIFECYCLE_WHOLE_STAGE=str(HERE))
started=time.monotonic()
with(out/'test.log').open('x')as log:
    task=subprocess.Popen(command,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    bound=process(task.pid);assert bound is not None and bound['sid']==bound['pgid']==task.pid
    save('process-binding.json',dict(task=bound,supervisor=process(os.getpid()),command=command));code=task.wait()
left=remaining(bound);assert not left,'Owned process remains; originals must not yet be censused'
after=sources(HERE);save('source-after.json',after);first=census();save('originals-first.json',first)
assert not remaining(bound);second=census();save('originals-second.json',second)
value=dict(exitCode=code,seconds=time.monotonic()-started,sourcePins=len(before),allPinsEqual=before==after,
    retainedOriginalsUnchanged=first==second,remainingOwnedProcesses=remaining(bound),
    retainedFiles=sum(stat.S_ISREG(row['stat'][2])for row in second.values()),wholeFeatureQualified=False,nativeQualified=False)
save('report.json',value);assert before==after and first==second and not value['remainingOwnedProcesses']
raise SystemExit(code)
