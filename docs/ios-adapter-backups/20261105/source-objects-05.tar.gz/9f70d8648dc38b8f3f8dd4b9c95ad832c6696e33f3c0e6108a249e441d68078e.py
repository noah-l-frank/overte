"""Exactly the real shutil fourth-case copy range; no generic keyword waiver."""
from pathlib import Path
from types import BuiltinFunctionType,FunctionType,FrameType
import os,sys,shutil,stat,threading,errno,builtins

class ExactShutilCopyRange:
    def __init__(self,python,python_pin,toys,pin,physical):
        self.source=Path(python);self.source_pin=dict(python_pin);self.toys=Path(toys);self.pin=pin
        self.reader_module=sys.modules[pin.__module__];self.reader_code=pin.__code__;self.reader_globals=pin.__globals__
        assert self.reader_globals is vars(self.reader_module)and self.reader_module.pin is pin
        self.os=os;self.posix=sys.modules['posix'];self.original=os.copy_file_range
        assert type(self.original)is BuiltinFunctionType and self.original.__self__ is self.posix and self.posix.copy_file_range is self.original
        self.fstat=os.fstat;self.readlink=os.readlink;self.frame=sys._getframe;self.ident=threading.get_ident;self.thread=self.ident()
        self.shutil=shutil;self.stdpath=Path(shutil.__file__);self.std_pin=dict(physical[str(self.stdpath)])
        assert pin(self.stdpath)==self.std_pin
        self.builtins=builtins;self.os_error=builtins.OSError;self.errno=errno;self.exdev=errno.EXDEV
        assert type(self.exdev)is int and self.exdev==18
        self.giveup=shutil._GiveupOnFastCopy;self.giveup_mro=self.giveup.__mro__
        assert self.giveup_mro[1]is builtins.Exception and '__init__'not in vars(self.giveup)and '__new__'not in vars(self.giveup)
        self.lseek=os.lseek
        self.functions=tuple((name,vars(shutil)[name],vars(shutil)[name].__code__,vars(shutil)[name].__globals__,vars(shutil)[name].__defaults__,vars(shutil)[name].__kwdefaults__,vars(shutil)[name].__closure__)for name in('copyfile','_fastcopy_copy_file_range','_determine_linux_fastcopy_blocksize','_fastcopy_sendfile','copyfileobj'))
        assert all(type(fn)is FunctionType and namespace is vars(shutil)and closure is None for name,fn,code,namespace,defaults,keywords,closure in self.functions)
        self.function_values=tuple((tuple(fn.__defaults__ or()),tuple((fn.__kwdefaults__ or{}).items()))for name,fn,code,namespace,defaults,keywords,closure in self.functions)
        self.boundary=None;self.module=None;self.children=None;self.closed=False;self.calls=0;self.returned_bytes=0;self.original_errors=0;self.error_records=[];self.last=None
        self.members=tuple((name,member,fn,fn.__code__,fn.__globals__)for name,member in vars(type(self)).items()for fn in(member.__func__ if type(member)is staticmethod else member,)if type(fn)is FunctionType)
    @staticmethod
    def meta(info):
        return dict(device=info.st_dev,inode=info.st_ino,mode=info.st_mode,uid=info.st_uid,gid=info.st_gid,nlink=info.st_nlink,bytes=info.st_size,mtimeNs=info.st_mtime_ns,ctimeNs=info.st_ctime_ns)
    def bind(self,boundary):
        assert self.boundary is None and boundary.copy_file_range_gate is self
        self.boundary=boundary;self.mutate=type(boundary).__dict__['mutate'];self.mutate_code=self.mutate.__code__;self.mutate_globals=self.mutate.__globals__
    def bind_subject(self,module,children):
        assert self.module is None
        self.module=module;self.cls=module.MovingProcessObservationTests;self.name='test_actual_live_deleted_executable_remains_original_error_not_zombie_or_absence'
        self.method=vars(self.cls)[self.name];self.code=self.method.__code__;self.globals=self.method.__globals__;self.children=children
        assert self.globals is vars(module)
    def check(self):
        assert not self.closed and self.ident()==self.thread
        assert sys.modules['posix']is self.posix and self.posix.copy_file_range is self.original and self.original.__self__ is self.posix
        assert os is self.os and os.fstat is self.fstat and os.readlink is self.readlink and sys._getframe is self.frame and threading.get_ident is self.ident
        assert self.reader_module.pin is self.pin and self.pin.__code__ is self.reader_code and self.pin.__globals__ is self.reader_globals is vars(self.reader_module)
        assert sys.modules['shutil']is self.shutil and shutil.os is os and Path(shutil.__file__)==self.stdpath and self.pin(self.stdpath)==self.std_pin
        assert sys.modules['builtins']is self.builtins and self.builtins.OSError is self.os_error
        assert sys.modules['errno']is self.errno and errno.EXDEV==self.exdev==18
        assert shutil.errno is self.errno and os.lseek is self.lseek
        assert shutil._GiveupOnFastCopy is self.giveup and self.giveup.__mro__ is self.giveup_mro
        assert '__init__'not in vars(self.giveup)and '__new__'not in vars(self.giveup)
        for name,fn,code,namespace,defaults,keywords,closure in self.functions:
            assert vars(shutil)[name]is fn and fn.__code__ is code and fn.__globals__ is namespace is vars(shutil)
            assert fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords and fn.__closure__ is closure
        for (name,fn,code,namespace,defaults,keywords,closure),(values,items)in zip(self.functions,self.function_values):
            assert len(fn.__defaults__ or())==len(values)and all(a is b for a,b in zip(fn.__defaults__ or(),values))
            assert tuple(fn.__kwdefaults__ or())==tuple(key for key,value in items)and all(fn.__kwdefaults__[key]is value for key,value in items)
        for name,member,fn,code,namespace in self.members:
            assert vars(type(self))[name]is member and fn.__code__ is code and fn.__globals__ is namespace
        assert self.boundary is not None and self.boundary.copy_file_range_gate is self and self.boundary.original['copy_file_range']is self.original
        assert type(self.boundary).__dict__['mutate']is self.mutate and self.mutate.__code__ is self.mutate_code and self.mutate.__globals__ is self.mutate_globals
        self.boundary._check()
    def descriptors(self,source_fd,output_fd,expected):
        assert self.pin(self.source)==self.source_pin
        assert self.readlink('/proc/self/fd/'+str(source_fd))==str(self.source)
        assert self.meta(self.fstat(source_fd))=={key:value for key,value in self.source_pin.items()if key!='sha256'}
        assert self.boundary.fd(output_fd)==expected
        result=self.fstat(output_fd)
        assert stat.S_ISREG(result.st_mode)and result.st_nlink==1 and result.st_uid==os.geteuid()
        assert self.readlink('/proc/self/fd/'+str(output_fd))==str(expected)
        return result.st_dev,result.st_ino,result.st_mode,result.st_uid,result.st_gid
    def copy(self,boundary,*args,**kwargs):
        self.check();assert boundary is self.boundary and self.module is not None
        assert len(args)==3 and all(type(value)is int for value in args)and args[0]>=0 and args[1]>=0 and args[0]!=args[1]and args[2]>0
        assert set(kwargs)=={'offset_dst'}and type(kwargs['offset_dst'])is int and kwargs['offset_dst']>=0
        mutation=self.frame(1);port=mutation.f_back;fast=port.f_back;copy=fast.f_back;test=copy.f_back
        assert all(type(value)is FrameType for value in(mutation,port,fast,copy,test))
        assert mutation.f_code is self.mutate_code and mutation.f_globals is self.mutate_globals and mutation.f_locals['self']is boundary and mutation.f_locals['name']=='copy_file_range'
        wrapper=boundary.ports['copy_file_range'];assert port.f_code is wrapper.__code__ and port.f_globals is wrapper.__globals__ and port.f_locals['self']is boundary and port.f_locals['_name']=='copy_file_range'
        assert fast.f_code is self.functions[1][2]and fast.f_globals is self.functions[1][3]
        assert copy.f_code is self.functions[0][2]and copy.f_globals is self.functions[0][3]
        assert self.module.MovingProcessObservationTests is self.cls and vars(self.cls)[self.name]is self.method and self.method.__code__ is self.code and self.method.__globals__ is self.globals
        assert test.f_code is self.code and test.f_globals is self.globals and type(test.f_locals['self'])is self.cls and test.f_locals['self']is self.children.current_case
        expected=test.f_locals['path'];assert type(expected)is type(self.source)and expected.name=='owned-original-python'
        assert expected.resolve(strict=True)==expected and expected.parent.parent==self.toys and expected.parent==Path(test.f_locals['temporary'])
        assert copy.f_locals['src']is self.module._CONTEXT['python']and copy.f_locals['dst']is expected and copy.f_locals['follow_symlinks']is True
        assert fast.f_locals['fsrc']is copy.f_locals['fsrc']and fast.f_locals['fdst']is copy.f_locals['fdst']
        assert args==(fast.f_locals['infd'],fast.f_locals['outfd'],fast.f_locals['blocksize'])and kwargs['offset_dst']==fast.f_locals['offset']
        assert Path(copy.f_locals['src'])==self.source
        before=self.descriptors(args[0],args[1],expected);self.calls+=1
        try:
            result=self.original(*args,**kwargs);self.returned_bytes+=result;return result
        except BaseException as original:
            self.original_errors+=1
            actual_errno=original.errno if type(original)is self.os_error else None
            self.error_records.append(dict(type=type(original).__module__+'.'+type(original).__qualname__,errno=actual_errno,
                callOrdinal=self.calls,offsetDestination=kwargs['offset_dst'],actualSyscallBytesBefore=self.returned_bytes,
                exactOriginalFirstEXDEV=type(original)is self.os_error and actual_errno==self.exdev
                    and self.calls==1 and kwargs['offset_dst']==0 and self.returned_bytes==0))
            raise # SAME original error reaches SAME original shutil fallback; no helper fallback.
        finally:
            assert self.descriptors(args[0],args[1],expected)==before
            self.check();self.last=dict(source=str(self.source),output=str(expected),offsetDestination=kwargs['offset_dst'],count=args[2],sourceFD=args[0],outputFD=args[1],outputDevice=before[0],outputInode=before[1])
    def release(self):
        self.check();self.closed=True
        return dict(status='ACTUAL_STRICT_SHUTIL_COPY_PORT_RETIRED',calls=self.calls,returnedBytes=self.returned_bytes,originalErrors=self.original_errors,originalErrorRecords=list(self.error_records),last=self.last,closed=True,OSAliasesReplaced=False,newFallbackImplemented=False,baseAllOtherPortsUnchanged=True)
