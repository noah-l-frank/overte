"""Actual historical22 +same-helper smoke; no successful prefix replay."""
import ast,hashlib,json,stat
from pathlib import Path
from prior_scoped_prerequisite import historical as prior_historical,allpins as prior_allpins,delta,cleanup,exited
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def allpins(master):
 pins=json.loads((master/'actual-history-current-pins.json').read_text())
 for name,expected in pins.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();v=dict(stat=[getattr(a,k) for k in F]);assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode)
  if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
  assert v==expected and v['stat']==[getattr(p.lstat(),k) for k in F]
 return [Path(name) for name in pins]
def historical(master,repo):
 plan=json.loads((master/'scope-plan.json').read_text());prior=Path(plan['priorMaster']);a,paths=prior_historical(prior,repo)
 assert json.loads((prior/'root-scoped19-report.json').read_text())==a;paths+=[prior/'root-scoped19-report.json'];paths+=allpins(master);paths+=delta(plan,repo)
 stage=Path(plan['oldStage']);out=stage/'root-run-first';r=json.loads((out/'report.json').read_text());assert r['exitCode']==1 and r['retainedFiles']==9 and all(r[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not r['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=1,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 a=json.loads((stage/'terminal-census-1.json').read_text());b=json.loads((stage/'terminal-census-2.json').read_text());assert a==b and a['threads']==a['pendingTasks']==a['sdkModules']==[] and a['children']==''
 selected=json.loads((stage/'selected-result.json').read_text());assert selected['selectedIds']==plan['newScopedCases']+plan['tail'] and selected['testsRun']==4 and not selected['successful'] and selected['errorCount']==1 and selected['failureCount']==selected['skippedCount']==0
 lines=(out/'first.log').read_text().splitlines();outcomes=[]
 for i,case in enumerate(plan['newScopedCases']+[plan['failedCase']],1):
  expected=case.rsplit('.',1)[1]+' ('+case+') ... '+('ERROR' if case==plan['failedCase'] else 'ok');assert lines.count(expected)==1;outcomes.append(expected);cleanup(stage,i,case)
 assert len(plan['unchangedPrefix'])==22 and plan['unchangedPrefix']==json.loads((prior/'scope-plan.json').read_text())['unchangedPrefix']+plan['newScopedCases']
 prior_allpins(prior);allpins(master)
 return dict(status='ACTUAL_HISTORICAL_SCOPED22_PASS',scopedCases=plan['unchangedPrefix'],priorScoped19Preserved=True,oldAggregate27Passed=False,oldAggregate27TerminalPresent=False,tail8AggregatePassed=False,tail8AggregateTerminalPresent=True,tail8ActualPerCaseCensuses=4,tail8OriginalFiles=9,actualTailOutcomeLines=outcomes,currentRawPinsExact=True,originalProcessAbsent=True,helperSha256=plan['helperSha256'],unchangedPrefixTestAST=True),paths

def require(here,repo,current=None):
 master=here.parent;plan=json.loads((master/'scope-plan.json').read_text());actual,paths=historical(master,repo)
 assert json.loads((master/'root-scoped22-report.json').read_text())==actual;paths.append(master/'root-scoped22-report.json')
 assert sha(repo/plan['testPath'])==plan['newTestSha256']
 prior=Path(plan['priorMaster']);pplan=json.loads((prior/'scope-plan.json').read_text());smoke=Path(pplan['smokeStage']);out=smoke/'root-run-first';r=json.loads((out/'report.json').read_text())
 assert r['exitCode']==0 and r['retainedFiles']==0 and all(r[k] for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged')) and not r['remainingOwnedProcesses']
 assert json.loads((out/'thread-report.json').read_text())==dict(exitCode=0,remainingNewThreads=[])
 assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
 assert json.loads((out/'originals-first.json').read_text())==json.loads((out/'originals-second.json').read_text());exited(out)
 ids=json.loads((smoke/'run-plan.json').read_text())['cases'];a=json.loads((smoke/'selected-result.json').read_text());assert len(ids)==1 and a['selectedIds']==ids and a['successful'] and a['testsRun']==1 and not any(a[k] for k in ('failureCount','errorCount','skippedCount'));cleanup(smoke,1,ids[0])
 old=json.loads((out/'root-source-map.json').read_text());assert old['repositoryRoot']==str(repo) and old['currentSourcePins'][plan['testPath']]==pplan['oldTestSha256']
 adjusted=dict(old['currentSourcePins']);adjusted[plan['testPath']]=plan['newTestSha256']
 if current is not None:assert current['currentSourcePins']==adjusted
 for name,digest in adjusted.items():
  p=repo/name;assert p.is_relative_to(repo) and p.resolve(strict=True)==p and sha(p)==digest
 prior_allpins(prior);allpins(master)
 return paths+[master/'scope-plan.json',master/'actual-history-current-pins.json',master/'prior_scoped_prerequisite.py']
