"""Root-only bounded RAISE diagnostics with exact numeric original join coordinates; no generic locals or returns."""
import json,os,sys
from pathlib import Path

def begin(here,repo):
    monitoring=sys.monitoring;event=monitoring.events.RAISE
    selected={str(repo/path) for path in ('tests/device/ios/pymobiledevice3_wda_xctest.py',
        'tests/device/ios/adapters/lifecycle_touch_resource_owner.py','tests/device/ios/adapters/lifecycle_world_hold.py',
        'tests/device/ios/adapters/bundle_observation.py','tests/device/ios/adapters/installed_code.py',
        'tests/device/ios/adapters/installed_adapter.py','tests/device/ios/adapters/feature_observation.py',
        'tests/device/adapters/native_feature_observation.py','tests/device/ios/adapters/bundle_identity.py')}
    helper=str(repo/'tests/device/adapters/native_feature_observation.py')
    validators={str(repo/path) for path in ('tests/device/adapters/native_clock_join.py',
        'tests/device/ios/adapters/native_geometry.py','tests/device/ios/adapters/keyboard_source.py',
        'tests/device/ios/adapters/lifecycle_world.py')}
    frame_paths=selected|validators
    free=[i for i in (4,3,5) if monitoring.get_tool(i) is None]
    if not free:raise RuntimeError('No private monitoring tool ID available')
    tool=free[0];name='overte-canonical-installed-private-raise-only';state=dict(tool=tool,name=name,records=0,dropped=0,writeFailures=0)
    destination=here/'actual-source-raise-events-first.jsonl'
    if destination.exists():raise RuntimeError('Original raise diagnostics already exist')
    descriptor=os.open(destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.close(descriptor)
    def raised(code,offset,error):
        if type(error) in (StopIteration,StopAsyncIteration):return None
        if code.co_filename not in selected and not (code.co_filename==helper and code.co_name=='need'):return None
        frame=None
        try:
            frame=sys._getframe(1)
            if frame.f_code is not code:return None
            frames=[];count=0;join_coordinates=[]
            while frame is not None and count<32:
                current=frame.f_code
                if current.co_filename in frame_paths:
                    frames.append(dict(file=current.co_filename,line=frame.f_lineno,function=current.co_qualname))
                if current.co_filename==str(repo/'tests/device/adapters/native_clock_join.py') and current.co_name=='validate_join':
                    record=frame.f_locals.get('record')
                    if type(record) is dict:
                        keys=('hostBeforeEpochMs','hostAfterEpochMs','hostBeforeMonotonic','hostAfterMonotonic')
                        coordinates={key:record.get(key) for key in keys}
                        coordinates['native']=[]
                        for key in ('nativeBefore','nativeAfter'):
                            packet=record.get(key)
                            if type(packet) is dict:
                                coordinates['native'].append({key:packet.get(key) for key in ('processId','instance','sequence','requestId','capturedEpochMs','lifecycle')})
                        join_coordinates.append(coordinates)
                frame=frame.f_back;count+=1
            if not any(row['file'] in selected for row in frames):return None
            if state['records']>=512:state['dropped']+=1;return None
            line=next((value for start,end,value in code.co_lines() if start<=offset<end),None)
            value=dict(sequence=state['records']+1,event='RAISE',originFile=code.co_filename,originFunction=code.co_qualname,
                originLine=line,instructionOffset=offset,exceptionType=type(error).__module__+'.'+type(error).__qualname__,
                selectedOriginalFrames=frames,exactOriginalJoinCoordinates=join_coordinates)
            raw=(json.dumps(value,sort_keys=True,separators=(',',':'))+'\n').encode('utf-8')
            fd=os.open(destination,os.O_WRONLY|os.O_APPEND|os.O_NOFOLLOW)
            try:
                view=memoryview(raw)
                while view:view=view[os.write(fd,view):]
            finally:os.close(fd)
            state['records']+=1
        except BaseException:
            # Diagnostic failure is recorded separately, never changes the
            # original exception/result/owned worker or source clocks.
            state['writeFailures']+=1
        finally:frame=None
        # CPython RAISE is GLOBAL; returning DISABLE is explicitly invalid.
        return None
    monitoring.use_tool_id(tool,name)
    try:
        if monitoring.get_events(tool)!=0:raise RuntimeError('Fresh owned tool has active events')
        monitoring.register_callback(tool,event,raised);monitoring.set_events(tool,event)
    except BaseException:
        monitoring.set_events(tool,0);monitoring.register_callback(tool,event,None);monitoring.free_tool_id(tool);raise
    return state

def finish(here,state):
    monitoring=sys.monitoring;tool=state['tool']
    if monitoring.get_tool(tool)!=state['name']:raise RuntimeError('Owned monitoring tool changed')
    try:
        monitoring.set_events(tool,0);monitoring.register_callback(tool,monitoring.events.RAISE,None)
    finally:monitoring.free_tool_id(tool)
    if monitoring.get_tool(tool) is not None:raise RuntimeError('Owned monitoring tool remains')
    value=dict(state,ownedToolFreed=True,sourceFlagsChanged=False,qualification=False,
        events='GLOBAL RAISE only; exact numeric join argument coordinates only, no generic locals/messages/return/line/call hooks',
        nonselected='returnNone; DISABLE is invalid for global RAISE per official CPython3.14 docs')
    fd=os.open(here/'actual-source-raise-summary-first.json',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as output:json.dump(value,output,indent=2);output.write('\n');output.flush();os.fsync(output.fileno())
    if state['writeFailures'] or state['dropped']:raise RuntimeError('Original source diagnostics incomplete')
