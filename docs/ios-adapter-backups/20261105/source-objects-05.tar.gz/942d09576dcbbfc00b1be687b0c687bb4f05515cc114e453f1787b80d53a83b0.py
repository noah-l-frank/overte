"""Original Emote supervisor owns its old-corpus window; Root closes whole outputs."""
from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys,traceback
R=Path.cwd().resolve();B=R/'.ios-host-tmp';S=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(n,x):
 with(OUT/n).open('x')as f:json.dump(x,f,sort_keys=True,indent=2);f.write('\n')
 (OUT/n).chmod(0o600)
assert sys.flags.no_site and sys.dont_write_bytecode and len(sys.argv)==4 and sys.argv[1]==sha(S/'source-freeze.json')
CP=Path(sys.argv[2]);assert CP.is_absolute()and CP.resolve(strict=True)==CP and CP.is_relative_to(B)and sha(CP)==sys.argv[3]
config=load(CP);assert config['schemaVersion']==1 and config['status']=='ROOT_REVIEWED_B15_ONE_ORIGINAL_POSITIVE_CURRENT1039_UNRUN'
H=Path(config['input']).parent;O=H.with_name(H.name+'-outer');OUT=Path(config['output'])
assert H.parent==OUT.parent==B and H.name=='emote-callback-source3-one-positive-prepared-root1039-headd483-b15-20261105'
assert config['driverSourceFreeze']==sys.argv[1] and config['scriptSha256']==sha(Path(__file__))
assert sha(Path(__file__))==load(S/'source-freeze.json')['files']['run.py']['sha256']
p=H/'approved-inputs.json';digest=config['inputSha256'];assert sha(p)==digest
plan=load(p);assert plan['rootAdmission']['kernelOwn6Proof']['sha256']=='4e68d118b40fd5c32edf49fbee10b42a1fab142d875947faa79c68851cd9976d'
assert plan['expectedHead']==config['expectedHead'] and plan['oldRootCount']==1039 and plan['wallSeconds']==300 and plan['killGraceSeconds']==5 and len(plan['cases'])==1
assert not O.exists()and not(H/'temporary').exists()and not OUT.exists()
review=Path(config['generatedInputReview']);assert review.parent==B and sha(review/'freeze.json')==config['generatedInputReviewFreeze']
freeze=load(review/'freeze.json')
for n,v in freeze['files'].items():assert sha(review/n)==v['sha256']
assert load(review/'review.json')['inputSha256']==digest
ad=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(ad)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(ad))['census']
OUT.mkdir(mode=0o700);put('attempt.json',dict(input=str(p),inputSha256=digest,oldRoots=1039,originalSupervisorOwnsBeforeAndTwoAfterGlobalWindows=True,externalRootAddsNoDuplicateOldCorpusWindow=True,original300Plus5CapsUnchanged=True))
try:
 with(OUT/'supervisor-stdout.log').open('xb')as stdout,(OUT/'supervisor-stderr.log').open('xb')as stderr:
  result=subprocess.run([sys.executable,'-S','-B',str(H/'supervise.py'),'--approved-inputs-sha',digest],cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
 terminal=load(O/'terminal.json');checks=terminal['checks'];assert checks['ownedProcessesAbsent']is True
 birth_receipt=load(O/'actual-runner-birth.json');birth=birth_receipt['birth']
 full=birth_receipt['immutableFullIdentity'];assert all(birth[k]==full[k]for k in('pid','parent','group','startTicks'))and full['session']==birth['group']
 # Missing original resource receipts stay missing and never qualify a case.
 # Independently confirm actual kernel absence even for a pre-case failure.
 resource_path=H/'child-receipts/actual-resources.json'
 resource=load(resource_path) if resource_path.is_file() else None
 observed=terminal['actualObservedDescendants']
 identities=[birth]+list(observed.values())
 if resource is not None:identities += [row['birth']for row in resource['nodes']if type(row.get('birth'))is dict]
 assert type(birth['group']) is int and birth['group']>0
 same_group=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdecimal():continue
  try:raw=(proc/'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  values=raw[raw.rfind(')')+2:].split()
  if int(values[2])==birth['group'] or int(values[3])==birth['group']:
   same_group.append(dict(pid=int(proc.name),group=int(values[2]),session=int(values[3]),startTicks=int(values[19])))
 assert not same_group,'Original process group/session remains; no quiet close'
 put('actual-root-kernel-absence.json',dict(originalBirth=birth,actualObservedDescendants=observed,originalResourceLedgerAvailable=resource is not None,checkedIdentities=identities,actualSameGroupOrSession=same_group,originalResourceQualificationGranted=False))
 for ident in identities:
  try:raw=Path('/proc',str(ident['pid']),'stat').read_text()
  except(FileNotFoundError,ProcessLookupError):continue
  assert int(raw[raw.rfind(')')+2:].split()[19])!=ident['startTicks'],'Original owned process remains'
 before=load(O/'global-before.json');after1=load(O/'global-after-first.json');after2=load(O/'global-after-second.json')
 context_path=Path(config['context'])
 assert sha(context_path)==config['contextSha256']
 context=load(context_path)
 for row in context['globalCustody'].values():assert sha(row['path'])==row['sha256']
 expected=load(context['globalCustody']['baseline']['path']);assert len(before)==1039 and before==expected
 original_posts=(after1 is not None and after2 is not None)
 root_post_scans=0
 if original_posts:
  assert after1==after2 and set(after1)==set(before)|{str(H/'temporary')}
  assert all(after1[name]==value for name,value in before.items())
 else:
  # A failure may correctly withhold internal quiet posts for unknown Node
  # lineage. Only after independent original process/group/session absence,
  # Root closes unchanged OLD originals, without fabricating child admission.
  helper=Path(context['globalCustody']['helper']['path']);assert sha(helper)=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
  current=runpy.run_path(str(helper))['current'];root1=current();root2=current();root_post_scans=2
  put('independent-global-after-first.json',root1);put('independent-global-after-second.json',root2)
  assert root1==root2 and set(root1)==set(expected)|{str(H/'temporary')}
  assert all(root1[name]==value for name,value in expected.items())
  assert root1[str(H/'temporary')]==census(H/'temporary')
 put('actual-global-window-scope.json',dict(originalBeforeUnchanged=True,originalPostsPresent=original_posts,
     independentRootPostScans=root_post_scans,allOldOriginalsLiteral=True,missingChildLineageNeverPromoted=True))
 roots=[H,H/'temporary',O];first={str(root):census(root)for root in roots};second={str(root):census(root)for root in roots};assert first==second
 put('whole-first.json',first);put('whole-second.json',second)
 put('terminal.json',dict(status='ROOT_ORIGINAL_EMOTE_ONE_PASS_CLOSED'if result.returncode==0 and terminal['status']=='PASS'else'ROOT_ORIGINAL_EMOTE_ONE_FAILURE_CLOSED',originalSupervisorReturnCode=result.returncode,originalSupervisorTerminal=terminal,actualOriginalThreeGlobalCensusesJoined=original_posts,independentRootPostGlobalScans=root_post_scans,all1039OldOriginalBodiesUnchanged=True,wholeHEREAndOuterTwiceEqual=True,ownProcessesAbsent=True,newOriginalRoots=[str(root)for root in roots]+[str(OUT)],nativeQualified=False,wholeQualified=False))
except BaseException:
 put('unqualified-partial.json',dict(status='NO_TERMINAL_QUALIFICATION_INFERRED',traceback=traceback.format_exc(),attemptedOriginalRoots=[str(H),str(H/'temporary'),str(O),str(OUT)]));raise
put('freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in sorted(OUT.iterdir())}))
print(json.dumps(dict(status=load(OUT/'terminal.json')['status'],freeze=sha(OUT/'freeze.json'))),flush=True)
raise SystemExit(0 if result.returncode==0 and terminal['status']=='PASS'else 1)
