"""Capture-local identity of the actual immutable marker/image interpretation.

Reuse the existing closed parser tokens and JSON/PNG policy. Follow only
referenced global/builtin/attribute bindings of the actual reader functions;
unrelated live input transports never become cached interpretation. No target
module is imported by the fingerprint. Unknown policies take the cold archive.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import dis
import sys
import contextlib
import abc
from abc import ABCMeta
from types import GetSetDescriptorType,MemberDescriptorType,WrapperDescriptorType
from types import FunctionType,CodeType,ModuleType
from ios.adapters import emote_callback_live_records as tokens


class AvatarSampleReturnLiteral:
    LIMIT=4096
    def __init__(self,roots):
        self.roots=tuple(roots);self.references=[];self.unsupported=None;self.unsupportedDetails=None
        # Keep the fingerprint engine itself fixed while comparing a policy.
        self.engines=tuple((container,name,getattr(container,name),getattr(container,name).__code__)
            for container,name in ((tokens,'_token'),(tokens,'_png_policy'),(tokens,'_parser_global_bindings'),
                (tokens,'_namedtuple_policy'),(dis,'get_instructions'),
                (type(self),'signature'),(type(self),'literal'),(type(self),'reader_token')))
        self.engine_globals=[]
        try:
            for _container,_name,function,_code in self.engines:
                for name in sorted(set(function.__code__.co_names)&function.__globals__.keys()):
                    if name=='__builtins__':continue
                    value=function.__globals__[name]
                    self.engine_globals.append((function.__globals__,name,value,self.reader_token(value,self.references)))
        except (AttributeError,TypeError,ValueError,RecursionError,tokens._Unsupported) as error:
            self.unsupportedDetails=dict(exceptionType=type(error).__name__,kind=getattr(error,'kind',None),reason=getattr(error,'reason',None));self.unsupported=('fingerprint-engine','unsupported-binding');self.policy=None;return
        self.policy=self.signature(self.references)

    @staticmethod
    def reader_token(value,references):
        # Only the exact already-loaded stdlib context manager classes used by
        # ScriptSourceLock.held. Their ABCMeta is not a generic object waiver:
        # every namespace/basis and method code on the original MRO is bound.
        if type(value) is ABCMeta and (value is contextlib._GeneratorContextManager or value is contextlib.AbstractContextManager):
            references.append(value);rows=[]
            for base in value.__mro__:
                references.extend((base,base.__bases__))
                if base is object:continue
                if base.__module__!='contextlib' and base is not abc.ABC:raise tokens._Unsupported(type(base),'context-manager-mro')
                fields=[]
                for name,item in sorted(vars(base).items()):
                    if name=='_abc_impl' or type(item) in (GetSetDescriptorType,MemberDescriptorType,WrapperDescriptorType):
                        references.append(item);part=('stdlib-class-internal-binding',id(item))
                    else:part=tokens._token(item,references,set())
                    fields.append((name,part))
                rows.append((id(base),tuple(id(parent) for parent in base.__bases__),tuple(fields)))
            return ('closed-stdlib-context-class',id(value),tuple(rows))
        return tokens._token(value,references,set())

    def signature(self,references):
        rows=[];seen=set();location=None
        def token(value):return self.reader_token(value,references)
        missing=object()
        def lookup(container,name):
            namespaces=(vars(container),) if type(container) is ModuleType else tuple(vars(base) for base in container.__mro__)
            for namespace in namespaces:
                if name in namespace:
                    value=namespace[name]
                    return value.__func__ if type(value) in (staticmethod,classmethod) else value
            return missing
        def code_bindings(code,namespace,builtins):
            # Nested code uses the same defining globals. Imports are observed
            # only in the already-loaded module registry; no import executes.
            imported=None;import_name=None
            for instruction in dis.get_instructions(code):
                if instruction.opname=='IMPORT_NAME':
                    name=instruction.argval;import_name=name;imported=sys.modules.get(name)
                    rows.append(('import-binding',name,None if imported is None else token(imported)))
                elif instruction.opname=='IMPORT_FROM' and imported is not None:
                    name=instruction.argval;item=vars(imported).get(name,missing)
                    # Python may resolve a loaded from-package submodule even
                    # when the package has no explicit attribute binding.
                    fallback=sys.modules.get(import_name+'.'+name)
                    rows.append(('import-from-binding',id(imported),name,
                        ('missing',) if item is missing else token(item),token(fallback)))
                    if item is not missing:walk(item,set(code.co_names))
                    if fallback is not None:walk(fallback,set(code.co_names))
            names=set(code.co_names)
            for name in sorted(names):
                if name in namespace:
                    value=namespace[name];rows.append(('global',id(namespace),name,token(value)));walk(value,names)
                elif name in builtins:rows.append(('builtin',name,token(builtins[name])))
            for value in code.co_consts:
                if type(value) is CodeType:code_bindings(value,namespace,builtins)
        def walk(value,attributes=()):
            nonlocal location
            identity=id(value)
            # Every actual attribute binding participates per use, even when
            # its container has already been visited through another alias.
            if type(value) is ModuleType or type(value) is type and value.__module__.startswith(('adapters.','ios.adapters.','feature_journeys.')):
                for name in sorted(set(attributes)):
                    item=lookup(value,name)
                    if item is missing:continue
                    rows.append(('attribute',identity,name,token(item)));walk(item)
            if identity in seen:return
            seen.add(identity)
            if len(seen)>self.LIMIT:raise tokens._Unsupported(type(value),'sample-reader-graph-limit')
            references.append(value);location=(type(value).__module__,getattr(value,'__qualname__',None))
            rows.append(('value',identity,token(value)))
            if type(value) is ModuleType:
                rows.append(('loaded-module',value.__name__,token(sys.modules.get(value.__name__))))
            if any(value is item for item in (tokens._token,tokens._png_policy,tokens._parser_global_bindings)):return
            if type(value) is FunctionType and value.__module__.startswith(('adapters.','ios.adapters.','feature_journeys.')):
                code_bindings(value.__code__,value.__globals__,value.__builtins__)
                if value.__closure__:
                    for cell in value.__closure__:walk(cell.cell_contents)
        try:
            for root in self.roots:walk(root)
            external=tuple((id(container),name,token(getattr(container,name))) for container,name in tokens.EXTERNAL_READERS)
            return tuple(rows),external,tokens._png_policy(references)
        except (AttributeError,TypeError,ValueError,RecursionError,tokens._Unsupported) as error:
            self.unsupportedDetails=dict(exceptionType=type(error).__name__,kind=getattr(error,'kind',None),reason=getattr(error,'reason',None));self.unsupported=location;return None

    def literal(self):
        if self.policy is None:return False
        if any(getattr(container,name) is not function or function.__code__ is not code
               for container,name,function,code in self.engines):return False
        try:
            if any(namespace.get(name) is not value or self.reader_token(value,[])!=policy
                   for namespace,name,value,policy in self.engine_globals):return False
            return self.signature([])==self.policy
        except (AttributeError,TypeError,ValueError,RecursionError,tokens._Unsupported):return False
