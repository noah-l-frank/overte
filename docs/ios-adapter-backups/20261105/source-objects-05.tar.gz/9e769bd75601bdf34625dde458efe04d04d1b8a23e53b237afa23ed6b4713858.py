"""One original Assets checkpoint body, complete old and actual own room custody."""
from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys,traceback
R=Path.cwd().resolve(strict=True);B=R/'.ios-host-tmp';S=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def main():
 assert sys.flags.no_site and sys.dont_write_bytecode and len(sys.argv)==4
 assert sha(S/'source-freeze.json')==sys.argv[1]
 cp=Path(sys.argv[2]);assert cp.parent.parent==B and sha(cp)==sys.argv[3];cfg=load(cp)
 assert cfg['status']=='ROOT_REVIEWED_ASSETS_SOURCE6_SECOND01_B11_CURRENT_CONTEXT_UNRUN'
 assert cfg['driverSourceFreeze']==sys.argv[1]and cfg['scriptSha256']==sha(Path(__file__))
 context=Path(cfg['context']);assert sha(context)==cfg['contextSha256'];ctx=load(context)
 assert ctx['allTargetsTerminal']is True and ctx['expectedHead']==cfg['expectedHead']
 for row in ctx['globalCustody'].values():assert sha(row['path'])==row['sha256']
 expected=load(ctx['globalCustody']['baseline']['path']);assert len(expected)==cfg['oldRootCount']
 helper=Path(ctx['globalCustody']['helper']['path']);assert sha(helper)=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
 ip=Path(cfg['input']);h=ip.parent;o=h.with_name(h.name+'-outer');cs=h.with_name(h.name+'-censuses');temp=h/'temporary';out=Path(cfg['output'])
 assert h.parent==out.parent==B and ip.name=='approved-inputs.json'and sha(ip)==cfg['inputSha256']
 p=load(ip);assert p['controllerRoot']==str(h)and p['repositoryRoot']==str(R)and p['actualPublicHead']==cfg['expectedHead']
 assert p['sourceFreeze']=='4e54af007973e2fee6e976331cf668a62356864b00181846ef6c7d4ee616381c'and p['subjectSourceFreeze']=='c8cb01b3a44896149113cbeadfc9258056be9438e057025bbcc3febe4dad5795'and p['historicalSubjectSourceFreeze']=='800d75f00c7d9e06341a6d8399d21f10b51a2e935f41b7a00800a3691909d552'
 assert p['status']=='PRIVATE_ASSETS_SOURCE23_BOOTSTRAP5_ONE_ORIGINAL_UNRUN'and p['groupName']=='second01'and len(p['cases'])==1
 assert p['wallSeconds']==300 and p['killGraceSeconds']==5 and p['expectedTemporaryDirectories']==4 and p['expectedNestedCleanupCalls']==7 and p['expectedNode']==1 and p['expectedHTTP']==2
 assert len(p['subjectOriginModules'])==587 and len(p['historicalDefinitionInventory'])==590 and set(p['historicalDefinitionInventory'])-set(p['subjectOriginModules'])=={'module_support','modules.feature_journey','overte_session'} and p['subjectHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
 assert p['SDKExecutions']==p['overteNativeQueries']==p['oldCorpusInputs']==p['globalOriginalScans']==0
 assert p['phaseAdmission']is p['remaining6Admission']is None and p['nativeCompiled']is p['nativeQualified']is p['wholeQualified']is p['normalAction2Qualified']is False
 assert set(p['qualifiedSourceExecution']['requiredOriginalRoots']+p['backendBoundaryQualification']['requiredOriginalRoots'])<=set(expected)
 source=B/'assets-checkpoint-source6-bootstrap11-exact-lower-namespace-dual-profiles-code-preparation-20261105'
 for z in h.glob('*.py'):assert sha(z)==sha(source/z.name)
 assert not o.exists()and not cs.exists()and not temp.exists()and not out.exists()
 out.mkdir(mode=0o700)
 def put(n,v):
  with(out/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
  (out/n).chmod(0o600)
 advance=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(advance)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(advance))['census'];current=runpy.run_path(str(helper))['current']
 before=current();assert before==expected;put('global-before.json',before)
 put('attempt.json',dict(input=str(ip),inputSha256=cfg['inputSha256'],prospectiveRooms=list(map(str,[h,temp,o,cs])),originalCaps300plus5=True,actualRuntimeSourceOrigins587=True,retainedPhysicalDefinitionOrigins590=True))
 print('ROOT_ASSETS_SOURCE3_SECOND01_START',flush=True)
 with(out/'supervisor-stdout.log').open('xb')as stdout,(out/'supervisor-stderr.log').open('xb')as stderr:
  result=subprocess.run([sys.executable,'-S','-B',str(h/'supervise-one.py'),cfg['inputSha256']],cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
 put('actual-supervisor-return.json',dict(returnCode=result.returncode))
 try:
  drain=load(o/'actual-drain.json');assert drain['remaining']==[]and drain['originalRunner']is not None
  identities=drain['observed']+[drain['originalRunner']];groups={row['group']for row in identities};seen=[]
  for proc in Path('/proc').iterdir():
   if not proc.name.isdecimal():continue
   try:raw=(proc/'stat').read_text()
   except(FileNotFoundError,ProcessLookupError):continue
   f=raw[raw.rfind(')')+2:].split()
   if int(f[2])in groups or int(f[3])in groups:seen.append(dict(pid=int(proc.name),group=int(f[2]),session=int(f[3]),startTicks=int(f[19])))
  assert seen==[]
  for row in identities:
   try:raw=Path('/proc',str(row['pid']),'stat').read_text()
   except(FileNotFoundError,ProcessLookupError):continue
   assert int(raw[raw.rfind(')')+2:].split()[19])!=row['startTicks']
  put('actual-root-kernel-absence.json',dict(actualRecordedOriginals=identities,actualSameGroupOrSession=seen,originalCreatorLineageQualified=drain['completeOriginalNodeLineage']))
 except BaseException:
  put('unqualified-partial.json',dict(status='NO_QUIET_CLOSE_INFERRED',originalTraceback=traceback.format_exc(),originalSupervisorReturnCode=result.returncode));raise
 terminal=load(o/'terminal.json')if(o/'terminal.json').exists()else None
 qualification=load(cs/'qualification.json')if(cs/'qualification.json').exists()else None
 rooms=[z for z in(h,temp,o,cs)if z.exists()];assert all(z.is_dir()and not z.is_symlink()for z in rooms)
 first={str(z):census(z)for z in rooms};second={str(z):census(z)for z in rooms};assert first==second
 put('whole-first.json',first);put('whole-second.json',second)
 post1=current();post2=current();assert post1==post2 and set(post1)==set(expected)|{str(temp)}and all(post1[n]==v for n,v in expected.items())and post1[str(temp)]==first[str(temp)]
 put('global-after-first.json',post1);put('global-after-second.json',post2)
 passed=result.returncode==0 and terminal is not None and qualification is not None and terminal['status']==qualification['status']=='PASS'
 if passed:
  assert terminal['ownProcessesAbsent']is terminal['completeOriginalNodeLineage']is True and qualification['originalRooms']==list(map(str,[h,o,cs]))and qualification['exclusions']==[]
 put('terminal.json',dict(status='ROOT_ASSETS_SOURCE3_SECOND01_ORIGINAL_HOST_CASE_PASS_CLOSED'if passed else'ROOT_ASSETS_SOURCE3_SECOND01_ORIGINAL_FAILURE_OR_PARTIAL_CLOSED_WITHOUT_LINEAGE_PROMOTION',originalSupervisorReturnCode=result.returncode,originalSupervisorTerminal=terminal,originalQualification=qualification,originalDrain=drain,allOldOriginalBodiesUnchanged=True,oldRootCount=len(expected),wholeAllActualOwnRoomsTwiceEqual=True,allRecordedOriginalPIDsAndGroupsAbsent=True,ownTemporaryExplicitlyIncluded=True,newOriginalRoots=list(map(str,rooms+[out])),phaseAdmission=None,normalAction2Qualified=False,nativeQualified=False,featureQualified=False,wholeQualified=False))
 put('freeze.json',dict(files={z.name:dict(sha256=sha(z))for z in out.iterdir()if z.is_file()}));print(json.dumps(dict(status='PASS'if passed else'FAIL',freeze=sha(out/'freeze.json'))),flush=True)
 return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
