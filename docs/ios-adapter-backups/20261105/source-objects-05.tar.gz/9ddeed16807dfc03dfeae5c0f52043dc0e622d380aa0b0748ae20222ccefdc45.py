from pathlib import Path
p=Path('.ios-host-tmp/prepare-lifecycle-native-query-owner.py')
s=p.read_text().replace('P.mkdir(mode=0o700);','P.mkdir(mode=0o700,exist_ok=True);')
s=s.replace('thread.join(timeout=0)','if thread.ident is not None:thread.join(timeout=0)')
s=s.replace('self.native_query_task=None\'','self.native_query_task=None;self.native_query_journals={}\'')
s=s.replace('        from adapters.native_feature_observation import need\n','')
s=s.replace('        current();self.native_query_task=task;thread=None;query=None;packet=None;record=None;store=None;lock=None;outcome={}\n', '''        journal=None;issued_query=None
        current();self.native_query_task=task;thread=None;query=None;packet=None;record=None;store=None;lock=None;outcome={}
''')
a='''        def save(previous):
            with lock.held():
                if store.read()!=previous:raise LaunchError('session-lifetime')
                store.write(packet,previous)
                if store.read()!=packet:raise LaunchError('session-lifetime')
            return deepcopy(packet)
'''
b='''        def save():
            # A lost write/readback never grants adoption or delivery permission.
            # Retain the exact attempted envelope in THIS original owner.
            previous=journal['previous']
            with lock.held():
                if journal['pending'] is not None or store.read()!=previous:raise LaunchError('session-lifetime')
                attempted=deepcopy(packet);journal['pending']=attempted
                store.write(attempted,previous)
                if store.read()!=attempted:raise LaunchError('session-lifetime')
                journal['previous']=deepcopy(attempted);journal['pending']=None
'''
assert a in s;s=s.replace(a,b)
a=s.index('            with lock.held():previous=store.read()');b=s.index("            query=dict(schemaVersion=1",a)
s=s[:a]+'''            journal=self.native_query_journals.get(run)
            if journal is None:
                # Never adopt a pre-existing JSON history as source ownership.
                with lock.held():
                    if store.read() is not None:raise LaunchError('session-lifetime')
                journal=dict(source=source,rsd=rsd,loop=loop,claim=claim_owner,binding=deepcopy(binding),
                    origin=origin,directory=directory,store=store,lock=lock,previous=None,pending=None)
                self.native_query_journals[run]=journal
            else:
                if (journal['source'] is not source or journal['rsd'] is not rsd or journal['loop'] is not loop
                        or journal['claim'] is not claim_owner or journal['binding']!=binding or journal['origin']!=origin
                        or journal['directory']!=directory or journal['pending'] is not None):raise LaunchError('session-lifetime')
                store=journal['store'];lock=journal['lock']
                with lock.held():
                    if store.read()!=journal['previous']:raise LaunchError('session-lifetime')
            packet=deepcopy(journal['previous']) if journal['previous'] is not None else dict(
                originalKeeperNativeQueryOwnerVersion=1,binding=deepcopy(binding),runId=run,ownerInstance=self.instance,records=[])
            if len(packet['records'])>=32:raise LaunchError('session-lifetime')
'''+s[b:]
s=s.replace("            if action=='feature-ios-lifecycle-world':query['runId']=run\n", "            if action=='feature-ios-lifecycle-world':query['runId']=run\n            issued_query=deepcopy(query)\n")
s=s.replace("packet['records'].append(record);previous=save(previous);current()","packet['records'].append(record);save();current()")
s=s.replace('            previous=save(previous)','            save()')
s=s.replace("query=deepcopy(query),\n                queryIntentOwned", "query=deepcopy(issued_query),\n                queryIntentOwned")
a="            if resource is not None and resource.version==2:\n"
b="""            if journal is not None:
                if journal['pending'] is not None or query!=issued_query:raise LaunchError('session-lifetime')
                with journal['lock'].held():
                    if journal['store'].read()!=journal['previous']:raise LaunchError('session-lifetime')
            if resource is not None and resource.version==2:
"""
# Only native_query current, script also contains native_original_read outside the inserted literal.
assert s.count(a)==1;s=s.replace(a,b)
# Initial current() needs its closure cells bound before calling it.
s=s.replace('        def current():\n','        journal=None;issued_query=None;query=None\n        def current():\n',1)
s=s.replace('        journal=None;issued_query=None\n        current();','        current();',1)
p.write_text(s)
