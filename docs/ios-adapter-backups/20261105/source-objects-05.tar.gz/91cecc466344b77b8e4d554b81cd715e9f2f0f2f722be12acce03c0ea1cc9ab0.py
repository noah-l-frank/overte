"""Sample-domain counterexamples, not acoustic or physical device evidence.

Synthetic microphone waveform bytes are explicit raw producer inputs. One case
uses the actual Actor/SDK ledger/original-owner/typed archive; seven isolate the
original native grammar and detector without replacing consumer validators.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import array,hashlib,json,sys,unittest
from copy import deepcopy
from adapters.normal_ui import NativeUIError
from feature_journeys.fixtures import challenge
from voice_peer.voice_signal import samples
from ios.adapters.audio_acoustic_window import analyze_native,from_actor
from ios.adapters.audio_passive_actor import IOSAudioPassiveActor,lease_id
from ios.adapters.audio_passive_capture_source import ACTION
from ios.self_tests.test_ios_audio_passive_owner import PassiveBoundary,raw
from ios.self_tests.test_ios_audio_passive_phase_continuity import PhaseLifecycleModel
from ios.self_tests.test_ios_audio_passive_runtime import RuntimeModel
from ios.self_tests.test_ios_audio_recorded_owner import AudioRecordedOwnerTests,RUN

TICKET='2'*32
RATE=8000


def waveform(*,second=True,duplicate=False,short_gap=False,partial=False):
    result=array.array('h',[0])*(RATE*8)
    first=samples(challenge(RUN,TICKET).hex(),rate=RATE,amplitude=.15,profile='recorded-preview-v1')
    result[:len(first)]=first
    if second:
        other=first if duplicate else samples(challenge(RUN,TICKET).hex(),rate=RATE,amplitude=.11,profile='recorded-preview-v1')
        if partial:other=other[:RATE*2]
        start=round((2.3 if short_gap else 3.5)*RATE);result[start:start+len(other)]=other
    if sys.byteorder!='little':result.byteswap()
    return result.tobytes()


class PatternBoundary(PassiveBoundary):
    """Raw native source input declared before the first capture admission."""
    def __init__(self,model,pcm):super().__init__(model,lease=lease_id(RUN,TICKET));self.pattern=pcm
    def finish(self):
        self.clock.sleep(self.seconds);self.complete=True;self.pcm=self.pattern;self.rows=[]
        size=RATE*2
        for offset in range(0,len(self.pcm),size):
            part=self.pcm[offset:offset+size];index=offset//size;end=index+len(part)/size
            self.rows.append(dict(sequence=index+1,generation=1,routeRevision='1',
                readBeforeEpochMs=self.started+round(index*1000),readAfterEpochMs=self.started+round(end*1000),
                readBeforeMonotonicMs=self.started_mono+round(index*1000),readAfterMonotonicMs=self.started_mono+round(end*1000),
                tapEpochMs=self.started+round(end*1000),tapMonotonicMs=self.started_mono+round(end*1000),
                readBytes=len(part),readSha256=hashlib.sha256(part).hexdigest(),offset=offset,bytes=len(part),sha256=hashlib.sha256(part).hexdigest()))


def emitted(pcm):
    model=PhaseLifecycleModel();boundary=PatternBoundary(model,pcm);creator='ios-'+('6'*32)
    command=dict(schemaVersion=1,commandId=creator,action=ACTION,operation='start',instance=model.native_instance,
        runId=RUN,role='actor',leaseId=lease_id(RUN,TICKET),startCommandId=creator,seconds=8)
    boundary.send(command);boundary.finish();capture={key:value for key,value in command.items() if key!='seconds'}
    capture.update(commandId='ios-'+('7'*32),operation='capture');boundary.send(capture)
    return boundary.files['capture'],boundary.files['wav'],capture


class AudioTwoCopyWindowTests(unittest.TestCase):
    def analyze(self,pcm,*,ticket=TICKET):
        native,wav,command=emitted(pcm);return analyze_native(native,wav,command,42,RUN,ticket)
    def test_two_complete_nonidentical_sample_copies_with_original_quiet_gap_preserve_whole_wave_and_unmet_causality(self):
        native,wav,command=emitted(waveform());before=(native,wav);value=analyze_native(native,wav,command,42,RUN,TICKET)
        self.assertEqual(before,(native,wav));self.assertTrue(value['twoCompleteCopies']);self.assertEqual(2,len(value['copies']))
        self.assertGreaterEqual(value['quietEndFrame']-value['quietBeginFrame'],RATE//2);self.assertLess(value['quietRmsDbFS'],-55)
        self.assertNotEqual(value['copies'][0]['pcmSha256'],value['copies'][1]['pcmSha256'])
        self.assertEqual(hashlib.sha256(wav).hexdigest(),value['wholeWavSha256']);self.assertFalse(value['acousticQualified'])
        self.assertFalse(value['physicalADCQualified']);self.assertFalse(value['dequeueClockUsedAsADCAge']);self.assertEqual(2,len(value['unmetCausalRequirements']))
        self.assertTrue(all(copy['originFragments'] for copy in value['copies']))
    def test_external_cue_only_cannot_become_preview_evidence(self):
        with self.assertRaises(NativeUIError):self.analyze(waveform(second=False))
    def test_exact_earlier_pcm_byte_replay_cannot_become_second_copy(self):
        with self.assertRaises(NativeUIError):self.analyze(waveform(duplicate=True))
    def test_echo_like_short_gap_is_not_a_separate_playback_window(self):
        with self.assertRaises(NativeUIError):self.analyze(waveform(short_gap=True))
    def test_partial_second_pattern_cannot_supply_complete_preview(self):
        with self.assertRaises(NativeUIError):self.analyze(waveform(partial=True))
    def test_foreign_recording_ticket_cannot_reuse_previous_wave_patterns(self):
        with self.assertRaises(NativeUIError):self.analyze(waveform(),ticket='4'*32)
    def test_invalid_original_native_read_sha_refuses_before_any_pattern_verdict(self):
        native,wav,command=emitted(waveform());value=json.loads(native);value['source']['rows'][0]['readSha256']='0'*64
        with self.assertRaises(NativeUIError):analyze_native(raw(value),wav,command,42,RUN,TICKET)
    def test_actual_actor_ledger_archive_supplies_untouched_native_bytes_and_wave_without_new_source(self):
        f=AudioRecordedOwnerTests();f.setUp();self.addCleanup(f.doCleanups);model=PhaseLifecycleModel();f.model=model
        root=f.root/'passive-artifacts';root.mkdir(mode=0o700);boundary=PatternBoundary(model,waveform());runtime=RuntimeModel(f,boundary)
        actor=IOSAudioPassiveActor(runtime,'actor',RUN,root,model.client(),epoch_ms=model.epoch,monotonic=lambda:model.clock,sleep=model.sleep)
        actor.arm(TICKET);boundary.finish();self.assertEqual('retired',actor.step()['phase'])
        def census():return {p:(p.stat().st_ino,p.read_bytes()) for p in root.rglob('*') if p.is_file()}
        before=census();commands=deepcopy(boundary.commands);calls=runtime.calls;boundary.block=True
        value=from_actor(actor,TICKET);self.assertTrue(value['twoCompleteCopies']);self.assertIsNotNone(value['absenceReference'])
        self.assertFalse(value['acousticQualified']);self.assertEqual(before,census());self.assertEqual(commands,boundary.commands);self.assertEqual(calls,runtime.calls)


if __name__=='__main__':unittest.main()
