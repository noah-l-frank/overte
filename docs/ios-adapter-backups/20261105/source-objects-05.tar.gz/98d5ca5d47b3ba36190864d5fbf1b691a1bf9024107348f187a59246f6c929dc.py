"""Exact Callback9 finish controller over the existing paired terminal owner.

A frozen proof, actual new fence, once-only Stop and independent OS/SDK end are
required in sequence. No absent metadata or successful HTTP ACK grants End.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as read_scope
from adapters.script_feature.history import same
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys import terminal
from ios.adapters.emote_callback_terminal import IOSEmoteCallbackTerminal
from ios.adapters.emote_callback_finish_profile import IOSEmoteCallbackFinishFeature,PROFILE9
from ios.adapters.emote_rooted_end_lock import held_existing
from ios.adapters.emote_observer import EmoteObservationPending
from ios.adapters.emote_operation import operation


class IOSEmoteCallbackFinishTerminal(IOSEmoteCallbackTerminal):
    Flow=IOSEmoteCallbackFinishFeature
    Pending=EmoteObservationPending

    @staticmethod
    def existing_actor(primary):
        need(primary.lock._owner is None)
        path=primary.runtime.state_path(primary.actor_selector).with_name('ios-emote-actor-feature.json')
        actor_lock=ScriptSourceLock(path.with_name('script-feature-sources.lock'))
        with held_existing(actor_lock),held_existing(primary.lock):
            value=PrivateFeatureState(path).read();actual=deepcopy(value)
            if value is None:
                from ios.adapters.emote_callback_finish import existing_archive
                archive,ownership=existing_archive(primary,actor_lock)
                need(archive is not None);ownership.read()
                value=archive.copies().get(str(path));need(type(value) is dict)
            need(type(value) is dict and type(value.get('iosEmoteFeatureVersion')) is int and value['iosEmoteFeatureVersion']==9)
            exact(value,{'iosEmoteFeatureVersion','runId','role','artifactRoot','fixtureUrl','imagePolicy','payload','targetPair','callbackProfile'})
            need(value['runId']==primary.run and value['role']=='actor' and value['fixtureUrl']==primary.phase.fixture_url
                and same(value['callbackProfile'],PROFILE9))
            from ios.adapters.emote_target_pair import selected
            pair=selected(value['targetPair']);need(same(pair,primary.configured_pair)
                and value['artifactRoot']==pair['actorArtifactRoot'] and str(primary.root)==pair['primaryArtifactRoot'])
            actor=IOSEmoteCallbackFinishFeature(primary.runtime,primary.actor_selector,primary.client,primary.run,'actor',
                value['artifactRoot'],value['imagePolicy'],primary_selector=primary.selector,monotonic=primary.monotonic,
                epoch_ms=primary.epoch_ms,sleep=primary.sleep,target_pair=pair)
            actor.lock,actor.primary_lock=actor_lock,primary.lock
            actor.load();need(same(actor.previous,actual));return actor

    @operation(30)
    def invoke(self,call):
        call=terminal.arguments('emotes',call);need(call['runId']==self.flow.run)
        self.inventory=None
        if call['stage']=='finish':
            from ios.adapters.emote_callback_finish import IOSEmoteCallbackFinish
            failure=None
            with held_existing(self.actor.lock),held_existing(self.flow.lock),self.actor.held(30):
                # Shared ordinary lock contexts normalize body errors. Keep
                # the original pending/uncertain result inside every lease
                # until all inode, owner and deadline exit checks succeed.
                try:result=IOSEmoteCallbackFinish(self,call['seal']).invoke()
                except BaseException as error:failure=(error,error.__traceback__)
            if failure is not None:
                self.clock();raise failure[0].with_traceback(failure[1])
            terminal.result('emotes',result);self.clock();return result
        with self.actor.held(30):
            with read_scope(fresh=True) as reads:
                window=self.window();self.guard();journal=self.Journal(window,check=self.guard)
            self.inventory=self.Inventory(journal,reads);self.guard()
            if call['stage']=='inspect':
                refs=({role:live.state['records'][-1] for role,live in window.roles.items()}
                    if journal.state is None else journal.state['references'])
                result=journal.inspect(refs)
            else:
                publisher=PrivateFeatureState(self.actor.store.path.with_name('phase-publication-emotes-'+self.flow.run+'-actor.json'))
                result=journal.seal(call['description'],call['samples'],publisher_store=publisher)
            terminal.result('emotes',result);self.clock();return result
