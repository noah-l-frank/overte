"""Original mapping counters for new-generation FBX namespace admission only.

These pure decoded-original models do not qualify runtime/native/whole flow.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import unittest
from adapters.normal_ui import NativeUIError
from ios.adapters.assets_baked_tree import admitted_mappings
from ios.adapters.assets_generation_baked_tree import original_namespace_admission


class AssetsGenerationBakedTreeMappingTests(unittest.TestCase):
    def setUp(self):
        self.prefix='/e2e-'+('a'*32)+'/'
        self.original='1'*64;self.derived='/.baked/'+self.original+'/'
        self.qualified={self.derived+'output.fbx':'2'*64,self.derived+'meta.json':'3'*64}
        self.before={'mappings':[{'path':self.prefix+'asset-stand.fbx','hash':self.original},
            *({'path':path,'hash':digest} for path,digest in self.qualified.items()),
            {'path':'/other/retained.obj','hash':'4'*64}]}
        self.arguments=dict(owned_prefix=self.prefix,derived_prefix=self.derived,original_hash=self.original,
            qualified=self.qualified,baseline_blobs={'4'*64:{}})
    def test_original_namespace_preserves_exact_known_derived_set_and_old_literal_policy(self):
        before=deepcopy(self.before);result=original_namespace_admission(before,**self.arguments)
        self.assertEqual({self.prefix+'asset-stand.fbx':self.original},result['owned'])
        self.assertEqual(self.qualified,result['derived']);self.assertEqual(self.before,before)
        with self.assertRaises(NativeUIError):admitted_mappings(before,**self.arguments)
    def test_other_namespace_alias_of_original_hash_keeps_shared_ownership_blocking(self):
        self.before['mappings'].append({'path':'/other/shared.fbx','hash':self.original})
        with self.assertRaises(NativeUIError):original_namespace_admission(self.before,**self.arguments)
    def test_unknown_derived_mapping_and_preexisting_derived_blob_each_refuse(self):
        changed=deepcopy(self.before);changed['mappings'].append({'path':self.derived+'foreign.fbx','hash':'5'*64})
        with self.assertRaises(NativeUIError):original_namespace_admission(changed,**self.arguments)
        self.arguments['baseline_blobs']['2'*64]={}
        with self.assertRaises(NativeUIError):original_namespace_admission(self.before,**self.arguments)
    def test_duplicate_path_cannot_hide_an_extra_mapping(self):
        self.before['mappings'].append(deepcopy(self.before['mappings'][0]))
        with self.assertRaises(NativeUIError):original_namespace_admission(self.before,**self.arguments)


if __name__=='__main__':unittest.main()
