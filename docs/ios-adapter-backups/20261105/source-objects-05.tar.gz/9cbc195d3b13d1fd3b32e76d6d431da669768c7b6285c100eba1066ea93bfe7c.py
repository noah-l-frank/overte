"""Private typed Callback fence/Stop/OS/SDK/final metadata composition.

This entry is separately named; public terminal(finish), registry and feature
capabilities stay closed. No issued Stop/DELETE is resent by recovery.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same
from feature_journeys import terminal as contract
from ios.adapters.emote_observer import EmoteObservationPending
from ios.adapters.emote_post9_terminal import IOSEmotePost9Terminal,IOSEmotePostControllerCallbackFeature
from ios.adapters.emote_post9_copied_state import CallbackRoleState
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.emote_rooted_end_lock import held_existing
from ios.adapters.emote_post9_copied_checkpoint import freeze as freeze_copies,existing
from ios.adapters.emote_post9_copied_ownership import IOSEmotePost9CopiedOwnership
from ios.adapters.emote_post9_end_context import archive_checkpoint
from ios.adapters.emote_post9_fence import _seal,inactive
from ios.adapters.emote_post9_end_archive import IOSEmotePost9EndArchive
from ios.adapters.emote_post9_process_end import IOSEmotePost9ProcessEnd
from ios.adapters.emote_post9_session_end import IOSEmotePost9SessionEnd
from ios.adapters.emote_post9_terminal_end import role_end
from ios.adapters.emote_post9_retirement_view import Post9RetirementView


def existing_end_actor(primary,seal):
    """Real Feature9 header constructor after a typed deleted Actor path.

    No native/source/Scope factory or fake historical Feature state is opened.
    The actual End WAL must own the absent role metadata before routing uses
    that retained configuration. Process/SDK replay rechecks the full graph.
    """
    need(type(primary) is IOSEmotePostControllerCallbackFeature and primary.role=='primary'
        and primary.lock._owner is None and primary.configured_pair is not None)
    path=primary.runtime.state_path(primary.actor_selector).with_name('ios-emote-actor-feature.json')
    lock=ScriptSourceLock(path.with_name('script-feature-sources.lock'))
    with held_existing(lock),held_existing(primary.lock):
        need(PrivateFeatureState(path).read() is None)
        store=PrivateFeatureState(primary.store.path.with_name('ios-emote-primary-'+primary.run+'-post9-copied.json'))
        raw=store.read();need(type(raw) is dict and raw.get('runId')==primary.run and raw.get('artifactRoot')==str(primary.root))
        def guard():primary.lock.assert_held();lock.assert_held();return True
        archive=existing(store,root=primary.root,binding=raw['binding'],run=primary.run,lock=primary.lock,actor_lock=lock,guard=guard)
        copies,checkpoint=archive.retained();view=Post9RetirementView(archive,seal)
        need(same(checkpoint['seal'],seal));value=copies[str(path)];retained=view.store_for(path,value)
        role=CallbackRoleState(value,store=retained,run=primary.run,role='actor',locks=dict(primary=primary.lock,actor=lock))
        need(same(role.configured_pair,primary.configured_pair))
        actor=IOSEmotePostControllerCallbackFeature(primary.runtime,primary.actor_selector,primary.client,primary.run,'actor',role.root,role.policy,
            primary_selector=primary.selector,monotonic=primary.monotonic,epoch_ms=primary.epoch_ms,sleep=primary.sleep,target_pair=role.configured_pair)
        actor.lock,actor.primary_lock=lock,primary.lock
        actor.load();need(actor.state is None and actor.previous is None)
        return actor


class IOSEmotePost9Finish:
    def __init__(self,terminal,seal):
        need(type(terminal) is IOSEmotePost9Terminal);contract.sealed(seal)
        self.terminal,self.flow,self.actor=terminal,terminal.flow,terminal.actor;self.seal=deepcopy(seal)
        need(seal['description']['runId']==self.flow.run and seal['description']['area']=='emotes')
    def freeze(self):
        flow,actor=self.flow,self.actor;flow.lock.assert_held();actor.lock.assert_held()
        store=PrivateFeatureState(flow.store.path.with_name('ios-emote-primary-'+flow.run+'-post9-copied.json'))
        if store.read() is None:
            archive,_result=freeze_copies(self.terminal,self.seal)
        else:
            value=store.read();need(type(value) is dict and value.get('runId')==flow.run and value.get('artifactRoot')==str(flow.root))
            archive=existing(store,root=flow.root,binding=value['binding'],run=flow.run,lock=flow.lock,actor_lock=actor.lock,guard=self.terminal.clock)
            if archive.state['phase']!='validated':archive.freeze()
        copies,checkpoint=archive.retained();archive.validate_context(copies)
        end_path=store.path.with_name('ios-emote-primary-'+flow.run+'-post9-end.json')
        view=Post9RetirementView(archive,self.seal) if PrivateFeatureState(end_path).read() is not None else None
        ownership=IOSEmotePost9CopiedOwnership(copies,run=flow.run,lock=flow.lock,actor_lock=actor.lock,retirement=view)
        # After fresh local fence appends, its typed decoder owns their read
        # membership. The old copy-only Inventory is never broadened/replayed.
        proof=ownership.read(checkpoint)['proof'];need(same(checkpoint['seal'],self.seal))
        _seal(proof,self.seal,run=flow.run,role='primary',binding=archive.binding)
        self.terminal.responsibilities=[];self.terminal.inventory=None
        return archive,ownership
    def invoke(self):
        archive,ownership=self.freeze();end=IOSEmotePost9EndArchive(archive,ownership,self.seal,self.terminal.clock)
        retirement=end if end.state is not None else None
        actor=IOSEmotePost9ProcessEnd(self.actor,ownership,archive,self.seal,retirement=retirement)
        primary=IOSEmotePost9ProcessEnd(self.flow,ownership,archive,self.seal,peer=actor,retirement=retirement)
        processes=dict(actor=actor,primary=primary)
        if end.state is None:
            for role in ('actor','primary'):
                process=processes[role];flow=process.flow
                if process.state is None:process.prepare()
                if process.state['phase']=='prepared':
                    checkpoint=archive_checkpoint(archive)
                    phase=flow.phase.status()
                    inactive(phase,run=flow.run,instance=process.role_state.state['phaseInstance'],ticket=self.seal['description']['ticket'],
                        after=checkpoint['phaseOriginal']['retiredEpochMs'])
                    parts=flow.components();process.stop(parts['scope'],flow.pointers(parts),flow.keys(parts))
                if not process.advance():raise EmoteObservationPending('Original '+role+' Callback OS quiet window is still pending')
        actor_sdk=IOSEmotePost9SessionEnd(actor,processes)
        primary_sdk=IOSEmotePost9SessionEnd(primary,processes,peer=actor_sdk)
        sessions=dict(actor=actor_sdk,primary=primary_sdk)
        if end.state is None:
            for role in ('actor','primary'):
                if not sessions[role].finish():raise EmoteObservationPending('Original '+role+' Callback SDK OS quiet window is still pending')
        end.attach(processes,sessions)
        if end.state is None:end.prepare()
        end.retire()
        value=dict(featureTerminalEndVersion=1,seal=deepcopy(self.seal),roles={role:role_end(processes[role],sessions[role],end) for role in ('primary','actor')})
        contract.ended(value,self.seal)
        checkpoint=archive_checkpoint(archive)
        return dict(iosEmotePostControllerEndVersion=3,terminalEnd=value,
            profile9FamilyOriginals=deepcopy(checkpoint['profile9FamilyOriginals']),
            nativeFileRetirementOriginalSha256=checkpoint['profile9NativeFileRetirementOriginalSha256'],
            retainedResponseFileDuty=deepcopy(checkpoint['responseFileDuty']),
            responseFileRetirementOriginals={role:processes[role].response.completed(processes[role].fence_original())for role in('primary','actor')},
            completeOriginalArchiveSha256=digest(end.previous),
            nativeQualified=False,deviceQualified=False,wholeQualified=False)
