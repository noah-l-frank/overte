"""Typed retained family ownership, not a Callback9 End/Stop/SDK verdict.

All source/clock/native2/palette2 originals remain literal. The archive copies
only host metadata to real OFS, retains uncertain query/file duties, and never
replays a source acquisition or deletes a resource. Native file observation and
creator-process/SDK End are separate required interfaces, not DTO flags.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.original_file_reads import collect,scope as read_scope
from adapters.script_feature.history import pack,unpack,same
from ios.adapters.emote_original_lease import EmoteOriginalLease
from ios.adapters.emote_sources import IOSEmoteSources
from ios.adapters.emote_post_controller_runtime_sources import IOSEmotePostControllerInventory
from ios.adapters.emote_observer import EmoteObservationPending

VERSION=1
NAMESPACE='emote-callback-post-copied'
PREFIX='emoteCallbackPostSourceCopied'


class PostControllerFamilyOwnership:
    """Actual typed host sources and immutable originals, never a live facade."""
    def __init__(self,sources,*,check=None):
        need(isinstance(sources,IOSEmoteSources)and(check is None or callable(check)));sources.lock.assert_held();self.check=check
        # Genuine historical reconstruction keeps its complete existing decoder
        # and all inode/history checks without an invalid live SDK guard.
        with collect()as reads,read_scope():
            self.sources=IOSEmoteSources(sources.store,sources.root,sources.binding,sources.run,sources.role,sources.lock,
                lambda:True,None,historical=True)
            need(self.sources.previous is not None)
            self.inventory=IOSEmotePostControllerInventory(self.sources)
            self.source_reads=set(reads)
        self.lock=self.sources.lock;self.root=self.sources.root;self.binding=deepcopy(self.sources.binding)
        self.role,self.run=self.sources.role,self.sources.run
        self.source_value=deepcopy(self.sources.previous)
        self.family_value=None if self.inventory.owner is None else deepcopy(self.inventory.owner.previous)
        self.paths={self.sources.store.path}|set(self.inventory.paths)|set(self.inventory.reads)|self.source_reads
        self.signatures={path:EmoteOriginalLease.signature(path.lstat())for path in self.paths}
        self.bound()
    def bound(self):
        self.lock.assert_held();need(self.check is None or self.check()is not False);need(same(self.sources.store.read(),self.source_value))
        self.inventory.bound()
        need(all(EmoteOriginalLease.signature(path.lstat())==signature for path,signature in self.signatures.items()))
        return True
    def snapshot(self):
        self.bound();duty=None if self.inventory.manifest is None else deepcopy(self.inventory.manifest)
        return dict(iosEmotePostControllerFamilyOwnershipVersion=VERSION,runId=self.run,role=self.role,
            sourceBinding=deepcopy(self.binding),artifactRoot=str(self.root),sourceOwnerPath=str(self.sources.store.path),
            sourceOwnerValue=deepcopy(self.source_value),familyOwnerPath=str(self.inventory.owner_path),
            familyOwnerValue=deepcopy(self.family_value),responsibility=duty,stableOriginalFlags=list(self.inventory.stable),
            actualReadPaths=sorted(str(path)for path in self.paths),
            actualSourceSignatures={str(path):list(signature)for path,signature in sorted(self.signatures.items())},
            creatorRole='primary',nativeFile='feature-ios-emote-palette.json',
            nativeFileRetirementRequired=self.inventory.owner is not None,
            creatorProcessLifetimeRequired=self.inventory.owner is not None,
            nativeFileOriginal=None,creatorProcessEndOriginal=None,sdkEndOriginal=None,
            hostMetadataRetirementAllowed=False,EndAllowed=False,nativeQualified=False,wholeQualified=False)
    def require_end(self):
        self.bound()
        raise EmoteObservationPending('Profile9 requires its own typed copied-State/fence plus actual PRIMARY-creator fixed-file retirement, process and SDK originals; no such joined End is installed')


class PostControllerFamilyOwnedArchive:
    """Version1 OFS copies with real planned/opened/saved recovery and PFS CAS."""
    def __init__(self,store,ownership):
        need(type(ownership)is PostControllerFamilyOwnership and isinstance(store,PrivateFeatureState))
        self.ownership=ownership;self.lock=ownership.lock;self.root=ownership.root;self.binding=deepcopy(ownership.binding)
        self.run,self.role=ownership.run,ownership.role;self.store=store;self.failed=False
        need(store.path==ownership.sources.store.path.with_name('ios-emote-'+self.role+'-'+self.run+'-post-controller-end-owned.json'))
        self.originals=OriginalFrameStore(self.root,self.binding,self.run,self.role,self.bound,self.intent,
            namespace=NAMESPACE,schema_prefix=PREFIX,kind='inputs')
        self.previous=store.read();self.state=None if self.previous is None else self.decode(self.previous)
        self.bound()
    def envelope(self,state):
        return dict(iosEmotePostControllerEndOwnedArchiveVersion=VERSION,runId=self.run,role=self.role,
            creatorBinding=deepcopy(self.binding),artifactRoot=str(self.root),payload=pack([state]))
    def decode(self,value):
        exact(value,{'iosEmotePostControllerEndOwnedArchiveVersion','runId','role','creatorBinding','artifactRoot','payload'})
        rows=unpack(value['payload']);need(type(value['iosEmotePostControllerEndOwnedArchiveVersion'])is int
            and value['iosEmotePostControllerEndOwnedArchiveVersion']==VERSION and len(rows)==1 and same(value,self.envelope(rows[0])))
        state=rows[0];exact(state,{'phase','ownershipSha256','record','pending'})
        need(state['phase']in('copying','copied')and state['ownershipSha256']==digest(self.ownership.snapshot()))
        if state['record']is not None:self.originals.expand(state['record']);need(state['record']['index']==1)
        if state['pending']is not None:
            self.originals.original(state['pending']);need(state['phase']=='copying'and state['record']is None and state['pending']['index']==1)
        if state['phase']=='copied':need(state['record']is not None and state['pending']is None)
        else:need(state['record']is None)
        return deepcopy(state)
    def paths(self):
        result={self.store.path}
        if self.state is not None:
            if self.state['record']is not None:result.add(self.originals.path(self.originals.expand(self.state['record'])))
            if self.state['pending']is not None:result.add(self.originals.path(self.state['pending']))
        return result
    def bound(self):
        self.lock.assert_held();self.ownership.bound();need(not self.failed and same(self.store.read(),self.previous))
        found=set(self.root.glob(NAMESPACE+'-frame-inputs-'+self.run+'-'+self.role+'-*'))
        expected={path for path in self.paths()if path.parent==self.root and path!=self.store.path and path.exists()}
        need(found==expected);return True
    def save(self):
        self.bound();value=self.envelope(self.state);self.decode(value)
        try:self.store.write(value,self.previous);need(same(self.store.read(),value));self.previous=deepcopy(value)
        except BaseException:self.failed=True;raise
    def intent(self,event,wire):
        need(event=='original'and self.state is not None and self.state['phase']=='copying'and wire['index']==1)
        self.originals.original(wire);old=self.state['pending']
        if old is None:need(wire['phase']=='planned')
        else:
            need((old['phase'],wire['phase'])in(('planned','opened'),('opened','saved'))
                and all(same(wire[k],old[k])for k in wire if k not in('phase','file')))
            if old['file']is not None:need(same(old['file'],wire['file']))
        self.state['pending']=deepcopy(wire);self.save()
    def freeze(self):
        self.bound()
        if self.state is None:
            self.state=dict(phase='copying',ownershipSha256=digest(self.ownership.snapshot()),record=None,pending=None);self.save()
        if self.state['phase']=='copied':return self.original()
        value=self.ownership.snapshot();need(digest(value)==self.state['ownershipSha256'])
        pending=self.state['pending']
        if pending is None:reference=self.originals.write(1,value)
        elif pending['phase']=='planned':
            need(not self.originals.path(pending).exists()and not self.originals.path(pending).is_symlink())
            reference=self.originals.write(1,value)
        else:
            need(pending['phase']in('opened','saved')and same(self.originals.read(pending),value))
            reference=self.originals.compact(dict(pending,phase='saved'))
        need(same(self.originals.read(self.originals.expand(reference)),value))
        self.state.update(phase='copied',record=deepcopy(reference),pending=None);self.save();return self.original()
    def original(self):
        self.bound();need(self.state is not None and self.state['phase']=='copied')
        value=self.originals.read(self.originals.expand(self.state['record']))
        need(digest(value)==self.state['ownershipSha256']and same(value,self.ownership.snapshot()))
        return deepcopy(value)
    def retirement_manifest(self):
        self.bound()
        if self.state is not None and self.state['phase']=='copied':self.original()
        return dict(iosEmotePostControllerEndOwnedResponsibilityVersion=VERSION,runId=self.run,role=self.role,
            phase=None if self.state is None else self.state['phase'],pending=None if self.state is None else deepcopy(self.state['pending']),
            hostOwnershipOriginal=None if self.state is None else deepcopy(self.state['record']),
            creatorRole='primary',creatorBinding=deepcopy(self.binding),nativeFile='feature-ios-emote-palette.json',
            nativeFileRetirementOriginal=None,creatorProcessEndOriginal=None,sdkEndOriginal=None,
            uncertainFamilyQuery=self.ownership.inventory.manifest is not None and self.ownership.inventory.manifest['uncertainRead'],
            metadataRetirementAllowed=False,finishAllowed=False,nativeQualified=False,wholeQualified=False)
    def retire(self):
        self.bound()
        if self.state is not None and self.state['phase']=='copied':self.original()
        self.ownership.require_end()
