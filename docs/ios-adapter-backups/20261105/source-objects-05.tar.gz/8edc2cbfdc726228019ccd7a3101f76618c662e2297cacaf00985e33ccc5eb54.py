"""Explicit Root semantic admission plus actual qualified C10c utility facts."""
from pathlib import Path
import json
from kernel_admission import require as require_kernel
C10C='63f5ffc563996ad7793a600cb6a16c53d8df05a54d65db24321a1a2b5c020fc4'
HELPER='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
SOURCE2='b28f623ffbad2a1a331dd29fc3abe6dc5b1e8ec61e803a161cfa728f68a702da'
SOURCE3='164487ed9c7f8eb64811957f06ead32b41becdfd0b70abb00d79a3064e681cae'
QUALIFIED='8d994401d65f175b1feec1e7d0629ac3a9e4e01499f1d44ec57f3569eb25e25a'
def read_ref(row,pin):
    assert type(row)is dict and set(row)=={'path','sha256'}
    path=Path(row['path']);assert path.is_absolute()and path.resolve(strict=True)==path
    assert pin(path)['sha256']==row['sha256'];return json.loads(path.read_text())
def packet(row,pin):
    value=read_ref(row,pin);root=Path(row['path']).parent;assert type(value['files'])is dict
    for name,entry in value['files'].items():
        assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
        assert pin(root/name)['sha256']==entry['sha256']
    return value

def require(value,pin):
    require_kernel(value['kernelOwn5Proof'],pin)
    # Root explicitly supplies a NEW semantic review of the two unrun product
    # packets. Neither this loader utility PASS nor old Source1 model assembly
    # constitutes that semantic admission.
    assert value['status']=='ROOT_REVIEWED_EMOTE_SOURCE3_ONE_POSITIVE_METADATA_ADMISSION'
    assert value['source2Freeze']==SOURCE2 and value['source3Freeze']==SOURCE3
    review=value['sourceSemanticReviewFreeze'];assert review['sha256']=='7ec477b361087c0abcb6a09c9167cfd83f1f8d29b810745cc912bcd276be1c6a'
    body=packet(review,pin);path=Path(review['path']).parent/'READBACK.json'
    result=read_ref(dict(path=str(path),sha256=body['files']['READBACK.json']['sha256']),pin)
    assert result['status']=='INDEPENDENT_FULL_SEMANTIC_SOURCE_REVIEW_NO_NEW_CONCRETE_BLOCKER'
    assert result['actualSource2And3CounterBodiesRead']==16 and result['actualNewLiveDunderNew']is False
    assert result['sources']['emote-callback-copied-state-ownership-source2-private-20261104']['freeze']==SOURCE2
    assert result['sources']['emote-callback-typed-fence-process-sdk-end-source3-private-20261104']['freeze']==SOURCE3
    ref=value['c10cQualifiedRootFreeze'];assert ref['sha256']==QUALIFIED
    root=packet(ref,pin);name='results.json';path=Path(ref['path']).parent/name
    actual=read_ref(dict(path=str(path),sha256=root['files'][name]['sha256']),pin)
    assert actual['status']=='ACTUAL_C10C_FRESH_SOURCE_CACHE_MUTATION_COMPILER_STDLIB_ALIAS_COUNTER6_AND_ALL_UTILITY_GATES_PASS'
    assert actual['subjectSourceFreeze']==C10C and actual['subjectHelperSha256']==HELPER
    assert actual['actualPassedCases']==actual['actualStartedCases']==6 and actual['actualFailedCases']==actual['actualUnrunCases']==0
    for key in('sourceExecutionCounterQualified','cachePoisonTimestampAndUncheckedRefusalQualified','actualSourceMutationRefusalQualified',
        'actualCompileExecRebindRefusalQualified','actualGenericStdlibExecutionRowEqualityQualified','actualGenuineFourExpatNamesAndForeignReceiverRefusalQualified',
        'all27OsCioDupToolsRestored','all725FrozenSourceBinaryPinsUnchanged','actualInputAndCliShaUnchanged','parentFDThreadAndKernelDrain','twoWholeOwnCensusesEqual'):
        assert actual[key]is True
    assert actual['actualOriginalStandardCleanupCalls']==actual['actualGenuineTemporaryDirectories']==6
    assert actual['actualCallbackErrors']==actual['NodeExecutions']==actual['SDKExecutions']==actual['overteNativeQueries']==0
    assert actual['terminal']==dict(childReturnCode=0,forcedKill=False,ownProcessesAbsent=True,problems=[],timedOut=False)
    assert actual['realNetwork']is False and actual['qualificationScope'].startswith('Actual runtime delegated Python source bytes')
    return True
