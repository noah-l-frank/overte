"""Actual host Node VM lifetime + real HTTP page polling; native models explicit.

No Scope/reader/manager method is replaced. Immutable events keep the exact
actual worker/source times, and shutdown is not relabeled process/thread exit.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,queue,re,subprocess,threading,time,uuid
from copy import deepcopy
from pathlib import Path
from urllib.request import Request,HTTPRedirectHandler,build_opener
from urllib.parse import urlsplit,urlunsplit
from lifecycle_moving_raw_world_renderer import SELF


from lifecycle_moving_raw_paths import guarded_path


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*_args,**_kwargs):return None


class RawMarkerBrowser:
    def __init__(self,state,retain_http):
        self.state,self.retain_http=state,retain_http;self.lock=threading.RLock();self.stop_event=threading.Event();self.image_ready=threading.Event();self.thread=None;self.source=None
        self.events=[];self.last_image=None;self.last_page=None;self.failure=None;self.created=None;self.retired=None;self.callback_created=0;self.callback_retired=0
    def _get(self,url):
        split=urlsplit(url);owned=urlsplit(self.state.case.fixture_url)
        assert split.scheme==owned.scheme=='http'and split.netloc==owned.netloc
        assert split.hostname in('127.0.0.1','::1','localhost')and not split.fragment and not split.query
        assert split.path.startswith(owned.path+'/runs/'+self.state.run+'/')
        before=self.state.stamp()
        with build_opener(NoRedirect()).open(Request(url),timeout=1)as response:
            assert response.status==200;raw=response.read(262145);assert len(raw)<=262144
        after=self.state.stamp();self.retain_http(url,before,after,raw);self.events.append(dict(url=url,before=before,after=after,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
        return raw
    def open(self,url):
        assert self.thread is None
        html=self._get(url).decode('utf-8');match=re.search(r'fetch\(("[^"\n]+")',html);assert match
        assert 'setInterval(refresh,100)'in html and '/marker.png'in html
        path=json.loads(match.group(1));origin=urlsplit(url);self.current=urlunsplit((origin.scheme,origin.netloc,path,'',''))
        self.source=url;self.created=self.state.stamp()['epochMs'];self.thread=threading.Thread(target=self._poll,name='explicit-marker-http-page-model',daemon=False)
        self.thread.start()
    def _poll(self):
        while not self.stop_event.is_set():
            with self.lock:self.callback_created+=1
            try:
                value=json.loads(self._get(self.current));ticket=value['ticket'];assert re.fullmatch('[0-9a-f]{32}',ticket)
                base=self.current.rsplit('/current',1)[0]+'/tickets/'+ticket+'/marker.png';raw=self._get(base)
                with self.lock:self.last_image=raw;self.last_page=dict(url=base,ticket=ticket,loadedEpochMs=self.state.stamp()['epochMs']);self.image_ready.set()
            except BaseException as error:self.failure=type(error).__module__+'.'+type(error).__qualname__
            finally:
                with self.lock:self.callback_retired+=1
            self.stop_event.wait(.1)
    def image(self,source):
        with self.lock:
            assert source==self.source and self.last_image is not None
            return bytes(self.last_image),deepcopy(self.last_page)
    def close(self):
        self.stop_event.set()
        if self.thread is not None:self.thread.join(timeout=5);assert not self.thread.is_alive()
        with self.lock:self.last_image=None;self.last_page=None
        if self.retired is None and self.created is not None:self.retired=self.state.stamp()['epochMs']


class RawMarkerWorker:
    def __init__(self,state,retain_http):
        self.state=state;self.process=None;self.reader=None;self.lines=queue.Queue();self.events=[]
        self.thread_instance=uuid.uuid4().hex;self.member=None;self.engine=None;self.running=False;self.browser=RawMarkerBrowser(state,retain_http)
        self.requests=[];self.worker_error=None
    def _read(self):
        try:
            for line in self.process.stdout:
                value=json.loads(line)
                if value.get('kind')=='entity-added':
                    row=value['record'];self.state.install_marker(row['id'],row['properties'],row['createdEpochMs'])
                elif value.get('kind')=='entity-deleted':self.state.remove_marker(value['record']['id'])
                else:self.lines.put(value)
        except BaseException as error:self.worker_error=type(error).__qualname__
    def exchange(self,operation,**fields):
        q=dict(op=operation,id=uuid.uuid4().hex,**fields);self.requests.append(deepcopy(q))
        self.process.stdin.write(json.dumps(q)+'\n');self.process.stdin.flush();reply=self.lines.get(timeout=5)
        assert reply['id']==q['id']and reply['kind']!='error';return reply
    def start(self,main):
        assert self.process is None;main=guarded_path(main);companion=guarded_path(main.with_name('companion.js'))
        raw=main.read_bytes();other=companion.read_text();path=Path(__file__).with_name('lifecycle_moving_marker_worker.mjs')
        self.process=subprocess.Popen(['node',str(path)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        self.reader=threading.Thread(target=self._read,name='explicit-marker-vm-stdout',daemon=False);self.reader.start()
        reply=self.exchange('load',main=raw.decode('utf-8'),companion=other,companionUrl=companion.as_uri(),selfId=SELF)
        assert reply['hostPid']==self.process.pid and len(reply['added'])==1
        self.member=dict(instance=reply['manager'],assigned=True,url=main.as_uri(),loadGeneration=1,assignedEpochMs=reply['assignedEpochMs'])
        self.engine=dict(url=main.as_uri(),running=True,stopping=False,finished=False,required=dict(instance=reply['manager'],
            sequence=len(reply['modules']),modules=reply['modules']),code=reply['code'])
        units=raw.decode().encode('utf-16le');assert self.engine['code']['sha256']==hashlib.sha256(units).hexdigest()
        assert self.engine['code']['codeUnits']==len(units)//2
        self.events.append(dict(eventSequence=1,capturedEpochMs=reply['assignedEpochMs'],monotonicMs=time.monotonic_ns()//1000000,
            kind='thread-bound',threadInstance=self.thread_instance,manager=deepcopy(self.member),code=None,work=None))
        added=reply['added'][0];assert self.state.marker_id==added['id'];self.running=True
        self.browser.open(added['properties']['sourceUrl']);return deepcopy(self.member)
    def work(self,query):
        assert self.running;requested=self.state.stamp()['epochMs'];reply=self.exchange('work');captured=self.state.stamp()['epochMs']
        assert type(reply['capturedEpochMs'])is int
        return dict(requested=requested,captured=captured,workerCapturedEpochMs=reply['capturedEpochMs'],work=dict(signalCallbacks=reply['signalCallbacks'],timerCallbacks=reply['timerCallbacks'],
            evaluating=reply['evaluating'],timers=reply['timers']))
    def stop(self):
        assert self.running;reply=self.exchange('stop');assert reply['kind']=='shutdown-drained'
        assert all(row['id']!=self.state.marker_id for row in reply['deleted'])
        self.events.append(dict(eventSequence=len(self.events)+1,capturedEpochMs=reply['capturedEpochMs'],monotonicMs=time.monotonic_ns()//1000000,
            kind='shutdown-drained',threadInstance=self.thread_instance,manager=deepcopy(self.member),code=deepcopy(self.engine['code']),
            work={k:reply[k]for k in('signalCallbacks','timerCallbacks','evaluating','timers')}))
        self.browser.close();code=self.process.wait(timeout=5);self.reader.join(timeout=5);assert code==0 and not self.reader.is_alive()
        self.events.append(dict(eventSequence=len(self.events)+1,capturedEpochMs=self.state.stamp()['epochMs'],monotonicMs=time.monotonic_ns()//1000000,
            kind='thread-finished',threadInstance=self.thread_instance,manager=deepcopy(self.member),code=deepcopy(self.engine['code']),work=None))
        self.running=False;self.engine.update(running=False,finished=True)
    def close(self):
        try:
            if self.running:self.stop()
        finally:
            self.browser.close()
            if self.process is not None:
                # Emergency owned-host drain can close stdin after a failed
                # load/unknown stop. Natural EOF/process exit proves only this
                # host child's exit; it does not delete an unreturned Entity,
                # fabricate shutdown-drained or qualify product cleanup.
                if self.process.poll()is None:self.process.stdin.close()
                self.process.wait(timeout=5)
                if self.reader is not None:self.reader.join(timeout=5);assert not self.reader.is_alive()
                for stream in(self.process.stdin,self.process.stdout,self.process.stderr):
                    if not stream.closed:stream.close()
