"""Private Root run metadata only; no target imports or process launch on import."""
from pathlib import Path
import ast,hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def pin(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode),str(path)
    value={key:getattr(a,key) for key in FIELDS}
    if stat.S_ISREG(a.st_mode):value['sha256']=sha(path)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in FIELDS),str(path)
    return value

def proc(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))

def load_plan():return json.loads((HERE/'suite-plan.json').read_text())
def validate_frozen():
    own=json.loads((HERE/'freeze.json').read_text())
    for name,expected in own['files'].items():assert sha(HERE/name)==expected,name
    plan=load_plan()
    assert sha(HERE/'source-root-final-map.json')==plan['sourceRootMapSha256']
    assert sha(HERE/'expected-publication.json')==plan['expectedPublicationSha256']
    assert sha(HERE/'expected-registry-own-key.json')==plan['expectedRegistryOwnKeySha256']
    for row in plan['frozenPackets']:
        root=REPO/row['path'];assert sha(root/'freeze.json')==row['freezeSha256']
        frozen=json.loads((root/'freeze.json').read_text())
        for name,expected in frozen['files'].items():assert sha(root/name)==expected,name
    return plan

def publication():
    rows=json.loads((HERE/'expected-publication.json').read_text())
    assert len(rows)==load_plan()['expectedPublicationCount']
    for row in rows:
        path=REPO/row['path'];assert path.resolve(strict=True)==path and sha(path)==row['expectedSha256'],row['path']
    own=json.loads((HERE/'expected-registry-own-key.json').read_text())
    assert json.loads((REPO/own['jsonPath']).read_text())[own['jsonSection']][own['ownKey']]==own['expectedContract']
    tree=ast.parse((REPO/own['validatorPath']).read_text())
    assignments=[node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id==own['validatorAssignment'] for target in node.targets)]
    assert len(assignments)==1 and ast.literal_eval(assignments[0].value)[own['ownKey']]==own['expectedRequired']
    contracts=json.loads((REPO/own['jsonPath']).read_text())[own['jsonSection']]
    required=ast.literal_eval(assignments[0].value)
    for key,contract in load_plan()['requiredAdditionalContracts'].items():
        assert contracts.get(key)==contract and required.get(key)==contract['current'],key
    return rows

def prior_originals(plan):
    root=REPO/plan['prior425Root'];expected=json.loads((REPO/plan['prior425PinsPath']).read_text())
    actual={str((root/name).relative_to(REPO)):row for name,row in originals(root).items()}
    assert actual==expected,'Old425 originals changed'
    assert len(actual)==440 and sum(stat.S_ISREG(row['st_mode']) for row in actual.values())==425
    cold_root=REPO/plan['priorCold23Root'];cold_expected=json.loads((REPO/plan['priorCold23PinsPath']).read_text())
    cold_actual=originals(cold_root)
    assert cold_actual==cold_expected,'First cold failed23 originals changed'
    assert sum(stat.S_ISREG(row['st_mode']) for row in cold_actual.values())==23
    assert len([path for path in cold_root.iterdir() if path.is_dir()])==3,'First cold actual3 TDs changed'
    result=dict(prior425=actual,firstCold23=cold_actual)
    for row in plan['priorAdditionalRoots']:
        extra_root=REPO/row['root'];wanted=json.loads((REPO/row['pinsPath']).read_text());observed=originals(extra_root)
        assert observed==wanted,'Prior successful cold4/guards6 originals changed'
        assert sum(stat.S_ISREG(item['st_mode']) for item in observed.values())==row['files']
        assert len([path for path in extra_root.iterdir() if path.is_dir()])==row['retainedTDRoots']
        result[row['root']]=observed
    all_prior=json.loads((REPO/plan['allPriorPinsPath']).read_text())
    current={name:pin(REPO/name) for name in all_prior}
    assert current==all_prior,'Old diagnostic/original inputs changed'
    result['allPriorAttempts']=current
    failed_root=REPO/plan['firstFailed112Root'];wanted=json.loads((HERE/'first112-originals.json').read_text())
    current=originals(failed_root);assert current==wanted,'First failed112 originals changed'
    result['firstFailed112']=current
    report=json.loads((REPO/plan['requiredPreviousSuiteReport']).read_text())
    assert report['exitCode']==0 and report['allPinsEqual'] and report['postStopCensusesQualified']
    prior_root=Path(report['runRoot'])/'temporary'
    wanted=json.loads((REPO/plan['requiredPreviousSuiteCensus']).read_text());current=originals(prior_root)
    assert current==wanted,'New Root4 actual originals changed before existing regressions'
    result['actualNewRoot4Originals']=current
    return result

def broad_sources(plan):
    names=subprocess.check_output(['rg','--files','-0',*plan['broadSourceRoots']],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}
    assert REPO/'interface/src/main.cpp' in paths,'Explicit main.cpp pin missing'
    return paths

def sources(plan):
    paths=broad_sources(plan)
    own=json.loads((HERE/'freeze.json').read_text())
    paths.update(HERE/name for name in own['files']);paths.add(HERE/'freeze.json')
    for row in plan['frozenPackets']:
        root=REPO/row['path'];frozen=json.loads((root/'freeze.json').read_text())
        paths.update(root/name for name in frozen['files']);paths.add(root/'freeze.json')
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}

def originals(root):
    return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
