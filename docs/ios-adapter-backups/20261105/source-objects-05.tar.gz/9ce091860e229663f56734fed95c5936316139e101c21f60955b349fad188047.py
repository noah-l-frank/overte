"""Exact opt-in Avatar Keeper End2; the old terminal End1 codec is unchanged.

This syntax decoder grants no ownership or successful close. The canonical
caller must reopen both real Keeper archives and all Scene/Final originals.
"""
from adapters.native_feature_observation import exact, need
from adapters.script_feature.history import same
from feature_journeys.contract import identifier

PROFILE = 'ios-avatar-original-keeper-reply-end-v2'


def arguments(value):
    from feature_journeys.terminal import sealed, description, bounded
    bounded(value)
    exact(value, {'contractVersion','runId','stage','seal','iosAvatarKeeperTerminalVersion','avatarReplyProfileVersion'})
    need(type(value['contractVersion']) is int and value['contractVersion'] == 1
        and type(value['iosAvatarKeeperTerminalVersion']) is int and value['iosAvatarKeeperTerminalVersion'] == 2
        and value['stage'] == 'finish' and type(value['avatarReplyProfileVersion'])is int and value['avatarReplyProfileVersion']==1)
    identifier(value['runId'])
    sealed(value['seal'])
    description(value['seal']['description'], area='avatar-people', run=value['runId'])
    return value


def end(value, seal=None):
    from feature_journeys.terminal import sealed, description, bounded
    from feature_journeys.retirement_receipts import sha
    bounded(value)
    exact(value, {'iosAvatarKeeperEndVersion','avatarReplyProfileVersion','profile','runId','seal','handoffSha256','roles','nativeReplies'})
    need(type(value['iosAvatarKeeperEndVersion']) is int and value['iosAvatarKeeperEndVersion'] == 2
        and value['profile'] == PROFILE and sha(value['handoffSha256'])
        and type(value['avatarReplyProfileVersion'])is int and value['avatarReplyProfileVersion']==1)
    identifier(value['runId'])
    sealed(value['seal'])
    description(value['seal']['description'], area='avatar-people', run=value['runId'])
    if seal is not None:
        need(same(value['seal'], seal))
    exact(value['roles'], {'primary','actor'})
    exact(value['nativeReplies'],{'primary','actor'})
    owners = []
    for role, proof in value['roles'].items():
        need(type(proof) is dict and type(proof.get('iosOriginalKeeperRetirementVersion')) is int
            and proof['iosOriginalKeeperRetirementVersion'] == 1
            and proof['profile'] == 'ios-original-keeper-process-end-v1'
            and proof['profileKey'] == 'avatarkeeperreply' and proof['runId'] == value['runId']
            and proof['role'] == role and type(proof['stage']) is int and proof['stage'] == 0
            and proof['resourceRetirementEstablished'] is True)
        from feature_journeys.retirement_receipts import binding_from_context
        need(same(binding_from_context(proof['binding']), value['seal']['description']['roles'][role]['binding']))
        reply=value['nativeReplies'][role]
        need(type(reply)is dict and type(reply.get('iosAvatarReplyRetirementVersion'))is int
            and reply['iosAvatarReplyRetirementVersion']==1 and reply['role']==role
            and reply['nativeDescriptorDutyDischargedByOriginalProcessAbsence']is True
            and all(reply[k]is False for k in ('nativeInodeEstablished','nativeCloseReturnMeasured','nativeQualified','deviceQualified','wholeQualified')))
        owners.append(identifier(proof['ownerInstance']))
    # This new profile is the existing two-original-SDK Avatar composition.
    # A logical shared-creator end requires a different explicit contract.
    need(len(set(owners)) == 2)
    return value


def result(value):
    exact(value, {'stage','end','iosAvatarKeeperTerminalVersion','avatarReplyProfileVersion'})
    need(value['stage'] == 'finish' and type(value['iosAvatarKeeperTerminalVersion']) is int
        and value['iosAvatarKeeperTerminalVersion'] == 2
        and type(value['avatarReplyProfileVersion'])is int and value['avatarReplyProfileVersion']==1)
    end(value['end'])
    return value
