class _NativeMotionPassiveRead:
    """Actual same-source observation Task while held or after own Up/drain.

    This is read admission only. No source/native freshness, new input or
    resource-retirement claim follows from the old worker's returned context.
    """
    def __init__(self,owner,session,action,binding,run):
        from ios.adapters import lifecycle_world as world
        resource=owner.touch_resources;lease=owner.touch;task=asyncio.current_task()
        need(type(resource) is LifecycleTouchResourceOwner and resource.version==4
            and type(resource._native_step) is _NativeMotionWorkerGuard and type(lease) is TouchLease
            and resource._lease() is lease and getattr(lease,'_original_motion_resource',None) is resource
            and action in (world.ACTION,'feature-native-observe') and session==resource.binding['sessionId']
            and same(context(binding),resource.binding) and run==resource.run
            and isinstance(task,asyncio.Task) and task.get_loop() is owner.source._loop
            and owner.native_acquisition is None and owner.native_query_task is None and not owner.native_passive_tasks)
        # A known still-opening/moving/draining worker is not a readable
        # boundary. Refusal here does not revoke its immutable source; later
        # actual original return may establish a new readable phase.
        if lease.worker is None or (not lease.worker.done() and (lease.request_release.is_set() or lease.previous['phase']!='holding')):
            raise TouchTransportUnavailable('Original touch has not reached a stable held or returned context boundary')
        step=resource._native_step
        self._owner,self._resource,self._step,self._lease,self._task=weakref.ref(owner),weakref.ref(resource),weakref.ref(step),weakref.ref(lease),weakref.ref(task)
        self._action,self._session=action,session
        self._phase='released' if lease.worker is not None and lease.worker.done() else 'holding'
        self._query_function=owner.native_query.__func__;self._file_function=owner.native_original_read.__func__
        owner.native_passive_tasks[task]=self
        try:self.current()
        except BaseException:
            owner.native_passive_tasks.pop(task,None);raise
    def lease_identity(self,source,owner,lease,worker):
        resource,step,task=self._resource(),self._step(),self._task()
        need(owner is self._owner() and resource is not None and step is resource._native_step
            and step._source() is source and step._owner() is owner and step._lease() is lease
            and lease is self._lease() and worker is step._worker() and worker is lease.worker
            and task is asyncio.current_task() and isinstance(task,asyncio.Task) and not task.done()
            and task.get_loop() is source._loop and owner.native_passive_tasks.get(task) is self
            and owner.native_query.__func__ is self._query_function and owner.native_original_read.__func__ is self._file_function
            and owner.touch is lease and source._leases==[lease] and len(source._born)==1
            and source._born[0]['lease'] is lease and source._born[0]['worker'] is worker
            and source._born[0]['loop'] is source._loop and source._born[0]['release'] is lease.request_release
            and source._born[0]['owner'] is not None and source._born[0].get('motionResource') is resource)
        status=source._born[0]['owner']._status()
        need(not lease.journal_failed and lease.down_issued)
        if self._phase=='holding':
            need(not worker.done() and not lease.request_release.is_set() and not lease.up_issued
                and lease.previous['phase']=='holding' and status['workerRunning'] and status['hostResponsibility']
                and not status['contextExitReturned'] and source._loop.time()<lease._deadline())
        else:
            need(worker.done() and not worker.cancelled() and worker.exception() is None and lease.request_release.is_set()
                and lease.closed and lease.up_issued and status['contextExitReturned']
                and not status['workerRunning'] and not status['hostResponsibility'])
        from ios.adapters.lifecycle_touch_transport import intent
        need(same(intent(lease.previous),intent(step._opening)))
    def current(self):
        owner,resource,step=self._owner(),self._resource(),self._step()
        need(owner is not None and resource is not None and step is not None
            and owner.touch_resources is resource and resource._native_step is step)
        lease=self._lease();worker=step._worker()
        if lease is None or worker is None or lease.worker is not worker:
            step.fail();need(False)
        if self._phase=='holding' and (worker.done() or lease.request_release.is_set()):
            # A known ordinary release changes the observation phase; reject
            # THIS result without inventing source loss or preventing later
            # independently acquired released observations.
            raise TouchTransportUnavailable('Original touch observation crossed its held boundary')
        with resource.lock.held():step.scope()
        need(owner.scope(self._session) is resource._motion_rsd());return True
    @property
    def lease_id(self):
        self.current();return self._lease().previous['leaseId']
    def close(self):
        owner,task=self._owner(),self._task()
        need(owner is not None and task is asyncio.current_task() and owner.native_passive_tasks.get(task) is self)
        del owner.native_passive_tasks[task]


