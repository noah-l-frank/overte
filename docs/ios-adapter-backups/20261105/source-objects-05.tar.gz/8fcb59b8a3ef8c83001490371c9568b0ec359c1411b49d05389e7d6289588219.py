"""Versioned two-family handoff to ONE genuine OriginalKeeper process End.

This creates no OS/provider/native proof. The existing keeper constructor,
original RPCs, creator exit and canonical DELETE/404 must actually complete.
"""
from copy import deepcopy
from pathlib import Path
import os,time
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.normal_ui import NativeUIError
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same
from ios.adapters.audio_shared_actor_inventory import SharedActorCoordinator

PROFILE_KEY='audiosharedactor2'
ROOT='ios-audio-shared-actor2-process-end'
JOURNAL='ios-audio-shared-actor2-end.json'


class NativeReplyRetirementMissing(NativeUIError):pass


def reply_retirement_duty():
    from ios.adapters.audio_passive_capture_source import FILE as passive
    from ios.adapters.audio_received_mixer_source import FILE as received
    from adapters.native_feature_observation import FILE as clock
    return dict(iosAudioSharedActorNativeReplyDutyVersion=1,paths=sorted({passive,received,clock}),
        writerFDOriginals=None,oneWayNativeRetireOriginal=None,independentHouseArrestAbsenceOriginal=None,
        fileRetirementEstablished=False)


def end_root(coordinator):return coordinator.root/ROOT


def end_store(coordinator):
    from ios.adapters.original_keeper_process_end import filename
    return PrivateFeatureState(coordinator.sdkroot/filename(PROFILE_KEY,'actor',0))


class KeeperArchiveView:
    """Genuine read-only constructor over literal original keeper codecs.

    A pending original is retained/decoded but never represented as a complete
    retirement. Incomplete bytes refuse and remain an unresolved responsibility.
    No Source/client/SDK object or live owner is allocated by this view.
    """
    def __init__(self,coordinator):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd as Keeper
        self.store=end_store(coordinator);self.root=end_root(coordinator);self.lock=coordinator.lock
        self.binding=deepcopy(coordinator.binding);self.run=coordinator.run;self.role='actor';self.stage=0
        self.profile_key=PROFILE_KEY;self.profile='ios-original-keeper-process-end-v1'
        self.previous=self.store.read();need(self.previous is not None)
        self.state=self.decode(self.previous)
        self.files=OriginalFrameStore(self.root,self.binding,self.run,'actor',self.bound,lambda *_:need(False),
            namespace='original-process-end',schema_prefix='iosOriginalProcessEnd')
        self.bound()
    from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd as _Keeper
    decode=_Keeper.decode
    bound=_Keeper.bound
    original=_Keeper.original
    owned_paths=_Keeper.owned_paths
    validate_history=_Keeper.validate_history
    validate_sdk=staticmethod(_Keeper.validate_sdk)
    validate_creator=_Keeper.validate_creator
    _summary=_Keeper._summary

    def originals(self):
        self.bound();values=[]
        for ordinal,reference in enumerate(self.state['records'],1):
            need(reference['index']==ordinal);values.append(self.original(reference))
        pending=self.state['pending']
        if pending is not None:
            file=pending['file']
            if file is not None and file['phase']!='planned':self.files.read(file)
        else:self.validate_history()
        return dict(phase=self.state['phase'],pending=deepcopy(pending),records=values,retirementEstablished=False)


class SharedActorEnd:
    def __init__(self,coordinator,*,epoch_ms=lambda:time.time()*1000,monotonic=time.monotonic,sleep=time.sleep):
        need(type(coordinator)is SharedActorCoordinator);self.coordinator=coordinator
        self.lock,self.root=coordinator.lock,end_root(coordinator)
        self.epoch_ms,self.monotonic,self.sleep=epoch_ms,monotonic,sleep
        self.failed=False;self.store=PrivateFeatureState(coordinator.sdkroot/JOURNAL)
        self.previous=self.store.read();self.state=None
        self.files=OriginalFrameStore(self.root,coordinator.binding,coordinator.run,'actor',self.bound,self.intent,
            namespace='audio-shared-actor-end',schema_prefix='iosAudioSharedActorEnd',monotonic=monotonic)
        if self.previous is not None:
            value=self.previous
            exact(value,{'iosAudioSharedActorEndVersion','binding','runId','artifactRoot','state'})
            need(type(value['iosAudioSharedActorEndVersion'])is int and value['iosAudioSharedActorEndVersion']==2
                and same(value['binding'],coordinator.binding)and value['runId']==coordinator.run and value['artifactRoot']==str(self.root))
            self.state=deepcopy(value['state']);self.shape()

    def shape(self):
        exact(self.state,{'phase','snapshot','pending','keeperProof','responses','replyContext'})
        from ios.adapters.audio_response_command import FILES
        exact(self.state['responses'],set(FILES))
        if self.state['replyContext']is not None:
            context=self.state['replyContext'];exact(context,{'ownerInstance','bundleId','resultsDirectory','processSource'})
            need(type(context['ownerInstance'])is str and len(context['ownerInstance'])==32
                and set(context['ownerInstance'])<=set('0123456789abcdef')
                and type(context['bundleId'])is str and bool(context['bundleId'])
                and type(context['resultsDirectory'])is str and bool(context['resultsDirectory'])
                and type(context['processSource'])is dict)
        need(self.state['phase']in('snapshotting','ready','ending','complete'))
        if self.state['phase']=='complete':need(self.state['snapshot']is not None and self.state['pending']is None and self.state['keeperProof']is not None)

    def envelope(self):
        c=self.coordinator
        return dict(iosAudioSharedActorEndVersion=2,binding=deepcopy(c.binding),runId=c.run,artifactRoot=str(self.root),state=deepcopy(self.state))

    def bound(self,*,writing=False):
        self.lock.assert_held();need(not self.failed and same(self.store.read(),self.previous))
        self.coordinator.bound()
        if not writing and self.previous is not None:need(same(self.previous,self.envelope()))
        return True

    def save(self):
        try:
            self.bound(writing=True);self.shape();value=self.envelope();self.store.write(value,self.previous)
            need(same(self.store.read(),value));self.previous=deepcopy(value)
        except BaseException:self.failed=True;raise

    def intent(self,event,value):
        need(event=='original'and value['index']==1);self.files.original(value)
        self.state['pending']=deepcopy(value);self.save();return True

    def snapshot(self):
        c=self.coordinator;self.bound();value=c.original()
        need(set(value['families'])=={'microphone','received'})
        # Process death does not prove deletion of persistent capture files.
        # Their actual original release/absence must precede this Stop; only
        # the explicitly retained process-bound PCM/cache duties go to End.
        closures={}
        for kind,family in c.originals().items():
            need(not family.pending and family.owners)
            closures[kind]={lease:owner.episode_retired()for lease,owner in family.owners.items()}
        value.update(iosAudioSharedActorEndSnapshotVersion=2,coordinatorBindingSha256=digest(c.binding),episodeClosures=closures)
        return value

    def prepare(self):
        from ios.adapters.audio_passive_runtime import identity,fsync_directory
        c=self.coordinator;self.lock.assert_held()
        if c.state['end']is None:
            c.guard();need(self.previous is None and not self.root.exists())
            need(all(row['phase']=='opened'for row in c.state['families'].values()))
            for family in c.originals().values():
                need(not family.pending and family.owners)
                for owner in family.owners.values():owner.episode_retired()
            c.state['end']=dict(phase='planned',rootIdentity=None,proof=None);c.save()
        row=c.state['end']
        if row['phase']=='planned':
            need(not self.root.exists());os.mkdir(self.root,0o700);fsync_directory(c.root)
            row.update(phase='opened',rootIdentity=identity(self.root));c.save()
        need(identity(self.root)==row['rootIdentity'])
        if self.state is None:
            from ios.adapters.audio_shared_actor_response_retirement import empty
            self.state=dict(phase='snapshotting',snapshot=None,pending=None,keeperProof=None,responses=empty(),replyContext=None);self.save()
        if self.state['snapshot']is None:
            value=self.snapshot()
            if self.state['pending']is not None:
                pending=self.state['pending'];need(pending['phase']in('opened','saved')and same(self.files.read(pending),value))
                reference=self.files.compact(dict(pending,phase='saved'))
            else:reference=self.files.write(1,value)
            self.state.update(snapshot=reference,pending=None,phase='ready');self.save()
        return self.original_snapshot()

    def original_snapshot(self):
        self.bound();need(self.state is not None and self.state['snapshot']is not None)
        value=self.files.read(self.files.expand(self.state['snapshot']));current=self.snapshot()
        need(same(value,current));return value

    def owned_paths(self):
        self.bound();paths={self.store.path}
        if self.state is not None:
            if self.state['snapshot']is not None:
                reference=self.files.expand(self.state['snapshot']);self.files.read(reference);paths.add(self.files.path(reference))
            if self.state['pending']is not None:
                pending=self.state['pending'];self.files.original(pending)
                if pending['phase']=='planned':need(not self.files.path(pending).exists())
                else:self.files.read(pending);paths.add(self.files.path(pending))
        if self.state is not None:
            from ios.adapters.audio_response_command import FILES
            from ios.adapters.audio_shared_actor_response_retirement import ReplyReadView
            for filename in FILES:paths.update(ReplyReadView(self,filename).owned_paths())
        if end_store(self.coordinator).read()is not None:
            history=KeeperArchiveView(self.coordinator);history.originals();paths.update(history.owned_paths())
            if self.state['keeperProof']is not None:need(same(history._summary(),self.state['keeperProof']))
        need({path for path in paths if path.parent==self.root}==set(self.root.iterdir()))
        return paths

    def finish(self):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd as Keeper
        c=self.coordinator;self.prepare()
        if self.state['phase']=='complete':
            self.complete_parent();return self.original()
        self.original_snapshot()
        if self.state['phase']=='ready':self.state['phase']='ending';self.save()
        # ONE genuine creator, existing issued/recovery journal and actual
        # before_original_stop hook. No live owner is reconstructed by fields.
        keeper=Keeper(c.runtime,c.selector,self.root,c.binding,c.run,'actor',0,PROFILE_KEY,c.lock,
            epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep,shared_actor=c)
        proof=keeper.finish()
        # The pre-Stop hook wrote its own genuine PFS constructor. This earlier
        # object is now stale; reopen the actual durable header, never rebase it.
        current=SharedActorEnd(c,epoch_ms=self.epoch_ms,monotonic=self.monotonic,sleep=self.sleep)
        current.validate_keeper(proof)
        current.reply_original()
        current.state.update(phase='complete',keeperProof=deepcopy(proof));current.save()
        current.complete_parent();return current.original()

    def reply_original(self):
        from ios.adapters.audio_shared_actor_response_retirement import archived_original
        self.bound();return archived_original(self,KeeperArchiveView(self.coordinator))

    def complete_parent(self):
        self.bound();need(self.state['phase']=='complete');proof=self.state['keeperProof'];self.validate_keeper(proof)
        c=self.coordinator;row=c.state['end'];expected=dict(archiveSha256=digest(self.previous),keeperArchiveSha256=proof['archiveSha256'])
        need(row is not None and row['phase']in('opened','complete'))
        if row['phase']=='opened':row.update(phase='complete',proof=expected);c.save()
        else:need(row['proof']==expected)

    def validate_keeper(self,proof):
        from ios.adapters.original_keeper_process_end import IOSOriginalKeeperProcessEnd as Keeper
        c=self.coordinator
        need(proof['profileKey']==PROFILE_KEY and proof['binding']==c.binding and proof['runId']==c.run
            and proof['role']=='actor'and type(proof['stage'])is int and proof['stage']==0 and proof['resourceRetirementEstablished']is True)
        Keeper.archived_original(proof,store=end_store(c),root=self.root,binding=c.binding,run=c.run,role='actor',stage=0,profile_key=PROFILE_KEY,lock=c.lock)
        snapshot=self.original_snapshot();instances=set()
        from adapters.script_feature.history import unpack
        for family in snapshot['families'].values():
            for child in family['children']:
                state=unpack(child['owner']['payload'])[0]
                if state['instance']is not None:instances.add(state['instance'])
        need(len(instances)==1 and proof['nativeFeatureInstance']in instances)
        return True

    def original(self):
        self.bound();need(self.state is not None and self.state['phase']=='complete')
        proof=self.state['keeperProof'];self.validate_keeper(proof)
        c=self.coordinator;row=c.state['end']
        need(row is not None and row['phase']=='complete'and row['proof']==dict(archiveSha256=digest(self.previous),keeperArchiveSha256=proof['archiveSha256']))
        return dict(iosAudioSharedActorRetirementVersion=2,binding=deepcopy(c.binding),runId=c.run,
            originalSnapshot=self.original_snapshot(),singleOriginalKeeperProcessEnd=deepcopy(proof),
            bothFamiliesProcessAndSDKDischargedBySameOriginalCreator=True,familyCaptureFilesRetiredBeforeStop=True,
            originalReplyRetirement=self.reply_original(),retainedResponseArtifactsNotDischarged=False,secondStopIssued=False,
            physicalADCQualified=False,physicalDACQualified=False,acousticQualified=False,peerQualified=False,nativeQualified=False,wholeQualified=False)
