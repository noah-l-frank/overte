"""Exact future public-copy admission; historical proofs keep their own scopes."""
from pathlib import Path
import json
from host_common import REPO
SOURCE=REPO/'.ios-host-tmp/snapshot-actor25-public73-compatibility-bootstrap1-dirty-parent-source-private-20261104'
STAGING=REPO/'.ios-host-tmp/snapshot-actor-source9-primary-png-source7-integration-staging1-private-20261104'
STAGING_SHA='5d8b58717b0c65f314f1b8070b7ba0f74475965be1ff1d6c25d5c64497e45594'
PARENT_HEAD='cb79372ab9ec96df5e1320f9c573259ac3fbebed'
ACTOR=REPO/'.ios-host-tmp/snapshot-actor22-primary-png12-bootstrap1-source9-source7-code-preparation-20261104'
PUBLIC39=REPO/'.ios-host-tmp/snapshot-scene-public39-compatibility-bootstrap2-real-bootstrap-module-source-private-20261104'
ROOT34=REPO/'.ios-host-tmp/root-snapshot-actor34-originals-primary-png-qualified-host-results-20261104'
ROOT39=REPO/'.ios-host-tmp/root-snapshot-public39-current-origin-compatibility-qualified-results-20261104'
HTTP=REPO/'.ios-host-tmp/root-snapshot-shared-default-http-standard-check1-20261104'
COPY=REPO/'.ios-host-tmp/root-snapshot-actor25-public-copy32-provenance-20261104'

def packet(folder,leaf,digest,pin,physical):
    path=folder/leaf;value=pin(path);assert value['sha256']==digest;physical[str(path)]=value
    data=json.loads(path.read_text())
    for name,row in data['files'].items():
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        path=folder/name;value=pin(path)
        assert value['sha256']==(row if type(row)is str else row['sha256']);physical[str(path)]=value
    return data

def readiness(pin,copy_manifest,copy_manifest_sha):
    physical={}
    packet(STAGING,'source-freeze.json',STAGING_SHA,pin,physical)
    packet(ACTOR,'source-freeze.json','015058c8fb81a8261b9c86ecfd565dc0db54ae7e3a7f95934e1f532c95fbf58a',pin,physical)
    packet(PUBLIC39,'source-freeze.json','fe20bf2d64fc8317ab20b702a7d148455ee8390da7b7c6e20a0606e07bce4f6c',pin,physical)
    manifest_path=Path(copy_manifest)
    assert manifest_path.is_absolute()and manifest_path.resolve(strict=True)==manifest_path
    assert manifest_path.is_relative_to(REPO/'.ios-host-tmp')
    before=pin(manifest_path);assert before['sha256']==copy_manifest_sha
    manifest=json.loads(manifest_path.read_text());assert pin(manifest_path)==before
    physical[str(manifest_path)]=before
    assert type(manifest)is dict and set(manifest)=={'schemaVersion','status','expectedParentHead','stagingFreeze','publicFiles'}
    assert type(manifest['schemaVersion'])is int and manifest['schemaVersion']==1
    assert manifest['status']=='ROOT_REVIEWED_EXACT_UNCOMMITTED_SNAPSHOT_ACTOR25_COPY'
    assert manifest['expectedParentHead']==PARENT_HEAD and manifest['stagingFreeze']==STAGING_SHA
    candidate_rows=json.loads((STAGING/'ALL-CANDIDATES-AND-BASES.json').read_text())['rows']
    expected_copy={row['path']:row['candidateSha256']for row in candidate_rows}
    assert len(candidate_rows)==len(expected_copy)==32 and manifest['publicFiles']==expected_copy
    packet(COPY,'freeze.json','6174308eae5013a25c1edf70840e8d944639c82e6ae723ea23d22855d9ba80d3',pin,physical)
    copied=json.loads((COPY/'copy.json').read_text())
    assert copied['status']=='ROOT_COPIED_EXACT_ACTOR25_AND_SEVEN_METADATA_DOC_PATHS_TO_PUBLIC'
    assert copied['parentHead']==PARENT_HEAD and copied['sourceFreeze']==STAGING_SHA and copied['expectedUncommittedPaths']==32
    assert copied['currentPublicCompatibilityQualified']is copied['nativeCompiled']is copied['nativeQualified']is copied['wholeQualified']is False
    assert len(copied['rows'])==32 and {row['path']:row['actualPublicSha256']for row in copied['rows']}==expected_copy
    assert all(row['actualPublicPath']==str(REPO/row['path'])and row['actualPublicSha256']==row['candidateSha256']for row in copied['rows'])
    stage=json.loads((STAGING/'STAGING-MANIFEST.json').read_text())
    implementation={row['path']:row['sha256']for row in stage['currentSource1354Public32']}
    assert len(implementation)==32
    implementation.update({row['path']:row['candidateSha256']for row in stage['rows']})
    assert len(stage['rows'])==25 and len(implementation)==45
    expected_public=dict(implementation)
    expected_public.update(expected_copy)
    assert len(expected_public)==52
    # The current docs/registry are the newly reviewed copy, not old37 pins.
    public={}
    for logical,digest in expected_public.items():
        relative=Path(logical);assert not relative.is_absolute()and '..'not in relative.parts
        path=REPO/relative;value=pin(path);assert value['sha256']==digest
        physical[str(path)]=value;public[logical]=digest
    declaration_path=SOURCE/'SUBJECT-DECLARATIONS.json';physical[str(declaration_path)]=pin(declaration_path)
    declarations=json.loads(declaration_path.read_text())['subjects']
    origins={};private_pure={};public_origins={}
    for name,row in declarations.items():
        path=Path(row['path']);value=pin(path);assert value['sha256']==row['sha256'];physical[str(path)]=value
        expected=dict(path=str(path),sha256=value['sha256']);origins[name]=expected
        if row['category']=='current-public-definition':
            assert path==REPO/'tests/device'/Path(*name.split('.')).with_suffix('.py')
            assert path.is_relative_to(REPO/'tests/device')
            public_origins[name]=expected
        else:
            assert row['category']=='explicit-private-pure-test-only'
            assert name=='snapshot_public_fixture_default_cases'and path==PUBLIC39/'snapshot_public_fixture_default_cases.py'
            private_pure[name]=expected
    assert len(origins)==46 and len(public_origins)==45 and len(private_pure)==1
    packet(ROOT34,'freeze.json','9ab60f35c1b7309f8e255c73bbcf1ed2bcc15335c56224d0c53cfc6e597779b6',pin,physical)
    result34=json.loads((ROOT34/'results.json').read_text())
    assert result34['status']=='ROOT_QUALIFIED_SNAPSHOT_ACTOR22_PRIMARY_PNG12_HOST_COMPONENTS'
    assert result34['actualCases']==result34['actualPassedCases']==34 and result34['genuineTemporaryDirectories']==82
    assert result34['actualSourceBootstrapFreeze']=='015058c8fb81a8261b9c86ecfd565dc0db54ae7e3a7f95934e1f532c95fbf58a'
    assert result34['hostActorOriginalModelsQualified']is result34['hostPrimaryActorOriginalCropEqualityQualified']is True
    assert result34['nativeCompiled']is result34['nativeQualified']is result34['wholeQualified']is False
    packet(ROOT39,'freeze.json','f668d54434f1c069897dbb6828a168987b60867422d0353ae3a11a283c0b3ee1',pin,physical)
    result39=json.loads((ROOT39/'results.json').read_text())
    assert result39['status']=='ROOT_QUALIFIED_CURRENT_PUBLIC_SNAPSHOT39_COMPATIBILITY_COMPONENTS'
    assert result39['actualCases']==result39['actualPassedCases']==39 and result39['currentPublicCompatibilityQualified']is True
    assert result39['nativeQualified']is result39['wholeQualified']is result39['actorPixelsQualified']is False
    recipe=json.loads((SOURCE/'SOURCE-RECIPE.json').read_text())
    actual=[case for group in recipe['groupOrder']for case in recipe['groups'][group]['cases']]
    assert actual==result39['cases']+result34['cases']and len(actual)==len(set(actual))==73
    # Actual old HTTP execution is kept as DATA, never a new-copy transport PASS.
    packet(HTTP,'freeze.json','62a12a4f71b08c905e10b4afc39356eb0642a3aa310dcc02faeb2d536b646af5',pin,physical)
    http=json.loads((HTTP/'results.json').read_text())
    assert http['status']=='PASS'and http['testsRun']==1 and http['realLoopbackHTTP']and http['resourcesRestored']and http['publicSourcePinsUnchanged']
    assert http['snapshotActorTransportQualified']is http['wholeQualified']is http['nativeCompiled']is False
    required=set(result39['requiredOriginalRoots'])|set(result34['newOriginalRoots'])|{str(HTTP)}
    return dict(publicCopyManifest=dict(path=str(manifest_path),sha256=copy_manifest_sha),expectedParentHead=PARENT_HEAD,
        actualRootCopyProvenance='6174308eae5013a25c1edf70840e8d944639c82e6ae723ea23d22855d9ba80d3',
        publicCopyPaths=expected_copy,publicImplementationPaths=implementation,publicPaths=public,
        subjectOrigins=origins,publicSubjectOrigins=public_origins,privatePureTestOrigins=private_pure,
        privateOverlayOrigins={},source9RootReview=recipe['source9RootReview'],
        historicalPublic39Proof='f668d54434f1c069897dbb6828a168987b60867422d0353ae3a11a283c0b3ee1',
        actualOriginalActor34Proof='9ab60f35c1b7309f8e255c73bbcf1ed2bcc15335c56224d0c53cfc6e597779b6',
        historicalSharedHTTPProof=dict(freeze='62a12a4f71b08c905e10b4afc39356eb0642a3aa310dcc02faeb2d536b646af5',
            appliesToOriginalSource1354Only=True,currentPublicCopyHTTPQualified=False),
        requiredOriginalRoots=sorted(required),allImplementationDefiningOriginsPublic=True,
        source9HostCountersQualifiedAtOriginalOrigins=True,source7ComparisonQualifiedAtOriginalOrigins=True,
        freshPublicCompatibilityQualified=False,nativeAdmission=None,nativeQualified=False,wholeQualified=False),physical
