"""Genuine FileFinder metadata selection; no SDK module is executed here.

All source/extension alternatives remain physical DATA. Default interpreter
loader order and package precedence choose the one actual execution delegate.
"""
from pathlib import Path
import importlib.machinery as machinery
from importlib import _bootstrap_external as external

_FINDER=machinery.FileFinder
_DETAILS=external._get_supported_file_loaders
_SOURCE=machinery.SourceFileLoader
_EXTENSION=machinery.ExtensionFileLoader
_SUFFIXES=tuple(machinery.EXTENSION_SUFFIXES)
_CONTROLS=tuple((owner,name,getattr(owner,name),getattr(owner,name).__code__,getattr(owner,name).__globals__)
    for owner,names in((external,('_get_supported_file_loaders',)),(_FINDER,('__init__','find_spec','_get_spec','_fill_cache')))
    for name in names)


def controls():
    assert machinery.FileFinder is _FINDER and external._get_supported_file_loaders is _DETAILS
    assert machinery.SourceFileLoader is _SOURCE and machinery.ExtensionFileLoader is _EXTENSION
    assert tuple(machinery.EXTENSION_SUFFIXES)==_SUFFIXES
    for owner,name,function,code,namespace in _CONTROLS:
        assert getattr(owner,name)is function and function.__code__ is code and function.__globals__ is namespace


def select_sdk_delegates(root,copies):
    controls();root=Path(root);assert root.is_absolute()and root.resolve(strict=True)==root
    details=_DETAILS() # Genuine interpreter loader order, not custom suffix sorting.
    order=[dict(loaderModule=loader.__module__,loaderName=loader.__qualname__,suffixes=list(suffixes))for loader,suffixes in details]
    candidates={}
    for relative,original in sorted(copies.items()):
        path=Path(original['path']);assert path==root/relative and path.resolve(strict=True)==path
        parts=Path(relative).parts;package=False;module=None;kind=None
        if path.suffix=='.py':
            parts=(*parts[:-1],path.stem);kind='source'
        else:
            for suffix in _SUFFIXES:
                if path.name.endswith(suffix):parts=(*parts[:-1],path.name[:-len(suffix)]);kind='extension';break
        if kind is None:continue # Non-module support bytes remain copied/pinned DATA.
        package=parts[-1]=='__init__';parts=parts[:-1]if package else parts
        if not parts or not all(n.isidentifier()for n in parts):continue
        module='.'.join(parts)
        entry=dict(path=str(path),sha256=original['pin']['sha256'],package=package,loader=kind)
        alternatives=candidates.setdefault(module,[])
        assert not any(row['entry']['path']==str(path)for row in alternatives)
        alternatives.append(dict(entry=entry,relative=relative,physicalPin=original['pin'],
            originalSource=original['original'],originalSourcePin=original['originalPin'],
            selectedSourceBytes=original['selectedOriginal']))
    selected={};observations={};finders={}
    for fullname,alternatives in sorted(candidates.items()):
        parent=root.joinpath(*fullname.split('.')[:-1]);assert parent.is_dir()and parent.resolve(strict=True)==parent
        finder=finders.get(str(parent))
        if finder is None:finder=_FINDER(str(parent),*details);finders[str(parent)]=finder
        controls();spec=finder.find_spec(fullname) # No create_module/exec/import.
        assert spec is not None and spec.name==fullname and type(spec.loader)in(_SOURCE,_EXTENSION),('Unsupported real SDK delegate',fullname)
        path=Path(spec.origin);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_relative_to(root)
        loader='source'if type(spec.loader)is _SOURCE else'extension';package=spec.submodule_search_locations is not None
        assert spec.loader.name==fullname and spec.loader.path==str(path)
        matches=[row for row in alternatives if row['entry']['path']==str(path)and row['entry']['loader']==loader and row['entry']['package']==package]
        assert len(matches)==1,('Real FileFinder selected an undeclared SDK original',fullname,str(path))
        chosen=matches[0];selected[fullname]=dict(chosen['entry'])
        if package:assert list(spec.submodule_search_locations)==[str(path.parent)]
        observations[fullname]=dict(actualDefaultFileFinderDirectory=str(parent),actualSpecOrigin=str(path),
            actualLoaderModule=type(spec.loader).__module__,actualLoaderName=type(spec.loader).__qualname__,
            actualPackage=package,selectedRelative=chosen['relative'],selectedPhysicalPin=chosen['physicalPin'],
            alternatives=alternatives,shadowedRelativePaths=[row['relative']for row in alternatives if row is not chosen],
            shadowedFilesRetainedAsData=True,SDKModuleExecutedBySelection=False)
    # A child cannot borrow an arbitrary real directory behind a selected
    # non-package parent. Missing package entries must be genuine namespaces.
    namespace_parents={}
    for fullname in selected:
        parts=fullname.split('.')
        for size in range(1,len(parts)):
            prefix='.'.join(parts[:size])
            if prefix in selected:
                assert selected[prefix]['package'],('Selected SDK parent is not a package',prefix,fullname)
                continue
            if prefix in namespace_parents:continue
            parent=root.joinpath(*parts[:size-1]);finder=finders.get(str(parent))
            if finder is None:finder=_FINDER(str(parent),*details);finders[str(parent)]=finder
            controls();spec=finder.find_spec(prefix);expected=str(root.joinpath(*parts[:size]))
            assert spec is not None and spec.name==prefix and spec.loader is None and spec.origin is None
            assert list(spec.submodule_search_locations)==[expected]
            namespace_parents[prefix]=[expected]
    controls()
    return selected,dict(schemaVersion=1,actualDefaultLoaderOrder=order,modules=observations,
        actualGenuineNamespaceParents=namespace_parents,
        physicalModuleAlternatives=sum(map(len,candidates.values())),selectedModuleCount=len(selected),
        collisionModuleNames=[name for name,rows in sorted(candidates.items())if len(rows)>1],
        packagePreferenceFromGenuineFileFinder=True,SDKExecutionByMetadataSelector=False,
        customLoaderFallback=False,sourcelessDelegateAdmitted=False)
