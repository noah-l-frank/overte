// Copyright (C) 2024 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:critical data-parser

#include "qv4compileddata_p.h"

#include <private/inlinecomponentutils_p.h>
#include <private/qqmlscriptdata_p.h>
#include <private/qqmltypenamecache_p.h>
#include <private/qv4resolvedtypereference_p.h>

#include <QtQml/qqmlfile.h>

#include <QtCore/qdir.h>
#include <QtCore/qscopeguard.h>
#include <QtCore/qstandardpaths.h>
#include <QtCore/qxpfunctional.h>

QT_BEGIN_NAMESPACE
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
namespace QV4::OverteCacheOriginals {
namespace { std::atomic<bool> admitted { false },unavailable { false };std::atomic<quint64> sequence { 0 }; }
bool active() noexcept { return admitted.load() && !unavailable.load(); }
void setEnabled(bool value) noexcept { admitted.store(value); }
void fail() noexcept { unavailable.store(true); }
quint64 next() noexcept {
    const auto value=sequence.fetch_add(1)+1;
    if (value==0 || value>1000000000) { fail();return 0; }
    return value;
}
}
#endif

namespace QV4 {
namespace CompiledData {


bool Unit::verifyHeader(QDateTime expectedSourceTimeStamp, QString *errorString) const
{
    if (strncmp(magic, CompiledData::magic_str, sizeof(magic))) {
        *errorString = QStringLiteral("Magic bytes in the header do not match");
        return false;
    }

    if (version != quint32(QV4_DATA_STRUCTURE_VERSION)) {
        *errorString = QString::fromUtf8("V4 data structure version mismatch. Found %1 expected %2")
                               .arg(quint32(version), 0, 16).arg(QV4_DATA_STRUCTURE_VERSION, 0, 16);
        return false;
    }

    if (sourceTimeStamp) {
        // Files from the resource system do not have any time stamps, so fall back to the application
        // executable.
        if (!expectedSourceTimeStamp.isValid())
            expectedSourceTimeStamp = QFileInfo(QCoreApplication::applicationFilePath()).lastModified();

        if (expectedSourceTimeStamp.isValid()
            && expectedSourceTimeStamp.toMSecsSinceEpoch() != sourceTimeStamp) {
            *errorString = QStringLiteral("QML source file has a different time stamp than cached file.");
            return false;
        }
    }

    return true;
}

/*!
    \internal
    This function creates a temporary key vector and sorts it to guarantuee a stable
    hash. This is used to calculate a check-sum on dependent meta-objects.
 */
bool ResolvedTypeReferenceMap::addToHash(
        QCryptographicHash *hash, QHash<quintptr, QByteArray> *checksums) const
{
    std::vector<int> keys (size());
    int i = 0;
    for (auto it = constBegin(), end = constEnd(); it != end; ++it) {
        keys[i] = it.key();
        ++i;
    }
    std::sort(keys.begin(), keys.end());
    for (int key: keys) {
        if (!this->operator[](key)->addToHash(hash, checksums))
            return false;
    }

    return true;
}

CompilationUnit::CompilationUnit(
        const Unit *unitData, const QString &fileName, const QString &finalUrlString)
{
    setUnitData(unitData, nullptr, fileName, finalUrlString);
}

CompilationUnit::~CompilationUnit()
{
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    overteE2eInvalidateSourceReceipt();
#endif
    qDeleteAll(resolvedTypes);

    if (data) {
        if (data->qmlUnit() != qmlData)
            free(const_cast<QmlUnit *>(qmlData));
        qmlData = nullptr;

        if (!(data->flags & QV4::CompiledData::Unit::StaticData))
            free(const_cast<Unit *>(data));
    }
    data = nullptr;
#if Q_BYTE_ORDER == Q_BIG_ENDIAN
    delete [] constants;
    constants = nullptr;
#endif
}

QString CompilationUnit::localCacheFilePath(const QUrl &url)
{
    static const QByteArray envCachePath = qgetenv("QML_DISK_CACHE_PATH");

    const QString localSourcePath = QQmlFile::urlToLocalFileOrQrc(url);
    const QString cacheFileSuffix
            = QFileInfo(localSourcePath + QLatin1Char('c')).completeSuffix();
    QCryptographicHash fileNameHash(QCryptographicHash::Sha1);
    fileNameHash.addData(localSourcePath.toUtf8());
    QString directory = envCachePath.isEmpty()
            ? QStandardPaths::writableLocation(QStandardPaths::CacheLocation)
                    + QLatin1String("/qmlcache/")
            : QString::fromLocal8Bit(envCachePath) + QLatin1String("/");
    QDir::root().mkpath(directory);
    return directory + QString::fromUtf8(fileNameHash.result().toHex())
            + QLatin1Char('.') + cacheFileSuffix;
}

bool CompilationUnit::loadFromDisk(
        const QUrl &url, const QDateTime &sourceTimeStamp, QString *errorString)
{
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    // Preserve only the actual preceding write as a candidate; the mapper
    // must independently bind its opened FD and mapped bytes before adoption.
    const auto observedCacheWrite=overteE2eCacheWriteOriginal;
    overteE2eInvalidateSourceReceipt();
#endif
    if (!QQmlFile::isLocalFile(url)) {
        *errorString = QStringLiteral("File has to be a local file.");
        return false;
    }

    const QString sourcePath = QQmlFile::urlToLocalFileOrQrc(url);
    auto cacheFile = std::make_unique<CompilationUnitMapper>();
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    cacheFile->setOverteE2eExpectedWrite(observedCacheWrite);
#endif

    const QStringList cachePaths = { sourcePath + QLatin1Char('c'), localCacheFilePath(url) };
    for (const QString &cachePath : cachePaths) {
        Unit *mappedUnit = cacheFile->get(cachePath, sourceTimeStamp, errorString);
        if (!mappedUnit)
            continue;

        const Unit *oldData = unitData();
        const Unit * const oldDataPtr
                = (oldData && !(oldData->flags & Unit::StaticData))
                ? oldData
                : nullptr;

        auto dataPtrRevert = qScopeGuard([this, oldData](){
            setUnitData(oldData);
        });
        setUnitData(mappedUnit);

        if (mappedUnit->sourceFileIndex != 0) {
            if (mappedUnit->sourceFileIndex >=
                mappedUnit->stringTableSize + dynamicStrings.size()) {
                *errorString = QStringLiteral("QML source file index is invalid.");
                continue;
            }
            if (sourcePath !=
                QQmlFile::urlToLocalFileOrQrc(stringAt(mappedUnit->sourceFileIndex))) {
                *errorString = QStringLiteral("QML source file has moved to a different location.");
                continue;
            }
        }

        dataPtrRevert.dismiss();
        free(const_cast<Unit*>(oldDataPtr));
        backingFile = std::move(cacheFile);
        return true;
    }

    return false;
}

bool CompilationUnit::saveToDisk(const QUrl &unitUrl, QString *errorString)
{
    if (unitData()->sourceTimeStamp == 0) {
        *errorString = QStringLiteral("Missing time stamp for source file");
        return false;
    }

    if (!QQmlFile::isLocalFile(unitUrl)) {
        *errorString = QStringLiteral("File has to be a local file.");
        return false;
    }

#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    // This executes BEFORE SaveableUnitPointer temporarily changes StaticData.
    QVariantMap compilerInput;
    const auto *observedUnit=data;const auto observedGeneration=overteE2eSourceGeneration;
    QT_TRY {
        if (OverteCacheOriginals::active() && data && !aotCompiledFunctions
                && !overteE2ePendingCompilerInput.isEmpty()
                && data->unitSize>0 && data->unitSize<=4*1024*1024
                && OverteCacheOriginals::sha(data,data->unitSize)
                    ==overteE2ePendingCompilerInput.value("compilerUnitSha256").toString()) {
            if (overteE2eOwnerId.isEmpty()) overteE2eOwnerId=OverteCacheOriginals::nonce();
            compilerInput=overteE2ePendingCompilerInput;
        }
        if (data!=observedUnit || overteE2eSourceGeneration!=observedGeneration) compilerInput.clear();
        overteE2eCacheWriteOriginal.clear();
    } QT_CATCH (...) { OverteCacheOriginals::fail(); }
#endif
    return SaveableUnitPointer(unitData()).saveToDisk<char>(
            [this,&unitUrl, errorString
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
             ,compilerInput,observedUnit,observedGeneration
#endif
             ](const char *data, quint32 size) {
                const QString cachePath = localCacheFilePath(unitUrl);
                if (SaveableUnitPointer::writeDataToFile(
                            cachePath, data, size, errorString
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
                            ,(unitData()==observedUnit && overteE2eSourceGeneration==observedGeneration
                                && data==reinterpret_cast<const char *>(observedUnit)) ? &overteE2eCacheWriteOriginal : nullptr,
                            compilerInput,overteE2eOwnerId,observedGeneration
#endif
                            )) {
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
                    if (unitData()!=observedUnit || overteE2eSourceGeneration!=observedGeneration)
                        overteE2eCacheWriteOriginal.clear();
#endif
                    CompilationUnitMapper::invalidate(cachePath);
                    return true;
                }

                return false;
            });
}

#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
QVariantMap CompilationUnit::overteE2eCacheOriginalForCurrentUnit() const
{
    QT_TRY {
        if (!OverteCacheOriginals::active() || !data || !backingFile || aotCompiledFunctions
                || overteE2eOwnerId.isEmpty() || overteE2eSourceGeneration>=1000000000) return {};
        const auto *pointer=data;const auto generation=overteE2eSourceGeneration;
        const auto bytes=pointer->unitSize;const auto before=OverteCacheOriginals::clock();
        const auto actual=backingFile->overteE2eOriginalFor(pointer);
        const auto after=OverteCacheOriginals::clock();
        if (actual.isEmpty() || data!=pointer || overteE2eSourceGeneration!=generation || pointer->unitSize!=bytes) return {};
        return {{QStringLiteral("qtOverteQmlCacheUnitVersion"),1},{QStringLiteral("clockDomain"),QStringLiteral("native-qt-steady-clock")},{QStringLiteral("processId"),QCoreApplication::applicationPid()},
            {QStringLiteral("unitOwnerId"),overteE2eOwnerId},{QStringLiteral("unitReadBefore"),before},{QStringLiteral("unitReadAfter"),after},
            {QStringLiteral("unitGeneration"),qulonglong(generation)},
            {QStringLiteral("unitBytes"),qlonglong(bytes)},
            {QStringLiteral("unitSha256"),actual.value(QStringLiteral("mappedSha256"))},
            {QStringLiteral("mappingOriginal"),actual}};
    } QT_CATCH (...) { OverteCacheOriginals::fail();return {}; }
}
#endif

QStringList CompilationUnit::moduleRequests() const
{
    QStringList requests;
    requests.reserve(data->moduleRequestTableSize);
    for (uint i = 0; i < data->moduleRequestTableSize; ++i)
        requests << stringAt(data->moduleRequestTable()[i]);
    return requests;
}

ResolvedTypeReference *CompilationUnit::resolvedType(QMetaType type) const
{
    for (ResolvedTypeReference *ref : std::as_const(resolvedTypes)) {
        if (ref->type().typeId() == type)
            return ref;
    }
    return nullptr;

}

void CompiledData::CompilationUnit::finalizeCompositeType(const QQmlType &type)
{
    // Add to type registry of composites
    if (propertyCaches.needsVMEMetaObject(/*root object*/0)) {
        // qmlType is only valid for types that have references to themselves.
        if (type.isValid()) {
            qmlType = type;
        } else {
            qmlType = QQmlMetaType::findCompositeType(
                    url(), this, (unitData()->flags & CompiledData::Unit::IsSingleton)
                            ? QQmlMetaType::Singleton
                            : QQmlMetaType::NonSingleton);
        }

        QQmlMetaType::registerInternalCompositeType(this);
    } else {
        const QV4::CompiledData::Object *obj = objectAt(/*root object*/0);
        auto *typeRef = resolvedTypes.value(obj->inheritedTypeNameIndex);
        Q_ASSERT(typeRef);
        qmlType = typeRef->type();
    }
}

bool CompilationUnit::verifyChecksum(const DependentTypesHasher &dependencyHasher) const
{
    if (!dependencyHasher) {
        for (size_t i = 0; i < sizeof(data->dependencyMD5Checksum); ++i) {
            if (data->dependencyMD5Checksum[i] != 0)
                return false;
        }
        return true;
    }
    const QByteArray checksum = dependencyHasher();
    return checksum.size() == sizeof(data->dependencyMD5Checksum)
            && memcmp(data->dependencyMD5Checksum, checksum.constData(),
                      sizeof(data->dependencyMD5Checksum)) == 0;
}

QQmlType CompilationUnit::qmlTypeForComponent(const QString &inlineComponentName) const
{
    if (inlineComponentName.isEmpty())
        return qmlType;
    return inlineComponentData[inlineComponentName].qmlType;
}

} // namespace CompiledData
} // namespace QV4

QT_END_NAMESPACE
