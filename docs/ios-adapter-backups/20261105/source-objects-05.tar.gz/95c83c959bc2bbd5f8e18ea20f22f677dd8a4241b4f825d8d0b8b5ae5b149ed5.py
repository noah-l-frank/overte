"""Actual pipe bytes, including subprocess.communicate's original os ports."""
import io,os
class Bytes(io.BufferedIOBase):
    def __init__(self,actual,log,process,reading):
        super().__init__();self.actual,self.log,self.process,self.reading=actual,log,process,reading;self.eof=False;self.count=0
    def readable(self):return self.reading
    def writable(self):return not self.reading
    def seekable(self):return False
    def fileno(self):return self.actual.fileno()
    def seen(self,value):
        assert type(value)is bytes
        if value:assert self.log.write(value)==len(value);self.count+=len(value)
        elif self.reading:self.eof=True
        return value
    def read(self,size=-1):assert self.reading;return self.seen(self.actual.read(size))
    def read1(self,size=-1):assert self.reading;return self.seen(self.actual.read1(size))
    def readinto(self,buffer):
        value=self.read(len(buffer));buffer[:len(value)]=value;return len(value)
    def write(self,value):
        assert not self.reading;count=self.actual.write(value);self.seen(bytes(value[:count]));return count
    def flush(self):
        if not self.actual.closed:self.actual.flush()
        if not self.log.closed:self.log.flush()
    def close(self):
        if self.closed:return
        try:
            if self.reading and not self.actual.closed and not self.eof:
                assert self.process.poll()is not None,'No unbounded drain of a live original writer'
                while not self.eof:self.seen(self.actual.read(65536))
            self.flush()
        finally:
            try:self.actual.close()
            finally:self.log.close();super().close()
def install(process,root):
    rows=[]
    for name in('stdin','stdout','stderr'):
        stream=getattr(process,name);assert type(stream)is io.TextIOWrapper and stream.newlines is None
        options=dict(encoding=stream.encoding,errors=stream.errors,newline=None,line_buffering=stream.line_buffering,write_through=stream.write_through)
        path=root/(name+'.bin');fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);log=os.fdopen(fd,'wb',buffering=0)
        original=stream.detach();buffer=Bytes(original,log,process,name!='stdin');text=io.TextIOWrapper(buffer,**options)
        setattr(process,name,text);rows.append(dict(name=name,buffer=buffer,text=text,path=path,fd=original.fileno(),stat=os.fstat(original.fileno())))
    return rows
