"""Genuine Callback8 prefix, real new end constructors, explicit raw OS model.

This is a new typed composition, not a replay of the old Whole600 test. The
original modeled producer clocks/ordinary waits remain unchanged. Actual wall
performance/native/device acceptance is not inferred from those clocks.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import unittest
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from feature_journeys.witness import Client
from ios.adapters.emote_runtime import IOSEmoteRuntime
from ios.adapters.emote_observer import EmoteObservationPending
from ios.adapters.emote_callback_sdk_cut import IOSEmoteCallbackSDKCut
from ios.self_tests.emote_callback_whole_end_fixture import CallbackWholeEndFixture


class CallbackTypedEndTests(unittest.TestCase):
    def prefix(self):
        f=CallbackWholeEndFixture(self,retain_originals=True);normal=f.normal;p,a=normal.flow,normal.actor.flow
        call=dict(contractVersion=16,runId=p.run,afterSequence=0)
        p.observe(call);a.observe(call);p.act(normal.call('play',name='Crying'));normal.target.native.sleep(.25)
        self.assertTrue(a.observe(call)['state']['override']);p.act(normal.call('cancel'));self.assertFalse(a.observe(call)['state']['override'])
        normal.call('cleanup');cleanup=dict(contractVersion=16,runId=p.run)
        def waiting(seconds):
            if p.lock._owner is None and p.primary_lock._owner is None:
                self.assertIsNone(a.lock._owner);a.cleanup(cleanup)
            normal.target.domain.sleep(seconds)
        p.sleep=waiting;self.assertEqual(dict(performed=True),p.cleanup(cleanup))
        reader=Client(normal.target.client.url,'r'*64);samples=[]
        for index in range(3):
            primary=p.observe(call);actor=a.observe(call);matches=[row for row in reader.request('/runs/'+p.run)['entries'] if row['actorSequence']==actor['sequence']]
            self.assertEqual(1,len(matches));samples.append(dict(primary=primary,actor=matches[0]))
            if index<2:normal.target.domain.sleep(1.6)
        inspected=f.terminal.invoke(dict(contractVersion=16,runId=p.run,stage='inspect'))
        sealed=f.terminal.invoke(dict(contractVersion=16,runId=p.run,stage='seal',description=inspected['description'],samples=samples))
        reader.request('/runs/'+p.run,method='DELETE');return f,sealed['seal']
    def invoke(self,f,seal):
        return IOSEmoteRuntime._emote_callback_end_checkpoint(f.runtime,f.facades['primary'],seal,f.facades['actor'])
    def complete(self,f,seal):
        for _attempt in range(25):
            try:return self.invoke(f,seal)
            except EmoteObservationPending:
                self.assertIsNone(f.facades['primary'].lock._owner);self.assertIsNone(f.facades['actor'].lock._owner)
                f.normal.target.domain.sleep(1.6)
        self.fail('Existing bounded producer schedule did not complete the new typed end')
    def feature_paths(self,f):return [item.store for item in f.facades.values()]
    def test_fresh_genuine_callback_fence_stop_os_sdk_end_and_historical_no_replay(self):
        f,seal=self.prefix();inputs=deepcopy(f.normal.target.vm.state['events']);actual=self.complete(f,seal)
        self.assertEqual('finish',actual['stage']);self.assertEqual(seal,actual['end']['seal'])
        self.assertEqual(['actor','primary'],f.stops);self.assertEqual({'actor','primary'},f.deleted)
        for role in ('actor','primary'):
            self.assertEqual(1,len([row for row in f.calls if row[0]==role and row[1]=='DELETE']))
            self.assertIsNone(f.base.read_session(role));self.assertIsNone(f.base._binding_store(role).read())
        self.assertTrue(all(store.read() is None for store in self.feature_paths(f)))
        calls,reads,factories=deepcopy(f.calls),deepcopy(f.native_reads),deepcopy(f.source_factories)
        self.assertEqual(actual,IOSEmoteRuntime._emote_callback_end_checkpoint(f.runtime,f.facades['primary'],seal));self.assertEqual(calls,f.calls);self.assertEqual(reads,f.native_reads);self.assertEqual(factories,f.source_factories)
        self.assertEqual(inputs,f.normal.target.vm.state['events'])
        # Source presence still does not open the ordinary public Finish.
        with self.assertRaises(EmoteObservationPending):f.terminal.invoke(dict(contractVersion=16,runId=f.normal.flow.run,stage='finish',seal=seal))
    def test_actual_lost_stop_reply_keeps_issued_owner_and_never_reconstructs_stopped_live_sources(self):
        f,seal=self.prefix();f.fault='lost-stop'
        with self.assertRaises(BaseException):self.invoke(f,seal)
        self.assertEqual(['actor'],f.stops)
        path=f.facades['actor'].store.path.with_name('ios-emote-actor-'+f.normal.flow.run+'-callback-process-end.json')
        from adapters.script_feature.history import unpack
        self.assertEqual('stop-issued',unpack(PrivateFeatureState(path).read()['payload'])[0]['phase'])
        f.fault='';before=len(f.source_factories);actual=self.complete(f,seal)
        self.assertEqual('finish',actual['stage']);self.assertEqual(['actor','primary'],f.stops)
        self.assertTrue(all(role!='actor' for role in f.source_factories[before:]))
    def test_real_lost_sdk_delete_reply_is_observed_as_404_without_resend(self):
        f,seal=self.prefix();f.fault='lost-sdk'
        with self.assertRaises(BaseException):self.complete(f,seal)
        self.assertEqual(1,len([row for row in f.calls if row[0]=='actor' and row[1]=='DELETE']))
        f.fault='';actual=self.complete(f,seal);self.assertEqual('finish',actual['stage'])
        self.assertEqual(1,len([row for row in f.calls if row[0]=='actor' and row[1]=='DELETE']))
    def test_ignored_sdk_delete_refuses_and_keeps_metadata_without_second_delete(self):
        f,seal=self.prefix();f.fault='ignored-sdk'
        with self.assertRaises(NativeUIError):self.complete(f,seal)
        for _ in range(2):
            with self.assertRaises(NativeUIError):self.invoke(f,seal)
        self.assertEqual(1,len([row for row in f.calls if row[0]=='actor' and row[1]=='DELETE']))
        self.assertEqual(0,len([row for row in f.calls if row[0]=='primary' and row[1]=='DELETE']))
        self.assertTrue(all(store.read() is not None for store in self.feature_paths(f)))
    def test_new_unknown_carrier_before_actual_sdk_dispatch_blocks_delete_and_retirement(self):
        f,seal=self.prefix();original=IOSEmoteCallbackSDKCut.issued;born=[]
        def orphan(cut,reads):
            path=f.normal.actor.flow.root/'emote-callback-unowned-sdk-cut.json'
            if not born:PrivateFeatureState(path).write(dict(unknown=True),None);born.append(path)
            return original(cut,reads)
        with patch.object(IOSEmoteCallbackSDKCut,'issued',orphan),self.assertRaises(NativeUIError):self.complete(f,seal)
        self.assertEqual(1,len(born));self.assertFalse(any(row[1]=='DELETE' for row in f.calls));self.assertTrue(all(store.read() is not None for store in self.feature_paths(f)))
    def test_actual_independent_installed_tree_mutation_refuses_before_any_stop(self):
        f,seal=self.prefix();path=f.trees['actor']/'assets/source.txt';before=path.read_bytes();path.write_bytes(before+b' changed')
        with self.assertRaises(NativeUIError):self.invoke(f,seal)
        self.assertEqual([],f.stops);self.assertEqual(set(),f.deleted);self.assertTrue(all(store.read() is not None for store in self.feature_paths(f)))

    def test_resurrected_gpu_metadata_after_durable_end_is_not_adopted_as_current_or_deleted(self):
        f,seal=self.prefix();self.complete(f,seal)
        from ios.adapters.emote_callback_copied_checkpoint import existing
        from ios.adapters.emote_rooted_end_lock import held_existing
        from pathlib import Path
        p,a=f.facades['primary'],f.facades['actor']
        with held_existing(a.lock),held_existing(p.lock):
            def guard():p.lock.assert_held();a.lock.assert_held();return True
            store=PrivateFeatureState(p.store.path.with_name('ios-emote-primary-'+p.run+'-callback-copied.json'));value=store.read()
            archive=existing(store,root=p.root,binding=value['binding'],run=p.run,lock=p.lock,actor_lock=a.lock,guard=guard)
            copies,_=archive.retained();paths=[Path(key) for key,value in copies.items() if Path(key).name.startswith('graphics-world-frame-') and value is not None]
            self.assertTrue(paths);path=paths[0];self.assertIsNone(PrivateFeatureState(path).read())
            PrivateFeatureState(path).write(copies[str(path)],None);before=path.stat();raw=path.read_bytes()
        calls,reads,factories=deepcopy(f.calls),deepcopy(f.native_reads),deepcopy(f.source_factories)
        with self.assertRaises(NativeUIError):self.invoke(f,seal)
        self.assertEqual(raw,path.read_bytes());self.assertEqual((before.st_dev,before.st_ino),(path.stat().st_dev,path.stat().st_ino))
        self.assertEqual(calls,f.calls);self.assertEqual(reads,f.native_reads);self.assertEqual(factories,f.source_factories)
    def test_actual_metadata_discard_lost_return_recovers_only_same_durable_path(self):
        f,seal=self.prefix();original=PrivateFeatureState.discard;lost=[]
        class LostDiscard(OSError):pass
        def discard(store,previous):
            result=original(store,previous)
            if store.path.name.startswith('graphics-world-frame-') and not lost:
                lost.append(store.path);raise LostDiscard('Actual metadata discard return lost')
            return result
        with patch.object(PrivateFeatureState,'discard',discard):
            with self.assertRaises(BaseException) as failure:self.complete(f,seal)
        self.assertEqual(1,len(lost));self.assertIsNone(PrivateFeatureState(lost[0]).read())
        chain=failure.exception
        while chain is not None and not isinstance(chain,LostDiscard):chain=chain.__cause__ or chain.__context__
        self.assertIsInstance(chain,LostDiscard)
        calls,reads,factories=deepcopy(f.calls),deepcopy(f.native_reads),deepcopy(f.source_factories)
        actual=self.complete(f,seal);self.assertEqual('finish',actual['stage'])
        self.assertEqual(calls,f.calls);self.assertEqual(reads,f.native_reads);self.assertEqual(factories,f.source_factories)


if __name__=='__main__':unittest.main()
