"""Private continuation of the reviewed direct-source/cache-original drafts."""
from pathlib import Path
import difflib,hashlib,json
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;PREVIOUS=OUT.with_name('chat-qml-cache-originals-proposal-20261027')
first=json.loads((PREVIOUS/'native-candidates.json').read_text());refs=json.loads((PREVIOUS/'reviewed-reference-originals.json').read_text())
for row in first['paths']:assert hashlib.sha256((ROOT/row['candidate']).read_bytes()).hexdigest()==row['candidateSha256']
base={name:(PREVIOUS/'source'/name).read_text() for name in refs};candidate=dict(base)
def change(name,old,new):
 assert candidate[name].count(old)==1,(name,old[:65]);candidate[name]=candidate[name].replace(old,new,1)
common='qtdeclarative/src/qml/common/qv4compileddata_p.h';executable='qtdeclarative/src/qml/jsruntime/qv4executablecompilationunit_p.h'
component='qtdeclarative/src/qml/qml/qqmlcomponent_p.h';typehead='qtdeclarative/src/qml/qml/qqmltypedata_p.h';typecpp='qtdeclarative/src/qml/qml/qqmltypedata.cpp'
change(common,'#define QT_OVERTE_E2E_QML_SOURCE_RECEIPTS 1\n','#define QT_OVERTE_E2E_QML_SOURCE_RECEIPTS 1\n#define QT_OVERTE_E2E_QML_CACHE_ORIGINALS 1\n')
change(executable,'''    QVariantMap overteE2eSourceReceipt() const
''','''    QString overteE2eExecutableIdentity() const
    {
        QT_TRY {
            if (!OverteCacheOriginals::active()) return {};
            if (m_overteE2eExecutableId.isEmpty()) m_overteE2eExecutableId=OverteCacheOriginals::nonce();
            return m_overteE2eExecutableId;
        } QT_CATCH (...) { OverteCacheOriginals::fail();return {}; }
    }
    QVariantMap overteE2eCacheOriginal() const
    {
        return m_compilationUnit->overteE2eCacheOriginalForCurrentUnit();
    }
    QVariantMap overteE2eSourceReceipt() const
''')
change(executable,'    QQmlRefPointer<CompiledData::CompilationUnit> m_compilationUnit;\n','''    QQmlRefPointer<CompiledData::CompilationUnit> m_compilationUnit;
#if defined(QT_OVERTE_E2E_QML_SOURCE_RECEIPTS)
    // Diagnostic lifetime identity, not a product/unit reference.
    mutable QString m_overteE2eExecutableId;
#endif
''')
change(component,'''    QQmlRefPointer<QV4::ExecutableCompilationUnit> compilationUnit() const
''','''#if defined(Q_OS_IOS)
    // Diagnostic identity comparison only; no observer refcount increment.
    const QV4::ExecutableCompilationUnit *overteE2eCompilationUnitIdentity() const
    { return m_compilationUnit.data(); }
#endif
    QQmlRefPointer<QV4::ExecutableCompilationUnit> compilationUnit() const
''')
change(typehead,'''    static Q_QML_EXPORT QVariantMap overteE2eSourceReceiptForObject(
            const QObject *object, const QQmlComponent *component = nullptr);
''','''    static Q_QML_EXPORT QVariantMap overteE2eSourceReceiptForObject(
            const QObject *object, const QQmlComponent *component = nullptr);
#if defined(QT_OVERTE_E2E_QML_CACHE_ORIGINALS)
    static Q_QML_EXPORT int overteE2eCacheObservationApiVersion();
    static Q_QML_EXPORT QVariantMap overteE2eCacheReceiptForObject(
            const QObject *object, const QQmlComponent *component = nullptr);
#endif
''')
change(typecpp,'#include <QtCore/qthread.h>\n','#include <QtCore/qthread.h>\n#include <QtCore/qpointer.h>\n')
change(typecpp,'''QString QQmlTypeData::TypeReference::qualifiedName() const
''','''#if defined(QT_OVERTE_E2E_QML_CACHE_ORIGINALS)
int QQmlTypeData::overteE2eCacheObservationApiVersion() { return 1; }
QVariantMap QQmlTypeData::overteE2eCacheReceiptForObject(
        const QObject *object,const QQmlComponent *component)
{
    QT_TRY {
        if (!overteE2eSourceEnabled.load(std::memory_order_acquire)
                || !QV4::OverteCacheOriginals::active() || !QCoreApplication::instance()
                || !object || object->thread()!=QThread::currentThread()) return {};
        QPointer<const QObject> weakObject(object);
        QPointer<const QQmlComponent> weakComponent(component);
        const auto *data=QQmlData::get(object);
        if (!data || !data->compilationUnit) return {};
        const auto *actual=data->compilationUnit.data();
        if (component && (component->thread()!=QThread::currentThread() || !component->isReady()
                || component->isError() || QQmlComponentPrivate::get(const_cast<QQmlComponent *>(component))
                    ->overteE2eCompilationUnitIdentity()!=actual)) return {};
        const auto unit=actual->overteE2eCacheOriginal();
        const auto executableId=actual->overteE2eExecutableIdentity();
        if (executableId.isEmpty() || unit.isEmpty() || unit.value(QStringLiteral("processId")).toLongLong()!=QCoreApplication::applicationPid()) return {};
        const auto sourceUrl=actual->url().toString(QUrl::FullyEncoded);
        const auto finalUrl=actual->finalUrl().toString(QUrl::FullyEncoded);
        if (!weakObject || (component && !weakComponent)) return {};
        const auto *current=QQmlData::get(object);
        if (!current || current->compilationUnit.data()!=actual) return {};
        if (component && QQmlComponentPrivate::get(const_cast<QQmlComponent *>(component))
                    ->overteE2eCompilationUnitIdentity()!=actual) return {};
        return {{QStringLiteral("qtOverteQmlObjectCacheReceiptVersion"),1},
            {QStringLiteral("processId"),QCoreApplication::applicationPid()},
            {QStringLiteral("executableUnitId"),executableId},
            {QStringLiteral("componentMatched"),component!=nullptr},
            {QStringLiteral("unitSourceUrl"),sourceUrl},{QStringLiteral("unitFinalUrl"),finalUrl},
            {QStringLiteral("unit"),unit}};
    } QT_CATCH (...) { QV4::OverteCacheOriginals::fail();return {}; }
}
#endif

QString QQmlTypeData::TypeReference::qualifiedName() const
''')
# A single getter must observe one unchanged actual executable->compiled owner
# generation throughout URL and weak-object rechecks as well as byte hashing.
# The second read is deliberate: no stored receipt can substitute for current
# generation when an unusual diagnostic hook mutates the compiled owner.
change(typecpp,'''        return {{QStringLiteral("qtOverteQmlObjectCacheReceiptVersion"),1},''','''        const auto reread=actual->overteE2eCacheOriginal();
        auto originalIdentity=unit;auto currentIdentity=reread;
        for (const auto &name : {QStringLiteral("unitReadBefore"),QStringLiteral("unitReadAfter")}) {
            originalIdentity.remove(name);currentIdentity.remove(name);
        }
        if (reread.isEmpty() || originalIdentity!=currentIdentity || !weakObject
                || actual->overteE2eExecutableIdentity()!=executableId) return {};
        const auto *last=QQmlData::get(object);
        if (!last || last->compilationUnit.data()!=actual || (component && (!weakComponent
                || QQmlComponentPrivate::get(const_cast<QQmlComponent *>(component))
                    ->overteE2eCompilationUnitIdentity()!=actual))) return {};
        return {{QStringLiteral("qtOverteQmlObjectCacheReceiptVersion"),1},''')
# Both reads are actual; return the later original read, which includes the
# final physical hash/generation observation instead of retiming the first.
change(typecpp,'{QStringLiteral("unit"),unit}};','{QStringLiteral("unit"),reread}};')
rows=[];diff=''
for name in sorted(candidate):
 path=OUT/'qt-source'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(candidate[name])
 if candidate[name]==base[name]:continue
 diff+=''.join(difflib.unified_diff(base[name].splitlines(True),candidate[name].splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 rows.append(dict(path=name,previousDraftSha256=hashlib.sha256(base[name].encode()).hexdigest(),candidateSha256=hashlib.sha256(candidate[name].encode()).hexdigest(),candidate=str(path.relative_to(ROOT))))
(OUT/'qt-cache-object-api-incremental.patch').write_text(diff)
(OUT/'native-candidates.json').write_text(json.dumps(dict(status='PRIVATE/source only; no native compiler or tests',paths=rows,noStrongCompilationUnitCopies=True,previousDraftUnchanged=True),indent=2)+'\n')
print('Private QObject cache binary API candidate paths',len(rows))
