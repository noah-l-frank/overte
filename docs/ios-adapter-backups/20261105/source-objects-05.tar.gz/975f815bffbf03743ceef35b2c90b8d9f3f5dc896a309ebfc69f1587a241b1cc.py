"""Prepare one supported Final2 archive diagnostic; never imports targets."""
from pathlib import Path
import ast,base64,hashlib,json,stat,zlib
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
BASE=ROOT/'.ios-host-tmp/tablet-parent-guard-metadata-fast-same328-profile-preparation-20261028'
ORIGINAL=ROOT/'.ios-host-tmp/avatar-scene-final-recovered-local-monitoring-root2-preparation-20261028'
RUN=ORIGINAL/'runs/final1/first-tg46i7x_';TEMP=RUN/'temporary'
ROLE_PATHS=dict(primary=TEMP/'tmpjhnsgzwa',actor=TEMP/'tmps7mb75ff')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    before=path.lstat();assert stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode)
    row={name:getattr(before,name) for name in FIELDS}
    if stat.S_ISREG(before.st_mode):row['sha256']=sha(path)
    after=path.lstat();assert all(getattr(before,name)==getattr(after,name) for name in FIELDS)
    return row
assert not (HERE/'freeze.json').exists()
originals={str(path.relative_to(TEMP)):pin(path) for path in (TEMP,*sorted(TEMP.rglob('*')))}
assert sum(stat.S_ISREG(row['st_mode']) for row in originals.values())==1113
save(HERE/'original-reference.json',originals)
parents={role:json.loads((path/('ios-avatar-'+role+'-feature.json')).read_text()) for role,path in ROLE_PATHS.items()}
states={}
for role,envelope in parents.items():
    packed=envelope['payload'];encoded=base64.b64decode(packed['data'],validate=True)
    decoder=zlib.decompressobj();raw=decoder.decompress(encoded,16*1024*1024+1)
    assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
    assert len(raw)==packed['bytes'] and hashlib.sha256(raw).hexdigest()==packed['sha256']
    values=json.loads(raw);assert len(values)==1;states[role]=values[0]
    assert envelope['role']==role and Path(envelope['artifactRoot'])==ROLE_PATHS[role]
assert parents['primary']['runId']==parents['actor']['runId']
assert states['primary']['bindings']==states['actor']['bindings']
scope=dict(role='primary',run=parents['primary']['runId'],bindingSource='independent original paired Feature envelopes and sessions',
    parentPaths={role:str(path/('ios-avatar-'+role+'-feature.json')) for role,path in ROLE_PATHS.items()},
    sdkMetadataRoots={role:str(path) for role,path in ROLE_PATHS.items()},bindings=states['primary']['bindings'],
    fixtureURL=parents['primary']['fixtureUrl'],artifactRoot=parents['primary']['artifactRoot'],
    expectedRows=3,expectedPendingIndex=4)
save(HERE/'independent-parent-scope.json',scope)
for name in ('profile_metadata.py','prepare-actual-map.py','root-supervise-profile.py'):
    body=(BASE/name).read_text()
    body=body.replace('all328OriginalsUnchanged','all1113OriginalsUnchanged').replace("==value['originalFiles']==328","==value['originalFiles']==1113")
    body=body.replace('originalFiles=328','originalFiles=1113')
    (HERE/name).write_text(body)
plan=json.loads((BASE/'profile-plan.json').read_text())
plan.update(status='PRIVATE_SUPPORTED_HELD_FINAL2_ARCHIVE_READONLY_PROFILE_UNRUN',
    actualRetainedTemporaryRoot=str(TEMP),originalFiles=1113,originalReference=str((HERE/'original-reference.json').relative_to(ROOT)),
    originalReport=str((ORIGINAL/'final1-report.json').relative_to(ROOT)),outerInitialSeconds=60,killAfterSeconds=5,
    independentScopeSha256=sha(HERE/'independent-parent-scope.json'),innerOriginalAPISeconds=None,
    selectedWork='One actual IOSAvatarHeldFinal.archive of original Primary Final2 rows3/pending4, independently reconstruct all inputs from parent Feature/session/checkpoint Source originals; no quiet/capture/recovery/runtime/end.',
    originalRows=dict(primaryReturned=3,primaryPendingIndex=4,actorReturned=3,actorPending=None),
    noWholeOrPerformanceClaim=True)
for key in ('baselineActualReport','baselineActualProfile','baselineMeasuredSeconds','precedingActualMemoResult','correctionPackets','frozenSourceCandidate','metadataSourcePacket','meaningfulChangedSource','instrumentationCorrection'):plan.pop(key,None)
required=['tests/device/ios/adapters/avatar_held_final.py','tests/device/ios/adapters/avatar_final.py',
    'tests/device/ios/adapters/avatar_final_pure_round.py','tests/device/ios/adapters/avatar_authority.py',
    'tests/device/ios/adapters/avatar_observation.py','tests/device/ios/adapters/avatar_observer.py',
    'tests/device/adapters/original_frame_store.py','tests/device/adapters/normal_feature_state.py',
    'tests/device/adapters/original_file_reads.py','tests/device/adapters/script_feature/lock.py']
plan['publicTabletSourceRequiredSha256']={name:sha(ROOT/name) for name in required}
plan['explicitExtraSourcePins']=['CMakeLists.txt','interface/CMakeLists.txt','interface/src/main.cpp',
    str((HERE/'independent-parent-scope.json').relative_to(ROOT)),str((HERE/'original-reference.json').relative_to(ROOT)),
    str((ORIGINAL/'final1-report.json').relative_to(ROOT))]
prior=json.loads((BASE/'retained-prior-original-pins.json').read_text())
for name,wanted in prior.items():assert pin(ROOT/name)==wanted,name
for name,row in originals.items():prior[str((TEMP/name).relative_to(ROOT))]=row
for path in RUN.iterdir():
    if path.is_file():prior[str(path.relative_to(ROOT))]=pin(path)
for path in ORIGINAL.glob('final1-*'):
    if path.is_file():prior[str(path.relative_to(ROOT))]=pin(path)
save(HERE/'retained-prior-original-pins.json',prior);plan['retainedPriorPinsSha256']=sha(HERE/'retained-prior-original-pins.json')
save(HERE/'profile-plan.json',plan)
child='''"""One supported original Final2 archive, never a live/quiet/end verdict."""
import cProfile,hashlib,importlib.abc,importlib.machinery,json,os,pstats,signal,stat,sys,threading,time,traceback
from contextlib import ExitStack
from pathlib import Path
from types import CodeType
from profile_metadata import HERE,REPO,frozen,pin,process,save,sources
value=frozen();OUTPUT=Path(os.environ['OVERTE_TABLET_ROOT328_PROFILE_ROOT']).resolve(strict=True)
assert OUTPUT.is_relative_to(HERE/'runs') and OUTPUT!=HERE/'runs' and stat.S_IMODE(OUTPUT.stat().st_mode)==0o700
save(OUTPUT/'runner-process-binding.json',process(os.getpid()))
ready=json.loads((HERE/'actual-source-map.json').read_text());assert ready['status']=='ACTUAL_CURRENT_DIAGNOSTIC_SOURCE_MAP'
expected=sources(value);assert expected==ready['sourcePins']
BASE_THREADS=set(threading.enumerate());effects=[];marks=[];imports={};error=None;interrupted=None;reads=set();owner=None
scope=json.loads((HERE/'independent-parent-scope.json').read_text());assert hashlib.sha256((HERE/'independent-parent-scope.json').read_bytes()).hexdigest()==value['independentScopeSha256']
lockpaths={Path(root)/'script-feature-sources.lock' for root in scope['sdkMetadataRoots'].values()};lockpins={path:pin(path) for path in lockpaths}
started=time.monotonic();profiler=cProfile.Profile();profiling_started=False
def mark(name):
    row=dict(name=name,seconds=time.monotonic()-started);marks.append(row);print('BOUNDARY',json.dumps(row),flush=True)
def forbidden(name):effects.append(name);raise AssertionError('Forbidden historical-only effect: '+name)
def audit(event,args):
    if event.startswith(('socket.','subprocess.','os.exec','os.spawn','os.fork')) or event in ('os.system','os.posix_spawn','pty.spawn','ctypes.dlopen'):forbidden(event)
    if event in ('os.remove','os.rmdir','os.rename','os.mkdir','os.chmod','os.chown','os.utime','os.link','os.symlink','os.truncate'):forbidden(event)
    if event=='open':
        path,mode,flags=args
        if not flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):return
        if not isinstance(path,(str,bytes,os.PathLike)):forbidden('descriptor-write-open')
        actual=Path(os.fsdecode(path)).absolute()
        if actual.parent==OUTPUT:return
        if actual in lockpins and mode is None and not flags&(os.O_TRUNC|os.O_APPEND|os.O_EXCL):
            row=actual.lstat();old=lockpins[actual]
            if row.st_dev==old['st_dev'] and row.st_ino==old['st_ino']:return
        forbidden('write-open:'+str(actual))
class SourceGuard(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.',1)[0] in ('pymobiledevice3','pmd_pytcp','pmd_pytcpstack','pytcp','tidevice','pyidevice'):forbidden('SDK-import:'+fullname)
        spec=importlib.machinery.PathFinder.find_spec(fullname,path)
        if spec is None or not spec.origin or spec.origin in ('built-in','frozen'):return None
        origin=Path(spec.origin).resolve()
        if 'overte-ios-remotexpc' in str(origin) or any(part in ('pymobiledevice3','pmd_pytcp','pmd_pytcpstack','pytcp') for part in origin.parts):forbidden('SDK-path:'+fullname)
        if origin.is_relative_to(REPO):
            key=str(origin.relative_to(REPO));wanted=expected.get(key)
            if '/self_tests/' in key:forbidden('fixture-import:'+fullname)
            assert wanted is not None and hashlib.sha256(origin.read_bytes()).hexdigest()==wanted['sha256'],('Unpinned source',fullname,key)
            imports[fullname]=key
        return None
assert not any(n.split('.',1)[0] in ('ios','adapters','feature_journeys','pymobiledevice3') for n in sys.modules)
ordered=[str(REPO/p) for p in ('tests/device','tests/device/self_tests','tests/device/ios/self_tests')];rest=[]
for item in sys.path:
    path=Path(item or os.getcwd()).resolve()
    if path==REPO or REPO in path.parents:continue
    if str(path) not in rest:rest.append(str(path))
sys.path[:]=ordered+rest
for name,relative in {'ios':'tests/device/ios','adapters':'tests/device/adapters','feature_journeys':'tests/device/feature_journeys'}.items():
    spec=importlib.machinery.PathFinder._get_spec(name,list(sys.path));assert spec is not None and list(spec.submodule_search_locations or ())==[str(REPO/relative)]
sys.addaudithook(audit);sys.meta_path.insert(0,SourceGuard())
def terminate(signum,frame):
    global interrupted
    interrupted=dict(signal=signum,stack=traceback.format_stack(frame));save(OUTPUT/'signal-cutpoint.json',interrupted)
    raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,terminate)
try:
    from copy import deepcopy
    from adapters.normal_feature_state import PrivateFeatureState,context
    from adapters.original_file_reads import readonly,collect
    from adapters.original_frame_store import OriginalFrameStore
    from adapters.script_feature.lock import ScriptSourceLock
    from adapters.script_feature.history import unpack,same
    from feature_journeys.witness import Client
    from ios.adapters.avatar_authority import AvatarAuthorityReader
    from ios.adapters.avatar_observation import source_history
    from ios.adapters.avatar_observer import IOSAvatarObserver
    from ios.adapters.avatar_held_final import IOSAvatarHeldFinal
    role=scope['role'];run=scope['run'];root=Path(scope['artifactRoot'])
    locks={subject:ScriptSourceLock(Path(path)/'script-feature-sources.lock') for subject,path in scope['sdkMetadataRoots'].items()}
    def locked():
        for lock in locks.values():lock.assert_held()
        return True
    def no_effect(*_args,**_kwargs):forbidden('native/status/input/clock/producer/Source writer')
    mark('actual-passive-imports-complete')
    with ExitStack() as stack,readonly(),collect() as reads:
        for lock in sorted(locks.values(),key=lambda lock:str(lock.path)):stack.enter_context(lock.held())
        parent=PrivateFeatureState(scope['parentPaths'][role]).read();rows=unpack(parent['payload']);assert len(rows)==1;state=rows[0]
        assert parent['runId']==run and parent['role']==role and parent['artifactRoot']==str(root) and parent['fixtureUrl']==scope['fixtureURL']
        assert state['bindings']==scope['bindings'] and all(context(binding)==binding for binding in state['bindings'].values())
        for subject,path in scope['parentPaths'].items():
            other=PrivateFeatureState(path).read();other_state=unpack(other['payload'])[0]
            assert other['runId']==run and other['role']==subject and other_state['bindings']==state['bindings']
        suffix='/runs/'+run+'/'
        assert parent['fixtureUrl'].endswith(suffix);fixture=parent['fixtureUrl'][:-len(suffix)]
        # Inert local diagnostic token only. It is not a credential/auth claim.
        client=Client(fixture,'readonly-cost-diagnostic-no-authority-'+'0'*32)
        authority=AvatarAuthorityReader(client,run,epoch_ms=no_effect,monotonic=no_effect)
        checkpoint=next(item for item in state['cleanup'] if item['kind']=='checkpoint')['reference']
        originals=OriginalFrameStore(root,state['bindings'][role],run,role,locked,no_effect,
            namespace='avatar-observation',schema_prefix='avatarObservation')
        record=originals.read(originals.expand(checkpoint['original']))
        assert record['status']==checkpoint['status']=='observed' and record['ticket']==checkpoint['ticket']==state['cleanup'][0]['ticket']
        assert record['index']==checkpoint['index']
        inputs={}
        for subject in ('primary','actor'):
            directory=root if subject==role else root/(subject+'-sdk-originals')
            base=Path(scope['sdkMetadataRoots'][subject]);snapshot=record['components']['sources'][subject]
            history=source_history(snapshot['owner'],snapshot['recovery'],store=PrivateFeatureState(base/('ios-avatar-'+role+'-sources.json')),
                root=directory,binding=state['bindings'][subject],run=run,role=role,lock=locks[subject])
            initial=IOSAvatarObserver.reference(history,state['sessions']['sources'][subject])
            child=state['sessions']['authority']['accounts'][subject]['runId']
            inputs[subject]=dict(root=str(directory),paths=dict(post=str(base/('ios-avatar-'+role+'-'+subject+'-postlogout.json')),
                tail=str(base/('ios-avatar-'+role+'-'+subject+'-postlogout-tail.json')),pointers=str(base/('ios-avatar-'+role+'-pointers.json')),
                web=str(base/('ios-avatar-'+role+'-marker-web.json'))),childRunId=child,fixtureUrl=fixture+'/runs/'+child+'/',
                markerFixtureUrl=parent['fixtureUrl'],ticket=state['cleanup'][0]['ticket'],
                baseline={key:deepcopy(initial['originals'][key]) for key in ('state','scripts','http')},logoutBefore=deepcopy(initial['originals']['native']))
        store=PrivateFeatureState(Path(scope['sdkMetadataRoots'][role])/('ios-avatar-'+role+'-final.json'));original=store.read()
        assert original['iosAvatarFinalVersion']==2 and original['runId']==run and original['role']==role
        assert same(original['bindings'],state['bindings']) and same(original['inputs'],inputs) and original['artifactRoot']==str(root)
        mark('independent-parent-checkpoint-source-inputs-complete')
        profiler.enable();profiling_started=True
        owner=IOSAvatarHeldFinal.archive(original,store=store,root=root,bindings=state['bindings'],run=run,role=role,
            locks=locks,authority=authority,inputs=inputs)
        profiler.disable();mark('supported-historical-Final2-archive-returned')
        assert owner.historical and len(owner.state['rows'])==scope['expectedRows'] and owner.state['pending']['index']==scope['expectedPendingIndex']
        assert same(owner.previous,original) and same(owner.store.read(),original)
    mark('original-locks-and-readonly-left')
except BaseException as exc:
    error=dict(type=type(exc).__name__,message=str(exc),traceback=traceback.format_exc());print(error['traceback'],file=sys.stderr,flush=True)
finally:
    profiler.disable();profiler.dump_stats(str(OUTPUT/'raw.pstats'))
    names={}
    for entry in profiler.getstats():
        code=entry.code
        if type(code) is CodeType:names[(code.co_filename,code.co_firstlineno,code.co_name)]=code.co_qualname
    statistics=pstats.Stats(profiler).stats if profiler.getstats() else {};rows=[]
    def label(key):
        filename,line,name=key;path=Path(filename)
        if not path.is_absolute() or not path.is_relative_to(REPO/'tests/device'):return None
        return dict(module=str(path.relative_to(REPO)),line=line,qualifiedName=names.get(key,name))
    for key,(primitive,calls,own,cumulative,callers) in statistics.items():
        item=label(key)
        if item is None:continue
        source=[]
        for caller,cost in callers.items():
            named=label(caller)
            if named is not None:source.append(dict(**named,cost=list(cost) if type(cost) is tuple else cost))
        source.sort(key=lambda row:row['cost'][3] if type(row['cost']) is list and len(row['cost'])>3 else 0,reverse=True)
        rows.append(dict(**item,primitiveCalls=primitive,calls=calls,selfSeconds=own,cumulativeSeconds=cumulative,callers=source[:8]))
    save(OUTPUT/'profile-summary.json',dict(topSelf=sorted(rows,key=lambda row:row['selfSeconds'],reverse=True)[:20],
        topCumulative=sorted(rows,key=lambda row:row['cumulativeSeconds'],reverse=True)[:20],profileOverheadQualified=False))
    threads=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in BASE_THREADS and t.is_alive()]
    save(OUTPUT/'diagnostic-result.json',dict(error=error,interrupted=interrupted,marks=marks,forbiddenEffects=effects,newThreads=threads,
        imports=imports,actualOriginalMembershipCount=len(reads),historicalOwnerReturned=owner is not None,
        originalFinalRows=None if owner is None else len(owner.state['rows']),originalPendingIndex=None if owner is None else owner.state['pending']['index'],
        profilingEnabled=profiling_started,traceEnabled=False,elapsedSeconds=time.monotonic()-started,
        quietCalculated=False,nativeExecuted=False,sdkExecuted=False,inputExecuted=False,authenticationQualified=False,wholeQualified=False,performanceQualified=False))
    assert expected=={name:pin(REPO/name) for name in expected},'Pinned Source/helper changed'
if error or effects or threads:raise SystemExit(1)
'''
(HERE/'profile-saved-once.py').write_text(child)
(HERE/'ROOT-REVIEW.txt').write_text('''PRIVATE / AST ONLY / UNRUN. Exact one supported IOSAvatarHeldFinal.archive,
Primary original rows3 +pending4. Outer initial60+kill5, no live API invocation,
no Original clock/cap change, no extra prefix/round context. Source original
Final.parse supplies its own existing pure validation scope unchanged.

Expected run/role/bindings/roots/fixture derive from paired PARENT Feature
envelopes and sessions, independently of Final-under-test. Before profiling,
the actual OriginalFrameStore reads the parent's checkpoint original and the
actual source_history/IOSAvatarObserver.reference reconstruct baseline/native
originals. All Final inputs are rebuilt by the existing final_inputs recipe,
never copied from Final's inputs. Parent/client URL remains original; the typed
AvatarAuthorityReader has an inert local diagnostic token and fatal clock
callbacks. Only its existing pure validate method may execute. This is not
authentication or physical/device evidence. Audit refuses all network/SDK/
subprocess/native/status/input/writer paths before target imports.

All1113 originals plus previous corpora/controls stay stat+byte pinned, original
lock inodes only, before/after PID/startticks/PGID-SID and both poststop censuses,
thread baseline before imports. Full actual broad source/main/CMake map must be
built Root after any Source publication. No Target imports/tests by author.
Original3 groups cover only1.72s quiet, so pending4 is legitimate unfinished
quiet. No quiet() call, retiming, acquisition, recovery, end/absence claim.
Raw pstats plus bounded Source self/cumulative/caller rows; overhead means no
isolated speed claim or explanation of the old600s timeout without evidence.

Root commands after review/grant and stable Source:
  PYTHONDONTWRITEBYTECODE=1 python3 -B <this-dir>/prepare-actual-map.py
  PYTHONDONTWRITEBYTECODE=1 python3 -B <this-dir>/root-supervise-profile.py
''')
for path in HERE.glob('*.py'):ast.parse(path.read_text(),filename=str(path))
files={str(path.relative_to(HERE)):sha(path) for path in sorted(HERE.iterdir()) if path.is_file() and path.name!='freeze.json'}
save(HERE/'freeze.json',dict(status='FROZEN_PRIVATE_SUPPORTED_FINAL2_ARCHIVE_PROFILE_UNRUN',files=files))
print(json.dumps(dict(freezeSha256=sha(HERE/'freeze.json'),originals=1113,priorNodes=len(prior),outerSeconds=60,killAfterSeconds=5),indent=2))
