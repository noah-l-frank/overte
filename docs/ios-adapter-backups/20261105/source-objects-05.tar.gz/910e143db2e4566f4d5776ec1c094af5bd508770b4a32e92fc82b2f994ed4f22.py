"""Authorized exact three private Audio host counters; every external action denied."""
from pathlib import Path
import hashlib,importlib.abc,importlib.util,json,os,stat,sys,tempfile,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent;REPO=HERE.parent.parent
PLAN=HERE/'preimport-map.json';EXPECTED='2e6281834267ef38fb38d83eb18dba17a8a0a59634d9e04f79c511800e0d1ed8'
assert hashlib.sha256(PLAN.read_bytes()).hexdigest()==EXPECTED
plan=json.loads(PLAN.read_text());assert plan['root']==str(HERE) and plan['repository']==str(REPO)
assert sys.dont_write_bytecode and len(plan['cases'])==2 and len(set(plan['cases']))==2
TEMP=HERE/'temporary';assert TEMP.is_dir() and not list(TEMP.iterdir());tempfile.tempdir=str(TEMP)
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(name,value):
 path=HERE/name;path.write_text(json.dumps(value,sort_keys=True,indent=2)+'\n');path.chmod(0o600)
for row in plan['frozenPackets']:assert digest(row['path'])==row['sha256']
for row in plan['modules'].values():assert digest(row['path'])==row['sha256']
save('preimport-verification.json',dict(status='EXACT_MAP_SHA_CHECKED_BEFORE_ANY_TARGET_IMPORT',mappedModules=len(plan['modules']),frozenPackets=plan['frozenPackets'],python=sys.version,executable=sys.executable,sourceMapSha256=EXPECTED,supervisorPid=os.getpid()))
loaded={};public_reads={};refusals=[];retained=[];depth=False
initial_modules=dict(sys.modules);initial_meta=list(sys.meta_path);initial_path=list(sys.path);initial_threads=set(threading.enumerate())
project_tops={name.split('.')[0]for name in plan['modules']}
assert not any(name.split('.')[0]in project_tops for name in sys.modules)

def pin_read(path):
 global depth
 if depth:return
 depth=True
 try:
  path=Path(path).absolute()
  if path.is_relative_to(REPO) and not path.is_relative_to(REPO/'.ios-host-tmp') and path.is_file():
   info=path.lstat();row=dict(sha256=digest(path),device=info.st_dev,inode=info.st_ino,bytes=info.st_size,mtimeNs=info.st_mtime_ns)
   if str(path)in public_reads:assert public_reads[str(path)]==row,'Public dependency changed during this exact run'
   else:public_reads[str(path)]=row
 finally:depth=False

def refuse(event,detail):
 row=dict(event=event,detail=detail);refusals.append(row);raise RuntimeError('AUDIT_REFUSED_'+event)

def audit(event,args):
 if event=='import':
  name=args[0]
  if any(name==prefix or name.startswith(prefix+'.')for prefix in ('pymobiledevice3','tidevice','pyidevice','zeroconf','appium','playwright','selenium','ios.pymobiledevice3_wda_xctest')):refuse(event,name)
 elif event.startswith('socket.'):
  if event not in ('socket.gethostname',):refuse(event,'All sockets, device/network transports and services are forbidden')
 elif event in ('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn') or event.startswith('os.spawn'):
  refuse(event,'All subprocess/compiler/Node/build/device actions are forbidden')
 elif event=='ctypes.dlopen':refuse(event,'Dynamic native SDK loads are forbidden')
 elif event=='open' and not depth:
  path,mode,flags=args
  if isinstance(path,(str,bytes,os.PathLike)):
   path=Path(os.fsdecode(path)).absolute();writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)) or isinstance(mode,str) and any(c in mode for c in 'wax+')
   if writing and not path.is_relative_to(HERE):refuse(event,'Write outside the exact private run root')
   if not writing:pin_read(path)
 elif event in ('os.remove','os.rmdir','os.mkdir','os.rename','os.chmod','os.link','os.symlink'):
  candidates=args[:2]if event in ('os.rename','os.link','os.symlink')else args[:1]
  for item in candidates:
   if isinstance(item,(str,bytes,os.PathLike)):
    path=Path(os.fsdecode(item)).absolute()
    if not path.is_relative_to(HERE):refuse(event,'Filesystem mutation outside the exact private run root')
sys.addaudithook(audit)

class Loader(importlib.abc.Loader):
 def __init__(self,name,row):self.name,self.row=name,row
 def create_module(self,spec):return None
 def exec_module(self,module):
  path=Path(self.row['path']);raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==self.row['sha256']
  module.__file__=str(path)
  if self.row['package']:module.__path__=[str(path.parent)]
  loaded[self.name]=self.row
  exec(compile(raw,str(path),'exec'),module.__dict__)
  assert digest(path)==self.row['sha256']
class Finder(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  row=plan['modules'].get(fullname)
  if row is not None:return importlib.util.spec_from_loader(fullname,Loader(fullname,row),is_package=row['package'])
  roots=plan['namespacePackages'].get(fullname)
  if roots is not None:
   spec=importlib.machinery.ModuleSpec(fullname,None,is_package=True);spec.submodule_search_locations=roots;return spec
  if fullname.split('.')[0]in project_tops:raise ImportError('Unmapped project import refused: '+fullname)
  return None
finder=Finder();sys.meta_path.insert(0,finder)
real_td=tempfile.TemporaryDirectory
class RetainedDirectory(real_td):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);assert Path(self.name).is_relative_to(TEMP);self._finalizer.detach();retained.append(self.name);save('retained-temporary-roots.json',retained)
 def cleanup(self):
  self._finalizer.detach() # All roots/originals/failures remain in this exact run.
tempfile.TemporaryDirectory=RetainedDirectory
case_receipts=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):
  self.started=time.monotonic();print('NORMAL2_SNAPSHOT_RETURN1_CASE_START',test.id(),flush=True);super().startTest(test)
 def stopTest(self,test):
  rows=[dict(name=t.name,ident=t.ident,daemon=t.daemon)for t in threading.enumerate()if t not in initial_threads and t.is_alive()]
  receipt=dict(id=test.id(),elapsedSeconds=time.monotonic()-self.started,newThreads=rows,auditRefusals=len(refusals))
  case_receipts.append(receipt);save('case-stop-receipts.json',case_receipts);print('NORMAL2_SNAPSHOT_RETURN1_CASE_STOP',json.dumps(receipt),flush=True);super().stopTest(test)
  # Final census runs after the actual interrupted-case outer cleanup drain.
 def addError(self,test,error):
  super().addError(test,error);self.preserve(test,error,'ERROR')
 def addFailure(self,test,error):
  super().addFailure(test,error);self.preserve(test,error,'FAIL')
 def preserve(self,test,error,kind):
  raw=''.join(traceback.format_exception(*error));print('NORMAL2_SNAPSHOT_RETURN1_'+kind,test.id(),raw,flush=True)
  with (HERE/'original-exceptions.log').open('a')as stream:stream.write(kind+' '+test.id()+'\n'+raw);stream.flush();os.fsync(stream.fileno())
result=None;fatal=None;actual_ids=[];selected_cases=[];cleanup_receipts=[];cleanup_ok=True;original_cleanup=unittest.TestCase.doCleanups;started=time.monotonic()
try:
 loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
 def flatten(value):
  if isinstance(value,unittest.TestSuite):
   for child in value:yield from flatten(child)
  else:yield value
 selected_cases=list(flatten(suite));actual_ids=[case.id()for case in selected_cases];save('actual-selected-ids.json',dict(ids=actual_ids,loaderErrors=loader.errors))
 assert not loader.errors and actual_ids==plan['cases'] and suite.countTestCases()==2,'Exact overlay/selection unresolved; no broadened execution'
 result=unittest.TextTestRunner(verbosity=2,resultclass=Result,failfast=True).run(suite)
except BaseException:
 fatal=traceback.format_exc();(HERE/'original-fatal.log').write_text(fatal);print(fatal,flush=True)
finally:
 # Python3.14's original TestCase.run skips registered cleanups when its test
 # raises KeyboardInterrupt. Drain ONLY callbacks still registered, in actual
 # original stdlib order; normal completed cleanups are never called twice.
 for case in selected_cases:
  pending=len(case._cleanups);prior=case._outcome;drain=unittest.TestResult();success=True
  try:
   if pending:
    case._outcome=unittest.case._Outcome(drain)
    success=unittest.TestCase.doCleanups(case)
  except BaseException:
   success=False
   (HERE/('original-cleanup-error-'+str(len(cleanup_receipts))+'.log')).write_text(traceback.format_exc())
  finally:case._outcome=prior
  row=dict(id=case.id(),pendingBeforeOuterFinally=pending,remaining=len(case._cleanups),success=success,
   errors=drain.errors,failures=drain.failures,originalFunctionUnchanged=unittest.TestCase.doCleanups is original_cleanup)
  cleanup_receipts.append(row)
  if not success or case._cleanups or drain.errors or drain.failures or unittest.TestCase.doCleanups is not original_cleanup:cleanup_ok=False
 save('original-cleanup-chain.json',dict(success=cleanup_ok,cases=cleanup_receipts))
 restored=[]
 for name,module in list(sys.modules.items()):
  if name in loaded and getattr(module,'TemporaryDirectory',None)is RetainedDirectory:module.TemporaryDirectory=real_td;restored.append(name+'.TemporaryDirectory')
 tempfile.TemporaryDirectory=real_td;sys.meta_path[:]=initial_meta;sys.path[:]=initial_path
 assert tempfile.TemporaryDirectory is real_td
 after={};unchanged=True
 for path,before in public_reads.items():
  info=Path(path).lstat();row=dict(sha256=digest(path),device=info.st_dev,inode=info.st_ino,bytes=info.st_size,mtimeNs=info.st_mtime_ns);after[path]=row
  if row!=before:unchanged=False
 for row in loaded.values():assert digest(row['path'])==row['sha256']
 for row in plan['frozenPackets']:assert digest(row['path'])==row['sha256']
 remaining=[dict(name=t.name,ident=t.ident)for t in threading.enumerate()if t not in initial_threads and t.is_alive()]
 save('loaded-project-modules.json',loaded);save('actual-public-dependencies-before.json',public_reads);save('actual-public-dependencies-after.json',after)
 report=dict(status='REFUSED_OR_FATAL'if fatal else'PASS'if result is not None and result.wasSuccessful()and unchanged and cleanup_ok and not refusals and not remaining else'FAIL_OR_ERROR',testsRun=0 if result is None else result.testsRun,failures=0 if result is None else len(result.failures),errors=0 if result is None else len(result.errors),skips=0 if result is None else len(result.skipped),fatal=fatal is not None,elapsedSeconds=time.monotonic()-started,selected=actual_ids,actualPublicDependencies=len(public_reads),allPublicDependenciesUnchanged=unchanged,loadedProjectModules=len(loaded),auditRefusals=refusals,temporaryRootsRetained=retained,restoredAliases=restored,metaPathRestored=sys.meta_path==initial_meta,sysPathRestored=sys.path==initial_path,tempfileAliasRestored=tempfile.TemporaryDirectory is real_td,remainingNewThreads=remaining,nodeExecutions=0,SDKExecutions=0,builds=0,deviceActions=0,hostOnly=True,originalRegisteredCleanupEstablished=cleanup_ok,nativeQualified=False,wholeQualified=False)
 save('report.json',report);print('NORMAL2_SNAPSHOT_RETURN1_TERMINAL',json.dumps(report),flush=True)

sys.exit(0 if report['status']=='PASS'else 1)
