"""Root-only future metadata assembly; no SUT/SDK/model import or target."""
from pathlib import Path
import argparse,ast,hashlib,json,os,shutil,stat,subprocess,sys
from root_context import root_context,later_context
from backend_dirfd_admission import require_backend_dirfd_qualification
from c10d_admission import qualify as current_source_qualification
from closed_source_metadata import prepare as closed_prepare
from metadata_reader import pin as source_pin
CODE=Path(__file__).resolve().parent
REPO=CODE.parent.parent
OLD=REPO/'.ios-host-tmp/assets-picker3-seven-sealed-gate-isolated-controller10-20261103'
C12=REPO/'.ios-host-tmp/assets-picker3-reserved-phase-controller12-source-draft-20261104'
FIXTURE=REPO/'.ios-host-tmp/assets-picker3-reserved-negative-fixture-source-draft-20261103'
OWN3=REPO/'.ios-host-tmp/root-assets-controller12-real-port-own3-qualified-results-20261104'
C14=REPO/'.ios-host-tmp/assets-picker3-reserved-phase-current-head-context-assembler14-source-private-20261104'
C14_REVIEW=REPO/'.ios-host-tmp/lifecycle-independent-assets-current-head-assembler14-full-review-20261104'
HISTORICAL_ASSEMBLER13_HEAD='06ff22857d8c8298390e00cd5df1c848a1d9c6a5'
ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml','tests/javascript','domain-server/resources')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def relative(p):return str(Path(p).relative_to(REPO))
def pin(p):
    p=Path(p);a=p.lstat();assert p.resolve(strict=True)==p and not p.is_symlink()and stat.S_ISREG(a.st_mode)
    value={k:getattr(a,k)for k in FIELDS};value['sha256']=sha(p)
    assert all(getattr(p.lstat(),k)==value[k]for k in FIELDS);return value
def frozen(p,filename,expected):
    assert sha(p/filename)==expected;body=load(p/filename);rows=body['files']
    entries=rows.items()if type(rows)is dict else((x['path'],x)for x in rows)
    for name,row in entries:
        assert not Path(name).is_absolute()and '..'not in Path(name).parts
        assert sha(p/name)==(row['sha256']if type(row)is dict else row)
    return body
def head():
    raw=(REPO/'.git').read_text();assert raw.startswith('gitdir: ')
    gd=Path(raw[8:].strip());gd=gd if gd.is_absolute()else REPO/gd
    gd=gd.resolve(strict=True);common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    selected=(gd/'HEAD').read_text().strip();assert selected.startswith('ref: ')
    for root in(gd,common):
        ref=root/selected[5:]
        if ref.is_file():return ref.read_text().strip()
    raise AssertionError('Reviewed current branch HEAD unavailable')
def flat_bodies(value):
    # The actual Root bundle and C12 use the SAME flat source format. Do not
    # convert row fields, invent missing stats, or delete an unknown field.
    fields=set(FIELDS)
    for root,body in value.items():
        p=Path(root);assert p.is_absolute()and p.resolve(strict=True)==p and p.is_dir()and p.is_relative_to(REPO/'.ios-host-tmp')
        assert type(body)is dict and '.'in body
        for name,row in body.items():
            assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
            assert type(row)is dict and fields<=set(row)and all(type(row[k])is int for k in FIELDS)
            mode=row['st_mode'];extra={'sha256'}if stat.S_ISREG(mode)else{'target'}if stat.S_ISLNK(mode)else set()
            assert stat.S_ISREG(mode)or stat.S_ISDIR(mode)or stat.S_ISLNK(mode)
            assert set(row)==fields|extra
            if 'sha256'in extra:assert type(row['sha256'])is str and len(row['sha256'])==64
            if 'target'in extra:assert type(row['target'])is str
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source-freeze',required=True);parser.add_argument('--expected-head',required=True);parser.add_argument('--destination',required=True)
    parser.add_argument('--later-terminal-results',required=True);parser.add_argument('--later-sha',required=True);parser.add_argument('--later-bundle-freeze',required=True)
    args=parser.parse_args()
    actual_head=args.expected_head
    assert type(actual_head)is str and len(actual_head)==40 and all(c in'0123456789abcdef'for c in actual_head)
    assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO and head()==actual_head
    own=frozen(CODE,'source-freeze.json',args.source_freeze)
    boundary_qualification,boundary_proof_pins=require_backend_dirfd_qualification(REPO,source_pin,CODE)
    current_helper_proof_pins={};current_source_qualification(REPO,source_pin,current_helper_proof_pins)
    frozen(REPO/'.ios-host-tmp/assets-picker3-reserved-phase-controller23-current-helper-own9-gate-source-private-20261104','source-freeze.json','b54abd8a3ab95a934044130dd31fcc45bdfddd39c1bc74ceb3fa0de4c5418e5d')
    frozen(C14,'source-freeze.json','6d67beb7ff2c1094ba3c68911f243e7b440fb43339f3f7cbf7e36185500afd85')
    frozen(C14_REVIEW,'freeze.json','24f13b53fd27da1e636df8f67b3100f0e0968bb62636ed5d8101ee653491540b')
    old=frozen(OLD,'freeze.json','24f773991b3ff5238712d6bed7b56847b0e1e63f41fba2b64a359f0e56f86f2a')
    frozen(C12,'freeze.json','ea3f310a79432af3e0561d3639737399dd4e387050c34411e457ba5f6748200d')
    frozen(FIXTURE,'freeze.json','abb2f1dadf4b9be26e376b5248d9557d23a4952546b9c28c82b58819fe2ad995')
    frozen(OWN3,'freeze.json','8c079bab025acad40ec33c9519b13b3e0972bf5f54406fc55c8f8f8c8bf27b06')
    qualification=load(OWN3/'results.json')
    assert qualification['actualTests']==3 and qualification['portNegativeCountersQualified']and qualification['terminal']['status']=='PASS'and qualification['terminal']['ownProcessesAbsent']
    assert qualification['portsSourceFreeze']=='ea3f310a79432af3e0561d3639737399dd4e387050c34411e457ba5f6748200d'
    roots,expected,proofs,base,wrapper=root_context()
    roots,expected,extra,later=later_context(Path(args.later_terminal_results),args.later_sha,args.later_bundle_freeze,roots,expected);proofs+=extra
    flat_bodies(expected);assert set(expected)==roots
    assert set(boundary_qualification['requiredOriginalRoots'])<=roots,'Actual Own9 four complete rooms must remain in Root custody before destination birth'
    # Every old original root stays present; saved old statuses stay failures.
    for row in load(OLD/'prior-run-corpus-roots.json'):assert str(REPO/row['path'])in roots
    executables=load(OLD/'host-executable-pins.json')
    for row in executables.values():
        p=Path(row['path']).resolve(strict=True);v=pin(p)
        assert str(p)==row['realPath']and v['sha256']==row['sha256']and(v['st_dev'],v['st_ino'])==(row['device'],row['inode'])
    raw=subprocess.check_output([executables['rg']['realPath'],'--files','-0',*ROOTS],cwd=REPO)
    names=set(filter(None,raw.decode().split('\0')))|{'CMakeLists.txt','interface/CMakeLists.txt'}
    public={name:pin(REPO/name)for name in sorted(names)}
    historical=load(OLD/'isolated-source-origins.json');private={name:row for name,row in historical.items()if row['source']!='unchanged-current-public-dependency'}
    assert len(private)==93
    for name,row in private.items():assert sha(OLD/'source'/name)==row['sha256']
    # All actual old import-map bytes and physical private rows remain separate
    # historical custody; rebase only the new view's physical import origins.
    old_map=load(OLD/'absolute-import-origin-map.json')
    destination=Path(args.destination)
    assert destination.is_absolute()and destination.parent==REPO/'.ios-host-tmp'and destination.parent.resolve(strict=True)==destination.parent and not destination.exists()and destination.resolve()==destination
    destination.mkdir(mode=0o700);view=destination/'source';view.mkdir(mode=0o700)
    def put(name,value):
        p=destination/name;assert p.parent==destination and not p.exists()
        with p.open('x')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
        p.chmod(0o600)
    def copy_file(original,target):
        assert not target.exists();target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        with target.open('xb')as stream:stream.write(original.read_bytes())
        target.chmod(0o600)
    control={'metadata.py','run-one.py','supervise.py','scoped_ports.py','typed_observer.py','monitoring_observer.py','owned_write_boundary.py',
        'backend_dirfd_ports.py','backend_dirfd_admission.py','c10d_admission.py','closed_import_origins.py','metadata_reader.py','source_execution_admission.py','closed_source_metadata.py','readonly-shared-stdlib-sources.json','readonly-own-public-source-verification.json','third-party-source-declarations.json'}
    generated={'execution-plan.json','isolated-source-origins.json','isolated-source-physical-pins.json','absolute-import-origin-map.json','fixture-pins.json','public-dependency-baselines.json','PREPARATION-STATUS.json','manifest.json','registry-preservation-review.json'}
    for row in old['files']:
        name=row['path']
        if name.startswith('source/')or name in control|generated:continue
        copy_file(OLD/name,destination/name)
    for name in control:copy_file(CODE/name,destination/name)
    origins={}
    for name in sorted(names):
        original=REPO/name;copy_file(original,view/name);origins[name]=dict(source='fresh-current-public-dependency',sourcePath=name,sha256=public[name]['sha256'])
    for name,row in private.items():
        target=view/name
        if target.exists():target.unlink()
        original=OLD/'source'/name;copy_file(original,target)
        origins[name]=dict(source='exact-historical-private-controller10-body',sourcePath=relative(original),sha256=row['sha256'],historicalOrigin=row)
    fixture_rows=load(FIXTURE/'candidate-source-rows.json')
    for row in fixture_rows:
        name=row['path'];original=FIXTURE/'candidate'/name;assert sha(original)==row['sha256']
        target=view/name
        if target.exists():target.unlink()
        copy_file(original,target);origins[name]=dict(source='exact-abb2-reserved-fixture',sourcePath=relative(original),sha256=sha(original))
    plan=load(OLD/'execution-plan.json');prospective=load(C12/'PROSPECTIVE-plan.json');old_view=plan['sourceRoot']
    plan.update(prospective);plan['historicalAssembler13Head']=HISTORICAL_ASSEMBLER13_HEAD;plan.update(status='PREPARED_SOURCE_ONLY_UNRUN_REQUIRES_ROOT_REVIEW',sourceRoot=str(view),rootReportedHead=actual_head,actualExpectedHead=actual_head,historicalController10Head='d824159435cbb4e70576ce13e3a343e9858e6caf',reservedFixturePacketPath=relative(FIXTURE),reservedFixtureFreeze='abb2f1dadf4b9be26e376b5248d9557d23a4952546b9c28c82b58819fe2ad995',failedController10ReceiptPath='.ios-host-tmp/assets-picker3-controller10-first-timeout-actual-20261103',executionAuthorized=False,targetExecutionAuthorized=False)
    plan['expectedPickerNodeArgv']=[x.replace(old_view,str(view),1)for x in plan['expectedPickerNodeArgv']]
    plan['historicalPublicGuardPinsAtController10']=plan['publicGuardPinsAtPreparation']
    plan['publicGuardPinsAtPreparation']=len(public)
    plan['runtimeOverlayPolicy']='Fresh independently pinned '+actual_head+' public view with exact93 historical private Controller10 bodies and unchanged abb2 reserved fixture. Historical three additive compositions are private old bytes, not current foreign integration evidence.'
    plan['backendOwn9Qualification']=boundary_qualification
    put('execution-plan.json',plan)
    copy_file(OLD/'absolute-import-origin-map.json',destination/'historical-controller10-import-map.json')
    assert sha(destination/'historical-controller10-import-map.json')==sha(OLD/'absolute-import-origin-map.json')
    copy_file(OLD/'registry-preservation-review.json',destination/'historical-controller10-registry-review.json')
    put('registry-preservation-review.json',dict(historicalController10Review=relative(OLD/'registry-preservation-review.json'),historicalReviewSha256=sha(OLD/'registry-preservation-review.json'),currentPublicRegistrySha256=public['tests/device/contract-versions.json']['sha256'],isolatedHistoricalRegistrySha256=sha(view/'tests/device/contract-versions.json'),allCurrentForeignRowsInIsolatedClaimed=False,publicRowsMutated=False,historicalPrivateTestViewOnly=True))
    put('isolated-source-origins.json',origins)
    physical={'files':{},'directories':{}}
    for path in(view,*sorted(view.rglob('*'))):
        assert not path.is_symlink();s=path.lstat();physical['directories'if path.is_dir()else'files'][str(path.relative_to(view))]={k:getattr(s,k)for k in FIELDS}
    put('isolated-source-physical-pins.json',physical)
    ordered=[view/'tests/device',view/'tests/device/self_tests',view/'tests/device/ios/self_tests'];modules={}
    for root in ordered:
        for path in sorted(root.rglob('*.py')):
            parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
            if package:parts.pop()
            if parts:modules.setdefault('.'.join(parts),dict(path=str(path),relativePath=str(path.relative_to(view)),sha256=sha(path),package=package))
    closed=closed_prepare(destination,view,modules,ordered,CODE)
    modules=closed['modules'];put('closed-source-inputs.json',closed)
    assert closed['backendOwn9Qualification']==boundary_qualification
    assert all(closed['physicalPins'].get(path)==row for path,row in boundary_proof_pins.items())
    assert set(closed['qualificationOutputRoots'])<=roots,'Latest Root context must preserve the actual current helper qualification rooms'
    put('absolute-import-origin-map.json',dict(orderedRoots=[str(p)for p in ordered],modules=modules))
    fixtures=load(OLD/'fixture-pins.json');put('fixture-pins.json',{name:dict(path=str(view/name),sha256=sha(view/name))for name in fixtures})
    put('public-dependency-baselines.json',{name:dict(device=v['st_dev'],inode=v['st_ino'],bytes=v['st_size'],sha256=v['sha256'])for name,v in public.items()})
    proof_paths={Path(row['path'])for row in proofs}
    for row in proofs:
        path=Path(row['path'])
        if path.name.endswith('freeze.json'):
            table=load(path)['files'];entries=table.items()if type(table)is dict else((r['path'],r)for r in table)
            proof_paths.update(path.parent/name for name,_value in entries)
    put('root-context-source-pins.json',{str(p):pin(p)for p in sorted(proof_paths)})
    packet_rows={str(Path(row['path']).parent):row['sha256']for row in proofs if Path(row['path']).name=='freeze.json'}
    put('root-terminal-context.json',dict(allTargetWindowsTerminal=True,originalRoots=sorted(roots),completedRootProofs=[dict(path=relative(Path(p)),freezeSha256=d)for p,d in sorted(packet_rows.items())],expectedRootCount=len(roots),noWriterExclusions=True,baseContext660=base,wrapper665=wrapper,later=later))
    put('explicit-root-original-baselines.json',expected)
    put('qualified-own3-prerequisite.json',dict(packet=relative(OWN3),freezeSha256='8c079bab025acad40ec33c9519b13b3e0972bf5f54406fc55c8f8f8c8bf27b06',counterOnly=True,nodeGateQualified=False,normalAction2Qualified=False,wholeQualified=False))
    historical_paths={OLD/'source'/name for name in private}|{OLD/'absolute-import-origin-map.json',OLD/'isolated-source-origins.json',OLD/'freeze.json'}
    put('historical-private-origin-pins.json',{str(path):pin(path)for path in sorted(historical_paths)})
    compositions=('tests/device/contract-versions.json','tests/device/validate_contract_versions.py','tests/device/ios/adapters/normal_input.py')
    put('historical-compositions-versus-current-public.json',{name:dict(historicalPhysicalPath=str(OLD/'source'/name),historicalSha256=historical[name]['sha256'],currentPublicPhysicalPath=str(REPO/name),currentPublicSha256=public[name]['sha256'],actualPrivateRuntimePath=str(view/name),actualPrivateRuntimeSha256=sha(view/name),currentPublicAuthorityClaimed=False)for name in compositions})
    put('controller-source-custody.json',[dict(path=str(CODE/'source-freeze.json'),sha256=args.source_freeze),dict(path=str(C12/'freeze.json'),sha256='ea3f310a79432af3e0561d3639737399dd4e387050c34411e457ba5f6748200d'),dict(path=str(C14/'source-freeze.json'),sha256='6d67beb7ff2c1094ba3c68911f243e7b440fb43339f3f7cbf7e36185500afd85'),dict(path=str(C14_REVIEW/'freeze.json'),sha256='24f13b53fd27da1e636df8f67b3100f0e0968bb62636ed5d8101ee653491540b')])
    assert all(pin(REPO/name)==v for name,v in public.items())and head()==actual_head
    put('SOURCE-READBACK.json',dict(status='METADATA_ONLY_REVIEW_REQUIRED',actualHead=actual_head,historicalHead=plan['historicalController10Head'],oldPrivateBodies=len(private),source6Unchanged=True,reservedBodies=7,selection=plan['selection'],genericRootCount=len(roots),frozenBodiesCopiedLiterally=True,oldImportMapRetained=True,normalAction2Qualified=False,NodeGateQualified=False,wholeAssetsQualified=False,qualifiedLoaderHelper=closed['qualifiedSourceExecution']['helperSha256'],initialHostBootstrapScope=closed['hostBootstrap'],targets=0))
    put('PREPARATION-STATUS.json',dict(status='METADATA_PREPARED_UNRUN_SEPARATE_ROOT_REVIEW_REQUIRED',head=actual_head,source6Unchanged=True,sevenBodiesPreserved=True,selectedCases=1,rootCount=len(roots),normalAction2Qualified=False,wholeAssetsQualified=False))
    put('manifest.json',dict(kind='private-C15-qualified-C10c-closed-source-reserved-prefix',head=actual_head,selectedCases=1,originalCapSeconds=300,drainSeconds=5,oldPrivateBodies=len(private),publicPins=len(public),sevenBodiesPreserved=True,nodeGateQualified=False,wholeAssetsQualified=False))
    files=[]
    for path in sorted(destination.rglob('*')):
        if path.is_file():files.append(dict(path=str(path.relative_to(destination)),sha256=sha(path),bytes=path.stat().st_size))
    put('freeze.json',dict(status='FROZEN_UNRUN_REQUIRES_SEPARATE_ROOT_REVIEW_AND_TARGET_WINDOW',files=files))
    print(json.dumps(dict(destination=str(destination),freezeSha256=sha(destination/'freeze.json'),currentHead=actual_head,rootCount=len(roots),cases=1,targets=0)))
if __name__=='__main__':main()
