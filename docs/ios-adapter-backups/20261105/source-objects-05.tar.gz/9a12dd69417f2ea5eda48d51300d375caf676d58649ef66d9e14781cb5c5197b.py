"""Metadata/AST-only preparation of exact Root-only source stages."""
import ast,hashlib,json,shutil,stat
from pathlib import Path
R=Path.cwd();P=R/'.ios-host-tmp/emote-current-constructor-own4-window-gated-root-preparation-20261103'
BASE=R/'.ios-host-tmp/emote-current747-constructor-foreign53-final-root-preparation-20261103'
OLD=R/'.ios-host-tmp/emote-callback-window-flow-cache-focused-window-corrected-root-preparation-20261103'
SOURCE=R/'.ios-host-tmp/emote-callback-current-constructor-shared-round-source-proposal-20261103'
assert not (P/'freeze.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
for p in BASE.iterdir():
 if p.is_file() and p.name not in ('freeze.json','prepare-private.py','plan.json','ROOT-PLAN.txt'):shutil.copyfile(p,P/p.name)
publication_names=('audio-passive-actor-source3-root-publication-20261103','avatar-bilateral-initial-cas3-root-publication-20261103',
 'avatar-gpu-original-pixels2-root-publication-20261103','emote-current-constructor-round-root-publication-20261103')
later=[]
for name,count in zip(publication_names,(5,3,2,1)):
 manifest=R/'.ios-host-tmp'/name/'manifest.json';v=json.loads(manifest.read_text());assert len(v['files'])==count and v['wholeFeatureFlagsUnchanged']and v['testsExecutedByPublication']is False
 packet=R/v['sourcePacket'];freezes=[p for p in (packet/'freeze.json',packet/'source-freeze.json')if p.is_file()and sha(p)==v['sourceFreezeSha256']];assert len(freezes)==1
 later.append(dict(path=str(manifest),sha256=sha(manifest),files=v['files'],sourceFreeze=str(freezes[0]),sourceFreezeSha256=v['sourceFreezeSha256'],ownSemanticKeys=v.get('ownSemanticKeys',[]),count=count))
plan=json.loads((P/'foreign53-publication-rebase.json').read_text());plan['laterPublications']=later;save(P/'foreign53-publication-rebase.json',plan)
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 a=p.lstat();v=dict(stat=[getattr(a,k)for k in F]);assert stat.S_ISREG(a.st_mode)or stat.S_ISDIR(a.st_mode)
 if stat.S_ISREG(a.st_mode):v['sha256']=sha(p)
 assert v['stat']==[getattr(p.lstat(),k)for k in F];return v
# Both completed/partial causal outcomes remain explicit, not rerun.
causal={str(p):pin(p)for name in ('round1','literal1')for p in (BASE/name,*sorted((BASE/name).rglob('*')))}
save(P/'actual-causal-profile-pins.json',causal)
shutil.copyfile(BASE/'round1/input-graph-pins.json',P/'actual-current747-input-pins.json')
helper=(BASE/'round1/foreign_publication_rebase.py').read_text()
helper=helper.replace("stage=Path(json.loads((HERE/'input-plan.json').read_text())['actualWindowStage'])","stage=Path("+repr(str(OLD/'window1'))+")")
a=" own=set(plan['ownRegistryKeys']);old=json.loads(oldregistry.read_text());new=json.loads((repo/'tests/device/contract-versions.json').read_text())"
b=""" own=set(plan['ownRegistryKeys'])
 for row in plan['laterPublications']:own.update(row['ownSemanticKeys'])
 old=json.loads(oldregistry.read_text());new=json.loads((repo/'tests/device/contract-versions.json').read_text())"""
assert helper.count(a)==1;helper=helper.replace(a,b)
a=" result=dict(mapping);rows=plan['sourceRows']+[plan['fixtureRow']];assert len({r['path']for r in plan['sourceRows']})==52"
b=""" result=dict(mapping);rows=plan['sourceRows']+[plan['fixtureRow']];assert len({r['path']for r in plan['sourceRows']})==52
 for publication in plan['laterPublications']:
  manifest=Path(publication['path']);assert sha(manifest)==publication['sha256']
  actual=json.loads(manifest.read_text());assert actual['files']==publication['files']and len(actual['files'])==publication['count']
  assert actual['wholeFeatureFlagsUnchanged']and actual['testsExecutedByPublication']is False
  assert actual.get('ownSemanticKeys',[])==publication['ownSemanticKeys']
  if publication['ownSemanticKeys']:assert actual['foreignRegistryAndValidatorSemanticsPreserved']
  else:assert actual['registryChanged']is False
  assert sha(Path(publication['sourceFreeze']))==publication['sourceFreezeSha256']==actual['sourceFreezeSha256']
  rows+=publication['files']"""
assert helper.count(a)==1;helper=helper.replace(a,b)
# One selected ownSource change is reviewed; all other shared required-source
# changes are exact foreign registry or GPU-fixture changes, never a wildcard.
a=" assert deps&{r['path']for r in rows}=={'tests/device/contract-versions.json','tests/device/validate_contract_versions.py'}"
b=" assert deps&{r['path']for r in rows}==set(json.loads((MASTER/'dependency-delta-scope.json').read_text())['changedRequiredDependencies'])"
assert helper.count(a)==1;helper=helper.replace(a,b)
window_plan=json.loads((OLD/'window1/run-plan.json').read_text());allrows=plan['sourceRows']+[plan['fixtureRow']]+[row for pub in later for row in pub['files']]
save(P/'dependency-delta-scope.json',dict(changedRequiredDependencies=sorted(set(window_plan['requiredPublicDependencies'])&{row['path']for row in allrows}),historicalHelper4feaUnchanged=True,ownChange='tests/device/ios/adapters/emote_callback_live.py',exactForeignRowsOnly=True))
gate='''"""Historical27/235/factory2 and genuine own4 gate; no unchanged replay."""
import hashlib,json,stat
from pathlib import Path
from component_prerequisite import require as historical,passed
from foreign_publication_rebase import retained_paths
F=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
OLD=Path(REPLACE_OLD)
def require(here,repo,current=None):
 paths=historical(OLD/'window1',repo,current)+retained_paths()
 pins={}
 for pinmap in ('actual-causal-profile-pins.json','actual-current747-input-pins.json'):pins.update(json.loads((here.parent/pinmap).read_text()))
 for name,expected in pins.items():
  p=Path(name);assert p.resolve(strict=True)==p;a=p.lstat();row=dict(stat=[getattr(a,k)for k in F]);assert stat.S_ISDIR(a.st_mode)or stat.S_ISREG(a.st_mode)
  if stat.S_ISREG(a.st_mode):row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
  assert row==expected and row['stat']==[getattr(p.lstat(),k)for k in F];paths.append(p)
 for stage_name,expected_exit in (('round1',0),('literal1',1)):
  stage=Path(REPLACE_CAUSAL)/stage_name;report=json.loads((stage/'root-run-first/report.json').read_text());assert report['exitCode']==expected_exit and all(report[k]for k in ('allPinsEqual','rootMapUnchanged','retainedOriginalsUnchanged'))and not report['remainingOwnedProcesses']
 if here.name in ('remaining3','window1'):
  first=here.parent/'first1';ids=passed(first,1);assert ids==json.loads((here.parent/'own4-cases.json').read_text())[:1]
  if current is not None:assert json.loads((first/'root-run-first/root-source-map.json').read_text())==current
  frozen=set(json.loads((first/'freeze.json').read_text())['files'])|{'freeze.json'}
  paths += [p for p in first.rglob('*')if str(p.relative_to(first))not in frozen]
 if here.name=='window1':
  remaining=here.parent/'remaining3';ids=passed(remaining,3);assert ids==json.loads((here.parent/'own4-cases.json').read_text())[1:]
  if current is not None:assert json.loads((remaining/'root-run-first/root-source-map.json').read_text())==current
  frozen=set(json.loads((remaining/'freeze.json').read_text())['files'])|{'freeze.json'}
  paths += [p for p in remaining.rglob('*')if str(p.relative_to(remaining))not in frozen]
 return paths
'''.replace('REPLACE_OLD',repr(str(OLD))).replace('REPLACE_CAUSAL',repr(str(BASE)))
model=SOURCE/'models/test_callback_current_constructor_round_models.py'
tree=ast.parse(model.read_text());cases=['test_callback_current_constructor_round_models.CallbackCurrentConstructorRoundModels.'+n.name for cls in tree.body if isinstance(cls,ast.ClassDef)for n in cls.body if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')];assert len(cases)==4;save(P/'own4-cases.json',cases)
old_manifest=json.loads((OLD/'window1/source-manifest.json').read_text());row=next(row for row in old_manifest['sourcePaths']if row['path']=='tests/device/ios/adapters/emote_callback_live.py')if any(row['path']=='tests/device/ios/adapters/emote_callback_live.py'for row in old_manifest['sourcePaths'])else None
source_relative='tests/device/ios/adapters/emote_callback_live.py';own=dict(path=source_relative,candidate=str(SOURCE/'candidate'/source_relative),candidateSHA256=sha(SOURCE/'candidate'/source_relative))
freezes={}
for name,selection,budget,roots in (('first1',cases[:1],15,1),('remaining3',cases[1:],30,3),('window1',window_plan['cases'],600,4)):
 T=P/name;T.mkdir();codebase=OLD/'window1'if name=='window1'else OLD/'focused2'
 for filename,digest in json.loads((codebase/'freeze.json').read_text())['files'].items():
  assert sha(codebase/filename)==digest
  if filename.endswith('.py')or filename=='sdk-original-pins.json':shutil.copyfile(codebase/filename,T/filename)
 # Remove the obsolete unselected old235 private model from this selection.
 (T/'test_current235_readonly_profile.py').unlink(missing_ok=True)
 if name!='window1':shutil.copyfile(model,T/model.name)
 (T/'foreign_publication_rebase.py').write_text(helper)
 component=(T/'component_prerequisite.py').read_text();anchor=" if current is not None:assert current['currentSourcePins']==expected";assert component.count(anchor)==1
 component=component.replace(anchor," from foreign_publication_rebase import apply\n expected=apply(expected,repo)\n"+anchor);(T/'component_prerequisite.py').write_text(component)
 (T/'actual_smoke_prerequisite.py').write_text(gate)
 stage_plan=json.loads((codebase/'run-plan.json').read_text());stage_plan.update(status='PRIVATE_UNRUN_CHANGED_CONSTRUCTOR_SOURCE_OWN4_THEN_WINDOW',cases=selection,caseCount=len(selection),totalCaseCount=len(selection),initialOuterSeconds=budget,expectedRetainedRoots=roots,modelMaps={})
 if name!='window1':stage_plan.update(retainedTemporaryDirectoryAliases=['test_callback_current_constructor_round_models'],mkdtempAliases=[],retainInstalledFixture=False)
 stage_plan['privateFiles']={p.name:sha(p)for p in T.glob('*.py')};save(T/'run-plan.json',stage_plan)
 manifest=json.loads((codebase/'source-manifest.json').read_text());manifest.update(name=name,sourcePaths=[own],caseCount=len(selection),pythonCaseCount=len(selection),initialTimeoutSeconds=budget,actualPublicBasis='Actual Root12 +Assets52/fixture1 +Audio5/Avatar3 +actualGPU2/Emote1 receipts; historical27/235/factory2 +causal26s/partial45s retained honestly. FullWindow requires four actual changed-source model passes; no old full source map declared current.')
 manifest['orderedParentFreezes'][SOURCE.name]=sha(SOURCE/'freeze.json');save(T/'source-manifest.json',manifest)
 superplan=json.loads((codebase/'supervisor-plan.json').read_text());superplan['initialSeconds']=budget;save(T/'supervisor-plan.json',superplan)
 shutil.copyfile(OLD/'window1/prior-retained-original-pins.json',T/'prior-retained-original-pins.json')
 save(T/'master-guard-pins.json',{p.name:sha(p)for p in P.iterdir()if p.is_file()and p.name not in ('freeze.json','prepare-private.py','ROOT-PLAN.txt','plan.json')})
 for path in T.glob('*.py'):ast.parse(path.read_text())
 save(T/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={p.name:sha(p)for p in sorted(T.iterdir())if p.is_file()}));freezes[name]=sha(T/'freeze.json')
save(P/'plan.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',stages=freezes,ownCases=4,first1Seconds=15,remaining3Seconds=30,changedWindowSeconds=600,killAfterSeconds=5,windowRequiresActualOwn4PASS=True,SDKImported=False,targetImports=False,testsRun=False,wholeFeatureQualified=False))
(P/'ROOT-PLAN.txt').write_text('Root-only fixed order first1/root-supervise.py original15+5/1TD, remaining3 original30+5/3TD, then window1 original600+5/4TD HARD actual own4PASS. Each command from resume checkout using PYTHONDONTWRITEBYTECODE=1 python3 -B. ZERO unchanged27/235/factory/profile reruns. Exact actual Root12 then52+fixture1 thenAudio5+Avatar3 thenGPU2+Emote1 ordered publication receipts; all hashes/sourcefreezes/foreign registry and validator semantics/current full source-map strict. Actual helper4fea/mechanisms testf4ed unchanged; Live class one reviewed production method changed. Historical causal round PASS26.334s/278reads and literal partialERROR45s remain exact, no ratio/current-equivalence claim. Sourcee89 is sole selected candidate. Own4 EMPTY metadata mechanisms run actual constructors/locks/censuses/fresh callbacks, zero Node/network/SDK; fullWindow actual2Node PROGRAM allowlist/original VMctor-close passive monitoring/loopback/percase standardRunner-return+2FD/task/thread/process+census/source-beforeafter remain unchanged. Original new53 Window600 timeout747 and old36 unavailable replay remain preserved. No SDK import/current/native/hardware/whole qualification granted by this preparation. No target imports/tests/public edits executed here. Unknown future Assets perf source changes are excluded and will fail exact-map admission.\n')
save(P/'freeze.json',dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(P)):sha(p)for p in sorted(P.rglob('*'))if p.is_file()and p.name!='freeze.json'},stages=freezes))
print(json.dumps(dict(masterFreeze=sha(P/'freeze.json'),stages=freezes)))
