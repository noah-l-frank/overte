"""Original primary/actor current-fact producers over independent real stores.

Normal QML inputs, actual files/HTTP/WAL/backend/weak Model/scene work execute
if Root runs these fixtures. SDK/Qt/Node/parser/Domain/native clock/platform
interfaces remain explicitly modeled. No primary publication is supplied to
Actor; both role endpoints acquire and retain fresh actual producer responses.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import json,uuid
from adapters.native_feature_observation import NativeFeatureObservation,need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters import create_state,emote_world,assets_model_origin
from ios.adapters.assets_checkpoint_scene import AssetsCheckpointScene
from ios.adapters.assets_generation_runtime import GenerationActionAssetsRuntime
from ios.adapters.assets_page_generation_runtime import PageGenerationAssetsRuntime
from ios.adapters.assets_shared_action_runtime import SharedActionAssetsRuntime
from ios.adapters.assets_whole_observation import AssetsWholeObservation
from ios.self_tests.assets_peer_fixture import SceneEndpoint
from ios.self_tests.assets_reply_fixture import Boundary as ReplyBoundary
from ios.self_tests.assets_whole_input_fixture import Fixture as InputFixture
from ios.self_tests.assets_picker_fixture import RUN


class PeerReplies(ReplyBoundary):
    def __init__(self,fixture):
        self.fixture=fixture;super().__init__(pid=43);self.binding=deepcopy(fixture.boundary.reads.binding)
    def clock(self):return self.fixture.boundary.peer.clock()
    def tick(self,amount=1):self.fixture.boundary.tick(amount);self.elapsed=self.clock()-1900000000000;return self.clock()
    def sleep(self,seconds):self.fixture.boundary.sleep(seconds);self.elapsed=self.clock()-1900000000000
    def monotonic(self):return self.fixture.boundary.monotonic()
    def send(self,query):
        # Read the actual server file/mapping model independently for THIS
        # native query; never copy the primary GetAll response or owner state.
        f=self.fixture;self.data={path:(f.backend.b.files/digest).read_bytes() for path,digest in f.backend.mappings.items()}
        self.status={path:f.get_status(path,digest) for path,digest in f.backend.mappings.items()}
        return super().send(query)


class Fixture(InputFixture):
    def __init__(self,test):
        super().__init__(test);self.peer_reads=PeerReplies(self);self.scene_endpoints={}
        fixture=self
        def sources(instance,selector,lock):
            scope=instance.assets_episode;role=('actor' if selector==self.selected.context['roles']['actor']['target'] else 'primary')
            expected=self.a.h.locks[role] if scope is None else scope.locks[role];need(lock is expected);lock.assert_held();instance.assets_action.guard()
            if getattr(instance,'assets_generations',None) is not None:instance.assets_generations.base_guard()
            if role=='primary':return fixture.ports(instance.assets_action)
            value=self.peer_permissions.ports(instance.assets_action);value['replies']=self.peer_reads.native()
            old=value['replies'].guard
            def checked():instance.assets_action.guard();need(old() is not False);return True
            value['replies'].guard=checked;return value
        for cls in (SharedActionAssetsRuntime,PageGenerationAssetsRuntime,GenerationActionAssetsRuntime):
            test.enterContext(patch.object(cls,'_assets_sources',sources))
        test.enterContext(patch.object(AssetsWholeObservation,'scene_parts',lambda observer,selector,role,lock:self.scene_parts(observer,selector,role,lock)))
    def scene_parts(self,observer,selector,role,lock):
        action,scope=observer.action,observer.episode;subject='actor' if role=='actor' else 'primary'
        root=Path(self.selected.context['roles'][subject]['stateRoot']) if scope is None else Path(scope.descriptor['directories'][subject]['stateRoot']['path'])
        key=(action.index,role)
        if key not in self.scene_endpoints:
            # Construct only an explicit host endpoint model, with the genuine
            # independently held canonical lock. No fake successful Model/Parsed
            # owner or second lock is introduced for a pre-model checkpoint.
            ep=object.__new__(SceneEndpoint);ep.fixture,ep.boundary,ep.role=self,self.boundary,role
            ep.world=self.boundary.peer if role=='actor' else self.boundary;ep.root=root;ep.pid=43 if role=='actor' else 42
            ep.binding=deepcopy(self.selected.context['roles'][subject]['binding']);ep.lock=lock;ep.lock_context=None
            ep.raw={};ep.counts=dict(clock=0,state=0,domain=0,origin=0);ep.queries=[];ep.good=True
            ep.instance=uuid.uuid4().hex;ep.domain_instance=uuid.uuid4().hex;ep.monotonic=self.boundary.monotonic;ep.epoch_ms=self.boundary.clock
            self.scene_endpoints[key]=ep
        ep=self.scene_endpoints[key]
        def guarded():action.guard();lock.assert_held();return self.boundary.live
        native=NativeFeatureObservation(lambda query:ep.send('clock',query),lambda:ep.raw.get('clock',''),ep.world.clock,guarded,ep.pid,
            ios=True,native_clock_bound=True,monotonic=ep.monotonic,sleep=self.boundary.sleep)
        def reader(cls,kind):return cls(lambda query:ep.send(kind,query),lambda:ep.raw.get(kind,''),ep.world.clock,guarded,ep.pid,
            monotonic=ep.monotonic,sleep=self.boundary.sleep)
        source=AssetsCheckpointScene(PrivateFeatureState(root/('ios-assets-checkpoint-'+RUN+'-a'+str(action.index)+'-'+role+'-scene.json')),
            ep.binding,RUN,role,lock,guarded,native=native,state=reader(create_state.IOSCreateState,'state'),domain=reader(emote_world.IOSEmoteWorld,'domain'),
            origin=reader(assets_model_origin.IOSAssetsModelOrigin,'origin'),epoch_ms=ep.epoch_ms,monotonic=ep.monotonic,
            selection=self.selected,action=action,episode=scope)
        return dict(check=guarded,scene=source)
    def observed(self,index,*,both=True):
        self.input(index);primary=self.driver.observe_current('primary')
        peer=self.driver.observe_current('actor') if both else None
        self.consume_input(index);return primary,peer
    def through(self,index):
        rows=[]
        for step in range(len(self.a.owner.state['records'])+1,index+1):rows.append(self.observed(step))
        return rows
