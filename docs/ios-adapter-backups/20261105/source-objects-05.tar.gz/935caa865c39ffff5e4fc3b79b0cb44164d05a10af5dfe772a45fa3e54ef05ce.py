"""Future root-granted World6 minimal-terminal exact2; no full19 authority."""
from pathlib import Path
import hashlib,json,os,stat,sys,tempfile,threading,types,unittest
from importlib.machinery import PathFinder

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
PLAN=HERE/'selected-suite-plan.json'
plan=json.loads(PLAN.read_text())
sha=lambda body:hashlib.sha256(body).hexdigest()
packet=REPO/plan['proposal']
assert sha((packet/'freeze.json').read_bytes())==plan['proposalFreezeSha256']
freeze=json.loads((packet/'freeze.json').read_text())
for name,expected in freeze['files'].items():assert sha((packet/name).read_bytes())==expected,name
# No imports or fixtures before exact future source publication/run preflight.
assert sha((REPO/plan['publicPath']).read_bytes())==plan['publicCandidateSha256'],'Recovery test not published at reviewed revision'
runroot=Path(os.environ['OVERTE_WORLD6_RECOVERY_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs') and runroot!=HERE/'runs'
info=runroot.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
temporary=Path(os.environ['TMPDIR']).resolve(strict=True)
assert temporary==runroot/'temporary' and Path(tempfile.gettempdir())==temporary
info=temporary.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
assert not any(temporary.iterdir()) and not (runroot/'selected2-result.json').exists(),'Fresh root required'
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(path):
    before=path.lstat();assert stat.S_ISREG(before.st_mode) or stat.S_ISDIR(before.st_mode),str(path)
    value={field:getattr(before,field) for field in FIELDS}
    if stat.S_ISREG(before.st_mode):value['sha256']=sha(path.read_bytes())
    after=path.lstat();assert all(getattr(before,f)==getattr(after,f) for f in FIELDS),str(path)
    return value
for name,row in plan['reviewedFixturePins'].items():
    actual=pin(REPO/name);assert actual['sha256']==row['sha256'] and all(actual[key]==value for key,value in row['stat'].items()),name
source_paths=[REPO/plan['publicPath'],PLAN,Path(__file__),packet/'freeze.json']
source_paths.extend(REPO/name for name in plan['reviewedFixturePins'])
ROOT_MAP=HERE/'source-root-final-map.json'
assert sha(ROOT_MAP.read_bytes())==plan['sourceRootMapSha256']
root_map=json.loads(ROOT_MAP.read_text())
source_paths.append(ROOT_MAP)
source_paths.extend(REPO/row['path'] for row in root_map['modules'].values())
source_before={str(path):pin(path) for path in source_paths}
thread_before=set(threading.enumerate())

def spec_without_import(name):
    # Use explicit parent search paths. Public find_spec may construct a nested
    # NamespacePath whose parent is absent from sys.modules before imports.
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:assert search is not None,name
    return spec

def preimport_source_roots():
    assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
    top_names={name.split('.')[0] for name in root_map['packageRoots']}
    assert not any(name.split('.')[0] in top_names for name in sys.modules),'Target namespace imported before source preflight'
    expected=[str(REPO/name) for name in root_map['orderedRoots']]
    remaining=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==REPO or REPO in path.parents:continue
        if str(path) not in remaining:remaining.append(str(path))
    sys.path[:]=expected+remaining
    for name,relative in root_map['packageRoots'].items():
        spec=spec_without_import(name)
        assert [str(Path(path).resolve()) for path in spec.submodule_search_locations or ()]==[str(REPO/relative)],name
    actual={}
    for name,row in root_map['modules'].items():
        spec=spec_without_import(name)
        assert spec.origin is not None,name
        path=Path(spec.origin).resolve(strict=True)
        assert path==REPO/row['path'] and sha(path.read_bytes())==row['sha256'],name
        actual[name]=str(path)
    (runroot/'preimport-source-root-actual.json').write_text(json.dumps(dict(orderedRoots=expected,modules=actual),indent=2)+'\n')

preimport_source_roots()
from ios.self_tests import test_ios_emote_marker_scope as marker_fixture
from ios.self_tests import world_web_actor_fixture as actor_fixture
from ios.self_tests.retained_host_roots import retain_owned_root

real_temporary_directory=tempfile.TemporaryDirectory
retained=[]
def retained_temporary_directory(*args,**kwargs):
    directory=real_temporary_directory(*args,**kwargs)
    root=Path(directory.name);assert root.is_relative_to(temporary)
    root=retain_owned_root(directory,expected_root=root)
    retained.append(str(root));print('RETAINED_ACTUAL_WORLD6_ROOT',root,flush=True)
    return directory

# Only fixture-local names. Keep real TemporaryDirectory/retain idempotence;
# no product decoder, file/HTTP/session getter, server or process is replaced.
original_aliases=[(module,module.tempfile) for module in (marker_fixture,actor_fixture)]
result=None
try:
    for module,original in original_aliases:
        assert original is tempfile
        module.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_temporary_directory)
    ids=plan['caseIds'];assert len(ids)==len(set(ids))==2
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for item in value:yield from flatten(item)
        else:yield value
    actual_ids=[test.id() for test in flatten(suite)]
    assert not loader.errors and actual_ids==ids and suite.countTestCases()==2,(loader.errors,actual_ids)
    print('ACTUAL_SELECTED_IDS',json.dumps(actual_ids),flush=True)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    assert result.testsRun==2 and not result.skipped,'Both selected cases must execute without skip'
finally:
    for module,original in original_aliases:module.tempfile=original
    assert tempfile.TemporaryDirectory is real_temporary_directory
    assert all(module.tempfile is original for module,original in original_aliases)
    assert source_before=={str(path):pin(path) for path in source_paths},'Source/launcher/fixture revision changed'
    def originals():return {str(path.relative_to(temporary)):pin(path) for path in (temporary,*sorted(temporary.rglob('*')))}
    first=originals();second=originals();assert first==second,'Post-test originals changed'
    (runroot/'selected2-originals-first.json').write_text(json.dumps(first,indent=2)+'\n')
    (runroot/'selected2-originals-second.json').write_text(json.dumps(second,indent=2)+'\n')
    remaining=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon)
        for thread in threading.enumerate() if thread not in thread_before and thread.is_alive()]
    report=dict(testsRun=None if result is None else result.testsRun,selectedCount=2,
        successful=False if result is None else result.wasSuccessful(),skipped=[] if result is None else result.skipped,
        retainedTemporaryDirectoryRoots=retained,fixtureAliasesRestored=True,
        sourceLauncherFixturePinsUnchanged=True,postTestOriginalCensusesEqual=True,
        newRemainingThreads=remaining,nativeCompiled=False,sdkExecuted=False,deviceQualified=False,
        whole19Qualified=False,full19CapClosed=True)
    (runroot/'selected2-result.json').write_text(json.dumps(report,indent=2)+'\n')
    print('ACTUAL_RESULT',json.dumps(report),flush=True)
    assert not remaining,'New fixture/worker/listener threads remain live'
sys.exit(0 if result is not None and result.wasSuccessful() else 1)
