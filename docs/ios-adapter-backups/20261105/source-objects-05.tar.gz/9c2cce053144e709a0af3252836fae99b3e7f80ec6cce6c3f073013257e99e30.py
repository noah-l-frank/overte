"""Root metadata-only assembler. No target or product import is performed.

Invocation requires a later explicit quiet Root context and exact external
module manifest. Merely importing this module performs no work.
"""
from pathlib import Path
import argparse,hashlib,importlib.machinery,importlib.util,json,os,shutil,stat,sys

REPO=Path(__file__).resolve().parents[2]
CONTROLLER=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller6-no-site-startup-code-preparation-20261104'
CONTROLLER_SHA='1a517b07d8c888d79cbfe86116def12a8d65b1f9a24f971bde4afa4b5caa4fea'
PROPOSAL=REPO/'.ios-host-tmp/chat-offline-send-no-replay-source1-private-20261104'
PROPOSAL_SHA='b1df990cbb9187fe6982cafe0a9e4065283eb541c7f30860162afd624a390f9b'
HISTORICAL=REPO/'.ios-host-tmp/lifecycle-moving-primary-first1-root687-source4-controller6-final-preparation-20261104'
HISTORICAL_SHA='d0a91ab61a8e578fadc17c4fd9f9ecf17c81ccc2751fb617e5e29eac80f95516'
GLOBAL_HELPER_SHA='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def excluded(path):return any(p in('site-packages','dist-packages')for p in path.parts)
def hex40(value):return type(value)is str and len(value)==40 and all(c in'0123456789abcdef'for c in value)


def checked_packet(directory,leaf,expected,pin):
    directory=Path(directory);assert sha(directory/leaf)==expected
    rows={str(directory/leaf):pin(directory/leaf)}
    packet=load(directory/leaf)
    files=packet['files']
    items=((r['path'],r)for r in files)if type(files)is list else files.items()
    for name,row in items:
        path=directory/name
        assert path.resolve(strict=True)==path and path.is_relative_to(directory)
        digest=row if type(row)is str else row['sha256']
        assert sha(path)==digest
        rows[str(path)]=pin(path)
    return rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head',required=True)
    parser.add_argument('--assembler-source-sha256',required=True)
    parser.add_argument('--root-context',type=Path,required=True)
    parser.add_argument('--root-context-sha256',required=True)
    parser.add_argument('--external-manifest',type=Path,required=True)
    parser.add_argument('--external-manifest-sha256',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert sys.dont_write_bytecode and Path.cwd()==REPO and hex40(args.expected_head)
    assert sys.flags.no_site == 1, "Explicit no-site interpreter startup required"
    assembler=Path(__file__).resolve().parent
    assert sha(assembler/'source-freeze.json')==args.assembler_source_sha256
    for name,row in load(assembler/'source-freeze.json')['files'].items():assert sha(assembler/name)==row['sha256']
    # Only independently hashed stdlib-only controller definitions are loaded.
    assert sha(CONTROLLER/'source-freeze.json')==CONTROLLER_SHA
    for name,row in load(CONTROLLER/'source-freeze.json')['files'].items():assert sha(CONTROLLER/name)==row['sha256']
    spec=importlib.util.spec_from_file_location('chat_offline_metadata_assembler',CONTROLLER/'metadata.py')
    M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
    assert M.head()==args.expected_head
    pins=checked_packet(CONTROLLER,'source-freeze.json',CONTROLLER_SHA,M.pin)
    pins.update(checked_packet(assembler,'source-freeze.json',args.assembler_source_sha256,M.pin))
    pins.update(checked_packet(PROPOSAL,'freeze.json',PROPOSAL_SHA,M.pin))
    # Historical metadata remains exact; its old public pin values are DATA,
    # not instructions to relabel old public files as the current runtime.
    pins.update(checked_packet(HISTORICAL,'freeze.json',HISTORICAL_SHA,M.pin))
    for directory,expected in(
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller1-code-preparation-20261104','4eb83643183a1953db3c1f7f2e7b093c1841b9ed5f2acb73883a314f9692aa0c'),
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller2-strict-origins-code-preparation-20261104','a846c7039b33fae0dc427d9cdbbe19e26e72a6a6a0d9f83c0496d1e431c534e3'),
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller3-package-spec-input-pin-code-preparation-20261104','f7e427301cded1b35ba46722f4194781399aca59baa8e2d576a637f4770d14e6'),
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller4-current-head-initial-module-custody-code-preparation-20261104','057ef27ebd51c0507ba1cc1fdd68cda76c5751472e5acb720120b4c410027fe4'),
        (REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller5-exact-readonly-stdlib-source-links-code-preparation-20261104','61c14acd1997272f039fa28c74c39fe9760f7f3ec9e8cf649d13cddd2028a510')):
        pins.update(checked_packet(directory,'source-freeze.json',expected,M.pin))
    for path,expected in((args.root_context,args.root_context_sha256),(args.external_manifest,args.external_manifest_sha256)):
        assert path.is_absolute()and path.resolve(strict=True)==path and sha(path)==expected
        pins[str(path)]=M.pin(path)
    context=load(args.root_context);external=load(args.external_manifest)
    assert context['status']=='ROOT_REVIEWED_QUIET_CURRENT_SOURCE_AND_ORIGINAL_CONTEXT'
    assert context['expectedHead']==args.expected_head and context['allTargetsTerminal']is True
    assert external['status']=='ROOT_REVIEWED_EXACT_EXTERNAL_MODULE_FRONTIER'
    assert set(external)=={'status','modules','namespaces','physicalFiles'}
    custody=context['globalCustody']
    for key in('helper','seed','baseline'):
        row=custody[key];path=Path(row['path'])
        assert path.is_absolute()and path.resolve(strict=True)==path and sha(path)==row['sha256']
        pins[str(path)]=M.pin(path)
    assert custody['helper']['sha256']==GLOBAL_HELPER_SHA
    assert Path(custody['seed']['path'])==Path(custody['helper']['path']).with_name('global-original-roots-seed.json')
    baseline=load(custody['baseline']['path']);seed=load(custody['seed']['path'])
    assert set(baseline)==set(seed['roots'])
    old=load(HISTORICAL/'global-original-corpus-baseline.json')
    assert set(old)<=set(baseline)and all(baseline[name]==rows for name,rows in old.items())
    # Root explicitly supplies every later terminal proof and the full output
    # roots, not an inferred current count or a writer exclusion.
    assert type(context['terminalAdditions'])is list
    for addition in context['terminalAdditions']:
        for name in addition['roots']:assert name in baseline
        packet=Path(addition['packet'])
        pins.update(checked_packet(packet,addition['freezeFile'],addition['freezeSha256'],M.pin))
    for row in context['additionalPhysicalProofs']:
        path=Path(row['path']);assert sha(path)==row['sha256'];pins[str(path)]=M.pin(path)
    output=args.output
    assert output.is_absolute()and output.resolve(strict=False)==output and output.parent==REPO/'.ios-host-tmp'
    assert output.name.startswith('chat-offline-initial4-prepared-')and not output.exists()
    assert output not in(CONTROLLER,PROPOSAL,HISTORICAL)
    # Every project alias is constructed from current public .py files. The
    # exact Source1 five rows are the only possible private module overlays.
    modules={};namespaces={};public_paths=set();ambiguous_aliases={}
    public_roots=[Path(value)for value in load(HISTORICAL/'public-source-namespace.json')['roots']]
    for root in public_roots:
        assert root.is_relative_to(REPO)and not root.is_relative_to(REPO/'.ios-host-tmp')
        for path in(root,*sorted(root.rglob('*'))):
            assert path.resolve(strict=True)==path and not path.is_symlink()
            public_paths.add(str(path))
            if path.is_file():pins[str(path)]=M.pin(path)
    # Ordered aliases are independently declared. A different physical file
    # with the same alias refuses; no silent PathFinder-precedence adoption.
    for root in(REPO/'tests/device',REPO/'tests/device/self_tests',REPO/'tests/device/ios/self_tests'):
        for path in sorted(root.rglob('*.py')):
            parts=list(path.relative_to(root).with_suffix('').parts);package=parts[-1]=='__init__'
            if package:parts.pop()
            if not parts:continue
            name='.'.join(parts);row=dict(path=str(path),sha256=sha(path),package=package)
            if name in ambiguous_aliases:
                if row not in ambiguous_aliases[name]:ambiguous_aliases[name].append(row)
            elif name in modules and modules[name]!=row:
                ambiguous_aliases[name]=[modules.pop(name),row]
            else:modules[name]=row
            for depth in range(1,len(parts)):
                prefix='.'.join(parts[:depth]);directory=root.joinpath(*parts[:depth])
                if not(directory/'__init__.py').is_file():
                    values=namespaces.setdefault(prefix,[])
                    if str(directory)not in values:values.append(str(directory))
    # These two actual bare aliases have different public files. Neither
    # receives import authority; both canonical qualified names remain real.
    assert set(ambiguous_aliases)=={'test_appium_adapter','test_voice_roundtrip'}
    assert not set(ambiguous_aliases).intersection(sys.stdlib_module_names)
    for name,choices in ambiguous_aliases.items():
        assert name not in modules and len(choices)==2
        assert modules['self_tests.'+name]in choices
        assert modules['ios.self_tests.'+name]in choices
    for name in modules:namespaces.pop(name,None)
    deps=load(PROPOSAL/'DEPENDENCIES.json')
    for row in deps['publicPhysicalDependencies']:
        assert sha(row['path'])==row['sha256'];pins[row['path']]=M.pin(row['path'])
    assert len(deps['overlays'])==5
    for row in deps['overlays']:
        assert sha(row['path'])==row['sha256']
        modules[row['module']]=dict(path=row['path'],sha256=row['sha256'],package=False)
        pins[row['path']]=M.pin(row['path'])
    # Actual stdlib's entire source/extension frontier is pinned BEFORE imports,
    # including initially loaded frozen-source representations. No site root.
    std=Path(vars(os)['__file__']).resolve(strict=True).parent
    assert std.is_dir()and not excluded(std)
    extensions=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    std_namespaces={}
    for current,dirs,names in os.walk(std,topdown=True,followlinks=False):
        directory=Path(current)
        # Prune excluded installation trees BEFORE descending. No installed
        # SDK/package tree is enumerated as a guessed stdlib allowance.
        dirs[:]=sorted(name for name in dirs if name not in('site-packages','dist-packages','__pycache__')
            and not(directory/name).is_symlink())
        relative=directory.relative_to(std)
        if relative.parts and all(part.isidentifier()for part in relative.parts)and not(directory/'__init__.py').is_file():
            std_namespaces['.'.join(relative.parts)]=[str(directory)]
        for name in sorted(names):
            path=directory/name
            if path.suffix!='.py'and not any(str(path).endswith(suffix)for suffix in extensions):continue
            real=path.resolve(strict=True)
            if excluded(real)or not real.is_relative_to(std):continue
            assert real.is_file();pins[str(real)]=M.pin(real)
    python=Path(sys.executable).resolve(strict=True);pins[str(python)]=M.pin(python)
    for name,module in tuple(sys.modules.items()):
        if module is None:continue
        file=vars(module).get('__file__')
        if file is None:continue
        path=Path(file).resolve(strict=True)
        if path.is_relative_to(std)and not excluded(path):pins[str(path)]=M.pin(path)
        elif path.parent in(Path(__file__).resolve().parent,CONTROLLER):pins[str(path)]=M.pin(path)
        else:assert name in external['modules']and external['modules'][name]['path']==str(path),'Unaccounted metadata bootstrap module: '+name
    for path,row in external['physicalFiles'].items():
        assert Path(path).is_absolute()and Path(path).resolve(strict=True)==Path(path)
        assert M.pin(path)==row;pins[path]=row
    for name,row in external['modules'].items():
        assert set(row)=={'path','sha256','package','loader'}and row['loader']in('source','extension')
        assert name not in modules and row['path']in pins and pins[row['path']]['sha256']==row['sha256']
        assert not Path(row['path']).is_relative_to(REPO)
    node=Path(shutil.which('node')).resolve(strict=True);pins[str(node)]=M.pin(node)
    script=REPO/'tests/device/ios/self_tests/chat_message_script_domain.js';model=script.with_suffix('.py')
    pins[str(script)]=M.pin(script);pins[str(model)]=M.pin(model)
    # No temporary/runs/raw room is born; only a new metadata destination.
    output.mkdir(mode=0o700)
    def save(name,value):
        path=output/name
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w')as stream:json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n')
        return path
    for key,name in(('helper','global_original_corpus.py'),('seed','global-original-roots-seed.json'),('baseline','global-original-corpus-baseline.json')):
        original=Path(custody[key]['path']);target=output/name
        with original.open('rb')as incoming,target.open('xb')as outgoing:shutil.copyfileobj(incoming,outgoing)
        target.chmod(0o600);assert sha(target)==custody[key]['sha256'];pins[str(target)]=M.pin(target)
    public=save('public-source-namespace.json',dict(roots=[str(r)for r in public_roots],paths=sorted(public_paths)));pins[str(public)]=M.pin(public)
    aliases=save('absolute-module-origins.json',dict(modules=modules,namespaces=namespaces,thirdPartyModules=external['modules'],thirdPartyNamespacePackages=external['namespaces']));pins[str(aliases)]=M.pin(aliases)
    unadmitted=save('unadmitted-public-aliases.json',dict(status='NO_BARE_ALIAS_AUTHORITY_GRANTED',aliases=ambiguous_aliases))
    pins[str(unadmitted)]=M.pin(unadmitted)
    plan=dict(status='ROOT_REVIEWED_PREPARED_UNRUN',head=args.expected_head,controllerSourceFreeze=CONTROLLER_SHA,
        currentHeadAdmission=dict(exactRootExpectedHead=args.expected_head,historicalControllerHead='06ff22857d8c8298390e00cd5df1c848a1d9c6a5',historicalManifestsPreserved=True),
        unadmittedPublicAliases=dict(path=str(unadmitted),sha256=sha(unadmitted),names=sorted(ambiguous_aliases)),
        proposalFreeze=PROPOSAL_SHA,cases=load(PROPOSAL/'INITIAL-SELECTION.json')['ids'],seconds=180,graceSeconds=5,
        maxNodePerCase=1,maxLiveNodes=1,maxTotalNodes=4,TDsPerExecutedCase=3,loopbacksAllowed=False,
        source15Or17Adopted=False,wholeQualified=False,physicalPins=pins,modules=modules,namespacePackages=namespaces,
        thirdPartyModules=external['modules'],thirdPartyNamespacePackages=external['namespaces'],stdlibNamespacePackages=std_namespaces,
        stdlibRoots=[str(std)],pythonExecutable=dict(path=str(python),pin=pins[str(python)]),
        publicNamespace=dict(path=str(public),sha256=sha(public)),
        node=dict(path=str(node),pin=pins[str(node)]),nodeScript=dict(path=str(script),pin=pins[str(script)]),nodeModel=dict(path=str(model),pin=pins[str(model)]),
        globalCustody=dict(helperPath=str(output/'global_original_corpus.py'),seedPath=str(output/'global-original-roots-seed.json'),
            seedSha256=sha(output/'global-original-roots-seed.json'),baselinePath=str(output/'global-original-corpus-baseline.json'),baselineSha256=sha(output/'global-original-corpus-baseline.json')))
    prepared=save('plan.json',plan);plan_sha=sha(prepared)
    M.validate(prepared,plan_sha,CONTROLLER_SHA,args.expected_head)
    assert M.head()==args.expected_head
    for path,row in pins.items():assert M.pin(path)==row
    summary=save('preparation-summary.json',dict(status='UNRUN_REQUIRES_ROOT_FINAL_REVIEW_AND_SEPARATE_TARGET_WINDOW',head=args.expected_head,controllerSourceFreeze=CONTROLLER_SHA,
        planPath=str(prepared),planSha256=plan_sha,physicalPins=len(pins),projectModules=len(modules),projectNamespaces=len(namespaces),
        externalModules=len(external['modules']),oldRootNamespaces=len(baseline),allReviewedHistoricalBaselineBodiesPreserved=True,historicalBaselineRootCount=len(old),rootCountIsNotExecutionCap=True,
        noProductImports=True,noTarget=True,noGlobalCensus=True,noRawRootBorn=True,nativeQualified=False,wholeQualified=False))
    frozen={}
    for path in sorted(output.iterdir()):
        assert path.is_file()and not path.is_symlink();frozen[path.name]=dict(bytes=path.stat().st_size,sha256=sha(path))
    freeze=save('freeze.json',dict(status='FROZEN_PREPARED_UNRUN_REQUIRES_ROOT_REVIEW',files=frozen))
    print(json.dumps(dict(freeze=str(freeze),freezeSha256=sha(freeze),plan=str(prepared),planSha256=plan_sha,controllerSourceFreeze=CONTROLLER_SHA),indent=2))
    return 0


if __name__=='__main__':raise SystemExit(main())
