"""Real original multi-generation QML/File4/Reply3/Model host producers.

SDK construction, Qt, parser, server and renderer remain declared host models.
Independent phase originals never count as target/peer/whole29 acceptance.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import weakref
import json
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.assets_generation_runtime import GenerationActionAssetsRuntime
from ios.adapters.assets_page_generation_runtime import PageGenerationAssetsRuntime
from ios.adapters.assets_page_generation_recovery import reconstruct_page_generations
from ios.adapters.assets_page_generations import AssetsPageGenerations
from ios.adapters.assets_step_consumer import AssetsStepConsumer
from ios.self_tests.assets_dead_page_retirement_fixture import Fixture as FirstFixture,Boundary as FirstBoundary
from ios.self_tests.assets_picker_fixture import RUN,URL,uid


class PageObject:
    def __init__(self):
        self.id,self.model,self.tree,self.rename,self.remove,self.destination=(uid() for _ in range(6))


class Boundary(FirstBoundary):
    def __init__(self,directory):
        self.page_objects=[];self.live_page=None;super().__init__(directory)
    def exchange(self,value):
        before=getattr(self,'host_state',{}).get('pageAlive',False);result=super().exchange(value)
        if before and not result['pageAlive']:self.live_page=None
        if result['pageAlive'] and not before:
            page=PageObject();self.live_page=page;self.page_objects.append((page.id,weakref.ref(page)))
            self.page,self.model,self.tree_id,self.rename,self.remove,self.destination=page.id,page.model,page.tree,page.rename,page.remove,page.destination
        return result


class Fixture(FirstFixture):
    boundary_type=Boundary
    def __init__(self,test):
        self.generations=None;super().__init__(test)
    def resolve_model(self,url):
        path=url[4:];digest=self.backend.mappings[path]
        if path.lower().endswith('.fbx'):
            prefix='/.baked/'+digest+'/'
            meta=json.loads((self.backend.b.files/self.backend.mappings[prefix+'meta.json']).read_bytes())
            target=meta.get('redirect_target','') or prefix+'asset.fbx';digest=self.backend.mappings[target]
        return (self.backend.b.files/digest).read_bytes()
    def runtime(self):
        if self.generations is None:return super().runtime()
        fixture=self
        class Adapter:
            def state_path(_self,selector):return fixture.a.h.roots[selector]/'session.json'
            def _candidate_guard(_self):return True
            def _binding(_self,*_args):raise AssertionError('Real SDK acquisition is outside this original host model')
        runtime=PageGenerationAssetsRuntime(Adapter(),self.selected,assets_action=self.action,phase=self.a.phase,episode=self.scope,
            generations=self.generations,monotonic=self.boundary.monotonic,epoch_ms=lambda:self.boundary.clock()+5000)
        def sources(selector,lock):
            need(selector=='primary' and lock is runtime.assets_episode.locks['primary']);lock.assert_held()
            runtime.assets_action.guard();runtime.assets_generations.base_guard();return self.ports(runtime.assets_action)
        runtime._assets_sources=sources;return runtime
    def prepare(self):
        _runtime,parts=super().prepare()
        store=PrivateFeatureState(self.a.h.roots['primary']/('ios-assets-page-generations-'+RUN+'-primary.json'))
        self.generations=AssetsPageGenerations(self.episodes,self.a.owner,store);self.generations.reserve()
        self.generations.attach_initial(self.birth,self.page);return self.runtime(),parts
    def refresh(self):
        self.generations=reconstruct_page_generations(self.episodes,self.a.owner,tuple(self.scopes),live=True)['owner']
        self.page=self.generations.contexts[len(self.generations.state['entries'])].page
        return self.generations
    def consume(self,*,runtime=None,parts=None):
        event=dict(contractVersion=1,runId=RUN,stepIndex=self.action.index,ticket=self.action.ticket)
        consumer=(runtime.generation_step_consumer(parts) if runtime is not None else
            AssetsStepConsumer(self.a.owner,page_generations=self.generations,episode_scopes=tuple(self.scopes)))
        result=consumer(event);self.refresh();return result
    def remove_reenter(self,*,parts=None):
        runtime=self.runtime()
        value=runtime.normal_remove_reenter('primary',RUN,'primary',URL,self.lock,self.backend.config,
            episode_scopes=tuple(self.scopes),parts=self.parts if parts is None else parts)
        self.parts=value;self.generations=runtime.assets_generations;self.page=value['next_page_lease']
        return runtime,value
    def view(self,runtime,parts):
        fixture=self
        def sources(instance,selector,lock):
            need(selector=='primary' and lock is instance.assets_episode.locks['primary'])
            instance.assets_action.guard();return fixture.ports(instance.assets_action)
        with patch.object(GenerationActionAssetsRuntime,'_assets_sources',sources):
            return runtime.generation_view_components('primary',RUN,'primary',URL,self.lock,parts,episode_scopes=tuple(self.scopes))
    def current_view(self):
        from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
        from ios.adapters.assets_generation_page_inventory import archive_generation_page
        number={2:2,3:3,4:4}[self.scope.index];old=number-1
        members=tuple(scope for scope in self.scopes if scope.index in {1:(1,2),2:(3,),3:(4,)}[old])
        page=archive_generation_page(self.episodes,old,self.generations.contexts[old].birth,members)['owner']
        graph=AssetsEpisodeModelGraph(self.scope,page,actions=self.a.owner,dependency_mode=True).decode()
        fixture=self
        class Adapter:
            def state_path(_self,selector):return fixture.a.h.roots[selector]/'session.json'
            def _candidate_guard(_self):return True
            def _binding(_self,*_args):raise AssertionError('No real SDK factory in host model')
        runtime=GenerationActionAssetsRuntime(Adapter(),self.selected,assets_action=self.action,phase=self.a.phase,episode=self.scope,
            generation=self.generations.contexts[number].birth,origin_graph=graph,generations=self.generations,
            episode_scopes=tuple(self.scopes),monotonic=self.boundary.monotonic,epoch_ms=lambda:self.boundary.clock()+5000)
        runtime._assets_sources=lambda selector,lock:self.ports(self.action)
        return runtime,runtime.generation_components('primary',RUN,'primary',URL,self.lock)
    def finish_gltf(self):
        runtime,parts=self.remove_reenter();view,components=self.view(runtime,parts)
        self.consume(runtime=view,parts=components)
        # These declared permission/denied-delete boundary transitions are
        # actual original QML controls, not a claim of real Domain propagation.
        for index,write in ((10,False),(11,None),(12,True)):
            self.activate(index);view,components=self.current_view()
            if write is not None:self.boundary.configure(canWrite=write,effectiveWrite=write)
            else:
                tree=components['tree']
                if tree.state is None:tree.reserve();tree.browse()
                actual=tree.page();need(not actual['canWrite'])
                packet=components['generation_view'].capture()
                rows=[row for row in packet['controls'] if row['id']=='assets.delete'];need(len(rows)==1 and not rows[0]['enabled'])
            self.consume(runtime=view,parts=components)
        self.activate(13);view,components=self.current_view();view.generation_delete(components)
        self.consume(runtime=view,parts=components)
    def prepare_obj(self):
        self.finish_gltf();self.activate(14);self.episode(3);self.boundary.reads.resource='obj-bundle/main.obj'
        runtime=self.runtime()
        self.parts=runtime._assets_prepare_unbaked_upload('primary',RUN,'primary',URL,self.action.ticket,self.lock,self.backend.config,resource='obj-bundle/main.obj')
        self.consume();self.activate(15);runtime=self.runtime()
        self.parts=runtime._assets_unbaked_components('primary',RUN,'primary',URL,self.lock,self.backend.config)
        runtime._assets_import_unbaked(self.parts);self.consume();self.activate(16)
        return self.removal_parts()
    def finish_obj(self):
        runtime,parts=self.remove_reenter();view,components=self.view(runtime,parts)
        self.consume(runtime=view,parts=components)
        self.activate(17);view,components=self.current_view();view.generation_delete(components)
        self.consume(runtime=view,parts=components)
    def prepare_fbx(self):
        from adapters.asset_backend_client import AssetsBackendClient
        from ios.adapters.assets_backend_owner import OwnedAssetsBackend
        self.prepare_obj();self.finish_obj();self.activate(18);self.episode(4)
        self.boundary.reads.resource='asset-stand.fbx';runtime=self.runtime()
        self.parts=runtime._assets_stage_fbx_upload('primary',RUN,'primary',URL,self.action.ticket,self.lock,self.backend.config)
        self.consume();self.activate(19);runtime=self.runtime()
        self.parts=runtime._assets_components('primary',RUN,'primary',URL,self.lock)
        backend=OwnedAssetsBackend(self.parts['upload'],AssetsBackendClient(self.backend.config,self.parts['check']),
            runtime._assets_store('primary',RUN,'primary','backend'),lock=self.lock)
        self.parts=dict(self.parts,backend=backend)
        runtime._assets_stage_baking_off(self.parts);self.consume()
        self.activate(20);runtime=self.runtime()
        self.parts=runtime._assets_baking_components('primary',RUN,'primary',URL,self.lock,self.backend.config)
        runtime._assets_stage_baking_on(self.parts,self.action.ticket);self.consume()
        self.activate(21);runtime=self.runtime()
        self.parts=runtime._assets_parsed_components('primary',RUN,'primary',URL,self.lock,self.backend.config)
        runtime._assets_stage_import_baked(self.parts,self.action.ticket);self.consume()
        self.activate(22)
        runtime=self.runtime()
        self.parts=runtime._assets_parsed_components('primary',RUN,'primary',URL,self.lock,self.backend.config)
        self.parts=runtime._assets_model_removal_components('primary',RUN,'primary',URL,self.lock,self.backend.config,parts=self.parts)
        removal=self.parts['model_removal']
        if removal.state is None:removal.reserve()
        if removal.state['phase']!='model-gone':
            self.boundary.attach_create();removal.remove()
        return runtime,self.parts
    def finish_fbx(self):
        runtime,parts=self.remove_reenter();view,components=self.view(runtime,parts)
        self.consume(runtime=view,parts=components)
        self.activate(23);view,components=self.current_view();view.generation_delete(components)
        self.consume(runtime=view,parts=components);return view,components
