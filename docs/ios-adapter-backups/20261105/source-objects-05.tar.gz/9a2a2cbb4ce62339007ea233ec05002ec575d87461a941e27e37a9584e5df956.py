"""One fixed remaining Snapshot Scene/order host-owner group; native producers are models."""
from pathlib import Path
from metadata_reader import pin
from closed_import_origins import ClosedOrigins
from host_common import head
from source_execution_readiness import qualification
from initial_four_admission import require_initial_four
import builtins,contextlib,hashlib,importlib.abc,importlib.util,io,json,os,signal,stat,sys,tempfile,threading,time,traceback,types,unittest
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert sys.flags.no_site==1, 'Explicit no-site startup required'
assert len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert plan['status']=='PRIVATE_SNAPSHOT_SCENE_REMAINING_GROUP_UNRUN_PROOF_JOIN_PENDING'
recipe=json.loads((HERE/'SOURCE-RECIPE.json').read_text());group=recipe['groups'][plan['group']]
assert plan['cases']==group['cases']and plan['caseCount']==group['caseCount']
assert plan['expectedTemporaryDirectories']==group['expectedTemporaryDirectories']and plan['expectedTemporaryDirectoriesPerCase']==group['expectedTemporaryDirectoriesPerCase']==2
assert not set(plan['cases'])&set(recipe['excludedInitialFour'])
initial_readiness,initial_pins=require_initial_four(plan['initialFourPrerequisite']['path'],plan['initialFourPrerequisite']['sha256'])
assert plan['qualifiedInitialFour']==initial_readiness and initial_readiness['firstFourQualified']is True and initial_readiness['remaining13Qualified']is False
assert plan['subjectOriginModules']==initial_readiness['subjectOrigins']
assert plan['initialFourRequiredOriginalRooms']==initial_readiness['requiredOriginalRoots']and plan['externalRootGuardMustIncludeInitialFourRooms']is True
assert all(plan['sourceAndBinaryPins'].get(name)==row for name,row in initial_pins.items())
assert plan['NodeExecutions']==plan['SDKExecutions']==plan['physicalNativeQueries']==plan['oldCorpusInputs']==plan['globalOriginalScans']==0
assert plan['declaredModelNativeObservationsAllowed']is True
assert plan['realNetwork']is False
assert plan['subjectHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
assert Path(plan['subjectActualCopiedPath'])==HERE/'closed_import_origins.py'
assert pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
assert head()==plan['actualPublicHead']
current_readiness,current_readiness_pins=qualification(pin)
assert current_readiness==plan['qualifiedSourceExecution']and current_readiness['currentHelperAlgorithmQualified']is True
assert current_readiness['consumerCompositionQualified']is False
assert plan['helperQualificationRequiredOriginalRooms']==current_readiness['requiredOriginalRoots']and len(current_readiness['requiredOriginalRoots'])==6
assert plan['externalRootGuardMustIncludeAllHelperOriginalRooms']is True
assert all(plan['sourceAndBinaryPins'].get(path)==row for path,row in current_readiness_pins.items())
assert len(plan['cases'])==len(set(plan['cases']))==plan['caseCount']and 1<=plan['caseCount']<=4 and plan['wallSeconds']==180 and plan['killGraceSeconds']==5
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def fds():
    out={}
    for path in Path('/proc/self/fd').iterdir():
        try:v=path.stat();out[path.name]=dict(target=os.readlink(path),device=v.st_dev,inode=v.st_ino,mode=v.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return out
def children():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
def census(root):
    out={}
    for path in(root,*sorted(root.rglob('*'))):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):row=dict(stat=[getattr(info,k)for k in FIELDS],namespace=sorted(p.name for p in path.iterdir()))
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        out[str(path.relative_to(root))]=row
    return out
assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
original_path=tuple(sys.path);original_meta=tuple(sys.meta_path);loaded={};td_callers=[]
bootstrap_names={'metadata_reader','host_common','closed_import_origins','source_execution_readiness','initial_four_admission'}
for name in(*plan['modules'],*plan['thirdPartyModules']):
    if name in bootstrap_names:
        actual=sys.modules[name]
        assert Path(vars(actual)['__file__'])==Path(plan['modules'][name]['path'])
        assert pin(Path(vars(actual)['__file__']))==plan['sourceAndBinaryPins'][vars(actual)['__file__']]
    else:assert name not in sys.modules
sys.path[:]=[p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespaces'],*plan['thirdPartyModules'])}
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright')
origin_plan=plan['originPlan']
assert origin_plan['physicalPins']==plan['sourceAndBinaryPins']and origin_plan['modules']==plan['modules']
origins=ClosedOrigins(origin_plan,HERE,REPO,pin)
origin_before=origins.snapshot('before-utility-project-imports')
class AfterActualLoader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name,self.delegate=name,delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module)
        path=Path(vars(module)['__file__']);loaded[self.name]=str(path)
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
        if self.name=='ios.self_tests.test_ios_snapshot_manifest':
            cls=vars(module)['SnapshotManifestTests'];setup=cls.__dict__['setUp']
            td_callers.append((cls,setup,setup.__code__,setup.__globals__))
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in forbidden:raise ImportError('Product SDK/browser package refused')
        row=plan['modules'].get(name)
        if row is not None:
            spec=origins.file_spec(name,dict(row,loader='source'),'project')
            spec.loader=AfterActualLoader(name,spec.loader);return spec
        if name in origin_plan['namespacePackages']:
            roots=origin_plan['namespacePackages'][name];origins.namespaces(name,roots,roots,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots;return spec
        if name in origin_plan['thirdPartyModules']or name in origin_plan['thirdPartyNamespacePackages']:return origins.remaining_spec(name,path)
        if name.split('.')[0]in tops:raise ImportError('Unmapped project/third-party import: '+name)
        return origins.remaining_spec(name,path)
finder=Finder();sys.meta_path.insert(0,finder)
TOYS=HERE/'own-toys';RECEIPTS=HERE/'child-receipts'
assert TOYS.is_dir()and RECEIPTS.is_dir()and not any(TOYS.iterdir())and not any(RECEIPTS.iterdir())
assert os.environ['TMPDIR']==str(TOYS)and Path(tempfile.gettempdir())==TOYS
from owned_write_boundary import OwnedWrites
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={n:getattr(os,n)for n in ports if hasattr(os,n)};original_io=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
original_cleanup=unittest.TestCase.doCleanups;original_td=tempfile.TemporaryDirectory;original_time=time.time
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):
    path=Path(os.readlink('/proc/self/fd/'+str(fd)));assert path.resolve(strict=True)==path and path.is_relative_to(HERE);protected.append(path)
boundary=OwnedWrites(HERE,protected=protected)
closed=False;tail_births={};tail_used=set()
def tail_write(path,value):
    assert closed and path in tail_births and path not in tail_used
    assert all(getattr(os,name)is original for name,original in original_ports.items())
    assert original_io==(io.open,builtins.open)and original_dup==(os.dup,os.dup2)
    assert pin(path)==tail_births[path]
    with original_io[0](path,'w',encoding='utf-8')as stream:
        json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    tail_used.add(path)
tail_function=tail_write;tail_code=tail_write.__code__;tail_globals=tail_write.__globals__
def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Product SDK/browser import refused')
    if event.startswith('socket.')or event in('subprocess.Popen','os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.kill','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('No real network/process/native/signal port in Source execution utilities')
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if not relevant:return
    if closed:
        if event=='open':
            value,mode,flags=args
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
            if not writing:return
            caller=sys._getframe(1);path=Path(value)if type(value)in(str,bytes)else None
            assert path in tail_births and path not in tail_used
            assert mode=='w'and flags==(os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC)
            assert caller.f_code is tail_code and caller.f_globals is tail_globals and caller.f_locals.get('path')==path
            assert tail_function is tail_write and tail_function.__code__ is tail_code and tail_function.__globals__ is tail_globals
            assert pin(path)==tail_births[path]
            assert all(getattr(os,name)is original for name,original in original_ports.items())and original_io==(io.open,builtins.open)
            return
        raise RuntimeError('Mutation after actual original port restoration')
    boundary.audit(event,args,sys._getframe(1))
boundary.install();sys.addaudithook(audit)
from ios.self_tests.retained_host_roots import retain_owned_root
retained=[];retained_objects=[];cleanup_calls=[]
class RetainedTemporaryDirectory(original_td):
    def __init__(self,*args,**kwargs):
        frame=sys._getframe(1)
        matches=[(cls,setup,code,namespace)for cls,setup,code,namespace in td_callers
            if frame.f_code is code and frame.f_globals is namespace and type(frame.f_locals.get('self'))is cls]
        assert len(matches)==1 and not args and not kwargs,'Only the actual SnapshotManifestTests.setUp default TD constructor'
        cls,setup,code,namespace=matches[0]
        assert cls.__dict__['setUp']is setup and setup.__code__ is code and setup.__globals__ is namespace
        super().__init__(dir=TOYS)
        root=Path(self.name);assert root.parent==TOYS and root.resolve(strict=True)==root
        retain_owned_root(self,expected_root=root);info=root.lstat();retained_objects.append(self)
        retained.append(dict(path=str(root),device=info.st_dev,inode=info.st_ino,
            actualConstructor=cls.__module__+'.'+cls.__qualname__,actualSetupFile=code.co_filename))
def observe_original_cleanup(case):
    before=len(case._cleanups);outcome=case._outcome
    success_before=None if outcome is None else outcome.success
    result_before=None if outcome is None else outcome.result
    errors_before=[]if result_before is None else list(result_before.errors)
    failures_before=[]if result_before is None else list(result_before.failures)
    returned=None;raised=None
    try:
        returned=original_cleanup(case)
        return returned
    except BaseException as error:
        raised=type(error).__module__+'.'+type(error).__qualname__
        raise
    finally:
        after_outcome=case._outcome
        after_result=None if after_outcome is None else after_outcome.result
        same_result=after_result is result_before
        new_errors=[]if not same_result or after_result is None else after_result.errors[len(errors_before):]
        new_failures=[]if not same_result or after_result is None else after_result.failures[len(failures_before):]
        cleanup_calls.append(dict(case=type(case).__module__+'.'+type(case).__qualname__,pendingBefore=before,
            remaining=len(case._cleanups),originalReturned=returned,originalRaised=raised,
            outcomeSuccessBefore=success_before,outcomeSuccessAfter=None if after_outcome is None else after_outcome.success,
            actualResultReceiverSame=same_result,
            newCallbackErrors=[dict(id=test.id(),traceback=text)for test,text in new_errors],
            newCallbackFailures=[dict(id=test.id(),traceback=text)for test,text in new_failures],
            callbackErrorDeltaEstablished=same_result and after_result is not None,
            failedReturnRemainsFailed=returned is not True))
unittest.TestCase.doCleanups=observe_original_cleanup;tempfile.TemporaryDirectory=RetainedTemporaryDirectory

def save(name,body):
    p=RECEIPTS/name
    with p.open('x')as stream:stream.write(json.dumps(body,indent=2,sort_keys=True)+'\n')
    p.chmod(0o600)
snapshot_failure_rows=[];snapshot_failure_receivers=[];snapshot_diagnostic_errors=[]
snapshot_function=ClosedOrigins.snapshot;snapshot_code=snapshot_function.__code__;snapshot_globals=snapshot_function.__globals__
execution_function=ClosedOrigins.execution_row;execution_code=execution_function.__code__;execution_globals=execution_function.__globals__
actual_path_type=type(HERE)
def actual_module_fields(module):
    if type(module)is not types.ModuleType:return dict(actualModuleType=type(module).__name__,objectIdentity=id(module),moduleFieldsUnavailable=True)
    namespace=vars(module)
    return dict(actualModuleType='module',objectIdentity=id(module),name=namespace.get('__name__'),file=namespace.get('__file__'))
def actual_path_field(value):
    if type(value)is str:return value
    if type(value)is actual_path_type:return str(value)
    return None

def diagnostic_snapshot(phase):
    try:return origins.snapshot(phase)
    except BaseException as error:
        try:
            assert ClosedOrigins.snapshot is snapshot_function and snapshot_function.__code__ is snapshot_code and snapshot_function.__globals__ is snapshot_globals
            assert ClosedOrigins.execution_row is execution_function and execution_function.__code__ is execution_code and execution_function.__globals__ is execution_globals
            # Read only genuine original traceback locals. No new Source,
            # disk hash, getter, native query, clock or successful verdict.
            trace=error.__traceback__;frames=[];snapshot_seen=False
            while trace is not None:
                frame=trace.tb_frame;assert type(frame)is types.FrameType
                if frame.f_code is snapshot_code and frame.f_globals is snapshot_globals and frame.f_locals.get('self')is origins:snapshot_seen=True
                if frame.f_code is execution_code and frame.f_globals is execution_globals and frame.f_locals.get('self')is origins:
                    local=frame.f_locals;name=local.get('name');module=local.get('module');original=local.get('original_module');actual=local.get('actual');path=local.get('path')
                    current=sys.modules.get(name)if type(name)is str else None
                    snapshot_failure_receivers.append((module,original,current))
                    frames.append(dict(name=name if type(name)is str else None,originalLine=trace.tb_lineno,originalBytecodeOffset=trace.tb_lasti,
                        currentReceiver=actual_module_fields(module),heldExecutionReceiver=actual_module_fields(original),currentSysModulesReceiver=actual_module_fields(current),
                        moduleIsHeldExecutionReceiver=module is original,sysModulesIsCurrentReceiver=current is module,
                        actualPathLocal=actual_path_field(actual),heldExecutionPathLocal=actual_path_field(path),
                        recordedSourceSHA=local.get('digest')if type(local.get('digest'))is str else None,
                        recordedSourceBytes=local.get('size')if type(local.get('size'))is int else None,
                        originalRecordLocalPresent='execution'in local,liveClockOrDiskHashRead=False))
                trace=trace.tb_next
            row=dict(phase=phase,actualSnapshotFrameBound=snapshot_seen,originalExceptionType='AssertionError'if type(error)is AssertionError else'unclassified-base-exception',
                originalExecutionRows=frames,helperFunctionBindingsActuallyChecked=True,diagnosticOnly=True,noAuthorityGranted=True,originalExceptionRethrown=True)
            snapshot_failure_rows.append(row);save('original-origin-refusal-'+str(len(snapshot_failure_rows))+'.json',row)
        except BaseException:
            # Diagnostic extraction/serialization/printing cannot replace the
            # original exception or qualify the failed Source operation.
            try:
                secondary=traceback.format_exc();snapshot_diagnostic_errors.append(secondary);print(secondary,flush=True)
            except BaseException:snapshot_diagnostic_errors.append('Original refusal diagnostic output also failed')
        raise

fd_before=fds();threads_before=tuple(threading.enumerate());children_before=children()
case_receipts=[];selected=[];result=None;fatal=None;cleanup_rows=[];cleanup_ok=True
class Result(unittest.TextTestResult):
    def startTest(self,test):
        assert original_methods_unchanged()and tools_unchanged()
        diagnostic_snapshot('before-standard-case-'+test.id())
        self.before=(fds(),tuple(threading.enumerate()),children(),len(cleanup_calls),len(retained));super().startTest(test)
    def stopTest(self,test):
        fd,threads,kernel,cleanup_count,roots=self.before
        diagnostic_snapshot('after-standard-case-'+test.id())
        row=dict(id=test.id(),standardStopAfterCleanup=True,originalMethodsUnchanged=original_methods_unchanged(),monitorSlotsUnchanged=tools_unchanged(),remainingStandardCleanups=len(test._cleanups),
            fdUnchanged=fds()==fd,threadsUnchanged=tuple(threading.enumerate())==threads,kernelChildrenUnchanged=children()==kernel,
            actualNestedCleanupCalls=deepcopy_rows(cleanup_calls[cleanup_count:]),newTemporaryDirectories=len(retained)-roots)
        case_receipts.append(row);save('standard-case-'+str(len(case_receipts))+'.json',row);super().stopTest(test)
def deepcopy_rows(rows):return json.loads(json.dumps(rows))
context_factory=contextlib.contextmanager;context_factory_code=context_factory.__code__
assert context_factory.__globals__ is vars(contextlib)
context_helpers=[value for value in context_factory_code.co_consts if type(value)is types.CodeType and value.co_name=='helper']
assert len(context_helpers)==1;context_helper_code=context_helpers[0]
context_manager=contextlib._GeneratorContextManager;context_base=contextlib._GeneratorContextManagerBase;context_mro=context_manager.__mro__
context_controls=[]
for owner,name in((context_base,'__init__'),(context_manager,'__enter__'),(context_manager,'__exit__')):
    function=owner.__dict__[name];assert type(function)is types.FunctionType and function.__globals__ is vars(contextlib)
    context_controls.append((owner,name,function,function.__code__,function.__globals__))
context_path=Path(vars(contextlib)['__file__'])
assert str(context_path)in plan['sourceAndBinaryPins']and pin(context_path)==plan['sourceAndBinaryPins'][str(context_path)]
method_seals=[]
WRAPPER_METHODS={('ios.adapters.snapshot_scene_witness', 'SnapshotSceneWitnessOwner', 'acquire'): 'operation', ('ios.adapters.snapshot_scene_review_join', 'SnapshotSceneReviewJoin', 'proof'): 'operation', ('ios.adapters.snapshot_scene_capture_order', 'SnapshotSceneCaptureOrder', 'acquire'): 'operation', ('ios.adapters.snapshot_scene_capture_order', 'SnapshotSceneCaptureOrder', 'proof'): 'operation', ('ios.adapters.snapshot_scene_pair_runtime', 'IOSSnapshotScenePairRuntime', 'scene_capture_order'): 'contextmanager', ('ios.adapters.snapshot_page_owner', 'IOSSnapshotPageOwner', 'open'): 'operation', ('ios.adapters.snapshot_page_owner', 'IOSSnapshotPageOwner', 'capture'): 'operation', ('ios.adapters.snapshot_page_owner', 'IOSSnapshotPageOwner', 'restore'): 'operation', ('ios.adapters.snapshot_capture_owner', 'IOSSnapshotCaptureOwner', 'provenance'): 'operation', ('ios.adapters.snapshot_capture_owner', 'IOSSnapshotCaptureOwner', 'capture'): 'operation', ('ios.adapters.snapshot_capture_owner', 'IOSSnapshotCaptureOwner', 'restore_name_before_destination'): 'operation', ('ios.adapters.snapshot_capture_owner', 'IOSSnapshotCaptureOwner', 'cleanup'): 'operation'}
operation_seal=None
def capture_control(function):
    assert type(function)is types.FunctionType
    code=function.__code__;namespace=function.__globals__;owner_name=namespace['__name__'];owner=sys.modules[owner_name]
    assert namespace is vars(owner)
    path=Path(code.co_filename);assert path.is_absolute()and str(path)in plan['sourceAndBinaryPins']and pin(path)==plan['sourceAndBinaryPins'][str(path)]
    defaults=function.__defaults__;keywords=function.__kwdefaults__;closure=function.__closure__
    return(function,code,namespace,owner_name,owner,getattr(function,'__wrapped__',None),defaults,tuple(defaults or()),keywords,tuple((keywords or{}).items()),closure,tuple(cell.cell_contents for cell in closure or()))

def control_unchanged(row):
    function,code,namespace,owner_name,owner,next_function,defaults,values,keywords,items,closure,cells=row
    assert function.__code__ is code and function.__globals__ is namespace and sys.modules.get(owner_name)is owner and namespace is vars(owner)
    assert getattr(function,'__wrapped__',None)is next_function and function.__defaults__ is defaults and function.__kwdefaults__ is keywords and function.__closure__ is closure
    assert len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values))
    assert tuple(keywords or())==tuple(key for key,value in items)and all(keywords[key]is value for key,value in items)
    assert len(closure or())==len(cells)and all(cell.cell_contents is value for cell,value in zip(closure or(),cells))

def bind_operation_controls():
    module=sys.modules['ios.adapters.snapshot_capture_clock'];namespace=vars(module)
    factory=namespace['operation'];budget=namespace['Budget'];current=namespace['_CURRENT']
    transport=sys.modules['adapters.operation_transport_guard'];transport_namespace=vars(transport)
    scope=transport_namespace['scope'];scope_target=scope.__wrapped__;transport_current=transport_namespace['_CURRENT']
    assert namespace['scope']is scope and namespace['wraps']is sys.modules['functools'].wraps
    factory_row=capture_control(factory);assert factory_row[2]is namespace and factory.__closure__ is None
    helpers=[value for value in factory.__code__.co_consts if type(value)is types.CodeType and value.co_name=='wrapped']
    assert len(helpers)==1 and helpers[0].co_freevars==('function',)
    assert scope.__code__ is context_helper_code and scope.__globals__ is vars(contextlib)
    assert scope.__code__.co_freevars==('func',)and scope.__closure__ is not None and len(scope.__closure__)==1 and scope.__closure__[0].cell_contents is scope_target
    assert scope_target.__globals__ is transport_namespace and scope_target.__code__.co_flags&0x20
    context_type=sys.modules['contextvars'].ContextVar
    assert type(current)is context_type and type(transport_current)is context_type and namespace['ContextVar']is context_type and transport_namespace['ContextVar']is context_type
    math_module=namespace['math'];finite=math_module.isfinite;error=namespace['NativeUIError']
    assert sys.modules['math']is math_module and type(finite)is types.BuiltinFunctionType and finite.__self__ is math_module
    assert transport_namespace['NativeUIError']is error and sys.modules['adapters.normal_ui'].NativeUIError is error
    check=transport_namespace['check'];controls=(factory,budget.__dict__['__init__'],budget.__dict__['check'],scope,scope_target,check)
    rows=tuple(capture_control(function)for function in controls)
    assert rows[1][2]is namespace and rows[2][2]is namespace and rows[5][2]is transport_namespace
    return(module,factory,helpers[0],budget,current,transport,scope,scope_target,transport_current,context_type,math_module,finite,error,check,namespace['wraps'],rows)

def operation_controls_unchanged():
    assert operation_seal is not None
    module,factory,helper_code,budget,current,transport,scope,scope_target,transport_current,context_type,math_module,finite,error,check,wraps,rows=operation_seal
    assert sys.modules.get('ios.adapters.snapshot_capture_clock')is module and sys.modules.get('adapters.operation_transport_guard')is transport
    namespace=vars(module);transport_namespace=vars(transport)
    assert namespace['operation']is factory and namespace['Budget']is budget and namespace['_CURRENT']is current and namespace['scope']is scope
    assert namespace['math']is math_module and math_module.isfinite is finite and sys.modules.get('math')is math_module
    assert namespace['NativeUIError']is error and transport_namespace['NativeUIError']is error and sys.modules['adapters.normal_ui'].NativeUIError is error
    assert namespace['wraps']is wraps and sys.modules['functools'].wraps is wraps
    assert transport_namespace['scope']is scope and transport_namespace['check']is check and transport_namespace['_CURRENT']is transport_current
    assert namespace['ContextVar']is context_type and transport_namespace['ContextVar']is context_type and sys.modules['contextvars'].ContextVar is context_type
    assert type(current)is context_type and type(transport_current)is context_type
    assert budget.__dict__['__init__']is rows[1][0]and budget.__dict__['check']is rows[2][0]
    for row in rows:control_unchanged(row)
    return module,helper_code

def bind_original_methods():
    global operation_seal
    operation_seal=bind_operation_controls()
    declarations=(
        ('closed_import_origins','ClosedOrigins',('execute_python_source','snapshot','execution_row')),
        ('closed_import_origins','PinnedDelegate',('create_module','exec_module')),
        ('ios.self_tests.test_ios_snapshot_manifest','SnapshotManifestTests',('setUp',)),
        ('ios.adapters.snapshot_scene_witness','SnapshotSceneWitnessOwner',('acquire','original','validate_original')),
        ('ios.adapters.snapshot_scene_review_join','SnapshotSceneReviewJoin',('proof',)),
        ('ios.adapters.snapshot_owned_packet','SnapshotOwnedPacket',('send','retain','historical')),
        ('ios.adapters.snapshot_scene_capture_order','SnapshotSceneActorSet',('owner','native_floor')),
        ('ios.adapters.snapshot_scene_capture_order','SnapshotSceneCaptureOrder',('acquire','proof','decode')),
        ('ios.adapters.snapshot_scene_pair_runtime','IOSSnapshotScenePairRuntime',('scene_capture_order',)),
        ('ios.adapters.snapshot_page_owner','IOSSnapshotPageOwner',('capture','open','observe')),
        ('ios.adapters.snapshot_capture_owner','IOSSnapshotCaptureOwner',('capture','input','provenance')),
        ('ios.self_tests.test_ios_snapshot_scene_review_join','SnapshotSceneReviewJoinTests',()),
        ('ios.self_tests.test_ios_snapshot_scene_capture_order','SnapshotSceneCaptureOrderTests',()))
    for module_name,class_name,names in declarations:
        module=sys.modules[module_name];cls=vars(module)[class_name]
        path=Path(vars(module)['__file__']);assert str(path)in plan['sourceAndBinaryPins']and pin(path)==plan['sourceAndBinaryPins'][str(path)]
        # Pin the full actual class-method table, including static control/
        # selector helpers transitively called by the explicit recipe methods.
        for name,member in cls.__dict__.items():
            function=member.__func__ if type(member)in(classmethod,staticmethod)else member
            if hasattr(function,'__code__'):
                chain=[];seen=set()
                while function is not None:
                    assert type(function)is types.FunctionType and id(function)not in seen;seen.add(id(function))
                    code=function.__code__;namespace=function.__globals__;owner_name=namespace['__name__'];owner=sys.modules[owner_name]
                    assert namespace is vars(owner)
                    physical=Path(code.co_filename)
                    if not physical.is_absolute():
                        actual_spec=vars(owner)['__spec__']
                        assert actual_spec.origin=='frozen'and actual_spec.loader is importlib.machinery.FrozenImporter and code.co_filename=='<frozen '+owner_name+'>'
                        physical=Path(vars(owner)['__file__'])
                    assert str(physical)in plan['sourceAndBinaryPins']and pin(physical)==plan['sourceAndBinaryPins'][str(physical)]
                    next_function=getattr(function,'__wrapped__',None);defaults=function.__defaults__;keywords=function.__kwdefaults__;closure=function.__closure__
                    profile=WRAPPER_METHODS.get((module_name,class_name,name))
                    if owner is not module:
                        assert next_function is not None and type(next_function)is types.FunctionType and next_function.__globals__ is vars(module)
                        if profile=='contextmanager':
                            assert owner is contextlib and code is context_helper_code and vars(module)['contextmanager']is context_factory
                            assert code.co_freevars==('func',)and closure is not None and len(closure)==1 and closure[0].cell_contents is next_function
                            assert next_function.__code__.co_flags&0x20
                        elif profile=='operation':
                            operation_module,operation_helper=operation_controls_unchanged()
                            assert owner is operation_module and code is operation_helper and vars(module)['operation']is operation_seal[1]
                            assert code.co_freevars==('function',)and closure is not None and len(closure)==1 and closure[0].cell_contents is next_function
                        else:raise AssertionError('Undeclared cross-module method wrapper')
                    else:assert next_function is None
                    chain.append((function,code,namespace,owner_name,owner,next_function,defaults,tuple(defaults or()),keywords,tuple((keywords or{}).items()),closure,tuple(cell.cell_contents for cell in closure or())))
                    function=next_function
                assert len(chain)==(2 if (module_name,class_name,name)in WRAPPER_METHODS else 1)
                method_seals.append((module,module_name,cls,class_name,name,member,chain))
def original_methods_unchanged():
    operation_controls_unchanged()
    assert sys.modules.get('contextlib')is contextlib and contextlib.contextmanager is context_factory
    assert context_factory.__code__ is context_factory_code and context_factory.__globals__ is vars(contextlib)
    assert contextlib._GeneratorContextManager is context_manager and contextlib._GeneratorContextManagerBase is context_base
    assert context_factory.__globals__['_GeneratorContextManager']is context_manager and context_manager.__mro__ is context_mro
    for owner,name,function,code,namespace in context_controls:
        assert owner.__dict__[name]is function and function.__code__ is code and function.__globals__ is namespace and namespace is vars(contextlib)
    for module,module_name,cls,class_name,name,member,chain in method_seals:
        assert sys.modules.get(module_name)is module and vars(module)[class_name]is cls and cls.__dict__[name]is member
        for function,code,namespace,owner_name,owner,next_function,defaults,values,keywords,items,closure,cells in chain:
            assert function.__code__ is code and function.__globals__ is namespace and sys.modules.get(owner_name)is owner and namespace is vars(owner)
            assert getattr(function,'__wrapped__',None)is next_function and function.__defaults__ is defaults and function.__kwdefaults__ is keywords and function.__closure__ is closure
            assert len(defaults or())==len(values)and all(a is b for a,b in zip(defaults or(),values))
            assert tuple(keywords or())==tuple(key for key,value in items)and all(keywords[key]is value for key,value in items)
            assert len(closure or())==len(cells)and all(cell.cell_contents is value for cell,value in zip(closure or(),cells))
    return True
monitor=sys.monitoring
monitor_ports=tuple((name,getattr(monitor,name))for name in('get_tool','get_events','get_local_events','set_local_events','register_callback','use_tool_id','free_tool_id'))
monitor_before=tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6))
def tools_unchanged():
    return (all(getattr(monitor,name)is port for name,port in monitor_ports)
        and monitor_before==tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6)))

original_term=signal.getsignal(signal.SIGTERM)
def interrupted(*_args):raise KeyboardInterrupt('Fixed180-second finite Snapshot Scene group host boundary')
signal.signal(signal.SIGTERM,interrupted)
try:
    # Real definitions of both subject tables must be present for the full
    # unchanged B6 operation/contextlib/source controls. No model/owner/TD
    # constructor is invoked by importing these actual declared definitions.
    for name in ('ios.self_tests.test_ios_snapshot_scene_review_join','ios.self_tests.test_ios_snapshot_scene_capture_order'):
        importlib.import_module(name)
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(suite):
        if isinstance(suite,unittest.TestSuite):
            for item in suite:yield from flatten(item)
        else:yield suite
    selected=list(flatten(suite));ids=[case.id()for case in selected]
    save('actual-selection.json',dict(ids=ids,loaderErrors=loader.errors));assert not loader.errors and ids==plan['cases']and suite.countTestCases()==plan['caseCount']
    bind_original_methods();assert original_methods_unchanged()and tools_unchanged()
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    try:
        for case in selected:
            pending=len(case._cleanups);old=case._outcome;drain=unittest.TestResult();success=True
            try:
                if pending:case._outcome=unittest.case._Outcome(drain);success=observe_original_cleanup(case)
            except BaseException:success=False;print(traceback.format_exc(),flush=True)
            finally:case._outcome=old
            row=dict(id=case.id(),pendingBeforeOuter=pending,remaining=len(case._cleanups),success=success,
                errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],failures=[dict(id=t.id(),traceback=text)for t,text in drain.failures]);cleanup_rows.append(row)
            if not success or case._cleanups or drain.errors or drain.failures:cleanup_ok=False
        for row in retained:
            root=Path(row['path']);info=root.lstat();assert root.parent==TOYS and(root.stat().st_dev,root.stat().st_ino)==(row['device'],row['inode'])
        nested_ok=all(row['originalReturned']is True and row['remaining']==0 for row in cleanup_calls)
        first=census(TOYS);second=census(TOYS)
        after={p:pin(p)for p in plan['sourceAndBinaryPins']}
        assert head()==plan['actualPublicHead']and pin(INPUT)['sha256']==sys.argv[2]
        origin_after=diagnostic_snapshot('after-genuine-original-cleanups')
        passed=fatal is None and result is not None and result.testsRun==plan['caseCount'] and result.wasSuccessful()and not result.skipped and cleanup_ok and nested_ok
        passed=passed and len(retained)==plan['expectedTemporaryDirectories']and len(case_receipts)==plan['caseCount'] and all(row['remainingStandardCleanups']==0 and row['fdUnchanged']and row['threadsUnchanged']and row['kernelChildrenUnchanged']and row['newTemporaryDirectories']==plan['expectedTemporaryDirectoriesPerCase'] and row['originalMethodsUnchanged']and row['monitorSlotsUnchanged']for row in case_receipts)
        passed=passed and after==plan['sourceAndBinaryPins']and fd_before==fds()and threads_before==tuple(threading.enumerate())and children_before==children()and first==second
        source_origins={}
        for name,expected in plan['subjectOriginModules'].items():
            module=sys.modules.get(name);actual=None if module is None else getattr(module,'__file__',None)
            source_origins[name]=dict(actualModulePresent=module is not None,actualModuleFile=actual,
                actualLoaderExecutedPath=loaded.get(name),expectedPath=expected['path'],expectedSha256=expected['sha256'],
                exactOriginMatched=actual==loaded.get(name)==expected['path'])
        origins_ok=len(source_origins)==plan['subjectOriginCount']==15 and all(row['exactOriginMatched']for row in source_origins.values())
        passed=passed and origins_ok and len(td_callers)==1 and original_methods_unchanged()and tools_unchanged()
        save('actual-all-loaded-origins-before.json',origin_before);save('actual-all-loaded-origins-after.json',origin_after)
        save('actual-source-model-origins.json',dict(subjectOrigins=source_origins,
            allFifteenActualRuntimeOriginsEstablished=origins_ok,actualExecutedOrigins=loaded))
        save('actual-toy-first.json',first);save('actual-toy-second.json',second);save('outer-cleanup.json',dict(success=cleanup_ok,cases=cleanup_rows,nestedActualCalls=cleanup_calls,nestedActualCleanupSucceeded=nested_ok))
        save('report.json',dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=None if result is None else result.testsRun,
            actualCaseReceipts=len(case_receipts),group=plan['group'],expectedCaseCount=plan['caseCount'],fatal=fatal,cleanupEstablished=cleanup_ok and nested_ok,
            retainedTemporaryDirectories=retained,temporaryDirectoryAbsenceClaimed=False,fdUnchanged=fd_before==fds(),
            threadsUnchanged=threads_before==tuple(threading.enumerate()),kernelChildrenUnchanged=children_before==children(),
            pinsUnchanged=after==plan['sourceAndBinaryPins'],twoToyCensusesEqual=first==second,allActualLoadedOriginsAccounted=True,originSnapshots=origins.snapshot_count,
            declaredModelNativeObservationsAllowed=True,physicalNativeQueries=0,nativeCompiled=False,actualStdlibInterpreterExtensionsAllowed=True,realNetwork=False,NodeExecutions=0,SDKExecutions=0,nativeQualified=False,wholeQualified=False))
    finally:
        signal.signal(signal.SIGTERM,original_term)
        tempfile.TemporaryDirectory=original_td;unittest.TestCase.doCleanups=original_cleanup
        tools_restored=tempfile.TemporaryDirectory is original_td and unittest.TestCase.doCleanups is original_cleanup and time.time is original_time and tools_unchanged()
        tail=RECEIPTS/'actual-port-restoration.json'
        descriptor=os.open(tail,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        try:assert stat.S_IMODE(os.fstat(descriptor).st_mode)==0o600
        finally:os.close(descriptor)
        tail_births[tail]=pin(tail)
        boundary.restore()
        restored=all(getattr(os,n)is v for n,v in original_ports.items())and original_io==(io.open,builtins.open)
        dup_restored=original_dup==(os.dup,os.dup2)
        boundary.close();closed=True
        sys.meta_path[:]=original_meta;sys.path[:]=original_path
        tail_write(RECEIPTS/'actual-port-restoration.json',dict(restored=restored,count=len(original_ports),
            controlDescriptors=sorted(boundary.control_fds),dupPortsRestored=dup_restored,toolsRestored=tools_restored,
            builtinsCioRestored=original_io==(io.open,builtins.open),actualC10dHelperSha256=pin(Path(__file__).with_name('closed_import_origins.py'))['sha256']))
raise SystemExit(0 if passed and restored and tools_restored and dup_restored else 1)
