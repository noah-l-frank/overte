// Copyright 2026 Overte contributors.
// SPDX-License-Identifier: Apache-2.0
#pragma once
#include <QtGlobal>

#if defined(Q_OS_IOS) && defined(OVERTE_IOS_E2E_TEST_BUILD) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
#include <memory>
#include <functional>
#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDateTime>
#include <QElapsedTimer>
#include <QHash>
#include <QMutex>
#include <QMutexLocker>
#include <QPointer>
#include <QRegularExpression>
#include <QThread>
#include <QUrl>
#include <QVariantList>
#include <QVariantMap>
#include "AudioInjector.h"
#include "ScriptAudioInjector.h"

namespace overte::e2e {
// This owner neither captures nor changes the ordinary audio graph. It fences
// one controlled cue URL at the original Audio.playSound input boundary and
// observes actual injector/data/QObject lifetimes. Tombstones survive Script
// reloads; a changed process/feature instance cannot adopt an old claim.
class IOSAudioOnceCue {
public:
    struct Claim {
        QString instance,run,ticket,cue,url,kind;
        QVariantMap caller,playCaller;std::function<bool()> admission;
        bool consumed {false},birth {false},wrapperBorn {false},complete {true},managerReturned {false},returnedNull {false};
        bool resourceRequested {false},resourceWrapperBorn {false},resourceWrapperDestroyed {false},resourceReady {false},retireAttempted {false};
        quint64 resourceReadyCallbacks {0},resourceDestroyCallbacks {0};
        QWeakPointer<Sound> resource;QPointer<SoundScriptingInterface> resourceWrapper;
        std::weak_ptr<const AudioData> resourceData;QMetaObject::Connection readyConnection,resourceConnection;
        bool finished {false},injectorDestroyed {false},wrapperDestroyed {false},released {false};
        quint64 finishedCallbacks {0},destroyCallbacks {0},wrapperDestroyCallbacks {0};
        qint64 claimedEpoch {0},consumedEpoch {0},bornEpoch {0},finishedEpoch {0},destroyedEpoch {0};
        QByteArray pcmSha;quint64 pcmBytes {0},pcmFrames {0};int pcmChannels {0};
        QWeakPointer<AudioInjector> injector;
        std::weak_ptr<const AudioData> data;
        QPointer<ScriptAudioInjector> wrapper;
        QMetaObject::Connection finishedConnection,destroyedConnection,wrapperConnection;
    };
    enum class Decision { Unrelated,Refuse,Allow };
    struct Input { Decision decision {Decision::Unrelated};std::shared_ptr<Claim> claim; };
    static IOSAudioOnceCue& instance() { static IOSAudioOnceCue value;return value; }
    QVariantMap request(const QString& instance,const QVariantMap& command,const QVariantMap& caller,std::function<bool()> admission) {
        const auto requested=QDateTime::currentMSecsSinceEpoch();QMutexLocker held(&_mutex);
        if (QThread::currentThread()!=QCoreApplication::instance()->thread() || !hex(instance) || !callerValid(caller,"featureIOSAudioOnceCue")) { return {}; }
        const auto operation=command.value("operation").toString();
        QStringList keys {"schemaVersion","commandId","action","operation","instance","runId","ticket","cueId","kind"};
        if (operation=="claim") { keys.append("soundUrl"); }
        keys.sort();auto actual=command.keys();actual.sort();
        for (const auto& key:keys) { if (key!="schemaVersion" && command.value(key).type()!=QVariant::String) { return {}; } }
        if (command.value("schemaVersion").type()==QVariant::Bool || command.value("schemaVersion").type()==QVariant::String) { return {}; }
        if (actual!=keys || command.value("schemaVersion")!=1 || command.value("action")!="feature-ios-audio-once-cue"
                || command.value("instance")!=instance || !commandId(command.value("commandId").toString())
                || !hex(command.value("runId").toString()) || !hex(command.value("ticket").toString())
                || !hex(command.value("cueId").toString()) || (command.value("kind")!="cue" && command.value("kind")!="pattern") || (operation!="claim" && operation!="observe" && operation!="retire" && operation!="release")) { return {}; }
        const auto cue=command.value("cueId").toString();auto found=_claims.find(cue);
        if (operation=="claim") {
            if (!admission || !admission()) { return {}; }
            const auto url=command.value("soundUrl").toString();
            const auto identity=QCryptographicHash::hash(("ios-audio-once-"+command.value("kind").toString()+"-v1:"+command.value("runId").toString()+":"+command.value("ticket").toString()).toLatin1(),QCryptographicHash::Sha256).toHex().left(32);
            if (cue!=QString::fromLatin1(identity)) { return {}; }
            if (command.value("commandId").toString()!="ios-"+cue || !controlledUrl(url,command.value("runId").toString(),command.value("ticket").toString(),cue,command.value("kind").toString())) { return {}; }
            if (found==_claims.end()) {
                if (_claims.size()>=64 || _urls.contains(url)) { return {}; }
                auto c=std::make_shared<Claim>();c->instance=instance;c->run=command.value("runId").toString();
                c->ticket=command.value("ticket").toString();c->kind=command.value("kind").toString();c->cue=cue;c->url=url;c->caller=caller;c->admission=std::move(admission);c->claimedEpoch=QDateTime::currentMSecsSinceEpoch();
                _claims.insert(cue,c);_urls.insert(url,cue);found=_claims.find(cue);
            }
        }
        if (found==_claims.end()) { return {}; }
        const auto c=found.value();
        if (c->instance!=instance || c->run!=command.value("runId") || c->ticket!=command.value("ticket") || c->kind!=command.value("kind")
                || (operation=="claim" && (c->url!=command.value("soundUrl") || !sameProducer(c->caller,caller)))) { return {}; }
        if (operation=="retire") {
            // The probe first disconnects its own ready/finished callbacks.
            // Retire is explicit once-only task-owned QObject cleanup input;
            // only a later actual destroyed observation can admit absence.
            if (c->consumed && (!c->managerReturned || (c->birth && (!c->injectorDestroyed || !c->injector.isNull())))) { return {}; }
            if (c->resourceWrapper && c->resourceWrapper->featureReadyReceiverCount()>1) { return {}; }
            if (c->wrapper && c->wrapper->featureFinishedReceiverCount()!=0) { return {}; }
            if (!c->retireAttempted) {
                c->retireAttempted=true;
                QObject::disconnect(c->readyConnection);
                if (c->resourceWrapper) { c->resourceWrapper->deleteLater(); }
                if (c->wrapper) { c->wrapper->deleteLater(); }
            }
        }
        if (operation=="release") {
            // A claim is never cleared/rearmed. Release proves only the actual
            // injector/wrapper/callback objects are gone; cached Sound PCM is
            // separately disclosed and may remain held by SoundCache.
            if (!c->retireAttempted || (c->resourceWrapperBorn && (!c->resourceWrapperDestroyed || c->resourceWrapper))) { return {}; }
            const bool noWrapper=c->managerReturned && c->returnedNull && !c->wrapperBorn && c->wrapper.isNull();
            if (c->consumed && (!c->managerReturned || (c->birth && (!c->injectorDestroyed || !c->injector.isNull()))
                    || (!c->birth && !c->returnedNull) || (!noWrapper && (!c->wrapperBorn || !c->wrapperDestroyed || c->wrapper)))) { return {}; }
            if (!c->released) {
                QObject::disconnect(c->finishedConnection);QObject::disconnect(c->destroyedConnection);QObject::disconnect(c->wrapperConnection);QObject::disconnect(c->readyConnection);QObject::disconnect(c->resourceConnection);
                c->released=true;
            }
        }
        if (_sequence>=1000000000) { return {}; }
        auto value=reply(c,command.value("commandId").toString(),operation);
        value.insert("sequence",static_cast<qulonglong>(++_sequence));value.insert("requestedEpochMs",requested);
        value.insert("capturedEpochMs",QDateTime::currentMSecsSinceEpoch());value.insert("processId",QCoreApplication::applicationPid());
        value.insert("queryCaller",caller);return value;
    }
    bool resourceRequest(const QString& url,const QVariantMap& caller) {
        QMutexLocker held(&_mutex);const auto known=_urls.find(url);
        if (known==_urls.end()) { return !reservedUrl(url); }
        const auto c=_claims.value(known.value());
        if (!c || c->resourceRequested || c->released || c->retireAttempted || !c->admission || !c->admission()
                || !callerValid(caller,"getSound") || !sameProducer(c->caller,caller)) { return false; }
        c->resourceRequested=true;return true;
    }
    void resourceBorn(const SharedSoundPointer& resource,SoundScriptingInterface* wrapper,const QVariantMap& caller) {
        if (!resource || !wrapper) { return; }QMutexLocker held(&_mutex);
        const auto key=_urls.find(resource->getURL().toString(QUrl::FullyEncoded));if (key==_urls.end()) { return; }
        const auto c=_claims.value(key.value());
        if (!c || !c->resourceRequested || c->resourceWrapperBorn || c->released || c->retireAttempted
                || !callerValid(caller,"getSound") || !sameProducer(c->caller,caller)) { if (c) { c->complete=false; }return; }
        c->resourceWrapperBorn=true;c->resource=resource.toWeakRef();c->resourceWrapper=wrapper;const std::weak_ptr<Claim> weak=c;
        if (wrapper->isReady()) { resourceReady(c,wrapper); }
        c->readyConnection=QObject::connect(wrapper,&SoundScriptingInterface::ready,wrapper,[weak,wrapper] {
            const auto c=weak.lock();if (!c) { return; }auto& owner=instance();QMutexLocker held(&owner._mutex);
            ++c->resourceReadyCallbacks;if (c->retireAttempted || c->resourceWrapperDestroyed) { c->complete=false; }
            owner.resourceReady(c,wrapper);
        },Qt::DirectConnection);
        c->resourceConnection=QObject::connect(wrapper,&QObject::destroyed,[weak] {
            const auto c=weak.lock();if (!c) { return; }auto& owner=instance();QMutexLocker held(&owner._mutex);
            if (++c->resourceDestroyCallbacks!=1) { c->complete=false; }c->resourceWrapperDestroyed=true;
        });
        if (!c->readyConnection || !c->resourceConnection) { c->complete=false; }
    }
    Input consume(const SharedSoundPointer& sound,const AudioInjectorOptions& options,const QVariantMap& caller) {
        if (!sound) { return {}; }
        const auto url=sound->getURL().toString(QUrl::FullyEncoded);QMutexLocker held(&_mutex);
        const auto known=_urls.find(url);
        if (known==_urls.end()) {
            // Only the reserved cue path is fenced. Other ordinary sounds do
            // not consult test claims or change their behavior.
            return {reservedUrl(url)?Decision::Refuse:Decision::Unrelated,{}};
        }
        const auto c=_claims.value(known.value());
        if (!c || c->released || c->retireAttempted || c->consumed || !c->complete
                || !c->resourceRequested || !c->resourceWrapperBorn || !c->resourceReady || !c->resourceWrapper
                || c->resource.toStrongRef()!=sound || c->resourceWrapper->getSound()!=sound || !c->admission || !c->admission() || !sound->isReady()
                || !callerValid(caller,"playSound") || !sameProducer(c->caller,caller)
                || caller.value("sequence").toULongLong()<=c->caller.value("sequence").toULongLong()
                || caller.value("invokedEpochMs").toLongLong()<c->claimedEpoch
                || !options.localOnly || options.loop || options.pitch!=1.0f || options.secondOffset!=0.0f
                || options.volume!=0.1f || options.ambisonic || options.stereo) { return {Decision::Refuse,{}}; }
        // Consume BEFORE manager.playSound. A failed/lost return never permits
        // another input, including after the JavaScript probe is reloaded.
        c->consumed=true;c->playCaller=caller;c->consumedEpoch=QDateTime::currentMSecsSinceEpoch();return {Decision::Allow,c};
    }
    class InjectionScope {
    public:
        explicit InjectionScope(std::shared_ptr<Claim> claim) : _previous(active()) { active()=std::move(claim); }
        ~InjectionScope() { active()=_previous; }
        InjectionScope(const InjectionScope&)=delete;InjectionScope& operator=(const InjectionScope&)=delete;
    private:std::shared_ptr<Claim> _previous;
    };
    bool injectorBorn(const AudioInjectorPointer& injector) {
        const auto c=active();if (!c) { return true; }QMutexLocker held(&_mutex);
        if (!c->consumed || c->birth || c->released || !injector) { c->complete=false;return false; }
        const auto data=injector->featureImmutableAudioData();
        const bool validData=data && data->getNumChannels()==1 && data->getNumFrames()>0 && data->getNumBytes()<=1024*1024;
        injector->featureClaimOnceCue();c->birth=true;c->injector=injector.toWeakRef();c->data=data;
        if (validData) {
            c->pcmChannels=data->getNumChannels();c->pcmBytes=data->getNumBytes();c->pcmFrames=data->getNumFrames();
            c->pcmSha=QCryptographicHash::hash(QByteArray(data->rawData(),data->getNumBytes()),QCryptographicHash::Sha256);
        } else { c->complete=false; }
        c->bornEpoch=QDateTime::currentMSecsSinceEpoch();const std::weak_ptr<Claim> weak=c;
        c->finishedConnection=QObject::connect(injector.data(),&AudioInjector::finished,injector.data(),[weak] {
            const auto c=weak.lock();if (!c) { return; }auto& owner=instance();QMutexLocker held(&owner._mutex);
            if (++c->finishedCallbacks!=1 || c->injectorDestroyed) { c->complete=false; }c->finished=true;c->finishedEpoch=QDateTime::currentMSecsSinceEpoch();
        },Qt::DirectConnection);
        c->destroyedConnection=QObject::connect(injector.data(),&QObject::destroyed,[weak] {
            const auto c=weak.lock();if (!c) { return; }auto& owner=instance();QMutexLocker held(&owner._mutex);
            if (++c->destroyCallbacks!=1) { c->complete=false; }c->injectorDestroyed=true;c->destroyedEpoch=QDateTime::currentMSecsSinceEpoch();
        });
        if (!c->finishedConnection || !c->destroyedConnection) { c->complete=false; }
        return validData && c->complete;
    }
    void managerReturned(const AudioInjectorPointer& injector) {
        const auto c=active();if (!c) { return; }QMutexLocker held(&_mutex);
        if (c->managerReturned || (injector && (!c->birth || c->injector.toStrongRef()!=injector))) { c->complete=false; }
        c->managerReturned=true;c->returnedNull=!injector;
    }
    void wrapperBorn(ScriptAudioInjector* wrapper) {
        const auto c=active();if (!c) { return; }QMutexLocker held(&_mutex);
        if (!c->birth || c->wrapperBorn || !wrapper) { c->complete=false;return; }
        c->wrapperBorn=true;c->wrapper=wrapper;const std::weak_ptr<Claim> weak=c;
        c->wrapperConnection=QObject::connect(wrapper,&QObject::destroyed,[weak] {
            const auto c=weak.lock();if (!c) { return; }auto& owner=instance();QMutexLocker held(&owner._mutex);
            if (++c->wrapperDestroyCallbacks!=1) { c->complete=false; }c->wrapperDestroyed=true;
        });
        if (!c->wrapperConnection) { c->complete=false; }
    }
private:
    void resourceReady(const std::shared_ptr<Claim>& c,SoundScriptingInterface* wrapper) {
        if (!wrapper || QThread::currentThread()!=wrapper->thread() || !wrapper->isReady() || !wrapper->getSound()) { c->complete=false;return; }
        c->resourceReady=true;c->resourceData=wrapper->getSound()->getAudioData();
    }
    static std::shared_ptr<Claim>& active() { static thread_local std::shared_ptr<Claim> claim;return claim; }
    static bool hex(const QString& value) { return value.size()==32 && QRegularExpression("^[0-9a-f]{32}$").match(value).hasMatch(); }
    static bool commandId(const QString& value) { return value.startsWith("ios-") && value.size()==36 && hex(value.mid(4)); }
    static bool callerValid(const QVariantMap& caller,const QString& method) {
        return caller.value("callerVersion")==1 && caller.value("method")==method && caller.value("sequence").toULongLong()>0
            && caller.value("invokedEpochMs").toLongLong()>0 && caller.value("manager").toMap().value("assigned").toBool()
            && caller.value("code").toMap().value("submitted").toBool();
    }
    static bool sameProducer(const QVariantMap& first,const QVariantMap& second) { return first.value("manager")==second.value("manager") && first.value("code")==second.value("code"); }
    static bool reservedUrl(const QString& value) {
        const QUrl url(value,QUrl::StrictMode);
        return url.isValid() && (url.scheme()=="https" || url.scheme()=="http") && url.userInfo().isEmpty()
            && !url.hasQuery() && !url.hasFragment() && url.toString(QUrl::FullyEncoded)==value
            && QRegularExpression("^/feature-fixture/v1/runs/[0-9a-f]{32}/tickets/[0-9a-f]{32}/audio-once-(cue|pattern)/[0-9a-f]{32}\\.wav$").match(url.path()).hasMatch();
    }
    static bool controlledUrl(const QString& value,const QString& run,const QString& ticket,const QString& cue,const QString& kind) {
        const QUrl url(value,QUrl::StrictMode);
        return url.isValid() && (url.scheme()=="https" || url.scheme()=="http") && !url.host().isEmpty()
            && url.userInfo().isEmpty() && !url.hasQuery() && !url.hasFragment()
            && url.toString(QUrl::FullyEncoded)==value && url.path()=="/feature-fixture/v1/runs/"+run+"/tickets/"+ticket+"/audio-once-"+kind+"/"+cue+".wav";
    }
    QVariantMap reply(const std::shared_ptr<Claim>& c,const QString& command,const QString& operation) const {
        const auto strong=c->injector.toStrongRef();
        return {{"iosAudioOnceCueVersion",1},{"commandId",command},{"operation",operation},{"instance",c->instance},
            {"runId",c->run},{"ticket",c->ticket},{"cueId",c->cue},{"kind",c->kind},{"soundUrl",c->url},{"complete",c->complete},
            {"claimedEpochMs",c->claimedEpoch},{"consumedEpochMs",c->consumedEpoch},{"bornEpochMs",c->bornEpoch},
            {"finishedEpochMs",c->finishedEpoch},{"destroyedEpochMs",c->destroyedEpoch},{"caller",c->caller},{"playCaller",c->playCaller},
            {"consumed",c->consumed},{"managerReturned",c->managerReturned},{"returnedNull",c->returnedNull},{"injectorBorn",c->birth},{"wrapperBorn",c->wrapperBorn},{"finished",c->finished},
            {"injectorDestroyed",c->injectorDestroyed},{"wrapperDestroyed",c->wrapperDestroyed},{"released",c->released},
            {"finishedCallbacks",c->finishedCallbacks},{"destroyCallbacks",c->destroyCallbacks},{"wrapperDestroyCallbacks",c->wrapperDestroyCallbacks},
            {"injectorLive",bool(strong)},{"playing",strong?strong->isPlaying():false},{"wrapperLive",!c->wrapper.isNull()},
            {"scriptFinishedReceivers",c->wrapper?c->wrapper->featureFinishedReceiverCount():0},
            {"pcmBytes",c->pcmBytes},{"pcmFrames",c->pcmFrames},{"pcmChannels",c->pcmChannels},
            {"resourceRequested",c->resourceRequested},{"resourceWrapperBorn",c->resourceWrapperBorn},{"resourceWrapperDestroyed",c->resourceWrapperDestroyed},
            {"resourceWrapperLive",!c->resourceWrapper.isNull()},{"resourceReady",c->resourceReady},{"resourceReadyCallbacks",c->resourceReadyCallbacks},
            {"resourceDestroyCallbacks",c->resourceDestroyCallbacks},{"resourceReadyReceivers",c->resourceWrapper?c->resourceWrapper->featureReadyReceiverCount():0},
            {"resourceCacheObjectLive",!c->resource.isNull()},{"resourcePCMStillHeld",!c->resourceData.expired()},{"retireAttempted",c->retireAttempted},
            {"pcmSha256",QString::fromLatin1(c->pcmSha.toHex())},{"observedInputPCMKnown",c->birth && !c->pcmSha.isEmpty()},
            {"observedInputPCMStillHeld",!c->data.expired()},{"soundCacheAbsenceQualified",false},
            {"physicalOutputQualified",false},{"acousticQualified",false},{"peerQualified",false},{"wholeQualified",false}};
    }
    QMutex _mutex;quint64 _sequence {0};QHash<QString,std::shared_ptr<Claim>> _claims;QHash<QString,QString> _urls;
};
}
#endif
