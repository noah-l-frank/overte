"""No existing receipt qualifies the new backend dirfd boundary."""
BACKEND_DIRFD_ROOT_PROOF_SCHEMA=None
def require_backend_dirfd_qualification():
    # A future independently reviewed successor must bind a real Root receipt
    # and its actual schema. Mutating None here cannot enable this source.
    assert BACKEND_DIRFD_ROOT_PROOF_SCHEMA is None
    raise AssertionError('C22 backend dirfd runtime admission is closed pending actual boundary qualification')
