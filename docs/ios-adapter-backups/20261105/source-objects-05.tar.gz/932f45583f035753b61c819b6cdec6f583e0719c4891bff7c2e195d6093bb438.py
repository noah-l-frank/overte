"""Actual copied-State/PNG graph, same round and between-phase faults.

Native/Qt/GPU are declared producer models. Real original file/Script VM/PNG,
metadata copying, typed parser policy, full archive and original close execute.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import contextmanager
import sys
from PIL import Image
from adapters.normal_ui import NativeUIError
from ios.adapters import emote_callback_current_state as state,emote_archive_round as rounds
from ios.adapters.emote_callback_live import IOSEmoteCallbackLive
from ios.adapters.emote_callback_live_records import CallbackLiveRecords
from ios.adapters import emote_callback_archive as archive
from ios.self_tests.test_ios_emote_callback_current_state import CallbackCurrentStateTests


class CallbackCurrentSharedRoundModels(CallbackCurrentStateTests):
    @contextmanager
    def trace(self,*,on_collect=None,on_reopen=None,extra_code=None,on_extra=None):
        monitor=sys.monitoring;free=[tool for tool in (3,5,4)if monitor.get_tool(tool)is None]
        self.assertTrue(free);tool=free[0];name='private-current-round-between-phase-counter';monitor.use_tool_id(tool,name)
        collect_code=state.collect.__code__;reopen_code=archive.reopen.__code__;codes=[collect_code,reopen_code]
        if extra_code is not None:codes.append(extra_code)
        def start(code,offset):
            if code is reopen_code and on_reopen is not None:on_reopen()
            if code is extra_code and on_extra is not None:on_extra()
        def returned(code,offset,result):
            if code is collect_code and on_collect is not None:on_collect()
        monitor.register_callback(tool,monitor.events.PY_START,start)
        monitor.register_callback(tool,monitor.events.PY_RETURN,returned)
        monitor.set_local_events(tool,collect_code,monitor.events.PY_RETURN)
        monitor.set_local_events(tool,reopen_code,monitor.events.PY_START)
        if extra_code is not None:monitor.set_local_events(tool,extra_code,monitor.events.PY_START)
        try:yield
        finally:
            self.assertEqual(name,monitor.get_tool(tool))
            for code in codes:monitor.set_local_events(tool,code,0)
            monitor.set_events(tool,0);monitor.register_callback(tool,monitor.events.PY_START,None);monitor.register_callback(tool,monitor.events.PY_RETURN,None)
            monitor.free_tool_id(tool);self.assertIsNone(monitor.get_tool(tool))

    def history(self):
        Image.preinit();history=CallbackLiveRecords()
        self.assertTrue(history.literal(),repr(history.unsupported_members()));self.assertEqual({},history.cache.rows)
        return history

    def test_actual_current_collect_and_typed_replay_share_only_one_immutable_round_while_default_keeps_two(self):
        f=self.closed();snapshot=self.snapshot(f);history=self.history();before=self.queries(f);seen=[]
        with self.trace(on_reopen=lambda:seen.append(rounds._ACTIVE.get())):
            result=state.current(snapshot,lock=f.lock,primary_lock=f.lock,historical_rows=history)
        self.assertTrue(result['currentGpu']);self.assertEqual(2,len(seen));self.assertIsNotNone(seen[0]);self.assertIs(seen[0],seen[1])
        self.assertIsNone(rounds._ACTIVE.get());self.assertEqual({},history.cache.rows);self.assertTrue(history.literal());self.assertEqual(before,self.queries(f))
        legacy=[]
        with self.trace(on_reopen=lambda:legacy.append(rounds._ACTIVE.get())):
            literal=state.current(snapshot,lock=f.lock,primary_lock=f.lock)
        self.assertTrue(literal['currentGpu']);self.assertEqual(2,len(legacy));self.assertIsNotNone(legacy[0]);self.assertIsNot(legacy[0],legacy[1])
        self.assertIsNone(rounds._ACTIVE.get());self.assertEqual(before,self.queries(f))

    def test_actual_same_body_current_wal_write_between_collect_and_read_refuses_before_live_intent(self):
        f=self.closed();history=self.history();live=IOSEmoteCallbackLive(f.keyed,historical_rows=history)
        target=f.t.samples.store.path;original=target.read_bytes();changed=[];before=self.queries(f)
        def write():
            self.assertFalse(changed);target.write_bytes(original);changed.append(True)
        with self.trace(on_collect=write),self.assertRaises(NativeUIError):live.append(f.keyed_ref)
        self.assertEqual([True],changed);self.assertEqual(original,target.read_bytes());self.assertIsNone(live.store.read());self.assertIsNone(live.state['pending'])
        self.assertEqual([],live.state['records']);self.assertEqual({},history.cache.rows);self.assertEqual(before,self.queries(f));self.assertIsNone(rounds._ACTIVE.get())

    def test_actual_new_gpu_owner_between_collect_and_read_cannot_enter_shared_round_or_live_original(self):
        f=self.closed();history=self.history();live=IOSEmoteCallbackLive(f.keyed,historical_rows=history)
        orphan=f.lock.path.with_name('graphics-world-frame-primary-0-'+'f'*32+'.json');created=[];before=self.queries(f)
        def birth():
            self.assertFalse(created);orphan.write_bytes(b'{}');orphan.chmod(0o600);created.append(True)
        with self.trace(on_collect=birth),self.assertRaises(NativeUIError):live.append(f.keyed_ref)
        self.assertEqual([True],created);self.assertEqual(b'{}',orphan.read_bytes());self.assertIsNone(live.store.read());self.assertIsNone(live.state['pending'])
        self.assertEqual([],live.state['records']);self.assertEqual({},history.cache.rows);self.assertEqual(before,self.queries(f));self.assertIsNone(rounds._ACTIVE.get())

    def test_same_current_parser_function_code_change_between_collect_and_read_refuses_before_changed_parser_runs(self):
        f=self.closed();history=self.history();live=IOSEmoteCallbackLive(f.keyed,historical_rows=history)
        function=state.CallbackCurrentState._read;original=function.__code__;self.assertIn('pending',original.co_consts)
        changed_code=original.replace(co_consts=tuple('declared-foreign-pending-field'if item=='pending'else item for item in original.co_consts))
        changed=[];entered=[];before=self.queries(f)
        def mutate():
            self.assertFalse(changed);function.__code__=changed_code;changed.append(True)
        try:
            with self.trace(on_collect=mutate,extra_code=changed_code,on_extra=lambda:entered.append(True)),self.assertRaises(NativeUIError):live.append(f.keyed_ref)
            self.assertEqual([True],changed);self.assertEqual([],entered);self.assertFalse(history.literal())
        finally:function.__code__=original
        self.assertTrue(history.literal());self.assertEqual({},history.cache.rows);self.assertIsNone(live.store.read());self.assertIsNone(live.state['pending'])
        self.assertEqual([],live.state['records']);self.assertEqual(before,self.queries(f));self.assertIsNone(rounds._ACTIVE.get())

    def test_unsupported_actual_current_module_namespace_keeps_literal_default_and_never_admits_row_cache(self):
        f=self.closed();before=self.queries(f);name='_DECLARED_UNSUPPORTED_CURRENT_POLICY';self.assertFalse(hasattr(state,name));Image.preinit()
        setattr(state,name,object())
        try:
            history=CallbackLiveRecords();self.assertIsNone(history.policy);self.assertFalse(history.literal())
            self.assertTrue(any(row['module']==state.__name__ and row['member']==name and row['type']==('builtins','object')for row in history.unsupported_members()))
            seen=[]
            with self.trace(on_reopen=lambda:seen.append(rounds._ACTIVE.get())):
                result=state.current(self.snapshot(f),lock=f.lock,primary_lock=f.lock,historical_rows=history)
            self.assertTrue(result['currentGpu']);self.assertEqual(2,len(seen));self.assertIsNotNone(seen[0]);self.assertIsNot(seen[0],seen[1])
            self.assertEqual({},history.cache.rows);self.assertEqual(before,self.queries(f));self.assertIsNone(rounds._ACTIVE.get())
        finally:delattr(state,name)
