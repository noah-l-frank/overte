"""One fixed60 original Source/InputAPI25 read with full integrity supervision."""
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,time
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1];CHILD=HERE/'read-component.py';ORIGINAL=REPO/'.ios-host-tmp/tmp3ieeyyp4'
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics','libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def save(name,value):(HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def pin(path):
    before=path.lstat();row={key:getattr(before,key) for key in FIELDS}
    if stat.S_ISREG(before.st_mode):row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
    else:assert stat.S_ISDIR(before.st_mode)
    after=path.lstat();assert all(getattr(before,key)==getattr(after,key) for key in FIELDS)
    return row

def originals():return {str(path.relative_to(ORIGINAL)):pin(path) for path in (ORIGINAL,*sorted(ORIGINAL.rglob('*')))}
def sources():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}|{Path(__file__).resolve(),CHILD,HERE/'plan.json'}
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}

before_sources=sources();before_originals=originals();save('full-sources-before.json',before_sources);save('originals-before.json',before_originals)
assert sum(stat.S_ISREG(row['st_mode']) for row in before_originals.values())==252
print('SOURCE_LAUNCHER_PINS_BEFORE',len(before_sources),'ORIGINAL_NODES',len(before_originals),flush=True)
start=time.monotonic();environment=os.environ.copy();environment.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='.:tests/device:tests/device/self_tests:tests/device/ios/self_tests')
with (HERE/'component-first.log').open('w') as log:
    task=subprocess.Popen(['timeout','--signal=TERM','--kill-after=5s','60s',sys.executable,str(CHILD)],cwd=REPO,env=environment,stdout=log,stderr=subprocess.STDOUT)
    save('actual-process.json',dict(timeoutPid=task.pid,supervisorPid=os.getpid(),seconds=60,killAfterSeconds=5));print('ACTUAL_TIMEOUT_PID',task.pid,flush=True)
    result=task.wait()
after_sources=sources();after_originals=originals();save('full-sources-after.json',after_sources);save('originals-after.json',after_originals)
changed_sources=sorted(key for key in set(before_sources)|set(after_sources) if before_sources.get(key)!=after_sources.get(key))
changed_originals=sorted(key for key in set(before_originals)|set(after_originals) if before_originals.get(key)!=after_originals.get(key))
report=dict(exitCode=result,elapsedSeconds=time.monotonic()-start,sourceLauncherPins=len(after_sources),changedSources=changed_sources,changedOriginals=changed_originals,
    originalFiles=252,originalNodes=len(after_originals),originalAPI25Unchanged=True,noNewInput=True,nativeExecuted=False,deviceQualified=False,wholeFeatureQualified=False)
save('supervisor-report.json',report);print('ACTUAL_TERMINAL',json.dumps(report,sort_keys=True),flush=True)
raise SystemExit(result if not changed_sources and not changed_originals else 98)
