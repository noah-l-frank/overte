"""Ordinary address return selected only from the actual owned native baseline.

The normal address input WAL retains uncertain sends. Its acknowledgment is
separate from fresh World position/orientation/input restoration evidence.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib,math,os,stat
from adapters.native_clock_join import NativeClockAcquisition,validate_join
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUI
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same
from ios.adapters import lifecycle_current as current,lifecycle_world as world,navigation_state
from ios.adapters.navigation_address_inputs import NavigationAddressInputs
from ios.adapters.normal_navigation import configuration
from ios.adapters.lifecycle_scene_identity import address_origin



def navigation_clock_originals(packet):
    """Bind both literal native getter clocks without changing the packet.

    Navigation exposes nested clockBefore/clockAfter rather than a top-level
    capture time. This matches the existing owned-Snapshot clock carrier:
    the full raw packet and both exact original epoch values share one digest.
    """
    return dict(navigation=packet,getterBefore=dict(capturedEpochMs=packet['clockBefore']['epochMs']),
        getterAfter=dict(capturedEpochMs=packet['clockAfter']['epochMs']))


def baseline_original(value,binding,run):
    """Correlate the actual idle World and actual ordinary-return address."""
    exact(value,{'world','navigation','clockJoin','currentReference','ownerInstance'})
    facts=current.original(value['world'],binding,run);packet=value['navigation']
    join=validate_join(value['clockJoin'],navigation_clock_originals(packet))
    navigation_state.validate(packet,dict(schemaVersion=1,commandId=packet['requestId'],action=navigation_state.ACTION,runId=run),
        int(binding['processIdentity']),join['nativeAfter']['capturedEpochMs'])
    need(join['nativeBefore']['capturedEpochMs']<=packet['clockBefore']['epochMs']<=packet['clockAfter']['epochMs']<=join['nativeAfter']['capturedEpochMs'])
    first=value['world']['originals']['world'];source=packet['source'];avatar=source['avatar'];origin=first['source']
    world.measure(first,first)
    need(facts['editor']['field']is None and not facts['editor']['keyboard']['keyboard']
        and not facts['editor']['holder']['resources']['pendingRuns'] and not origin['touch']['active'])
    need(first['clockAfter']['epochMs']<=packet['clockBefore']['epochMs']
        and packet['clockAfter']['epochMs']-first['clockBefore']['epochMs']<1500
        and same(origin['lifecycle'],join['nativeBefore']['lifecycle'])and same(origin['lifecycle'],join['nativeAfter']['lifecycle']))
    need(source['foreground']and source['domain']['handlerConnected']and not source['domain']['serverless']and source['domain']['protocol']=='hifi'
        and not avatar['inAir']and not avatar['flying']and avatar['modelScale']==origin['avatar']['modelScale']
        and math.dist(origin['avatar']['feetPosition'],avatar['feetPosition'])<=.025
        and abs(sum(a*b for a,b in zip(origin['avatar']['orientation'],avatar['orientation'])))>=.9999)
    scheme,authority=address_origin(source['sceneUrl'])
    # Native Lifecycle hashes currentAddress(true), while native Navigation
    # returns currentAddress() with currentPath(). Correlate only their actual
    # Domain authority; the returned pose path remains literal and unmodified.
    need(hashlib.sha256((scheme+'://'+authority).encode('utf-8')).hexdigest()==origin['domain']['addressSha256'])
    return value


class LifecycleRestoration:
    def __init__(self,store,editors,*,epoch_ms,monotonic,current_stream=None):
        self.store,self.editors,self.source=store,editors,editors.sources.source;self.historical=False
        self.binding,self.run,self.lock=deepcopy(editors.binding),editors.run,editors.lock
        from ios.adapters.lifecycle_current_stream import LifecycleCurrentStream
        need(current_stream is None or type(current_stream) is LifecycleCurrentStream and current_stream.source is self.source
            and current_stream.binding==self.binding and current_stream.run==self.run and current_stream.role=='primary'and current_stream.lock is self.lock)
        self.current_stream=current_stream
        self.original_source=tuple((name,self.source[name])for name in ('client','session','observer','native','clock_source','check'))
        self.source_check_function=getattr(self.source['check'],'__func__',self.source['check']);self.source_check_code=self.source_check_function.__code__
        namespaces=((globals(),('validate_join','same','configuration','baseline_original','navigation_clock_originals','address_origin')),(vars(current),('original',)),
            (vars(world),('measure',)),(vars(navigation_state),('validate',)),
            (vars(NavigationAddressInputs),('__init__','decode','goto','bound','save','capture','request','edit','intent')),
            (vars(NativeClockAcquisition),('__init__','begin','finish')),
            (vars(type(self)),('__init__','check','save','intent','baseline','original','selected','restore','recover_saved','inventory')))
        self.receivers=tuple((namespace,name,namespace[name],namespace[name].__code__)for namespace,names in namespaces for name in names)
        self.stream_receivers=()if current_stream is None else tuple((name,getattr(type(current_stream),name),getattr(type(current_stream),name).__code__)for name in ('bound','current','capture','record'))
        need(isinstance(store,PrivateFeatureState) and store.path==editors.store.path.with_name('ios-lifecycle-restoration.json'))
        self.epoch_ms,self.monotonic=epoch_ms,monotonic;self.previous=store.read()
        self.state=dict(baseline=None,after=None,storage={}) if self.previous is None else deepcopy(self.previous['state'])
        if self.previous is not None:
            exact(self.previous,{'iosLifecycleRestorationVersion','binding','runId','state'})
            need(type(self.previous['iosLifecycleRestorationVersion']) is int and self.previous['iosLifecycleRestorationVersion']==1
                and self.previous['binding']==self.binding and self.previous['runId']==self.run);exact(self.state,{'baseline','after','storage'})
        self.files=OriginalFrameStore(store.path.parent,self.binding,self.run,'primary',self.check,self.intent,
            namespace='lifecycle-restoration',schema_prefix='iosLifecycleRestoration',kind='inputs')
        self.reader=self.source['observer'].lifecycle_world(self.source['clock_source'])
        self.navigation=self.source['observer'].navigation_state(self.source['clock_source'])
        read=self.navigation.read;self.navigation_receiver=(read.__func__,read.__func__.__code__)
        self.check()
        need(type(self.state['storage']) is dict and set(self.state['storage'])<= {'1','2'}
            and (self.state['after'] is None or self.state['baseline'] is not None))
        for key,value in self.state['storage'].items():self.files.original(value);need(value['index']==int(key))
        for name,index in (('baseline',1),('after',2)):
            reference=self.state[name]
            if reference is not None:
                need(reference['index']==index and str(index)in self.state['storage']
                    and same(reference,self.files.compact(self.state['storage'][str(index)])))
                self.original(reference)
        self.inventory();self.recover_saved()

    @classmethod
    def archived(cls,store,stream,binding,run,lock):
        from ios.adapters.lifecycle_current_archive import LifecycleCurrentArchive
        need(type(stream)is LifecycleCurrentArchive and stream.role=='primary'and stream.binding==binding and stream.run==run)
        scope=object.__new__(cls);scope.store,scope.current_stream=store,stream
        scope.binding,scope.run,scope.lock=deepcopy(binding),run,lock;scope.historical=True
        scope.previous=store.read();need(scope.previous is not None)
        exact(scope.previous,{'iosLifecycleRestorationVersion','binding','runId','state'})
        need(type(scope.previous['iosLifecycleRestorationVersion'])is int and scope.previous['iosLifecycleRestorationVersion']==1
            and scope.previous['binding']==binding and scope.previous['runId']==run)
        scope.state=deepcopy(scope.previous['state']);exact(scope.state,{'baseline','after','storage'})
        scope.files=OriginalFrameStore(store.path.parent,binding,run,'primary',scope.check,lambda *_:need(False),
            namespace='lifecycle-restoration',schema_prefix='iosLifecycleRestoration',kind='inputs')
        scope.inventory();need(scope.state['baseline']is not None and scope.state['after']is not None)
        scope.original(scope.state['baseline']);scope.original(scope.state['after']);return scope

    def check(self):
        if self.historical:
            self.lock.assert_held();need(same(self.store.read(),self.previous));return True
        for namespace,name,function,code in self.receivers:
            if namespace.get(name)is not function or function.__code__ is not code:raise RuntimeError('Original Lifecycle restoration receiver/code changed')
        for name,value in self.original_source:
            if self.source.get(name)is not value:raise RuntimeError('Original Lifecycle restoration Source changed')
        if self.source_check_function.__code__ is not self.source_check_code:raise RuntimeError('Original Lifecycle restoration Source check code changed')
        for name,function,code in self.stream_receivers:
            if getattr(type(self.current_stream),name)is not function or function.__code__ is not code:raise RuntimeError('Original Lifecycle restoration Current7 receiver/code changed')
        read=self.navigation.read;function,code=self.navigation_receiver
        if read.__self__ is not self.navigation or read.__func__ is not function or function.__code__ is not code:raise RuntimeError('Original Lifecycle restoration navigation receiver/code changed')
        self.lock.assert_held();need(self.source is self.editors.sources.source and self.source['binding']==self.binding
            and self.source['check']() is not False and same(self.store.read(),self.previous));return True

    def save(self):
        self.check();value=dict(iosLifecycleRestorationVersion=1,binding=self.binding,runId=self.run,state=deepcopy(self.state))
        self.store.write(value,self.previous);self.previous=deepcopy(value)

    def intent(self,kind,value):
        self.check();need(kind=='original');self.files.original(value);key=str(value['index']);need(key in ('1','2'))
        old=self.state['storage'].get(key)
        if old is None:need(value['phase']=='planned')
        else:
            need(all(same(old[k],value[k]) for k in old if k not in ('phase','file'))
                and (old['phase'],value['phase']) in (('planned','opened'),('opened','saved'))
                and (old['file'] is None or old['file']==value['file']))
        self.state['storage'][key]=deepcopy(value);self.save()

    def inventory(self):
        self.check();prefix=self.files.namespace+'-frame-'+self.files.kind+'-'+self.run+'-primary-'
        expected={self.files.path(value).name:value for value in self.state['storage'].values()if value['phase']!='planned'}
        actual={path.name:path for path in self.store.path.parent.iterdir()if path.name.startswith(prefix)}
        need(set(actual)==set(expected))
        for name,path in actual.items():
            info=path.lstat();value=expected[name]
            need(stat.S_ISREG(info.st_mode)and info.st_nlink==1 and info.st_size<=value['bytes']
                and (os.name=='nt'or info.st_uid==os.geteuid()and stat.S_IMODE(info.st_mode)==0o600)
                and (info.st_dev,info.st_ino)==(value['file']['device'],value['file']['inode']))
            if value['phase']=='saved':need(info.st_size==value['bytes'])

    def recover_saved(self):
        """Adopt only an actual completed original, never reissue uncertain IO."""
        self.check();self.inventory()
        for name,index in (('baseline',1),('after',2)):
            value=self.state['storage'].get(str(index))
            if value is None:continue
            # Partial bytes remain on disk with their WAL. A new Current7 or
            # ordinary Go cannot be substituted for this unresolved result.
            need(value['phase']=='saved');reference=self.files.compact(value)
            if self.state[name]is None:
                self.original(reference);self.state[name]=reference;self.save()
            else:need(same(self.state[name],reference))

    def baseline(self,actual):
        self.check();self.recover_saved();current.original(actual,self.binding,self.run)
        need(self.current_stream is not None and self.current_stream.state['records']);reference=self.current_stream.state['records'][-1]
        retained=self.current_stream.record(reference);need(same(retained['current'],actual))
        if self.state['baseline'] is not None:
            need(same(self.original(self.state['baseline'])['world'],actual));return self.selected()
        clock=NativeClockAcquisition(self.source['clock_source'],epoch_ms=self.epoch_ms,monotonic=self.monotonic)
        clock.begin(self.epoch_ms());raw=self.navigation.read(self.run);joined=clock.finish(navigation_clock_originals(raw),[('getterBefore','capturedEpochMs'),('getterAfter','capturedEpochMs')])
        first=actual['originals']['world'];need(first['clockAfter']['epochMs']<=raw['clockBefore']['epochMs']
            and raw['clockAfter']['epochMs']-first['clockBefore']['epochMs']<1500)
        need(math.dist(first['source']['avatar']['feetPosition'],raw['source']['avatar']['feetPosition'])<=.025)
        frame=dict(world=deepcopy(actual),navigation=raw,clockJoin=joined,currentReference=deepcopy(reference),ownerInstance=self.current_stream.state['owner'])
        baseline_original(frame,self.binding,self.run)
        ref=self.files.write(1,frame);self.state['baseline']=ref;self.save();return self.selected()

    def original(self,reference):
        self.check();self.inventory();value=self.files.read(self.files.expand(reference))
        if reference['index']==2:
            exact(value,{'current','addressOwner','currentReference'});facts=current.original(value['current'],self.binding,self.run)
            need(self.current_stream is not None and same(self.current_stream.record(value['currentReference'])['current'],value['current']))
            # Decode the literal actual ordinary-address WAL, without creating
            # a live navigation/Input owner or issuing a replacement Go.
            decoder=object.__new__(NavigationAddressInputs);decoder.binding,decoder.run=self.binding,self.run
            decoded=decoder.decode(value['addressOwner']);rows=[row for row in decoded['rows']if row['key']=='return']
            need(len(rows)==1 and rows[0]['phase']=='acknowledged' and rows[0]['url']==self.selected())
            baseline=self.original(self.state['baseline']);first=baseline['world']['originals']['world'];last=value['current']['originals']['world']
            need(value['currentReference']['index']>baseline['currentReference']['index']
                and rows[0]['captures'][-1]['sampleEpochMs']<=value['current']['clockJoin']['nativeBefore']['capturedEpochMs']
                and facts['editor']['field']is None and not facts['editor']['keyboard']['keyboard']
                and not facts['editor']['holder']['resources']['pendingRuns'])
            measured=world.measure(first,last)
            need(measured['heldInputs']==[] and measured['worldDisplacement']<=.025 and not last['source']['touch']['active']
                and abs(sum(a*b for a,b in zip(first['source']['avatar']['orientation'],last['source']['avatar']['orientation'])))>=.9999)
            return value
        need(reference['index']==1);exact(value,{'world','navigation','clockJoin','currentReference','ownerInstance'})
        need(self.current_stream is not None and value['ownerInstance']==self.current_stream.state['owner']
            and same(self.current_stream.record(value['currentReference'])['current'],value['world']))
        return baseline_original(value,self.binding,self.run)

    def selected(self):
        self.check();need(self.state['baseline'] is not None);value=self.original(self.state['baseline']);url=value['navigation']['source']['sceneUrl']
        need(type(url) is str and 1<=len(url)<=2048 and not any(ord(c)<32 for c in url));return url

    def restore(self,*,ticket):
        from feature_journeys.contract import identifier
        self.check();identifier(ticket);self.recover_saved();need(self.current_stream is not None)
        if self.state['after']is not None:
            # Replay the already recorded action result, without pretending its
            # historical native sources are a new observation of the product.
            self.original(self.state['after']);return dict(performed=True)
        # A new actual original-owner cut is REQUIRED before Go. A new Source
        # with only the old JSON binding cannot borrow the baseline address.
        opening=self.current_stream.current(ticket);first_cut=opening['current'];first_facts=current.original(first_cut,self.binding,self.run)
        need(not first_facts['world']['source']['touch']['active'] and first_facts['editor']['field'] is None
            and not first_facts['editor']['keyboard']['keyboard']and not first_facts['editor']['holder']['resources']['pendingRuns'])
        url=self.selected();source=self.source
        owner=NavigationAddressInputs(PrivateFeatureState(self.store.path.with_name('ios-navigation-address-'+self.binding['processIdentity']+'-inputs.json')),
            self.binding,self.run,self.lock,self.check,NativeUI(source['client'],source['session'],self.check),source['native'],
            epoch_ms=self.epoch_ms,monotonic=self.monotonic)
        profile=configuration(source['target']);need(profile is not None)
        owner.goto('return',url,profile,{url},original_return=self)
        # New actual current sources, never the Go acknowledgment or requested
        # address. An unsettled return refuses and leaves all responsibility.
        observed=self.current_stream.current(ticket);value=observed['current'];current_reference=deepcopy(self.current_stream.state['records'][-1])
        first=self.original(self.state['baseline'])['world']['originals']['world'];last=value['originals']['world'];facts=world.measure(first,last)
        need(facts['heldInputs']==[] and facts['worldDisplacement']<=.025 and not last['source']['touch']['active'])
        a,b=first['source']['avatar']['orientation'],last['source']['avatar']['orientation']
        need(abs(sum(x*y for x,y in zip(a,b)))>=.9999)
        if self.state['after'] is None:
            # The restored evidence uses its own complete Current original;
            # no fabricated second navigation clock join is published.
            self.state['after']=self.files.write(2,dict(current=value,addressOwner=deepcopy(owner.previous),currentReference=current_reference))
            self.save()
        self.original(self.state['after'])
        return dict(performed=True)
