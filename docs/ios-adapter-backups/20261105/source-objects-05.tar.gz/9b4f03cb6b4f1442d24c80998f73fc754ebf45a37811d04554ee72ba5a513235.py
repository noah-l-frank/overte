"""Source-only suite bootstrap; an external reviewed controller owns all guards.

Importing this file does not import project code or launch a counter. Calling
build_suite requires Root's preinstalled frozen module loader and audit boundary.
This helper never grants SDK/process/file authority and is not a supervisor.
"""
from pathlib import Path
import hashlib,json,sys,tempfile,unittest
SOURCE_NAME='audio-native-clock-join-original-operands-diagnostic2-counter-frame-stage-private-20261103'
SOURCE_FREEZE='43434cc922fbea103521edd97a3eaf4952a21e98544216afc12cecc6be3d2fcf'
CASES=['self_tests.test_native_clock_join_refusal_original.NativeClockJoinRefusalOriginalTests.test_positive_scope_keeps_record_contract_and_clock_query_counts_without_output', 'self_tests.test_native_clock_join_refusal_original.NativeClockJoinRefusalOriginalTests.test_actual_false_conjunction_retains_only_original_operands_and_no_extra_clock_or_query', 'self_tests.test_native_clock_join_refusal_original.NativeClockJoinRefusalOriginalTests.test_other_false_stages_do_not_create_a_native_host_refusal_original', 'self_tests.test_native_clock_join_refusal_original.NativeClockJoinRefusalOriginalTests.test_standalone_historical_validation_cannot_borrow_the_live_finish_receiver', 'self_tests.test_native_clock_join_refusal_original.NativeClockJoinRefusalOriginalTests.test_output_conflict_never_overwrites_or_replaces_the_original_false_refusal']
PRIVATE={
 'adapters.native_clock_join':'candidate/tests/device/adapters/native_clock_join.py',
 'adapters.native_clock_join_refusal_original':'candidate/tests/device/adapters/native_clock_join_refusal_original.py',
 'self_tests.test_native_clock_join_refusal_original':'candidate/tests/device/self_tests/test_native_clock_join_refusal_original.py',
}

def build_suite():
    # This selects only the declared five unit counters. It does not establish
    # that an outer controller's runtime guards/cleanup/censuses have passed.
    assert sys.dont_write_bytecode
    repo=Path.cwd().resolve(strict=True)
    assert repo.name=='overte-ios-feature-adapters-resume-20261026'and(repo/'.git').is_file()
    root=repo/'.ios-host-tmp'/SOURCE_NAME;freeze=root/'freeze.json'
    assert hashlib.sha256(freeze.read_bytes()).hexdigest()==SOURCE_FREEZE
    manifest=json.loads(freeze.read_text())
    for name,row in manifest['files'].items():
        path=root/name
        assert not Path(name).is_absolute()and '..'not in Path(name).parts and path.resolve(strict=True)==path
        assert path.stat().st_size==row['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
    # Temp root is created/retained by the external controller, never by this
    # bootstrap. The source writer deliberately refuses generic /tmp roots.
    assert type(tempfile.tempdir)is str
    temporary=Path(tempfile.tempdir)
    assert temporary.is_absolute()and temporary.resolve(strict=True)==temporary and temporary.is_dir()and temporary.is_relative_to(repo/'.ios-host-tmp')
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(CASES)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for child in value:yield from flatten(child)
        else:yield value
    cases=list(flatten(suite))
    assert not loader.errors and [case.id()for case in cases]==CASES and suite.countTestCases()==5
    # Exact module/code origins after the real frozen loader imported them;
    # a public fallback for either new diagnostic module is not admitted.
    for module,relative in PRIVATE.items():
        current=sys.modules[module];path=root/relative
        assert Path(current.__file__).resolve(strict=True)==path
    for case in cases:
        method=getattr(type(case),case._testMethodName)
        assert Path(method.__code__.co_filename).resolve(strict=True)==root/PRIVATE['self_tests.test_native_clock_join_refusal_original']
    return suite
