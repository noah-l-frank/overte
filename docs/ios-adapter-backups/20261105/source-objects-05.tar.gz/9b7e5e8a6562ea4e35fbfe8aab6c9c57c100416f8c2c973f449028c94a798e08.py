"""Read-only custody repair of a passed case; no subject input/replay."""
from pathlib import Path
import hashlib,json,runpy
B=Path.cwd()/'.ios-host-tmp'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def put(d,n,v):
 with(d/n).open('x')as f:json.dump(v,f,sort_keys=True,indent=2);f.write('\n')
 (d/n).chmod(0o600)
H=B/'audio-received-ordinary-audio-01-prepared-next-headd483-b2-20261105';OUTER=H.with_name(H.name+'-outer');COL=B/'root-audio26-b2-first1-window-current1051-20261105';CENSUS=H.with_name(H.name+'-censuses');TEMP=H/'temporary'
assert not(COL/'freeze.json').exists()and not(COL/'global-after-first.json').exists()and not(COL/'global-after-second.json').exists()
assert sha(H/'approved-inputs.json')=='6f49bcdf5e4053294fcb9277bb135ef195ba0492ffa2249f4a3e4083e6b6b328';p=load(H/'approved-inputs.json');terminal=load(OUTER/'terminal.json')
assert terminal['status']=='PASS'and terminal['childReturnCode']==0 and terminal['ownProcessesAbsent']and not terminal['problems']and not terminal['timedOut']and not terminal['forcedKill']and not terminal['orphansRequiredKill']
for k in('actualClassCleanupCustodyEstablished','actualOneCaseReceiptsEstablished','actualRetainedAudioResourceRecipeEstablished','actualStdlibParentFDThreadDrain','allSourceBinaryPinsEqual','allSubjectActualRuntimeOriginsEstablished','approvedInputsExactPinAndCliShaUnchanged','originalChildSubtreesCensusesEqual','twoFullOwnOutputCensusesEqual','zeroCaseChildBirthsEstablished'):assert terminal[k]is True
report=load(H/'child-receipts/report.json');assert report['testsRun']==report['actualCaseReceipts']==1 and report['status']=='PASS'and report['cleanupEstablished']and report['fatal']is None and len(report['retainedTemporaryDirectories'])==1
case=load(H/'child-receipts/standard-case-1.json');assert case['id']==p['cases'][0]and len(case['actualNestedCleanupCalls'])==2 and case['newTemporaryDirectories']==1
ports=load(H/'child-receipts/actual-port-restoration.json');assert ports['count']==27 and ports['controlDescriptors']==[]
for k in('restored','dupPortsRestored','toolsRestored','builtinsCioRestored'):assert ports[k]is True
assert ports['actualClassCleanupRestoration']['originalDescriptorRestored']is True
origins=load(H/'child-receipts/actual-source-model-origins.json');assert origins['allSubjectActualRuntimeOriginsEstablished']and len(origins['subjectOrigins'])==447
q=load(CENSUS/'qualification.json');assert q['status']=='PASS'and q['ownProcessesAbsent']and q['noCensusExclusions']and q['originalRoots']==list(map(str,[H,OUTER,CENSUS]))
drain=load(OUTER/'actual-process-drain.json');assert not drain['remaining']and not drain['orphansRequiredKill']
for row in drain['owned']:
 try:raw=Path('/proc',str(row['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(raw[raw.rfind(')')+2:].split()[19])!=row['startTicks']
A=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(A)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(A))['census'];ctx=load(B/'root-ios-current1051-after-emote-b16-negative-context-20261105/root-context.json');old=load(ctx['globalCustody']['baseline']['path']);assert len(old)==1051 and old==load(COL/'global-before.json')
assert load(COL/'whole-output-first.json')==load(COL/'whole-output-second.json')
for n,v in load(COL/'whole-output-first.json').items():assert census(Path(n))==v
O=B/'root-audio26-audio01-original-host-qualified-complete-own-temporary-custody-20261105';O.mkdir(mode=0o700)
helper=Path(ctx['globalCustody']['helper']['path']);assert sha(helper)=='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03';current=runpy.run_path(str(helper))['current']
first=current();put(O,'repair-global-after-first.json',first);second=current();put(O,'repair-global-after-second.json',second)
assert first==second and set(first)==set(old)|{str(TEMP)}and all(first[n]==v for n,v in old.items())and first[str(TEMP)]==census(TEMP)
rooms=[H,TEMP,OUTER,CENSUS,COL];one={str(root):census(root)for root in rooms};two={str(root):census(root)for root in rooms};assert one==two;put(O,'repair-whole-originals-first.json',one);put(O,'repair-whole-originals-second.json',two)
refs={str(f):dict(path=str(f),sha256=sha(f))for root in rooms for f in sorted(root.rglob('*'))if f.is_file()and not f.is_symlink()}
put(O,'results.json',dict(status='ROOT_QUALIFIED_AUDIO26_AUDIO01_HOST_CASE_ONLY_WITH_READ_ONLY_OWN_TEMPORARY_CUSTODY_REPAIR',terminal=terminal,newOriginalRoots=list(map(str,rooms+[O])),singleSource5AcquisitionHostCaseQualified=True,actualCases=p['cases'],actualCaseCount=1,actualFreshSubjectOrigins=447,actualReport=report,actualCaseReceipt=case,actualPortRestoration=ports,actualProcessDrain=drain,sourceFreeze=p['sourceFreeze'],source5Freeze=p['receivedSource5Freeze'],source6Freeze=p['mediaSourceFreeze'],all1051OldOriginalBodiesUnchanged=True,originalCollectorFailure='Root external collector asserted old-only global dictionary equality although its own newly created H/temporary is included by unchanged bc052 discovery.',originalCollectorAfterMapsRecorded=False,actualRepairGlobalPostScans=2,originalRootBeforeRetained=True,allOwnTemporaryAndOuterAndCensusesAndFailedCollectorIncluded=True,originalCaseReexecuted=False,remaining25GroupsUnrun=True,receivedMixerLiveAdmission=None,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(O,'actual-receipt-references.json',refs);put(O,'freeze.json',dict(files={f.name:dict(sha256=sha(f))for f in sorted(O.iterdir())}));print(json.dumps(dict(freeze=sha(O/'freeze.json'),results=sha(O/'results.json'),references=len(refs),newRoots=6))))
