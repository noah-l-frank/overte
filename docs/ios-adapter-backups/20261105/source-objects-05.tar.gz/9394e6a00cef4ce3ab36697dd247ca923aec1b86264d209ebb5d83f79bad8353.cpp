//
//  MixedProcessedAudioStream.cpp
//  libraries/audio/src
//
//  Created by Yixin Wang on 8/4/14.
//  Copyright 2013 High Fidelity, Inc.
//
//  Distributed under the Apache License, Version 2.0.
//  See the accompanying file LICENSE or http://www.apache.org/licenses/LICENSE-2.0.html
//

#include "MixedProcessedAudioStream.h"
#include "AudioLogging.h"
#include "TryLocker.h"
#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
#include <QDateTime>
#include <QElapsedTimer>
#include <QCryptographicHash>
#include <PortableHighResolutionClock.h>
namespace { qint64 receivedDecodeMonotonicMs() { QElapsedTimer timer; timer.start(); return timer.msecsSinceReference(); } }
#endif

MixedProcessedAudioStream::MixedProcessedAudioStream(int numFramesCapacity, int numStaticJitterFrames)
    : InboundAudioStream(AudioConstants::STEREO, AudioConstants::NETWORK_FRAME_SAMPLES_PER_CHANNEL,
        numFramesCapacity, numStaticJitterFrames) {}

void MixedProcessedAudioStream::outputFormatChanged(int sampleRate, int channelCount) {
    _outputSampleRate = sampleRate;
    _outputChannelCount = channelCount;
    int deviceOutputFrameFrames = networkToDeviceFrames(AudioConstants::NETWORK_FRAME_SAMPLES_STEREO / AudioConstants::STEREO);
    int deviceOutputFrameSamples = deviceOutputFrameFrames * AudioConstants::STEREO;
    _ringBuffer.resizeForFrameSize(deviceOutputFrameSamples);
}

int MixedProcessedAudioStream::writeDroppableSilentFrames(int silentFrames) {
    int deviceSilentFrames = networkToDeviceFrames(silentFrames);
    int deviceSilentFramesWritten = InboundAudioStream::writeDroppableSilentFrames(deviceSilentFrames);
    emit addedSilence(deviceToNetworkFrames(deviceSilentFramesWritten));
    return deviceSilentFramesWritten;
}

int MixedProcessedAudioStream::lostAudioData(int numPackets) {
    QByteArray decodedBuffer;
    QByteArray outputBuffer;

    while (numPackets--) {
        MutexTryLocker lock(_decoderMutex);
        if (!lock.isLocked()) {
            // an incoming packet is being processed,
            // and will likely be on the ring buffer shortly,
            // so don't bother generating more data
            qCInfo(audiostream, "Packet currently being unpacked or lost frame already being generated.  Not generating lost frame.");
            return 0;
        }
        if (_decoder) {
            _decoder->lostFrame(decodedBuffer);
        } else {
            decodedBuffer.resize(AudioConstants::NETWORK_FRAME_BYTES_STEREO);
            memset(decodedBuffer.data(), 0, decodedBuffer.size());
        }
        emit addedStereoSamples(decodedBuffer);

        emit processSamples(decodedBuffer, outputBuffer);

        _ringBuffer.writeData(outputBuffer.data(), outputBuffer.size());
        qCDebug(audiostream, "Wrote %d samples to buffer (%d available)", outputBuffer.size() / (int)sizeof(int16_t), getSamplesAvailable());
    }
    return 0;
}

#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_E2E_VOICE_TESTS)
int MixedProcessedAudioStream::parseAcceptedAudioOriginal(ReceivedMessage& message, quint16 sequence,
        const QString& codec, bool early, const QByteArray& payload) {
    if (!_receivedOriginalsEnabled.load(std::memory_order_acquire)) { return parseAudioData(payload); }
    ReceivedMixerDecodedOriginal original;
    original.stream = this; original.message = &message; original.encoded = &payload;
    original.sequence = sequence; original.packetCodec = codec; original.early = early;
    original.thread = QThread::currentThread();
    if (message.getMessage().size() <= 2048) {
        original.originalMessageDigest = QCryptographicHash::hash(message.getMessage(), QCryptographicHash::Sha256);
    }
    return decodeAudioOriginal(payload, &original);
}
int MixedProcessedAudioStream::parseAudioData(const QByteArray& payload) { return decodeAudioOriginal(payload, nullptr); }
int MixedProcessedAudioStream::decodeAudioOriginal(const QByteArray& packetAfterStreamProperties, ReceivedMixerDecodedOriginal* original) {
    QByteArray decodedBuffer;
    QMutexLocker lock(&_decoderMutex);
    if (original) {
        original->decoder = _decoder; original->selectedCodec = _selectedCodecName;
        original->decoderLifeBefore = e2eDecoderLifetime();
        original->beforeEpoch = QDateTime::currentMSecsSinceEpoch(); original->beforeMono = receivedDecodeMonotonicMs();
        original->beforeReceiveClockUs = std::chrono::duration_cast<std::chrono::microseconds>(p_high_resolution_clock::now().time_since_epoch()).count();
    }
    if (_decoder) { _decoder->decode(packetAfterStreamProperties, decodedBuffer); }
    else { decodedBuffer = packetAfterStreamProperties; }
    if (original) {
        original->afterEpoch = QDateTime::currentMSecsSinceEpoch(); original->afterMono = receivedDecodeMonotonicMs();
        original->afterReceiveClockUs = std::chrono::duration_cast<std::chrono::microseconds>(p_high_resolution_clock::now().time_since_epoch()).count();
        original->decoderLifeAfter = e2eDecoderLifetime();
        original->decoded = &decodedBuffer;
        emit receivedMixerDecodedOriginal(original); // Direct only; stack lifetime ends before ordinary processing returns.
        original->decoded = nullptr; original->encoded = nullptr; original->message = nullptr;
    }
    emit addedStereoSamples(decodedBuffer);
    QByteArray outputBuffer;
    emit processSamples(decodedBuffer, outputBuffer);
    _ringBuffer.writeData(outputBuffer.data(), outputBuffer.size());
    qCDebug(audiostream, "Wrote %d samples to buffer (%d available)", outputBuffer.size() / (int)sizeof(int16_t), getSamplesAvailable());
    return packetAfterStreamProperties.size();
}
#else
int MixedProcessedAudioStream::parseAudioData(const QByteArray& packetAfterStreamProperties) {
    QByteArray decodedBuffer;

    // may block on the real-time thread, which is acceptible as 
    // parseAudioData is only called by the packet processing
    // thread which, while high performance, is not as sensitive to
    // delays as the real-time thread.
    QMutexLocker lock(&_decoderMutex);
    if (_decoder) {
        _decoder->decode(packetAfterStreamProperties, decodedBuffer);
    } else {
        decodedBuffer = packetAfterStreamProperties;
    }

    emit addedStereoSamples(decodedBuffer);

    QByteArray outputBuffer;
    emit processSamples(decodedBuffer, outputBuffer);

    _ringBuffer.writeData(outputBuffer.data(), outputBuffer.size());
    qCDebug(audiostream, "Wrote %d samples to buffer (%d available)", outputBuffer.size() / (int)sizeof(int16_t), getSamplesAvailable());

    return packetAfterStreamProperties.size();
}

#endif

int MixedProcessedAudioStream::networkToDeviceFrames(int networkFrames) {
    return ((quint64)networkFrames * _outputChannelCount * _outputSampleRate) /
        (quint64)(AudioConstants::STEREO * AudioConstants::SAMPLE_RATE);
}

int MixedProcessedAudioStream::deviceToNetworkFrames(int deviceFrames) {
    return (quint64)deviceFrames * (quint64)(AudioConstants::STEREO * AudioConstants::SAMPLE_RATE) /
        (_outputSampleRate * _outputChannelCount);
}
