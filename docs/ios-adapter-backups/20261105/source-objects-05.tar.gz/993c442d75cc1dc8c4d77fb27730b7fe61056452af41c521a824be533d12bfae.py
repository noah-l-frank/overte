"""Actual current negative WAL reconciliation, declared raw native producers."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import unittest
from copy import deepcopy
from adapters.normal_ui import NativeUIError
from ios.self_tests.audio_whole_fixture import AudioWholeFixture

class AudioNegativeReconcileTests(unittest.TestCase):
    def setUp(self):
        self.f=AudioWholeFixture(self);self.f.primary.prepare();self.f.actor.prepare();self.f.step('open','1'*32)
    def lose_first_observe(self):
        f=self.f;send=f.once.boundary.send;lost=[]
        def producer(query):
            result=send(query)
            if query['operation']=='observe'and not lost:
                lost.append(query['commandId']);raise NativeUIError('Declared lost original observe after actual producer delivery')
            return result
        f.once.boundary.send=producer;call=f.activate('mute','2'*32,dict(enabled=True))
        try:
            with self.assertRaises((NativeUIError,ValueError)):f.primary.act(call)
        finally:f.once.boundary.send=send
        self.assertTrue(lost);return call
    def test_same_unknown_original_capture_completes_before_its_only_release_without_second_start_or_mute(self):
        f=self.f;call=self.lose_first_observe();commands=f.once.boundary.commands
        self.assertEqual(1,sum(q['operation']=='start'for q in commands));self.assertEqual(0,sum(q['operation']=='release'for q in commands))
        muted=f.m.actions.count('audio.mute');f.primary=f.flow('primary');f.primary.act(call)
        operations=[q['operation']for q in f.once.boundary.commands]
        self.assertEqual(1,operations.count('start'));self.assertEqual(1,operations.count('capture'));self.assertEqual(1,operations.count('release'))
        self.assertLess(operations.index('capture'),operations.index('release'));self.assertEqual(muted,f.m.actions.count('audio.mute'))
        with f.primary.held():
            self.assertTrue(f.primary.state['actions'][-1]['completed']);self.assertEqual(1,len([r for r in f.primary.state['artifacts']if r['ticket']=='2'*32]))
    def test_previously_released_without_snapshot_refuses_before_actor_factory_or_new_native_query(self):
        f=self.f;call=self.lose_first_observe();f.primary.retire_actor()
        commands=deepcopy(f.once.boundary.commands);actual=f.primary.actor_runtime._sources;factories=[];muted=f.m.actions.count('audio.mute')
        def counted(*args,**kwargs):factories.append(True);return actual(*args,**kwargs)
        f.primary.actor_runtime._sources=counted
        try:
            f.primary=f.flow('primary')
            with self.assertRaises((NativeUIError,ValueError)):f.primary.act(call)
        finally:f.primary.actor_runtime._sources=actual
        self.assertEqual([],factories);self.assertEqual(commands,f.once.boundary.commands);self.assertEqual(muted,f.m.actions.count('audio.mute'))
    def test_lost_original_media_handoff_reuses_same_snapshot_bytes_epoch_and_absence_without_second_capture(self):
        f=self.f;call=f.activate('mute','2'*32,dict(enabled=True));actual=f.primary.evidence.retain;lost=[]
        def handoff(*args,**kwargs):
            row=actual(*args,**kwargs)
            if not lost:lost.append(deepcopy(row));raise NativeUIError('Declared lost handoff return after actual immutable media/WAL commit')
            return row
        f.primary.evidence.retain=handoff
        with self.assertRaises((NativeUIError,ValueError)):f.primary.act(call)
        self.assertTrue(lost);before=deepcopy(f.once.boundary.commands);f.primary=f.flow('primary');f.primary.act(call)
        self.assertEqual(before,f.once.boundary.commands)
        with f.primary.held():
            row=next(r for r in f.primary.state['artifacts']if r['ticket']=='2'*32)
            self.assertEqual(lost[0],row);self.assertGreater(len(f.primary.evidence.read(row)),44)
