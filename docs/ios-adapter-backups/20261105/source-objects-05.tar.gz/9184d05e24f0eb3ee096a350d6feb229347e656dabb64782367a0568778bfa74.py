"""Closed actual JSON/default decoder and PNG dispatch policy, source/AST only."""
import ast,difflib,hashlib,json
from pathlib import Path
R=Path.cwd();H=R/'.ios-host-tmp/emote-callback-live-prefix-external-parser-policy-source-draft-20261102';B=R/'.ios-host-tmp/emote-callback-live-prefix-typed-set-diagnostics-source-fix-20261102'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(s)
rows=[];diff=[]
for row in json.loads((B/'plan.json').read_text())['sourceRows']:
 rel=row['path'];p=B/'candidate'/rel;assert sha(p)==row['candidateSHA256'];before=p.read_text();after=before
 if rel.endswith('emote_callback_live_records.py'):
  after=after.replace('from PIL import Image,ImageChops,ImageStat','from PIL import Image,ImageChops,ImageStat,ImageFile,PngImagePlugin,ImageMode,_binary\nimport zlib')
  after=after.replace('if kind in (str,int,bool,type(None)):','if kind in (str,bytes,int,bool,type(None)):')
  needle="    if kind is CodeType:return ('code',identity)\n";assert after.count(needle)==1
  after=after.replace(needle,needle+"""    if value is int.__repr__ or value is float.__repr__:return ('json-number-repr',identity)
    if kind is json.JSONDecoder:
        fields=('object_hook','parse_float','parse_int','parse_constant','strict','object_pairs_hook','parse_object','parse_array','parse_string','memo','scan_once')
        if set(vars(value))!=set(fields):raise _Unsupported(kind,'json-decoder-state')
        return ('json-decoder',identity,tuple((name,token(getattr(value,name))) for name in fields))
    if kind is json.JSONEncoder:
        required={'skipkeys','ensure_ascii','check_circular','allow_nan','sort_keys','indent'}
        if not required<=set(vars(value))<=required|{'item_separator','key_separator','default'}:raise _Unsupported(kind,'json-encoder-state')
        return ('json-encoder',identity,token(vars(value)))
    if json.scanner.c_make_scanner is not None and kind is json.scanner.c_make_scanner:
        fields=('strict','object_hook','object_pairs_hook','parse_float','parse_int','parse_constant')
        return ('json-c-scanner',identity,tuple((name,token(getattr(value,name))) for name in fields))
""")
  anchor='\n\nclass CallbackLiveRecords:';assert after.count(anchor)==1
  extra="""

# Explicit closed dependencies called by actual JSON and original RGBA PNG
# decoding. No external arbitrary instance/buffer or custom PNG decoder is
# accepted. Mutable registry bindings and same-function code changes participate.
EXTERNAL_READERS+=((json,'JSONDecoder'),(json,'JSONEncoder'),(json,'_default_decoder'),(json,'_default_encoder'),
    (json,'detect_encoding'),(json.decoder,'JSONObject'),(json.decoder,'JSONArray'),(json.decoder,'scanstring'),
    (json.decoder,'py_scanstring'),(json.decoder,'_decode_uXXXX'),(json.decoder,'_CONSTANTS'),
    (json.decoder,'BACKSLASH'),(json.decoder,'WHITESPACE'),(json.decoder,'WHITESPACE_STR'),(json.decoder,'STRINGCHUNK'),
    (json.decoder,'HEXDIGITS'),(json.scanner,'make_scanner'),(json.scanner,'c_make_scanner'),
    (json.scanner,'py_make_scanner'),(json.scanner,'NUMBER_RE'),(json.encoder,'c_make_encoder'),
    (json.encoder,'_make_iterencode'),(json.encoder,'encode_basestring'),(json.encoder,'encode_basestring_ascii'),
    (json.encoder,'py_encode_basestring'),(json.encoder,'py_encode_basestring_ascii'),(json.encoder,'ESCAPE_DCT'),
    (json.encoder,'ESCAPE'),(json.encoder,'ESCAPE_ASCII'),(json.encoder,'INFINITY'),
    (json.JSONDecoder,'__init__'),(json.JSONDecoder,'decode'),(json.JSONDecoder,'raw_decode'),
    (json.JSONEncoder,'__init__'),(json.JSONEncoder,'encode'),(json.JSONEncoder,'iterencode'),
    (json.JSONEncoder,'default'),(json.JSONEncoder,'item_separator'),(json.JSONEncoder,'key_separator'),
    (Image,'_getdecoder'),(Image,'_decompression_bomb_check'),(Image,'MAX_IMAGE_PIXELS'),(Image,'ID'),
    (Image,'core'),(Image.core,'zip_decoder'),(Image.core,'raw_decoder'),(Image.core,'new'),
    (Image,'getmodebase'),(Image,'getmodebands'),(Image,'preinit'),(Image,'init'),(ImageMode,'getmode'),
    (ImageFile,'_safe_read'),(ImageFile,'_tilesort'),(ImageFile,'LOAD_TRUNCATED_IMAGES'),
    (ImageFile,'MAXBLOCK'),(ImageFile,'SAFEBLOCK'),(ImageFile._Tile,'__new__'),
    (PngImagePlugin,'_accept'),(PngImagePlugin,'_MAGIC'),(PngImagePlugin,'MAX_TEXT_CHUNK'),
    (PngImagePlugin,'MAX_TEXT_MEMORY'),(PngImagePlugin,'_crc32'),(PngImagePlugin,'_safe_zlib_decompress'),
    (PngImagePlugin,'i16'),(PngImagePlugin,'i32'),(PngImagePlugin,'o8'),(PngImagePlugin,'o16'),(PngImagePlugin,'o32'),
    (_binary,'pack'),(_binary,'unpack_from'),(zlib,'crc32'),(zlib,'decompressobj'))
_PNG_CLASSES=(Image.Image,ImageFile.ImageFile,PngImagePlugin.PngImageFile,PngImagePlugin.PngStream,PngImagePlugin.ChunkStream)


def _png_policy(references):
    def token(value):return _token(value,references,set())
    # The real native original codec requires RGBA PNG. The known PNG opener
    # and C zip decoder remain the only cached dispatch, never a custom decoder.
    entry=Image.OPEN.get('PNG')
    if type(entry) is not tuple or len(entry)!=2 or entry[0] is not PngImagePlugin.PngImageFile:
        raise _Unsupported(type(entry),'png-opener')
    if 'zip' in Image.DECODERS:raise _Unsupported(type(Image.DECODERS['zip']),'png-custom-decoder')
    classes=[]
    for cls in _PNG_CLASSES:
        references.append(cls);references.append(cls.__bases__);members=[]
        for name,value in sorted(vars(cls).items()):
            if name.startswith('__') and name not in ('__init__','__new__','__enter__','__exit__','__getattr__'):continue
            members.append((name,token(value)))
        classes.append((id(cls),tuple(id(base) for base in cls.__bases__),tuple(members)))
    modes=PngImagePlugin._MODES
    if type(modes) is not dict or any(type(key) is not tuple or len(key)!=2 or any(type(item) is not int for item in key) for key in modes):
        raise _Unsupported(type(modes),'png-mode-table')
    return token(entry),tuple(classes),tuple((key,token(modes[key])) for key in sorted(modes))
"""
  after=after.replace(anchor,extra+anchor)
  needle='            return tuple(result),external\n';assert after.count(needle)==1
  after=after.replace(needle,"            location=('PIL.PNG','closed-policy');png=_png_policy(references)\n            return tuple(result),external,png\n")
  needle='        return output\n\n    def literal';assert after.count(needle)==1
  after=after.replace(needle,"        try:_png_policy([])\n        except _Unsupported as error:output.append(dict(module='PIL.PNG',member='closed-policy',type=error.kind,reason=error.reason))\n        except (AttributeError,TypeError,ValueError,RecursionError) as error:\n            output.append(dict(module='PIL.PNG',member='closed-policy',type=(type(error).__module__,type(error).__qualname__),reason='token-error'))\n        return output\n\n    def literal")
 if rel.endswith('test_ios_emote_callback_live_history_cache.py'):
  after+='''
    def test_changed_actual_immutable_source_metadata_bytes_binding_cannot_reuse_warm_history(self):
        from ios.adapters import world_web_keys
        self.assertIs(type(world_web_keys._ORIGINAL_SOURCE_METADATA),bytes);self.read()
        with patch.object(world_web_keys,'_ORIGINAL_SOURCE_METADATA',world_web_keys._ORIGINAL_SOURCE_METADATA+b'changed'):
            self.assertFalse(self.history.literal());self.read()
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())

    def test_mutable_bytearray_source_metadata_remains_unsupported_and_uses_literal_decoder(self):
        from ios.adapters import world_web_keys
        self.read()
        with patch.object(world_web_keys,'_ORIGINAL_SOURCE_METADATA',bytearray(world_web_keys._ORIGINAL_SOURCE_METADATA)):
            self.assertFalse(self.history.literal());self.read()
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())

    def test_actual_json_default_scanner_binding_change_cannot_borrow_warm_parsed_value(self):
        import json
        def parse():
            self.calls+=1;record(self.file);return json.loads(self.file.read_text())
        first=self.history.read(self.owner,self.reference,parse);self.assertEqual({'historical':'one'},first)
        self.assertEqual(2,self.calls)
        def changed(text,index):return {'declared':'changed-actual-json-parser'},len(text)
        with patch.object(json._default_decoder,'scan_once',new=changed):
            self.assertFalse(self.history.literal());actual=self.history.read(self.owner,self.reference,parse)
            self.assertEqual({'declared':'changed-actual-json-parser'},actual)
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())
        self.assertEqual(first,self.history.read(self.owner,self.reference,parse));self.assertEqual(3,self.calls)

    def test_same_png_parser_function_code_change_cannot_borrow_warm_original_pixels(self):
        from PIL import Image,PngImagePlugin
        self.file=self.root/'actual-decoder-original.png';Image.new('RGBA',(2,2),(20,30,40,255)).save(self.file)
        self.file.chmod(0o600)
        with Image.open(self.file) as image:image.load()
        self.history=CallbackLiveRecords();self.owner._historical_rows=self.history
        self.assertTrue(self.history.literal(),repr(self.history.unsupported_members()))
        def parse():
            self.calls+=1;record(self.file)
            with Image.open(self.file) as image:image.load();return image.tobytes()
        first=self.history.read(self.owner,self.reference,parse);self.assertEqual(2,self.calls)
        function=PngImagePlugin.PngImageFile._open;code=function.__code__
        def changed(self):raise RuntimeError('Declared changed actual PNG parser code')
        function.__code__=changed.__code__
        try:
            self.assertIs(PngImagePlugin.PngImageFile._open,function);self.assertFalse(self.history.literal())
            with self.assertRaisesRegex(RuntimeError,'Declared changed actual PNG parser code'):self.history.read(self.owner,self.reference,parse)
        finally:function.__code__=code
        self.assertEqual(3,self.calls);self.assertTrue(self.history.literal())
        self.assertEqual(first,self.history.read(self.owner,self.reference,parse));self.assertEqual(3,self.calls)
'''
 ast.parse(after,filename=rel);write(H/'base'/rel,before);write(H/'candidate'/rel,after)
 rows.append(dict(path=rel,baseSHA256=row['candidateSHA256'],candidateSHA256=hashlib.sha256(after.encode()).hexdigest()));diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='source19/'+rel,tofile='external/'+rel))
write(H/'external-parser-only.diff',''.join(diff))
external=[Path('/usr/lib64/python3.14/json')/name for name in ('__init__.py','decoder.py','scanner.py','encoder.py')]+[Path('/usr/lib64/python3.14/site-packages/PIL')/name for name in ('Image.py','ImageFile.py','PngImagePlugin.py','ImageMode.py','_binary.py')]
plan=dict(status='PRIVATE_UNRUN_SOURCE_REVIEW_REQUIRED',baseFreeze=sha(B/'freeze.json'),sourceRows=rows,actualUnsupported=['ios.adapters.world_web_keys','_ORIGINAL_SOURCE_METADATA'],actualCause='Actual _source_metadata marshal bytes singleton',externalSourcePins=[dict(path=str(p),sha256=sha(p)) for p in external],closedDependencies='JSONDecoder/JSONEncoder exact instance schemas +actual C scanner readonly fields and parser globals; actual RGBA PNG opener/class code/ZIP dispatch/mode table/binary CRC and byte/decode limits. Custom PNG decoder remains unsupported.',mechanismCases=23,testsRun=False,targetImports=False,SDKImported=False,old747RuntimeReplayForbidden=True,pendingReview='Static only; actual smoke diagnostics still required before mechanisms/new graph.')
write(H/'plan.json',json.dumps(plan,indent=2)+'\n');write(H/'freeze.json',json.dumps(dict(status=plan['status'],files={str(p.relative_to(H)):sha(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n');print(json.dumps(dict(packet=str(H),freeze=sha(H/'freeze.json'),sourceRows=rows,diffLines=sum(x.count('\n') for x in diff))))
