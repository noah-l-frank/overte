"""One closed historical publisher decode and the actual unpublished callback.

This never enters the live publisher factory, whose first operation would
require a new phase HTTP read. All original callbacks and DTOs remain literal.
"""
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import builtins,cProfile,hashlib,io,json,os,pstats,re,signal,socket,stat,subprocess,sys,time,traceback

ROOT=Path.cwd();RUNNER=Path(__file__).resolve();OUT=RUNNER.parent
JOB_STARTED=time.perf_counter()
BASE=ROOT/'.ios-host-tmp/avatar-genuine-actor-terminal-two-refs-launch03-20261027'
REVISION=os.environ.get('AVATAR_PROFILE_SOURCE_REVISION','')
if not re.fullmatch('[0-9a-f]{40}',REVISION):raise AssertionError('Exact predeclared source revision required')

def sources():
    files={p for p in (ROOT/'tests/device').rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
    files.update(p for p in (ROOT/'scripts').rglob('*.js') if p.is_file())
    files.update(p for p in (ROOT/'interface/resources/qml/hifi').rglob('*.qml') if p.is_file());files.add(RUNNER)
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}

BEFORE=sources();(OUT/'source-before.json').write_text(json.dumps(BEFORE,indent=2)+'\n')
from adapters.native_clock_join import digest
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as original_reads
from adapters.script_feature.history import unpack
from ios.adapters.avatar_ended_archive import FilesOnlyClient
from ios.adapters.avatar_feature import IOSAvatarFeature
from ios.adapters.avatar_runtime import IOSAvatarRuntime
from ios.adapters.avatar_witness_publisher import AvatarWitnessPublisher
from ios.adapters.emote_archive_lock import ArchiveSourceLock
from ios.adapters.emote_original_lease import EmoteOriginalLease

AUDIT_PATH=BASE/'timeout-actual-terminal-references.json';PINS_PATH=BASE/'timeout-poststop-originals-census.json'
AUDIT_BYTES=AUDIT_PATH.read_bytes();PINS_BYTES=PINS_PATH.read_bytes()
AUDIT=json.loads(AUDIT_BYTES);PINS=json.loads(PINS_BYTES);ROOTS=[Path(p) for p in PINS['retainedRoots']]
need(len(ROOTS)==5 and all(p.is_relative_to(BASE) for p in ROOTS) and PINS['originalFiles']==1204)

def census():
    result={}
    for root in ROOTS:
        for path in (root,*sorted(root.rglob('*'))):
            first=path.lstat();need(stat.S_ISREG(first.st_mode) or stat.S_ISDIR(first.st_mode))
            raw=None if stat.S_ISDIR(first.st_mode) else hashlib.sha256(path.read_bytes()).hexdigest()
            last=path.lstat();need(EmoteOriginalLease.signature(first)==EmoteOriginalLease.signature(last))
            result[str(path)]=[list(EmoteOriginalLease.signature(last)),raw]
    return result

ORIGINALS=census();need(ORIGINALS==PINS['originals'])
values={}
for root in ROOTS:
    for path in root.glob('ios-avatar-*-feature.json'):
        value=PrivateFeatureState(path).read();need(value['role'] not in values);values[value['role']]=(path,value)
need(set(values)=={'primary','actor'})
actor=values['actor'][1];run=actor['runId'];suffix='/runs/'+run+'/'
need(actor['fixtureUrl'].endswith(suffix));url=actor['fixtureUrl'][:-len(suffix)]
need(digest(actor)==AUDIT['actorFeatureSha256'])
selectors={value['selectors'][role]:path.with_name('session.json') for role,(path,value) in values.items()}
effects=[]

def forbidden(label):
    def refuse(*_args,**_kwargs):
        effects.append(label);raise AssertionError('Closed original profile forbids '+label)
    return refuse

base=SimpleNamespace(state_path=lambda selector:selectors[selector],_candidate_guard=forbidden('candidate'),
    _target=forbidden('target'),_scope=forbidden('SDK scope'),_binding=forbidden('binding'),
    read_session=forbidden('SDK read'),ensure_session=forbidden('SDK ensure'),invoke=forbidden('SDK invoke'))
runtime=IOSAvatarRuntime(base);client=FilesOnlyClient(url,'closed-avatar-original-profile-'+'a'*32)
locks={role:ArchiveSourceLock(path.with_name('script-feature-sources.lock')) for role,(path,_value) in values.items()}
os_open,io_open,builtin_open=os.open,io.open,builtins.open

def open_fd(path,flags,*args,**kwargs):
    if flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):return forbidden('writable os.open')()
    return os_open(path,flags,*args,**kwargs)

def read_open(function,path,mode='r',*args,**kwargs):
    if type(mode) is not str or any(flag in mode for flag in 'wax+'):return forbidden('writable open')()
    return function(path,mode,*args,**kwargs)

profiles={};stages=[];failure=None;complete=False;cold=None;began=time.perf_counter()
def terminated(_signal,_frame):raise TimeoutError('Fixed 180-second outer diagnostic terminated the closed traversal')
signal.signal(signal.SIGTERM,terminated)

def stage(label,function):
    profile=cProfile.Profile();profiles[label]=profile;started=time.perf_counter()
    print('Actual historical stage enter: '+label,flush=True)
    with original_reads(fresh=True) as membership:
        profile.enable(subcalls=False,builtins=False)
        try:return function()
        finally:
            profile.disable();stages.append(dict(stage=label,seconds=time.perf_counter()-started,
                totalSeconds=time.perf_counter()-began,membership=sorted(map(str,membership))))
            print('Actual historical stage exited: '+label+' seconds='+format(time.perf_counter()-started,'.3f'),flush=True)

try:
    with ExitStack() as stack:
        for lock in locks.values():stack.enter_context(lock.held())
        for owner,name,label in ((socket,'socket','network socket'),(subprocess,'Popen','process startup'),
                (PrivateFeatureState,'write','original write'),(PrivateFeatureState,'discard','original discard')):
            stack.enter_context(patch.object(owner,name,forbidden(label)))
        for name in ('unlink','remove','rename','replace','mkdir','rmdir','fork','forkpty','posix_spawn','posix_spawnp'):
            if hasattr(os,name):stack.enter_context(patch.object(os,name,forbidden('os.'+name)))
        stack.enter_context(patch.object(runtime,'_sources',forbidden('runtime SDK sources')))
        stack.enter_context(patch.object(os,'open',open_fd))
        stack.enter_context(patch.object(io,'open',lambda path,mode='r',*a,**k:read_open(io_open,path,mode,*a,**k)))
        stack.enter_context(patch.object(builtins,'open',lambda path,mode='r',*a,**k:read_open(builtin_open,path,mode,*a,**k)))
        started=time.perf_counter();flow=IOSAvatarFeature.archive(runtime,actor,client,locks);cold=time.perf_counter()-started
        need(flow.role=='actor' and flow.state['phase']=='terminal-ready')
        publisher_path=Path(AUDIT['publisherPath']);publisher=PrivateFeatureState(publisher_path).read()
        need(digest(publisher)==AUDIT['publisherSha256']);saved=unpack(publisher['payload'])[0]
        need(len(saved['records'])==3 and saved['pending'] is None)
        # Actual archive dispatch validates both old observations and the first
        # published terminal reference. No pending entry is manufactured.
        decoded=stage('actual-three-record-publisher-archive',lambda:AvatarWitnessPublisher.archive(publisher,
            store=PrivateFeatureState(publisher_path),binding=flow.state['bindings']['actor'],run=flow.run,
            area='avatar-people',fixture_url=flow.client.url,phase_instance=flow.state['phaseInstance'],
            validate_original=flow.terminal_witness_original))
        need(decoded==saved)
        second=AUDIT['secondActualKeptTerminalOriginal'];event=flow.kept(second['reference'])
        need(event in flow.state['cleanup'] and event['kind']=='final-observation'
            and event['references']==AUDIT['secondEventFinalReferences'])
        final_path=flow.root/('avatar-final-'+flow.run+'-actor-5.json');last=PrivateFeatureState(final_path).read()
        need(digest(last)==event['references'][-1]['sha256']);last_row=unpack(last['payload'])[0]
        # This is the original canonical callback immediately below
        # PhaseWitnessPublisher.original, before any intent/write/HTTP stage.
        derived=stage('actual-second-kept-terminal-callback',lambda:flow.terminal_witness_original(second))
        need(derived['public']['sequence']==last_row['sequence'] and derived['ticket']==last_row['ticket']
            and derived['acquisition']==last_row['acquisition'])
        need(saved['pending'] is None and not publisher_path.with_name(publisher_path.stem+'-4.json').exists())
        complete=True
except BaseException as error:
    failure=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
finally:
    after=sources();same_sources=after==BEFORE;same_originals=census()==ORIGINALS
    audit_unchanged=AUDIT_PATH.read_bytes()==AUDIT_BYTES and PINS_PATH.read_bytes()==PINS_BYTES
    (OUT/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
    report=dict(completedBothHistoricalStages=complete,failure=failure,stages=stages,
        seconds=time.perf_counter()-began,totalJobSeconds=time.perf_counter()-JOB_STARTED,
        preProfileSetupSeconds=began-JOB_STARTED,coldFeatureArchiveSeconds=cold,
        sourceRevision=REVISION,sourceFilesAndLauncher=len(after),
        allSourcesUnchanged=same_sources,originalFiles=1204,originalGraphSha256=digest(ORIGINALS),
        originalsUnchanged=same_originals,auditInputsUnchanged=audit_unchanged,forbiddenEffects=effects,
        actualPublishedTerminalReference=AUDIT['firstActualPublishedTerminal']['original'],
        actualSecondKeptReference=AUDIT['secondActualKeptTerminalOriginal'],
        originalCallbacksReplaced=False,liveFactoryInvoked=False,newPublicationAttempted=False,
        liveObserveQualified=False,twoPublishedTerminalReferencesQualified=False,sealEndQualified=False,
        wholeFeatureQualified=False,nativeCompiled=False,deviceQualified=False,
        boundary='Historical cold archive/callback over actual timeout graph; not the live API cache/budget context')
    (OUT/'profile-report.json').write_text(json.dumps(report,indent=2)+'\n')
    for name,profile in profiles.items():
        profile.dump_stats(str(OUT/(name+'.pstats')))
        pstats.Stats(profile).strip_dirs().sort_stats('cumulative').print_stats(35)
    print(json.dumps({k:v for k,v in report.items() if k not in ('stages','failure')},sort_keys=True),flush=True)
    if failure:print(json.dumps(failure),flush=True)
    if not (same_sources and same_originals and audit_unchanged and not effects):complete=False
sys.exit(0 if complete and failure is None else 1)
