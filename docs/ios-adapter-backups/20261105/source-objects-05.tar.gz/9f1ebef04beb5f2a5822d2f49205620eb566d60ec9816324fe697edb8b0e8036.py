"""Read-only pins/censuses for one saved-third historical diagnostic."""
from pathlib import Path
import hashlib,json,os,stat
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
PREP=Path(__file__).resolve().parent
REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()
PUBLIC_ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml')


def target(path):
    path=Path(path);assert path.resolve().is_relative_to(REPO);return path


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pin(path):
    path=Path(path);before=path.lstat();assert path.resolve(strict=True)==path and not path.is_symlink()
    assert stat.S_ISDIR(before.st_mode)or stat.S_ISREG(before.st_mode)
    value=dict(stat=[getattr(before,key)for key in FIELDS])
    if stat.S_ISREG(before.st_mode):value['sha256']=sha(path)
    assert value['stat']==[getattr(path.lstat(),key)for key in FIELDS];return value


def census(roots):
    value={}
    for root in roots:
        root=Path(root)
        for path in(root,*sorted(root.rglob('*'))):value[str(path)]=pin(path)
    return value


def model_census(roots):
    # Exact input schema used by the reviewed immutable diagnostic model.
    fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
    return {name:dict(stat=[row['stat'][FIELDS.index(key)]for key in fields],**({'sha256':row['sha256']}if 'sha256'in row else{}))
        for name,row in census(roots).items()}


def namespace():
    paths={REPO/'CMakeLists.txt'}
    for name in PUBLIC_ROOTS:
        root=REPO/name;assert root.is_dir()
        paths.update((root,*root.rglob('*')))
    assert all(p.resolve(strict=True)==p and not p.is_symlink()for p in paths)
    return sorted(str(p.relative_to(REPO))for p in paths)



def graphics_qualification():
    """Fresh frozen Pure5 result, never live/native or speed authority."""
    source=REPO/'.ios-host-tmp/emote-graphics-prefix-pure-original-source4-draft-20261104'
    packet=REPO/'.ios-host-tmp/root-emote-graphics-prefix-pure-source4-five-qualified-results-20261104'
    paths=set()
    for directory,expected in((source,'2defde9cfecd36ab93d56e2383071d6f5447c0ecf42f47e89dfbd683f6dd95e7'),(packet,'417c4054eda37dd1afbd66f91265353e78bb3dd21de7d606bd7bb97d343b1a3c')):
        assert sha(directory/'freeze.json')==expected;paths.add(directory/'freeze.json')
        rows=json.loads((directory/'freeze.json').read_text())['files']
        for name,row in rows.items():
            assert type(name)is str and not Path(name).is_absolute()and '..'not in Path(name).parts
            path=directory/name;assert path.resolve(strict=True)==path and sha(path)==row['sha256'];paths.add(path)
    proof=json.loads((packet/'results.json').read_text());child=proof['child'];terminal=proof['terminal']
    assert proof['productionSourceFreeze']=='2defde9cfecd36ab93d56e2383071d6f5447c0ecf42f47e89dfbd683f6dd95e7'
    assert proof['purePrefixCountersQualified']is True and proof['actualTests']==5 and proof['savedOriginalProbeQualified']is False
    assert child['status']=='PASS'and child['testsRun']==5 and not child['failures']and not child['errors']and not child['skips']
    selected=json.loads((source/'prospective-selectors.json').read_text())
    assert child['selected']==[selected['module']+'.'+selected['className']+'.'+name for name in selected['methods']]
    assert all(child[name]is True for name in('actualFDDrainEstablished','allActualCodeOriginsUnchanged','allPublicDependenciesUnchanged','originalBuiltinIOUnchanged','originalRegisteredCleanupEstablished','toolSlotsRestored'))
    assert not child['auditRefusals']and not child['remainingNewThreads']and not child['temporaryRootsRetained']
    assert terminal['status']=='PASS'and terminal['childReturnCode']==0 and terminal['allPinsUnchanged']and terminal['ownProcessesAbsent']and terminal['twoOwnClosedOutputCensusesEqual']
    assert not terminal['timedOut']and not terminal['forcedKill']and not terminal['rawRoots']and not terminal['temporaryRoots']
    assert proof['standardCleanup']['success']and proof['ports']['restored']and proof['ports']['actualCportCount']==27 and not proof['ports']['controlDescriptors']
    assert proof['parentDrain']['fdUnchanged']and proof['parentDrain']['threadsUnchanged']and not proof['kernelDrain']['remaining']
    for row in json.loads((packet/'actual-receipt-references.json').read_text()).values():
        path=Path(row['path']);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_relative_to(REPO/'.ios-host-tmp')and sha(path)==row['sha256'];paths.add(path)
    return paths

def sources():
    graphics_qualification()
    plan=json.loads((PREP/'plan.json').read_text());assert plan['status']=='FROZEN_UNRUN_REQUIRES_ROOT_REVIEW_AND_WINDOW'
    assert plan['repositoryRoot']==str(REPO)
    expected=json.loads((PREP/'immutable-source-pins.json').read_text())
    actual={name:pin(name)for name in expected};assert actual==expected,'Source/binary/Git/receipt identity changed'
    source_map=json.loads((PREP/'source-map.json').read_text());assert namespace()==source_map['publicNamespace']
    frozen=json.loads((PREP/'freeze.json').read_text())
    for name,digest in frozen['files'].items():
        path=target(PREP/name);assert sha(path)==digest,name;actual[str(path)]=pin(path)
    actual[str(PREP/'freeze.json')]=pin(PREP/'freeze.json')
    return actual


def input_guard():
    plan=json.loads((PREP/'plan.json').read_text())
    expected=json.loads((PREP/'input-graph-pins.json').read_text());actual=model_census(plan['oldInputRoots'])
    assert actual==expected,'Historical input namespace/metadata/bytes changed'
    locks=json.loads((PREP/'existing-lock-pins.json').read_text())
    assert locks and all(pin(name)==row and row['sha256']==hashlib.sha256(b'').hexdigest()and row['stat'][6]==0 for name,row in locks.items())
    return actual


def qualified_pass(stage):
    stage=Path(stage);report=json.loads((stage/'run/report.json').read_text());selected=json.loads((stage/'selected-result.json').read_text())
    selection=json.loads((stage/'case.json').read_text());plan=json.loads((PREP/'plan.json').read_text())
    assert report['exitCode']==0 and all(report[key]for key in('allPinsEqual','inputOriginalsUnchanged','existingLockInodesUnchanged',
        'diagnosticOutputUnchanged','globalOriginalsUnchanged','rootMapUnchanged'))and not report['remainingOwnedProcesses']
    assert selected['selectedIds']==[selection['case']]and selected['successful']and selected['testsRun']==1
    assert not any(selected[key]for key in('failureCount','errorCount','skippedCount'))
    receipt=json.loads((stage/'cleanup/receipt.json').read_text());assert receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']
    assert receipt['retainedRoots']==[]and receipt['case']==selection['case']and receipt['noSDK']and receipt['noSubprocess']and receipt['noNetwork']
    a=json.loads((stage/'cleanup/terminal-census-1.json').read_text());b=json.loads((stage/'cleanup/terminal-census-2.json').read_text())
    assert a==b and not any(a[key]for key in('threads','pendingTasks','sdkModules'))and a['children']==''
    assert json.loads((stage/'run/source-before.json').read_text())==json.loads((stage/'run/source-after.json').read_text())
    assert json.loads((stage/'run/input-before.json').read_text())==json.loads((stage/'run/input-first.json').read_text())==json.loads((stage/'run/input-second.json').read_text())==input_guard()
    first=json.loads((stage/'run/output-first.json').read_text());second=json.loads((stage/'run/output-second.json').read_text())
    output_roots=[stage/'diagnostic',stage/'cleanup',stage/'selected-result.json']
    assert first==second==census(output_roots)and report['outputFiles']==sum('sha256'in row for row in second.values())
    assert report['diagnosticFiles']==sum('sha256'in row for row in census([stage/'diagnostic']).values())
    expected_globals=json.loads((PREP/'global-original-corpus-baseline.json').read_text())
    assert expected_globals==json.loads((stage/'run/global-before.json').read_text())==json.loads((stage/'run/global-first.json').read_text())==json.loads((stage/'run/global-second.json').read_text())
    data=json.loads((stage/'diagnostic/diagnostic-result.json').read_text())
    assert data['status']=='ACTUAL_SAVED_THIRD_HISTORICAL_ONLY'and data['readMembership']>0
    assert all(data[key]is False for key in('nativeSDKHTTPNodeExecuted','currentMetadataOrClockRenewed','actualRuntimeCacheReconstructed',
        'stoppedWindowStackProved','completeLiveJournalQualified','freshnessQualified','wholeFeatureQualified'))
    for phase in('cold','warm'):
        value=json.loads((stage/'diagnostic'/(phase+'-actual-costs.json')).read_text())
        assert value['completed']and value['actualReadMembership']and (stage/'diagnostic'/(phase+'-partial-or-complete.pstats')).is_file()
    assert receipt['graphicsOverlayActualOriginChecked']is True and receipt['overlayFinderRestored']is True
    assert report['wholeFeatureQualified']is False and report['nativeQualified']is False
    return report
