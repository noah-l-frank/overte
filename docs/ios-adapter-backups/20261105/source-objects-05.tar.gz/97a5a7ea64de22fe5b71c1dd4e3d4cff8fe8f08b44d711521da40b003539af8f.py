"""Read-only pins/censuses for one saved-third historical diagnostic."""
from pathlib import Path
import hashlib,json,os,stat
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
PREP=Path(__file__).resolve().parent
REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()
PUBLIC_ROOTS=('tests/device','interface/src','libraries','ios','cmake','scripts/system','interface/resources/qml')


def target(path):
    path=Path(path);assert path.resolve().is_relative_to(REPO);return path


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pin(path):
    path=Path(path);before=path.lstat();assert path.resolve(strict=True)==path and not path.is_symlink()
    assert stat.S_ISDIR(before.st_mode)or stat.S_ISREG(before.st_mode)
    value=dict(stat=[getattr(before,key)for key in FIELDS])
    if stat.S_ISREG(before.st_mode):value['sha256']=sha(path)
    assert value['stat']==[getattr(path.lstat(),key)for key in FIELDS];return value


def census(roots):
    value={}
    for root in roots:
        root=Path(root)
        for path in(root,*sorted(root.rglob('*'))):value[str(path)]=pin(path)
    return value


def model_census(roots):
    # Exact input schema used by the reviewed immutable diagnostic model.
    fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
    return {name:dict(stat=[row['stat'][FIELDS.index(key)]for key in fields],**({'sha256':row['sha256']}if 'sha256'in row else{}))
        for name,row in census(roots).items()}


def namespace():
    paths={REPO/'CMakeLists.txt'}
    for name in PUBLIC_ROOTS:
        root=REPO/name;assert root.is_dir()
        paths.update((root,*root.rglob('*')))
    assert all(p.resolve(strict=True)==p and not p.is_symlink()for p in paths)
    return sorted(str(p.relative_to(REPO))for p in paths)


def sources():
    plan=json.loads((PREP/'plan.json').read_text());assert plan['status']=='FROZEN_UNRUN_REQUIRES_ROOT_REVIEW_AND_WINDOW'
    assert plan['repositoryRoot']==str(REPO)
    expected=json.loads((PREP/'immutable-source-pins.json').read_text())
    actual={name:pin(name)for name in expected};assert actual==expected,'Source/binary/Git/receipt identity changed'
    source_map=json.loads((PREP/'source-map.json').read_text());assert namespace()==source_map['publicNamespace']
    frozen=json.loads((PREP/'freeze.json').read_text())
    for name,digest in frozen['files'].items():
        path=target(PREP/name);assert sha(path)==digest,name;actual[str(path)]=pin(path)
    actual[str(PREP/'freeze.json')]=pin(PREP/'freeze.json')
    return actual


def input_guard():
    plan=json.loads((PREP/'plan.json').read_text())
    expected=json.loads((PREP/'input-graph-pins.json').read_text());actual=model_census(plan['oldInputRoots'])
    assert actual==expected,'Historical input namespace/metadata/bytes changed'
    locks=json.loads((PREP/'existing-lock-pins.json').read_text())
    assert locks and all(pin(name)==row and row['sha256']==hashlib.sha256(b'').hexdigest()and row['stat'][6]==0 for name,row in locks.items())
    return actual


def qualified_pass(stage):
    stage=Path(stage);report=json.loads((stage/'run/report.json').read_text());selected=json.loads((stage/'selected-result.json').read_text())
    selection=json.loads((stage/'case.json').read_text());plan=json.loads((PREP/'plan.json').read_text())
    assert report['exitCode']==0 and all(report[key]for key in('allPinsEqual','inputOriginalsUnchanged','existingLockInodesUnchanged',
        'diagnosticOutputUnchanged','globalOriginalsUnchanged','rootMapUnchanged'))and not report['remainingOwnedProcesses']
    assert selected['selectedIds']==[selection['case']]and selected['successful']and selected['testsRun']==1
    assert not any(selected[key]for key in('failureCount','errorCount','skippedCount'))
    receipt=json.loads((stage/'cleanup/receipt.json').read_text());assert receipt['actualStandardCaseRunReturned']and receipt['twoCensusesPassed']
    assert receipt['retainedRoots']==[]and receipt['case']==selection['case']and receipt['noSDK']and receipt['noSubprocess']and receipt['noNetwork']
    a=json.loads((stage/'cleanup/terminal-census-1.json').read_text());b=json.loads((stage/'cleanup/terminal-census-2.json').read_text())
    assert a==b and not any(a[key]for key in('threads','pendingTasks','sdkModules'))and a['children']==''
    assert json.loads((stage/'run/source-before.json').read_text())==json.loads((stage/'run/source-after.json').read_text())
    assert json.loads((stage/'run/input-before.json').read_text())==json.loads((stage/'run/input-first.json').read_text())==json.loads((stage/'run/input-second.json').read_text())==input_guard()
    first=json.loads((stage/'run/output-first.json').read_text());second=json.loads((stage/'run/output-second.json').read_text())
    output_roots=[stage/'diagnostic',stage/'cleanup',stage/'selected-result.json']
    assert first==second==census(output_roots)and report['outputFiles']==sum('sha256'in row for row in second.values())
    assert report['diagnosticFiles']==sum('sha256'in row for row in census([stage/'diagnostic']).values())
    expected_globals=json.loads((PREP/'global-original-corpus-baseline.json').read_text())
    assert expected_globals==json.loads((stage/'run/global-before.json').read_text())==json.loads((stage/'run/global-first.json').read_text())==json.loads((stage/'run/global-second.json').read_text())
    data=json.loads((stage/'diagnostic/diagnostic-result.json').read_text())
    assert data['status']=='ACTUAL_SAVED_THIRD_HISTORICAL_ONLY'and data['readMembership']>0
    assert all(data[key]is False for key in('nativeSDKHTTPNodeExecuted','currentMetadataOrClockRenewed','actualRuntimeCacheReconstructed',
        'stoppedWindowStackProved','completeLiveJournalQualified','freshnessQualified','wholeFeatureQualified'))
    for phase in('cold','warm'):
        value=json.loads((stage/'diagnostic'/(phase+'-actual-costs.json')).read_text())
        assert value['completed']and value['actualReadMembership']and (stage/'diagnostic'/(phase+'-partial-or-complete.pstats')).is_file()
    assert report['wholeFeatureQualified']is False and report['nativeQualified']is False
    return report
