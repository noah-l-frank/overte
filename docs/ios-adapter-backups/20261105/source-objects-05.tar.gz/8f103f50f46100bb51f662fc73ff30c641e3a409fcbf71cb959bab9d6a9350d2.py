"""Literal registry/REQUIRED byte projections. No imported validator or tests."""
from pathlib import Path
import json,ast,hashlib,difflib
R=Path.cwd();S=R/'.ios-host-tmp/audio-normal14-route-media-current-actor-union-staging2-private-20261104';O=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
candidate=S/'candidate/tests/device/contract-versions.json';new=load(candidate)
current=load(S/'base-current/tests/device/contract-versions.json');audio=load(S/'audio-addon-branch/tests/device/contract-versions.json');common=load(S/'base-addon/tests/device/contract-versions.json')
assert [len(d['contracts'])for d in(current,audio,common,new)]==[1503,1597,1491,1610]
updates=load(S/'REGISTRY-THREEWAY-UNION.json')['intentionalExistingUpdates'];assert set(updates)=={'ios-audio-passive-owner','ios-audio-passive-sdk-ledger','ios-lifecycle-editors'}
media={'current':1,'reads':[1]};media_name='ios-audio-ordinary-independent-originals'
additions={k:v for k,v in audio['contracts'].items()if k not in common['contracts']};assert len(additions)==106 and not(set(additions)&set(current['contracts']))
expected=json.loads(json.dumps(current));expected['contracts'].update(additions)
for name,row in updates.items():assert current['contracts'][name]==row['old'];expected['contracts'][name]=row['new']
expected['contracts'][media_name]=media;assert expected==new
actors={k:v for k,v in current['contracts'].items()if k not in common['contracts']};assert len(actors)==12
for k,v in actors.items():assert new['contracts'][k]==v
assert all(new[k]==current[k]==audio[k]==common[k]for k in ('schemaVersion','migrationRules'))
json_projections={}
for label,base,basepath in [('current1503',current,S/'base-current/tests/device/contract-versions.json'),('audio1597',audio,S/'audio-addon-branch/tests/device/contract-versions.json'),('common1491',common,S/'base-addon/tests/device/contract-versions.json')]:
 projected=dict(new,contracts={k:base['contracts'][k]if k in updates else new['contracts'][k]for k in new['contracts']if k in base['contracts']})
 assert projected==base
 text=json.dumps(projected,sort_keys=True,indent=2)+'\n';assert text==basepath.read_text(),label
 json_projections[label]=hashlib.sha256(text.encode()).hexdigest()

def required(p):
 t=ast.parse(p.read_text());n=next(n for n in t.body if isinstance(n,ast.Assign)and any(isinstance(x,ast.Name)and x.id=='REQUIRED'for x in n.targets));return t,n.value,ast.literal_eval(n.value)
p=S/'candidate/tests/device/validate_contract_versions.py';t,node,new_required=required(p)
assert len(new_required)==1610 and new_required=={k:v['current']for k,v in new['contracts'].items()}
text=p.read_text();lines=text.splitlines(True);starts=[];offset=0
for line in lines:starts.append(offset);offset+=len(line)
code_projections={}
for label,bp in [('current1503',S/'base-current/tests/device/validate_contract_versions.py'),('audio1597',S/'audio-addon-branch/tests/device/validate_contract_versions.py'),('common1491',S/'base-addon/tests/device/validate_contract_versions.py')]:
 base_t,_dict,base=required(bp);edits=[]
 for key,val in zip(node.keys,node.values):
  name=ast.literal_eval(key)
  if name not in base:edits.append((starts[key.lineno-1],starts[val.end_lineno-1]+len(lines[val.end_lineno-1]),''))
  elif ast.literal_eval(val)!=base[name]:
   assert name in updates
   edits.append((starts[val.lineno-1]+val.col_offset,starts[val.end_lineno-1]+val.end_col_offset,str(base[name])))
 out=text
 for a,b,s in sorted(edits,reverse=True):out=out[:a]+s+out[b:]
 assert out==bp.read_text(),label
 # Functions and migration behavior are original, not a broad dictionary guard.
 original_functions=[ast.dump(n,include_attributes=False)for n in ast.walk(base_t)if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
 current_functions=[ast.dump(n,include_attributes=False)for n in ast.walk(t)if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
 assert current_functions==original_functions
 code_projections[label]=hashlib.sha256(out.encode()).hexdigest()
# Every native current-to-union change is an insertion; no Actor line is lost.
native=[]
for name in ['interface/src/scripting/TestScriptingInterface.cpp','interface/src/scripting/TestScriptingInterface.h','tests/device/probe/overte_e2e_probe.js']:
 old=(S/'base-current'/name).read_text().splitlines(True);new_lines=(S/'candidate'/name).read_text().splitlines(True)
 ops=difflib.SequenceMatcher(a=old,b=new_lines,autojunk=False).get_opcodes();assert all(tag in('equal','insert')for tag,*_ in ops)
 native.append(dict(path=name,allCurrentActorLinesPreserved=True,candidateSha256=sha(S/'candidate'/name)))
v=dict(status='SOURCE_ONLY_EXACT_REGISTRY_AND_NATIVE_BYTE_PROJECTIONS',jsonByteProjections=json_projections,requiredByteProjections=code_projections,rows=[1503,1597,1491,1610],AudioAdditions=106,MediaAddition=1,ActorFamilies=12,existingUpdates=updates,allOther1500CurrentRowsAndReadsUnchanged=True,validatorFunctionASTsUnchanged=True,schemaAndMigrationRulesUnchanged=True,allThreeNativeCurrentToUnionChangesOnlyInsertions=native,tests=0,imports=0,builders=0,maps=0,censuses=0,targets=0)
(O/'REGISTRY-AND-NATIVE-READBACK.json').write_text(json.dumps(v,sort_keys=True,indent=2)+'\n');print(json.dumps(dict(registryAndRequiredExactProjections=3,currentRows=1503,AudioRows=1597,commonRows=1491,unionRows=1610,AudioAdditions=106,MediaAddition=1,ActorFamiliesPreserved=12,nativeOnlyInsertions=3)))
