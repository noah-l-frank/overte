"""One new CPU-accounted World Source5 unissued-input recovery and actual retirement slice; lower native/SDK/Qt/GPU are models."""
from pathlib import Path
from metadata_reader import pin,load
from closed_import_origins import ClosedOrigins
from host_common import head
from project_namespace_admission import project_namespace_admission
from world_node_port import WorldNodePort
from types import FrameType
import builtins,hashlib,importlib.abc,importlib.util,io,json,os,signal,stat,sys,tempfile,threading,time,traceback,unittest
HERE=Path(__file__).resolve().parent;REPO=Path.cwd().resolve(strict=True)
assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and(REPO/'.git').is_file()and sys.dont_write_bytecode
assert sys.flags.no_site==1, 'Explicit no-site startup required'
assert len(sys.argv)==3
INPUT=Path(sys.argv[1]);assert INPUT==HERE/'approved-inputs.json'and hashlib.sha256(INPUT.read_bytes()).hexdigest()==sys.argv[2]
plan=json.loads(INPUT.read_text());assert plan['controllerRoot']==str(HERE)and plan['repositoryRoot']==str(REPO)
assert plan['status']=='PRIVATE_WORLD_SOURCE5_UNCAPTURED_ACTION_RETIREMENT_FIRST1_UNRUN'
assert plan['cases']==json.loads((HERE/'exact-one-selector.json').read_text())
assert plan['NodeExecutions']==plan['maxTotalNodes']==plan['maxLiveNodes']==plan['maxNodePerCase']==1 and plan['SDKExecutions']==plan['physicalNativeQueries']==0
assert plan['declaredModelNativeObservationsAllowed']is True
assert plan['realNetwork']is False
assert plan['subjectHelperSha256']=='387e1133c5d1c07f45bad2b3611489dc81512d7ebedf6483f56efd708f01ffeb'
assert Path(plan['subjectActualCopiedPath'])==HERE/'closed_import_origins.py'
assert pin(HERE/'closed_import_origins.py')['sha256']==plan['subjectHelperSha256']
assert head()==plan['actualPublicHead']
assert len(plan['cases'])==len(set(plan['cases']))==1 and plan['wallSeconds']==300 and plan['killGraceSeconds']==5
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def fds():
    out={}
    for path in Path('/proc/self/fd').iterdir():
        try:v=path.stat();out[path.name]=dict(target=os.readlink(path),device=v.st_dev,inode=v.st_ino,mode=v.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return out
def children():return Path('/proc/self/task/'+str(os.getpid())+'/children').read_text()
def census(root):
    out={}
    for path in(root,*sorted(root.rglob('*'))):
        info=path.lstat();assert not path.is_symlink()
        if stat.S_ISDIR(info.st_mode):row=dict(stat=[getattr(info,k)for k in FIELDS],namespace=sorted(p.name for p in path.iterdir()))
        else:assert stat.S_ISREG(info.st_mode)and info.st_nlink==1;row=pin(path)
        out[str(path.relative_to(root))]=row
    return out
assert {p:pin(p)for p in plan['sourceAndBinaryPins']}==plan['sourceAndBinaryPins']
original_path=tuple(sys.path);original_meta=tuple(sys.meta_path);loaded={};td_callers=[]
bootstrap_names={'metadata_reader','host_common','closed_import_origins','world_node_port','raw_pipe_tee','project_namespace_admission'}
for name in(*plan['modules'],*plan['thirdPartyModules']):
    if name in bootstrap_names:
        actual=sys.modules[name]
        assert Path(vars(actual)['__file__'])==Path(plan['modules'][name]['path'])
        assert pin(Path(vars(actual)['__file__']))==plan['sourceAndBinaryPins'][vars(actual)['__file__']]
    else:assert name not in sys.modules
sys.path[:]=[p for p in sys.path if p and not Path(p).resolve().is_relative_to(REPO)]
tops={name.split('.')[0]for name in(*plan['modules'],*plan['namespaces'],*plan['thirdPartyModules'])}
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf','appium','selenium','playwright')
declared_aliases=dict(plan['modules'])
for name,row in plan['projectAliasAdmission']['unadmittedAliases'].items():
    assert name not in declared_aliases
    assert pin(row['origin']['path'])==plan['sourceAndBinaryPins'][row['origin']['path']]
    declared_aliases[name]=row['origin']
actual_aliases,actual_namespaces,actual_alias_admission=project_namespace_admission(declared_aliases,plan['orderedProjectRoots'])
assert actual_aliases==plan['modules']and actual_namespaces==plan['namespaces']and actual_alias_admission==plan['projectAliasAdmission']
origin_plan=plan['originPlan']
assert origin_plan['physicalPins']==plan['sourceAndBinaryPins']and origin_plan['modules']==plan['modules']
origins=ClosedOrigins(origin_plan,HERE,REPO,pin)
origin_before=origins.snapshot('before-utility-project-imports')
class AfterActualLoader(importlib.abc.Loader):
    def __init__(self,name,delegate):self.name,self.delegate=name,delegate
    def create_module(self,spec):return self.delegate.create_module(spec)
    def exec_module(self,module):
        self.delegate.exec_module(module)
        path=Path(vars(module)['__file__']);loaded[self.name]=str(path)
        assert pin(path)==plan['sourceAndBinaryPins'][str(path)]
        if self.name=='ios.self_tests.world_web_whole_fixture':
            node.bind(vars(module)['WholeSDK'],sys.modules['ios.self_tests.world_web_active_source_fixture'].ActiveSDK)
        if self.name=='ios.self_tests.test_ios_emote_marker_scope':
            cls=vars(module)['MarkerScopeTests'];setup=cls.__dict__['setUp']
            td_callers.append((cls,setup,setup.__code__,setup.__globals__))
class Finder(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name.split('.')[0]in forbidden:raise ImportError('Product SDK/browser package refused')
        row=plan['modules'].get(name)
        if row is not None:
            spec=origins.file_spec(name,dict(row,loader='source'),'project')
            spec.loader=AfterActualLoader(name,spec.loader);return spec
        if name in origin_plan['namespacePackages']:
            roots=origin_plan['namespacePackages'][name];origins.namespaces(name,roots,roots,'project')
            spec=importlib.machinery.ModuleSpec(name,None,is_package=True);spec.submodule_search_locations=roots;return spec
        if name in origin_plan['thirdPartyModules']or name in origin_plan['thirdPartyNamespacePackages']:return origins.remaining_spec(name,path)
        if name.split('.')[0]in tops:raise ImportError('Unmapped project/third-party import: '+name)
        return origins.remaining_spec(name,path)
finder=Finder();sys.meta_path.insert(0,finder)
TOYS=HERE/'temporary';RECEIPTS=HERE/'child-receipts'
assert TOYS.is_dir()and RECEIPTS.is_dir()and not any(TOYS.iterdir())and not any(RECEIPTS.iterdir())
assert os.environ['TMPDIR']==str(TOYS)and Path(tempfile.gettempdir())==TOYS
from owned_write_boundary import OwnedWrites
ports=('open','close','mkdir','unlink','remove','rmdir','rename','replace','chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')
original_ports={n:getattr(os,n)for n in ports if hasattr(os,n)};original_io=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
original_cleanup=unittest.TestCase.doCleanups;original_td=tempfile.TemporaryDirectory;original_time=time.time
protected=[INPUT,*map(Path,plan['sourceAndBinaryPins'])]
for fd in(1,2):
    path=Path(os.readlink('/proc/self/fd/'+str(fd)));assert path.resolve(strict=True)==path and path.is_relative_to(HERE);protected.append(path)
def proc(pid):
    try:raw=Path('/proc/'+str(pid)+'/stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    fields=raw[raw.rfind(')')+2:].split()
    assert int(raw[:raw.index('(')].strip())==pid
    return dict(pid=pid,parent=int(fields[1]),group=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))

boundary=OwnedWrites(HERE,protected=protected)
node=WorldNodePort(plan,HERE,pin,proc)
closed=False;tail_births={};tail_used=set()
def tail_write(path,value):
    assert closed and path in tail_births and path not in tail_used
    assert all(getattr(os,name)is original for name,original in original_ports.items())
    assert original_io==(io.open,builtins.open)and original_dup==(os.dup,os.dup2)
    assert pin(path)==tail_births[path]
    with original_io[0](path,'w',encoding='utf-8')as stream:
        json.dump(value,stream,sort_keys=True,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    tail_used.add(path)
tail_function=tail_write;tail_code=tail_write.__code__;tail_globals=tail_write.__globals__
original_metadata=sys.modules['metadata_reader']
metadata_pin=pin;metadata_pin_code=pin.__code__;metadata_pin_globals=pin.__globals__
metadata_open=type(boundary).__dict__['os_open'];metadata_open_code=metadata_open.__code__;metadata_open_globals=metadata_open.__globals__
metadata_read_flags=os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC
own_read_manifest=load(HERE/'readonly-own-public-source-verification.json')
assert own_read_manifest['version']==1 and own_read_manifest['publicRoot']==str(REPO/'tests/device/adapters/appium')
assert len(own_read_manifest['paths'])==8
own_read_rows=tuple((name,row['sha256'])for name,row in sorted(own_read_manifest['paths'].items()))
for name,digest in own_read_rows:
    path=Path(name);assert path.parent==REPO/'tests/device/adapters/appium'and path.resolve(strict=True)==path
    assert name in plan['sourceAndBinaryPins']and plan['sourceAndBinaryPins'][name]['sha256']==digest

def own_metadata_pin_read(args,caller):
    value,mode,flags=args
    if mode is not None or flags!=metadata_read_flags or type(value)not in(str,bytes):return False
    path=Path(os.fsdecode(value));name=str(path)
    if not any(name==approved and plan['sourceAndBinaryPins'][name]['sha256']==digest for approved,digest in own_read_rows):return False
    if not path.is_absolute()or path.resolve(strict=True)!=path or type(caller)is not FrameType:return False
    if (sys.modules.get('metadata_reader')is not original_metadata or original_metadata.pin is not metadata_pin or pin is not metadata_pin
            or metadata_pin.__code__ is not metadata_pin_code or metadata_pin.__globals__ is not metadata_pin_globals
            or metadata_pin_globals is not original_metadata.__dict__):return False
    frame=caller
    if caller.f_code is metadata_open_code:
        if (caller.f_globals is not metadata_open_globals or type(boundary).__dict__['os_open']is not metadata_open
                or metadata_open.__code__ is not metadata_open_code or metadata_open.__globals__ is not metadata_open_globals
                or caller.f_locals.get('self')is not boundary or caller.f_locals.get('path')!=path
                or caller.f_locals.get('flags')!=metadata_read_flags or caller.f_locals.get('dir_fd')is not None
                or boundary.original['open']is not original_ports['open']or os.open is not boundary.ports['open']):return False
        frame=caller.f_back
    elif os.open is not original_ports['open']:return False
    return(type(frame)is FrameType and frame.f_code is metadata_pin_code and frame.f_globals is metadata_pin_globals
        and frame.f_locals.get('path')==path)

def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Product SDK/browser import refused')
    if event=='subprocess.Popen':node.spawn(args,sys._getframe(1));return
    if event=='os.kill':node.signal(args,sys._getframe(1));return
    if event=='open'and type(args[0])is int and node.pipe_open(args,sys._getframe(1)):return
    if event.startswith('socket.')or event in('os.system','os.exec','os.posix_spawn','os.fork','os.forkpty','pty.spawn','ctypes.dlopen','os.killpg','os.setsid','os.setpgid')or event.startswith('os.spawn'):
        raise RuntimeError('Only one exact original World Node constructor; no real network/SDK/native/compiler or other child')
    if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
        path=os.fsdecode(args[0])
        if '/overte-ios-remotexpc/'in path or any('/'+name+'/'in path for name in forbidden):
            assert own_metadata_pin_read(args,sys._getframe(1)),'No vendor/installed SDK path, except exact independently pinned own-source reader'
    relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
    if not relevant:return
    if closed:
        if event=='open':
            value,mode,flags=args
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
            if not writing:return
            caller=sys._getframe(1);path=Path(value)if type(value)in(str,bytes)else None
            assert path in tail_births and path not in tail_used
            assert mode=='w'and flags==(os.O_WRONLY|os.O_CREAT|os.O_TRUNC|os.O_CLOEXEC)
            assert caller.f_code is tail_code and caller.f_globals is tail_globals and caller.f_locals.get('path')==path
            assert tail_function is tail_write and tail_function.__code__ is tail_code and tail_function.__globals__ is tail_globals
            assert pin(path)==tail_births[path]
            assert all(getattr(os,name)is original for name,original in original_ports.items())and original_io==(io.open,builtins.open)
            return
        raise RuntimeError('Mutation after actual original port restoration')
    boundary.audit(event,args,sys._getframe(1))
boundary.install();sys.addaudithook(audit)
from ios.self_tests.retained_host_roots import retain_owned_root
retained=[];retained_objects=[];cleanup_calls=[];scaffolds=[]
class RetainedTemporaryDirectory(original_td):
    def __init__(self,*args,**kwargs):
        frame=sys._getframe(1)
        matches=[(cls,setup,code,namespace)for cls,setup,code,namespace in td_callers
            if frame.f_code is code and frame.f_globals is namespace and type(frame.f_locals.get('self'))is cls]
        assert len(matches)==1 and not args and not kwargs,'Only the actual MarkerScopeTests.setUp default TD constructor'
        cls,setup,code,namespace=matches[0]
        assert cls.__dict__['setUp']is setup and setup.__code__ is code and setup.__globals__ is namespace
        super().__init__(dir=TOYS)
        root=Path(self.name);assert root.parent==TOYS and root.resolve(strict=True)==root
        retain_owned_root(self,expected_root=root);info=root.lstat();retained_objects.append(self)
        retained.append(dict(path=str(root),device=info.st_dev,inode=info.st_ino,
            actualConstructor=cls.__module__+'.'+cls.__qualname__,actualSetupFile=code.co_filename))
        scaffolds.append(dict(owner=frame.f_locals['self'],cls=cls,setup=setup,code=code,namespace=namespace,temporary=self,root=root,teardown=cls.__dict__['tearDown'],teardownCode=cls.__dict__['tearDown'].__code__))
def observe_original_cleanup(case):
    before=len(case._cleanups);outcome=case._outcome
    success_before=None if outcome is None else outcome.success
    result_before=None if outcome is None else outcome.result
    errors_before=[]if result_before is None else list(result_before.errors)
    failures_before=[]if result_before is None else list(result_before.failures)
    returned=None;raised=None
    try:
        returned=original_cleanup(case)
        return returned
    except BaseException as error:
        raised=type(error).__module__+'.'+type(error).__qualname__
        raise
    finally:
        after_outcome=case._outcome
        after_result=None if after_outcome is None else after_outcome.result
        same_result=after_result is result_before
        new_errors=[]if not same_result or after_result is None else after_result.errors[len(errors_before):]
        new_failures=[]if not same_result or after_result is None else after_result.failures[len(failures_before):]
        cleanup_calls.append(dict(case=type(case).__module__+'.'+type(case).__qualname__,pendingBefore=before,
            remaining=len(case._cleanups),originalReturned=returned,originalRaised=raised,
            outcomeSuccessBefore=success_before,outcomeSuccessAfter=None if after_outcome is None else after_outcome.success,
            actualResultReceiverSame=same_result,
            newCallbackErrors=[dict(id=test.id(),traceback=text)for test,text in new_errors],
            newCallbackFailures=[dict(id=test.id(),traceback=text)for test,text in new_failures],
            callbackErrorDeltaEstablished=same_result and after_result is not None,
            failedReturnRemainsFailed=returned is not True))
unittest.TestCase.doCleanups=observe_original_cleanup;tempfile.TemporaryDirectory=RetainedTemporaryDirectory

def save(name,body):
    p=RECEIPTS/name
    with p.open('x')as stream:stream.write(json.dumps(body,indent=2,sort_keys=True)+'\n')
    p.chmod(0o600)
fd_before=fds();threads_before=tuple(threading.enumerate());children_before=children()
case_receipts=[];selected=[];result=None;fatal=None;cleanup_rows=[];cleanup_ok=True;node_rescues=[];scaffold_rescues=[];passed=False
class Result(unittest.TextTestResult):
    def startTest(self,test):
        assert original_methods_unchanged()and tools_unchanged()
        origins.snapshot('before-standard-case-'+test.id())
        node.current_case=test.id()
        self.before=(fds(),tuple(threading.enumerate()),children(),len(cleanup_calls),len(retained));super().startTest(test)
    def stopTest(self,test):
        fd,threads,kernel,cleanup_count,roots=self.before
        origins.snapshot('after-standard-case-'+test.id())
        actual_node=node.finish_case(test.id())
        row=dict(actualNode=actual_node,id=test.id(),standardStopAfterCleanup=True,originalMethodsUnchanged=original_methods_unchanged(),monitorSlotsUnchanged=tools_unchanged(),remainingStandardCleanups=len(test._cleanups),
            fdUnchanged=fds()==fd,threadsUnchanged=tuple(threading.enumerate())==threads,kernelChildrenUnchanged=children()==kernel,
            actualNestedCleanupCalls=deepcopy_rows(cleanup_calls[cleanup_count:]),newTemporaryDirectories=len(retained)-roots)
        case_receipts.append(row);save('standard-case-'+str(len(case_receipts))+'.json',row);super().stopTest(test)
def deepcopy_rows(rows):return json.loads(json.dumps(rows))
method_seals=[]
def bind_original_methods():
    declarations=(
        ('closed_import_origins','ClosedOrigins',()),('closed_import_origins','PinnedDelegate',()),
        ('world_node_port','WorldNodePort',()),
        ('ios.self_tests.test_ios_emote_marker_scope','MarkerScopeTests',()),
        ('ios.self_tests.world_web_whole_fixture','WholeSDK',()),
        ('ios.self_tests.world_web_active_source_fixture','ActiveSDK',()),
        ('ios.adapters.world_web_sources','WorldWebSources',()),
        ('ios.adapters.world_web_input','WorldWebInput',()),
        ('ios.adapters.world_web_actions','WorldWebActions',()),
        ('ios.adapters.world_web_retirement','WorldWebRetirement',()),
        ('adapters.normal_ui','NativeUI',()),
        ('adapters.normal_feature_state','PrivateFeatureState',()),
        ('ios.self_tests.test_ios_world_web_uncaptured_input_recovery','WorldWebUncapturedActionRetirementTests',()))
    for module_name,class_name,names in declarations:
        module=sys.modules[module_name];cls=vars(module)[class_name]
        path=Path(vars(module)['__file__']);assert str(path)in plan['sourceAndBinaryPins']and pin(path)==plan['sourceAndBinaryPins'][str(path)]
        # Pin the full actual class-method table, including static control/
        # selector helpers transitively called by the explicit recipe methods.
        for name,member in cls.__dict__.items():
            function=member.__func__ if type(member)in(classmethod,staticmethod)else member
            if hasattr(function,'__code__'):
                method_seals.append((module,module_name,cls,class_name,name,member,function,function.__code__,function.__globals__))
def original_methods_unchanged():
    for module,module_name,cls,class_name,name,member,function,code,namespace in method_seals:
        assert sys.modules.get(module_name)is module and vars(module)[class_name]is cls and cls.__dict__[name]is member
        assert function.__code__ is code and function.__globals__ is namespace and namespace is vars(module)
    return True
assert sys.gettrace()is None and sys.getprofile()is None
monitor=sys.monitoring
monitor_ports=tuple((name,getattr(monitor,name))for name in('get_tool','get_events','set_events','get_local_events','set_local_events','register_callback','use_tool_id','free_tool_id'))
monitor_before=tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6))
def tools_unchanged():
    return (all(getattr(monitor,name)is port for name,port in monitor_ports)
        and monitor_before==tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6)))

monitor_tool=next((n for n in(5,4,3)if monitor.get_tool(n)is None),None)
assert monitor_tool is not None and monitor.get_events(monitor_tool)==0
monitor.use_tool_id(monitor_tool,'world-source5-genuine-node-constructor')
monitor.register_callback(monitor_tool,monitor.events.PY_START,node.constructor_start)
monitor.register_callback(monitor_tool,monitor.events.PY_RETURN,node.constructor_return)
constructor_code=node.popen.__init__.__code__
monitor.set_local_events(monitor_tool,constructor_code,monitor.events.PY_START|monitor.events.PY_RETURN)
# Expected tool occupancy is observed only while this controller owns its slot.
monitor_active=tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6))
original_tools_unchanged=tools_unchanged

def tools_unchanged():
    return all(getattr(monitor,name)is port for name,port in monitor_ports)and monitor_active==tuple((monitor.get_tool(n),monitor.get_events(n))for n in range(6))and monitor.get_local_events(monitor_tool,constructor_code)==(monitor.events.PY_START|monitor.events.PY_RETURN)

original_term=signal.getsignal(signal.SIGTERM)
def interrupted(*_args):raise KeyboardInterrupt('Fixed300-second first World Source5 action recovery boundary')
signal.signal(signal.SIGTERM,interrupted)
try:
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(plan['cases'])
    def flatten(suite):
        if isinstance(suite,unittest.TestSuite):
            for item in suite:yield from flatten(item)
        else:yield suite
    selected=list(flatten(suite));ids=[case.id()for case in selected]
    save('actual-selection.json',dict(ids=ids,loaderErrors=loader.errors));assert not loader.errors and ids==plan['cases']and suite.countTestCases()==1
    bind_original_methods();assert original_methods_unchanged()and tools_unchanged()
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
except BaseException:fatal=traceback.format_exc();print(fatal,flush=True)
finally:
    try:
        for case in selected:
            pending=len(case._cleanups);old=case._outcome;drain=unittest.TestResult();success=True
            try:
                if pending:case._outcome=unittest.case._Outcome(drain);success=observe_original_cleanup(case)
            except BaseException:success=False;print(traceback.format_exc(),flush=True)
            finally:case._outcome=old
            row=dict(id=case.id(),pendingBeforeOuter=pending,remaining=len(case._cleanups),success=success,
                errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],failures=[dict(id=t.id(),traceback=text)for t,text in drain.failures]);cleanup_rows.append(row)
            if not success or case._cleanups or drain.errors or drain.failures:cleanup_ok=False
        needs_node_rescue=node.pending is not None or any(row['process'].poll()is None or any(stream is not None and not stream.closed for stream in(getattr(row['process'],name,None)for name in('stdin','stdout','stderr')))for row in node.entries)
        if needs_node_rescue:
            cleanup_ok=False
            try:node.abort_all()
            except BaseException:node_rescues.append(dict(error=traceback.format_exc()))
            node_rescues.extend(node.controller_drains)
        # Constructor may fail before whole.close is registered. Only the
        # exact genuinely created scaffold/held context is released, and that
        # rescue is always separate negative evidence, never standard cleanup.
        for item in scaffolds:
            owner,cls=item['owner'],item['cls'];lock=getattr(owner,'lock',None)
            if lock is not None and getattr(lock,'_owner',None)is not None:
                cleanup_ok=False
                row=dict(root=str(item['root']),typedFailureRescue=True,standardCleanupEstablished=False)
                try:
                    assert type(owner)is cls and cls.__dict__['setUp']is item['setup']and item['setup'].__code__ is item['code']and item['setup'].__globals__ is item['namespace']
                    assert cls.__dict__['tearDown']is item['teardown']and item['teardown'].__code__ is item['teardownCode']
                    assert owner.temp is item['temporary']and owner.root==item['root']and lock.path==owner.root/'script-feature-sources.lock'
                    item['teardown'](owner);row['released']=lock._owner is None
                except BaseException:row['error']=traceback.format_exc()
                scaffold_rescues.append(row)
        for row in retained:
            root=Path(row['path']);info=root.lstat();assert root.parent==TOYS and(root.stat().st_dev,root.stat().st_ino)==(row['device'],row['inode'])
        nested_ok=all(row['originalReturned']is True and row['remaining']==0 for row in cleanup_calls)
        first=census(TOYS);second=census(TOYS)
        after={p:pin(p)for p in plan['sourceAndBinaryPins']}
        assert head()==plan['actualPublicHead']and pin(INPUT)['sha256']==sys.argv[2]
        origin_after=origins.snapshot('after-genuine-original-cleanups')
        passed=fatal is None and result is not None and result.testsRun==1 and result.wasSuccessful()and not result.skipped and cleanup_ok and nested_ok
        passed=passed and len(retained)==1 and len(case_receipts)==1 and all(row['remainingStandardCleanups']==0 and row['fdUnchanged']and row['threadsUnchanged']and row['kernelChildrenUnchanged']and row['newTemporaryDirectories']==1 and row['originalMethodsUnchanged']and row['monitorSlotsUnchanged']for row in case_receipts)
        passed=passed and after==plan['sourceAndBinaryPins']and fd_before==fds()and threads_before==tuple(threading.enumerate())and children_before==children()and first==second
        source_origins={}
        for name,expected in plan['subjectOriginModules'].items():
            module=sys.modules.get(name);actual=None if module is None else getattr(module,'__file__',None)
            source_origins[name]=dict(actualModulePresent=module is not None,actualModuleFile=actual,
                actualLoaderExecutedPath=loaded.get(name),expectedPath=expected['path'],expectedSha256=expected['sha256'],
                exactOriginMatched=actual==loaded.get(name)==expected['path'])
        origins_ok=len(source_origins)==plan['subjectOriginCount']==3 and all(row['exactOriginMatched']for row in source_origins.values())
        passed=passed and origins_ok and node.completed_cases==plan['cases']and len(node.entries)==1 and node.pending is None and not node_rescues and not scaffold_rescues and len(td_callers)==1 and original_methods_unchanged()and tools_unchanged()
        save('actual-all-loaded-origins-before.json',origin_before);save('actual-all-loaded-origins-after.json',origin_after)
        save('actual-source-model-origins.json',dict(subjectOrigins=source_origins,
            allThreeActualRuntimeOriginsEstablished=origins_ok,actualExecutedOrigins=loaded))
        save('actual-toy-first.json',first);save('actual-toy-second.json',second);save('outer-cleanup.json',dict(success=cleanup_ok,cases=cleanup_rows,nestedActualCalls=cleanup_calls,nestedActualCleanupSucceeded=nested_ok,nodeFailureRescue=node_rescues,scaffoldFailureRescue=scaffold_rescues))
        save('report.json',dict(status='PASS'if passed else'FAIL_OR_ERROR',testsRun=None if result is None else result.testsRun,
            actualCaseReceipts=len(case_receipts),fatal=fatal,cleanupEstablished=cleanup_ok and nested_ok,
            retainedTemporaryDirectories=retained,temporaryDirectoryAbsenceClaimed=False,fdUnchanged=fd_before==fds(),
            threadsUnchanged=threads_before==tuple(threading.enumerate()),kernelChildrenUnchanged=children_before==children(),
            pinsUnchanged=after==plan['sourceAndBinaryPins'],twoToyCensusesEqual=first==second,allActualLoadedOriginsAccounted=True,originSnapshots=origins.snapshot_count,
            declaredModelNativeObservationsAllowed=True,physicalNativeQueries=0,nativeCompiled=False,actualStdlibInterpreterExtensionsAllowed=True,realNetwork=False,actualNodeBirths=len(node.entries),NodeExecutions=1,SDKExecutions=0,nativeQualified=False,wholeQualified=False))
    finally:
        restoration_failures=[]
        def restore_attempt(name,function):
            try:return function()
            except BaseException:
                restoration_failures.append(dict(port=name,traceback=traceback.format_exc()));return None
        # Independent attempts: a failed monitor/origin check cannot prevent
        # another actual original cleanup/port restoration from being tried.
        restore_attempt('signal',lambda:signal.signal(signal.SIGTERM,original_term))
        restore_attempt('monitor-local-mask',lambda:monitor.set_local_events(monitor_tool,constructor_code,0))
        restore_attempt('monitor-start-callback',lambda:monitor.register_callback(monitor_tool,monitor.events.PY_START,None))
        restore_attempt('monitor-return-callback',lambda:monitor.register_callback(monitor_tool,monitor.events.PY_RETURN,None))
        restore_attempt('monitor-tool-id',lambda:monitor.free_tool_id(monitor_tool))
        tools_unchanged=original_tools_unchanged
        tempfile.TemporaryDirectory=original_td;unittest.TestCase.doCleanups=original_cleanup
        tools_restored=restore_attempt('actual-tool-alias-readback',lambda:tempfile.TemporaryDirectory is original_td and unittest.TestCase.doCleanups is original_cleanup and time.time is original_time and tools_unchanged())is True
        tail=RECEIPTS/'actual-port-restoration.json'
        def birth_tail():
            descriptor=os.open(tail,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
            try:assert stat.S_IMODE(os.fstat(descriptor).st_mode)==0o600
            finally:os.close(descriptor)
            tail_births[tail]=pin(tail)
            return True
        tail_born=restore_attempt('private-tail-birth',birth_tail)is True
        restore_attempt('original-27-ports-CIO',boundary.restore)
        restored=all(getattr(os,n)is v for n,v in original_ports.items())and original_io==(io.open,builtins.open)
        dup_restored=original_dup==(os.dup,os.dup2)
        restore_attempt('boundary-control-descriptor-close',boundary.close);closed=True
        sys.meta_path[:]=original_meta;sys.path[:]=original_path
        if tail_born:
            restore_attempt('postrestore-original-CIO-tail',lambda:tail_write(tail,dict(restored=restored,count=len(original_ports),
                controlDescriptors=sorted(boundary.control_fds),dupPortsRestored=dup_restored,toolsRestored=tools_restored,
                builtinsCioRestored=original_io==(io.open,builtins.open),restorationFailures=restoration_failures,
                actualC10cHelperSha256=pin(Path(__file__).with_name('closed_import_origins.py'))['sha256'])))
        if restoration_failures:
            passed=False
            print(json.dumps(dict(actualRestorationFailures=restoration_failures)),flush=True)

raise SystemExit(0 if passed and restored and tools_restored and dup_restored else 1)
