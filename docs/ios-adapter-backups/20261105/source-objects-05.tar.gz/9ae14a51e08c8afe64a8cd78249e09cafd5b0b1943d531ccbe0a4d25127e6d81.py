"""Prospective genuine frontdoor counters, UNRUN and producer prerequisites open.

No image compose call, neutral Scope or successful renderer/clock DTO substitutes
for Feature.observe→parts→Scope constructor→native/normal input→images.acquire.
Hostile copies never replace actual originals or their durable file references.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import hashlib
from copy import deepcopy
from adapters.normal_ui import NativeUIError
from lifecycle_moving_constructor_fixture import LifecycleMovingConstructorFixture


class LifecycleMovingConstructorOriginalModels(LifecycleMovingConstructorFixture):
    async def test_actual_feature_parts_scope_constructor_and_acquire_retain_complete_native_ui_file_png_originals(self):
        public,original,raw,snapshot=await self.acquire_through_feature()
        image=original['image'];self.assertTrue(snapshot['payload'])
        self.assertEqual(hashlib.sha256(raw).hexdigest(),image['frame']['capture']['source']['image']['sha256'])
        self.assertEqual(self.active_ticket,image['ticket']);self.assertEqual(1,len(self.frontdoor_calls))
        before=self.counts();again,name=await self.pure_image_original(image)
        self.assertEqual(raw,again);self.assertEqual(public['artifacts'][0]['name'],name);self.assertEqual(before,self.counts())

    async def test_actual_fourteenth_held_input_image_uses_fresh_native_motion_and_original_scope_before_independent_up(self):
        await self.acquire_through_feature()
        image=None
        for index in range(14):
            public,original,_raw,_snapshot=await self.actual_step(index)
            image=original['image']
        self.assertEqual(['forward'],public['state']['heldInputs'])
        first,last=image['frame']['worldBefore'],image['frame']['worldAfter']
        a=next(row for row in first['source']['bodies']['avatars']if row['self'])
        b=next(row for row in last['source']['bodies']['avatars']if row['self'])
        self.assertNotEqual(a['position'],b['position'])
        self.assertEqual(image['ticket'],self.active_ticket)
        # No expected pose, renderer, clock or success field is written. Actual
        # normal restoration/marker cleanup runs in the registered async cleanup.

    async def test_foreign_phase_ticket_copy_cannot_relabel_actual_capture_or_cause_a_fresh_query(self):
        _public,original,raw,_snapshot=await self.acquire_through_feature();image=original['image'];saved=deepcopy(image)
        hostile=deepcopy(image);hostile['ticket']='f'*32 if image['ticket']!='f'*32 else'e'*32
        before=self.counts()
        with self.assertRaises(NativeUIError):await self.pure_image_original(hostile)
        self.assertEqual(before,self.counts());self.assertEqual(saved,image);self.assertEqual(raw,(await self.pure_image_original(image))[0])

    async def test_renderer_or_parent_transform_hostile_copy_refuses_and_keeps_actual_complete_frame_bytes(self):
        _public,original,raw,_snapshot=await self.acquire_through_feature();image=original['image'];saved=deepcopy(image)
        for kind in('bounds','marker-parent'):
            hostile=deepcopy(image);frame=hostile['frame']
            if kind=='bounds':
                row=next(row for row in frame['renderersAfter']['source']['avatars']if row['self'])
                row.update(boundsReady=False,bounds=None)
            else:
                frame['worldAfter']['source']['markers'][0]['position'][0]+=1.
            before=self.counts()
            with self.assertRaises(NativeUIError):await self.pure_image_original(hostile)
            self.assertEqual(before,self.counts());self.assertEqual(saved,image)
        self.assertEqual(raw,(await self.pure_image_original(image))[0])

    async def test_changed_capture_clock_copy_cannot_be_retimed_into_the_existing_native_join(self):
        _public,original,_raw,_snapshot=await self.acquire_through_feature();image=original['image'];saved=deepcopy(image)
        for key in('requestedEpochMs','capturedEpochMs'):
            hostile=deepcopy(image);hostile['frame']['capture'][key]+=1;before=self.counts()
            with self.assertRaises(NativeUIError):await self.pure_image_original(hostile)
            self.assertEqual(before,self.counts());self.assertEqual(saved,image)
