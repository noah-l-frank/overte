from pathlib import Path
import ast,json,hashlib,difflib,textwrap
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';B=T/'lifecycle-original-owner-resource-borrow-proposal-20261028/candidate/repo';P=T/'lifecycle-original-owner-resource-consumer-proposal-20261028';P.mkdir(mode=0o700);h=lambda b:hashlib.sha256(b).hexdigest();rows=[];d=[]
def rep(s,a,b):assert s.count(a)==1,(a[:85],s.count(a));return s.replace(a,b,1)
def put(rel,base,s):
 b=base.read_bytes();q=P/'candidate/repo'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(s);ast.parse(s)
 rows.append(dict(path=rel,base=str(base),baseSHA256=h(b),candidate=str(q),candidateSHA256=h(q.read_bytes())))
 d.extend(difflib.unified_diff(b.decode().splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
rel='tests/device/ios/adapters/lifecycle_touch_resource_owner.py';base=B/rel;s=base.read_text()
# Reuse the SAME strict state/frame grammar for archive owner and passive DTO.
start=s.index('    def decode(self,value):');body_start=s.index('        exact(value,',start);body_end=s.index('        previous=None\n',body_start)
header=s[body_start:body_end].replace('self.binding','binding').replace('self.run','run')
header='def owner_header(value,binding,run):\n'+textwrap.dedent(header).replace('\n','\n    ')
# Preserve actual first-line indentation correctly, and return only validated DTO.
header='def owner_header(value,binding,run):\n'+textwrap.indent(textwrap.dedent(s[body_start:body_end].replace('self.binding','binding').replace('self.run','run')),'    ')+'    return state\n\n\n'
frame_start=s.index('    def frame(self,value,state=None,previous=None):');frame_body_start=s.index('        exact(value,',frame_start);frame_end=s.index('    def make_lease(',frame_body_start)
frame='def capture_original(value,state,previous=None):\n'+textwrap.indent(textwrap.dedent(s[frame_body_start:frame_end]),'    ')+'\n\n'
s=s[:body_start]+"        state=owner_header(value,self.binding,self.run)\n"+s[body_end:]
frame_start=s.index('    def frame(self,value,state=None,previous=None):');frame_end=s.index('    def make_lease(',frame_start)
s=s[:frame_start]+'''    def frame(self,value,state=None,previous=None):
        return capture_original(value,self.state if state is None else state,previous)
'''+s[frame_end:]
s=rep(s,'class LifecycleTouchResourceOwner:',header+frame+'class LifecycleTouchResourceOwner:');put(rel,base,s)
rel='tests/device/ios/pymobiledevice3_wda_xctest.py';base=B/rel;s=base.read_text();a='''            return dict(originalKeeperTouchResourceVersion=1,ownerInstance=self.instance,
                        capture=value,owner=owner,nativeTouchSupport=False,resourceRetirementEstablished=False)''';b='''            # Lossless transport through Node JSON: original uint64 device/
            # inode metadata stays inside canonical JSON TEXT, never JS Number.
            resource_json=json.dumps(dict(capture=value,owner=owner),sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
            if len(resource_json)>12288:raise LaunchError('request')
            return dict(originalKeeperTouchResourceVersion=2,ownerInstance=self.instance,
                        encoding='canonical-json-ascii',resourceJson=resource_json,
                        nativeTouchSupport=False,resourceRetirementEstablished=False)''';s=rep(s,a,b);put(rel,base,s)
rel='tests/device/ios/adapters/lifecycle_world_hold_runtime.py';base=R/rel;s=base.read_text();s=rep(s,'from adapters.native_feature_observation import need','from adapters.native_feature_observation import need,exact\nfrom copy import deepcopy\nimport hashlib\nfrom adapters.original_frame_store import OriginalFrameStore\nfrom adapters.script_feature.history import canonical\nfrom feature_journeys.contract import identifier,json_document')
a='    def production_child(self,selector,editors,attempt,*,configuration=None):'
b='''    def resource_metadata(self,selector,run,*,recover=False):
        """Read the original child's passive resource DTO, never borrow auth.

        Actual loop/Task/RSD objects remain in that child. This consumer opens
        no lease/session, grants no input or native-end/production admission.
        """
        from ios.adapters.lifecycle_touch_resource_owner import owner_header,capture_original
        identifier(run);need(type(recover) is bool)
        source=IOSScriptRuntime(self.adapter)._sources(selector);source['check']()
        operation='touch-resource-recover' if recover else 'touch-resource-capture'
        value=source['client'].execute(source['session'],'mobile: overteOriginalKeeperOperation',
                                      dict(operation=operation,args={}))
        source['check']()
        exact(value,{'originalKeeperTouchResourceVersion','ownerInstance','encoding','resourceJson',
                     'nativeTouchSupport','resourceRetirementEstablished'})
        need(type(value['originalKeeperTouchResourceVersion']) is int and value['originalKeeperTouchResourceVersion']==2
             and value['encoding']=='canonical-json-ascii' and type(value['resourceJson']) is str
             and len(value['resourceJson'])<=12288 and value['resourceJson'].isascii()
             and value['nativeTouchSupport'] is False and value['resourceRetirementEstablished'] is False)
        identifier(value['ownerInstance'])
        payload=json_document(value['resourceJson']);exact(payload,{'capture','owner'})
        need(value['resourceJson']==canonical(payload).decode('ascii'))
        state=owner_header(payload['owner'],source['binding'],run)
        need(state['pending'] is None and state['frames'])
        # Reuse existing reference codec and canonical original-body hash.
        # This checks DTO content correlation, NOT remote inode authority or
        # a local substitute for the child's original file/worker ownership.
        codec=OriginalFrameStore(self.adapter.state_path(selector).parent,source['binding'],run,'primary',
            source['check'],lambda *_:need(False),namespace='lifecycle-touch-resource',schema_prefix='iosLifecycleTouchResource')
        references=[codec.expand(ref) for ref in state['frames']]
        need([ref['index'] for ref in references]==list(range(1,len(references)+1)))
        capture=capture_original(payload['capture'],state);reference=references[-1]
        body=dict(iosLifecycleTouchResourceFrameVersion=1,kind='sources',binding=source['binding'],
                  runId=run,role='primary',index=reference['index'],frame=capture)
        raw=canonical(body)
        need(len(raw)==reference['bytes'] and hashlib.sha256(raw).hexdigest()==reference['sha256'])
        source['check']()
        return dict(originalKeeperTouchResourceVersion=2,ownerInstance=value['ownerInstance'],
                    capture=deepcopy(capture),owner=deepcopy(payload['owner']),
                    nativeTouchSupport=False,resourceRetirementEstablished=False)

'''+a
s=rep(s,a,b);put(rel,base,s)
(P/'proposal.diff').write_text(''.join(d));(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE CANONICAL PASSIVE RESOURCE CONSUMER UNRUN',files=rows,baseResourceBorrowFreeze='d1417c0657d73a9c865810cd497c3535b72975cba49d8e418945b2ed527ba8bd',productionChildAdmission=False,physicalRemoteInodeAuthority=False,actualSDKAuthObserved=False,nativeTouchSupport=False),indent=2)+'\n');print(json.dumps(rows,indent=2))
