"""Seventeen exact unprofiled classifier semantic cases; no writes, TDs or live authority."""
from pathlib import Path
import faulthandler,importlib,importlib.abc,importlib.machinery,importlib.util,json,os,signal,sys,sysconfig,threading,traceback,unittest
from metadata import HERE,REPO,RAW,ARTIFACT,ARTIFACT_SHA,load,save,pin,sha,census,proc,processes,fds,validate

assert Path.cwd()==REPO and sys.dont_write_bytecode
assert sys.getprofile()is None and sys.gettrace()is None,'Actual unprofiled/untraced semantic scope required'
assert sha(HERE/'freeze.json')==os.environ['CHAT_DISPATCH_EXPECTED_FREEZE']
plan=validate();approved=load('approved-source-map.json')
# Complete source/physical verification and independent IPA pin precede ALL
# candidate imports and all sender/receive header reads.
assert all(pin(Path(path))==row for path,row in approved.items())
assert pin(ARTIFACT)==load('input-originals-baseline.json')['tmp27bwiir_/candidate.ipa'] and sha(ARTIFACT)==ARTIFACT_SHA
assert census(RAW)==load('input-originals-baseline.json')
origins=load('absolute-module-origins.json');source_before=dict(approved)
project_tops={name.split('.',1)[0]for name in(*origins['modules'],*origins['namespaces'])}
old_path=list(sys.path);old_meta=list(sys.meta_path)
baseline_fds=fds();baseline_threads=set(threading.enumerate())
identity=proc(os.getpid());assert identity is not None and identity['group']==identity['session']
refusals=[];output_allowed=True;actual_origins={};cleanup=[];returned=False;result=None;case=None;cases=[];failure=None;diagnostic=None;coverage=None
outputs={'term-stack.log','child-result.json','child-input-first.json','child-input-second.json','child-output-first.json','child-output-second.json'}
forbidden={'pymobiledevice3','tidevice','pyidevice','zeroconf','selenium','playwright','appium','PySide6','PyQt6'}

def refuse(reason):
    refusals.append(reason);raise RuntimeError(reason)

def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:refuse('SDK/browser/vendor import refused')
    if event=='import'and args[0].split('.')[0]in project_tops and args[0]not in origins['modules']and args[0]not in origins['namespaces']:
        refuse('Project import absent from exact origin map')
    if event=='subprocess.Popen'or event.startswith('socket.')or event in(
            'os.system','os.exec','os.fork','os.forkpty','os.posix_spawn','os.spawn','ctypes.dlopen'):
        refuse('No network/Node/SDK/subprocess authority')
    if event=='fcntl.flock':refuse('Pure counters have no original lock or flock authority')
    if event=='open':
        value,mode,flags=args
        writing=isinstance(flags,int)and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if writing:
            if type(value)is not str or not os.path.isabs(value):refuse('No integer/relative writable-open authority')
            path=Path(value)
            if not(output_allowed and path.parent==HERE and path.resolve(strict=False)==path and path.name in outputs):
                refuse('No target write or original lock mutation authority')
    if event in('os.mkdir','os.remove','os.rmdir','os.chmod','os.chown','os.rename','os.link','os.symlink',
            'os.truncate','os.utime','os.chdir'):
        # Refuse the entire operation, including descriptor targets and every
        # dir_fd form. Pure models require no filesystem mutation at all.
        refuse('No filesystem/descriptor/dir_fd/cwd mutation or TD birth')
sys.addaudithook(audit)

class Origins(importlib.abc.MetaPathFinder):
    def find_spec(self,name,path=None,target=None):
        if name in origins['modules']:
            source=Path(origins['modules'][name]);assert pin(source)==approved[str(source)],name
            # Build from this one exact source. No cwd, sibling worktree,
            # arbitrary sys.path or unpinned alternate source is searched.
            return importlib.util.spec_from_file_location(name,source,
                submodule_search_locations=[str(source.parent)]if source.name=='__init__.py'else None)
        if name in origins['namespaces']:
            directory=origins['namespaces'][name]
            spec=importlib.machinery.ModuleSpec(name,loader=None,is_package=True)
            spec.submodule_search_locations=[directory];return spec
        if name.split('.')[0]in project_tops:
            refuse('Project module absent from absolute origin map')
        return None

sys.meta_path.insert(0,Origins())
stdlib=Path(sysconfig.get_path('stdlib')).resolve()
sys.path[:]=[p for p in sys.path if p and(str(p).endswith('.zip')or
    Path(p).resolve().is_relative_to(stdlib))and'site-packages'not in p and'dist-packages'not in p]
trace_stream=(HERE/'term-stack.log').open('x')

def stop(*_args):
    faulthandler.dump_traceback(file=trace_stream,all_threads=True)
    trace_stream.flush()
    raise KeyboardInterrupt('Fixed60+5 pure-suite supervisor stop; original stack captured')
signal.signal(signal.SIGTERM,stop)

try:
    assert len(plan['allowedSelectors'])==17 and plan['suiteFailfast']is True
    output_allowed=False
    def only(test):
        if isinstance(test,unittest.TestSuite):
            children=list(test);assert len(children)==1;return only(children[0])
        return test
    for selected in plan['allowedSelectors']:
        module_name,class_name,method_name=selected.rsplit('.',2)
        assert module_name in origins['modules'],'Only exact mapped test module imports'
        actual_module=importlib.import_module(module_name)
        loaded=unittest.defaultTestLoader.loadTestsFromName(class_name+'.'+method_name,actual_module)
        assert loaded.countTestCases()==1
        case=only(loaded);assert case.id()==selected;cases.append(case)
    assert len({item.id()for item in cases})==17
    suite=unittest.TestSuite(cases)
    assert sys.getprofile()is None and sys.gettrace()is None
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite);returned=True
    assert sys.getprofile()is None and sys.gettrace()is None
    if result.wasSuccessful()and result.testsRun==17 and not result.skipped:
        from ios.adapters import chat_archive_round
        actual=chat_archive_round._LAST_MODULE_DISPATCH.get()
        assert type(actual)is dict and actual['fastEntries']>0 and actual['mode']=='fresh-per-entry'
        coverage=json.loads(json.dumps(actual,allow_nan=False))
except BaseException as exc:
    failure=dict(type=type(exc).__name__,traceback=traceback.format_exc())
finally:
    output_allowed=True
    for case in cases:
        prior=case._outcome;drain=unittest.TestResult();pending=len(case._cleanups)
        try:
            if pending:case._outcome=unittest.case._Outcome(drain);unittest.TestCase.doCleanups(case)
        finally:case._outcome=prior
        cleanup.append(dict(id=case.id(),pendingBefore=pending,remaining=len(case._cleanups),
            errors=[dict(id=t.id(),traceback=text)for t,text in drain.errors],
            failures=[dict(id=t.id(),traceback=text)for t,text in drain.failures]))
    trace_stream.close()
    for name,module in tuple(sys.modules.items()):
        filename=getattr(module,'__file__',None)
        if filename:
            path=Path(filename).resolve()
            if path.is_relative_to(REPO):
                assert str(path)in approved and pin(path)==approved[str(path)],name
                assert origins['modules'].get(name)==str(path),name
                actual_origins[name]=str(path)
    sdk_absent=not any(name.split('.')[0]in forbidden for name in sys.modules)
    fd_after=fds();threads=[t.name for t in threading.enumerate()if t not in baseline_threads and t.is_alive()]
    remaining=[p for p in processes(identity['session'])if p['pid']not in(identity['pid'],identity['parentPid'])]
    first=census(RAW);second=census(RAW)
    assert all(pin(Path(path))==row for path,row in source_before.items())
    sys.path[:]=old_path;sys.meta_path[:]=old_meta
    save(HERE/'child-input-first.json',first);save(HERE/'child-input-second.json',second)
    # Fixed output membership, with complete bytes/inodes for every artifact
    # already closed at this point. These observer files and the still-open
    # parent log/result are not misrepresented as sealed producer originals.
    sealed={name:pin(HERE/name)for name in('term-stack.log','child-input-first.json','child-input-second.json')}
    save(HERE/'child-output-first.json',sealed)
    again={name:pin(HERE/name)for name in sealed};save(HERE/'child-output-second.json',again)
    clean=returned and result is not None and result.wasSuccessful()and result.testsRun==17 and not result.skipped
    clean=clean and coverage is not None and failure is None and not refusals and sdk_absent and not threads and not remaining and fd_after==baseline_fds
    clean=clean and first==second==load('input-originals-baseline.json')and sealed==again
    clean=clean and all(not row['remaining']and not row['errors']and not row['failures']for row in cleanup)
    save(HERE/'child-result.json',dict(successful=clean,diagnostic=diagnostic,coverage=coverage,standardRunReturned=returned,
        selectedIds=list(plan['allowedSelectors']),suiteFailfast=True,testsRun=None if result is None else result.testsRun,
        cleanup=cleanup,failure=failure,fdBefore=baseline_fds,fdAfter=fd_after,newThreads=threads,
        remainingOwned=remaining,refusals=refusals,sdkAbsent=sdk_absent,importedOrigins=actual_origins,
        projectTopLevelNamespaces=sorted(project_tops),originalHeldOpens=[],originalHeldFlocks=[],pureCounter=True,source17SemanticSuite=True,cProfileEnabled=False,actualProfileAbsent=sys.getprofile()is None,actualTraceAbsent=sys.gettrace()is None,
        inputCensusesEqual=first==second,inputUnchanged=first==load('input-originals-baseline.json'),
        sealedOutputCensusesEqual=sealed==again,profileOverheadIncluded=False,
        nativeQualified=False,wholeChatQualified=False,deviceQualified=False))
    print('CHAT_CURRENT_MODULE_COUNTER_TERMINAL',clean,flush=True)
if not clean:raise SystemExit(1)
