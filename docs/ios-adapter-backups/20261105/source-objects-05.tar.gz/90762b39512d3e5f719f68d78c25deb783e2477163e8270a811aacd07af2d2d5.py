from pathlib import Path
import ast,difflib,hashlib,json,shutil
R=Path.cwd();T=R/'.ios-host-tmp';D=T/'lifecycle-original-owner-passive-carrier-quiet-source-draft-20261028';P=T/'lifecycle-original-owner-passive-carrier-quiet-proposal-20261028';B=T/'lifecycle-original-owner-passive-thread-rpc-task11-root-preparation-20261028/45-native-passive11';H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();P.mkdir(mode=0o700)
checkpoint=json.loads((D/'checkpoint.json').read_text());rows=[]
for row in checkpoint['files']:
 src=Path(row['candidate']);assert H(src)==row['candidateSHA256'];rel=row['path'];assert H(R/rel)==row['baseSHA256'],rel
 base=P/'bases/repo'/rel;base.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,base)
 out=P/'candidate/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,out);rows.append(dict(path=rel,base=str(base),baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out)))
for name in ['test_native_passive_scope_models.py','test_native_motion_existing_rpc_models.py','test_native_motion_worker_scope_models.py','test_motion_selected_join_models.py','motion_reference_fixture.py','native_acquisition_fixture.py','native_file_fixture.py']:
 shutil.copyfile(B/name,P/name)
shutil.copyfile(D/'test_native_passive_carrier_models.py',P/'test_native_passive_carrier_models.py')
model=P/'test_native_passive_carrier_models.py';tree=ast.parse(model.read_bytes());cases=['test_native_passive_carrier_models.NativePassiveCarrierModels.'+n.name for cls in tree.body if isinstance(cls,ast.ClassDef) and cls.name=='NativePassiveCarrierModels' for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name.startswith('test_')];assert len(cases)==8
# Shared files are source-owned DELTA plans only. Every foreign byte is retained.
versions={'original-keeper-native-acquisition':(3,4),'original-keeper-native-acquisition-read':(1,2)}
newkeys=['original-keeper-passive-raw','original-keeper-passive-world-frame','ios-lifecycle-passive-raw-frame','ios-lifecycle-passive-raw-original','ios-lifecycle-passive-world-frame','ios-lifecycle-passive-world-original'];registry=[]
for rel in ['tests/device/contract-versions.json','tests/device/validate_contract_versions.py']:
 base=P/'bases/repo'/rel;base.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,base);s=base.read_text()
 if rel.endswith('.json'):
  for k,(old,new) in versions.items():
   literal='"'+k+'": {"current": '+str(old)+', "reads": '+str(list(range(1,old+1)))+'}'
   replacement='"'+k+'": {"current": '+str(new)+', "reads": '+str(list(range(1,new+1)))+'}'
   assert s.count(literal)==1,k;s=s.replace(literal,replacement)
  marker='    "original-keeper-native-acquisition-owner":';assert s.count(marker)==1
  insertion=''.join('    "'+k+'": {"current": 1, "reads": [1]},\n' for k in newkeys);s=s.replace(marker,insertion+marker)
  json.loads(s)
 else:
  for k,(old,new) in versions.items():
   literal='"'+k+'": '+str(old)+',';assert s.count(literal)==1;s=s.replace(literal,'"'+k+'": '+str(new)+',')
  marker='    "original-keeper-native-acquisition-owner":';assert s.count(marker)==1;s=s.replace(marker,''.join('    "'+k+'": 1,\n' for k in newkeys)+marker);ast.parse(s)
 out=P/'own-registry-plan/repo'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s);registry.append(dict(path=rel,base=str(base),baseSHA256=H(base),candidate=str(out),candidateSHA256=H(out),ownFamilies=list(versions)+newkeys))
(P/'source2.diff').write_text(''.join(''.join(difflib.unified_diff(Path(row['base']).read_text().splitlines(True),Path(row['candidate']).read_text().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path'])) for row in rows))
(P/'registry-own8.diff').write_text(''.join(''.join(difflib.unified_diff(Path(row['base']).read_text().splitlines(True),Path(row['candidate']).read_text().splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path'])) for row in registry))
(P/'test-plan.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',cases=cases,caseCount=8,initialSeconds=90,killAfterSeconds=5,expectedGenuineRoots=16,nodeExecution=False,targetImportsByAgent=False,scope='Actual selected source AST/HTTP/FD/bytes/WAL/chunk/runtime methods with explicit SDK/native/HID/physics producers; no authentication/native/whole qualification',beforeImport='Root current original source map/candidate/SDK/launcher hash+stat admission and FD/thread/child baseline, exact three namespace roots, real fixture-local TemporaryDirectory retention',terminal='Original SDK AFC reader/HTTP thread/capture Tasks/creator/WDA/socket/hostThread/server close+join before both retained file/stat/SHA+FD/task/thread/child censuses',priorFiles=2685,priorNote='Source frozen packets retain existing2519 plus Root45actualPASS166; Root-prep later snapshots original bytes/stat, no old Root43 childterminal qualification',defaultRegressions=['existing explicit passive11 unchanged','existing NativeAcq8 default1 unchanged'],productionGates=False),indent=2)+'\n')
(P/'README.txt').write_text('''Feature14: same-original-source passive held/released/strict four-quiet carrier chain.
PRIVATE Source2+8models UNRUN. Existing original child touch-native-acquire and
chunk-read operations, same client/runtime; no broker, Source, SDK session,
endpoint selector or input callback serialization. The existing canonical
production_child gate remains CLOSED. All five capability/end flags false.

Source keeper078af834 (Root45 PASS11) and runtimea00e71 base. Resource3c7426
unchanged. Source Root45 proof is 166actualfiles/11cases, not a qualification
transfer to this new code. Existing frozen source/model packets unchanged.

Query start epoch+monotonic and raw-read END epoch+monotonic are sampled at
actual original query entry / validated original read BEFORE SDK close/WAL/
transport return. Original endpoint stays exact on reread. Raw bytes+carriers
use existing OriginalFrameStore at StateRoot; query-WAL stores compact typed
refs only (existing PrivateFeatureState65536 limit unchanged). A source-local
opaque tuple+real source-defined guard mints ONLY inside actual native read;
weak original Source/RSD/creator/loop, exact query/function/membership, actual
completed capture Task+real finished HTTP Thread+original AFC-close are joined
on each physical reread. Observed unknown raw identity revokes that receipt.
Physical source/task ownership is not derived from JSON, nonce, stat or hashes.

Collector is serialized on its actual original-loop Task. Pair SDK Tasks are
born here, retained in existing Source query/read rows and awaited to real
return; cancellation/unknown saved ACK never becomes completion/adoption.
Holding/released phase comes from the original born lease+worker, not selector.
It records genuine held forward proof, then separate own-Up terminal proof,
then four distinct strictly later World packets. New quiet calls wait against
the unchanged preceding native After's ORIGINAL host end +1.05seconds and
query NEW World+NEW NativeAfter. Every adjacent existing validate_join remains
strict <1.5sec /250ms/native sequence/instance/PID/sourceTimes; no clock rewrite.
Lastfour native World originals must pass existing stationary>=3000ms.

Budget: original selected/prep/preDown/postDown16 +held3+released3+quiet4*2=30
queries, <=32; native file reads29<=32, original full acquisition frames remain3
and bound8 unchanged. No geometry is invented or repeatedly queried for later
passive cuts. No new continuous-native-freshness claim for a12second hold.
Raw/proof files each retain existing1MiB OriginalFrameStore cap. Query WAL is
refs/metadata, not an aggregate raw dump. Existing12000 escaped DTO/16384pipe/
4096chunk/5second historical transfer caps all unchanged. Host decoded DTOs
remain correlation/historical typed proof; cannot mint child's live receipt.

Eight real source-DI cases: complete held/released/fourquiet via actual host
methods+HTTP/AFC-model+files with30uniquequeries; samebyte carrier inode swap;
real stale endpoint; wrongphase selector without implicit release/newquery;
raw saved-ACKloss; joined saved-ACKloss; actual modeled AFC stat mismatch;
actual chunk truncation. Original modeled physics responds only to actual HID
Move, configured before first native capture; native clocks use existing real
elapsed producer mapping, no retained packet retime. Prospective90+kill5/16real
TD; Root owns all execution/PUB/registry8 hunks. No agent import or test run.

Remaining qualification: installed real native/SDK/physical HID/whole end and
canonical normal-journey production routing remain unqualified. Native endpoints
or transfer jitter which cannot meet unchanged strictjoin refuse. This source
connection alone is not a Feature14 complete verdict.
''')
for p in P.rglob('*.py'):ast.parse(p.read_bytes())
manifest=dict(status='PRIVATE_FROZEN_SOURCE2_MODELS8_UNRUN',files=rows,ownRegistryPlan=registry,modelSHA256=H(model),cases=8,initialSeconds=90,killAfterSeconds=5,genuineRoots=16,sourceDiffSHA256=H(P/'source2.diff'),registryDiffSHA256=H(P/'registry-own8.diff'),dependencies={'lifecycle-original-owner-passive-callback-thread-origin-overlay-20261028':H(T/'lifecycle-original-owner-passive-callback-thread-origin-overlay-20261028/freeze.json'),'lifecycle-original-owner-passive-thread-and-rpc-task-model-composition-20261028':H(T/'lifecycle-original-owner-passive-thread-and-rpc-task-model-composition-20261028/freeze.json')},canonicalGate=False,nativeTouchSupport=False,actualAuthenticationQualified=False)
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(P/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_UNRUN',files={str(p.relative_to(P)):H(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n');print(json.dumps(dict(packet=str(P),freeze=H(P/'freeze.json'),source=rows,models=H(model),diff=H(P/'source2.diff'),registry=H(P/'registry-own8.diff')),indent=2))
