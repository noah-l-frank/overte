"""Connected actual normal input route for all29 Assets action slots.

The independent activated phase chooses the next exact scenario input. Existing
SDK bindings, held episode locks and child WALs own every actual effect. Input
ACKs neither complete actions nor supply target/peer/image/file observations;
the engine's existing consumed seam commits only after those consumers finish.
No whole capability, fixture service or Domain process is started here.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextlib import ExitStack
from pathlib import Path
import time
from adapters.asset_backend_client import AssetsBackendClient
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same,unpack
from feature_journeys.contract import arguments,result,typed_equal
from ios.adapters.assets_action_phase import AssetsActionPhases,AssetsActionScope
from ios.adapters.assets_backend_owner import OwnedAssetsBackend
from ios.adapters.assets_budget import operation
from ios.adapters.assets_born_page_lease import BornAssetsPageLease
from ios.adapters.assets_controls import project
from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
from ios.adapters.assets_episodes import AssetsEpisodes,AssetsEpisodeScope
from ios.adapters.assets_generation_page_inventory import archive_generation_page
from ios.adapters.assets_generation_runtime import GenerationActionAssetsRuntime
from ios.adapters.assets_page_birth import AssetsPageBirth
from ios.adapters.assets_page_generations import AssetsPageGenerations,AssetsPageGenerationContext
from ios.adapters.assets_page_generation_recovery import reconstruct_page_generations
from ios.adapters.assets_page_generation_runtime import PageGenerationAssetsRuntime
from ios.adapters.assets_permission_actions import AssetsPermissionActions
from ios.adapters.assets_shared_action_runtime import SharedActionAssetsRuntime
from ios.adapters.assets_step_consumer import AssetsStepConsumer
from ios.adapters.assets_usage_controls import project as usage_controls
from ios.adapters.assets_whole_picker import open_only,choose_only,select_unavailable_only

BIRTHS={2:1,4:2,14:3,18:4,24:5}
EPISODES={2:1,3:1,4:2,5:2,6:2,7:2,8:2,9:2,10:2,11:2,12:2,13:2,
          14:3,15:3,16:3,17:3,18:4,19:4,20:4,21:4,22:4,23:4,
          24:5,25:5,26:5,27:5,28:5,29:5}
VIEW_ACTIONS=frozenset((10,11,12,13,17,23))


class AssetsWholeInput:
    def __init__(self,adapter,selected,actions,episodes,*,backend_config,permission_client,
                 episode_scopes=(),monotonic=time.monotonic,epoch_ms=lambda:time.time()*1000):
        need(type(actions) is AssetsActionPhases and not actions.historical and actions.selected is selected
            and type(episodes) is AssetsEpisodes and episodes.selected is selected and episodes.locks==actions.locks
            and type(episode_scopes) is tuple and callable(monotonic) and callable(epoch_ms))
        self.adapter,self.selected,self.actions,self.episodes=adapter,selected,actions,episodes
        self.backend_config,self.monotonic,self.epoch_ms=backend_config,monotonic,epoch_ms
        self.scopes=list(episode_scopes);self.new_leases=ExitStack();self.closed=False
        ready=[entry for entry in episodes.state['entries'] if entry['phase']=='ready']
        need([scope.index for scope in self.scopes]==list(range(1,len(ready)+1))
            and len(episodes.state['entries'])-len(ready)<=1)
        for scope in self.scopes:
            need(type(scope) is AssetsEpisodeScope and scope.owner is episodes)
            for lock in scope.locks.values():lock.assert_held()
        self.root=Path(selected.context['roles']['primary']['stateRoot']);self.selector=selected.context['roles']['primary']['target']
        self.run,self.url=selected.run,selected.context['fixtureUrl'];self.generations=None;self.last=None
        self.permissions=AssetsPermissionActions(actions,permission_client,
            PrivateFeatureState(self.root/('ios-assets-write-actions-'+self.run+'.json')))
        self.guard()
    def guard(self):
        need(not self.closed);self.selected.selected_guard();self.actions.guard();self.episodes.guard()
        need(self.actions.state is not None and same(self.actions.envelope(),self.actions.previous)
            and same(self.actions.store.read(),self.actions.previous))
        for scope in self.scopes:
            scope.guard()
            for lock in scope.locks.values():lock.assert_held()
        return True
    def release_local_leases(self):
        # This releases Python flock custody only. It does not retire native,
        # server, page, marker, image or selected-pair responsibilities.
        self.new_leases.close();self.closed=True
    def refresh(self):
        self.generations=reconstruct_page_generations(self.episodes,self.actions,tuple(self.scopes),live=True)['owner']
        return self.generations
    def _runtime(self,action,scope=None):
        kwargs=dict(assets_action=action,phase=self.actions.phase,episode=scope,monotonic=self.monotonic,epoch_ms=self.epoch_ms)
        if scope is None:return SharedActionAssetsRuntime(self.adapter,self.selected,**kwargs)
        return PageGenerationAssetsRuntime(self.adapter,self.selected,generations=self.generations,**kwargs)
    def _arguments(self,scope):return (self.selector,self.run,'primary',self.url,scope.locks['primary'])
    def _scope(self,action):
        index=EPISODES[action.index]
        if index>len(self.scopes):
            need(BIRTHS.get(action.index)==index and index==len(self.scopes)+1)
            entries=self.episodes.state['entries']
            if len(entries)<index:scope=self.episodes.begin(index,action.ticket)
            else:
                need(len(entries)==index and entries[-1]['ticket']==action.ticket)
                scope=self.episodes.finish_birth(index)
            self.new_leases.enter_context(scope.held());self.scopes.append(scope)
        need(len(self.scopes)>=index);scope=self.scopes[index-1]
        if action.index in BIRTHS:need(scope.descriptor['ticket']==action.ticket)
        return scope
    def _view(self,action,scope):
        generation={2:2,3:3,4:4}[scope.index];old=generation-1;contexts=self.generations.contexts
        members=tuple(member for member in self.scopes if member.index in {1:(1,2),2:(3,),3:(4,)}[old])
        report=archive_generation_page(self.episodes,old,contexts[old].birth,members)
        graph=AssetsEpisodeModelGraph(scope,report['owner'],actions=self.actions,dependency_mode=True).decode()
        runtime=GenerationActionAssetsRuntime(self.adapter,self.selected,assets_action=action,phase=self.actions.phase,
            episode=scope,generation=contexts[generation].birth,origin_graph=graph,generations=self.generations,
            episode_scopes=tuple(self.scopes),monotonic=self.monotonic,epoch_ms=self.epoch_ms)
        return runtime,runtime.generation_components(*self._arguments(scope))
    def _open(self,action):
        runtime=self._runtime(action);parts=runtime._assets_sources(self.selector,self.actions.locks['primary'])
        birth=AssetsPageBirth(self.selected,PrivateFeatureState(self.root/('ios-assets-page-birth-'+self.run+'-primary.json')),
            self.actions.locks['primary'],action,parts['native'],parts['clock_source'],monotonic=self.monotonic)
        if birth.state is None:birth.reserve()
        birth.open()
        page=BornAssetsPageLease(self.episodes,PrivateFeatureState(self.root/('ios-assets-page-lease-'+self.run+'-primary.json')),
            self.actions.locks['primary'],birth=birth,monotonic=self.monotonic)
        if page.state is None:page.reserve()
        if page.state['pending'] is not None:page.recover_capture()
        if page.state['origin'] is None:page.attach_birth()
        store=PrivateFeatureState(self.root/('ios-assets-page-generations-'+self.run+'-primary.json'));saved=store.read()
        contexts={}
        if saved is not None:
            rows=unpack(saved['payload']);need(len(rows)==1 and len(rows[0]['entries'])<=1)
            if rows[0]['entries']:contexts={1:AssetsPageGenerationContext(birth,page)}
        generations=AssetsPageGenerations(self.episodes,self.actions,store,contexts=contexts)
        if generations.state is None:generations.reserve()
        generations.attach_initial(birth,page);self.generations=generations
        return runtime,dict(parts,page_birth=birth,page_lease=page)
    @operation
    def act(self,call):
        arguments('feature.assets.act',call);self.guard()
        need(call['runId']==self.run and call['fixtureUrl']==self.url)
        pending=self.actions.state['pending'];index=len(self.actions.state['records'])+1
        need(index<=29 and typed_equal(dict(verb=call['verb'],inputs=call['inputs']),self.actions.plan()[index-1]))
        if pending is None:action=self.actions.begin(index,call['ticket'],call['verb'],call['inputs'])
        else:
            need(pending['index']==index and pending['ticket']==call['ticket'] and pending['after'] is None and pending['original'] is None)
            action=AssetsActionScope(self.actions,index,call['ticket']);action.guard()
        if index==1:runtime,parts=self._open(action)
        else:
            scope=self._scope(action)
            # Birth of a later file episode changes the actual canonical page
            # skeleton membership; reconstruct it with the same held scopes.
            self.refresh();runtime=self._runtime(action,scope);args=self._arguments(scope)
            if index in VIEW_ACTIONS:
                runtime,parts=self._view(action,scope)
                if index in (10,12):
                    runtime.generation_browse(parts);tree=parts['tree']
                    tree.once_selected(tree.delete_prefix(),'permission-owned-root')
                    self.permissions.apply(action,parts['generation_view'])
                elif index==11:
                    runtime.generation_browse(parts);tree=parts['tree']
                    tree.once_selected(tree.delete_prefix(),'denied-owned-root')
                    packet=parts['generation_view'].capture();self.permissions._effective(packet,parts['generation_view'],False)
                    # Disabled Delete has no normal native input authority.
                    # Exact independent mapping read proves no owned deletion.
                    view=parts['generation_view'];replies=view.reply_owner('generation-delete-denied',create=True)
                    jobs=[job for job in replies.state['jobs'] if job['slot']=='generation-delete-denied']
                    if not jobs:proof=replies.read('generation-delete-denied')
                    elif jobs[0]['phase']=='issued':proof=replies.recover('generation-delete-denied')
                    else:need(jobs[0]['phase']=='complete');proof=replies.proof('generation-delete-denied')
                    tree.baseline(proof);current=view.capture()
                    need(0<=current['sampleEpochMs']-proof['captured']['epochMs']<=1500)
                    self.permissions._effective(current,view,False)
                else:runtime.generation_delete(parts)
            elif index in (9,16,22):
                parts=runtime.normal_remove_reenter(*args,self.backend_config,episode_scopes=tuple(self.scopes))
                self.generations=runtime.assets_generations
                runtime,parts=runtime.generation_view_components(*args,parts,episode_scopes=tuple(self.scopes))
            elif index in (4,14):
                parts=runtime._assets_prepare_unbaked_upload(*args[:4],action.ticket,args[4],self.backend_config,resource=call['inputs']['resource'])
            elif index in (8,15):
                parts=runtime._assets_unbaked_components(*args,self.backend_config);runtime._assets_import_unbaked(parts)
            elif index==18:parts=runtime._assets_stage_fbx_upload(*args[:4],action.ticket,args[4],self.backend_config)
            elif index==19:
                parts=runtime._assets_components(*args)
                parts['backend']=OwnedAssetsBackend(parts['upload'],AssetsBackendClient(self.backend_config,parts['check']),
                    runtime._assets_store(self.selector,self.run,'primary','backend'),lock=scope.locks['primary'])
                runtime._assets_stage_baking_off(parts)
            elif index==20:
                parts=runtime._assets_baking_components(*args,self.backend_config);runtime._assets_stage_baking_on(parts,action.ticket)
            elif index==21:
                parts=runtime._assets_parsed_components(*args,self.backend_config);runtime._assets_stage_import_baked(parts,action.ticket)
            elif index==29:parts=runtime.close_final_page(*args)
            else:
                parts=runtime._assets_components(*args);files,picker=parts['owned_files'],parts['picker']
                if index in (2,24):
                    if files.state is None:files.reserve(action.ticket,call['inputs']['resource'])
                    need(files.state['ticket']==action.ticket and files.state['resource']==call['inputs']['resource'])
                    if files.state['phase']=='reserved':files.stage()
                    elif files.state['phase']=='staging':files.recover_stage()
                    need(files.state['phase']=='staged');open_only(picker)
                elif index in (3,28):picker.cancel_owned();picker.retire_inputs()
                elif index==25:choose_only(picker)
                elif index==26:
                    if files.state['phase']=='staged':files.retire_primary()
                    else:need(files.state['phase'] in ('retiring-primary','primary-retired'));files.recover_primary()
                    need(picker.state['phase']=='primary-chosen')
                elif index==27:select_unavailable_only(picker)
                elif index in (5,6):
                    tree=parts['tree']
                    if tree.state is None:tree.reserve()
                    if tree.state['phase']=='reserved':tree.finish_browse() if tree.state['reads'] else tree.browse()
                    if index==6:
                        if tree.state['phase']=='browsed':tree.rename()
                        elif tree.state['phase']=='renaming':tree.finish_rename()
                        need(tree.state['phase']=='renamed')
                    else:need(tree.state['phase']=='browsed')
                elif index==7:
                    usage=parts['usage'];runtime._assets_stage_select(parts)
                    actual=usage_controls(usage.capture(),parts['upload'].state['page'])
                    need(not actual['baking']['enabled'] and not actual['baking']['checked'])
                else:need(False)
        self.last=dict(index=index,ticket=action.ticket,runtime=runtime,parts=parts)
        # Performed confirms this exact actual ordinary input route only.
        # Actions.pending stays active throughout every external consumer.
        return result('feature.assets.act',dict(performed=True))
    @operation
    def input_ownership(self):
        self.guard()
        from ios.adapters.assets_whole_ownership import inspect_whole_inputs
        return inspect_whole_inputs(self.episodes,self.actions,tuple(self.scopes),self.permissions)

    @operation
    def cleanup_normal(self):
        self.guard()
        from ios.adapters.assets_cleanup_phase import AssetsCleanupPhase
        from ios.adapters.assets_whole_cleanup import AssetsWholeCleanup
        owner=AssetsCleanupPhase(self.selected,self.actions,self.episodes,
            PrivateFeatureState(self.root/('ios-assets-cleanup-phase-'+self.run+'.json')),self.actions.locks,monotonic=self.monotonic)
        cleanup=AssetsWholeCleanup(self,owner);self.last_cleanup=cleanup
        return cleanup.normal()

    @operation
    def consumed(self,event):
        self.guard();need(event['runId']==self.run)
        if self.last is not None and self.last['index']==event['stepIndex'] and self.last['ticket']==event['ticket']:
            parts=self.last['parts'];runtime=self.last['runtime']
            if 'generation_view' in parts:consumer=runtime.generation_step_consumer(parts)
            else:consumer=AssetsStepConsumer(self.actions,page_generations=self.generations,episode_scopes=tuple(self.scopes))
        else:
            # A newly constructed coordinator uses immutable originals only;
            # reconstruction never sends act again for an already saved action.
            from ios.adapters.assets_whole_recovery import whole_step_consumer
            consumer=whole_step_consumer(self.episodes,self.actions,tuple(self.scopes))
        value=consumer(event);self.last=None;self.refresh();return value
