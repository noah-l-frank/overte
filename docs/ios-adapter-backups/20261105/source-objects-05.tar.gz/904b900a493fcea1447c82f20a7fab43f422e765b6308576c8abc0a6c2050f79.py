"""Original stdlib socket frames and exact toy dup/dup2 receivers only."""
import _socket,http.server,os,socket,socketserver,stat,sys,threading

class UtilityPorts:
    def __init__(self):
        self.main=threading.current_thread();self.active=None;self.subject=None;self.sockets=[];self.binds=[];self.reverse_reads=[];self.duplicates=[];self.redirects=[]
        self.socket_class=socket.socket;self.c_fileno=_socket.socket.fileno;self.c_name=_socket.socket.getsockname
        self.c_option=_socket.socket.getsockopt;self.c_family=_socket.socket.family;self.c_type=_socket.socket.type
        self.fstat=os.fstat;self.real_dup=os.dup;self.real_dup2=os.dup2
        self.tcp_init=socketserver.TCPServer.__init__;self.tcp_bind=socketserver.TCPServer.server_bind
        self.http_bind=http.server.HTTPServer.server_bind;self.fqdn=socket.getfqdn;self.reverse=socket.gethostbyaddr
        self.frames=tuple((fn,fn.__code__,fn.__globals__)for fn in(self.tcp_init,self.tcp_bind,self.http_bind,self.fqdn))
        self.wrapper_ports=()
    def bind_subject(self,subject):
        assert self.subject is None;self.subject=subject
        self.case_class=subject.ScopedPortNegativeTests
        self.case_functions={name:(fn,fn.__code__,fn.__globals__)for name,fn in self.case_class.__dict__.items()if name.startswith('test_')or name=='actual_server'}
    def check(self):
        assert threading.current_thread()is self.main
        assert socket.socket is self.socket_class and socket.getfqdn is self.fqdn and socket.gethostbyaddr is self.reverse
        assert socketserver.TCPServer.__init__ is self.tcp_init and socketserver.TCPServer.server_bind is self.tcp_bind
        assert http.server.HTTPServer.server_bind is self.http_bind and os.fstat is self.fstat
        for fn,code,namespace in self.frames:assert fn.__code__ is code and fn.__globals__ is namespace
        if self.subject is not None:
            for name,(fn,code,namespace)in self.case_functions.items():
                assert self.case_class.__dict__[name]is fn and fn.__code__ is code and fn.__globals__ is namespace
        if self.wrapper_ports:
            assert os.dup is self.wrapper_ports[0]and os.dup2 is self.wrapper_ports[1]
    def selected_frame(self,frame,name):
        self.check();assert self.active is not None and self.subject is not None
        fn,code,namespace=self.case_functions[name]
        return frame.f_code is code and frame.f_globals is namespace and frame.f_locals.get('self')is self.active
    def ancestor(self,frame,name):
        for unused in range(16):
            if frame is None:return None
            if self.selected_frame(frame,name):return frame
            frame=frame.f_back
        return None
    def signature(self,sock,bound=False):
        assert type(sock)is self.socket_class
        assert int(self.c_family.__get__(sock))==int(socket.AF_INET)
        assert self.c_option(sock,socket.SOL_SOCKET,socket.SO_TYPE)==socket.SOCK_STREAM
        assert int(self.c_type.__get__(sock))&0xf==int(socket.SOCK_STREAM)
        fd=self.c_fileno(sock);info=self.fstat(fd);assert stat.S_ISSOCK(info.st_mode)
        address=self.c_name(sock)
        if bound:assert address[0]=='127.0.0.1'and type(address[1])is int and address[1]>0
        return fd,info.st_dev,info.st_ino,info.st_mode,address
    def audit(self,event,args,caller):
        self.check()
        first='test_actual_same_socket_object_foreign_fd_inode_is_rejected_and_descriptor_restored'
        if event=='socket.__new__':
            owner,family,kind,protocol=args
            assert threading.current_thread()is self.main and family==socket.AF_INET and kind==socket.SOCK_STREAM and protocol in(0,socket.IPPROTO_TCP)
            assert self.ancestor(caller,'actual_server')is not None or self.ancestor(caller,first)is not None
            assert not any(owner is previous for previous in self.sockets);self.sockets.append(owner);return
        if event=='socket.bind':
            owner,address=args;assert any(owner is previous for previous in self.sockets)
            assert address==('127.0.0.1',0);self.signature(owner)
            original=caller.f_code is self.tcp_bind.__code__ and caller.f_globals is self.tcp_bind.__globals__
            if original:
                assert caller.f_locals['self'].socket is owner and self.ancestor(caller,'actual_server')is not None
            else:assert self.selected_frame(caller,first)
            self.binds.append(dict(case=self.active.id(),socket=owner,address=address));return
        if event=='socket.gethostbyaddr':
            assert caller.f_code is self.fqdn.__code__ and caller.f_globals is self.fqdn.__globals__
            parent=caller.f_back;assert parent is not None and parent.f_code is self.http_bind.__code__ and parent.f_globals is self.http_bind.__globals__
            server=parent.f_locals['self'];assert self.ancestor(parent,'actual_server')is not None
            sock=server.socket;assert any(sock is previous for previous in self.sockets)
            signature=self.signature(sock,True);assert args==('127.0.0.1',)and caller.f_locals.get('name')=='127.0.0.1'
            self.reverse_reads.append(dict(case=self.active.id(),numericHost=args[0],descriptor=signature[0],device=signature[1],inode=signature[2],address=signature[4],scopedOriginalHostResolverRead=True));return
        raise RuntimeError('No utility connect/datagram/foreign socket or resolver port admitted')
    def redirected_frame(self,frame):
        name='test_actual_same_socket_object_foreign_fd_inode_is_rejected_and_descriptor_restored'
        assert self.selected_frame(frame,name)
        v=frame.f_locals;scope=v['scope'];row=v['row'];sock=v['sock'];destination=v['descriptor']
        assert type(scope)is self.subject.FixturePorts and row in scope.servers and row[3]is sock and scope.c_fileno(sock)==destination
        assert any(sock is previous for previous in self.sockets)
        return v,row,sock,destination
    def install(self):
        assert not self.wrapper_ports
        def duplicate(fd):
            values,row,sock,destination=self.redirected_frame(sys._getframe(1))
            assert type(fd)is int and fd==destination and self.signature(sock,True)==row[4]
            result=self.real_dup(fd);info=self.fstat(result)
            assert(info.st_dev,info.st_ino)==row[4][1:3]
            self.duplicates.append(dict(case=self.active.id(),descriptor=result,device=info.st_dev,inode=info.st_ino));return result
        def redirect(source,destination,*,inheritable=True):
            values,row,sock,expected=self.redirected_frame(sys._getframe(1));assert type(source)is int and type(destination)is int and destination==expected and inheritable is True
            actual=self.fstat(source);foreign=values['foreign'];saved=values['saved']
            assert type(foreign)is self.socket_class and any(foreign is previous for previous in self.sockets)
            if source==saved:
                assert any(r['descriptor']==saved and(r['device'],r['inode'])==(actual.st_dev,actual.st_ino)for r in self.duplicates)
                assert(actual.st_dev,actual.st_ino)==row[4][1:3]
            else:assert source==self.c_fileno(foreign)and(actual.st_dev,actual.st_ino)==self.signature(foreign,True)[1:3]
            before=self.fstat(destination)
            assert(before.st_dev,before.st_ino)in(row[4][1:3],self.signature(foreign,True)[1:3])
            result=self.real_dup2(source,destination,inheritable=inheritable);after=self.fstat(destination)
            assert(after.st_dev,after.st_ino)==(actual.st_dev,actual.st_ino)
            self.redirects.append(dict(case=self.active.id(),source=source,destination=destination,beforeDevice=before.st_dev,beforeInode=before.st_ino,device=after.st_dev,inode=after.st_ino));return result
        os.dup,os.dup2=duplicate,redirect;self.wrapper_ports=(duplicate,redirect)
    def restore(self):
        self.check();os.dup,os.dup2=self.real_dup,self.real_dup2;self.wrapper_ports=()
        assert os.dup is self.real_dup and os.dup2 is self.real_dup2
    def terminal(self):
        assert all(self.c_fileno(sock)==-1 for sock in self.sockets)
        for row in self.duplicates:
            try:info=self.fstat(row['descriptor'])
            except OSError as error:assert error.errno==9
            else:assert(info.st_dev,info.st_ino)!=(row['device'],row['inode']),'Original duplicate remains live'
        return dict(actualCreatedSockets=len(self.sockets),allActualSocketObjectsClosed=True,actualSocketBinds=len(self.binds),originalHostResolverReads=self.reverse_reads,
            actualDuplicateDescriptors=self.duplicates,actualRedirectEvents=self.redirects,duplicateOriginalsAbsent=True,dupPortsRestored=os.dup is self.real_dup and os.dup2 is self.real_dup2)
