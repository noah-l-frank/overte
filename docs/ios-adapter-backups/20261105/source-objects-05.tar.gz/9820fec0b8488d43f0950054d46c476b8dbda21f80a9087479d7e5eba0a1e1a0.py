"""Single-use60+5 passive namespace microprobe supervisor. Review/authorization required before invocation."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
from metadata import HERE,REPO,RAW,load,save,sha,pin,census,source_guard,validate,global_roots,global_census,proc,processes

assert Path.cwd()==REPO and sys.dont_write_bytecode
assert len(sys.argv)==2 and sys.argv[1]==sha(HERE/'freeze.json'),'Exact reviewed suite freeze required'
expected_freeze=sys.argv[1];plan=validate();selected='fixed-actual-namespace-microprobe'
assert len(plan['allowedSelectors'])==1 and plan['suiteFailfast']is True
assert plan['publicHead']=='00fafcc4c097552198456c7e7687f243801d3ed8'
assert not(HERE/'report.json').exists()and not(HERE/'test.log').exists(),'No unchanged retry'
before=source_guard();input_before=census(RAW);assert input_before==load('input-originals-baseline.json')
roots=global_roots();assert sorted(map(str,roots))==sorted(load('global-originals-baseline.json'))
global_before=global_census(roots);assert global_before==load('global-originals-baseline.json')
save(HERE/'source-before.json',before);save(HERE/'input-before.json',input_before)
initial_membership=set(p.name for p in HERE.iterdir())
env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONPATH='',CHAT_DISPATCH_EXPECTED_FREEZE=expected_freeze)
host=load('host-executable-pins.json')
command=[host['timeout']['path'],'--signal=TERM','--kill-after=5s','60s',host['python']['path'],'-B',str(HERE/'run-one.py')]
started=time.monotonic()
with(HERE/'test.log').open('x')as log:
    task=subprocess.Popen(command,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    bound=proc(task.pid);assert bound is not None and bound['group']==bound['session']==task.pid
    save(HERE/'process-binding.json',dict(supervisor=proc(os.getpid()),task=bound,command=command));code=task.wait()
remaining=processes(task.pid)
if remaining:
    save(HERE/'remaining-owned-processes.json',remaining)
    raise RuntimeError('Own process absence required; no foreign process is stopped')
# Target stdout and all child artifacts are now closed. They are measured twice
# outside the target process. No output baseline is relabeled as an input one.
runtime_outputs={'test.log','process-binding.json','term-stack.log','child-result.json',
    'child-input-first.json','child-input-second.json','child-output-first.json','child-output-second.json'}
assert set(p.name for p in HERE.iterdir())<=initial_membership|runtime_outputs
assert all(p.is_file()and not p.is_symlink()for p in HERE.iterdir()),'No new directory/TD/rawroot admitted'
output_paths={p.name:p for p in HERE.iterdir()if p.name in runtime_outputs}
output_first={name:pin(p)for name,p in sorted(output_paths.items())}
input_first=census(RAW);global_first=global_census(roots)
output_second={name:pin(p)for name,p in sorted(output_paths.items())}
input_second=census(RAW);global_second=global_census(roots)
assert not processes(task.pid)
after=source_guard();membership_unchanged=roots==global_roots()
save(HERE/'output-first.json',output_first);save(HERE/'output-second.json',output_second)
save(HERE/'input-first.json',input_first);save(HERE/'input-second.json',input_second)
save(HERE/'global-first.json',global_first);save(HERE/'global-second.json',global_second)
save(HERE/'source-after.json',after)
child=load('child-result.json')if(HERE/'child-result.json').exists()else None
qualified=code==0 and child is not None and child['successful']and child['standardRunReturned']and child['testsRun']==1
qualified=qualified and before==after and input_before==input_first==input_second and global_before==global_first==global_second
qualified=qualified and output_first==output_second and membership_unchanged and not processes(task.pid)
save(HERE/'report.json',dict(qualifiedMicroprobe=qualified,source17dFreeze=plan['source17dFreeze'],expectedNamespaces=180,semanticSuiteSelected=False,selectedId=selected,exitCode=code,seconds=time.monotonic()-started,
    fixedBudgetSeconds=60,killGraceSeconds=5,originalFiles=41,sourcePins=len(before),globalRoots=len(roots),
    allSourcePinsEqual=before==after,inputUnchanged=input_before==input_first==input_second,
    allGlobalOriginalsUnchanged=global_before==global_first==global_second,globalMembershipUnchanged=membership_unchanged,
    outputCensusesEqual=output_first==output_second,remainingOwnedProcesses=processes(task.pid),
    childQualified=child is not None and child['successful'],profileOverheadIncluded=False,
    wholeChatQualified=False,nativeQualified=False,deviceQualified=False,sdkExecuted=False,normalFlowRetried=False))
print('CHAT_CURRENT_MODULE_COUNTER_TERMINAL',json.dumps(load('report.json')),flush=True)
raise SystemExit(0 if qualified else code if code else 1)
