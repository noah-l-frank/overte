"""Exact Combined-fixture process/openat ports, not product/native authority.

One E458 helper supplies the canonical filesystem policy. It is deliberately
not installed under another OS router. This sole router preserves original
relative openat/unlink calls and original Popen bodies/arguments.
"""
from pathlib import Path
from types import FrameType,FunctionType,ModuleType
import os,shutil,signal,stat,subprocess,sys,threading
from owned_write_boundary import WriteRefusal

MONITOR_NAME='snapshot-source12-original-popen-custody-v1'


class SnapshotResources:
    def __init__(self,helper,pin,plan,here,proc,writer):
        self.helper,self.pin,self.plan,self.here,self.proc,self.writer=helper,pin,plan,here,proc,writer
        self.original=helper.original;self.thread=threading.get_ident();self.active=False
        self.definitions={};self.node_alias_scope=None;self.methods=[];self.directory_fds={};self.events=[]
        self.nodes=[];self.pending=None;self.case=None;self.rescue=None;self.failures=[]
        self.popen=subprocess.Popen
        self.popen_methods=tuple((name,getattr(self.popen,name),getattr(self.popen,name).__code__,getattr(self.popen,name).__globals__)
            for name in('__init__','_execute_child','send_signal','kill','terminate','poll','wait','communicate','_communicate','_wait','_internal_poll','_get_handles'))
        self.environment=dict(os.environ)
        assert not any(name.startswith('NODE_')for name in self.environment)
        self.global_values=tuple((name,globals()[name])for name in('Path','FrameType','FunctionType','ModuleType','os','shutil','signal','stat','subprocess','sys','threading','WriteRefusal','SnapshotResources','NodeConstructorMonitor','MONITOR_NAME'))
        self.input_seals=tuple((fn,fn.__code__,fn.__globals__,fn.__closure__,tuple(c.cell_contents for c in fn.__closure__ or()))for fn in(pin,proc,writer))
        self.readers=tuple((m,n,getattr(m,n))for m,names in((os,('fstat','lstat','readlink','getpid','geteuid')),
            (sys,('_getframe',)),(threading,('get_ident',)))for n in names)
        self.controls=tuple((name,fn,fn.__code__,fn.__globals__,fn.__closure__,tuple(c.cell_contents for c in fn.__closure__ or()))
            for name,fn in type(self).__dict__.items()if type(fn)is FunctionType)

    def check(self):
        self.helper._check()
        assert self.active and threading.get_ident()==self.thread and self.helper.original is self.original
        assert dict(os.environ)==self.environment and subprocess.Popen is self.popen
        assert all(getattr(m,n)is value for m,n,value in self.readers)
        assert all(globals().get(name)is value for name,value in self.global_values)
        for fn,code,namespace,closure,cells in self.input_seals:
            assert fn in(self.pin,self.proc,self.writer)and fn.__code__ is code and fn.__globals__ is namespace and fn.__closure__ is closure
            assert len(closure or())==len(cells)and all(c.cell_contents is value for c,value in zip(closure or(),cells))
        for fn,code,namespace,defaults,keywords,items,closure,cells in self.port_seals:
            assert fn.__code__ is code and fn.__globals__ is namespace and fn.__defaults__ is defaults and fn.__kwdefaults__ is keywords
            assert tuple(keywords.items())==items and fn.__closure__ is closure and len(closure or())==len(cells)and all(c.cell_contents is value for c,value in zip(closure or(),cells))
        assert all(getattr(os,n)is port for n,port in self.ports.items())
        for name,fn,code,namespace,closure,cells in self.controls:
            assert type(self).__dict__[name]is fn and fn.__code__ is code and fn.__globals__ is namespace
            assert fn.__closure__ is closure and len(closure or())==len(cells)and all(c.cell_contents is v for c,v in zip(closure or(),cells))
        for name,fn,code,namespace in self.popen_methods:
            assert getattr(self.popen,name)is fn and fn.__code__ is code and fn.__globals__ is namespace
        for name,(module,path,cls,fn,code,namespace,closure,cells)in self.definitions.items():
            assert sys.modules.get(module.__name__)is module and vars(module)['__file__']==str(path)
            self.definition_binding(name,module,cls)
            assert cls.__dict__[name.rsplit('.',1)[-1]]is fn
            assert fn.__code__ is code and fn.__globals__ is namespace is vars(module)
            assert fn.__closure__ is closure and len(closure or())==len(cells)and all(c.cell_contents is v for c,v in zip(closure or(),cells))

    def definition_binding(self,name,module,original_class):
        current=vars(module).get(original_class.__name__)
        if current is original_class:return
        # The old original constructor temporarily selects the exact derived
        # Node source in this one global slot. No other alias may change.
        assert name=='NodeQuerySource.close'and module is sys.modules['ios.self_tests.snapshot_share_query_domain']
        assert self.node_alias_scope is not None
        archive,klass,init,code,namespace,closure,cells=self.node_alias_scope
        expected=self.definitions['ArchiveEndNodeSource.__init__'][2]
        assert current is expected and vars(archive)['ArchiveEndNodeSource']is expected
        assert sys.modules.get(archive.__name__)is archive and vars(archive)['SourceArchiveEndArchive']is klass
        assert klass.__dict__['__init__']is init and init.__code__ is code and init.__globals__ is namespace is vars(archive)
        assert init.__closure__ is closure and len(closure or())==len(cells)and all(c.cell_contents is value for c,value in zip(closure or(),cells))
        frame=sys._getframe(1)
        while frame is not None:
            if frame.f_code is code and frame.f_globals is namespace:
                assert type(frame.f_locals.get('self'))is klass
                return
            frame=frame.f_back
        raise AssertionError('Exact Node alias requires the active original SourceArchiveEndArchive constructor')

    def bind(self):
        self.check()
        selected=(('ios.self_tests.snapshot_share_source_retirement_domain','SourceRetirementArchive',('source_retire','source_inspect')),
            ('ios.self_tests.snapshot_share_archive_end_domain','ArchiveEndNodeSource',('__init__',)),
            ('ios.self_tests.snapshot_upload_script_domain','OriginalUploadScript',('dispatch',)),
            ('ios.self_tests.snapshot_share_query_domain','NodeQuerySource',('close',)))
        for module_name,class_name,names in selected:
            module=sys.modules[module_name];assert type(module)is ModuleType
            path=Path(vars(module)['__file__']);assert self.pin(path)==self.plan['sourceAndBinaryPins'][str(path)]
            cls=vars(module)[class_name]
            for name in names:
                fn=cls.__dict__[name];assert type(fn)is FunctionType and fn.__globals__ is vars(module)
                self.definitions[class_name+'.'+name]=(module,path,cls,fn,fn.__code__,fn.__globals__,fn.__closure__,tuple(c.cell_contents for c in fn.__closure__ or()))
        archive=sys.modules['ios.self_tests.snapshot_share_archive_end_domain'];script=sys.modules['ios.self_tests.snapshot_upload_script_domain']
        self.archive_program=(vars(archive)['process_fixture'],vars(archive)['BRIDGE'],vars(archive)['PLUGIN'],vars(archive)['BUNDLE'],vars(vars(archive)['process_fixture'])['BOOT'])
        self.upload_driver=Path(vars(script)['__file__']).with_name('snapshot_upload_preflight.js')
        assert self.pin(self.upload_driver)==self.plan['sourceAndBinaryPins'][str(self.upload_driver)]
        klass=vars(archive)['SourceArchiveEndArchive'];init=klass.__dict__['__init__']
        assert type(init)is FunctionType and init.__globals__ is vars(archive)
        self.node_alias_scope=(archive,klass,init,init.__code__,init.__globals__,init.__closure__,tuple(c.cell_contents for c in init.__closure__ or()))

    def bind_audit(self,function):
        self.check();assert type(function)is FunctionType and function.__globals__ is vars(sys.modules['__main__'])
        path=Path(function.__code__.co_filename);assert path==self.here/'run-group.py'and self.pin(path)==self.plan['sourceAndBinaryPins'][str(path)]
        assert function.__globals__['resources']is self
        self.audit_seal=(function,function.__code__,function.__globals__)

    def audit_call(self,args,caller):
        function,code,namespace=self.audit_seal;frame=sys._getframe(2)
        assert function.__code__ is code and function.__globals__ is namespace and namespace['audit']is function
        assert type(frame)is FrameType and frame.f_code is code and frame.f_globals is namespace
        assert frame.f_locals.get('args')is args and caller is frame.f_back

    def original_frame(self,frame,key):
        assert type(frame)is FrameType and key in self.definitions
        module,path,cls,fn,code,namespace,closure,cells=self.definitions[key]
        assert frame.f_code is code and frame.f_globals is namespace
        owner=frame.f_locals.get('self')
        if key.startswith('SourceRetirementArchive.'):
            expected=sys.modules['ios.self_tests.snapshot_share_archive_end_domain'].SourceArchiveEndArchive
            assert type(owner)is expected
        else:assert type(owner)is cls
        return owner

    def directory(self,fd,owner,frame):
        self.check();assert type(fd)is int and fd in self.directory_fds
        row=self.directory_fds[fd];assert row['owner']is owner and row['frame']is frame
        path=row['path'];self.helper.target(path,write=False)
        info=os.fstat(fd);named=path.lstat()
        actual=(info.st_dev,info.st_ino,info.st_mode,info.st_uid)
        assert actual==row['identity']==(named.st_dev,named.st_ino,named.st_mode,named.st_uid)
        assert os.readlink('/proc/self/fd/'+str(fd))==str(path)and frame.f_locals.get('directory')==fd
        return row

    def filesystem(self,name,args,kwargs,caller):
        self.check()
        port_frame=sys._getframe(1)
        assert type(port_frame)is FrameType and port_frame.f_code is self.ports[name].__code__ and port_frame.f_globals is self.ports[name].__globals__
        assert port_frame.f_locals.get('_name')==name and caller is port_frame.f_back
        if name=='close'and args and args[0]in self.directory_fds:
            assert len(args)==1 and not kwargs
            row=self.directory_fds[args[0]];owner=row['owner'];key=row['key']
            self.original_frame(caller,key);self.directory(args[0],owner,caller)
            value=self.original['close'](*args);del self.directory_fds[args[0]]
            self.events.append(dict(kind='actual-directory-close',fd=args[0]));return True,value
        key=next((key for key,row in self.definitions.items()if key.startswith('SourceRetirementArchive.')and type(caller)is FrameType and caller.f_code is row[4]and caller.f_globals is row[5]),None)
        if name=='open'and key is not None and not kwargs and len(args)==2:
            owner=self.original_frame(caller,key);flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
            if args!=(owner.documents,flags):return False,None
            path=self.helper.target(owner.documents,write=False);root=self.helper.target(owner.root,write=False)
            assert path.parent==root and path.name=='Documents'and root.parent==self.here/'own-toys'
            info=path.lstat();assert stat.S_ISDIR(info.st_mode)and info.st_uid==os.geteuid()and stat.S_IMODE(info.st_mode)in(0o700,0o755)
            identity=(info.st_dev,info.st_ino,info.st_mode,info.st_uid)
            fd=self.original['open'](*args)
            try:
                assert fd not in self.directory_fds and fd not in self.helper.control_fds
                opened=os.fstat(fd);assert identity==(opened.st_dev,opened.st_ino,opened.st_mode,opened.st_uid)
                self.directory_fds[fd]=dict(owner=owner,path=path,identity=identity,frame=caller,key=key)
                self.events.append(dict(kind='actual-source-directory-open',path=str(path),fd=fd));return True,fd
            except BaseException:self.original['close'](fd);raise
        if any(kwargs.get(k)is not None for k in('dir_fd','src_dir_fd','dst_dir_fd')):
            assert key=='SourceRetirementArchive.source_retire'and set(kwargs)=={'dir_fd'}
            owner=self.original_frame(caller,key);fd=kwargs['dir_fd'];row=self.directory(fd,owner,caller)
            module=self.definitions[key][0];names=vars(module)['ALL_NAMES'];intent=vars(module)['INTENT']
            assert type(names)is tuple and len(names)==7 and type(intent)is str
            if name=='open':
                flags=os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC
                assert args==(intent,flags,0o600)and caller.f_locals.get('valid')is True
                path=self.helper.target(row['path']/intent);assert not os.path.lexists(path)
                result=self.helper.invoke('open',(intent,None,flags),self.original['open'],*args,**kwargs)
                self.helper._remember(result);self.directory(fd,owner,caller)
                self.events.append(dict(kind='actual-exclusive-intent-openat',name=intent,fd=result));return True,result
            assert name=='unlink'and len(args)==1 and args[0]in names
            current=caller.f_locals.get('pin');assert type(current)is dict and args[0]==current['name']
            path=self.helper.target(row['path']/args[0]);info=path.lstat()
            assert stat.S_ISREG(info.st_mode)and info.st_nlink==1 and info.st_uid==os.geteuid()and stat.S_IMODE(info.st_mode)==0o600
            result=self.helper.invoke('os.remove',(args[0],fd),self.original['unlink'],*args,**kwargs)
            self.directory(fd,owner,caller);self.events.append(dict(kind='actual-source-unlinkat',name=args[0]));return True,result
        return False,None

    def install(self):
        assert not self.active and not self.helper.installed
        self.ports={}
        for name in self.original:
            def port(*args,_name=name,**kwargs):
                caller=sys._getframe(1)
                # Read-only metadata can use the original E458 reader branch;
                # no source import is a writable descriptor allowance.
                if _name=='open'and not kwargs and len(args)in(2,3)and not(args[1]&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)):
                    handled,value=self.filesystem(_name,args,kwargs,caller)
                    return value if handled else self.helper.os_open(*args)
                handled,value=self.filesystem(_name,args,kwargs,caller)
                if handled:return value
                if _name=='close':return self.original['close'](*args,**kwargs)
                if _name=='write'and args and any(row['process'].stdin is not None and not row['process'].stdin.closed and row['process'].stdin.fileno()==args[0]for row in self.nodes):
                    matches=[row for row in self.nodes if row['process'].stdin is not None and not row['process'].stdin.closed and row['process'].stdin.fileno()==args[0]]
                    assert len(matches)==1;row=matches[0]
                    fn=self.popen.communicate;execute=self.popen._communicate
                    assert caller.f_code is execute.__code__ and caller.f_globals is execute.__globals__ and caller.f_locals.get('self')is row['process']
                    assert self.proc(row['process'].pid)==row['birth']
                    return self.original['write'](*args,**kwargs)
                return self.helper.os_open(*args,**kwargs)if _name=='open'else self.helper.mutate(_name,*args,**kwargs)
            self.ports[name]=port;setattr(os,name,port)
        self.port_seals=tuple((fn,fn.__code__,fn.__globals__,fn.__defaults__,fn.__kwdefaults__,tuple(fn.__kwdefaults__.items()),fn.__closure__,tuple(c.cell_contents for c in fn.__closure__ or()))for fn in self.ports.values())
        self.active=True

    def popen_frame(self,frame,*,at_start=False):
        self.check();constructor=frame
        node=Path(shutil.which('node')).resolve(strict=True);assert str(node)==self.plan['nodeBinary']['path']and self.pin(node)==self.plan['nodeBinary']['pin']
        assert type(constructor)is FrameType and constructor.f_code is self.popen.__init__.__code__ and constructor.f_globals is self.popen.__init__.__globals__
        caller=constructor.f_back;key=next((key for key,row in self.definitions.items()if key in('ArchiveEndNodeSource.__init__','OriginalUploadScript.dispatch')and caller.f_code is row[4]and caller.f_globals is row[5]),None)
        assert key is not None;owner=self.original_frame(caller,key);values=constructor.f_locals
        process=values['self'];assert type(process)is self.popen and self.case is not None
        if key.startswith('ArchiveEnd'):
            module=self.definitions[key][0];fixture,bridge,plugin,bundle,boot_source=self.archive_program
            assert vars(module)['process_fixture']is fixture and vars(module)['BRIDGE']is bridge and vars(module)['PLUGIN']is plugin and vars(module)['BUNDLE']is bundle
            assert vars(fixture)['BOOT']is boot_source
            expected_boot=boot_source.replace("assert.equal(bundle,'org.example.overte')","assert(['org.example.overte','org.example.overte.receiver'].includes(bundle))").replace('org.example.overte',bundle)
            assert caller.f_locals['boot']==expected_boot
            expected=['node','-e',expected_boot+'\n'+bridge,str(plugin)];text=True;bufsize=1 if at_start else -1
        else:
            expected=['node',str(self.upload_driver),str(Path(self.definitions[key][1]).resolve().parents[4])];text=None;bufsize=0
        assert values['args']==expected and values['stdin']==values['stdout']==values['stderr']==subprocess.PIPE
        assert values['text']is text and values['bufsize']==bufsize and values['shell']is False
        assert values['cwd']is values['env']is values['executable']is values['preexec_fn']is None
        assert values['start_new_session']is False and values['close_fds']is True and values['pass_fds']==()
        assert values['process_group']is None if at_start else values['process_group']==-1
        assert values['errors']is values['universal_newlines']is None
        if at_start or text is None:assert values['encoding']is None
        else:assert type(values['encoding'])is str and values['encoding']==process.encoding
        assert '_execute_child'not in vars(process)and getattr(process,'_execute_child').__func__ is self.popen._execute_child
        return constructor,caller,owner,process,key,expected

    def started_from_frame(self,code,frame):
        control=sys._getframe(1);assert control.f_code is NodeConstructorMonitor.started.__code__ and control.f_globals is NodeConstructorMonitor.started.__globals__
        assert type(control.f_locals.get('self'))is NodeConstructorMonitor and control.f_locals['self'].resources is self and frame is control.f_back
        assert code is self.popen.__init__.__code__ and self.pending is None
        constructor,caller,owner,process,key,command=self.popen_frame(frame,at_start=True)
        quota=self.plan['resourceRecipe'];assert len(self.nodes)<quota['NodeExecutions']
        assert sum(row['process'].poll()is None for row in self.nodes)<quota['maxLiveNodes']
        expected='ArchiveEndNodeSource.__init__'if len(self.nodes)%2==0 else'OriginalUploadScript.dispatch'
        assert key==expected
        self.pending=dict(owner=owner,process=process,key=key,command=command,spawned=False,pipes=[],birth=None)

    def pipe_open(self,args,caller):
        if self.pending is None or type(args[0])is not int:return False
        value,mode,flags=args
        if type(mode)is not str or not any(c in mode for c in'wax+'):return False
        self.audit_call(args,caller)
        constructor,original,owner,process,key,command=self.popen_frame(caller)
        assert process is self.pending['process']and owner is self.pending['owner']
        info=os.fstat(value);assert stat.S_ISFIFO(info.st_mode)and value==constructor.f_locals['p2cwrite']and mode in('w','wb')and not self.pending['pipes']
        self.pending['pipes'].append((value,info.st_dev,info.st_ino));return True

    def spawned(self,args,caller):
        self.audit_call(args,caller);cursor=caller
        while cursor is not None and cursor.f_code is not self.popen.__init__.__code__:cursor=cursor.f_back
        constructor,original,owner,process,key,command=self.popen_frame(cursor)
        assert type(caller)is FrameType and caller.f_code is self.popen._execute_child.__code__ and caller.f_globals is self.popen._execute_child.__globals__ and caller.f_locals.get('self')is process
        assert self.pending is not None and process is self.pending['process']and len(self.pending['pipes'])==1
        executable,actual,cwd,env=args;assert executable=='node'and actual==command and cwd is env is None and not self.pending['spawned']
        self.pending['spawned']=True

    def returned_from_frame(self,code,value,frame):
        control=sys._getframe(1);assert control.f_code is NodeConstructorMonitor.returned.__code__ and control.f_globals is NodeConstructorMonitor.returned.__globals__
        assert type(control.f_locals.get('self'))is NodeConstructorMonitor and control.f_locals['self'].resources is self and frame is control.f_back
        assert code is self.popen.__init__.__code__ and self.pending is not None and value is None
        constructor,caller,owner,process,key,command=self.popen_frame(frame)
        assert self.pending['process']is process and self.pending['spawned']
        birth=self.proc(process.pid);parent=self.proc(os.getpid())
        assert birth is not None and birth['parent']==os.getpid()and birth['group']==parent['group']and birth['session']==parent['session']
        row=self.pending;row['birth']=birth;row['streams']=tuple(getattr(process,n)for n in('stdin','stdout','stderr'))
        row['pipeIdentities']=tuple((os.fstat(s.fileno()).st_dev,os.fstat(s.fileno()).st_ino)for s in row['streams'])
        assert len(set(row['pipeIdentities']))==3 and all(stat.S_ISFIFO(os.fstat(s.fileno()).st_mode)for s in row['streams'])
        assert all(os.readlink('/proc/self/fd/'+str(stream.fileno()))=='pipe:['+str(identity[1])+']'for stream,identity in zip(row['streams'],row['pipeIdentities']))
        self.nodes.append(row);self.pending=None
        self.writer('actual-node-birth-'+str(len(self.nodes))+'.json',dict(schemaVersion=1,birth=birth,creator=key,command=command,case=self.case,actualOriginalConstructorReturnObserved=True))

    def allow_signal(self,args,caller):
        self.audit_call(args,caller);pid,sig=args;assert sig in(signal.SIGTERM,signal.SIGKILL)
        rows=[row for row in self.nodes if row['process'].pid==pid];assert len(rows)==1;row=rows[0]
        assert self.proc(pid)==row['birth'];process=row['process'];original=False;sender=False
        cursor=caller
        while cursor is not None:
            if cursor.f_code is self.popen.send_signal.__code__ and cursor.f_locals.get('self')is process:sender=True
            if row['key']=='OriginalUploadScript.dispatch'and cursor.f_code is self.definitions[row['key']][4]and cursor.f_locals.get('self')is row['owner']:original=True
            if row['key']=='ArchiveEndNodeSource.__init__'and cursor.f_code is self.definitions['NodeQuerySource.close'][4]and cursor.f_locals.get('self')is row['owner']:original=True
            cursor=cursor.f_back
        assert sender and(original or self.rescue is row)

    def finish(self):
        self.check();assert self.pending is None and not self.directory_fds
        assert len(self.nodes)==self.plan['resourceRecipe']['NodeExecutions']
        assert sum(row['kind']=='actual-exclusive-intent-openat'for row in self.events)==self.plan['resourceRecipe']['graphs']
        assert sum(row['kind']=='actual-source-unlinkat'for row in self.events)==self.plan['resourceRecipe']['sourceDirectoryUnlinks']
        for row in self.nodes:
            process=row['process'];assert process.poll()==0 and self.proc(process.pid)is None
            assert tuple(getattr(process,n)for n in('stdin','stdout','stderr'))==row['streams']and all(s.closed for s in row['streams'])
        return dict(actualNodes=[dict(identity=row['birth'],creator=row['key'],exitCode=row['process'].returncode,allOriginalStreamsClosed=True)for row in self.nodes],actualSourceDirFDCalls=self.events,
            directoryDescriptorsDrained=True,rawPipeBytesClaimed=False,noListenerOrDevice=True,consumerQualification=False)

    def drain(self):
        """Failure rescue is separate and never repairs the primary verdict."""
        if self.pending is not None and self.pending['spawned']:
            process=self.pending['process'];pid=getattr(process,'pid',None);birth=None if pid is None else self.proc(pid)
            if birth is not None:
                parent=self.proc(os.getpid());assert birth['parent']==os.getpid()and birth['group']==parent['group']and birth['session']==parent['session']
                self.pending['birth']=birth;self.pending['streams']=tuple(getattr(process,n,None)for n in('stdin','stdout','stderr'));self.nodes.append(self.pending)
            self.pending=None
        for row in self.nodes:
            try:
                process=row['process']
                if process.poll()is None:
                    assert self.proc(process.pid)==row['birth'];self.rescue=row
                    try:process.kill();process.wait(timeout=5)
                    finally:self.rescue=None
                for stream in row['streams']:
                    if stream is not None and not stream.closed:stream.close()
            except BaseException as error:self.failures.append(type(error).__module__+'.'+type(error).__qualname__)
        for fd,row in tuple(self.directory_fds.items()):
            try:
                info=os.fstat(fd);assert(info.st_dev,info.st_ino,info.st_mode,info.st_uid)==row['identity']
                self.original['close'](fd);del self.directory_fds[fd]
            except BaseException as error:self.failures.append(type(error).__module__+'.'+type(error).__qualname__)

    def restore(self):
        assert all(getattr(os,n)is port for n,port in self.ports.items())
        for name,value in self.original.items():setattr(os,name,value)
        self.active=False


class NodeConstructorMonitor:
    """One independently acquired tool, exact original Popen entry/return only."""
    def __init__(self,resources):
        assert type(resources)is SnapshotResources
        self.resources=resources;self.resource_original=resources;self.api=sys.monitoring;self.tool=None;self.pending=None;self.acquired=False
        self.name=MONITOR_NAME;self.acquired_name=None;self.old_callbacks={};self.pending_callbacks=set();self.callback_objects={};self.errors=[];self.installed=False
        self.code=resources.popen.__init__.__code__;self.thread_init=threading.Thread.__init__;self.thread_code=self.thread_init.__code__;self.thread_globals=self.thread_init.__globals__;self.local_before=None;self.thread_local_before=None;self.closed=False
        names=('get_tool','get_events','get_local_events','use_tool_id','free_tool_id','register_callback','set_events','set_local_events')
        self.ports=tuple((name,getattr(self.api,name))for name in names)
        self.methods=tuple((name,fn,fn.__code__,fn.__globals__)for name,fn in type(self).__dict__.items()if type(fn)is FunctionType)
        self.callbacks=(self.started,self.returned,self.unwound)

    def bound(self):
        assert self.resources is self.resource_original and type(self.resources)is SnapshotResources
        assert sys.monitoring is self.api and all(getattr(self.api,n)is fn for n,fn in self.ports)
        assert all(type(self).__dict__[n]is fn and fn.__code__ is code and fn.__globals__ is namespace for n,fn,code,namespace in self.methods)
        assert self.resources.popen.__init__.__code__ is self.code
        assert threading.Thread.__init__ is self.thread_init and self.thread_init.__code__ is self.thread_code and self.thread_init.__globals__ is self.thread_globals
        if self.tool is not None:
            assert self.name is self.acquired_name is MONITOR_NAME and self.api.get_tool(self.tool)is MONITOR_NAME and self.acquired
            if self.installed:
                assert self.api.get_events(self.tool)==self.api.events.PY_UNWIND
                assert self.api.get_local_events(self.tool,self.code)==self.api.events.PY_START|self.api.events.PY_RETURN
                assert self.api.get_local_events(self.tool,self.thread_code)==self.api.events.PY_START

    def install(self):
        self.bound();assert not self.closed and self.tool is None and not self.acquired and self.acquired_name is None
        tool=next(n for n in(3,2,1,0,4,5)if self.api.get_tool(n)is None and self.api.get_events(n)==0 and self.api.get_local_events(n,self.code)==0 and self.api.get_local_events(n,self.thread_code)==0)
        self.pending=tool;self.api.use_tool_id(tool,self.name)
        self.tool=tool;self.acquired=True;self.acquired_name=MONITOR_NAME;self.pending=None;self.bound()
        self.local_before=self.api.get_local_events(tool,self.code);self.thread_local_before=self.api.get_local_events(tool,self.thread_code);assert self.local_before==self.thread_local_before==0
        for event,callback in zip((self.api.events.PY_START,self.api.events.PY_RETURN,self.api.events.PY_UNWIND),self.callbacks):
            self.bound();self.callback_objects[event]=callback;self.pending_callbacks.add(event)
            self.old_callbacks[event]=self.api.register_callback(tool,event,callback);self.pending_callbacks.remove(event)
        self.bound();self.api.set_events(tool,self.api.events.PY_UNWIND)
        self.api.set_local_events(tool,self.code,self.api.events.PY_START|self.api.events.PY_RETURN)
        self.api.set_local_events(tool,self.thread_code,self.api.events.PY_START)
        self.installed=True

    def started(self,code,offset):
        self.bound()
        if code is self.thread_code:raise WriteRefusal('Source12 admits zero Python thread constructors')
        assert code is self.code
        self.resources.started_from_frame(code,sys._getframe(1))

    def returned(self,code,offset,value):
        self.bound();assert code is self.code
        self.resources.returned_from_frame(code,value,sys._getframe(1))

    def unwound(self,code,offset,error):
        if code is not self.code:return
        self.bound();frame=sys._getframe(1)
        assert type(frame)is FrameType and frame.f_code is self.code and frame.f_globals is self.resources.popen.__init__.__globals__
        self.errors.append(dict(kind='actual-original-constructor-unwind',exceptionType=type(error).__module__+'.'+type(error).__qualname__))
        # A genuine failed constructor supplies no positive return/birth proof.
        # Leave its exact pending original for independent nongreen rescue.

    def restore(self):
        failures=[];tool=self.tool;self.installed=False
        def attempt(label,operation):
            try:self.bound();operation()
            except BaseException as error:failures.append(dict(step=label,type=type(error).__module__+'.'+type(error).__qualname__))
        if tool is not None:
            attempt('global-mask',lambda:self.api.set_events(tool,0))
            if self.local_before is not None:attempt('local-mask',lambda:self.api.set_local_events(tool,self.code,self.local_before))
            if self.thread_local_before is not None:attempt('thread-local-mask',lambda:self.api.set_local_events(tool,self.thread_code,self.thread_local_before))
            for event,previous in self.old_callbacks.items():
                def callback(event=event,previous=previous):
                    actual=self.api.register_callback(tool,event,previous);assert actual is self.callback_objects[event]
                attempt('original-callback',callback)
            def free():
                self.api.free_tool_id(tool);self.tool=None;self.acquired=False;self.acquired_name=None
            attempt('original-free',free)
        self.closed=True
        restored=not failures and not self.pending_callbacks and self.pending is None and self.tool is None and not self.acquired and self.acquired_name is None
        if tool is not None:
            restored=restored and self.api.get_tool(tool)is None and self.api.get_events(tool)==0
            restored=restored and self.api.get_local_events(tool,self.code)==self.local_before and self.api.get_local_events(tool,self.thread_code)==self.thread_local_before
        return dict(actualOwnedConstructorToolRestored=restored,failures=failures,originalConstructorUnwinds=list(self.errors),consumerQualified=False)
