"""Private source/latency-counterexample preparation; no target imports/tests."""
import ast,difflib,hashlib,json
from pathlib import Path
REPO=Path.cwd();HERE=REPO/'.ios-host-tmp/lifecycle-resource4-native-bookend-overall-deadline-source-proposal-20261102'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.parent.mkdir(mode=0o700,parents=True,exist_ok=True);p.open('x').write(v)
receiver='tests/device/ios/pymobiledevice3_wda_xctest.py';resource='tests/device/ios/adapters/lifecycle_touch_resource_owner.py'
receiver_before=(REPO/receiver).read_text();assert sha(REPO/receiver)=='c5feb80767f19fcd1839c4e887d1d16a471eb2308e066180304de91dbc074075'
receiver_after=receiver_before
needle="receipt=_NativeMotionReference(self,journal,reference,window_task,window_function,started,selected=selected,selected_id=selected_id)";assert receiver_after.count(needle)==1
receiver_after=receiver_after.replace(needle,"receipt=_NativeMotionReference(self,journal,reference,window_task,window_function,started,selected=selected,selected_id=selected_id,\n                    deadline=None if current_cut is None else deadline)")
needle="loop=asyncio.get_running_loop();started=loop.time();epoch=time.time()*1000;deadline=min(started+1.5,lease._deadline())";assert receiver_after.count(needle)==1
receiver_after=receiver_after.replace(needle,"loop=asyncio.get_running_loop();operation_started=loop.time();deadline=min(operation_started+1.5,lease._deadline())")
needle="            task=asyncio.create_task(acquire(),name='original-native-motion-'+phase)\n";assert receiver_after.count(needle)==1
replacement="""            # Full historical anchor proof remains inside the ORIGINAL overall
            #1.5s operation deadline. Its old clocks are not fresh acquisition.
            # Start this NEW native interval before its first request/task,
            # after historical-only admission; never reset the overall budget.
            started=loop.time();epoch=time.time()*1000
            if started>=deadline:raise LaunchError('session-lifetime')
"""+needle
receiver_after=receiver_after.replace(needle,replacement)
resource_before=(REPO/resource).read_text();assert sha(REPO/resource)=='2b285170ffa5b867866c9997374fd8605c652898e2247ce994fa7619bd0d4696'
resource_after=resource_before
needle='def __init__(self,owner,journal,reference,window_task,window_function,started,*,selected=None,selected_id=None):';assert resource_after.count(needle)==1
resource_after=resource_after.replace(needle,'def __init__(self,owner,journal,reference,window_task,window_function,started,*,selected=None,selected_id=None,deadline=None):')
needle='        self._capture=weakref.ref(asyncio.current_task());self._started=started;self._deadline=started+1.5\n';assert resource_after.count(needle)==1
replacement='''        self._capture=weakref.ref(asyncio.current_task());self._started=started;self._deadline=started+1.5
        if deadline is not None:
            # A worker acquisition inherits its EARLIER end-to-end deadline;
            # moving historical proof before the new native interval cannot
            # grant later Down/Move or a longer receipt lifetime.
            need(number(deadline,started,started+1.5) and deadline>started)
            self._deadline=deadline
'''
resource_after=resource_after.replace(needle,replacement)
source=[];diff=[]
for relative,before,after in [(receiver,receiver_before,receiver_after),(resource,resource_before,resource_after)]:
 write(HERE/'base'/relative,before);write(HERE/'candidate'/relative,after);ast.parse(after,filename=relative)
 diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative))
 source.append(dict(path=relative,baseSHA256=hashlib.sha256(before.encode()).hexdigest(),candidateSHA256=hashlib.sha256(after.encode()).hexdigest()))
write(HERE/'source2.diff',''.join(diff))
models='''"""Actual source deadlines/worker/files; only producer SDK and latency are models."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import asyncio,json,time
from unittest.mock import patch
from test_resource4_observation_models import Resource4ObservationModels


class Resource4NativeBookendModels(Resource4ObservationModels):
    def worker_phase(self,resource):
        step=resource._native_step
        if step is None or step._worker is None or asyncio.current_task() is not step._worker():return None
        lease=step._lease()
        return 'after-down' if lease.down_issued else 'before-down'
    async def test_actual_anchor_stays_inside_original_deadline_but_each_new_native_interval_starts_after_its_historical_proof(self):
        from ios.adapters.lifecycle_touch_resource_owner import _NativeMotionReference
        original=_NativeMotionReference.anchor;events={}
        def observed(reference,source,resource,owner):
            phase=self.worker_phase(resource)
            if phase is None:return original(reference,source,resource,owner)
            before=asyncio.get_running_loop().time();value=original(reference,source,resource,owner)
            events[phase]=(before,asyncio.get_running_loop().time());return value
        with patch.object(_NativeMotionReference,'anchor',observed):await self.open_motion()
        self.assertEqual({'before-down','after-down'},set(events));self.assertEqual(16,len(self.commands))
        self.assertEqual([0xC2,0xC2],self.f.states());self.assertEqual(2,len(self.source._native_current_tasks))
        # Default preparation receipt remains exactly started+1.5. No native
        # field or prior original has been changed to meet the new interval.
        old=self.resource._motion_original;self.assertEqual(old._started+1.5,old._deadline)
        for task in self.source._native_current_tasks:
            self.assertTrue(task.done());receipt=task.result();before,after=events[receipt._worker_phase]
            self.assertGreaterEqual(receipt._started,after)
            self.assertLessEqual(receipt._deadline,before+1.5)
            self.assertLess(receipt._deadline,receipt._started+1.5)
            # Inspect the ACTUAL immutable saved frame as metadata; real source
            # admission/byte read/clock join have already run before this Task
            # returned. No host dictionary can supply its original receipt.
            frame=json.loads(self.frame_path(receipt.reference).read_bytes())['frame']
            self.assertEqual(receipt._started,frame['clockJoin']['hostBeforeMonotonic'])
            self.assertLess(frame['clockJoin']['hostAfterMonotonic'],receipt._deadline)
        await self.passive_rpc('touch-release',{});self.assertEqual([0xC2,0xC2,0x02],self.f.states())
        self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes())
    async def delayed_anchor_refusal(self,phase):
        from ios.adapters.lifecycle_touch_resource_owner import _NativeMotionReference
        original=_NativeMotionReference.anchor;observed=[]
        def delayed(reference,source,resource,owner):
            value=original(reference,source,resource,owner)
            if self.worker_phase(resource)==phase:
                before=asyncio.get_running_loop().time();count=len(self.commands)
                # REAL elapsed latency, never a fake native/host clock jump.
                time.sleep(1.55)
                observed.append(dict(before=before,after=asyncio.get_running_loop().time(),queries=count))
            return value
        args=await self.prepare_rpc()
        with patch.object(_NativeMotionReference,'anchor',delayed):packet,_=await self.rpc_begin(args)
        self.assertEqual('failed',packet['status']);self.assertEqual(1,len(observed))
        self.assertGreaterEqual(observed[0]['after']-observed[0]['before'],1.5)
        self.assertEqual(observed[0]['queries'],len(self.commands)) # No new Native query after expired original budget.
        worker=self.ops.touch.worker;await worker
        self.assertFalse(worker.cancelled());self.assertTrue(self.ops.touch.closed)
        self.assertEqual([],self.f.states() if phase=='before-down' else self.f.states()[:-2])
        self.assertEqual([] if phase=='before-down' else [0xC2,0x02],self.f.states())
        self.assertEqual(self.prepared_bytes,self.resource.store.path.read_bytes())
        self.assertTrue(all(fd.fileno()==-1 for fd in self.resource_receiver.sockets));self.assertEqual(1,len(self.resource_display.stops))
    async def test_real_delayed_before_down_anchor_cannot_restart_budget_or_issue_any_down_or_new_query(self):
        await self.delayed_anchor_refusal('before-down')
    async def test_real_delayed_after_down_anchor_cannot_restart_budget_or_issue_move_and_original_up_still_returns(self):
        await self.delayed_anchor_refusal('after-down')
'''
ast.parse(models,filename='test_resource4_native_cut_bookend_models.py');write(HERE/'models/test_resource4_native_cut_bookend_models.py',models)
classes=ast.parse(models).body;cls=next(n for n in classes if isinstance(n,ast.ClassDef));cases=['test_resource4_native_cut_bookend_models.'+cls.name+'.'+n.name for n in cls.body if isinstance(n,ast.AsyncFunctionDef) and n.name.startswith('test_')]
plan=dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',source=source,actualTimeline='.ios-host-tmp/lifecycle-resource4-join-bookend-timeline-root-preparation-20261102/01-source-first1/actual-original-join-bookend-timeline.json',observedBasis='BeforeDown243.897ms gap with historical anchor26.560; afterDown242.363ms with anchor24.555. Original strict250 guard correctly exposes bookend overhead; no claim anchor dominates.',models=cases,modelSourceSHA256=hashlib.sha256(models.encode()).hexdigest(),prospectiveFirst3=dict(initialSeconds=30,killAfterSeconds=5,realRoots=6),modelBase='Root-reviewed fbe7 Resource4ObservationModels, unchanged SDK producers/full Source/worker/FD/WAL pipeline',defaultCallerSemanticsUnchanged=True,clockJoin250msUnchanged=True,overallDeadline1500msUnchanged=True,receiptUsesOriginalEarlierDeadline=True,originalPacketsReclocked=False,queryCountsUnchanged=True,SourcePublished=False,targetImported=False,testsRun=False,nativeSDKAuthWholeQualified=False)
write(HERE/'plan.json',json.dumps(plan,indent=2)+'\n')
write(HERE/'README.txt','Private new Native acquisition placement refinement, not a timestamp shift around previously acquired data. Original per-input overalldeadline remains captured BEFORE historical anchor, bounded by original12s lease. Exact old anchor is fully reread/validated, then new native interval clocks are captured BEFORE creating its acquisition Task/firstNative request. Current-cut tuple retains original earlierdeadline; NativeMotionReference optionally inherits that exactdeadline, so full source/post-validation/checkpoint/Down/Move cannot run later. Existing default reference calls keep started+1.5 literally. All old/native packet clocks and250ms join/1.5s overall guard stay unchanged; five query/file pairs per cut unchanged. Positive actual-source model compares real anchor return times to actual savedframe/ref starts+deadlines; two real1.55s delayed-anchor cases prove no new queries/lateDown orMove and original context/Up cleanup. No native/SDK/device/whole qualification. Source2+model3 UNRUN/unpublished.\n')
write(HERE/'freeze.json',json.dumps(dict(status='PRIVATE_UNRUN_ROOT_REVIEW_REQUIRED',files={str(p.relative_to(HERE)):sha(p) for p in sorted(HERE.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(packet=str(HERE),freeze=sha(HERE/'freeze.json'),source=source,cases=cases)))
