from pathlib import Path
import ast,difflib,hashlib,json,shutil
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';OLD=T/'lifecycle-original-owner-native-query10-root-preparation-20261028/06-query10';P=T/'lifecycle-original-owner-native-query-own-registry-overlay-20261028';P.mkdir(mode=0o700);h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=R/'tests/device/contract-versions.json';raw=base.read_text();name='original-keeper-native-query';line='    "original-keeper-native-query": {"current": 1, "reads": [1]},\n';anchor='    "original-keeper-native-file": {"current": 1, "reads": [1]},\n';assert raw.count(anchor)==1 and '"'+name+'"' not in raw
candidate=raw.replace(anchor,anchor+line,1);assert candidate.replace(line,'',1)==raw
old=json.loads(raw);new=json.loads(candidate);expected=json.loads(raw);expected['contracts'][name]={'current':1,'reads':[1]};assert new==expected
copy=P/'candidate/repo/tests/device/contract-versions.json';copy.parent.mkdir(parents=True);copy.write_text(candidate)
(P/'registry-own-only.diff').write_text(''.join(difflib.unified_diff(raw.splitlines(True),candidate.splitlines(True),fromfile='a/tests/device/contract-versions.json',tofile='b/tests/device/contract-versions.json')))
(P/'README.txt').write_text('''PRIVATE registry-only correction; old whole-file-reformatted proposal is
superseded and MUST NOT be applied. Exactly one native-query1 line is inserted
beside existing native-file1, preserving every foreign original byte. Root
applies only the own-key insertion on actual current registry, checks no foreign
key/value changed, and creates fresh actual source census AFTER publication.
No production capability flag; Source3/ten model bytes unchanged. UNRUN.
''')
(P/'manifest.json').write_text(json.dumps(dict(status='PRIVATE_OWN_KEY_ONLY_UNRUN',baseSHA256=h(base),candidateSHA256=h(copy),foreignBytesPreserved=True,addedKey=name,sourceOrModelsChanged=False,originalOversizedProposalPreserved=str(OLD/'registry-own-only.diff')),indent=2)+'\n')
(P/'freeze.json').write_text(json.dumps(dict(files={str(p.relative_to(P)):h(p) for p in sorted(P.rglob('*')) if p.is_file()}),indent=2)+'\n')
TOP=T/'lifecycle-original-owner-native-query10-own-registry-corrected-root-preparation-20261028';S=TOP/'06-query10';S.mkdir(mode=0o700,parents=True)
for name in json.loads((OLD/'freeze.json').read_bytes())['files']:
 source=OLD/name;dest=S/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
shutil.copyfile(copy,S/'registry-candidate/tests/device/contract-versions.json');shutil.copyfile(P/'registry-own-only.diff',S/'registry-own-only.diff')
stage=json.loads((S/'source-manifest.json').read_bytes());stage['orderedParentFreezes']['lifecycle-original-owner-native-query-own-registry-overlay-20261028']=h(P/'freeze.json')
for row in stage['sourcePaths']:row['observedPublicSHA256']=h(R/row['path']);row['changesCurrentPublic']=row['observedPublicSHA256']!=row['candidateSHA256']
(S/'source-manifest.json').write_text(json.dumps(stage,indent=2)+'\n')
(S/'registry-correction-provenance.json').write_text(json.dumps(dict(parentFreezeSHA256=h(OLD/'freeze.json'),registryOverlayFreezeSHA256=h(P/'freeze.json'),sourceCandidatesUnchanged=True,modelSHA256=h(S/'test_native_query_owner_models.py'),registrySourceBaseSHA256=h(base),foreignBytesPreserved=True,initialOuterSeconds=60,killAfterSeconds=5),indent=2)+'\n')
(S/'README-own-registry-correction.txt').write_text('''Supersedes only Root10 oversized registry proposal. Actual candidate inserts
exactly ONE own-key line, keeping every other source byte. All ten models,
Source3 candidates, fixed60+5, runner/parent guards and original retention are
unchanged. Original oversized packet stays frozen; never apply its registry.
''')
for p in S.rglob('*.py'):ast.parse(p.read_bytes())
(S/'freeze.json').write_text(json.dumps(dict(status='PRIVATE_QUERY10_OWN_KEY_CORRECTED_UNRUN',files={str(p.relative_to(S)):h(p) for p in sorted(S.rglob('*')) if p.is_file() and p.name!='freeze.json'}),indent=2)+'\n')
(TOP/'freeze.json').write_text(json.dumps(dict(files={str(p.relative_to(TOP)):h(p) for p in sorted(TOP.rglob('*')) if p.is_file()}),indent=2)+'\n')
print(json.dumps(dict(overlayFreeze=h(P/'freeze.json'),stageFreeze=h(S/'freeze.json'),parentFreeze=h(TOP/'freeze.json'),registryDiffLines=len((S/'registry-own-only.diff').read_text().splitlines()),modelsSHA256=h(S/'test_native_query_owner_models.py')),indent=2))
