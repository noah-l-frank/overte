"""Root-only quiet metadata assembler. This file never launches the target."""
from pathlib import Path
import argparse,ast,hashlib,importlib.machinery,importlib.util,json,os,shutil,sys
from metadata_reader import pin,load
from host_common import REPO,head
from admission import require,packet,SOURCE2,SOURCE3,C10C,HELPER,QUALIFIED
from root_context import root_context,later_context
SOURCE=Path(__file__).resolve().parent
PREVIOUS=REPO/'.ios-host-tmp/emote-callback-source3-positive-end-bootstrap3-probe-document-custody-code-preparation-20261104'
PREVIOUS4=REPO/'.ios-host-tmp/emote-callback-source3-positive-end-bootstrap4-owned-stat-discovery-code-preparation-20261104'
S2=REPO/'.ios-host-tmp/emote-callback-copied-state-ownership-source2-private-20261104'
S3=REPO/'.ios-host-tmp/emote-callback-typed-fence-process-sdk-end-source3-private-20261104'
SUBJECT=REPO/'.ios-host-tmp/chat-offline-source1-initial4-controller10c-copied-bootstrap-namespace-row-code-preparation-20261104'
SEMANTIC=REPO/'.ios-host-tmp/lifecycle-independent-emote-copied2-typed-end3-full-semantic-review-20261104'
QUALIFICATION=REPO/'.ios-host-tmp/root-c10c-source-execution-six-cache-mutation-alias-counters-qualified-results-20261104'
HISTORICAL_COVERAGE=REPO/'.ios-host-tmp/root-emote-source23-historical-coverage-from-parent-20261104'
CURRENT_INTEGRATION=REPO/'.ios-host-tmp/root-chat-offline-source1-exact-public-integration-20261104'
COVERAGE_LOGICAL='tests/device/ios/FEATURE_ADAPTER_COVERAGE_20261021.md'
COVERAGE_OLD_SHA='144fac65108474b71638f0472abd13d9407b2e6d7b7d29ceb7ced36745527450'
EXECUTORS=('run-one.py','supervise.py','metadata_reader.py','host_common.py','closed_import_origins.py','owned_write_boundary.py','root_context.py','global_original_corpus.py',
    'resources.py','byte_streams.py','locks.py','kernel.py','admission.py','exact-one-selector.json','readonly-shared-stdlib-sources.json','readonly-own-public-source-verification.json')

def main():
    parser=argparse.ArgumentParser()
    for name in('source-freeze','expected-head','terminal-context','terminal-context-sha','terminal-bundle-freeze','destination'):parser.add_argument('--'+name,required=True)
    # An explicit Root-only invocation is not an automatic target permission.
    parser.add_argument('--root-reviewed-one-positive',action='store_true',required=True)
    args=parser.parse_args();assert sys.flags.no_site==1 and sys.dont_write_bytecode and Path.cwd()==REPO
    assert len(args.expected_head)==40 and head()==args.expected_head
    physical={}
    def keep(path,digest=None):
        path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path
        value=pin(path)
        if digest is not None:assert value['sha256']==digest
        physical[str(path)]=value;return value
    def frozen(folder,name,digest):
        ref=dict(path=str(folder/name),sha256=digest);value=packet(ref,pin);keep(folder/name,digest)
        for leaf,row in value['files'].items():keep(folder/leaf,row['sha256'])
        return value
    frozen(SOURCE,'source-freeze.json',args.source_freeze)
    frozen(PREVIOUS,'source-freeze.json','a8edd9f52f0aab3331188c09ce3f6e375eb1e4a9bed8848e4a6bec746ae3d492')
    frozen(PREVIOUS4,'source-freeze.json','97bfdf57918d6e39bdf0ed238c61ea46109907d2ac0b8f501cfd10640ec794b5')
    frozen(S2,'source-freeze.json',SOURCE2);frozen(S3,'source-freeze.json',SOURCE3);frozen(SUBJECT,'source-freeze.json',C10C)
    frozen(SEMANTIC,'freeze.json','7ec477b361087c0abcb6a09c9167cfd83f1f8d29b810745cc912bcd276be1c6a')
    frozen(QUALIFICATION,'freeze.json',QUALIFIED)
    root_admission=dict(status='ROOT_REVIEWED_EMOTE_SOURCE3_ONE_POSITIVE_METADATA_ADMISSION',source2Freeze=SOURCE2,source3Freeze=SOURCE3,
        sourceSemanticReviewFreeze=dict(path=str(SEMANTIC/'freeze.json'),sha256='7ec477b361087c0abcb6a09c9167cfd83f1f8d29b810745cc912bcd276be1c6a'),
        c10cQualifiedRootFreeze=dict(path=str(QUALIFICATION/'freeze.json'),sha256=QUALIFIED))
    require(root_admission,pin)
    assert keep(SOURCE/'closed_import_origins.py')['sha256']==HELPER
    frozen(HISTORICAL_COVERAGE,'freeze.json','81f7bddd9971312ef38296ac0220be6ef47c87e0d09e34ae06a563bb14857206')
    frozen(CURRENT_INTEGRATION,'freeze.json','f35e841db95bd84e136d549b0213c62e3554b631407df238644c00afc9e77027')
    old_doc=load(HISTORICAL_COVERAGE/'historical-source.json')
    assert old_doc['status']=='ROOT_EXACT_HISTORICAL_DOCUMENT_BYTES_FROM_IMMUTABLE_LOCAL_PARENT_COMMIT_ONLY'
    assert old_doc['historicalPublicPath']==old_doc['currentPublicPath']==str(REPO/COVERAGE_LOGICAL)
    assert old_doc['historicalBytes']==61446 and old_doc['historicalSha256']==COVERAGE_OLD_SHA
    assert old_doc['sourceCommit']=='7c18ac7c24270419b3f8cc5fdd3bb24ef4ee70f9'and old_doc['sourceGitBlob']=='a084f17eb5fd060fc8bea04026cfa64e2f96bc0a'
    assert old_doc['currentPublicAuthorityClaimedForHistoricalBytes']is old_doc['historicalRowRewritten']is False
    old_path=HISTORICAL_COVERAGE/'historical-feature-adapter-coverage.md'
    assert old_doc['historicalPhysicalPath']==str(old_path)and keep(old_path,COVERAGE_OLD_SHA)['bytes']==61446
    assert old_doc['currentIntegrationProof']=='f35e841db95bd84e136d549b0213c62e3554b631407df238644c00afc9e77027'
    integration=load(CURRENT_INTEGRATION/'integration.json')
    assert keep(CURRENT_INTEGRATION/'integration.json')['sha256']=='c766a349671ccd258a886eab0a967d4806295accac82ec18e297463db7bb2bdc'
    assert integration['publicCommitFiles'][COVERAGE_LOGICAL]==old_doc['currentPublicSha256']=='be8a965753dec804099c299ffe65f011d91d75e7e40365d196fde1d392363678'
    current_doc=keep(REPO/COVERAGE_LOGICAL,old_doc['currentPublicSha256'])
    historical_rows=[]
    for packet_root in(S2,S3):
        for row in load(packet_root/'SOURCE-INPUTS.json')['rows']:
            if row['path']==str(REPO/COVERAGE_LOGICAL):
                assert row==dict(path=str(REPO/COVERAGE_LOGICAL),bytes=61446,sha256=COVERAGE_OLD_SHA)
                keep(old_path,COVERAGE_OLD_SHA)
                historical_rows.append(dict(packet=str(packet_root),originalRow=row,actualHistoricalSource=str(old_path),currentPublicPin=current_doc,
                    currentPublicPath=str(REPO/COVERAGE_LOGICAL),currentIntegrationFreeze=old_doc['currentIntegrationProof'],originalRowUnchanged=True,currentAuthorityNotClaimedForOldBytes=True))
            else:keep(row['path'],row['sha256'])
    assert len(historical_rows)==2
    refs=load(QUALIFICATION/'actual-receipt-references.json')
    for row in refs.values():keep(row['path'],row['sha256'])
    # Historical result statuses and original bodies are never reheadered.
    roots,expected,proofs,unused_base,unused_wrapper=root_context()
    roots,expected,later_proofs,later=later_context(args.terminal_context,args.terminal_context_sha,args.terminal_bundle_freeze,roots,expected)
    for row in(*proofs,*later_proofs):keep(row['path'],row['sha256'])
    assert set(expected)==roots
    assert set(load(QUALIFICATION/'results.json')['newOriginalRoots'])<=roots,'The actual current helper qualification outputs must be retained too'
    overlays=load(S3/'SOURCE-INPUTS.json')['productionOverlays'];assert len(overlays)==20
    models=load(S3/'SOURCE-INPUTS.json')['modelOverlays'];assert len(models)==2
    projects={};namespaces={}
    def module_name(relative):
        parts=list(Path(relative).with_suffix('').parts)
        package=parts[-1]=='__init__'
        if package:parts.pop()
        return '.'.join(parts),package
    device=REPO/'tests/device'
    for path in sorted(device.rglob('*.py')):
        assert path.resolve(strict=True)==path and not path.is_symlink()
        name,package=module_name(path.relative_to(device))
        if not name:continue
        value=keep(path);projects[name]=dict(path=str(path),sha256=value['sha256'],package=package)
    for row in overlays:
        relative=Path(row['logical']).relative_to('tests/device');name,package=module_name(relative)
        value=keep(row['path'],row['sha256']);projects[name]=dict(path=row['path'],sha256=value['sha256'],package=package)
    for row in models:
        name,package=module_name(Path('ios/self_tests')/Path(row['path']).name)
        value=keep(row['path'],row['sha256']);projects[name]=dict(path=row['path'],sha256=value['sha256'],package=package)
    for name in tuple(projects):
        parts=name.split('.')
        for size in range(1,len(parts)):
            parent='.'.join(parts[:size])
            if parent not in projects:namespaces[parent]=[str(device.joinpath(*parts[:size]))]
    # Physical non-Python sources read by the actual normal producer. The
    # staged marker JS is created by product code and captured as new raw.
    names=('Crying','Surprised','Dancing','Cheering','Waving','Fall','Pointing','Clapping','Sit1','Sit2','Sit3','Love')
    for path in(device/'feature_journeys/emote-source-pins.v1.json',REPO/'scripts/system/+android_phoneInterface/phoneEmote.js',REPO/'scripts/system/emote.js',
        *(REPO/'scripts/system/assets/animations'/(name+'.fbx')for name in names)):keep(path)
    for path in sorted((device/'feature_journeys').rglob('*')):
        if path.is_file()and not path.is_symlink()and path.suffix in('.json','.js','.mjs','.png'):keep(path)
    programs={}
    for name in('ios.self_tests.emote_script_vm_fixture','ios.self_tests.emote_marker_domain_fixture'):
        path=Path(projects[name]['path']);tree=ast.parse(path.read_text());assign=[node for node in tree.body if isinstance(node,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='PROGRAM'for t in node.targets)]
        assert len(assign)==1;value=ast.literal_eval(assign[0].value);assert type(value)is str
        programs[name]=dict(path=str(path),sourceSha256=physical[str(path)]['sha256'],sha256=hashlib.sha256(value.encode()).hexdigest())
    third={}
    declarations=load(SOURCE/'third-party-source-declarations.json');assert len(declarations)==39
    for name,row in declarations.items():
        value=keep(row['path'],row['sha256']);third[name]=dict(path=row['path'],sha256=value['sha256'],package=row['package'],loader='source'if row['kind']=='python'else'extension')
    for path,row in load(SOURCE/'readonly-own-public-source-verification.json')['paths'].items():keep(path,row['sha256'])
    std=Path(os.__file__).resolve(strict=True).parent;std_namespaces={};suffixes=tuple(importlib.machinery.EXTENSION_SUFFIXES)
    for current,dirs,names_ in os.walk(std,topdown=True,followlinks=False):
        folder=Path(current);dirs[:]=sorted(name for name in dirs if name not in('site-packages','dist-packages','__pycache__')and not(folder/name).is_symlink())
        relative=folder.relative_to(std)
        if relative.parts and all(p.isidentifier()for p in relative.parts)and not(folder/'__init__.py').is_file():std_namespaces['.'.join(relative.parts)]=[str(folder)]
        for name in names_:
            path=folder/name
            if path.suffix=='.py'or str(path).endswith(suffixes):keep(path)
    python=Path(sys.executable).resolve(strict=True);python_pin=keep(python)
    assert not any(name.startswith('NODE_')for name in os.environ)
    node=Path(shutil.which('node')).resolve(strict=True);node_pin=keep(node)
    # Actual repository control files are metadata, not a git subprocess.
    git=(REPO/'.git').read_text();assert git.startswith('gitdir: ')
    gd=Path(git[8:].strip());gd=(gd if gd.is_absolute()else REPO/gd).resolve(strict=True)
    common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True);ref=(gd/'HEAD').read_text().strip();assert ref.startswith('ref: ')
    for path in(REPO/'.git',gd/'HEAD',gd/'commondir',gd/'index'):keep(path)
    keep(next((base/ref[5:]for base in(gd,common)if(base/ref[5:]).is_file()),common/'packed-refs'))
    destination=Path(args.destination);assert destination.is_absolute()and destination.resolve(strict=False)==destination
    assert destination.parent==REPO/'.ios-host-tmp'and destination.name.startswith('emote-callback-source3-one-positive-prepared-')and not destination.exists()
    assert head()==args.expected_head and all(pin(p)==v for p,v in physical.items())
    destination.mkdir(mode=0o700)
    def write(name,value,raw=False):
        path=destination/name;fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
        with os.fdopen(fd,'wb')as stream:stream.write(value if raw else(json.dumps(value,indent=2,sort_keys=True)+'\n').encode())
        return path
    for name in EXECUTORS:
        path=write(name,(SOURCE/name).read_bytes(),True);keep(path)
        if name.endswith('.py')and name not in('run-one.py','supervise.py'):
            projects[path.stem]=dict(path=str(path),sha256=physical[str(path)]['sha256'],package=False)
    # Only now may the future quiet Root assembler read original inventories.
    # No temporary/runs root exists yet and no writer is excluded.
    write('global-original-roots-seed.json',dict(roots=sorted(roots)));write('global-original-corpus-baseline.json',expected)
    spec=importlib.util.spec_from_file_location('_emote_global_guard',destination/'global_original_corpus.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    actual=module.current();assert actual==expected,'All old flat original bodies and root spellings must remain exact'
    for name in('global-original-roots-seed.json','global-original-corpus-baseline.json'):keep(destination/name)
    resource_contract=dict(realNodeExecutions=3,maximumConcurrentNodeExecutions=2,nodeRoles=['vm','marker-primary','marker-actor'],realHTTPListeners=1,realUDPReceiverSockets=1,realUDPSenderSockets=1,
        realTLS=0,realSDK=0,nativeQueries=0,realTemporaryDirectoryBirths=5,temporaryRoles={'whole':1,'pair':2,'installed':2},
        modeled=['native','WDA','SDK endpoint/DELETE/404','OS process/lifecycle','preflight release/SBOM','inherited Source1 constructor-free fixture facades'],
        newProductionLiveDunderNew=False,publicFinishEnabled=False,wholeQualified=False,nativeQualified=False)
    plan=dict(status='PRIVATE_ONE_CALLBACK3_POSITIVE_UNRUN_ROOT_REVIEW_REQUIRED',controllerRoot=str(destination),repositoryRoot=str(REPO),expectedHead=args.expected_head,
        source2Freeze=SOURCE2,source3Freeze=SOURCE3,subjectSourceFreeze=C10C,subjectHelperSha256=HELPER,rootAdmission=root_admission,
        sourceAndBinaryPins=physical,modules=projects,productionOverlays=overlays,modelOverlays=models,cases=load(SOURCE/'exact-one-selector.json'),programs=programs,
        node=dict(path=str(node),pin=node_pin),pythonExecutable=dict(path=str(python),pin=python_pin),resourceContract=resource_contract,
        wallSeconds=300,killGraceSeconds=5,actSeconds=25,observeSeconds=30,cleanupSeconds=60,terminalSeconds=30,nativeFreshnessMilliseconds=1500,clockDisagreementMilliseconds=250,
        nativeQualified=False,wholeQualified=False,publicFinishEnabled=False,oldRootCount=len(roots),genericTerminalContext=later)
    plan['originPlan']=dict(modules=projects,namespacePackages=namespaces,thirdPartyModules=third,thirdPartyNamespacePackages={},stdlibNamespacePackages=std_namespaces,
        stdlibRoots=[str(std)],pythonExecutable=plan['pythonExecutable'],physicalPins=physical)
    assert head()==args.expected_head and all(pin(p)==v for p,v in physical.items())
    write('historical-coverage-source-row-admission.json',historical_rows)
    approved=write('approved-inputs.json',plan);digest=pin(approved)['sha256']
    write('PREPARED-CLI.json',dict(command=[str(python),'-B','-S',str(destination/'supervise.py'),'--approved-inputs-sha',digest],targetExecuted=False,metadataOnly=True))
    write('freeze.json',dict(status='ROOT_PREPARED_METADATA_ONLY_UNRUN',expectedHead=args.expected_head,approvedInputSha256=digest,
        oldRootCount=len(roots),files={str(p.relative_to(destination)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in sorted(destination.iterdir())if p.is_file()}))
    print(json.dumps(dict(destination=str(destination),approvedInputSha256=digest,physicalPins=len(physical),modules=len(projects),oldRoots=len(roots),targetExecuted=False),sort_keys=True))
if __name__=='__main__':main()
