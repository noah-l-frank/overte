"""Actual original-write boundary countermodels for typed Picker3 intents."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import os,unittest
from adapters.normal_ui import NativeUIError
from adapters.script_feature.history import unpack
from ios.adapters.assets_picker_originals import page_picker_owner
from ios.self_tests.assets_whole_observation_fixture import Fixture
from ios.self_tests.assets_picker_fixture import RUN


class AssetsPickerIntentTransitionTests(unittest.TestCase):
    def opened(self):
        fixture=Fixture(self);fixture.perform_action(1);fixture.consume_input(1)
        return fixture,fixture.perform_action(2)['picker']
    def planned_fault(self,picker,callback):
        store=picker.stores['capture'];original=store.intent;events=[]
        def actual(transition,reference):
            if not events and reference['phase']=='planned':
                events.append(dict(header=picker.store.path.read_bytes(),reference=deepcopy(reference)))
                callback(events[-1])
            return original(transition,reference)
        return store,actual,events
    def test_actual_phase_advance_during_planned_intent_rejects_before_wal_progress_or_another_ui_input(self):
        fixture,picker=self.opened()
        def advance(row):
            fixture.a.activate(3);row.update(ui=fixture.boundary.ui_sequence,inputs=deepcopy(fixture.boundary.inputs))
        store,actual,events=self.planned_fault(picker,advance)
        with patch.object(store,'intent',side_effect=actual),self.assertRaises(NativeUIError):picker.capture()
        self.assertEqual(1,len(events));row=events[0]
        self.assertEqual(row['header'],picker.store.path.read_bytes());self.assertEqual(row['ui'],fixture.boundary.ui_sequence)
        self.assertEqual(row['inputs'],fixture.boundary.inputs);self.assertFalse(store.path(row['reference']).exists())
    def test_actual_foreign_actor_binding_during_planned_intent_cannot_rebind_primary_original_context(self):
        fixture,picker=self.opened();binding=deepcopy(picker.binding)
        def switch(row):
            picker.binding=deepcopy(fixture.selected.context['roles']['actor']['binding'])
            row.update(ui=fixture.boundary.ui_sequence,inputs=deepcopy(fixture.boundary.inputs))
        store,actual,events=self.planned_fault(picker,switch)
        try:
            with patch.object(store,'intent',side_effect=actual),self.assertRaises(NativeUIError):picker.capture()
        finally:picker.binding=binding
        row=events[0];self.assertEqual(row['header'],picker.store.path.read_bytes())
        self.assertEqual(row['ui'],fixture.boundary.ui_sequence);self.assertEqual(row['inputs'],fixture.boundary.inputs)
        self.assertFalse(store.path(row['reference']).exists())
    def test_actual_samebytes_old_capture_inode_replacement_blocks_intermediate_wal_progress(self):
        fixture,picker=self.opened();source=picker.stores['capture'];path=source.path(source.expand(picker.storage['captures'][0]))
        raw=path.read_bytes();before_inode=path.stat().st_ino
        def replace(row):
            path.rename(path.with_name('retained-before-picker3-intent-inode'));path.write_bytes(raw);path.chmod(0o600)
            row['ui']=fixture.boundary.ui_sequence
        store,actual,events=self.planned_fault(picker,replace)
        with patch.object(store,'intent',side_effect=actual),self.assertRaises(NativeUIError):picker.capture()
        self.assertNotEqual(before_inode,path.stat().st_ino);self.assertEqual(raw,path.read_bytes())
        self.assertEqual(events[0]['header'],picker.store.path.read_bytes());self.assertEqual(events[0]['ui'],fixture.boundary.ui_sequence)
        self.assertFalse(store.path(events[0]['reference']).exists())
    def test_actual_unadmitted_zero_byte_original_between_intents_blocks_wal_progress_and_stays_owned(self):
        fixture,picker=self.opened();path=picker.store.path.parent/('assets-picker-capture-frame-sources-'+RUN+'-primary-0096-'+('d'*64)+'.json')
        def orphan(row):
            path.touch(mode=0o600,exist_ok=False);info=path.stat();row.update(inode=info.st_ino,device=info.st_dev,ui=fixture.boundary.ui_sequence)
        store,actual,events=self.planned_fault(picker,orphan)
        with patch.object(store,'intent',side_effect=actual),self.assertRaises(NativeUIError):picker.capture()
        row=events[0];self.assertEqual(row['header'],picker.store.path.read_bytes());self.assertEqual(row['ui'],fixture.boundary.ui_sequence)
        self.assertEqual((row['device'],row['inode'],0),(path.stat().st_dev,path.stat().st_ino,path.stat().st_size))
        self.assertFalse(store.path(row['reference']).exists())
    def test_actual_saved_original_final_cas_failure_retains_fault_wal_and_recovers_without_native_repeat(self):
        fixture,picker=self.opened();before=len(picker.state['captures']);write=picker.store.write;fault=[]
        def fail(value,previous):
            prior=unpack(previous['payload'])[0]['originals']['pending'];after=unpack(value['payload'])[0]['originals']['pending']
            if not fault and prior is not None and prior['original'] is not None and prior['original']['phase']=='saved' and after is None:
                fault.append(True);raise OSError('Actual modeled final parent CAS failure after saved typed-intent original')
            return write(value,previous)
        with patch.object(picker.store,'write',side_effect=fail),self.assertRaises(OSError):picker.capture()
        self.assertTrue(fault);wal=picker.store.path.read_bytes()
        retained=picker.store.path.with_name('retained-picker3-saved-intent-wal.json')
        descriptor=os.open(retained,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(descriptor,'wb') as stream:stream.write(wal);stream.flush();os.fsync(stream.fileno())
        reopened=page_picker_owner(picker.native,picker.files,picker.store,picker.binding,lock=picker.lock,
            page_lease=picker.page_lease,episode=picker.episode,monotonic=picker.monotonic,sleep=picker.sleep)
        self.assertEqual('saved',reopened.storage['pending']['original']['phase'])
        ui=fixture.boundary.ui_sequence;inputs=deepcopy(fixture.boundary.inputs)
        result=reopened.recover_storage_saved();self.assertFalse(result['nativeQueryRepeated']);self.assertFalse(result['nativeInputRepeated'])
        self.assertEqual(ui,fixture.boundary.ui_sequence);self.assertEqual(inputs,fixture.boundary.inputs)
        self.assertEqual(before+1,len(reopened.state['captures']));self.assertEqual(reopened.state,reopened.decode(reopened.previous))
        self.assertEqual(wal,retained.read_bytes())


if __name__=='__main__':unittest.main()
