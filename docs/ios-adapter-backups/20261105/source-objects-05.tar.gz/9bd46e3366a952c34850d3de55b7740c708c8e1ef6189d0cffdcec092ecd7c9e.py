"""Immutable byte handoff from actual retained Audio originals to common v16.

Artifact acquisition clocks describe the original native samples. Reading or
copying a saved WAV never makes that waveform current again.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import hashlib
import os
import re
from adapters.native_feature_observation import exact,need,number
from feature_journeys.contract import identifier
from ios.adapters.assets_file_sources import private_original,node,sync

class AudioWholeEvidence:
    def __init__(self,flow):self.flow=flow
    def decode(self,rows):
        need(type(rows) is list and len(rows)<=64)
        for row in rows:
            exact(row,{'ticket','kind','sourceTicket','sourceReference','captureEpochMs','sha256','bytes','name','file','phase'})
            identifier(row['ticket']);identifier(row['sourceTicket'])
            need(row['kind'] in ('file','audio') and row['phase'] in ('planned','opened','saved') and type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}',row['sha256'])
                and type(row['bytes']) is int and 44<row['bytes']<=2*1024*1024 and number(row['captureEpochMs'],1,1e15))
            if row['phase']=='planned':need(row['file'] is None)
            else:
                exact(row['file'],{'device','inode','bytes','modifiedNs','changedNs'})
                need(all(type(n) is int and n>=0 for n in row['file'].values()) and row['file']['inode']>0)
            need(row['name']==self.name(row['ticket'],row['kind'],row['sha256']))
            if row['phase']=='saved':self.read(row)
            elif row['phase']=='opened':
                self.read_partial(row)
            if row['phase']=='saved':self.flow.validate_artifact_source(row)
        return rows
    def name(self,ticket,kind,sha):return 'audio11-'+self.flow.run+'-'+ticket+'-'+kind+'-'+sha[:16]+'.wav'
    def read(self,row):
        path=self.flow.public_root/row['name'];raw,info=private_original(path,2*1024*1024)
        need((info==row['file'] if row['phase']=='saved' else info['device']==row['file']['device'] and info['inode']==row['file']['inode']) and len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']);return raw
    def read_partial(self,row):
        import stat
        from adapters.original_file_reads import record
        path=self.flow.public_root/row['name'];fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        try:
            before=os.fstat(fd);need(stat.S_ISREG(before.st_mode) and stat.S_IMODE(before.st_mode)==0o600 and before.st_nlink==1
                and before.st_uid==os.geteuid() and before.st_dev==row['file']['device'] and before.st_ino==row['file']['inode'] and before.st_size<=row['bytes'])
            content=b''
            while len(content)<before.st_size:
                chunk=os.read(fd,min(65536,before.st_size-len(content)));need(chunk);content+=chunk
            need(node(before)==node(os.fstat(fd))==node(path.lstat()))
            expected=self.flow.validate_artifact_source(row,return_bytes=True);need(content==expected[:len(content)]);record(path);return content
        finally:os.close(fd)

    def retain(self,ticket,kind,raw,*,source_ticket,source_reference,capture_epoch):
        f=self.flow;need(type(raw) is bytes and 44<len(raw)<=2*1024*1024)
        sha=hashlib.sha256(raw).hexdigest();rows=f.state['artifacts'];existing=[r for r in rows if r['ticket']==ticket and r['kind']==kind]
        if existing:
            need(len(existing)==1);row=existing[0]
            need(row['sourceTicket']==source_ticket and row['sourceReference']==source_reference and row['captureEpochMs']==capture_epoch
                and row['sha256']==sha and self.read(row)==raw)
            if row['phase']!='saved':row['file']=node((f.public_root/row['name']).lstat());row['phase']='saved';f.save()
            return row
        need(len(rows)<64);row=dict(ticket=ticket,kind=kind,sourceTicket=source_ticket,sourceReference=deepcopy(source_reference),captureEpochMs=capture_epoch,
            sha256=sha,bytes=len(raw),name=self.name(ticket,kind,sha),file=None,phase='planned')
        rows.append(row);f.save();path=f.public_root/row['name'];fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb') as stream:
            row.update(phase='opened',file=node(os.fstat(stream.fileno())));f.save()
            need(stream.write(raw)==len(raw));stream.flush();os.fsync(stream.fileno())
            row['file']=node(os.fstat(stream.fileno()));f.save()
        sync(f.public_root);need(self.read(row)==raw);row['phase']='saved';f.save();return row
    def public(self,ticket,sequence,epoch):
        result=[]
        for row in self.flow.state['artifacts']:
            if row['ticket']!=ticket:continue
            need(row['phase']=='saved' and -250<=epoch-row['captureEpochMs']<=1500);self.read(row)
            result.append(dict(kind=row['kind'],name=row['name'],ticket=ticket,sequence=sequence,capturedEpochMs=row['captureEpochMs']))
        return result
    def owned_paths(self):return {self.flow.public_root/r['name'] for r in self.flow.state['artifacts'] if r['phase']!='planned'}
