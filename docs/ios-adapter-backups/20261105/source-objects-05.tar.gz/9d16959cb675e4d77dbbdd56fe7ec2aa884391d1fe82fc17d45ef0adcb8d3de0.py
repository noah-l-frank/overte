"""One unchanged fresh Primary4 test, fixed180+5; real package-main entry."""
def main():
 from pathlib import Path
 import builtins,faulthandler,hashlib,io,json,os,signal,stat,sys,tempfile,threading,time,traceback,types,unittest
 from .common import repo,pin,save,fds,census,kernel,validate_input,source_pins,no_sdk
 from .imports import ClosedFinder
 assert sys.flags.no_site and sys.dont_write_bytecode and len(sys.argv)==3
 SOURCE=Path(__file__).resolve().parent;R=repo();INPUT=Path(sys.argv[1]);digest=sys.argv[2]
 plan,input_before=validate_input(INPUT,digest);HERE=Path(plan['controllerRoot']);ROOM=HERE/'child-receipts';TOYS=HERE/'own-toys'
 assert SOURCE==Path(plan['packageSource'])and INPUT==HERE/'approved-inputs.json'
 assert Path(tempfile.gettempdir())==TOYS and len(plan['cases'])==1
 source_pins(plan)
 std=Path(os.__file__).resolve(strict=True).parent
 sys.path[:]=[str(SOURCE.parent),str(std),str(std/'lib-dynload')]
 import multiprocessing.connection as connection,multiprocessing.heap as heap,multiprocessing.spawn as spawn
 import multiprocessing.resource_tracker as tracker,multiprocessing.sharedctypes,multiprocessing.synchronize
 import multiprocessing.popen_spawn_posix as spawn_popen,multiprocessing.util as util
 finder=ClosedFinder(plan,SOURCE,R);finder.install();origin_before=finder.snapshot('before-project-imports')
 from owned_write_boundary import OwnedWrites
 from .locks import OriginalSourceLocks
 baseline=OwnedWrites(HERE,protected=[INPUT]);baseline.install();boundary=baseline;phase='imports';node=http=mp_life=None;source_locks=None
 original_ports=dict(baseline.original);original_cio=(io.open,builtins.open);original_dup=(os.dup,os.dup2)
 original_cleanup=unittest.TestCase.doCleanups;cleanup_calls=[];case_receipts=[];selected=[];result=None;fatal=None
 initial_fds=fds();initial_threads=tuple(threading.enumerate());initial_children=kernel(os.getpid())
 def audit(event,args):
  if event=='object.__getattr__':return
  if event=='import'and args[0].split('.')[0]in ('pymobiledevice3','pmd_pytcp','appium','selenium','PySide6','PyQt6'):
   raise RuntimeError('Physical SDK/native package refused')
  relevant=event in('open','os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink','os.setxattr','os.removexattr','os.chdir','os.chroot')or event.startswith('fcntl.')
  process_event=event in('subprocess.Popen','os.kill','os.system','os.exec','os.fork','os.forkpty','os.posix_spawn','pty.spawn','os.killpg','os.setsid','os.setpgid','ctypes.dlopen')or event.startswith('os.spawn')
  if not(event.startswith('socket.')or process_event or relevant):return
  frame=sys._getframe(1)
  if event.startswith('socket.'):
   assert phase=='target'and http is not None;http.audit(event,args,frame);return
  if event=='subprocess.Popen':assert phase=='target';node.spawn(args,frame);return
  if event=='os.kill':
   assert phase=='target'
   if frame.f_code is node.signal.code:node.signal_allowed(args,frame)
   else:mp_life.actor_signal(args,frame)
   return
  if event in('os.system','os.exec','os.fork','os.forkpty','os.posix_spawn','pty.spawn','os.killpg','os.setsid','os.setpgid','ctypes.dlopen')or event.startswith('os.spawn'):
   raise RuntimeError('No unbound process/native/signal port')
  if event=='fcntl.flock':
   assert source_locks is not None;source_locks.audit(args,frame)
  if relevant:boundary.audit(event,args,frame)
 # Preload required genuine stdlib before the write/audit gate captures its
 # original C defaults. ctypes interpreter-self initialization is completed
 # here, never permitted as a later native/SDK DLL route.
 sys.addaudithook(audit)
 from tablet_constructor_custody import RealTemporaryDirectoryRetention,OwnedArenaConfiguration,FunctionBinding
 from tablet_guarded_spawn import GuardedOriginalSpawn
 from tablet_ipc_capacity import ActualIPCCapacities
 from tablet_http_ports import ThreeOriginalHTTPServers
 from tablet_original_host_ports import OwnedLoopbacks
 from tablet_node_ports import TwoOriginalTabletNodes
 from parent_ports import ParentWrites
 from .monitor import LocalMonitor
 from .mp_lifetime import OriginalMPLifetime
 from raw_pipe_tee import install as install_raw_tee
 # Actual target imports stay closed and birth ports remain refused until
 # every real constructor/receiver is independently bound below.
 import ios.self_tests.test_tablet_fresh_primary_four as subject
 import ios.self_tests.test_ios_tablet_web_context as context
 import ios.self_tests.test_ios_installed_code as installed
 import ios.self_tests.tablet_web_paired_fixture as pair
 import ios.self_tests.test_ios_tablet_web_open_admission as opened
 import ios.self_tests.tablet_web_echo_fixture as echo
 import ios.self_tests.tablet_web_host_app as host
 import feature_journeys.server as fixture
 from ios.self_tests.retained_host_roots import retain_owned_root
 source_locks=OriginalSourceLocks(TOYS);source_locks.bind(sys.modules['adapters.script_feature.lock'])
 baseline.restore()  # Capture original C ports in capacities before router installation.
 def save_actual(name,body):save(ROOM,name,body)
 retained=RealTemporaryDirectoryRetention(TOYS,((context.TabletWebContextTests,context.TabletWebContextTests.setUp),(installed.InstalledCodeTests,installed.InstalledCodeTests.setUp)),retain_owned_root)
 def producer_roots():return tuple(Path(row['path'])for row in retained.rows)
 arena=OwnedArenaConfiguration(TOYS,heap,pair.PairedTabletFixture.__init__)
 http=ThreeOriginalHTTPServers(original_loopbacks_class=OwnedLoopbacks,paired_class=pair.PairedTabletFixture,
  sdk_class=pair.SDKBridge,fixture_server_class=fixture.FixtureServer,make_server=fixture.make_server,pipe_function=connection.Pipe)
 def transport_scope():
  return dict(numericEndpoints=[list(address)for family,address in http.original.current_servers()],
   actualArenaInodes=[[row['device'],row['inode']]for owner,buffer,row in arena.arenas])
 spawn_guard=GuardedOriginalSpawn(util_module=util,spawn_module=spawn,popen_module=spawn_popen,tracker_module=tracker,
  actor_function=opened.admission_actor,paired_class=pair.PairedTabletFixture,run_open_function=opened.TabletOpenAdmissionTests.run_open,
  guard_path=SOURCE/'child.py',guard_pin=plan['physicalPins'][str(SOURCE/'child.py')],policy_path=INPUT,policy_pin=input_before,
  owned_root=HERE,actor_roots=producer_roots,save_row=save_actual,transport_scope=transport_scope)
 ipc=ActualIPCCapacities(connection,tracker,{})
 node=TwoOriginalTabletNodes(plan=plan,repo=R,actual_js=echo.actual_js,host_app_class=host.TabletHostApp,producer_roots=producer_roots)
 mp_life=OriginalMPLifetime(arena,ipc,spawn_guard,save_actual)
 monitor=LocalMonitor();thread_rows=[];thread_binding=FunctionBinding(threading.Thread.start)
 server_loop=FunctionBinding(__import__('socketserver').BaseServer.serve_forever)
 def observe_thread(frame):
  thread_binding.frame(frame);owner=frame.f_locals['self'];target=owner._target
  assert type(owner)is threading.Thread and type(target)is types.MethodType and owner.daemon is True
  rows=[row for row in http.rows if row['server']is target.__self__];assert len(rows)==1
  if target.__func__ is server_loop.function:kind='server'
  else:
   assert target.__func__ is http.http_request.function;kind='request'
   request,address=owner._args;assert type(request)is http.socket_class
   info=os.fstat(request.fileno());assert stat.S_ISSOCK(info.st_mode)
   assert request.getsockname()==rows[0]['server'].socket.getsockname()and address[0]=='127.0.0.1'
  thread_rows.append((owner,kind))
 def node_return(frame,value):
  assert value is None;node.returned(frame);row=node.entries[-1]
  directory=HERE/'child-logs'/('node-'+str(len(node.entries)));directory.mkdir(mode=0o700)
  row['tee']=install_raw_tee(row['owner'],directory)
 def pipe_return(frame,result):
  ipc.pipe_binding.frame(frame)
  assert type(result)is tuple and len(result)==2 and len(http.socketpairs)==1
  for obj in result:ipc.register_parent_connection(obj,actual_pipe_frame=frame,pipe_binding=ipc.pipe_binding,observed_socket_pair=http.socketpairs[0][1])
 # Only these actual functions receive local monitoring callbacks.
 ipc.pipe_binding=FunctionBinding(connection.Pipe)
 monitor.add(node.init.function,start=node.begin,returned=node_return)
 monitor.add(node.execute.function,returned=node.executed_returned)
 monitor.add(arena.constructor.function,start=arena.begin,returned=lambda frame,value:arena.returned(frame))
 monitor.add(connection.Pipe,returned=pipe_return)
 monitor.add(__import__('socket').socketpair,returned=http.socketpair_returned)
 monitor.add(tracker.ResourceTracker._launch,returned=mp_life.tracker_returned)
 monitor.add(__import__('multiprocessing.synchronize',fromlist=['SemLock']).SemLock.__init__,returned=mp_life.semaphore_returned)
 monitor.add(util.Finalize.__call__,returned=mp_life.finalize_returned,unwind=mp_life.finalize_unwound)
 monitor.add(threading.Thread.start,start=observe_thread)
 boundary=ParentWrites(HERE,ipc,http,node,mp_life,[INPUT])
 subject.CONTROL=dict(save=save_actual,outputRoot=str(ROOM))
 def observe_cleanup(case):
  pending=len(case._cleanups);returned=original_cleanup(case)
  cleanup_calls.append(dict(id=case.id(),remaining=len(case._cleanups),pendingBefore=pending,originalReturned=returned));return returned
 unittest.TestCase.doCleanups=observe_cleanup
 trace=(HERE/'child-logs/term-stack.log').open('x')
 def stop(sig,frame):
  faulthandler.dump_traceback(file=trace,all_threads=True);trace.flush();raise KeyboardInterrupt('Fixed180+5 boundary')
 old_term=signal.signal(signal.SIGTERM,stop)
 class Result(unittest.TextTestResult):
  def startTest(self,test):selected.append(test.id());super().startTest(test)
  def stopTest(self,test):
   case_receipts.append(dict(id=test.id(),actualStandardStopAfterCleanup=True,pendingCleanups=len(test._cleanups),
    actualFDsAfterOriginalCleanup=fds(),threadsAfterOriginalCleanup=[t.name for t in threading.enumerate()]))
   super().stopTest(test)
 initialization=dict(stage='before-controlled-installation',completed=[],finished=False,caseRunCallAttempted=False)
 report=dict(status='FAIL',testsRun=None,actualCaseReceipts=case_receipts,nativeQualified=False,wholeQualified=False)
 try:
  for label,action in(('OS',boundary.install),('TD',retained.install),('arena',arena.install),('IPC',ipc.install),('spawn',spawn_guard.install),('monitor',monitor.install)):
   initialization['stage']=label;action();initialization['completed'].append(label)
  initialization.update(stage='selected-case',finished=True);phase='target'
  cases=unittest.defaultTestLoader.loadTestsFromNames(plan['cases']);assert cases.countTestCases()==1
  initialization['caseRunCallAttempted']=True
  result=unittest.TextTestRunner(stream=sys.stdout,verbosity=2,resultclass=Result,failfast=True).run(cases)
  report['testsRun']=result.testsRun
  assert result.wasSuccessful()and selected==plan['cases']and len(case_receipts)==1
  assert not case_receipts[0]['pendingCleanups']and all(row['originalReturned']is True and row['remaining']==0 for row in cleanup_calls)
  assert len(retained.rows)==2
  report['node']=node.finish()
  assert all(row['tee']and all(x['tee'].closed and x['log'].closed and x['buffer'].closed for x in row['tee'])for row in node.entries)
  report['actualRawNodeByteTeeEstablished']=True
  deadline=time.monotonic()+5
  for thread,kind in thread_rows:thread.join(max(0,deadline-time.monotonic()))
  assert all(not thread.is_alive()for thread,kind in thread_rows)
  assert sum(kind=='server'for thread,kind in thread_rows)==3
  report['sourceLocks']=source_locks.finish()
  report['http']=http.finish();report['actualOwnedHTTPThreadsDrained']=True
  report['stdlibRetirement']=mp_life.retire_original_stdlib()
  assert len(spawn_guard.records)==2 and [row['role']for row in spawn_guard.records]==['tracker','actor']
  assert all(kernel(row['kernel']['pid'])is None for row in spawn_guard.records)
  report['status']='PASS'
 except BaseException as original_failure:
  fatal=traceback.format_exc();report['fatal']=fatal;report['primaryFailure']=dict(type=type(original_failure).__name__,message=str(original_failure),stage=initialization['stage'])
 finally:
  # This independent observation must not prevent genuine original restoration.
  observation_errors=[]
  try:report['actualNodeFailureOrSuccessDrainLedger']=node.failure_ledger()
  except BaseException:observation_errors.append(dict(component='node-failure-ledger',traceback=traceback.format_exc()))
  subject.CONTROL=None;unittest.TestCase.doCleanups=original_cleanup
  # Each independent restoration is attempted; an initial failure remains
  # nonzero even if controller-owned cleanup later closes resources.
  restoration={};errors=list(observation_errors)
  for name,action in(('monitor',monitor.restore),('spawn',spawn_guard.restore),('arena',arena.restore),('TD',retained.restore),('OS',boundary.restore),('IPC',ipc.finish)):
   try:restoration[name]=action()
   except BaseException:errors.append(dict(component=name,traceback=traceback.format_exc()))
  phase='closed'
  for name,action in(('original-term-handler',lambda:signal.signal(signal.SIGTERM,old_term)),('original-trace-close',trace.close)):
   try:action()
   except BaseException:errors.append(dict(component=name,traceback=traceback.format_exc()))
  # Filesystem ports are restored, but the immutable audit hook still permits
  # only the exact trusted final control writer via the original helper.
  boundary=OwnedWrites(HERE,protected=[INPUT])
  report.update(initialization=initialization,selected=selected,actualCaseReceipts=case_receipts,actualNestedStandardCleanups=cleanup_calls,
   retainedTemporaryDirectories=retained.rows,restoration=restoration,restorationErrors=errors,
   originalPortsRestored=all(getattr(os,n)is value for n,value in original_ports.items()),
   originalCIOUnchanged=(io.open,builtins.open)==original_cio,dupRestored=(os.dup,os.dup2)==original_dup,
   actualThreadRows=[dict(name=t.name,ident=t.ident,nativeID=t.native_id,kind=k,alive=t.is_alive())for t,k in thread_rows],
   actualFDsBefore=initial_fds,actualFDsAfterRetirement=fds(),actualThreadsAfter=[t.name for t in threading.enumerate()])
  try:
   no_sdk();assert not errors and report['originalPortsRestored']and report['originalCIOUnchanged']and report['dupRestored']
   assert tuple(threading.enumerate())==initial_threads
   allowed={(row['device'],row['inode'])for owner,buffer,row in arena.arenas}
   extras={fd:row for fd,row in fds().items()if initial_fds.get(fd)!=row}
   assert all((row['device'],row['inode'])in allowed for row in extras.values())
   report['actualProcessLifetimeFDs']=extras;report['actualOrigins']=finder.snapshot('after-selected-original-and-cleanup')
   source_pins(plan);assert pin(INPUT)==input_before and input_before['sha256']==digest
   report['inputUnchanged']=True;report['sourcePinsUnchanged']=True
  except BaseException:
   report['status']='FAIL';report['finalGateError']=traceback.format_exc()
  if errors:report['status']='FAIL'
  def final_original_write(name,body):
   assert name in('actual-selection.json','report.json')and boundary.root==HERE
   target=ROOM/name;assert target.parent==ROOM and target.resolve(strict=False)==target and not target.exists()
   descriptor=boundary.os_open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
   try:
    before=os.fstat(descriptor)
    assert stat.S_ISREG(before.st_mode)and before.st_nlink==1 and stat.S_IMODE(before.st_mode)==0o600
    with os.fdopen(descriptor,'w',closefd=False)as stream:json.dump(body,stream,sort_keys=True,indent=2);stream.write('\n')
    after=os.fstat(descriptor);path=target.lstat()
    assert(after.st_dev,after.st_ino)==(before.st_dev,before.st_ino)==(path.st_dev,path.st_ino)
   finally:boundary.original['close'](descriptor)
  try:
   final_original_write('actual-selection.json',dict(ids=selected,expectedIds=plan['cases']))
   final_original_write('report.json',report)
  except BaseException:
   report['status']='FAIL';sys.stderr.write('Secondary final original report failure:\n'+traceback.format_exc())
  if fatal:sys.stderr.write(fatal)
  assert sys.gettrace()is None and sys.getprofile()is None
 return 0 if report['status']=='PASS'else 1
if __name__=='__main__':
 import sys
 try:code=main()
 except BaseException:
  import traceback;traceback.print_exc();code=1
 raise SystemExit(code)
