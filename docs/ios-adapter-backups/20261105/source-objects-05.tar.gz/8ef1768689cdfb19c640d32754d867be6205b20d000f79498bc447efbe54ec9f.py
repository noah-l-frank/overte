from pathlib import Path
import ast,difflib,hashlib,json
R=Path.cwd();T=R/'.ios-host-tmp';P=T/'lifecycle-original-owner-resource4-observation-core-draft-20261029';P.mkdir(mode=0o700);H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rel='tests/device/ios/adapters/lifecycle_touch_resource_owner.py';base=R/rel;s=base.read_text()
s=s.replace("and action in (world.ACTION,'feature-native-observe') and session==resource.binding['sessionId']", "and action in (world.ACTION,'feature-native-observe','touch-resource-capture') and session==resource.binding['sessionId']",1)
s=s.replace('    def __init__(self,store,binding,run,lock,guard):','    def __init__(self,store,binding,run,lock,guard,*,_observation_parent=None):',1)
old="        self.store,self.binding,self.run,self.lock,self.check=store,deepcopy(context(binding)),identifier(run),lock,guard\n        need(store.path.name=='ios-lifecycle-touch-resources-'+run+'.json' and lock.path==store.path.parent/'script-feature-sources.lock')"
new="""        self.store,self.binding,self.run,self.lock,self.check=store,deepcopy(context(binding)),identifier(run),lock,guard
        self._observation_parent=None if _observation_parent is None else weakref.ref(_observation_parent)
        self._observation_owner=None;self._observation_birth=None
        if _observation_parent is not None:
            parent=_observation_parent
            need(type(parent) is LifecycleTouchResourceOwner and parent.version==4
                and type(parent._native_step) is _NativeMotionWorkerGuard
                and parent._native_step._worker() is asyncio.current_task()
                and parent._loop is asyncio.get_running_loop()
                and type(parent._source) is resources.TouchResourceObservation
                and same(parent.binding,self.binding) and parent.run==self.run and lock is parent.lock)
        name=('ios-lifecycle-touch-resource-observations-' if _observation_parent is not None else 'ios-lifecycle-touch-resources-')+run+'.json'
        need(store.path.name==name and lock.path==store.path.parent/'script-feature-sources.lock')""";assert s.count(old)==1;s=s.replace(old,new,1)
old="        self.version=1 if self.previous is None else self.previous.get('iosLifecycleTouchResourceOwnerVersion')";new=old+"\n        if _observation_parent is not None:need(self.previous is None) # No archive may recreate this live observation owner.";assert s.count(old)==1;s=s.replace(old,new,1)
old="        if self.version==2:\n            raise TouchTransportUnavailable('Original child native world/geometry/current deadline guard is not connected for motion')";new="        need(self._observation_parent is None) # A passive recorder never owns another HID factory.\n"+old;assert s.count(old)==1;s=s.replace(old,new,1)
old="                self._source=resources.TouchResourceObservation(rsd);self._retained=RetainedTouchWorker(lease)\n                self._loop=asyncio.get_running_loop()";new=old+"\n                self._begin_motion_observation(lease) # Original worker BEFORE actual SDK/context opening.";assert s.count(old)==1;s=s.replace(old,new,1)
marker='    def intent(self,kind,reference):'
methods='''    def _begin_motion_observation(self,lease):
        # Reuse the existing v1 capture journal/codec, separate from the
        # immutable v4 PREPARATION bytes. This creates no second SDK/HID owner.
        need(self.version==4 and self._observation_owner is None
            and type(lease) is TouchLease and self._lease() is lease
            and lease.worker is asyncio.current_task() and self._native_step._worker() is lease.worker
            and self._loop is asyncio.get_running_loop() and lease.previous['phase']=='opening')
        source=self._motion_source();owner=self._motion_original._owner();observer=self._source
        need(source is self._native_step._source() and owner is self._native_step._owner()
            and owner.source is source and owner.touch_resources is self and owner.touch is lease
            and type(observer) is resources.TouchResourceObservation
            and observer._worker() is lease.worker and observer._loop() is self._loop
            and observer._refs['rsd']() is self._motion_rsd()
            and type(self._retained) is RetainedTouchWorker and self._retained._lease is lease)
        row=next((row for row in source._born if row['lease'] is lease),None)
        need(row is not None and row.get('motionResource') is self and row.get('motionStep') is self._native_step)
        parent=weakref.ref(self)
        def original_current():
            actual=parent();need(type(actual) is LifecycleTouchResourceOwner)
            return actual._motion_observation_identity(live=True)
        recorder=LifecycleTouchResourceOwner(PrivateFeatureState(self.store.path.with_name('ios-lifecycle-touch-resource-observations-'+self.run+'.json')),
            self.binding,self.run,self.lock,original_current,_observation_parent=self)
        # Retain before the first journal CAS can lose its original return.
        self._observation_owner=recorder
        recorder._source=observer;recorder._retained=self._retained;recorder._lease=weakref.ref(lease)
        recorder._factory=self._factory;recorder._loop=self._loop
        recorder._observation_birth=(weakref.ref(source),weakref.ref(owner),weakref.ref(self._motion_rsd()),
            weakref.ref(lease.worker),row,resources.TouchResourceObservation.snapshot,source.current.__func__)
        recorder.state=dict(phase='factory-issued',leaseFile=lease.store.path.name,leaseOpening=deepcopy(lease._opening),
            sourceInstance=observer.instance,hostProcessId=os.getpid(),frames=[],pending=None)
        owner_header(recorder.envelope(),self.binding,self.run);recorder.save()

    def _motion_observation_identity(self,*,live):
        need(type(live) is bool and self.version==4 and type(self._native_step) is _NativeMotionWorkerGuard)
        recorder=self._observation_owner;lease=self._lease();observer=self._source;loop=asyncio.get_running_loop()
        need(type(recorder) is LifecycleTouchResourceOwner and recorder.version==1
            and recorder._observation_parent() is self and type(lease) is TouchLease
            and type(observer) is resources.TouchResourceObservation and recorder._source is observer
            and recorder._lease() is lease and recorder._retained is self._retained and recorder._factory is self._factory
            and recorder._loop is self._loop is loop and lease.worker is self._native_step._worker()
            and lease._session_factory is self._factory and self._retained._lease is lease)
        source_ref,owner_ref,rsd_ref,worker_ref,row,snapshot,current=recorder._observation_birth
        source,owner,rsd,worker=source_ref(),owner_ref(),rsd_ref(),worker_ref()
        need(source is not None and owner is not None and rsd is not None and worker is not None
            and source is self._motion_source() and owner is self._motion_original._owner()
            and source._loop is loop and source.current.__func__ is current
            and rsd is self._motion_rsd() and worker is lease.worker and worker.get_loop() is loop
            and observer._loop() is loop and observer._worker() is worker and observer._refs['rsd']() is rsd
            and observer.snapshot.__func__ is snapshot and observer.instance==recorder.state['sourceInstance']
            and row in source._born and row['lease'] is lease and row['worker'] is worker
            and row.get('motionResource') is self and row.get('motionStep') is self._native_step
            and recorder.state['hostProcessId']==os.getpid())
        self.file_guard();self._retained._status();row['owner']._status()
        if live:
            if asyncio.current_task() is worker:
                need(lease.previous['phase']=='opening' and not lease.down_issued and not worker.done())
                self._native_step.scope()
            else:
                scope=owner.native_passive_tasks.get(asyncio.current_task())
                need(type(scope) is _NativeMotionPassiveRead and scope._resource() is self
                    and scope._action=='touch-resource-capture');scope.current()
        return True

    def observation_header(self):
        self._motion_observation_identity(live=False);recorder=self._observation_owner
        recorder.file_guard();return deepcopy(recorder.previous)

    def observation_original(self,reference):
        self._motion_observation_identity(live=False);recorder=self._observation_owner;recorder.file_guard()
        need(reference in recorder.state['frames'])
        value=recorder.files.read(recorder.files.expand(reference))
        index=reference['index'];previous=None if index==1 else recorder.files.read(recorder.files.expand(recorder.state['frames'][index-2]))
        recorder.frame(value,previous=previous);recorder.file_guard();return value

'''
assert s.count(marker)==1;s=s.replace(marker,methods+marker,1)
old="    def capture(self):\n        self.current();need(self.version==1";new="""    def capture(self):
        if self.version==4:
            self._motion_observation_identity(live=True)
            return self._observation_owner.capture()
        self.current();need(self.version==1""";assert s.count(old)==1;s=s.replace(old,new,1)
old="    def recover_capture(self):\n        # Exact saved adoption only.";new="""    def recover_capture(self):
        if self.version==4:
            self._motion_observation_identity(live=False);recorder=self._observation_owner
            if recorder.state['pending'] is not None:return recorder.recover_capture()
            # An already committed original may have lost only its transport
            # return. Reopen that SAME original, never snapshot or replay SDK.
            need(recorder.state['frames']);return self.observation_original(recorder.state['frames'][-1])
        # Exact saved adoption only.""";assert s.count(old)==1;s=s.replace(old,new,1)
basecopy=P/'bases/repo'/rel;out=P/'candidate/repo'/rel
for path in (basecopy,out):path.parent.mkdir(parents=True,exist_ok=True)
basecopy.write_bytes(base.read_bytes());out.write_text(s);ast.parse(s);(P/'resource-source-checkpoint.diff').write_text(''.join(difflib.unified_diff(basecopy.read_text().splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(P/'checkpoint.json').write_text(json.dumps(dict(status='PRIVATE_ACTIVE_SOURCE_DRAFT_UNRUN_NOT_FROZEN',source=dict(path=rel,baseSHA256=H(basecopy),candidateSHA256=H(out)),exactVersion4Only=True,default1BodyPreserved=True,immutablePreparationWALBytesPreserved=True,existingV1CaptureWALCodecReused=True,newObserverWAL='ios-lifecycle-touch-resource-observations-<run>.json',noSecondFactoryOrLease=True,ensureRetiredUnchanged=True,remaining=['existingSourceRPCexplicitprofile4tupleguard+exclusiveactualScope','existingref/chunktransport+taskdone/readphysicalproof','hostactualresource_metadata optionalprofile3 consumer','positiveactualtouch_session SDK-model5resources +foreign+lostreturn+busy models'],imports=False,testsRun=False),indent=2)+'\n');print(json.dumps(dict(path=str(P),source=rel,candidateSHA256=H(out)),indent=2))
