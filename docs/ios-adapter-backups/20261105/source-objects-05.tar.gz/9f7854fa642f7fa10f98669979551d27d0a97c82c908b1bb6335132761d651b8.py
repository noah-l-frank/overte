"""Readonly native fixed-file v1 grammar, not transport/process/SDK authority.

A genuine native producer is proposed separately. No live host sender is
installed: the current probe has no owned result-delivery channel for this
family. Grammar success cannot discharge Source3 pending queries or grant End.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import re,stat
from adapters.native_feature_observation import exact,integer,need
from adapters.normal_feature_state import context
from adapters.script_feature.history import same
from ios.adapters.emote_palette_original import validate as palette,command as palette_command

ACTION='feature-ios-emote-palette-file'
FILE='feature-ios-emote-palette.json'
METADATA=('device','inode','mode','uid','gid','nlink','bytes','mtimeNs','ctimeNs')


def _hex(value):need(type(value)is str and re.fullmatch('[0-9a-f]{32}',value)is not None)
def _nonce(value):need(type(value)is str and re.fullmatch('ios-[0-9a-f]{32}',value)is not None)
def _metadata(value,*,links):
    exact(value,set(METADATA))
    for item in value.values():need(type(item)is str and re.fullmatch('0|[1-9][0-9]{0,20}',item)is not None)
    numbers={name:int(item)for name,item in value.items()}
    need(all(0<=item<=2**64-1 for item in numbers.values())and numbers['inode']>0 and numbers['nlink']==links and stat.S_ISREG(numbers['mode'])
        and stat.S_IMODE(numbers['mode'])==0o600 and 1<=numbers['bytes']<=250000)
    return numbers


def decode_file_original(value,query,binding,previous=None):
    binding=context(binding);pid=int(binding['processIdentity']);need(str(pid)==binding['processIdentity']and pid>0)
    operation=query.get('operation');need(operation in('observe','retire'))
    keys={'schemaVersion','commandId','action','operation','runId'}
    exact(query,keys|({'ownerInstance','generation','paletteRequestId'}if operation=='retire'else set()))
    need(type(query['schemaVersion'])is int and query['schemaVersion']==1 and query['action']==ACTION)
    _nonce(query['commandId']);_hex(query['runId'])
    if operation=='retire':_hex(query['ownerInstance']);_nonce(query['paletteRequestId']);need(integer(query['generation'],1,1000000000))
    exact(value,{'iosEmotePaletteFileVersion','requestId','runId','instance','sequence','processId','clockDomain','clockBefore','clockAfter','source'})
    need(type(value['iosEmotePaletteFileVersion'])is int and value['iosEmotePaletteFileVersion']==1
        and value['requestId']==query['commandId']and value['runId']==query['runId']and integer(value['processId'],1)and value['processId']==pid
        and integer(value['sequence'],1,1000000000)and value['clockDomain']=='native-main-emote-palette-file')
    _hex(value['instance'])
    for item in(value['clockBefore'],value['clockAfter']):
        exact(item,{'epochMs','monotonicMs'});need(integer(item['epochMs'],1)and integer(item['monotonicMs']))
    elapsed=value['clockAfter']['epochMs']-value['clockBefore']['epochMs'];mono=value['clockAfter']['monotonicMs']-value['clockBefore']['monotonicMs']
    need(0<=elapsed<1500 and 0<=mono<1500 and abs(elapsed-mono)<=250)
    exact(value['source'],{'complete','ownership'});need(type(value['source']['complete'])is bool)
    original=value['source']['ownership']
    exact(original,{'iosEmotePaletteFileOwnedOriginalVersion','instance','processId','generation','phase','retirementIssued','pendingPublication','file','afterRetirement','processDeathProved','sdkAbsentProved'})
    need(type(original['iosEmotePaletteFileOwnedOriginalVersion'])is int and original['iosEmotePaletteFileOwnedOriginalVersion']==1
        and integer(original['processId'],1)and original['processId']==pid and integer(original['generation'],0,1000000000)
        and original['phase']in('unobserved','owned','retired','unknown')and type(original['retirementIssued'])is bool
        and type(original['pendingPublication'])is bool and original['processDeathProved']is False and original['sdkAbsentProved']is False)
    _hex(original['instance']);phase=original['phase'];file=original['file'];need(type(file)is dict and type(original['afterRetirement'])is dict)
    need(value['source']['complete']is (phase in('owned','retired')and not original['pendingPublication']))
    if file:
        exact(file,{'name','metadata','sha256','bytes','palette'});need(file['name']==FILE and integer(file['bytes'],1,250000)
            and type(file['sha256'])is str and re.fullmatch('[0-9a-f]{64}',file['sha256'])is not None)
        before=_metadata(file['metadata'],links=1);need(before['bytes']==file['bytes']and original['generation']>=1)
        packet=file['palette'];palette(packet,palette_command(dict(schemaVersion=1,commandId=packet['requestId'],action='feature-ios-emote-palette',runId=query['runId'])),pid)
        # The old palette stays an old literal original. A fresh file read is
        # not permission to retime its computation/history or claim playback.
        if phase=='retired':
            after=_metadata(original['afterRetirement'],links=0)
            need(original['retirementIssued']is True and not original['pendingPublication']
                and all(after[k]==before[k]for k in('device','inode','mode','uid','gid','bytes','mtimeNs'))
                and after['ctimeNs']>=before['ctimeNs'])
        else:need(original['afterRetirement']=={} or phase=='unknown')
    else:need(phase in('unobserved','unknown')and original['afterRetirement']=={})
    if phase=='owned':need(original['retirementIssued']is False and not original['pendingPublication'])
    if phase=='unobserved':need(original['generation']==0 and not original['retirementIssued']and not original['pendingPublication'])
    if operation=='retire':
        need(original['instance']==query['ownerInstance']and original['generation']==query['generation']
            and file and file['palette']['requestId']==query['paletteRequestId']and original['retirementIssued']is True)
    if previous is not None:
        old=previous['source']['ownership']
        need(value['instance']==previous['instance']and value['sequence']>previous['sequence']
            and original['instance']==old['instance']and original['generation']>=old['generation']
            and value['clockBefore']['epochMs']>=previous['clockAfter']['epochMs']
            and value['clockBefore']['monotonicMs']>=previous['clockAfter']['monotonicMs'])
        if old['phase']=='unknown':need(phase=='unknown')
        if old['retirementIssued']:need(original['retirementIssued']and phase in('retired','unknown')and original['generation']==old['generation'])
        if original['generation']==old['generation']and old['file']:need(same(file,old['file']))
    return deepcopy(value)
