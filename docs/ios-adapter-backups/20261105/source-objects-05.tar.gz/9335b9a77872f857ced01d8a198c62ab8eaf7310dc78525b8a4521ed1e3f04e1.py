"""Read-only close of actual pre-case local-monitor failure; no target rerun."""
from pathlib import Path
import json,hashlib,runpy
B=Path.cwd()/'.ios-host-tmp'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(o,n,v):
 with(o/n).open('x')as s:json.dump(v,s,sort_keys=True,indent=2);s.write('\n')
h=B/'tablet-fresh-primary-four-prepared-headd483-current1210-b7-20261105';o=h.with_name(h.name+'-outer')
assert sha(h/'approved-inputs.json')=='56a975dc420a66838b54e9e55d0fde8adb842ffdf1a48eeb273e33aae4f1fdf8'
t=load(o/'terminal.json');assert t['status']=='FAIL'and t['childReturnCode']==1
for key in('ownProcessesAbsent','globalOriginalsExactlyUnchanged','inputExact','sourcePinsUnchanged','actualParentFDThreadDrain','twoFullWholeRootCensusesEqual'):assert t[key]is True
assert t['fullOwnCensusExclusions']==t['violations']==t['rescued']==t['remainingOwnedProcesses']==t['controllerOwnedSemaphoreRescue']==[]
assert t['timedOut']is t['forcedKill']is False and t['gateError']is not None
assert not(h/'child-receipts/report.json').exists()
raw=h/'child-logs/stderr.log';text=raw.read_text();assert 'monitor.install()'in text and 'set_local_events'in text and 'ValueError: invalid local event set 0x2005'in text
assert not any((h/'own-toys').iterdir())and not any((h/'child-processes').iterdir())and not any((h/'bindings').iterdir())
drain=load(o/'actual-kernel-drain.json');assert len(drain['actualObserved'])==1 and drain['remaining']==drain['rescued']==drain['controllerOwnedSemaphoreRescue']==[]and drain['forced']is drain['timedOut']is False
for row in drain['actualObserved']:
 try:proc=Path('/proc',str(row['pid']),'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 assert int(proc[proc.rfind(')')+2:].split()[19])!=row['startTicks']
groups={r['group']for r in drain['actualObserved']};same=[]
for proc in Path('/proc').iterdir():
 if not proc.name.isdecimal():continue
 try:body=(proc/'stat').read_text()
 except(FileNotFoundError,ProcessLookupError):continue
 fields=body[body.rfind(')')+2:].split()
 if int(fields[2])in groups or int(fields[3])in groups:same.append(dict(pid=int(proc.name),group=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19])))
assert same==[]
ctx=load(B/'root-ios-current1210-after-assets-second01-b8-input-shadow-negative-context-20261105/root-context.json');old=load(ctx['globalCustody']['baseline']['path']);assert len(old)==1210
assert load(o/'global-originals-before.json')==load(o/'global-originals-after-first.json')==load(o/'global-originals-after-second.json')==old
assert load(o/'source-before.json')==load(o/'source-after.json')and load(o/'approved-input-before.json')==load(o/'approved-input-after.json')
assert load(o/'whole-root-after-first.json')==load(o/'whole-root-after-second.json')
source=B/'root-terminal-custody-advance2-terminal-failures-retained-20261104/advance.py';assert sha(source)=='1a00174d599620fcb90f9e42bc378ad45f7ee6457c078b778cf40470ac4a00be';census=runpy.run_path(str(source))['census']
rooms=[h,h/'own-toys',o];first={str(p):census(p)for p in rooms};second={str(p):census(p)for p in rooms};assert first==second
out=B/'root-tablet-first4-b7-original-local-unwind-failure-complete-custody-results-20261105';out.mkdir(mode=0o700)
put(out,'whole-first.json',first);put(out,'whole-second.json',second)
put(out,'actual-root-kernel-absence.json',dict(originals=drain['actualObserved'],remainingSameGroupOrSession=same,observationsGrantNoSignalAuthority=True))
refs={str(p):dict(path=str(p),sha256=sha(p))for root in rooms for p in sorted(root.rglob('*'))if p.is_file()and not p.is_symlink()}
terminal=dict(childReturnCode=t['childReturnCode'],returnCodeScope='Actual original fresh-four SUT runner; outer supervisor also returned1',ownProcessesAbsent=True,problems=t['violations'],timedOut=t['timedOut'],forcedKill=t['forcedKill'],custodyProjectionOnly=True)
put(out,'results.json',dict(status='ROOT_RETAINED_TABLET_FIRST4_B7_ORIGINAL_PRECASE_LOCAL_PY_UNWIND_REFUSAL',terminal=terminal,originalSupervisorTerminal=t,originalKernelDrain=drain,newOriginalRoots=list(map(str,rooms+[out])),actualOldRootsUnchanged=1210,actualOriginalTestCasesExecuted=0,actualSDKOrNativeExecutions=0,originalInnerReport=None,originalInnerRestorationReceipt=None,originalFailure=dict(path=str(raw),sha256=sha(raw),message='Actual Python3.14 local PY_UNWIND mask0x2005 refused before suite'),actualSupervisorToolCompletion=dict(session=7569,chunkId='d2391e',exitCode=1),rootAfterStopEntireHEREAndOuterTwiceEqual=True,consumerCaseQualified=False,nativeQualified=False,featureQualified=False,wholeQualified=False))
put(out,'actual-receipt-references.json',refs);put(out,'freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in out.iterdir()}));print(json.dumps(dict(freeze=sha(out/'freeze.json'),results=sha(out/'results.json'),references=len(refs),newRoots=4)))
