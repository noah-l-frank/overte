"""Genuine EditorDomain constructor plus explicit lower Moving UI state models.

No Feature/Scope/manager/SDK/native/Node producer is constructed here. The
existing EditorDomain owners and their original standard cleanups remain real.
"""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import unittest
from adapters.normal_ui import NativeUIError
from ios.adapters import lifecycle_navigation_controls as navigation
from ios.self_tests.test_ios_lifecycle_editors import EditorDomain
from lifecycle_moving_raw_ui import RawMovingUI


class MovingNavigationMembershipModels(unittest.TestCase):
    def setUp(self):
        self.editor=EditorDomain(self)
        self.normal=SimpleNamespace(d=self.editor)
        # Explicit lower channel data only. No Source, feature owner or native
        # verdict is synthesized and these tests issue no channel operation.
        self.channels=SimpleNamespace(world=SimpleNamespace(view_mode='first person look at'),
            worker=SimpleNamespace(running=False))
        self.ui=RawMovingUI(self,self.channels)

    def packet(self):
        original=self.editor.observed();before=deepcopy(original)
        value=self.ui.decorate(original)
        self.assertEqual(before,original)
        navigation.membership(value)
        self.assertTrue(value['lifecycleNavigation']['complete'])
        expected={row['id']:row for row in value['controls']if row['id']in navigation.IDS}
        actual={row['controlId']:row for row in value['lifecycleNavigation']['controls']}
        self.assertEqual(set(expected),set(actual))
        for name,row in actual.items():
            self.assertEqual(expected[name]['token'],row['token'])
            self.assertEqual(self.editor.object(name),row['controlObject'])
            self.assertEqual(self.editor.object('window'),row['windowObject'])
        return value

    def test_actual_ancestor_launcher_inventory_refuses_when_only_moving_controls_are_replaced(self):
        self.ui.activate('tablet.open')
        original=self.editor.observed();bad=deepcopy(original);bad['controls']=self.ui.controls(original)
        before={row['controlId']for row in bad['lifecycleNavigation']['controls']}
        actual={row['id']for row in bad['controls']if row['id']in navigation.IDS}
        self.assertEqual({'create.entry','chat.entry'},before-actual)
        self.assertEqual({'scripts.menu'},actual-before)
        with self.assertRaises(NativeUIError):navigation.membership(bad)

    def test_same_real_launcher_state_produces_exact_visible_navigation_rows_without_old_packet_mutation(self):
        self.ui.activate('tablet.open');value=self.packet()
        self.assertEqual({'scripts.entry','scripts.menu','tablet.close'},
            {row['controlId']for row in value['lifecycleNavigation']['controls']})
        self.assertTrue(value['tabletShown'])

    def test_actual_ordinary_route_transitions_keep_control_and_navigation_tokens_joined(self):
        self.packet()
        for control in('tablet.open','scripts.menu','scripts.menu-edit','scripts.menu-running','tablet.home','tablet.close'):
            self.ui.activate(control);self.packet()

    def test_closed_ancestor_navigation_metadata_is_retained_literally(self):
        original=self.editor.observed();value=self.ui.decorate(original)
        self.assertIsNone(self.ui.route)
        self.assertEqual(original['lifecycleNavigation'],value['lifecycleNavigation'])
        self.assertEqual(original['controls'],value['controls'])
        self.assertFalse(value['tabletShown']);navigation.membership(value)

    def test_actual_navigation_validator_still_refuses_token_and_complete_membership_changes(self):
        self.ui.activate('tablet.open');value=self.packet()
        bad=deepcopy(value);bad['lifecycleNavigation']['controls'][0]['token']='00000000-0000-4000-8000-000000000001'
        if bad['lifecycleNavigation']['controls'][0]['token']==value['lifecycleNavigation']['controls'][0]['token']:
            bad['lifecycleNavigation']['controls'][0]['token']='00000000-0000-4000-8000-000000000002'
        with self.assertRaises(NativeUIError):navigation.membership(bad)
        bad=deepcopy(value);bad['lifecycleNavigation']['controls'].pop()
        with self.assertRaises(NativeUIError):navigation.membership(bad)


if __name__=='__main__':unittest.main()
