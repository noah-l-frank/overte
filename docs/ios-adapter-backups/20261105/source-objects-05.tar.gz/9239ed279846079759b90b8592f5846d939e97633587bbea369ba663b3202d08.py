"""Typed live received-mixer transport over the existing original manager.

No decoder/mixer/peer is synthesized. Commands are durably owned by the caller
before send. Original receive-clock strings remain opaque decoded-PCM order;
none is an ADC/DAC, rendered-output or individual-talker measurement.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import base64,hashlib,json,re,time,uuid
from adapters.native_feature_observation import decode,exact,fresh,integer,need,number
from adapters.normal_ui import NativeUIError
from ios.adapters.audio_passive_capture_source import IOSAudioPassiveCaptureSource
from ios.adapters import audio_received_mixer as originals

ACTION=originals.ACTION
FILE=originals.FILE
VERSION=1 # Actual request schema; all received native reply/state/originals are2.
MAX_ORIGINAL=originals.MAX_ORIGINAL
MAX_CHUNK=4096
KINDS=('intent','capture','wav')
PROFILE=originals.PROFILE
FLAGS=originals.FLAGS
hex32=originals.hex32
command=originals.command
original_intent=originals.original_intent

def descriptor(value,kind):
    need(kind in KINDS and type(value) is dict and type(value.get('exists')) is bool)
    if not value['exists']:exact(value,{'kind','exists'});need(value['kind']==kind);return value
    exact(value,{'kind','exists','complete','bytes','sha256','device','inode'})
    need(value['kind']==kind and type(value['complete']) is bool and integer(value['bytes'],0,MAX_ORIGINAL)
        and type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}',value['sha256'])
        and all(type(value[key]) is str and re.fullmatch('[0-9]{1,24}',value[key]) for key in ('device','inode')))
    return value


def state(value,request,*,full=False):
    # Only compact manager replies belong here. Full captured rows are decoded
    # by the unchanged Source2 original_capture, with all actual packet bytes.
    need(full is False)
    exact(value,{'receivedMixerVersion','profile','owned','runId','leaseId','instance','role','admissionEpoch',
        'decoderLifetimeGeneration','currentDecoderLifetimeGeneration','captureGeneration','startedEpochMs',
        'startedMonotonicMs','startedReceiveClockUs','maximumOwnedSeconds','targetPackets','sampleRate','channels','sampleFormat',
        'streamIdentity','outputIdentity','bytes','active','complete','invalid','receiveClockDomain','sampleClockMeaning',
        'watchdogOwned','watchdogActive','originRows','originRowsSha256',*FLAGS})
    need(type(value['receivedMixerVersion'])is int and value['receivedMixerVersion']==2 and value['profile']==PROFILE
        and all(type(value[key])is bool for key in('owned','active','complete','invalid','watchdogOwned','watchdogActive',*FLAGS))
        and all(value[key]is False for key in FLAGS) and value['sampleFormat']=='pcm16le'
        and value['receiveClockDomain']=='udt-p_high_resolution_clock-us-opaque'
        and value['sampleClockMeaning']=='decoded-pcm-order-not-adc-dac-time'
        and integer(value['captureGeneration'],0,1000000000)
        and integer(value['originRows'],0,64) and integer(value['bytes'],0,64*960)
        and value['bytes']==value['originRows']*960 and type(value['originRowsSha256'])is str
        and re.fullmatch('[0-9a-f]{64}',value['originRowsSha256']))
    if not value['owned']:
        need(not any(value[key]for key in('active','complete','invalid','watchdogOwned','watchdogActive'))
            and all(value[key]==''for key in('runId','leaseId','instance','role','streamIdentity','outputIdentity'))
            and all(type(value[key])is int and value[key]==0 for key in('admissionEpoch','decoderLifetimeGeneration',
                'currentDecoderLifetimeGeneration','startedEpochMs','startedMonotonicMs','maximumOwnedSeconds',
                'targetPackets','sampleRate','channels','bytes','originRows'))
            and value['startedReceiveClockUs']=='0'and value['originRowsSha256']==hashlib.sha256(b'[]').hexdigest())
        return value
    need(all(value[key]==request[key]for key in('runId','leaseId','instance','role'))
        and integer(value['admissionEpoch'],1,4000000000)and value['admissionEpoch']&3==1
        and integer(value['decoderLifetimeGeneration'],1,1000000000)
        and integer(value['currentDecoderLifetimeGeneration'],0,1000000000)
        and integer(value['captureGeneration'],1,1000000000)
        and integer(value['startedEpochMs'],1)and integer(value['startedMonotonicMs'],1)
        and type(value['startedReceiveClockUs'])is str and re.fullmatch('[0-9]{1,24}',value['startedReceiveClockUs'])
        and int(value['startedReceiveClockUs'])>0 and integer(value['maximumOwnedSeconds'],6,10)
        and type(value['targetPackets'])is int and value['targetPackets']==64
        and type(value['sampleRate'])is int and value['sampleRate']==24000
        and type(value['channels'])is int and value['channels']==2)
    originals.identity(value['streamIdentity']);originals.identity(value['outputIdentity'])
    need(value['active']==(not value['invalid']and value['originRows']<64)
        and value['complete']==(not value['invalid']and value['originRows']==64))
    if not value['invalid']:need(value['currentDecoderLifetimeGeneration']==value['decoderLifetimeGeneration'])
    if value['complete']:need(value['watchdogOwned']and value['watchdogActive'])
    return value

def validate(value,request,pid,clock,*,original_only=False):
    command(request);need(type(original_only) is bool and original_only==(request['operation']=='read'))
    exact(value,{'receivedMixerReplyVersion','commandId','instance','sequence','processId','runId','role','leaseId',
        'operation','requestedEpochMs','capturedEpochMs','source'})
    need(type(value['receivedMixerReplyVersion']) is int and value['receivedMixerReplyVersion']==2
        and integer(pid,1) and integer(value['sequence'],1,1000000000)
        and value['processId']==pid and integer(value['processId'],1)
        and all(value[key]==request[key] for key in ('commandId','instance','runId','role','leaseId','operation'))
        and integer(value['requestedEpochMs'],1) and integer(value['capturedEpochMs'],value['requestedEpochMs'])
        and value['capturedEpochMs']-value['requestedEpochMs']<5000)
    if original_only:need(clock is None)
    else:
        need(type(clock) is dict and clock['processId']==pid and clock['instance']==request['instance'])
        fresh(value['capturedEpochMs'],clock['capturedEpochMs'])
    source=value['source']
    if request['operation']=='read':
        exact(source,{'kind','offset','bytes','base64','sha256','original','originalOnly'});need(source['originalOnly'] is True)
        descriptor(source['original'],source['kind']);need(source['original']['exists'] and source['original']['complete'])
        need(all(source[key]==request[key] for key in ('kind','offset','bytes')) and type(source['base64']) is str)
        raw=base64.b64decode(source['base64'],validate=True)
        need(len(raw)==source['bytes'] and base64.b64encode(raw).decode()==source['base64']
            and type(source['sha256']) is str and hashlib.sha256(raw).hexdigest()==source['sha256'])
    else:
        exact(source,{'state','files','retired','startAttempted','captureAttempted','releaseAttempted','openOriginalFds','originalBytes'})
        need(all(type(source[key]) is bool for key in ('retired','startAttempted','captureAttempted','releaseAttempted'))
            and type(source['files']) is list and len(source['files'])==3)
        for row,kind in zip(source['files'],KINDS):descriptor(row,kind)
        state(source['state'],request)
        actual=[row for row in source['files'] if row['exists']]
        need(integer(source['openOriginalFds'],0,3) and source['openOriginalFds']==len(actual)
            and integer(source['originalBytes'],0,MAX_ORIGINAL*3) and source['originalBytes']==sum(row['bytes'] for row in actual))
        if source['retired']:
            need(source['releaseAttempted'] and not source['state']['owned'] and not actual)
    return value


class IOSAudioReceivedMixerSource(IOSAudioPassiveCaptureSource):
    def query(self,operation,**fields):
            query=dict(schemaVersion=VERSION,commandId=self.start_command_id if operation=='start' else 'ios-'+uuid.uuid4().hex,action=ACTION,operation=operation,
                instance=self.instance,runId=self.run,role='actor',leaseId=self.lease,startCommandId=self.start_command_id,**fields)
            command(query);need(self.guard() is not False)
            started=previous=self.monotonic();need(number(started,0,1e15))
            # The caller's real ownership WAL must return only AFTER durable intent.
            need(self.intent(deepcopy(query)) is not False);need(self.guard() is not False);self.send(query)
            for attempt in range(101):
                need(self.guard() is not False);raw=self.read()
                try:value=decode(raw) if raw else None
                except json.JSONDecodeError:value=None
                if type(value) is dict and value.get('commandId')==query['commandId']:
                    original_only=operation=='read'
                    clock=None if original_only else self.native_clock()
                    validate(value,query,self.pid,clock,original_only=original_only)
                    need(value['sequence']>self.sequence and value['capturedEpochMs']>=self.epoch)
                    now=self.monotonic();need(number(now,previous,started+5) and now-started<5)
                    self.sequence,self.epoch=value['sequence'],value['capturedEpochMs']
                    need(self.guard() is not False);return query,value
                now=self.monotonic();need(number(now,previous,started+5));previous=now
                if now-started>=5 or attempt==100:break
                self.sleep(min(.05,5-(now-started)))
            raise NativeUIError('Original received-mixer iOS Audio reply is unavailable')

    def original(self,reference):
            kind=reference.get('kind');descriptor(reference,kind);need(reference['exists'] and reference['complete'])
            result=bytearray()
            while len(result)<reference['bytes']:
                _,packet=self.query('read',kind=kind,offset=len(result),bytes=min(MAX_CHUNK,reference['bytes']-len(result)))
                need(packet['source']['original']==reference)
                result.extend(base64.b64decode(packet['source']['base64'],validate=True))
            raw=bytes(result);need(len(raw)==reference['bytes'] and hashlib.sha256(raw).hexdigest()==reference['sha256'])
            return raw

