"""Canonical actual Assets page generations, with separate old-client duties.

This journal composes typed birth/page/retirement originals. It never opens a
page, substitutes a current native fact, closes a legacy header or grants end.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from adapters.native_feature_observation import exact,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same,pack,unpack
from ios.adapters.assets_action_phase import AssetsActionPhases,AssetsActionScope
from ios.adapters.assets_born_page_lease import BornAssetsPageLease
from ios.adapters.assets_dead_page_retirement import AssetsDeadPageRetirement
from ios.adapters.assets_episodes import AssetsEpisodes,AssetsEpisodeScope
from ios.adapters.assets_generation_action_history import action_original
from ios.adapters.assets_episode_metadata_graph import readonly_store
from ios.adapters.assets_generation_page_lease import GenerationAssetsPageLease
from ios.adapters.assets_page_birth import AssetsPageBirth
from ios.adapters.assets_page_reentry import AssetsPageReentry

EPISODES={1:(1,2),2:(3,),3:(4,),4:(5,)}
REMOVALS={1:9,2:16,3:22}


@dataclass(frozen=True)
class AssetsPageGenerationContext:
    birth:object
    page:object
    retirement:object=None


class AssetsPageGenerations:
    def __init__(self,episodes,actions,store,*,contexts=None,historical=False):
        need(type(episodes) is AssetsEpisodes and type(actions) is AssetsActionPhases
            and actions.selected is episodes.selected and isinstance(store,PrivateFeatureState) and type(historical) is bool)
        self.episodes,self.actions,self.store,self.historical=episodes,actions,readonly_store(store) if historical else store,historical
        self.run,self.lock=episodes.run,episodes.locks['primary'];self.contexts={} if contexts is None else dict(contexts)
        need(store.path==Path(episodes.context['roles']['primary']['stateRoot'])/('ios-assets-page-generations-'+self.run+'-primary.json'))
        self.previous=store.read();self.state=None
        if self.previous is not None:self.state=self.decode(self.previous)
        self.base_guard()
    def base_guard(self):
        self.episodes.guard();self.actions.guard();self.lock.assert_held();need(same(self.store.read(),self.previous));return True
    def context_row(self,generation,context):
        need(generation in EPISODES and type(context) is AssetsPageGenerationContext)
        birth,page=context.birth,context.page
        need((generation==1 and type(birth) is AssetsPageBirth and type(page) is BornAssetsPageLease and page.birth is birth)
            or (generation>1 and type(birth) is AssetsPageReentry and birth.generation==generation
                and type(page) is GenerationAssetsPageLease and page.reentry is birth))
        need(birth.selected is self.episodes.selected and page.episodes is self.episodes and birth.lock is page.lock is self.lock)
        index=1 if generation==1 else {2:9,3:16,4:22}[generation]
        if birth.historical:need(action_original(self.actions,index,include_saved_pending=True)['ticket']==birth.ticket)
        else:need(birth.action.owner is self.actions);birth.action.guard()
        page.bound();need(page.state is not None and page.state['origin'] is not None and page.state['pending'] is None)
        page.decode(page.previous);identity=page.identity();need(same(identity,birth.page()))
        retired=None
        if context.retirement is not None:
            retirement=context.retirement;need(generation in REMOVALS and type(retirement) is AssetsDeadPageRetirement
                and retirement.action.index==REMOVALS[generation] and retirement.episode.owner is self.episodes
                and retirement.episode.index==EPISODES[generation][-1] and retirement.upload.state['page']==identity['rootId'])
            wanted={str(i) for i in EPISODES[generation]}
            need(set(page.state['attachments'])==wanted and set(page.state['transfers'])==wanted-{str(EPISODES[generation][-1])})
            retired=retirement.retired()
        closed=None
        if page.state['phase']=='closed':
            need(generation==4 and retired is None);page.all_transferred(page.state)
            closed=dict(pageLease=page.link(),source=deepcopy(page.state['closed']))
        return dict(generation=generation,birth=birth.link(),pageLease=page.link(),page=identity,retirement=retired,closed=closed)
    def guard(self):
        self.base_guard()
        if self.state is not None:
            need(self.previous is not None and same(self.envelope(),self.previous))
            need(set(self.contexts)==set(range(1,len(self.state['entries'])+1)))
            for row in self.state['entries']:need(same(row,self.context_row(row['generation'],self.contexts[row['generation']])))
        return True
    def bind_context(self,generation,context):
        # Typed data reassembly can replace an expired live source BEFORE any
        # later native operation. It does not change the canonical journal.
        self.base_guard();need(self.state is not None and same(self.envelope(),self.previous) and 1<=generation<=len(self.state['entries'])
            and same(self.state['entries'][generation-1],self.context_row(generation,context)))
        self.contexts[generation]=context;return context
    def envelope(self):
        return dict(iosAssetsPageGenerationsVersion=1,runId=self.run,selectedPair=self.episodes.selected.link(),
            actionsPath=str(self.actions.store.path),payload=pack([self.state]))
    def decode(self,value):
        exact(value,{'iosAssetsPageGenerationsVersion','runId','selectedPair','actionsPath','payload'})
        need(type(value['iosAssetsPageGenerationsVersion']) is int and value['iosAssetsPageGenerationsVersion']==1
            and value['runId']==self.run and same(value['selectedPair'],self.episodes.selected.link()) and value['actionsPath']==str(self.actions.store.path))
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0];exact(state,{'entries','complete'})
        need(type(state['entries']) is list and len(state['entries'])<=4 and type(state['complete']) is bool
            and set(self.contexts)==set(range(1,len(state['entries'])+1)))
        roots=set()
        for index,row in enumerate(state['entries'],1):
            need(same(row,self.context_row(index,self.contexts[index])) and row['page']['rootId'] not in roots);roots.add(row['page']['rootId'])
            if index<len(state['entries']):need(row['retirement'] is not None and row['closed'] is None)
        complete=len(state['entries'])==4 and all(row['retirement'] is not None for row in state['entries'][:3]) and state['entries'][-1]['closed'] is not None
        need(state['complete']==complete);return state
    def assert_namespace(self,contexts=None):
        contexts=self.contexts if contexts is None else contexts
        known={self.store.path};root=self.store.path.parent
        for context in contexts.values():
            page=context.page;need(page.state is not None and page.state['pending'] is None)
            known.add(page.store.path)
            known.update(page.originals.path(page.originals.expand(ref)) for ref in page.state['records'])
        actual={path for path in root.iterdir() if path.name.startswith(('assets-page-lease-','ios-assets-page-lease-','ios-assets-page-generations-'))}
        need(actual==known);return True
    def save(self):
        self.base_guard();need(not self.historical);value=self.envelope();self.decode(value)
        self.store.write(value,self.previous);self.previous=deepcopy(value)
    def reserve(self):
        self.base_guard();need(self.state is None and not self.contexts);self.state=dict(entries=[],complete=False);self.save()
    def attach_initial(self,birth,page):
        self.guard();need(not self.historical and self.state is not None)
        context=AssetsPageGenerationContext(birth,page);row=self.context_row(1,context)
        if self.state['entries']:need(same(self.state['entries'][0],row));return page
        self.assert_namespace({1:context});self.contexts[1]=context;self.state['entries'].append(row);self.save();return page
    def advance(self,retirement,birth,page):
        self.guard();need(not self.historical and self.state is not None and self.state['entries'] and not self.state['complete']
            and type(birth) is AssetsPageReentry)
        generation=birth.generation;need(generation in (2,3,4))
        if len(self.state['entries'])==generation:
            need(same(self.state['entries'][-1],self.context_row(generation,AssetsPageGenerationContext(birth,page))));self.assert_namespace();return page
        need(len(self.state['entries'])==generation-1);previous=self.contexts[generation-1]
        old_context=AssetsPageGenerationContext(previous.birth,previous.page,retirement);old=self.context_row(generation-1,old_context)
        need(same(dict(old,retirement=None),self.state['entries'][-1]) and retirement.action.index==birth.action_index
            and retirement.action.ticket==birth.ticket and birth.source().store.path==retirement.upload.store.path
            and birth.prior()['rootId']==old['page']['rootId'])
        release=retirement.packet(retirement.state['releasedBy'])
        need(birth._cached and birth._cached[0]['ui']['sampleEpochMs']>=release['clockAfter']['epochMs'])
        context=AssetsPageGenerationContext(birth,page);new=self.context_row(generation,context)
        need(new['page']['rootId'] not in {row['page']['rootId'] for row in self.state['entries']})
        proposed=dict(self.contexts);proposed[generation-1]=old_context;proposed[generation]=context
        self.assert_namespace(proposed)
        self.contexts[generation-1]=old_context;self.contexts[generation]=context
        self.state['entries'][-1]=old;self.state['entries'].append(new);self.save();return page
    def page_for_episode(self,episode):
        self.guard();need(self.state is not None and not self.historical and type(episode) is AssetsEpisodeScope and episode.owner is self.episodes)
        generation=next(g for g,indices in EPISODES.items() if episode.index in indices)
        need(generation==len(self.state['entries']) and self.state['entries'][generation-1]['retirement'] is None
            and self.state['entries'][generation-1]['closed'] is None)
        page=self.contexts[generation].page;need(not page.historical);page.live(episode);return page
    def final_closed(self,action):
        self.base_guard();need(not self.historical and self.state is not None and same(self.envelope(),self.previous)
            and type(action) is AssetsActionScope and action.owner is self.actions and action.index==29)
        action.guard();need(len(self.state['entries'])==4)
        for row in self.state['entries'][:3]:need(same(row,self.context_row(row['generation'],self.contexts[row['generation']])))
        context=self.contexts[4];row=self.context_row(4,context)
        need(row['closed'] is not None and same(dict(row,closed=None),dict(self.state['entries'][-1],closed=None)))
        closed=context.page.read(context.page.state['closed']);snapshot=unpack(closed['pickerSnapshot']['payload'])[0]
        packet=snapshot['captures'][closed['captureIndex']]
        need(packet['sampleEpochMs']>=self.actions.state['pending']['before']['capturedEpochMs'])
        self.assert_namespace();self.state['entries'][-1]=row;self.state['complete']=True;self.save();return row
    def responsibilities(self):
        self.guard();need(self.state is not None)
        return dict(assetsPageGenerationsOwnershipVersion=1,generations=len(self.state['entries']),
            unresolvedPages=[row['generation'] for row in self.state['entries'] if row['retirement'] is None and row['closed'] is None],
            completePageJourney=self.state['complete'],wholeEndEligible=False,abortAuthorized=False)
