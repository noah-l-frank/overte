"""Exact physical namespaces for one actual current checkpoint composition.

Unreferenced/orphan/planned/opened files are never adopted by an inventory.
This is the checkpoint subset only; whole evidence/process membership remains
separate. Typed source decoders retain their existing body/inode guards.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import need
from ios.adapters.assets_end_metadata import signature


def references(owner):
    known=set();prefixes=set()
    def header(value):
        if value.previous is not None:known.add(value.store.path)
    def frame_store(store,refs):
        prefixes.add((store.root,store.namespace+'-frame-'))
        for ref in refs:
            full=store.expand(ref) if 'phase' not in ref else ref
            if full['phase']!='planned':known.add(store.path(full))
            else:need(not store.path(full).exists())
    header(owner)
    if hasattr(owner,'originals'):
        refs=list(owner.state['frames']) if owner.state is not None else []
        if owner.state is not None and owner.state['pending'] is not None:
            pending=owner.state['pending'];original=pending.get('original')
            if original is not None:refs.append(original)
        if owner.state is not None:
            for row in owner.state.get('interrupted',[]):
                if row['pending']['original'] is not None:refs.append(row['pending']['original'])
        frame_store(owner.originals,refs)
    if hasattr(owner,'sources'):
        native=owner.sources;prefixes.add((owner.store.path.parent,native.NAMESPACE+'-frame-'))
        prefixes.add((owner.store.path.parent,native.MIGRATION_PREFIX))
        known.update(native.owned_paths())
    if hasattr(owner,'raws'):
        native=owner.raws;prefixes.add((owner.store.path.parent,native.NAMESPACE+'-frame-'))
        prefixes.add((owner.store.path.parent,native.MIGRATION_PREFIX));known.update(native.owned_paths())
    if hasattr(owner,'parts') and hasattr(owner.parts,'store'):
        refs=[]
        if owner.state is not None:
            for row in owner.state['samples']:
                if row['parts'] is not None:refs.extend(row['parts']['chunks'])
        frame_store(owner.parts.store,refs)
    return known,prefixes


def checkpoint_membership(observer):
    owners=[observer.ui,observer.node,observer.replies,observer.backend,observer.primary_scene['scene']]
    if observer.peer_scene is not None:owners.append(observer.peer_scene['scene'])
    unique={id(owner):owner for owner in owners}.values();known=set();prefixes=set();headers=set()
    for owner in unique:
        paths,names=references(owner);known.update(paths);prefixes.update(names);headers.add(owner.store.path)
    directories={path.parent for path in headers}|{root for root,_name in prefixes};actual=set()
    for root in directories:
        entries=list(root.iterdir());need(len(entries)<=4096)
        for path in entries:
            if path in headers or any(path.parent==directory and path.name.startswith(prefix) for directory,prefix in prefixes):actual.add(path)
    need(actual==known and all(signature(path) is not None for path in known));return {path:signature(path) for path in known}
