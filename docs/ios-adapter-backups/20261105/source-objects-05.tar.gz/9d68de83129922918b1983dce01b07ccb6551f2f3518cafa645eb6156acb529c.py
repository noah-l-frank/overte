"""UNRUN read-only retained-original boundary diagnostic; no acceptance authority."""
import cProfile
import hashlib
import importlib.abc
import importlib.machinery
import json
import os
from pathlib import Path
import pstats
import signal
import stat
import sys
import threading
import time
import traceback

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
OUTPUT=Path(sys.argv[1]).resolve(strict=True)
PLAN=json.loads((HERE/'plan.json').read_text())
EXPECTED=json.loads((OUTPUT/'sources-before.json').read_text())
BASE_THREADS=set(threading.enumerate())
started=time.monotonic();marks=[];effects=[];imported={};profile=cProfile.Profile()

def save(name,value):
    path=OUTPUT/name
    with path.open('w') as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n');stream.flush();os.fsync(stream.fileno())

def mark(name):
    value={'name':name,'elapsedSeconds':time.monotonic()-started}
    marks.append(value);print('BOUNDARY',json.dumps(value),flush=True)

def forbidden(name):
    effects.append(name);raise AssertionError('Forbidden read-only diagnostic effect: '+name)

tmp=REPO/PLAN['originalRoot']
locks={str(tmp/name/'script-feature-sources.lock') for name in
       (PLAN['selection']['main'],PLAN['selection']['photos'],PLAN['selection']['archive'])}
pins=json.loads((HERE/'original-pins.json').read_text())
def audit(event,args):
    if event.startswith(('socket.','subprocess.','os.exec','os.spawn','os.fork')) or event in ('os.system','os.posix_spawn','pty.spawn','ctypes.dlopen'):
        forbidden(event)
    if event in ('os.remove','os.rmdir','os.rename','os.mkdir','os.chmod','os.chown','os.utime','os.link','os.symlink','os.truncate'):
        forbidden(event)
    if event=='open':
        path,mode,flags=args
        if not flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):return
        if not isinstance(path,(str,bytes,os.PathLike)):forbidden('descriptor-write-open')
        actual=Path(os.fsdecode(path)).absolute()
        if actual.parent==OUTPUT:return
        if str(actual) in locks and mode is None and not flags&(os.O_TRUNC|os.O_APPEND|os.O_EXCL):
            row=actual.lstat();pin=pins[str(actual.relative_to(REPO))]
            if row.st_dev==pin['st_dev'] and row.st_ino==pin['st_ino']:return
        forbidden('write-open:'+str(actual))

class SourceGuard(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.',1)[0] in ('pymobiledevice3','pmd_pytcp','pmd_pytcpstack','pytcp'):
            forbidden('SDK-import:'+fullname)
        spec=importlib.machinery.PathFinder.find_spec(fullname,path)
        if spec is None or not spec.origin or spec.origin in ('built-in','frozen'):return None
        origin=Path(spec.origin).resolve()
        if 'overte-ios-remotexpc' in str(origin):forbidden('SDK-import:'+fullname)
        if origin.is_relative_to(REPO):
            key=str(origin.relative_to(REPO));expected=EXPECTED.get(key)
            assert expected is not None and hashlib.sha256(origin.read_bytes()).hexdigest()==expected['sha256'],('Unpinned import',fullname,key)
            imported[fullname]=key
        return None

error=None;interrupted=None;actual_reads=set()
# Observe only the ACTUAL parser_identity return from the known ReadArea.check
# frame. Never invoke a second parser, replace a return, relax a guard or dump
# general frame locals. cProfile keeps its independent profiling hook.
CHECK_FILE=str(REPO/'tests/device/ios/adapters/snapshot_photos_end_read_area.py')
PARSER_FILE=str(REPO/'tests/device/ios/adapters/snapshot_photos_end_round.py')
CHECK_LINE=104
previous_trace=sys.gettrace();assert previous_trace is None,'Do not replace another tracer'
check_calls={};delta_observed=False

def identical_data(left,right):
    if left is right:return True
    if type(left) is not type(right):return False
    if type(left) is tuple:
        return len(left)==len(right) and all(identical_data(a,b) for a,b in zip(left,right))
    if type(left) in (str,bytes,int,float,bool,type(None)):return left==right
    # Raw class descriptors in methods() compare by identity only. No opaque
    # equality, repr, attribute traversal or callback is invoked here.
    return False

def named_rows(rows):
    assert type(rows) is tuple
    result={}
    for row in rows:
        assert type(row) is tuple and len(row)>=2 and type(row[0]) is str and row[0] not in result
        result[row[0]]=row
    return result

def changed_names(before,after):
    a,b=named_rows(before),named_rows(after)
    return dict(added=sorted(set(b)-set(a)),removed=sorted(set(a)-set(b)),
        changed=sorted(name for name in set(a)&set(b) if not identical_data(a[name],b[name])))

def signature_delta(before,after):
    result=changed_names(before,after);a,b=named_rows(before),named_rows(after);details={}
    labels=('functionIdentity','codeIdentity','defaults','keywordDefaults','wrappedFunction','closureFunctions')
    for name in result['changed']:
        old,new=a[name],b[name];entry={}
        if len(old)!=len(new):entry['descriptorShapeChanged']=True
        elif len(old)==3:
            entry['classIdentityChanged']=old[1] is not new[1]
            old_members,new_members=old[2],new[2]
            entry['members']=[]
            for index in range(max(len(old_members),len(new_members))):
                x=old_members[index] if index<len(old_members) else None
                y=new_members[index] if index<len(new_members) else None
                if not identical_data(x,y):
                    # Attribute NAMES only; no values or inherited object repr.
                    entry['members'].append(dict(ordinal=index,beforeAttribute=None if x is None else x[1],
                        afterAttribute=None if y is None else y[1]))
        elif type(old[1]) is tuple and type(new[1]) is tuple and len(old[1])==len(new[1])==6:
            entry['functionFields']=[label for index,label in enumerate(labels) if not identical_data(old[1][index],new[1][index])]
        else:entry['aliasIdentityChanged']=True
        details[name]=entry
    result['details']=details;return result

def parser_delta(before,after):
    a,b=named_rows(before),named_rows(after);changed={}
    for name in sorted(set(a)&set(b)):
        old,new=a[name],b[name];assert len(old)==len(new)==4
        if not identical_data(old,new):
            changed[name]=dict(moduleIdentityChanged=old[1]!=new[1],methods=signature_delta(old[2],new[2]),
                constants=changed_names(old[3],new[3]))
    return dict(addedModules=sorted(set(b)-set(a)),removedModules=sorted(set(a)-set(b)),changedModules=changed,
        baselineModuleCount=len(a),actualReturnedModuleCount=len(b),valuesIncluded=False)

def selected_trace(frame,event,arg):
    global delta_observed
    code=frame.f_code
    if code.co_filename==PARSER_FILE and code.co_name=='parser_identity':
        if event=='return':
            caller=frame.f_back;entry=check_calls.get(id(caller))
            if entry is not None and type(arg) is tuple:entry['actualReturnedIdentity']=arg
        return selected_trace
    if code.co_filename==CHECK_FILE and code.co_name=='check':
        if event=='exception' and frame.f_lineno==CHECK_LINE and not delta_observed:
            entry=check_calls.get(id(frame));current=None if entry is None else entry.get('actualReturnedIdentity')
            if type(current) is tuple:
                delta_observed=True
                try:
                    owner=frame.f_locals.get('self')
                    # Read precisely the selected existing baseline; no other
                    # locals, paths, configuration, headers or owner state.
                    baseline=vars(owner).get('parsers')
                    report=parser_delta(baseline,current)
                    report.update(actualGuardFile=CHECK_FILE,actualGuardLine=CHECK_LINE,
                        actualExceptionType=arg[0].__name__,actualParserReturnObserved=True,
                        guardResultReplaced=False,parserInvokedByObserver=False,authority=False)
                    save('parser-identity-delta.json',report)
                except Exception as observation_error:
                    # Metadata trouble must not replace the ORIGINAL failure.
                    try:
                        save('parser-identity-delta-observer-error.json',dict(type=type(observation_error).__name__,
                            originalGuardContinuesUnmodified=True))
                    except Exception:pass
        if event=='return':check_calls.pop(id(frame),None)
        return selected_trace
    return None

def trace_calls(frame,event,arg):
    if delta_observed or event!='call':return None
    code=frame.f_code
    if ((code.co_filename==CHECK_FILE and code.co_name=='check')
            or (code.co_filename==PARSER_FILE and code.co_name=='parser_identity')):
        frame.f_trace_lines=False;frame.f_trace_opcodes=False
        if code.co_filename==CHECK_FILE:check_calls[id(frame)]={}
        return selected_trace
    return None

def terminate(signum,frame):
    global interrupted
    profile.disable();interrupted={'signal':signum,'stack':traceback.format_stack(frame)}
    save('signal-cutpoint.json',interrupted)
    raise SystemExit(128+signum)

# Root canonical namespace check BEFORE all production imports.
assert not any(name.split('.',1)[0] in ('ios','adapters','feature_journeys') for name in sys.modules)
ordered=[str(REPO/name) for name in PLAN['apiPYTHONPATH']]
remaining=[]
for value in sys.path:
    path=Path(value or os.getcwd()).resolve()
    if path==REPO or REPO in path.parents:continue
    if str(path) not in remaining:remaining.append(str(path))
sys.path[:]=ordered+remaining
for name,relative in {'ios':'tests/device/ios','adapters':'tests/device/adapters','feature_journeys':'tests/device/feature_journeys'}.items():
    spec=importlib.machinery.PathFinder._get_spec(name,list(sys.path))
    assert spec is not None and list(spec.submodule_search_locations or ())==[str(REPO/relative)],name
mark('canonical-source-roots-checked')
assert not any(name.split('.',1)[0] in ('pymobiledevice3','pmd_pytcp','pmd_pytcpstack','pytcp') for name in sys.modules),'SDK preloaded before passive import gate'
sys.addaudithook(audit)
sys.meta_path.insert(0,SourceGuard())
signal.signal(signal.SIGTERM,terminate)
try:
    # No fixture/native/SDK module is imported. The controller policy is the
    # actual selected-before-first-input original, never a backend-derived DTO.
    from contextlib import ExitStack
    from unittest.mock import patch
    from adapters.native_clock_join import digest
    from adapters.normal_feature_state import PrivateFeatureState
    from adapters.operation_transport_guard import scope
    from ios.adapters.snapshot_capture_clock import Budget
    from ios.adapters.snapshot_photos_end_originals import SnapshotPhotosEndOriginals
    from adapters.original_file_reads import readonly,collect
    mark('actual-passive-imports-complete')
    main_binding=dict(sourceRevision='a'*40,artifactSha256='b'*64,processIdentity='42',sessionId='owned-session',generation=0,targetFingerprint='c'*64)
    def selected(name,bundle,pid,capabilities,admission):
        root=tmp/name;target=dict(platform='ios',physical=True,appId=bundle,serverUrl='http://already-bound.invalid',capabilities=capabilities)
        artifact=root/'selected.ipa'
        binding=dict(sourceRevision='c'*40,artifactSha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),processIdentity=str(pid),sessionId='companion-session',generation=1,targetFingerprint=digest(target))
        return dict(root=str(root),binding=binding,artifactPath=str(artifact),sessionPath=str(root/'session.json'),admissionPath=str(root/admission),target=target)
    device='HOST-PHYSICAL-SHARE-DEVICE-MODEL'
    photos=selected(PLAN['selection']['photos'],'org.example.snapshot.photos',84,{'appium:udid':device,'appium:platformVersion':'99.1'},'ios-snapshot-companion-owner.json')
    archive=selected(PLAN['selection']['archive'],'org.example.snapshot.sharearchive',85,{'appium:udid':device},'ios-snapshot-share-code-owner.json')
    controller=PrivateFeatureState(tmp/PLAN['selection']['controllerPolicy']).read()
    assert set(controller)=={'selectionKind','runId','configuration'} and controller['selectionKind']=='snapshot-photos-public-domain-selection' and controller['runId']=='a'*32
    # Literal field selections from reviewed declared fixture sources. None of
    # the expected main/helper identities is recovered from owner headers.
    system_ui=dict(select=dict(using='accessibility id',value='Snapshot Original Receiver'),cancel=dict(using='accessibility id',value='System Share Cancel'))
    factory=SnapshotPhotosEndOriginals(dict(root=str(tmp/PLAN['selection']['main']),binding=main_binding),photos,archive,run='a'*32,
        fixture_url='https://controlled.invalid/feature-fixture/v1/runs/'+'a'*32+'/',primary_bundle='org.example.client',system_ui=system_ui,domain_policy=controller['configuration'],reuse_originals=True)
    def blocked(*args,**kwargs):forbidden('PrivateFeatureState writer')
    with ExitStack() as held:
        held.enter_context(patch.object(PrivateFeatureState,'write',blocked));held.enter_context(patch.object(PrivateFeatureState,'discard',blocked))
        for lock in sorted(factory.locks.values(),key=lambda item:str(item.path)):held.enter_context(lock.held())
        factory.check_locks();mark('three-existing-original-locks-held')
        # This is the literal runtime outer25 gate. No clocks/limits/decoders
        # are replaced. cProfile incurs overhead: timings are diagnostic only.
        budget=Budget(time.monotonic)
        profile.enable()
        sys.settrace(trace_calls)
        try:
            with scope(budget.check),readonly(),collect() as actual_reads:
                budget.check();mark('before-read-journey')
                with factory.read_journey() as journey:
                    mark('journey-yielded');budget.check()
                    result=journey.proof();mark('explicit-result2-returned');budget.check()
                    assert result['snapshotCombinedJourneyResultVersion']==2
                mark('read-area-finished');budget.check()
        finally:
            profile.disable();sys.settrace(previous_trace);check_calls.clear()
except BaseException as exc:
    profile.disable();error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
    print(error['traceback'],file=sys.stderr,flush=True)
finally:
    profile.disable()
    sys.settrace(previous_trace);check_calls.clear()
    profile.dump_stats(str(OUTPUT/'passive-boundary.pstats'))
    stats=pstats.Stats(profile).stats if profile.getstats() else {}
    rows=[dict(file=file,line=line,function=name,primitiveCalls=record[0],totalCalls=record[1],selfSeconds=record[2],inclusiveSeconds=record[3])
          for (file,line,name),record in stats.items() if str(REPO) in file]
    save('profile-rows.json',sorted(rows,key=lambda row:row['inclusiveSeconds'],reverse=True))
    new_threads=[dict(name=thread.name,ident=thread.ident,daemon=thread.daemon) for thread in threading.enumerate() if thread not in BASE_THREADS and thread.is_alive()]
    save('diagnostic-result.json',dict(error=error,marks=marks,forbiddenEffects=effects,imports=imported,interrupted=interrupted,
        newThreads=new_threads,
        parserIdentityDeltaObserved=delta_observed,
        elapsedSeconds=time.monotonic()-started,actualReadPaths=sorted(map(str,actual_reads)),authority=False,wholeQualified=False,
        oldInnerStackKnown=False,timingQualification=False))
if error or effects or new_threads:raise SystemExit(1)
