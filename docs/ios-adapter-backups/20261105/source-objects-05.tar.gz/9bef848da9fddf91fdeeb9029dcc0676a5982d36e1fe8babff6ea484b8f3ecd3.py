"""Actual keeper/source/files/tasks; SDK/RSD/native/WDA remain explicit models."""
from __future__ import annotations
import ast,asyncio,hashlib,inspect,json,os,re,socket,time,unittest,uuid,weakref
from contextlib import asynccontextmanager,suppress
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch


class OriginalNativeFileChannelModels(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        raw=Path(os.environ['LIFECYCLE_NATIVE_FILE_MAP']).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=os.environ['LIFECYCLE_NATIVE_FILE_MAP_SHA256']:raise RuntimeError('Reviewed actual source map required before target imports')
        self.mapping=json.loads(raw)
        for row in self.mapping.values():
            if hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()!=row['sha256']:raise RuntimeError('Actual source changed')
        from ios.self_tests import test_ios_touch_lease as fixture
        from ios.self_tests.test_ios_native_geometry_floor import NativeGeometryFloorTests
        self.f=fixture.TouchLeaseTests();self.f.setUp()
        for callback,args,kwargs in self.f._cleanups:self.addCleanup(callback,*args,**kwargs)
        self.f._cleanups.clear();self.addAsyncCleanup(self.f.asyncTearDown)
        geo=NativeGeometryFloorTests();reader=geo.reader();self.packet=reader.capture()
        self.input=self.f.store.path.parent/'retained-modeled-native-original.json';self.input.write_text(json.dumps(self.packet));self.input.chmod(0o600)
        self.binding=dict(self.f.binding,processIdentity='42');self.services=[];self.tasks=[];self.controls=[];self.starts=[];self.hook=None;self.delay=0.;self.close_failure=False
        outer=self
        class HouseArrestModel:
            def __init__(self,rsd,documents_only=False):
                outer.assertIs(rsd,outer.rsd);outer.assertIs(documents_only,False);outer.services.append(self)
                self.calls=[];self._service=object();self._afc_reader_task=None;self._afc_pending={};self.gate=asyncio.Event();self.gate.set();self.fail_close=False
                self.descriptors={};self.sockets=socket.socketpair();self.reader_stop=asyncio.Event()
            async def send_command(self,bundle,command):
                self.calls.append(('vend',bundle,command));outer.assertIsNone(self._afc_reader_task)
                if outer.hook is not None:outer.hook(self)
                await asyncio.sleep(0)
            async def __aenter__(self):
                self.calls.append(('enter',));self._afc_reader_task=asyncio.create_task(self.reader_stop.wait());return self
            async def stat(self,path):
                self.calls.append(('stat',path));await asyncio.sleep(0);info=outer.input.stat()
                return dict(st_ifmt='S_IFREG',st_nlink=info.st_nlink,st_size=info.st_size,st_mtime=info.st_mtime_ns)
            async def fopen(self,path,mode):
                self.calls.append(('open',path,mode));fd=os.open(outer.input,os.O_RDONLY|os.O_NOFOLLOW);self.descriptors[fd]=fd;return fd
            async def fread(self,handle,count):
                self.calls.append(('read',count));await self.gate.wait()
                if outer.delay:await asyncio.sleep(outer.delay)
                return os.read(handle,count)
            async def fclose(self,handle):self.calls.append(('fclose',handle));os.close(self.descriptors.pop(handle))
            async def aclose(self):
                self.calls.append(('aclose',))
                if self.fail_close or outer.close_failure:raise OSError('Declared original AFC close return lost')
                if self._afc_reader_task is not None:
                    self._afc_reader_task.cancel()
                    with suppress(asyncio.CancelledError):await self._afc_reader_task
                    self._afc_reader_task=None
                for fd in tuple(self.descriptors):os.close(self.descriptors.pop(fd))
                for fd in self.sockets:fd.close()
                self._afc_pending.clear();self._service=None
        self.service_type=HouseArrestModel
        source_path=Path(self.mapping['keeper']['path']);tree=ast.parse(source_path.read_bytes())
        source=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='OriginalKeeperSource')
        ops=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='OriginalKeeperOperations')
        method=next(n for n in ops.body if isinstance(n,ast.AsyncFunctionDef) and n.name=='native_original_read')
        node=method.body[1] if isinstance(method.body[0],ast.Expr) else method.body[0]
        # Exactly ONE reviewed SDK import is replaced by explicit service DI.
        self.assertIsInstance(node,ast.ImportFrom);self.assertEqual('pymobiledevice3.services.house_arrest',node.module)
        self.assertEqual(['HouseArrestService'],[a.name for a in node.names]);method.body.remove(node)
        ns=dict(asyncio=asyncio,weakref=weakref,inspect=inspect,asynccontextmanager=asynccontextmanager,
            uuid=uuid,re=re,json=json,time=time,LaunchError=RuntimeError,HouseArrestService=HouseArrestModel)
        module=ast.Module(body=[source,ops],type_ignores=[]);code=compile(ast.fix_missing_locations(module),str(source_path),'exec')
        # Actual source/selected AST/code hashes, diagnostic only, not auth.
        self.binding_metadata=dict(sourceSha256=self.mapping['keeper']['sha256'],selectedAstSha256=hashlib.sha256(ast.dump(module,include_attributes=False).encode()).hexdigest(),compiledCodeSha256=hashlib.sha256(__import__('marshal').dumps(code)).hexdigest())
        bindings=Path(os.environ['LIFECYCLE_CODE_BINDINGS_ROOT']);info=bindings.stat()
        self.assertEqual(0o700,info.st_mode&0o777);self.assertEqual(os.geteuid(),info.st_uid)
        fd=os.open(bindings/(uuid.uuid4().hex+'.json'),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as stream:json.dump(self.binding_metadata,stream,sort_keys=True);stream.write('\n')
        exec(code,ns)
        class RSD:pass
        class Capability:
            # Explicit original SDK socket-factory model, resolved before the
            # injected HID context call; never an authentication/source claim.
            udp_socket=staticmethod(socket.socket)
            def current(_):return outer.rsd,'fd00::1'
        class Tunnel:
            def original_source(_):return outer.cap
        self.rsd=RSD();self.cap=Capability();self.tunnel=Tunnel()
        self.source=ns['OriginalKeeperSource'].__new__(ns['OriginalKeeperSource']);self.source._tunnel=weakref.ref(self.tunnel);self.source._source=self.cap
        self.source._loop=asyncio.get_running_loop();self.source._born=[];self.source._leases=[];self.source._native_reads=[];self.source._closing=False
        self.ops=ns['OriginalKeeperOperations'](self.source,self.f.store.path.parent)
        self.ops.session=dict(sessionId=self.binding['sessionId'],archiveBundleId='org.example.overte',wdaBundleId='org.example.wda')
        async def fresh(binding):self.assertEqual(self.binding,binding);self.source.current();self.starts.append(deepcopy(binding))
        self.ops.fresh_touch_scope=fresh
        self.addAsyncCleanup(self.cleanup_native)
    async def cleanup_native(self):
        self.close_failure=False
        for service in self.services:service.gate.set();service.fail_close=False
        for task in self.tasks:
            if not task.done():await asyncio.wait_for(asyncio.shield(task),3)
        for row in self.source._native_reads:await self.source._close_native_read(row)
        await self.source.settle_touches()
        if self.controls:await asyncio.gather(*self.controls,return_exceptions=True)
    def args(self):return dict(binding=deepcopy(self.binding),runId=self.f.run_id,resultsDirectory='owned',query=dict(schemaVersion=1,commandId=self.packet['commandId'],action='native-geometry-snapshot'))
    def start(self,args=None):
        task=asyncio.create_task(self.ops.execute('touch-native-original-read',self.args() if args is None else args,self.binding['sessionId']));self.tasks.append(task);return task
    async def touch(self):
        with patch('ios.adapters.hid_session.touch_session',side_effect=lambda *_a,**_k:self.f.context):
            lease=self.source.touch_lease(self.f.store,binding=self.binding,run=self.f.run_id,check=lambda:True)
            self.f.owner=lease;self.ops.touch=lease;await lease.begin(100,50,25,10,seconds=3)
        return lease

    async def test_same_rsd_vend_before_demux_and_exact_real_bytes_never_mint_fresh_native_authority(self):
        before=self.input.read_bytes();value=await self.start();service=self.services[0]
        self.assertEqual([('vend','org.example.overte','VendContainer'),('enter',)],service.calls[:2])
        self.assertEqual(before,value['rawJson'].encode());self.assertEqual(hashlib.sha256(before).hexdigest(),value['sha256'])
        self.assertTrue(all(not value[key] for key in ('queryIssuanceOwned','freshNativeAcquisitionEstablished','installedCandidateBound','physicalFileIdentityEstablished','nativeMotionGuardAvailable','nativeTouchSupport','resourceRetirementEstablished')))
        self.assertEqual(before,self.input.read_bytes());self.assertTrue(all(fd.fileno()==-1 for fd in service.sockets));self.assertIsNone(service._afc_reader_task)
        self.assertIn(('open','/Documents/owned/ios-ui-request-result.json','r'),service.calls)

    async def test_actual_world_original_typed_pid_run_and_raw_bytes_use_the_same_fixed_channel(self):
        from ios.self_tests.test_ios_lifecycle_touch import TouchBoundary
        from ios.adapters import lifecycle_world as world
        from ios.self_tests.test_ios_lifecycle_world import RUN
        # The existing Scene producer was born with RUN before this capture;
        # never rewrite its original journal/run to match the touch fixture.
        b=TouchBoundary();packet=b.reader().read(RUN);self.input.write_text(json.dumps(packet))
        self.assertEqual(RUN,packet['runId']);self.assertEqual(int(self.binding['processIdentity']),packet['processId'])
        args=self.args();args['runId']=RUN
        args['query']=dict(schemaVersion=1,commandId=packet['requestId'],action=world.ACTION,runId=RUN)
        value=await self.start(args);self.assertEqual(self.input.read_bytes(),value['rawJson'].encode());self.assertFalse(value['freshNativeAcquisitionEstablished'])
        self.assertIn(('open','/Documents/owned/'+world.FILE,'r'),self.services[0].calls)

    async def test_supplied_stale_nonce_cannot_replace_original_bytes_and_missing_query_owner_stays_false(self):
        args=self.args();args['query']['commandId']='ios-'+'f'*32
        with self.assertRaises((RuntimeError,ValueError)):await self.start(args)
        self.assertEqual(1,len(self.services));self.assertTrue(self.source._native_reads[0][4].is_set())
        self.assertTrue(all(fd.fileno()==-1 for fd in self.services[0].sockets))

    async def test_foreign_source_object_during_vend_refuses_even_if_same_rsd_and_claim_survive(self):
        original=self.ops.source;foreign=type(original).__new__(type(original));foreign.__dict__.update(original.__dict__)
        self.hook=lambda _:setattr(self.ops,'source',foreign)
        with self.assertRaises(RuntimeError):await self.start()
        self.assertNotIn(('enter',),self.services[0].calls);self.assertEqual(1,len(original._native_reads));self.ops.source=original

    async def test_original_release_after_down_refuses_native_read_and_still_sends_only_once_up(self):
        lease=await self.touch();self.hook=lambda _:lease.request_release.set()
        with self.assertRaises(RuntimeError):await self.start()
        await self.source.settle_touches();self.assertEqual([0xC2,0x02],self.f.states());self.assertEqual(1,self.f.context.exited)
        self.assertNotIn(('enter',),self.services[0].calls)

    async def test_actual_slow_original_read_does_not_widen_1_5s_budget_or_retime_native_receipt(self):
        before=self.input.read_bytes();self.delay=1.55
        with self.assertRaises(RuntimeError):await self.start()
        self.assertEqual(before,self.input.read_bytes());self.assertTrue(all(fd.fileno()==-1 for fd in self.services[0].sockets))

    async def test_escaped_reply_cap_refuses_large_original_after_actual_read_and_close(self):
        self.input.write_bytes(self.input.read_bytes()+b' '*13000)
        with self.assertRaises(RuntimeError):await self.start()
        self.assertTrue(self.source._native_reads[0][4].is_set());self.assertTrue(all(fd.fileno()==-1 for fd in self.services[0].sockets))

    async def test_failed_original_close_retains_creator_until_existing_cleanup_retries_same_service(self):
        self.close_failure=True
        with self.assertRaises(RuntimeError):await self.start()
        started=asyncio.Event();source_closed=[]
        async def creator_exit():
            started.set();await self.source.settle_touches();source_closed.append(True)
        exiting=asyncio.create_task(creator_exit());self.controls.append(exiting);await started.wait()
        self.assertFalse(exiting.done());self.assertEqual([],source_closed);service=self.services[0]
        self.assertTrue(any(fd.fileno()>=0 for fd in service.sockets));self.assertFalse(self.source._native_reads[0][4].is_set())
        self.close_failure=False;await self.source.settle_touches();await exiting
        self.assertEqual([True],source_closed);self.assertEqual(1,len(self.services));self.assertTrue(all(fd.fileno()==-1 for fd in service.sockets))
