from pathlib import Path
import hashlib,importlib.util,json,stat,sys
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
assert len(sys.argv)==2 and sys.argv[1] in ('before','after')
phase=sys.argv[1];metadata=REPO/'.ios-host-tmp/audio-normal-close-evidence-root-preparation-20261028/run_metadata.py'
spec=importlib.util.spec_from_file_location('audio_private_check_metadata',metadata);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
plan=module.validate_frozen();sources=module.sources(plan);sources[str(Path(__file__).resolve().relative_to(REPO))]=module.pin(Path(__file__).resolve());sources[str((HERE/'retention-plan.json').relative_to(REPO))]=module.pin(HERE/'retention-plan.json')
stage_path=REPO/'.ios-host-tmp/lifecycle-original-owner-root-three-stage-preparation-20261028/03-motion7/source-manifest.json'
for row in json.loads(stage_path.read_text())['sourcePaths']:
    path=REPO/row['path'];need_sha=hashlib.sha256(path.read_bytes()).hexdigest();assert need_sha==row['candidateSHA256'],row['path']
    sources[row['path']]=module.pin(path)
sources[str(stage_path.relative_to(REPO))]=module.pin(stage_path)
module.save(HERE/(phase+'-sources.json'),sources)
if phase=='after':assert sources==json.loads((HERE/'before-sources.json').read_text()),'Public/launcher source changed'
reports=[]
for label,reportname,censusname in json.loads((HERE/'retention-plan.json').read_text()):
    report=json.loads((REPO/reportname).read_text());expected=json.loads((REPO/censusname).read_text())
    root=Path(report['runRoot'])/'temporary';actual=module.originals(root);assert actual==expected,label
    reports.append(dict(label=label,files=sum(stat.S_ISREG(v['st_mode']) for v in actual.values()),originalsUnchanged=True))
root=REPO/'.ios-host-tmp/lifecycle-owner-exact26-async-setup-testprep-20261028/retained-first26'
expected=json.loads((REPO/'.ios-host-tmp/lifecycle-owner-exact26-async-setup-root-preparation-20261028/originals-first.json').read_text())
fields=('st_dev','st_ino','st_mode','st_nlink','st_uid','st_gid','st_size','st_mtime_ns','st_ctime_ns')
actual={}
for p in (root,*sorted(root.rglob('*'))):
    a=p.lstat();row=dict(stat=[getattr(a,k) for k in fields])
    if stat.S_ISREG(a.st_mode):row['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
    actual[str(p.relative_to(root))]=row
assert actual==expected,'Lifecycle model originals changed'
reports.append(dict(label='lifecycle-async-setup26',files=sum(stat.S_ISREG(v['stat'][2]) for v in actual.values()),originalsUnchanged=True))
stage_roots=[
('.ios-host-tmp/lifecycle-original-owner-root-three-stage-preparation-20261028/01-final35','retained-exact35-first','root-run-first'),
('.ios-host-tmp/lifecycle-original-owner-root-three-stage-preparation-20261028/02-resource11','retained-first','root-run-first'),
('.ios-host-tmp/lifecycle-original-owner-root-three-stage-preparation-20261028/03-motion7','retained-first','root-run-first'),
('.ios-host-tmp/lifecycle-original-owner-motion7-cleanup-root-preparation-20261028/03-motion7','retained-first','root-run-first'),
('.ios-host-tmp/lifecycle-original-owner-post-motion-v1-borrow4-root-preparation-20261028/04-borrow4','retained-first','root-run-first')]
for packet,dirname,outname in stage_roots:
    base=REPO/packet;root=base/dirname;expected=json.loads((base/outname/'originals-first.json').read_text());actual={}
    for path in (root,*sorted(root.rglob('*'))):
        before=path.lstat();item={'stat':[getattr(before,key) for key in fields]}
        if stat.S_ISREG(before.st_mode):item['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
        assert item['stat']==[getattr(path.lstat(),key) for key in fields]
        actual[str(path.relative_to(root))]=item
    assert actual==expected,packet
    reports.append(dict(label=packet,files=sum(stat.S_ISREG(row['stat'][2]) for row in actual.values()),originalsUnchanged=True))
module.save(HERE/(phase+'-retention.json'),reports)
print(json.dumps(dict(phase=phase,sourcePins=len(sources),retainedFiles=sum(v['files'] for v in reports),allOriginalsUnchanged=True)),flush=True)
