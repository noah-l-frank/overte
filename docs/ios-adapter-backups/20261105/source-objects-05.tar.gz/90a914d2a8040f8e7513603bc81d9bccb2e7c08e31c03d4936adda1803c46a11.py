"""Exactly14 reviewed host cases; retained fixture lifetime only."""
from pathlib import Path
from types import SimpleNamespace
from contextlib import ExitStack
import json,os,tempfile,unittest
from unittest.mock import patch
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1];RETAINED=HERE/'retained-first14'
RETAINED.mkdir(mode=0o700,exist_ok=False)
MKDTEMP=tempfile.mkdtemp;cases=[]
def save(name,value):(HERE/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')
def proc(pid):
    tail=Path('/proc/'+str(pid)+'/stat').read_text().rsplit(') ',1)[1].split()
    return dict(pid=pid,ppid=int(tail[1]),pgid=int(tail[2]),sid=int(tail[3]),startTicks=int(tail[19]))
save('runner-process.json',proc(os.getpid()));print('ACTUAL_RUNNER',json.dumps(proc(os.getpid())),flush=True)
def replacement(label):
    class RetainedDirectory:
        def __init__(self,*,prefix=None):
            self.name=MKDTEMP(prefix=label+'-' if prefix is None else prefix,dir=RETAINED)
        def cleanup(self):pass
    return SimpleNamespace(TemporaryDirectory=RetainedDirectory)
def roots():return {str(path) for path in RETAINED.iterdir() if path.is_dir()}
class Result(unittest.TextTestResult):
    def startTest(self,test):super().startTest(test);self.previous=roots();print('START_CASE',test.id(),flush=True)
    def stopTest(self,test):
        cases.append(dict(id=test.id(),actualOwnedRoots=sorted(roots()-self.previous)))
        super().stopTest(test);print('END_CASE',test.id(),flush=True)
from ios.self_tests import test_ios_emote_marker_scope as primary_fixture
from ios.self_tests import world_web_actor_fixture as actor_fixture
from ios.self_tests import test_ios_world_web_scope_construction_round as new_tests
names=('ios.self_tests.test_ios_world_web_scope_construction_round','ios.self_tests.test_ios_world_web_scope_archive',
    'ios.self_tests.test_ios_world_web_feature.WorldWebFeatureTests.test_actual_factory_baseline_normal_script_open_and_independent_dual_sdk_admission')
suite=unittest.defaultTestLoader.loadTestsFromNames(names)
def flatten(test):
    return [case for child in test for case in flatten(child)] if isinstance(test,unittest.TestSuite) else [test.id()]
identifiers=flatten(suite);expected=json.loads((HERE/'final-manifest.json').read_text())['selectedCaseIds']
assert len(identifiers)==len(set(identifiers))==14 and set(identifiers)==set(expected),identifiers
save('first14-selected-case-ids.json',identifiers);result=None
try:
    with ExitStack() as patches:
        for module,label in ((primary_fixture,'primary'),(actor_fixture,'actor'),(new_tests,'inode')):
            patches.enter_context(patch.object(module,'tempfile',replacement(label)))
        result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=Result).run(suite)
finally:
    save('first14-test-report.json',dict(testsRun=None if result is None else result.testsRun,
        successful=False if result is None else result.wasSuccessful(),caseResults=cases,
        actualOwnedRoots=sorted(roots()),selectedIds=identifiers,nativeExecuted=False,deviceQualified=False,wholeFeatureQualified=False))
raise SystemExit(result is None or not result.wasSuccessful())
