"""Controller-only canonical write ports; never product or End authority."""
from contextlib import contextmanager
from pathlib import Path
import builtins,io,os,stat,sys,threading


class WriteRefusal(RuntimeError):pass




class OwnedWrites:
    def __init__(self,root,protected=(),*,copy_file_range_gate=None):
        self.copy_file_range_gate=copy_file_range_gate
        self.copy_file_range_binding=None
        if copy_file_range_gate is not None:
            cls=type(copy_file_range_gate);function=cls.__dict__['copy']
            self.copy_file_range_binding=(copy_file_range_gate,cls,function,function.__code__,function.__globals__)
        self.root=Path(root).resolve(strict=True);self.identity=self._signature(self.root.lstat())
        if not self.root.is_dir()or self.root.is_symlink():raise WriteRefusal('Invalid owned root')
        self.thread=threading.get_ident();self.authority=None;self.depth=False;self.installed=False
        self.original={name:getattr(os,name)for name in ('open','close','mkdir','unlink','remove','rmdir','rename','replace',
            'chmod','chown','utime','truncate','fchmod','fchown','ftruncate','write','writev','pwrite','pwritev','link','symlink','mkfifo','mknod','posix_fallocate','sendfile','copy_file_range','splice')if hasattr(os,name)}
        self.original_io,self.original_builtin=io.open,builtins.open
        self.protected={Path(p).resolve(strict=True)for p in protected}
        self.known={};self.control_fds=set();self.ports={};self.closed=False
        self.original_items=tuple(self.original.items())
        self.implementation=[];self.wrapped=[];self.function_seals=[]
        for name,member in tuple(type(self).__dict__.items()):
            function=member.__func__ if type(member)is staticmethod else member
            if callable(function)and hasattr(function,'__code__'):
                self.implementation.append((name,member,function,function.__code__,function.__globals__))
                wrapped=getattr(function,'__wrapped__',None)
                if wrapped is not None:self.wrapped.append((function,wrapped,wrapped.__code__,wrapped.__globals__))
        self.global_values=tuple((name,globals()[name])for name in ('Path','builtins','io','os','stat','sys','threading','WriteRefusal','OwnedWrites'))
        self.reader_values=tuple((module,name,getattr(module,name))for module,names in (
            (os,('fstat','readlink','geteuid','fsdecode','lstat','stat')),
            (stat,('S_ISDIR','S_ISLNK','S_ISREG')),(sys,('_getframe',)),(threading,('get_ident',)))for name in names)
        self.invocation_code=type(self).__dict__['invoke'].__code__
        for unused,unused2,function,unused3,unused4 in self.implementation:self._seal_function(function)
        for unused,function,unused2,unused3 in self.wrapped:self._seal_function(function)
        for fd in (1,2):
            try:self._remember(fd)
            except (OSError,WriteRefusal):pass

    def _seal_function(self,function):
        defaults=function.__defaults__;keywords=function.__kwdefaults__
        self.function_seals.append((function,defaults,tuple(defaults or ()),keywords,tuple((keywords or {}).items()),
            function.__closure__,tuple(cell.cell_contents for cell in function.__closure__ or ())))

    @staticmethod
    def _signature(s):return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid)
    def _check(self):
        for function,defaults,values,keywords,items,closure,cells in self.function_seals:
            if function.__defaults__ is not defaults or function.__kwdefaults__ is not keywords or function.__closure__ is not closure:
                raise WriteRefusal('Write boundary default/closure binding changed')
            if len(defaults or ())!=len(values)or any(a is not b for a,b in zip(defaults or (),values)):
                raise WriteRefusal('Write boundary defaults changed')
            if tuple(keywords or ())!=tuple(key for key,value in items)or any(keywords[key]is not value for key,value in items):
                raise WriteRefusal('Write boundary keyword defaults changed')
            if any(cell.cell_contents is not value for cell,value in zip(closure or (),cells)):
                raise WriteRefusal('Write boundary closure changed')
        for name,member,function,code,namespace in self.implementation:
            if type(self).__dict__.get(name)is not member or function.__code__ is not code or function.__globals__ is not namespace:
                raise WriteRefusal('Write boundary implementation changed')
        for wrapper,function,code,namespace in self.wrapped:
            if wrapper.__wrapped__ is not function or function.__code__ is not code or function.__globals__ is not namespace:
                raise WriteRefusal('Original contextmanager body changed')
        if any(globals().get(name)is not value for name,value in self.global_values):raise WriteRefusal('Write boundary global changed')
        if any(getattr(module,name)is not value for module,name,value in self.reader_values):raise WriteRefusal('Write boundary reader alias changed')
        if tuple(self.original)!=tuple(name for name,value in self.original_items)or any(self.original[name]is not value for name,value in self.original_items):
            raise WriteRefusal('Original write port custody changed')
        if threading.get_ident()!=self.thread or self.closed:raise WriteRefusal('Write port thread/lifetime changed')
        if self._signature(self.root.lstat())!=self.identity or self.root.resolve(strict=True)!=self.root:
            raise WriteRefusal('Owned root changed')
        if self.installed:
            for port,function,code,closure in self.port_implementations:
                if getattr(port,'__func__',port)is not function or function.__code__ is not code:
                    raise WriteRefusal('Installed write port code changed')
                if any(cell.cell_contents is not value for cell,value in zip(function.__closure__ or (),closure))or len(function.__closure__ or ())!=len(closure):
                    raise WriteRefusal('Installed write port closure changed')
            if any(getattr(os,k)is not v for k,v in self.ports.items()):raise WriteRefusal('OS write alias changed')
            if io.open is not self.original_io or builtins.open is not self.original_builtin:raise WriteRefusal('Original C IO alias changed')

    def target(self,path,*,write=True):
        self._check()
        if type(path)not in (str,bytes,type(self.root)):raise WriteRefusal('Unsupported pathname port')
        path=Path(os.fsdecode(path))
        if not path.is_absolute():raise WriteRefusal('Relative pathname has no admitted parent')
        if '..'in path.parts:raise WriteRefusal('Parent traversal refused')
        resolved=path.resolve(strict=False)
        if not resolved.is_relative_to(self.root)or resolved==self.root:raise WriteRefusal('Foreign write target')
        if resolved!=path:raise WriteRefusal('Noncanonical or symlink write target')
        if write and resolved in self.protected:raise WriteRefusal('Frozen controller target')
        current=self.root
        for name in path.relative_to(self.root).parts:
            current=current/name
            try:s=current.lstat()
            except FileNotFoundError:
                if current!=path:raise FileNotFoundError(2,'Missing canonical own parent',str(current))
                break
            if stat.S_ISLNK(s.st_mode)or s.st_uid!=os.geteuid():raise WriteRefusal('Foreign or symlink component')
            if current!=path and not stat.S_ISDIR(s.st_mode):raise WriteRefusal('Non-directory write parent')
        return path

    @contextmanager
    def parent(self,path):
        path=self.target(path);fds=[]
        try:
            fd=self.original['open'](self.root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
            fds.append(fd);self.control_fds.add(fd)
            if self._signature(os.fstat(fd))!=self.identity:raise WriteRefusal('Root descriptor changed')
            current=self.root
            for name in path.parent.relative_to(self.root).parts:
                current=current/name;s=current.lstat()
                child=self.original['open'](name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
                fds.append(child);self.control_fds.add(child)
                if self._signature(os.fstat(child))!=self._signature(s):raise WriteRefusal('Parent descriptor changed')
                fd=child
            before=self._signature(os.fstat(fd))
            yield fd,path.name
            if self._signature(os.fstat(fd))!=before or self._signature(path.parent.lstat())!=before:
                raise WriteRefusal('Parent changed during mutation')
        finally:
            for fd in reversed(fds):self.control_fds.discard(fd);self.original['close'](fd)

    def _remember(self,fd,*,record=True):
        s=os.fstat(fd);raw=os.readlink('/proc/self/fd/'+str(fd))
        if raw.endswith(' (deleted)'):raise WriteRefusal('Deleted descriptor target')
        path=self.target(raw,write=False)
        if not(stat.S_ISREG(s.st_mode)and s.st_nlink==1 or stat.S_ISDIR(s.st_mode))or s.st_uid!=os.geteuid():raise WriteRefusal('Unknown write descriptor')
        actual=path.lstat()
        if (s.st_dev,s.st_ino)!=(actual.st_dev,actual.st_ino):raise WriteRefusal('Descriptor/path mismatch')
        if record:self.known[fd]=(path,s.st_dev,s.st_ino)
        return path
    def fd(self,fd,*,stream=False):
        self._check()
        if type(fd)is not int or fd<0:raise WriteRefusal('Invalid integer write port')
        if fd not in self.known:
            path=self._remember(fd,record=False)
            if path in self.protected:raise WriteRefusal('Frozen descriptor target')
            return path
        before=self.known[fd];path=self._remember(fd)
        if self.known[fd]!=before:raise WriteRefusal('Reused write descriptor')
        if path in self.protected and not(stream and fd in (1,2)):raise WriteRefusal('Frozen descriptor target')
        return path

    def invoke(self,event,args,function,*callargs,**kwargs):
        self._check()
        if self.authority is not None:raise WriteRefusal('Reentrant mutation port')
        frame=sys._getframe();self.authority=(event,args,frame)
        if frame.f_code is not self.invocation_code:raise WriteRefusal('Wrong original invocation code')
        try:return function(*callargs,**kwargs)
        finally:self.authority=None

    def os_open(self,path,flags,mode=0o777,*,dir_fd=None):
        if dir_fd is not None:raise WriteRefusal('External open dir_fd refused')
        writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if not writing:return self.original['open'](path,flags,mode)
        self._check()
        path=self.target(path)
        with self.parent(path)as(fd,name):
            effective=flags|os.O_NOFOLLOW|os.O_CLOEXEC
            result=self.invoke('open',(name,None,effective),self.original['open'],name,effective,mode,dir_fd=fd)
        self._remember(result);return result

    def mutate(self,name,*args,**kwargs):
        self._check()
        # New local variant: exactly one separately bound genuine shutil port.
        # All kwargs-free calls and every other original port stay literal.
        if name=='copy_file_range'and kwargs:
            if self.copy_file_range_gate is None:raise WriteRefusal('No exact shutil copy range admission')
            gate,cls,function,code,namespace=self.copy_file_range_binding
            if self.copy_file_range_gate is not gate or type(gate)is not cls or cls.__dict__['copy']is not function or function.__code__ is not code or function.__globals__ is not namespace:
                raise WriteRefusal('Exact shutil copy range binding changed')
            return function(gate,self,*args,**kwargs)
        allowed={'mkdir':{'mode','dir_fd'},'unlink':{'dir_fd'},'remove':{'dir_fd'},'rmdir':{'dir_fd'},
            'rename':{'src_dir_fd','dst_dir_fd'},'replace':{'src_dir_fd','dst_dir_fd'},
            'chmod':{'mode','dir_fd','follow_symlinks'},'chown':{'uid','gid','dir_fd','follow_symlinks'},
            'utime':{'times','ns','dir_fd','follow_symlinks'},'truncate':set(),'fchmod':set(),'fchown':set(),'ftruncate':set(),'write':set(),
            'writev':set(),'pwrite':set(),'pwritev':set(),'link':set(),'symlink':set(),
            'mkfifo':set(),'mknod':set(),'posix_fallocate':set(),'sendfile':set(),'copy_file_range':set(),'splice':set()}
        if name not in allowed or set(kwargs)-allowed[name]:raise WriteRefusal('Unsupported mutation arguments')
        if kwargs.get('follow_symlinks',True)is not True:raise WriteRefusal('Unsupported symlink mutation semantics')
        if any(key in kwargs for key in ('mode','uid','gid'))and name!='mkdir':raise WriteRefusal('Use positional ownership/mode arguments')
        for key in ('dir_fd','src_dir_fd','dst_dir_fd'):
            if kwargs.get(key)is not None:raise WriteRefusal('External mutation dir_fd refused')
        if name in ('link','symlink','mkfifo','mknod'):raise WriteRefusal('Unsupported link/special-file mutation')
        if name in ('posix_fallocate','sendfile','copy_file_range','splice'):
            output=0 if name in ('posix_fallocate','sendfile')else 1
            self.fd(args[output]);return self.original[name](*args,**kwargs)
        if name in ('writev','pwrite','pwritev'):
            self.fd(args[0]);return self.original[name](*args,**kwargs)
        if name in ('fchmod','fchown','ftruncate','write'):
            fd=args[0];self.fd(fd,stream=name=='write')
            event={'fchmod':'os.chmod','fchown':'os.chown','ftruncate':'os.truncate','write':None}[name]
            if event is None:return self.original[name](*args,**kwargs)
            wire=(fd,*args[1:],-1)if name in ('fchmod','fchown')else(fd,args[1])
            return self.invoke(event,wire,self.original[name],*args,**kwargs)
        if name in ('chmod','chown','utime','truncate')and type(args[0])is int:
            self.fd(args[0]);event='os.'+name
            # Audit payloads differ by platform; descriptor custody is already
            # exact. The active port still binds event/frame and all inputs.
            return self.invoke(event,None,self.original[name],*args,**kwargs)
        if name in ('rename','replace'):
            source,dest=self.target(args[0]),self.target(args[1])
            with self.parent(source)as(a,left),self.parent(dest)as(b,right):
                return self.invoke('os.rename',(left,right,a,b),self.original[name],left,right,src_dir_fd=a,dst_dir_fd=b)
        path=self.target(args[0]);rest=args[1:]
        with self.parent(path)as(fd,leaf):
            if name in ('unlink','remove','rmdir'):
                event='os.rmdir'if name=='rmdir'else'os.remove'
                return self.invoke(event,(leaf,fd),self.original[name],leaf,dir_fd=fd)
            if name=='mkdir':
                mode=rest[0]if rest else kwargs.get('mode',0o777)
                return self.invoke('os.mkdir',(leaf,mode,fd),self.original[name],leaf,mode,dir_fd=fd)
            if name in ('chmod','chown','utime','truncate'):
                opened=self.original['open'](leaf,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=fd)
                try:
                    self._remember(opened);self.fd(opened)
                    if name=='chmod':return self.mutate('fchmod',opened,*rest)
                    if name=='chown':return self.mutate('fchown',opened,*rest)
                    if name=='truncate':return self.mutate('ftruncate',opened,*rest)
                    # fd utime forbids a second dir_fd/follow_symlinks port.
                    options={k:v for k,v in kwargs.items()if k in ('times','ns')}
                    return self.invoke('os.utime',None,self.original['utime'],opened,*rest,**options)
                finally:self.original['close'](opened)
        raise WriteRefusal('Unknown write port')

    def audit(self,event,args,caller):
        if self.depth:
            # Reentrancy is confined to exact stdlib metadata reads made by this
            # audit callback. A callback cannot acquire a write port here.
            if event in ('os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink'):
                raise WriteRefusal('Nested filesystem mutation during audit')
            if event=='open':
                unused,mode,flags=args
                if flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND)or type(mode)is str and any(c in mode for c in 'wax+'):
                    raise WriteRefusal('Nested writable open during audit')
            return
        self.depth=True
        try:
            if event=='open':
                path,mode,flags=args;writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))or type(mode)is str and any(c in mode for c in 'wax+')
                if not writing:return
                self._check()
                if type(path)is int:self.fd(path,stream=True);return
                if mode is None:
                    auth=self.authority
                    if auth is None or auth[0]!='open'or auth[1]!=args or caller is not auth[2]or caller.f_code is not self.invocation_code:raise WriteRefusal('Unbound writable os.open alias')
                else:
                    # Keep the actual C IO port original. CPython's C-IO audit
                    # supplies a pathname, never a dir_fd; require an absolute
                    # canonical own path and re-read the actual parent chain.
                    # This is a controlled-writer boundary, not an atomic
                    # kernel O_NOFOLLOW guarantee for C-IO after this callback.
                    path=self.target(path)
                    with self.parent(path):pass
            elif event in ('os.remove','os.rmdir','os.mkdir','os.chmod','os.chown','os.utime','os.truncate','os.rename','os.link','os.symlink'):
                self._check();auth=self.authority
                if auth is None or auth[0]!=event or caller is not auth[2]or caller.f_code is not self.invocation_code or auth[1]is not None and args!=auth[1]:
                    raise WriteRefusal('Unbound filesystem mutation/dir_fd alias')
            elif event=='fcntl.flock':self.fd(args[0])
            elif event.startswith('fcntl.')or event in ('os.setxattr','os.removexattr','os.chdir','os.chroot'):
                raise WriteRefusal('Unsupported descriptor or filesystem control')
        finally:self.depth=False

    def install(self):
        self._check()
        for name in self.original:
            if name=='close':continue
            if name=='open':port=self.os_open
            else:
                def port(*args,_name=name,**kwargs):return self.mutate(_name,*args,**kwargs)
            self.ports[name]=port;setattr(os,name,port)
        self.port_implementations=[]
        for port in self.ports.values():
            function=getattr(port,'__func__',port)
            self.port_implementations.append((port,function,function.__code__,tuple(cell.cell_contents for cell in function.__closure__ or ())))
            self._seal_function(function)
        self.installed=True
    def restore(self):
        self._check()
        for name,original in self.original.items():setattr(os,name,original)
        io.open,builtins.open=self.original_io,self.original_builtin;self.installed=False
        if self.control_fds:raise WriteRefusal('Controller parent descriptor remains live')
    def close(self):
        if self.installed:self.restore()
        if self.control_fds:raise WriteRefusal('Controller descriptor remains live')
        self.closed=True
