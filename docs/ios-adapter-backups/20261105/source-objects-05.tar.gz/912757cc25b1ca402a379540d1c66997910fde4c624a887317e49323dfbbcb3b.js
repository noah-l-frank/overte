module.exports = {kind: "avatar-marker-v1"};
