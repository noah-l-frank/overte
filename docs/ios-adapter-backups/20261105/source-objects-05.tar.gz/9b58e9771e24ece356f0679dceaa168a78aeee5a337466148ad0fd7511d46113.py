"""Comparison-only pure scaffold; never installed as a Lifecycle policy.

Same private pure-bench Comparisons class. Reads every alias fresh; falls back
to actual unchanged tokenizer for unoptimized branches. No result memoization.
This scaffold assumes unchanged stdlib classifier bindings and is NOT a complete
production verifier proposal or a replacement for policy.admitted().
"""
from types import FunctionType
from ios.adapters.emote_callback_live_records import _token,_Unsupported
class Comparisons:
    """Share immutable instructions, NEVER comparison or verification results.

    Optimized exact built-in function/class/container branches; all other
    supported/unsupported branches invoke the unchanged literal tokenizer at
    their original active/depth boundary. No decoder or source namespace used.
    """
    def __init__(self):self.instructions={}
    def compile(self,expected):
        try:saved=self.instructions.get(expected)
        except TypeError:saved=None
        if saved is not None:return saved
        tag=expected[0]if type(expected)is tuple and expected else None
        children=None
        if tag in('list','tuple'):children=tuple(self.compile(t)for t in expected[1])
        elif tag=='dict':children={pair[0]:self.compile(pair[1])for pair in expected[1]}
        elif tag=='function':children=(self.compile(expected[3]),self.compile(expected[4]),tuple(self.compile(t)for t in expected[5]))
        elif tag=='class':children={name:self.compile(t)for name,t in expected[3]}
        def compare(value,refs,active,depth=0):
            if depth>32:raise _Unsupported(type(value),'depth')
            kind=type(value)
            if kind in(str,bytes,int,bool,type(None)):return (kind.__name__,value)==expected
            if kind is float:return ('float',value.hex())==expected
            refs.append(value);identity=id(value)
            if identity in active:return ('recursive',identity)==expected
            original_active=active;active=active|{identity}
            def literal():
                temporary=[]
                try:result=_token(value,temporary,original_active,depth)
                finally:refs.extend(temporary[1:]) # Prefix's same strong ref already appended.
                return result==expected
            # Classification globals are actual current globals just as in
            # _token. Fast branches below precede no earlier competing dynamic
            # branch in the declared stdlib type environment of this pure bench.
            if tag=='function'and kind is FunctionType:
                refs.append(value.__code__);cl=value.__closure__;cells=()if cl is None else cl
                matched=len(cells)==len(children[2])
                for i,cell in enumerate(cells):
                    check=children[2][i]if i<len(children[2])else self.compile(('missing-cell',))
                    current=check(cell.cell_contents,refs,active,depth+1);matched=current and matched
                code_id=id(value.__code__)
                a=children[0](value.__defaults__,refs,active,depth+1);b=children[1](value.__kwdefaults__,refs,active,depth+1)
                return identity==expected[1]and code_id==expected[2]and matched and a and b
            if tag in('list','tuple')and kind is(list if tag=='list'else tuple):
                matched=len(value)==len(children)
                for i,item in enumerate(value):
                    check=children[i]if i<len(children)else self.compile(('missing-item',))
                    current=check(item,refs,active,depth+1);matched=current and matched
                return matched
            if tag=='dict'and kind is dict:
                unsupported=next((type(key)for key in value if type(key)not in(str,int)),None)
                if unsupported is not None:raise _Unsupported(unsupported,'mapping-key')
                matched=len(value)==len(children)
                for key,item in value.items():
                    token=(type(key).__name__,key);check=children.get(token)
                    if check is None:
                        _token(item,refs,active,depth+1);matched=False
                    else:
                        current=check(item,refs,active,depth+1);matched=current and matched
                return matched
            if tag=='class'and kind is type and value.__module__.startswith(('adapters.','ios.adapters.','feature_journeys.')):
                names=[];matched=True
                for name,item in sorted(vars(value).items()):
                    if name.startswith('__')and name not in('__init__','__enter__','__exit__','__call__'):continue
                    names.append(name);check=children.get(name)
                    if check is None:
                        _token(item,refs,active,depth+1);matched=False
                    else:
                        current=check(item,refs,active,depth+1);matched=current and matched
                refs.append(value.__bases__)
                return (matched and identity==expected[1]and tuple(id(base)for base in value.__bases__)==expected[2]
                    and tuple(names)==tuple(name for name,_token in expected[3]))
            return literal()
        try:self.instructions[expected]=compare
        except TypeError:pass
        return compare
