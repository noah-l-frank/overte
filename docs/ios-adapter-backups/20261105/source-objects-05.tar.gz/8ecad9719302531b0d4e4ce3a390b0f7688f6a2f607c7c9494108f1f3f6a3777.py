"""Root serial orchestration; four original supervisors, one complete global window.

No product helper, case, deadline, supervisor or ownership predicate is changed.
Every executed group preserves its own original parent/child boundary. Any group
failure stops later groups; old originals and every actual whole output remain.
"""
from pathlib import Path
import argparse,hashlib,json,os,runpy,stat,subprocess,sys,traceback
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
REPO=Path.cwd().resolve(strict=True);PRIVATE=REPO/'.ios-host-tmp'
SUBJECT=PRIVATE/'snapshot-scene-remaining13-fixed-groups-bootstrap4-complete-controller-data-closure-private-20261104'
SUBJECT_SHA='418b7cf916b92621deac49b173298e4e4ee3d14e0e3e4f4942cb4201fb1426bf'
HELPER_SHA='bc0522314e4b0d2e0ec080048efd4d868ce3013d87f8b5de52ae306999609e03'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def checked(path):
 path=Path(path);assert path.is_absolute()and path.resolve(strict=True)==path and path.is_relative_to(PRIVATE);return path

def census(root):
    assert root.resolve(strict=True) == root and root.is_dir() and not root.is_symlink()
    result = {}
    for path in (root, *sorted(root.rglob('*'))):
        before = path.lstat()
        value = {key: getattr(before, key) for key in FIELDS}
        if stat.S_ISREG(before.st_mode):
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            try:
                assert all(getattr(os.fstat(descriptor), key) == value[key] for key in FIELDS)
                digest = hashlib.sha256()
                while chunk := os.read(descriptor, 1024 * 1024):
                    digest.update(chunk)
                assert all(getattr(os.fstat(descriptor), key) == value[key] for key in FIELDS)
                value['sha256'] = digest.hexdigest()
            finally:
                os.close(descriptor)
        elif stat.S_ISLNK(before.st_mode):
            value['target'] = os.readlink(path)
        else:
            assert stat.S_ISDIR(before.st_mode)
        assert all(getattr(path.lstat(), key) == value[key] for key in FIELDS)
        result[str(path.relative_to(root))] = value
    return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--configuration',type=Path,required=True);p.add_argument('--configuration-sha',required=True);a=p.parse_args()
 assert REPO.name=='overte-ios-feature-adapters-resume-20261026'and sys.flags.no_site and sys.dont_write_bytecode
 config_path=checked(a.configuration);assert sha(config_path)==a.configuration_sha;config=load(config_path)
 assert config['schemaVersion']==1 and config['status']=='ROOT_REVIEWED_SINGLE_GLOBAL_WINDOW_SERIAL_THIRTEEN_UNRUN'
 assert config['scriptSha256']==sha(Path(__file__))and config['sourceFreeze']==SUBJECT_SHA and sha(SUBJECT/'source-freeze.json')==SUBJECT_SHA
 context=checked(config['context']);assert sha(context)==config['contextSha256'];context_body=load(context)
 assert context_body['allTargetsTerminal']is True and context_body['expectedHead']==config['expectedHead']
 helper_path=checked(context.parent/'global_original_corpus.py');assert sha(helper_path)==HELPER_SHA
 baseline_path=checked(context.parent/'global-original-corpus-baseline.json');expected=load(baseline_path)
 assert len(expected)==config['oldRootCount']and context_body['globalCustody']['baseline']==dict(path=str(baseline_path),sha256=sha(baseline_path))
 recipe=load(SUBJECT/'SOURCE-RECIPE.json');assert len(config['groups'])==4
 all_cases=[];plans=[];required=set()
 for index,row in enumerate(config['groups'],1):
  assert row['group']=='group-'+str(index);h=checked(row['input']).parent
  assert h.parent==PRIVATE and h.name.startswith('snapshot-scene-own4-prepared-')and not h.with_name(h.name+'-outer').exists()
  assert Path(row['input'])==h/'approved-inputs.json'and sha(row['input'])==row['inputSha256'];plan=load(row['input'])
  assert plan['controllerRoot']==str(h)and plan['repositoryRoot']==str(REPO)and plan['sourceFreeze']==SUBJECT_SHA and plan['actualPublicHead']==config['expectedHead']
  group=recipe['groups'][row['group']];assert plan['group']==row['group']and plan['cases']==group['cases']and plan['caseCount']==group['caseCount']==(4 if index==1 else 3)
  assert plan['wallSeconds']==180 and plan['killGraceSeconds']==5 and plan['expectedTemporaryDirectories']==2*len(plan['cases'])
  assert plan['NodeExecutions']==plan['SDKExecutions']==plan['physicalNativeQueries']==plan['oldCorpusInputs']==plan['globalOriginalScans']==0
  assert plan['subjectHelperSha256']=='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d'
  assert plan['qualifiedInitialFour']['firstFourQualified']is True and plan['qualifiedInitialFour']['remaining13Qualified']is False
  assert plan['externalRootGuardMustIncludeInitialFourRooms']is plan['externalRootGuardMustIncludeAllHelperOriginalRooms']is True
  assert len(plan['initialFourRequiredOriginalRooms'])==3 and len(plan['helperQualificationRequiredOriginalRooms'])==6
  required.update(plan['initialFourRequiredOriginalRooms']);required.update(plan['helperQualificationRequiredOriginalRooms'])
  for name in('supervise-group.py','run-group.py','closed_import_origins.py','initial_four_admission.py','source_execution_readiness.py','owned_write_boundary.py'):
   assert sha(h/name)==sha(SUBJECT/name)
  all_cases.extend(plan['cases']);plans.append((row,h,plan))
 assert len(all_cases)==len(set(all_cases))==13 and not set(all_cases)&set(recipe['excludedInitialFour'])
 assert required<=set(expected)and len(required)==9
 out=Path(config['output']);assert out.is_absolute()and out.resolve(strict=False)==out and out.parent==PRIVATE and out.name.startswith('root-snapshot-remaining13-serial-window-')and not out.exists()
 out.mkdir(mode=0o700)
 def put(name,value):
  path=out/name
  with path.open('x')as f:json.dump(value,f,sort_keys=True,separators=(',',':'));f.write('\n')
  path.chmod(0o600)
 helper=runpy.run_path(str(helper_path));before=helper['current']();assert before==expected
 put('global-before.json',before);put('configuration-reference.json',dict(path=str(config_path),sha256=a.configuration_sha))
 groups=[];new_roots=[]
 for row,h,plan in plans:
  outer=h.with_name(h.name+'-outer')
  attempt=dict(status='ROOT_ATTEMPT_DECLARED_BEFORE_SUPERVISOR_START_NO_ABSENCE_CLAIM',group=row['group'],input=row['input'],inputSha256=row['inputSha256'],prospectiveOriginalRooms=[str(h),str(outer)],ownedProcessAbsenceEstablished=False)
  put('attempt-before-'+row['group']+'.json',attempt)
  try:
   print('ROOT_SERIAL_START '+row['group']+' '+str(len(plan['cases']))+' CASES',flush=True)
   with(out/(row['group']+'-stdout.log')).open('xb')as stdout,(out/(row['group']+'-stderr.log')).open('xb')as stderr:
    result=subprocess.run([sys.executable,'-S','-B',str(h/'supervise-group.py'),row['inputSha256']],cwd=REPO,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
   terminal=load(outer/'terminal.json');drain=load(outer/'actual-process-drain.json')
   assert terminal['ownProcessesAbsent']is True and drain['remaining']==[]
   for own in drain['owned']:
    try:raw=Path('/proc',str(own['pid']),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):continue
    values=raw[raw.rfind(')')+2:].split();assert int(values[19])!=own['startTicks'],'Original owned process still exists'
  except BaseException as original_error:
   # Missing receipts/uncertain kernel ownership cannot become a quiet close.
   # Keep every attempted room named, including a possibly unborn outer room.
   # Post-global inventories and a qualified freeze require real absence first.
   try:
    put('unqualified-partial-custody.json',dict(status='ROOT_PARTIAL_ATTEMPT_CUSTODY_NO_QUIET_CLOSE',attempt=attempt,completedGroups=groups,allAttemptedOriginalRooms=list(map(str,new_roots))+[str(h),str(outer),str(out)],originalExceptionType=type(original_error).__module__+'.'+type(original_error).__qualname__,originalTraceback=traceback.format_exc(),currentGroupKernelAbsenceEstablished=False,postGlobalInventoriesQualified=False,quietFreezeWritten=False,remainingGroupsNotStarted=True))
   except BaseException:
    try:print('ROOT_PARTIAL_CUSTODY_RECORD_WRITE_FAILED_NO_QUALIFICATION',flush=True)
    except BaseException:pass
   raise
  groups.append(dict(group=row['group'],input=row['input'],inputSha256=row['inputSha256'],supervisorReturnCode=result.returncode,originalTerminal=terminal,originalRoots=[str(h),str(outer)]));new_roots.extend((h,outer))
  put('groups-after-'+row['group']+'.json',groups)
  print('ROOT_SERIAL_CLOSED '+row['group']+' '+terminal['status'],flush=True)
  if result.returncode!=0 or terminal['status']!='PASS':break
 # No supervisor/runner/fixture remains. A later group has never had a writer
 # port into earlier HERE rooms; the final pairs cover their ENTIRE outputs.
 whole_first={str(root):census(root)for root in new_roots};whole_second={str(root):census(root)for root in new_roots};assert whole_first==whole_second
 put('all-complete-own-output-first.json',whole_first);put('all-complete-own-output-second.json',whole_second)
 after_first=helper['current']();after_second=helper['current']();assert after_first==after_second==expected
 put('global-after-first.json',after_first);put('global-after-second.json',after_second)
 all_passed=len(groups)==4 and all(g['supervisorReturnCode']==0 and g['originalTerminal']['status']=='PASS'for g in groups)
 terminal=dict(status='ROOT_SERIAL_FOUR_GROUPS_COMPLETED'if all_passed else'ROOT_SERIAL_STOPPED_ON_ORIGINAL_GROUP_FAILURE',groups=groups,unrunGroups=[r['group']for r,_h,_p in plans[len(groups):]],allOldOriginalBodiesUnchanged=True,oldRootCount=len(expected),globalCensuses=3,wholeOwnOutputCensusesEqual=True,newOriginalRoots=list(map(str,new_roots))+[str(out)],allExecutedOwnedProcessesAbsent=True,featureQualified=False,nativeQualified=False,wholeQualified=False)
 put('terminal.json',terminal);put('freeze.json',dict(files={p.name:dict(sha256=sha(p))for p in sorted(out.iterdir())if p.is_file()}))
 print(json.dumps(dict(status=terminal['status'],freeze=sha(out/'freeze.json'),executedGroups=len(groups))),flush=True)
 return 0 if all_passed else 1
if __name__=='__main__':raise SystemExit(main())
