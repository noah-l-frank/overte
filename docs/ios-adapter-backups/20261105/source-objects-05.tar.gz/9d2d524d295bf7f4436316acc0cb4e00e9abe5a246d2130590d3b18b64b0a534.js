"use strict";
(function () {
    var metadata=Script.require("./script-bundle/companion.js");
    var inline=Script.require("./companion.js")+Script.require("./script-bundle/main.js");
    var tablet=Tablet.getTablet("com.highfidelity.interface.tablet.system"), stopped=false;
    var buttons={};
    function respond(message, surface, send) {
        var packet;
        if (typeof message !== "string" || message.length > 4096) return;
        try { packet = JSON.parse(message); } catch (_) { return; }
        if (!packet || packet.contract !== "overte-web-parity-v1" || packet.action !== "echo" ||
                typeof packet.sequence !== "number" || !isFinite(packet.sequence) ||
                packet.sequence < 1 || packet.sequence > 1000000 || Math.floor(packet.sequence) !== packet.sequence) return;
        send(JSON.stringify({contract: packet.contract, action: "echo", sequence: packet.sequence, surface: surface}));
    }

    function tabletEvent(message) {
        if (!stopped) respond(message,"tablet",function (reply) { tablet.emitScriptEvent(reply); });
    }
    function open() { if (!stopped) tablet.gotoWebScreen("http://127.0.0.1:18000/feature-fixture/v1/runs/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/tickets/bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb/index.html"); }
    function openInline() { if (!stopped) tablet.gotoWebScreen(inline); }
    function returnToReference() { if (!stopped) tablet.gotoWebScreen("http://127.0.0.1:18000/feature-fixture/v1/runs/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/tickets/bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb/reference.html"); }
    var handlers={open:open,inline:openInline,return:returnToReference};
    Object.keys(handlers).forEach(function (key) {
        buttons[key]=tablet.addButton({text:{"inline": "WEB INLINE", "open": "WEB TEST", "return": "WEB RETURN"}[key],semanticId:"tablet-web-app."+"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"+"."+"88acad3add29b708047610643f130798"+"."+key,fixtureUrl:"http://127.0.0.1:18000/feature-fixture/v1/runs/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/",sortOrder:200});
        buttons[key].clicked.connect(handlers[key]);
    });
    tablet.webEventReceived.connect(tabletEvent);
    Script.scriptEnding.connect(function () {
        stopped=true;
        tablet.webEventReceived.disconnect(tabletEvent);
        Object.keys(buttons).forEach(function (key) {
            buttons[key].clicked.disconnect(handlers[key]);tablet.removeButton(buttons[key]);
        });
        // The owning normal UI flow closes its actually owned page first.
        // Ending this Script never navigates or closes an unrelated page.
    });
}());
