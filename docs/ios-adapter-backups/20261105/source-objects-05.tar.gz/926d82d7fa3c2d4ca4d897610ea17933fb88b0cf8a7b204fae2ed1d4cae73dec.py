"""Root-only ONE own Fresh16 method; exact file overlay, no guard replacement."""
import hashlib,importlib.abc,importlib.util,json,os,sys,tempfile,threading,unittest
from contextlib import ExitStack
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from guard import sources,first_pass,sha
from root_stage_guard import baseline,terminal
sys.dont_write_bytecode=True
HERE=Path(os.environ['LIFECYCLE_WHOLE_STAGE']).resolve();PREP=HERE.parent
plan=json.loads((PREP/'plan.json').read_text());REPO=Path(plan['repositoryRoot']);assert Path.cwd()==REPO
sources(HERE);first_pass(HERE)
for key,row in json.loads((PREP/'maps.json').read_text()).items():
    path=Path(row['path']);assert sha(path)==row['sha256'];os.environ[key]=str(path);os.environ[key+'_SHA256']=row['sha256']
for name in ('bindings','retained','cleanup'):(HERE/name).mkdir(mode=0o700,exist_ok=False)
os.environ['LIFECYCLE_CODE_BINDINGS_ROOT']=str(HERE/'bindings')
forbidden=('pymobiledevice3','pmd_pytcp','pmd_net_addr','tidevice','pyidevice','zeroconf')
def sdk_free():assert not [name for name in sys.modules if name.split('.')[0]in forbidden],'SDK imported'
def audit(event,args):
    if event=='import'and args[0].split('.')[0]in forbidden:raise RuntimeError('Installed/vendor SDK import prohibited')
    if event=='open'and isinstance(args[0],(str,bytes,os.PathLike)):
        value=os.fsdecode(args[0])
        if '/overte-ios-remotexpc/'in value or any('/'+name+'/'in value for name in forbidden):raise RuntimeError('Installed SDK path prohibited')
    if event=='subprocess.Popen':raise RuntimeError('Fresh16 own3 permits ZERO subprocesses/Node/SDK/device')
    if event in ('socket.connect','socket.bind'):
        value=args[1]
        if not isinstance(value,tuple)or value[0]not in ('127.0.0.1','::1','localhost'):raise RuntimeError('Only owned loopback socket fixtures allowed')
sdk_free();sys.addaudithook(audit) # Before target imports or host-model birth.
initial=baseline()
class Overlay(importlib.abc.MetaPathFinder):
    def __init__(self):self.rows={row['module']:row for row in plan['overlays']}
    def find_spec(self,fullname,path=None,target=None):
        row=self.rows.get(fullname)
        if row is None:return None
        source=Path(row['path']);assert sha(source)==row['sha256']
        # Execute the exact complete reviewed file. No parent/native guard,
        # function or AST is replaced by this source-selection mechanism.
        return importlib.util.spec_from_file_location(fullname,source)
sys.meta_path.insert(0,Overlay())
roots=[str(PREP/'models'),str(PREP/'support'),*[str(REPO/rel)for rel in ('tests/device','tests/device/self_tests','tests/device/ios/self_tests')]]
rest=[entry for entry in sys.path if entry and not Path(entry).resolve().is_relative_to(REPO)]
sys.path[:]=roots+rest
# Genuine original TemporaryDirectory objects are retained by the repository's
# already reviewed retained_host_roots hook; actual case cleanup still runs.
from ios.self_tests.retained_host_roots import retain_owned_root
real_td=tempfile.TemporaryDirectory;owned=[];objects=[]
def temporary(suffix=None,prefix=None,dir=None,*,ignore_cleanup_errors=False,delete=True):
    assert dir is None or Path(dir)==HERE/'retained'
    actual=real_td(suffix=suffix,prefix=prefix,dir=HERE/'retained',ignore_cleanup_errors=ignore_cleanup_errors,delete=delete)
    root=Path(actual.name);assert root.parent==HERE/'retained'and root.is_dir()and root.stat().st_mode&0o077==0
    retain_owned_root(actual,expected_root=root);owned.append(str(root));objects.append(actual)
    (HERE/'created-original-roots.json').write_text(json.dumps(owned)+'\n');return actual
selection=json.loads((HERE/'case.json').read_text());case_id=selection['case']
module_name,class_name,method=case_id.rsplit('.',2)
module=__import__(module_name,fromlist=[class_name]);kind=getattr(module,class_name)
assert method in kind.__dict__ and method.startswith('test_'),'Only explicitly authored OWN method allowed'
loader=unittest.TestLoader();suite=loader.loadTestsFromName(case_id);assert suite.countTestCases()==1
result=None;returned=False
try:
    with ExitStack()as stack:
        from importlib import import_module
        for name in plan['retainedTemporaryDirectoryAliases']:
            stack.enter_context(patch.object(import_module(name),'tempfile',SimpleNamespace(TemporaryDirectory=temporary)))
        result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite);returned=True
finally:
    # Standard TestSuite.run has returned only after real IsolatedAsyncio
    # teardown, cleanups and Runner.close. Never weaken these actual censuses.
    terminal(HERE/'cleanup',initial,owned);sdk_free();sources(HERE)
    receipt=dict(case=case_id,actualStandardCaseRunReturned=returned,twoCensusesPassed=True,retainedRoots=owned,
        noSDK=True,noSubprocess=True,wholeFeatureQualified=False)
    (HERE/'cleanup/receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    assert len(owned)==3,'Expected three genuine inherited fixture temp roots'
if result is None:raise RuntimeError('Standard test result unavailable')
value=dict(selectedIds=[case_id],testsRun=result.testsRun,successful=result.wasSuccessful()and result.testsRun==1 and not result.skipped,
    failureCount=len(result.failures),errorCount=len(result.errors),skippedCount=len(result.skipped),wholeFeatureQualified=False,nativeQualified=False)
(HERE/'selected-result.json').write_text(json.dumps(value,indent=2)+'\n')
raise SystemExit(0 if value['successful']else 1)
