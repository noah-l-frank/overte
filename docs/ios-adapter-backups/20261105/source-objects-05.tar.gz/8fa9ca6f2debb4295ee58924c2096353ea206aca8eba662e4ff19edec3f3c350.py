"""UNRUN: unchanged files are not cached semantic-validator authority.

Actual existing host producer/archive constructors; native microphone/phase
boundaries remain the original explicit models. No production cache is supplied.
"""
from copy import deepcopy
import sys,unittest
from adapters.normal_ui import NativeUIError
from adapters.original_file_reads import collect
from adapters.original_frame_store import OriginalFrameStore
from ios.adapters import audio_passive_owner as passive
from ios.adapters.audio_passive_owner import IOSAudioPassiveOwner
from ios.adapters.emote_original_lease import EmoteOriginalLease
from ios.self_tests.test_ios_audio_passive_owner import AudioPassiveOwnerTests,m_fixture_url
from ios.self_tests.test_ios_audio_recorded_owner import BINDING,RUN


def refusing_phase_code(*args,**keywords):
    raise ValueError('Actual current phase-validator code executed')


class RetiredFamilyLiteralValidationFrontierTests(unittest.TestCase):
    def setUp(self):
        self.f=AudioPassiveOwnerTests();self.f.setUp();self.addCleanup(self.f.doCleanups)
        self.f.begin()
        with self.f.owner()as owner:owner.capture();owner.retire()
        self.f.boundary.block=True
        self.commands=deepcopy(self.f.boundary.commands)
        self.phase=passive.phase_packet;self.code=self.phase.__code__
        self.keywords=self.phase.__kwdefaults__;self.previous=self.keywords['previous']
        self.assertIsNone(self.previous)
        self.alias_fault=None
        self.addCleanup(self.restore_controls)
    def restore_controls(self):
        self.assertTrue(passive.phase_packet is self.phase or passive.phase_packet is self.alias_fault)
        passive.phase_packet=self.phase
        self.assertTrue(self.phase.__code__ is self.code or self.phase.__code__ is refusing_phase_code.__code__)
        self.phase.__code__=self.code
        self.assertIs(self.phase.__kwdefaults__,self.keywords)
        self.assertTrue(self.keywords['previous']is self.previous or self.keywords['previous']is False)
        self.keywords['previous']=self.previous
        self.assertEqual(self.commands,self.f.boundary.commands)
    def original(self):
        return IOSAudioPassiveOwner.archive(self.f.store,self.f.root,BINDING,RUN,'4'*32,
            self.f.f.lock,m_fixture_url(self.f.m))
    def test_each_literal_archive_reopens_real_originals_without_native_or_cross_call_verdict(self):
        with self.f.f.lock.held():
            lease=EmoteOriginalLease(self.f.root,[])
            expected={p for p in self.f.root.iterdir()if p.is_file()}
            with collect()as first_reads:first=self.original();self.assertTrue(first.retired()['retired'])
            with collect()as second_reads:second=self.original();self.assertTrue(second.retired()['retired'])
            self.assertIsNot(first,second);self.assertEqual(first.previous,second.previous)
            self.assertTrue(expected<=first_reads);self.assertTrue(expected<=second_reads);lease.guard()
    def test_same_original_files_cannot_authorize_a_changed_live_phase_alias(self):
        problem=NativeUIError('Actual held validator alias refusal');calls=[]
        def refused(*args,**keywords):calls.append(True);raise problem
        with self.f.f.lock.held():
            self.original();lease=EmoteOriginalLease(self.f.root,[])
            self.alias_fault=refused;passive.phase_packet=refused;lease.guard()
            with self.assertRaises(NativeUIError)as caught:self.original()
            self.assertIs(caught.exception,problem);self.assertTrue(calls);lease.guard()
    def test_same_function_code_mutation_is_not_hidden_by_an_unchanged_readset_lease(self):
        with self.f.f.lock.held():
            self.original();lease=EmoteOriginalLease(self.f.root,[])
            self.phase.__code__=refusing_phase_code.__code__;lease.guard()
            with self.assertRaisesRegex(ValueError,'Actual current phase-validator code executed'):self.original()
            lease.guard()
    def test_current_keyword_default_is_still_executed_with_the_same_original_files(self):
        with self.f.f.lock.held():
            self.original();lease=EmoteOriginalLease(self.f.root,[])
            self.keywords['previous']=False;lease.guard()
            with self.assertRaises(TypeError):self.original()
            lease.guard()
    def test_genuine_decode_c_return_mutator_requires_the_literal_archive_call(self):
        prior=sys.getprofile();self.assertIsNone(prior)
        read=OriginalFrameStore.read;code,namespace=read.__code__,read.__globals__
        problem=NativeUIError('Actual decode C_RETURN changed current phase alias');fired=[]
        def refused(*args,**keywords):raise problem
        self.alias_fault=refused
        def observer(frame,event,argument):
            if not fired and event=='c_return'and frame.f_code is code and frame.f_globals is namespace:
                if getattr(argument,'__name__',None)=='decode'and getattr(argument,'__self__',None)is frame.f_locals.get('raw'):
                    fired.append(True);passive.phase_packet=refused
        with self.f.f.lock.held():
            self.original();lease=EmoteOriginalLease(self.f.root,[])
            try:
                sys.setprofile(observer);self.assertIs(sys.getprofile(),observer)
                with self.assertRaises(NativeUIError)as caught:self.original()
                self.assertIs(caught.exception,problem);self.assertEqual([True],fired)
            finally:
                current=sys.getprofile()
                if current is observer:sys.setprofile(prior)
                else:self.assertIs(current,prior,'Unknown profiler was not overwritten')
                self.assertIs(sys.getprofile(),prior)
            lease.guard()
