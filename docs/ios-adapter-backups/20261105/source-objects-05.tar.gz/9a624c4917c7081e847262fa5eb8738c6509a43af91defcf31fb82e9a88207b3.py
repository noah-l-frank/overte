"""Fresh original Audio11 cuts, independent from the normal input owner.

Each reader retains its actual query, reply bytes and immutable frame. Current
facts are recomputed from that frame; no previous observation is retimed.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from types import SimpleNamespace
from adapters.native_clock_join import NativeClockAcquisition,validate_join
from adapters.native_clock_source_history import restore
from adapters.native_feature_observation import decode,exact,need,validate as native_validate
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.recorded_preview_history import measured_state
from adapters.script_feature.history import same,pack,unpack
from feature_journeys.contract import state as public_state
from feature_journeys.phase_fixture import PhaseFixtureReader,validate as phase_validate
from ios.adapters.assets_file_sources import FileSources
from ios.adapters.audio_api_clock import operation
from ios.adapters.audio_page_inputs import AudioPageInputs
from ios.adapters.audio_recorded_owner import IOSAudioRecordedOwner
from ios.adapters.normal_input import observation as ui_validate
from ios.adapters import audio_session_source as session_source,audio_settings_source as settings_source
from ios.adapters.graphics_history import follow_native

from ios.adapters.audio_whole_journal import AudioWholeJournal as WholeRawSources

class AudioWholeSources:
    def __init__(self,store,root,binding,run,role,lock,*,source,client,epoch_ms,monotonic):
        need(role in ('primary','actor'));lock.assert_held()
        self.store,self.root,self.binding,self.run,self.role,self.lock=store,root,deepcopy(context(binding)),run,role,lock
        self.epoch_ms,self.monotonic=epoch_ms,monotonic
        self.source=None;self.historical=True;self.native=SimpleNamespace(monotonic=monotonic)
        self.phase=PhaseFixtureReader(client,run,'audio',epoch_ms=epoch_ms,monotonic=monotonic)
        self.previous=store.read();self.state=dict(records=[],pending=None,interrupted=[],rawSources=None)
        self.raws=WholeRawSources(self,role,self.bound,self.save)
        self.frames=OriginalFrameStore(root,binding,run,role,self.bound,self.intent,namespace='ios-audio11-current',schema_prefix='iosAudio11Current',monotonic=monotonic)
        if self.previous is not None:self.state=self.decode(self.previous)
        if source is not None:self.attach(source)

    def attach(self,source):
        need(self.historical and self.source is None and self.raws.pending is None)
        self.source=source;self.historical=False;self.native=source['clock_source']
        need(same(source['binding'],self.binding));self.readers=dict(clock=self.native,settings=source['observer'].audio_settings(clock_source=self.native),session=source['observer'].audio_session(clock_source=self.native))
        if self.state['records']:
            last=self.original(self.state['records'][-1]);restore(self.native,last['clockJoin']['nativeAfter'])
            # Each API factory has independent current readers. The global
            # original stream below, not a reused reader result, checks their
            # identities/cursors across a legitimate background phase.

    def bound(self):
        self.lock.assert_held();need(same(self.store.read(),self.previous))
        if not self.historical:need(self.source['check']() is not False)
        return True

    def envelope(self):
        return dict(iosAudio11CurrentVersion=1,binding=self.binding,runId=self.run,role=self.role,artifactRoot=str(self.root),
                    payload=pack([dict(self.state,rawSources=self.raws.manifest())]))

    def save(self):
        need(not self.historical);self.bound();value=self.envelope();self.store.write(value,self.previous)
        need(same(self.store.read(),value));self.previous=deepcopy(value)

    def intent(self,event,wire):
        need(event=='original' and self.state['pending'] is not None)
        self.state['pending']['wire']=deepcopy(wire);self.save();return True

    def query(self,kind,query):
        need(kind in ('clock','ui','settings','session'))
        if kind in ('clock','ui'):IOSAudioRecordedOwner.query(query)
        elif kind=='settings':settings_source.command(query)
        else:session_source.command(query)
        return dict(kind=kind,command=deepcopy(query))

    def decode(self,value):
        exact(value,{'iosAudio11CurrentVersion','binding','runId','role','artifactRoot','payload'})
        need(type(value['iosAudio11CurrentVersion']) is int and value['iosAudio11CurrentVersion']==1 and same(value['binding'],self.binding)
            and value['runId']==self.run and value['role']==self.role and value['artifactRoot']==str(self.root))
        rows=unpack(value['payload']);need(len(rows)==1);state=deepcopy(rows[0]);exact(state,{'records','pending','interrupted','rawSources'});self.raws.load(state['rawSources'])
        need(type(state['records']) is list and len(state['records'])<=512 and type(state['interrupted']) is list and len(state['interrupted'])<=16)
        previous=None;used=[]
        for i,ref in enumerate(state['records'],1):
            need(ref['index']==i);frame=self.frame(self.frames.read(self.frames.expand(ref)),previous);previous=frame;used.extend(frame['rawRefs'])
        for pending in state['interrupted']+([] if state['pending'] is None else [state['pending']]):
            exact(pending,{'phase','queries','rawRefs','wire'});used.extend(pending['rawRefs'])
            for row in pending['queries']:self.query(row['kind'],row['command'])
            for ref in pending['rawRefs']:self.raws.read_record(ref)
            if pending['wire'] is not None:
                wire=pending['wire'];self.frames.original(wire)
                if wire['phase']!='planned':self.frames.read(wire)
        unused=[ref for ref in self.raws.refs if ref not in used]
        need(state['pending'] is not None or not unused)
        for ref in unused:
            record=self.raws.read_record(ref)
            need(any(same(record['query'],r['command']) for r in state['pending']['queries']))
        need(len(used)==len({r['index'] for r in used}))
        return state

    def frame(self,value,previous=None):
        exact(value,{'iosAudio11CutVersion','phaseBefore','phaseAfter','queries','rawRefs','originals','clockJoin','uiReceipt'})
        need(type(value['iosAudio11CutVersion']) is int and value['iosAudio11CutVersion']==1)
        before,after=value['phaseBefore'],value['phaseAfter']
        for phase in (before,after):phase_validate(phase,run=self.run,area='audio',request=phase['requestId'],epoch=phase['capturedEpochMs'])
        phase_validate(after,run=self.run,area='audio',request=after['requestId'],epoch=after['capturedEpochMs'],previous=before)
        need(same(before['activations'],after['activations']) and before['active']==after['active'])
        raw=value['originals'];exact(raw,{'native','ui','settings','session','settingsClock','sessionClock'})
        join=validate_join(value['clockJoin'],raw);first,last=join['nativeBefore'],join['nativeAfter'];pid=int(self.binding['processIdentity'])
        native_validate(raw['native'],raw['native']['requestId'],pid,last['capturedEpochMs'],require_recorded_history=True)
        ui_validate(raw['ui'],pid,last['capturedEpochMs']);follow_native(first,raw['native']);follow_native(raw['native'],last)
        receipt=value['uiReceipt'];exact(receipt,{'schemaVersion','commandId','observation'})
        need(type(receipt['schemaVersion']) is int and receipt['schemaVersion']==1 and same(receipt['observation'],raw['ui']))
        queries=value['queries'];need(type(queries) is list and 1<=len(queries)<=32)
        ids=[r['command']['commandId'] for r in queries];need(len(ids)==len(set(ids)))
        ui_queries=[r for r in queries if r['kind']=='ui'];need(len(ui_queries)==1 and ui_queries[0]['command']['commandId']==receipt['commandId'])
        for kind,module in (('settings',settings_source),('session',session_source)):
            packet=raw[kind];module.validate(packet,dict(schemaVersion=1,action=module.ACTION,commandId=packet['requestId'],runId=self.run),pid,last['capturedEpochMs'])
            need(packet['instance']==first['instance']==last['instance'] and packet['lifecycle']==last['lifecycle'])
            need(raw[kind+'Clock']==dict(capturedEpochMs=packet['clockAfter']['epochMs'])
                and first['capturedEpochMs']<=packet['clockBefore']['epochMs']<=packet['clockAfter']['epochMs']<=last['capturedEpochMs'])
        records=[self.raws.read_record(ref) for ref in value['rawRefs']];clock_packets=[]
        for row in value['queries']:
            self.query(row['kind'],row['command'])
            if row['kind']=='ui':continue # NativeInput retains its exact returned receipt above.
            matches=[]
            for record in records:
                if not same(record['query'],row['command']):continue
                try:packet=decode(record['raw'],limit=262144)
                except ValueError:continue
                if packet.get('requestId')==row['command']['commandId']:matches.append(packet)
            need(matches and all(same(p,matches[0]) for p in matches))
            if row['kind']=='clock':
                native_validate(matches[0],row['command']['commandId'],pid,matches[0]['capturedEpochMs'],require_recorded_history=True)
                need(matches[0]['instance']==first['instance']);clock_packets.append(matches[0])
            else:need(same(matches[0],raw[row['kind']]))
        for a,b in zip(clock_packets,clock_packets[1:]):follow_native(a,b)
        need(clock_packets[0]==first and clock_packets[-1]==last)
        ids={row['command']['commandId'] for row in value['queries'] if row['kind']=='clock'}
        need({first['requestId'],raw['native']['requestId'],last['requestId']}<=ids)
        if previous is not None:
            follow_native(previous['clockJoin']['nativeAfter'],first)
            for kind in ('settings','session'):
                a,b=previous['originals'][kind],raw[kind]
                need(a['instance']==b['instance'] and b['sequence']>a['sequence'] and b['requestId']!=a['requestId']
                    and b['clockBefore']['epochMs']>=a['clockAfter']['epochMs'] and b['clockBefore']['monotonicMs']>=a['clockAfter']['monotonicMs'])
            need(join['hostBeforeMonotonic']>=previous['clockJoin']['hostAfterMonotonic'] and join['hostBeforeEpochMs']>=previous['clockJoin']['hostAfterEpochMs'])
        return value

    def original(self,ref):return self.frame(self.frames.read(self.frames.expand(ref)))

    def current_state(self,value):
        self.frame(value);actual=measured_state(value['originals']['native'])
        actual['open']=AudioPageInputs.route(value['originals']['ui'])=='audio'
        return public_state('audio',actual,self.run)

    @operation
    def capture(self):
        need(not self.historical and len(self.state['records'])<512);self.bound()
        if self.raws.pending is not None:
            self.raws.accept_capture();self.save()
        if self.state['pending'] is not None:
            assigned={r['index'] for r in self.state['pending']['rawRefs']}
            all_used={r['index'] for frame in self.state['records'] for r in self.original(frame)['rawRefs']}
            all_used.update(r['index'] for p in self.state['interrupted'] for r in p['rawRefs'])
            self.state['pending']['rawRefs'].extend(r for r in self.raws.refs if r['index'] not in assigned|all_used)
            self.save()
        if self.state['pending'] is not None:
            # A saved immutable frame can be recovered. A failed readonly
            # acquisition is retained, then a different fresh cut may begin.
            pending=self.state['pending'];wire=pending['wire']
            if wire is not None and wire['phase'] in ('opened','saved'):
                value=self.frame(self.frames.read(wire));ref=self.frames.compact(dict(wire,phase='saved'))
                self.state['records'].append(ref);self.state['pending']=None;self.save()
            else:
                need(len(self.state['interrupted'])<16);self.state['interrupted'].append(pending);self.state['pending']=None;self.save()
        phase=self.phase.status();self.state['pending']=dict(phase=phase,queries=[],rawRefs=[],wire=None);self.save();wrappers=[]
        for kind,reader in self.readers.items():
            send,original=reader.send,reader.original;wrappers.append((reader,send,original))
            def issued(query,kind=kind,send=send):
                need(len(self.state['pending']['queries'])<32);self.state['pending']['queries'].append(self.query(kind,query));self.save();return send(query)
            def body(kind=kind,original=original):
                raw=original()
                if raw:
                    query=next(r['command'] for r in reversed(self.state['pending']['queries']) if r['kind']==kind)
                    self.raws.capture(query,raw);self.raws.accept_capture();self.state['pending']['rawRefs'].append(deepcopy(self.raws.refs[-1]));self.save()
                return raw
            reader.send,reader.original=issued,body
        normal=self.source['native'];old_intent=getattr(normal,'observe_intent',None)
        def ui_intent(query):self.state['pending']['queries'].append(self.query('ui',query));self.save()
        normal.observe_intent=ui_intent
        try:
            from ios.adapters.audio_outer_original_acquisition import AudioOuterOriginalAcquisition,supported
            round_=AudioOuterOriginalAcquisition(self.source,self.readers,self.run,monotonic=self.monotonic)if supported(self.source,self.readers)else None
            acquisition=NativeClockAcquisition(self.native,epoch_ms=self.epoch_ms,monotonic=self.monotonic);acquisition.begin(self.epoch_ms())
            native=self.native.read(self.native.sequence,require_recorded_history=True)
            if round_ is not None:
                round_.bind_before(acquisition.started['nativeBefore'])
                ui=round_.ui_original();ui_receipt=deepcopy(normal.last_receipt)
                settings=round_.reader_original('settings');session=round_.reader_original('session')
            else:
                # Unsupported component producers retain the unchanged fully
                # independent readers; no DTO can activate the joined path.
                ui=normal.capture();ui_receipt=deepcopy(normal.last_receipt)
                settings=self.readers['settings'].read(self.run);session=self.readers['session'].read(self.run)
            raw=dict(native=native,ui=ui,settings=settings,session=session,settingsClock=dict(capturedEpochMs=settings['clockAfter']['epochMs']),sessionClock=dict(capturedEpochMs=session['clockAfter']['epochMs']))
            join=acquisition.finish(raw,[('native','capturedEpochMs'),('ui','sampleEpochMs'),('settingsClock','capturedEpochMs'),('sessionClock','capturedEpochMs')])
            if round_ is not None:need(same(round_.accept(join['nativeAfter']),ui))
            after=self.phase.status(phase)
            value=dict(iosAudio11CutVersion=1,phaseBefore=phase,phaseAfter=after,queries=deepcopy(self.state['pending']['queries']),rawRefs=deepcopy(self.state['pending']['rawRefs']),originals=raw,clockJoin=join,uiReceipt=ui_receipt)
            self.frame(value,self.original(self.state['records'][-1]) if self.state['records'] else None)
            ref=self.frames.write(len(self.state['records'])+1,value);self.state['records'].append(ref);self.state['pending']=None;self.save();return ref,value
        finally:
            normal.observe_intent=old_intent
            for reader,send,original in wrappers:reader.send,reader.original=send,original

    def owned_paths(self):
        paths={self.store.path}|self.raws.owned_paths()
        paths.update(self.frames.path(self.frames.expand(ref)) for ref in self.state['records'])
        for p in self.state['interrupted']+([] if self.state['pending'] is None else [self.state['pending']]):
            if p['wire'] is not None and p['wire']['phase']!='planned':paths.add(self.frames.path(p['wire']))
        return paths
