"""Closed source declarations and original host metadata; no target import."""
from pathlib import Path
import contextlib,hashlib,json,os,signal,stat,subprocess,sys,tempfile,threading,unittest
SOURCE=Path(__file__).resolve().parent
REPO=SOURCE.parent.parent
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def meta(s):return [getattr(s,k)for k in FIELDS]
def pin(p):
    p=Path(p);a=p.lstat();assert p.resolve(strict=True)==p and not p.is_symlink()and stat.S_ISREG(a.st_mode)
    fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
    try:
        assert meta(os.fstat(fd))==meta(a)
        with os.fdopen(fd,'rb',closefd=False)as stream:raw=stream.read()
        assert len(raw)==a.st_size and meta(os.fstat(fd))==meta(a)==meta(p.lstat())
    finally:os.close(fd)
    return dict(stat=meta(a),sha256=hashlib.sha256(raw).hexdigest())
def head():
    raw=(REPO/'.git').read_text();assert raw.startswith('gitdir: ')
    gd=Path(raw[8:].strip());gd=gd if gd.is_absolute()else REPO/gd
    gd=gd.resolve(strict=True);common=(gd/(gd/'commondir').read_text().strip()).resolve(strict=True)
    selected=(gd/'HEAD').read_text().strip();assert selected.startswith('ref: ')
    ref=selected[5:]
    for base in(gd,common):
        if(base/ref).is_file():return(base/ref).read_text().strip()
    for line in(common/'packed-refs').read_text().splitlines():
        if line and not line.startswith(('#','^')):
            value,name=line.split(' ',1)
            if name==ref:return value
    raise AssertionError('Actual own checkout HEAD unavailable')
def identity(pid):
    try:raw=Path('/proc',str(pid),'stat').read_text()
    except(FileNotFoundError,ProcessLookupError):return None
    v=raw[raw.rfind(')')+2:].split()
    return dict(pid=int(raw[:raw.index('(')].strip()),parent=int(v[1]),group=int(v[2]),session=int(v[3]),startTicks=int(v[19]))
def fds():
    out={}
    for p in Path('/proc/self/fd').iterdir():
        try:s=p.stat();out[p.name]=dict(target=os.readlink(p),device=s.st_dev,inode=s.st_ino,mode=s.st_mode)
        except(FileNotFoundError,ProcessLookupError):pass
    return out
def census(root):
    root=Path(root);out={}
    def visit(p):
        s=p.lstat();assert not p.is_symlink()
        if stat.S_ISDIR(s.st_mode):
            names=sorted(x.name for x in p.iterdir());row=dict(stat=meta(s),namespace=names)
            for name in names:visit(p/name)
            assert meta(p.lstat())==meta(s)
        else:assert stat.S_ISREG(s.st_mode)and s.st_nlink==1;row=pin(p)
        out[str(p.relative_to(root))]=row
    visit(root);return out
def admitted(expected_head,freeze_sha):
    assert sys.dont_write_bytecode and Path.cwd()==REPO and REPO.name=='overte-ios-feature-adapters-resume-20261026'
    assert sha(SOURCE/'source-freeze.json')==freeze_sha
    own=load(SOURCE/'source-freeze.json');decl=load(SOURCE/'source-declarations.json')
    assert expected_head==decl['expectedCurrentHead']==head()
    paths={SOURCE/'source-freeze.json'}
    for name,row in own['files'].items():assert sha(SOURCE/name)==row['sha256'];paths.add(SOURCE/name)
    original=Path(decl['source4Freeze']['path']);assert sha(original)==decl['source4Freeze']['sha256'];paths.add(original)
    for name,row in load(original)['files'].items():assert sha(original.parent/name)==row['sha256'];paths.add(original.parent/name)
    for row in decl['modules'].values():assert sha(row['path'])==row['sha256'];paths.add(Path(row['path']))
    paths.add(Path(sys.executable).resolve(strict=True))
    # Exact original standard cleanup/process/FD implementations, not another
    # project import frontier or any SDK definitions.
    for module in(contextlib,signal,subprocess,tempfile,threading,unittest.case,unittest.runner,unittest.result):
        p=Path(module.__file__).resolve(strict=True)
        assert p.is_relative_to(Path(os.__file__).resolve(strict=True).parent)
        paths.add(p)
    for path,row in decl['qualifiedControllerReferences'].items():assert sha(path)==row['sha256'];paths.add(Path(path))
    return decl,{str(p):pin(p)for p in sorted(paths)}
