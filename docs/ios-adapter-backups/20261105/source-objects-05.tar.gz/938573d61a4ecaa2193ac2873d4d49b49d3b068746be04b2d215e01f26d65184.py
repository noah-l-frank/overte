"""Unrun original-oracle comparisons on real imported modules and classes.

No ModuleType/spec/frame/context/owner is synthesized. No current guard
verdict, field value, method/code signature or archive proof is cached.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from contextvars import ContextVar
from copy import deepcopy
import inspect
import sys
from types import FunctionType
import unittest
from unittest.mock import patch
from ios.adapters import chat_archive_round as rounds
from ios.self_tests import chat_archive_order_subject as subject
from ios.self_tests import chat_archive_signature_oracle as literal


def original(namespace,*,class_cache=None):
    # Preserve the original function's exact source and real module globals.
    # Match explicitly substituted old control aliases in both algorithms.
    for name in('FunctionType','ModuleType','ContextVar','_MUTATORS','function','need','sorted',
            'isinstance','type','vars','id','str','int','float','bool','tuple','frozenset'):
        if name in vars(rounds):vars(literal)[name]=vars(rounds)[name]
        else:vars(literal).pop(name,None)
    return literal.module_signature(namespace,class_cache=class_cache)


class ChatOriginalOrderSchemaTests(unittest.TestCase):
    def setUp(self):
        self.namespace=vars(subject);rounds._compile_original_orders(self.namespace)
        self.expected=original(self.namespace)

    def equal(self):
        before=original(self.namespace);after=rounds._prototype_signature(self.namespace)
        self.assertEqual(before,after);self.assertEqual(before,rounds._live_signature(self.namespace));return after

    def test_real_module_and_inherited_static_class_methods_keep_original_order_and_receiver(self):
        self.assertEqual(self.expected,self.equal())
        class_cache={};left=rounds._prototype_signature(self.namespace,class_cache=class_cache)
        self.assertIs(class_cache[id(subject.Child)][0],subject.Child)
        self.assertEqual(left,original(self.namespace,class_cache={}))
        actual=subject.Child();self.assertEqual(rounds.function(actual.first),literal.function(actual.first))

    def test_fresh_function_code_identity_and_equal_code_object_rules_are_literal(self):
        old=subject.a_early.__code__
        try:
            subject.a_early.__code__=old.replace()
            self.assertEqual(self.expected,self.equal())  # original tuple uses code equality
            subject.a_early.__code__=subject.alternate.__code__
            self.assertNotEqual(self.expected,self.equal())
        finally:subject.a_early.__code__=old

    def test_add_remove_type_change_and_ignored_mutator_rules_remain_original(self):
        for name,value in(('NEW_UPPER',3),('new_lower',subject.alternate),('ignored',subject.alternate)):
            with self.subTest(name=name),patch.object(subject,name,value,create=True):self.equal()
        with patch.object(subject,'CONSTANT',True):
            self.assertEqual(self.expected,self.equal())  # bool/int equality is not strengthened
        with patch.object(subject.Parent,'save',subject.alternate):self.assertEqual(self.expected,self.equal())
        function=subject.z_late
        try:
            del subject.z_late;self.assertNotEqual(self.expected,self.equal())
        finally:subject.z_late=function
        # Reinserted key order remains literal even when the original hint misses.
        self.assertEqual(self.expected,self.equal())

    def test_fresh_mro_static_class_method_and_alias_mutations_are_not_a_cached_verdict(self):
        for method,value in(('static',staticmethod(subject.alternate)),('bound',classmethod(subject.alternate)),('first',subject.alternate)):
            with self.subTest(method=method),patch.object(subject.Parent,method,value):self.assertNotEqual(self.expected,self.equal())
        bases=subject.Child.__bases__
        try:
            subject.Child.__bases__=(subject.Other,);self.assertNotEqual(self.expected,self.equal())
        finally:subject.Child.__bases__=bases
        with patch.object(subject,'Alias',subject.Other):self.assertNotEqual(self.expected,self.equal())
        self.assertEqual(self.expected,self.equal())

    def test_context_module_primitives_and_shared_cyclic_ignored_values_are_fresh(self):
        with patch.object(subject,'CONTEXT',ContextVar('actual-other',default=None)):
            self.assertNotEqual(self.expected,self.equal())
        with patch.object(subject,'MODULE',inspect):self.assertNotEqual(self.expected,self.equal())
        cycle=[];cycle.append(cycle)
        with patch.object(subject,'ignored',cycle):self.assertEqual(self.expected,self.equal())
        with patch.object(subject,'CYCLIC_TUPLE',(cycle,),create=True):self.equal()
        with patch.object(subject,'PRIMITIVE',('changed',)):self.assertNotEqual(self.expected,self.equal())

    def test_str_subclass_key_isupper_and_sort_callbacks_are_not_skipped(self):
        calls=[]
        class Key(str):
            def __lt__(self,other):calls.append('lt');return super().__lt__(other)
            def isupper(self):calls.append('upper');return super().isupper()
        key=Key('odd_key');self.namespace[key]=object()
        try:
            calls.clear();left=original(self.namespace);before=tuple(calls)
            calls.clear();right=rounds._prototype_signature(self.namespace);after=tuple(calls)
            self.assertEqual(left,right);self.assertEqual(before,after);self.assertIn('upper',before)
        finally:del self.namespace[key]

    def test_custom_metaclass_namespace_access_and_classifier_masquerade_stay_literal(self):
        seen=[]
        class Meta(type):
            def __getattribute__(self,name):
                if name in('__mro__','__dict__'):seen.append(name)
                return super().__getattribute__(name)
        class Actual(metaclass=Meta):
            def actual(self):return None
        class Masquerade:
            @property
            def __class__(self):return FunctionType
        with patch.object(subject,'Actual',Actual,create=True),patch.object(subject,'masquerade',Masquerade(),create=True):
            seen.clear();left=original(self.namespace);before=tuple(seen)
            seen.clear();right=rounds._prototype_signature(self.namespace);after=tuple(seen)
            self.assertEqual(left,right);self.assertEqual(before,after)

    def test_actual_sorted_alias_receives_the_same_old_items_protocol(self):
        seen=[];builtin=sorted
        def actual(values):seen.append(type(values).__name__);return builtin(values)
        with patch.object(rounds,'sorted',actual,create=True):
            seen.clear();left=original(self.namespace);before=tuple(seen)
            seen.clear();right=rounds._prototype_signature(self.namespace);after=tuple(seen)
            self.assertEqual(left,right);self.assertEqual(before,after);self.assertIn('dict_items',after)

    def test_existing_classifier_alias_changes_are_not_replaced_by_a_new_fast_classifier(self):
        for name,value in(('type',subject.Other),('FunctionType',subject.Parent),('str',subject.Other),('dict',subject.Other)):
            with self.subTest(alias=name),patch.object(rounds,name,value,create=True):self.equal()

    def test_code_audit_callback_uses_the_complete_pre_callback_value_snapshot(self):
        active={'armed':False,'seen':0};old=subject.z_late
        def audit(event,args):
            if active['armed']and event=='object.__getattr__'and len(args)==2 and args[0]is subject.a_early and args[1]=='__code__':
                active['armed']=False;active['seen']+=1;subject.z_late=subject.alternate
        sys.addaudithook(audit)
        try:
            active.update(armed=True,seen=0);left=original(self.namespace);self.assertEqual(1,active['seen'])
            subject.z_late=old;active.update(armed=True,seen=0);right=rounds._prototype_signature(self.namespace)
            self.assertEqual(1,active['seen']);self.assertEqual(left,right)
            self.assertEqual(old,[row[1][0]for row in right if row[0]=='z_late'][0])
        finally:active['armed']=False;subject.z_late=old

    def test_corrupted_order_hint_falls_back_without_changing_current_authority(self):
        cells=inspect.getclosurevars(rounds._ordered_items).nonlocals;plans=cells['plans'];key=id(self.namespace)
        prior=plans[key]
        try:
            for order in((0,)*len(prior[1]),tuple(reversed(prior[2])),(False,)*len(prior[1])):
                plans[key]=(prior[0],prior[1],order);self.assertEqual(self.expected,self.equal())
        finally:plans[key]=prior

    def test_real_local_sorted_c_return_mutator_requires_live_literal_fallback(self):
        self.assertIsNone(sys.gettrace(),'The actual counter must be untraced')
        self.assertIsNone(sys.getprofile(),'The actual counter must be unprofiled')
        monitoring=sys.monitoring;event=monitoring.events.C_RETURN;call=monitoring.events.CALL
        functions=(literal.module_signature,rounds._live_signature,rounds._prototype_signature)
        codes=tuple(fn.__code__ for fn in functions)
        selected=None
        for tool in(5,4,3,2,1):
            if monitoring.get_tool(tool)is None and monitoring.get_events(tool)==0 and all(monitoring.get_local_events(tool,code)==0 for code in codes):
                selected=tool;break
        self.assertIsNotNone(selected,'A genuinely unused monitoring slot is required')
        # Capture ALL actual prior callback receivers through their genuine
        # exchange ports. get_tool(None) alone does not invent their absence.
        events=tuple(sorted({value for value in vars(monitoring.events).values()
            if type(value)is int and value>0 and value&(value-1)==0}))
        prior={};acquired=False;pending=None;state=dict(armed=False,returns=0,portPending=False)
        late=subject.z_late;builtin_sorted=sorted
        def on_return(code,offset,callee,arg0):
            if code in codes and callee is builtin_sorted and state['armed']:
                state['armed']=False;state['returns']+=1;subject.z_late=subject.alternate
        try:
            pending='use_tool_id';monitoring.use_tool_id(selected,'chat-real-sorted-return-counter');acquired=True;pending=None
            for item in events:
                pending=('callback',item);prior[item]=monitoring.register_callback(selected,item,None);pending=None
            pending=('callback-install',event);monitoring.register_callback(selected,event,on_return);pending=None
            for code in codes:
                pending=('local',code);monitoring.set_local_events(selected,code,call);pending=None
            outcomes=[]
            for fn in functions:
                subject.z_late=late;state.update(armed=True,returns=0)
                first=fn(self.namespace)==self.expected
                second=fn(self.namespace)==self.expected
                outcomes.append((first,second,state['returns']))
            self.assertEqual((True,False,1),outcomes[0])
            self.assertEqual(outcomes[0],outcomes[1])
            # The ungated experiment is kept explicitly as the counterexample,
            # never selected by original_methods or qml_authority.
            self.assertEqual((True,True,0),outcomes[2])

            # Concrete remaining limit of read-only LIVE mask queries: a
            # genuine global C_RETURN observer can silence itself when a NEW
            # get_events(0) query occurs, before its own slot is inspected.
            # The original collector has no such query. This counter is an
            # expected blocker, not an optimization-semantic PASS.
            for code in codes:
                pending=('clear-local',code);monitoring.set_local_events(selected,code,0);pending=None
            allowed_code=rounds._live_sort_allowed.__code__;getevents=monitoring.get_events
            def self_silencing_return(code,offset,callee,arg0):
                if code is allowed_code and callee is getevents and arg0==0 and state['armed']:
                    state['portPending']=True;monitoring.set_events(selected,0);state['portPending']=False
                elif code in codes and callee is builtin_sorted and state['armed']:
                    state['armed']=False;state['returns']+=1;subject.z_late=subject.alternate
            pending='replace-callback';monitoring.register_callback(selected,event,self_silencing_return);pending=None
            control_outcomes=[]
            for fn in functions[:2]:
                subject.z_late=late;state.update(armed=True,returns=0)
                pending='global-call';monitoring.set_events(selected,call);pending=None
                first=fn(self.namespace)==self.expected;second=fn(self.namespace)==self.expected
                control_outcomes.append((first,second,state['returns']))
                pending='clear-global';monitoring.set_events(selected,0);pending=None
            self.assertEqual((True,False,1),control_outcomes[0])
            self.assertEqual((True,True,0),control_outcomes[1])
        finally:
            state['armed']=False;subject.z_late=late
            # An unreturned mutating C port has unknown outcome; do not invent
            # acquisition/old callbacks or silently free an unproved slot.
            if pending is not None or state['portPending']:raise RuntimeError('Monitoring counter port outcome unknown; no restoration qualification')
            if acquired:
                pending='restore-global';monitoring.set_events(selected,0);pending=None
                for code in codes:
                    pending=('restore-local',code);monitoring.set_local_events(selected,code,0);pending=None
                for item,callback in prior.items():
                    pending=('restore-callback',item);monitoring.register_callback(selected,item,callback);pending=None
                pending='free_tool_id';monitoring.free_tool_id(selected);pending=None
                # CPython3.14 free clears registrations. Restore any ACTUALLY
                # captured preexisting unowned callback through the real port.
                for item,callback in prior.items():
                    if callback is not None:
                        pending=('restore-unowned-callback',item)
                        replaced=monitoring.register_callback(selected,item,callback);pending=None
                        self.assertIsNone(replaced)
                self.assertIsNone(monitoring.get_tool(selected));self.assertEqual(0,monitoring.get_events(selected))
                for code in codes:self.assertEqual(0,monitoring.get_local_events(selected,code))
