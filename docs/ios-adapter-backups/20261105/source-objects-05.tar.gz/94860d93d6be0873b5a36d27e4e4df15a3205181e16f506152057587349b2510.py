"""Selected Avatar host boundary, using the unchanged E458 mutation ports.

No native or product observation is supplied by this controller. Every helper
belongs to its actual writer thread and is closed in that same original thread.
"""
from pathlib import Path
from types import FrameType,MethodType,ModuleType
import hashlib,http.client,os,socket,socketserver,ssl,stat,subprocess,sys,threading
from assets_fixture_ports import FixturePorts
from owned_write_boundary import OwnedWrites,WriteRefusal
from prefix_common import proc


class AvatarPorts(FixturePorts):
    def __init__(self,*args,openssl_pin,**kwargs):
        self.base_seals=tuple((name,function,function.__code__,function.__globals__)
            for name,function in FixturePorts.__dict__.items()if hasattr(function,'__code__'))
        self.constructor_profiles=[];self.births=[];self.actor=None;self.actor_work=None
        self.make_server=None;self.server_class=None;self.listener_rows=[];self.retired=[]
        self.openssl_pin=openssl_pin;self.model_files=[];self.lock_type=None;self.lock_held=None
        self.lifecycle_seals=[];self.server_bind=socketserver.TCPServer.server_bind
        self.https_type=http.client.HTTPSConnection;self.https_connect=self.https_type.connect
        self.https_code=self.https_connect.__code__;self.https_globals=self.https_connect.__globals__
        self.tls_client=None;self.tls_server=None;self.ipv6_attempts=[]
        self.server_bind_code=self.server_bind.__code__;self.server_bind_globals=self.server_bind.__globals__
        super().__init__(*args,**kwargs)

    def check(self):
        super().check()
        for name,function,code,namespace in self.base_seals:
            if FixturePorts.__dict__.get(name)is not function or function.__code__ is not code or function.__globals__ is not namespace:
                raise WriteRefusal('Original reviewed base boundary changed')
        for owner,name,function,code,namespace in self.lifecycle_seals:
            value=owner.__dict__.get(name)
            if type(value)is classmethod:value=value.__func__
            if value is not function or function.__code__ is not code or function.__globals__ is not namespace:
                raise WriteRefusal('Actual original source function/class binding changed')
        if (socketserver.TCPServer.server_bind is not self.server_bind or self.server_bind.__code__ is not self.server_bind_code
                or self.server_bind.__globals__ is not self.server_bind_globals):raise WriteRefusal('Listener constructor changed')
        if (http.client.HTTPSConnection is not self.https_type or self.https_type.connect is not self.https_connect
                or self.https_connect.__code__ is not self.https_code or self.https_connect.__globals__ is not self.https_globals):raise WriteRefusal('Original HTTPS receiver changed')

    def seal(self,owner,name):
        function=owner.__dict__[name]
        if type(function)is classmethod:function=function.__func__
        row=(owner,name,function,function.__code__,function.__globals__)
        if not any(old[0]is owner and old[1]==name for old in self.lifecycle_seals):self.lifecycle_seals.append(row)
        return function

    def bind_module(self,name,module):
        self.check()
        expected=self.namespace['plan']['modules'].get(name)
        if (type(module)is not ModuleType or sys.modules.get(name)is not module or module.__name__!=name
                or expected is None or Path(module.__file__).resolve(strict=True)!=Path(expected['path'])):
            raise WriteRefusal('Lifecycle binding outside exact closed original module loader')
        if name=='feature_journeys.server':
            self.server_class=module.FixtureServer;self.make_server=self.seal(module,'make_server')
            return (self.make_server,)
        if name=='ios.self_tests.avatar_installed_full15_fixture':
            self.actor=module.OriginalAvatarActor;self.actor_work=self.seal(self.actor,'work')
            self.seal(self.actor,'close');return(self.actor_work,)
        if name in('ios.self_tests.avatar_people_node','ios.self_tests.avatar_app_node'):
            selected=module.PeopleNode if name.endswith('avatar_people_node')else module.AvatarAppNode
            constructor=self.seal(selected,'__init__');self.seal(selected,'close')
            program=module.PROGRAM
            tail=[str(Path(self.namespace['REPO'])/'scripts'),str(Path(self.namespace['REPO'])/'interface/resources/qml/hifi/Pal.qml')]if name.endswith('avatar_people_node')else[str(Path(self.namespace['REPO'])/'scripts/system/avatarapp.js')]
            self.constructor_profiles.append((selected,constructor,program,tuple(['node','-e',program,*tail]),1 if name.endswith('avatar_people_node')else 2,module))
        if name=='self_tests.test_account_provider':
            self.tls_class=module.AccountProviderTests;self.tls_setup=self.seal(self.tls_class,'setUpClass')
            return(self.tls_setup,)
        if name=='adapters.script_feature.lock':
            self.lock_type=module.ScriptSourceLock;wrapper=self.seal(self.lock_type,'held')
            self.lock_held=wrapper.__wrapped__;self.lock_body=(self.lock_held,self.lock_held.__code__,self.lock_held.__globals__)
        if name=='ios.self_tests.avatar_canonical_frontdoor_fixture':
            self.frontdoor=module.AvatarCanonicalFrontdoor;self.frontdoor_init=self.seal(self.frontdoor,'__init__')
        if name=='ios.adapters.installed_adapter':
            # A real public function, not a substitute installation receipt.
            return(self.seal(module,'create_physical_adapter'),)
        return()

    def listener_returned(self,frame,server):
        self.check()
        if (type(frame)is not FrameType or frame.f_code is not self.make_server.__code__
                or frame.f_globals is not self.make_server.__globals__ or type(server)is not self.server_class
                or threading.current_thread()is not self.main or self.listener_rows):raise WriteRefusal('Exact original single listener return required')
        if self.tls_server is None or server.tls_context is not self.tls_server:raise WriteRefusal('Listener lacks original freshly owned TLS context')
        identity=self.socket_snapshot(server.socket)
        if identity[4][0]!='127.0.0.1' or not 0<identity[4][1]<65536:raise WriteRefusal('Actual original bound loopback endpoint required')
        self.listener_rows.append((server,server.socket,identity))

    def tls_returned(self,frame):
        self.check()
        if frame.f_locals.get('cls')is not self.tls_class or self.tls_client is not None:raise WriteRefusal('TLS setup receiver/birth changed')
        client,server=self.tls_class.client_context,self.tls_class.server_context
        if type(client)is not ssl.SSLContext or type(server)is not ssl.SSLContext or client.verify_mode!=ssl.CERT_REQUIRED or not client.check_hostname:
            raise WriteRefusal('Actual original verifying client/server TLS contexts required')
        self.tls_client,self.tls_server=client,server

    def https_caller(self):
        self.check();frame=sys._getframe(1)
        while frame is not None:
            if frame.f_code is self.https_code and frame.f_globals is self.https_globals:
                owner=frame.f_locals.get('self');unused,address=self.listener_guard()
                if (type(owner)is not self.https_type or owner.host!='localhost'or owner.port!=address[1]
                        or owner._context is not self.tls_client or self.tls_class.client_context is not self.tls_client
                        or self.tls_client.verify_mode!=ssl.CERT_REQUIRED or not self.tls_client.check_hostname):raise WriteRefusal('Original HTTPS host/port/TLS receiver changed')
                return address
            frame=frame.f_back
        raise WriteRefusal('Network outside genuine original HTTPS connection frame')

    def listener_guard(self):
        self.check()
        if len(self.listener_rows)!=1:raise WriteRefusal('Unknown listening endpoint')
        server,sock,identity=self.listener_rows[0]
        if server.socket is not sock or self.socket_snapshot(sock)!=identity:raise WriteRefusal('Listener socket/FD/inode changed')
        return server,identity[4]

    def network(self,event,args,caller):
        if event=='socket.__new__':
            if args[1]not in(socket.AF_INET,socket.AF_INET6)or args[2]!=socket.SOCK_STREAM or args[3]not in(0,socket.IPPROTO_TCP):raise WriteRefusal('Unselected socket family/type/protocol')
            if args[1]==socket.AF_INET6:self.https_caller()
        elif event=='socket.bind':
            self.check();sock,address=args
            if (self.listener_rows or type(sock)is not self.socket_type or address!=('127.0.0.1',0)
                    or caller.f_code is not self.server_bind_code or caller.f_globals is not self.server_bind_globals
                    or type(caller.f_locals.get('self'))is not self.server_class or caller.f_locals['self'].socket is not sock):
                raise WriteRefusal('Only actual FixtureServer ephemeral bind is admitted')
        elif event in('socket.connect','socket.getaddrinfo'):
            address=self.https_caller()
            if event=='socket.connect':
                sock,destination=args
                if type(sock)is not self.socket_type or destination not in(address,('::1',address[1],0,0)):raise WriteRefusal('Foreign socket/endpoint')
                if destination[0]=='::1':self.ipv6_attempts.append(dict(endpoint=destination,originalResolverCandidateOnly=True,ownedIPv6ListenerClaim=False))
            elif args[0]not in('localhost','127.0.0.1')or args[1]!=address[1]:raise WriteRefusal('Foreign resolver endpoint')
        elif event in('socket.connect_ex','socket.sendto','socket.sendmsg','socket.gethostbyname','socket.gethostbyaddr','socket.getnameinfo','socket.sethostname'):
            raise WriteRefusal('Unselected network port')

    def _writer_root(self):
        current=threading.current_thread()
        if current is self.main:return self.runroot
        frame=sys._getframe(1)
        while frame is not None:
            if self.actor_work is not None and frame.f_code is self.actor_work.__code__ and frame.f_globals is self.actor_work.__globals__:
                owner=frame.f_locals.get('self');target=getattr(current,'_target',None)
                if (type(owner)is not self.actor or owner.thread is not current or type(target)is not MethodType or target.__self__ is not owner
                        or target.__func__ is not self.actor_work or Path(owner.root).resolve(strict=True).parent!=self.root):
                    raise WriteRefusal('Actual original Actor writer ownership changed')
                return self.root
            if frame.f_code is self.http_code and frame.f_globals is self.http_globals:
                server,unused=self.listener_guard()
                if frame.f_locals.get('self')is not server:raise WriteRefusal('Foreign HTTP request owner')
                request=frame.f_locals.get('request')
                # SSLSocket is a genuine subclass of the original C socket;
                # it is accepted only inside this exact server request frame.
                if not isinstance(request,self.c_socket_type)or not stat.S_ISSOCK(os.fstat(self.c_fileno(request)).st_mode):
                    raise WriteRefusal('Actual accepted socket missing')
                return self.root
            frame=frame.f_back
        raise WriteRefusal('Unselected writer thread/frame')

    def helper(self):
        self.check()
        if self.closed:raise WriteRefusal('Writes after boundary close')
        current=threading.current_thread();root=self._writer_root();helper=self.helpers.get(current)
        if helper is None:
            helper=OwnedWrites(root,protected=self.namespace['PROTECTED'])
            helper.original=self.original;helper.original_items=self.original_items
            self.helpers[current]=helper;self.helper_records.append((current,helper,root))
        if helper.closed or helper.root!=root or helper.thread!=threading.get_ident()or helper.original is not self.original:
            raise WriteRefusal('Actual writer helper lifetime changed')
        helper._check();return helper

    def retire_writer(self,frame):
        # Called by the actual original work/request return or unwind callback,
        # while its original frame and thread still exist, never by Main later.
        current=threading.current_thread();helper=self.helpers.get(current)
        if helper is None:return
        if (frame.f_code is self.http_code and frame.f_globals is self.http_globals):
            server,unused=self.listener_guard()
            if frame.f_locals.get('self')is not server:raise WriteRefusal('HTTP retirement frame changed')
        elif self.actor_work is not None and frame.f_code is self.actor_work.__code__ and frame.f_globals is self.actor_work.__globals__:
            owner=frame.f_locals.get('self')
            if type(owner)is not self.actor or owner.thread is not current:raise WriteRefusal('Actor retirement frame changed')
        else:raise WriteRefusal('Writer retirement outside exact original frame')
        if helper.control_fds:raise WriteRefusal('Writer parent descriptors not drained')
        helper.close();self.retired.append((current,helper))

    def node_start(self,frame):
        self.check();v=frame.f_locals;caller=frame.f_back
        if frame.f_code is not self.popen_code or frame.f_globals is not self.popen_globals or type(v.get('self'))is not self.popen_class:
            raise WriteRefusal('Original Popen frame required')
        profile=next((p for p in self.constructor_profiles if caller is not None and caller.f_code is p[1].__code__ and caller.f_globals is p[1].__globals__ and type(caller.f_locals.get('self'))is p[0]),None)
        kind='node'
        desired={'bufsize':1,'stdin':-1,'stdout':-1,'stderr':-1,'text':True}
        if profile is not None:
            if profile[5].PROGRAM is not profile[2]or tuple(v['args'])!=profile[3]:raise WriteRefusal('Original JS program/tail changed')
            if sum(row['profile']is profile for row in self.births)>=profile[4]:raise WriteRefusal('Extra original Node birth')
            self.node_environment_guard()
        else:
            # subprocess.run owns this Popen frame; its actual caller must be
            # the original TLS setUpClass, not any arbitrary matching argv.
            setup=caller.f_back if caller is not None and caller.f_code is subprocess.run.__code__ else None
            if setup is None or setup.f_code is not self.tls_setup.__code__ or setup.f_globals is not self.tls_setup.__globals__:
                raise WriteRefusal('No selected original subprocess constructor')
            cls=setup.f_locals.get('cls');root=Path(cls.path).resolve(strict=True)
            expected=['openssl','req','-x509','-newkey','rsa:2048','-sha256','-days','1','-nodes','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost,IP:127.0.0.1','-keyout',str(root/'ephemeral.key'),'-out',str(root/'ephemeral.crt')]
            if cls is not self.tls_class or root.parent!=self.root or list(v['args'])!=expected or any(row['kind']=='openssl'for row in self.births):raise WriteRefusal('TLS original argv/root/count changed')
            kind='openssl';desired={'bufsize':-1,'stdin':None,'stdout':-1,'stderr':-1,'text':None}
            self.executable_guard(self.openssl_pin)
        defaults={'executable':None,'preexec_fn':None,'close_fds':True,'shell':False,'cwd':None,'env':None,'universal_newlines':None,'startupinfo':None,'creationflags':0,'restore_signals':True,'start_new_session':False,'pass_fds':(),'user':None,'group':None,'extra_groups':None,'encoding':None,'errors':None,'umask':-1,'pipesize':-1,'process_group':None}
        for name,value in dict(defaults,**desired).items():
            if v.get(name,object())!=value:raise WriteRefusal('Unselected original Popen parameter '+name)
        self.births.append(dict(process=v['self'],profile=profile,kind=kind,args=tuple(v['args']),birth=None,constructorReturned=False,constructorUnwound=False))
        self.node_entries.append(v['self'])

    def popen_returned(self,frame,*,unwound=False):
        self.check();owner=frame.f_locals.get('self');row=next((row for row in self.births if row['process']is owner),None)
        if row is None:raise WriteRefusal('Unbound Popen return/unwind')
        row['constructorUnwound']=unwound;row['constructorReturned']=not unwound
        pid=getattr(owner,'pid',None)
        if type(pid)is not int:
            if not unwound:raise WriteRefusal('Returned constructor without original child PID')
            return
        identity=proc(pid);parent=proc(os.getpid())
        if identity is None or parent is None or identity['parentPid']!=os.getpid()or identity['processGroup']!=parent['processGroup']or identity['session']!=parent['session']:
            raise WriteRefusal('Unobservable/detached original child')
        expected=self.node_pin if row['kind']=='node'else self.openssl_pin
        self.executable_guard(expected)
        actual=Path('/proc',str(pid),'exe').resolve(strict=True)
        if str(actual)!=expected['realPath']:raise WriteRefusal('Original child executable identity mismatch')
        row['birth']=identity

    def executable_guard(self,row):
        path=Path(row['realPath']);info=path.stat()
        if path.resolve(strict=True)!=path or (info.st_dev,info.st_ino)!=(row['device'],row['inode'])or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
            raise WriteRefusal('Original executable bytes/inode changed')

    def original_node_pipe(self,event,args,caller):
        if event!='open'or type(args[0])is not int or caller.f_code is not self.popen_code:return False
        self.check();owner=caller.f_locals.get('self');row=next((row for row in self.births if row['process']is owner),None)
        if row is None or caller.f_globals is not self.popen_globals or tuple(caller.f_locals['args'])!=row['args']:
            raise WriteRefusal('Original pipe constructor custody missing')
        fd,mode,flags=args
        if fd!=caller.f_locals.get('p2cwrite')or mode not in('w','wb'):raise WriteRefusal('Unknown original writable pipe')
        info=os.fstat(fd)
        if not stat.S_ISFIFO(info.st_mode)or not os.readlink('/proc/self/fd/'+str(fd)).startswith('pipe:['):raise WriteRefusal('Original pipe inode missing')
        self.pipe_opens.append((owner,fd,info.st_dev,info.st_ino));return True

    def model_before_adapter(self,frame):
        self.check();found=None;caller=frame.f_back
        # The genuine lower fixture file already exists before consumer birth.
        while caller is not None:
            if caller.f_code is self.frontdoor_init.__code__ and caller.f_globals is self.frontdoor_init.__globals__:
                found=caller.f_locals.get('self');break
            caller=caller.f_back
        if found is None or not isinstance(found,self.frontdoor):raise WriteRefusal('Missing original frontdoor artifact producer')
        if Path(frame.f_locals['args'].artifact_root)!=found.artifacts:raise WriteRefusal('Artifact consumer root differs from original producer')
        path=Path(found.artifacts)/'declared-model.ipa'
        if not path.is_relative_to(self.root)or path.resolve(strict=True)!=path:raise WriteRefusal('Foreign declared artifact model')
        info=path.lstat();raw=path.read_bytes()
        if raw!=b'Declared native model, not an installable IPA'or not stat.S_ISREG(info.st_mode)or info.st_nlink!=1 or stat.S_IMODE(info.st_mode)!=0o600:
            raise WriteRefusal('Original declared model bytes/mode changed')
        summary=caller.f_locals['summary'];handoff=summary['artifactIdentity']
        if type(handoff)is not dict or set(handoff)!={'sourceRevision','artifactSha256'}:raise WriteRefusal('Original modeled handoff missing')
        self.model_files.append(dict(path=str(path),device=info.st_dev,inode=info.st_ino,sha256=hashlib.sha256(raw).hexdigest(),declaredModelOnly=True,declaredModelHandoff=dict(handoff),installedArtifactHashEqualityClaim=False))

    def audit(self,event,args,caller):
        if event.startswith('socket.'):self.network(event,args,caller)
        if event=='subprocess.Popen':
            self.check();frame=caller
            while frame is not None and frame.f_code is not self.popen_code:frame=frame.f_back
            row=next((row for row in self.births if frame is not None and row['process']is frame.f_locals.get('self')),None)
            if row is None or tuple(args[1])!=row['args']or args[2]is not None or args[3]is not None:raise WriteRefusal('Spawn without exact observed original constructor')
        if event=='fcntl.flock':
            self.check();function,code,namespace=self.lock_body
            if function.__code__ is not code or function.__globals__ is not namespace or self.lock_type.held.__wrapped__ is not function:
                raise WriteRefusal('Original lock implementation changed')
            if caller.f_code is not code or caller.f_globals is not namespace or type(caller.f_locals.get('self'))is not self.lock_type:
                raise WriteRefusal('Flock outside actual original lock body')
            if args[0]!=caller.f_locals.get('descriptor'):raise WriteRefusal('Foreign original lock descriptor')
            import fcntl
            if args[1]!=(fcntl.LOCK_EX|fcntl.LOCK_NB):raise WriteRefusal('Foreign original flock operation')
            path=self.helper().fd(args[0]);owner=caller.f_locals['self']
            if path!=owner.path or os.fstat(args[0]).st_size!=0:raise WriteRefusal('Original lock path/FD changed')
        super().audit(event,args,caller)

    def restore(self):
        self.check()
        if any(thread is not self.main and(not helper.closed or thread.is_alive())for thread,helper,root in self.helper_records):raise WriteRefusal('Actual writer threads/helpers not drained')
        main=self.helpers.get(self.main)
        if main is not None:
            if main.control_fds:raise WriteRefusal('Main parent descriptors not drained')
            main.close()
        for name,original in self.original_items:setattr(os,name,original)
        self.installed=False;self.closed=True
        if any(getattr(os,name)is not original for name,original in self.original_items):raise WriteRefusal('Actual 27 mutation ports not restored')
        return dict(actualPortsRestored=True,writerHelpersClosed=len(self.helper_records),sameThreadRetirements=len(self.retired),wholeQualified=False)
