"""Metadata-only retained-owner Own7 controller. No target imports/execution."""
import ast,difflib,hashlib,json,os,runpy,stat,subprocess
from pathlib import Path
R=Path.cwd().resolve(strict=True);assert R.name=='overte-ios-feature-adapters-resume-20261026'and(R/'.git').is_file()
def target(p):
 p=Path(p);assert p.resolve().is_relative_to(R);return p
def mkdir(p):target(p).mkdir(parents=True,exist_ok=True,mode=0o700)
def write(p,value):
 p=target(p);p.write_text(value);p.chmod(0o600)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert os.environ.get('LIFECYCLE_ALL_FOREIGN_RAW_WRITERS_TERMINAL')=='root-confirmed'
HEAD='d824159435cbb4e70576ce13e3a343e9858e6caf'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==HEAD
O=R/'.ios-host-tmp/lifecycle-literal-policy-own7-real-http-scope-pinned-overlay-root-preparation-20261103'
B=R/'.ios-host-tmp/lifecycle-literal-container-policy-plan-bound-source-proposal-20261103'
P=R/'.ios-host-tmp/lifecycle-retained-owner-literal-index-inventory-source-proposal-20261103'
S=R/'.ios-host-tmp/lifecycle-retained-owner-identical-api-source10-proposal-20261103'
H=R/'.ios-host-tmp/lifecycle-retained-owner-source10-snapshot-seed-seven-pinned-overlay-root-preparation-20261103'
assert sha(O/'freeze.json')=='bad384cbbee21cc8521a8e13612111b114b8afef9be7c39ebf8e35df97082abf'
assert sha(P/'freeze.json')=='8c2a3db7f760c2b1c35f203a4120fae1a008e08e66867f260412d99325ca9492'
assert sha(S/'freeze.json')=='f174ef19c95c2f14b59fb062de6daf19a46b67750154d4020741220b1bae3ff5'
for row in json.loads((S/'freeze.json').read_text())['productionFiles']:assert sha(Path(row['path']))==row['sha256']
for p in (O,S,P):
 rows=json.loads((p/'freeze.json').read_text())['files']
 rows=rows.items()if type(rows)is dict else((r['path'],r['sha256'])for r in rows)
 for relative,digest in rows:assert sha(p/relative)==digest
assert not H.exists();mkdir(H)
for relative in json.loads((O/'freeze.json').read_text())['files']:
 if relative.startswith('models/')or relative in ('immutable-source-pins.json','AST-ONLY.json','global-original-corpus-baseline.json','ROOT-PLAN.txt'):continue
 path=H/relative;mkdir(path.parent);target(path).write_bytes((O/relative).read_bytes());path.chmod(0o600)
def rebase(value):
 if type(value)is dict:return {name:rebase(row)for name,row in value.items()}
 if type(value)is list:return [rebase(row)for row in value]
 return value.replace(str(O),str(H)).replace(str(B),str(P))if type(value)is str else value
for relative in ('plan.json','maps.json',*[str(p.relative_to(O))for p in(O/'maps').glob('*.json')]):
 value=rebase(json.loads((H/relative).read_text()))
 if relative.startswith('maps/'):
  for row in value.values():
   if type(row)is dict and 'path'in row and 'sha256'in row:row['sha256']=sha(Path(row['path']))
 write(H/relative,json.dumps(value,indent=2,sort_keys=True)+'\n')
maprows=json.loads((H/'maps.json').read_text())
for row in maprows.values():row['sha256']=sha(Path(row['path']))
write(H/'maps.json',json.dumps(maprows,indent=2,sort_keys=True)+'\n')
model=S/'models/test_lifecycle_retained_current_owner_models.py';tree=ast.parse(model.read_text())
methods=[node.name for cls in tree.body if isinstance(cls,ast.ClassDef)for node in cls.body if isinstance(node,ast.AsyncFunctionDef)and node.name.startswith('test_')]
assert len(methods)==7
order=['first1','sameInode1','foreignInode1','sameCode1','lostCAS1','publisherPrepare1','literalInventory1']
rows=[]
for stage,method in zip(order,methods):
 row=dict(case=model.stem+'.LifecycleRetainedCurrentOwnerModels.'+method,wallSeconds=180,killAfterSeconds=5,expectedTemporaryDirectories=3,ownMethodOnly=True,pureTokenCounter=False,wholeFeatureQualified=False,freshPublishQualified=False,scope='RETAINED_CURRENT_OWNER_CUSTODY_PREFLIGHT_LITERAL_INDEX_ONLY')
 mkdir(H/stage);write(H/stage/'case.json',json.dumps(row,indent=2,sort_keys=True)+'\n');rows.append(dict(stage=stage,**row))
# Remove unused copied stage directories, which contain only frozen case metadata.
for path in H.iterdir():
 if path.is_dir()and(path/'case.json').exists()and path.name not in order:
  assert set(x.name for x in path.iterdir())=={'case.json'};target(path/'case.json').unlink();target(path).rmdir()
plan=json.loads((H/'plan.json').read_text());plan.update(publicHead=HEAD,sourcePacket=str(S),sourceFreezeSha256=sha(S/'freeze.json'),caseCount=7,cases=[x['case']for x in rows],stageOrder=order,stageCases=rows,modelRoot=str(S/'models'),baseModelRoot=str(P/'models'),productionSourcePacket=str(P),productionSourceFreezeSha256=sha(P/'freeze.json'),selectionScope='SEVEN_ACTUAL_RETAINED_CURRENT_OWNER_CUSTODY_PREFLIGHT_LITERAL_INVENTORY_COUNTERS_ONLY',qualification='AST-only proposed source qualification; no LivePublish/Own7/Whole16/images/terminal/native/SDK/device claim',diagnosticOnly=False)
for row in plan['overlays']:
 row['sha256']=sha(Path(row['path']))
 if row.get('publicPath')is not None:row['publicSha256']=sha(Path(row['publicPath']))if Path(row['publicPath']).exists()else None
write(H/'plan.json',json.dumps(plan,indent=2,sort_keys=True)+'\n')
old_order=repr(tuple(json.loads((O/'plan.json').read_text())['stageOrder']));new_order=repr(tuple(order))
for filename in ('guard.py','root-supervise.py'):
 p=H/filename;text=p.read_text();assert old_order in text;write(p,text.replace(old_order,new_order))
p=H/'guard.py';text=p.read_text()
needle="    root=stage/'retained';actual="
addition="""    if expected.startswith('test_lifecycle_retained_current_owner_models.'):
        baseline=json.loads((stage.parent/'global-original-corpus-baseline.json').read_text())
        before_global=json.loads((stage/'run/global-originals-before.json').read_text())
        first_global=json.loads((stage/'run/global-originals-first.json').read_text())
        second_global=json.loads((stage/'run/global-originals-second.json').read_text())
        assert report['globalOriginalsUnchanged']and report['globalOriginalRoots']==len(baseline)
        assert before_global==first_global==second_global==baseline
"""
assert text.count(needle)==1;write(p,text.replace(needle,addition+needle))
p=H/'run-selected.py';text=p.read_text();text=text.replace('Root-only ONE exact Own7 live-publication/read-phase method','Root-only ONE exact retained-owner custody/preflight/literal-index method').replace("str(PREP/'models')","str(Path(plan['modelRoot'])),str(Path(plan['baseModelRoot']))").replace('Own7 permits ZERO subprocesses/Node/SDK/device','Retained-owner counters permit ZERO subprocesses/Node/SDK/device');write(p,text)
assert sha(H/'root_stage_guard.py')=='862293f5b6b6aee20e890910af6c31197e92196b310643d65994aa5e85501804'
# Historical helper PASS remains scoped to its exact3b source. New source is UNRUN.
for filename in ('passive-diagnostic-provenance.json','diagnostic-provenance.json'):
 p=H/filename
 if p.exists():write(p,json.dumps(dict(historicalOnly=True,inheritedProvenance=json.loads(p.read_text()),currentSelection=plan['selectionScope'],currentLivePublisherPOSTRequired=False,whole16Qualified=False),indent=2,sort_keys=True)+'\n')
history=json.loads((H/'historical-proof-scope.json').read_text())
f=O/'first1';oldreport=json.loads((f/'run/report.json').read_text());assert oldreport['exitCode']==1 and oldreport['retainedFiles']==43 and oldreport['globalOriginalsUnchanged']
history.setdefault('failedStages',[]).append(dict(path=str(f),reportSha256=sha(f/'run/report.json'),exitCode=1,retainedFiles=43,retainedRootCount=3,selectedResultExists=True,scope='Source3b real Live-baseline-publish setup failure BEFORE own admission body; six following cases UNRUN'))
previous=R/'.ios-host-tmp/lifecycle-retained-owner-seven-full-global-predecessor-pinned-overlay-root-preparation-20261103'
failed=previous/'first1';assert sha(failed/'run/report.json')=='f213bd758764648c54ba884ff4ab26fa6fd77b60d6de7506c5fead7e59569ede'
history['failedStages'].append(dict(path=str(failed),reportSha256=sha(failed/'run/report.json'),exitCode=1,retainedFiles=20,retainedRootCount=3,selectedResultExists=True,scope='Source8c mechanical fixture name collision before new Archive operation; six following UNRUN'))
previous9=R/'.ios-host-tmp/lifecycle-retained-owner-source9-seven-pinned-overlay-root-preparation-20261103'
failed9=previous9/'first1';assert sha(failed9/'run/report.json')=='4885a598ad892b3709e2436d1d559cefd19c059c31ebf1cdf39e2943970e0d7b'
history['failedStages'].append(dict(path=str(failed9),reportSha256=sha(failed9/'run/report.json'),exitCode=1,retainedFiles=28,retainedRootCount=3,selectedResultExists=True,scope='Source9 compares pure Archive read with live Stream entrypoint; additional actual installed-code-binding Source read, no product success; six following UNRUN'))
write(H/'historical-proof-scope.json',json.dumps(history,indent=2,sort_keys=True)+'\n')
seed=json.loads((H/'global-original-roots-seed.json').read_text());seed['roots']=sorted(set(seed['roots'])|{str((f/'retained').relative_to(R)),str((failed/'retained').relative_to(R)),str((failed9/'retained').relative_to(R))});seed['writerExclusions']=[]
for relative in ('.ios-host-tmp/snapshot-resume-page-first1-root-preparation-20261103/runs/first1-de2j9x22/temporary','.ios-host-tmp/snapshot-resume-page-own5-root-preparation-20261103/runs/own5-4rqqo3di/temporary'):
 path=R/relative;assert path.resolve(strict=True)==path and path.is_dir();seed['roots']=sorted(set(seed['roots'])|{relative})
write(H/'global-original-roots-seed.json',json.dumps(seed,indent=2,sort_keys=True)+'\n')
g=runpy.run_path(str(H/'global_original_corpus.py'));first=g['current']();second=g['current']();assert first==second,'An original writer is active; wait without exclusions'
write(H/'global-original-corpus-baseline.json',json.dumps(second,indent=2,sort_keys=True)+'\n')
F=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def pin(p):
 p=Path(p);a=p.lstat();assert not p.is_symlink()and p.resolve(strict=True)==p;v=dict(stat=[getattr(a,k)for k in F])
 if p.is_file():v['sha256']=sha(p)
 assert v['stat']==[getattr(p.lstat(),k)for k in F];return v
oldpins=json.loads((O/'immutable-source-pins.json').read_text());allowed=set(subprocess.check_output(['git','diff','--name-only','4a8287f147ad33555c34dbda420b0f09162fb368',HEAD],text=True).splitlines());pins={};drift=[]
for name,old in oldpins.items():
 p=Path(name);current=pin(p);pins[name]=current
 if current!=old:
  relative=str(p.relative_to(R));assert relative in allowed,relative
  assert p.read_bytes()==subprocess.check_output(['git','show',HEAD+':'+relative])
  drift.append(dict(path=relative,previous=old,current=current))

for relative in allowed:
 p=R/relative;assert p.read_bytes()==subprocess.check_output(['git','show',HEAD+':'+relative]);pins[str(p)]=pin(p)
write(H/'exact-public-head-delta.json',json.dumps(dict(previousPublicHead='4a8287f147ad33555c34dbda420b0f09162fb368',currentPublicHead=HEAD,changedPreviouslyPinned=drift,allCommittedPaths=sorted(allowed),historicalSourceAndReceiptChecksRetained=True),indent=2,sort_keys=True)+'\n')
# Keep all exact historical source metadata and all actually retained first1
# originals/failure/cleanup as immutable inputs; no historical outcome relabeling.
for p in (O/'freeze.json',O/'immutable-source-pins.json',Path(__file__).resolve(),*sorted((O/'first1').rglob('*'))):pins[str(p)]=pin(p)
for p in sorted((R/'.ios-host-tmp/lifecycle-retained-owner-seven-pinned-overlay-root-preparation-20261103').rglob('*')):
 if p.is_file():pins[str(p)]=pin(p)
for p in sorted((R/'.ios-host-tmp/lifecycle-retained-owner-seven-optional-public-path-pinned-overlay-root-preparation-20261103').rglob('*')):
 if p.is_file():pins[str(p)]=pin(p)
for p in (previous/'freeze.json',previous/'immutable-source-pins.json',*sorted((previous/'first1').rglob('*'))):pins[str(p)]=pin(p)
for p in sorted((R/'.ios-host-tmp/lifecycle-retained-owner-first1-helper-collision-results-20261103').rglob('*')):
 if p.is_file():pins[str(p)]=pin(p)
for row in json.loads((S/'static-mro-name-audit.json').read_text())['mro']:pins[row['path']]=pin(Path(row['path']))
for p in sorted(P.rglob('*')):
 if p.is_file():pins[str(p)]=pin(p)
for p in (previous9/'freeze.json',previous9/'immutable-source-pins.json',*sorted((previous9/'first1').rglob('*'))):pins[str(p)]=pin(p)
for root in (R/'.ios-host-tmp/lifecycle-retained-owner-helper-name-source9-proposal-20261103',R/'.ios-host-tmp/lifecycle-retained-owner-source9-first1-api-boundary-results-20261103'):
 for p in sorted(root.rglob('*')):
  if p.is_file():pins[str(p)]=pin(p)
for p in sorted(S.rglob('*')):
 if p.is_file():pins[str(p)]=pin(p)
# Bind the actual current Git HEAD and loose branch ref without a target-side
# subprocess. These are read-only repository metadata, never mutation targets.
githead=Path(subprocess.check_output(['git','rev-parse','--git-path','HEAD'],text=True).strip()).resolve(strict=True)
pins[str(githead)]=pin(githead);headtext=githead.read_text().strip()
if headtext.startswith('ref: '):
 ref=Path(subprocess.check_output(['git','rev-parse','--git-path',headtext[5:]],text=True).strip()).resolve(strict=True);assert ref.read_text().strip()==HEAD;pins[str(ref)]=pin(ref)
else:assert headtext==HEAD
write(H/'selection-provenance.json',json.dumps(dict(sourceFreeze=sha(S/'freeze.json'),productionSourceFreeze=sha(P/'freeze.json'),parentControllerFreeze=sha(O/'freeze.json'),mechanicalFixturePredecessorFreeze=sha(previous/'freeze.json'),identicalAPIPredecessorFreeze=sha(previous9/'freeze.json'),currentPublicHead=HEAD,selected=rows,modelRoot=str(S/'models'),modelSha256=sha(model),actualSourceOverlays=len(plan['overlays']),rootStageGuardSha256=sha(H/'root_stage_guard.py'),rootStageGuardByteExact=True,productionGuardReplacements=0,allSevenInitiallyUnrun=True,firstFailureStops=True,whole16Authorized=False,freshPublishAuthorized=False,oldSource3bLiveSetupFailureRetained=True,defaultPassiveNoPublisherWAL=True,clockJoin1500msUnchanged=True,allGlobalWriterExclusions=[]),indent=2,sort_keys=True)+'\n')
write(H/'ROOT-PLAN.txt',"""ROOT REVIEW REQUIRED — SEVEN RETAINED CURRENT OWNER COUNTERS ONLY

Current public HEADd824159435cbb4e70576ce13e3a343e9858e6caf. Source10f174ef19 changes ONLY the left read collection to the same actual
stream.archive().record(reference) entrypoint as the right collection. All
Sourcechecks/readpaths remain. Source9 helper rename and21-class MRO audit
remain unchanged. The other six API boundaries have a separate static audit. Source8c
production49 files/44 overlays is byte-identical. Corrected single model loads
first, with Source8c base models second, then unchanged support. No clean tree
is duplicated into this controller. The
44 exact reviewed complete product overlays select Source8c; seven original
birth/source maps preserve actual source constructor/receiver provenance.

Fixed order, EACH exactly180+5 once, first failure/refusal/timeout stops:
first1 actual same Archive+history identity/read membership;
sameInode1 same-inode exact rewrite refusal;
foreignInode1 real equal-body foreign PFS CAS refusal;
sameCode1 actual same decoder function __code__ mutation/refusal/restore;
lostCAS1 actual planned Current WAL CAS return loss before new query;
publisherPrepare1 passive default no-WAL versus actual Publisher preflight;
literalInventory1 actual complete literal index read membership/no nested memo.
Only an actual fully qualified predecessor PASS permits the next exact method.
Each new predecessor explicitly rechecks its global before/two-after censuses
against this exact complete frozen baseline, in addition to its own raw custody.
No fresh LivePublish/Own7/Whole16/moving-PNG/End/native/device claim or target.

All normal Source/SDK/header/nonce/raw/native/phase/clock parsers and1500ms
limits remain. Lower SDK/native/OS producer data stays explicitly modeled. The
only sockets are existing owned canonical loopbacks; zero Node/child subprocess,
real SDK/vendor imports, service/start/remote/native/device/compiler/build use.
Actual unchanged standard TestCase.run/AsyncRunner close/cleanup, three retained
original TemporaryDirectories, actual root_stage_guard FD/task/thread/child/
SDK checks and two original terminal censuses remain. Root's session/PGID/
startTicks guard requires actual process absence before final raw censuses.

All old original/failure corpora are preserved, including Source3b first1 setup
failure43 files/3TD with the other six methods UNRUN. Historical Clock/Own8/
warm PASS receipts remain exact historical source scopes, never current proof.
The previous265 global roots plus every new /runs AND direct /temporary root
and both old own first1/retained corpora (43,20 and28 files) are covered. No writer/controller is excluded. Both completed Snapshot-Resume temporary
corpora are explicitly seeded in addition to the complete parent /runs roots.
Root confirmed foreign writers terminal before the two equal preparation scans.
Global originals are checked before target birth and twice after real process
drain, with predecessor/historical corpus checks repeated at both boundaries.

Exact current public commit delta is metadata-only, pinned to committed bytes;
no old semantic receipt guard is bypassed. Current Git HEAD/ref files are also
read-only pinned. All foreign/public Snapshot rows remain actual current bytes.
No target imports/execution occurred during preparation. Review/final Root
window authorization are required before root-supervise.py first1.

Entrypoint after authorization, from exact Resume cwd:
PYTHONDONTWRITEBYTECODE=1 python3 -B <this-controller>/root-supervise.py <this-controller>/first1
Do not launch the remaining cases until each preceding actual report, selected
ID, cleanup, process, source and original/global corpus checks fully pass.
""")
for p in sorted(H.rglob('*')):
 if p.is_file():pins[str(p)]=pin(p)
write(H/'immutable-source-pins.json',json.dumps(pins,indent=2,sort_keys=True)+'\n')
asts=[]
for p in sorted(H.rglob('*.py')):asts.append(dict(path=str(p.relative_to(H)),sha256=sha(p),astSha256=hashlib.sha256(ast.dump(ast.parse(p.read_bytes()),include_attributes=False).encode()).hexdigest()))
write(H/'AST-ONLY.json',json.dumps(dict(status='NO_TARGET_IMPORT_OR_EXECUTION',files=asts),indent=2,sort_keys=True)+'\n')
files={str(p.relative_to(H)):sha(p)for p in sorted(H.rglob('*'))if p.is_file()}
write(H/'freeze.json',json.dumps(dict(status='PRIVATE_FROZEN_SOURCE10_RETAINED_OWNER_SEVEN_UNRUN_ROOT_REVIEW_REQUIRED',publicHead=HEAD,sourceFreeze=sha(S/'freeze.json'),parentControllerFreeze=sha(O/'freeze.json'),files=files),indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(controller=str(H),freeze=sha(H/'freeze.json'),pins=len(pins),overlays=len(plan['overlays']),maps=len(maprows),stages=order,globalRawRoots=len(second),globalRawEntries=sum(len(x)for x in second.values()),modelSha256=sha(model),publicHeadDelta=len(allowed),oldPinDelta=len(drift),executed=False),indent=2))
