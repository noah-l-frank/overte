"""Capture-local identity of the actual immutable marker/image interpretation.

Reuse the existing closed parser tokens and JSON/PNG policy. Follow only
referenced global/builtin/attribute bindings of the actual reader functions;
unrelated live input transports never become cached interpretation. No target
module is imported by the fingerprint. Unknown policies take the cold archive.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
import dis
import inspect
import sys
from types import FunctionType,CodeType,ModuleType
from ios.adapters import emote_callback_live_records as tokens


class AvatarSampleReturnLiteral:
    LIMIT=4096
    def __init__(self,roots):
        self.roots=tuple(roots);self.references=[];self.unsupported=None
        # Keep the fingerprint engine itself fixed while comparing a policy.
        self.engines=tuple((container,name,getattr(container,name),getattr(container,name).__code__)
            for container,name in ((tokens,'_token'),(tokens,'_png_policy'),(tokens,'_parser_global_bindings'),
                (type(self),'signature'),(type(self),'literal')))
        self.engine_globals=[]
        try:
            for _container,_name,function,_code in self.engines:
                for name in sorted(set(function.__code__.co_names)&function.__globals__.keys()):
                    if name=='__builtins__':continue
                    value=function.__globals__[name]
                    self.engine_globals.append((function.__globals__,name,value,tokens._token(value,self.references,set())))
        except (AttributeError,TypeError,ValueError,RecursionError,tokens._Unsupported):
            self.unsupported=('fingerprint-engine','unsupported-binding');self.policy=None;return
        self.policy=self.signature(self.references)

    def signature(self,references):
        rows=[];seen=set();location=None
        def token(value):return tokens._token(value,references,set())
        def lookup(container,name):
            value=inspect.getattr_static(container,name)
            return value.__func__ if type(value) in (staticmethod,classmethod) else value
        def code_bindings(code,namespace,builtins):
            # Nested code uses the same defining globals. Imports are observed
            # only in the already-loaded module registry; no import executes.
            imported=None
            for instruction in dis.get_instructions(code):
                if instruction.opname=='IMPORT_NAME':
                    name=instruction.argval;imported=sys.modules.get(name)
                    rows.append(('import-binding',name,None if imported is None else token(imported)))
                elif instruction.opname=='IMPORT_FROM' and imported is not None:
                    name=instruction.argval;item=vars(imported).get(name)
                    rows.append(('import-from-binding',id(imported),name,token(item)));walk(item)
            names=set(code.co_names)
            for name in sorted(names):
                if name in namespace:
                    value=namespace[name];rows.append(('global',id(namespace),name,token(value)));walk(value,names)
                elif name in builtins:rows.append(('builtin',name,token(builtins[name])))
            for value in code.co_consts:
                if type(value) is CodeType:code_bindings(value,namespace,builtins)
        def walk(value,attributes=()):
            nonlocal location
            identity=id(value)
            # Every actual attribute binding participates per use, even when
            # its container has already been visited through another alias.
            if type(value) is ModuleType or type(value) is type and value.__module__.startswith(('adapters.','ios.adapters.','feature_journeys.')):
                for name in sorted(set(attributes)):
                    try:item=lookup(value,name)
                    except AttributeError:continue
                    rows.append(('attribute',identity,name,token(item)));walk(item)
            if identity in seen:return
            seen.add(identity)
            if len(seen)>self.LIMIT:raise tokens._Unsupported(type(value),'sample-reader-graph-limit')
            references.append(value);location=(type(value).__module__,getattr(value,'__qualname__',None))
            rows.append(('value',identity,token(value)))
            if any(value is item for item in (tokens._token,tokens._png_policy,tokens._parser_global_bindings)):return
            if type(value) is FunctionType and value.__module__.startswith(('adapters.','ios.adapters.','feature_journeys.')):
                code_bindings(value.__code__,value.__globals__,value.__builtins__)
                if value.__closure__:
                    for cell in value.__closure__:walk(cell.cell_contents)
        try:
            for root in self.roots:walk(root)
            external=tuple((id(container),name,token(getattr(container,name))) for container,name in tokens.EXTERNAL_READERS)
            return tuple(rows),external,tokens._png_policy(references)
        except (AttributeError,TypeError,ValueError,RecursionError,tokens._Unsupported):
            self.unsupported=location;return None

    def literal(self):
        if self.policy is None:return False
        if any(getattr(container,name) is not function or function.__code__ is not code
               for container,name,function,code in self.engines):return False
        try:
            if any(namespace.get(name) is not value or tokens._token(value,[],set())!=policy
                   for namespace,name,value,policy in self.engine_globals):return False
            return self.signature([])==self.policy
        except (AttributeError,TypeError,ValueError,RecursionError,tokens._Unsupported):return False
