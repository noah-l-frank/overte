from pathlib import Path
import ast,difflib,json,hashlib
r=Path.cwd().resolve();assert r.name=='overte-ios-feature-adapters-resume-20261026'and(r/'.git').is_file();p=r/'.ios-host-tmp/audio-original-keeper-profile-route-closed-utility6-bootstrap1-code-preparation-20261104';assert p.resolve().is_relative_to(r)
s=r/'.ios-host-tmp/audio-original-keeper-cli-profile-adapter-source2-exact-interface-inventory-private-20261104';stage=r/'.ios-host-tmp/audio-normal14-original-handoff-integration-staging1-private-20261104';b=r/'.ios-host-tmp/c24-diagnostic-source3-closed-utility14-bootstrap1-code-preparation-20261104'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,value):
 f=p/n;assert f.resolve().is_relative_to(r)and not f.exists();f.write_text(value)
def dump(v):return json.dumps(v,indent=2,sort_keys=True)+'\n'
f=p/'ROOT-PLAN.md';f.write_text(f.read_text().replace('The32-bit/native/SharedKeeper','The native/SharedKeeper'))
assert sha(s/'source-freeze.json')=='cf980ab55fe1801ff683281440b41dfc54595193dd1953a98898c9ef98b0373b'
assert sha(stage/'source-freeze.json')=='28babecbcbb390c5638a695965f0a822fc872c86b505cb011d2c5bcdba1c986a'
asts={}
for f in p.glob('*.py'):ast.parse(f.read_text(),filename=str(f));asts[f.name]=sha(f)
assert len(asts)==8
closure=json.loads((p/'PROJECT-DEFINING-ORIGINS.json').read_text());assert len(closure['modules'])==41 and len(closure['subjectModules'])==6
refs={}
for name,row in closure['modules'].items():
 q=Path(row['path']);assert q.resolve(strict=True)==q and sha(q)==row['sha256'];refs[str(q)]=sha(q);ast.parse(q.read_text())
for folder,leaf in((s,'source-freeze.json'),(stage,'source-freeze.json'),(b,'source-freeze.json'),(r/'.ios-host-tmp/root-audio-original-keeper-profile-routing-source2-review-20261104','freeze.json')):
 q=folder/leaf;refs[str(q)]=sha(q)
 for name,row in json.loads(q.read_text())['files'].items():
  path=folder/name;expected=row if type(row)is str else row['sha256'];assert sha(path)==expected;refs[str(path)]=sha(path)
rows=json.loads((stage/'STAGING-MANIFEST.json').read_text())['rows'];assert len(rows)==107
for row in rows:assert sha(stage/'candidate'/row['path'])==row['sha256']
for row in json.loads((s/'CANDIDATES.json').read_text()):assert sha(s/'candidate'/row['path'])==row['candidateSha256']
external=json.loads((p/'third-party-source-declarations.json').read_text());assert len(external)==39
for name,row in external.items():assert sha(Path(row['path']))==row['sha256'];refs[row['path']]=row['sha256']
assert sha(p/'third-party-source-declarations.json')=='0df1d3968a70455a27b8a1c4c69d9b97178960ff187888d2e14677093cdacf1b'
selector_packet=json.loads((p/'exact-six-selectors.json').read_text());assert selector_packet==json.loads((s/'prospective-six-selectors.json').read_text());ids=selector_packet['caseIds'];assert len(ids)==len(set(ids))==6
casepath=s/'candidate/tests/device/self_tests/test_audio_original_keeper_terminal_profile.py'
cl=next(c for c in ast.parse(casepath.read_text()).body if isinstance(c,ast.ClassDef)and c.name=='AudioOriginalKeeperTerminalProfileTests')
assert {v.rsplit('.',1)[-1]for v in ids}=={f.name for f in cl.body if isinstance(f,ast.FunctionDef)}
for name,old in(('prepare.py','prepare.py'),('run-six.py','run-fourteen.py'),('supervise-six.py','supervise-fourteen.py')):
 write(name+'.utility14-to-audio6.patch',''.join(difflib.unified_diff((b/old).read_text().splitlines(True),(p/name).read_text().splitlines(True),fromfile='Utility14/'+old,tofile='AudioUtility6/'+name)))
runner=(p/'run-six.py').read_text();outer=(p/'supervise-six.py').read_text();prep=(p/'prepare.py').read_text()
for field in ['allSixActualRuntimeOriginsEstablished','actual-source-model-origins.json','actual-port-restoration.json','profileRestored']:
 assert field in runner and field in outer
assert outer.count('dict(HERE=census(HERE),outer=census(COLLECTOR))')==2
assert 'intent_graph_diagnostic'not in prep and 'import feature_journeys'not in prep
write('SOURCE-REFERENCES.json',dump(refs))
write('STATIC-READBACK.json',dump(dict(status='AUTHOR_CRITICAL_SOURCE_ONLY_UNRUN',eightPythonASTs=asts,actualOriginal6BodiesUnchanged=True,exactSixSelectors=ids,actualStaged107SourcePathsPinned=True,actualRouteSource2FourCandidatesPinned=True,explicitModelCompatibilitySixthBody=True,CLIImportedOrExecuted=False,finiteDefiningProjectModules=41,requiredActualRuntimeSubjects=6,exactPILDefusedRows=39,subprocesses=0,threads=0,TDs=0,realNetwork=False,overteNativeQueries=0,wallSeconds=30,killGraceSeconds=5,currentHelperSha256='69093cc530ebbcd4bc0d7e95aa591ed3d480e0ac4812eced45da1cf78a56b81d',E458Strict7ByteExact=True,twoCompleteHEREPlusOuterCensusesThirdRoom=True,utilityQualification=None,audioEndAdmission=None,nativeQualified=False,wholeQualified=False,imports=0,builders=0,targets=0,maps=0,censuses=0)))
write('source-freeze.json',dump(dict(schemaVersion=1,status='FROZEN_SOURCE_ONLY_AUDIO_PROFILE_ROUTE_UTILITY6_BOOTSTRAP_UNRUN',files={f.name:sha(f)for f in sorted(p.iterdir())},routeSource2Freeze=sha(s/'source-freeze.json'),staged107Freeze=sha(stage/'source-freeze.json'),RootSourceReviewFreeze='59d2213ef3927ae46c3403030dd46f82bbf7cdb2f69358e7c4868f39591eab1f',utilityQualification=None,audioEndAdmission=None,nativeQualified=False,wholeQualified=False,imports=0,builders=0,targets=0,maps=0,censuses=0)))
print(p/'source-freeze.json');print(sha(p/'source-freeze.json'));print('members',len(json.loads((p/'source-freeze.json').read_text())['files']),'ASTs',len(asts),'namedrefs',len(refs))
