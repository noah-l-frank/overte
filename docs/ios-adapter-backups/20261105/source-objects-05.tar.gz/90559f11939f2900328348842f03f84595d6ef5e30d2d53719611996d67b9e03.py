"""Connected original admission DAG: actual model originals, no native proof."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import cProfile,json,sys,time,types,unittest
from adapters.normal_ui import NativeUIError
from adapters.original_frame_store import OriginalFrameStore
from ios.adapters import audio_passive_capture_source as contract
from ios.adapters.audio_original_validation_graph import original_validation_graph,SemanticFence,ControlGraph,UnsupportedCodec
from ios.adapters.audio_native_pure_readers import prepare as prepare_native_readers,MODULES as NATIVE_READERS
from ios.self_tests.test_ios_audio_passive_owner import AudioPassiveOwnerTests


def replacement_command(value):return value

_ORDERED_LITERAL={'first':1,'second':2}
_NESTED_LITERAL={'allowed':True}
_ALIAS_LEFT={'allowed':True}
_ALIAS_RIGHT=_ALIAS_LEFT

def alias_identity_reader():return _ALIAS_LEFT is _ALIAS_RIGHT

def unknown_import_reader():
    from audio_unreviewed_sideeffect_reader import value
    return value

def dynamic_import_reader(name):return __import__(name)

class NestedLiteralCodec:
    def read(self):return _NESTED_LITERAL['allowed']


class ClassClosureCodec:
    def __init__(self):super().__init__()


class AudioOriginalValidationGraphTests(unittest.TestCase):
    def fixture(self):
        f=AudioPassiveOwnerTests();f.setUp();self.addCleanup(f.doCleanups);f.begin()
        with f.owner()as owner:owner.capture();owner.retire()
        return f

    def test_actual_complete_admission_shares_local_semantics_but_reads_actual_originals_and_rebuilds_next_round(self):
        f=self.fixture()
        with f.owner()as owner:
            originals={p:(p.stat().st_ino,p.read_bytes())for p in owner.root.iterdir()};commands=deepcopy(f.boundary.commands)
            # Prove actual positive sharing without profiler observer cost.
            owner.admit();first=deepcopy(owner._last_validation_graph_profile)
            self.assertIsNone(first['unsupported'],first)
            self.assertGreater(first['reusedLocalValidations'],0,first)
            self.assertGreater(first['freshFrames'],first['semanticValidations'])
            self.assertIsNone(owner._validation_graph)
            # Independent admission for measured real call counts. Profiling
            # may cross real50ms boundaries and legitimately discard all reuse.
            profile=cProfile.Profile();profile.runcall(owner.admit)
            measured=deepcopy(owner._last_validation_graph_profile)
            self.assertIsNone(measured['unsupported'],measured)
            calls=sum(row.callcount for row in profile.getstats()if row.code is owner.validate_entry.__func__.__code__)
            self.assertEqual(calls,measured['semanticValidations'])
            raw_reads=sum(row.callcount for row in profile.getstats()if row.code is OriginalFrameStore.read.__code__)
            self.assertGreaterEqual(raw_reads,sum(row['revision']for row in owner.state['streams'].values()))
            self.assertGreaterEqual(measured['freshFrames'],measured['semanticValidations'])
            self.assertIsNone(owner._validation_graph);self.assertIsNone(owner._inventory_round)
            owner.admit();second=owner._last_validation_graph_profile
            self.assertGreater(second['semanticValidations'],0);self.assertGreater(second['freshFrames'],0)
            self.assertEqual(commands,f.boundary.commands)
            self.assertEqual(originals,{p:(p.stat().st_ino,p.read_bytes())for p in owner.root.iterdir()})

    def test_same_inode_rewrite_and_new_foreign_namespace_refuse_and_clear_entire_round(self):
        for foreign in (False,True):
            f=self.fixture()
            with self.subTest(foreign=foreign),f.owner()as owner:
                journal=owner.journals['proofs'];actual=journal.files.read;changed=[]
                signed=next(p for p in owner._signatures if '-native-frame-'in p.name);raw=signed.read_bytes();inode=signed.stat().st_ino
                def read(ref):
                    result=actual(ref)
                    if not changed:
                        if foreign:
                            path=owner.root/'foreign-original-duty.json';path.write_text('{}');path.chmod(0o600)
                        else:signed.write_bytes(raw)
                        changed.append(True)
                    return result
                with patch.object(journal.files,'read',read),self.assertRaises(NativeUIError):owner.admit()
                self.assertTrue(changed);self.assertEqual(signed.stat().st_ino,inode)
                self.assertIsNone(owner._validation_graph);self.assertIsNone(owner._inventory_round)

    def test_same_object_parser_code_and_owner_state_mutations_refuse_before_round_can_escape(self):
        for parser in (True,False):
            f=self.fixture()
            with self.subTest(parser=parser),f.owner()as owner:
                journal=owner.journals['native'];actual=journal.files.read;changed=[];original_code=contract.command.__code__
                def read(ref):
                    result=actual(ref)
                    if not changed:
                        if parser:contract.command.__code__=replacement_command.__code__
                        else:owner.state['phase']='captured'
                        changed.append(True)
                    return result
                try:
                    with patch.object(journal.files,'read',read),self.assertRaises(NativeUIError):owner.admit()
                finally:contract.command.__code__=original_code
                self.assertTrue(changed);self.assertIsNone(owner._validation_graph);self.assertIsNone(owner._inventory_round)

    def test_external_owner_authority_callback_and_real_time_boundary_discard_local_status(self):
        f=self.fixture()
        with f.owner()as owner:
            commands=deepcopy(f.boundary.commands)
            with original_validation_graph(owner)as graph:
                for journal in owner.journals.values():journal.restore()
                self.assertTrue(graph.enabled,graph.fence.unsupported)
                first=graph.counts['semanticValidations'];owner.bound()
                self.assertGreater(graph.counts['externalInvalidations'],0);self.assertFalse(graph.tokens)
                owner.proof(owner.state['snapshot']);self.assertGreater(graph.counts['semanticValidations'],first)
                before=graph.counts['timeInvalidations'];time.sleep(.055);graph.guard()
                self.assertGreater(graph.counts['timeInvalidations'],before);self.assertFalse(graph.tokens)
            self.assertIsNone(owner._validation_graph);self.assertEqual(commands,f.boundary.commands)

    def test_reordered_parser_literal_mapping_refuses_even_with_identical_keys_values_and_identity(self):
        f=self.fixture()
        with f.owner()as owner:
            fence=SemanticFence(owner);self.assertTrue(fence.supported,fence.unsupported)
            fence.bind(globals(),'_ORDERED_LITERAL',());fence.guard(owner)
            before=tuple(_ORDERED_LITERAL.items());identity=_ORDERED_LITERAL
            try:
                first=_ORDERED_LITERAL.pop('first');_ORDERED_LITERAL['first']=first
                self.assertIs(identity,_ORDERED_LITERAL);self.assertEqual(dict(before),_ORDERED_LITERAL)
                self.assertNotEqual(before,tuple(_ORDERED_LITERAL.items()))
                with self.assertRaises(NativeUIError):fence.guard(owner)
            finally:_ORDERED_LITERAL.clear();_ORDERED_LITERAL.update(before)

    def test_changed_referenced_nested_reader_class_global_refuses_without_method_or_class_replacement(self):
        f=self.fixture()
        with f.owner()as owner:
            fence=SemanticFence(owner);self.assertTrue(fence.supported,fence.unsupported)
            function=NestedLiteralCodec.read;code=function.__code__
            fence.bind(globals(),'NestedLiteralCodec',());fence.guard(owner)
            old=_NESTED_LITERAL['allowed']
            try:
                _NESTED_LITERAL['allowed']=False
                self.assertIs(function,NestedLiteralCodec.read);self.assertIs(code,function.__code__)
                self.assertFalse(NestedLiteralCodec().read())
                with self.assertRaises(NativeUIError):fence.guard(owner)
            finally:_NESTED_LITERAL['allowed']=old

    def test_real_json_scanner_and_encoder_heap_class_builtin_receiver_cycles_are_independently_sealed(self):
        graph=ControlGraph();classes=(json.scanner.make_scanner,json.encoder.c_make_encoder)
        for cls in classes:
            self.assertFalse(cls.__flags__&256)
            self.assertIs(vars(cls)['__new__'].__self__,cls)
        expected=graph.token(classes,'actual-json-heap-classes');graph.guard()
        self.assertLess(len(graph.nodes),100)
        self.assertEqual(expected,graph.token(classes,'independent-fresh-values'));graph.guard()

    def test_actual_class_closure_cycle_is_sealed_and_same_class_new_method_refuses(self):
        graph=ControlGraph();function=ClassClosureCodec.__init__
        cells=dict(zip(function.__code__.co_freevars,function.__closure__))
        self.assertIs(cells['__class__'].cell_contents,ClassClosureCodec)
        graph.token(ClassClosureCodec,'actual-project-class');graph.guard()
        try:
            ClassClosureCodec.__init__=replacement_command
            with self.assertRaises(UnsupportedCodec):graph.guard()
        finally:ClassClosureCodec.__init__=function
        graph.guard()

    def test_shared_literal_defaults_are_fresh_and_real_deep_literals_or_opaque_values_stay_unsupported(self):
        shared={'allowed':True};literal={'first':shared,'second':shared}
        def reader(value=literal):return value
        graph=ControlGraph();graph.token(reader,'actual-literal-default');graph.guard()
        shared['allowed']=False
        with self.assertRaises(NativeUIError):graph.guard()
        shared['allowed']=True;graph.guard()
        deep=None
        for _ in range(26):deep=[deep]
        with self.assertRaisesRegex(UnsupportedCodec,'literal-depth'):ControlGraph().token(deep)
        with self.assertRaises(UnsupportedCodec):ControlGraph().token(object())

    def test_equal_literal_alias_rebinding_changes_actual_reader_identity_and_refuses(self):
        global _ALIAS_RIGHT
        f=self.fixture()
        with f.owner()as owner:
            fence=SemanticFence(owner);self.assertTrue(fence.supported,fence.unsupported)
            fence.follow(alias_identity_reader);fence.guard(owner)
            self.assertTrue(alias_identity_reader());previous=_ALIAS_RIGHT
            try:
                _ALIAS_RIGHT=dict(_ALIAS_LEFT)
                self.assertEqual(_ALIAS_RIGHT,_ALIAS_LEFT);self.assertFalse(alias_identity_reader())
                with self.assertRaises(NativeUIError):fence.guard(owner)
            finally:_ALIAS_RIGHT=previous

    def test_complete_native_pure_import_preparation_calls_no_native_reader_or_validator_and_returns_no_authority(self):
        from adapters.native_feature_observation import NativeFeatureObservation
        from ios.adapters.audio_passive_capture_source import IOSAudioPassiveCaptureSource
        from adapters import native_account_observation,native_animation_history,recorded_preview_history
        with patch.object(NativeFeatureObservation,'read',side_effect=AssertionError('Native acquisition during import preparation')),\
             patch.object(IOSAudioPassiveCaptureSource,'query',side_effect=AssertionError('Passive control during import preparation')),\
             patch.object(native_account_observation,'validate',side_effect=AssertionError('Account verdict during import preparation')),\
             patch.object(native_animation_history,'validate',side_effect=AssertionError('Animation verdict during import preparation')),\
             patch.object(recorded_preview_history,'validate_history',side_effect=AssertionError('Audio verdict during import preparation')):
            self.assertIsNone(prepare_native_readers())
        self.assertEqual(14,len(NATIVE_READERS))
        for name in NATIVE_READERS:
            self.assertIs(type(sys.modules[name]),types.ModuleType)
            self.assertEqual(name,vars(sys.modules[name])['__name__'])

    def test_prepared_optional_native_codec_literals_and_same_contents_module_replacement_are_fenced(self):
        from adapters import native_account_observation
        f=self.fixture()
        with f.owner()as owner:
            fence=SemanticFence(owner);self.assertTrue(fence.supported,fence.unsupported);fence.guard(owner)
            version=native_account_observation.VERSION;function=native_account_observation.validate;code=function.__code__
            try:
                native_account_observation.VERSION=version+1
                self.assertIs(function,native_account_observation.validate);self.assertIs(code,function.__code__)
                with self.assertRaises(NativeUIError):fence.guard(owner)
            finally:native_account_observation.VERSION=version
            fence.guard(owner);name=native_account_observation.__name__
            clone=types.ModuleType(name);vars(clone).update(vars(native_account_observation))
            try:
                sys.modules[name]=clone
                self.assertEqual(vars(clone),vars(native_account_observation))
                with self.assertRaises(NativeUIError):fence.guard(owner)
            finally:sys.modules[name]=native_account_observation

    def test_unreviewed_even_loaded_import_and_dynamic_import_stay_unsupported_without_loader_execution(self):
        f=self.fixture()
        with f.owner()as owner:
            name='audio_unreviewed_sideeffect_reader';self.assertNotIn(name,sys.modules)
            module=types.ModuleType(name);module.value=True;sys.modules[name]=module
            try:
                fence=SemanticFence(owner);self.assertTrue(fence.supported,fence.unsupported)
                with self.assertRaisesRegex(UnsupportedCodec,'unreviewed-reader-import'):
                    fence.follow(unknown_import_reader)
                fence=SemanticFence(owner);self.assertTrue(fence.supported,fence.unsupported)
                with self.assertRaisesRegex(UnsupportedCodec,'dynamic-reader-import'):
                    fence.follow(dynamic_import_reader)
            finally:del sys.modules[name]
