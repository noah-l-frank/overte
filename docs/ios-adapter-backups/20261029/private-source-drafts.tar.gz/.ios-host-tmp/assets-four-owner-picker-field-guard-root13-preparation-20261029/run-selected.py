"""Exact7 canonical factory +6 normal picker IDs; no discovery/native/SDK execution."""
from pathlib import Path
import json,os,stat,sys,tempfile,threading,types,unittest
from importlib.machinery import PathFinder
from run_metadata import HERE,REPO,pin,proc,publication,save,sha,sources,registry_original,validate_frozen
assert len(sys.argv)==2 and sys.argv[1] in ('assets13',)
kind=sys.argv[1];plan=validate_frozen();selected=plan['suites'][kind];publication()
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/(kind+'-publication-ready-source-map.json');assert ready.is_file(),'Root must refresh after source publication'
runroot=Path(os.environ['OVERTE_ASSETS_CANONICAL_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs'/kind) and runroot!=HERE/'runs'/kind
info=runroot.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
temporary=Path(os.environ['TMPDIR']).resolve(strict=True)
assert temporary==runroot/'temporary' and Path(tempfile.gettempdir())==temporary
info=temporary.lstat();assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
assert not any(temporary.iterdir()) and not (runroot/'selected-result.json').exists()
save(runroot/'runner-process-binding.json',proc(os.getpid()))
config=json.loads((HERE/'source-root-final-map.json').read_text())
approved=json.loads(ready.read_text());ready_pin=pin(ready)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
assert approved['broadSourceRoots']==plan['broadSourceRoots']
root=REPO.stat();assert approved['worktreeRoot']==str(REPO) and approved['rootIdentity']==dict(st_dev=root.st_dev,st_ino=root.st_ino)
source_before=sources(plan);assert source_before==approved['sourcePins'],'Current full Source membership/bytes differ from after-publication map'
assert 'interface/src/main.cpp' in source_before and approved['registry']==registry_original()
for row in config['modules'].values():assert row['path'] in source_before

def spec_without_import(name):
    parts=name.split('.');search=sys.path;spec=None
    for index in range(len(parts)):
        spec=PathFinder._get_spec('.'.join(parts[:index+1]),list(search))
        assert spec is not None,name
        search=spec.submodule_search_locations
        if index<len(parts)-1:assert search is not None,name
    return spec

def preimport_source_roots():
    top_names={name.split('.')[0] for name in config['packageRoots']}
    assert not any(name.split('.')[0] in top_names for name in sys.modules),'Target imported before source preflight'
    expected=[str(REPO/name) for name in config['orderedRoots']];remaining=[]
    for item in sys.path:
        path=Path(item or os.getcwd()).resolve()
        if path==REPO or REPO in path.parents:continue
        if str(path) not in remaining:remaining.append(str(path))
    sys.path[:]=expected+remaining
    for name,relative in config['packageRoots'].items():
        spec=spec_without_import(name)
        assert [str(Path(path).resolve()) for path in spec.submodule_search_locations or ()]==[str(REPO/relative)],name
    actual={}
    for name,row in config['modules'].items():
        spec=spec_without_import(name);assert spec.origin is not None,name
        path=Path(spec.origin).resolve(strict=True)
        assert path==REPO/row['path'] and sha(path)==approved['sourcePins'][row['path']]['sha256'],name
        actual[name]=str(path)
    save(runroot/'preimport-source-map-actual.json',dict(orderedRoots=expected,modules=actual))
threads_before=set(threading.enumerate())
process_before_import=proc(os.getpid())
def current_group_processes():
    values=[]
    for path in Path('/proc').iterdir():
        if not path.name.isdecimal():continue
        value=proc(int(path.name))
        if value is not None and (value['session']==process_before_import['session'] or value['processGroup']==process_before_import['processGroup']):values.append(value)
    return values
process_baseline={(row['pid'],row['startTicks']) for row in current_group_processes()}
save(runroot/'processes-before-target-imports.json',current_group_processes())
def remaining_children():
    return [row for row in current_group_processes() if (row['pid'],row['startTicks']) not in process_baseline]
preimport_source_roots()
from ios.self_tests import test_ios_assets_image_pool_runtime as pool_fixture
from ios.self_tests import test_ios_assets_picker_prepare_recovery as picker_test_fixture
from ios.self_tests import assets_picker_fixture as node_fixture
from ios.self_tests.retained_host_roots import retain_owned_root
real_td=tempfile.TemporaryDirectory;real_mkdtemp=tempfile.mkdtemp;retained=[];objects=[];root_identities=[]
def record_root(root,kind):
    root=Path(root);info=root.lstat()
    assert root.is_relative_to(temporary) and root.resolve(strict=True)==root
    assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
    retained.append(str(root));root_identities.append(dict(root=str(root),producer=kind,device=info.st_dev,inode=info.st_ino))
    save(runroot/'created-original-roots.json',retained);save(runroot/'created-original-root-identities.json',root_identities)
    return root
def retained_directory(*args,**kwargs):
    directory=real_td(*args,**kwargs);root=record_root(directory.name,'genuineTemporaryDirectory')
    retain_owned_root(directory,expected_root=root);objects.append(directory);return directory
def observed_mkdtemp(*args,**kwargs):return str(record_root(real_mkdtemp(*args,**kwargs),'originalMkdtemp'))
def roots_guard():
    for row in root_identities:
        p=Path(row['root']);info=p.lstat();assert p.resolve(strict=True)==p and p.is_relative_to(temporary)
        assert stat.S_ISDIR(info.st_mode) and stat.S_IMODE(info.st_mode)==0o700 and info.st_uid==os.geteuid()
        assert (info.st_dev,info.st_ino)==(row['device'],row['inode'])
aliases=[(pool_fixture,pool_fixture.tempfile),(picker_test_fixture,picker_test_fixture.tempfile)]
node_original=node_fixture.subprocess;node_children=[]
def node_popen(*args,**kwargs):
    child=node_original.Popen(*args,**kwargs);node_children.append((child,proc(child.pid)));return child
node_fixture.subprocess=types.SimpleNamespace(Popen=node_popen,PIPE=node_original.PIPE,TimeoutExpired=node_original.TimeoutExpired)
case_receipts=[];case_audit_failures=[];result=None;actual_ids=[]
def nodes_since(index):
    return [dict(binding=binding,exitCode=child.poll(),stdinClosed=child.stdin.closed,stdoutClosed=child.stdout.closed,stderrClosed=child.stderr.closed)
        for child,binding in node_children[index:]]
def clean_nodes(rows):return all(x['binding'] is not None and x['exitCode'] is not None and x['stdinClosed'] and x['stdoutClosed'] and x['stderrClosed'] for x in rows)

class ImmediateResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.error_serial=0
    def startTest(self,test):
        self.case_node_start=len(node_children)
        super().startTest(test)
    def stopTest(self,test):
        # Actual unittest tearDown/doCleanups have returned before this hook.
        nodes=nodes_since(self.case_node_start)
        threads=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
        processes=remaining_children();expected_nodes=1 if 'AssetsPickerPrepareRecoveryTests' in test.id() else 0
        clean=not threads and not processes and len(nodes)==expected_nodes and clean_nodes(nodes)
        row=dict(testId=test.id(),originalCleanupsReturned=True,nodeCloseObservations=nodes,
            remainingNewThreads=threads,remainingOwnedChildren=processes,cleanAtCaseBoundary=clean)
        case_receipts.append(row)
        path=runroot/('case-stop-receipt-'+format(len(case_receipts),'06d')+'.json')
        descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(descriptor,'w') as output:
            output.write(json.dumps(row,indent=2,sort_keys=True)+'\n');output.flush();os.fsync(output.fileno())
        if not clean:case_audit_failures.append(test.id())
        super().stopTest(test)

    def report_exception(self,test,error,kind):
        import traceback
        # Preserve the original traceback immediately, BEFORE any optional
        # metadata diagnostic. Never capture generic locals or configuration.
        text=''.join(traceback.format_exception(*error))
        pending=[error[1]];seen=set();chain=[]
        while pending and len(chain)<64:
            actual=pending.pop()
            if id(actual) in seen:continue
            seen.add(id(actual));chain.append(dict(type=type(actual).__name__,module=type(actual).__module__,
                traceback=''.join(traceback.format_exception(type(actual),actual,actual.__traceback__,chain=False)),suppressContext=actual.__suppress_context__))
            for linked in (actual.__context__,actual.__cause__):
                if linked is not None:pending.append(linked)
        self.error_serial+=1
        path=runroot/('explicit-original-exception-chain-'+format(self.error_serial,'06d')+'.json')
        descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(descriptor,'w') as output:
            output.write(json.dumps(dict(testId=test.id(),event=kind,exceptions=chain),indent=2,sort_keys=True)+'\n')
            output.flush();os.fsync(output.fileno())
        self.stream.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text)
        self.stream.flush()
        descriptor=os.open(runroot/'immediate-exceptions.log',os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
        with os.fdopen(descriptor,'a') as output:
            output.write('IMMEDIATE_'+kind+' '+test.id()+'\n'+text);output.flush();os.fsync(output.fileno())
    def addError(self,test,error):
        super().addError(test,error);self.report_exception(test,error,'ERROR')
    def addFailure(self,test,error):
        super().addFailure(test,error);self.report_exception(test,error,'FAILURE')
    def addSubTest(self,test,subtest,error):
        super().addSubTest(test,subtest,error)
        if error is not None:self.report_exception(subtest,error,'SUBTEST_ERROR')

try:
    assert pool_fixture.tempfile is tempfile and picker_test_fixture.tempfile is tempfile
    pool_fixture.tempfile=types.SimpleNamespace(mkdtemp=observed_mkdtemp)
    picker_test_fixture.tempfile=types.SimpleNamespace(TemporaryDirectory=retained_directory)
    ids=selected['caseIds'];assert len(ids)==len(set(ids))==selected['count']
    loader=unittest.TestLoader();suite=loader.loadTestsFromNames(ids)
    def flatten(value):
        if isinstance(value,unittest.TestSuite):
            for child in value:yield from flatten(child)
        else:yield value
    actual_ids=[test.id() for test in flatten(suite)]
    assert not loader.errors and actual_ids==ids and suite.countTestCases()==selected['count'],(loader.errors,actual_ids)
    save(runroot/'selected-ids-actual.json',actual_ids);print('ACTUAL_SELECTED_IDS',json.dumps(actual_ids),flush=True)
    result=unittest.TextTestRunner(verbosity=2,failfast=True,resultclass=ImmediateResult).run(suite)
    assert result.testsRun==selected['count'] and not result.skipped,'All exact cases must execute without skip'
    if result.wasSuccessful():assert len(retained)==selected['expectedRetainedRootsNotProof'],'Unexpected actual root count'
finally:
    for module,original in aliases:module.tempfile=original
    node_fixture.subprocess=node_original
    assert tempfile.TemporaryDirectory is real_td and tempfile.mkdtemp is real_mkdtemp and all(m.tempfile is original for m,original in aliases)
    imported={}
    for name,module in tuple(sys.modules.items()):
        file=getattr(module,'__file__',None)
        if file is not None:
            path=Path(file).resolve()
            if REPO in path.parents:
                relative=str(path.relative_to(REPO));assert relative in source_before,(name,relative);imported[name]=relative
    save(runroot/'actual-imported-local-sources.json',imported)
    assert source_before==sources(plan) and pin(ready)==ready_pin
    assert registry_original()==approved['registry']
    def census():return {str(p.relative_to(temporary)):pin(p) for p in (temporary,*sorted(temporary.rglob('*')))}
    threads_first=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
    processes_first=remaining_children();nodes=nodes_since(0);roots_guard();first=census();second=census();roots_guard()
    save(runroot/'selected-originals-first.json',first);save(runroot/'selected-originals-second.json',second)
    threads_second=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
    processes_second=remaining_children()
    complete=result is not None and result.testsRun==selected['count'] and not result.skipped
    node_complete=len(nodes)==selected['expectedNodeChildrenNotProof'] and clean_nodes(nodes)
    report=dict(kind=kind,testsRun=None if result is None else result.testsRun,selectedIds=actual_ids,successful=complete and result.wasSuccessful() and node_complete and not case_audit_failures,
        caseStopReceipts=case_receipts,caseAuditFailures=case_audit_failures,originalProducerRoots=root_identities,originalNodeCloseObservations=nodes,
        fixtureAliasesRestored=all(m.tempfile is original for m,original in aliases),nodeProducerAliasRestored=node_fixture.subprocess is node_original,
        sourceLauncherPinsUnchanged=True,originalCensusesEqual=first==second,remainingOwnedChildrenBeforeCensuses=processes_first,remainingOwnedChildrenAfterCensuses=processes_second,
        remainingNewThreadsBeforeCensuses=threads_first,remainingNewThreads=threads_second,nativeCompiled=False,sdkExecuted=False,wholeAssetsQualified=False)
    save(runroot/'selected-result.json',report);print('ACTUAL_RESULT',json.dumps(report),flush=True)
    assert first==second and not threads_first and not threads_second and not processes_first and not processes_second and not case_audit_failures
    if complete and result.wasSuccessful():assert node_complete and len(retained)==selected['expectedRetainedRootsNotProof']
sys.exit(0 if result is not None and result.wasSuccessful() and not case_audit_failures else 1)
