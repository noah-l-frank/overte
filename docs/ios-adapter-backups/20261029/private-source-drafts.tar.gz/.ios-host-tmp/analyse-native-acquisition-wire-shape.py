from pathlib import Path
import json,hashlib
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');P=R/'.ios-host-tmp/lifecycle-original-owner-native-acquisition-join-proposal-20261028';D=R/'.ios-host-tmp/lifecycle-original-owner-motion7-cleanup-root-preparation-20261028/03-motion7/retained-first'
def snap(p):
 s=p.stat();return dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),stat=[s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns])
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
source=None
for p in D.rglob('ios-lifecycle-touch-resources-*.json'):
 v=json.loads(p.read_bytes());f=v.get('state',{}).get('frame')
 if f and 'world' in f.get('originals',{}):source=p;owner=v;old=f;break
assert source is not None;before=snap(source);binding=owner['binding'];run=owner['runId'];orig=old['originals'];joined=old['clockJoin'];nativeBefore=joined['nativeBefore'];nativeAfter=joined['nativeAfter'];world=orig['world'];geometry=orig['geometry']
# Source-confirmed model json.dumps serializer. Historical original clocks are
# preserved; this is sizing only, never a new capture or native/Source fact.
actions=['feature-native-observe','native-geometry-snapshot','feature-ios-lifecycle-world','feature-native-observe'];packets=[nativeBefore,geometry,world,nativeAfter];reads=[]
for index,(action,packet) in enumerate(zip(actions,packets),1):
 raw=json.dumps(packet);nonce=packet.get('requestId',packet.get('commandId'));query=dict(schemaVersion=1,commandId=nonce,action=action)
 if action=='feature-ios-lifecycle-world':query['runId']=run
 value=dict(originalKeeperNativeFileVersion=1,ownerInstance='0'*32,source='original-rsd-house-arrest',action=action,requestId=nonce,rawJson=raw,bytes=len(raw.encode()),sha256=hashlib.sha256(raw.encode()).hexdigest(),queryIssuanceOwned=False,freshNativeAcquisitionEstablished=False,installedCandidateBound=False,physicalFileIdentityEstablished=False,nativeMotionGuardAvailable=False,nativeTouchSupport=False,resourceRetirementEstablished=False)
 reads.append(dict(query=query,queryIndex=index,original=value))
raw_originals=dict(world=world,worldClock=orig['worldClock'],geometry=geometry);join=dict(joined,originalsSha256=hashlib.sha256(canonical(raw_originals)).hexdigest());frame=dict(originalKeeperNativeAcquisitionFrameVersion=1,originals=raw_originals,clockJoin=join,reads=reads)
body=dict(iosLifecycleNativeAcquisitionFrameVersion=1,kind='sources',binding=binding,runId=run,role='primary',index=1,frame=frame);raw=canonical(body)
# Upper-bound INTEGER representations are SIZE inputs only, not observed inode
# authority or fabricated original file facts.
ref=dict(index=1,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),device=2**64-1,inode=2**64-1)
flags=dict(nativeAcquisitionBound=False,installedCandidateBound=False,nativeMotionGuardAvailable=False,nativeTouchSupport=False,resourceRetirementEstablished=False)
result=dict(originalKeeperNativeAcquisitionVersion=1,ownerInstance='0'*32,encoding='canonical-json-ascii',acquisitionJson=canonical(dict(binding=binding,runId=run,reference=ref)).decode(),**flags)
chunks=[]
import base64
for offset in range(0,len(raw),4096):
 payload=canonical(dict(reference=ref,offset=offset,contentBase64=base64.b64encode(raw[offset:offset+4096]).decode())).decode()
 value=dict(originalKeeperNativeAcquisitionReadVersion=1,ownerInstance='0'*32,encoding='canonical-json-ascii',originalJson=payload,**flags)
 encoded=canonical(value);envelope=canonical(dict(schemaVersion=2,requestId='0'*32,ownerInstance='0'*32,status='complete',result=value))
 chunks.append(dict(offset=offset,chunkBytes=len(raw[offset:offset+4096]),escapedResultBytes=len(encoded),escapedPipeBytes=len(envelope)))
report=dict(status='READ_ONLY_SERIALIZATION_SHAPE_ANALYSIS_NO_CAPTURE_OR_CODE_EXECUTION',source=str(source),sourcePin=before,sourceAfterEqual=snap(source)==before,rawFrameBytes=len(raw),frameStoreCap=1048576,captureDTOEscapedBytes=len(canonical(result)),maxChunkEscapedResult=max(c['escapedResultBytes'] for c in chunks),maxChunkEscapedPipe=max(c['escapedPipeBytes'] for c in chunks),chunkCount=len(chunks),chunks=chunks,resultCap=12000,pipeCap=16384,qualification='Historical retained model dictionary/raw serializer sizing only; clocks unchanged; synthetic worst-width64-bit ID text used for size upper bound only, never ownership/native identity. No source/SDK/device test or fresh acquisition.')
assert report['sourceAfterEqual'] and len(raw)>12000 and len(raw)<1048576 and report['maxChunkEscapedResult']<12000 and report['maxChunkEscapedPipe']<16384
(P/'wire-shape-analysis.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('rawFrameBytes','captureDTOEscapedBytes','maxChunkEscapedResult','maxChunkEscapedPipe','chunkCount','sourceAfterEqual')},indent=2))
