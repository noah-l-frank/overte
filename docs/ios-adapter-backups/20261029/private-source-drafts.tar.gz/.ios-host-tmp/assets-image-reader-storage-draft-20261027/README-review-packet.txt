PRIVATE REVIEW PACKET — ImageReader selected runnable storage edges

Prepared against bcc8ff36981a4adf632f20dc73b4d9c7bcb1a483. No candidate has been
published, imported or executed. No configure/compiler/build/device operation
has run for this packet. All 30 small cases and one connected case are UNRUN.

Start with package-plan.json (exact25 target paths, base/draft hashes, own12
registry keys, actual dependency hash and test names). full-private-packet.patch
contains all exact changes. own-registry-hunks.patch is the only permitted
future registry edit; the candidate registry files derive committed HEAD and
must not replace the worktree's retained Photo additions.

Review order:
1. primary-source-audit.json and primary-qt-v6.11.1/source-pins.json. Four exact
   official tag files are retained with complete byte hashes and selected range
   hashes. No native/runtime result is inferred from their text.
2. libraries/material-networking/.../IOSAssetsImageReaderStorageObservation.h/.cpp
   and TextureCache.cpp. Class-specific ordinary scalar new/delete plus a gated
   derived-destructor entry; actual successful allocation/context attach; weak
   diagnostic metadata only; captured generation/State before free; no pointer
   or address lookup after free. Reentrant instrumentation fails closed before
   acquiring its metadata mutex. Native class allocation/deletion delegation
   is an explicit diagnostic-build path, not proof of the earlier compiled SDK
   virtual deleting-destructor ABI. Ordinary non-test builds retain old code.
3. tests/device/ios/adapters/assets_image_reader_storage.py. Strict independent
   History1/source1/acquisition1; all original event and thread clocks, failed
   allocation, unbound/failed constructor, actual full destructor/deallocation
   distinction, stable generation identities and complete Source1 membership.
   Allocation order is deliberately not treated as constructor/task order.
4. assets_image_storage_sources.py / assets_image_storage_ownership.py. Literal
   one-attempt query intent, immutable raw originals, WAL/frame capture, exact
   saved adoption and opened/unknown responsibility. Historical inventory grants
   no fresh product facts and always retains storage-resource responsibility.
5. assets_image_storage_lifecycle.py. Pure selected task/generation closure and
   normal Delete/Home composition with the existing image/processing joins,
   original20/1.5/3 limits and independent repeated actual sample acquisition.
   No query, input, cache/deallocator call, process or SDK effect belongs here.
6. Exact getter/header/Probe/fixture/factory hunks and closed namespace dispatch.
   Existing Processing writer gate, compact serialization and private atomic
   permissions/symlink branches remain present. Only the new Storage filename
   is added to those branches. Source1, Queue and Processing wires are unchanged.
   The image CMake target macro is a preserved pinned dependency, not re-edited.
7. Three fixtures and four test modules. Fifteen source/model/native-contract
   cases, eleven real-file WAL/inventory/routing cases, four canonical existing
   candidate/session/AFC cases; one normal deletion/deallocation connected case.
   The host allocator uses private Slot objects to MODEL native addresses and
   real held bytearray Blocks. This does not claim physical pointer reuse or
   actual C++/Qt deallocation, destructor, pool or OS memory execution.
8. ASSETS_IMAGE_STORAGE_SOURCE.txt / ASSETS_IMAGE_PROCESSING_SOURCE.txt contain
   the proposed English guides, kept as private TXT until source publication.

Important negatives are concrete code: an expired derived marker and complete
body cannot hide an unreturned global delete; an old delete return stays on its
captured generation after a model address Slot is reused; failed allocation and
constructor-only matching delete do not create a complete normal destructor;
wrong source/task/resource/process, missing allocation prefix, rewritten phase,
known weak resurrection and failure healing fail closed. Full Probe execution
consumes a nonce once; pure joins forbid file writes, queries, processes/sockets.
All current SDK/native/candidate boundaries remain explicitly modeled.

The connected code first establishes the existing processing edges while the
declared allocator still holds free-return barriers. Storage closure must
refuse. Only the test driver releases its own barrier; fresh repeated samples
then join. Exactly one normal Delete/Home, pure effects, immutable file census
and the full session inventory are checked; all Resource responsibilities stay.

Required later: coordinated source publication followed by review-selected
no-build tests, actual matching SDK compile/link/deleting ABI, native allocator
and constructor-failure dispatch, plus separate generation-aware QThreadPool
admission/removal/running observations. Byte copies, pool, plugin/decoded data,
physical GPU/fences/recycler, actor/backend/process/SDK and whole Resource end
remain false/unavailable. This packet does not increase the5/14 completed count.
