"""Reviewable private weak-owner bridge; never apply to Repo/SDK here."""
from pathlib import Path
import hashlib,json,difflib

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
NAMES=('tests/device/native/IOSAssetsModelOrigin.h','tests/device/native/IOSAssetsImageReaderObservation.h',
    'libraries/material-networking/src/material-networking/IOSAssetsImageReaderQueueObservation.h',
    'libraries/material-networking/src/material-networking/IOSAssetsImageReaderQueueObservation.cpp')


def once(text,old,new):
    assert text.count(old)==1,old[:100]
    return text.replace(old,new,1)


lookup='''    // Pure weak-control-block identity lookup. Never create a group, dereference
    // a Source, inspect URLs/payloads, or enter a Material object/mutex or GPU.
    // Health below is the existing static lock-free Material atomic only.
    QVariantMap textureSources(const QVector<std::weak_ptr<const void>>& sources) {
        if (!enabled() || !main() || sources.size()>512) {return {};}
        QMutexLocker lock(&_mutex);QVariantList ids,states;
        const std::weak_ptr<const void> empty;
        for (const auto& source:sources) {
            QString selected=QStringLiteral("");
            // An expired nonempty weak owner still has its original control-block
            // identity. It must not be confused with an empty unknown weak value.
            const bool known=source.owner_before(empty) || empty.owner_before(source);
            if (known) {
                for (const auto& row:_textures) {
                    if (row.kind=="source" && !row.holder.owner_before(source) && !source.owner_before(row.holder)) {
                        if (!selected.isEmpty()) {return {};}
                        selected=row.id;
                    }
                }
            }
            ids.append(selected);states.append(!known ? QStringLiteral("empty") : selected.isEmpty() ? QStringLiteral("unmatched") : QStringLiteral("matched"));
        }
        return {{"instance",_instance},{"revision",_textureRevision},{"clock",stamp()},
            {"complete",_complete && graphics::Material::featureAssetsTextureObservationComplete()},
            {"sourceIds",ids},{"sourceStates",states}};
    }
'''
pins={};patch=[]
for name in NAMES:
    before=(REPO/name).read_text();text=before;pins[name]=hashlib.sha256(before.encode()).hexdigest()
    if name.endswith('IOSAssetsModelOrigin.h'):
        text=once(text,'    void textureIncomplete() noexcept {',lookup+'    void textureIncomplete() noexcept {')
    elif name.endswith('IOSAssetsImageReaderObservation.h'):
        public='''#if defined(OVERTE_IOS_E2E_TEST_BUILD)
    struct TextureContexts {
        QString instance;QVariantMap clock;bool complete{false};
        QVector<IOSAssetsImageReaderQueueObservation::Context> tasks,receivers;
    };
    static TextureContexts textureSourceContexts() noexcept {
        if (!enabled() || !main()) {return {};}
        QT_TRY {
            auto& owner=state();QMutexLocker lock(&owner.mutex);TextureContexts result;
            result.instance=owner.instance;result.complete=!failed().load();
            for (const auto& task:owner.tasks) {
                IOSAssetsImageReaderQueueObservation::Context row;row.ownerInstance=owner.instance;
                row.taskId=task.value.value("id").toString();row.resourceId=task.value.value("resourceId").toString();
                row.source=task.source;result.tasks.append(row);
            }
            for (const auto& receiver:owner.receivers) {
                IOSAssetsImageReaderQueueObservation::Context row;row.ownerInstance=owner.instance;
                row.receiverId=receiver.value.value("id").toString();row.resourceId=receiver.value.value("resourceId").toString();
                row.source=receiver.source;result.receivers.append(row);
            }
            result.clock=owner.clock();return result;
        } QT_CATCH (...) {return {};}
    }
#endif
'''
        text=once(text,'    static QVariantMap snapshot() noexcept {',public+'    static QVariantMap snapshot() noexcept {')
        text=once(text,'                result.receiverId=row.value.value("id").toString();',
                  '                result.source=row.source;\n                result.receiverId=row.value.value("id").toString();')
        text=once(text,'                result.taskId=task.value.value("id").toString();result.dispatchId=row.value.value("id").toString();',
                  '                result.source=task.source;\n                result.taskId=task.value.value("id").toString();result.dispatchId=row.value.value("id").toString();')
    elif name.endswith('.h'):
        text=once(text,'#include <QVariantMap>','#include <QVariantMap>\n#include <memory>')
        text=once(text,'        QPointer<QObject> receiver;',
                  '        QPointer<QObject> receiver;\n        std::weak_ptr<const void> source;')
    else:
        text=once(text,'#include "IOSAssetsImageReaderQueueObservation.h"',
            '#include "IOSAssetsImageReaderQueueObservation.h"\n#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD)\n#include "../../../../tests/device/native/IOSAssetsModelOrigin.h"\n#include "../../../../tests/device/native/IOSAssetsImageReaderObservation.h"\n#endif')
        text=once(text,'    Observation::Context context;',
                  '    Observation::Context context;\n    std::weak_ptr<const void> receiverSource;')
        text=once(text,'            entry.value["receiverId"] = context.receiverId;',
                  '            entry.receiverSource = context.source;\n            entry.value["receiverId"] = context.receiverId;')
        text=once(text,'        QVariantMap result;\n',
                  '        QVariantMap result;\n        QVector<std::weak_ptr<const void>> receiverSources;\n')
        text=once(text,'                entries.append(value);',
                  '                entries.append(value);\n                receiverSources.append(entry.receiverSource);')
        text=once(text,'{"assetImageReaderQueueHistoryVersion", 1}',
                  '{"assetImageReaderQueueHistoryVersion", 2}')
        anchor='        // Disarm/failure racing a snapshot cannot return a former complete result.\n'
        addition='''        // Release Bridge BEFORE Source1, then release Source1 BEFORE H5.
        // The full Source1 task prefix includes tasks with no dispatch yet; a
        // dispatched-only table could hide a selected pending reader.
        const auto taskContexts=IOSAssetsImageReaderObservation::textureSourceContexts();
        if (!taskContexts.complete || taskContexts.instance!=result.value("source1Instance")
                || taskContexts.tasks.size()>64 || taskContexts.receivers.size()>256) {fail();return {};}
        QVector<std::weak_ptr<const void>> sources;
        for (const auto& task:taskContexts.tasks) {sources.append(task.source);}
        for (const auto& receiver:taskContexts.receivers) {sources.append(receiver.source);}
        // H5 compares weak owners only, including expired control blocks. No
        // lookup creates a group or enters Source1/Bridge/Material object locks/GPU;
        // H5 health uses only the existing static lock-free Material atomic.
        const auto linked=IOSAssetsModelOrigin::shared().textureSources(sources);
        const auto ids=linked.value("sourceIds").toList();
        const auto states=linked.value("sourceStates").toList();
        auto entries=result.value("entries").toList();
        if (linked.isEmpty() || !linked.value("complete").toBool()
                || ids.size()!=taskContexts.tasks.size()+taskContexts.receivers.size() || states.size()!=ids.size()) {fail();return {};}
        QVariantList taskSources;
        for (int index=0;index<taskContexts.tasks.size();++index) {
            const auto& task=taskContexts.tasks[index];
            taskSources.append(QVariantMap{{"taskId",task.taskId},{"resourceId",task.resourceId},
                {"textureSourceId",ids[index]},{"textureSourceState",states[index]}});
        }
        QVariantList receiverTable;
        for (int index=0;index<taskContexts.receivers.size();++index) {
            const auto& receiver=taskContexts.receivers[index];const int offset=taskContexts.tasks.size()+index;
            receiverTable.append(QVariantMap{{"receiverId",receiver.receiverId},{"resourceId",receiver.resourceId},
                {"textureSourceId",ids[offset]},{"textureSourceState",states[offset]}});
        }
        for (int index=0;index<entries.size();++index) {
            auto row=entries[index].toMap();const auto receiverId=row.value("receiverId").toString();
            QString selected=QStringLiteral(""),state=QStringLiteral("not-observed");
            if (!receiverId.isEmpty()) {
                int found=-1;
                for (int candidate=0;candidate<taskContexts.receivers.size();++candidate) {
                    if (taskContexts.receivers[candidate].receiverId==receiverId) {
                        if (found>=0) {fail();return {};}found=candidate;
                    }
                }
                if (found<0) {fail();return {};}
                const auto& actual=taskContexts.receivers[found];
                if (actual.resourceId!=row.value("resourceId").toString()
                        || actual.source.owner_before(receiverSources[index])
                        || receiverSources[index].owner_before(actual.source)) {fail();return {};}
                selected=ids[taskContexts.tasks.size()+found].toString();state=states[taskContexts.tasks.size()+found].toString();
            }
            row["receiverTextureSourceId"]=selected;row["receiverTextureSourceState"]=state;entries[index]=row;
        }
        result["entries"]=entries;
        result["taskTextureSources"]=taskSources;
        result["receiverTextureSources"]=receiverTable;
        result["source1TextureReference"]=QVariantMap{{"instance",taskContexts.instance},
            {"clockDomain","native-assets-image-reader-observer"},{"clock",taskContexts.clock}};
        result["originTextureReference"]=QVariantMap{{"instance",linked.value("instance")},
            {"revision",linked.value("revision")},{"clockDomain","native-assets-model-origin"},
            {"clock",linked.value("clock")}};
'''
        text=once(text,anchor,addition+anchor)
    target=HERE/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
    patch.extend(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='a/'+name,tofile='b/'+name,n=3))
(HERE/'native-original-sha256.json').write_text(json.dumps(pins,indent=2)+'\n')
(HERE/'native-own-hunks.patch').write_text(''.join(patch).replace('\n \n','\n\n'))
