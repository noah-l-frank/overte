"""Historical Assets ownership before ordinary installed session operations.

The existing owner decoders inspect original private data without constructing
live transports. No SDK, candidate read, native query, input, timestamp or
retirement is produced here. An upload's client retirement never establishes
server/oven/blob retirement; that outstanding responsibility remains blocking.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from functools import wraps
from pathlib import Path
import re
import time
from types import SimpleNamespace
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState,context
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same
from feature_journeys.contract import identifier
from ios.adapters.assets_files import OwnedAssetsFiles
from ios.adapters.assets_file_sources import FileSources
from ios.adapters.assets_reply_sources import ReplySources
from ios.adapters.assets_picker import OwnedAssetsPicker
from ios.adapters.assets_reply_owner import OwnedAssetsReplyReads
from ios.adapters.assets_upload import OwnedAssetsUpload
from ios.adapters.assets_tree_owner import OwnedAssetsTree
from ios.adapters.assets_backend_owner import OwnedAssetsBackend,BackendSegments
from ios.adapters.assets_usage_owner import OwnedAssetsUsage
from ios.adapters.assets_baking_owner import OwnedAssetsBaking
from ios.adapters.assets_model_sources import AssetsModelSources
from ios.adapters.assets_model_raw_sources import ModelRawSources
from ios.adapters.assets_model_owner import OwnedAssetsModel
from ios.adapters.assets_parsed_sources import AssetsParsedSources,ParsedRawSources
from ios.adapters.assets_parsed_owner import OwnedAssetsParsedInput
from ios.adapters.assets_model_removal import OwnedAssetsModelRemoval
from ios.adapters.assets_baked_tree import OwnedAssetsBakedTree

OWNER=re.compile(r'ios-assets-([a-f0-9]{32})-(primary|actor)-(files|picker|replies|upload|tree|backend|usage|baking|model-sources|model|parsed-sources|parsed|model-removal|baked-tree)\.json')
FRAME=re.compile(r'assets-upload-frame-sources-([a-f0-9]{32})-(primary|actor)-[0-9]{4}-[a-f0-9]{64}\.json')
BACKEND_FRAME=re.compile(r'assets-backend-(primary|actor)-parts-frame-sources-([a-f0-9]{32})-(primary|actor)-[0-9]{4}-[a-f0-9]{64}\.json')
FILE_SOURCE=re.compile(r'assets-files-native-frame-sources-([a-f0-9]{32})-(primary|actor)-[0-9]{4}-[a-f0-9]{64}\.json')
FILE_MIGRATION=re.compile(r'assets-files-migration-([a-f0-9]{32})-(primary|actor)\.json')
REPLY_SOURCE=re.compile(r'assets-replies-native-frame-sources-([a-f0-9]{32})-(primary|actor)-[0-9]{4}-[a-f0-9]{64}\.json')
REPLY_MIGRATION=re.compile(r'assets-replies-migration-([a-f0-9]{32})-(primary|actor)\.json')
MODEL_FRAME=re.compile(r'assets-model-(?:source|native)-frame-sources-([a-f0-9]{32})-(primary|actor)-[0-9]{4}-[a-f0-9]{64}\.json')
PARSED_FRAME=re.compile(r'assets-parsed-(?:source|native)-frame-sources-([a-f0-9]{32})-(primary|actor)-[0-9]{4}-[a-f0-9]{64}\.json')


def forbidden(*_args,**_kwargs):raise RuntimeError('Historical Assets inspection cannot acquire or write sources')


def directory_entries(directory):
    directory=Path(directory)
    if not directory.exists():return []
    PrivateFeatureState(directory/'assets-read-boundary.json')._parent()
    result=list(directory.iterdir());need(len(result)<=4096);return sorted(result,key=lambda path:path.name)


def inspect_directory(directory,*,primary_directory=None,_contexts=None,image_context=None):
    """Return private responsibilities, not fresh product-state observations."""
    from ios.adapters.assets_scene_ownership import scene_path,inspect_scenes
    from ios.adapters.assets_image_reader_lifecycle_ownership import lifecycle_path,inspect_lifecycles
    from ios.adapters.assets_image_ownership import ImageInventoryContext,inventory_path,inspect_session
    need(image_context is None or isinstance(image_context,ImageInventoryContext))
    directory=Path(directory);entries=directory_entries(directory);groups={};frame_paths={};backend_paths={};file_paths={};reply_paths={};model_paths={};parsed_paths={}
    for path in entries:
        if inventory_path(path.name):
            need(image_context is not None);continue
        if scene_path(path.name) or lifecycle_path(path.name):continue
        match=OWNER.fullmatch(path.name)
        if match:
            run,role,kind=match.groups();identifier(run);groups.setdefault((run,role),{})[kind]=(path,PrivateFeatureState(path).read());continue
        match=FRAME.fullmatch(path.name)
        if match:frame_paths.setdefault(match.groups(),set()).add(path);continue
        match=BACKEND_FRAME.fullmatch(path.name)
        if match:
            subject,run,role=match.groups();need(subject==role);backend_paths.setdefault((run,role),set()).add(path);continue
        match=FILE_SOURCE.fullmatch(path.name) or FILE_MIGRATION.fullmatch(path.name)
        if match:file_paths.setdefault(match.groups(),set()).add(path);continue
        match=REPLY_SOURCE.fullmatch(path.name) or REPLY_MIGRATION.fullmatch(path.name)
        if match:reply_paths.setdefault(match.groups(),set()).add(path);continue
        match=MODEL_FRAME.fullmatch(path.name)
        if match:model_paths.setdefault(match.groups(),set()).add(path);continue
        match=PARSED_FRAME.fullmatch(path.name)
        if match:parsed_paths.setdefault(match.groups(),set()).add(path);continue
        need(not path.name.startswith(('ios-assets-','assets-upload-','assets-backend-','assets-files-','assets-replies-','assets-model-','assets-parsed-','assets-scene-','assets-image-reader-')))
    need(len(groups)<=64 and all(set(paths)<=set(groups) for paths in (frame_paths,backend_paths,file_paths,reply_paths,model_paths,parsed_paths)));result=[]
    image_parsed=None;image_url=None
    for (run,role),records in sorted(groups.items()):
        need(all(type(value) is dict for _path,value in records.values()))
        values={kind:value for kind,(_path,value) in records.items()};bindings=[context(value.get('binding')) for value in values.values()]
        need(bindings and all(same(bindings[0],binding) for binding in bindings));binding=bindings[0]
        need(re.fullmatch('[1-9][0-9]{0,15}',binding['processIdentity']) is not None);pid=int(binding['processIdentity'])
        urls=[value['fixtureUrl'] for kind,value in values.items() if kind in ('files','replies','backend')]
        need(urls and all(url==urls[0] for url in urls));url=urls[0]
        # These are pure codec contexts, not alternate/live managers. Their
        # constructors are deliberately not called; no transports or clocks
        # can be acquired, and every attempted write is explicitly forbidden.
        files=object.__new__(OwnedAssetsFiles);files.native=SimpleNamespace(pid=pid,monotonic=time.monotonic);files.run,files.url,files.binding=run,url,deepcopy(binding)
        files.state=None;files.role=role;file_covered=set();migration_pending=False
        if 'files' in values:
            files.store=PrivateFeatureState(records['files'][0]);files.sources=FileSources(files,role,lambda:True,forbidden)
            files.state=files.decode(values['files']);file_covered=files.sources.owned_paths()
            if files.storage_version==1:
                extra=files.sources.legacy_migration_paths();file_covered|=extra;migration_pending=bool(extra)
        need(file_paths.get((run,role),set())==file_covered)
        picker=object.__new__(OwnedAssetsPicker);picker.files,picker.binding=files,deepcopy(binding);picker.state=None
        if 'picker' in values:
            need(files.state is not None);picker.state=picker.decode(values['picker'])
        replies=object.__new__(OwnedAssetsReplyReads);replies.native=SimpleNamespace(pid=pid,monotonic=time.monotonic);replies.run,replies.url,replies.binding=run,url,deepcopy(binding);replies.state=None
        reply_covered=set();reply_migration_pending=False;replies.role=role
        if 'replies' in values:
            replies.store=PrivateFeatureState(records['replies'][0]);replies.sources=ReplySources(replies,role,lambda:True,forbidden);replies.state=replies.decode(values['replies']);reply_covered=replies.sources.owned_paths()
            if replies.storage_version==1:
                extra=replies.sources.legacy_migration_paths();reply_covered|=extra;reply_migration_pending=bool(extra)
        need(reply_paths.get((run,role),set())==reply_covered)
        upload=None;tree=None;backend=None;usage=None;baking=None;model_source=None;model=None;parsed_source=None;parsed=None;removal=None;baked_tree=None;covered=set();backend_covered=set();model_covered=set();parsed_covered=set()
        if 'upload' in values:
            need(files.state is not None and picker.state is not None and replies.state is not None)
            upload=object.__new__(OwnedAssetsUpload);upload.files,upload.picker,upload.replies=files,picker,replies
            upload.store=PrivateFeatureState(records['upload'][0]);upload.previous=deepcopy(values['upload'])
            upload.binding,upload.role,upload.clock=deepcopy(binding),role,SimpleNamespace(pid=pid)
            upload.state=None;upload._cached=[];upload._validated_refs=[];upload._projects=[]
            upload.originals=OriginalFrameStore(directory,binding,run,role,lambda:True,forbidden,namespace='assets-upload',schema_prefix='iosAssetsUpload')
            upload.state=upload.decode(values['upload']);state=upload.state
            need(picker.state['phase']=='primary-chosen' and state['page']==picker.state['page'] and state['picker']==picker.state['picker'])
            for ref in state['frames']:covered.add(upload.originals.path(upload.originals.expand(ref)))
            if state['pending'] is not None and state['pending']['original'] is not None:covered.add(upload.originals.path(state['pending']['original']))
        if 'tree' in values:
            need(upload is not None);tree=object.__new__(OwnedAssetsTree);tree.upload=upload;tree.state=None;tree.state=tree.decode(values['tree'])
        if 'usage' in values:
            need(upload is not None);usage=object.__new__(OwnedAssetsUsage);usage.source=upload;usage.store=PrivateFeatureState(records['usage'][0]);usage.previous=deepcopy(values['usage']);usage.state=None;usage.state=usage.decode(values['usage'])
        need(frame_paths.get((run,role),set())==covered)
        if 'backend' in values:
            backend=object.__new__(OwnedAssetsBackend);backend.upload=upload if upload is not None else SimpleNamespace(files=files,state=None)
            backend.binding,backend.run,backend.role=deepcopy(binding),run,role;backend.config=deepcopy(values['backend']['backendConfiguration'])
            backend.parts=BackendSegments(directory,binding,run,role,role,lambda:True,forbidden,monotonic=time.monotonic)
            backend.state=backend.decode(values['backend'])
            for row in backend.state['samples']:
                if row['parts'] is not None:
                    for reference in row['parts']['chunks']:
                        if reference['phase']!='planned':backend_covered.add(backend.parts.store.path(reference))
        need(backend_paths.get((run,role),set())==backend_covered)
        if 'baking' in values:
            need(usage is not None and backend is not None);baking=object.__new__(OwnedAssetsBaking);baking.usage,baking.backend=usage,backend;baking.previous=deepcopy(values['baking']);baking.state=None;baking.state=baking.decode(values['baking'])
        if 'model-sources' in values:
            need(usage is not None);model_source=object.__new__(AssetsModelSources);model_source.usage=usage;model_source.native=SimpleNamespace(pid=pid,monotonic=time.monotonic)
            model_source.binding,model_source.run,model_source.role=deepcopy(binding),run,role;model_source.store=PrivateFeatureState(records['model-sources'][0]);model_source._cached=[]
            model_source.raws=ModelRawSources(model_source,role,lambda:True,forbidden);model_source.originals=OriginalFrameStore(directory,binding,run,role,lambda:True,forbidden,namespace='assets-model-source',schema_prefix='iosAssetsModelSource')
            model_source.state=model_source.decode(values['model-sources']);model_covered|=model_source.raws.owned_paths()
            for reference in model_source.state['frames']:model_covered.add(model_source.originals.path(model_source.originals.expand(reference)))
            pending=[row['pending'] for row in model_source.state['interrupted']]+([model_source.state['pending']] if model_source.state['pending'] is not None else [])
            for row in pending:
                if row['original'] is not None and row['original']['phase']!='planned':model_covered.add(model_source.originals.path(row['original']))
        need(model_paths.get((run,role),set())==model_covered)
        if 'model' in values:
            need(usage is not None and model_source is not None);model=object.__new__(OwnedAssetsModel);model.usage,model.sources=usage,model_source;model.previous=deepcopy(values['model']);model.state=None;model.state=model.decode(values['model'])
        if 'parsed-sources' in values:
            need(model is not None);parsed_source=object.__new__(AssetsParsedSources);parsed_source.usage,parsed_source.model=usage,model
            parsed_source.native=SimpleNamespace(pid=pid,monotonic=time.monotonic);parsed_source.binding,parsed_source.run,parsed_source.role=deepcopy(binding),run,role
            parsed_source.store=PrivateFeatureState(records['parsed-sources'][0]);parsed_source._cached=[]
            parsed_source.raws=ParsedRawSources(parsed_source,role,lambda:True,forbidden)
            parsed_source.originals=OriginalFrameStore(directory,binding,run,role,lambda:True,forbidden,namespace='assets-parsed-source',schema_prefix='iosAssetsParsedSource')
            parsed_source.state=parsed_source.decode(values['parsed-sources']);parsed_covered|=parsed_source.raws.owned_paths()
            for reference in parsed_source.state['frames']:parsed_covered.add(parsed_source.originals.path(parsed_source.originals.expand(reference)))
            pending=[row['pending'] for row in parsed_source.state['interrupted']]+([parsed_source.state['pending']] if parsed_source.state['pending'] is not None else [])
            for row in pending:
                if row['original'] is not None and row['original']['phase']!='planned':parsed_covered.add(parsed_source.originals.path(row['original']))
        need(parsed_paths.get((run,role),set())==parsed_covered)
        if 'parsed' in values:
            need(parsed_source is not None and baking is not None);parsed=object.__new__(OwnedAssetsParsedInput);parsed.sources,parsed.model,parsed.baking=parsed_source,model,baking
            parsed.store=PrivateFeatureState(records['parsed'][0]);parsed.previous=deepcopy(values['parsed']);parsed.state=None;parsed.state=parsed.decode(values['parsed'])
        if image_context is not None and (run,role)==(image_context.run,'primary'):
            need(parsed is not None and same(binding,image_context.binding));parsed.lock=image_context.lock
            image_parsed,image_url=parsed,url
        if 'model-removal' in values:
            need(parsed is not None and parsed.state['phase']=='observed');removal=object.__new__(OwnedAssetsModelRemoval)
            removal.parsed,removal.model,removal.sources,removal.usage,removal.pid=parsed,model,parsed_source,usage,pid
            removal.state=None;removal.state=removal.decode(values['model-removal'])
        if 'baked-tree' in values:
            need(parsed is not None and parsed.state['phase']=='observed');baked_tree=object.__new__(OwnedAssetsBakedTree)
            baked_tree.parsed,baked_tree.backend,baked_tree.upload=parsed,backend,upload;baked_tree.state=None;baked_tree.state=baked_tree.decode(values['baked-tree'])
        responsibilities=[]
        if files.state is not None and files.state['phase']!='retired':responsibilities.append('input-files')
        if files.state is not None and (migration_pending or files.sources.pending is not None):responsibilities.append('input-source-write')
        if picker.state is not None and picker.state['phase']!='retired' and upload is None:responsibilities.append('picker')
        if replies.state is not None and replies.state['phase']!='closed':responsibilities.append('read-leases')
        if replies.state is not None and (reply_migration_pending or replies.sources.pending is not None):responsibilities.append('read-source-write')
        if upload is not None:
            if upload.state['phase']!='retired':responsibilities.append('upload-client')
            if backend is None or backend.state['phase']!='restored':responsibilities.append('server-retirement')
        elif backend is not None:responsibilities.append('server-retirement')
        if tree is not None and tree.state['clientClosedBy'] is None:responsibilities.append('mapping-actions')
        if baked_tree is not None:
            if baked_tree.state['phase']!='deleted':responsibilities.append('baked-mapping-actions')
            if baked_tree.state['clientClosedBy'] is None:responsibilities.append('baked-mapping-client')
        if usage is not None:
            if usage.state['clientClosedBy'] is None:responsibilities.append('usage-client')
            # A closed dialog/page and its ordinary input ACK never establish
            # destruction of an entity/model/resource created by acceptance.
            if any(entry['id']=='assets.model.accept' and entry['command'] is not None for entry in usage.state['inputs']):responsibilities.append('usage-model-retirement')
        if baking is not None and baking.state['phase']!='qualified' and not (usage.state['clientClosedBy'] is not None and backend.state['phase']=='restored'):responsibilities.append('baking-actions')
        if model_source is not None and (model_source.state['pending'] is not None or model_source.raws.pending is not None):responsibilities.append('model-source-write')
        # Geometry observation deliberately supplies no origin/resource lifetime
        # verdict. The earlier Usage accept responsibility remains blocking.
        if model is not None and any(entry['slot']=='usage-accept-model' and entry['command'] is not None for entry in usage.state['inputs']):responsibilities.append('model-resource-origin')
        if parsed_source is not None and (parsed_source.state['pending'] is not None or parsed_source.raws.pending is not None):responsibilities.append('parsed-source-write')
        if parsed is not None:responsibilities.append('parsed-resource-retirement')
        if removal is not None:
            if removal.state['phase']!='model-gone':responsibilities.append('model-removal')
            if removal.state['contextClosedBy'] is None:responsibilities.append('model-removal-context')
            # Local entity/Model death never retires cached QObject/HFM or the
            # earlier origin, rendering, actor or server responsibilities.
            responsibilities.append('model-removal-resources')
        result.append(dict(runId=run,role=role,binding=deepcopy(binding),responsibilities=responsibilities,
            successor=upload is not None,clientRetired=upload is not None and upload.state['phase']=='retired'))
        if _contexts is not None:_contexts[(run,role)]=dict(parsed=parsed)
        for kind,(path,value) in records.items():need(same(PrivateFeatureState(path).read(),value))
    result+=inspect_scenes(directory,entries,primary_directory=primary_directory)
    result+=inspect_lifecycles(directory,entries)
    if image_context is not None:
        need(image_parsed is not None);report=inspect_session(directory,image_context,image_parsed,image_url)
        result.append({key:value for key,value in report.items() if key!='paths'})
    need([path.name for path in directory_entries(directory)]==[path.name for path in entries]);return result


def owners_absent(adapter,selector):
    return not any(row['responsibilities'] for row in inspect_directory(adapter.state_path(selector).parent))


def ensure_released(adapter,selector):
    need(owners_absent(adapter,selector));return True


def installed_entry(function):
    @wraps(function)
    def invoke(adapter,selector,operation,values):
        ensure_released(adapter,selector);return function(adapter,selector,operation,values)
    return invoke
