module.exports = {kind: "create-marker-v1"};
