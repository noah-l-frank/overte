from contextlib import ExitStack
from copy import deepcopy
import builtins,hashlib,json,os,socket,subprocess,time,traceback
from pathlib import Path
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.assets_session_owners import inspect_directory
from ios.adapters.assets_model_removal import OwnedAssetsModelRemoval
root=Path('.ios-host-tmp/assets-geometry-release-flow-t4qlg6qx').resolve(strict=True)
run='a'*32

def census():
 return {p.name:(p.stat().st_dev,p.stat().st_ino,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.iterdir() if p.is_file()}
before=census();forbidden={};error=None;proof=None;started=time.monotonic()
def refuse(name):
 def fail(*args,**kwargs):
  forbidden[name]=forbidden.get(name,0)+1;raise AssertionError('readonly diagnostic '+name)
 return fail
ordinary_open=builtins.open;descriptor_open=os.open
def open_readonly(file,mode='r',*args,**kwargs):
 if any(x in mode for x in 'wax+'):return refuse('open-write')()
 return ordinary_open(file,mode,*args,**kwargs)
def descriptor_readonly(path,flags,*args,**kwargs):
 if flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):return refuse('os-open-write')()
 return descriptor_open(path,flags,*args,**kwargs)
with ScriptSourceLock(root/'script-feature-sources.lock').held(),ExitStack() as stack:
 for name in ('socket.socket','socket.create_connection','subprocess.Popen','urllib.request.build_opener',
  'adapters.asset_backend_client.build_opener','ios.adapters.feature_observation.FeatureObservation.send',
  'adapters.native_feature_observation.NativeFeatureObservation.read','ios.adapters.normal_input.NativeInput.capture',
  'ios.adapters.normal_input.NativeInput.deliver'):
  stack.enter_context(patch(name,side_effect=refuse(name)))
 stack.enter_context(patch('builtins.open',side_effect=open_readonly));stack.enter_context(patch('os.open',side_effect=descriptor_readonly))
 for name in ('unlink','rename','replace','remove','mkdir','rmdir'):stack.enter_context(patch('os.'+name,side_effect=refuse(name)))
 for cls,name in ((PrivateFeatureState,'write'),(PrivateFeatureState,'discard'),(OriginalFrameStore,'write')):stack.enter_context(patch.object(cls,name,side_effect=refuse(name)))
 try:
  contexts={};inspect_directory(root,_contexts=contexts);parsed=contexts[(run,'primary')]['parsed']
  owner=object.__new__(OwnedAssetsModelRemoval);owner.parsed,owner.model,owner.sources=parsed,parsed.model,parsed.sources
  owner.usage,owner.pid=parsed.model.usage,parsed.sources.native.pid
  owner.store=PrivateFeatureState(root/('ios-assets-'+run+'-primary-model-removal.json'));owner.previous=owner.store.read();owner.state=owner.decode(owner.previous)
  proof=owner.removed()
 except Exception as caught:
  error=dict(type=type(caught).__name__,location=[dict(file=Path(x.filename).name,line=x.lineno,function=x.name) for x in traceback.extract_tb(caught.__traceback__)])
after=census();assert before==after and not forbidden
print(json.dumps(dict(seconds=round(time.monotonic()-started,3),files=len(before),unchanged=before==after,forbidden=forbidden,error=error,proof=proof),sort_keys=True))
