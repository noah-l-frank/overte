from pathlib import Path
import json,hashlib,os
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');P=R/'.ios-host-tmp/lifecycle-original-owner-native-query-owner-proposal-20261028'
D=R/'.ios-host-tmp/lifecycle-original-owner-motion7-cleanup-root-preparation-20261028/03-motion7/retained-first'
def snap(p):
 s=p.stat();return dict(path=str(p),dev=s.st_dev,ino=s.st_ino,size=s.st_size,mode=s.st_mode,mtimeNs=s.st_mtime_ns,ctimeNs=s.st_ctime_ns,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
files=sorted(p for p in D.rglob('*') if p.is_file());before=[snap(p) for p in files];samples={};occurrences={}
def walk(v,path,route):
 if isinstance(v,dict):
  kind=None
  if v.get('iosLifecycleWorldVersion') in (1,2) and 'requestId' in v and 'source' in v:kind='world'
  elif v.get('schemaVersion')==1 and all(k in v for k in ('requestId','processId','capturedEpochMs','graphics')):kind='native-clock'
  elif v.get('schemaVersion')==1 and 'commandId' in v and isinstance(v.get('observation'),dict) and 'nativeUi' in v['observation']:kind='geometry'
  if kind:
   canonical=json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode();key=(kind,hashlib.sha256(canonical).hexdigest())
   occurrences[kind]=occurrences.get(kind,0)+1
   if key not in samples:
    # The existing Python model Boundary.original uses json.dumps(value).
    # This is measured serialization of a retained typed dictionary, not an
    # assertion that its original native-file whitespace was retained.
    raw=json.dumps(v);action={'world':'feature-ios-lifecycle-world','native-clock':'feature-native-observe','geometry':'native-geometry-snapshot'}[kind]
    request=v.get('requestId',v.get('commandId'));result=dict(originalKeeperNativeFileVersion=1,ownerInstance='0'*32,source='original-rsd-house-arrest',action=action,requestId=request,rawJson=raw,bytes=len(raw.encode()),sha256=hashlib.sha256(raw.encode()).hexdigest(),queryIssuanceOwned=False,freshNativeAcquisitionEstablished=False,installedCandidateBound=False,physicalFileIdentityEstablished=False,nativeMotionGuardAvailable=False,nativeTouchSupport=False,resourceRetirementEstablished=False)
    encoded=json.dumps(result,separators=(',',':'),ensure_ascii=True).encode();packet=json.dumps(dict(schemaVersion=2,requestId='r'*128,ownerInstance='0'*32,status='complete',result=result),separators=(',',':'),ensure_ascii=True).encode()
    samples[key]=dict(kind=kind,path=str(path),jsonPath=route,typedDictionarySha256=key[1],modelDefaultSerializedBytes=len(raw.encode()),escapedResultBytes=len(encoded),escapedPipeEnvelopeBytes=len(packet),withinResult12000=len(encoded)<=12000,withinPipe16384=len(packet)<=16384)
  for k,w in v.items():walk(w,path,route+'.'+k)
 elif isinstance(v,list):
  for i,w in enumerate(v):walk(w,path,route+'['+str(i)+']')
for p in files:
 try:walk(json.loads(p.read_bytes()),p,'$')
 except (ValueError,UnicodeError):pass
after=[snap(p) for p in files];assert before==after
summary={}
for kind in sorted(occurrences):
 rows=[r for r in samples.values() if r['kind']==kind];summary[kind]=dict(uniqueTypedDictionaries=len(rows),occurrences=occurrences[kind],maxModelDefaultSerializedBytes=max(r['modelDefaultSerializedBytes'] for r in rows),maxEscapedResultBytes=max(r['escapedResultBytes'] for r in rows),maxEscapedPipeEnvelopeBytes=max(r['escapedPipeEnvelopeBytes'] for r in rows),allWithinResult12000=all(r['withinResult12000'] for r in rows),allWithinPipe16384=all(r['withinPipe16384'] for r in rows))
report=dict(status='READ_ONLY_STDLIB_SERIALIZATION_SHAPE_ANALYSIS_NO_PRODUCER_EXECUTION',originalCount=len(files),originalBeforeAfterIdentical=True,summary=summary,samples=list(samples.values()),limits=dict(result=12000,ownerPipe=16384),qualification='Retained actual model dictionaries serialized using source-confirmed json.dumps(value). Original native-file raw whitespace is not available from these nested WAL dictionaries. Values/source clocks are unchanged. No native/device/SDK/production capacity qualification.',sources={str(p):snap(p) for p in (R/'tests/device/ios/self_tests/test_ios_lifecycle_world.py',R/'tests/device/ios/self_tests/test_ios_lifecycle_touch.py')})
(P/'native-file-wire-shape-analysis.json').write_text(json.dumps(report,indent=2)+'\n');(P/'native-file-wire-original-pins.json').write_text(json.dumps(before,indent=2)+'\n');print(json.dumps(dict(originalCount=len(files),summary=summary),indent=2))
