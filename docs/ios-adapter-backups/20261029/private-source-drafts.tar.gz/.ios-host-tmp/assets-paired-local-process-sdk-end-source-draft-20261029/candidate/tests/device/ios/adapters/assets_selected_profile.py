"""Explicit early selected pair; never infer a target from an old Asset WAL.

The immutable selection is an OriginalFrame owned by the same final archive.
It is host configuration provenance, not native/OS/server absence evidence.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from adapters.native_clock_join import digest
from adapters.native_feature_observation import exact,need
from adapters.script_feature.history import same
from ios.adapters.assets_files import OwnedAssetsFiles
from ios.adapters.assets_scene_sources import AssetsSceneSources


def link(value):
    exact(value,{'archivePath','contextSha256','reference'})
    p=Path(value['archivePath']);need(type(value['archivePath']) is str and p.is_absolute() and p.resolve()==p)
    # The actual OriginalFrame codec validates the complete reference. No path,
    # digest or target-looking string independently grants selection authority.
    need(type(value['reference']) is dict and type(value['contextSha256']) is str)
    return deepcopy(value)


class SelectedAssetsFiles(OwnedAssetsFiles):
    OWNER_VERSION=3
    EXTRA_FIELDS=frozenset({'selectedPair'})
    def __init__(self,*args,selection,**kwargs):
        self.selection=selection;self.selection_read_only=False;self.selection_role=kwargs.get('role','primary')
        selection.selected_guard();super().__init__(*args,**kwargs)
        need(self.role=='primary' and same(self.binding,selection.context['roles'][self.role]['binding'])
            and self.run==selection.run and self.url==selection.context['fixtureUrl']
            and self.store.path.parent==Path(selection.context['roles'][self.role]['stateRoot']))
        selection.selected_guard()
    def extra_envelope(self):return dict(selectedPair=self.selection.link())
    def envelope_guard(self):
        self.selection.selected_guard();need(getattr(self,'selection_read_only',False) is True or self.selection.state==dict(phase='selected'));return True
    def decode(self,value):
        need(type(value) is dict and type(value.get('iosAssetsFileOwnerVersion')) is int and value['iosAssetsFileOwnerVersion']==3)
        return super().decode(value)


class SelectedAssetsScene(AssetsSceneSources):
    OWNER_VERSION=2
    EXTRA_FIELDS=frozenset({'selectedPair'})
    def __init__(self,*args,selection,**kwargs):
        self.selection=selection;self.selection_read_only=False;selection.selected_guard();super().__init__(*args,**kwargs)
        selected_role='actor' if self.role=='actor' else 'primary'
        need(same(self.binding,selection.context['roles'][selected_role]['binding']) and self.run==selection.run
            and self.store.path.parent==Path(selection.context['roles'][selected_role]['stateRoot']))
        selection.selected_guard()
    def extra_envelope(self):return dict(selectedPair=self.selection.link())
    def envelope_guard(self):
        self.selection.selected_guard();need(getattr(self,'selection_read_only',False) is True or self.selection.state==dict(phase='selected'));return True
