"""Fresh combined normal Assets/Create/Marker/Image and independent peer model.

This is a producer composition selected before the first owner/capture. It
never imports a primary observation into the peer, copies old frame facts or
releases cached resources as adapter cleanup. Native/Qt/parser/GPU are models.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from functools import partial
from types import SimpleNamespace
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.assets_runtime import IOSAssetsRuntime
from ios.adapters.assets_baked_tree import OwnedAssetsBakedTree
from unittest.mock import patch
from adapters.native_feature_observation import need
from ios.adapters.assets_selected_profile import SelectedAssetsFiles,SelectedAssetsScene
from ios.self_tests import assets_upload_fixture as upload
from ios.self_tests import assets_geometry_release_fixture as geometry
from ios.self_tests import assets_image_removal_fixture as image
from ios.self_tests import assets_peer_fixture as peer
from ios.self_tests import assets_baked_tree_fixture as baked
from ios.self_tests.assets_reply_fixture import RUN,TICKET,URL
from ios.self_tests.assets_image_pool_flow_fixture import Boundary as PoolBoundary,Fixture as PoolFixture


class DomainEntities(dict):
    """Publish only actual normal controller writes/deletes to a second store."""
    def __init__(self,remote):super().__init__();self.remote=remote
    def __setitem__(self,identity,entity):
        super().__setitem__(identity,entity);self.remote.receive(identity,deepcopy(entity.properties))
    def pop(self,identity,*default):
        existed=identity in self;value=super().pop(identity,*default)
        if existed:self.remote.removed(identity)
        return value
    def __delitem__(self,identity):
        super().__delitem__(identity);self.remote.removed(identity)


class PeerWorld(peer.PeerWorld):
    def removed(self,identity):
        # The actual domain message deletes the peer's entity/model. A model
        # resource cache is a different real owner and is deliberately retained.
        need(identity in self.entities and identity in self.models)
        self.deliveries.append(dict(id=identity,event='removed'))
        self.entities.pop(identity);self.models.pop(identity);self.entity_revision+=1


class Boundary(PoolBoundary,image.Boundary,baked.Boundary):
    def __init__(self,directory):
        super().__init__(directory);need(not self.entities and not self.models)
        self.peer=PeerWorld(self);self.entities=DomainEntities(self.peer)


class ParsedFixture(PoolFixture,baked.Fixture):
    boundary_type=Boundary
    def __init__(self,directory,*,selected,lock):
        # Exact existing lock object nests real ownership rather than creating
        # a second lock instance with the same path or returning a no-op scope.
        def canonical(path):
            need(path.parent==directory and path.name in ('assets.lock','script-feature-sources.lock'))
            lock.assert_held();return lock
        with (patch.object(upload,'ScriptSourceLock',side_effect=canonical),
              patch.object(geometry,'ScriptSourceLock',side_effect=canonical),
              patch.object(upload,'OwnedAssetsFiles',partial(SelectedAssetsFiles,selection=selected))):
            super().__init__(directory)
        need(self.lock is lock and self.files.selection is selected)
        self.boundary.peer.resolve_model=self.resolve_model

    def prepared(self):
        # Fresh actual normal upload/bake/import goes through the existing
        # canonical operation recipe, not seeded-prefix parsed test setup.
        self.boundary.reads.resource='asset-stand.fbx';parts=self.parts()
        runtime=IOSAssetsRuntime(SimpleNamespace(_candidate_guard=lambda:True,_binding=lambda:None),monotonic=self.boundary.monotonic)
        with patch('adapters.asset_backend_client.build_opener',return_value=self):
            runtime._assets_upload_model_bytes('declared-existing-parts',RUN,'primary',self.files.url,TICKET,self.lock,self.backend.config,parts=parts)
        self.normal_parts=parts
        # These actual normal mapping operations precede the ordinary fixture's
        # parent close. The loaded local/peer models remain separate owners and
        # retain their accepted bytes after server namespace deletion.
        self.baked_tree=OwnedAssetsBakedTree(parts['parsed'],PrivateFeatureState(self.path('baked-tree')),lock=self.lock)
        self.baked_tree.reserve();self.baked_tree.browse();self.baked_tree.rename();self.baked_tree.delete();self.baked_tree.deletion()
        return parts['model'],parts['baking']


class CombinedImageFixture(image.Fixture):
    def __init__(self,test,directory,*,selected,lock):
        # Existing normal Script marker baseline is acquired before the normal
        # model import. Pool/byte/scene producers share this actual one tree.
        with patch.object(image,'ParsedFixture',partial(ParsedFixture,selected=selected,lock=lock)):
            super().__init__(test,directory)


class SelectedSceneEndpoint(peer.SceneEndpoint):
    def __init__(self,*args,selected,lock,**kwargs):
        # The real selected role binding is chosen before owner()/FIRST query.
        self.selected=selected
        role=kwargs.get('role',args[3] if len(args)>3 else None);need(role in ('primary','actor','actor-primary'))
        target_role='actor' if role=='actor' else 'primary'
        kwargs.setdefault('pid',int(selected.context['roles'][target_role]['binding']['processIdentity']))
        def canonical(path):need(path==lock.path);lock.assert_held();return lock
        with patch.object(peer,'ScriptSourceLock',side_effect=canonical):super().__init__(*args,**kwargs)
        target_role='actor' if self.role=='actor' else 'primary'
        info=selected.context['roles'][target_role]
        need(self.root==lock.path.parent and self.pid==int(info['binding']['processIdentity']))
        self.binding=deepcopy(info['binding']);self.lock=lock
    def owner(self):
        # Reuse the exact reader assembly, changing only the explicitly selected
        # Scene2 parent owner constructor; no packet/result/verdict is replaced.
        with patch.object(peer,'AssetsSceneSources',partial(SelectedAssetsScene,selection=self.selected)):
            return super().owner()


class PrimarySceneEndpoint(SelectedSceneEndpoint):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);need(self.role=='primary' and not self.queries)
        self.world=self.boundary
