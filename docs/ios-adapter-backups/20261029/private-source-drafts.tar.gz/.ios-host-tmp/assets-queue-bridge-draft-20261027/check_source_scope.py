"""Bounded read-only source projection; no CMake/compiler/native execution."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

REPO = Path(__file__).resolve().parents[2]
NAMES = ('libraries/material-networking/CMakeLists.txt',
         'libraries/material-networking/src/material-networking/TextureCache.cpp',
         'tests/device/native/IOSAssetsImageReaderObservation.h')


def without_new_dedicated_blocks(text):
    result, depth = [], 0
    for line in text.splitlines(True):
        value = line.strip()
        if depth:
            if re.match(r'#\s*(if|ifdef|ifndef)\b', value):
                depth += 1
            elif re.match(r'#\s*endif\b', value):
                depth -= 1
        elif value == '#if defined(OVERTE_IOS_E2E_TEST_BUILD)':
            depth = 1
        else:
            result.append(line)
    assert depth == 0
    return ''.join(result)


def tokens(text):
    pattern = r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*.*?\*/|[A-Za-z_]\w*|[0-9]+|[^\s]'
    return [item for item in re.findall(pattern, text, re.S)
            if not item.startswith('//') and not item.startswith('/*')]


def main():
    pins = {}
    for name in NAMES:
        baseline = subprocess.check_output(['git', 'show', 'b90666ae7c:' + name], cwd=REPO).decode()
        current = (REPO / name).read_text()
        pins[name] = hashlib.sha256(current.encode()).hexdigest()
        if name.endswith('CMakeLists.txt'):
            prefix = current.split('\nif (IOS AND OVERTE_E2E_FEATURE_TESTS AND OVERTE_IOS_E2E_TEST_BUILD)\n')
            assert len(prefix) == 2 and prefix[0].rstrip() == baseline.rstrip()
        elif name.endswith('TextureCache.cpp'):
            assert without_new_dedicated_blocks(current) == baseline
        else:
            # Existing inline returned() was reformatted around its optional hook.
            # Compare literal C++ tokens, preserving all string/character contents.
            assert tokens(without_new_dedicated_blocks(current)) == tokens(baseline)
    print(json.dumps(dict(sourceProjectionOnly=True, originalProductCppBytesPreserved=True,
                          originalSource1TokensPreserved=True, nativeCompilationVerified=False,
                          runtimeApiVerified=False, sourceSha256=pins), indent=2))


if __name__ == '__main__':
    main()
