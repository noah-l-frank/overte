"""Prepare five private native source candidates; never modify repository files."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]


def replace_once(text, old, new):
    assert text.count(old) == 1, old[:80]
    return text.replace(old, new, 1)


paths = ['libraries/material-networking/CMakeLists.txt',
         'tests/device/native/IOSAssetsImageReaderObservation.h',
         'libraries/material-networking/src/material-networking/TextureCache.cpp']
pins = {}
for name in paths:
    path = REPO / name
    data = path.read_bytes()
    pins[name] = hashlib.sha256(data).hexdigest()
    text = data.decode()
    if name.endswith('CMakeLists.txt'):
        text = text.rstrip() + '''

if (IOS AND OVERTE_E2E_FEATURE_TESTS AND OVERTE_IOS_E2E_TEST_BUILD)
    target_compile_definitions(${TARGET_NAME} PRIVATE OVERTE_IOS_E2E_TEST_BUILD=1)
    if (TARGET Qt6::CorePrivate)
        # Optional matching QtCore SDK; an absent/unpatched API stays unavailable.
        # Rebuild the complete SDK and all private-header consumers together.
        target_link_libraries(${TARGET_NAME} PRIVATE Qt6::CorePrivate)
        target_compile_definitions(${TARGET_NAME} PRIVATE OVERTE_E2E_METACALL_PRIVATE_API=1)
    endif()
endif()
'''
    elif name.endswith('TextureCache.cpp'):
        old = '''                    actual.staticCast<NetworkTexture>()->_textureSource,_url,_content.size());'''
        text = replace_once(text, old, old + '''
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
                // Source1::created has returned and released its mutex.
                if (_featureTask) { overte::e2e::IOSAssetsImageReaderQueueObservation::prepare(); }
#endif''')
    else:
        text = replace_once(text, '#include "NativeReadBracket.h"', '''#include "NativeReadBracket.h"
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
#include "../../../libraries/material-networking/src/material-networking/IOSAssetsImageReaderQueueObservation.h"
#endif''')
        text = replace_once(text, '            activeDispatch()=_token;\n', '''            activeDispatch()=_token;
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
            if (_token) { _queue.begin(queueContext(_token,false),target); }
#endif
''')
        text = replace_once(text, '        void returned(bool accepted) noexcept {_returned=true;invoked(_token,accepted);}', '''        void returned(bool accepted) noexcept {
            _returned=true;invoked(_token,accepted);
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
            if (_token) { _queue.returned(accepted); }
#endif
        }''')
        text = replace_once(text, '    private:quint64 _previous{0},_token{0};bool _returned{false};', '''    private:quint64 _previous{0},_token{0};bool _returned{false};
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
        IOSAssetsImageReaderQueueObservation::Binding _queue;
#endif''')
        text = replace_once(text, '            : _token(receiving(target,source,gpu,width,height)),_exceptions(std::uncaught_exceptions()) {}', '''            : _token(receiving(target,source,gpu,width,height)),_exceptions(std::uncaught_exceptions()) {
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
            if (_token) { _queue.begin(queueContext(_token,true)); }
#endif
        }''')
        text = replace_once(text, '    private:quint64 _token{0};int _exceptions;\n', '''    private:quint64 _token{0};int _exceptions;
#if defined(OVERTE_IOS_E2E_TEST_BUILD)
        IOSAssetsImageReaderQueueObservation::Receiver _queue;
#endif
''')
        anchor = '    static std::atomic<bool>& failed() noexcept'
        helper = '''#if defined(OVERTE_IOS_E2E_TEST_BUILD)
    static IOSAssetsImageReaderQueueObservation::Context queueContext(quint64 token,bool receiver) noexcept {
        QT_TRY {
            auto& owner=state();QMutexLocker lock(&owner.mutex);
            const auto& rows=receiver ? owner.receivers : owner.dispatches;
            if (!token || token>quint64(rows.size())) {return {};}
            const auto& row=rows[int(token-1)];IOSAssetsImageReaderQueueObservation::Context result;
            result.ownerInstance=owner.instance;result.receiver=row.object.data();
            if (receiver) {
                result.receiverId=row.value.value("id").toString();
                result.resourceId=row.value.value("resourceId").toString();
            } else {
                if (!row.task || row.task>quint64(owner.tasks.size())) {return {};}
                const auto& task=owner.tasks[int(row.task-1)];
                result.taskId=task.value.value("id").toString();result.dispatchId=row.value.value("id").toString();
                result.resourceId=task.value.value("resourceId").toString();
            }
            // Return by value; caller enters Qt/Bridge only after this lock is gone.
            return result;
        } QT_CATCH (...) {return {};}
    }
#endif
'''
        text = replace_once(text, anchor, helper + anchor)
    target = HERE / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
(HERE / 'repository-original-sha256.json').write_text(json.dumps(pins, indent=2) + '\n')
