"""Once-only normal owned-domain settings input, not client effect proof."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from urllib.parse import urlsplit
import re
from adapters.native_feature_observation import exact,need,number
from fixture.create_rez_authority import process
from fixture.assets_write_authority import AssetsWriteControl,rows
from ios.adapters.create_rez_client import CreateRezClient
from ios.adapters.assets_budget import check


def configuration(value):
    exact(value,{'controlUrl','token','domainId'})
    parsed=urlsplit(value['controlUrl'])
    need(parsed.scheme=='http' and parsed.hostname=='127.0.0.1' and parsed.port is not None
        and not parsed.username and not parsed.password and not parsed.query and not parsed.fragment
        and parsed.path=='/v1/assets-write' and type(value['token']) is str and re.fullmatch('[A-Za-z0-9_-]{40,128}',value['token'])
        and type(value['domainId']) is str and re.fullmatch(r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}',value['domainId'])
        and value['domainId']!='00000000-0000-0000-0000-000000000000')
    return value


def original(value,domain_id):
    exact(value,{'assetsWriteSettingsVersion','binding','hostBeforeEpochMs','hostAfterEpochMs','standardPermissions'})
    need(type(value['assetsWriteSettingsVersion']) is int and value['assetsWriteSettingsVersion']==1
        and process(value['binding'])['domainId']==domain_id and number(value['hostBeforeEpochMs'],1,1e15)
        and number(value['hostAfterEpochMs'],value['hostBeforeEpochMs'],value['hostBeforeEpochMs']+5000))
    rows(value['standardPermissions']);return value


class AssetsWriteClient(CreateRezClient):
    CLIENT_KEY='iosAssetsWriteClientVersion'
    configuration=staticmethod(configuration)
    original=staticmethod(original)
    Control=AssetsWriteControl
    api_check=staticmethod(check)
