"""Owned AssetServer write permission through the existing normal domain API.

Settings rows are fixture INPUT originals, never effective client permission,
Delete disabledness, native absence or public Assets success. Clients and the
independent Actor must separately read actual propagation and negative spans.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from adapters.native_feature_observation import need
from fixture.create_rez_authority import CreateRezAuthority,CreateRezControl,STANDARD_IDS

BITS=('id_can_write_to_asset_server',)


def rows(value):
    need(type(value) is list and len(value)==len(STANDARD_IDS))
    names=[]
    for row in value:
        need(type(row) is dict and row.get('permissions_id') in STANDARD_IDS and len(row)<=32
            and type(row.get(BITS[0])) is bool)
        names.append(row['permissions_id'])
    need(set(names)==STANDARD_IDS and len(set(names))==len(names));return deepcopy(value)


class AssetsWriteAuthority(CreateRezAuthority):
    BITS=BITS
    rows=staticmethod(rows)
    AUTHORITY_KEY='assetsWriteAuthorityVersion'
    SETTINGS_KEY='assetsWriteSettingsVersion'


class AssetsWriteControl(CreateRezControl):
    CONTROL_KEY='assetsWriteControlVersion'
    def __init__(self,authority,store):
        need(type(authority) is AssetsWriteAuthority);super().__init__(authority,store)
