"""Actual owned handler/settings HTTP and once-only WAL, no DomainServer/native.

The independently modeled settings server retains actual rows. These tests
never supply client Delete/permission effects, Source pixels or whole facts.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from http.server import ThreadingHTTPServer
from urllib.error import HTTPError
from urllib.request import Request,urlopen
from pathlib import Path
import json,threading,unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from adapters.script_feature.lock import ScriptSourceLock
from fixture.domain import DomainControlHandler
from fixture.assets_write_authority import AssetsWriteAuthority,AssetsWriteControl
from fixture.create_rez_authority import CreateRezAuthority,fixture_permissions
from ios.adapters.assets_write_client import AssetsWriteClient
from ios.self_tests import test_ios_create_rez_authority as original_fixture
from ios.self_tests.test_ios_create_files import BINDING,RUN


class AssetsWriteControlTests(unittest.TestCase):
    def setUp(self):
        self.h=original_fixture.RezAuthorityTests();self.h.setUp();self.addCleanup(self.h.doCleanups)
        self.path=self.h.path;self.lock=ScriptSourceLock(self.path/'script-feature-sources.lock')
        self.authority_store=PrivateFeatureState(self.path/'assets-write-authority.json')
        self.control_store=PrivateFeatureState(self.path/'assets-write-control.json')
        self.store=PrivateFeatureState(self.path/'assets-write-client.json');self.commands=[]
        self.authority=self.make_authority();self.control=AssetsWriteControl(self.authority,self.control_store)
        def command(value):self.commands.append(deepcopy(value));return self.control.handle(value)
        handler=type('ActualAssetsWriteHandler',(DomainControlHandler,),dict(token='T'*48,assets_write=staticmethod(command),log_message=lambda *_:None))
        self.server=ThreadingHTTPServer(('127.0.0.1',0),handler)
        self.thread=threading.Thread(target=self.server.serve_forever,kwargs={'poll_interval':.01},daemon=True);self.thread.start()
        self.addCleanup(self.server.server_close);self.addCleanup(self.thread.join,2);self.addCleanup(self.server.shutdown)
        self.config=dict(controlUrl='http://127.0.0.1:'+str(self.server.server_port)+'/v1/assets-write',token='T'*48,domainId=self.h.binding['domainId'])
    def make_authority(self):return AssetsWriteAuthority(self.h.origin,self.authority_store,lambda:deepcopy(self.h.binding))
    def client(self):return AssetsWriteClient(self.store,self.lock,BINDING,RUN,self.config,lambda:True)
    def wire(self,value,token):
        request=Request(self.config['controlUrl'],data=json.dumps(value).encode(),method='POST',headers={'X-Overte-E2E-Token':token,'Content-Type':'application/json'})
        return urlopen(request,timeout=2)
    def test_actual_normal_settings_input_changes_only_write_bit_and_restores_exact_original_rows(self):
        before=deepcopy(self.h.security)
        with self.lock.held():
            client=self.client();initial=client.request('observe');denied=client.request('set',allowed=False)
            self.assertTrue(all(not row['id_can_write_to_asset_server'] for row in denied['standardPermissions']))
            self.assertEqual([{k:v for k,v in row.items() if k!='id_can_write_to_asset_server'} for row in before['standard_permissions']],
                [{k:v for k,v in row.items() if k!='id_can_write_to_asset_server'} for row in self.h.security['standard_permissions']])
            restored=client.request('restore');self.assertEqual(initial['standardPermissions'],restored['standardPermissions'])
            self.assertEqual(before,self.h.security);self.assertEqual(2,self.h.posts)
            self.assertNotIn('canWriteAssets',restored);self.assertNotIn('deleteEnabled',restored)
            self.assertNotIn(self.config['token'],json.dumps(self.store.read()))
    def test_success_ack_ignored_settings_remains_pending_and_cold_recovery_cannot_resend(self):
        with self.lock.held():
            client=self.client();client.request('observe');self.h.ignore=True
            with self.assertRaises(HTTPError) as error:client.request('set',allowed=False)
            error.exception.close();self.assertEqual(1,self.h.posts)
            self.authority=self.make_authority();self.control=AssetsWriteControl(self.authority,self.control_store)
            with self.assertRaises(HTTPError) as error:self.client().recover()
            error.exception.close();self.assertEqual(1,self.h.posts)
            self.assertIsNone(self.client().state['commands'][-1]['original'])
    def test_lost_normal_post_return_reopens_actual_owner_and_recovers_via_get_only(self):
        with self.lock.held():
            client=self.client();self.h.lose=True
            with self.assertRaises(HTTPError) as error:client.request('set',allowed=False)
            error.exception.close();self.assertEqual(1,self.h.posts);self.h.lose=False
            self.authority=self.make_authority();self.control=AssetsWriteControl(self.authority,self.control_store)
            fresh=self.client();observed=fresh.recover()
            self.assertEqual(['set','recover'],[q['operation'] for q in self.commands]);self.assertEqual(1,self.h.posts)
            self.assertEqual(self.commands[0]['commandId'],self.commands[1]['queryCommandId'])
            self.assertTrue(all(not row['id_can_write_to_asset_server'] for row in observed['standardPermissions']))
            fresh.request('restore');self.assertEqual(2,self.h.posts)
    def test_actual_handler_rejects_foreign_token_and_unknown_fields_before_settings_post(self):
        query=dict(schemaVersion=1,commandId='b'*32,runId=RUN,operation='set',allowed=False)
        for value,token in ((query,'wrong'),(dict(query,expectedCanWrite=False),'T'*48),(dict(query,schemaVersion=True),'T'*48)):
            with self.subTest(fields=sorted(value)),self.assertRaises(HTTPError) as error:self.wire(value,token)
            error.exception.close();self.assertEqual(0,self.h.posts)
    def test_foreign_domain_process_and_external_override_refuse_before_normal_mutation(self):
        self.authority.prepare();self.h.binding['processId']+=1
        with self.assertRaises(NativeUIError):self.make_authority().transition(False)
        self.assertEqual(0,self.h.posts);self.h.binding['processId']-=1
        self.h.security['permissions']=[dict(permissions_id='foreign',id_can_write_to_asset_server=True)]
        with self.assertRaises(NativeUIError):self.authority.transition(False)
        self.assertEqual(0,self.h.posts)
    def test_asset_authority_wal_cannot_be_adopted_by_literal_create_reader(self):
        self.authority.prepare();before=self.authority_store.path.read_bytes()
        with self.assertRaises(NativeUIError):CreateRezAuthority(self.h.origin,self.authority_store,lambda:deepcopy(self.h.binding))
        self.assertEqual(before,self.authority_store.path.read_bytes());self.assertEqual(0,self.h.posts)
    def test_explicit_fixture_write_opt_in_preserves_description_and_create_default(self):
        path=Path(__file__).resolve().parents[4]/'domain-server/resources/describe-settings.json'
        description=json.loads(path.read_text());before=deepcopy(description)
        legacy=fixture_permissions(description);assets=fixture_permissions(description,bits=('id_can_write_to_asset_server',))
        self.assertEqual(before,description)
        self.assertFalse(next(row for row in legacy if row['permissions_id']=='anonymous')['id_can_write_to_asset_server'])
        self.assertTrue(next(row for row in assets if row['permissions_id']=='anonymous')['id_can_write_to_asset_server'])
        for row in assets:
            old=next(item for item in legacy if item['permissions_id']==row['permissions_id'])
            if row['permissions_id']!='anonymous':self.assertEqual(old,row)
