Assets 13/14 minimum ByteBlock/three-view shape - PRIVATE CODE SKETCH ONLY
======================================================================

One reviewable minimum-shape.cpp.sketch.txt, deliberately NOT compilable product
code: table/events/clock/poison are explicit abstract obligations, not invented
working implementation. No Qt patch, observer implementation, host test, public
source or registry/Source1 change. Original source/ownership plan stays frozen.
Only retained exact Qt6.11.1 source was reread; no download/profile/SDK/build.

Concrete before/after ownership
-------------------------------
FreeEntering runs while actual header is live, reserves its diagnostic record,
captures instance/generation/size/clock and removes only that live address lookup.
Released token contains NO product pointer/address. Original sizedFree/free runs
once, unchanged. FreeReturned takes only that token and commits by DIAGNOSTIC
record/version, never by old address. A new same-address allocation therefore
cannot be retired by the earlier callback. Reserved diagnostic rows cannot be
reused before token completion; contention/overflow/unknown completion closes
availability instead of changing the product allocator flow.

Realloc removes/fences the tracked old lookup before the original call. Success
ALWAYS creates a new generation, including same-address success. Its callback
may inspect only the new LIVE result; old generation ends from captured token.
Concurrent reuse of old address by another allocation stays untouched. Positive-
size null failure restores the SAME old generation from reserved metadata, no
new birth/free. That restoration is allowed only on actual failure, where the
original allocation remains live. Null old/pre-arm/untracked input gives no
invented historical birth or old-end. Overflow return without allocator call
supplies no success event. Abstract table conflict handling must fail closed.

Three selected views and retirement boundary
-------------------------------------------
Task joins actual Source1 context, never requested IDs. On owning thread, use
const QByteArray::data_ptr by reference: header/ptr/size and handle identity,
without ByteArray copy/ref/detach. View IDs mean observed live attachment
GENERATIONS, not observed C++ constructor birth. Explicit sites are reader
_content after actual task creation; original OwningBuffer move return, then
its gated const-owned-content accessor and const QBuffer::data default view.
Borrow raw liveBuffer from existing shared_ptr only during these calls; no
extra shared_ptr or product object is retained in diagnostics.

The one selected-char QArrayDataPointer destructor placement leaves its exact
original deref branch. Tail callback uses a pointer-free captured view token.
It observes completed reference release at BODY TAIL, NOT destructor return.
Block release requires independent actual allocator-release-return event;
last selected view alone never proves all shared owners/borrowed views ended.
Unknown assignment/swap/detach or wrong header/generation cannot be papered over.

Explicitly unavailable
----------------------
Null header is nonowned/raw/static-unclassified: do not infer which category or
look up constData against guessed headers. Pre-arm/untracked blocks, request/
loaded/queued/NetworkTexture copies, external raw borrows/plugins, QImage pixels,
float buffers/NVTT/mips/codec scratch/GPU and complete global pool/app end remain
open. All broad copy/decoder/all-alias/raw-absence/global-pool/GPU/whole flags
remain false, and original task/pool histories unchanged.

Gates/ABI and unimplemented obligations
--------------------------------------
Separate dedicated QtCore opt-in plus actual iOS feature/test-build/testScript
and original task/source binding; missing optional protocol stays unavailable.
Bounded fixed POD state only in hooks, no Qt/STL allocations/product callbacks/
QObject reads/product locks. No metadata lock held over malloc/realloc/free.
Exact table/queue/concurrency/clock source/capacity, no-throw path and loss
accounting still require implementation review and native verification.
QtPrivate::sizedFree is the actual reviewed call boundary; its SDK/libc ABI,
C++ sized-delete ABI, inline instantiations and native concurrency are UNRUN.
No claim that feature macros alone prove the previously compiled ABI route.
The sketch does not supply code/build/API availability or execution evidence.
