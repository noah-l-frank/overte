"""Prepare only private shared-file candidates. Never apply these blindly later."""
from pathlib import Path
import difflib
import hashlib
import json

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
NAMES=('interface/src/scripting/TestScriptingInterface.h','interface/src/scripting/TestScriptingInterface.cpp',
    'tests/device/probe/overte_e2e_probe.js','tests/device/fixture/serve.py','tests/device/ios/adapters/feature_observation.py')


def replace(text,old,new):
    assert text.count(old)==1,old[:100]
    return text.replace(old,new,1)


pins={};patch=[]
for name in NAMES:
    data=(REPO/name).read_bytes();before=data.decode();text=before;pins[name]=hashlib.sha256(data).hexdigest()
    if name.endswith('TestScriptingInterface.h'):
        for prefix in ('    Q_INVOKABLE QVariantMap featureIOSAssetsImageReader(const QVariantMap& command);',
                       '    std::shared_ptr<overte::e2e::NativeReadBracket> _featureIOSAssetsImageReader;'):
            text=replace(text,prefix,prefix+'\n'+prefix.replace('AssetsImageReader','AssetsImageReaderQueue'))
    elif name.endswith('TestScriptingInterface.cpp'):
        anchor='#include "../../../tests/device/native/IOSAssetsImageReaderObservation.h"'
        text=replace(text,anchor,anchor+'\n#include <material-networking/IOSAssetsImageReaderQueueObservation.h>')
        first=text.index('QVariantMap TestScriptingInterface::featureIOSAssetsImageReader(')
        last=text.index('\nQVariantMap TestScriptingInterface::featureIOSAssetsModelOrigin(',first)
        method=text[first:last]
        queued=method.replace('AssetsImageReader','AssetsImageReaderQueue').replace('assets-image-reader','assets-image-reader-queue')
        # Empty can mean no actual Source1 parent yet, or missing optional SDK.
        # A passive unavailable read must not disarm a merely not-yet-born source.
        queued=queued.replace('        if (result.isEmpty()) {overte::e2e::IOSAssetsImageReaderQueueObservation::unavailable();}\n','')
        queued=queued.replace('IOSAssetsImageReaderQueueObservation::unavailable()','IOSAssetsImageReaderQueueObservation::disarm()')
        text=text[:last]+'\n'+queued+text[last:]
        for old,new in (
            ('    if (filename=="feature-ios-assets-image-reader.json") {return;}',
             '    if (filename=="feature-ios-assets-image-reader-queue.json") {return;}'),
            ('    if (filename=="feature-ios-assets-image-reader.json") {jsonData=jsonDocument.toJson(QJsonDocument::Compact);}',
             '    if (filename=="feature-ios-assets-image-reader-queue.json") {jsonData=jsonDocument.toJson(QJsonDocument::Compact);}')):
            text=replace(text,old,old+'\n'+new)
        text=replace(text,'    if (filename == "feature-ios-assets-image-reader.json" ||',
                     '    if (filename == "feature-ios-assets-image-reader-queue.json" || filename == "feature-ios-assets-image-reader.json" ||')
    elif name.endswith('overte_e2e_probe.js'):
        first=text.index('        if (command && command.action === "feature-ios-assets-image-reader") {')
        last=text.index('        if (command && command.action === "feature-ios-assets-model-origin") {',first)
        block=text[first:last]
        queued=block.replace('AssetsImageReader','AssetsImageReaderQueue').replace('assetsImageReader','assetsImageReaderQueue')
        queued=queued.replace('assets-image-reader','assets-image-reader-queue')
        text=text[:last]+queued+text[last:]
    elif name.endswith('serve.py'):
        first=text.index('        elif action == "feature-ios-assets-image-reader":')
        last=text.index('        elif action == "feature-ios-assets-model-origin":',first)
        block=text[first:last]
        queued=block.replace('assets-image-reader','assets-image-reader-queue').replace('assets_image_reader','assets_image_reader_queue')
        queued=queued.replace('Assets image reader request','Assets image reader queue request')
        text=text[:last]+queued+text[last:]
    else:
        line='from ios.adapters.assets_image_reader import IOSAssetsImageReader,FILE as ASSETS_IMAGE_READER_FILE,LIMIT as ASSETS_IMAGE_READER_LIMIT,command as assets_image_reader_command'
        new=line.replace('assets_image_reader','assets_image_reader_queue').replace('IOSAssetsImageReader','IOSAssetsImageReaderQueue').replace('ASSETS_IMAGE_READER','ASSETS_IMAGE_READER_QUEUE')
        text=replace(text,line,line+'\n'+new)
        line="        elif command.get('action')=='feature-ios-assets-image-reader':assets_image_reader_command(command)"
        new=line.replace('assets-image-reader','assets-image-reader-queue').replace('assets_image_reader','assets_image_reader_queue')
        text=replace(text,line,line+'\n'+new)
        first=text.index('    def assets_image_reader(self,clock_source=None):')
        last=text.index('    def assets_model_origin(self,clock_source=None):',first)
        block=text[first:last]
        queued=block.replace('assets_image_reader','assets_image_reader_queue').replace('ASSETS_IMAGE_READER','ASSETS_IMAGE_READER_QUEUE').replace('IOSAssetsImageReader','IOSAssetsImageReaderQueue')
        text=text[:last]+queued+text[last:]
    target=HERE/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
    patch.extend(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='a/'+name,tofile='b/'+name,n=3))
(HERE/'shared-original-sha256.json').write_text(json.dumps(pins,indent=2)+'\n')
(HERE/'shared-own-hunks.patch').write_text(''.join(patch).replace('\n \n','\n\n'))
