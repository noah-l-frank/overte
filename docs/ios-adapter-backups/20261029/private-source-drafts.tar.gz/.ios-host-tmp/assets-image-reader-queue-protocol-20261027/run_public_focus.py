"""Pinned explicit host-only selection; never launch native code or a device."""
from pathlib import Path
import hashlib
import json
import subprocess
import unittest

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml',
       'ios','cmake','scripts/system','interface/resources/qml')


def census():
    raw=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO)
    paths=[REPO/name for name in raw.decode().split('\0') if name]+[Path(__file__).resolve()]
    result={}
    for path in sorted(paths):
        a=path.lstat();data=path.read_bytes();b=path.lstat()
        fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
        first={field:getattr(a,field) for field in fields};last={field:getattr(b,field) for field in fields}
        assert first==last
        result[str(path.relative_to(REPO))]=dict(stat=last,sha256=hashlib.sha256(data).hexdigest())
    return result


before=census();(HERE/'public-focus-before.json').write_text(json.dumps(before,indent=2)+'\n')
suite=unittest.defaultTestLoader.loadTestsFromNames(('test_ios_assets_image_reader_queue',
                                                  'test_ios_assets_image_reader_queue_runtime'))
assert suite.countTestCases()==15,suite.countTestCases()
result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
after=census();(HERE/'public-focus-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after,'Source/launcher inventory or bytes/metadata changed'
print('SOURCE_LAUNCHER_PINS_UNCHANGED',len(before))
raise SystemExit(not result.wasSuccessful())
