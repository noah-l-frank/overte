"""Exactly approved host-only selection; no native build/device/whole journey."""
from pathlib import Path
import hashlib,json,subprocess,unittest

HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics',
       'libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')

def census():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths=[REPO/name for name in names if name]+[Path(__file__).resolve(),HERE/'small43-first-own-hunks.json']
    rows={};fields=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    for path in sorted(paths):
        a=path.lstat();raw=path.read_bytes();b=path.lstat()
        before={name:getattr(a,name) for name in fields};after={name:getattr(b,name) for name in fields}
        assert before==after,'Source changed during actual original read: '+str(path)
        rows[str(path.relative_to(REPO))]=dict(stat=after,sha256=hashlib.sha256(raw).hexdigest())
    return rows

before=census();(HERE/'public-small43-first-before.json').write_text(json.dumps(before,indent=2)+'\n')
print('SOURCE_LAUNCHER_PINS_BEFORE',len(before),flush=True)
result=None
try:
    names=('test_ios_assets_image_reader_lifecycle','test_ios_assets_image_reader_lifecycle_sources',
           'test_ios_assets_image_reader_queue','test_ios_assets_image_reader_queue_runtime')
    suite=unittest.defaultTestLoader.loadTestsFromNames(names)
    assert suite.countTestCases()==43,suite.countTestCases()
    print('EXACT_HOST_CASES',suite.countTestCases(),flush=True)
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
finally:
    after=census();(HERE/'public-small43-first-after.json').write_text(json.dumps(after,indent=2)+'\n')
    assert before==after,'Source/launcher inventory, bytes or metadata changed'
    print('SOURCE_LAUNCHER_PINS_UNCHANGED',len(after),flush=True)
raise SystemExit(result is None or not result.wasSuccessful())
