"""Exactly one approved fresh connected host-model case, outer300/kill5 external."""
from pathlib import Path
import hashlib,json,os,re,signal,subprocess,sys,unittest
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics',
       'libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
FIELD=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
owned=[]
def entry(path):
    a=path.lstat();raw=path.read_bytes();b=path.lstat();before={k:getattr(a,k) for k in FIELD};after={k:getattr(b,k) for k in FIELD}
    assert before==after,str(path)
    return dict(stat=after,sha256=hashlib.sha256(raw).hexdigest())
def census():
    raw=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO)
    paths=[REPO/name for name in raw.decode().split('\0') if name]+[Path(__file__).resolve(),HERE/'connected-first-actual-own-hunks.json']
    return {str(path.relative_to(REPO)):entry(path) for path in sorted(paths)}
class Output:
    def __init__(self,actual):self.actual=actual;self.pending=''
    def write(self,value):
        self.actual.write(value);self.pending+=value
        while '\n' in self.pending:
            line,self.pending=self.pending.split('\n',1)
            if line.startswith('owned original root '):
                path=Path(line.removeprefix('owned original root '))
                assert path.parent==REPO/'.ios-host-tmp' and path.name.startswith('assets-image-processing-flow-')
                owned.append(path)
    def flush(self):self.actual.flush()
def stopped(_signal,_frame):
    print('ACTUAL_OUTER300_TERMINATION',flush=True)
    raise SystemExit(124)
signal.signal(signal.SIGTERM,stopped)
actual_stat=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()
process=dict(pid=os.getpid(),parentPid=os.getppid(),processGroup=os.getpgrp(),session=os.getsid(0),startTicks=int(actual_stat[19]))
(HERE/'connected-first-process-binding.json').write_text(json.dumps(process,indent=2)+'\n')
print('RUNNER_PROCESS',json.dumps(process,sort_keys=True),flush=True)
before=census();(HERE/'connected-first-before.json').write_text(json.dumps(before,indent=2)+'\n')
print('SOURCE_LAUNCHER_PINS_BEFORE',len(before),flush=True)
actual_stdout=sys.stdout;sys.stdout=Output(actual_stdout);result=None
try:
    name='test_ios_assets_image_processing_flow.AssetsImageProcessingFlowTests.test_normal_delete_image_edges_closed_refuses_independent_input_until_actual_originals_close'
    suite=unittest.defaultTestLoader.loadTestsFromName(name);assert suite.countTestCases()==1
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
finally:
    sys.stdout.flush();sys.stdout=actual_stdout
    after=census();(HERE/'connected-first-after.json').write_text(json.dumps(after,indent=2)+'\n')
    assert before==after,'Source/launcher/selected base hunks bytes or metadata changed'
    rows=[]
    for root in owned:
        files={str(p.relative_to(root)):entry(p) for p in sorted(root.rglob('*')) if p.is_file()}
        rows.append(dict(root=str(root),files=files))
    (HERE/'connected-first-retention.json').write_text(json.dumps(dict(roots=rows,sourceLauncherPins=len(after)),indent=2)+'\n')
    print('SOURCE_LAUNCHER_PINS_UNCHANGED',len(after),'RETAINED_FILES',sum(len(row['files']) for row in rows),flush=True)
raise SystemExit(result is None or not result.wasSuccessful())
