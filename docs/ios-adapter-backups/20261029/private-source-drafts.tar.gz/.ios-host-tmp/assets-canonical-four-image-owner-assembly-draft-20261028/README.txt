PRIVATE DRAFT CHECKPOINT, NOT READY FOR PUBLICATION OR EXECUTION.

One actual runtime source candidate assembles four existing primary original
owners under one canonical candidate/session/PID/Run/Lock. Before/after each
actual constructor it runs the existing typed closed prefix inspectors and
current source guard; foreign run/binding, orphan/unknown prefixes refuse.
Readers/Native/Source1 cursors remain distinct. The owners retain their literal
pending/interrupted responsibilities; this assembly does not reserve/capture,
read Native, query a Pool, send input, release a resource, replay an uncertain
query or change any wire/registry/capability/retirement flag.

Test implementation is PENDING: planned actual canonical transport/file cases
are cold four-owner construction with no query or birth; sequential original
capture and cold reopening with no query/WAL mutation; actual unknown/orphan
prefix before constructor and during a later constructor; foreign run/binding;
foreign SDK lock; late candidate/PID/foreground loss; unknown delivery retained
without resend; independent reader cursors and same-byte carrier replacement.
Use the current canonical Pool fixture plus its SAME declared Queue/Processing
producers and HTTP/AFC paths. Its root producer is fixture-local mkdtemp, not
TemporaryDirectory; retain/provenance must describe that truthfully. Normal
factory reopening may refresh InstalledBinding WAL, not pure reconstruction.
Native/HTTP/AFC/Qt producer effects remain models. Whole Assets is NOT complete.

This checkpoint was frozen promptly because Root's new measured World API25
failure took priority. No test case or actual integration PASS is claimed.
