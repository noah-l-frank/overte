Private Source4 correction; original 4-path packet remains frozen.
Two paths only; independent current fieldText read precedes ordinary Submit.
New genuine Node/QML ignored-replace ACK countercase; no transport/product/deadline changes.
All target imports and tests UNRUN. Existing twelve IDs preserved plus one explicit new ID.
