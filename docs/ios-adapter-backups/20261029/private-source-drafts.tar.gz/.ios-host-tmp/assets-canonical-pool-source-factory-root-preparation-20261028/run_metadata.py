"""Private Root run metadata only; no target imports or process launch on import."""
from pathlib import Path
import ast,hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(descriptor,'w') as output:
        output.write(json.dumps(value,indent=2,sort_keys=True)+'\n');output.flush();os.fsync(output.fileno())
def pin(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode),str(path)
    value={key:getattr(a,key) for key in FIELDS}
    if stat.S_ISREG(a.st_mode):value['sha256']=sha(path)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in FIELDS),str(path)
    return value

def proc(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))

def load_plan():return json.loads((HERE/'suite-plan.json').read_text())
def validate_frozen():
    own=json.loads((HERE/'freeze.json').read_text())
    for name,expected in own['files'].items():assert sha(HERE/name)==expected,name
    plan=load_plan()
    for row in plan['frozenPackets']:
        root=REPO/row['path'];assert sha(root/'freeze.json')==row['freezeSha256']
        frozen=json.loads((root/'freeze.json').read_text())
        for name,expected in frozen.get('files',frozen).items():assert sha(root/name)==expected,name
    assert sha(HERE/'source-root-final-map.json')==plan['sourceRootMapSha256']
    assert sha(HERE/'expected-publication.json')==plan['expectedPublicationSha256']
    return plan

def publication():
    rows=json.loads((HERE/'expected-publication.json').read_text())
    assert len(rows)==load_plan()['expectedPublicationCount']
    for row in rows:
        path=REPO/row['path'];assert path.resolve(strict=True)==path and sha(path)==row['expectedSha256'],row['path']
    return rows

def broad_sources(plan):
    names=subprocess.check_output(['rg','--files','-0',*plan['broadSourceRoots']],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}
    paths.update(REPO/name for name in plan['explicitExtraSourcePins'])
    assert REPO/'interface/src/main.cpp' in paths,'Explicit main.cpp pin missing'
    return paths

def sources(plan):
    paths=broad_sources(plan)
    for root in (HERE,*[REPO/row['path'] for row in plan['frozenPackets']]):
        frozen=json.loads((root/'freeze.json').read_text())
        paths.update(root/name for name in frozen.get('files',frozen));paths.add(root/'freeze.json')
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}

def originals(root):
    return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}


def registry_original():
    path=REPO/'tests/device/contract-versions.json';json.loads(path.read_bytes())
    return dict(sha256=sha(path),registry=pin(path),validator=pin(REPO/'tests/device/validate_contract_versions.py'))

def old_originals_expected():
    root=REPO/load_plan()['oldOriginalReference']
    value=json.loads(root.read_text())
    assert value['originalFiles']==722 and value['allExactOldByteStatMembershipUnchanged'] is True
    result={}
    for group in value['groups']:result.update(group['actual'])
    return result

def old_originals():
    result={};expected=old_originals_expected()
    for name in expected:
        root=Path(name);assert root.is_relative_to(REPO/'.ios-host-tmp') and root.resolve(strict=True)==root
        result[name]={'.' if path==root else str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}
    return result
