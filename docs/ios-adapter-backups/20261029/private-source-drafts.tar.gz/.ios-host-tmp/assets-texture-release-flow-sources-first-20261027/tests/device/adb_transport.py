#!/usr/bin/env python3
"""Privacy-safe ADB primitives shared by Android target adapters."""

from __future__ import annotations

import os
from pathlib import Path, PurePosixPath
import re
import shlex
import shutil
import subprocess
import sys
import time


class AdbTransport:
    def __init__(self, executable: str | None = None, *,
                 server_port: int | None = None) -> None:
        self.executable = executable or self.find_executable()
        self.command = ([sys.executable, self.executable]
                        if os.name == "nt" and self.executable.lower().endswith(".py")
                        else [self.executable])
        if server_port is not None:
            if (isinstance(server_port, bool) or not isinstance(server_port, int)
                    or not 1 <= server_port <= 65535):
                raise RuntimeError("ADB server port is invalid")
            self.command += ["-P", str(server_port)]

    @staticmethod
    def find_executable() -> str:
        candidates = [
            os.environ.get("OVERTE_ANDROID_ADB", ""),
            str(Path(os.environ.get("ANDROID_SDK_ROOT", "")) / "platform-tools/adb"),
            str(Path(os.environ.get("ANDROID_HOME", "")) / "platform-tools/adb"),
            str(Path.home() / "Android/Sdk/platform-tools/adb"),
            shutil.which("adb") or "",
        ]
        for candidate in candidates:
            is_python_mock = os.name == "nt" and candidate.lower().endswith(".py")
            if candidate and Path(candidate).is_file() and (is_python_mock or os.access(candidate, os.X_OK)):
                return candidate
        raise RuntimeError("ADB executable was not found")

    def execute(self, arguments: list[str], *, target: str | None = None,
                timeout: int = 20, check: bool = True,
                input_text: str | None = None) -> str:
        command = list(self.command)
        if target:
            command += ["-s", target]
        try:
            result = subprocess.run([*command, *arguments], text=True, input=input_text,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    timeout=timeout, check=False)
        except subprocess.TimeoutExpired as error:
            raise RuntimeError("ADB operation timed out: " + self.operation_label(arguments)) from error
        if check and result.returncode != 0:
            raise RuntimeError("ADB operation failed")
        return result.stdout.replace("\r", "")

    @staticmethod
    def operation_label(arguments: list[str]) -> str:
        """Closed command categories; never include selectors or payloads."""
        if arguments[:3] == ["shell", "am", "start"]:
            return "activity launch"
        if arguments[:3] == ["shell", "am", "force-stop"]:
            return "application stop"
        if arguments[:2] == ["shell", "pidof"]:
            return "process inspection"
        if arguments[:3] == ["shell", "dumpsys", "activity"]:
            return "foreground inspection"
        if arguments[:2] == ["shell", "run-as"] or arguments[:2] == ["exec-out", "run-as"]:
            return "controlled app file access"
        return "command"

    def execute_bytes(self, arguments: list[str], *, target: str | None = None,
                      timeout: int = 20, check: bool = True) -> bytes:
        """Run one bounded ADB command without decoding binary target output."""
        command = list(self.command)
        if target:
            command += ["-s", target]
        try:
            result = subprocess.run(
                [*command, *arguments], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                timeout=timeout, check=False)
        except subprocess.TimeoutExpired as error:
            raise RuntimeError("ADB binary operation timed out") from error
        if check and result.returncode != 0:
            raise RuntimeError("ADB binary operation failed")
        return result.stdout

    @staticmethod
    def _validate_debug_app_file(package: str, relative_path: str) -> None:
        path = PurePosixPath(relative_path)
        if (not re.fullmatch(r"[A-Za-z0-9_]+(?:[.][A-Za-z0-9_]+)+", package)
                or not relative_path or "\\" in relative_path or path.is_absolute()
                or any(part in {"", ".", ".."} for part in path.parts)
                or str(path) != relative_path):
            raise RuntimeError("debug app file selector is unsafe")

    def shell(self, target: str, *arguments: str, check: bool = True) -> str:
        return self.execute(["shell", *arguments], target=target, check=check)

    def prop(self, target: str, name: str) -> str:
        return self.shell(target, "getprop", name, check=False).strip()

    def properties(self, target: str, names: tuple[str, ...] | None = None) -> dict[str, str]:
        """Read one fresh property snapshot without logging private values."""
        requested = set(names) if names is not None else None
        values = {}
        for line in self.shell(target, "getprop").splitlines():
            match = re.fullmatch(r"\[([^\[\]]+)\]: \[(.*)\]", line)
            if match and (requested is None or match[1] in requested):
                if match[1] in values:
                    raise RuntimeError("Android property snapshot contains duplicate entries")
                values[match[1]] = match[2]
        return values if names is None else {name: values.get(name, "") for name in names}

    def epoch_milliseconds(self, target: str) -> int:
        """Read the target clock so native samples do not use the host epoch."""
        value = self.shell(target, "date", "+%s%3N").strip()
        if not re.fullmatch(r"[1-9][0-9]{12}", value):
            raise RuntimeError("Android native clock is unavailable")
        return int(value)

    def authorized_targets(self) -> list[str]:
        lines = self.execute(["devices", "-l"]).splitlines()
        return [parts[0] for line in lines
                if len(parts := line.split()) >= 2 and parts[1] == "device"]

    def require_connected(self, target: str, *, attempts: int = 1,
                          interval_seconds: float = 0.25) -> None:
        if (isinstance(attempts, bool) or not isinstance(attempts, int)
                or not 1 <= attempts <= 120
                or isinstance(interval_seconds, bool)
                or not isinstance(interval_seconds, (int, float))
                or not 0.0 <= interval_seconds <= 1.0):
            raise RuntimeError("ADB connection retry policy is invalid")
        host, separator, port = target.rpartition(":")
        network_target = bool(
            separator and host and port.isdigit() and 1 <= int(port) <= 65535)
        for attempt in range(attempts):
            if self.execute(
                    ["get-state"], target=target, check=False).strip() == "device":
                return
            if attempt == 0 and network_target:
                # `get-state` does not recreate a dropped ADB-over-TCP
                # transport. Keep the reconnect scoped to the exact selected
                # endpoint and suppress ADB's selector-bearing response.
                try:
                    self.execute(
                        ["connect", target], timeout=5, check=False)
                except RuntimeError:
                    pass
            if attempt + 1 < attempts:
                time.sleep(interval_seconds)
        raise RuntimeError("target is not connected and authorized")

    def read_debug_app_file(self, target: str, package: str, relative_path: str,
                            *, attempts: int = 60, interval_seconds: float = 0.25) -> str:
        """Read one app-private debug artifact without granting broad storage access."""
        self._validate_debug_app_file(package, relative_path)
        if attempts < 1 or interval_seconds < 0:
            raise RuntimeError("debug app file retry policy is invalid")
        for attempt in range(attempts):
            raw = self.shell(target, "run-as", package, "cat", relative_path, check=False)
            if raw:
                return raw
            if attempt + 1 < attempts:
                time.sleep(interval_seconds)
        return ""

    def write_debug_app_file(self, target: str, package: str, relative_path: str,
                             content: str) -> None:
        """Atomically write one fixed app-private debug control file through run-as."""
        self._validate_debug_app_file(package, relative_path)
        if (not isinstance(content, str) or "\0" in content
                or len(content.encode("utf-8")) > 16 * 1024):
            raise RuntimeError("debug app file content is invalid or oversized")
        script = ('umask 077; temporary="$1.tmp"; cat > "$temporary" '
                  '&& chmod 600 "$temporary" && mv "$temporary" "$1"')
        # `adb shell ARG...` joins its host-side arguments into one remote
        # command line.  Preserve the `sh -c` script and positional arguments
        # explicitly instead of relying on host argv boundaries that are lost
        # before Android's shell parses the command.
        remote = " ".join(shlex.quote(value) for value in (
            "run-as", package, "sh", "-c", script,
            "overte-e2e-write", relative_path,
        ))
        self.execute(["shell", remote], target=target, input_text=content)
        if self.read_debug_app_file(
                target, package, relative_path, attempts=1) != content:
            raise RuntimeError("debug app control file could not be confirmed")

    def process_state(self, target: str, package: str) -> dict:
        pid = self.shell(target, "pidof", "-s", package, check=False).strip()
        if not pid.isdigit():
            return {"running": False, "identity": None}
        stat = self.shell(target, "cat", f"/proc/{pid}/stat", check=False).strip().split()
        start_ticks = stat[21] if len(stat) > 21 and stat[21].isdigit() else "unknown"
        return {"running": True, "identity": f"{pid}:{start_ticks}"}

    def foreground_package(self, target: str) -> str | None:
        activities = self.shell(target, "dumpsys", "activity", "activities", check=False)
        pattern = re.compile(
            r"^\s*(?:mResumedActivity|topResumedActivity|ResumedActivity|Resumed):.*?\s([A-Za-z0-9._]+)/(?:[A-Za-z0-9._$]+)")
        for line in activities.splitlines():
            if match := pattern.search(line):
                return match.group(1)
        return None

    @staticmethod
    def integer_match(pattern: str, text: str) -> int | None:
        match = re.search(pattern, text, re.MULTILINE | re.IGNORECASE)
        return int(match.group(1)) if match else None

    def telemetry_snapshot(self, target: str, package: str) -> dict:
        before = self.process_state(target, package)
        identity = before.get("identity")
        if before.get("running") is not True or not isinstance(identity, str) or not re.fullmatch(r"[1-9][0-9]*:[0-9]+", identity):
            raise RuntimeError("memory telemetry requires a stable running application process")
        pid = identity.split(":", 1)[0]
        memory = self.shell(target, "dumpsys", "meminfo", pid, check=False)
        status = self.shell(target, "run-as", package, "cat", f"/proc/{pid}/status", check=False)
        pss = self.integer_match(r"^\s*TOTAL\s+(\d+)(?:\s|$)", memory)
        if pss is None:
            pss = self.integer_match(r"^\s*TOTAL(?: PSS)?:\s*(\d+)", memory)
        rss = self.integer_match(r"^VmRSS:\s*(\d+)\s+kB\s*$", status)
        if rss is None:
            rss = self.integer_match(r"\bTOTAL RSS:\s*(\d+)", memory)
        if pss is None or rss is None:
            rollup = self.shell(target, "run-as", package, "cat", f"/proc/{pid}/smaps_rollup", check=False)
            if pss is None:
                pss = self.integer_match(r"^Pss:\s*(\d+)\s+kB\s*$", rollup)
            if rss is None:
                rss = self.integer_match(r"^Rss:\s*(\d+)\s+kB\s*$", rollup)
        battery = self.shell(target, "dumpsys", "battery", check=False)
        thermal = self.shell(target, "dumpsys", "thermalservice", check=False)
        if self.process_state(target, package).get("identity") != identity:
            raise RuntimeError("application process changed during memory telemetry")
        return {
            "batteryLevel": self.integer_match(r"^\s*level:\s*(\d+)", battery),
            "batteryTemperatureDeciC": self.integer_match(
                r"^\s*temperature:\s*(\d+)", battery),
            "memoryPssKb": pss,
            "memoryRssKb": rss,
            "thermalStatus": self.integer_match(
                r"(?:Thermal Status:|mStatus=)\s*(\d+)", thermal),
        }
