"""Exactly1 approved host cases, outer30/kill5 external; no connected/native."""
from pathlib import Path
import hashlib,json,os,signal,subprocess,unittest
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[1]
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics',
       'libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
PREFIXES=('assets-image-processing-image-metadata-',)

def entry(path):
    a=path.lstat();raw=path.read_bytes();b=path.lstat()
    before={key:getattr(a,key) for key in FIELDS};after={key:getattr(b,key) for key in FIELDS}
    assert before==after,'Source/original changed during read: '+str(path)
    return dict(stat=after,sha256=hashlib.sha256(raw).hexdigest())
def census():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths=[REPO/name for name in names if name]+[Path(__file__).resolve(),HERE/'metadata1-actual-own-hunks.json']
    return {str(path.relative_to(REPO)):entry(path) for path in sorted(paths)}
def stopped(_signal,_frame):
    print('ACTUAL_OUTER30_TERMINATION',flush=True);raise SystemExit(124)
signal.signal(signal.SIGTERM,stopped)
print('RUNNER_PID',os.getpid(),'PARENT_PID',os.getppid(),flush=True)
old_roots={p for p in (REPO/'.ios-host-tmp').iterdir() if p.is_dir() and p.name.startswith(PREFIXES)}
before=census();(HERE/'metadata1-first-before.json').write_text(json.dumps(before,indent=2)+'\n')
print('SOURCE_LAUNCHER_PINS_BEFORE',len(before),flush=True)
result=None
try:
    names=('test_ios_assets_image_processing.AssetsImageProcessingTests.test_actual_image_target_definition_over_all_eight_option_combinations_without_configure',)
    suite=unittest.defaultTestLoader.loadTestsFromNames(names);assert suite.countTestCases()==1,suite.countTestCases()
    print('EXACT_HOST_CASES',suite.countTestCases(),flush=True)
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
finally:
    after=census();(HERE/'metadata1-first-after.json').write_text(json.dumps(after,indent=2)+'\n')
    assert before==after,'Source/launcher/own-hunks bytes, metadata or membership changed'
    roots=sorted(p for p in (REPO/'.ios-host-tmp').iterdir() if p.is_dir() and p.name.startswith(PREFIXES) and p not in old_roots)
    retained=[dict(root=str(root),files={str(p.relative_to(root)):entry(p) for p in sorted(root.rglob('*')) if p.is_file()}) for root in roots]
    (HERE/'metadata1-first-retention.json').write_text(json.dumps(dict(roots=retained,sourceLauncherPins=len(after)),indent=2)+'\n')
    print('SOURCE_LAUNCHER_PINS_UNCHANGED',len(after),'RETAINED_ROOTS',len(roots),'RETAINED_FILES',sum(len(row['files']) for row in retained),flush=True)
raise SystemExit(result is None or not result.wasSuccessful())
