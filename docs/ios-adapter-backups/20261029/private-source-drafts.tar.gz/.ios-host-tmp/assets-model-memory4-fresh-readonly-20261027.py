"""One diagnostic only: original decoder cost, not admission qualification."""
from contextlib import ExitStack
import cProfile
import builtins
import hashlib
import json
import marshal
import os
from pathlib import Path
import pstats
import signal
import socket
import subprocess
import time
import traceback
from unittest.mock import patch
from adapters.asset_backend_client import AssetsBackendClient
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.lock import ScriptSourceLock
from ios.adapters.assets_image_ownership import ImageInventoryContext
from ios.adapters.assets_session_owners import inspect_directory
from ios.adapters.assets_model_sources import AssetsModelSources
from ios.self_tests.assets_reply_fixture import RUN,TICKET

root=Path('.ios-host-tmp/assets-model-memory-fresh-8qtouj01').resolve(strict=True)
assert root.parent==Path('.ios-host-tmp').resolve(strict=True)
assert (root/'assets.lock').is_file()
binding=json.loads((root/('ios-assets-'+RUN+'-primary-model.json')).read_text())['binding']
def census():
    return {p.name:dict(device=p.stat().st_dev,inode=p.stat().st_ino,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        for p in root.iterdir() if p.is_file()}
before=census();assert len(before)==148
Path('.ios-host-tmp/assets-model-memory4-fresh-census-before-20261027.json').write_text(json.dumps(before,sort_keys=True))
counts={}
def forbidden(kind):
    def reject(*args,**kwargs):
        counts[kind]=counts.get(kind,0)+1
        raise AssertionError('Readonly diagnostic attempted '+kind)
    return reject
original_open,original_os_open=builtins.open,os.open
def readonly_open(file,mode='r',*args,**kwargs):
    if any(flag in mode for flag in 'wax+'):return forbidden('open-write')()
    return original_open(file,mode,*args,**kwargs)
def readonly_descriptor(file,flags,*args,**kwargs):
    if flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):return forbidden('descriptor-write')()
    return original_os_open(file,flags,*args,**kwargs)
profiles=[];started=time.monotonic()
def deadline(*args):raise TimeoutError('Diagnostic outer deadline')
signal.signal(signal.SIGTERM,deadline)
lock=ScriptSourceLock(root/'assets.lock')
try:
    with lock.held(),ExitStack() as stack:
        for target in ('socket.socket','socket.create_connection','subprocess.Popen','urllib.request.build_opener',
                'adapters.asset_backend_client.build_opener','feature_journeys.witness.Client.request',
                'ios.adapters.feature_observation.FeatureObservation.send',
                'adapters.native_feature_observation.NativeFeatureObservation.read',
                'ios.adapters.normal_input.NativeInput.capture','ios.adapters.normal_input.NativeInput.deliver',
                'adapters.owned_vulkan_world_frame.VulkanWorldFrameOwner.capture'):
            stack.enter_context(patch(target,side_effect=forbidden(target)))
        stack.enter_context(patch('builtins.open',side_effect=readonly_open))
        stack.enter_context(patch('os.open',side_effect=readonly_descriptor))
        for name in ('unlink','rename','replace','remove','mkdir','rmdir'):stack.enter_context(patch('os.'+name,side_effect=forbidden(name)))
        for cls,method in ((PrivateFeatureState,'write'),(PrivateFeatureState,'discard'),(OriginalFrameStore,'write')):
            stack.enter_context(patch.object(cls,method,side_effect=forbidden(method)))
        contexts={}
        try:inspect_directory(root,_contexts=contexts,image_context=None)
        except Exception as expected:
            assert type(expected).__name__=='NativeUIError'
            print('inventory refusal',[(Path(row.filename).name,row.lineno,row.name) for row in traceback.extract_tb(expected.__traceback__)])
        parsed=contexts[(RUN,'primary')]['parsed'];decoder=parsed.sources
        parsed.model.store=PrivateFeatureState(root/('ios-assets-'+RUN+'-primary-model.json'))
        for owner in (decoder,parsed.model.sources):
            owner.previous=owner.store.read();owner.lock=lock
        from ios.adapters.assets_model_creation_round import eligible
        assert eligible(decoder)
        for label,duplicate in (('private-local-creation-json',False),('private-local-creation-marshal4',False),('public-full-frame-hook',True)):
            profile=cProfile.Profile();error=None;location=[];reads={};step=time.monotonic()
            original_read=OriginalFrameStore.read;original_pending=decoder.frame
            def count_read(owner,*args,**kwargs):
                reads[owner.namespace]=reads.get(owner.namespace,0)+1
                return original_read(owner,*args,**kwargs)
            def duplicate_pending(*args,**kwargs):return original_pending(*args,**kwargs)
            with ExitStack() as comparison:
                comparison.enter_context(patch.object(OriginalFrameStore,'read',count_read))
                if duplicate:comparison.enter_context(patch.object(decoder,'frame',duplicate_pending))
                if label.endswith('marshal4'):comparison.enter_context(patch('ios.adapters.assets_model_creation_round.digest',side_effect=lambda value:marshal.dumps(value,4)))
                profile.enable()
                try:decoder.decode(decoder.previous)
                except Exception as caught:
                    error=type(caught).__name__
                    location=[dict(file=Path(row.filename).name,line=row.lineno,function=row.name) for row in traceback.extract_tb(caught.__traceback__)]
                finally:profile.disable()
            profiles.append((profile,dict(label=label,seconds=round(time.monotonic()-step,3),error=error,location=location,reads=reads)))
            if error=='TimeoutError':break
except Exception as caught:
    profiles.append((cProfile.Profile(),dict(label='harness-error',error=type(caught).__name__,location=[dict(file=Path(row.filename).name,line=row.lineno,function=row.name) for row in traceback.extract_tb(caught.__traceback__)])))
finally:
    after=census()
    Path('.ios-host-tmp/assets-model-memory4-fresh-census-after-20261027.json').write_text(json.dumps(after,sort_keys=True))
    print('diagnostic only',json.dumps(dict(seconds=round(time.monotonic()-started,3),forbidden=counts,
        originals=len(before),unchanged=before==after),sort_keys=True))
    for profile,result in profiles:
        print('comparison',json.dumps(result,sort_keys=True))
        if profile.getstats():pstats.Stats(profile).strip_dirs().sort_stats('cumulative').print_stats(20)
    assert before==after and not counts
