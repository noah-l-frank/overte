from pathlib import Path
import cProfile, hashlib, json, pstats, signal, sys, time
from unittest.mock import patch
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import scope as reads
from ios.adapters.assets_session_owners import inspect_directory
from ios.adapters.feature_observation import FeatureObservation
from ios.adapters.normal_input import NativeInput
root=Path('.ios-host-tmp/tmpncj53r6y').resolve(strict=True)
base=Path('.ios-host-tmp').resolve(strict=True)
assert root.parent==base
output=base/'assets-baked-profile-20261026'
def inventory():
    return {p.name:dict(device=p.stat().st_dev,inode=p.stat().st_ino,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in root.iterdir() if p.is_file()}
def forbidden(*args,**kwargs):raise AssertionError('Read-only retained profile forbids SDK/Input/HTTP/writes')
def interrupted(*args):raise TimeoutError('bounded retained profile alarm')
before=inventory();(output.with_suffix('.before.json')).write_text(json.dumps(before,sort_keys=True))
profile=cProfile.Profile();status='incomplete';started=time.monotonic();actual=set()
signal.signal(signal.SIGALRM,interrupted);signal.alarm(55)
try:
    with patch.object(PrivateFeatureState,'write',side_effect=forbidden),patch.object(FeatureObservation,'send',side_effect=forbidden),patch.object(NativeInput,'_request',side_effect=forbidden),patch('urllib.request.build_opener',side_effect=forbidden),patch('subprocess.Popen',side_effect=forbidden),reads(fresh=True) as actual:
        profile.enable();rows=inspect_directory(root);profile.disable();status='complete-read-only'
except TimeoutError:status='partial-timeout'
except BaseException as error:status='error-'+type(error).__name__;raise
finally:
    signal.alarm(0);profile.disable();profile.dump_stats(str(output.with_suffix('.pstats')))
    after=inventory();(output.with_suffix('.after.json')).write_text(json.dumps(after,sort_keys=True))
    print('status',status,'seconds',round(time.monotonic()-started,3),'originalFiles',len(before),'actualReads',len(actual),'unchanged',before==after,flush=True)
    assert before==after
    pstats.Stats(profile,stream=sys.stdout).sort_stats('cumulative').print_stats(32)
