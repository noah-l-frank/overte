from pathlib import Path
import ast,hashlib,json,difflib
R=Path('/home/user/Documents/github/overte-ios-feature-adapters-resume-20261026');T=R/'.ios-host-tmp';P=T/'lifecycle-original-owner-final-source-integration-20261028';h=lambda b:hashlib.sha256(b).hexdigest()
def load(name):return json.loads((T/name/'manifest.json').read_text())
repo={};origins={}
def collect(name):
 for p in (T/name/'candidate/repo').rglob('*'):
  if p.is_file():repo[str(p.relative_to(T/name/'candidate/repo'))]=p
collect('lifecycle-original-owner-python-packaging-proposal-20261028')
repo.pop('tests/device/ios/remotexpc_tunnel.py')
collect('lifecycle-original-owner-appium-assembly-proposal-20261028')
collect('lifecycle-original-owner-readonly-preflight-ddi-proposal-20261028')
repo['tests/device/ios/appium_wda_host_ops.js']=T/'lifecycle-original-wda-session-observed-revocation-overlay-20261028/candidate/repo/tests/device/ios/appium_wda_host_ops.js'
repo['tests/device/ios/process_plugin/index.cjs']=T/'lifecycle-original-owner-route-draft-20261028/candidates/repo/tests/device/ios/process_plugin/index.cjs'
repo['tests/device/ios/adapters/touch_lease.py']=R/'tests/device/ios/adapters/touch_lease.py'
selected=[];diff=[]
for rel,src in sorted(repo.items()):
 b=src.read_bytes();target=R/rel;old=target.read_bytes() if target.is_file() else b'';q=P/'candidate/repo'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 if old:
  op=P/'originals/repo'/rel;op.parent.mkdir(parents=True,exist_ok=True);op.write_bytes(old)
 if q.suffix=='.py':ast.parse(b,filename=str(q))
 selected.append(dict(path=rel,source=str(src),sourceSHA256=h(b),candidate=str(q),candidateSHA256=h(b),currentPublicSHA256=h(old) if target.is_file() else None,requiresChange=b!=old))
 if b!=old:diff.extend(difflib.unified_diff(old.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel))
# Exact full SDK originals for actual source/loaded/declarations, and SDK Python2.
SDK=Path('/usr/local/lib/overte-ios-remotexpc/5.15.3-r12');originals=[]
for name in ['lifecycle-authenticated-creator-draft-20261028','lifecycle-original-owner-route-draft-20261028']:
 pin_name='current-source-pins.json' if name.startswith('lifecycle-authenticated') else 'source-pins.json'
 for row in json.loads((T/name/pin_name).read_text()):
  p=Path(row['path'])
  if SDK in p.parents:originals.append((p,row['sha256']))
for row in load('lifecycle-original-owner-loaded-mirrors-20261028')['files']:
 originals.append((Path(row['source']),row['sourceSHA256']))
for row in load('lifecycle-original-owner-loaded-mirrors-20261028')['references']:
 originals.append((Path(row['source']),row['sha256']))
for row in load('lifecycle-original-owner-readonly-preflight-ddi-proposal-20261028')['references']:
 originals.append((Path(row['source']),row['sha256']))
refs=[]
for p,expected in sorted(dict(originals).items(),key=lambda x:str(x[0])):
 b=p.read_bytes();assert h(b)==expected,(str(p),'original drift')
 v=p.stat();rel=str(p.relative_to(SDK));q=P/'read-reference/sdk'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 refs.append(dict(path=str(p),copy=str(q),sha256=h(b),stat=[v.st_dev,v.st_ino,v.st_mode,v.st_uid,v.st_gid,v.st_size,v.st_mtime_ns,v.st_ctime_ns]))
# Static literal-import dependency inventory only: parse bytes, NEVER import or
# call target closure function. Includes parent initializers and relative edges.
root=R/'tests/device';pending=['ios.adapters.touch_lease','ios.adapters.hid_session','ios.adapters.lifecycle_touch_transport'];seen=set();members={};outside=set();dynamic=[]
def resolve(name):
 if not all(x.isidentifier() for x in name.split('.')):return None
 for p in (root.joinpath(*name.split('.')).with_suffix('.py'),root.joinpath(*name.split('.'))/'__init__.py'):
  if p.is_file():assert p.resolve()==p and 'self_tests' not in p.parts;return p
 return None
while pending:
 name=pending.pop()
 if name in seen:continue
 seen.add(name);p=resolve(name)
 if p is None:outside.add(name);continue
 b=p.read_bytes();members[str(p.relative_to(root))]=(p,b)
 for count in range(1,len(name.split('.'))):pending.append('.'.join(name.split('.')[:count]))
 package=name if p.name=='__init__.py' else name.rpartition('.')[0]
 for n in ast.walk(ast.parse(b)):
  if isinstance(n,ast.Import):pending.extend(x.name for x in n.names)
  elif isinstance(n,ast.ImportFrom):
   prefix=package.split('.') if package else []
   assert not n.level or n.level<=len(prefix)
   base='.'.join(prefix[:len(prefix)-n.level+1]+((n.module or '').split('.') if n.module else [])) if n.level else n.module or ''
   if base:pending.append(base);pending.extend(base+'.'+x.name for x in n.names if x.name!='*')
  elif isinstance(n,ast.Call) and ((isinstance(n.func,ast.Name) and n.func.id=='__import__') or (isinstance(n.func,ast.Attribute) and n.func.attr=='import_module')):
   if n.args and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str):pending.append(n.args[0].value)
   else:dynamic.append(dict(source=str(p),line=n.lineno))
closure=[]
for rel,(p,b) in sorted(members.items()):
 q=P/'read-reference/repo-closure'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);v=p.stat()
 closure.append(dict(path=str(p),copy=str(q),sha256=h(b),stat=[v.st_dev,v.st_ino,v.st_mode,v.st_uid,v.st_gid,v.st_size,v.st_mtime_ns,v.st_ctime_ns]))
(P/'python-static-closure.json').write_text(json.dumps(dict(status='READ AST ONLY; NOT IMPORTED OR ASSEMBLED',files=closure,outsideCanonicalRoot=sorted(outside),nonliteralDynamicImportCalls=dynamic,closedImportGraphQualified=False),indent=2)+'\n')
# Actual final payload mirrors are the SDK candidates used by source models.
profile=json.loads((P/'candidate/repo/tests/device/ios/original-owner-appium-sources.json').read_text());sdk_candidates=[]
for row in profile['sources']:
 p=P/'candidate/repo/tests/device/ios'/row['payload'];assert h(p.read_bytes())==row['payloadSha256']
 sdk_candidates.append(dict(path=row['path'],candidate=str(p),sha256=row['payloadSha256'],originalSHA256=row['originalSha256']))
# Copy existing3 Python WDA route cases unchanged, no target/module imports.
q=P/'test_existing_wda_route_models.py';q.write_bytes((T/'lifecycle-original-wda-session-route-overlay-20261028/test_existing_wda_route_models.py').read_bytes());ast.parse(q.read_bytes())
by={r['path']:r for r in sdk_candidates}
node_map={role:{'path':by[path]['candidate'],'sha256':by[path]['sha256']} for role,path in {
 'proxy':'node_modules/appium-xcuitest-driver/node_modules/@appium/base-driver/build/lib/jsonwp-proxy/proxy.js',
 'api':'node_modules/appium-xcuitest-driver/node_modules/appium-ios-remotexpc/build/src/lib/tunnel/tunnel-api-client.js',
 'server':'node_modules/appium-ios-remotexpc/build/src/lib/tunnel/tunnel-registry-server.js'}.items()}
host=next(r for r in selected if r['path']=='tests/device/ios/appium_wda_host_ops.js');node_map['hostops']={'path':host['candidate'],'sha256':host['candidateSHA256']}
(P/'node-model-source-map.json').write_text(json.dumps(node_map,indent=2)+'\n')
cases=[]
for module in ['test_owner_readonly_preflight_models','test_existing_wda_route_models']:
 tree=ast.parse((P/(module+'.py')).read_bytes())
 for cls in tree.body:
  if isinstance(cls,ast.ClassDef):
   for n in cls.body:
    if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith('test_'):cases.append(module+'.'+cls.name+'.'+n.name)
assert len(cases)==11
text=(P/'test_actual_loaded_owner_routes.mjs').read_text();node_cases=[x.split("',",1)[0] for x in text.split("test('")[1:]];assert len(node_cases)==9
plan=dict(status='PRIVATE ROOT REVIEW PREPARATION; UNRUN',repositoryRoot=str(R),initialTimeoutSeconds=90,killGraceSeconds=5,pythonCases=cases,nodeCases=node_cases,caseCount=20,fixtureOriginalRootsExpected=0,fixtureRootExpectationIsEvidence=False,modelsOnly=True,SDKImported=False,productionGate=False,publicExpected={r['path']:r['candidateSHA256'] for r in selected},sdkOriginals=refs,closure=closure,sdkCandidates=sdk_candidates)
(P/'test-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
(P/'integration.diff').write_text(''.join(diff))
manifest=dict(status='PRIVATE COMPOSED REVIEW ONLY UNRUN',repoFiles=selected,repoFileCount=len(selected),repoChangedCount=sum(r['requiresChange'] for r in selected),sdkOriginalFiles=refs,sdkCandidateFiles=sdk_candidates,closureManifestSHA256=h((P/'python-static-closure.json').read_bytes()),modelCounts={'python':11,'node':9},noNewArchitecture=True,productionGate=False,authQualified=False,SDKInstalled=False,nativeTouchSupport=False)
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'repo':len(selected),'changed':sum(r['requiresChange'] for r in selected),'SDKoriginals':len(refs),'closure':len(closure),'dynamic':dynamic,'node9':node_cases},indent=2))
