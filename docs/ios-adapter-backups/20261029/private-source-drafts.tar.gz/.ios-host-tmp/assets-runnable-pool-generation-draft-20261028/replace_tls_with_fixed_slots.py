"""Private design correction; no Qt/native execution."""
from pathlib import Path
h=Path(__file__).resolve().parent
p=h/'qt-pool-protocol-api.inc';s=p.read_text().replace('MaxPools=64,MaxRegistrations=64','MaxPools=64,MaxThreads=128,MaxRegistrations=64');p.write_text(s)
p=h/'qt-pool-protocol-implementation.inc';s=p.read_text()
s=s.replace('struct PoolState {','''struct PoolThreadCell {
    // Qt::HANDLE never leaves the SDK. It selects a bounded context slot,
    // not a certified OS-thread lifetime generation. All mutable fields are
    // atomic so even a reused OS handle cannot race stale non-atomic state.
    std::atomic<Qt::HANDLE> key{nullptr};
    std::atomic<quint64> currentAdmission{0},lastTakenAdmission{0};
};
struct PoolState {''').replace('slots{0},threads{0},operations','slots{0},operations')
s=s.replace('    PoolRegistrationCell registration[PoolSnapshot::MaxRegistrations];','    PoolThreadCell thread[PoolSnapshot::MaxThreads];\n    PoolRegistrationCell registration[PoolSnapshot::MaxRegistrations];')
s=s.replace('thread_local quint64 poolThread=0,poolCurrentAdmission=0,poolLastTakenAdmission=0;','static_assert(std::atomic<Qt::HANDLE>::is_always_lock_free);')
a='''quint64 poolThreadId() noexcept {
    if (!poolThread) {poolThread=poolState.threads.fetch_add(1,std::memory_order_relaxed)+1;}
    return poolThread;
}'''
b='''PoolThreadCell* poolThreadCell() noexcept {
    if (!poolArmed()) {return nullptr;}
    // Exact Qt6.11.1 Darwin ARM64 fallback is currentThreadIdImpl() ->
    // to_HANDLE(pthread_self()). No QThread/QObject is obtained or read.
    const auto key=QThread::currentThreadId();if (!key) {poolFail();return nullptr;}
    for (auto& row:poolState.thread) {
        auto found=row.key.load(std::memory_order_acquire);
        if (found==key) {return &row;}
        if (!found && row.key.compare_exchange_strong(found,key,std::memory_order_acq_rel)) {return &row;}
    }
    poolFail();return nullptr;
}
quint64 poolThreadId() noexcept {
    auto* row=poolThreadCell();return row ? quint64(row-poolState.thread)+1 : 0;
}
quint64 poolCurrent() noexcept {auto* row=poolThreadCell();return row ? row->currentAdmission.load(std::memory_order_relaxed) : 0;}
void poolSetCurrent(quint64 id) noexcept {if (auto* row=poolThreadCell()) {row->currentAdmission.store(id,std::memory_order_relaxed);}}
quint64 poolTakeLast() noexcept {auto* row=poolThreadCell();return row ? row->lastTakenAdmission.exchange(0,std::memory_order_relaxed) : 0;}
void poolSetLast(quint64 id) noexcept {if (auto* row=poolThreadCell()) {row->lastTakenAdmission.store(id,std::memory_order_relaxed);}}'''
assert a in s;s=s.replace(a,b)
s=s.replace('return poolCurrentAdmission;','return poolCurrent();').replace('const auto value=poolLastTakenAdmission;poolLastTakenAdmission=0;return value;','return poolTakeLast();')
s=s.replace('_previous(poolCurrentAdmission)','_previous(poolCurrent())').replace('poolCurrentAdmission=0;','poolSetCurrent(0);').replace('poolCurrentAdmission=_admission;','poolSetCurrent(_admission);').replace('poolCurrentAdmission=_previous;','poolSetCurrent(_previous);').replace('poolCurrentAdmission=admission;','poolSetCurrent(admission);')
s=s.replace('poolLastTakenAdmission=0;','poolSetLast(0);').replace('poolLastTakenAdmission=_returned && _removed ? _admission : 0;','poolSetLast(_returned && _removed ? _admission : 0);')
assert 'thread_local' not in s and 'poolCurrentAdmission' not in s and 'poolLastTakenAdmission' not in s
p.write_text(s)
p=h/'tests/device/ios/adapters/assets_image_reader_pool.py';s=p.read_text().replace("integer(event['threadId'],1,2**53-1)","integer(event['threadId'],1,128)");p.write_text(s)
