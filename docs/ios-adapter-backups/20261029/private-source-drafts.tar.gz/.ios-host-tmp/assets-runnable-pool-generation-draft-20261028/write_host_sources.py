"""Construct private drafts; never import or run test entry points."""
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
OUT=HERE/'tests/device/ios/adapters';OUT.mkdir(parents=True,exist_ok=True)
# Preserve the existing one-attempt WAL, unknown-delivery and original-frame
# mechanics with a separate namespace. Actual three-original binding below.
s=(ROOT/'tests/device/ios/adapters/assets_image_storage_sources.py').read_text()
for a,b in [('assets_image_storage','assets_image_pool'),('AssetsImageReaderStorageSources','AssetsImageReaderPoolSources'),('StorageRawSources','PoolRawSources'),('ImageReaderStorageSources','ImageReaderPoolSources'),('ImageStorage','ImagePool'),('image-storage','image-pool'),('Storage/Source1','Pool/Storage/Source1'),('ImageReader storage','ImageReader pool')]:s=s.replace(a,b)
s=s.replace('assets_image_reader_storage as storage_source','assets_image_reader_storage as storage_source,assets_image_reader_pool as pool_source')
s=s.replace('*,native,storage,image_reader,epoch_ms,monotonic','*,native,pool,storage,image_reader,epoch_ms,monotonic')
s=s.replace('and type(storage) is storage_source.IOSAssetsImageReaderStorage','and type(pool) is pool_source.IOSAssetsImageReaderPool and type(storage) is storage_source.IOSAssetsImageReaderStorage')
s=s.replace('self.readers=dict(storage=storage,reader=image_reader)','self.readers=dict(pool=pool,storage=storage,reader=image_reader)')
s=s.replace('(native,storage,image_reader)','(native,pool,storage,image_reader)')
s=s.replace("storage._parent_history=deepcopy(image_reader.last)","storage._parent_history=deepcopy(image_reader.last);pool.last=deepcopy(sample['originals']['pool']);pool._storage_history=deepcopy(storage.last)")
s=s.replace("return {'storage':storage_source,'reader':reader_source}[kind]","return {'pool':pool_source,'storage':storage_source,'reader':reader_source}[kind]")
s=s.replace("'nativeBarrier','storage','reader','storageAcquisition','readerAcquisition','bindingHostSpan'","'nativeBarrier','pool','storage','reader','poolAcquisition','storageAcquisition','readerAcquisition','bindingHostSpan'")
s=s.replace("same(external,[originals['storage'],originals['reader']])","same(external,[originals['pool'],originals['storage'],originals['reader']])")
s=s.replace("for key,module,acquisition_key in (('storage',storage_source", "for key,module,acquisition_key in (('pool',pool_source,'iosAssetsImageReaderPoolAcquisitionVersion'),\n                ('storage',storage_source")
s=s.replace("storage_source.parent_links(originals['storage'],originals['reader'])","pool_source.parent_links(originals['pool'],originals['storage'],originals['reader'])")
s=s.replace("need(originals['storage']['source']['assetImageReaderStorageHistoryVersion']==1)","need(originals['pool']['source']['assetImageReaderPoolHistoryVersion']==1)")
s=s.replace("storage=self.readers['storage'];packet=storage.read(self.run,source1=self.readers['reader'])", "pool=self.readers['pool'];packet=pool.read(self.run,storage=self.readers['storage'],source1=self.readers['reader'])")
s=s.replace("storage=packet,reader=deepcopy(storage.parent_original),\n                storageAcquisition=deepcopy(storage.acquisition),readerAcquisition=deepcopy(storage.parent_acquisition),bindingHostSpan=list(storage.binding_host_span)","pool=packet,storage=deepcopy(pool.storage_original),reader=deepcopy(pool.parent_original),\n                poolAcquisition=deepcopy(pool.acquisition),storageAcquisition=deepcopy(pool.storage_acquisition),\n                readerAcquisition=deepcopy(pool.parent_acquisition),bindingHostSpan=list(pool.binding_host_span)")
(OUT/'assets_image_pool_sources.py').write_text(s)
s=(ROOT/'tests/device/ios/adapters/assets_image_storage_ownership.py').read_text()
for a,b in [('assets_image_storage','assets_image_pool'),('AssetsImageReaderStorageSources','AssetsImageReaderPoolSources'),('StorageRawSources','PoolRawSources'),('ImageStorage','ImagePool'),('image-storage','image-pool'),('Storage/Source1','Pool/Storage/Source1'),('ImageReader storage','ImageReader pool')]:s=s.replace(a,b)
s=s.replace('dict(storage=None,reader=None)','dict(pool=None,storage=None,reader=None)')
(OUT/'assets_image_pool_ownership.py').write_text(s)
print('Private durable-source and readonly-inventory drafts written')
