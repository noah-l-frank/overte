"""Exactly135 approved explicit host IDs; run only after Root grant/publication.

Supervisor supplies the unchanged outer90/kill5. No connected/native/device
case is loaded. Qt verifier operates only on private exact-source copies.
"""
from pathlib import Path
import hashlib,json,os,signal,stat,subprocess,unittest
HERE=Path(__file__).resolve().parent;REPO=HERE.parents[2]
ROOTS=('tests/device','interface/src/scripting','libraries/material-networking','libraries/qml','libraries/graphics',
       'libraries/image','libraries/shared','libraries/gpu','libraries/gpu-vk','ios','cmake','scripts/system','interface/resources/qml')
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
PREFIXES=('assets-image-pool-small-','assets-image-pool-runtime-','qt-runnable-pool-source-test-',
    'assets-image-storage-small-','assets-image-storage-runtime-','assets-image-processing-small-','assets-image-processing-runtime-',
    'assets-image-reader-life-small-','assets-image-processing-image-metadata-')
PLAN=json.loads((HERE/'package-plan.json').read_text())
EXPECTED=json.loads((HERE/'small135-exact-case-ids.json').read_text())
assert len(EXPECTED)==len(set(EXPECTED))==135 and not any('_flow.' in name for name in EXPECTED)
REFERENCE=Path(os.environ['OVERTE_QT_CORE_POOL_SOURCE_REFERENCE_ROOT']).resolve(strict=True)
QT_FILES=json.loads((REPO/'tests/device/ios/qt-runnable-pool-source-patch.json').read_text())['sourceSha256']
assert len(QT_FILES)==2

def entry(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) and not path.is_symlink()
    raw=path.read_bytes();b=path.lstat();before={key:getattr(a,key) for key in FIELDS};after={key:getattr(b,key) for key in FIELDS}
    assert before==after,'Input changed during read: '+str(path)
    return dict(stat=after,sha256=hashlib.sha256(raw).hexdigest())
def census():
    names=subprocess.check_output(['rg','--files','-0',*ROOTS],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}
    # main.cpp is deliberately outside the broad scripting/resource roots.
    paths.add(REPO/'interface/src/main.cpp')
    paths.update(HERE/row['path'] for row in PLAN['publicationPaths'])
    paths.update(HERE/name for name in ('package-plan.json','full-private-packet.patch','own-registry-hunks.patch',
        'own-registry-keys.json','small135-exact-case-ids.json','small135-selection-provenance.json','main.cpp-explicit-pin.json',
        'reference-pins.json','run_small135.py'))
    return {str(path.relative_to(REPO)):entry(path) for path in sorted(paths)}
def stopped(_signal,_frame):
    print('ACTUAL_OUTER90_TERMINATION',flush=True);raise SystemExit(124)
def ids(suite):
    for item in suite:
        if isinstance(item,unittest.TestSuite):yield from ids(item)
        else:yield item.id()
signal.signal(signal.SIGTERM,stopped)
identity=dict(pid=os.getpid(),parentPid=os.getppid(),pgid=os.getpgid(0),sid=os.getsid(0),
    procStartToken=Path('/proc/self/stat').read_text().rpartition(')')[2].split()[19])
(HERE/'small135-runner-identity.json').write_text(json.dumps(identity,indent=2)+'\n');print('RUNNER_IDENTITY',json.dumps(identity),flush=True)
for row in PLAN['publicationPaths']:
    if row['publication']!='APPLY_13_OWN_REGISTRY_HUNKS_ONLY_PRESERVE_FOREIGN_KEYS':
        assert entry(REPO/row['path'])['sha256']==row['candidateSha256'],('Published source differs from reviewed candidate',row['path'])
for name,digest in QT_FILES.items():assert entry(REFERENCE/name)['sha256']==digest,('Unknown explicit source reference',name)
reference_before={name:entry(REFERENCE/name) for name in QT_FILES}
(HERE/'small135-reference-before.json').write_text(json.dumps(reference_before,indent=2)+'\n')
old_roots={p for p in (REPO/'.ios-host-tmp').iterdir() if p.is_dir() and p.name.startswith(PREFIXES)}
before=census();(HERE/'small135-first-before.json').write_text(json.dumps(before,indent=2)+'\n')
print('SOURCE_LAUNCHER_MAIN_PINS_BEFORE',len(before),flush=True)
result=None
try:
    # Exact method IDs prevent imported TestCase/discovery duplicates.
    suite=unittest.defaultTestLoader.loadTestsFromNames(EXPECTED);actual=list(ids(suite))
    (HERE/'small135-first-actual-case-ids.json').write_text(json.dumps(actual,indent=2)+'\n')
    print('ACTUAL_LOADED_COUNT',suite.countTestCases(),'UNIQUE',len(set(actual)),flush=True)
    assert suite.countTestCases()==135 and actual==EXPECTED and len(set(actual))==135,('Actual loader differs',actual)
    assert not any('_flow.' in name for name in actual)
    result=unittest.TextTestRunner(verbosity=2,failfast=True).run(suite)
    assert not result.skipped,('Skipped cases are not executed qualification',result.skipped)
finally:
    after=census();(HERE/'small135-first-after.json').write_text(json.dumps(after,indent=2)+'\n')
    assert before==after,'Source/launcher/main/private candidates changed'
    reference_after={name:entry(REFERENCE/name) for name in QT_FILES}
    (HERE/'small135-reference-after.json').write_text(json.dumps(reference_after,indent=2)+'\n')
    assert reference_before==reference_after,'Exact retained Qt originals changed'
    roots=sorted(p for p in (REPO/'.ios-host-tmp').iterdir() if p.is_dir() and p.name.startswith(PREFIXES) and p not in old_roots)
    retained=[dict(root=str(root),files={str(p.relative_to(root)):entry(p) for p in sorted(root.rglob('*')) if p.is_file()}) for root in roots]
    assert all(stat.S_IMODE(root.stat().st_mode)==0o700 for root in roots)
    (HERE/'small135-first-retention.json').write_text(json.dumps(dict(roots=retained,sourceLauncherPins=len(after),exactQtOriginalsUnchanged=True),indent=2)+'\n')
    print('SOURCE_LAUNCHER_MAIN_PINS_UNCHANGED',len(after),'RETAINED_ROOTS',len(roots),'RETAINED_FILES',sum(len(row['files']) for row in retained),flush=True)
raise SystemExit(result is None or not result.wasSuccessful())
