"""Private source inventory/AST parsing only; no imports/tests/native execution."""
from pathlib import Path
import ast,difflib,hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
sha=lambda data:hashlib.sha256(data).hexdigest()
app=json.loads((HERE/'app-integration-plan.json').read_text());app_bases={row['path']:row['baseSha256'] for row in app['files']}
roots=('interface','libraries','tests','ios')
paths=sorted(str(p.relative_to(HERE)) for root in roots for p in (HERE/root).rglob('*') if p.is_file())
rows=[];python=[];tests=[];patch=[]
for name in paths:
    p=HERE/name;data=p.read_bytes();actual=ROOT/name
    existing=actual.exists();base=actual.read_bytes() if existing else b''
    if name in app_bases:assert sha(base)==app_bases[name],('Public base changed; rebase private hunk',name)
    registry=name in ('tests/device/contract-versions.json','tests/device/validate_contract_versions.py')
    if registry:base=subprocess.check_output(['git','show','HEAD:'+name],cwd=ROOT)
    rows.append(dict(path=name,privatePath=str(p.relative_to(ROOT)),exists=existing,
        baseSha256=sha(base) if existing else None,sha256=sha(data),currentWorktreeSha256=sha(actual.read_bytes()) if existing else None,
        publication='OWN_REGISTRY_HUNKS_ONLY_PRESERVE_ALL_FOREIGN_KEYS' if registry else 'BASE_SHA_VERIFY_THEN_EXACT_PATH'))
    if name.endswith('.py'):
        tree=ast.parse(data.decode(),filename=name);python.append(name)
        if '/self_tests/test_' in name:
            for c in tree.body:
                if isinstance(c,ast.ClassDef):
                    tests.extend(dict(module=name,className=c.name,case=n.name,connected=name.endswith('_flow.py')) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
    if name.endswith('.json'):json.loads(data)
    patch.extend(difflib.unified_diff(base.decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),fromfile='a/'+name if existing else '/dev/null',tofile='b/'+name))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
keys=json.loads((HERE/'own-registry-keys.json').read_text())
manifest=dict(status='PRIVATE_COMPLETE_SOURCE_DRAFT_UNRUN_REQUIRES_ROOT_REVIEW_AND_PUBLICATION_GRANT',head=head,
    nativeCompilationVerified=False,qtPatchApplicationChecked=False,hostTestsExecuted=False,connectedExecuted=False,
    nativeAbiVerified=False,deviceQualified=False,adapterCompletionCount='5/14',wholeResourceRetirementAvailable=False,
    publicationPaths=rows,ownRegistryKeys=keys,parsedPythonOnly=python,
    proposedSmallCases=[r for r in tests if not r['connected']],proposedConnectedCases=[r for r in tests if r['connected']],
    dependencyPins={name:sha((ROOT/name).read_bytes()) for name in ('libraries/image/CMakeLists.txt','libraries/image/src/image/IOSImageProcessingObservation.h','tests/device/ios/adapters/assets_image_reader.py','tests/device/ios/adapters/assets_image_reader_storage.py')},
    primarySourcePins='../assets-image-reader-storage-draft-20261027/primary-qt-v6.11.1/source-pins.json',
    qtSourceTransformPlan='qt-source-patch-plan.json')
(HERE/'package-plan.json').write_text(json.dumps(manifest,indent=2)+'\n')
(HERE/'full-private-packet.patch').write_text(''.join(patch))
(HERE/'publication-paths.txt').write_text('\n'.join(paths)+'\n')
print(json.dumps(dict(privatePaths=len(rows),registryOwnKeys=len(keys),astOnly=len(python),smallAuthored=len(manifest['proposedSmallCases']),connectedAuthored=len(manifest['proposedConnectedCases']),allTests='UNRUN')))
