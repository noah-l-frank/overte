"""Publish only the reviewed33-path composition, retaining foreign Photo registry work."""
from pathlib import Path
import ast,hashlib,json,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
COMPOSE=HERE/'final-composition'
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
    plan=json.loads((COMPOSE/'package-plan.json').read_text())
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==plan['headAtComposition']
    assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=REPO)
    assert len(plan['publicationPaths'])==33
    assert not (HERE/'root-publication.json').exists(),'No repeated publication'
    registry={'tests/device/contract-versions.json','tests/device/validate_contract_versions.py'}
    before={};candidates={}
    for row in plan['publicationPaths']:
        target=REPO/row['path'];candidate=REPO/row['privatePath'];raw=candidate.read_bytes()
        assert sha(raw)==row['candidateSha256'],row['path']
        old=target.read_bytes() if target.exists() else None
        assert (sha(old) if old is not None else None)==row['currentWorktreeSha256'],row['path']
        if row['path'] not in registry:
            assert (sha(old) if old is not None else None)==row['actualBaseSha256'],row['path']
        if target.suffix=='.py':ast.parse(raw,filename=str(target))
        if target.suffix=='.json':json.loads(raw)
        candidates[row['path']]=raw
        before[row['path']]=dict(sha256=sha(old) if old is not None else None)
    for name in registry:
        original=REPO/name;backup=HERE/'prepublication-originals'/name
        backup.parent.mkdir(parents=True,exist_ok=True);backup.write_bytes(original.read_bytes())
    patch=COMPOSE/'own-registry-hunks.patch'
    subprocess.run(['git','apply','--check',str(patch)],cwd=REPO,check=True)
    for name,raw in candidates.items():
        if name in registry:continue
        target=REPO/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    subprocess.run(['git','apply',str(patch)],cwd=REPO,check=True)
    for name,raw in candidates.items():
        if name not in registry:assert (REPO/name).read_bytes()==raw,name
    old=json.loads((HERE/'prepublication-originals/tests/device/contract-versions.json').read_text())
    new=json.loads((REPO/'tests/device/contract-versions.json').read_text())
    keys=set(plan['ownRegistryKeys']);assert len(keys)==13
    def stripped(value):
        if isinstance(value,dict):return {k:stripped(v) for k,v in value.items() if k not in keys}
        if isinstance(value,list):return [stripped(v) for v in value]
        return value
    assert stripped(old)==stripped(new),'Foreign registry changes'
    rows=[dict(path=name,before=before[name],afterSha256=sha((REPO/name).read_bytes()),candidateSha256=sha(raw)) for name,raw in candidates.items()]
    (HERE/'root-publication.json').write_text(json.dumps(dict(paths=rows,head=plan['headAtComposition'],ownRegistryKeys=sorted(keys),foreignRegistryValuesPreserved=True,nativeCompiled=False,deviceQualified=False),indent=2)+'\n')
    print('Published exact33 paths with13 own registry keys; foreign values preserved.')
if __name__=='__main__':main()
