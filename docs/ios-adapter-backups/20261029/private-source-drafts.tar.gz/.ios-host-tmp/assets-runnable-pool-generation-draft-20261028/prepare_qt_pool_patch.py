"""PRIVATE exact-source transformation only; never build/compile/execute Qt."""
from pathlib import Path
import difflib,hashlib,json
HERE=Path(__file__).resolve().parent
ORIGINAL=HERE.parent/'assets-image-reader-storage-draft-20261027/primary-qt-v6.11.1'

def change(text,before,after,count=1):
    assert text.count(before)==count,(text.count(before),before)
    return text.replace(before,after)

header=(ORIGINAL/'qthreadpool_p.h').read_text()
header=change(header,'QT_BEGIN_NAMESPACE\n','QT_BEGIN_NAMESPACE\n\n'+(HERE/'qt-pool-protocol-api.inc').read_text()+'\n')
header=change(header,'        m_entries[m_lastIndex] = runnable;','''        m_entries[m_lastIndex] = runnable;
        m_featureAdmission[m_lastIndex]=qOverteE2ePoolCurrentAdmission();
        m_featureSlot[m_lastIndex]=qOverteE2ePoolEnqueued(m_featureAdmission[m_lastIndex]);''')
header=change(header,'    QRunnable *pop()\n','''    quint64 featureAdmission() const { return m_featureAdmission[m_firstIndex]; }
    QRunnable *pop(quint32 featureReason=0)
''')
header=change(header,'        m_entries[m_firstIndex] = nullptr;','''        m_entries[m_firstIndex] = nullptr;
        qOverteE2ePoolSlotRemoved(m_featureAdmission[m_firstIndex],m_featureSlot[m_firstIndex],featureReason);
        m_featureAdmission[m_firstIndex]=m_featureSlot[m_firstIndex]=0;''')
header=change(header,'    bool tryTake(QRunnable *runnable)\n','    bool tryTake(QRunnable *runnable,QOverteE2ePoolTakeScope* featureTake=nullptr)\n')
header=change(header,'                m_entries[i] = nullptr;','''                m_entries[i] = nullptr;
                qOverteE2ePoolSlotRemoved(m_featureAdmission[i],m_featureSlot[i],3);
                if (featureTake) {featureTake->removed(m_featureAdmission[i],m_featureSlot[i]);}
                m_featureAdmission[i]=m_featureSlot[i]=0;''')
header=change(header,'    QRunnable *m_entries[MaxPageSize];','''    QRunnable *m_entries[MaxPageSize];
    quint64 m_featureAdmission[MaxPageSize]{},m_featureSlot[MaxPageSize]{};''')
header=change(header,'    mutable QMutex mutex;','    quint64 featurePoolId{0};\n    mutable QMutex mutex;')
cpp=(ORIGINAL/'qthreadpool.cpp').read_text()
cpp=change(cpp,'#include <memory>\n','#include <memory>\n#include <atomic>\n#include <chrono>\n')
cpp=change(cpp,'using namespace Qt::StringLiterals;\n','using namespace Qt::StringLiterals;\n\n'+(HERE/'qt-pool-protocol-implementation.inc').read_text()+'\n')
cpp=change(cpp,'    QRunnable *runnable;','    QRunnable *runnable;\n    quint64 featureAdmission{0};')
cpp=change(cpp,'        QRunnable *r = runnable;\n        runnable = nullptr;','''        QRunnable *r = runnable;
        quint64 feature=featureAdmission;featureAdmission=0;
        runnable = nullptr;''')
cpp=change(cpp,'                const bool del = r->autoDelete();','''                const bool del = r->autoDelete();
                const QOverteE2ePoolRunScope featureRunPlaceholderDoesNotExist;''')
# Make the observer mutable; no product method is called/read a second time.
cpp=change(cpp,'                const QOverteE2ePoolRunScope featureRunPlaceholderDoesNotExist;','                QOverteE2ePoolRunScope featureRun(manager->featurePoolId,feature,r,del,1);')
cpp=change(cpp,'                    r->run();','                    r->run();\n                    featureRun.returned();')
cpp=change(cpp,'                if (del)\n                    delete r;','''                if (del) {
                    featureRun.deleting();
                    delete r;
                    featureRun.deleted();
                }''')
cpp=change(cpp,'            r = page->pop();','''            feature=page->featureAdmission();
            r = page->pop(1);
            qOverteE2ePoolWorkerAssigned(manager->featurePoolId,feature,r);''')
cpp=change(cpp,'        thread->runnable = task;','''        thread->runnable = task;
        thread->featureAdmission=qOverteE2ePoolCurrentAdmission();
        qOverteE2ePoolWorkerAssigned(featurePoolId,thread->featureAdmission,task);''')
cpp=change(cpp,'        if (!tryStart(page->first()))','''        QOverteE2ePoolTransferScope featureTransfer(page->featureAdmission());
        if (!tryStart(page->first()))''')
cpp=change(cpp,'        page->pop();','        page->pop(4);')
cpp=change(cpp,'    thread->runnable = runnable;','''    thread->runnable = runnable;
    thread->featureAdmission=qOverteE2ePoolCurrentAdmission();
    qOverteE2ePoolWorkerAssigned(featurePoolId,thread->featureAdmission,runnable);''')
cpp=change(cpp,'            QRunnable *r = page->pop();','''            const auto feature=page->featureAdmission();
            QRunnable *r = page->pop(2);''')
cpp=change(cpp,'''            if (r && r->autoDelete()) {
                locker.unlock();
                delete r;
                locker.relock();
            }''','''            if (r && r->autoDelete()) {
                QOverteE2ePoolCancelScope featureCancel(featurePoolId,feature);
                locker.unlock();
                delete r;
                featureCancel.deleted();
                locker.relock();
            } else if (feature) {
                qOverteE2ePoolUnsupported();
            }''')
cpp=change(cpp,'''    QMutexLocker locker(&d->mutex);
    for (QueuePage *page : std::as_const(d->queue)) {''','''    QOverteE2ePoolTakeScope featureTake(d->featurePoolId,runnable);
    QMutexLocker locker(&d->mutex);
    for (QueuePage *page : std::as_const(d->queue)) {''')
cpp=change(cpp,'        if (page->tryTake(runnable)) {','        if (page->tryTake(runnable,&featureTake)) {')
cpp=change(cpp,'''            return true;
        }
    }

    return false;
}''','''            featureTake.returned(true);
            return true;
        }
    }

    featureTake.returned(false);
    return false;
}''')
cpp=change(cpp,'    const bool del = runnable->autoDelete();\n\n    runnable->run();\n\n    if (del)\n        delete runnable;','''    const bool del = runnable->autoDelete();
    const auto feature=qOverteE2ePoolTakeLastAdmission();
    QOverteE2ePoolRunScope featureRun(featurePoolId,feature,runnable,del,2);

    runnable->run();
    featureRun.returned();
    if (del) {
        featureRun.deleting();
        delete runnable;
        featureRun.deleted();
    }''')
cpp=change(cpp,'''QThreadPool::QThreadPool(QObject *parent)
    : QObject(*new QThreadPoolPrivate, parent)
{
    Q_D(QThreadPool);''','''QThreadPool::QThreadPool(QObject *parent)
    : QObject(*new QThreadPoolPrivate, parent)
{
    Q_D(QThreadPool);
    d->featurePoolId=qOverteE2ePoolCreated();''')
cpp=change(cpp,'    Q_ASSERT(d->allThreads.isEmpty());\n}','    Q_ASSERT(d->allThreads.isEmpty());\n    qOverteE2ePoolDestructorBodyReturned(d->featurePoolId);\n}')
for function,kind in (('start','StartEntered'),('tryStart','TryStartEntered'),('startOnReservedThread','ReservedEntered')):
 if function=='start':
  before='''    Q_D(QThreadPool);
    QMutexLocker locker(&d->mutex);

    if (!d->tryStart(runnable))
        d->enqueueTask(runnable, priority);'''
  after='''    Q_D(QThreadPool);
    QOverteE2ePoolAdmissionScope featureCall(d->featurePoolId,runnable,QOverteE2ePoolEventKind::StartEntered);
    QMutexLocker locker(&d->mutex);

    if (!d->tryStart(runnable))
        d->enqueueTask(runnable, priority);
    featureCall.returned();'''
 elif function=='tryStart':
  before='''    Q_D(QThreadPool);
    QMutexLocker locker(&d->mutex);
    if (d->tryStart(runnable))
        return true;

    return false;'''
  after='''    Q_D(QThreadPool);
    QOverteE2ePoolAdmissionScope featureCall(d->featurePoolId,runnable,QOverteE2ePoolEventKind::TryStartEntered);
    QMutexLocker locker(&d->mutex);
    const bool accepted=d->tryStart(runnable);
    featureCall.returned(accepted);
    return accepted;'''
 else:
  before='''    Q_D(QThreadPool);
    QMutexLocker locker(&d->mutex);
    Q_ASSERT(d->reservedThreads > 0);'''
  after='''    Q_D(QThreadPool);
    QOverteE2ePoolAdmissionScope featureCall(d->featurePoolId,runnable,QOverteE2ePoolEventKind::ReservedEntered);
    QMutexLocker locker(&d->mutex);
    Q_ASSERT(d->reservedThreads > 0);'''
 cpp=change(cpp,before,after)
cpp=change(cpp,'''        d->enqueueTask(runnable, INT_MAX);
    }
}''','''        d->enqueueTask(runnable, INT_MAX);
    }
    featureCall.returned();
}''')
files={'qtbase/src/corelib/thread/qthreadpool_p.h':header,'qtbase/src/corelib/thread/qthreadpool.cpp':cpp}
rows=[];patch=[]
for name,text in files.items():
    p=HERE/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
    before=(ORIGINAL/Path(name).name).read_text();rows.append(dict(path=name,baseSha256=hashlib.sha256(before.encode()).hexdigest(),sha256=hashlib.sha256(text.encode()).hexdigest()))
    patch.extend(difflib.unified_diff(before.splitlines(keepends=True),text.splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
(HERE/'qtbase-overte-e2e-runnable-pool.patch').write_text(''.join(patch))
(HERE/'qt-source-patch-plan.json').write_text(json.dumps(dict(status='PRIVATE_SOURCE_TRANSFORM_ONLY_NO_APPLY_COMPILE_OR_RUNTIME_CHECK',qtVersion='6.11.1',apiVersion=1,files=rows),indent=2)+'\n')
print('PRIVATE transformed exactQt2sourceFiles; no git apply/build/compile/runtime')
