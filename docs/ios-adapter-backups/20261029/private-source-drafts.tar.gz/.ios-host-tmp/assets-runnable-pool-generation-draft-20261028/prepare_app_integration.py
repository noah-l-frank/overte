"""Private source drafts only. Does not apply, configure, build, or execute C++."""
from pathlib import Path
import difflib,hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent.parent
rows=[];patch=[]
def change(s,a,b):
    assert s.count(a)==1,(s.count(a),a)
    return s.replace(a,b)
def save(name,transform):
    source=(ROOT/name).read_text();result=transform(source)
    out=HERE/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(result)
    rows.append(dict(path=name,baseSha256=hashlib.sha256(source.encode()).hexdigest(),sha256=hashlib.sha256(result.encode()).hexdigest()))
    patch.extend(difflib.unified_diff(source.splitlines(keepends=True),result.splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
save('interface/src/main.cpp',lambda s:change(change(s,'#include <BuildInfo.h>','#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD)\n#include <material-networking/IOSAssetsImageReaderPoolObservation.h>\n#endif\n#include <BuildInfo.h>'),'int main(int argc, const char* argv[]) {','int main(int argc, const char* argv[]) {\n#if defined(Q_OS_IOS) && defined(OVERTE_E2E_FEATURE_TESTS) && defined(OVERTE_IOS_E2E_TEST_BUILD)\n    overte::e2e::IOSAssetsImageReaderPoolObservation::bootstrap(argc,argv);\n#endif'))
save('libraries/material-networking/CMakeLists.txt',lambda s:change(s,'PRIVATE OVERTE_E2E_METACALL_PRIVATE_API=1)','PRIVATE OVERTE_E2E_METACALL_PRIVATE_API=1)\n        target_compile_definitions(${TARGET_NAME} PRIVATE OVERTE_E2E_RUNNABLE_POOL_PRIVATE_API=1)'))
name='libraries/material-networking/src/material-networking/IOSAssetsImageReaderStorageObservation.h'
save(name,lambda s:change(change(s,'#include <QVariantMap>','#include <QVariantMap>\n#include <QRunnable>'),'static void attach(void* actual,const image','static void attach(void* actual,QRunnable* actualBase,const image'))
def storage(s):
    s=change(s,'#include "IOSAssetsImageReaderStorageObservation.h"','#include "IOSAssetsImageReaderStorageObservation.h"\n#include "IOSAssetsImageReaderPoolObservation.h"')
    s=change(s,'struct Row {QVariantMap value;std::weak_ptr<void> marker;};','struct Row {QVariantMap value;std::weak_ptr<void> marker;quint64 poolRegistration{0};};')
    s=change(s,'void Observation::attach(void* actual,const image','void Observation::attach(void* actual,QRunnable* actualBase,const image')
    a='''        const auto original=owner->phase();QMutexLocker lock(&owner->mutex);if (!admitted()) {return;}
        const auto found=owner->addresses.constFind(actual);'''
    b='''        const auto original=owner->phase();quint64 index=0;QString allocation;
        {
        QMutexLocker lock(&owner->mutex);if (!admitted()) {return;}
        const auto found=owner->addresses.constFind(actual);'''
    s=change(s,a,b)
    s=change(s,'''        row.value["taskId"]=task.taskId;row.value["resourceId"]=task.resourceId;row.value["sourceAttached"]=original;
    } catch (...) {fail();}''','''        row.value["taskId"]=task.taskId;row.value["resourceId"]=task.resourceId;row.value["sourceAttached"]=original;
        index=found.value();allocation=row.value.value("id").toString();
        }
        // Actual live base conversion was captured by the constructor. SDK
        // registration runs outside Storage/Source1/Pool observer mutexes.
        const auto registered=IOSAssetsImageReaderPoolObservation::registration(actualBase,allocation,
            task.source1Instance,task.taskId,task.resourceId);
        {QMutexLocker lock(&owner->mutex);owner->rows[int(index-1)].poolRegistration=registered;}
    } catch (...) {fail();}''')
    s=change(s,'''        const auto original=owner->phase();QMutexLocker lock(&owner->mutex);if (!admitted()) {return result;}
        const auto found=owner->addresses.find(actual);''','''        const auto original=owner->phase();quint64 registered=0;
        {
        QMutexLocker lock(&owner->mutex);if (!admitted()) {return result;}
        const auto found=owner->addresses.find(actual);''')
    s=change(s,'result._state=owner;result._row=index;owner->addresses.erase(found);return result;','''registered=owner->rows[int(index-1)].poolRegistration;
        result._state=owner;result._row=index;owner->addresses.erase(found);
        }
        // Retire the captured generation before free; no address lookup or
        // product access occurs after deallocation, even on address reuse.
        IOSAssetsImageReaderPoolObservation::retiring(registered);return result;''')
    return s
save('libraries/material-networking/src/material-networking/IOSAssetsImageReaderStorageObservation.cpp',storage)
save('libraries/material-networking/src/material-networking/TextureCache.cpp',lambda s:change(s,'IOSAssetsImageReaderStorageObservation::attach(this,actualContext)','IOSAssetsImageReaderStorageObservation::attach(this,static_cast<QRunnable*>(this),actualContext)'))
exec((HERE/'extra_app_transforms.inc').read_text())
(HERE/'app-integration.patch').write_text(''.join(patch))
(HERE/'app-integration-plan.json').write_text(json.dumps(dict(status='PRIVATE_SOURCE_ONLY_UNCOMPILED_UNRUN',head=__import__('subprocess').check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),files=rows),indent=2)+'\n')
print('PRIVATE app integration drafts: '+str(len(rows))+' files; no application/build/test')
