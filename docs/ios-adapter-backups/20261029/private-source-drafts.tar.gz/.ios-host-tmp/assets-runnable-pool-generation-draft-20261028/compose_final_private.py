"""Compose approved frozen candidates and AST IDs only; never import/run tests."""
from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,difflib
B=Path(__file__).resolve().parent;R=B.parent.parent;H=B/'final-composition';H.mkdir(exist_ok=True,mode=0o700)
sha=lambda data:hashlib.sha256(data).hexdigest()
plan=json.loads((B/'package-plan.json').read_text());tail=B/'body-tail-correction-20261028';runtime=B/'runtime-third-source-guard-correction-20261028'
rows=[];patch=[];names=[row['path'] for row in plan['publicationPaths']]+['tests/device/ios/self_tests/test_ios_qt_runnable_pool_source_patch.py']
for name in sorted(names):
 original=next((row for row in plan['publicationPaths'] if row['path']==name),None)
 if original is not None:assert sha((B/name).read_bytes())==original['sha256'],('Frozen original changed',name)
 candidate=runtime/name if (runtime/name).exists() else tail/name if (tail/name).exists() else B/name
 data=candidate.read_bytes();target=H/name;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700);target.write_bytes(data)
 actual=R/name;registry=name in ('tests/device/contract-versions.json','tests/device/validate_contract_versions.py')
 base=subprocess.check_output(['git','show','HEAD:'+name],cwd=R) if registry else actual.read_bytes() if actual.exists() else b''
 if original is not None and not registry:assert (sha(base) if actual.exists() else None)==original['baseSha256'],('Public base changed',name)
 rows.append(dict(path=name,privatePath=str(target.relative_to(R)),frozenCandidateSha256=None if original is None else original['sha256'],
     candidateSha256=sha(data),actualBaseSha256=sha(base) if actual.exists() else None,currentWorktreeSha256=sha(actual.read_bytes()) if actual.exists() else None,
     publication='APPLY_13_OWN_REGISTRY_HUNKS_ONLY_PRESERVE_FOREIGN_KEYS' if registry else 'VERIFY_BASE_SHA_THEN_EXACT_PATH',overlay=str(candidate.relative_to(B))))
 patch.extend(difflib.unified_diff(base.decode().splitlines(keepends=True),data.decode().splitlines(keepends=True),fromfile='a/'+name if actual.exists() else '/dev/null',tofile='b/'+name))
(H/'own-registry-hunks.patch').write_bytes((B/'own-registry-hunks.patch').read_bytes());(H/'own-registry-keys.json').write_bytes((B/'own-registry-keys.json').read_bytes())
# Enumerate direct declared methods only; never import a module or discover its
# imported TestCase classes. Match every existing actual ID against current AST.
def declared(name,path):
 tree=ast.parse(path.read_text(),filename=str(path));out=[]
 for cls in tree.body:
  if isinstance(cls,ast.ClassDef):
   for node in cls.body:
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name.startswith('test_'):out.append(name+'.'+cls.name+'.'+node.name)
 return sorted(out)
old=json.loads((B.parent/'assets-image-reader-storage-draft-20261027/small102-first-actual-case-ids.json').read_text());assert len(old)==len(set(old))==102
for module in sorted({value.split('.')[0] for value in old}):
 ids=declared(module,R/'tests/device/ios/self_tests'/str(module+'.py'));expected=sorted(value for value in old if value.split('.')[0]==module)
 assert ids==expected,('Existing actual selection changed',module,ids,expected)
new=[]
for module in ('test_ios_assets_image_pool','test_ios_assets_image_pool_sources','test_ios_assets_image_pool_runtime','test_ios_qt_runnable_pool_source_patch'):
 new+=declared(module,H/'tests/device/ios/self_tests'/str(module+'.py'))
assert len(new)==len(set(new))==33
ids=sorted(new+old);assert len(ids)==len(set(ids))==135 and not any('_flow.' in value for value in ids)
(H/'small135-exact-case-ids.json').write_text(json.dumps(ids,indent=2)+'\n')
(H/'small135-selection-provenance.json').write_text(json.dumps(dict(status='AST_ONLY_NOT_LOADED_OR_EXECUTED',existingActualSelection=102,newPool=30,newVerifier=3,total=135,
    existingIdsOriginal='../assets-image-reader-storage-draft-20261027/small102-first-actual-case-ids.json',fullIdSelection=True,discoveryUsed=False),indent=2)+'\n')
# Source-only test references: copies of the two immutable retained primary
# inputs, not an installed SDK. No patch application is performed here.
reference=H/'qt-source-reference';reference.mkdir(exist_ok=True,mode=0o700);original=B.parent/'assets-image-reader-storage-draft-20261027/primary-qt-v6.11.1'
refs=[]
for name in ('qthreadpool_p.h','qthreadpool.cpp'):
 source=original/name;a=source.stat();data=source.read_bytes();b=source.stat();assert (a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(b.st_ino,b.st_size,b.st_mtime_ns,b.st_ctime_ns)
 target=reference/'qtbase/src/corelib/thread'/name;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700);target.write_bytes(data);target.chmod(0o600)
 refs.append(dict(original=str(source.relative_to(R)),reference=str(target.relative_to(H)),sha256=sha(data),bytes=len(data),originalStat={key:getattr(b,key) for key in ('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')}))
(H/'reference-pins.json').write_text(json.dumps(refs,indent=2)+'\n')
main=next(row for row in rows if row['path']=='interface/src/main.cpp');(H/'main.cpp-explicit-pin.json').write_text(json.dumps(main,indent=2)+'\n')
value=dict(status='PRIVATE_COMPOSED33_NO_PUBLICATION_NO_TEST_EXECUTION',headAtComposition=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    frozenBasisManifestSha256=sha((B/'package-plan.json').read_bytes()),frozenBasisPatchSha256=sha((B/'full-private-packet.patch').read_bytes()),
    publicationPaths=rows,ownRegistryKeys=json.loads((H/'own-registry-keys.json').read_text()),mainExplicitPin='main.cpp-explicit-pin.json',
    proposedSuiteIds='small135-exact-case-ids.json',proposedSuiteCount=135,hostTestsExecuted=False,qtSourcePatchApplicationChecked=False,nativeCompilationVerified=False,
    deviceQualified=False,adapterCompletionCount='5/14',globalPoolCompletionAvailable=False,wholeResourceRetirementAvailable=False)
(H/'package-plan.json').write_text(json.dumps(value,indent=2)+'\n');(H/'publication-paths.txt').write_text('\n'.join(sorted(names))+'\n');(H/'full-private-packet.patch').write_text(''.join(patch))
for path in H.rglob('*'):
 if path.is_dir():path.chmod(0o700)
print(json.dumps(dict(publicationPaths=len(rows),ownKeys=len(value['ownRegistryKeys']),exactUniqueIds=len(ids),newPool=30,newVerifier=3,existing=102,status='PRIVATE_UNRUN')))
