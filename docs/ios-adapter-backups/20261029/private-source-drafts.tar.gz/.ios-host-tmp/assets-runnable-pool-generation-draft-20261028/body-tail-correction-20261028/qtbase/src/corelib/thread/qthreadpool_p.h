// Copyright (C) 2016 The Qt Company Ltd.
// SPDX-License-Identifier: LicenseRef-Qt-Commercial OR LGPL-3.0-only OR GPL-2.0-only OR GPL-3.0-only
// Qt-Security score:significant reason:default

#ifndef QTHREADPOOL_P_H
#define QTHREADPOOL_P_H

//
//  W A R N I N G
//  -------------
//
// This file is not part of the Qt API.  It exists purely as an
// implementation detail.  This header file may change from version to
// version without notice, or even be removed.
//
// We mean it.
//
//

#include "QtCore/qmutex.h"
#include "QtCore/qthread.h"
#include "QtCore/qwaitcondition.h"
#include "QtCore/qthreadpool.h"
#include "QtCore/qset.h"
#include "QtCore/qqueue.h"
#include "private/qobject_p.h"

QT_BEGIN_NAMESPACE

// Optional matching Qt6.11.1 private SDK protocol. Native/runtime UNVERIFIED.
#define QT_OVERTE_E2E_RUNNABLE_POOL 1
struct QOverteE2ePoolKey { quint64 high{0},low{0}; };
enum class QOverteE2ePoolEventKind : quint32 {
    PoolCreated=1,PoolDestructorBodyTailObserved,
    Registered,RegistrationRetired,
    StartEntered,StartReturned,StartUnwound,TryStartEntered,TryStartReturned,TryStartUnwound,
    ReservedEntered,ReservedReturned,ReservedUnwound,
    Enqueued,SlotRemoved,WorkerAssigned,
    RunEntered,RunReturned,RunUnwound,AutoDeleteEntered,AutoDeleteReturned,
    IterationReturned,IterationUnwound,CancelDeleteEntered,CancelDeleteReturned,CancelScopeReturned,CancelScopeUnwound,
    TryTakeEntered,TryTakeReturned,TryTakeUnwound,TakeMatched
};
struct QOverteE2ePoolEvent {
    quint64 sequence{0},pool{0},registration{0},admission{0},slot{0},thread{0},operation{0};
    qint64 epochMs{0};quint64 steadyNs{0};QOverteE2ePoolEventKind kind{};quint32 flags{0};
};
struct QOverteE2ePoolRegistration {
    quint64 id{0};QOverteE2ePoolKey allocation;bool live{false};
};
struct QOverteE2ePoolAdmission {
    quint64 id{0},pool{0},registration{0};QOverteE2ePoolEventKind operation{};
};
struct QOverteE2ePoolSnapshot {
    enum {MaxPools=64,MaxThreads=128,MaxRegistrations=64,MaxAdmissions=128,MaxEvents=2048};
    quint32 version{1};bool healthy{false},cutComplete{false};QOverteE2ePoolKey instance;
    qint64 epochMs{0};quint64 steadyNs{0},mutationSerial{0},inFlight{0};
    quint64 poolCount{0},registrationCount{0},admissionCount{0},eventCount{0};
    QOverteE2ePoolRegistration registrations[MaxRegistrations];
    QOverteE2ePoolAdmission admissions[MaxAdmissions];
    QOverteE2ePoolEvent events[MaxEvents];
};
class QRunnable;
Q_CORE_EXPORT bool qOverteE2ePoolArm(QOverteE2ePoolKey instance) noexcept;
Q_CORE_EXPORT void qOverteE2ePoolDisarm() noexcept;
Q_CORE_EXPORT bool qOverteE2ePoolHealthy() noexcept;
Q_CORE_EXPORT quint64 qOverteE2ePoolRegister(QRunnable* actual,QOverteE2ePoolKey allocation) noexcept;
Q_CORE_EXPORT bool qOverteE2ePoolRetire(quint64 registration) noexcept;
Q_CORE_EXPORT bool qOverteE2ePoolCopy(QOverteE2ePoolSnapshot* target) noexcept;
Q_CORE_EXPORT quint64 qOverteE2ePoolCreated() noexcept;
Q_CORE_EXPORT void qOverteE2ePoolDestructorBodyTailObserved(quint64 pool) noexcept;
Q_CORE_EXPORT quint64 qOverteE2ePoolCurrentAdmission() noexcept;
Q_CORE_EXPORT quint64 qOverteE2ePoolTakeLastAdmission() noexcept;
Q_CORE_EXPORT quint64 qOverteE2ePoolEnqueued(quint64 admission) noexcept;
Q_CORE_EXPORT void qOverteE2ePoolSlotRemoved(quint64 admission,quint64 slot,quint32 reason) noexcept;
Q_CORE_EXPORT void qOverteE2ePoolWorkerAssigned(quint64 pool,quint64 admission,QRunnable* actual) noexcept;
class Q_CORE_EXPORT QOverteE2ePoolAdmissionScope {
public:
    QOverteE2ePoolAdmissionScope(quint64 pool,QRunnable* actual,QOverteE2ePoolEventKind operation) noexcept;
    ~QOverteE2ePoolAdmissionScope();
    void returned(bool accepted=true) noexcept {_accepted=accepted;_returned=true;}
private:
    quint64 _pool{0},_registration{0},_admission{0},_previous{0};
    QOverteE2ePoolEventKind _operation;bool _returned{false},_accepted{false};
};
class Q_CORE_EXPORT QOverteE2ePoolTransferScope {
public:
    explicit QOverteE2ePoolTransferScope(quint64 admission) noexcept;
    ~QOverteE2ePoolTransferScope();
private:quint64 _previous{0};
};
class Q_CORE_EXPORT QOverteE2ePoolRunScope {
public:
    QOverteE2ePoolRunScope(quint64 pool,quint64 admission,QRunnable* actual,bool autoDelete,quint32 path) noexcept;
    ~QOverteE2ePoolRunScope();
    void returned() noexcept;
    void deleting() noexcept;
    void deleted() noexcept;
private:quint64 _pool{0},_admission{0};bool _returned{false},_deleteEntered{false},_deleteReturned{false},_autoDelete{false};
};
class Q_CORE_EXPORT QOverteE2ePoolTakeScope {
public:
    QOverteE2ePoolTakeScope(quint64 pool,QRunnable* actual) noexcept;
    ~QOverteE2ePoolTakeScope();
    void removed(quint64 admission,quint64 slot) noexcept;
    void returned(bool removed) noexcept {_returned=true;_removed=removed;}
private:quint64 _pool{0},_registration{0},_admission{0},_operation{0};bool _returned{false},_removed{false};
};
class Q_CORE_EXPORT QOverteE2ePoolCancelScope {
public:
    QOverteE2ePoolCancelScope(quint64 pool,quint64 admission) noexcept;
    ~QOverteE2ePoolCancelScope();
    void deleted() noexcept;
private:quint64 _pool{0},_admission{0};bool _returned{false};
};
Q_CORE_EXPORT void qOverteE2ePoolUnsupported() noexcept;


class QDeadlineTimer;

class QueuePage
{
public:
    enum {
        MaxPageSize = 256
    };

    QueuePage(QRunnable *runnable, int pri) : m_priority(pri) { push(runnable); }

    bool isFull() { return m_lastIndex >= MaxPageSize - 1; }

    bool isFinished() { return m_firstIndex > m_lastIndex; }

    void push(QRunnable *runnable)
    {
        Q_ASSERT(runnable != nullptr);
        Q_ASSERT(!isFull());
        m_lastIndex += 1;
        m_entries[m_lastIndex] = runnable;
        m_featureAdmission[m_lastIndex]=qOverteE2ePoolCurrentAdmission();
        m_featureSlot[m_lastIndex]=qOverteE2ePoolEnqueued(m_featureAdmission[m_lastIndex]);
    }

    void skipToNextOrEnd()
    {
        while (!isFinished() && m_entries[m_firstIndex] == nullptr) {
            m_firstIndex += 1;
        }
    }

    QRunnable *first()
    {
        Q_ASSERT(!isFinished());
        QRunnable *runnable = m_entries[m_firstIndex];
        Q_ASSERT(runnable);
        return runnable;
    }

    quint64 featureAdmission() const { return m_featureAdmission[m_firstIndex]; }
    QRunnable *pop(quint32 featureReason=0)
    {
        Q_ASSERT(!isFinished());
        QRunnable *runnable = first();
        Q_ASSERT(runnable);

        // clear the entry although this should not be necessary
        m_entries[m_firstIndex] = nullptr;
        qOverteE2ePoolSlotRemoved(m_featureAdmission[m_firstIndex],m_featureSlot[m_firstIndex],featureReason);
        m_featureAdmission[m_firstIndex]=m_featureSlot[m_firstIndex]=0;
        m_firstIndex += 1;

        // make sure the next runnable returned by first() is not a nullptr
        skipToNextOrEnd();

        return runnable;
    }

    bool tryTake(QRunnable *runnable,QOverteE2ePoolTakeScope* featureTake=nullptr)
    {
        Q_ASSERT(!isFinished());
        for (int i = m_firstIndex; i <= m_lastIndex; i++) {
            if (m_entries[i] == runnable) {
                m_entries[i] = nullptr;
                qOverteE2ePoolSlotRemoved(m_featureAdmission[i],m_featureSlot[i],3);
                if (featureTake) {featureTake->removed(m_featureAdmission[i],m_featureSlot[i]);}
                m_featureAdmission[i]=m_featureSlot[i]=0;
                if (i == m_firstIndex) {
                    // make sure first() does not return a nullptr
                    skipToNextOrEnd();
                }
                return true;
            }
        }
        return false;
    }

    int priority() const { return m_priority; }

private:
    int m_priority = 0;
    int m_firstIndex = 0;
    int m_lastIndex = -1;
    QRunnable *m_entries[MaxPageSize];
    quint64 m_featureAdmission[MaxPageSize]{},m_featureSlot[MaxPageSize]{};
};

class QThreadPoolThread;
class Q_CORE_EXPORT QThreadPoolPrivate : public QObjectPrivate
{
    Q_DECLARE_PUBLIC(QThreadPool)
    friend class QThreadPoolThread;

public:
    QThreadPoolPrivate();

    bool tryStart(QRunnable *task);
    void enqueueTask(QRunnable *task, int priority = 0);
    int activeThreadCount() const;

    void tryToStartMoreThreads();
    bool areAllThreadsActive() const;
    bool tooManyThreadsActive() const;

    int maxThreadCount() const
    { return qMax(requestedMaxThreadCount, 1); }    // documentation says we start at least one
    void startThread(QRunnable *runnable = nullptr);
    void reset();
    bool waitForDone(const QDeadlineTimer &timer);
    void clear();
    void stealAndRunRunnable(QRunnable *runnable);
    void deletePageIfFinished(QueuePage *page);

    quint64 featurePoolId{0};
    mutable QMutex mutex;
    QSet<QThreadPoolThread *> allThreads;
    QQueue<QThreadPoolThread *> waitingThreads;
    QQueue<QThreadPoolThread *> expiredThreads;
    QList<QueuePage *> queue;
    QWaitCondition noActiveThreads;
    QString objectName;

    std::chrono::duration<int, std::milli> expiryTimeout = std::chrono::seconds(30);
    int requestedMaxThreadCount = QThread::idealThreadCount();  // don't use this directly
    int reservedThreads = 0;
    int activeThreads = 0;
    uint stackSize = 0;
    QThread::Priority threadPriority = QThread::InheritPriority;
    QThread::QualityOfService serviceLevel = QThread::QualityOfService::Auto;
};

QT_END_NAMESPACE

#endif
