PRIVATE REVIEW PACKET — generation-carrying selected ImageReader pool edges

Concrete source, not a plan-only packet. Current package-plan.json names exactly
32 target paths, all current base/draft SHA256 values, 13 own registry keys,
17 parsed Python sources, 30 authored small cases and one authored connected
case. All test cases, source patch application, native compile/link, SDK/runtime
and devices remain UNRUN. No source is public; the index was not changed.

full-private-packet.patch contains only these proposed changes. App integration
hunks are based on the actual worktree bytes pinned by app-integration-plan.json;
registry hunks are based on committed HEAD and deliberately omit foreign Photo
keys. Never replace the two registry files with their private draft copies.
Only own-registry-hunks.patch may add these thirteen keys to the current files.
The thirteenth key is the independently versioned optional Qt Core protocol.

Review in this order:
1. primary-source-audit.json and both linked exact Qt6.11.1 primary pin files.
   Four original runnable/pool files from the earlier Storage audit are retained
   unchanged. Two new official original thread files are retained with URLs,
   tag and complete SHA256. They are evidence of source text, not SDK execution.
2. qt-pool-protocol-api.inc / qt-pool-protocol-implementation.inc and the generated
   ios/patches/qtbase-overte-e2e-runnable-pool.patch. It changes exactly
   qthreadpool_p.h / qthreadpool.cpp at the pinned tag, without new SDK CMake files.
   Every actual queue slot and worker runnable assignment carries an admission
   generation captured before worker execution. Promotion keeps old/new slots;
   tryTake matches retain captured generation and distinct operation IDs.
3. The fixed POD protocol has 64 pools, 64 registrations, 128 admissions,
   2048 events and 128 atomic thread-context slots. Observer thread_local state
   was removed after private review because first Darwin TLS resolution was
   not proven allocation-free. Raw thread/runnable handles remain internal.
   Exported threadSlotId is an opaque slot index, explicitly not a lifetime
   generation of an OS thread; OS handles may be reused. No product owner,
   QObject read, app callback, observer blocking lock or explicit allocator call
   belongs to pool-locked SDK hook code. Platform execution/cost is still unrun.
4. SDK mutation writers, serials and release-published immutable cells support
   valid incomplete concurrent cuts. They never turn benign concurrency into a
   sticky failure. Reserved counts can include unpublished holes; whole selected
   edge closure requires a later healthy complete cut. Original older clocks
   can publish later without global timestamp sorting by reservation sequence.
5. IOSAssetsImageReaderPoolObservation.h/.cpp, main.cpp and material CMake. The
   first main statement gates bootstrap before WebView/Application setup. Only
   actual testScript and exact optional SDK/version arm it. Unpatched SDK stays
   unavailable. A selected pool created before bootstrap has unknown generation
   zero and fails rather than adopting an address. Shutdown disarms. QVariant/
   diagnostic heap construction occurs on the main getter side outside pool locks.
6. Storage/TextureCache hunks. A live actual QRunnable base conversion and exact
   Storage UUID/context register before constructor return. The private Row
   stores only an opaque SDK id. Storage releases its mutex before registering
   or retiring in Core. The exact id is captured before global free and no dead
   object/base conversion/address lookup occurs after it. Existing Source1,
   Queue, Processing and Storage wires stay unchanged. Existing class delete
   ABI remains diagnostic and uncompiled; no identical-old-ABI claim is made.
7. assets_image_reader_pool.py. Strict complete/incomplete POD cuts, original
   clocks/IDs/shape/caps, nonce wrappers, immutable-history succession and a
   fresh three-original Pool -> Storage -> Source1 binding. Cross-domain joins
   use epoch clocks; native monotonic domains are not conflated.
8. assets_image_pool_sources.py / ownership.py, source inventory and factory/
   Probe/getter/writer hunks. Real literal originals, query-before-send WAL,
   saved adoption, opened/unknown responsibility, closed namespaces and readonly
   inventory follow the existing source ownership mechanics. Existing Processing
   remains first in its writer condition; the Pool filename is added to all
   three known private writer branches. image/CMake macro bytes are pinned only.
9. assets_image_pool_lifecycle.py. Pure selected admission/slot/run/delete/scope
   closure composes on actual Storage and Source1 originals, then the prior
   normal Delete/Home image/processing/storage joins with fresh Pool samples.
   It cannot query, write, spawn, deliver, clear or release. Worker/clear/take/
   steal/declined cases differ. A selected worker scope ends after native relock
   and before later scheduler bookkeeping; it is not worker/thread/global-pool
   completion. GlobalPool/Bytes/Decoder/GPU/wholeResource flags remain false.
10. Three fixtures/four test entrypoints: 15 core behavior/Probe cases, 11 actual
    host-file WAL/inventory cases and four canonical factory/session/AFC cases.
    The connected case first closes Storage while a declared pool iteration
    tail is still held, refuses Pool closure, then allows only test-driver
    release and fresh quiet samples. Original 20/1.5/3/1.6 timing constants were
    not relaxed. Host weak markers/Blocks/files are real; native Qt is a model.
11. The exact source-only SDK verifier can later check private apply/reverse and
    original readback against the two manifest SHA pins. It is authored but
    UNRUN, does not compile/execute Qt, and does not assert native API/ABI.
12. The two English guides explicitly mark all new cases unrun, preserve old
    qualification as applying only to old actual source hashes, and retain the
    existing 5/14 completion count and all broad retirement responsibilities.

Matching complete SDK/all private consumers still require separate authorized
configure/build/link/runtime/device work because private layouts changed.
Actual native allocation/deletion ABI, constructor failures, scheduler races,
independent byte copies/decoded/plugins and GPU/fences/recycler are unverified.
This packet introduces no global pool or whole Resource end claim.
