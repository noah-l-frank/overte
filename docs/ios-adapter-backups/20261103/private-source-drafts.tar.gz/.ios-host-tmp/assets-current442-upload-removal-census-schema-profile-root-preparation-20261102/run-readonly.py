"""Narrow ordinary partial Assets decoder reads over preserved442.

Historical selected construction plus unchanged Upload/ModelRemoval decoders;
no full end eligibility, live runtime, native clock, SDK/input/recovery/query.
The partial WAL states stay literal, including pending uncompleted ownership.
"""
from pathlib import Path
from contextlib import ExitStack
import signal,cProfile,hashlib,importlib.machinery,json,os,pstats,stat,sys,threading,time,traceback,shutil
from run_metadata import HERE,REPO,pin,proc,publication,save,sources,registry_original,validate_frozen
assert len(sys.argv)==2 and sys.argv[1]=='profile1'
plan=dict(validate_frozen(),activeSelection='profile1');publication();selected=plan['diagnosticInputs']
runroot=Path(os.environ['OVERTE_ASSETS_CANONICAL_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs/profile1') and stat.S_IMODE(runroot.stat().st_mode)==0o700
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/'profile1-publication-ready-source-map.json';approved=json.loads(ready.read_text());ready_pin=pin(ready)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
source_before=sources(plan);assert source_before==approved['sourcePins'] and registry_original()==approved['registry']
save(runroot/'runner-process-binding.json',proc(os.getpid()))
threads_before=set(threading.enumerate());self_proc=proc(os.getpid())
def group():
    result=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        row=proc(int(p.name))
        if row is not None and (row['session']==self_proc['session'] or row['processGroup']==self_proc['processGroup']):result.append(row)
    return result
baseline={(row['pid'],row['startTicks']) for row in group()}
def remaining():return [row for row in group() if (row['pid'],row['startTicks']) not in baseline]
config=json.loads((HERE/'source-root-final-map.json').read_text())
expected=[str(REPO/name) for name in config['orderedRoots']]
sys.path[:]=expected+[p for p in sys.path if not Path(p or os.getcwd()).resolve().is_relative_to(REPO)]
def spec(name):
    search=sys.path;found=None
    for i in range(len(name.split('.'))):
        found=importlib.machinery.PathFinder._get_spec('.'.join(name.split('.')[:i+1]),list(search))
        assert found is not None,name;search=found.submodule_search_locations
    return found
for name,relative in config['packageRoots'].items():assert [str(Path(x).resolve()) for x in spec(name).submodule_search_locations or ()]==[str(REPO/relative)],name
for name,row in config['modules'].items():
    path=Path(spec(name).origin).resolve(strict=True)
    assert path==REPO/row['path'] and pin(path)==source_before[row['path']],name
wal=REPO/selected['archiveWAL'];lockpaths={role:REPO/row['existingLock'] for role,row in selected['roles'].items()}
inputs={str(p):pin(p) for p in (wal,*lockpaths.values())}
assert inputs[str(wal)]['sha256']==selected['archiveWALSha256']
raw=json.loads(wal.read_text())
assert raw['context']==selected['context'] and raw['context']['roles']==selected['selectedRoleMap']
provenance=REPO/selected['rootProducerReceipt'];provenance_pin=pin(provenance)
root_receipt=json.loads(provenance.read_text())
for role,info in selected['roles'].items():
    expected_root=REPO/info['directory'];root=expected_root.lstat()
    receipt=root_receipt[info['producerIndex']]
    assert receipt['root']==str(expected_root) and receipt['producer']=='genuineTemporaryDirectory'
    assert (root.st_dev,root.st_ino)==(receipt['device'],receipt['inode'])
    assert raw['context']['roles'][role]['stateRoot']==raw['context']['roles'][role]['artifactRoot']==str(expected_root)
    assert raw['context']['roles'][role]['target']==role and lockpaths[role]==expected_root/'script-feature-sources.lock'
    assert stat.S_IMODE(root.st_mode)==0o700

# Install all denials BEFORE any target import. Only pinned metadata rg and
# opening the exact already-existing lock inode can escape the output folder.
metadata_command=['rg','--files','-0',*plan['broadSourceRoots']]
rg_executable=Path(shutil.which('rg')).resolve(strict=True);rg_original_pin=pin(rg_executable)
metadata_subprocesses=[];forbidden=[];sdk_attempts=[]
sdk_bad=('pymobiledevice3','tidevice','pyidevice','zeroconf')
def sdk_path(path):
    if not isinstance(path,(str,bytes,os.PathLike)):return False
    return any(part in ('overte-ios-remotexpc',*sdk_bad) or any(part.startswith(bad+'_') for bad in sdk_bad)
        for part in Path(os.fsdecode(path)).parts)
def check_sdk():
    bad=[]
    for name,module in tuple(sys.modules.items()):
        if any(part in sdk_bad for part in name.split('.')) or sdk_path(getattr(module,'__file__',None)):bad.append(name)
    assert not bad,'Forbidden SDK source/name already imported'
    return bad
sdk_before=check_sdk()
def audit(event,args):
    if event=='import' and (any(part in sdk_bad for part in args[0].split('.')) or sdk_path(args[1])):
        sdk_attempts.append(args[0]);raise RuntimeError('Readonly diagnostic refused SDK import')
    if event=='open':
        path,mode,flags=args
        # This repository-owned receiver is pinned source text, not an SDK
        # import. Only its exact canonical READ path is admitted to metadata.
        receiver=REPO/'tests/device/ios/pymobiledevice3_wda_xctest.py'
        source_only_receiver=(isinstance(path,(str,bytes,os.PathLike)) and Path(os.fsdecode(path))==receiver
            and receiver.resolve(strict=True)==receiver
            and not flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if sdk_path(path) and not source_only_receiver:
            sdk_attempts.append('source-open');raise RuntimeError('Readonly diagnostic refused SDK source')
        if isinstance(path,(str,bytes,os.PathLike)):
            actual=Path(os.fsdecode(path)).resolve()
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            allowed_lock=actual in lockpaths.values() and bool(flags&os.O_RDWR) and not flags&(os.O_CREAT|os.O_TRUNC|os.O_APPEND)
            if writing and not actual.is_relative_to(runroot) and not allowed_lock:
                forbidden.append(event);raise RuntimeError('Readonly diagnostic refused write')
    if event=='subprocess.Popen':
        executable,argv,cwd,environment=args
        allowed=executable=='rg' and type(argv) is list and argv==metadata_command and Path(cwd)==REPO and environment is None
        if allowed:
            assert Path(shutil.which('rg')).resolve(strict=True)==rg_executable and pin(rg_executable)==rg_original_pin
            metadata_subprocesses.append(dict(command=list(argv),cwd=str(cwd)));return
        forbidden.append(event);raise RuntimeError('Readonly diagnostic refused nonmetadata subprocess')
    if event in ('os.system','os.exec','os.posix_spawn','socket.__new__','socket.connect','socket.bind','os.remove','os.rename','os.rmdir','os.mkdir','os.chmod','os.truncate'):
        forbidden.append(event);raise RuntimeError('Readonly diagnostic refused external effect')
sys.addaudithook(audit)

profiler=cProfile.Profile();stages=[];primary_error=None;start=time.monotonic();reports=None
interrupts=[]
def original_timeout(signum,frame):
    # Exact interrupted MAIN call stack locations only; no locals, values or
    # original edits. Profiling finalization writes only this owned run folder.
    rows=[]
    while frame is not None and len(rows)<96:
        rows.append(dict(file=frame.f_code.co_filename,function=frame.f_code.co_name,line=frame.f_lineno))
        frame=frame.f_back
    interrupts.append(dict(signal=signum,actualInterruptedFrames=rows))
    raise TimeoutError('Owned readonly diagnostic reached its fixed outer deadline')
previous_timeout=signal.signal(signal.SIGTERM,original_timeout)
def measure(label,call):
    row=dict(stage=label,entered=True,returned=False);stages.append(row);save(runroot/'actual-stages.json',stages)
    before=time.monotonic();profiler.enable()
    try:
        value=call();row['returned']=True;return value
    finally:
        profiler.disable();row['seconds']=time.monotonic()-before;save(runroot/'actual-stages.json',stages)
def construct_partial_graph(directory,run,metadata):
    """Pure ordinary-owner graph only; image/marker/end admission is not read."""
    from copy import deepcopy
    from types import SimpleNamespace
    from adapters.native_feature_observation import need
    from adapters.normal_feature_state import context
    from adapters.script_feature.history import same
    from adapters.original_frame_store import OriginalFrameStore
    from ios.adapters.assets_end_metadata import store as metadata_store
    from ios.adapters.assets_session_owners import (directory_entries,forbidden,FILE_SOURCE,FILE_MIGRATION,REPLY_SOURCE,REPLY_MIGRATION,
        FRAME,BACKEND_FRAME,MODEL_FRAME,PARSED_FRAME,OwnedAssetsFiles,FileSources,OwnedAssetsPicker,OwnedAssetsReplyReads,ReplySources,
        OwnedAssetsUpload,OwnedAssetsTree,OwnedAssetsUsage,OwnedAssetsBackend,BackendSegments,OwnedAssetsBaking,
        AssetsModelSources,ModelRawSources,OwnedAssetsModel,AssetsParsedSources,ParsedRawSources,OwnedAssetsParsedInput,OwnedAssetsModelRemoval)
    role='primary';directory=Path(directory);store_for=lambda path:metadata_store(path,metadata)
    kinds=('files','picker','replies','upload','usage','backend','baking','model-sources','model','parsed-sources','parsed','model-removal')
    records={kind:(directory/('ios-assets-'+run+'-'+role+'-'+kind+'.json'),None) for kind in kinds}
    records={kind:(path,store_for(path).read()) for kind,(path,_value) in records.items()}
    values={kind:value for kind,(_path,value) in records.items()};need(all(type(value) is dict for value in values.values()))
    binding=deepcopy(context(values['files']['binding']));pid=int(binding['processIdentity']);url=values['files']['fixtureUrl']
    need(all(same(context(value['binding']),binding) for value in values.values()) and values['replies']['fixtureUrl']==values['backend']['fixtureUrl']==url)
    selected=metadata.selection;selected.selected_guard();info=selected.context['roles']['primary']
    need(selected.run==run and Path(info['stateRoot'])==directory and same(info['binding'],binding))
    entries=directory_entries(directory,metadata=metadata)
    maps=[{} for _ in range(6)];file_paths,reply_paths,frame_paths,backend_paths,model_paths,parsed_paths=maps
    for path in entries:
        for patterns,result in (((FILE_SOURCE,FILE_MIGRATION),file_paths),((REPLY_SOURCE,REPLY_MIGRATION),reply_paths),
                ((FRAME,),frame_paths),((BACKEND_FRAME,),backend_paths),((MODEL_FRAME,),model_paths),((PARSED_FRAME,),parsed_paths)):
            matches=[pattern.fullmatch(path.name) for pattern in patterns];match=next((row for row in matches if row is not None),None)
            if match is not None:
                groups=match.groups()
                if result is backend_paths:
                    subject,current_run,current_role=groups;need(subject==current_role);groups=(current_run,current_role)
                result.setdefault(groups,set()).add(path)
    Files=OwnedAssetsFiles;selected=None
    if 'files' in values and values['files'].get('iosAssetsFileOwnerVersion')==3:
        from ios.adapters.assets_selected_profile import SelectedAssetsFiles
        selected=getattr(metadata,'selection',None);need(selected is not None);selected.selected_guard();Files=SelectedAssetsFiles
        need(role=='primary' and selected.context['runId']==run and selected.context['fixtureUrl']==url
            and Path(selected.context['roles'][role]['stateRoot'])==directory and same(selected.context['roles'][role]['binding'],binding))
    files=object.__new__(Files)
    if selected is not None:files.selection=selected;files.selection_read_only=True
    files.native=SimpleNamespace(pid=pid,monotonic=time.monotonic);files.run,files.url,files.binding=run,url,deepcopy(binding)
    files.state=None;files.role=role;file_covered=set();migration_pending=False
    if 'files' in values:
        files.store=store_for(records['files'][0]);files.sources=FileSources(files,role,lambda:True,forbidden)
        files.state=files.decode(values['files']);file_covered=files.sources.owned_paths()
        if files.storage_version==1:
            extra=files.sources.legacy_migration_paths();file_covered|=extra;migration_pending=bool(extra)
    need(file_paths.get((run,role),set())==file_covered)
    picker=object.__new__(OwnedAssetsPicker);picker.files,picker.binding=files,deepcopy(binding);picker.state=None
    if 'picker' in values:
        need(files.state is not None);picker.state=picker.decode(values['picker'])
    replies=object.__new__(OwnedAssetsReplyReads);replies.native=SimpleNamespace(pid=pid,monotonic=time.monotonic);replies.run,replies.url,replies.binding=run,url,deepcopy(binding);replies.state=None
    reply_covered=set();reply_migration_pending=False;replies.role=role
    if 'replies' in values:
        replies.store=store_for(records['replies'][0]);replies.sources=ReplySources(replies,role,lambda:True,forbidden);replies.state=replies.decode(values['replies']);reply_covered=replies.sources.owned_paths()
        if replies.storage_version==1:
            extra=replies.sources.legacy_migration_paths();reply_covered|=extra;reply_migration_pending=bool(extra)
    need(reply_paths.get((run,role),set())==reply_covered)
    upload=None;tree=None;backend=None;usage=None;baking=None;model_source=None;model=None;parsed_source=None;parsed=None;removal=None;baked_tree=None;covered=set();backend_covered=set();model_covered=set();parsed_covered=set()
    if 'upload' in values:
        need(files.state is not None and picker.state is not None and replies.state is not None)
        upload=object.__new__(OwnedAssetsUpload);upload.files,upload.picker,upload.replies=files,picker,replies
        upload.store=store_for(records['upload'][0]);upload.previous=deepcopy(values['upload'])
        upload.binding,upload.role,upload.clock=deepcopy(binding),role,SimpleNamespace(pid=pid)
        upload.state=None;upload._cached=[];upload._validated_refs=[];upload._projects=[]
        upload.originals=OriginalFrameStore(directory,binding,run,role,lambda:True,forbidden,namespace='assets-upload',schema_prefix='iosAssetsUpload')
        upload.state=upload.decode(values['upload']);state=upload.state
        need(picker.state['phase']=='primary-chosen' and state['page']==picker.state['page'] and state['picker']==picker.state['picker'])
        for ref in state['frames']:covered.add(upload.originals.path(upload.originals.expand(ref)))
        if state['pending'] is not None and state['pending']['original'] is not None:covered.add(upload.originals.path(state['pending']['original']))
    if 'tree' in values:
        need(upload is not None);tree=object.__new__(OwnedAssetsTree);tree.upload=upload;tree.state=None;tree.state=tree.decode(values['tree'])
    if 'usage' in values:
        need(upload is not None);usage=object.__new__(OwnedAssetsUsage);usage.source=upload;usage.store=store_for(records['usage'][0]);usage.previous=deepcopy(values['usage']);usage.state=None;usage.state=usage.decode(values['usage'])
    need(frame_paths.get((run,role),set())==covered)
    if 'backend' in values:
        backend=object.__new__(OwnedAssetsBackend);backend.upload=upload if upload is not None else SimpleNamespace(files=files,state=None)
        backend.binding,backend.run,backend.role=deepcopy(binding),run,role;backend.config=deepcopy(values['backend']['backendConfiguration'])
        backend.parts=BackendSegments(directory,binding,run,role,role,lambda:True,forbidden,monotonic=time.monotonic)
        backend.state=backend.decode(values['backend'])
        for row in backend.state['samples']:
            if row['parts'] is not None:
                for reference in row['parts']['chunks']:
                    if reference['phase']!='planned':backend_covered.add(backend.parts.store.path(reference))
    need(backend_paths.get((run,role),set())==backend_covered)
    if 'baking' in values:
        need(usage is not None and backend is not None);baking=object.__new__(OwnedAssetsBaking);baking.usage,baking.backend=usage,backend;baking.previous=deepcopy(values['baking']);baking.state=None;baking.state=baking.decode(values['baking'])
    if 'model-sources' in values:
        need(usage is not None);model_source=object.__new__(AssetsModelSources);model_source.usage=usage;model_source.native=SimpleNamespace(pid=pid,monotonic=time.monotonic)
        model_source.binding,model_source.run,model_source.role=deepcopy(binding),run,role;model_source.store=store_for(records['model-sources'][0]);model_source._cached=[]
        model_source.raws=ModelRawSources(model_source,role,lambda:True,forbidden);model_source.originals=OriginalFrameStore(directory,binding,run,role,lambda:True,forbidden,namespace='assets-model-source',schema_prefix='iosAssetsModelSource')
        model_source.state=model_source.decode(values['model-sources']);model_covered|=model_source.raws.owned_paths()
        for reference in model_source.state['frames']:model_covered.add(model_source.originals.path(model_source.originals.expand(reference)))
        pending=[row['pending'] for row in model_source.state['interrupted']]+([model_source.state['pending']] if model_source.state['pending'] is not None else [])
        for row in pending:
            if row['original'] is not None and row['original']['phase']!='planned':model_covered.add(model_source.originals.path(row['original']))
    need(model_paths.get((run,role),set())==model_covered)
    if 'model' in values:
        need(usage is not None and model_source is not None);model=object.__new__(OwnedAssetsModel);model.usage,model.sources=usage,model_source;model.previous=deepcopy(values['model']);model.state=None;model.state=model.decode(values['model'])
    if 'parsed-sources' in values:
        need(model is not None);parsed_source=object.__new__(AssetsParsedSources);parsed_source.usage,parsed_source.model=usage,model
        parsed_source.native=SimpleNamespace(pid=pid,monotonic=time.monotonic);parsed_source.binding,parsed_source.run,parsed_source.role=deepcopy(binding),run,role
        parsed_source.store=store_for(records['parsed-sources'][0]);parsed_source._cached=[]
        parsed_source.raws=ParsedRawSources(parsed_source,role,lambda:True,forbidden)
        parsed_source.originals=OriginalFrameStore(directory,binding,run,role,lambda:True,forbidden,namespace='assets-parsed-source',schema_prefix='iosAssetsParsedSource')
        parsed_source.state=parsed_source.decode(values['parsed-sources']);parsed_covered|=parsed_source.raws.owned_paths()
        for reference in parsed_source.state['frames']:parsed_covered.add(parsed_source.originals.path(parsed_source.originals.expand(reference)))
        pending=[row['pending'] for row in parsed_source.state['interrupted']]+([parsed_source.state['pending']] if parsed_source.state['pending'] is not None else [])
        for row in pending:
            if row['original'] is not None and row['original']['phase']!='planned':parsed_covered.add(parsed_source.originals.path(row['original']))
    need(parsed_paths.get((run,role),set())==parsed_covered)
    if 'parsed' in values:
        need(parsed_source is not None and baking is not None);parsed=object.__new__(OwnedAssetsParsedInput);parsed.sources,parsed.model,parsed.baking=parsed_source,model,baking
        parsed.store=store_for(records['parsed'][0]);parsed.previous=deepcopy(values['parsed']);parsed.state=None;parsed.state=parsed.decode(values['parsed'])
    if 'model-removal' in values:
        need(parsed is not None and parsed.state['phase']=='observed');removal=object.__new__(OwnedAssetsModelRemoval)
        removal.parsed,removal.model,removal.sources,removal.usage,removal.pid=parsed,model,parsed_source,usage,pid
        removal.state=None;removal.state=removal.decode(values['model-removal'])
    need(upload is not None and removal is not None and removal.state['phase']!='model-gone')
    return dict(upload=upload,removal=removal,values=values,runId=run,role=role,binding=binding)

try:
    from adapters.normal_feature_state import PrivateFeatureState
    from adapters.original_file_reads import collect
    from adapters.script_feature.lock import ScriptSourceLock
    from ios.adapters.emote_rooted_end_lock import held_existing
    from ios.adapters.assets_end_selection import construct
    from ios.adapters.assets_end_metadata import RecordingAssetsMetadata
    locks={role:ScriptSourceLock(path) for role,path in lockpaths.items()}
    with ExitStack() as held:
        for role in ('actor','primary'):held.enter_context(held_existing(locks[role]))
        archived=measure('actual-historical-selected-pair-open',lambda:construct(PrivateFeatureState(wal),selected['context'],locks,
            [PrivateFeatureState(Path(path)) for path in raw['paths']]))
        archived.selected_guard()
        primary=selected['context']['roles']['primary'];view=RecordingAssetsMetadata(owned=archived.owned_paths(),selection=archived)
        with collect() as reads:
            graph=measure('actual-complete-ordinary-partial-dependency-graph',lambda:construct_partial_graph(Path(primary['stateRoot']),raw['runId'],view))
            upload,removal=graph['upload'],graph['removal']
            upload._cached=[];upload._validated_refs=[];upload._projects=[]
            upload.state=measure('actual-cold-current-upload-original-decoder',lambda:upload.decode(graph['values']['upload']))
            removal.state=measure('actual-current-model-removal-original-decoder',lambda:removal.decode(graph['values']['model-removal']))
            view.guard();save(runroot/'actual-original-read-membership.json',sorted(str(path) for path in reads))
        reports=[dict(runId=graph['runId'],role=graph['role'],responsibilities=['model-removal','model-removal-resources'],
            ordinaryPartialScopeOnly=True,wholeDirectoryOwnershipRead=False,wholeEndEligible=False,
            uploadFrames=len(upload.state['frames']),uploadPending=upload.state['pending'] is not None,
            removalPhase=removal.state['phase'],removalInputs=len(removal.state['inputs']),removalObservations=len(removal.state['observations']))]
        assert reports[0]['uploadPending'] and reports[0]['removalPhase']=='selecting'
        save(runroot/'actual-private-responsibilities.json',reports)
except BaseException as error:
    primary_error=error;text=''.join(traceback.format_exception(error));print(text,flush=True)
    save(runroot/'actual-original-error.json',dict(type=type(error).__name__,traceback=text))
finally:
    signal.signal(signal.SIGTERM,previous_timeout)
    save(runroot/'actual-timeout-interrupts.json',interrupts)
    profiler.disable();profiler.create_stats()
    if profiler.getstats():
        profiler.dump_stats(str(runroot/'actual-decoders.pstats'));stats=pstats.Stats(profiler);rows=[]
        for (file,line,name),(cc,nc,tt,ct,callers) in stats.stats.items():
            if not Path(file).is_absolute():continue
            try:path=str(Path(file).resolve().relative_to(REPO))
            except (ValueError,OSError):continue
            rows.append(dict(path=path,line=line,function=name,primitiveCalls=cc,calls=nc,selfSeconds=tt,cumulativeSeconds=ct,
                callers=[dict(path=str(Path(f).resolve().relative_to(REPO)) if Path(f).is_absolute() and Path(f).resolve().is_relative_to(REPO) else '<external>',line=l,function=n,counts=list(counts) if type(counts) is tuple else counts) for (f,l,n),counts in callers.items()]))
        save(runroot/'actual-project-calls.json',sorted(rows,key=lambda row:row['cumulativeSeconds'],reverse=True))
    before=remaining();after_inputs={str(p):pin(p) for p in (wal,*lockpaths.values())}
    assert inputs==after_inputs and source_before==sources(plan) and ready_pin==pin(ready) and provenance_pin==pin(provenance)
    imported={}
    for name,module in tuple(sys.modules.items()):
        filename=getattr(module,'__file__',None)
        if filename is None:continue
        path=Path(filename).resolve()
        if path.is_relative_to(REPO):
            relative=str(path.relative_to(REPO));assert relative in source_before,(name,relative);imported[name]=relative
    save(runroot/'actual-imported-local-sources.json',imported)
    after=remaining();threads=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
    sdk_after=check_sdk()
    result=dict(status='ACTUAL_READONLY_DECODER_RETURNED' if primary_error is None else 'ACTUAL_READONLY_DECODER_ERROR',stages=stages,seconds=time.monotonic()-start,
        originalInputsUnchanged=inputs==after_inputs,sourcePinsUnchanged=True,forbiddenAttempts=forbidden,
        remainingOwnedBeforeCensuses=before,remainingOwnedAfterCensuses=after,remainingNewThreads=threads,
        sdkNameAndSourceAuditBeforeImports=True,sdkModulesBefore=sdk_before,sdkModulesAfter=sdk_after,sdkAttempts=sdk_attempts,
        metadataSubprocesses=metadata_subprocesses,rgBinaryUnchanged=pin(rg_executable)==rg_original_pin,
        nativeCompiled=False,sdkExecuted=False,wholeAssetsQualified=False,deviceQualified=False,
        interruptedStackObserved=bool(interrupts),performanceQualification=False,ordinaryPartialScopeOnly=True,wholeDirectoryOwnershipRead=False,wholeEndEligible=False,partialOwnershipKept=reports is not None and any(row['responsibilities'] for row in reports))
    save(runroot/'profile-result.json',result);print('ACTUAL_DIAGNOSTIC',json.dumps(result),flush=True)
    assert not forbidden and not before and not after and not threads and not sdk_attempts
if primary_error is not None:raise primary_error.with_traceback(primary_error.__traceback__)
