"""Distinct current page-generation UI duty over historical upload dependencies.

The original Upload page/file/reply birth is never relabeled. New frame and
read owners are independently current-action scoped; preserved old originals
only authorize the selected owned namespace/bundle and lineage.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import secrets
import time
from adapters.native_feature_observation import NativeFeatureObservation,exact,integer,need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same,pack,unpack
from feature_journeys.phase_fixture import validate as phase_original
from feature_journeys.contract import typed_equal
from ios.adapters.assets_action_phase import AssetsActionPhases,AssetsActionScope
from ios.adapters.assets_episodes import AssetsEpisodeScope
from ios.adapters.assets_generation_replies import GenerationActionReplyReads
from ios.adapters.assets_page_reentry import AssetsPageReentry
from ios.adapters.assets_upload import OwnedAssetsUpload
from ios.adapters.assets_controls import project
from ios.adapters.assets_picker import root
from ios.adapters.assets_tree_owner import OwnedAssetsTree
from ios.adapters.normal_input import NativeInput

VERSION=1


class AssetsGenerationView:
    def __init__(self,generation,episode,actions,action,old_upload,replies,store,native,clock,*,namespace,old_tree=None,monotonic=time.monotonic):
        need(type(generation) is AssetsPageReentry and type(episode) is AssetsEpisodeScope and generation.selected is episode.owner.selected
            and type(actions) is AssetsActionPhases and actions.selected is generation.selected and type(action) is AssetsActionScope and action.owner is actions
            and isinstance(old_upload,OwnedAssetsUpload) and type(replies) is GenerationActionReplyReads and replies.generation is generation
            and replies.reply_episode is episode and replies.action_history is actions and isinstance(store,PrivateFeatureState)
            and isinstance(native,NativeInput) and isinstance(clock,NativeFeatureObservation) and clock.ios and not clock.native_clock_bound
            and namespace in ('original','renamed') and callable(monotonic))
        self.generation,self.episode,self.actions,self.action,self.old_upload=generation,episode,actions,action,old_upload
        self.files,self.replies,self.store,self.native,self.clock=old_upload.files,replies,store,native,clock
        self.run,self.role,self.binding,self.lock=self.files.run,'primary',deepcopy(old_upload.binding),episode.locks['primary']
        self.old_tree=old_tree
        self.namespace,self.monotonic,self.historical=namespace,monotonic,False;self._native_capture=native.capture;self._cached=[];self.clients={}
        need(self.run==actions.run and self.lock is old_upload.lock and same(self.binding,generation.binding) and clock.pid==int(self.binding['processIdentity'])
            and self.store.path==Path(episode.descriptor['directories']['primary']['stateRoot']['path'])/('ios-assets-'+self.run+'-primary-gen'+str(generation.generation)+'-view.json'))
        self.previous=store.read();self.state=None
        self.originals=OriginalFrameStore(store.path.parent,self.binding,self.run,'primary',self.guard,self.frame_intent,
            namespace='assets-gen'+str(generation.generation)+'-view',schema_prefix='iosAssetsGenViewSource',monotonic=monotonic)
        if self.previous is not None:self.state=self.decode(self.previous)
    def origin(self):
        source=self.old_upload;need(source.state is not None and source.state['page']!=self.generation.page()['rootId']
            and same(source.store.read(),source.previous) and source.files is self.files and same(source.binding,self.binding))
        return dict(path=str(source.store.path),page=source.state['page'],fileOwnerToken=self.files.state['token'],
            resource=self.files.state['resource'],ticket=self.files.state['ticket'],destination=source.state['destination'])
    def baseline(self):
        source=self.old_upload;need(source.state is not None and source.state['phase']=='uploaded' and source.state['readback'] is not None)
        need(same(source.decode(source.previous),source.state))
        if self.namespace=='renamed':
            tree=self.old_tree;need(isinstance(tree,OwnedAssetsTree) and tree.upload is source and tree.RENAME_REQUIRED
                and tree.state is not None and tree.state['phase']=='renamed' and same(tree.store.read(),tree.previous) and same(tree.decode(tree.previous),tree.state))
            proof=tree.read_proof('tree-renamed');kind='original-renamed-tree';path=tree.store.path
        else:
            need(self.old_tree is None);source.readback_proof(source.state);proof=source.replies.proof('bundle-final-inventory');kind='original-upload-readback';path=source.store.path
        need(proof['kind']=='inventory');return dict(kind=kind,path=str(path),sha256=digest(proof)),proof
    def guard(self):
        self.lock.assert_held();self.episode.guard();self.generation.guard();self.actions.guard()
        need(same(self.store.read(),self.previous));self.origin()
        if not self.historical:self.action.guard()
        return True
    def link(self):
        self.guard();need(self.state is not None)
        return dict(iosAssetsGenerationViewLinkVersion=1,path=str(self.store.path),token=self.state['token'],pageGeneration=self.generation.link())
    def prefix(self):return '/'+('renamed-' if self.namespace=='renamed' else 'e2e-')+self.run+'/'
    def envelope(self):return dict(iosAssetsGenerationViewVersion=VERSION,binding=self.binding,runId=self.run,role='primary',
        episode=self.episode.link(),pageGeneration=self.generation.link(),originUpload=self.origin(),namespace=self.namespace,payload=pack([self.state]))
    def save(self):
        self.guard();need(not self.historical);value=self.envelope();self.decode(value);self.store.write(value,self.previous);self.previous=deepcopy(value)
    def frame_intent(self,kind,value):
        need(kind=='original' and self.state['pending'] is not None);self.state['pending']['original']=deepcopy(value);self.save()
    def action_frame(self,row):
        exact(row,{'index','ticket','before','after'});index=row['index'];need(integer(index,1,len(self.actions.plan())))
        self.actions.phase_packet(row['before'],index,row['ticket']);self.actions.phase_packet(row['after'],index,row['ticket'])
        phase_original(row['after'],run=self.run,area='assets',request=row['after']['requestId'],epoch=row['after']['capturedEpochMs'],previous=row['before'])
        need(typed_equal(row['before']['activations'],row['after']['activations']))
        if len(self.actions.state['records'])>=index:
            original=self.actions.read(index);need(original['ticket']==row['ticket']);prior=original['phaseBefore']
        else:
            original=self.actions.state['pending'];need(original is not None and original['index']==index and original['ticket']==row['ticket']);prior=original['before']
        phase_original(row['before'],run=self.run,area='assets',request=row['before']['requestId'],epoch=row['before']['capturedEpochMs'],previous=prior)
        return row
    def frame(self,value,previous=None):
        exact(value,{'iosAssetsGenerationViewFrameVersion','action','native'});need(type(value['iosAssetsGenerationViewFrameVersion']) is int and value['iosAssetsGenerationViewFrameVersion']==VERSION)
        self.action_frame(value['action']);OwnedAssetsUpload.frame(self,value['native'],None if previous is None else previous['native'])
        page=root(project(value['native']['ui']),'page',identifier=self.generation.page()['rootId']);known=self.generation.page()
        need(page['visible'] and all(page[key]==known[key] for key in ('rootId','windowId','modelId','componentSource','ownerRootId')))
        root(project(value['native']['ui']),'page',alive=False,identifier=self.origin()['page']);return value
    def decode(self,value):
        exact(value,{'iosAssetsGenerationViewVersion','binding','runId','role','episode','pageGeneration','originUpload','namespace','payload'})
        need(type(value['iosAssetsGenerationViewVersion']) is int and value['iosAssetsGenerationViewVersion']==VERSION and same(value['binding'],self.binding)
            and value['runId']==self.run and value['role']=='primary' and same(value['episode'],self.episode.link())
            and same(value['pageGeneration'],self.generation.link()) and same(value['originUpload'],self.origin()) and value['namespace']==self.namespace)
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0];exact(state,{'phase','token','page','destination','frames','pending','clients','baseline','readback','closedBy'})
        need(state['phase'] in ('ready','view-clients-closed') and type(state['token']) is str and __import__('re').fullmatch('[a-f0-9]{64}',state['token'])
            and state['page']==self.generation.page()['rootId'] and state['destination']==self.prefix() and type(state['frames']) is list and len(state['frames'])<=160
            and type(state['clients']) is dict and set(state['clients'])<={'tree','usage'})
        previous=None;frames=[]
        for index,reference in enumerate(state['frames'],1):
            full=self.originals.expand(reference);need(full['index']==index);frame=self.originals.read(full);self.frame(frame,previous);frames.append(frame);previous=frame
        for kind,path in state['clients'].items():need(path==str(self.store.path.with_name('ios-assets-'+self.run+'-primary-gen'+str(self.generation.generation)+'-'+kind+'.json')))
        baseline,_proof=self.baseline();need(same(state['baseline'],baseline) and type(state['readback']) is dict and state['readback']['kind']=='inventory')
        pending=state['pending']
        if pending is not None:
            exact(pending,{'actionIndex','ticket','phaseBefore','phaseAfter','hostBefore','hostAfter','queries','clocks','ui','uiReceipt','original'})
            self.actions.phase_packet(pending['phaseBefore'],pending['actionIndex'],pending['ticket'])
            if pending['original'] is not None:
                self.originals.original(pending['original'])
                from ios.adapters.assets_model_sources import AssetsModelSources
                AssetsModelSources.prefix(self,pending['original'])
        if state['closedBy'] is not None:need(state['phase']=='view-clients-closed' and integer(state['closedBy'],1,len(frames)) and self.replies.state['phase']=='closed')
        else:need(state['phase']=='ready')
        self._cached=[row['native'] for row in frames];return state
    def reserve(self):
        self.guard();need(self.state is None and self.files.state['phase']=='retired' and self.replies.state['phase']=='open'
            )
        baseline,old_proof=self.baseline()
        # The actual typed historical dependency supplies ownership; the new
        # independent inventory is a distinct current native read job.
        proof=self.replies.read('generation-view-birth');owned=lambda rows:[(row['path'],row['hash']) for row in rows if row['path'].startswith(self.prefix())]
        need(owned(proof['mappings']) and owned(proof['mappings'])==owned(old_proof['mappings']))
        self.state=dict(phase='ready',token=secrets.token_hex(32),page=self.generation.page()['rootId'],destination=self.prefix(),
            frames=[],pending=None,clients={},baseline=deepcopy(baseline),readback=deepcopy(proof),closedBy=None);self.save()
    def capture(self):
        self.guard();need(self.state is not None and self.state['pending'] is None and len(self.state['frames'])<160)
        before=self.actions.phase.status();self.actions.phase_packet(before,self.action.index,self.action.ticket)
        pending=dict(actionIndex=self.action.index,ticket=self.action.ticket,phaseBefore=before,phaseAfter=None,hostBefore=self.monotonic(),hostAfter=None,
            queries=[],clocks=[],ui=None,uiReceipt=None,original=None);self.state['pending']=pending;self.save()
        send,read=self.clock.send,self.clock.read;previous_intent=getattr(self.native,'observe_intent',None)
        def clock_send(query):pending['queries'].append(dict(kind='clock',command=deepcopy(query)));self.save();return send(query)
        def clock_read(*args,**kwargs):
            value=read(*args,**kwargs);pending['clocks'].append(deepcopy(value));self.save();return value
        def ui_intent(query):
            pending['queries'].append(dict(kind='ui',command=deepcopy(query)));self.save()
            if previous_intent is not None:previous_intent(query)
        self.clock.send,self.clock.read,self.native.observe_intent=clock_send,clock_read,ui_intent
        try:
            self.clock.read(self.clock.sequence);pending['ui']=deepcopy(self._native_capture());pending['uiReceipt']=deepcopy(self.native.last_receipt);self.save()
            self.clock.read(self.clock.sequence);pending['hostAfter']=self.monotonic();pending['phaseAfter']=self.actions.phase.status();self.save()
        finally:
            self.clock.send,self.clock.read=send,read
            if previous_intent is None:del self.native.observe_intent
            else:self.native.observe_intent=previous_intent
        native={key:deepcopy(pending[key]) for key in ('hostBefore','hostAfter','queries','clocks','ui','uiReceipt')}
        frame=dict(iosAssetsGenerationViewFrameVersion=VERSION,action=dict(index=pending['actionIndex'],ticket=pending['ticket'],before=pending['phaseBefore'],after=pending['phaseAfter']),native=native)
        self.frame(frame);reference=self.originals.write(len(self.state['frames'])+1,frame);self.state['frames'].append(reference);self.state['pending']=None;self.save();return deepcopy(native['ui'])
    def bind_client(self,kind,owner):
        self.guard();need(kind in ('tree','usage') and owner.lock is self.lock and owner.store.path==self.store.path.with_name('ios-assets-'+self.run+'-primary-gen'+str(self.generation.generation)+'-'+kind+'.json'))
        existing=self.state['clients'].get(kind);need(existing is None or existing==str(owner.store.path));self.clients[kind]=owner
        if existing is None:self.state['clients'][kind]=str(owner.store.path);self.save()
    def cleanup_phase(self):return 'view-clients-closed'
    def cleanup(self,*,abort=False):
        self.guard();need(type(abort) is bool and set(self.clients)==set(self.state['clients']))
        for owner in self.clients.values():
            need(owner.state is not None and same(owner.store.read(),owner.previous) and all(entry['resolvedBy'] is not None and entry['abandonedBy'] is None for entry in owner.state['inputs']))
        self.replies.close();packet=self.capture();page=root(project(packet),'page',identifier=self.state['page'])
        need(not page['busy'] and not page['bundleRequest'] and not page['pendingBundle'] and not page['destinationOpen'])
        self.state['phase']='view-clients-closed';self.state['closedBy']=len(self.state['frames']);self.save();return packet
