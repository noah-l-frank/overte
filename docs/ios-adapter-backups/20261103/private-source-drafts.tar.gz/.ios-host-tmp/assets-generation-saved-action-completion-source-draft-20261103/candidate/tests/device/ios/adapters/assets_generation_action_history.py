"""Read an actual completed or saved-pending action original as data only.

A saved pending source stays pending. This reader cannot complete an action,
acquire native authority or infer success from an absent/planned/opened source.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import integer,need
from adapters.script_feature.history import same
from ios.adapters.assets_action_phase import AssetsActionPhases


def action_original(actions,index,*,include_saved_pending=False):
    need(type(actions) is AssetsActionPhases and type(include_saved_pending) is bool
        and integer(index,1,len(actions.plan())))
    actions.guard();need(actions.state is not None and same(actions.store.read(),actions.previous)
        and same(actions.envelope(),actions.previous))
    if index<=len(actions.state['records']):return actions.read(index)
    pending=actions.state['pending']
    need(include_saved_pending and pending is not None and index==len(actions.state['records'])+1
        and pending['index']==index and pending['after'] is not None and pending['original'] is not None
        and pending['original']['phase']=='saved')
    body=actions.originals.read(pending['original']);actions.frame(body,index)
    need(same(body,actions.body(pending)) and same(actions.store.read(),actions.previous)
        and same(actions.envelope(),actions.previous))
    return body
