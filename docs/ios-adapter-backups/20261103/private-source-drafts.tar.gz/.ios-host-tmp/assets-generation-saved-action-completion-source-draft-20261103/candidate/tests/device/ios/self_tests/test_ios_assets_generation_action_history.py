"""Actual saved Actions originals stay pending under generation data reads."""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.assets_action_phase import AssetsActionPhases
from ios.adapters.assets_generation_action_history import action_original


class AssetsGenerationActionHistoryTests(unittest.TestCase):
    def setUp(self):
        from ios.self_tests.test_ios_assets_action_phase import AssetsActionPhaseTests
        self.f=AssetsActionPhaseTests();self.f.setUp();self.addCleanup(self.f.doCleanups)
        ticket,row=self.f.activate(1);self.action=self.f.owner.begin(1,ticket,row['verb'],row['inputs'])
    def forbidden(self,*_args,**_kwargs):raise AssertionError('Generation action history cannot query or write')
    def saved_pending(self):
        save=self.f.owner.save
        def lost_parent():
            if self.f.owner.state['pending'] is None:raise OSError('Lost actual parent completion CAS')
            return save()
        self.f.owner.save=lost_parent
        with self.assertRaises(OSError):self.f.owner.complete(self.action)
        return AssetsActionPhases(self.f.selected,self.f.store,self.f.h.locks,self.f.phase)
    def test_actual_saved_pending_original_reads_without_completing_or_reacquiring_live_scope(self):
        owner=self.saved_pending();before=deepcopy(owner.state);header=owner.store.path.read_bytes()
        with patch.object(self.f.phase,'status',side_effect=self.forbidden),patch.object(PrivateFeatureState,'write',side_effect=self.forbidden):
            original=action_original(owner,1,include_saved_pending=True)
        self.assertEqual(self.action.ticket,original['ticket']);self.assertEqual(before,owner.state)
        self.assertEqual(header,owner.store.path.read_bytes());self.assertEqual([],owner.state['records'])
        self.assertEqual('saved',owner.state['pending']['original']['phase'])
        with self.assertRaises(NativeUIError):self.action.guard()
    def test_saved_pending_source_requires_explicit_data_only_profile(self):
        owner=self.saved_pending()
        with patch.object(self.f.phase,'status',side_effect=self.forbidden):
            with self.assertRaises(NativeUIError):action_original(owner,1)
        self.assertIsNotNone(owner.state['pending']);self.assertEqual([],owner.state['records'])
    def test_actual_unissued_pending_action_cannot_become_historical_success(self):
        before=deepcopy(self.f.owner.state)
        with patch.object(self.f.phase,'status',side_effect=self.forbidden):
            with self.assertRaises(NativeUIError):action_original(self.f.owner,1,include_saved_pending=True)
        self.assertEqual(before,self.f.owner.state)
    def test_samebytes_foreign_saved_original_inode_refuses_and_keeps_pending_duty(self):
        owner=self.saved_pending();reference=owner.state['pending']['original'];path=owner.originals.path(reference);raw=path.read_bytes()
        path.rename(path.with_name('retained-before-foreign-action-inode'));path.write_bytes(raw);path.chmod(0o600)
        with patch.object(self.f.phase,'status',side_effect=self.forbidden):
            with self.assertRaises(NativeUIError):action_original(owner,1,include_saved_pending=True)
        self.assertIsNotNone(owner.state['pending']);self.assertEqual([],owner.state['records'])


if __name__=='__main__':unittest.main()
