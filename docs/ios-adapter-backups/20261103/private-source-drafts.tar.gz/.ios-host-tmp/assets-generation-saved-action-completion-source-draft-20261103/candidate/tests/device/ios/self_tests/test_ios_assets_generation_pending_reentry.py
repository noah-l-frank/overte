"""Actual reentry originals remain readable after a lost Actions parent CAS.

The original QML/page model remains the declared host boundary; no real SDK,
device, parser, service or full scenario prefix is qualified here.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from ios.adapters.assets_action_phase import AssetsActionPhases
from ios.adapters.assets_page_reentry import AssetsPageReentry


class AssetsGenerationPendingReentryTests(unittest.TestCase):
    def test_saved_pending_actual_birth_reads_without_native_query_write_or_false_action_completion(self):
        from ios.self_tests.test_ios_assets_page_reentry import AssetsPageReentryTests
        case=AssetsPageReentryTests();case.setUp();self.addCleanup(case.doCleanups)
        case.close_context();owner=case.owner();owner.reserve();page=owner.open();save=case.a.owner.save
        def lost_parent():
            if case.a.owner.state['pending'] is None and len(case.a.owner.state['records'])==9:
                raise OSError('Lost actual action9 parent CAS after original was saved')
            return save()
        case.a.owner.save=lost_parent;case.a.epoch=max(case.a.epoch,case.b.clock())+1
        with self.assertRaises(OSError):case.a.owner.complete(case.action)
        actions=AssetsActionPhases(case.a.selected,case.a.store,case.a.h.locks,case.a.phase)
        before=deepcopy(actions.state);source_header=case.store.path.read_bytes()
        with patch.object(case.b,'exchange',side_effect=case.forbidden),patch.object(case.a.phase,'status',side_effect=case.forbidden),patch.object(PrivateFeatureState,'write',side_effect=case.forbidden):
            cold=AssetsPageReentry.from_archive(case.a.selected,case.store,case.a.h.locks['primary'],actions,
                action_index=9,removal=case.removal,monotonic=case.b.monotonic)
            self.assertEqual(page,cold.page())
        self.assertEqual(before,actions.state);self.assertEqual(8,len(actions.state['records']))
        self.assertEqual('saved',actions.state['pending']['original']['phase'])
        self.assertEqual(source_header,case.store.path.read_bytes())


if __name__=='__main__':unittest.main()
