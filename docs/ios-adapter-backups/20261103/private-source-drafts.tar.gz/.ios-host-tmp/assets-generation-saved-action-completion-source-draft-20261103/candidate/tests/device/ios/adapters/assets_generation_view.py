"""Distinct current page-generation UI duty over historical upload dependencies.

The original Upload page/file/reply birth is never relabeled. New frame and
read owners are independently current-action scoped; preserved old originals
only authorize the selected owned namespace/bundle and lineage.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import secrets
import time
from types import SimpleNamespace
from adapters.native_feature_observation import NativeFeatureObservation,exact,integer,need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same,pack,unpack
from feature_journeys.phase_fixture import validate as phase_original
from feature_journeys.contract import typed_equal
from ios.adapters.assets_action_phase import AssetsActionPhases,AssetsActionScope
from ios.adapters.assets_episodes import AssetsEpisodeScope
from ios.adapters.assets_generation_replies import GenerationActionReplyReads
from ios.adapters.assets_page_reentry import AssetsPageReentry
from ios.adapters.assets_generation_action_history import action_original
from ios.adapters.assets_upload import OwnedAssetsUpload
from ios.adapters.assets_controls import project
from ios.adapters.assets_picker import root
from ios.adapters.assets_tree_owner import OwnedAssetsTree
from ios.adapters.normal_input import NativeInput

VERSION=1


class AssetsGenerationView:
    def __init__(self,generation,episode,actions,action,old_upload,replies,store,native,clock,*,namespace,old_tree=None,reply_owners=(),resume_completed_prefix=False,monotonic=time.monotonic):
        need(type(generation) is AssetsPageReentry and type(episode) is AssetsEpisodeScope and generation.selected is episode.owner.selected
            and type(actions) is AssetsActionPhases and actions.selected is generation.selected and type(action) is AssetsActionScope and action.owner is actions
            and isinstance(old_upload,OwnedAssetsUpload) and type(replies) is GenerationActionReplyReads and replies.generation is generation
            and replies.reply_episode is episode and replies.action_history is actions and replies.reply_action is action
            and replies.action_index==action.index and isinstance(store,PrivateFeatureState)
            and isinstance(native,NativeInput) and isinstance(clock,NativeFeatureObservation) and clock.ios and not clock.native_clock_bound
            and namespace in ('original','renamed') and callable(monotonic) and type(resume_completed_prefix) is bool)
        self.generation,self.episode,self.actions,self.action,self.old_upload=generation,episode,actions,action,old_upload
        self.files,self.replies,self.store,self.native,self.clock=old_upload.files,replies,store,native,clock
        self.run,self.role,self.binding,self.lock=self.files.run,'primary',deepcopy(old_upload.binding),episode.locks['primary']
        self.old_tree=old_tree
        self.namespace,self.monotonic,self.historical=namespace,monotonic,resume_completed_prefix;self._native_capture=native.capture;self._cached=[];self.clients={}
        self.reply_owners={};self.archive_only=False
        for owner in (reply_owners if resume_completed_prefix else (*reply_owners,replies)):
            self.reply_binding(owner);need(owner.action_index not in self.reply_owners or self.reply_owners[owner.action_index] is owner)
            self.reply_owners[owner.action_index]=owner
        need(self.run==actions.run and self.lock is old_upload.lock and same(self.binding,generation.binding) and clock.pid==int(self.binding['processIdentity'])
            and self.store.path==Path(episode.descriptor['directories']['primary']['stateRoot']['path'])/('ios-assets-'+self.run+'-primary-gen'+str(generation.generation)+'-view.json'))
        self.previous=store.read();self.state=None
        self.originals=OriginalFrameStore(store.path.parent,self.binding,self.run,'primary',self.guard,self.frame_intent,
            namespace='assets-gen'+str(generation.generation)+'-view',schema_prefix='iosAssetsGenViewSource',monotonic=monotonic)
        if self.previous is not None:self.state=self.decode(self.previous)
        if resume_completed_prefix:
            # Rebuild every old per-action owner against a fresh historical
            # generation before calling this explicit handoff constructor.
            # Its read-only prefix never needs the expired old action guard.
            need(generation.historical and self.state is not None and self.state['phase']=='ready'
                and self.state['pending'] is None and self.state['activeAction']==len(actions.state['records'])
                and action.index==self.state['activeAction']+1 and replies.reply_action is action
                and replies.action_index==action.index and replies.state['phase']=='open'
                and action.index not in self.reply_owners)
            action.guard();actions.read(self.state['activeAction'])
            self.reply_owners[action.index]=replies;self.state['activeAction']=action.index
            self.state['replyOwners'][str(action.index)]=replies.link();self.historical=False;self.save()
    @classmethod
    def from_archive(cls,generation,episode,actions,old_upload,store,*,reply_owners,namespace,old_tree=None,baked_parsed=None,monotonic=time.monotonic):
        need(type(generation) is AssetsPageReentry and generation.historical and type(episode) is AssetsEpisodeScope
            and type(actions) is AssetsActionPhases and generation.selected is episode.owner.selected is actions.selected
            and isinstance(old_upload,OwnedAssetsUpload) and isinstance(store,PrivateFeatureState)
            and namespace in ('original','renamed') and callable(monotonic))
        owner=object.__new__(cls)
        owner.generation,owner.episode,owner.actions,owner.old_upload=generation,episode,actions,old_upload
        owner.files,owner.store,owner.old_tree,owner.namespace=old_upload.files,store,old_tree,namespace
        owner.run,owner.role,owner.binding,owner.lock=owner.files.run,'primary',deepcopy(old_upload.binding),episode.locks['primary']
        owner.historical,owner.archive_only,owner.monotonic=True,True,monotonic
        owner.previous=store.read();owner.state=None;need(owner.previous is not None)
        need(store.path==Path(episode.descriptor['directories']['primary']['stateRoot']['path'])/('ios-assets-'+owner.run+'-primary-gen'+str(generation.generation)+'-view.json'))
        rows=unpack(owner.previous['payload']);need(len(rows)==1 and type(rows[0]) is dict)
        index=rows[0].get('activeAction');original=action_original(actions,index,include_saved_pending=True)
        # A data context is not a live ActionScope; there is no guard/native port.
        owner.action=SimpleNamespace(index=index,ticket=original['ticket']);owner.reply_owners={}
        for replies in reply_owners:
            owner.reply_binding(replies);need(replies.action_index not in owner.reply_owners)
            owner.reply_owners[replies.action_index]=replies
        need(index in owner.reply_owners);owner.replies=owner.reply_owners[index]
        def forbidden(*_args,**_kwargs):raise RuntimeError('Historical generation View has no native/query/input/write/recovery authority')
        owner.native=SimpleNamespace(capture=forbidden,assets_input=forbidden,guard=forbidden,sleep=forbidden)
        owner.clock=SimpleNamespace(pid=int(owner.binding['processIdentity']),send=forbidden,read=forbidden)
        owner._native_capture,owner._cached,owner.clients=forbidden,[],{}
        owner.originals=OriginalFrameStore(store.path.parent,owner.binding,owner.run,'primary',owner.guard,forbidden,
            namespace='assets-gen'+str(generation.generation)+'-view',schema_prefix='iosAssetsGenViewSource',monotonic=monotonic)
        owner.state=owner.decode(owner.previous)
        from ios.adapters.assets_generation_clients import GenerationAssetsTree,GenerationAssetsUsage
        from ios.adapters.assets_generation_baked_tree import GenerationAssetsBakedTree
        for kind,name in owner.state['clients'].items():
            client_store=PrivateFeatureState(name)
            if kind=='tree':
                client=(GenerationAssetsBakedTree(owner,baked_parsed,client_store,lock=owner.lock) if generation.generation==4
                    else GenerationAssetsTree(owner,client_store,lock=owner.lock))
            else:client=GenerationAssetsUsage(owner,client_store,lock=owner.lock)
            need(client.state is not None and owner.clients.get(kind) is client)
        owner.guard();return owner
    def origin(self):
        source=self.old_upload;need(source.state is not None and source.state['page']!=self.generation.page()['rootId']
            and same(source.store.read(),source.previous) and source.files is self.files and same(source.binding,self.binding))
        return dict(path=str(source.store.path),page=source.state['page'],fileOwnerToken=self.files.state['token'],
            resource=self.files.state['resource'],ticket=self.files.state['ticket'],destination=source.state['destination'])
    def baseline(self):
        source=self.old_upload;need(source.state is not None and source.state['phase']=='uploaded' and source.state['readback'] is not None)
        need(same(source.decode(source.previous),source.state))
        if self.namespace=='renamed':
            tree=self.old_tree;need(isinstance(tree,OwnedAssetsTree) and tree.upload is source and tree.RENAME_REQUIRED
                and tree.state is not None and tree.state['phase']=='renamed' and same(tree.store.read(),tree.previous) and same(tree.decode(tree.previous),tree.state))
            proof=tree.read_proof('tree-renamed');kind='original-renamed-tree';path=tree.store.path
        else:
            need(self.old_tree is None);source.readback_proof(source.state);proof=source.replies.proof('bundle-final-inventory');kind='original-upload-readback';path=source.store.path
        need(proof['kind']=='inventory');return dict(kind=kind,path=str(path),sha256=digest(proof)),proof
    def guard(self):
        self.lock.assert_held();self.episode.guard();self.generation.guard();self.actions.guard()
        need(same(self.store.read(),self.previous));self.origin()
        if not self.historical:self.action.guard()
        return True
    def link(self):
        self.guard();need(self.state is not None)
        return dict(iosAssetsGenerationViewLinkVersion=1,path=str(self.store.path),token=self.state['token'],pageGeneration=self.generation.link())
    def prefix(self):return '/'+('renamed-' if self.namespace=='renamed' else 'e2e-')+self.run+'/'
    def envelope(self):return dict(iosAssetsGenerationViewVersion=VERSION,binding=self.binding,runId=self.run,role='primary',
        episode=self.episode.link(),pageGeneration=self.generation.link(),originUpload=self.origin(),namespace=self.namespace,payload=pack([self.state]))
    def save(self):
        self.guard();need(not self.historical);value=self.envelope();self.decode(value);self.store.write(value,self.previous);self.previous=deepcopy(value)
    def frame_intent(self,kind,value):
        need(kind=='original' and self.state['pending'] is not None);self.state['pending']['original']=deepcopy(value);self.save()
    def action_frame(self,row):
        exact(row,{'index','ticket','before','after'});index=row['index'];need(integer(index,1,len(self.actions.plan())))
        self.actions.phase_packet(row['before'],index,row['ticket']);self.actions.phase_packet(row['after'],index,row['ticket'])
        phase_original(row['after'],run=self.run,area='assets',request=row['after']['requestId'],epoch=row['after']['capturedEpochMs'],previous=row['before'])
        need(typed_equal(row['before']['activations'],row['after']['activations']))
        if len(self.actions.state['records'])>=index:
            original=self.actions.read(index);need(original['ticket']==row['ticket']);prior=original['phaseBefore']
        else:
            original=self.actions.state['pending'];need(original is not None and original['index']==index and original['ticket']==row['ticket']);prior=original['before']
        phase_original(row['before'],run=self.run,area='assets',request=row['before']['requestId'],epoch=row['before']['capturedEpochMs'],previous=prior)
        return row
    def frame(self,value,previous=None):
        exact(value,{'iosAssetsGenerationViewFrameVersion','action','native'});need(type(value['iosAssetsGenerationViewFrameVersion']) is int and value['iosAssetsGenerationViewFrameVersion']==VERSION)
        self.action_frame(value['action']);OwnedAssetsUpload.frame(self,value['native'],None if previous is None else previous['native'])
        page=root(project(value['native']['ui']),'page',identifier=self.generation.page()['rootId']);known=self.generation.page()
        need(page['visible'] and all(page[key]==known[key] for key in ('rootId','windowId','modelId','componentSource','ownerRootId')))
        root(project(value['native']['ui']),'page',alive=False,identifier=self.origin()['page']);return value
    def decode(self,value):
        exact(value,{'iosAssetsGenerationViewVersion','binding','runId','role','episode','pageGeneration','originUpload','namespace','payload'})
        need(type(value['iosAssetsGenerationViewVersion']) is int and value['iosAssetsGenerationViewVersion']==VERSION and same(value['binding'],self.binding)
            and value['runId']==self.run and value['role']=='primary' and same(value['episode'],self.episode.link())
            and same(value['pageGeneration'],self.generation.link()) and same(value['originUpload'],self.origin()) and value['namespace']==self.namespace)
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0];exact(state,{'phase','token','page','destination','frames','pending','clients','baseline','readback','closedBy','activeAction','replyOwners','replySlots'})
        need(state['phase'] in ('ready','view-clients-closed') and type(state['token']) is str and __import__('re').fullmatch('[a-f0-9]{64}',state['token'])
            and state['page']==self.generation.page()['rootId'] and state['destination']==self.prefix() and type(state['frames']) is list and len(state['frames'])<=160
            and type(state['clients']) is dict and set(state['clients'])<={'tree','usage'})
        self.reply_state(state)
        previous=None;frames=[]
        for index,reference in enumerate(state['frames'],1):
            full=self.originals.expand(reference);need(full['index']==index);frame=self.originals.read(full);self.frame(frame,previous);frames.append(frame);previous=frame
        for kind,path in state['clients'].items():need(path==str(self.store.path.with_name('ios-assets-'+self.run+'-primary-gen'+str(self.generation.generation)+'-'+kind+'.json')))
        baseline,_proof=self.baseline();need(same(state['baseline'],baseline) and type(state['readback']) is dict and state['readback']['kind']=='inventory')
        need(same(state['readback'],self.reply_owners[state['replySlots']['generation-view-birth']].proof('generation-view-birth')))
        pending=state['pending']
        if pending is not None:
            exact(pending,{'actionIndex','ticket','phaseBefore','phaseAfter','hostBefore','hostAfter','queries','clocks','ui','uiReceipt','original'})
            self.actions.phase_packet(pending['phaseBefore'],pending['actionIndex'],pending['ticket'])
            if pending['original'] is not None:
                self.originals.original(pending['original'])
                from ios.adapters.assets_model_sources import AssetsModelSources
                AssetsModelSources.prefix(self,pending['original'])
        if state['closedBy'] is not None:need(state['phase']=='view-clients-closed' and integer(state['closedBy'],1,len(frames)) and self.replies.state['phase']=='closed')
        else:need(state['phase']=='ready')
        self._cached=[row['native'] for row in frames];return state
    def reserve(self):
        self.guard();need(self.state is None and self.action.index==self.generation.action_index
            and self.files.state['phase']=='retired' and self.replies.state['phase']=='open'
            )
        baseline,old_proof=self.baseline()
        # The actual typed historical dependency supplies ownership; the new
        # independent inventory is a distinct current native read job.
        proof=self.replies.read('generation-view-birth');owned=lambda rows:[(row['path'],row['hash']) for row in rows if row['path'].startswith(self.prefix())]
        need(owned(proof['mappings']) and owned(proof['mappings'])==owned(old_proof['mappings']))
        self.state=dict(phase='ready',token=secrets.token_hex(32),page=self.generation.page()['rootId'],destination=self.prefix(),
            frames=[],pending=None,clients={},baseline=deepcopy(baseline),readback=deepcopy(proof),closedBy=None,
            activeAction=self.action.index,replyOwners={str(self.action.index):self.replies.link()},replySlots={'generation-view-birth':self.action.index});self.save()
    def capture(self):
        self.guard();need(self.state is not None and self.state['pending'] is None and len(self.state['frames'])<160)
        before=self.actions.phase.status();self.actions.phase_packet(before,self.action.index,self.action.ticket)
        pending=dict(actionIndex=self.action.index,ticket=self.action.ticket,phaseBefore=before,phaseAfter=None,hostBefore=self.monotonic(),hostAfter=None,
            queries=[],clocks=[],ui=None,uiReceipt=None,original=None);self.state['pending']=pending;self.save()
        send,read=self.clock.send,self.clock.read;previous_intent=getattr(self.native,'observe_intent',None)
        def clock_send(query):pending['queries'].append(dict(kind='clock',command=deepcopy(query)));self.save();return send(query)
        def clock_read(*args,**kwargs):
            value=read(*args,**kwargs);pending['clocks'].append(deepcopy(value));self.save();return value
        def ui_intent(query):
            pending['queries'].append(dict(kind='ui',command=deepcopy(query)));self.save()
            if previous_intent is not None:previous_intent(query)
        self.clock.send,self.clock.read,self.native.observe_intent=clock_send,clock_read,ui_intent
        try:
            self.clock.read(self.clock.sequence);pending['ui']=deepcopy(self._native_capture());pending['uiReceipt']=deepcopy(self.native.last_receipt);self.save()
            self.clock.read(self.clock.sequence);pending['hostAfter']=self.monotonic();pending['phaseAfter']=self.actions.phase.status();self.save()
        finally:
            self.clock.send,self.clock.read=send,read
            if previous_intent is None:del self.native.observe_intent
            else:self.native.observe_intent=previous_intent
        native={key:deepcopy(pending[key]) for key in ('hostBefore','hostAfter','queries','clocks','ui','uiReceipt')}
        frame=dict(iosAssetsGenerationViewFrameVersion=VERSION,action=dict(index=pending['actionIndex'],ticket=pending['ticket'],before=pending['phaseBefore'],after=pending['phaseAfter']),native=native)
        self.frame(frame);reference=self.originals.write(len(self.state['frames'])+1,frame);self.state['frames'].append(reference);self.state['pending']=None;self.save();return deepcopy(native['ui'])
    def bind_client(self,kind,owner):
        self.guard();need(kind in ('tree','usage') and owner.lock is self.lock and owner.store.path==self.store.path.with_name('ios-assets-'+self.run+'-primary-gen'+str(self.generation.generation)+'-'+kind+'.json'))
        existing=self.state['clients'].get(kind);need(existing is None or existing==str(owner.store.path));self.clients[kind]=owner
        if existing is None:self.state['clients'][kind]=str(owner.store.path);self.save()
    def reply_binding(self,owner):
        need(type(owner) is GenerationActionReplyReads and owner.generation is self.generation
            and owner.reply_episode is self.episode and owner.action_history is self.actions
            and owner.lock is self.lock and same(owner.binding,self.binding)
            and same(owner.store.read(),owner.previous) and owner.state is not None
            and owner.state['ticket']==self.episode.descriptor['ticket'] and owner.state['resource']==self.files.state['resource']
            and owner.state['namespace']==self.namespace)
        return owner
    def reply_state(self,state):
        need(type(state['activeAction']) is int and state['activeAction'] in self.reply_owners
            and (self.historical and (state['activeAction']==self.action.index if self.archive_only else state['activeAction']<self.action.index) or not self.historical
                and state['activeAction']==self.action.index==self.replies.action_index) and type(state['replyOwners']) is dict
            and set(state['replyOwners'])=={str(index) for index in self.reply_owners}
            and type(state['replySlots']) is dict and 1<=len(state['replySlots'])<=64)
        need(set(self.reply_owners)==set(range(self.generation.action_index,state['activeAction']+1)))
        for index,owner in self.reply_owners.items():
            self.reply_binding(owner);need(same(state['replyOwners'][str(index)],owner.link()))
            need(index<=state['activeAction'])
            if self.historical or index!=state['activeAction']:need(owner.state['phase']=='closed')
            for job in owner.state['jobs']:need(state['replySlots'].get(job['slot'])==index)
        for slot,index in state['replySlots'].items():
            need(type(slot) is str and __import__('re').fullmatch('[a-z][a-z0-9-]{0,47}',slot)
                and type(index) is int and index in self.reply_owners)
        need(state['replySlots'].get('generation-view-birth')==self.generation.action_index)
        return True
    def reply_owner(self,slot,*,create=False):
        self.guard();need(type(create) is bool and type(slot) is str
            and __import__('re').fullmatch('[a-z][a-z0-9-]{0,47}',slot) and self.state is not None)
        index=self.state['replySlots'].get(slot)
        if index is None:
            need(create and not self.historical and self.state['phase']=='ready' and self.state['pending'] is None)
            self.action.guard();owner=self.reply_binding(self.replies);need(owner.state['phase']=='open')
            need(len(self.state['replySlots'])<64);index=owner.action_index;self.state['replySlots'][slot]=index;self.save()
        owner=self.reply_binding(self.reply_owners[index])
        if create:
            # Read recovery cannot issue fresh native work through an owner
            # whose actual action already ended. Data-only proof() still reads it.
            need(index==self.action.index and owner is self.replies and owner.state['phase']=='open')
        return owner
    def finish_action_replies(self):
        self.guard();need(not self.historical and self.state['phase']=='ready' and self.state['pending'] is None)
        # Called only after every actual target/peer/image/file consumer, while
        # this original action remains current. This closes actual known jobs;
        # it produces no aggregate ReplyOwner or cross-action cleanup authority.
        self.reply_state(self.state);need(set(self.clients)==set(self.state['clients']))
        for owner in self.clients.values():
            need(owner.state is not None and same(owner.store.read(),owner.previous)
                and all(entry['resolvedBy'] is not None and entry['abandonedBy'] is None for entry in owner.state['inputs']))
        self.replies.close();self.save();return self.replies.link()
    def confirm_retired_action(self,event):
        need(self.historical and self.archive_only and event['runId']==self.run
            and event['stepIndex']==self.action.index and event['ticket']==self.action.ticket)
        self.guard();original=action_original(self.actions,self.action.index,include_saved_pending=True)
        need(original['ticket']==event['ticket'] and same(self.decode(self.previous),self.state)
            and self.state['pending'] is None and set(self.clients)==set(self.state['clients']))
        self.reply_state(self.state)
        for client in self.clients.values():
            need(client.state is not None and same(client.store.read(),client.previous)
                and same(client.decode(client.previous),client.state)
                and all(entry['resolvedBy'] is not None and entry['abandonedBy'] is None for entry in client.state['inputs']))
        self.guard();return True
    def cleanup_phase(self):return 'view-clients-closed'
    def cleanup(self,*,abort=False):
        self.guard();need(type(abort) is bool and set(self.clients)==set(self.state['clients']))
        for owner in self.clients.values():
            need(owner.state is not None and same(owner.store.read(),owner.previous) and all(entry['resolvedBy'] is not None and entry['abandonedBy'] is None for entry in owner.state['inputs']))
        self.replies.close();packet=self.capture();page=root(project(packet),'page',identifier=self.state['page'])
        need(not page['busy'] and not page['bundleRequest'] and not page['pendingBundle'] and not page['destinationOpen'])
        self.state['phase']='view-clients-closed';self.state['closedBy']=len(self.state['frames']);self.save();return packet
