"""Actual engine cleanup activation, separate from every regular input scope.

This source records only owned cleanup authority and retained prefix duties.
It does not complete cancellation, prove absence, retire resources or qualify
normal29/whole end. New SDK factories must opt in to the exact typed scope.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
import time
from adapters.native_feature_observation import exact,integer,need
from adapters.native_clock_join import digest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same,pack,unpack
from adapters.script_feature.lock import ScriptSourceLock
from feature_journeys.contract import typed_equal
from feature_journeys.phase_fixture import PhaseFixtureReader,validate as phase_original
from ios.adapters.assets_action_phase import AssetsActionPhases
from ios.adapters.assets_episodes import AssetsEpisodes,AssetsEpisodeScope
from ios.adapters.assets_end_graph import AssetsFinalArchive
from ios.adapters.assets_model_sources import AssetsModelSources

VERSION=1


class AssetsCleanupPhase:
    def __init__(self,selected,actions,episodes,store,locks,*,historical=False,monotonic=time.monotonic):
        need(type(selected) is AssetsFinalArchive and type(actions) is AssetsActionPhases and type(episodes) is AssetsEpisodes
            and actions.selected is episodes.selected is selected and isinstance(store,PrivateFeatureState)
            and set(locks)=={'primary','actor'} and all(type(lock) is ScriptSourceLock for lock in locks.values())
            and all(locks[role] is actions.locks[role] is episodes.locks[role] for role in locks)
            and type(historical) is bool and callable(monotonic) and actions.state is not None)
        self.selected,self.actions,self.episodes,self.store,self.locks=selected,actions,episodes,store,dict(locks)
        self.run,self.binding,self.historical,self.monotonic=selected.run,deepcopy(selected.context['roles']['primary']['binding']),historical,monotonic
        self.phase=None if historical else actions.phase
        if not historical:need(type(self.phase) is PhaseFixtureReader)
        need(store.path==Path(selected.context['roles']['primary']['stateRoot'])/('ios-assets-cleanup-phase-'+self.run+'.json'))
        self.previous=store.read();self.state=None
        self.originals=OriginalFrameStore(store.path.parent,self.binding,self.run,'primary',self.metadata_guard,self.intent,
            namespace='assets-cleanup-phase',schema_prefix='iosAssetsCleanupPhase',kind='inputs',monotonic=monotonic)
        if self.previous is not None:self.state=self.decode(self.previous)
    def metadata_guard(self):
        for lock in self.locks.values():lock.assert_held()
        self.selected.selected_guard();self.actions.guard();self.episodes.guard()
        need(same(self.store.read(),self.previous));return True
    def snapshots(self):
        self.metadata_guard();need(same(self.actions.store.read(),self.actions.previous) and same(self.actions.envelope(),self.actions.previous)
            and same(self.episodes.store.read(),self.episodes.previous)
            and (same(self.episodes.envelope(),self.episodes.previous) if self.episodes.previous is not None else self.episodes.state==dict(entries=[])))
        return dict(actions=dict(path=str(self.actions.store.path),sha256=digest(self.actions.previous)),
            episodes=dict(path=str(self.episodes.store.path),sha256=digest(self.episodes.previous)))
    def phase_packet(self,packet):
        context=self.selected.context;initial=context['inputPhaseOriginal'];owner=self.actions
        phase_original(packet,run=self.run,area='assets',request=packet['requestId'],epoch=packet['capturedEpochMs'],previous=initial)
        need(packet['active'] and len(packet['activations'])>len(initial['activations']))
        prefix=packet['activations'][:len(initial['activations'])];regular=packet['activations'][len(prefix):-1];last=packet['activations'][-1]
        need(typed_equal(prefix,initial['activations']) and typed_equal(last['stimulus'],dict(verb='cleanup',inputs={})) and len(regular)<=len(owner.plan()))
        for index,row in enumerate(regular):need(typed_equal(row['stimulus'],owner.plan()[index]))
        records=owner.state['records'];pending=owner.state['pending'];need(len(records)<=len(regular)<=len(records)+1)
        for index,ref in enumerate(records,1):need(owner.read(index)['ticket']==regular[index-1]['ticket'])
        if pending is not None:
            need(pending['index']==len(regular)==len(records)+1 and pending['ticket']==regular[-1]['ticket'])
            owner.phase_packet(pending['before'],pending['index'],pending['ticket'])
        mode='all-action-originals' if owner.state['complete'] and pending is None and len(records)==len(owner.plan()) else 'prefix'
        duties=[]
        if pending is not None:duties.append('regular-action-pending-original')
        elif len(regular)>len(records):duties.append('activated-regular-action-not-journaled')
        for row in self.episodes.state['entries']:
            if row['phase']!='ready':duties.append('episode-directory-birth-prefix')
        return dict(ticket=last['ticket'],mode=mode,regularActivations=len(regular),completedActionOriginals=len(records),prefixDuties=sorted(set(duties)))
    def body(self,packet):
        return dict(iosAssetsCleanupPhaseSourceVersion=VERSION,runId=self.run,selectedPair=self.selected.link(),
            journals=self.snapshots(),phaseOriginal=deepcopy(packet),**self.phase_packet(packet))
    def frame(self,value):
        exact(value,{'iosAssetsCleanupPhaseSourceVersion','runId','selectedPair','journals','phaseOriginal','ticket','mode','regularActivations','completedActionOriginals','prefixDuties'})
        need(type(value['iosAssetsCleanupPhaseSourceVersion']) is int and value['iosAssetsCleanupPhaseSourceVersion']==VERSION
            and value['runId']==self.run and same(value['selectedPair'],self.selected.link()) and same(value['journals'],self.snapshots())
            and same({key:value[key] for key in ('ticket','mode','regularActivations','completedActionOriginals','prefixDuties')},self.phase_packet(value['phaseOriginal'])))
        return value
    def envelope(self):return dict(iosAssetsCleanupPhaseVersion=VERSION,runId=self.run,binding=self.binding,role='primary',selectedPair=self.selected.link(),payload=pack([self.state]))
    def save(self):
        self.metadata_guard();need(not self.historical);value=self.envelope();self.store.write(value,self.previous);self.previous=deepcopy(value)
    def intent(self,kind,value):
        need(kind=='original' and self.state is not None and self.state['pending'] is not None)
        self.state['pending']['original']=deepcopy(value);self.save()
    def decode(self,value):
        exact(value,{'iosAssetsCleanupPhaseVersion','runId','binding','role','selectedPair','payload'})
        need(type(value['iosAssetsCleanupPhaseVersion']) is int and value['iosAssetsCleanupPhaseVersion']==VERSION and value['runId']==self.run
            and same(value['binding'],self.binding) and value['role']=='primary' and same(value['selectedPair'],self.selected.link()))
        rows=unpack(value['payload']);need(len(rows)==1);state=rows[0];exact(state,{'phase','original','pending'})
        need(state['phase'] in ('recording','active'))
        if state['original'] is not None:
            need(state['phase']=='active' and state['pending'] is None)
            reference=self.originals.expand(state['original']);need(reference['index']==1);self.frame(self.originals.read(reference))
        else:
            need(state['phase']=='recording' and state['pending'] is not None);pending=state['pending'];exact(pending,{'row','original'});self.frame(pending['row'])
            if pending['original'] is not None:
                self.originals.original(pending['original']);need(pending['original']['index']==1);AssetsModelSources.prefix(self,pending['original'])
                if pending['original']['phase']=='saved':need(same(self.originals.read(pending['original']),pending['row']))
        return state
    def begin(self):
        self.metadata_guard();need(not self.historical and self.state is None)
        packet=self.phase.status();row=self.body(packet);self.state=dict(phase='recording',original=None,pending=dict(row=row,original=None));self.save()
        reference=self.originals.write(1,row);self.current_packet(row)
        self.state=dict(phase='active',original=reference,pending=None);self.save();return AssetsCleanupScope(self)
    def read(self):
        self.metadata_guard();need(self.state is not None and self.state['phase']=='active' and same(self.envelope(),self.previous))
        reference=self.originals.expand(self.state['original']);return self.frame(self.originals.read(reference))
    def current_packet(self,row):
        need(not self.historical);packet=self.phase.status();self.phase_packet(packet)
        phase_original(packet,run=self.run,area='assets',request=packet['requestId'],epoch=packet['capturedEpochMs'],previous=row['phaseOriginal'])
        need(typed_equal(packet['activations'],row['phaseOriginal']['activations']));return packet
    def current(self):self.metadata_guard();row=self.read();self.current_packet(row);return row
    def recover_saved(self):
        self.metadata_guard();need(not self.historical and self.state is not None and self.state['phase']=='recording')
        pending=self.state['pending'];reference=pending['original'];need(reference is not None and reference['phase']=='saved')
        row=self.originals.read(reference);self.frame(row);need(same(row,pending['row']));self.current_packet(row)
        self.state=dict(phase='active',original=self.originals.compact(reference),pending=None);self.save();return AssetsCleanupScope(self)
    def link(self):
        row=self.read();return dict(iosAssetsCleanupPhaseLinkVersion=VERSION,path=str(self.store.path),ticket=row['ticket'],mode=row['mode'])


class AssetsCleanupScope:
    def __init__(self,owner):need(type(owner) is AssetsCleanupPhase);self.owner=owner
    def guard(self):self.owner.current();return True
    def runtime_guard(self,runtime,selector,binding=None,*,episode=None):
        self.guard();owner=self.owner;roles=[role for role,info in owner.selected.context['roles'].items() if info['target']==selector];need(len(roles)==1)
        role=roles[0];info=owner.selected.context['roles'][role];need(runtime.state_path(selector).parent==Path(info['stateRoot']))
        owner.locks[role].assert_held()
        if binding is not None:need(same(binding,info['binding']))
        if episode is not None:
            need(type(episode) is AssetsEpisodeScope and episode.owner is owner.episodes )
            episode.guard();episode.locks[role].assert_held()
        return True
