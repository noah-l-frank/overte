"""Actual independent cleanup activation and original private prefix journals.

Host metadata/authority counters only: no SDK/native input, resource absence,
whole journey success or cancellation completion is supplied by these models.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_feature_state import PrivateFeatureState
from adapters.normal_ui import NativeUIError
from ios.adapters.assets_cleanup_phase import AssetsCleanupPhase,AssetsCleanupScope
from ios.adapters.assets_episodes import AssetsEpisodes
from ios.adapters.assets_runtime import IOSAssetsRuntime
from ios.adapters.script_runtime import IOSScriptRuntime
from ios.self_tests.test_ios_assets_action_phase import AssetsActionPhaseTests
from ios.self_tests.assets_picker_fixture import RUN


class AssetsCleanupPhaseTests(unittest.TestCase):
    def setUp(self):
        self.a=AssetsActionPhaseTests();self.a.setUp();self.addCleanup(self.a.doCleanups)
        self.episodes=AssetsEpisodes(self.a.selected,self.a.h.locks)
        self.store=PrivateFeatureState(self.a.h.roots['primary']/('ios-assets-cleanup-phase-'+RUN+'.json'))
    def owner(self,*,historical=False):return AssetsCleanupPhase(self.a.selected,self.a.owner,self.episodes,self.store,self.a.h.locks,historical=historical)
    def cleanup(self,ticket='f'*32):self.a.epoch+=1;self.a.journal.activate(RUN,ticket,'cleanup',{})
    def regular(self,index,*,pending=False):
        ticket,row=self.a.activate(index);scope=self.a.owner.begin(index,ticket,row['verb'],row['inputs'])
        if not pending:self.a.owner.complete(scope)
        return scope
    def files(self):return {str(p):(p.stat().st_ino,p.read_bytes()) for root in self.a.h.roots.values() for p in root.rglob('*') if p.is_file()}
    def test_zero_episode_actual_cleanup_is_owned_prefix_and_historical_original_read_is_query_free(self):
        self.cleanup();owner=self.owner();scope=owner.begin();self.assertTrue(scope.guard());row=owner.read()
        self.assertEqual('prefix',row['mode']);self.assertEqual(0,row['regularActivations']);self.assertEqual(0,row['completedActionOriginals'])
        self.assertEqual([],self.episodes.state['entries']);self.assertIsNone(self.episodes.store.read());before=self.files()
        with patch.object(self.a.phase,'status',side_effect=AssertionError('Historical source must not query')):
            cold=self.owner(historical=True);self.assertEqual(row,cold.read());self.assertEqual(owner.link(),cold.link())
            with self.assertRaises(NativeUIError):AssetsCleanupScope(cold).guard()
        self.assertEqual(before,self.files());self.assertEqual([],self.a.h.native_calls)
    def test_actual_pending_action_cleanup_revokes_regular_birth_and_existing_episode_factory_before_sources(self):
        self.regular(1);regular=self.regular(2,pending=True);episode=self.episodes.begin(1,regular.ticket)
        with episode.held():
            self.cleanup();owner=self.owner();scope=owner.begin();self.assertIn('regular-action-pending-original',owner.read()['prefixDuties'])
            test=self
            class Adapter:
                def state_path(_self,selector):return test.a.h.roots[selector]/'session.json'
                def _candidate_guard(_self):pass
                def _binding(_self,*args):return test.a.h.no_native(*args)
            runtime=IOSAssetsRuntime(Adapter(),episode=episode);requests=len(self.a.requests)
            with patch.object(IOSScriptRuntime,'_sources',side_effect=self.a.h.no_native) as sources:
                with self.assertRaises(NativeUIError):runtime._assets_sources('primary',episode.locks['primary'])
                self.assertEqual(0,sources.call_count)
            self.assertEqual(requests,len(self.a.requests));self.assertEqual(episode.index,episode.link()['index'])
            self.assertTrue(scope.runtime_guard(runtime,'primary',self.a.h.context['roles']['primary']['binding'],episode=episode))
            with self.assertRaises(NativeUIError):self.a.owner.begin(3,'e'*32,'upload-picker-cancel',{})
            with self.assertRaises(NativeUIError):self.episodes.begin(2,'e'*32)
        self.assertEqual([],self.a.h.native_calls)
    def test_all29_actual_action_originals_do_not_turn_cleanup_metadata_into_all_episode_or_end_success(self):
        for index in range(1,30):self.regular(index)
        self.cleanup();owner=self.owner();owner.begin();row=owner.read()
        self.assertEqual('all-action-originals',row['mode']);self.assertEqual(29,row['completedActionOriginals']);self.assertEqual([],self.episodes.state['entries'])
        self.assertEqual({'phase','original','pending'},set(owner.state));self.assertEqual('active',owner.state['phase']);self.assertEqual([],self.a.h.native_calls)
    def test_activated_but_unjournaled_regular_action_is_retained_as_a_duty(self):
        self.regular(1);self.a.activate(2);self.cleanup();owner=self.owner();owner.begin();row=owner.read()
        self.assertEqual(2,row['regularActivations']);self.assertEqual(1,row['completedActionOriginals']);self.assertIn('activated-regular-action-not-journaled',row['prefixDuties'])
        self.assertEqual([],self.a.h.native_calls)
    def test_lost_parent_saved_original_recovers_current_cleanup_once_but_next_activation_never_retroactivates(self):
        self.cleanup();owner=self.owner();save=owner.save
        def lost():
            if owner.state['phase']=='active':raise OSError('Declared cleanup final parent commit failure')
            return save()
        with patch.object(owner,'save',side_effect=lost):
            with self.assertRaises(OSError):owner.begin()
        restored=self.owner();reference=deepcopy(restored.state['pending']['original']);self.assertEqual('saved',reference['phase'])
        with patch.object(restored.originals,'write',side_effect=AssertionError('Saved cleanup original must not be written again')):
            scope=restored.recover_saved();self.assertTrue(scope.guard())
        self.assertEqual(restored.originals.compact(reference),restored.state['original']);self.cleanup('e'*32);before=self.files()
        with self.assertRaises(NativeUIError):scope.guard()
        self.assertEqual(before,self.files());self.assertEqual([],self.a.h.native_calls)
    def test_original_write_failure_keeps_recording_duty_and_never_authorizes_cleanup_runtime(self):
        self.cleanup();owner=self.owner();failure=OSError('Declared cleanup original store failure')
        with patch.object(owner.originals,'write',side_effect=failure):
            with self.assertRaises(OSError) as caught:owner.begin()
        self.assertIs(failure,caught.exception);restored=self.owner();self.assertEqual('recording',restored.state['phase']);self.assertIsNone(restored.state['pending']['original'])
        with self.assertRaises(NativeUIError):restored.recover_saved()
        with self.assertRaises(NativeUIError):AssetsCleanupScope(restored).guard()
        with self.assertRaises(NativeUIError):self.episodes.begin(1,'d'*32)
        self.assertEqual([],self.a.h.native_calls)
    def test_samebytes_foreign_cleanup_original_inode_cannot_supply_historical_or_current_authority(self):
        self.cleanup();owner=self.owner();owner.begin();reference=owner.originals.expand(owner.state['original']);path=owner.originals.path(reference);raw=path.read_bytes()
        path.rename(path.with_name('retained-before-foreign-cleanup-inode'));path.write_bytes(raw);path.chmod(0o600)
        with patch.object(self.a.phase,'status',side_effect=AssertionError('Invalid original must refuse before current query')):
            with self.assertRaises(NativeUIError):self.owner(historical=True)
            with self.assertRaises(NativeUIError):owner.current()
        self.assertEqual([],self.a.h.native_calls)


if __name__=='__main__':unittest.main()
