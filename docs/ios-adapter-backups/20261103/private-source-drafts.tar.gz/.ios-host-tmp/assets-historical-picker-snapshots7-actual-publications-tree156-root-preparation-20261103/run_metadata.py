"""Private Root run metadata only; no target imports or process launch on import."""
from pathlib import Path
import ast,hashlib,json,os,stat,subprocess
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[1]
FIELDS=('st_dev','st_ino','st_mode','st_uid','st_gid','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    descriptor=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
    with os.fdopen(descriptor,'w') as output:
        output.write(json.dumps(value,indent=2,sort_keys=True)+'\n');output.flush();os.fsync(output.fileno())
def pin(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) or stat.S_ISDIR(a.st_mode),str(path)
    value={key:getattr(a,key) for key in FIELDS}
    if stat.S_ISREG(a.st_mode):value['sha256']=sha(path)
    b=path.lstat();assert all(getattr(a,key)==getattr(b,key) for key in FIELDS),str(path)
    return value

def proc(pid):
    try:fields=Path('/proc',str(pid),'stat').read_text().rsplit(') ',1)[1].split()
    except (FileNotFoundError,ProcessLookupError):return None
    return dict(pid=pid,parentPid=int(fields[1]),processGroup=int(fields[2]),session=int(fields[3]),startTicks=int(fields[19]))

def load_plan():return json.loads((HERE/'suite-plan.json').read_text())
def validate_frozen():
    own=json.loads((HERE/'freeze.json').read_text())
    for name,expected in own['files'].items():assert sha(HERE/name)==expected,name
    plan=load_plan()
    for row in plan['frozenPackets']:
        root=REPO/row['path'];assert sha(root/'freeze.json')==row['freezeSha256']
        frozen=json.loads((root/'freeze.json').read_text())
        for name,expected in frozen.get('files',frozen).items():assert sha(root/name)==expected,name
    for row in plan.get('sourcePackets',[]):
        root=REPO/row['path'];freeze=root/row['freezeFile'];assert sha(freeze)==row['freezeSha256']
        for name,expected in json.loads(freeze.read_text()).items():assert sha(root/name)==expected,name
    for row in plan['actualUi6Tablet2Prerequisites']:
        report=json.loads((REPO/row['report']).read_text());assert report['exitCode']==0 and report['originalFiles']==row['files']
        assert report['allPinsEqual'] and report['postStopOriginalCensusesEqual'] and report['priorOriginalCensusesUnchanged']
        assert report['postStopCensusesQualified'] and not report['ownedProcessesBeforeCensuses'] and not report['remainingOwnedProcesses']
        root=Path(row['runRoot']);child=json.loads((root/'selected-result.json').read_text())
        assert child['testsRun']==row['count'] and child['successful'] and not child['caseAuditFailures']
        assert child['sourceLauncherPinsUnchanged'] and child['originalCensusesEqual']
        assert not child['remainingOwnedChildrenBeforeCensuses'] and not child['remainingOwnedChildrenAfterCensuses']
        assert not child['remainingNewThreadsBeforeCensuses'] and not child['remainingNewThreads']
        proof=plan['actualUi7HistoricalSupplement'];path=REPO/proof['path'];assert sha(path)==proof['sha256']
    actual=json.loads(path.read_text());assert actual['status']=='ACTUAL_UI7_TEST_SNAPSHOT_QUALIFIED_WITH_COUNT_FAILURE_AND_EXPLICIT_FOREIGN_DELTA'
    assert actual['actualUnitCasesQualified']==7 and actual['originalParentExitCode']==1 and actual['originalSelectedSuccessful'] is False
    assert actual['originalAggregateControllerPassed'] is False and actual['currentWholeSourceQualified'] is False and actual['wholeAssetsQualified'] is False
    assert actual['perCasePickerNodes']==1 and actual['totalPickerNodes']==7 and actual['allOriginalCensusesUnchanged'] is True
    prefix=plan['actualComponentPartialPrefix'];receipt_path=REPO/prefix['path'];assert sha(receipt_path)==prefix['sha256']
    receipt=json.loads(receipt_path.read_text());assert receipt['status']=='ACTUAL_FIRST5_ACTION_PHASE_TEST_SNAPSHOT_ONLY_FROM_FAILED_PURE24'
    assert receipt['qualifiedIds']==prefix['qualifiedIds'] and receipt['actualFailedId']==prefix['failedId']
    assert receipt['originalAggregateSuccessful'] is False and receipt['originalParentExitCode']==1 and receipt['currentWholeSourceQualified'] is False and receipt['wholeAssetsQualified'] is False
    for row in receipt['originalEvidencePins']:assert sha(REPO/row['path'])==row['sha256'],row['path']
    failed=json.loads((REPO/prefix['report']).read_text());root=Path(prefix['runRoot']);child=json.loads((root/'selected-result.json').read_text())
    assert failed['exitCode']==1 and failed['originalFiles']==71 and failed['runRoot']==str(root)
    assert failed['allPinsEqual'] and failed['postStopOriginalCensusesEqual'] and failed['priorOriginalCensusesUnchanged'] and failed['postStopCensusesQualified']
    assert not failed['ownedProcessesBeforeCensuses'] and not failed['remainingOwnedProcesses']
    assert child['testsRun']==6 and child['successful'] is False and child['caseAuditFailures']==[] and child['selectedIds'][:5]==prefix['qualifiedIds'] and child['selectedIds'][5]==prefix['failedId']
    cases=child['caseStopReceipts'];assert len(cases)==6 and [case['testId'] for case in cases]==child['selectedIds'][:6]
    assert all(case['cleanAtCaseBoundary'] and case['originalCleanupsReturned'] and not case['remainingNewThreads'] and not case['remainingOwnedChildren'] for case in cases)
    log=(REPO/prefix['report']).with_name('pure24-first.log').read_text()
    for name in prefix['qualifiedIds']:assert name.rsplit('.',1)[1]+' ('+name+') ... ok\n' in log
    assert child['sourceLauncherPinsUnchanged'] and child['originalCensusesEqual']
    assert not child['remainingOwnedChildrenBeforeCensuses'] and not child['remainingOwnedChildrenAfterCensuses'] and not child['remainingNewThreadsBeforeCensuses'] and not child['remainingNewThreads']
    for key in ('taskBinding','runnerBinding'):
        binding=failed[key];current=proc(binding['pid']);assert current is None or current['startTicks']!=binding['startTicks']
    foreign=plan['approvedPendingForeignPublication'];receipt_path=REPO/foreign['receipt']
    assert receipt_path.resolve(strict=True)==receipt_path and receipt_path.is_file(),'Actual reviewed Root publication receipt is required'
    receipt_pin=pin(receipt_path);actual_receipt=json.loads(receipt_path.read_text())
    assert actual_receipt==foreign['expectedReceipt'],'Actual foreign publication receipt differs from the exact Root-approved scope'
    assert pin(receipt_path)==receipt_pin
    for row in actual_receipt['files']:assert sha(REPO/row['path'])==row['sha256'],row['path']
    for publication in plan['actualCurrentPublications']:
        assert sha(REPO/publication['path'])==publication['sha256']
    for foreign in plan['actualAvatarForeign6Publications']:
        receipt_path=REPO/foreign['path'];assert receipt_path.resolve(strict=True)==receipt_path
        assert sha(receipt_path)==foreign['sha256'];actual=json.loads(receipt_path.read_text())
        assert actual==foreign['expectedReceipt'] and actual['registryChanged'] is False
        assert actual['testsExecutedByPublication'] is False and actual['wholeFeatureFlagsUnchanged'] is True
        for row in actual['files']:
            overlay=plan['actualAvatarTestOnlyOverlay']
            if row['path']==overlay['target']:
                assert foreign['path']==overlay['historicalReceipt'] and foreign['sha256']==overlay['historicalReceiptSha256']
                assert row['sha256']==overlay['baseSha256']==overlay['historicalSourceSha256']
                assert sha(REPO/overlay['historicalSourceBytes'])==row['sha256']
                assert sha(REPO/row['path'])==overlay['candidateSha256']
            else:assert sha(REPO/row['path'])==row['sha256'],row['path']
        assert sha(receipt_path)==foreign['sha256']
    foreign=plan['actualAvatarWork2Publication'];path=REPO/foreign['path']
    assert path.resolve(strict=True)==path and sha(path)==foreign['sha256']
    actual=json.loads(path.read_text());assert actual==foreign['expectedReceipt'] and actual['registryChanged'] is False
    assert actual['testsExecutedByPublication'] is False and actual['wholeFeatureFlagsUnchanged'] is True
    for row in actual['files']:assert sha(REPO/row['path'])==row['sha256'],row['path']
    assert sha(path)==foreign['sha256']
    for key in ('actualAvatarTestOnlyOverlay','actualEmoteSharedRound3Publication'):
        proof=plan[key];path=REPO/proof['path'];assert path.resolve(strict=True)==path and sha(path)==proof['sha256']
        actual=json.loads(path.read_text());assert actual==proof['expectedReceipt']
        assert actual['registryChanged'] is False and actual['testsExecutedByPublication'] is False and actual['wholeFeatureFlagsUnchanged'] is True
        if key=='actualAvatarTestOnlyOverlay':
            assert len(actual['files'])==1;row=actual['files'][0]
            assert row['path']==proof['target'] and row['baseSha256']==proof['baseSha256'] and row['sha256']==proof['candidateSha256']
            assert sha(REPO/proof['historicalReceipt'])==proof['historicalReceiptSha256']
            assert sha(REPO/proof['historicalSourceBytes'])==proof['baseSha256']
        for row in actual['files']:assert sha(REPO/row['path'])==row['sha256'],row['path']
        assert sha(path)==proof['sha256']
    fresh=plan['prospectiveHistoricalSnapshotPublication'];path=REPO/fresh['path']
    assert path.resolve(strict=True)==path and path.is_file(),'Actual reviewed historical snapshot Source4 receipt required'
    before=pin(path);assert sha(path)==plan['actualHistoricalSnapshotPublicationSha256']
    actual=json.loads(path.read_text());assert actual==fresh['expectedReceipt']
    for row in actual['files']:assert sha(REPO/row['path'])==row['sha256'],row['path']
    assert pin(path)==before
    qualified=plan['actualCompletedReadonlyProfile'];report=json.loads((REPO/qualified['report']).read_text())
    assert report['kind']=='profile1' and report['exitCode']==0 and report['originalFiles']==0 and report['runRoot']==qualified['runRoot']
    assert report['allPinsEqual'] and report['publicationReadyMapUnchanged'] and report['postStopOriginalCensusesEqual'] and report['priorOriginalCensusesUnchanged'] and report['postStopCensusesQualified']
    assert not report['ownedProcessesBeforeCensuses'] and not report['remainingOwnedProcesses']
    assert json.loads((REPO/qualified['firstCensus']).read_text())==json.loads((REPO/qualified['secondCensus']).read_text())
    result=json.loads((REPO/qualified['result']).read_text())
    assert result['status']=='ACTUAL_READONLY_DECODER_RETURNED' and result['originalInputsUnchanged'] and result['sourcePinsUnchanged']
    assert result['partialOwnershipKept'] is True and result['performanceQualification'] is False and result['wholeDirectoryOwnershipRead'] is False and result['wholeEndEligible'] is False
    assert result['ordinaryPartialScopeOnly'] is True and not result['nativeCompiled'] and not result['sdkExecuted'] and not result['deviceQualified'] and not result['wholeAssetsQualified']
    assert not result['forbiddenAttempts'] and not result['sdkAttempts'] and not result['remainingNewThreads'] and not result['remainingOwnedBeforeCensuses'] and not result['remainingOwnedAfterCensuses']
    assert len(result['stages'])==3 and all(stage['entered'] and stage['returned'] for stage in result['stages'])
    assert result['stages'][-1]['stage']=='actual-existing-complete-page-prefix-inventory'
    assert sha(HERE/'source-root-final-map.json')==plan['sourceRootMapSha256']
    assert sha(HERE/'expected-publication.json')==plan['expectedPublicationSha256']
    return plan

def publication():
    rows=json.loads((HERE/'expected-publication.json').read_text())
    assert len(rows)==load_plan()['expectedPublicationCount']
    for row in rows:
        path=REPO/row['path'];assert path.resolve(strict=True)==path and sha(path)==row['expectedSha256'],row['path']
    return rows

def broad_sources(plan):
    names=subprocess.check_output(['rg','--files','-0',*plan['broadSourceRoots']],cwd=REPO).decode().split('\0')
    paths={REPO/name for name in names if name}
    paths.update(REPO/name for name in plan['explicitExtraSourcePins'])
    paths.update(REPO/name for name in plan.get('selectionConditionalExtraPins',{}).get(plan.get('activeSelection'),[]))
    assert REPO/'interface/src/main.cpp' in paths,'Explicit main.cpp pin missing'
    return paths

def sources(plan):
    paths=broad_sources(plan)
    for root in (HERE,*[REPO/row['path'] for row in plan['frozenPackets']]):
        frozen=json.loads((root/'freeze.json').read_text())
        paths.update(root/name for name in frozen.get('files',frozen));paths.add(root/'freeze.json')
    return {str(path.relative_to(REPO)):pin(path) for path in sorted(paths)}

def originals(root):
    return {str(path.relative_to(root)):pin(path) for path in (root,*sorted(root.rglob('*')))}


def registry_original():
    raw=(REPO/'tests/device/contract-versions.json').read_bytes();value=json.loads(raw)
    required=load_plan()['registryRequired']
    assert all(value['contracts'].get(key)==row for key,row in required.items()),'Previously observed Emote8/foreign registry keys changed'
    validator=REPO/'tests/device/validate_contract_versions.py';tree=ast.parse(validator.read_text())
    assignments=[node for node in tree.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='REQUIRED' for target in node.targets)]
    assert len(assignments)==1;actual=ast.literal_eval(assignments[0].value)
    assert all(actual[key]==row['current'] for key,row in required.items()),'Previously observed Emote8 validator versions changed'
    return dict(sha256=hashlib.sha256(raw).hexdigest(),required=required,validator=pin(validator))


def prior_originals(plan):
    actual={}
    for row in completed_prior_rows(plan):
        root=Path(row['root']);expected=json.loads((REPO/row['reference']).read_text())
        if 'referenceRootKey' in row:expected=expected[row['referenceRootKey']]
        current=originals(root);assert current==expected,row['reference']
        assert sum(stat.S_ISREG(value['st_mode']) for value in current.values())==row['files']
        actual[row['root']]=current
    for row in plan.get('additionalPriorFilePins',[]):
        path=REPO/row['path'];assert sha(path)==row['sha256']
        expected=__import__('json').loads(path.read_text());current={name:pin(REPO/name) for name in expected}
        assert current==expected,'Supplemental retained Photo/Tablet originals changed'
        actual['flat:'+row['path']]=current
    for row in plan.get('additionalRootOriginalCorpora',[]):
        root=Path(row['root']);assert root.resolve(strict=True)==root and root.is_relative_to(REPO/'.ios-host-tmp')
        reference=REPO/row['reference'];assert sha(reference)==row['referenceSha256']
        expected=json.loads(reference.read_text());current=originals(root)
        if row['schema']=='stat-list':
            fields=row['statFields'];current={name:dict(stat=[value[field] for field in fields],**({'sha256':value['sha256']} if 'sha256' in value else {})) for name,value in current.items()}
        else:assert row['schema']=='named-stat-fields'
        assert current==expected,row['label']
        assert sum('sha256' in value for value in current.values())==row['files']
        actual['root25769:'+row['label']]=current
    return actual


def completed_prior_rows(plan):
    for required in plan.get('additionalStoppedResourceDiagnostics',[]):
        report=json.loads((REPO/required['report']).read_text())
        assert report['exitCode']==required['exitCode'] and report['retainedFiles']==required['files']
        assert report['allPinsEqual'] and report['rootMapUnchanged'] and report['retainedOriginalsUnchanged'] and not report['remainingOwnedProcesses']
        thread=json.loads((REPO/required['threadReport']).read_text())
        assert thread['exitCode']==required['exitCode'] and not thread['remainingNewThreads']
        assert json.loads((REPO/required['firstCensus']).read_text())==json.loads((REPO/required['secondCensus']).read_text())
        for path in required['terminalCensuses']:
            terminal=json.loads((REPO/path).read_text())
            assert not terminal['threads'] and not terminal['pendingTasks'] and not terminal['children']
    for required in plan.get('requireActualStoppedDiagnostics',[]):
        actual=json.loads((REPO/required['report']).read_text())
        assert actual['runRoot']==required['runRoot'] and actual['originalFiles']==required['files'] and actual['exitCode']==required['exitCode']
        assert actual['allPinsEqual'] and actual['postStopOriginalCensusesEqual'] and actual['priorOriginalCensusesUnchanged'] and actual['postStopCensusesQualified']
        assert not actual['ownedProcessesBeforeCensuses'] and not actual['remainingOwnedProcesses']
        first=REPO/required['firstCensus'];second=REPO/required['secondCensus'];a=pin(first);b=pin(second)
        assert json.loads(first.read_text())==json.loads(second.read_text())
        assert a==pin(first) and b==pin(second)
        assert required['childFinalQualified'] is False  # Outer termination is not a child-final-drain PASS.
    rows=[dict(row) for row in plan['priorOriginalCorpora']]
    # A prerequisite is NOT claimed complete by this frozen plan. Require
    # its actual parent and child result before this selection can be mapped.
    for required in plan.get('requireActualCompletedSelections',[]):
        if required.get('onlyForKinds') is not None and plan.get('activeSelection') not in required['onlyForKinds']:continue
        path=REPO/required['report'];actual=json.loads(path.read_text())
        assert actual['kind']==required['kind'] and actual['exitCode']==0
        assert actual['allPinsEqual'] and actual['postStopOriginalCensusesEqual']
        assert actual['priorOriginalCensusesUnchanged'] and actual['postStopCensusesQualified']
        assert not actual['ownedProcessesBeforeCensuses'] and not actual['remainingOwnedProcesses']
        root=Path(actual['runRoot']);assert root.resolve(strict=True)==root
        assert root.is_relative_to(REPO/required['runRootParent'])
        child=json.loads((root/'selected-result.json').read_text())
        assert child['successful'] and child['testsRun']==required['count']
        if required.get('resultSchema')=='actual-avatar-case-stop-jsonl-v1':
            assert child['skipped']==[] and child['actualPreimportAuditInstalled'] and child['fixtureAliasesRestored']
            assert child['sourceLauncherPinsUnchanged'] and child['originalCensusesEqual']
            assert not child['remainingNewThreadsBeforeCensuses'] and not child['remainingNewThreads']
            cases=[json.loads(line) for line in (REPO/required['caseStopReceipts']).read_text().splitlines() if line]
            assert len(cases)==required['count'] and [case['testId'] for case in cases]==child['selectedIds']
            assert all(case['caseSuccessful'] and case['allKnownNodeProcessesGone'] and case['allOriginalStreamsClosed']
                and case['allObservedOriginalHostClosesCompleted'] and not case['remainingNewThreads'] for case in cases)
            closed=json.loads((REPO/required['originalCloseReceipt']).read_text())
            assert all(node['current'] is None and node['returnCode'] is not None
                and all(value is None or value is True for value in node['originalStreamsClosed'].values()) for node in closed['nodes'])
        else:
            assert required.get('resultSchema') is None
            assert child['caseAuditFailures']==[]
        row=dict(root=str(root/'temporary'),reference=required['reference'],files=actual['originalFiles'])
        previous=[item for item in rows if item['root']==row['root']]
        if previous:
            assert len(previous)==1,'More than one preexisting original cohort for one root'
            prior=previous[0]
            allowed={'root','files','reference','referenceRootKey'}
            assert set(prior)<=allowed and set(row)<=allowed,'Unknown repeated original cohort grammar'
            assert prior['root']==row['root'] and prior['files']==row['files'],'Conflicting repeated original cohort scope/count'
            def retained_reference(item):
                path=REPO/item['reference']
                assert path.resolve(strict=True)==path and path.is_relative_to(REPO/'.ios-host-tmp')
                before=pin(path);value=json.loads(path.read_text())
                if 'referenceRootKey' in item:
                    assert type(item['referenceRootKey']) is str and item['referenceRootKey'] in value
                    value=value[item['referenceRootKey']]
                assert pin(path)==before,'Repeated original census reference changed while reading'
                return value,before
            original,first_pin=retained_reference(prior);requested,second_pin=retained_reference(row)
            assert original==requested,'Repeated original census references differ'
            assert pin(REPO/prior['reference'])==first_pin and pin(REPO/row['reference'])==second_pin
            # Keep exactly the already-retained row, including its original
            # reference identity. Equivalence does not replace old provenance.
        else:rows.append(row)
    assert len(rows)==len({row['root'] for row in rows})
    return rows
