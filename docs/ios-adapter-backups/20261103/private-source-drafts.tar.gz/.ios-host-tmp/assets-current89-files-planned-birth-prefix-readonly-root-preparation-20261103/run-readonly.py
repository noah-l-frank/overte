"""Read-only admitted native-original prefix and planned-but-born conflict.

Historical selected construction; original Files4/Picker2 admission stays refused;
no full end eligibility, live runtime, native clock, SDK/input/recovery/query.
The partial WAL states stay literal, including pending uncompleted ownership.
"""
from pathlib import Path
from contextlib import ExitStack
import signal,cProfile,hashlib,importlib.machinery,json,os,pstats,stat,sys,threading,time,traceback,shutil
from run_metadata import HERE,REPO,pin,proc,publication,save,sources,registry_original,validate_frozen
assert len(sys.argv)==2 and sys.argv[1]=='picker89'
kind=sys.argv[1];plan=dict(validate_frozen(),activeSelection=kind);publication();selected=plan['diagnosticInputsByKind'][kind]
runroot=Path(os.environ['OVERTE_ASSETS_CANONICAL_RUN_ROOT']).resolve(strict=True)
assert runroot.is_relative_to(HERE/'runs'/kind) and stat.S_IMODE(runroot.stat().st_mode)==0o700
assert Path.cwd()==REPO and os.environ.get('PYTHONDONTWRITEBYTECODE')=='1' and sys.dont_write_bytecode
ready=HERE/(kind+'-publication-ready-source-map.json');approved=json.loads(ready.read_text());ready_pin=pin(ready)
assert approved['status']=='ACTUAL_AFTER_EXACT_PUBLICATION_READONLY_METADATA'
source_before=sources(plan);assert source_before==approved['sourcePins'] and registry_original()==approved['registry']
save(runroot/'runner-process-binding.json',proc(os.getpid()))
threads_before=set(threading.enumerate());self_proc=proc(os.getpid())
def group():
    result=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        row=proc(int(p.name))
        if row is not None and (row['session']==self_proc['session'] or row['processGroup']==self_proc['processGroup']):result.append(row)
    return result
baseline={(row['pid'],row['startTicks']) for row in group()}
def remaining():return [row for row in group() if (row['pid'],row['startTicks']) not in baseline]
config=json.loads((HERE/'source-root-final-map.json').read_text())
expected=[str(REPO/name) for name in config['orderedRoots']]
sys.path[:]=expected+[p for p in sys.path if not Path(p or os.getcwd()).resolve().is_relative_to(REPO)]
def spec(name):
    search=sys.path;found=None
    for i in range(len(name.split('.'))):
        found=importlib.machinery.PathFinder._get_spec('.'.join(name.split('.')[:i+1]),list(search))
        assert found is not None,name;search=found.submodule_search_locations
    return found
for name,relative in config['packageRoots'].items():assert [str(Path(x).resolve()) for x in spec(name).submodule_search_locations or ()]==[str(REPO/relative)],name
for name,row in config['modules'].items():
    path=Path(spec(name).origin).resolve(strict=True)
    assert path==REPO/row['path'] and pin(path)==source_before[row['path']],name
wal=REPO/selected['archiveWAL'];lockpaths={role:REPO/row['existingLock'] for role,row in selected['roles'].items()}
all_lockpaths={REPO/path for path in selected['allExistingLockPaths']};episode_wal=REPO/selected['episodeWAL']
assert len(all_lockpaths)==6 and set(lockpaths.values())<=all_lockpaths
assert pin(episode_wal)['sha256']==selected['episodeWALSha256']
inputs={str(p):pin(p) for p in (wal,episode_wal,*sorted(all_lockpaths))}
assert inputs[str(wal)]['sha256']==selected['archiveWALSha256']
raw=json.loads(wal.read_text())
assert raw['context']==selected['context'] and raw['context']['roles']==selected['selectedRoleMap']
provenance=REPO/selected['rootProducerReceipt'];provenance_pin=pin(provenance)
root_receipt=json.loads(provenance.read_text())
for role,info in selected['roles'].items():
    expected_root=REPO/info['directory'];root=expected_root.lstat()
    receipt=root_receipt[info['producerIndex']]
    assert receipt['root']==str(expected_root) and receipt['producer']=='genuineTemporaryDirectory'
    assert (root.st_dev,root.st_ino)==(receipt['device'],receipt['inode'])
    assert raw['context']['roles'][role]['stateRoot']==raw['context']['roles'][role]['artifactRoot']==str(expected_root)
    assert raw['context']['roles'][role]['target']==role and lockpaths[role]==expected_root/'script-feature-sources.lock'
    assert stat.S_IMODE(root.st_mode)==0o700

# Install all denials BEFORE any target import. Only pinned metadata rg and
# opening the exact already-existing lock inode can escape the output folder.
metadata_command=['rg','--files','-0',*plan['broadSourceRoots']]
rg_executable=Path(shutil.which('rg')).resolve(strict=True);rg_original_pin=pin(rg_executable)
metadata_subprocesses=[];forbidden=[];sdk_attempts=[]
sdk_bad=('pymobiledevice3','tidevice','pyidevice','zeroconf')
def sdk_path(path):
    if not isinstance(path,(str,bytes,os.PathLike)):return False
    return any(part in ('overte-ios-remotexpc',*sdk_bad) or any(part.startswith(bad+'_') for bad in sdk_bad)
        for part in Path(os.fsdecode(path)).parts)
def check_sdk():
    bad=[]
    for name,module in tuple(sys.modules.items()):
        if any(part in sdk_bad for part in name.split('.')) or sdk_path(getattr(module,'__file__',None)):bad.append(name)
    assert not bad,'Forbidden SDK source/name already imported'
    return bad
sdk_before=check_sdk()
def audit(event,args):
    if event=='import' and (any(part in sdk_bad for part in args[0].split('.')) or sdk_path(args[1])):
        sdk_attempts.append(args[0]);raise RuntimeError('Readonly diagnostic refused SDK import')
    if event=='open':
        path,mode,flags=args
        # This repository-owned receiver is pinned source text, not an SDK
        # import. Only its exact canonical READ path is admitted to metadata.
        receiver=REPO/'tests/device/ios/pymobiledevice3_wda_xctest.py'
        source_only_receiver=(isinstance(path,(str,bytes,os.PathLike)) and Path(os.fsdecode(path))==receiver
            and receiver.resolve(strict=True)==receiver
            and not flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
        if sdk_path(path) and not source_only_receiver:
            sdk_attempts.append('source-open');raise RuntimeError('Readonly diagnostic refused SDK source')
        if isinstance(path,(str,bytes,os.PathLike)):
            actual=Path(os.fsdecode(path)).resolve()
            writing=bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND))
            allowed_lock=actual in all_lockpaths and bool(flags&os.O_RDWR) and not flags&(os.O_CREAT|os.O_TRUNC|os.O_APPEND)
            if writing and not actual.is_relative_to(runroot) and not allowed_lock:
                forbidden.append(event);raise RuntimeError('Readonly diagnostic refused write')
    if event=='subprocess.Popen':
        executable,argv,cwd,environment=args
        allowed=executable=='rg' and type(argv) is list and argv==metadata_command and Path(cwd)==REPO and environment is None
        if allowed:
            assert Path(shutil.which('rg')).resolve(strict=True)==rg_executable and pin(rg_executable)==rg_original_pin
            metadata_subprocesses.append(dict(command=list(argv),cwd=str(cwd)));return
        forbidden.append(event);raise RuntimeError('Readonly diagnostic refused nonmetadata subprocess')
    if event in ('os.system','os.exec','os.posix_spawn','socket.__new__','socket.connect','socket.bind','os.remove','os.rename','os.rmdir','os.mkdir','os.chmod','os.truncate'):
        forbidden.append(event);raise RuntimeError('Readonly diagnostic refused external effect')
sys.addaudithook(audit)

profiler=cProfile.Profile();stages=[];primary_error=None;start=time.monotonic();reports=None
interrupts=[]
def original_timeout(signum,frame):
    # Exact interrupted MAIN call stack locations only; no locals, values or
    # original edits. Profiling finalization writes only this owned run folder.
    rows=[]
    while frame is not None and len(rows)<96:
        rows.append(dict(file=frame.f_code.co_filename,function=frame.f_code.co_name,line=frame.f_lineno))
        frame=frame.f_back
    interrupts.append(dict(signal=signum,actualInterruptedFrames=rows))
    raise TimeoutError('Owned readonly diagnostic reached its fixed outer deadline')
previous_timeout=signal.signal(signal.SIGTERM,original_timeout)
def measure(label,call):
    row=dict(stage=label,entered=True,returned=False);stages.append(row);save(runroot/'actual-stages.json',stages)
    before=time.monotonic();profiler.enable()
    try:
        value=call();row['returned']=True;return value
    finally:
        profiler.disable();row['seconds']=time.monotonic()-before;save(runroot/'actual-stages.json',stages)
try:
    from adapters.normal_feature_state import PrivateFeatureState
    from adapters.original_file_reads import collect
    from adapters.script_feature.lock import ScriptSourceLock
    from ios.adapters.emote_rooted_end_lock import held_existing
    from ios.adapters.assets_end_selection import construct
    from ios.adapters.assets_end_metadata import RecordingAssetsMetadata
    locks={role:ScriptSourceLock(path) for role,path in lockpaths.items()}
    with ExitStack() as held:
        for role in ('actor','primary'):held.enter_context(held_existing(locks[role]))
        archived=measure('actual-historical-selected-pair-open',lambda:construct(PrivateFeatureState(wal),selected['context'],locks,
            [PrivateFeatureState(Path(path)) for path in raw['paths']]))
        archived.selected_guard()
        from ios.adapters.assets_episodes import AssetsEpisodes
        from ios.adapters.assets_page_ownership import AssetsPageInventoryContext,inspect_page
        episodes=measure('actual-existing-episode-original-authority',lambda:AssetsEpisodes(archived,locks))
        assert [row['index'] for row in episodes.state['entries']]==selected['readyEpisodeIndices']
        scopes=tuple(episodes.scope(index) for index in selected['readyEpisodeIndices'])
        actual_extra={scope.locks[role].path for scope in scopes for role in ('primary','actor')}
        assert actual_extra==all_lockpaths-set(lockpaths.values())
        for scope in scopes:
            for role in ('actor','primary'):held.enter_context(held_existing(scope.locks[role]))
        from copy import deepcopy
        from types import SimpleNamespace
        from adapters.original_frame_store import OriginalFrameStore
        from adapters.script_feature.history import same
        from adapters.native_feature_observation import need
        from ios.adapters.assets_end_metadata import store as metadata_store,entries as metadata_entries,coverage
        from adapters.original_file_reads import scope as original_scope
        from ios.adapters.assets_page_clients import PageLeaseUpload,PageLeaseTree
        from ios.adapters.assets_reply_owner import OwnedAssetsReplyReads
        from ios.adapters.assets_reply_sources import ReplySources
        from ios.adapters.assets_session_owners import REPLY_SOURCE,REPLY_MIGRATION,FRAME
        from ios.adapters.assets_model_sources import AssetsModelSources
        def forbidden_port(*_args,**_kwargs):raise RuntimeError('Readonly current decoder has no native/SDK/query/input/recovery port')
        view=RecordingAssetsMetadata(owned=archived.owned_paths(),selection=archived)
        header=measure('actual-current-header-read',lambda:metadata_store(REPO/selected['currentHeader'],view).read())
        assert type(header) is dict
        # Deliberately do not call inspect_page or reconstruct Files4/Picker2:
        # their unchanged admission guard refuses this planned-but-born file.
        from adapters.native_feature_observation import exact,integer,decode
        from adapters.normal_ui import NativeUIError
        from adapters.script_feature.history import unpack,canonical
        from ios.adapters.assets_selected_profile import EpisodeAssetsFiles
        from ios.adapters.assets_file_sources import FileSources
        from ios.adapters.assets_files import validate as validate_native_files
        from adapters.original_file_reads import scope as original_scope
        scope=scopes[selected['currentEpisode']-1];role='primary';run=episodes.run
        root=Path(scope.descriptor['directories'][role]['stateRoot']['path']);binding=episodes.context['roles'][role]['binding']
        file_path=root/('ios-assets-'+run+'-primary-files.json');file_header=metadata_store(file_path,view).read()
        exact(file_header,{'iosAssetsFileOwnerVersion','runId','fixtureUrl','binding','role','payload','selectedPair','episode'})
        assert type(file_header['iosAssetsFileOwnerVersion']) is int and file_header['iosAssetsFileOwnerVersion']==4
        assert file_header['runId']==run and file_header['fixtureUrl']==episodes.context['fixtureUrl'] and same(file_header['binding'],binding) and file_header['role']==role
        assert same(file_header['selectedPair'],archived.link()) and same(file_header['episode'],scope.link())
        rows=unpack(file_header['payload']);assert len(rows)==1;stored=rows[0]
        exact(stored,{'phase','token','ticket','resource','inputManifest','directory','sources'})
        assert stored['phase']=='staged' and stored['ticket']==scope.descriptor['ticket'] and stored['resource']==scope.descriptor['resource']
        manifest=stored['sources'];exact(manifest,{'refs','pending','migration'})
        assert manifest['migration'] is None and len(manifest['refs'])==27
        pending=manifest['pending'];exact(pending,{'queryId','querySha256','rawSha256','rawBytes','original','snapshot'})
        ref=pending['original'];assert ref['phase']=='planned' and ref['file'] is None and ref['index']==28 and pending['snapshot'] is None
        def metadata_guard():
            scope.guard();scope.locks[role].assert_held();archived.selected_guard();return True
        files=object.__new__(EpisodeAssetsFiles);files.selection,files.selection_read_only,files.episode=archived,True,scope
        files.native=SimpleNamespace(pid=int(binding['processIdentity']),monotonic=time.monotonic)
        files.run,files.url,files.binding,files.role,files.lock=run,episodes.context['fixtureUrl'],deepcopy(binding),role,scope.locks[role]
        files.store=metadata_store(file_path,view);files.previous=deepcopy(file_header);files.state=None
        def forbidden_port(*_args,**_kwargs):raise RuntimeError('Read-only prefix diagnostic has no mutation/native/query port')
        files.sources=FileSources(files,role,metadata_guard,forbidden_port);files.sources.store.original(ref)
        conflict=files.sources.store.path(ref);entries_before={str(path):pin(path) for path in metadata_entries(root,view)}
        # This inode is physically present but the WAL never recorded its birth
        # identity. Inspect it independently; never adopt it into OriginalFrame.
        conflict_pin=pin(conflict);assert conflict_pin['st_size']==0 and conflict_pin['st_nlink']==1
        assert conflict_pin['st_uid']==os.geteuid() and stat.S_IMODE(conflict_pin['st_mode'])==0o600
        fd=os.open(conflict,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC)
        try:
            inode_before=os.fstat(fd);assert all(getattr(inode_before,key)==conflict_pin[key] for key in conflict_pin if key!='sha256')
            conflict_raw=os.read(fd,1);assert conflict_raw==b''
            assert all(getattr(os.fstat(fd),key)==conflict_pin[key] for key in conflict_pin if key!='sha256')
        finally:os.close(fd)
        assert pin(conflict)==conflict_pin
        def literal_refusal():
            try:files.sources.load(manifest)
            except NativeUIError as error:
                locations=[];tb=error.__traceback__
                while tb is not None:
                    locations.append(dict(file=tb.tb_frame.f_code.co_filename,function=tb.tb_frame.f_code.co_name,line=tb.tb_lineno));tb=tb.tb_next
                assert [row['function'] for row in locations]==['literal_refusal','load','inspect','need']
                assert Path(locations[-2]['file'])==REPO/'tests/device/ios/adapters/assets_file_sources.py'
                return dict(type=type(error).__name__,actualRefusalLocations=locations)
            raise AssertionError('Literal planned-but-born guard unexpectedly admitted the owner')
        refusal=measure('actual-literal-FileSources-load-retains-planned-born-refusal',literal_refusal)
        assert same(files.sources.refs,manifest['refs']) and same(files.sources.pending,pending)
        prefix=[]
        def admitted_prefix():
            previous=None
            for index,reference in enumerate(manifest['refs'],1):
                full=files.sources.store.expand(reference);assert full['index']==index
                record=files.sources.read_record(reference);assert record['kind']=='native'
                packet=decode(record['raw']);validate_native_files(packet,record['query'],files.native.pid,previous=previous);previous=packet
                assert record['query']['runId']==run and record['query']['ticket']==stored['ticket'] and record['query']['ownerToken']==stored['token'] and record['query']['resource']==stored['resource']
                prefix.append(dict(index=index,path=str(files.sources.store.path(full)),queryId=record['query']['commandId'],operation=record['query']['operation']))
            return prefix
        with original_scope(fresh=True) as reads:
            measure('actual-admitted27-native-original-prefix-only',admitted_prefix)
            expected={files.sources.store.path(files.sources.store.expand(reference)) for reference in manifest['refs']}
            assert reads==expected
        assert conflict not in reads and not any(row['index']==28 for row in prefix)
        assert {str(path):pin(path) for path in metadata_entries(root,view)}==entries_before
        view.guard();metadata_guard();assert same(metadata_store(file_path,view).read(),file_header)
        assert same(metadata_store(REPO/selected['currentHeader'],view).read(),header)
        save(runroot/'actual-original-read-membership.json',sorted(str(path) for path in reads))
        save(runroot/'actual-planned-born-conflict.json',dict(status='ACTUAL_READONLY_UNADMITTED_BORN_FILE_CONFLICT',
            originalManifest=manifest,ownerHeaderPath=str(file_path),conflictingPath=str(conflict),physicalIdentityObservedOnly=conflict_pin,
            admittedPrefix=prefix,literalRefusal=refusal,pendingSnapshotPresent=False,birthIdentityRecorded=False,
            originalAccepted=False,nativeFactsFromPending=False,pickerDecoderReached=False,filesOwnerDecoded=False,
            knownAdmittedOriginalCount=27,pendingOriginalIndex=28,wholeEndEligible=False,wholeAssetsQualified=False))
        reports=[dict(runId=run,role=role,responsibilities=['episode-input-files','episode-picker-client','shared-page-root','planned-native-file-source','unadmitted-born-file-identity'],
            ordinaryPartialScopeOnly=True,wholeDirectoryOwnershipRead=False,wholeEndEligible=False,currentNativeFactsProduced=False)]
        save(runroot/'actual-private-responsibilities.json',reports)

except BaseException as error:
    primary_error=error;text=''.join(traceback.format_exception(error));print(text,flush=True)
    save(runroot/'actual-original-error.json',dict(type=type(error).__name__,traceback=text))
finally:
    signal.signal(signal.SIGTERM,previous_timeout)
    save(runroot/'actual-timeout-interrupts.json',interrupts)
    profiler.disable();profiler.create_stats()
    if profiler.getstats():
        profiler.dump_stats(str(runroot/'actual-decoders.pstats'));stats=pstats.Stats(profiler);rows=[]
        for (file,line,name),(cc,nc,tt,ct,callers) in stats.stats.items():
            if not Path(file).is_absolute():continue
            try:path=str(Path(file).resolve().relative_to(REPO))
            except (ValueError,OSError):continue
            rows.append(dict(path=path,line=line,function=name,primitiveCalls=cc,calls=nc,selfSeconds=tt,cumulativeSeconds=ct,
                callers=[dict(path=str(Path(f).resolve().relative_to(REPO)) if Path(f).is_absolute() and Path(f).resolve().is_relative_to(REPO) else '<external>',line=l,function=n,counts=list(counts) if type(counts) is tuple else counts) for (f,l,n),counts in callers.items()]))
        save(runroot/'actual-project-calls.json',sorted(rows,key=lambda row:row['cumulativeSeconds'],reverse=True))
    before=remaining();after_inputs={str(p):pin(p) for p in (wal,episode_wal,*sorted(all_lockpaths))}
    assert inputs==after_inputs and source_before==sources(plan) and ready_pin==pin(ready) and provenance_pin==pin(provenance)
    imported={}
    for name,module in tuple(sys.modules.items()):
        filename=getattr(module,'__file__',None)
        if filename is None:continue
        path=Path(filename).resolve()
        if path.is_relative_to(REPO):
            relative=str(path.relative_to(REPO));assert relative in source_before,(name,relative);imported[name]=relative
    save(runroot/'actual-imported-local-sources.json',imported)
    after=remaining();threads=[dict(name=t.name,ident=t.ident,daemon=t.daemon) for t in threading.enumerate() if t not in threads_before and t.is_alive()]
    sdk_after=check_sdk()
    result=dict(status='ACTUAL_READONLY_DECODER_RETURNED' if primary_error is None else 'ACTUAL_READONLY_DECODER_ERROR',stages=stages,seconds=time.monotonic()-start,
        originalInputsUnchanged=inputs==after_inputs,sourcePinsUnchanged=True,forbiddenAttempts=forbidden,
        remainingOwnedBeforeCensuses=before,remainingOwnedAfterCensuses=after,remainingNewThreads=threads,
        sdkNameAndSourceAuditBeforeImports=True,sdkModulesBefore=sdk_before,sdkModulesAfter=sdk_after,sdkAttempts=sdk_attempts,
        metadataSubprocesses=metadata_subprocesses,rgBinaryUnchanged=pin(rg_executable)==rg_original_pin,
        nativeCompiled=False,sdkExecuted=False,wholeAssetsQualified=False,deviceQualified=False,
        interruptedStackObserved=bool(interrupts),performanceQualification=False,ordinaryPartialScopeOnly=True,wholeDirectoryOwnershipRead=False,wholeEndEligible=False,partialOwnershipKept=reports is not None and any(row['responsibilities'] for row in reports))
    save(runroot/'profile-result.json',result);print('ACTUAL_DIAGNOSTIC',json.dumps(result),flush=True)
    assert not forbidden and not before and not after and not threads and not sdk_attempts
if primary_error is not None:raise primary_error.with_traceback(primary_error.__traceback__)
