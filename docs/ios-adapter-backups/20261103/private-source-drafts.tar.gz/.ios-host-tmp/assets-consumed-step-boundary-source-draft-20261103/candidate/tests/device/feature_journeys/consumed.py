"""Explicit optional Assets post-consumer recording seam, independent v1.

A recorded receipt is host custody only, never an observed product result.
No old adapter/proxy method is discovered or invoked without the advertised
exact capability and an explicitly supplied existing session invoke port.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from .contract import exact,identifier
from .scenarios import SCENARIOS

VERSION=1
PROFILE='post-consumer-step-v1'


def arguments(area,value):
    if area!='assets':raise ValueError('Post-consumer recording is not admitted for this feature')
    exact(value,{'contractVersion','runId','stepIndex','ticket'},'post-consumer input')
    if type(value['contractVersion']) is not int or value['contractVersion']!=VERSION:raise ValueError('Unsupported post-consumer contract version')
    identifier(value['runId']);identifier(value['ticket'])
    if type(value['stepIndex']) is not int or not 1<=value['stepIndex']<=len(SCENARIOS[area]['steps']):raise ValueError('Unknown consumed input step')
    return value


def result(area,value):
    if area!='assets':raise ValueError('Post-consumer recording is not admitted for this feature')
    exact(value,{'recorded'},'post-consumer receipt')
    if value['recorded'] is not True:raise ValueError('Post-consumer recording was not confirmed')
    return value


class BoundStepConsumer:
    def __init__(self,area,invoke):
        if area!='assets' or not callable(invoke):raise ValueError('Explicit existing Assets session invoke port is required')
        self.area,self.invoke,self.operation=area,invoke,'feature.assets.consumed'
    def __call__(self,value):
        arguments(self.area,value);return result(self.area,self.invoke(self.operation,value))


def bind(area,capabilities,invoke):
    # A concrete no-op default: do not inspect a dynamic adapter/proxy for a
    # synthesized method, profile property, support flag or remote operation.
    if area!='assets' or 'feature.assets.consumed' not in capabilities:return None
    return BoundStepConsumer(area,invoke)
