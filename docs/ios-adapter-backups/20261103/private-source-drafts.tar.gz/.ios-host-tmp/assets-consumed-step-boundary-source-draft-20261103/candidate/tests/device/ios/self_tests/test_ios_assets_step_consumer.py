"""Existing Actions/originals plus actual independent phase Journal custody.

No native/SDK input or product evidence is generated. The common-engine model
separately covers ordering after actual host target/peer/image/file consumers.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from unittest.mock import patch
import unittest
from adapters.normal_ui import NativeUIError
from ios.adapters.assets_action_phase import AssetsActionPhases
from ios.adapters.assets_step_consumer import AssetsStepConsumer
from ios.self_tests.test_ios_assets_action_phase import AssetsActionPhaseTests
from ios.self_tests.assets_picker_fixture import RUN


class AssetsStepConsumerTests(unittest.TestCase):
    def setUp(self):
        self.a=AssetsActionPhaseTests();self.a.setUp();self.addCleanup(self.a.doCleanups)
        self.ticket,row=self.a.activate(1);self.scope=self.a.owner.begin(1,self.ticket,row['verb'],row['inputs'])
        self.event=dict(contractVersion=1,runId=RUN,stepIndex=1,ticket=self.ticket);self.consumer=AssetsStepConsumer(self.a.owner)
    def reopen(self):
        owner=AssetsActionPhases(self.a.h.archive(),self.a.store,self.a.h.locks,self.a.phase);return owner,AssetsStepConsumer(owner)
    def files(self):return {str(p):(p.stat().st_ino,p.read_bytes()) for root in self.a.h.roots.values() for p in root.rglob('*') if p.is_file()}
    def test_actual_original_completion_and_same_current_ticket_replay_are_idempotent(self):
        self.assertEqual(dict(recorded=True),self.consumer(self.event));owner=self.a.owner
        self.assertEqual(1,len(owner.state['records']));self.assertIsNone(owner.state['pending']);self.assertEqual(self.ticket,owner.read(1)['ticket'])
        files=self.files();refs=deepcopy(owner.state['records']);self.assertEqual(dict(recorded=True),self.consumer(deepcopy(self.event)))
        self.assertEqual(files,self.files());self.assertEqual(refs,owner.state['records']);self.assertEqual([],self.a.h.native_calls)
    def test_actual_next_activation_refuses_old_ack_without_completing_or_rewriting_history(self):
        self.consumer(self.event);self.a.activate(2);before=self.files()
        with self.assertRaises(NativeUIError):self.consumer(self.event)
        self.assertEqual(before,self.files());self.assertEqual(self.ticket,self.a.owner.ticket_for(1));self.assertEqual([],self.a.h.native_calls)
    def test_original_storage_failure_never_completes_action_or_adopts_a_partial_original(self):
        failure=OSError('Declared action evidence store failure')
        with patch.object(self.a.owner.originals,'write',side_effect=failure):
            with self.assertRaises(OSError) as actual:self.consumer(self.event)
        self.assertIs(failure,actual.exception);self.assertEqual([],self.a.owner.state['records']);self.assertIsNotNone(self.a.owner.state['pending']['after'])
        self.assertIsNone(self.a.owner.state['pending']['original'])
        owner,consumer=self.reopen();before=self.files()
        with self.assertRaises(NativeUIError):consumer(self.event)
        self.assertEqual(before,self.files());self.assertEqual([],owner.state['records']);self.assertEqual([],self.a.h.native_calls)
    def test_actual_saved_original_after_lost_parent_CAS_recovers_only_same_current_phase(self):
        owner=self.a.owner;save=owner.save;failure=OSError('Declared final parent commit failure')
        def lost():
            if owner.state['pending'] is None:raise failure
            return save()
        with patch.object(owner,'save',side_effect=lost):
            with self.assertRaises(OSError) as actual:self.consumer(self.event)
        self.assertIs(failure,actual.exception);restored,consumer=self.reopen();self.assertEqual([],restored.state['records'])
        original=deepcopy(restored.state['pending']['original']);self.assertEqual('saved',original['phase'])
        with patch.object(restored.originals,'write',side_effect=AssertionError('Saved original must not be written twice')):
            self.assertEqual(dict(recorded=True),consumer(self.event))
        self.assertEqual(restored.originals.compact(original),restored.state['records'][0]);self.assertEqual([],self.a.h.native_calls)
    def test_next_activation_between_original_save_and_final_commit_retains_owned_saved_prefix(self):
        owner=self.a.owner;write=owner.originals.write
        def advance_after_save(*args,**kwargs):
            ref=write(*args,**kwargs);self.a.activate(2);return ref
        with patch.object(owner.originals,'write',side_effect=advance_after_save):
            with self.assertRaises(NativeUIError):self.consumer(self.event)
        self.assertEqual([],owner.state['records']);self.assertEqual('saved',owner.state['pending']['original']['phase'])
        restored,consumer=self.reopen();before=self.files()
        with self.assertRaises(NativeUIError):consumer(self.event)
        self.assertEqual(before,self.files());self.assertEqual([],restored.state['records']);self.assertEqual([],self.a.h.native_calls)
    def test_foreign_run_step_ticket_and_samebytes_foreign_original_inode_do_not_gain_current_authority(self):
        before=self.files()
        for event in (dict(self.event,runId='f'*32),dict(self.event,stepIndex=2),dict(self.event,ticket='e'*32)):
            with self.subTest(event=event),self.assertRaises(NativeUIError):self.consumer(event)
        self.assertEqual(before,self.files());self.consumer(self.event);owner=self.a.owner
        ref=owner.originals.expand(owner.state['records'][0]);path=owner.originals.path(ref);raw=path.read_bytes()
        path.rename(path.with_name('retained-before-foreign-consumption-inode'));path.write_bytes(raw);path.chmod(0o600)
        with self.assertRaises(NativeUIError):self.consumer(self.event)
        self.assertEqual([],self.a.h.native_calls)


if __name__=='__main__':unittest.main()
