"""Actual common-engine consumers over the existing independent host reducer.

No target state is supplied by these callbacks. Original image/file bytes and
independent witness reductions go through the unchanged Journey.wait consumers.
This is host-only ordering/compatibility coverage, not adapter/device evidence.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
import unittest
from feature_journeys.consumed import bind,arguments,result
from feature_journeys.contract import arguments as operation_arguments,result as operation_result
from feature_journeys.engine import Journey
from feature_journeys.scenarios import SCENARIOS
from self_tests.test_feature_journeys import Boundary,RUN,TICKET,POLICY


class FeatureConsumedStepTests(unittest.TestCase):
    def journey(self,boundary,consumer,*,reader=None,observer=None):
        if observer is not None:boundary.observe=observer
        return Journey('assets',RUN,'http://controlled.test/feature-fixture/v1/runs/'+RUN+'/',
            invoke=boundary.invoke,witness=boundary.witness,activate=boundary.activate,
            read_artifact=reader or boundary.files.__getitem__,image_policy=POLICY,continuity=boundary.continuity,
            monotonic=lambda:boundary.clock,epoch_ms=boundary.epoch,sleep=boundary.sleep,
            report=boundary.reports.append,step_consumed=consumer)
    def test_actual_all29_consumers_finish_before_completion_and_next_activation(self):
        b=Boundary('assets');events=[];reads=[];j=None
        def read(name):reads.append((b.ticket,name));return b.files[name]
        def consumed(event):
            arguments('assets',event);self.assertEqual(b.ticket,event['ticket'])
            self.assertEqual(f"{event['stepIndex']:02d}-"+b.verb,j.phases[-1]['phase'])
            self.assertEqual(event['ticket'],j.samples[-1]['ticket']);self.assertTrue(j.samples[-1]['witness'])
            self.assertEqual({'contractVersion','runId','stepIndex','ticket'},set(event))
            if 'image' in SCENARIOS['assets']['steps'][event['stepIndex']-1]['evidence']:
                self.assertTrue(any(ticket==event['ticket'] for ticket,_name in reads))
            events.append(deepcopy(event));return dict(recorded=True)
        activate=b.activate
        def next_activation(ticket,verb='baseline',inputs=None):
            if verb not in ('baseline','cleanup'):self.assertEqual(sum(operation=='feature.assets.act' for operation,_fields in b.actions),len(events))
            return activate(ticket,verb,inputs)
        b.activate=next_activation;j=self.journey(b,consumed,reader=read);j.execute()
        self.assertEqual(list(range(1,30)),[row['stepIndex'] for row in events]);self.assertEqual(29,len({row['ticket'] for row in events}))
        self.assertTrue(b.reports[0]['sequenceCompleted']);self.assertEqual('cleanup',b.verb)
    def test_actual_original_image_read_failure_does_not_complete_failed_step(self):
        b=Boundary('assets');events=[];failure=OSError('Declared original image storage failure')
        def read(name):
            if b.verb=='browse':raise failure
            return b.files[name]
        def consumed(event):events.append(event['stepIndex']);return dict(recorded=True)
        with self.assertRaises(OSError) as actual:self.journey(b,consumed,reader=read).execute()
        self.assertIs(failure,actual.exception);self.assertEqual([1,2,3,4],events)
        self.assertFalse(b.reports[0]['sequenceCompleted']);self.assertTrue(b.reports[0]['cleanupSucceeded'])
        self.assertFalse(any(fields.get('verb')=='rename-folder' for _operation,fields in b.actions))
    def test_actual_observer_failure_does_not_complete_or_activate_next_step(self):
        b=Boundary('assets');events=[];observe=b.observe;failure=OSError('Declared observer lost delivery')
        def observer(fields):
            if b.verb=='browse':raise failure
            return observe(fields)
        def consumed(event):events.append(event['stepIndex']);return dict(recorded=True)
        with self.assertRaises(OSError) as actual:self.journey(b,consumed,observer=observer).execute()
        self.assertIs(failure,actual.exception);self.assertEqual([1,2,3,4],events)
        self.assertFalse(b.reports[0]['sequenceCompleted']);self.assertTrue(b.reports[0]['cleanupSucceeded'])
    def test_completion_storage_failure_after_consumers_prevents_next_activation(self):
        b=Boundary('assets');events=[];failure=OSError('Declared completion journal commit failure');j=None
        def consumed(event):
            self.assertEqual(event['ticket'],j.samples[-1]['ticket'])
            if event['stepIndex']==5:raise failure
            events.append(event['stepIndex']);return dict(recorded=True)
        j=self.journey(b,consumed)
        with self.assertRaises(OSError) as actual:j.execute()
        self.assertIs(failure,actual.exception);self.assertEqual([1,2,3,4],events)
        self.assertTrue(any(row['phase']=='05-browse' for row in j.phases));self.assertFalse(any(row['phase'].startswith('06-') for row in j.phases))
        self.assertFalse(b.reports[0]['sequenceCompleted']);self.assertTrue(b.reports[0]['cleanupSucceeded'])
    def test_malformed_completion_receipt_is_not_a_success_or_next_input_authority(self):
        b=Boundary('assets');events=[]
        def consumed(event):events.append(event['stepIndex']);return dict(recorded=True,passed=True)
        with self.assertRaises(ValueError):self.journey(b,consumed).execute()
        self.assertEqual([1],events);self.assertFalse(b.reports[0]['sequenceCompleted']);self.assertTrue(b.reports[0]['cleanupSucceeded'])
    def test_default_actual_assets_journey_keeps_literal_operations_without_opt_in(self):
        b=Boundary('assets');invoke=b.invoke;operations=[]
        def observe_operation(operation,fields):operations.append(operation);return invoke(operation,fields)
        b.invoke=observe_operation;b.execute()
        self.assertTrue(b.reports[0]['sequenceCompleted']);self.assertNotIn('feature.assets.consumed',operations)
        self.assertEqual({'feature.assets.act','feature.assets.observe','feature.assets.cleanup'},set(operations))
    def test_no_capability_or_foreign_area_never_probes_dynamic_proxy(self):
        class DynamicProxy:
            def __getattr__(self,name):raise AssertionError('Default must not discover a dynamic remote operation')
            def __call__(self,*args):raise AssertionError('Default must not invoke a remote operation')
        proxy=DynamicProxy();self.assertIsNone(bind('assets',[],proxy));self.assertIsNone(bind('create',['feature.assets.consumed'],proxy))
        calls=[]
        def invoke(operation,value):calls.append((operation,deepcopy(value)));return dict(recorded=True)
        request=dict(contractVersion=1,runId=RUN,stepIndex=5,ticket=TICKET)
        self.assertEqual(dict(recorded=True),bind('assets',['feature.assets.consumed'],invoke)(request));self.assertEqual([('feature.assets.consumed',request)],calls)
    def test_independent_versioned_contract_refuses_state_verdict_foreign_area_and_boolean_index(self):
        request=dict(contractVersion=1,runId=RUN,stepIndex=1,ticket=TICKET)
        self.assertEqual(request,operation_arguments('feature.assets.consumed',request));self.assertEqual(dict(recorded=True),operation_result('feature.assets.consumed',dict(recorded=True)))
        for invalid in (dict(request,state={}),dict(request,passed=True),dict(request,stepIndex=True),dict(request,stepIndex=30),dict(request,contractVersion=16)):
            with self.subTest(invalid=invalid),self.assertRaises(ValueError):arguments('assets',invalid)
        with self.assertRaises(ValueError):arguments('create',request)
        with self.assertRaises(ValueError):result('assets',dict(recorded=1))


if __name__=='__main__':unittest.main()
