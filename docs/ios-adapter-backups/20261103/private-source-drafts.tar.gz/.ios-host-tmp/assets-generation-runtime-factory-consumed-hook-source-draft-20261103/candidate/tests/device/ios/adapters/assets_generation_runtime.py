"""Explicit generation Tree/Usage factories on the current canonical SDK.

Original upload/page/file ownership stays in its real episode. Per-action
Reply4 originals and View slots retain every earlier proof independently.
This module provides no shared29 entry point, capability or final-end gate.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from adapters.native_feature_observation import integer,need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.script_feature.history import same,unpack
from ios.adapters.assets_action_runtime import AssetsActionRuntime
from ios.adapters.assets_selected_runtime import SelectedAssetsRuntime
from ios.adapters.assets_episode_model_graph import AssetsEpisodeModelGraph
from ios.adapters.assets_generation_clients import GenerationAssetsTree,GenerationAssetsUsage
from ios.adapters.assets_generation_baked_tree import GenerationAssetsBakedTree
from ios.adapters.assets_parsed_owner import OwnedAssetsParsedInput
from ios.adapters.assets_generation_replies import GenerationActionReplyReads
from ios.adapters.assets_generation_view import AssetsGenerationView
from ios.adapters.assets_page_reentry import AssetsPageReentry
from ios.adapters.assets_budget import operation


class GenerationActionAssetsRuntime(AssetsActionRuntime,SelectedAssetsRuntime):
    def __init__(self,*args,generation,origin_graph,**kwargs):
        need(type(generation) is AssetsPageReentry and type(origin_graph) is AssetsEpisodeModelGraph
            and origin_graph.dependency_mode and origin_graph.metadata is None and origin_graph.active)
        self.assets_generation,self.assets_origin_graph=generation,origin_graph
        super().__init__(*args,**kwargs)
        episode=self.assets_episode;action=self.assets_action
        need(episode is origin_graph.episode and episode.owner.selected is self.assets_selection
            and generation.selected is self.assets_selection and action.owner.selected is self.assets_selection
            and (generation.generation,episode.index) in ((2,2),(3,3),(4,4))
            and generation.action_index<=action.index<={2:13,3:17,4:23}[generation.generation])
        need(action.index==generation.action_index or generation.historical)
        if generation.generation==4:
            need(isinstance(origin_graph.parsed,OwnedAssetsParsedInput) and origin_graph.parsed.model.usage.source is origin_graph.upload)
        origin_graph.guard();generation.guard();action.guard()

    def _assets_components(self,*_args,**_kwargs):
        # Generic factories would reconstruct the historical Upload using
        # current native ports, and silently alias its earlier Reply owner.
        raise RuntimeError('Use the explicit generation component factory')

    def _generation_store(self,kind,*,action_index=None):
        need(kind in ('replies','view','tree','usage'))
        root=Path(self.assets_episode.descriptor['directories']['primary']['stateRoot']['path'])
        prefix='ios-assets-'+self.assets_selection.run+'-primary-gen'+str(self.assets_generation.generation)
        if kind=='replies':
            need(integer(action_index,self.assets_generation.action_index,self.assets_action.index))
            prefix+='-action'+str(action_index)
        else:need(action_index is None)
        return PrivateFeatureState(root/(prefix+'-'+kind+'.json'))

    @operation
    def generation_components(self,selector,run,role,fixture_url,lock):
        episode,action,generation,graph=self.assets_episode,self.assets_action,self.assets_generation,self.assets_origin_graph
        need(role=='primary' and episode.role(selector)==role and run==self.assets_selection.run
            and fixture_url==episode.owner.context['fixtureUrl'] and lock is episode.locks['primary'])
        graph.guard();generation.guard();action.guard()
        need(graph.upload is not None and graph.files.state['phase']=='retired'
            and graph.upload.state['phase']=='uploaded' and graph.replies.state['phase']=='closed')
        parts=self._assets_sources(selector,lock);parts['check']()
        namespace='renamed' if generation.generation==2 else 'original'
        replies=GenerationActionReplyReads(parts['replies'],self._generation_store('replies',action_index=action.index),
            parts['binding'],run,fixture_url,lock=lock,role=role,actions=action.owner,episode=episode,action=action,
            generation=generation,action_index=action.index)
        if replies.state is None:replies.reserve(episode.descriptor['ticket'],episode.descriptor['resource'],namespace)
        need(replies.state['ticket']==episode.descriptor['ticket'] and replies.state['resource']==episode.descriptor['resource']
            and replies.state['namespace']==namespace)
        store=self._generation_store('view');value=store.read();old=[];resume=False
        if value is not None:
            # This header is selection only; the actual View decoder below
            # validates every field, original, link and exact old proof.
            rows=unpack(value['payload']);need(len(rows)==1 and type(rows[0]) is dict)
            active=rows[0].get('activeAction');need(integer(active,generation.action_index,action.index))
            need(action.index in (active,active+1));resume=action.index==active+1
            for index in range(generation.action_index,active+1):
                if index==action.index:continue
                need(generation.historical)
                old.append(GenerationActionReplyReads.from_archive(self._generation_store('replies',action_index=index),
                    generation=generation,episode=episode,actions=action.owner,action_index=index,monotonic=self.monotonic))
        else:need(action.index==generation.action_index)
        view=AssetsGenerationView(generation,episode,action.owner,action,graph.upload,replies,store,
            parts['native'],parts['clock_source'],namespace=namespace,old_tree=graph.tree if namespace=='renamed' else None,
            reply_owners=tuple(old),resume_completed_prefix=resume,monotonic=self.monotonic)
        if view.state is None:view.reserve()
        tree=(GenerationAssetsBakedTree(view,graph.parsed,self._generation_store('tree'),lock=lock)
            if generation.generation==4 else GenerationAssetsTree(view,self._generation_store('tree'),lock=lock))
        usage=GenerationAssetsUsage(view,self._generation_store('usage'),lock=lock)
        need(same(parts['binding'],graph.binding));parts['check']();graph.guard()
        return dict(parts,origin_graph=graph,owned_files=graph.files,picker=graph.picker,
            owned_replies=replies,generation_view=view,tree=tree,usage=usage)

    @operation
    def generation_browse(self,parts):
        view,tree=parts['generation_view'],parts['tree'];parts['check']();view.guard()
        if tree.state is None:tree.reserve()
        if tree.state['phase']=='reserved':tree.finish_browse() if tree.state['reads'] else tree.browse()
        need(tree.state['phase'] in ('browsed','deleting','deleted'));parts['check']();return tree.read_proof('tree-before')

    @operation
    def generation_delete(self,parts):
        need(self.assets_action.index in (13,17,23));self.generation_browse(parts)
        tree=parts['tree']
        if tree.state['phase']=='browsed':tree.delete()
        if tree.state['phase']=='deleting':tree.finish_delete()
        need(tree.state['phase']=='deleted');parts['check']();return tree.read_proof('tree-deleted')

    def generation_step_consumer(self,parts):
        from ios.adapters.assets_step_consumer import AssetsStepConsumer
        need(type(parts['generation_view']) is AssetsGenerationView and parts['generation_view'].action is self.assets_action)
        return AssetsStepConsumer(self.assets_action.owner,generation_view=parts['generation_view'])
