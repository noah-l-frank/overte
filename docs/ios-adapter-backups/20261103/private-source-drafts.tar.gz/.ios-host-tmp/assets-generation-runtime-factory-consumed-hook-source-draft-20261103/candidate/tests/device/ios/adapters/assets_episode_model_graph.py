"""Constructor-free original Model/Backend/Parsed/Removal generation inputs.

Every source is an actual private original. This explicit dependency subset
neither opens transports nor supplies current facts or whole directory coverage.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from types import SimpleNamespace
import time
from adapters.native_feature_observation import need
from adapters.original_file_reads import collect
from adapters.original_frame_store import OriginalFrameStore
from ios.adapters.assets_episode_metadata_graph import AssetsEpisodeClientGraph,forbidden
from ios.adapters.assets_end_metadata import signature
from ios.adapters.assets_backend_owner import OwnedAssetsBackend,BackendSegments
from ios.adapters.assets_baking_owner import OwnedAssetsBaking
from ios.adapters.assets_model_sources import AssetsModelSources
from ios.adapters.assets_model_raw_sources import ModelRawSources
from ios.adapters.assets_model_owner import OwnedAssetsModel
from ios.adapters.assets_parsed_sources import AssetsParsedSources,ParsedRawSources
from ios.adapters.assets_parsed_owner import OwnedAssetsParsedInput
from ios.adapters.assets_unbaked_input import OwnedAssetsUnbakedInput
from ios.adapters.assets_action_owners import ActionAssetsBaking,ActionAssetsParsed
from ios.adapters.assets_action_unbaked import ActionAssetsUnbakedInput
from ios.adapters.assets_model_removal import OwnedAssetsModelRemoval


class AssetsEpisodeModelGraph(AssetsEpisodeClientGraph):
    def decode(self):
        need(self.original_pins is None and self.dependency_mode and self.metadata is None and self.episode.index in (2,3,4)
            and self.actions is not None)
        super().decode();need(self.usage is not None)
        with collect() as reads:
            store,value=self.store('backend');need(value is not None)
            backend=object.__new__(OwnedAssetsBackend);backend.upload,backend.store,backend.previous=self.upload,store,deepcopy(value)
            backend.lock,backend.monotonic,backend.sleep=self.lock,time.monotonic,forbidden
            backend.binding,backend.run,backend.role=deepcopy(self.binding),self.run,self.role
            backend.config=deepcopy(value['backendConfiguration']);backend.client=SimpleNamespace(guard=self.guard,request=forbidden)
            backend.parts=BackendSegments(self.root,self.binding,self.run,self.role,self.role,self.guard,forbidden,monotonic=time.monotonic)
            backend.state=backend.decode(value);self.backend=backend
            self.baking=None
            if self.episode.index==4:
                store,value=self.store('baking');need(value is not None)
                version=value.get('iosAssetsBakingOwnerVersion');need(version in (1,2))
                Baking=OwnedAssetsBaking if version==1 else ActionAssetsBaking
                baking=object.__new__(Baking);baking.usage,baking.backend,baking.store,baking.previous=self.usage,backend,store,deepcopy(value)
                baking.lock,baking.monotonic,baking.state=self.lock,time.monotonic,None
                if version==2:baking.action_ticket=self.actions.read(20)['ticket']
                baking.state=baking.decode(value);self.baking=baking
            store,value=self.store('model-sources');need(value is not None)
            source=self.source(AssetsModelSources,ModelRawSources,store,value)
            store,value=self.store('model');need(value is not None)
            model=object.__new__(OwnedAssetsModel);model.usage,model.sources,model.store,model.previous=self.usage,source,store,deepcopy(value)
            model.lock,model.monotonic,model.state=self.lock,time.monotonic,None;model.state=model.decode(value);self.model=model
            store,value=self.store('parsed-sources');need(value is not None)
            parsed_source=self.source(AssetsParsedSources,ParsedRawSources,store,value,model=model)
            store,value=self.store('parsed');need(value is not None)
            unbaked=self.episode.index in (2,3)
            key='iosAssetsUnbakedInputOwnerVersion' if unbaked else 'iosAssetsParsedInputOwnerVersion'
            version=value.get(key);need(version in (1,2))
            Parsed=(OwnedAssetsUnbakedInput if version==1 else ActionAssetsUnbakedInput) if unbaked else (OwnedAssetsParsedInput if version==1 else ActionAssetsParsed)
            parsed=object.__new__(Parsed);parsed.sources,parsed.model,parsed.store,parsed.previous=parsed_source,model,store,deepcopy(value)
            parsed.lock,parsed.monotonic,parsed.state=self.lock,time.monotonic,None
            if unbaked:parsed.backend=backend
            else:parsed.baking=self.baking
            if version==2:parsed.action_ticket=self.actions.read({2:8,3:15,4:21}[self.episode.index])['ticket']
            parsed.state=parsed.decode(value);self.parsed=parsed
            store,value=self.store('model-removal');need(value is not None)
            removal=object.__new__(OwnedAssetsModelRemoval)
            removal.parsed,removal.model,removal.sources,removal.usage=parsed,model,parsed_source,self.usage
            removal.store,removal.previous,removal.lock=store,deepcopy(value),self.lock
            removal.native,removal.pid,removal.monotonic,removal.last_ui=self.ports(),int(self.binding['processIdentity']),time.monotonic,None
            removal.ui=SimpleNamespace(perform=forbidden,capture=forbidden);removal.state=None
            removal.state=removal.decode(value);self.removal=removal
            need(parsed.state['phase']=='observed' and removal.state['phase']=='model-gone'
                and removal.state['contextClosedBy'] is not None)
        self.reads.update(reads);self.original_pins={str(path):signature(path) for path in self.reads}
        need(all(pin is not None for pin in self.original_pins.values()));self.guard();return self

    def source(self,Source,Raws,store,value,*,model=None):
        owner=object.__new__(Source);owner.usage,owner.store,owner.previous=self.usage,store,deepcopy(value)
        if model is not None:owner.model=model
        owner.native,owner.lock,owner.monotonic,owner.epoch_ms=self.ports(),self.lock,time.monotonic,forbidden
        owner.binding,owner.run,owner.role=deepcopy(self.binding),self.run,self.role
        owner.state,owner._cached,owner.active=None,[],False
        owner.readers={'state':self.ports(),'work':self.ports()}
        if model is not None:owner.origin_reader=self.ports();owner.readers['origin']=owner.origin_reader
        owner.raws=Raws(owner,self.role,self.guard,forbidden)
        owner.originals=OriginalFrameStore(self.root,self.binding,self.run,self.role,self.guard,forbidden,
            namespace=Source.NAMESPACE,schema_prefix=Source.SCHEMA_PREFIX,monotonic=time.monotonic)
        owner.state=owner.decode(value);return owner
