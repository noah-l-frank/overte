"""New generation Tree/Usage duties over an explicit current view source.

The old upload/page/file/reply objects stay historical. No legacy Tree rename
is fabricated to delete an original OBJ/FBX namespace on a new page.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import need
from adapters.script_feature.history import same
from ios.adapters.assets_budget import operation
from ios.adapters.assets_controls import project
from ios.adapters.assets_picker import root
from ios.adapters.assets_tree_owner import OwnedAssetsTree
from ios.adapters.assets_usage_owner import OwnedAssetsUsage
from ios.adapters.assets_generation_view import AssetsGenerationView


class GenerationClient:
    SOURCE_TYPE=AssetsGenerationView
    EXTRA_FIELDS=frozenset({'generationView'})
    def view(self):raise NotImplementedError
    def reply_owner(self,slot,*,create=False):return self.view().reply_owner(slot,create=create)
    def extra_envelope(self):return dict(generationView=self.view().link())
    def source_clients_closed(self):return self.view().state['phase']=='view-clients-closed'
    def client_page(self,packet,state):
        view=self.view();page=root(project(packet),'page',identifier=view.state['page']);known=view.generation.page()
        need(page['visible'] and all(page[key]==known[key] for key in ('rootId','windowId','modelId','componentSource','ownerRootId')))
        return page
    def retire_unresolved(self,index):need(all(entry['resolvedBy'] is not None and entry['abandonedBy'] is None for entry in self.state['inputs']))
    def close_clients(self):
        # Cleanup can close this view's read jobs, never abandon an unresolved
        # old/new input or relabel the original upload's page as this one.
        self.retire_unresolved(0);return super().close_clients()


class GenerationAssetsTree(GenerationClient,OwnedAssetsTree):
    OWNER_VERSION=5
    RENAME_REQUIRED=False
    def __init__(self,view,store,*,lock):
        super().__init__(view,store,lock=lock)
        if self.state is not None:view.bind_client('tree',self)
    def view(self):return self.upload
    def source_ready(self):return self.upload.state['phase']=='ready' and self.upload.replies.state['phase']=='open'
    def prefix(self,renamed=False):return self.upload.prefix()
    def baseline(self,proof):
        view=self.upload;before=view.state['readback'];prefix=view.prefix()
        owned=lambda rows:[(row['path'],row['hash']) for row in rows if row['path'].startswith(prefix)]
        need(owned(proof['mappings']) and owned(proof['mappings'])==owned(before['mappings']))
    def delete_admission(self,proof):self.baseline(proof)
    def deleted_proof(self,before,after):
        prefix=self.upload.prefix();need(after['mappings']==[row for row in before['mappings'] if not row['path'].startswith(prefix)]
            and not any(row['path'].startswith(prefix) for row in after['mappings']))
    @operation
    def reserve(self):
        need(self.upload.files.state['resource']!='asset-stand.fbx');result=super().reserve();self.upload.bind_client('tree',self);return result


class GenerationAssetsUsage(GenerationClient,OwnedAssetsUsage):
    OWNER_VERSION=5
    def __init__(self,view,store,*,lock):
        super().__init__(view,store,lock=lock)
        if self.state is not None:view.bind_client('usage',self)
    def view(self):return self.source
    @operation
    def reserve(self):
        result=super().reserve();self.source.bind_client('usage',self);return result
