"""Explicit optional host-consumer completion using original Assets actions.

The common engine calls this only after all real observation and evidence
consumers succeeded. The receipt is custody, not a native/product reading.
No additional generic broker, fabricated checkpoint or source journal is used:
the existing current action and its immutable before/after original own the
completion. A later activation can never complete or retro-acknowledge it.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import need
from adapters.script_feature.history import same
from feature_journeys.consumed import arguments,result
from feature_journeys.contract import typed_equal
from feature_journeys.phase_fixture import validate as phase_original
from ios.adapters.assets_action_phase import AssetsActionPhases,AssetsActionScope


class AssetsStepConsumer:
    def __init__(self,actions,*,generation_view=None):
        need(type(actions) is AssetsActionPhases and not actions.historical)
        if generation_view is not None:
            from ios.adapters.assets_generation_view import AssetsGenerationView
            need(type(generation_view) is AssetsGenerationView and generation_view.actions is actions)
        self.actions,self.generation_view=actions,generation_view

    def current(self,event,previous):
        owner=self.actions;owner.live()
        need(same(owner.store.read(),owner.previous) and same(owner.envelope(),owner.previous))
        packet=owner.phase.status();owner.phase_packet(packet,event['stepIndex'],event['ticket'])
        phase_original(packet,run=owner.run,area='assets',request=packet['requestId'],epoch=packet['capturedEpochMs'],previous=previous)
        need(typed_equal(packet['activations'],previous['activations']))
        return packet

    def __call__(self,event):
        arguments('assets',event);owner=self.actions;owner.live()
        need(event['runId']==owner.run and owner.state is not None
            and same(owner.store.read(),owner.previous) and same(owner.envelope(),owner.previous))
        index,ticket=event['stepIndex'],event['ticket'];records=owner.state['records'];pending=owner.state['pending']
        if pending is None:
            # Only the latest completed action can repeat its receipt while its
            # exact original activation is STILL current. Older bytes remain
            # readable independently; they never reacquire fresh authority.
            need(index==len(records) and index>=1)
            # A generation factory is a current-action native owner. Repeated
            # completed receipts use the ordinary data-only consumer instead.
            need(self.generation_view is None)
            row=owner.read(index);need(row['ticket']==ticket)
            self.current(event,row['phaseAfter'])
        else:
            need(index==len(records)+1 and pending['index']==index and pending['ticket']==ticket)
            self.current(event,pending['after'] if pending['after'] is not None else pending['before'])
            if pending['after'] is None:
                need(pending['original'] is None)
                if self.generation_view is not None:
                    view=self.generation_view
                    need(view.action.index==index and view.action.ticket==ticket and view.run==event['runId'])
                    view.finish_action_replies();self.current(event,pending['before'])
                owner.complete(AssetsActionScope(owner,index,ticket),consumer_guard=lambda:self.current(event,pending['after']))
            else:
                # A saved original whose parent CAS failed may be replayed as
                # data-only bookkeeping, but ONLY in its actual current phase.
                # Planned/opened/missing originals remain unresolved duties.
                # No current native guard is reacquired after phaseAfter was
                # saved. Its typed generation recovery reader is a separate
                # unresolved dependency, and this optional live hook refuses.
                need(self.generation_view is None)
                need(pending['original'] is not None and pending['original']['phase']=='saved')
                owner.recover_completed(consumer_guard=lambda:self.current(event,pending['after']))
            row=owner.read(index);need(row['ticket']==ticket)
        return result('assets',dict(recorded=True))
