"""Actual FBX derived-mapping deletion through its new generation page.

The original Parsed/Baking/Backend lineage remains historical. A distinct
Tree6 owns current UI inputs and Reply4 proofs for the original e2e namespace.
Literal renamed BakedTree1 admission and its historical headers stay intact.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import need
from adapters.script_feature.history import same
from ios.adapters.assets_budget import operation
from ios.adapters.assets_baked_tree import OwnedAssetsBakedTree
from ios.adapters.assets_generation_clients import GenerationAssetsTree
from ios.adapters.assets_parsed_owner import OwnedAssetsParsedInput
from ios.adapters.assets_tree_owner import OwnedAssetsTree


def original_namespace_admission(before,*,owned_prefix,derived_prefix,original_hash,qualified,baseline_blobs):
    from adapters import asset_backend_source as source
    from ios.adapters.assets_tree_controls import owned_root
    source.digest(original_hash);owned_root(owned_prefix)
    need(owned_prefix.startswith('/e2e-') and derived_prefix=='/.baked/'+original_hash+'/')
    actual={row['path']:row['hash'] for row in before['mappings']}
    derived={path:digest for path,digest in actual.items() if path.startswith(derived_prefix)}
    need(len(actual)==len(before['mappings']) and derived and derived==qualified
        and not set(derived.values())&set(baseline_blobs))
    owned={path:digest for path,digest in actual.items() if path.startswith(owned_prefix)}
    need(owned and set(owned.values())=={original_hash}
        and not any(digest==original_hash and not path.startswith((owned_prefix,derived_prefix)) for path,digest in actual.items()))
    return dict(owned=owned,derived=derived)


class GenerationAssetsBakedTree(GenerationAssetsTree):
    OWNER_VERSION=6
    EXTRA_FIELDS=GenerationAssetsTree.EXTRA_FIELDS|frozenset({'bakedLineage'})
    def __init__(self,view,parsed,store,*,lock):
        need(isinstance(parsed,OwnedAssetsParsedInput) and parsed.model.usage.source is view.old_upload
            and view.namespace=='original' and view.generation.generation==4
            and view.files.state['resource']=='asset-stand.fbx')
        self.parsed,self.backend=parsed,parsed.baking.backend
        super().__init__(view,store,lock=lock)
    def extra_envelope(self):return dict(super().extra_envelope(),bakedLineage=self.lineage())
    def guard(self):
        super().guard();self.parsed.guard();need(same(self.backend.store.read(),self.backend.previous));return True
    lineage=OwnedAssetsBakedTree.lineage
    authority=OwnedAssetsBakedTree.authority
    @operation
    def reserve(self):
        self.guard();self.authority();result=OwnedAssetsTree.reserve(self);self.upload.bind_client('tree',self);return result
    def delete_admission(self,proof):
        super().delete_admission(proof);lineage,prefix,qualified,blobs=self.authority()
        return original_namespace_admission(proof,owned_prefix=self.prefix(),derived_prefix=prefix,
            original_hash=lineage['originalHash'],qualified=qualified,baseline_blobs=blobs)
    def deleted_proof(self,before,after):
        delta=self.delete_admission(before);lineage,prefix,_qualified,_blobs=self.authority()
        expected=[row for row in before['mappings'] if not row['path'].startswith((self.prefix(),prefix))]
        need(len({row['path'] for row in after['mappings']})==len(after['mappings']) and same(after['mappings'],expected))
        return delta
    @operation
    def deletion(self):
        self.guard();need(self.state['phase']=='deleted');self.decode(self.previous)
        return dict(assetGenerationBakedTreeDeleteProofVersion=1,runId=self.upload.files.run,role=self.upload.role,
            pageGeneration=self.upload.generation.link(),lineage=self.lineage(),
            mappings=self.deleted_proof(self.read_proof('tree-delete-admission'),self.read_proof('tree-deleted')),
            resourceRetirementAvailable=False)
