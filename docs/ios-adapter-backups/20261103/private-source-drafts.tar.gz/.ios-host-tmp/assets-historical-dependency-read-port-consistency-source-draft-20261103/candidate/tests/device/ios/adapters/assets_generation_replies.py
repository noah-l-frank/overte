"""Distinct per-action readers in each current page generation; original jobs remain historical.

Native start tickets are still the actual current action, while the existing
episode/file birth is unchanged. Separate per-action raw/query namespaces prevent a new
view from adopting/reopening the old generation's closed Reply3 owner.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from adapters.native_feature_observation import integer,need
from adapters.script_feature.history import same
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import time
from ios.adapters.assets_page_reentry import AssetsPageReentry
from ios.adapters.assets_action_reply_owner import ActionAssetsReplyReads
from ios.adapters.assets_reply_action_sources import AssetsReplyActionSources
from ios.adapters.assets_reply_sources import ReplySources


class GenerationReplySources(ReplySources):
    SCHEMA_PREFIX='iosAssetsGenReplySource'
    RECORD_KEY='iosAssetsGenReplySourceRecordVersion'
    MIGRATION_KEY='iosAssetsGenReplySourceMigrationVersion'
    def __init__(self,*args,generation,action_index,**kwargs):
        need(type(generation) is AssetsPageReentry and integer(action_index,1,29))
        prefix='assets-g'+str(generation.generation)+'-a'+str(action_index)
        self.NAMESPACE=prefix+'-native-replies';self.MIGRATION_PREFIX=prefix+'-replies-migration-'
        super().__init__(*args,**kwargs)


class GenerationReplyActionSources(AssetsReplyActionSources):
    OWNER_VERSION=2
    LINK_VERSION=2
    EXTRA_FIELDS=frozenset({'pageGeneration','queryActionIndex'})
    def __init__(self,*args,generation,action_index,**kwargs):
        self.generation,self.action_index=generation,action_index;super().__init__(*args,**kwargs)
    def source_path(self,owner):return owner.store.path.with_name('ios-assets-'+owner.run+'-primary-gen'+str(self.generation.generation)+'-action'+str(self.action_index)+'-reply-actions.json')
    def original_profile(self):return dict(namespace='assets-g'+str(self.generation.generation)+'-a'+str(self.action_index)+'-reply-actions',schema_prefix='iosAssetsGenReplyAction')
    def extra_envelope(self):return dict(pageGeneration=self.generation.link(),queryActionIndex=self.action_index)
    def extra_link(self):return self.extra_envelope()
    def record(self,row,index):
        super().record(row,index);need(row['actionIndex']==self.action_index);return row


class GenerationActionReplyReads(ActionAssetsReplyReads):
    CURRENT_VERSION=4
    def __init__(self,*args,generation,action_index,**kwargs):
        need(type(generation) is AssetsPageReentry and integer(action_index,1,29))
        self.generation,self.action_index,self.metadata=generation,action_index,None
        super().__init__(*args,**kwargs)
        limits={2:(9,13),3:(16,17),4:(22,23)};need(generation.generation in limits)
        first,last=limits[generation.generation];need(first<=action_index<=last)
        need(generation.selected is self.action_history.selected and (self.reply_action is None or self.reply_action.index==action_index)
            and self.store.path.name=='ios-assets-'+self.run+'-primary-gen'+str(generation.generation)+'-action'+str(action_index)+'-replies.json')
    def profile(self):
        self.sources=GenerationReplySources(self,self.role,self.source_guard,self.save,generation=self.generation,action_index=self.action_index)
        self.query_sources=GenerationReplyActionSources(self,self.action_history,self.reply_episode,self.reply_action,generation=self.generation,action_index=self.action_index,metadata=self.metadata)
    @classmethod
    def from_archive(cls,store,*,generation,episode,actions,action_index,metadata=None,monotonic=time.monotonic):
        # Original native/query sources still use their real immutable reader.
        # No SDK/native constructor, seeding/recovery, new query or retirement.
        from ios.adapters.assets_end_metadata import store as metadata_store
        from ios.adapters.assets_episode_metadata_graph import readonly_store
        need(type(generation) is AssetsPageReentry and generation.historical and integer(action_index,1,29))
        need(episode.owner.selected is generation.selected and actions.selected is generation.selected)
        limits={2:(9,13),3:(16,17),4:(22,23)};first,last=limits[generation.generation]
        need(first<=action_index<=last)
        if len(actions.state['records'])>=action_index:actions.read(action_index)
        else:
            pending=actions.state['pending'];need(pending is not None and pending['index']==action_index)
        owner=object.__new__(cls);owner.generation,owner.action_index,owner.metadata=generation,action_index,metadata
        owner.action_history,owner.reply_episode,owner.reply_action=actions,episode,None
        owner.run,owner.url,owner.role=actions.run,actions.context['fixtureUrl'],'primary'
        owner.binding=deepcopy(episode.owner.context['roles']['primary']['binding']);owner.lock=episode.locks['primary']
        owner.lock.assert_held();generation.guard();episode.guard();actions.guard()
        expected=Path(episode.descriptor['directories']['primary']['stateRoot']['path'])/('ios-assets-'+owner.run+'-primary-gen'+str(generation.generation)+'-action'+str(action_index)+'-replies.json')
        need(Path(store.path)==expected);owner.store=readonly_store(metadata_store(expected,metadata));owner.previous=owner.store.read();owner.state=None
        def forbidden(*_args,**_kwargs):raise RuntimeError('Historical generation replies cannot query, seed, write, recover or retire')
        owner.native=SimpleNamespace(pid=int(owner.binding['processIdentity']),monotonic=monotonic,guard=forbidden,
            request=forbidden,clock_ms=forbidden,sleep=forbidden,jobs={},last=None)
        owner.storage_version=owner.CURRENT_VERSION;owner.profile();need(owner.previous is not None)
        owner.state=owner.decode(owner.previous);owner.source_guard();return owner
    def source_guard(self):
        super().source_guard();self.reply_episode.guard();self.action_history.guard();self.generation.guard();return True
    def link(self):
        self.lock.assert_held();self.reply_episode.guard();self.action_history.guard()
        need(self.state is not None and same(self.store.read(),self.previous))
        return dict(iosAssetsGenerationActionReplyLinkVersion=1,path=str(self.store.path),token=self.state['token'],
            actionIndex=self.action_index,pageGeneration=self.generation.link(),replyActions=self.query_sources.link())
