"""Typed historical episode client graph over actual immutable originals.

This explicit subset replays old Upload/Tree/Usage in one synchronous inventory.
A new inventory must rebuild it before later generation use; no current verdict
is retained. Model/marker/image/backend/global duties remain separate;
this reader cannot qualify an episode directory, abort or whole feature end.
"""
# Copyright 2026 Overte contributors.
# SPDX-License-Identifier: Apache-2.0
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import time
from adapters.native_feature_observation import need
from adapters.normal_feature_state import PrivateFeatureState
from adapters.original_file_reads import collect
from adapters.original_frame_store import OriginalFrameStore
from adapters.script_feature.history import same
from ios.adapters.assets_action_phase import AssetsActionPhases
from ios.adapters.assets_episodes import AssetsEpisodeScope
from ios.adapters.assets_end_metadata import store as metadata_store,entries as metadata_entries,signature
from ios.adapters.assets_page_ownership import skeleton
from ios.adapters.assets_page_lease import OwnedAssetsPageLease
from ios.adapters.assets_page_clients import PageLeaseUpload,PageLeaseTree,PageLeaseOriginalTree,PageLeaseUsage,PageLeaseRenamedUsage
from ios.adapters.assets_reply_owner import OwnedAssetsReplyReads
from ios.adapters.assets_action_reply_owner import ActionAssetsReplyReads
from ios.adapters.assets_reply_action_sources import AssetsReplyActionSources
from ios.adapters.assets_reply_sources import ReplySources


def forbidden(*_args,**_kwargs):raise RuntimeError('Historical episode graph has no native/SDK/query/input/recovery/write/retirement port')


def readonly_store(original):
    # Preserve the actual reader (including an explicitly supplied logical
    # metadata profile), while refusing every exposed mutation method.
    class HistoricalRead(PrivateFeatureState):
        def read(self):return original.read()
        write=staticmethod(forbidden)
        discard=staticmethod(forbidden)
    return HistoricalRead(original.path)


class AssetsEpisodeClientGraph:
    def __init__(self,episode,page,*,actions=None,metadata=None,dependency_mode=False):
        need(type(episode) is AssetsEpisodeScope and isinstance(page,OwnedAssetsPageLease) and page.historical
            and page.episodes is episode.owner and (actions is None or type(actions) is AssetsActionPhases and actions.selected is episode.owner.selected))
        need(type(dependency_mode) is bool and (not dependency_mode or metadata is None))
        self.dependency_mode,self.original_pins=dependency_mode,None
        self.episode,self.page,self.actions,self.metadata=episode,page,actions,metadata
        self.role,self.run='primary',episode.owner.run;self.lock=episode.locks[self.role]
        self.binding=deepcopy(episode.owner.context['roles'][self.role]['binding'])
        self.root=Path(episode.descriptor['directories'][self.role]['stateRoot']['path'])
        self.active=True;self.headers={};self.reads=set();self.files=self.picker=self.replies=self.upload=self.tree=self.usage=None
        self.inventory={str(path):signature(path) for path in metadata_entries(self.root,metadata)}
        self.guard()
    def guard(self):
        need(self.active);self.episode.guard();self.lock.assert_held()
        for lock in self.episode.owner.locks.values():lock.assert_held()
        need(same(self.binding,self.episode.owner.context['roles'][self.role]['binding'])
            and self.root==Path(self.episode.descriptor['directories'][self.role]['stateRoot']['path']))
        for store,value in self.headers.values():need(same(store.read(),value))
        if not self.dependency_mode:need(self.inventory=={str(path):signature(path) for path in metadata_entries(self.root,self.metadata)})
        elif self.original_pins is not None:
            # This is an explicit dependency subset, not a directory census.
            # Unrelated NEW generation outputs may appear, while every actual
            # old original and header retains its physical/body custody.
            need(all(signature(path)==pin for path,pin in self.original_pins.items()))
        return True
    def store(self,kind):
        path=self.root/('ios-assets-'+self.run+'-primary-'+kind+'.json');store=readonly_store(metadata_store(path,self.metadata));value=store.read()
        self.headers[kind]=(store,deepcopy(value));return store,value
    def ports(self):
        # guard() establishes metadata custody only. Every operation capable
        # of producing a current fact or delivery is a distinct refusing port.
        return SimpleNamespace(pid=int(self.binding['processIdentity']),monotonic=time.monotonic,guard=self.guard,
            request=forbidden,read=forbidden,send=forbidden,clock_ms=forbidden,capture=forbidden,
            deliver=forbidden,assets_input=forbidden,sleep=forbidden,jobs={},last=None)
    def decode(self):
        self.guard()
        with collect() as reads:
            picker=skeleton(self.episode,self.metadata);picker.page_lease=self.page
            self.files,self.picker=picker.files,picker
            self.files.native=self.ports();self.files.store=readonly_store(self.files.store);picker.store=readonly_store(picker.store)
            self.headers['files']=(self.files.store,deepcopy(self.files.previous));self.headers['picker']=(picker.store,deepcopy(picker.previous))
            picker.state=picker.decode(picker.previous)
            need(self.page.pickers.get(self.episode.index) is picker or same(self.page.pickers[self.episode.index].previous,picker.previous))
            store,value=self.store('replies');need(value is not None)
            version=value.get('iosAssetsReplyOwnerVersion');need(version in (2,3))
            Replies=OwnedAssetsReplyReads if version==2 else ActionAssetsReplyReads
            replies=object.__new__(Replies);replies.native=self.ports()
            replies.run,replies.url,replies.binding,replies.role,replies.lock=self.run,self.episode.owner.context['fixtureUrl'],deepcopy(self.binding),self.role,self.lock
            replies.store,replies.previous,replies.state=store,deepcopy(value),None
            if version==3:
                need(type(self.actions) is AssetsActionPhases)
                replies.action_history,replies.reply_episode,replies.reply_action=self.actions,self.episode,None
                replies.query_sources=AssetsReplyActionSources(replies,self.actions,self.episode,None,metadata=self.metadata)
            replies.sources=ReplySources(replies,self.role,self.guard,forbidden);replies.state=replies.decode(value);self.replies=replies
            store,value=self.store('upload');need(value is not None and value.get('iosAssetsUploadOwnerVersion')==2)
            upload=object.__new__(PageLeaseUpload);upload.files,upload.picker,upload.replies=self.files,picker,replies
            upload.store,upload.previous,upload.state=store,deepcopy(value),None
            upload.binding,upload.role,upload.lock=deepcopy(self.binding),self.role,self.lock
            upload.native,upload.clock=self.ports(),self.ports();upload.monotonic=time.monotonic;upload.sleep=forbidden
            upload.page_lease,upload.episode=self.page,self.episode;upload._cached=[];upload._validated_refs=[];upload._projects=[]
            upload.originals=OriginalFrameStore(self.root,self.binding,self.run,self.role,self.guard,forbidden,namespace='assets-upload',schema_prefix='iosAssetsUpload')
            upload.state=upload.decode(value);self.upload=upload
            store,value=self.store('tree')
            if value is not None:
                version=value.get('iosAssetsTreeOwnerVersion');need(version in (3,4))
                Tree=PageLeaseTree if version==3 else PageLeaseOriginalTree
                tree=object.__new__(Tree);tree.upload,tree.store,tree.previous,tree.lock=upload,store,deepcopy(value),self.lock
                tree.native,tree.monotonic,tree.state=upload.native,time.monotonic,None;tree.state=tree.decode(value);self.tree=tree
            store,value=self.store('usage')
            if value is not None:
                version=value.get('iosAssetsUsageOwnerVersion');need(version in (3,4))
                Usage=PageLeaseUsage if version==3 else PageLeaseRenamedUsage
                usage=object.__new__(Usage);usage.source,usage.store,usage.previous,usage.lock=upload,store,deepcopy(value),self.lock
                usage.native,usage.monotonic,usage.state=upload.native,time.monotonic,None
                if version==4:need(type(self.tree) is PageLeaseTree);usage.tree=self.tree
                usage.state=usage.decode(value);self.usage=usage
            self.reads=set(reads)
            if self.dependency_mode:
                pins={str(path):signature(path) for path in self.reads};need(all(pin is not None for pin in pins.values()))
                if self.original_pins is not None:need(self.original_pins==pins)
                self.original_pins=pins
        self.guard();return self
    def responsibilities(self):
        self.guard();need(self.upload is not None)
        return dict(assetsEpisodeClientSubsetVersion=1,episode=self.episode.link(),actualOriginalReads=set(self.reads),
            typedOwners=['files','picker','replies','upload']+(['tree'] if self.tree is not None else [])+(['usage'] if self.usage is not None else []),
            duties=['old-page-client-generation-handoff','separate-model-marker-image-backend-duty'],
            immutableDependencySubset=self.dependency_mode,allowsUnrelatedNewGenerationOutputs=self.dependency_mode,
            completeEpisodeDirectoryRead=False,nativeFactsProduced=False,abortAuthorized=False,wholeEndEligible=False)
    def close(self):
        try:self.guard()
        finally:self.active=False
    def __enter__(self):self.guard();return self
    def __exit__(self,kind,error,traceback):
        try:self.close()
        except BaseException as secondary:
            if error is None:raise
            error.add_note('Closing the historical episode client inventory also failed: '+type(secondary).__name__)
        return False
